import Mathlib

/-!
# 被覆の不等式（Z₂ の符号の系、抽象の形）

紙： 節「定理 C（被覆の不等式）」。

有限群 `G`（配位。格子では「リンクの符号の場」、積は点ごとの積）の上の、値が ±1 の乗法的な関数
（符号の指標。格子では「面の符号」＝面の周りのリンクの符号の積）の族 `χ : ι → G → ℝ` と結合
`c : ι → ℝ` について、分配関数 `Z χ c = ∑ g, exp (∑ B, c B * χ B g)`。

* `Z_flip_le`（Griffiths 型の第一の不等式）：結合が非負なら、符号 `ζ = ±1` を掛けた（捩った）
  分配関数は掛けないものを越えない。
* `covering_ineq`（紙の定理 C）：被覆の系 `(G, χ)` と底の系 `(G₀, χ₀)` が、引き戻し
  `p : G₀ → G`（周期的な配位）で `χ B (p t) = χ₀ B t` と結ばれているとき、
  `Z χ K * Z χ₀ (ζK) ≤ Z χ (ζK) * Z χ₀ K`。格子では：n 重の被覆のトーラスの捩れた比は、
  底のトーラスの（結合 n 倍の）捩れた比以上。面 `B` の添字は被覆の側の面で数え、底の側の結合は
  同じ添字の上の和なので、一様な結合 K なら底の結合は「重なりの数 × K」になる。
* `covering_ratio`・`vfe_cover_le`：比の形と、渦の自由エネルギー −log(比) の形。
* `mon_ineq`・`mon_ratio`：Z₂ の符号の系の (Mon)（結合を増やすと捩れた比は増えない）。
* `covering_ineq_field`・`vfe_cover_le_field`・`mon_ineq_field`：符号の場の形（場所の集合 `X`、底 `X₀`、
  写像 `π : X → X₀`、台 `S : ι → Finset X` は任意。仮定は結合の非負と捩れの符号だけ）。
* `dominated_covering_ineq`・`dominated_covering_sum`・`dominated_covering_integral`（紙の定理 F）：
  被覆の側の結合の符号が定まらなくても、絶対値が強磁性の結合 `K` で抑えられていれば同じ不等式。
  SU(2) の系（リンクの符号の平均を先に取った形）と Z₂ の系の比べ。
* `card_mul_sum_exp`・`equivariant_dominated`：有限の配位の集合に符号の群が作用する系（中心 Z₂ を持つ
  有限群のゲージ理論。捩れの背景つきでよい）について、中心の平均まで含めた定理 F。
* `card_mul_integral_exp`・`invariant_dominated`：同じことを、符号の群の作用で積分が不変な測度の上で
  （SU(2) の Haar 測度の積がこの形）。
* `two_site_ring`・`two_site_mon`：仮定の欄が満たせる例（二点の Ising の輪が一点の輪を二重に覆う）。
-/

open Finset BigOperators

namespace CoveringInequality

section Defs

variable {G : Type*} [Fintype G] {ι : Type*} [Fintype ι]

/-- 分配関数：`Z χ c = ∑ g, exp (∑ B, c B * χ B g)`。 -/
noncomputable def Z (χ : ι → G → ℝ) (c : ι → ℝ) : ℝ :=
  ∑ g : G, Real.exp (∑ B : ι, c B * χ B g)

/-- 指標つきの和（帰納法のための一般化）。 -/
noncomputable def F (χ : ι → G → ℝ) (S : Finset ι) (ψ : G → ℝ) (c : ι → ℝ) : ℝ :=
  ∑ g : G, ψ g * ∏ B ∈ S, (Real.cosh (c B) + χ B g * Real.sinh (c B))

end Defs

section Basic

variable {G : Type*} [Fintype G] [Group G]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- 符号の指標：乗法的で、値が ±1。 -/
def IsSignChar (ψ : G → ℝ) : Prop :=
  (∀ g h : G, ψ (g * h) = ψ g * ψ h) ∧ ∀ g : G, ψ g = 1 ∨ ψ g = -1

omit [Fintype G] in
theorem isSignChar_one : IsSignChar (fun _ : G => (1 : ℝ)) :=
  ⟨fun _ _ => by norm_num, fun _ => Or.inl rfl⟩

omit [Fintype G] in
theorem IsSignChar.mul {ψ φ : G → ℝ} (hψ : IsSignChar ψ) (hφ : IsSignChar φ) :
    IsSignChar (fun g => ψ g * φ g) := by
  refine ⟨fun g h => ?_, fun g => ?_⟩
  · show ψ (g * h) * φ (g * h) = ψ g * φ g * (ψ h * φ h)
    rw [hψ.1 g h, hφ.1 g h]; ring
  · show ψ g * φ g = 1 ∨ ψ g * φ g = -1
    rcases hψ.2 g with h1 | h1 <;> rcases hφ.2 g with h2 | h2 <;> rw [h1, h2] <;> norm_num

/-- 符号の指標の和は非負（自明な指標なら位数、そうでなければ 0）。 -/
theorem sum_signChar_nonneg {ψ : G → ℝ} (hψ : IsSignChar ψ) : 0 ≤ ∑ g : G, ψ g := by
  by_cases h : ∃ a : G, ψ a = -1
  · obtain ⟨a, ha⟩ := h
    have e1 : ∑ g : G, ψ (g * a) = ∑ g : G, ψ g :=
      Fintype.sum_equiv (Equiv.mulRight a) (fun g => ψ (g * a)) ψ (fun _ => rfl)
    have e2 : ∑ g : G, ψ (g * a) = -∑ g : G, ψ g := by
      rw [← Finset.sum_neg_distrib]
      refine Finset.sum_congr rfl fun g _ => ?_
      rw [hψ.1 g a, ha]; ring
    linarith
  · have h' : ∀ a : G, ψ a = 1 := by
      intro a
      rcases hψ.2 a with h1 | h1
      · exact h1
      · exact absurd ⟨a, h1⟩ h
    refine Finset.sum_nonneg fun g _ => ?_
    rw [h' g]; norm_num

omit [Group G] [Fintype ι] in
theorem F_insert (χ : ι → G → ℝ) (S : Finset ι) (B : ι) (hB : B ∉ S) (ψ : G → ℝ) (c : ι → ℝ) :
    F χ (insert B S) ψ c = Real.cosh (c B) * F χ S ψ c
      + Real.sinh (c B) * F χ S (fun g => ψ g * χ B g) c := by
  unfold F
  rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun g _ => ?_
  rw [Finset.prod_insert hB]
  ring

omit [Fintype ι] in
/-- 帰納法の芯：捩った結合での指標つきの和の絶対値は、捩らない結合での和を越えない。 -/
theorem abs_F_le (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (J ζ : ι → ℝ)
    (hJ : ∀ B, 0 ≤ J B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) (S : Finset ι) :
    ∀ ψ : G → ℝ, IsSignChar ψ → |F χ S ψ (fun b => ζ b * J b)| ≤ F χ S ψ J := by
  induction S using Finset.induction_on with
  | empty =>
    intro ψ hψ
    have h0 : ∀ c : ι → ℝ, F χ ∅ ψ c = ∑ g : G, ψ g := by
      intro c; unfold F; simp
    have h1 : |F χ ∅ ψ (fun b => ζ b * J b)| = F χ ∅ ψ J := by
      rw [h0, h0, abs_of_nonneg (sum_signChar_nonneg hψ)]
    exact le_of_eq h1
  | insert B S hB ih =>
    intro ψ hψ
    have h1 := ih ψ hψ
    have h2 := ih (fun g => ψ g * χ B g) (hψ.mul (hχ B))
    have hcpos : 0 ≤ Real.cosh (J B) := (Real.cosh_pos _).le
    have hspos : 0 ≤ Real.sinh (J B) := Real.sinh_nonneg_iff.mpr (hJ B)
    have hc : Real.cosh (ζ B * J B) = Real.cosh (J B) := by
      rcases hζ B with h | h
      · rw [h, one_mul]
      · rw [h, neg_one_mul, Real.cosh_neg]
    have hs : |Real.sinh (ζ B * J B)| = Real.sinh (J B) := by
      rcases hζ B with h | h
      · rw [h, one_mul, abs_of_nonneg hspos]
      · rw [h, neg_one_mul, Real.sinh_neg, abs_neg, abs_of_nonneg hspos]
    have step1 : |Real.cosh (ζ B * J B) * F χ S ψ (fun b => ζ b * J b)
          + Real.sinh (ζ B * J B) * F χ S (fun g => ψ g * χ B g) (fun b => ζ b * J b)|
        ≤ Real.cosh (J B) * |F χ S ψ (fun b => ζ b * J b)|
          + Real.sinh (J B) * |F χ S (fun g => ψ g * χ B g) (fun b => ζ b * J b)| := by
      refine (abs_add_le _ _).trans (le_of_eq ?_)
      rw [abs_mul, abs_mul, hc, hs, abs_of_nonneg hcpos]
    have step2 : Real.cosh (J B) * |F χ S ψ (fun b => ζ b * J b)|
          + Real.sinh (J B) * |F χ S (fun g => ψ g * χ B g) (fun b => ζ b * J b)|
        ≤ Real.cosh (J B) * F χ S ψ J
          + Real.sinh (J B) * F χ S (fun g => ψ g * χ B g) J :=
      add_le_add (mul_le_mul_of_nonneg_left h1 hcpos) (mul_le_mul_of_nonneg_left h2 hspos)
    rw [F_insert χ S B hB ψ (fun b => ζ b * J b), F_insert χ S B hB ψ J]
    exact step1.trans step2

theorem exp_mul_sign (c x : ℝ) (hx : x = 1 ∨ x = -1) :
    Real.exp (c * x) = Real.cosh c + x * Real.sinh c := by
  rcases hx with h | h
  · rw [h, mul_one, one_mul, Real.cosh_eq, Real.sinh_eq]; ring
  · rw [h, mul_neg_one, Real.cosh_eq, Real.sinh_eq]; ring

omit [DecidableEq ι] in
theorem Z_eq_F (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (c : ι → ℝ) :
    Z χ c = F χ Finset.univ (fun _ => 1) c := by
  simp only [Z, F, one_mul]
  refine Finset.sum_congr rfl fun g _ => ?_
  rw [Real.exp_sum]
  exact Finset.prod_congr rfl fun B _ => exp_mul_sign (c B) (χ B g) ((hχ B).2 g)

/-- Griffiths 型の第一の不等式：非負の結合の符号を変えた（捩った）分配関数は、元を越えない。 -/
theorem Z_flip_le (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (J ζ : ι → ℝ)
    (hJ : ∀ B, 0 ≤ J B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ (fun b => ζ b * J b) ≤ Z χ J := by
  rw [Z_eq_F χ hχ (fun b => ζ b * J b), Z_eq_F χ hχ J]
  exact (le_abs_self _).trans (abs_F_le χ hχ J ζ hJ hζ Finset.univ _ isSignChar_one)

omit [DecidableEq ι] in
theorem Z_pos (χ : ι → G → ℝ) (c : ι → ℝ) : 0 < Z χ c := by
  unfold Z
  exact Finset.sum_pos (fun g _ => Real.exp_pos _) ⟨1, Finset.mem_univ 1⟩

end Basic

section Cover

variable {G : Type*} [Fintype G] [Group G]
variable {G₀ : Type*} [Fintype G₀] [Group G₀]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [Group G₀] [DecidableEq ι] in
/-- 鍵の恒等式：被覆の配位を `s = u * p t` と置き換えると、二つの分配関数の積は、
底の系の（`u` に依る結合での）分配関数の和になる。 -/
theorem Z_mul_Z (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (χ₀ : ι → G₀ → ℝ) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t) (J J' : ι → ℝ) :
    Z χ J * Z χ₀ J' = ∑ u : G, Z χ₀ (fun b => J b * χ b u + J' b) := by
  simp only [Z]
  calc (∑ s : G, Real.exp (∑ b, J b * χ b s)) * (∑ t : G₀, Real.exp (∑ b, J' b * χ₀ b t))
      = ∑ s : G, ∑ t : G₀, Real.exp (∑ b, J b * χ b s) * Real.exp (∑ b, J' b * χ₀ b t) :=
        Finset.sum_mul_sum _ _ _ _
    _ = ∑ t : G₀, ∑ s : G, Real.exp (∑ b, J b * χ b s) * Real.exp (∑ b, J' b * χ₀ b t) :=
        Finset.sum_comm
    _ = ∑ t : G₀, ∑ u : G,
          Real.exp (∑ b, J b * χ b (u * p t)) * Real.exp (∑ b, J' b * χ₀ b t) := by
        refine Finset.sum_congr rfl fun t _ => ?_
        exact (Fintype.sum_equiv (Equiv.mulRight (p t))
          (fun u => Real.exp (∑ b, J b * χ b (u * p t)) * Real.exp (∑ b, J' b * χ₀ b t))
          (fun s => Real.exp (∑ b, J b * χ b s) * Real.exp (∑ b, J' b * χ₀ b t))
          (fun _ => rfl)).symm
    _ = ∑ t : G₀, ∑ u : G, Real.exp (∑ b, (J b * χ b u + J' b) * χ₀ b t) := by
        refine Finset.sum_congr rfl fun t _ => Finset.sum_congr rfl fun u _ => ?_
        rw [← Real.exp_add, ← Finset.sum_add_distrib]
        congr 1
        refine Finset.sum_congr rfl fun b _ => ?_
        rw [(hχ b).1 u (p t), hp b t]; ring
    _ = ∑ u : G, ∑ t : G₀, Real.exp (∑ b, (J b * χ b u + J' b) * χ₀ b t) :=
        Finset.sum_comm

/-- **被覆の不等式**（紙の定理 C）。`K ≥ 0`、`ζ = ±1`、`χ B (p t) = χ₀ B t` のとき
`Z_被覆(K) · Z_底(ζK) ≤ Z_被覆(ζK) · Z_底(K)`。 -/
theorem covering_ineq (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ K * Z χ₀ (fun b => ζ b * K b) ≤ Z χ (fun b => ζ b * K b) * Z χ₀ K := by
  rw [Z_mul_Z χ hχ χ₀ p hp K (fun b => ζ b * K b),
    Z_mul_Z χ hχ χ₀ p hp (fun b => ζ b * K b) K]
  show ∑ u : G, Z χ₀ (fun b => K b * χ b u + ζ b * K b)
      ≤ ∑ u : G, Z χ₀ (fun b => ζ b * K b * χ b u + K b)
  refine Finset.sum_le_sum fun u _ => ?_
  have key : (fun b => K b * χ b u + ζ b * K b)
      = fun b => ζ b * (ζ b * K b * χ b u + K b) := by
    funext b
    show K b * χ b u + ζ b * K b = ζ b * (ζ b * K b * χ b u + K b)
    rcases hζ b with h | h <;> rw [h] <;> ring
  rw [key]
  refine Z_flip_le χ₀ hχ₀ (fun b => ζ b * K b * χ b u + K b) ζ (fun b => ?_) hζ
  show 0 ≤ ζ b * K b * χ b u + K b
  have hKb := hK b
  rcases hζ b with h | h <;> rcases (hχ b).2 u with h' | h' <;> rw [h, h'] <;> linarith

/-- **抑えられた結合の被覆の不等式**（紙の定理 F の芯）。被覆の側の結合 `J` は符号が定まらなくてよい。
`|J B| ≤ K B`、`ζ = ±1`、`χ B (p t) = χ₀ B t` のとき `Z_被覆(J) · Z_底(ζK) ≤ Z_被覆(ζJ) · Z_底(K)`。
`J = K` が `covering_ineq`、底＝被覆で `J = K ≤ K'` が `mon_ineq` に当たる。 -/
theorem dominated_covering_ineq (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J K ζ : ι → ℝ) (hJ : ∀ B, |J B| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ J * Z χ₀ (fun b => ζ b * K b) ≤ Z χ (fun b => ζ b * J b) * Z χ₀ K := by
  rw [Z_mul_Z χ hχ χ₀ p hp J (fun b => ζ b * K b),
    Z_mul_Z χ hχ χ₀ p hp (fun b => ζ b * J b) K]
  show ∑ u : G, Z χ₀ (fun b => J b * χ b u + ζ b * K b)
      ≤ ∑ u : G, Z χ₀ (fun b => ζ b * J b * χ b u + K b)
  refine Finset.sum_le_sum fun u _ => ?_
  have key : (fun b => J b * χ b u + ζ b * K b)
      = fun b => ζ b * (ζ b * J b * χ b u + K b) := by
    funext b
    show J b * χ b u + ζ b * K b = ζ b * (ζ b * J b * χ b u + K b)
    rcases hζ b with h | h <;> rw [h] <;> ring
  rw [key]
  refine Z_flip_le χ₀ hχ₀ (fun b => ζ b * J b * χ b u + K b) ζ (fun b => ?_) hζ
  show 0 ≤ ζ b * J b * χ b u + K b
  have h1 := abs_le.mp (hJ b)
  have h2 := h1.1
  have h3 := h1.2
  rcases hζ b with h | h <;> rcases (hχ b).2 u with h' | h' <;> rw [h, h'] <;> linarith

/-- 重みつきの有限和の形：`Ω` の点ごとに結合 `J ω`（`|J ω B| ≤ K B`）、重み `μ ω ≥ 0`。 -/
theorem dominated_covering_sum {Ω : Type*} [Fintype Ω] (μ : Ω → ℝ) (hμ : ∀ ω, 0 ≤ μ ω)
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J : Ω → ι → ℝ) (K ζ : ι → ℝ) (hJ : ∀ ω B, |J ω B| ≤ K B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∑ ω, μ ω * Z χ (J ω)) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∑ ω, μ ω * Z χ (fun b => ζ b * J ω b)) * Z χ₀ K := by
  rw [Finset.sum_mul, Finset.sum_mul]
  refine Finset.sum_le_sum fun ω _ => ?_
  rw [mul_assoc, mul_assoc]
  exact mul_le_mul_of_nonneg_left
    (dominated_covering_ineq χ hχ χ₀ hχ₀ p hp (J ω) K ζ (hJ ω) hζ) (hμ ω)

/-- **積分の形**（紙の定理 F）：測度 `μ` の上の配位 `ω`（SU(2) では中心を割った側の配位）ごとに
Z₂ の符号の系の結合 `J ω` が決まり、`|J ω B| ≤ K B` のとき、
`(∫ Z_被覆(J ω) dμ) · Z_底(ζK) ≤ (∫ Z_被覆(ζ J ω) dμ) · Z_底(K)`。
SU(2) の Wilson 作用では `J ω p = z₀(p)·(β/2) tr U_p`、`K = β`（リンクの符号の平均を先に取った形）。 -/
theorem dominated_covering_integral {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J : Ω → ι → ℝ) (K ζ : ι → ℝ) (hJ : ∀ ω B, |J ω B| ≤ K B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1)
    (h1 : MeasureTheory.Integrable (fun ω => Z χ (J ω)) μ)
    (h2 : MeasureTheory.Integrable (fun ω => Z χ (fun b => ζ b * J ω b)) μ) :
    (∫ ω, Z χ (J ω) ∂μ) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∫ ω, Z χ (fun b => ζ b * J ω b) ∂μ) * Z χ₀ K := by
  rw [← MeasureTheory.integral_mul_const, ← MeasureTheory.integral_mul_const]
  exact MeasureTheory.integral_mono (h1.mul_const _) (h2.mul_const _)
    (fun ω => dominated_covering_ineq χ hχ χ₀ hχ₀ p hp (J ω) K ζ (hJ ω) hζ)

/-- 比の形：底の捩れた比 ≤ 被覆の捩れた比。 -/
theorem covering_ratio (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ₀ (fun b => ζ b * K b) / Z χ₀ K ≤ Z χ (fun b => ζ b * K b) / Z χ K := by
  rw [div_le_div_iff₀ (Z_pos χ₀ K) (Z_pos χ K)]
  exact (mul_comm _ _).trans_le (covering_ineq χ hχ χ₀ hχ₀ p hp K ζ hK hζ)

/-- 渦の自由エネルギーの形：被覆の −log(捩れた比) ≤ 底の −log(捩れた比)。 -/
theorem vfe_cover_le (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    -Real.log (Z χ (fun b => ζ b * K b) / Z χ K)
      ≤ -Real.log (Z χ₀ (fun b => ζ b * K b) / Z χ₀ K) := by
  have h := covering_ratio χ hχ χ₀ hχ₀ p hp K ζ hK hζ
  have hpos : 0 < Z χ₀ (fun b => ζ b * K b) / Z χ₀ K := div_pos (Z_pos _ _) (Z_pos _ _)
  exact neg_le_neg (Real.log_le_log hpos h)

end Cover

section Equivariant

variable {G : Type*} [Fintype G] [Group G]
variable {G₀ : Type*} [Fintype G₀] [Group G₀]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [DecidableEq ι] in
/-- 中心の平均（有限の場合）：配位の有限集合 `Ω` に符号の群 `G` が作用し、結合が
`J B (g • ω) = χ B g * J B ω` と変わるなら、`Ω` の上の重みの和は、`ω` ごとの Z₂ の符号の系の
分配関数の和に書ける。格子のゲージ理論では `Ω` はリンクの配位、`G` はリンクごとの中心の符号。 -/
theorem card_mul_sum_exp {Ω : Type*} [Fintype Ω] [MulAction G Ω]
    (χ : ι → G → ℝ) (J : ι → Ω → ℝ) (hJ : ∀ B g ω, J B (g • ω) = χ B g * J B ω) :
    (Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, J B ω)
      = ∑ ω : Ω, Z χ (fun b => J b ω) := by
  simp only [Z]
  calc (Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, J B ω)
      = ∑ _g : G, ∑ ω : Ω, Real.exp (∑ B, J B ω) := by
        rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    _ = ∑ g : G, ∑ ω : Ω, Real.exp (∑ B, J B (g • ω)) := by
        refine Finset.sum_congr rfl fun g _ => ?_
        exact (Fintype.sum_equiv (MulAction.toPerm g)
          (fun ω => Real.exp (∑ B, J B (g • ω)))
          (fun ω => Real.exp (∑ B, J B ω)) (fun _ => rfl)).symm
    _ = ∑ g : G, ∑ ω : Ω, Real.exp (∑ B, J B ω * χ B g) := by
        refine Finset.sum_congr rfl fun g _ => Finset.sum_congr rfl fun ω _ => ?_
        congr 1
        refine Finset.sum_congr rfl fun B _ => ?_
        rw [hJ B g ω]; ring
    _ = ∑ ω : Ω, ∑ g : G, Real.exp (∑ B, J B ω * χ B g) := Finset.sum_comm

/-- **中心 Z₂ を持つ有限の系と、Z₂ の符号の系の比べ**（紙の定理 F の有限の場合。中心の平均まで含む）。
配位 `Ω`（例：リンクの上の Q₈ の元）、符号の群の作用、結合 `J B ω`（例：捩れの背景つきの面の指標
`z₀(B)·β·Re χ(U_B)/d`）が `J B (g • ω) = χ B g * J B ω`、`|J B ω| ≤ K B` を満たすとき、
`(Σ_ω e^{Σ J}) · Z_底(ζK) ≤ (Σ_ω e^{Σ ζJ}) · Z_底(K)`：捩れた比は、Z₂ の底の系の捩れた比以上。 -/
theorem equivariant_dominated {Ω : Type*} [Fintype Ω] [MulAction G Ω]
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J : ι → Ω → ℝ) (hJ : ∀ B g ω, J B (g • ω) = χ B g * J B ω)
    (K ζ : ι → ℝ) (hK : ∀ B ω, |J B ω| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∑ ω : Ω, Real.exp (∑ B, J B ω)) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∑ ω : Ω, Real.exp (∑ B, ζ B * J B ω)) * Z χ₀ K := by
  have hcard : (0 : ℝ) < Fintype.card G := Nat.cast_pos.mpr Fintype.card_pos
  have h' : (∑ ω : Ω, Z χ (fun b => J b ω)) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∑ ω : Ω, Z χ (fun b => ζ b * J b ω)) * Z χ₀ K := by
    rw [Finset.sum_mul, Finset.sum_mul]
    exact Finset.sum_le_sum fun ω _ =>
      dominated_covering_ineq χ hχ χ₀ hχ₀ p hp (fun b => J b ω) K ζ (fun B => hK B ω) hζ
  have e1 : (Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, J B ω)
      = ∑ ω : Ω, Z χ (fun b => J b ω) := card_mul_sum_exp χ J hJ
  have e2 : (Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, ζ B * J B ω)
      = ∑ ω : Ω, Z χ (fun b => ζ b * J b ω) :=
    card_mul_sum_exp χ (fun B ω => ζ B * J B ω) (fun B g ω => by
      show ζ B * J B (g • ω) = χ B g * (ζ B * J B ω)
      rw [hJ B g ω]; ring)
  rw [← e1, ← e2] at h'
  refine le_of_mul_le_mul_left ?_ hcard
  calc (Fintype.card G : ℝ) * ((∑ ω : Ω, Real.exp (∑ B, J B ω)) * Z χ₀ (fun b => ζ b * K b))
      = ((Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, J B ω))
          * Z χ₀ (fun b => ζ b * K b) := by ring
    _ ≤ ((Fintype.card G : ℝ) * ∑ ω : Ω, Real.exp (∑ B, ζ B * J B ω)) * Z χ₀ K := h'
    _ = (Fintype.card G : ℝ) * ((∑ ω : Ω, Real.exp (∑ B, ζ B * J B ω)) * Z χ₀ K) := by ring

/-- `equivariant_dominated` の仮定の欄が満たせる例：`Ω = G`（左からの積の作用）、`J B ω = K B * χ B ω`。
このとき左辺・右辺は Z₂ の符号の系そのもので、結論は被覆の不等式に戻る。 -/
theorem equivariant_example (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∑ ω : G, Real.exp (∑ B, K B * χ B ω)) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∑ ω : G, Real.exp (∑ B, ζ B * (K B * χ B ω))) * Z χ₀ K :=
  equivariant_dominated χ hχ χ₀ hχ₀ p hp (fun B ω => K B * χ B ω)
    (fun B g ω => by
      show K B * χ B (g * ω) = χ B g * (K B * χ B ω)
      rw [(hχ B).1 g ω]; ring)
    K ζ
    (fun B ω => by
      show |K B * χ B ω| ≤ K B
      rcases (hχ B).2 ω with h | h
      · rw [h, mul_one, abs_of_nonneg (hK B)]
      · rw [h, mul_neg_one, abs_neg, abs_of_nonneg (hK B)])
    hζ

end Equivariant

section Invariant

variable {G : Type*} [Fintype G] [Group G]
variable {G₀ : Type*} [Fintype G₀] [Group G₀]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [Group G] [DecidableEq ι] in
theorem Z_eq_sum_comm (χ : ι → G → ℝ) (c : ι → ℝ) :
    Z χ c = ∑ g : G, Real.exp (∑ B, χ B g * c B) := by
  simp only [Z]
  refine Finset.sum_congr rfl fun g _ => ?_
  congr 1
  exact Finset.sum_congr rfl fun B _ => mul_comm _ _

omit [DecidableEq ι] in
/-- 中心の平均（測度の場合）：測度 `μ` の積分が符号の群 `G` の作用で不変（`hinv`）で、結合が
`J B (g • ω) = χ B g * J B ω` と変わるなら、`|G| · ∫ e^{Σ J} dμ = ∫ Z(J(ω)) dμ`。 -/
theorem card_mul_integral_exp {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MulAction G Ω]
    (hinv : ∀ (g : G) (f : Ω → ℝ), ∫ ω, f (g • ω) ∂μ = ∫ ω, f ω ∂μ)
    (χ : ι → G → ℝ) (J : ι → Ω → ℝ) (hJ : ∀ B g ω, J B (g • ω) = χ B g * J B ω)
    (hint : ∀ g : G, MeasureTheory.Integrable (fun ω => Real.exp (∑ B, χ B g * J B ω)) μ) :
    (Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, J B ω) ∂μ
      = ∫ ω, Z χ (fun b => J b ω) ∂μ := by
  have hZ : (fun ω => Z χ (fun b => J b ω))
      = fun ω => ∑ g : G, Real.exp (∑ B, χ B g * J B ω) :=
    funext fun ω => Z_eq_sum_comm χ (fun b => J b ω)
  rw [hZ, MeasureTheory.integral_finsetSum Finset.univ (fun g _ => hint g)]
  calc (Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, J B ω) ∂μ
      = ∑ _g : G, ∫ ω, Real.exp (∑ B, J B ω) ∂μ := by
        rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    _ = ∑ g : G, ∫ ω, Real.exp (∑ B, χ B g * J B ω) ∂μ := by
        refine Finset.sum_congr rfl fun g _ => ?_
        have h1 : ∫ ω, Real.exp (∑ B, J B (g • ω)) ∂μ = ∫ ω, Real.exp (∑ B, J B ω) ∂μ :=
          hinv g (fun ω => Real.exp (∑ B, J B ω))
        have h2 : (fun ω => Real.exp (∑ B, J B (g • ω)))
            = fun ω => Real.exp (∑ B, χ B g * J B ω) := by
          funext ω
          congr 1
          exact Finset.sum_congr rfl fun B _ => hJ B g ω
        exact h1.symm.trans (congrArg (fun f : Ω → ℝ => ∫ ω, f ω ∂μ) h2)

/-- **不変な測度の上の系と、Z₂ の符号の系の比べ**（紙の定理 F、中心の平均まで含む。測度の場合）。
SU(2) の Wilson 作用では：`Ω` はリンクの配位、`μ` は Haar 測度の積、`G` はリンクごとの符号、
`J B ω = z₀(B)·(β/2)·tr U_B`（`z₀` は捩れの背景）、`K = β`。結論は
`Z_{SU(2)}[z₀] · Z_底(ζK) ≤ Z_{SU(2)}[z₀ζ] · Z_底(K)`。 -/
theorem invariant_dominated {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MulAction G Ω]
    (hinv : ∀ (g : G) (f : Ω → ℝ), ∫ ω, f (g • ω) ∂μ = ∫ ω, f ω ∂μ)
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J : ι → Ω → ℝ) (hJ : ∀ B g ω, J B (g • ω) = χ B g * J B ω)
    (K ζ : ι → ℝ) (hK : ∀ B ω, |J B ω| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1)
    (hint : ∀ c : ι → ℝ,
      MeasureTheory.Integrable (fun ω => Real.exp (∑ B, c B * J B ω)) μ) :
    (∫ ω, Real.exp (∑ B, J B ω) ∂μ) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ) * Z χ₀ K := by
  have hcard : (0 : ℝ) < Fintype.card G := Nat.cast_pos.mpr Fintype.card_pos
  have hi1 : ∀ g : G,
      MeasureTheory.Integrable (fun ω => Real.exp (∑ B, χ B g * J B ω)) μ :=
    fun g => hint (fun B => χ B g)
  have hi2 : ∀ g : G,
      MeasureTheory.Integrable (fun ω => Real.exp (∑ B, χ B g * (ζ B * J B ω))) μ := by
    intro g
    have e : (fun ω => Real.exp (∑ B, χ B g * (ζ B * J B ω)))
        = fun ω => Real.exp (∑ B, (χ B g * ζ B) * J B ω) := by
      funext ω
      congr 1
      exact Finset.sum_congr rfl fun B _ => (mul_assoc _ _ _).symm
    rw [e]
    exact hint (fun B => χ B g * ζ B)
  have e1 : (Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, J B ω) ∂μ
      = ∫ ω, Z χ (fun b => J b ω) ∂μ := card_mul_integral_exp μ hinv χ J hJ hi1
  have e2 : (Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ
      = ∫ ω, Z χ (fun b => ζ b * J b ω) ∂μ :=
    card_mul_integral_exp μ hinv χ (fun B ω => ζ B * J B ω) (fun B g ω => by
      show ζ B * J B (g • ω) = χ B g * (ζ B * J B ω)
      rw [hJ B g ω]; ring) hi2
  have hI1 : MeasureTheory.Integrable (fun ω => Z χ (fun b => J b ω)) μ := by
    have hZ : (fun ω => Z χ (fun b => J b ω))
        = fun ω => ∑ g : G, Real.exp (∑ B, χ B g * J B ω) :=
      funext fun ω => Z_eq_sum_comm χ (fun b => J b ω)
    rw [hZ]
    exact MeasureTheory.integrable_finsetSum Finset.univ (fun g _ => hi1 g)
  have hI2 : MeasureTheory.Integrable (fun ω => Z χ (fun b => ζ b * J b ω)) μ := by
    have hZ : (fun ω => Z χ (fun b => ζ b * J b ω))
        = fun ω => ∑ g : G, Real.exp (∑ B, χ B g * (ζ B * J B ω)) :=
      funext fun ω => Z_eq_sum_comm χ (fun b => ζ b * J b ω)
    rw [hZ]
    exact MeasureTheory.integrable_finsetSum Finset.univ (fun g _ => hi2 g)
  have h'' : (∫ ω, Z χ (fun b => J b ω) ∂μ) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∫ ω, Z χ (fun b => ζ b * J b ω) ∂μ) * Z χ₀ K :=
    dominated_covering_integral μ χ hχ χ₀ hχ₀ p hp (fun ω b => J b ω) K ζ
      (fun ω B => hK B ω) hζ hI1 hI2
  rw [← e1, ← e2] at h''
  refine le_of_mul_le_mul_left ?_ hcard
  calc (Fintype.card G : ℝ)
        * ((∫ ω, Real.exp (∑ B, J B ω) ∂μ) * Z χ₀ (fun b => ζ b * K b))
      = ((Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, J B ω) ∂μ)
          * Z χ₀ (fun b => ζ b * K b) := by ring
    _ ≤ ((Fintype.card G : ℝ) * ∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ) * Z χ₀ K := h''
    _ = (Fintype.card G : ℝ)
          * ((∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ) * Z χ₀ K) := by ring

/-- `invariant_dominated` の仮定の欄が空でないことの確認（一点の空間、結合 0。結論は底の系の
`Z_flip_le` に測度の全質量を掛けたもの）。SU(2) の Haar 測度が欄を満たすことは紙。 -/
theorem invariant_example (μ : MeasureTheory.Measure PUnit) [MeasureTheory.IsFiniteMeasure μ]
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∫ _ω : PUnit, Real.exp (∑ _B : ι, (0 : ℝ)) ∂μ) * Z χ₀ (fun b => ζ b * K b)
      ≤ (∫ _ω : PUnit, Real.exp (∑ B : ι, ζ B * (0 : ℝ)) ∂μ) * Z χ₀ K :=
  invariant_dominated μ (fun _ _ => rfl) χ hχ χ₀ hχ₀ p hp (fun _ _ => (0 : ℝ))
    (fun B g ω => by simp) K ζ (fun B ω => by simpa using hK B) hζ
    (fun c => by simp)

/-- 渦の自由エネルギーの形（紙の定理 F の見出しの形）：不変な測度の上の系の
`ΔF = −log(∫e^{ΣζJ}dμ / ∫e^{ΣJ}dμ)` は、Z₂ の底の系の `ΔF₀ = −log(Z₀(ζK)/Z₀(K))` 以下。
SU(2) では左辺が捩れた板の渦の自由エネルギー（背景の捩れは `J` に入れる）。 -/
theorem invariant_vfe_le {Ω : Type*} [MeasurableSpace Ω] (μ : MeasureTheory.Measure Ω)
    [MulAction G Ω]
    (hinv : ∀ (g : G) (f : Ω → ℝ), ∫ ω, f (g • ω) ∂μ = ∫ ω, f ω ∂μ)
    (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (χ₀ : ι → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → G)
    (hp : ∀ B t, χ B (p t) = χ₀ B t)
    (J : ι → Ω → ℝ) (hJ : ∀ B g ω, J B (g • ω) = χ B g * J B ω)
    (K ζ : ι → ℝ) (hK : ∀ B ω, |J B ω| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1)
    (hint : ∀ c : ι → ℝ,
      MeasureTheory.Integrable (fun ω => Real.exp (∑ B, c B * J B ω)) μ)
    (hpos : 0 < ∫ ω, Real.exp (∑ B, J B ω) ∂μ) :
    -Real.log ((∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ) / (∫ ω, Real.exp (∑ B, J B ω) ∂μ))
      ≤ -Real.log (Z χ₀ (fun b => ζ b * K b) / Z χ₀ K) := by
  have h := invariant_dominated μ hinv χ hχ χ₀ hχ₀ p hp J hJ K ζ hK hζ hint
  have hx0 : 0 < Z χ₀ (fun b => ζ b * K b) / Z χ₀ K := div_pos (Z_pos _ _) (Z_pos _ _)
  have hle : Z χ₀ (fun b => ζ b * K b) / Z χ₀ K
      ≤ (∫ ω, Real.exp (∑ B, ζ B * J B ω) ∂μ) / (∫ ω, Real.exp (∑ B, J B ω) ∂μ) := by
    rw [div_le_div_iff₀ (Z_pos χ₀ K) hpos]
    exact (mul_comm _ _).trans_le h
  exact neg_le_neg (Real.log_le_log hx0 hle)

end Invariant

section Mon

variable {G : Type*} [Fintype G] [Group G]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

omit [DecidableEq ι] in
/-- 指標のずらし：結合に `χ b u` を掛けても分配関数は変わらない（配位の置き換え `g ↦ g * u`）。 -/
theorem Z_char_shift (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (u : G) (c : ι → ℝ) :
    Z χ (fun b => χ b u * c b) = Z χ c := by
  simp only [Z]
  refine Fintype.sum_equiv (Equiv.mulRight u) _ _ (fun g => ?_)
  show Real.exp (∑ b, χ b u * c b * χ b g) = Real.exp (∑ b, c b * χ b (g * u))
  congr 1
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [(hχ b).1 g u]; ring

/-- **Z₂ の符号の系の (Mon)**（教科書 13-06 の (2) の、捩れの背景の無い Z₂ の場合の差分の形）：
結合を項ごとに増やすと、捩れた比は増えない。`0 ≤ K ≤ K'`、`ζ = ±1` のとき
`Z(ζK') · Z(K) ≤ Z(K') · Z(ζK)`。 -/
theorem mon_ineq (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (K K' ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hKK' : ∀ B, K B ≤ K' B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ (fun b => ζ b * K' b) * Z χ K ≤ Z χ K' * Z χ (fun b => ζ b * K b) := by
  rw [Z_mul_Z χ hχ χ (fun t => t) (fun _ _ => rfl) (fun b => ζ b * K' b) K,
    Z_mul_Z χ hχ χ (fun t => t) (fun _ _ => rfl) K' (fun b => ζ b * K b)]
  show ∑ u : G, Z χ (fun b => ζ b * K' b * χ b u + K b)
      ≤ ∑ u : G, Z χ (fun b => K' b * χ b u + ζ b * K b)
  refine Finset.sum_le_sum fun u _ => ?_
  have hm : ∀ b, 0 ≤ K' b + ζ b * χ b u * K b := by
    intro b
    have h1 := hK b
    have h2 := hKK' b
    rcases hζ b with h | h <;> rcases (hχ b).2 u with h' | h' <;> rw [h, h'] <;> linarith
  have e1 : (fun b => ζ b * K' b * χ b u + K b)
      = fun b => χ b u * (ζ b * (K' b + ζ b * χ b u * K b)) := by
    funext b
    show ζ b * K' b * χ b u + K b = χ b u * (ζ b * (K' b + ζ b * χ b u * K b))
    rcases hζ b with h | h <;> rcases (hχ b).2 u with h' | h' <;> rw [h, h'] <;> ring
  have e2 : (fun b => K' b * χ b u + ζ b * K b)
      = fun b => χ b u * (K' b + ζ b * χ b u * K b) := by
    funext b
    show K' b * χ b u + ζ b * K b = χ b u * (K' b + ζ b * χ b u * K b)
    rcases hζ b with h | h <;> rcases (hχ b).2 u with h' | h' <;> rw [h, h'] <;> ring
  rw [e1, e2]
  calc Z χ (fun b => χ b u * (ζ b * (K' b + ζ b * χ b u * K b)))
      = Z χ (fun b => ζ b * (K' b + ζ b * χ b u * K b)) :=
        Z_char_shift χ hχ u (fun b => ζ b * (K' b + ζ b * χ b u * K b))
    _ ≤ Z χ (fun b => K' b + ζ b * χ b u * K b) :=
        Z_flip_le χ hχ (fun b => K' b + ζ b * χ b u * K b) ζ hm hζ
    _ = Z χ (fun b => χ b u * (K' b + ζ b * χ b u * K b)) :=
        (Z_char_shift χ hχ u (fun b => K' b + ζ b * χ b u * K b)).symm

/-- (Mon) の比の形：`K ≤ K'` なら捩れた比は `K'` の方が小さい（渦の自由エネルギーは大きい）。 -/
theorem mon_ratio (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B))
    (K K' ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hKK' : ∀ B, K B ≤ K' B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ (fun b => ζ b * K' b) / Z χ K' ≤ Z χ (fun b => ζ b * K b) / Z χ K := by
  rw [div_le_div_iff₀ (Z_pos χ K') (Z_pos χ K)]
  exact (mon_ineq χ hχ K K' ζ hK hKK' hζ).trans_eq (mul_comm _ _)

/-- 捩れた比は 1 以下。 -/
theorem flip_ratio_le_one (χ : ι → G → ℝ) (hχ : ∀ B, IsSignChar (χ B)) (K ζ : ι → ℝ)
    (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z χ (fun b => ζ b * K b) / Z χ K ≤ 1 :=
  (div_le_one (Z_pos χ K)).mpr (Z_flip_le χ hχ K ζ hK hζ)

/-- 一つの箱の判定（紙の系 C1 の算術）：被覆の率 `σc` が底の（結合を n 倍にした）率 `σb'` 以上で、
`n · σb' ≥ e^δ · σb` なら、`n · σc ≥ e^δ · σb`。 -/
theorem step_of_one_box (n σc σb' σb δ : ℝ) (hn : 0 ≤ n) (h1 : σb' ≤ σc)
    (h2 : Real.exp δ * σb ≤ n * σb') : Real.exp δ * σb ≤ n * σc :=
  h2.trans (mul_le_mul_of_nonneg_left h1 hn)

end Mon

section Example

/-- ±1 の符号（整数の単数）を実数に。 -/
def sgn (u : ℤˣ) : ℝ := ((u : ℤ) : ℝ)

theorem sgn_isSignChar : IsSignChar (G := ℤˣ) sgn := by
  refine ⟨fun g h => ?_, fun g => ?_⟩
  · simp [sgn]
  · rcases Int.units_eq_one_or g with h | h <;> simp [sgn, h]

theorem sgn_fst : IsSignChar (G := ℤˣ × ℤˣ) (fun g => sgn g.1) :=
  ⟨fun g h => sgn_isSignChar.1 g.1 h.1, fun g => sgn_isSignChar.2 g.1⟩

theorem sgn_snd : IsSignChar (G := ℤˣ × ℤˣ) (fun g => sgn g.2) :=
  ⟨fun g h => sgn_isSignChar.1 g.2 h.2, fun g => sgn_isSignChar.2 g.2⟩

/-- 例の被覆の側の指標：二点の輪の結合 `a·b`（二本とも同じ）。 -/
def chiPair : Bool → ℤˣ × ℤˣ → ℝ := fun _ g => sgn g.1 * sgn g.2

/-- 例の底の側の指標：一点の輪の結合 `t·t`（= 1）。 -/
def chiOne : Bool → ℤˣ → ℝ := fun _ t => sgn t * sgn t

theorem chiPair_isSignChar (b : Bool) : IsSignChar (chiPair b) :=
  sgn_fst.mul sgn_snd

theorem chiOne_isSignChar (b : Bool) : IsSignChar (chiOne b) :=
  sgn_isSignChar.mul sgn_isSignChar

theorem chi_pull (b : Bool) (t : ℤˣ) : chiPair b (t, t) = chiOne b t := by
  show sgn (t, t).1 * sgn (t, t).2 = sgn t * sgn t
  rfl

/-- 仮定の欄が満たせる例：二点の Ising の輪（二本の結合、配位 `(a, b)`、指標 `a·b`）が、
一点の輪（指標 `t·t = 1`）を二重に覆う。`p t = (t, t)`。`ζ` で一本の結合の符号を変えると
反周期の境界条件。 -/
theorem two_site_ring (K ζ : Bool → ℝ) (hK : ∀ b, 0 ≤ K b) (hζ : ∀ b, ζ b = 1 ∨ ζ b = -1) :
    Z chiPair K * Z chiOne (fun b => ζ b * K b)
      ≤ Z chiPair (fun b => ζ b * K b) * Z chiOne K :=
  covering_ineq chiPair chiPair_isSignChar chiOne chiOne_isSignChar
    (fun t : ℤˣ => ((t, t) : ℤˣ × ℤˣ)) chi_pull K ζ hK hζ

/-- (Mon) の仮定の欄が満たせる例：同じ二点の輪。 -/
theorem two_site_mon (K K' ζ : Bool → ℝ) (hK : ∀ b, 0 ≤ K b) (hKK' : ∀ b, K b ≤ K' b)
    (hζ : ∀ b, ζ b = 1 ∨ ζ b = -1) :
    Z chiPair (fun b => ζ b * K' b) * Z chiPair K
      ≤ Z chiPair K' * Z chiPair (fun b => ζ b * K b) :=
  mon_ineq chiPair chiPair_isSignChar K K' ζ hK hKK' hζ

end Example

section Field

/-- 符号の場の系の指標：場所の集合 `X` の上の符号の場 `s : X → ℤˣ` の、台 `S B` の上の積。
格子のゲージ理論では `X` はリンクの集合、`S B` は面 `B` の周りのリンク。 -/
noncomputable def chiField {X ι : Type*} (S : ι → Finset X) : ι → (X → ℤˣ) → ℝ :=
  fun B s => ∏ x ∈ S B, sgn (s x)

/-- 底の側の指標：底の符号の場 `t : X₀ → ℤˣ` を `π : X → X₀` で引き戻し、同じ台の上で積を取る。
格子では、面 `B` の像 `π(B)` の周りの符号の積（重なったリンクは二乗で消える）。 -/
noncomputable def chiPull {X X₀ ι : Type*} (π : X → X₀) (S : ι → Finset X) :
    ι → (X₀ → ℤˣ) → ℝ :=
  fun B t => ∏ x ∈ S B, sgn (t (π x))

theorem chiPull_isSignChar {X X₀ ι : Type*} (π : X → X₀) (S : ι → Finset X) (B : ι) :
    IsSignChar (chiPull π S B) := by
  refine ⟨fun s t => ?_, fun s => ?_⟩
  · show ∏ x ∈ S B, sgn ((s * t) (π x))
        = (∏ x ∈ S B, sgn (s (π x))) * ∏ x ∈ S B, sgn (t (π x))
    rw [← Finset.prod_mul_distrib]
    exact Finset.prod_congr rfl fun x _ => sgn_isSignChar.1 (s (π x)) (t (π x))
  · show (∏ x ∈ S B, sgn (s (π x))) = 1 ∨ (∏ x ∈ S B, sgn (s (π x))) = -1
    refine Finset.prod_induction (fun x => sgn (s (π x))) (fun r => r = 1 ∨ r = -1) ?_
      (Or.inl rfl) ?_
    · intro a b ha hb
      rcases ha with h | h <;> rcases hb with h' | h' <;> rw [h, h'] <;> norm_num
    · intro x _
      exact sgn_isSignChar.2 (s (π x))

theorem chiField_isSignChar {X ι : Type*} (S : ι → Finset X) (B : ι) :
    IsSignChar (chiField S B) :=
  chiPull_isSignChar (fun x : X => x) S B

theorem chiField_pull {X X₀ ι : Type*} (π : X → X₀) (S : ι → Finset X) (B : ι)
    (t : X₀ → ℤˣ) : chiField S B (fun x => t (π x)) = chiPull π S B t := rfl

/-- **被覆の不等式、符号の場の形**（紙の定理 C の、Z₂ の格子の系への当てはめの形）。
仮定は結合の非負と捩れの符号だけ。`π`・`S` は任意。 -/
theorem covering_ineq_field {X X₀ ι : Type*} [Fintype X] [DecidableEq X] [Fintype X₀]
    [DecidableEq X₀] [Fintype ι] [DecidableEq ι] (π : X → X₀) (S : ι → Finset X)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z (chiField S) K * Z (chiPull π S) (fun b => ζ b * K b)
      ≤ Z (chiField S) (fun b => ζ b * K b) * Z (chiPull π S) K :=
  covering_ineq (chiField S) (chiField_isSignChar S) (chiPull π S) (chiPull_isSignChar π S)
    (fun (t : X₀ → ℤˣ) (x : X) => t (π x)) (chiField_pull π S) K ζ hK hζ

/-- 渦の自由エネルギーの形、符号の場の形。 -/
theorem vfe_cover_le_field {X X₀ ι : Type*} [Fintype X] [DecidableEq X] [Fintype X₀]
    [DecidableEq X₀] [Fintype ι] [DecidableEq ι] (π : X → X₀) (S : ι → Finset X)
    (K ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    -Real.log (Z (chiField S) (fun b => ζ b * K b) / Z (chiField S) K)
      ≤ -Real.log (Z (chiPull π S) (fun b => ζ b * K b) / Z (chiPull π S) K) :=
  vfe_cover_le (chiField S) (chiField_isSignChar S) (chiPull π S) (chiPull_isSignChar π S)
    (fun (t : X₀ → ℤˣ) (x : X) => t (π x)) (chiField_pull π S) K ζ hK hζ

/-- Z₂ の符号の場の系の (Mon)、符号の場の形。仮定は `0 ≤ K ≤ K'` と捩れの符号だけ。 -/
theorem mon_ineq_field {X ι : Type*} [Fintype X] [DecidableEq X] [Fintype ι] [DecidableEq ι]
    (S : ι → Finset X) (K K' ζ : ι → ℝ) (hK : ∀ B, 0 ≤ K B) (hKK' : ∀ B, K B ≤ K' B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z (chiField S) (fun b => ζ b * K' b) * Z (chiField S) K
      ≤ Z (chiField S) K' * Z (chiField S) (fun b => ζ b * K b) :=
  mon_ineq (chiField S) (chiField_isSignChar S) K K' ζ hK hKK' hζ

/-- 抑えられた結合の被覆の不等式、符号の場の形・積分の形（紙の定理 F の、格子への当てはめの形）。
`X`・`X₀`・`π`・`S` は任意。仮定は `|J ω B| ≤ K B`、捩れの符号、二つの可積分性。 -/
theorem dominated_covering_integral_field {X X₀ ι Ω : Type*} [Fintype X] [DecidableEq X]
    [Fintype X₀] [DecidableEq X₀] [Fintype ι] [DecidableEq ι] [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) (π : X → X₀) (S : ι → Finset X)
    (J : Ω → ι → ℝ) (K ζ : ι → ℝ) (hJ : ∀ ω B, |J ω B| ≤ K B)
    (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1)
    (h1 : MeasureTheory.Integrable (fun ω => Z (chiField S) (J ω)) μ)
    (h2 : MeasureTheory.Integrable (fun ω => Z (chiField S) (fun b => ζ b * J ω b)) μ) :
    (∫ ω, Z (chiField S) (J ω) ∂μ) * Z (chiPull π S) (fun b => ζ b * K b)
      ≤ (∫ ω, Z (chiField S) (fun b => ζ b * J ω b) ∂μ) * Z (chiPull π S) K :=
  dominated_covering_integral μ (chiField S) (chiField_isSignChar S) (chiPull π S)
    (chiPull_isSignChar π S) (fun (t : X₀ → ℤˣ) (x : X) => t (π x)) (chiField_pull π S)
    J K ζ hJ hζ h1 h2

/-- 仮定の欄が満たせる例（空でないことの確認）：一点の測度（Dirac）、結合は定数 `J`。
可積分性は自動で、結論は `dominated_covering_ineq` の符号の場の形に戻る。 -/
theorem dominated_field_const {X X₀ ι : Type*} [Fintype X] [DecidableEq X]
    [Fintype X₀] [DecidableEq X₀] [Fintype ι] [DecidableEq ι]
    (π : X → X₀) (S : ι → Finset X)
    (J K ζ : ι → ℝ) (hJ : ∀ B, |J B| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    Z (chiField S) J * Z (chiPull π S) (fun b => ζ b * K b)
      ≤ Z (chiField S) (fun b => ζ b * J b) * Z (chiPull π S) K :=
  dominated_covering_ineq (chiField S) (chiField_isSignChar S) (chiPull π S)
    (chiPull_isSignChar π S) (fun (t : X₀ → ℤˣ) (x : X) => t (π x)) (chiField_pull π S)
    J K ζ hJ hζ

/-- `dominated_covering_integral_field` の仮定の欄が満たせる例（空でないことの確認）：
有限の測度と、配位に依らない結合。可積分性は定数関数として払える。 -/
theorem dominated_integral_const {X X₀ ι Ω : Type*} [Fintype X] [DecidableEq X]
    [Fintype X₀] [DecidableEq X₀] [Fintype ι] [DecidableEq ι] [MeasurableSpace Ω]
    (μ : MeasureTheory.Measure Ω) [MeasureTheory.IsFiniteMeasure μ]
    (π : X → X₀) (S : ι → Finset X)
    (J K ζ : ι → ℝ) (hJ : ∀ B, |J B| ≤ K B) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∫ _ω : Ω, Z (chiField S) J ∂μ) * Z (chiPull π S) (fun b => ζ b * K b)
      ≤ (∫ _ω : Ω, Z (chiField S) (fun b => ζ b * J b) ∂μ) * Z (chiPull π S) K :=
  dominated_covering_integral_field μ π S (fun _ => J) K ζ (fun _ => hJ) hζ
    (MeasureTheory.integrable_const (Z (chiField S) J))
    (MeasureTheory.integrable_const (Z (chiField S) (fun b => ζ b * J b)))

/-- 実例（格子の系）：n 点の Ising の輪（場所 `ZMod n`、結合 `i` の台は `{i, i + 1}`）が、一点の輪を
n 重に覆う。`ζ` で一本の結合の符号を変えると反周期の境界条件。底の側では結合が足し合わされる。 -/
theorem ising_ring_covering (n : ℕ) [NeZero n] (K ζ : ZMod n → ℝ) (hK : ∀ i, 0 ≤ K i)
    (hζ : ∀ i, ζ i = 1 ∨ ζ i = -1) :
    Z (chiField (fun i : ZMod n => ({i, i + 1} : Finset (ZMod n)))) K
        * Z (chiPull (fun _ : ZMod n => PUnit.unit)
            (fun i : ZMod n => ({i, i + 1} : Finset (ZMod n)))) (fun b => ζ b * K b)
      ≤ Z (chiField (fun i : ZMod n => ({i, i + 1} : Finset (ZMod n)))) (fun b => ζ b * K b)
        * Z (chiPull (fun _ : ZMod n => PUnit.unit)
            (fun i : ZMod n => ({i, i + 1} : Finset (ZMod n)))) K :=
  covering_ineq_field (fun _ : ZMod n => PUnit.unit)
    (fun i : ZMod n => ({i, i + 1} : Finset (ZMod n))) K ζ hK hζ

end Field

end CoveringInequality

#print axioms CoveringInequality.sum_signChar_nonneg
#print axioms CoveringInequality.abs_F_le
#print axioms CoveringInequality.Z_flip_le
#print axioms CoveringInequality.Z_mul_Z
#print axioms CoveringInequality.covering_ineq
#print axioms CoveringInequality.covering_ratio
#print axioms CoveringInequality.vfe_cover_le
#print axioms CoveringInequality.two_site_ring
#print axioms CoveringInequality.Z_char_shift
#print axioms CoveringInequality.mon_ineq
#print axioms CoveringInequality.mon_ratio
#print axioms CoveringInequality.flip_ratio_le_one
#print axioms CoveringInequality.step_of_one_box
#print axioms CoveringInequality.two_site_mon
#print axioms CoveringInequality.chiPull_isSignChar
#print axioms CoveringInequality.covering_ineq_field
#print axioms CoveringInequality.vfe_cover_le_field
#print axioms CoveringInequality.mon_ineq_field

#print axioms CoveringInequality.dominated_covering_ineq
#print axioms CoveringInequality.dominated_covering_sum
#print axioms CoveringInequality.dominated_covering_integral
#print axioms CoveringInequality.dominated_covering_integral_field
#print axioms CoveringInequality.dominated_field_const
#print axioms CoveringInequality.card_mul_sum_exp
#print axioms CoveringInequality.equivariant_dominated
#print axioms CoveringInequality.equivariant_example
#print axioms CoveringInequality.dominated_integral_const
#print axioms CoveringInequality.card_mul_integral_exp
#print axioms CoveringInequality.invariant_dominated
#print axioms CoveringInequality.invariant_example
#print axioms CoveringInequality.ising_ring_covering
#print axioms CoveringInequality.invariant_vfe_le
