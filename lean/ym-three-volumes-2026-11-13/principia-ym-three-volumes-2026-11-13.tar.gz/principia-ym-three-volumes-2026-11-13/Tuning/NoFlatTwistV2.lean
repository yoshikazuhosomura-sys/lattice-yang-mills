import Wilson.SU2TwistV2
import Tuning.FlatStokesV1

/-!
# (1,1) の区画に欠け 0 の配位は無い、と最小の欠けが正（全ての N, M ≥ 1）

紙：(iii) の芯（§2.1）。
* `no_flat_twist11`：背景の捩れ n₁₂ = n₃₄ = 1（`zt N M true true`）で、全ての面で
  `z_B Re U_B = 1` となる配位 ω は無い。証明：欠け 0 なら面のホロノミーは中心の符号 z_B に等しく
  （`hol_eq_of_flat`）、面の関係 `U_μ(x) U_ν(x+μ) = z · U_ν(x) U_μ(x+ν)` から、離散の Stokes
  （`FlatStokes.torus_commutator`）で原点の周回 W₀, W₁（長さ N）、W₂, W₃（長さ M）について
  W₀W₁ = −W₁W₀、W₂W₃ = −W₃W₂、W₀W₂ = W₂W₀、W₁W₂ = W₂W₁。これは単位四元数で両立しない
  （`FlatStokes.no_twisted_quadruple`）。
* `action_lt_card`：全ての ω で `Σ_B z_B Re U_B < |P|`（面の数）。
* `defect11_floor`：欠け `D(ω) = Σ_B (1 − z_B Re U_B)` は正の下限を持ち、その下限は達せられる。
  `minDefect11_pos`：`0 < ⨅ ω, D(ω)`。
-/

open Finset TwistedWilson FlatStokes

namespace TwistFlat

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem zt_pm (a b : Bool) (B : Plaq N M) : zt N M a b B = 1 ∨ zt N M a b B = -1 := by
  unfold zt tw; split_ifs <;> norm_num

theorem normSq_unit (u : SU2) : Quaternion.normSq (u : ℍr) = 1 := by
  rw [Quaternion.normSq_eq_norm_mul_self, norm_eq_of_mem_sphere, one_mul]

theorem star_mul_unit (u : SU2) : star (u : ℍr) * (u : ℍr) = 1 := by
  rw [Quaternion.star_mul_self, normSq_unit]; simp

theorem star_mul_unit_left (u : SU2) (Z : ℍr) : star (u : ℍr) * ((u : ℍr) * Z) = Z := by
  rw [← mul_assoc, star_mul_unit, one_mul]

/-- 欠け 0 の面のホロノミーは捩れの符号そのもの -/
theorem hol_eq_of_flat (a b : Bool) (ω : Link N M → SU2) (B : Plaq N M)
    (h : zt N M a b B * (hol N M ω B).re = 1) : hol N M ω B = ((zt N M a b B : ℝ) : ℍr) :=
  ThickFloor.eq_of_re_eq_one _ (by rw [Quaternion.normSq_eq_norm_mul_self, norm_hol, one_mul]) _
    (zt_pm N M a b B) h

/-- **面の関係**：欠け 0 なら `U_μ(x) U_ν(x+μ) = z_{(x,μν)} • (U_ν(x) U_μ(x+ν))` -/
theorem plaq_rel (a b : Bool) (ω : Link N M → SU2)
    (hflat : ∀ B, zt N M a b B * (hol N M ω B).re = 1) (P : Plane) (x : Site N M) :
    (ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      = zt N M a b (x, P) • ((ω (x, P.1.2) : ℍr) * (ω (x + ev N M P.1.2, P.1.1) : ℍr)) := by
  have h := hol_eq_of_flat N M a b ω (x, P) (hflat _)
  have hh : hol N M ω (x, P) = (ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      * star (ω (x + ev N M P.1.2, P.1.1) : ℍr) * star (ω (x, P.1.2) : ℍr) := rfl
  have key : (ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      = hol N M ω (x, P) * ((ω (x, P.1.2) : ℍr) * (ω (x + ev N M P.1.2, P.1.1) : ℍr)) := by
    rw [hh]; simp only [mul_assoc, star_mul_unit_left, star_mul_unit, mul_one]
  rw [key, h, Quaternion.coe_mul_eq_smul]

theorem nsmul_ev0 : N • ev N M 0 = 0 := by
  simp [ev, Prod.smul_mk, nsmul_eq_mul]
theorem nsmul_ev1 : N • ev N M 1 = 0 := by
  simp [ev, Prod.smul_mk, nsmul_eq_mul]
theorem nsmul_ev2 : M • ev N M 2 = 0 := by
  simp [ev, Prod.smul_mk, nsmul_eq_mul]
theorem nsmul_ev3 : M • ev N M 3 = 0 := by
  simp [ev, Prod.smul_mk, nsmul_eq_mul]

def pl02 : Plane := ⟨(0, 2), by decide⟩
def pl12 : Plane := ⟨(1, 2), by decide⟩

theorem natCast_zero_iff (L : ℕ) [NeZero L] (k : ℕ) (hk : k < L) : ((k : ZMod L) = 0 ↔ k = 0) := by
  rw [ZMod.natCast_eq_zero_iff]
  constructor
  · intro h; exact Nat.eq_zero_of_dvd_of_lt h hk
  · rintro rfl; exact dvd_zero L

theorem prod_delta (L : ℕ) [NeZero L] :
    ∏ i ∈ range L, (if i = 0 then (-1 : ℝ) else 1) = -1 := by
  rw [Finset.prod_ite_eq' (range L) 0 (fun _ => (-1 : ℝ))]
  simp [NeZero.pos L]

theorem prod_delta2 (L : ℕ) [NeZero L] :
    ∏ j ∈ range L, ∏ i ∈ range L, (if i = 0 ∧ j = 0 then (-1 : ℝ) else 1) = -1 := by
  have h : ∀ j, ∏ i ∈ range L, (if i = 0 ∧ j = 0 then (-1 : ℝ) else 1)
      = if j = 0 then -1 else 1 := by
    intro j
    by_cases hj : j = 0
    · simp only [hj, and_true, if_true]; exact prod_delta L
    · simp [hj]
  simp only [h]; exact prod_delta L

/-- 切り口 (1,2) の符号の積は −1 -/
theorem sheet_p01 :
    sheetSign (fun y => zt N M true true (y, p01)) (ev N M 0) (ev N M 1) N N 0 = -1 := by
  unfold sheetSign lineSign
  rw [← prod_delta2 N]
  refine Finset.prod_congr rfl fun j hj => Finset.prod_congr rfl fun i hi => ?_
  have hi' := natCast_zero_iff N i (Finset.mem_range.1 hi)
  have hj' := natCast_zero_iff N j (Finset.mem_range.1 hj)
  unfold zt tw
  simp [ev, p01, p23, Prod.smul_mk, nsmul_eq_mul, Prod.ext_iff, hi', hj']

/-- 切り口 (3,4) の符号の積は −1 -/
theorem sheet_p23 :
    sheetSign (fun y => zt N M true true (y, p23)) (ev N M 2) (ev N M 3) M M 0 = -1 := by
  unfold sheetSign lineSign
  rw [← prod_delta2 M]
  refine Finset.prod_congr rfl fun j hj => Finset.prod_congr rfl fun i hi => ?_
  have hi' := natCast_zero_iff M i (Finset.mem_range.1 hi)
  have hj' := natCast_zero_iff M j (Finset.mem_range.1 hj)
  unfold zt tw
  simp [ev, p01, p23, Prod.smul_mk, nsmul_eq_mul, Prod.ext_iff, hi', hj']

theorem zt_pl02 (y : Site N M) : zt N M true true (y, pl02) = 1 := by
  unfold zt; simp [pl02, p01, p23]

theorem zt_pl12 (y : Site N M) : zt N M true true (y, pl12) = 1 := by
  unfold zt; simp [pl12, p01, p23]

theorem sheetSign_one {G : Type*} [AddCommGroup G] (e f : G) (L L' : ℕ) (x : G) :
    sheetSign (fun _ => (1 : ℝ)) e f L L' x = 1 := by
  simp [sheetSign, lineSign]

/-- **(1,1) の区画に欠け 0 の配位は無い**（全ての N, M ≥ 1） -/
theorem no_flat_twist11 (ω : Link N M → SU2) :
    ¬ ∀ B : Plaq N M, zt N M true true B * (hol N M ω B).re = 1 := by
  intro hflat
  have hu : ∀ μ : Fin 4, ∀ x : Site N M, Quaternion.normSq (ω (x, μ) : ℍr) = 1 :=
    fun μ x => normSq_unit _
  set W0 := lineProd (fun x => (ω (x, 0) : ℍr)) (ev N M 0) 0 N
  set W1 := lineProd (fun x => (ω (x, 1) : ℍr)) (ev N M 1) 0 N
  set W2 := lineProd (fun x => (ω (x, 2) : ℍr)) (ev N M 2) 0 M
  set W3 := lineProd (fun x => (ω (x, 3) : ℍr)) (ev N M 3) 0 M
  have h01 := torus_commutator (fun x => (ω (x, 0) : ℍr)) (fun x => (ω (x, 1) : ℍr))
    (fun y => zt N M true true (y, p01)) (ev N M 0) (ev N M 1) N N (nsmul_ev0 N M) (nsmul_ev1 N M)
    (fun x => plaq_rel N M true true ω hflat p01 x) 0
  have h23 := torus_commutator (fun x => (ω (x, 2) : ℍr)) (fun x => (ω (x, 3) : ℍr))
    (fun y => zt N M true true (y, p23)) (ev N M 2) (ev N M 3) M M (nsmul_ev2 N M) (nsmul_ev3 N M)
    (fun x => plaq_rel N M true true ω hflat p23 x) 0
  have h02 := torus_commutator (fun x => (ω (x, 0) : ℍr)) (fun x => (ω (x, 2) : ℍr))
    (fun _ => (1 : ℝ)) (ev N M 0) (ev N M 2) N M (nsmul_ev0 N M) (nsmul_ev2 N M)
    (fun x => by
      have := plaq_rel N M true true ω hflat pl02 x
      rw [zt_pl02] at this; exact this) 0
  have h12 := torus_commutator (fun x => (ω (x, 1) : ℍr)) (fun x => (ω (x, 2) : ℍr))
    (fun _ => (1 : ℝ)) (ev N M 1) (ev N M 2) N M (nsmul_ev1 N M) (nsmul_ev2 N M)
    (fun x => by
      have := plaq_rel N M true true ω hflat pl12 x
      rw [zt_pl12] at this; exact this) 0
  rw [sheet_p01, neg_one_smul] at h01
  rw [sheet_p23, neg_one_smul] at h23
  rw [sheetSign_one, one_smul] at h02 h12
  exact no_twisted_quadruple W0 W1 W2 W3
    (normSq_lineProd _ _ (hu 0) N 0) (normSq_lineProd _ _ (hu 1) N 0)
    (normSq_lineProd _ _ (hu 2) M 0) (normSq_lineProd _ _ (hu 3) M 0) h01 h23 h02 h12

theorem term_le_one (a b : Bool) (ω : Link N M → SU2) (B : Plaq N M) :
    zt N M a b B * (hol N M ω B).re ≤ 1 := by
  calc zt N M a b B * (hol N M ω B).re ≤ |zt N M a b B * (hol N M ω B).re| := le_abs_self _
    _ = |(hol N M ω B).re| := by rw [abs_mul, abs_zt, one_mul]
    _ ≤ 1 := abs_re_le_one _ (norm_hol N M ω B)

/-- **全ての ω で作用は面の数より真に小さい**（背景 (1,1)） -/
theorem action_lt_card (ω : Link N M → SU2) :
    ∑ B, zt N M true true B * (hol N M ω B).re < (Fintype.card (Plaq N M) : ℝ) := by
  have hex : ∃ B ∈ (univ : Finset (Plaq N M)), zt N M true true B * (hol N M ω B).re < 1 := by
    by_contra hne
    push_neg at hne
    exact no_flat_twist11 N M ω fun B =>
      le_antisymm (term_le_one N M true true ω B) (hne B (mem_univ B))
  calc ∑ B, zt N M true true B * (hol N M ω B).re < ∑ _B : Plaq N M, (1 : ℝ) :=
        Finset.sum_lt_sum (fun B _ => term_le_one N M true true ω B) hex
    _ = (Fintype.card (Plaq N M) : ℝ) := by simp

/-- 欠け `D(ω) = Σ_B (1 − z_B Re U_B)`（背景 (1,1)） -/
noncomputable def defect11 (ω : Link N M → SU2) : ℝ :=
  ∑ B, (1 - zt N M true true B * (hol N M ω B).re)

theorem defect11_eq (ω : Link N M → SU2) :
    defect11 N M ω = (Fintype.card (Plaq N M) : ℝ) - ∑ B, zt N M true true B * (hol N M ω B).re := by
  unfold defect11; rw [Finset.sum_sub_distrib]; simp

theorem continuous_action (a b : Bool) :
    Continuous fun ω : Link N M → SU2 => ∑ B, zt N M a b B * (hol N M ω B).re :=
  continuous_finset_sum _ fun B _ => continuous_const.mul (continuous_hol_re N M B)

theorem continuous_defect11 : Continuous (defect11 N M) := by
  have : defect11 N M = fun ω => (Fintype.card (Plaq N M) : ℝ)
      - ∑ B, zt N M true true B * (hol N M ω B).re := funext (defect11_eq N M)
  rw [this]; exact continuous_const.sub (continuous_action N M true true)

/-- **最小の欠けは正で、達せられる**：ある ω⋆ で全ての ω について `0 < D(ω⋆) ≤ D(ω)` -/
theorem defect11_floor : ∃ ωs : Link N M → SU2, 0 < defect11 N M ωs ∧
    ∀ ω, defect11 N M ωs ≤ defect11 N M ω := by
  obtain ⟨ωs, -, hmin⟩ := isCompact_univ.exists_isMinOn
    (⟨fun _ => 1, Set.mem_univ _⟩ : (Set.univ : Set (Link N M → SU2)).Nonempty)
    (continuous_defect11 N M).continuousOn
  refine ⟨ωs, ?_, fun ω => hmin (Set.mem_univ ω)⟩
  rw [defect11_eq]; linarith [action_lt_card N M ωs]

/-- **`0 < inf_ω D(ω)`** -/
theorem minDefect11_pos : 0 < ⨅ ω, defect11 N M ω := by
  obtain ⟨ωs, hpos, hmin⟩ := defect11_floor N M
  exact lt_of_lt_of_le hpos (le_ciInf hmin)

end TwistFlat

#print axioms TwistFlat.no_flat_twist11
#print axioms TwistFlat.defect11_floor
#print axioms TwistFlat.minDefect11_pos
