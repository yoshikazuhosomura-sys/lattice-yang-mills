import Blocks.TheoremEV2

/-!
# 渦の比 θ の合わせ：連続性と合わせの存在（(i)(ii)）

`TwistBlocks.thetaM N M β = (Z(1,0) − Z(1,1))/(Z(1,0) + Z(1,1))`（`TwistedWilson.ZW`）について
* `ZW_continuous`：β ↦ ZW N M β a b は連続（Haar の確率測度の上の有界な指数の積分）。
* `thetaM_continuous`：β ↦ θ は連続（分母は `ZW_pos` で正）。
* `thetaM_zero`：θ(0) = 0。
* `tuning_exists`：0 ≤ κ ≤ θ(β₁)、0 ≤ β₁ なら [0, β₁] に θ(β) = κ の解。
* `tuning_max_exists`：その解の集合に最大の元が在る（β*(κ; N) の [0, β₁] での形）。
-/

open MeasureTheory Filter Topology Finset

namespace ThetaTuning

open TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 作用の和の絶対値は面の数で抑えられる -/
theorem abs_action_le (a b : Bool) (ω : Link N M → SU2) :
    |∑ B, zt N M a b B * (hol N M ω B).re| ≤ (Fintype.card (Plaq N M) : ℝ) := by
  calc |∑ B, zt N M a b B * (hol N M ω B).re|
      ≤ ∑ B, |zt N M a b B * (hol N M ω B).re| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _B : Plaq N M, (1 : ℝ) := by
        refine Finset.sum_le_sum fun B _ => ?_
        rw [abs_mul]
        have h1 : |zt N M a b B| ≤ 1 := by
          unfold zt tw; split_ifs <;> simp
        have h2 : |(hol N M ω B).re| ≤ 1 := abs_re_le_one _ (norm_hol N M ω B)
        calc |zt N M a b B| * |(hol N M ω B).re| ≤ 1 * 1 :=
              mul_le_mul h1 h2 (abs_nonneg _) zero_le_one
          _ = 1 := one_mul 1
    _ = (Fintype.card (Plaq N M) : ℝ) := by simp

theorem aesm_exp (β : ℝ) (a b : Bool) :
    AEStronglyMeasurable (fun ω => Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re))
      (haarCfg N M) := by
  have h := integrable_exp N M β (zt N M a b) (fun _ => 1)
  have e : (fun ω => Real.exp (∑ B, (fun _ => (1 : ℝ)) B * Jc N M β (zt N M a b) B ω))
      = fun ω => Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re) := by
    funext ω; rw [← sum_Jc]; simp
  rw [e] at h
  exact h.aestronglyMeasurable

/-- **β ↦ Z(β; a, b) は連続** -/
theorem ZW_continuous (a b : Bool) : Continuous fun β => ZW N M β a b := by
  rw [continuous_iff_continuousAt]
  intro β₀
  set C : ℝ := (Fintype.card (Plaq N M) : ℝ)
  unfold ZW
  refine continuousAt_of_dominated (bound := fun _ => Real.exp ((|β₀| + 1) * C)) ?_ ?_ ?_ ?_
  · exact Eventually.of_forall fun β => aesm_exp N M β a b
  · have hn : ∀ᶠ β in 𝓝 β₀, |β| ≤ |β₀| + 1 := by
      have : ∀ᶠ β in 𝓝 β₀, dist β β₀ < 1 := Metric.ball_mem_nhds β₀ one_pos
      filter_upwards [this] with β hβ
      have := abs_sub_abs_le_abs_sub β β₀
      rw [Real.dist_eq] at hβ
      linarith
    filter_upwards [hn] with β hβ
    refine Eventually.of_forall fun ω => ?_
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply Real.exp_le_exp.mpr
    have hS := abs_action_le N M a b ω
    have hC : 0 ≤ C := Nat.cast_nonneg _
    calc β * ∑ B, zt N M a b B * (hol N M ω B).re
        ≤ |β * ∑ B, zt N M a b B * (hol N M ω B).re| := le_abs_self _
      _ = |β| * |∑ B, zt N M a b B * (hol N M ω B).re| := abs_mul _ _
      _ ≤ (|β₀| + 1) * C := mul_le_mul hβ hS (abs_nonneg _) (by positivity)
  · exact integrable_const _
  · refine Eventually.of_forall fun ω => ?_
    exact (Real.continuous_exp.comp (continuous_id.mul continuous_const)).continuousAt

/-- **β ↦ θ(β) は連続** -/
theorem thetaM_continuous : Continuous fun β => TwistBlocks.thetaM N M β := by
  unfold TwistBlocks.thetaM
  refine ((ZW_continuous N M true false).sub (ZW_continuous N M true true)).div
    ((ZW_continuous N M true false).add (ZW_continuous N M true true)) ?_
  intro β
  exact (add_pos (ZW_pos N M β true false) (ZW_pos N M β true true)).ne'

theorem ZW_zero (a b : Bool) : ZW N M 0 a b = 1 := by
  unfold ZW; simp

/-- **θ(0) = 0** -/
theorem thetaM_zero : TwistBlocks.thetaM N M 0 = 0 := by
  unfold TwistBlocks.thetaM; rw [ZW_zero, ZW_zero]; simp

/-- **合わせの存在（弱い形）**：0 ≤ β₁、κ ∈ [0, θ(β₁)] なら [0, β₁] に θ(β) = κ の解が在る -/
theorem tuning_exists {β₁ κ : ℝ} (hβ : 0 ≤ β₁) (hκ0 : 0 ≤ κ)
    (hκ1 : κ ≤ TwistBlocks.thetaM N M β₁) :
    ∃ β ∈ Set.Icc 0 β₁, TwistBlocks.thetaM N M β = κ := by
  have hc : ContinuousOn (fun β => TwistBlocks.thetaM N M β) (Set.Icc 0 β₁) :=
    (thetaM_continuous N M).continuousOn
  have h := intermediate_value_Icc hβ hc
  have hm : κ ∈ Set.Icc (TwistBlocks.thetaM N M 0) (TwistBlocks.thetaM N M β₁) := by
    rw [thetaM_zero]; exact ⟨hκ0, hκ1⟩
  obtain ⟨β, hβI, hβe⟩ := h hm
  exact ⟨β, hβI, hβe⟩

/-- **最大の解**：同じ仮定で、解の集合 {β ∈ [0, β₁] | θ(β) = κ} は最大の元を持つ -/
theorem tuning_max_exists {β₁ κ : ℝ} (hβ : 0 ≤ β₁) (hκ0 : 0 ≤ κ)
    (hκ1 : κ ≤ TwistBlocks.thetaM N M β₁) :
    ∃ βs ∈ Set.Icc 0 β₁, TwistBlocks.thetaM N M βs = κ ∧
      ∀ β ∈ Set.Icc 0 β₁, TwistBlocks.thetaM N M β = κ → β ≤ βs := by
  set S := {β | β ∈ Set.Icc 0 β₁ ∧ TwistBlocks.thetaM N M β = κ}
  have hS : IsCompact S := by
    have hcl : IsClosed S := by
      have : S = Set.Icc 0 β₁ ∩ (fun β => TwistBlocks.thetaM N M β) ⁻¹' {κ} := rfl
      rw [this]
      exact isClosed_Icc.inter (isClosed_singleton.preimage (thetaM_continuous N M))
    exact isCompact_Icc.of_isClosed_subset hcl (fun x hx => hx.1)
  obtain ⟨β, hβI, hβe⟩ := tuning_exists N M hβ hκ0 hκ1
  have hne : S.Nonempty := ⟨β, hβI, hβe⟩
  obtain ⟨βs, hβs, hmax⟩ := hS.exists_isGreatest hne
  exact ⟨βs, hβs.1, hβs.2, fun x hx hxe => hmax ⟨hx, hxe⟩⟩

end ThetaTuning

#print axioms ThetaTuning.tuning_max_exists
