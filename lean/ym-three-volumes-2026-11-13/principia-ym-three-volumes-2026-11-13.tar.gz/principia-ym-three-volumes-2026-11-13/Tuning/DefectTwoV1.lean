import Tuning.DefectFloorV1
import Tuning.QuadTwoV1
import Tuning.ThetaRateV2

/-!
# 最小の欠けの一様な下界（最良の四元数の下界 2 の版）：対称な箱で 1/2

`TwistFloor.defect11_ge` と同じ道で、四元数の下界を
`QuadFloor.quad_floor_two`（2）に替えたもの。全ての N, M ≥ 1、全ての ω で
`2N²M²/(N² + M²)² ≤ D(ω)`、対称な箱で `1/2 ≤ D(ω)`、`1/2 ≤ Smin N N`。
-/

open Finset TwistedWilson FlatStokes Filter Topology

namespace TwistFloor

section
variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 各基点で、四つの切り口の誤差の和は 2 以上 -/
theorem local_floor_two (ω : Link N M → SU2) (x : Site N M) :
    2 ≤ sh N M ω p01 0 1 N N x + sh N M ω p23 2 3 M M x
      + sh N M ω TwistFlat.pl02 0 2 N M x + sh N M ω TwistFlat.pl12 1 2 N M x := by
  have hq := QuadFloor.quad_floor_two (W N M ω 0 N x) (W N M ω 1 N x) (W N M ω 2 M x)
    (W N M ω 3 M x) (norm_W N M ω 0 N x) (norm_W N M ω 1 N x) (norm_W N M ω 2 M x)
    (norm_W N M ω 3 M x)
  linarith [comm01 N M ω x, comm23 N M ω x, comm02 N M ω x, comm12 N M ω x]

/-- **最小の欠けの下界**：全ての N, M ≥ 1、全ての ω で
`2N²M²/(N² + M²)² ≤ D(ω)` -/
theorem defect11_ge_two (ω : Link N M → SU2) :
    2 * ((N : ℝ) ^ 2 * (M : ℝ) ^ 2) / ((N : ℝ) ^ 2 + (M : ℝ) ^ 2) ^ 2
      ≤ TwistFlat.defect11 N M ω := by
  set S1 := ∑ x, eps N M ω x p01
  set S2 := ∑ x, eps N M ω x p23
  set S3 := ∑ x, eps N M ω x TwistFlat.pl02
  set S4 := ∑ x, eps N M ω x TwistFlat.pl12
  set D1 := ∑ x, dterm N M ω x p01
  set D2 := ∑ x, dterm N M ω x p23
  set D3 := ∑ x, dterm N M ω x TwistFlat.pl02
  set D4 := ∑ x, dterm N M ω x TwistFlat.pl12
  have hN : (0 : ℝ) < N := by exact_mod_cast NeZero.pos N
  have hM : (0 : ℝ) < M := by exact_mod_cast NeZero.pos M
  set a := (N : ℝ) ^ 2
  set b := (M : ℝ) ^ 2
  set K := a * b with hK
  have ha : 0 < a := by positivity
  have hb : 0 < b := by positivity
  have hK0 : 0 < K := mul_pos ha hb
  set r : ℝ := 2 with hr
  have r0 : 0 ≤ r := by norm_num
  have hsum : r * K ≤ a * S1 + b * S2 + ((N : ℝ) * M) * S3 + ((N : ℝ) * M) * S4 := by
    have h1 := Finset.sum_le_sum (s := (univ : Finset (Site N M))) fun x _ =>
      local_floor_two N M ω x
    rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_site] at h1
    simp only [Finset.sum_add_distrib, sum_sh] at h1
    have e1 : (N : ℝ) * N = a := by ring
    have e2 : (M : ℝ) * M = b := by ring
    have e3 : (M : ℝ) * N = N * M := by ring
    rw [e1, e2, e3] at h1
    linarith
  have hc1 := cs_plane N M ω p01
  have hc2 := cs_plane N M ω p23
  have hc3 := cs_plane N M ω TwistFlat.pl02
  have hc4 := cs_plane N M ω TwistFlat.pl12
  have hfour := four_planes_le N M ω
  have hcs := cs4 a b ((N : ℝ) * M) ((N : ℝ) * M) S1 S2 S3 S4
  have hab : a ^ 2 + b ^ 2 + ((N : ℝ) * M) ^ 2 + ((N : ℝ) * M) ^ 2 = (a + b) ^ 2 := by
    simp only [a, b]; ring
  rw [hab] at hcs
  have hX0 : 0 ≤ r * K := by positivity
  have hsq := pow_le_pow_left₀ hX0 hsum 2
  have hSS : S1 ^ 2 + S2 ^ 2 + S3 ^ 2 + S4 ^ 2 ≤ K * (2 * (D1 + D2 + D3 + D4)) := by
    rw [← hK] at hc1 hc2 hc3 hc4
    nlinarith
  have hab0 : 0 ≤ (a + b) ^ 2 := sq_nonneg _
  have hmain : (r * K) ^ 2 ≤ (a + b) ^ 2 * (K * (2 * (D1 + D2 + D3 + D4))) :=
    le_trans hsq (le_trans hcs (mul_le_mul_of_nonneg_left hSS hab0))
  have hrK : (r * K) ^ 2 = 2 * K * (2 * K) := by rw [hr]; ring
  rw [hrK] at hmain
  have hmain2 : 2 * K ≤ (a + b) ^ 2 * (D1 + D2 + D3 + D4) := by
    have : (2 * K) * (2 * K) ≤ (2 * K) * ((a + b) ^ 2 * (D1 + D2 + D3 + D4)) := by nlinarith
    exact le_of_mul_le_mul_left this (by positivity)
  have hpos : 0 < (a + b) ^ 2 := by positivity
  rw [div_le_iff₀ hpos]
  nlinarith

end

/-- **対称な箱の一様な下界**：全ての N ≥ 1、全ての ω で `1/2 ≤ D(ω)` -/
theorem defect11_sym_half (N : ℕ) [NeZero N] (ω : Link N N → SU2) :
    1 / 2 ≤ TwistFlat.defect11 N N ω := by
  have h := defect11_ge_two N N ω
  have hN : (0 : ℝ) < N := by exact_mod_cast NeZero.pos N
  have he : 2 * ((N : ℝ) ^ 2 * (N : ℝ) ^ 2) / ((N : ℝ) ^ 2 + (N : ℝ) ^ 2) ^ 2 = 1 / 2 := by
    field_simp; ring
  rw [he] at h
  exact h

theorem defect11_uniform_half :
    ∃ c : ℝ, 0 < c ∧ ∀ (N : ℕ) [NeZero N] (ω : Link N N → SU2), c ≤ TwistFlat.defect11 N N ω :=
  ⟨1 / 2, by norm_num, fun N _ ω => defect11_sym_half N ω⟩

theorem Smin_sym_half (N : ℕ) [NeZero N] : 1 / 2 ≤ ThetaLimit.Smin N N :=
  le_ciInf (defect11_sym_half N)

/-- 全ての N ≥ 1 で、ln(Z(1,0)/Z(1,1))/β は β → ∞ で 1/2 以上の値 S_N に収束する -/
theorem logratio_limit_half :
    ∀ (N : ℕ) [NeZero N], ∃ S : ℝ, 1 / 2 ≤ S ∧
      Tendsto (fun β => Real.log (ZW N N β true false / ZW N N β true true) / β) atTop (𝓝 S) :=
  fun N _ => ⟨ThetaLimit.Smin N N, Smin_sym_half N, ThetaLimit.tendsto_logratio_div N N⟩

end TwistFloor

#print axioms TwistFloor.defect11_ge_two
#print axioms TwistFloor.defect11_uniform_half
#print axioms TwistFloor.logratio_limit_half
