import Tuning.NoFlatTwistV2
import Tuning.ThetaContV1
import Blocks.VacuumV1

/-!
# θ_{N,M}(β) → 1（β → ∞、格子を止めて）と、全ての κ ∈ [0, 1) での合わせの最大の解

紙：(iii) と (ii) の全体の形。θ = `TwistBlocks.thetaM N M β`
`= (Z(1,0) − Z(1,1))/(Z(1,0) + Z(1,1))`、`Z(a,b) = TwistedWilson.ZW N M β a b`。全ての N, M ≥ 1。
* `Z11_le`：β ≥ 0 で `Z(1,1) ≤ exp(β(|P| − S))`、`S = inf_ω D(ω) > 0`（`TwistFlat.minDefect11_pos`）。
* `Z10_ge`：β ≥ 0 で `Z(1,0) ≥ v · exp(β(|P| − S/2))`、`v` は真空 V（`TwistBlocks.vac`、
  `vac_term`：(1,0) の区画の欠け 0 の配位）の開近傍 `{ω | Σ z Re U > |P| − S/2}` の Haar の体積で、
  `v > 0`（Haar の積の測度は空でない開集合で正）。
* `theta_lower`：β ≥ 0 で `1 − (2/v) e^{−βS/2} ≤ θ(β)`。
* `tendsto_theta_one`：θ(β) → 1（β → ∞）。
* `tuning_all`：全ての κ ∈ [0, 1) で、θ(β) = κ となる β ≥ 0 が在り、その解の集合（β ≥ 0）に最大の元が在る。
-/

open MeasureTheory Filter Topology Finset TwistedWilson

namespace ThetaLimit

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 面の数 |P| -/
noncomputable abbrev nP : ℝ := (Fintype.card (Plaq N M) : ℝ)

/-- 最小の欠け S = inf_ω D(ω)（背景 (1,1)） -/
noncomputable abbrev Smin : ℝ := ⨅ ω, TwistFlat.defect11 N M ω

theorem Smin_pos : 0 < Smin N M := TwistFlat.minDefect11_pos N M

theorem integrable_ZW (β : ℝ) (a b : Bool) :
    Integrable (fun ω => Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re)) (haarCfg N M) := by
  have h := integrable_exp N M β (zt N M a b) (fun _ => 1)
  have e : (fun ω => Real.exp (∑ B, (fun _ => (1 : ℝ)) B * Jc N M β (zt N M a b) B ω))
      = fun ω => Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re) := by
    funext ω; rw [← sum_Jc]; simp
  rwa [e] at h

/-- **`Z(1,1) ≤ exp(β(|P| − S))`**（β ≥ 0） -/
theorem Z11_le (β : ℝ) (hβ : 0 ≤ β) :
    ZW N M β true true ≤ Real.exp (β * (nP N M - Smin N M)) := by
  have hbdd : BddBelow (Set.range (TwistFlat.defect11 N M)) := by
    obtain ⟨ωs, -, hmin⟩ := TwistFlat.defect11_floor N M
    exact ⟨_, by rintro _ ⟨ω, rfl⟩; exact hmin ω⟩
  have hpt : ∀ ω, Real.exp (β * ∑ B, zt N M true true B * (hol N M ω B).re)
      ≤ Real.exp (β * (nP N M - Smin N M)) := by
    intro ω
    apply Real.exp_le_exp.mpr
    apply mul_le_mul_of_nonneg_left _ hβ
    have h1 := ciInf_le hbdd ω
    have h2 := TwistFlat.defect11_eq N M ω
    simp only [nP, Smin]
    linarith
  unfold ZW
  calc _ ≤ ∫ _ω, Real.exp (β * (nP N M - Smin N M)) ∂(haarCfg N M) :=
        integral_mono (integrable_ZW N M β true true) (integrable_const _) hpt
    _ = _ := by simp

/-- 真空 V の作用は |P|（背景 (1,0)） -/
theorem action_vac : ∑ B, zt N M true false B * (hol N M (TwistBlocks.vac N M) B).re = nP N M := by
  rw [Finset.sum_congr rfl fun B _ => TwistBlocks.vac_term N M B, Finset.sum_const,
    Finset.card_univ, nsmul_eq_mul, mul_one]

/-- 真空 V の近傍 -/
def nbhdV : Set (Link N M → SU2) :=
  {ω | nP N M - Smin N M / 2 < ∑ B, zt N M true false B * (hol N M ω B).re}

theorem isOpen_nbhdV : IsOpen (nbhdV N M) :=
  isOpen_lt continuous_const (TwistFlat.continuous_action N M true false)

theorem vac_mem_nbhdV : TwistBlocks.vac N M ∈ nbhdV N M := by
  show nP N M - Smin N M / 2 < _
  rw [action_vac]; linarith [Smin_pos N M]

theorem haarSU2_openPos : Measure.IsOpenPosMeasure haarSU2 := by
  unfold haarSU2 haarProb; infer_instance

theorem haarCfg_openPos : Measure.IsOpenPosMeasure (haarCfg N M) := by
  unfold haarCfg
  haveI : ∀ _ : Link N M, Measure.IsOpenPosMeasure haarSU2 := fun _ => haarSU2_openPos
  haveI : ∀ _ : Link N M, SigmaFinite haarSU2 := fun _ => inferInstance
  exact Measure.pi.isOpenPosMeasure _

/-- 近傍の体積 v -/
noncomputable def volV : ℝ := (haarCfg N M).real (nbhdV N M)

/-- **近傍の体積は正** -/
theorem volV_pos : 0 < volV N M := by
  unfold volV
  rw [measureReal_def]
  haveI := haarCfg_openPos N M
  exact ENNReal.toReal_pos ((isOpen_nbhdV N M).measure_pos (haarCfg N M)
    ⟨_, vac_mem_nbhdV N M⟩).ne' (measure_ne_top _ _)

/-- **`Z(1,0) ≥ v · exp(β(|P| − S/2))`**（β ≥ 0） -/
theorem Z10_ge (β : ℝ) (hβ : 0 ≤ β) :
    Real.exp (β * (nP N M - Smin N M / 2)) * volV N M ≤ ZW N M β true false := by
  unfold ZW volV
  have hint := integrable_ZW N M β true false
  calc Real.exp (β * (nP N M - Smin N M / 2)) * (haarCfg N M).real (nbhdV N M)
      ≤ ∫ ω in nbhdV N M, Real.exp (β * ∑ B, zt N M true false B * (hol N M ω B).re)
          ∂(haarCfg N M) :=
        setIntegral_ge_of_const_le_real (isOpen_nbhdV N M).measurableSet (measure_ne_top _ _)
          (fun ω hω => Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left (le_of_lt hω) hβ))
          hint.integrableOn
    _ ≤ _ := setIntegral_le_integral hint (Eventually.of_forall fun ω => (Real.exp_pos _).le)

/-- **θ の下界**：β ≥ 0 で `1 − (2/v) e^{−(S/2)β} ≤ θ(β)` -/
theorem theta_lower (β : ℝ) (hβ : 0 ≤ β) :
    1 - 2 / volV N M * Real.exp (-(Smin N M / 2 * β)) ≤ TwistBlocks.thetaM N M β := by
  have hv := volV_pos N M
  set Z0 := ZW N M β true false
  set Z1 := ZW N M β true true
  have h0 : 0 < Z0 := ZW_pos N M β true false
  have h1 : 0 < Z1 := ZW_pos N M β true true
  set A := Real.exp (β * (nP N M - Smin N M))
  set Bv := Real.exp (β * (nP N M - Smin N M / 2)) * volV N M
  have hA : Z1 ≤ A := Z11_le N M β hβ
  have hB : Bv ≤ Z0 := Z10_ge N M β hβ
  have hBpos : 0 < Bv := mul_pos (Real.exp_pos _) hv
  have hne : Z0 + Z1 ≠ 0 := ne_of_gt (by linarith)
  have hth : TwistBlocks.thetaM N M β = 1 - 2 * Z1 / (Z0 + Z1) := by
    show (Z0 - Z1) / (Z0 + Z1) = 1 - 2 * Z1 / (Z0 + Z1)
    rw [eq_sub_iff_add_eq, ← add_div, div_eq_one_iff_eq hne]; ring
  have hstep1 : 2 * Z1 / (Z0 + Z1) ≤ 2 * Z1 / Z0 :=
    div_le_div_of_nonneg_left (by linarith) h0 (by linarith)
  have hstep2 : 2 * Z1 / Z0 ≤ 2 * A / Bv := div_le_div₀ (by positivity) (by linarith) hBpos hB
  have hid : 2 * A / Bv = 2 / volV N M * Real.exp (-(Smin N M / 2 * β)) := by
    have e : β * (nP N M - Smin N M) = β * (nP N M - Smin N M / 2) + -(Smin N M / 2 * β) := by ring
    simp only [A, Bv]
    rw [e, Real.exp_add]
    field_simp
  rw [hth]
  linarith

theorem theta_le_one (β : ℝ) : TwistBlocks.thetaM N M β ≤ 1 := by
  unfold TwistBlocks.thetaM
  have h0 := ZW_pos N M β true false
  have h1 := ZW_pos N M β true true
  rw [div_le_one (by linarith)]
  linarith

/-- **θ_{N,M}(β) → 1（β → ∞）** -/
theorem tendsto_theta_one : Tendsto (TwistBlocks.thetaM N M) atTop (𝓝 1) := by
  have hg : 0 < Smin N M / 2 := by linarith [Smin_pos N M]
  have hexp : Tendsto (fun β : ℝ => Real.exp (-(Smin N M / 2 * β))) atTop (𝓝 0) :=
    Real.tendsto_exp_neg_atTop_nhds_zero.comp (Tendsto.const_mul_atTop hg tendsto_id)
  have hlow : Tendsto (fun β : ℝ => 1 - 2 / volV N M * Real.exp (-(Smin N M / 2 * β))) atTop
      (𝓝 1) := by
    have := (tendsto_const_nhds (x := (1 : ℝ))).sub
      ((tendsto_const_nhds (x := 2 / volV N M)).mul hexp)
    simpa using this
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow tendsto_const_nhds ?_ ?_
  · filter_upwards [eventually_ge_atTop 0] with β hβ
    exact theta_lower N M β hβ
  · exact Eventually.of_forall fun β => theta_le_one N M β

/-- 仮定 `κ ≤ θ(β₁)` は全ての κ < 1 で満たせる -/
theorem exists_theta_gt (κ : ℝ) (h1 : κ < 1) :
    ∃ b0 : ℝ, 0 ≤ b0 ∧ ∀ β, b0 ≤ β → κ < TwistBlocks.thetaM N M β := by
  obtain ⟨b, hb⟩ := eventually_atTop.1 ((tendsto_theta_one N M).eventually (lt_mem_nhds h1))
  exact ⟨max b 0, le_max_right _ _, fun β hβ => hb β (le_trans (le_max_left _ _) hβ)⟩

/-- **合わせの存在の全体の形**：全ての κ ∈ [0, 1) で、θ(β) = κ となる β ≥ 0 が在り、
その解の集合 {β ≥ 0 | θ(β) = κ} に最大の元 β*(κ; N, M) が在る（全ての N, M ≥ 1） -/
theorem tuning_all (κ : ℝ) (h0 : 0 ≤ κ) (h1 : κ < 1) :
    ∃ βs : ℝ, 0 ≤ βs ∧ TwistBlocks.thetaM N M βs = κ ∧
      ∀ β, 0 ≤ β → TwistBlocks.thetaM N M β = κ → β ≤ βs := by
  obtain ⟨b0, hb0, hgt⟩ := exists_theta_gt N M κ h1
  obtain ⟨βs, hβs, hθ, hmax⟩ :=
    ThetaTuning.tuning_max_exists N M hb0 h0 (le_of_lt (hgt b0 le_rfl))
  refine ⟨βs, hβs.1, hθ, fun β hβ hβe => ?_⟩
  by_cases hle : β ≤ b0
  · exact hmax β ⟨hβ, hle⟩ hβe
  · exfalso
    have := hgt β (le_of_lt (lt_of_not_ge hle))
    rw [hβe] at this
    exact lt_irrefl _ this

/-- κ > 0 なら最大の解は正（θ(0) = 0） -/
theorem tuning_all_pos (κ : ℝ) (h0 : 0 < κ) (h1 : κ < 1) :
    ∃ βs : ℝ, 0 < βs ∧ TwistBlocks.thetaM N M βs = κ ∧
      ∀ β, 0 ≤ β → TwistBlocks.thetaM N M β = κ → β ≤ βs := by
  obtain ⟨βs, hβs, hθ, hmax⟩ := tuning_all N M κ h0.le h1
  refine ⟨βs, lt_of_le_of_ne hβs ?_, hθ, hmax⟩
  rintro rfl
  rw [ThetaTuning.thetaM_zero] at hθ
  linarith

/-- 確かめ：仮定の欄（0 ≤ κ < 1）は満たせる（κ = 1/2、N = M = 2） -/
theorem sanity_half : ∃ βs : ℝ, 0 < βs ∧ TwistBlocks.thetaM 2 2 βs = 1 / 2 := by
  obtain ⟨βs, h, hθ, -⟩ := tuning_all_pos 2 2 (1 / 2) (by norm_num) (by norm_num)
  exact ⟨βs, h, hθ⟩

end ThetaLimit

#print axioms ThetaLimit.tendsto_theta_one
#print axioms ThetaLimit.tuning_all
#print axioms ThetaLimit.tuning_all_pos
#print axioms ThetaLimit.sanity_half
