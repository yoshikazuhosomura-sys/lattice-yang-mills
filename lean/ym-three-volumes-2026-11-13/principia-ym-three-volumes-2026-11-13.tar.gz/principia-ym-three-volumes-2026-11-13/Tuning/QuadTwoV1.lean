import Tuning.QuadFloorV1

/-!
# 崩れの量の最良の下界 2

紙：「c₀ = 2 の紙の証明」。単位四元数 a, b, c, d で
`2 ≤ ‖ab + ba‖ + ‖cd + dc‖ + ‖ac − ca‖ + ‖bc − cb‖`（a, b が反可換で c = ±1 のとき等号）。

虚部のベクトルを A, B, C、α = |A|²、β = |B|²、p = A·B、x = A·C、y = B·C、c = |C|²、
D = αβ − p² = |A × B|² と置く。
* 成分の恒等式：`‖ac − ca‖² + ‖bc − cb‖² = 4((α+β)c − x² − y²)`、
  `Dc − (βx² − 2pxy + αy²) = (C·(A×B))²`、`‖ab − ba‖² = 4D`。
* 二次形式の比べ（`gram_scalar`）：σ ≥ 0、σ² = 1 − D なら `x² + y² ≤ (α + β − 1 + σ)c`
  （固有値を使わず、2×2 の行列の正値と場合分け D = 0 / D > 0 で）。
* σ = ‖ab + ba‖/2、τ = ‖cd + dc‖/2、q = ‖cd − dc‖/2 ≤ √c で σ + τ + (u+v)/2 ≥ 1。
-/

namespace QuadFloor

local notation "ℍr" => Quaternion ℝ

/-- 二次形式の比べ（スカラーの補題） -/
theorem gram_scalar (α β p x y c σ : ℝ) (hα0 : 0 ≤ α) (hα1 : α ≤ 1) (hβ0 : 0 ≤ β)
    (hβ1 : β ≤ 1) (hD : 0 ≤ α * β - p ^ 2) (hσ0 : 0 ≤ σ) (hσ2 : σ ^ 2 = 1 - (α * β - p ^ 2))
    (hc : 0 ≤ c) (hx : x ^ 2 ≤ α * c) (hy : y ^ 2 ≤ β * c)
    (hQ : β * x ^ 2 - 2 * p * x * y + α * y ^ 2 ≤ (α * β - p ^ 2) * c) :
    x ^ 2 + y ^ 2 ≤ (α + β - 1 + σ) * c := by
  set D := α * β - p ^ 2 with hDdef
  set L := α + β - 1 + σ with hL
  have hσ1 : σ ≤ 1 := by nlinarith
  have hσa : 1 - α ≤ σ := by nlinarith [mul_nonneg hβ0 (sub_nonneg.2 hα1)]
  have hσb : 1 - β ≤ σ := by nlinarith [mul_nonneg hα0 (sub_nonneg.2 hβ1)]
  have hLa : α ≤ L := by linarith
  have hLb : β ≤ L := by linarith
  have hL0 : 0 ≤ L := by linarith
  have he : 0 ≤ L * β - D := by nlinarith [sq_nonneg p, mul_le_mul_of_nonneg_right hLa hβ0]
  have hh : 0 ≤ L * α - D := by nlinarith [sq_nonneg p, mul_le_mul_of_nonneg_right hLb hα0]
  have hdet : (L * β - D) * (L * α - D) - L ^ 2 * p ^ 2 = D * ((1 - σ) * (2 - α - β)) := by
    have : L ^ 2 - L * (α + β) + D = (1 - σ) * (2 - α - β) := by
      rw [hL]; nlinarith [hσ2]
    have e2 : (L * β - D) * (L * α - D) - L ^ 2 * p ^ 2 = D * (L ^ 2 - L * (α + β) + D) := by
      rw [hDdef]; ring
    rw [e2, this]
  have hdet0 : 0 ≤ (L * β - D) * (L * α - D) - L ^ 2 * p ^ 2 := by
    rw [hdet]
    exact mul_nonneg hD (mul_nonneg (by linarith) (by linarith))
  -- 二次形式 F = (Lβ − D)x² − 2Lpxy + (Lα − D)y² ≥ 0
  have hF : 0 ≤ (L * β - D) * x ^ 2 - 2 * (L * p) * x * y + (L * α - D) * y ^ 2 := by
    rcases he.lt_or_eq with he' | he'
    · have key : (L * β - D) * ((L * β - D) * x ^ 2 - 2 * (L * p) * x * y + (L * α - D) * y ^ 2)
          = ((L * β - D) * x - L * p * y) ^ 2
            + ((L * β - D) * (L * α - D) - L ^ 2 * p ^ 2) * y ^ 2 := by ring
      have : 0 ≤ (L * β - D) * ((L * β - D) * x ^ 2 - 2 * (L * p) * x * y
          + (L * α - D) * y ^ 2) := by
        rw [key]; exact add_nonneg (sq_nonneg _) (mul_nonneg hdet0 (sq_nonneg _))
      by_contra hneg
      push Not at hneg
      have := mul_neg_of_pos_of_neg he' hneg
      linarith
    · rw [← he'] at hdet0
      have hLp : L * p = 0 := by nlinarith [sq_nonneg (L * p)]
      rw [← he', hLp]
      nlinarith [mul_nonneg hh (sq_nonneg y)]
  -- F = L·Q − D(x² + y²)
  have hFQ : (L * β - D) * x ^ 2 - 2 * (L * p) * x * y + (L * α - D) * y ^ 2
      = L * (β * x ^ 2 - 2 * p * x * y + α * y ^ 2) - D * (x ^ 2 + y ^ 2) := by ring
  rw [hFQ] at hF
  have h1 : D * (x ^ 2 + y ^ 2) ≤ D * (L * c) := by
    have := mul_le_mul_of_nonneg_left hQ hL0
    nlinarith
  rcases hD.lt_or_eq with hD' | hD'
  · have := le_of_mul_le_mul_left h1 hD'
    linarith
  · have hs : σ = 1 := by
      have h2 : σ ^ 2 = 1 := by rw [hσ2, ← hD']; ring
      have h3 : (σ - 1) * (σ + 1) = 0 := by linear_combination h2
      rcases mul_eq_zero.1 h3 with h4 | h4
      · linarith
      · linarith
    rw [hL, hs, show α + β - 1 + 1 = α + β by ring, add_mul]
    linarith

/-- 最後の比べ（スカラー） -/
theorem final_scalar (σ τ q ω cc : ℝ) (hσ0 : 0 ≤ σ) (hσ1 : σ ≤ 1) (hτ : 0 ≤ τ)
    (hτq : τ ^ 2 + q ^ 2 = 1) (hq : q ^ 2 ≤ cc) (hω : 0 ≤ ω) (hω2 : (1 - σ) * cc ≤ ω ^ 2) :
    1 ≤ σ + τ + ω := by
  by_cases h : 1 ≤ σ + τ
  · linarith
  push Not at h
  set a := 1 - σ with ha
  have ha0 : 0 ≤ a := by linarith
  have hτa : τ < a := by linarith
  have h1 : a * q ^ 2 ≤ a * cc := mul_le_mul_of_nonneg_left hq ha0
  have h2 : (a - τ) ^ 2 ≤ a * q ^ 2 := by
    have hq2 : q ^ 2 = 1 - τ ^ 2 := by linarith
    rw [hq2]
    have h3 : 0 ≤ a * τ * (1 - a) := mul_nonneg (mul_nonneg ha0 hτ) (by linarith)
    have h4 : τ ^ 2 * (1 + a) ≤ a * τ * (1 + a) := by
      have : τ * τ ≤ a * τ := mul_le_mul_of_nonneg_right hτa.le hτ
      nlinarith
    nlinarith
  have h5 : (a - τ) ^ 2 ≤ ω ^ 2 := by linarith
  have h6 : a - τ ≤ ω := by
    by_contra h7
    push Not at h7
    have := pow_lt_pow_left₀ h7 hω (by norm_num : (2 : ℕ) ≠ 0)
    linarith
  linarith

theorem nsq_le_one (q : ℍr) (hq : ‖q‖ = 1) :
    q.imI ^ 2 + q.imJ ^ 2 + q.imK ^ 2 ≤ 1 := by
  have h := nsq q
  rw [hq] at h
  nlinarith [sq_nonneg q.re]

/-- **崩れの量の下界 2**：単位四元数 a, b, c, d で
`2 ≤ ‖ab + ba‖ + ‖cd + dc‖ + ‖ac − ca‖ + ‖bc − cb‖` -/
theorem quad_floor_two (a b c d : ℍr) (ha : ‖a‖ = 1) (hb : ‖b‖ = 1) (hc : ‖c‖ = 1)
    (hd : ‖d‖ = 1) :
    2 ≤ ‖a * b + b * a‖ + ‖c * d + d * c‖ + ‖a * c - c * a‖ + ‖b * c - c * b‖ := by
  set α := a.imI ^ 2 + a.imJ ^ 2 + a.imK ^ 2 with hαd
  set β := b.imI ^ 2 + b.imJ ^ 2 + b.imK ^ 2 with hβd
  set p := a.imI * b.imI + a.imJ * b.imJ + a.imK * b.imK with hpd
  set x := a.imI * c.imI + a.imJ * c.imJ + a.imK * c.imK with hxd
  set y := b.imI * c.imI + b.imJ * c.imJ + b.imK * c.imK with hyd
  set cc := c.imI ^ 2 + c.imJ ^ 2 + c.imK ^ 2 with hccd
  have hα1 : α ≤ 1 := nsq_le_one a ha
  have hβ1 : β ≤ 1 := nsq_le_one b hb
  have hc1 : cc ≤ 1 := nsq_le_one c hc
  have hδ1 := nsq_le_one d hd
  have hα0 : 0 ≤ α := by positivity
  have hβ0 : 0 ≤ β := by positivity
  have hcc0 : 0 ≤ cc := by positivity
  have Eac : ‖a * c - c * a‖ ^ 2 = 4 * (α * cc - x ^ 2) := by
    rw [nsq]
    simp only [Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
      Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul]
    rw [hαd, hccd, hxd]; ring
  have Ebc : ‖b * c - c * b‖ ^ 2 = 4 * (β * cc - y ^ 2) := by
    rw [nsq]
    simp only [Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
      Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul]
    rw [hβd, hccd, hyd]; ring
  have Eab : ‖a * b - b * a‖ ^ 2 = 4 * (α * β - p ^ 2) := by
    rw [nsq]
    simp only [Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
      Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul]
    rw [hαd, hβd, hpd]; ring
  have Ecd : ‖c * d - d * c‖ ^ 2 = 4 * (cc * (d.imI ^ 2 + d.imJ ^ 2 + d.imK ^ 2)
      - (c.imI * d.imI + c.imJ * d.imJ + c.imK * d.imK) ^ 2) := by
    rw [nsq]
    simp only [Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
      Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul]
    rw [hccd]; ring
  have hx : x ^ 2 ≤ α * cc := by
    have := sq_nonneg ‖a * c - c * a‖; rw [Eac] at this; linarith
  have hy : y ^ 2 ≤ β * cc := by
    have := sq_nonneg ‖b * c - c * b‖; rw [Ebc] at this; linarith
  have hD : 0 ≤ α * β - p ^ 2 := by
    have := sq_nonneg ‖a * b - b * a‖; rw [Eab] at this; linarith
  have hQ : β * x ^ 2 - 2 * p * x * y + α * y ^ 2 ≤ (α * β - p ^ 2) * cc := by
    have e : (α * β - p ^ 2) * cc - (β * x ^ 2 - 2 * p * x * y + α * y ^ 2)
        = (c.imI * (a.imJ * b.imK - a.imK * b.imJ) + c.imJ * (a.imK * b.imI - a.imI * b.imK)
          + c.imK * (a.imI * b.imJ - a.imJ * b.imI)) ^ 2 := by
      rw [hαd, hβd, hpd, hxd, hyd, hccd]; ring
    have := sq_nonneg (c.imI * (a.imJ * b.imK - a.imK * b.imJ)
      + c.imJ * (a.imK * b.imI - a.imI * b.imK) + c.imK * (a.imI * b.imJ - a.imJ * b.imI))
    linarith
  have hab := anti_add_comm a b ha hb
  have hcd := anti_add_comm c d hc hd
  set σ := ‖a * b + b * a‖ / 2 with hσd
  have hσ0 : 0 ≤ σ := by positivity
  have hσ2 : σ ^ 2 = 1 - (α * β - p ^ 2) := by
    have e : σ ^ 2 = ‖a * b + b * a‖ ^ 2 / 4 := by rw [hσd]; ring
    rw [e]; linarith [hab, Eab]
  have hg := gram_scalar α β p x y cc σ hα0 hα1 hβ0 hβ1 hD hσ0 hσ2 hcc0 hx hy hQ
  have hσ1 : σ ≤ 1 := by
    have : σ ^ 2 ≤ 1 := by linarith
    exact (pow_le_one_iff_of_nonneg hσ0 (by norm_num : (2 : ℕ) ≠ 0)).1 this
  set u := ‖a * c - c * a‖
  set v := ‖b * c - c * b‖
  have hu0 : 0 ≤ u := norm_nonneg _
  have hv0 : 0 ≤ v := norm_nonneg _
  have huv : 4 * ((1 - σ) * cc) ≤ u ^ 2 + v ^ 2 := by
    rw [Eac, Ebc]
    have e1 : (α + β - 1 + σ) * cc = α * cc + β * cc - cc + σ * cc := by ring
    have e2 : 4 * ((1 - σ) * cc) = 4 * cc - 4 * (σ * cc) := by ring
    rw [e2]; linarith [hg, e1]
  set ω := (u + v) / 2 with hωd
  have hω0 : 0 ≤ ω := by positivity
  have hω2 : (1 - σ) * cc ≤ ω ^ 2 := by
    have e : ω ^ 2 = (u ^ 2 + v ^ 2) / 4 + u * v / 2 := by rw [hωd]; ring
    rw [e]; linarith [mul_nonneg hu0 hv0, huv]
  set τ := ‖c * d + d * c‖ / 2 with hτd
  set q := ‖c * d - d * c‖ / 2 with hqd
  have hτ0 : 0 ≤ τ := by positivity
  have hτq : τ ^ 2 + q ^ 2 = 1 := by
    have e : τ ^ 2 + q ^ 2 = (‖c * d + d * c‖ ^ 2 + ‖c * d - d * c‖ ^ 2) / 4 := by
      rw [hτd, hqd]; ring
    rw [e, hcd]; norm_num
  have hq : q ^ 2 ≤ cc := by
    have hdd : 0 ≤ (c.imI * d.imI + c.imJ * d.imJ + c.imK * d.imK) ^ 2 := sq_nonneg _
    have h1 : cc * (d.imI ^ 2 + d.imJ ^ 2 + d.imK ^ 2) ≤ cc := by
      have := mul_le_mul_of_nonneg_left hδ1 hcc0
      rwa [mul_one] at this
    have e : q ^ 2 = ‖c * d - d * c‖ ^ 2 / 4 := by rw [hqd]; ring
    rw [e, Ecd]; linarith
  have hfin := final_scalar σ τ q ω cc hσ0 hσ1 hτ0 hτq hq hω0 hω2
  rw [hσd, hτd, hωd] at hfin
  linarith

end QuadFloor

#print axioms QuadFloor.quad_floor_two
