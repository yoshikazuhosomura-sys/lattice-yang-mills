import Tuning.FlatStokesV1

/-!
# 量の形の離散の Stokes

紙：(b)。`FlatStokes.torus_commutator` の量の版。
面の関係が誤差 `d x` で崩れているとき（`‖A x · B (x+e) − s x • (B x · A (x+f))‖ ≤ d x`、
場は単位、`|s x| ≤ 1`）、二つの周回の交換子の崩れは切り口の全ての面の誤差の和で抑えられる：
`‖W_e W_f − (切り口の s の積) • W_f W_e‖ ≤ Σ_{j<L'} Σ_{i<L} d (x + j•f + i•e)`。
一枚剥がすごとに誤差が一つ（場が単位なのでノルムは保たれる）。
-/

namespace FlatStokes

local notation "ℍr" => Quaternion ℝ

variable {G : Type*} [AddCommGroup G]

theorem norm_lineProd (A : G → ℍr) (e : G) (hA : ∀ x, ‖A x‖ = 1) :
    ∀ (k : ℕ) (x : G), ‖lineProd A e x k‖ = 1
  | 0, x => by simp [lineProd]
  | k + 1, x => by
    simp only [lineProd]
    rw [norm_mul, hA, norm_lineProd A e hA k (x + e), one_mul]

theorem abs_lineSign_le (s : G → ℝ) (e : G) (hs : ∀ x, |s x| ≤ 1) (x : G) (k : ℕ) :
    |lineSign s e x k| ≤ 1 := by
  unfold lineSign
  rw [Finset.abs_prod]
  exact Finset.prod_le_one (fun _ _ => abs_nonneg _) (fun i _ => hs _)

/-- **一列の梯子（量の形）** -/
theorem approx_ladder_line (A B : G → ℍr) (s d : G → ℝ) (e f : G)
    (hA : ∀ x, ‖A x‖ = 1) (hB : ∀ x, ‖B x‖ = 1) (hs : ∀ x, |s x| ≤ 1)
    (h : ∀ x, ‖A x * B (x + e) - s x • (B x * A (x + f))‖ ≤ d x) :
    ∀ (k : ℕ) (x : G), ‖lineProd A e x k * B (x + k • e)
      - lineSign s e x k • (B x * lineProd A e (x + f) k)‖
      ≤ ∑ i ∈ Finset.range k, d (x + i • e)
  | 0, x => by simp [lineProd, lineSign]
  | k + 1, x => by
    have ih := approx_ladder_line A B s d e f hA hB hs h k (x + e)
    have e1 : x + (k + 1) • e = x + e + k • e := by rw [succ_nsmul]; abel
    have e2 : x + f + e = x + e + f := by abel
    set σ := lineSign s e (x + e) k
    set L := lineProd A e (x + e + f) k
    set E1 := lineProd A e (x + e) k * B (x + e + k • e) - σ • (B (x + e) * L)
    set E2 := A x * B (x + e) - s x • (B x * A (x + f))
    have hid : lineProd A e x (k + 1) * B (x + (k + 1) • e)
        - lineSign s e x (k + 1) • (B x * lineProd A e (x + f) (k + 1))
        = A x * E1 + σ • (E2 * L) := by
      simp only [lineProd, lineSign_succ, e1, e2, E1, E2, L]
      simp only [mul_sub, sub_mul, mul_smul_comm, smul_mul_assoc, smul_sub, smul_smul,
        mul_assoc, mul_comm σ (s x)]
      abel
    rw [hid]
    have hL : ‖L‖ = 1 := norm_lineProd A e hA k _
    have hσ : |σ| ≤ 1 := abs_lineSign_le s e hs _ _
    calc ‖A x * E1 + σ • (E2 * L)‖ ≤ ‖A x * E1‖ + ‖σ • (E2 * L)‖ := norm_add_le _ _
      _ = ‖E1‖ + |σ| * ‖E2‖ := by
          rw [norm_mul, hA, one_mul, norm_smul, norm_mul, hL, mul_one, Real.norm_eq_abs]
      _ ≤ (∑ i ∈ Finset.range k, d (x + e + i • e)) + 1 * d x := by
          have := mul_le_mul hσ (h x) (norm_nonneg _) zero_le_one
          linarith [ih]
      _ = ∑ i ∈ Finset.range (k + 1), d (x + i • e) := by
          rw [Finset.sum_range_succ', one_mul]
          congr 1
          · refine Finset.sum_congr rfl fun i _ => ?_
            congr 1; rw [succ_nsmul]; abel
          · simp

/-- **一枚の梯子（量の形）** -/
theorem approx_ladder_sheet (P B : G → ℍr) (c d : G → ℝ) (f : G)
    (hP : ∀ x, ‖P x‖ = 1) (hB : ∀ x, ‖B x‖ = 1) (hc : ∀ x, |c x| ≤ 1)
    (h : ∀ x, ‖P x * B x - c x • (B x * P (x + f))‖ ≤ d x) :
    ∀ (j : ℕ) (x : G), ‖P x * lineProd B f x j
      - lineSign c f x j • (lineProd B f x j * P (x + j • f))‖
      ≤ ∑ i ∈ Finset.range j, d (x + i • f)
  | 0, x => by simp [lineProd, lineSign]
  | j + 1, x => by
    have ih := approx_ladder_sheet P B c d f hP hB hc h j (x + f)
    have e1 : x + (j + 1) • f = x + f + j • f := by rw [succ_nsmul]; abel
    set σ := lineSign c f (x + f) j
    set L := lineProd B f (x + f) j
    set E1 := P (x + f) * L - σ • (L * P (x + f + j • f))
    set E2 := P x * B x - c x • (B x * P (x + f))
    have hid : P x * lineProd B f x (j + 1)
        - lineSign c f x (j + 1) • (lineProd B f x (j + 1) * P (x + (j + 1) • f))
        = E2 * L + c x • (B x * E1) := by
      simp only [lineProd, lineSign_succ, e1, E1, E2, L]
      simp only [mul_sub, sub_mul, mul_smul_comm, smul_mul_assoc, smul_sub, smul_smul,
        mul_assoc]
      abel
    rw [hid]
    have hL : ‖L‖ = 1 := norm_lineProd B f hB j _
    calc ‖E2 * L + c x • (B x * E1)‖ ≤ ‖E2 * L‖ + ‖c x • (B x * E1)‖ := norm_add_le _ _
      _ = ‖E2‖ + |c x| * ‖E1‖ := by
          rw [norm_mul, hL, mul_one, norm_smul, norm_mul, hB, one_mul, Real.norm_eq_abs]
      _ ≤ d x + 1 * (∑ i ∈ Finset.range j, d (x + f + i • f)) := by
          have := mul_le_mul (hc x) ih (norm_nonneg _) zero_le_one
          linarith [h x]
      _ = ∑ i ∈ Finset.range (j + 1), d (x + i • f) := by
          rw [Finset.sum_range_succ', one_mul, add_comm (d x)]
          congr 1
          · refine Finset.sum_congr rfl fun i _ => ?_
            congr 1; rw [succ_nsmul]; abel
          · simp

/-- **離散の Stokes（量の形）**：周期 `L • e = 0`、`L' • f = 0` のとき、
`‖W_e W_f − sheetSign • W_f W_e‖ ≤ Σ_{j<L'} Σ_{i<L} d (x + j•f + i•e)` -/
theorem approx_torus_commutator (A B : G → ℍr) (s d : G → ℝ) (e f : G) (L L' : ℕ)
    (hL : L • e = 0) (hL' : L' • f = 0)
    (hA : ∀ x, ‖A x‖ = 1) (hB : ∀ x, ‖B x‖ = 1) (hs : ∀ x, |s x| ≤ 1)
    (h : ∀ x, ‖A x * B (x + e) - s x • (B x * A (x + f))‖ ≤ d x) (x : G) :
    ‖lineProd A e x L * lineProd B f x L'
      - sheetSign s e f L L' x • (lineProd B f x L' * lineProd A e x L)‖
      ≤ ∑ j ∈ Finset.range L', ∑ i ∈ Finset.range L, d (x + j • f + i • e) := by
  have h1 : ∀ y, ‖lineProd A e y L * B y - lineSign s e y L • (B y * lineProd A e (y + f) L)‖
      ≤ ∑ i ∈ Finset.range L, d (y + i • e) := by
    intro y
    have := approx_ladder_line A B s d e f hA hB hs h L y
    rwa [hL, add_zero] at this
  have := approx_ladder_sheet (fun y => lineProd A e y L) B (fun y => lineSign s e y L)
    (fun y => ∑ i ∈ Finset.range L, d (y + i • e)) f
    (fun y => norm_lineProd A e hA L y) hB (fun y => abs_lineSign_le s e hs y L) h1 L' x
  simp only [hL', add_zero] at this
  exact this

end FlatStokes

#print axioms FlatStokes.approx_torus_commutator
