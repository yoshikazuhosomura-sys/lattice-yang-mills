import Mathlib

/-!
# 反可換な二対の四元数の崩れの量の下界

紙：(a)。単位四元数 a, b, c, d について
`f := ‖ab + ba‖ + ‖cd + dc‖ + ‖ac − ca‖ + ‖bc − cb‖ ≥ 4/3`。
（`ab = −ba`、`cd = −dc`、`ac = ca`、`bc = cb` が両立しないことの、量の形。）

道：P := ‖ab − ba‖、Q := ‖cd − dc‖、u := ‖ac − ca‖、v := ‖bc − cb‖。
* 平行四辺形の法則で ‖ab + ba‖² = 4 − P²、‖cd + dc‖² = 4 − Q²。
* y := c の虚部、w := ab − ba（虚部だけ）。純な四元数の積の恒等式
  `‖wy − yw‖² + 4 (Re wy)² = 4‖w‖²‖y‖²`、`Re(wy) = Re(a(by − yb))`、
  `[w, c] = a[b,c] + [a,c]b − b[a,c] − [b,c]a` から `P²‖y‖² ≤ v² + (u+v)²`、
  また `Q ≤ 2‖y‖`。よって `P²Q² ≤ 8(u+v)²`、`PQ ≤ 3(u+v)`。
* `f ≥ (2 − P) + (2 − Q) + PQ/3 ≥ 4/3`（P, Q ∈ [0, 2]）。
-/

namespace QuadFloor

local notation "ℍr" => Quaternion ℝ

theorem nsq (q : ℍr) : ‖q‖ ^ 2 = q.re ^ 2 + q.imI ^ 2 + q.imJ ^ 2 + q.imK ^ 2 := by
  rw [sq, ← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']

theorem re_sq_le (q : ℍr) : q.re ^ 2 ≤ ‖q‖ ^ 2 := by
  rw [nsq]; nlinarith [sq_nonneg q.imI, sq_nonneg q.imJ, sq_nonneg q.imK]

/-- 純な四元数 w, y の積の恒等式 -/
theorem pure_identity (w y : ℍr) (hw : w.re = 0) (hy : y.re = 0) :
    ‖w * y - y * w‖ ^ 2 + 4 * (w * y).re ^ 2 = 4 * (‖w‖ ^ 2 * ‖y‖ ^ 2) := by
  rw [nsq, nsq, nsq]
  simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub, hw, hy]
  ring

theorem comm_re (a b : ℍr) : (a * b - b * a).re = 0 := by
  simp only [Quaternion.re_sub, Quaternion.re_mul]; ring

theorem re_comm_swap (a b y : ℍr) : ((a * b - b * a) * y).re = (a * (b * y - y * b)).re := by
  simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    Quaternion.re_sub, sub_mul, mul_sub]
  ring

theorem norm_comm_le (x y : ℍr) : ‖x * y - y * x‖ ≤ 2 * (‖x‖ * ‖y‖) := by
  calc ‖x * y - y * x‖ ≤ ‖x * y‖ + ‖y * x‖ := norm_sub_le _ _
    _ = 2 * (‖x‖ * ‖y‖) := by rw [norm_mul, norm_mul]; ring

/-- 虚部との交換子は元との交換子に等しい -/
theorem comm_im (x c : ℍr) : x * c.im - c.im * x = x * c - c * x := by
  have hc : c = (c.re : ℍr) + c.im := (Quaternion.re_add_im c).symm
  conv_rhs => rw [hc]
  rw [mul_add, add_mul, Quaternion.coe_commutes]
  abel

/-- **鍵の不等式**：単位四元数 a, b, c, d で `‖[a,b]‖²‖[c,d]‖² ≤ 8(‖[a,c]‖ + ‖[b,c]‖)²` -/
theorem key_ineq (a b c d : ℍr) (ha : ‖a‖ = 1) (hb : ‖b‖ = 1) (hd : ‖d‖ = 1) :
    ‖a * b - b * a‖ ^ 2 * ‖c * d - d * c‖ ^ 2
      ≤ 8 * (‖a * c - c * a‖ + ‖b * c - c * b‖) ^ 2 := by
  set y := c.im with hydef
  set w := a * b - b * a with hwdef
  have hyre : y.re = 0 := Quaternion.re_im c
  have hwre : w.re = 0 := comm_re a b
  set u := ‖a * c - c * a‖ with hu
  set v := ‖b * c - c * b‖ with hv
  have u0 : 0 ≤ u := norm_nonneg _
  have v0 : 0 ≤ v := norm_nonneg _
  -- Q ≤ 2‖y‖
  have hQ : ‖c * d - d * c‖ ≤ 2 * ‖y‖ := by
    have h1 : c * d - d * c = -(d * y - y * d) := by
      rw [comm_im d c]; abel
    rw [h1, norm_neg]
    calc ‖d * y - y * d‖ ≤ 2 * (‖d‖ * ‖y‖) := norm_comm_le _ _
      _ = 2 * ‖y‖ := by rw [hd, one_mul]
  -- Re(wy)² ≤ v²
  have hr : (w * y).re ^ 2 ≤ v ^ 2 := by
    rw [hwdef, re_comm_swap, comm_im b c]
    calc (a * (b * c - c * b)).re ^ 2 ≤ ‖a * (b * c - c * b)‖ ^ 2 := re_sq_le _
      _ = v ^ 2 := by rw [norm_mul, ha, one_mul]
  -- ‖wy − yw‖ ≤ 2(u+v)
  have hc : ‖w * y - y * w‖ ≤ 2 * (u + v) := by
    rw [comm_im w c]
    have hj : w * c - c * w = a * (b * c - c * b) + (a * c - c * a) * b
        - b * (a * c - c * a) - (b * c - c * b) * a := by
      rw [hwdef]; noncomm_ring
    rw [hj]
    have n1 : ‖a * (b * c - c * b)‖ = v := by rw [norm_mul, ha, one_mul]
    have n2 : ‖(a * c - c * a) * b‖ = u := by rw [norm_mul, hb, mul_one]
    have n3 : ‖b * (a * c - c * a)‖ = u := by rw [norm_mul, hb, one_mul]
    have n4 : ‖(b * c - c * b) * a‖ = v := by rw [norm_mul, ha, mul_one]
    calc ‖a * (b * c - c * b) + (a * c - c * a) * b - b * (a * c - c * a) - (b * c - c * b) * a‖
        ≤ ‖a * (b * c - c * b) + (a * c - c * a) * b - b * (a * c - c * a)‖
          + ‖(b * c - c * b) * a‖ := norm_sub_le _ _
      _ ≤ ‖a * (b * c - c * b) + (a * c - c * a) * b‖ + ‖b * (a * c - c * a)‖
          + ‖(b * c - c * b) * a‖ := by gcongr; exact norm_sub_le _ _
      _ ≤ ‖a * (b * c - c * b)‖ + ‖(a * c - c * a) * b‖ + ‖b * (a * c - c * a)‖
          + ‖(b * c - c * b) * a‖ := by gcongr; exact norm_add_le _ _
      _ = 2 * (u + v) := by rw [n1, n2, n3, n4]; ring
  have hid := pure_identity w y hwre hyre
  have hc2 : ‖w * y - y * w‖ ^ 2 ≤ (2 * (u + v)) ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) hc 2
  have hPY : ‖w‖ ^ 2 * ‖y‖ ^ 2 ≤ v ^ 2 + (u + v) ^ 2 := by nlinarith
  have hQ2 : ‖c * d - d * c‖ ^ 2 ≤ 4 * ‖y‖ ^ 2 := by
    have := pow_le_pow_left₀ (norm_nonneg _) hQ 2
    nlinarith
  have hw2 : 0 ≤ ‖w‖ ^ 2 := sq_nonneg _
  calc ‖w‖ ^ 2 * ‖c * d - d * c‖ ^ 2 ≤ ‖w‖ ^ 2 * (4 * ‖y‖ ^ 2) :=
        mul_le_mul_of_nonneg_left hQ2 hw2
    _ = 4 * (‖w‖ ^ 2 * ‖y‖ ^ 2) := by ring
    _ ≤ 4 * (v ^ 2 + (u + v) ^ 2) := by linarith
    _ ≤ 8 * (u + v) ^ 2 := by nlinarith

/-- 単位の積の和と差：`‖xy + yx‖² + ‖xy − yx‖² = 4` -/
theorem anti_add_comm (x y : ℍr) (hx : ‖x‖ = 1) (hy : ‖y‖ = 1) :
    ‖x * y + y * x‖ ^ 2 + ‖x * y - y * x‖ ^ 2 = 4 := by
  have h := parallelogram_law_with_norm ℝ (x * y) (y * x)
  rw [norm_mul, norm_mul, hx, hy] at h
  nlinarith [h]

/-- **崩れの量の下界**：単位四元数 a, b, c, d で
`4/3 ≤ ‖ab + ba‖ + ‖cd + dc‖ + ‖ac − ca‖ + ‖bc − cb‖` -/
theorem quad_floor (a b c d : ℍr) (ha : ‖a‖ = 1) (hb : ‖b‖ = 1) (hc : ‖c‖ = 1)
    (hd : ‖d‖ = 1) :
    4 / 3 ≤ ‖a * b + b * a‖ + ‖c * d + d * c‖ + ‖a * c - c * a‖ + ‖b * c - c * b‖ := by
  have hk := key_ineq a b c d ha hb hd
  have hab := anti_add_comm a b ha hb
  have hcd := anti_add_comm c d hc hd
  set s := ‖a * b + b * a‖
  set t := ‖c * d + d * c‖
  set P := ‖a * b - b * a‖
  set Q := ‖c * d - d * c‖
  set u := ‖a * c - c * a‖
  set v := ‖b * c - c * b‖
  have s0 : 0 ≤ s := norm_nonneg _
  have t0 : 0 ≤ t := norm_nonneg _
  have P0 : 0 ≤ P := norm_nonneg _
  have Q0 : 0 ≤ Q := norm_nonneg _
  have u0 : 0 ≤ u := norm_nonneg _
  have v0 : 0 ≤ v := norm_nonneg _
  have P2 : P ≤ 2 := by nlinarith
  have Q2 : Q ≤ 2 := by nlinarith
  have hs : 2 - P ≤ s := by nlinarith
  have ht : 2 - Q ≤ t := by nlinarith
  have hPQ : P * Q ≤ 3 * (u + v) := by
    by_contra hne
    push Not at hne
    have h3 : 0 ≤ 3 * (u + v) := by linarith
    have : (3 * (u + v)) ^ 2 < (P * Q) ^ 2 := by
      exact pow_lt_pow_left₀ hne h3 (by norm_num)
    nlinarith
  nlinarith [mul_nonneg (sub_nonneg.2 P2) (sub_nonneg.2 Q2)]

end QuadFloor

#print axioms QuadFloor.quad_floor
