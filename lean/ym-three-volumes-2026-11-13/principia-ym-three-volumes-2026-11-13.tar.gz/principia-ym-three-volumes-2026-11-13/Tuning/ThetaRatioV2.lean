import Tuning.ThetaLimitV2

/-!
# Z(1,1)/Z(1,0) → 0（β → ∞）と、言明が自明でないことの確かめ

紙：(iii)、§2.1。
* `ratio_tendsto_zero`：Z(1,1)/Z(1,0) → 0（β → ∞、全ての N, M ≥ 1）。
* `ratio_le`：β ≥ 0 で Z(1,1)/Z(1,0) ≤ e^{−βS/2}/v（S は (1,1) の最小の欠け、v は真空の近傍の体積）。
* `flat_exists_10`：対の背景 (1,0) には欠け 0 の配位が在る（`TwistBlocks.vac`）。だから
  `TwistFlat.no_flat_twist11` は捩れの組 (1,1) に固有の言明で、全ての背景で立つ自明な言明ではない。
* `theta_pos_somewhere`：θ(β) > 0 となる β ≥ 0 が在る（`tuning_exists` の仮定が κ > 0 で満たせる例）。
-/

open MeasureTheory Filter Topology TwistedWilson

namespace ThetaLimit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem ratio_le (β : ℝ) (hβ : 0 ≤ β) :
    ZW N M β true true / ZW N M β true false
      ≤ Real.exp (-(Smin N M / 2 * β)) / volV N M := by
  have hv := volV_pos N M
  have h0 := ZW_pos N M β true false
  have hA := Z11_le N M β hβ
  have hB := Z10_ge N M β hβ
  have hBpos : 0 < Real.exp (β * (nP N M - Smin N M / 2)) * volV N M :=
    mul_pos (Real.exp_pos _) hv
  calc ZW N M β true true / ZW N M β true false
      ≤ Real.exp (β * (nP N M - Smin N M)) / (Real.exp (β * (nP N M - Smin N M / 2)) * volV N M) :=
        div_le_div₀ (Real.exp_pos _).le hA hBpos hB
    _ = Real.exp (-(Smin N M / 2 * β)) / volV N M := by
        have e : β * (nP N M - Smin N M) = β * (nP N M - Smin N M / 2) + -(Smin N M / 2 * β) := by
          ring
        rw [e, Real.exp_add]
        field_simp

/-- **Z(1,1)/Z(1,0) → 0（β → ∞）** -/
theorem ratio_tendsto_zero :
    Tendsto (fun β => ZW N M β true true / ZW N M β true false) atTop (𝓝 0) := by
  have hg : 0 < Smin N M / 2 := by linarith [Smin_pos N M]
  have hexp : Tendsto (fun β : ℝ => Real.exp (-(Smin N M / 2 * β))) atTop (𝓝 0) :=
    Real.tendsto_exp_neg_atTop_nhds_zero.comp (Tendsto.const_mul_atTop hg tendsto_id)
  have hup : Tendsto (fun β : ℝ => Real.exp (-(Smin N M / 2 * β)) / volV N M) atTop (𝓝 0) := by
    simpa using hexp.div_const (volV N M)
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hup ?_ ?_
  · exact Eventually.of_forall fun β =>
      (div_pos (ZW_pos N M β true true) (ZW_pos N M β true false)).le
  · filter_upwards [eventually_ge_atTop 0] with β hβ
    exact ratio_le N M β hβ

/-- 背景 (1,0) には欠け 0 の配位が在る（対照） -/
theorem flat_exists_10 :
    ∃ ω : Link N M → SU2, ∀ B : Plaq N M, zt N M true false B * (hol N M ω B).re = 1 :=
  ⟨TwistBlocks.vac N M, TwistBlocks.vac_term N M⟩

/-- θ(β) > 0 となる β ≥ 0 が在る -/
theorem theta_pos_somewhere : ∃ β : ℝ, 0 ≤ β ∧ 0 < TwistBlocks.thetaM N M β := by
  obtain ⟨b0, hb0, h⟩ := exists_theta_gt N M 0 one_pos
  exact ⟨b0, hb0, h b0 le_rfl⟩

end ThetaLimit

#print axioms ThetaLimit.ratio_tendsto_zero
#print axioms ThetaLimit.flat_exists_10
#print axioms ThetaLimit.theta_pos_somewhere
