import Tuning.NoFlatTwistV2
import Tuning.ApproxStokesV1
import Tuning.QuadFloorV1
import Blocks.VacuumV1

/-!
# (1,1) の区画の最小の欠けの、格子の大きさに一様な下界

背景の捩れ n₁₂ = n₃₄ = 1（`zt N M true true`）の欠け
`D(ω) = Σ_B (1 − z_B Re U_B)`（`TwistFlat.defect11`）について、全ての N, M ≥ 1、全ての ω で
`(8/9)·N²M²/(N² + M²)² ≤ D(ω)`。対称な箱（N = M）では `2/9 ≤ D(ω)`（N に依らない）。

道：
* 面ごとの誤差 `ε_B := ‖hol_B − z_B‖`、`ε_B² = 2(1 − z_B Re hol_B)`（`eps_sq`）。
  面の関係 `U_μ(x)U_ν(x+μ) = hol_B · U_ν(x)U_μ(x+ν)` の崩れは `ε_B`（`face_approx`）。
* 各基点 x で、四つの向き (0,1)・(2,3)・(0,2)・(1,2) の周回 W₀, W₁（長さ N）、W₂, W₃（長さ M）に
  量の形の離散の Stokes（`FlatStokes.approx_torus_commutator`）を使い、切り口の符号の積は
  (0,1)・(2,3) で −1、(0,2)・(1,2) で 1（全ての基点で）。四元数の下界
  （`QuadFloor.quad_floor`）から、四つの切り口の誤差の和は 4/3 以上（`local_floor`）。
* 基点の和：各面は同じ向きの切り口の基点の数だけ数えられ（平行移動の不変性）、
  `Σ_x (切り口の和) = L L' Σ_x ε_{(x,P)}`。Cauchy–Schwarz を二度。
向き (0,3)・(1,3) は使わない。
-/

open Finset TwistedWilson FlatStokes

namespace TwistFloor

local notation "ℍr" => Quaternion ℝ

section
variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 面ごとの欠け `1 − z_B Re hol_B` -/
noncomputable def dterm (ω : Link N M → SU2) (x : Site N M) (P : Plane) : ℝ :=
  1 - zt N M true true (x, P) * (hol N M ω (x, P)).re

/-- 面ごとの誤差 `‖hol_B − z_B‖` -/
noncomputable def eps (ω : Link N M → SU2) (x : Site N M) (P : Plane) : ℝ :=
  ‖hol N M ω (x, P) - ((zt N M true true (x, P) : ℝ) : ℍr)‖

theorem dterm_nonneg (ω : Link N M → SU2) (x : Site N M) (P : Plane) : 0 ≤ dterm N M ω x P := by
  unfold dterm; linarith [TwistFlat.term_le_one N M true true ω (x, P)]

theorem eps_nonneg (ω : Link N M → SU2) (x : Site N M) (P : Plane) : 0 ≤ eps N M ω x P :=
  norm_nonneg _

/-- `ε_B² = 2(1 − z_B Re hol_B)` -/
theorem eps_sq (ω : Link N M → SU2) (x : Site N M) (P : Plane) :
    eps N M ω x P ^ 2 = 2 * dterm N M ω x P := by
  unfold eps dterm
  have hn2 := QuadFloor.nsq (hol N M ω (x, P))
  rw [norm_hol] at hn2
  have hz : zt N M true true (x, P) ^ 2 = 1 := by
    rcases TwistFlat.zt_pm N M true true (x, P) with h | h <;> rw [h] <;> norm_num
  rw [QuadFloor.nsq]
  simp only [Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
    Quaternion.re_coe, Quaternion.imI_coe, Quaternion.imJ_coe, Quaternion.imK_coe, sub_zero]
  linear_combination (-1 : ℝ) * hn2 + hz

theorem normU (u : SU2) : ‖(u : ℍr)‖ = 1 := norm_eq_of_mem_sphere u

/-- 面の関係（崩れつき）：`U_μ(x)U_ν(x+μ) = hol_B · (U_ν(x)U_μ(x+ν))` -/
theorem face_eq (ω : Link N M → SU2) (x : Site N M) (P : Plane) :
    (ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      = hol N M ω (x, P) * ((ω (x, P.1.2) : ℍr) * (ω (x + ev N M P.1.2, P.1.1) : ℍr)) := by
  have hh : hol N M ω (x, P) = (ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      * star (ω (x + ev N M P.1.2, P.1.1) : ℍr) * star (ω (x, P.1.2) : ℍr) := rfl
  rw [hh]
  simp only [mul_assoc, TwistFlat.star_mul_unit_left, TwistFlat.star_mul_unit, mul_one]

theorem face_approx (ω : Link N M → SU2) (x : Site N M) (P : Plane) :
    ‖(ω (x, P.1.1) : ℍr) * (ω (x + ev N M P.1.1, P.1.2) : ℍr)
      - zt N M true true (x, P) • ((ω (x, P.1.2) : ℍr) * (ω (x + ev N M P.1.2, P.1.1) : ℍr))‖
      = eps N M ω x P := by
  rw [face_eq, ← Quaternion.coe_mul_eq_smul, ← sub_mul, norm_mul, norm_mul, normU, normU,
    mul_one, mul_one]
  rfl

/-- 一つの向きでちょうど一度 0 になる -/
theorem prod_shift (L : ℕ) [NeZero L] (c : ZMod L) :
    ∏ i ∈ range L, (if c + (i : ZMod L) = 0 then (-1 : ℝ) else 1) = -1 := by
  have key : ∀ i ∈ range L, (c + (i : ZMod L) = 0 ↔ i = (-c).val) := by
    intro i hi
    have hi' := Finset.mem_range.1 hi
    constructor
    · intro h
      have h2 : (i : ZMod L) = -c := by linear_combination h
      rw [← h2, ZMod.val_cast_of_lt hi']
    · rintro rfl
      rw [ZMod.natCast_zmod_val]; ring
  have hc : ∀ i ∈ range L, (if c + (i : ZMod L) = 0 then (-1 : ℝ) else 1)
      = (if i = (-c).val then (-1 : ℝ) else 1) := by
    intro i hi
    by_cases h : i = (-c).val
    · rw [if_pos ((key i hi).2 h), if_pos h]
    · rw [if_neg (fun h' => h ((key i hi).1 h')), if_neg h]
  rw [Finset.prod_congr rfl hc, Finset.prod_ite_eq' (range L) ((-c).val) (fun _ => (-1 : ℝ))]
  simp [ZMod.val_lt]

theorem zt01_at (x : Site N M) (i j : ℕ) :
    zt N M true true (x + j • ev N M 1 + i • ev N M 0, p01)
      = if x.1.1 + (i : ZMod N) = 0 ∧ x.1.2 + (j : ZMod N) = 0 then -1 else 1 := by
  unfold zt tw
  simp [ev, p01, p23, Prod.smul_mk, nsmul_eq_mul, Prod.ext_iff]

theorem zt23_at (x : Site N M) (i j : ℕ) :
    zt N M true true (x + j • ev N M 3 + i • ev N M 2, p23)
      = if x.2.1 + (i : ZMod M) = 0 ∧ x.2.2 + (j : ZMod M) = 0 then -1 else 1 := by
  unfold zt tw
  simp [ev, p01, p23, Prod.smul_mk, nsmul_eq_mul, Prod.ext_iff]

/-- 基点 x を通る (0,1) の切り口の符号の積は −1（全ての x） -/
theorem sheet01_at (x : Site N M) :
    sheetSign (fun y => zt N M true true (y, p01)) (ev N M 0) (ev N M 1) N N x = -1 := by
  unfold sheetSign lineSign
  have hin : ∀ j : ℕ, ∏ i ∈ range N, zt N M true true (x + j • ev N M 1 + i • ev N M 0, p01)
      = if x.1.2 + (j : ZMod N) = 0 then -1 else 1 := by
    intro j
    simp only [zt01_at]
    by_cases hj : x.1.2 + (j : ZMod N) = 0
    · simp only [hj, and_true, if_true]; exact prod_shift N x.1.1
    · simp [hj]
  exact (Finset.prod_congr rfl fun j _ => hin j).trans (prod_shift N x.1.2)

/-- 基点 x を通る (2,3) の切り口の符号の積は −1（全ての x） -/
theorem sheet23_at (x : Site N M) :
    sheetSign (fun y => zt N M true true (y, p23)) (ev N M 2) (ev N M 3) M M x = -1 := by
  unfold sheetSign lineSign
  have hin : ∀ j : ℕ, ∏ i ∈ range M, zt N M true true (x + j • ev N M 3 + i • ev N M 2, p23)
      = if x.2.2 + (j : ZMod M) = 0 then -1 else 1 := by
    intro j
    simp only [zt23_at]
    by_cases hj : x.2.2 + (j : ZMod M) = 0
    · simp only [hj, and_true, if_true]; exact prod_shift M x.2.1
    · simp [hj]
  exact (Finset.prod_congr rfl fun j _ => hin j).trans (prod_shift M x.2.2)

/-- 基点 x の周回 -/
noncomputable def W (ω : Link N M → SU2) (μ : Fin 4) (L : ℕ) (x : Site N M) : ℍr :=
  lineProd (fun y => (ω (y, μ) : ℍr)) (ev N M μ) x L

theorem norm_W (ω : Link N M → SU2) (μ : Fin 4) (L : ℕ) (x : Site N M) : ‖W N M ω μ L x‖ = 1 :=
  norm_lineProd _ _ (fun y => normU _) L x

/-- 基点 x を通る向き P の切り口の誤差の和 -/
noncomputable def sh (ω : Link N M → SU2) (P : Plane) (μ ν : Fin 4) (L L' : ℕ) (x : Site N M) : ℝ :=
  ∑ j ∈ range L', ∑ i ∈ range L, eps N M ω (x + j • ev N M ν + i • ev N M μ) P

theorem comm01 (ω : Link N M → SU2) (x : Site N M) :
    ‖W N M ω 0 N x * W N M ω 1 N x + W N M ω 1 N x * W N M ω 0 N x‖
      ≤ sh N M ω p01 0 1 N N x := by
  have h := approx_torus_commutator (fun y => (ω (y, 0) : ℍr)) (fun y => (ω (y, 1) : ℍr))
    (fun y => zt N M true true (y, p01)) (fun y => eps N M ω y p01) (ev N M 0) (ev N M 1) N N
    (TwistFlat.nsmul_ev0 N M) (TwistFlat.nsmul_ev1 N M) (fun _ => normU _) (fun _ => normU _)
    (fun _ => (abs_zt N M true true _).le) (fun y => le_of_eq (face_approx N M ω y p01)) x
  rw [sheet01_at, neg_one_smul, sub_neg_eq_add] at h
  exact h

theorem comm23 (ω : Link N M → SU2) (x : Site N M) :
    ‖W N M ω 2 M x * W N M ω 3 M x + W N M ω 3 M x * W N M ω 2 M x‖
      ≤ sh N M ω p23 2 3 M M x := by
  have h := approx_torus_commutator (fun y => (ω (y, 2) : ℍr)) (fun y => (ω (y, 3) : ℍr))
    (fun y => zt N M true true (y, p23)) (fun y => eps N M ω y p23) (ev N M 2) (ev N M 3) M M
    (TwistFlat.nsmul_ev2 N M) (TwistFlat.nsmul_ev3 N M) (fun _ => normU _) (fun _ => normU _)
    (fun _ => (abs_zt N M true true _).le) (fun y => le_of_eq (face_approx N M ω y p23)) x
  rw [sheet23_at, neg_one_smul, sub_neg_eq_add] at h
  exact h

theorem comm02 (ω : Link N M → SU2) (x : Site N M) :
    ‖W N M ω 0 N x * W N M ω 2 M x - W N M ω 2 M x * W N M ω 0 N x‖
      ≤ sh N M ω TwistFlat.pl02 0 2 N M x := by
  have h := approx_torus_commutator (fun y => (ω (y, 0) : ℍr)) (fun y => (ω (y, 2) : ℍr))
    (fun _ => (1 : ℝ)) (fun y => eps N M ω y TwistFlat.pl02) (ev N M 0) (ev N M 2) N M
    (TwistFlat.nsmul_ev0 N M) (TwistFlat.nsmul_ev2 N M) (fun _ => normU _) (fun _ => normU _)
    (fun _ => by norm_num)
    (fun y => by
      have := face_approx N M ω y TwistFlat.pl02
      rw [TwistFlat.zt_pl02] at this
      exact le_of_eq this) x
  rw [TwistFlat.sheetSign_one, one_smul] at h
  exact h

theorem comm12 (ω : Link N M → SU2) (x : Site N M) :
    ‖W N M ω 1 N x * W N M ω 2 M x - W N M ω 2 M x * W N M ω 1 N x‖
      ≤ sh N M ω TwistFlat.pl12 1 2 N M x := by
  have h := approx_torus_commutator (fun y => (ω (y, 1) : ℍr)) (fun y => (ω (y, 2) : ℍr))
    (fun _ => (1 : ℝ)) (fun y => eps N M ω y TwistFlat.pl12) (ev N M 1) (ev N M 2) N M
    (TwistFlat.nsmul_ev1 N M) (TwistFlat.nsmul_ev2 N M) (fun _ => normU _) (fun _ => normU _)
    (fun _ => by norm_num)
    (fun y => by
      have := face_approx N M ω y TwistFlat.pl12
      rw [TwistFlat.zt_pl12] at this
      exact le_of_eq this) x
  rw [TwistFlat.sheetSign_one, one_smul] at h
  exact h

/-- **各基点で、四つの切り口の誤差の和は 4/3 以上** -/
theorem local_floor (ω : Link N M → SU2) (x : Site N M) :
    4 / 3 ≤ sh N M ω p01 0 1 N N x + sh N M ω p23 2 3 M M x
      + sh N M ω TwistFlat.pl02 0 2 N M x + sh N M ω TwistFlat.pl12 1 2 N M x := by
  have hq := QuadFloor.quad_floor (W N M ω 0 N x) (W N M ω 1 N x) (W N M ω 2 M x)
    (W N M ω 3 M x) (norm_W N M ω 0 N x) (norm_W N M ω 1 N x) (norm_W N M ω 2 M x)
    (norm_W N M ω 3 M x)
  linarith [comm01 N M ω x, comm23 N M ω x, comm02 N M ω x, comm12 N M ω x]

theorem sum_translate (g : Site N M → ℝ) (t : Site N M) : ∑ x, g (x + t) = ∑ x, g x :=
  Fintype.sum_equiv (Equiv.addRight t) _ _ (fun _ => rfl)

/-- 基点の和：各面は切り口の基点の数 L L' だけ数えられる -/
theorem sum_sh (ω : Link N M → SU2) (P : Plane) (μ ν : Fin 4) (L L' : ℕ) :
    ∑ x, sh N M ω P μ ν L L' x = ((L' : ℝ) * L) * ∑ x, eps N M ω x P := by
  unfold sh
  calc ∑ x, ∑ j ∈ range L', ∑ i ∈ range L, eps N M ω (x + j • ev N M ν + i • ev N M μ) P
      = ∑ j ∈ range L', ∑ x, ∑ i ∈ range L, eps N M ω (x + j • ev N M ν + i • ev N M μ) P :=
        Finset.sum_comm
    _ = ∑ j ∈ range L', ∑ i ∈ range L, ∑ x,
          eps N M ω (x + (j • ev N M ν + i • ev N M μ)) P := by
        refine Finset.sum_congr rfl fun j _ => ?_
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun x _ => ?_
        rw [add_assoc]
    _ = ∑ j ∈ range L', ∑ i ∈ range L, ∑ x, eps N M ω x P := by
        refine Finset.sum_congr rfl fun j _ => Finset.sum_congr rfl fun i _ => ?_
        exact sum_translate N M (fun x => eps N M ω x P) _
    _ = ((L' : ℝ) * L) * ∑ x, eps N M ω x P := by
        simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]; ring

theorem card_site : (Fintype.card (Site N M) : ℝ) = (N : ℝ) ^ 2 * (M : ℝ) ^ 2 := by
  simp only [Fintype.card_prod, ZMod.card]; push_cast; ring

/-- Cauchy–Schwarz：`(Σ_x ε_{(x,P)})² ≤ |Site| · 2 Σ_x (1 − z Re hol)` -/
theorem cs_plane (ω : Link N M → SU2) (P : Plane) :
    (∑ x, eps N M ω x P) ^ 2 ≤ ((N : ℝ) ^ 2 * (M : ℝ) ^ 2) * (2 * ∑ x, dterm N M ω x P) := by
  have h := sq_sum_le_card_mul_sum_sq (s := (univ : Finset (Site N M))) (f := fun x => eps N M ω x P)
  rw [Finset.card_univ, card_site] at h
  simp only [eps_sq, ← Finset.mul_sum] at h
  exact h

/-- 欠けは四つの向きの面の欠けの和以上 -/
theorem four_planes_le (ω : Link N M → SU2) :
    ∑ x, dterm N M ω x p01 + ∑ x, dterm N M ω x p23 + ∑ x, dterm N M ω x TwistFlat.pl02
      + ∑ x, dterm N M ω x TwistFlat.pl12 ≤ TwistFlat.defect11 N M ω := by
  have hD : TwistFlat.defect11 N M ω = ∑ x, ∑ P, dterm N M ω x P := by
    unfold TwistFlat.defect11 dterm
    exact Fintype.sum_prod_type _
  rw [hD, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  refine Finset.sum_le_sum fun x _ => ?_
  have hsub : ({p01, p23, TwistFlat.pl02, TwistFlat.pl12} : Finset Plane) ⊆ univ :=
    Finset.subset_univ _
  have hle := Finset.sum_le_sum_of_subset_of_nonneg hsub
    (fun P _ _ => dterm_nonneg N M ω x P)
  rw [Finset.sum_insert (by decide), Finset.sum_insert (by decide),
    Finset.sum_insert (by decide), Finset.sum_singleton] at hle
  linarith

theorem cs4 (a b c d p q r s : ℝ) :
    (a * p + b * q + c * r + d * s) ^ 2
      ≤ (a ^ 2 + b ^ 2 + c ^ 2 + d ^ 2) * (p ^ 2 + q ^ 2 + r ^ 2 + s ^ 2) := by
  nlinarith [sq_nonneg (a * q - b * p), sq_nonneg (a * r - c * p), sq_nonneg (a * s - d * p),
    sq_nonneg (b * r - c * q), sq_nonneg (b * s - d * q), sq_nonneg (c * s - d * r)]

/-- **最小の欠けの下界（縦横の比に依る形）**：全ての N, M ≥ 1、全ての ω で
`(8/9)·N²M²/(N² + M²)² ≤ D(ω)` -/
theorem defect11_ge (ω : Link N M → SU2) :
    8 / 9 * ((N : ℝ) ^ 2 * (M : ℝ) ^ 2) / ((N : ℝ) ^ 2 + (M : ℝ) ^ 2) ^ 2
      ≤ TwistFlat.defect11 N M ω := by
  set S1 := ∑ x, eps N M ω x p01
  set S2 := ∑ x, eps N M ω x p23
  set S3 := ∑ x, eps N M ω x TwistFlat.pl02
  set S4 := ∑ x, eps N M ω x TwistFlat.pl12
  set D1 := ∑ x, dterm N M ω x p01
  set D2 := ∑ x, dterm N M ω x p23
  set D3 := ∑ x, dterm N M ω x TwistFlat.pl02
  set D4 := ∑ x, dterm N M ω x TwistFlat.pl12
  have hN : (0 : ℝ) < N := by exact_mod_cast NeZero.pos N
  have hM : (0 : ℝ) < M := by exact_mod_cast NeZero.pos M
  set a := (N : ℝ) ^ 2
  set b := (M : ℝ) ^ 2
  set K := a * b with hK
  have ha : 0 < a := by positivity
  have hb : 0 < b := by positivity
  have hK0 : 0 < K := mul_pos ha hb
  -- 基点の和
  have hsum : 4 / 3 * K ≤ a * S1 + b * S2 + ((N : ℝ) * M) * S3 + ((N : ℝ) * M) * S4 := by
    have h1 := Finset.sum_le_sum (s := (univ : Finset (Site N M))) fun x _ => local_floor N M ω x
    rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_site] at h1
    simp only [Finset.sum_add_distrib, sum_sh] at h1
    have e1 : (N : ℝ) * N = a := by ring
    have e2 : (M : ℝ) * M = b := by ring
    have e3 : (M : ℝ) * N = N * M := by ring
    rw [e1, e2, e3] at h1
    linarith
  have hc1 := cs_plane N M ω p01
  have hc2 := cs_plane N M ω p23
  have hc3 := cs_plane N M ω TwistFlat.pl02
  have hc4 := cs_plane N M ω TwistFlat.pl12
  have hfour := four_planes_le N M ω
  have hcs := cs4 a b ((N : ℝ) * M) ((N : ℝ) * M) S1 S2 S3 S4
  have hab : a ^ 2 + b ^ 2 + ((N : ℝ) * M) ^ 2 + ((N : ℝ) * M) ^ 2 = (a + b) ^ 2 := by
    simp only [a, b]; ring
  rw [hab] at hcs
  have hX0 : 0 ≤ 4 / 3 * K := by positivity
  have hsq := pow_le_pow_left₀ hX0 hsum 2
  have hSS : S1 ^ 2 + S2 ^ 2 + S3 ^ 2 + S4 ^ 2 ≤ K * (2 * (D1 + D2 + D3 + D4)) := by
    rw [← hK] at hc1 hc2 hc3 hc4
    nlinarith
  have hab0 : 0 ≤ (a + b) ^ 2 := sq_nonneg _
  have hmain : (4 / 3 * K) ^ 2 ≤ (a + b) ^ 2 * (K * (2 * (D1 + D2 + D3 + D4))) :=
    le_trans hsq (le_trans hcs (mul_le_mul_of_nonneg_left hSS hab0))
  have hmain2 : 8 / 9 * K ≤ (a + b) ^ 2 * (D1 + D2 + D3 + D4) := by
    have : K * (16 / 9 * K) ≤ K * (2 * ((a + b) ^ 2 * (D1 + D2 + D3 + D4))) := by
      nlinarith
    have := le_of_mul_le_mul_left this hK0
    linarith
  have hpos : 0 < (a + b) ^ 2 := by positivity
  rw [div_le_iff₀ hpos]
  nlinarith

/-- 対照：片方の面だけの捩れ (1,0) では、欠けに正の下界は無い（`vac` で欠け 0） -/
theorem no_floor_10 :
    ¬ ∃ c : ℝ, 0 < c ∧ ∀ ω : Link N M → SU2,
      c ≤ ∑ B, (1 - zt N M true false B * (hol N M ω B).re) := by
  rintro ⟨c, hc, h⟩
  have := h (TwistBlocks.vac N M)
  simp only [TwistBlocks.vac_term, sub_self, Finset.sum_const_zero] at this
  linarith

end

/-- **対称な箱の一様な下界**：全ての N ≥ 1、全ての ω で `2/9 ≤ D(ω)` -/
theorem defect11_sym (N : ℕ) [NeZero N] (ω : Link N N → SU2) :
    2 / 9 ≤ TwistFlat.defect11 N N ω := by
  have h := defect11_ge N N ω
  have hN : (0 : ℝ) < N := by exact_mod_cast NeZero.pos N
  have he : 8 / 9 * ((N : ℝ) ^ 2 * (N : ℝ) ^ 2) / ((N : ℝ) ^ 2 + (N : ℝ) ^ 2) ^ 2 = 2 / 9 := by
    field_simp; ring
  rw [he] at h
  exact h

/-- **言明の形**：`∃ c > 0, ∀ N ≥ 1, ∀ ω, c ≤ D_{N,N}(ω)`（c = 2/9） -/
theorem defect11_uniform_floor :
    ∃ c : ℝ, 0 < c ∧ ∀ (N : ℕ) [NeZero N] (ω : Link N N → SU2), c ≤ TwistFlat.defect11 N N ω :=
  ⟨2 / 9, by norm_num, fun N _ ω => defect11_sym N ω⟩

/-- 最小の欠け（下限）も 2/9 以上 -/
theorem minDefect11_sym (N : ℕ) [NeZero N] : 2 / 9 ≤ ⨅ ω, TwistFlat.defect11 N N ω :=
  le_ciInf (defect11_sym N)

/-- 確かめ：N = M = 1（退化した格子）、自明な配位でも下界は立つ -/
example : 2 / 9 ≤ TwistFlat.defect11 1 1 (fun _ => 1) := defect11_sym 1 _

end TwistFloor

#print axioms TwistFloor.defect11_ge
#print axioms TwistFloor.defect11_uniform_floor
#print axioms TwistFloor.no_floor_10
