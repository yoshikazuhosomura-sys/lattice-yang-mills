import Blocks.ThickFloorQuatV1

/-!
# 離散の Stokes（中心の値の曲率の接続）と、反可換な二対の四元数が両立しないこと

紙：「(1,1) の区画に欠け 0 の配位が無いことの素描」の代数の部分。
加法群 `G` の上の四元数の場 `A, B : G → ℍ` が、全ての `x` で
`A x · B (x+e) = s x • (B x · A (x+f))`（面の関係、`s x` は実数）を満たすとき、
* `ladder_line`：向き `e` の線の積 `lineProd A e x k` を `B` に通す関係（帰納で一列ずつ）。
* `ladder_sheet`：線の積 `P` と向き `f` の線の積を交換する関係（帰納でもう一方の向きに一列ずつ）。
* `torus_commutator`：`L • e = 0`、`L' • f = 0`（周期）なら、二つの周回の積 `W_e`、`W_f` について
  `W_e · W_f = d • (W_f · W_e)`、`d` は切り口の全ての面の `s` の積（`sheetSign`）。
* `no_twisted_quadruple`：単位四元数 a, b, c, d で ab = −ba、cd = −dc、ac = ca、bc = cb は両立しない。
-/

namespace FlatStokes

local notation "ℍr" => Quaternion ℝ

variable {G : Type*} [AddCommGroup G]

/-- 向き `e` の線の積 `A x · A (x+e) ⋯ A (x+(k−1)e)` -/
noncomputable def lineProd (A : G → ℍr) (e : G) : G → ℕ → ℍr
  | _, 0 => 1
  | x, k + 1 => A x * lineProd A e (x + e) k

/-- 線の上の符号の積 `Π_{i<k} s (x + i•e)` -/
def lineSign (s : G → ℝ) (e : G) (x : G) (k : ℕ) : ℝ :=
  ∏ i ∈ Finset.range k, s (x + i • e)

theorem lineSign_zero (s : G → ℝ) (e x : G) : lineSign s e x 0 = 1 := by
  simp [lineSign]

theorem lineSign_succ (s : G → ℝ) (e x : G) (k : ℕ) :
    lineSign s e x (k + 1) = s x * lineSign s e (x + e) k := by
  unfold lineSign
  rw [Finset.prod_range_succ', mul_comm]
  congr 1
  · simp
  · refine Finset.prod_congr rfl fun i _ => ?_
    congr 1
    rw [succ_nsmul]; abel

theorem lineSign_one (e x : G) (k : ℕ) : lineSign (fun _ => (1 : ℝ)) e x k = 1 := by
  simp [lineSign]

/-- **一列の梯子**：面の関係から、線の積を `B` に通す -/
theorem ladder_line (A B : G → ℍr) (s : G → ℝ) (e f : G)
    (h : ∀ x, A x * B (x + e) = s x • (B x * A (x + f))) :
    ∀ (k : ℕ) (x : G), lineProd A e x k * B (x + k • e)
      = lineSign s e x k • (B x * lineProd A e (x + f) k)
  | 0, x => by simp [lineProd, lineSign]
  | k + 1, x => by
    have ih := ladder_line A B s e f h k (x + e)
    have h' : ∀ y (Z : ℍr), A y * (B (y + e) * Z) = s y • (B y * (A (y + f) * Z)) := by
      intro y Z; rw [← mul_assoc, h, smul_mul_assoc, mul_assoc]
    have e1 : x + (k + 1) • e = x + e + k • e := by rw [succ_nsmul]; abel
    have e2 : x + e + f = x + f + e := by abel
    simp only [lineProd]
    rw [lineSign_succ, e1, mul_assoc, ih, mul_smul_comm, h', smul_smul, e2, mul_comm (s x)]

/-- **一枚の梯子**：`P x · B x = c x • (B x · P (x+f))` から、`P` と向き `f` の線の積の交換 -/
theorem ladder_sheet (P B : G → ℍr) (c : G → ℝ) (f : G)
    (h : ∀ x, P x * B x = c x • (B x * P (x + f))) :
    ∀ (j : ℕ) (x : G), P x * lineProd B f x j
      = lineSign c f x j • (lineProd B f x j * P (x + j • f))
  | 0, x => by simp [lineProd, lineSign]
  | j + 1, x => by
    have ih := ladder_sheet P B c f h j (x + f)
    have e1 : x + (j + 1) • f = x + f + j • f := by rw [succ_nsmul]; abel
    simp only [lineProd]
    rw [← mul_assoc, h, smul_mul_assoc, mul_assoc (B x), ih, mul_smul_comm, smul_smul,
      lineSign_succ, e1, mul_assoc (B x)]

/-- 切り口の符号 `Π_{j<L'} Π_{i<L} s (x + j•f + i•e)` -/
def sheetSign (s : G → ℝ) (e f : G) (L L' : ℕ) (x : G) : ℝ :=
  lineSign (fun y => lineSign s e y L) f x L'

/-- **離散の Stokes（トーラスの周回の交換子）** -/
theorem torus_commutator (A B : G → ℍr) (s : G → ℝ) (e f : G) (L L' : ℕ)
    (hL : L • e = 0) (hL' : L' • f = 0)
    (h : ∀ x, A x * B (x + e) = s x • (B x * A (x + f))) (x : G) :
    lineProd A e x L * lineProd B f x L'
      = sheetSign s e f L L' x • (lineProd B f x L' * lineProd A e x L) := by
  have h1 : ∀ y, lineProd A e y L * B y = lineSign s e y L • (B y * lineProd A e (y + f) L) := by
    intro y
    have := ladder_line A B s e f h L y
    rwa [hL, add_zero] at this
  have := ladder_sheet (fun y => lineProd A e y L) B (fun y => lineSign s e y L) f h1 L' x
  simp only [hL', add_zero] at this
  exact this

/-- 単位四元数の線の積は単位 -/
theorem normSq_lineProd (A : G → ℍr) (e : G) (hA : ∀ x, Quaternion.normSq (A x) = 1) :
    ∀ (k : ℕ) (x : G), Quaternion.normSq (lineProd A e x k) = 1
  | 0, x => by simp [lineProd]
  | k + 1, x => by
    simp only [lineProd]
    rw [map_mul, hA, normSq_lineProd A e hA k (x + e), one_mul]

theorem ne_zero_of_normSq {q : ℍr} (h : Quaternion.normSq q = 1) : q ≠ 0 := by
  intro h0; rw [h0, map_zero] at h; exact zero_ne_one h

/-- **反可換な二対は両立しない**：単位四元数 a, b, c, d で
`ab = −ba`、`cd = −dc`、`ac = ca`、`bc = cb` となるものは無い -/
theorem no_twisted_quadruple (a b c d : ℍr) (ha : Quaternion.normSq a = 1)
    (hb : Quaternion.normSq b = 1) (hc : Quaternion.normSq c = 1) (hd : Quaternion.normSq d = 1)
    (hab : a * b = -(b * a)) (hcd : c * d = -(d * c)) (hac : a * c = c * a)
    (hbc : b * c = c * b) : False := by
  obtain ⟨g, hg, hga, hgb⟩ := ThickFloor.anticomm_conj a b ha hb hab
  have conj_mul : ∀ p q : ℍr, (g * p * g⁻¹) * (g * q * g⁻¹) = g * (p * q) * g⁻¹ := by
    intro p q
    simp only [mul_assoc, inv_mul_cancel_left₀ hg]
  set X := g * c * g⁻¹ with hX
  set Y := g * d * g⁻¹ with hY
  have hXi : X * ThickFloor.qi = ThickFloor.qi * X := by
    rw [← hga, hX, conj_mul, conj_mul, hac]
  have hXj : X * ThickFloor.qj = ThickFloor.qj * X := by
    rw [← hgb, hX, conj_mul, conj_mul, hbc]
  have hXY : X * Y = -(Y * X) := by
    rw [hX, hY, conj_mul, conj_mul, hcd, mul_neg, neg_mul]
  have i1 := congrArg (fun q : ℍr => q.imJ) hXi
  have i2 := congrArg (fun q : ℍr => q.imK) hXi
  have j1 := congrArg (fun q : ℍr => q.imK) hXj
  simp only [Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.imI_mul, ThickFloor.qi_re,
    ThickFloor.qi_imI, ThickFloor.qi_imJ, ThickFloor.qi_imK, ThickFloor.qj_re, ThickFloor.qj_imI,
    ThickFloor.qj_imJ, ThickFloor.qj_imK, mul_zero, zero_mul, mul_one, one_mul, sub_zero,
    zero_sub, add_zero, zero_add] at i1 i2 j1
  have xJ : X.imJ = 0 := by linarith
  have xK : X.imK = 0 := by linarith
  have xI : X.imI = 0 := by linarith
  have hXr : X = ((X.re : ℝ) : ℍr) := by
    apply Quaternion.ext <;> simp [xI, xJ, xK]
  have hcomm : X * Y = Y * X := by
    rw [hXr, Quaternion.coe_mul_eq_smul, Quaternion.mul_coe_eq_smul]
  have h2 : X * Y = 0 := by
    have : (2 : ℝ) • (X * Y) = 0 := by
      rw [two_smul]; nth_rewrite 1 [hcomm]; rw [hXY, add_neg_cancel]
    exact (smul_eq_zero.mp this).resolve_left two_ne_zero
  have hX0 : X ≠ 0 := mul_ne_zero (mul_ne_zero hg (ne_zero_of_normSq hc)) (inv_ne_zero hg)
  have hY0 : Y ≠ 0 := mul_ne_zero (mul_ne_zero hg (ne_zero_of_normSq hd)) (inv_ne_zero hg)
  exact (mul_ne_zero hX0 hY0) h2

end FlatStokes

#print axioms FlatStokes.torus_commutator
#print axioms FlatStokes.no_twisted_quadruple
