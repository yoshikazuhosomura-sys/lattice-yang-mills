import Tuning.ThetaLimitV2

/-!
# ΔF(β)/β → S（β → ∞、格子を止めて）

紙：ΔF_N(β) := ln(Z(1,0)/Z(1,1)) = Φ(θ_N(β))、§4.5
（「β → ∞ で ΔF_N/β → S_N」）。ここで S = `Smin N M` = inf_ω Σ_B (1 − z_B Re U_B)（背景 (1,1)）は
対称な箱に限らない全ての N, M ≥ 1 の、(1,1) の区画の大域の最小の欠け（`TwistBlocks.SN` とは別の量）。
* `Z_le_exp`：β ≥ 0 で Z(a,b) ≤ e^{β|P|}。
* `Z_ge_vol`：β ≥ 0 で Z(a,b) ≥ e^{βc}·μ{ω : c < Σ z Re U}。その集合が空でなければ体積は正。
* `phi_theta_eq`：Φ(θ) = ln(Z(1,0)/Z(1,1))。
* `tendsto_logratio_div`：ln(Z(1,0)/Z(1,1))/β → S。
-/

open MeasureTheory Filter Topology TwistedWilson

namespace ThetaLimit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem Z_le_exp (a b : Bool) (β : ℝ) (hβ : 0 ≤ β) : ZW N M β a b ≤ Real.exp (β * nP N M) := by
  have hpt : ∀ ω, Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re) ≤ Real.exp (β * nP N M) := by
    intro ω
    apply Real.exp_le_exp.mpr
    apply mul_le_mul_of_nonneg_left _ hβ
    calc ∑ B, zt N M a b B * (hol N M ω B).re ≤ ∑ _B : Plaq N M, (1 : ℝ) :=
          Finset.sum_le_sum fun B _ => TwistFlat.term_le_one N M a b ω B
      _ = nP N M := by rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one]
  unfold ZW
  calc _ ≤ ∫ _ω, Real.exp (β * nP N M) ∂(haarCfg N M) :=
        integral_mono (integrable_ZW N M β a b) (integrable_const _) hpt
    _ = _ := by simp

/-- 上の水準集合の体積 -/
noncomputable def volAt (a b : Bool) (c : ℝ) : ℝ :=
  (haarCfg N M).real {ω | c < ∑ B, zt N M a b B * (hol N M ω B).re}

theorem volAt_pos (a b : Bool) (c : ℝ) (ω0 : Link N M → SU2)
    (h : c < ∑ B, zt N M a b B * (hol N M ω0 B).re) : 0 < volAt N M a b c := by
  haveI := haarCfg_openPos N M
  unfold volAt
  rw [measureReal_def]
  exact ENNReal.toReal_pos
    ((isOpen_lt continuous_const (TwistFlat.continuous_action N M a b)).measure_pos (haarCfg N M)
      ⟨ω0, h⟩).ne' (measure_ne_top _ _)

theorem Z_ge_vol (a b : Bool) (c β : ℝ) (hβ : 0 ≤ β) :
    Real.exp (β * c) * volAt N M a b c ≤ ZW N M β a b := by
  unfold ZW volAt
  have hint := integrable_ZW N M β a b
  have hU : IsOpen {ω : Link N M → SU2 | c < ∑ B, zt N M a b B * (hol N M ω B).re} :=
    isOpen_lt continuous_const (TwistFlat.continuous_action N M a b)
  calc _ ≤ ∫ ω in {ω : Link N M → SU2 | c < ∑ B, zt N M a b B * (hol N M ω B).re},
          Real.exp (β * ∑ B, zt N M a b B * (hol N M ω B).re) ∂(haarCfg N M) :=
        setIntegral_ge_of_const_le_real hU.measurableSet (measure_ne_top _ _)
          (fun ω hω => Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left (le_of_lt hω) hβ))
          hint.integrableOn
    _ ≤ _ := setIntegral_le_integral hint (Eventually.of_forall fun ω => (Real.exp_pos _).le)

/-- 最小の欠けは達せられる：ある ω⋆ で作用が |P| − S -/
theorem exists_action_eq : ∃ ωs : Link N M → SU2,
    ∑ B, zt N M true true B * (hol N M ωs B).re = nP N M - Smin N M := by
  obtain ⟨ωs, -, hmin⟩ := TwistFlat.defect11_floor N M
  have hbdd : BddBelow (Set.range (TwistFlat.defect11 N M)) :=
    ⟨_, by rintro _ ⟨ω, rfl⟩; exact hmin ω⟩
  have hS : Smin N M = TwistFlat.defect11 N M ωs :=
    le_antisymm (ciInf_le hbdd ωs) (le_ciInf hmin)
  refine ⟨ωs, ?_⟩
  rw [hS, TwistFlat.defect11_eq]; ring

/-- Φ(θ) = ln(Z(1,0)/Z(1,1)) -/
theorem phi_theta_eq (β : ℝ) :
    Real.log ((1 + TwistBlocks.thetaM N M β) / (1 - TwistBlocks.thetaM N M β))
      = Real.log (ZW N M β true false / ZW N M β true true) := by
  have h0 := ZW_pos N M β true false
  have h1 := ZW_pos N M β true true
  congr 1
  unfold TwistBlocks.thetaM
  set Z0 := ZW N M β true false
  set Z1 := ZW N M β true true
  have hs : Z0 + Z1 ≠ 0 := by linarith
  have e1 : 1 + (Z0 - Z1) / (Z0 + Z1) = 2 * Z0 / (Z0 + Z1) := by
    rw [eq_div_iff hs, add_mul, div_mul_cancel₀ _ hs]; ring
  have e2 : 1 - (Z0 - Z1) / (Z0 + Z1) = 2 * Z1 / (Z0 + Z1) := by
    rw [eq_div_iff hs, sub_mul, div_mul_cancel₀ _ hs]; ring
  rw [e1, e2, div_div_div_cancel_right₀ hs, mul_div_mul_left _ _ two_ne_zero]

/-- **ln(Z(1,0)/Z(1,1))/β → S（β → ∞）** -/
theorem tendsto_logratio_div :
    Tendsto (fun β => Real.log (ZW N M β true false / ZW N M β true true) / β) atTop
      (𝓝 (Smin N M)) := by
  rw [Metric.tendsto_atTop]
  intro ε hε
  set δ := ε / 3 with hδ
  have hδpos : 0 < δ := by rw [hδ]; positivity
  -- 体積の定数
  set v0 := volAt N M true false (nP N M - δ)
  set v1 := volAt N M true true (nP N M - Smin N M - δ)
  have hv0 : 0 < v0 := volAt_pos N M true false _ (TwistBlocks.vac N M) (by
    rw [action_vac]; linarith)
  obtain ⟨ωs, hωs⟩ := exists_action_eq N M
  have hv1 : 0 < v1 := volAt_pos N M true true _ ωs (by rw [hωs]; linarith)
  set C := |Real.log v0| + |Real.log v1| + 1
  have hC : 0 < C := by positivity
  refine ⟨max 1 (C / δ), fun β hβ => ?_⟩
  have hβ1 : 1 ≤ β := le_trans (le_max_left _ _) hβ
  have hβpos : 0 < β := by linarith
  have hβC : C / δ ≤ β := le_trans (le_max_right _ _) hβ
  have hCβ : C ≤ δ * β := by rwa [div_le_iff₀ hδpos, mul_comm] at hβC
  have h0 := ZW_pos N M β true false
  have h1 := ZW_pos N M β true true
  -- 四つの評価
  have u0 := Z_le_exp N M true false β hβpos.le
  have u1 := Z11_le N M β hβpos.le
  have l0 := Z_ge_vol N M true false (nP N M - δ) β hβpos.le
  have l1 := Z_ge_vol N M true true (nP N M - Smin N M - δ) β hβpos.le
  have lu0 : Real.log (ZW N M β true false) ≤ β * nP N M := by
    rw [← Real.log_exp (β * nP N M)]; exact Real.log_le_log h0 u0
  have lu1 : Real.log (ZW N M β true true) ≤ β * (nP N M - Smin N M) := by
    rw [← Real.log_exp (β * (nP N M - Smin N M))]; exact Real.log_le_log h1 u1
  have ll0 : β * (nP N M - δ) + Real.log v0 ≤ Real.log (ZW N M β true false) := by
    rw [← Real.log_exp (β * (nP N M - δ)), ← Real.log_mul (Real.exp_pos _).ne' hv0.ne']
    exact Real.log_le_log (mul_pos (Real.exp_pos _) hv0) l0
  have ll1 : β * (nP N M - Smin N M - δ) + Real.log v1 ≤ Real.log (ZW N M β true true) := by
    rw [← Real.log_exp (β * (nP N M - Smin N M - δ)), ← Real.log_mul (Real.exp_pos _).ne' hv1.ne']
    exact Real.log_le_log (mul_pos (Real.exp_pos _) hv1) l1
  have hlog : Real.log (ZW N M β true false / ZW N M β true true)
      = Real.log (ZW N M β true false) - Real.log (ZW N M β true true) :=
    Real.log_div h0.ne' h1.ne'
  have a0 := neg_abs_le (Real.log v0)
  have a1 := neg_abs_le (Real.log v1)
  have b0 := le_abs_self (Real.log v0)
  have b1 := le_abs_self (Real.log v1)
  -- L − Sβ ∈ [−δβ − C, δβ + C]
  have hlo : (Smin N M - δ) * β - C ≤ Real.log (ZW N M β true false / ZW N M β true true) := by
    rw [hlog]; linarith
  have hhi : Real.log (ZW N M β true false / ZW N M β true true) ≤ (Smin N M + δ) * β + C := by
    rw [hlog]; linarith
  rw [Real.dist_eq, abs_lt]
  constructor
  · have hq : (Smin N M - 2 * δ) * β ≤ Real.log (ZW N M β true false / ZW N M β true true) := by
      linarith
    have : Smin N M - 2 * δ ≤ Real.log (ZW N M β true false / ZW N M β true true) / β := by
      rw [le_div_iff₀ hβpos]; exact hq
    linarith
  · have hq : Real.log (ZW N M β true false / ZW N M β true true) ≤ (Smin N M + 2 * δ) * β := by
      linarith
    have : Real.log (ZW N M β true false / ZW N M β true true) / β ≤ Smin N M + 2 * δ := by
      rw [div_le_iff₀ hβpos]; exact hq
    linarith

end ThetaLimit

#print axioms ThetaLimit.tendsto_logratio_div
#print axioms ThetaLimit.phi_theta_eq
