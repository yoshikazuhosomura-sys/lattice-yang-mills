import Tuning.ThetaLimitV2

/-!
# 右からの下の包絡 θ̲(β) := inf_{β′ ≥ β} θ(β′) と最大の解

紙：回避の候補 (a)。全ての N, M ≥ 1。
* `thetaLow_mono`：θ̲ は単調に増える。`thetaLow_le`：θ̲ ≤ θ。
* `above_max_sol`：β* が {β ≥ 0 : θ(β) = κ} の最大の元なら、β′ > β* で θ(β′) > κ（θ → 1 と中間値から）。
* `envelope_max_sol`：全ての κ ∈ [0, 1) で、θ の最大の解 β* について θ̲(β*) = κ、β > β* で θ̲(β) > κ。
  よって β* は {β ≥ 0 : θ̲(β) = κ} の最大の元でもある（θ が単調でなくても）。
-/

open Filter Topology TwistedWilson

namespace ThetaLimit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem theta_gt_neg_one (β : ℝ) : -1 < TwistBlocks.thetaM N M β := by
  unfold TwistBlocks.thetaM
  have h0 := ZW_pos N M β true false
  have h1 := ZW_pos N M β true true
  rw [lt_div_iff₀ (by linarith)]
  linarith

/-- 右からの下の包絡 -/
noncomputable def thetaLow (β : ℝ) : ℝ := ⨅ b : Set.Ici β, TwistBlocks.thetaM N M b

theorem bdd_low (β : ℝ) : BddBelow (Set.range fun b : Set.Ici β => TwistBlocks.thetaM N M b) :=
  ⟨-1, by rintro _ ⟨b, rfl⟩; exact (theta_gt_neg_one N M b).le⟩

theorem thetaLow_le (β : ℝ) : thetaLow N M β ≤ TwistBlocks.thetaM N M β :=
  ciInf_le (bdd_low N M β) ⟨β, Set.mem_Ici.mpr le_rfl⟩

theorem thetaLow_mono : Monotone (thetaLow N M) := by
  intro β₁ β₂ h
  haveI : Nonempty (Set.Ici β₂) := ⟨⟨β₂, Set.mem_Ici.mpr le_rfl⟩⟩
  refine le_ciInf fun b => ?_
  exact ciInf_le (bdd_low N M β₁) ⟨b, Set.mem_Ici.mpr (le_trans h b.2)⟩

/-- 最大の解より右では θ > κ -/
theorem above_max_sol (κ : ℝ) (h1 : κ < 1) (βs : ℝ)
    (hmax : ∀ β, 0 ≤ β → TwistBlocks.thetaM N M β = κ → β ≤ βs) (hβs : 0 ≤ βs)
    (β : ℝ) (hβ : βs < β) : κ < TwistBlocks.thetaM N M β := by
  by_contra hle
  push_neg at hle
  obtain ⟨b0, -, hgt⟩ := exists_theta_gt N M κ h1
  set b1 := max b0 β
  have hb1 : κ < TwistBlocks.thetaM N M b1 := hgt b1 (le_max_left _ _)
  have hc : ContinuousOn (fun b => TwistBlocks.thetaM N M b) (Set.Icc β b1) :=
    (ThetaTuning.thetaM_continuous N M).continuousOn
  obtain ⟨γ, hγ, hγe⟩ := intermediate_value_Icc (le_max_right b0 β) hc ⟨hle, hb1.le⟩
  have := hmax γ (by linarith [hγ.1]) hγe
  linarith [hγ.1]

/-- 最大の解より右では θ̲ > κ（下限が真に κ を越える） -/
theorem thetaLow_gt (κ : ℝ) (h1 : κ < 1) (βs : ℝ)
    (hmax : ∀ β, 0 ≤ β → TwistBlocks.thetaM N M β = κ → β ≤ βs) (hβs : 0 ≤ βs)
    (β : ℝ) (hβ : βs < β) : κ < thetaLow N M β := by
  have hk2 : (1 + κ) / 2 < 1 := by linarith
  obtain ⟨b0, -, hgt⟩ := exists_theta_gt N M ((1 + κ) / 2) hk2
  set b1 := max b0 β
  obtain ⟨m, hm, hmin⟩ := isCompact_Icc.exists_isMinOn
    (Set.nonempty_Icc.mpr (le_max_right b0 β))
    (ThetaTuning.thetaM_continuous N M).continuousOn
  have hmk : κ < TwistBlocks.thetaM N M m :=
    above_max_sol N M κ h1 βs hmax hβs m (lt_of_lt_of_le hβ hm.1)
  set c := min (TwistBlocks.thetaM N M m) ((1 + κ) / 2)
  have hc : κ < c := lt_min hmk (by linarith)
  haveI : Nonempty (Set.Ici β) := ⟨⟨β, Set.mem_Ici.mpr le_rfl⟩⟩
  refine lt_of_lt_of_le hc (le_ciInf fun b => ?_)
  by_cases hb : (b : ℝ) ≤ b1
  · exact (min_le_left _ _).trans (hmin ⟨b.2, hb⟩)
  · exact (min_le_right _ _).trans (hgt b (le_trans (le_max_left _ _) (le_of_not_ge hb))).le

/-- **包絡と最大の解**：全ての κ ∈ [0,1) で、θ の最大の解 β* について θ̲(β*) = κ、
β > β* で θ̲(β) > κ。よって β* は {β ≥ 0 : θ̲(β) = κ} の最大の元 -/
theorem envelope_max_sol (κ : ℝ) (h0 : 0 ≤ κ) (h1 : κ < 1) :
    ∃ βs : ℝ, 0 ≤ βs ∧ TwistBlocks.thetaM N M βs = κ ∧
      (∀ β, 0 ≤ β → TwistBlocks.thetaM N M β = κ → β ≤ βs) ∧
      thetaLow N M βs = κ ∧ (∀ β, βs < β → κ < thetaLow N M β) ∧
      (∀ β, 0 ≤ β → thetaLow N M β = κ → β ≤ βs) := by
  obtain ⟨βs, hβs, hθ, hmax⟩ := tuning_all N M κ h0 h1
  have hgt := thetaLow_gt N M κ h1 βs hmax hβs
  have hlow : thetaLow N M βs = κ := by
    refine le_antisymm (hθ ▸ thetaLow_le N M βs) ?_
    haveI : Nonempty (Set.Ici βs) := ⟨⟨βs, Set.mem_Ici.mpr le_rfl⟩⟩
    refine le_ciInf fun b => ?_
    rcases eq_or_lt_of_le (Set.mem_Ici.mp b.2) with h | h
    · rw [← h, hθ]
    · exact (above_max_sol N M κ h1 βs hmax hβs b h).le
  refine ⟨βs, hβs, hθ, hmax, hlow, hgt, fun β _ hβe => ?_⟩
  by_contra hlt
  push_neg at hlt
  have := hgt β hlt
  rw [hβe] at this
  exact lt_irrefl _ this

end ThetaLimit

#print axioms ThetaLimit.envelope_max_sol
#print axioms ThetaLimit.thetaLow_mono
