import Covering.IneqV10

/-!
# 二次元のトーラス (ℤ/M)² の Z₂ のゲージ理論：捩れた分配関数の閉じた式

紙： の段取り 4。高温展開
`Σ_t Π_y (cosh c_y + χ_y(t) sinh c_y) = Σ_{A ⊆ 面} (Π_{y∈A} sinh c_y)(Π_{y∉A} cosh c_y) Σ_t Π_{y∈A} χ_y(t)`
で、`Σ_t Π_{y∈A} χ_y(t)` が消えないのは `A = ∅` と `A = 全体` だけ（どのリンクも二枚の面の辺で、
面の隣接は連結）。

約束：
* 点 `y ∈ ZMod M × ZMod M`、リンク `(y, d)`、`d ∈ Fin 2`（`d = 0` が第一の向き、`d = 1` が第二の向き）。
* 面 `y` の指標 `χ_y(t) = t(y,0) · t(y+e₁,1) · t(y+e₂,0) · t(y,1)`（四本の積、重複は重複のまま数える。
  `M = 1` でも同じ定義で、そのときは `χ ≡ 1`）。
* 分配関数は `CoveringInequality.Z`：`Z χ c = Σ_t exp(Σ_y c_y χ_y(t))`。

主な結果：
* `Z_plane`：`Z χ c = |配位| · (Π_y cosh c_y + Π_y sinh c_y)`（任意の結合 `c`、任意の `M ≥ 1`）。
* `Z_plane_const`・`Z_plane_flip`：一様な結合 `L` と、面 `0` だけ符号を変えた結合。
* `plane_flip_ratio`：`Z(捩れ)/Z = (1 − tanh L ^ M²)/(1 + tanh L ^ M²)`。
-/

open Finset BigOperators CoveringInequality

namespace TwistedPlane

variable (M : ℕ) [NeZero M]

/-- 二次元の点 -/
abbrev Pt := ZMod M × ZMod M
/-- 二次元のリンク -/
abbrev Lk2 := Pt M × Fin 2
/-- Z₂ の配位（リンクの符号） -/
abbrev Cfg2 := Lk2 M → ℤˣ

/-- 第一・第二の向きの単位 -/
def e1 : Pt M := (1, 0)
def e2 : Pt M := (0, 1)

/-- 面 `y` の指標（四本のリンクの符号の積） -/
noncomputable def chi2 : Pt M → Cfg2 M → ℝ := fun y t =>
  sgn (t (y, 0)) * sgn (t (y + e1 M, 1)) * sgn (t (y + e2 M, 0)) * sgn (t (y, 1))

theorem sgn_mul' (a b : ℤˣ) : sgn (a * b) = sgn a * sgn b := sgn_isSignChar.1 a b

theorem sgn_sq (a : ℤˣ) : sgn a * sgn a = 1 := by
  rcases sgn_isSignChar.2 a with h | h <;> rw [h] <;> norm_num

theorem chi2_isSignChar (y : Pt M) : IsSignChar (chi2 M y) := by
  refine ⟨fun g h => ?_, fun g => ?_⟩
  · simp only [chi2, Pi.mul_apply, sgn_mul']
    ring
  · simp only [chi2]
    rcases sgn_isSignChar.2 (g (y, 0)) with h1 | h1 <;>
    rcases sgn_isSignChar.2 (g (y + e1 M, 1)) with h2 | h2 <;>
    rcases sgn_isSignChar.2 (g (y + e2 M, 0)) with h3 | h3 <;>
    rcases sgn_isSignChar.2 (g (y, 1)) with h4 | h4 <;>
    rw [h1, h2, h3, h4] <;> norm_num

/-- 全ての面の指標の積は 1（どのリンクもちょうど二回現れる）。 -/
theorem prod_chi2_univ (t : Cfg2 M) : ∏ y, chi2 M y t = 1 := by
  simp only [chi2, Finset.prod_mul_distrib]
  have s1 : ∏ y : Pt M, sgn (t (y + e1 M, 1)) = ∏ y : Pt M, sgn (t (y, 1)) :=
    Fintype.prod_equiv (Equiv.addRight (e1 M)) _ _ (fun _ => rfl)
  have s2 : ∏ y : Pt M, sgn (t (y + e2 M, 0)) = ∏ y : Pt M, sgn (t (y, 0)) :=
    Fintype.prod_equiv (Equiv.addRight (e2 M)) _ _ (fun _ => rfl)
  have q : ∀ d : Fin 2, (∏ y : Pt M, sgn (t (y, d))) * ∏ y : Pt M, sgn (t (y, d)) = 1 := by
    intro d
    rw [← Finset.prod_mul_distrib]
    simp [sgn_sq]
  rw [s1, s2, show ∀ a b : ℝ, a * b * a * b = (a * a) * (b * b) from fun a b => by ring,
    q 0, q 1, one_mul]

/-- 符号を一本だけ変える配位 -/
def flipAt (ℓ : Lk2 M) : Cfg2 M := Pi.mulSingle ℓ (-1)

theorem sgn_flipAt (ℓ ℓ' : Lk2 M) : sgn (flipAt M ℓ ℓ') = if ℓ' = ℓ then -1 else 1 := by
  unfold flipAt
  rw [Pi.mulSingle_apply]
  split_ifs <;> simp [sgn]

/-- 符号を一本変えると、和が 0 になる（`F(t·u) = −F(t)` なら `Σ F = 0`）。 -/
theorem sum_eq_zero_of_antisym (F : Cfg2 M → ℝ) (u : Cfg2 M) (h : ∀ t, F (t * u) = -F t) :
    ∑ t, F t = 0 := by
  have e : ∑ t, F (t * u) = ∑ t, F t :=
    Fintype.sum_equiv (Equiv.mulRight u) _ _ (fun _ => rfl)
  simp only [h, Finset.sum_neg_distrib] at e
  linarith

/-- 第一の向きのリンク `(y₀, 0)` を変えたときの、面 `y` の指標の変わり方。 -/
theorem chi2_flip0 (y0 y : Pt M) (t : Cfg2 M) :
    chi2 M y (t * flipAt M (y0, 0))
      = (if y = y0 then -1 else 1) * (if y = y0 - e2 M then -1 else 1) * chi2 M y t := by
  have hm := (chi2_isSignChar M y).1 t (flipAt M (y0, 0))
  rw [hm]
  have hu : chi2 M y (flipAt M (y0, 0))
      = (if y = y0 then -1 else 1) * (if y = y0 - e2 M then -1 else 1) := by
    have h10 : (1 : Fin 2) ≠ 0 := by decide
    simp only [chi2, sgn_flipAt, Prod.mk.injEq, and_true, h10, and_false,
      if_false, mul_one, eq_sub_iff_add_eq]
  rw [hu]; ring

/-- 第二の向きのリンク `(y₀, 1)` を変えたときの、面 `y` の指標の変わり方。 -/
theorem chi2_flip1 (y0 y : Pt M) (t : Cfg2 M) :
    chi2 M y (t * flipAt M (y0, 1))
      = (if y = y0 - e1 M then -1 else 1) * (if y = y0 then -1 else 1) * chi2 M y t := by
  have hm := (chi2_isSignChar M y).1 t (flipAt M (y0, 1))
  rw [hm]
  have hu : chi2 M y (flipAt M (y0, 1))
      = (if y = y0 - e1 M then -1 else 1) * (if y = y0 then -1 else 1) := by
    have h01 : (0 : Fin 2) ≠ 1 := by decide
    simp only [chi2, sgn_flipAt, Prod.mk.injEq, and_true, h01, and_false,
      if_false, one_mul, mul_one, eq_sub_iff_add_eq]
  rw [hu]; ring

theorem prod_sign_ite (A : Finset (Pt M)) (a : Pt M) :
    ∏ y ∈ A, (if y = a then (-1 : ℝ) else 1) = if a ∈ A then -1 else 1 :=
  Finset.prod_ite_eq' A a (fun _ => (-1 : ℝ))

/-- 面の集合 `A` の上の指標の積。 -/
noncomputable def FA (A : Finset (Pt M)) (t : Cfg2 M) : ℝ := ∏ y ∈ A, chi2 M y t

theorem FA_flip0 (A : Finset (Pt M)) (y0 : Pt M) (t : Cfg2 M) :
    FA M A (t * flipAt M (y0, 0))
      = (if y0 ∈ A then -1 else 1) * (if y0 - e2 M ∈ A then -1 else 1) * FA M A t := by
  unfold FA
  simp only [chi2_flip0, Finset.prod_mul_distrib, prod_sign_ite]

theorem FA_flip1 (A : Finset (Pt M)) (y0 : Pt M) (t : Cfg2 M) :
    FA M A (t * flipAt M (y0, 1))
      = (if y0 - e1 M ∈ A then -1 else 1) * (if y0 ∈ A then -1 else 1) * FA M A t := by
  unfold FA
  simp only [chi2_flip1, Finset.prod_mul_distrib, prod_sign_ite]

theorem sign_mismatch (p q : Prop) [Decidable p] [Decidable q] (h : ¬ (p ↔ q)) :
    ((if p then (-1 : ℝ) else 1) * (if q then -1 else 1)) = -1 := by
  by_cases hp : p <;> by_cases hq : q <;> simp_all

/-- 二つの向きのずらしで閉じた面の集合は、空か全体。 -/
theorem closed_empty_or_univ (A : Finset (Pt M))
    (h1 : ∀ y, y ∈ A ↔ y - e1 M ∈ A) (h2 : ∀ y, y ∈ A ↔ y - e2 M ∈ A) :
    A = ∅ ∨ A = Finset.univ := by
  by_cases hA : A = ∅
  · exact Or.inl hA
  right
  obtain ⟨y, hy⟩ := Finset.nonempty_iff_ne_empty.mpr hA
  have k1 : ∀ n : ℕ, ∀ z, z ∈ A → z - ((n : ZMod M), (0 : ZMod M)) ∈ A := by
    intro n
    induction n with
    | zero =>
      intro z hz
      convert hz using 1
      ext <;> simp
    | succ n ih =>
      intro z hz
      have h := (h1 (z - ((n : ZMod M), (0 : ZMod M)))).mp (ih z hz)
      have e : z - ((n : ZMod M), (0 : ZMod M)) - e1 M = z - (((n + 1 : ℕ) : ZMod M), (0 : ZMod M)) := by
        simp only [e1, Nat.cast_succ]
        ext <;> simp only [Prod.fst_sub, Prod.snd_sub] <;> ring
      rwa [e] at h
  have k2 : ∀ n : ℕ, ∀ z, z ∈ A → z - ((0 : ZMod M), (n : ZMod M)) ∈ A := by
    intro n
    induction n with
    | zero =>
      intro z hz
      convert hz using 1
      ext <;> simp
    | succ n ih =>
      intro z hz
      have h := (h2 (z - ((0 : ZMod M), (n : ZMod M)))).mp (ih z hz)
      have e : z - ((0 : ZMod M), (n : ZMod M)) - e2 M = z - ((0 : ZMod M), ((n + 1 : ℕ) : ZMod M)) := by
        simp only [e2, Nat.cast_succ]
        ext <;> simp only [Prod.fst_sub, Prod.snd_sub] <;> ring
      rwa [e] at h
  rw [Finset.eq_univ_iff_forall]
  intro z
  have hz := k2 (y - z).2.val _ (k1 (y - z).1.val y hy)
  have e : y - (((y - z).1.val : ZMod M), (0 : ZMod M)) - ((0 : ZMod M), ((y - z).2.val : ZMod M)) = z := by
    simp only [ZMod.natCast_zmod_val]
    ext <;> simp only [Prod.fst_sub, Prod.snd_sub] <;> ring
  rwa [e] at hz

/-- `A` が空でも全体でもなければ、`Σ_t Π_{y∈A} χ_y(t) = 0`。 -/
theorem sum_FA_eq_zero (A : Finset (Pt M)) (hA : ¬ (A = ∅ ∨ A = Finset.univ)) :
    ∑ t, FA M A t = 0 := by
  by_contra hne
  apply hA
  refine closed_empty_or_univ M A (fun y => ?_) (fun y => ?_)
  · by_contra hm
    -- 向き 1 のリンク (y, 1) を変える：符号 (y - e1 ∈ A) と (y ∈ A)
    have hm' : ¬ (y - e1 M ∈ A ↔ y ∈ A) := fun h => hm h.symm
    exact hne (sum_eq_zero_of_antisym M (FA M A) (flipAt M (y, 1)) (fun t => by
      rw [FA_flip1, sign_mismatch _ _ hm']; ring))
  · by_contra hm
    exact hne (sum_eq_zero_of_antisym M (FA M A) (flipAt M (y, 0)) (fun t => by
      rw [FA_flip0, sign_mismatch _ _ hm]; ring))

/-- **高温展開の閉じた式**：任意の結合 `c` で `Z χ c = |配位| · (Π cosh c_y + Π sinh c_y)`。 -/
theorem Z_plane (c : Pt M → ℝ) :
    Z (chi2 M) c = (Fintype.card (Cfg2 M) : ℝ)
      * (∏ y, Real.cosh (c y) + ∏ y, Real.sinh (c y)) := by
  have hexp : ∀ t : Cfg2 M, Real.exp (∑ y, c y * chi2 M y t)
      = ∑ A ∈ (Finset.univ : Finset (Pt M)).powerset,
          (∏ y ∈ A, Real.sinh (c y)) * (∏ y ∈ Finset.univ \ A, Real.cosh (c y)) * FA M A t := by
    intro t
    rw [Real.exp_sum]
    have h1 : ∀ y, Real.exp (c y * chi2 M y t)
        = chi2 M y t * Real.sinh (c y) + Real.cosh (c y) := by
      intro y
      rw [exp_mul_sign (c y) (chi2 M y t) ((chi2_isSignChar M y).2 t)]; ring
    simp only [h1]
    rw [Finset.prod_add]
    refine Finset.sum_congr rfl fun A _ => ?_
    unfold FA
    rw [Finset.prod_mul_distrib]
    ring
  unfold Z
  simp only [hexp]
  rw [Finset.sum_comm]
  have hterm : ∀ A ∈ (Finset.univ : Finset (Pt M)).powerset,
      ∑ t : Cfg2 M, (∏ y ∈ A, Real.sinh (c y)) * (∏ y ∈ Finset.univ \ A, Real.cosh (c y)) * FA M A t
        = (∏ y ∈ A, Real.sinh (c y)) * (∏ y ∈ Finset.univ \ A, Real.cosh (c y))
          * ∑ t : Cfg2 M, FA M A t := by
    intro A _
    rw [Finset.mul_sum]
  rw [Finset.sum_congr rfl hterm]
  have hne : (∅ : Finset (Pt M)) ≠ Finset.univ := by
    intro h
    have : (0 : Pt M) ∈ (∅ : Finset (Pt M)) := h ▸ Finset.mem_univ _
    simp at this
  rw [Finset.sum_eq_add_of_mem ∅ Finset.univ (Finset.empty_mem_powerset _)
    (Finset.mem_powerset_self _) hne (fun A _ hA => by
      rw [sum_FA_eq_zero M A (fun h => h.elim hA.1 hA.2), mul_zero])]
  have f0 : ∀ t, FA M ∅ t = 1 := fun t => by simp [FA]
  have f1 : ∀ t, FA M Finset.univ t = 1 := fun t => prod_chi2_univ M t
  simp only [f0, f1, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one,
    Finset.prod_empty, one_mul, Finset.sdiff_empty, Finset.sdiff_self]
  ring

theorem card_Pt : Fintype.card (Pt M) = M ^ 2 := by
  simp [Pt, Fintype.card_prod, ZMod.card, sq]

theorem Z_plane_const (L : ℝ) :
    Z (chi2 M) (fun _ => L) = (Fintype.card (Cfg2 M) : ℝ)
      * (Real.cosh L ^ (M ^ 2) + Real.sinh L ^ (M ^ 2)) := by
  rw [Z_plane]
  simp only [Finset.prod_const, Finset.card_univ, card_Pt]

/-- 面 `0` の符号だけを変えた結合（捩れ）。 -/
noncomputable def flipC (L : ℝ) : Pt M → ℝ := fun y => (if y = 0 then -1 else 1) * L

theorem Z_plane_flip (L : ℝ) :
    Z (chi2 M) (flipC M L) = (Fintype.card (Cfg2 M) : ℝ)
      * (Real.cosh L ^ (M ^ 2) - Real.sinh L ^ (M ^ 2)) := by
  have hc : ∀ y : Pt M, Real.cosh (flipC M L y) = Real.cosh L := by
    intro y; unfold flipC; split_ifs <;> simp
  have hs : ∀ y : Pt M, Real.sinh (flipC M L y) = (if y = 0 then -1 else 1) * Real.sinh L := by
    intro y; unfold flipC; split_ifs <;> simp
  rw [Z_plane]
  simp only [hc, hs, Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ, card_Pt,
    prod_sign_ite, Finset.mem_univ, if_true]
  ring

/-- **二次元の Z₂ のゲージ理論の捩れた比**：`Z(捩れ)/Z = (1 − tanh L ^ M²)/(1 + tanh L ^ M²)`。 -/
theorem plane_flip_ratio (L : ℝ) :
    Z (chi2 M) (flipC M L) / Z (chi2 M) (fun _ => L)
      = (1 - Real.tanh L ^ (M ^ 2)) / (1 + Real.tanh L ^ (M ^ 2)) := by
  have hC : 0 < Real.cosh L := Real.cosh_pos L
  have hCn : 0 < Real.cosh L ^ (M ^ 2) := pow_pos hC _
  have hW : (0 : ℝ) < Fintype.card (Cfg2 M) := Nat.cast_pos.mpr Fintype.card_pos
  have hT : Real.tanh L ^ (M ^ 2) = Real.sinh L ^ (M ^ 2) / Real.cosh L ^ (M ^ 2) := by
    rw [Real.tanh_eq_sinh_div_cosh, div_pow]
  rw [Z_plane_flip, Z_plane_const, hT, mul_div_mul_left _ _ hW.ne', one_sub_div hCn.ne',
    one_add_div hCn.ne', div_div_div_cancel_right₀ hCn.ne']

end TwistedPlane

#print axioms TwistedPlane.prod_chi2_univ
#print axioms TwistedPlane.closed_empty_or_univ
#print axioms TwistedPlane.sum_FA_eq_zero
#print axioms TwistedPlane.Z_plane
#print axioms TwistedPlane.Z_plane_const
#print axioms TwistedPlane.Z_plane_flip
#print axioms TwistedPlane.plane_flip_ratio
