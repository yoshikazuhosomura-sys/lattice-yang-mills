import Box.FermionBaseV8a

/-! # file B, version b: the Wilson–fermion measure in the box chain (`chain_end_to_end_box`)

Paper side: The box chain takes, at fine level `n`, a probability measure on the
ball-valued configurations of the box `(ℤ/2ⁿL′)⁴` (`Cfg (BoxLk L′ n)`), the concrete block map `blockMap`
(retraction after the six-order average of the induction's walk), `νP n m := (μ n).map (down n m)`.
Its field `hcons` is discharged by construction (`hcons_blockMap`). Here:

* the box parameter is `L′ = 2L` and the fine lattice of this column at level `n` is `PhysLink (2h) h`, `h = 2ⁿL`
  (isotropic, time `2h = 2ⁿ·2L`); `pullBox` is `pull` followed by the transport
  `castCfg` along `2·(2ⁿL) = 2ⁿ·(2L)`;
* `fermProbBox`: the push-forward by `pullBox` of the normalised Wilson–fermion measure `wfProb`
  (density `exp(−β S_W) Re det D^{2j}`, bare mass `mseq n`, inverse coupling `βseq n`);
* `refl_pullBox`: `reflCfg ∘ pullBox = pullBox ∘ thetaPhys` (the two reflections agree);
* `hcomm_box`, `hν_box`, `stripSet_dependsOn_posSide`: the fields `hcomm`, `hν` of this column's chain
  (`chain_end_to_end_tuned`) and the physical-support condition, for `V n m := down n m ∘ pullBox`, `Θ m := reflCfg`;
* `fermion_hΘp`: the field `hΘp` of the box chain for the fermion family (`m > −1` at every level);
* **`chain_end_to_end_box_fermion`**: the `chain_end_to_end_box` with `μ := fermProbBox`, `Θ := reflCfg`,
  `Aset m := stripSet (c m)`, `hΘc`, `hΘp` discharged. The other fields stay. -/

namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config FineSupportReflection

/-! ## 1. transport of configurations along an equality of torus sizes -/

/-- the link map `Lk b → Lk a` for `a = b` (the identity after `subst`) -/
def castLk {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) : TorusRP.Lk b → TorusRP.Lk a := by
  subst e; exact id

/-- configurations on `Lk a` as configurations on `Lk b` -/
def castCfg {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) (U : TorusRP.Lk a → TorusRP.QBall) :
    TorusRP.Lk b → TorusRP.QBall :=
  fun ℓ => U (castLk e ℓ)

theorem measurable_castCfg {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) : Measurable (castCfg e) :=
  measurable_pi_lambda _ fun ℓ => measurable_pi_apply _

theorem castCfg_linkRefl {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) (U : TorusRP.Lk a → TorusRP.QBall) :
    castCfg e (LinkReflection.linkRefl (TorusRP.thL a) (TorusRP.sig a) U)
      = LinkReflection.linkRefl (TorusRP.thL b) (TorusRP.sig b) (castCfg e U) := by
  subst e; rfl

theorem castLk_halfSlab {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) (ℓ : TorusRP.Lk b)
    (hℓ : ℓ.1 0 ∈ TorusRP.halfSlabT b) : (castLk e ℓ).1 0 ∈ TorusRP.halfSlabT a := by
  subst e; exact hℓ

/-! ## 2. the fine lattice of level `n` inside the box `(ℤ/2ⁿ·2L)⁴` -/

variable (L : ℕ) [NeZero L]

instance twoL_neZero : NeZero (2 * L) := ⟨by have := NeZero.ne L; omega⟩

instance twoh_neZero (n : ℕ) : NeZero (2 * (2 ^ n * L)) :=
  ⟨by have := NeZero.ne L; positivity⟩

theorem size_eq (n : ℕ) : 2 * (2 ^ n * L) = 2 ^ n * (2 * L) := by ring

theorem h_pos (n : ℕ) : 0 < 2 ^ n * L := by have := NeZero.ne L; positivity

/-- this column's configuration at level `n` as a ball-valued configuration of the box -/
noncomputable def pullBox (n : ℕ) (ω : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) : Cfg (BoxLk (2 * L) n) :=
  castCfg (size_eq L n) (pull (2 ^ n * L) ω)

theorem measurable_pullBox (n : ℕ) : Measurable (pullBox L n) :=
  (measurable_castCfg (size_eq L n)).comp (measurable_pull (2 ^ n * L))

/-- **the reflections agree**: `reflCfg ∘ pullBox = pullBox ∘ thetaPhys` -/
theorem refl_pullBox (n : ℕ) (ω : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) :
    reflCfg (2 * L) n (pullBox L n ω) = pullBox L n (thetaPhys ω) := by
  rw [reflCfg_eq_linkRefl]
  have h1 := castCfg_linkRefl (size_eq L n) (pull (2 ^ n * L) ω)
  have h2 : LinkReflection.linkRefl (TorusRP.thL (2 * (2 ^ n * L))) (TorusRP.sig (2 * (2 ^ n * L)))
      (pull (2 ^ n * L) ω) = pull (2 ^ n * L) (thetaPhys ω) :=
    funext fun ℓ => Subtype.ext (refl_pull (2 ^ n * L) ω ℓ)
  rw [h2] at h1
  exact h1.symm

/-- the half-slab links of the box come from links of this column's positive side -/
theorem pullBox_halfSlab (n : ℕ) (ω ω' : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2)
    (heq : ∀ l ∈ posSide (2 * (2 ^ n * L)) (2 ^ n * L), ω l = ω' l)
    (ℓ : BoxLk (2 * L) n) (hℓ : ℓ.1 0 ∈ halfSlab (2 * L) n) :
    pullBox L n ω ℓ = pullBox L n ω' ℓ := by
  have hc : (castLk (size_eq L n) ℓ).1 0 ∈ TorusRP.halfSlabT (2 * (2 ^ n * L)) :=
    castLk_halfSlab (size_eq L n) ℓ hℓ
  have hfp := TorusRP.halfSlab_closed (2 * (2 ^ n * L)) (2 ^ n * L) rfl _ hc
  have hmem := toPhys_mem_posSide (2 ^ n * L) (h_pos L n) _ hfp
  show pull (2 ^ n * L) ω (castLk (size_eq L n) ℓ) = pull (2 ^ n * L) ω' (castLk (size_eq L n) ℓ)
  simp only [pull]
  rw [heq _ hmem]

/-! ## 3. the fermion family on the box and its reflection positivity -/

/-- the normalised Wilson–fermion measure of level `n` as a probability measure -/
noncomputable def wfProbM (n j : ℕ) (m β : ℝ) :
    ProbabilityMeasure (PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) :=
  ⟨wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j m β,
    wfProb_isProbability (2 * (2 ^ n * L)) (2 ^ n * L) (h_pos L n) j m β⟩

/-- **the fermion family of the box chain**: `μ n = (wfProb at level n).map pullBox` -/
noncomputable def fermProbBox (j : ℕ) (mseq βseq : ℕ → ℝ) (n : ℕ) : ProbabilityMeasure (Cfg (BoxLk (2 * L) n)) :=
  (wfProbM L n j (mseq n) (βseq n)).map (measurable_pullBox L n).aemeasurable

theorem fermProbBox_toMeasure (j : ℕ) (mseq βseq : ℕ → ℝ) (n : ℕ) :
    (fermProbBox L j mseq βseq n : Measure (Cfg (BoxLk (2 * L) n)))
      = (wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n)).map (pullBox L n) := by
  rw [fermProbBox, ProbabilityMeasure.toMeasure_map]
  rfl

/-- fine reflection positivity of the push-forward, on the half-slab class of `reflection_positive_down_slab_bdd` -/
theorem fermion_rp_box (n j : ℕ) (m : ℝ) (hm : -1 < m) (β : ℝ) :
    ∀ f ∈ {f : Cfg (BoxLk (2 * L) n) → ℝ | Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
        ∃ φ : ({ℓ : BoxLk (2 * L) n // ℓ.1 0 ∈ halfSlab (2 * L) n} → Ball) → ℝ, ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (reflCfg (2 * L) n ω) * f ω
        ∂((wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j m β).map (pullBox L n)) := by
  rintro f ⟨hf, ⟨C, hC⟩, φ, hφ⟩
  have hRm : Measurable (reflCfg (2 * L) n) := (continuous_reflCfg (2 * L) n).measurable
  have hmeas : Measurable fun ω : Cfg (BoxLk (2 * L) n) => f (reflCfg (2 * L) n ω) * f ω := (hf.comp hRm).mul hf
  rw [integral_map (measurable_pullBox L n).aemeasurable hmeas.aestronglyMeasurable]
  simp only [refl_pullBox]
  refine fineRP_wilson_fermion_prob (2 * (2 ^ n * L)) (2 ^ n * L) (h_pos L n) j m hm β
    (fun ω => f (pullBox L n ω)) (hf.comp (measurable_pullBox L n)) ⟨C, fun ω => hC _⟩ ?_
  intro ω ω' heq
  show f (pullBox L n ω) = f (pullBox L n ω')
  rw [hφ, hφ]
  congr 1
  funext ℓ
  exact pullBox_halfSlab L n ω ω' heq ℓ.1 ℓ.2

/-- **the field `hΘp` of the box chain for the fermion family** (bare masses `> −1`, any couplings, any widths) -/
theorem fermion_hΘp {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (hm : ∀ n, -1 < mseq n) (c : ℕ → ℕ) :
    ∀ m, ∀ᶠ n in atTop, ∀ F ∈ stripSet (2 * L) (c m) m,
      0 ≤ ∫ ω, F (reflCfg (2 * L) m ω) * F ω
        ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) := by
  intro m
  filter_upwards [eventually_ge_atTop m] with n hn
  rintro F ⟨hc, hFpos⟩
  rw [νP, ProbabilityMeasure.toMeasure_map, fermProbBox_toMeasure]
  exact reflection_positive_down_slab_bdd (2 * L) hr n m hn (c m) hc _
    (fermion_rp_box L n j (mseq n) (hm n) (βseq n)) F F.continuous.measurable
    ⟨‖F‖, fun e => by simpa [Real.norm_eq_abs] using F.norm_coe_le_norm e⟩ hFpos

/-! ## 4. the fields `hcomm`, `hν` of this column's chain for `V n m := down n m ∘ pullBox` -/

/-- `hcomm` of `chain_end_to_end_tuned` with `V n m = down n m ∘ pullBox`, `Θf = thetaPhys`, `Θ m = reflCfg` -/
theorem hcomm_box {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n)
    (ω : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) :
    down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n (thetaPhys ω))
      = reflCfg (2 * L) m (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n ω)) := by
  rw [← refl_pullBox]
  exact down_refl (2 * L) hr n (n - m) m (by omega) _

/-- `hν` of `chain_end_to_end_tuned`: the block measures are the push-forwards of the fine measure by `V n m` -/
theorem hν_box {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (n m : ℕ) :
    (νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
      = (wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n)).map
          (fun ω => down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n ω)) := by
  rw [νP, ProbabilityMeasure.toMeasure_map, fermProbBox_toMeasure,
    Measure.map_map (continuous_down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m).measurable
      (measurable_pullBox L n)]
  rfl

/-- the physical-support form: a coarse strip function, pulled back by `V n m`, is determined on `posSide`
(so `stripSet ⊆ physPositive V posSide` at every level `n ≥ m`) -/
theorem stripSet_dependsOn_posSide {r₀ : ℝ} (hr : 0 < r₀) (c n m : ℕ) (hmn : m ≤ n)
    (F : Cfg (BoxLk (2 * L) m) → ℝ) (hc : 2 * c + 6 ≤ 2 ^ m * (2 * L))
    (hFpos : ∃ φ : ({ℓ : BoxLk (2 * L) m // ℓ.1 0 ∈ strip (2 * L) m c} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    DependsOn (posSide (2 * (2 ^ n * L)) (2 ^ n * L))
      (fun ω => F (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n ω))) := by
  obtain ⟨ψ, hψ⟩ := down_strip_local (2 * L) hr n m hmn c hc F hFpos
  intro ω ω' heq
  show F (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n ω))
    = F (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (pullBox L n ω'))
  rw [hψ, hψ]
  congr 1
  funext ℓ
  exact pullBox_halfSlab L n ω ω' heq ℓ.1 ℓ.2

/-! ## 5. the box chain with the fermion family -/

/-- **Theorem W (box chain) for the Wilson–fermion family.** `chain_end_to_end_box` at
`L′ = 2L`, `μ := fermProbBox L j mseq βseq`, `Θ := reflCfg`, `Aset m := stripSet (c m) m`; the fields `hΘc`
(`continuous_reflCfg`) and `hΘp` (`fermion_hΘp`) are discharged, `hcons` is discharged inside the chain
(`hcons_blockMap`).  New hypothesis: `−1 < mseq n` for every `n`.  The other fields (`HE`, `rarity`,
`hsym`, `hpos`, `HR`, …) stay. -/
theorem chain_end_to_end_box_fermion {r₀ : ℝ} (hr : 0 < r₀) {X : Type*} [MetricSpace X]
    (j : ℕ) (mseq βseq : ℕ → ℝ) (hm : ∀ n, -1 < mseq n) (c : ℕ → ℕ) :
    type_of% (@chain_end_to_end_box (2 * L) _ r₀ hr X _ (fermProbBox L j mseq βseq)
      (Θ := reflCfg (2 * L)) (Aset := fun m => stripSet (2 * L) (c m) m)
      (hΘc := continuous_reflCfg (2 * L)) (hΘp := fermion_hΘp L hr j mseq βseq hm c)) :=
  @chain_end_to_end_box (2 * L) _ r₀ hr X _ (fermProbBox L j mseq βseq)
    (Θ := reflCfg (2 * L)) (Aset := fun m => stripSet (2 * L) (c m) m)
    (hΘc := continuous_reflCfg (2 * L)) (hΘp := fermion_hΘp L hr j mseq βseq hm c)

/-- the class `Aset m` is not empty once `2c + 6 ≤ 2ᵐ·2L` (constant width `c`) -/
theorem fermion_Aset_nonempty (c m : ℕ) (hc : 2 * c + 6 ≤ 2 ^ m * (2 * L)) :
    (stripSet (2 * L) c m).Nonempty := by
  obtain ⟨F, hF, -⟩ := stripSet_witness (2 * L) c m hc
  exact ⟨F, hF⟩

end BoxFermion

#print axioms BoxFermion.refl_pullBox
#print axioms BoxFermion.fermion_rp_box
#print axioms BoxFermion.fermion_hΘp
#print axioms BoxFermion.hcomm_box
#print axioms BoxFermion.hν_box
#print axioms BoxFermion.stripSet_dependsOn_posSide
#print axioms BoxFermion.chain_end_to_end_box_fermion
#print axioms BoxFermion.fermion_Aset_nonempty
