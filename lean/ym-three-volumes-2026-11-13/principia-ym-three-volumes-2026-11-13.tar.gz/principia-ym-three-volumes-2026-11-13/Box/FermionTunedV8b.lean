import Box.FermionChainV8b

/-! # file F, version b: the box chain for the fermion family at the two-parameter tuned points

Paper side: The box chain (`chain_end_to_end_box_fermion`) takes free sequences of bare
masses `mseq` and couplings `βseq`.  This column's chain tuned both bare parameters with the two-parameter lemma
(W0') (`FermionChain.tuning_of_steps`, `Tuned`).  `Chain.ChainFermionV7` cannot be imported next to
`Chain.BoxWilsonV2` (both contain copies of `WeakUltravioletExistence` …), so its namespaces `FermionTuning` and the
first part of `FermionChain` (`CouplingMassSteps`, `tuning_of_steps`, `model_steps`, `Tuned`, `tuned_nonempty`),
which use nothing from the chain copies, are copied verbatim here (ChainFermionV7 lines 2052–2788 and 2906–2922).
New: `chain_end_to_end_box_fermion_two_param` — there are tuned bare points `p_n = (x_n, y_n)` (after `n` steps the
effective coupling is `t` and the effective mass `m̄`), the bare masses are in the reflection-positivity range
`y_n > −1` (mass window `Mq < 1`), and the box chain applies to the fermion family with bare mass `y_n` and
`β_n = 4 x_n`. -/

namespace FermionTuning

open Set Filter Topology

/-- **(W0') Two-parameter tuning.**  Inside the domain
`{p | ∀ j ≤ k, u⋆ ≤ u j p ∧ |m j p| ≤ M}` we assume
(S) `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2`,
(M) `|m_{k+1} − λ m_k| ≤ ε |m_k| + s` with `1 + ε < λ` and `s < (λ − 1 − ε) M`,
(C) continuity of `u_{k+1}` and `m_{k+1}`,
(E) `y ↦ m_{k+1}(x, y)` strictly increasing.
Then for a target coupling `t ≥ u⋆`, a target mass `|m̄| ≤ M` and a number of steps `n` there is a bare point
`p = (x, y)` with `u_n p = t`, `m_n p = m̄`, staying in the domain at all intermediate steps, and with the
one-loop type sandwich `t + (b/2) n ≤ x ≤ t + (3b/2) n`. -/
theorem exists_bare_coupling_and_mass (u m : ℕ → ℝ × ℝ → ℝ)
    (b ustar t M lam ε s mbar : ℝ) (n : ℕ)
    (hb : 0 < b) (hε : 0 ≤ ε) (hs : 0 ≤ s) (hlam : 1 + ε < lam) (hgap : s < (lam - 1 - ε) * M)
    (hu0 : ∀ p, u 0 p = p.1) (hm0 : ∀ p, m 0 p = p.2)
    (hS : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M) →
      u k p - 3 * b / 2 ≤ u (k + 1) p ∧ u (k + 1) p ≤ u k p - b / 2)
    (hM : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M) →
      |m (k + 1) p - lam * m k p| ≤ ε * |m k p| + s)
    (hCu : ∀ k, ContinuousOn (u (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M})
    (hCm : ∀ k, ContinuousOn (m (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M})
    (hE : ∀ k x y y', (∀ j ≤ k, ustar ≤ u j (x, y) ∧ |m j (x, y)| ≤ M) →
      (∀ j ≤ k, ustar ≤ u j (x, y') ∧ |m j (x, y')| ≤ M) → y < y' →
      m (k + 1) (x, y) < m (k + 1) (x, y'))
    (ht : ustar ≤ t) (hmbar : |mbar| ≤ M) :
    ∃ p : ℝ × ℝ, t + b / 2 * n ≤ p.1 ∧ p.1 ≤ t + 3 * b / 2 * n ∧ u n p = t ∧ m n p = mbar ∧
      ∀ k ≤ n, t ≤ u k p ∧ |m k p| ≤ M := by
  have hlam0 : 0 < lam := by linarith
  have hMpos : 0 < M := by
    by_contra h
    push_neg at h
    have h1 : 0 ≤ lam - 1 - ε := by linarith
    have h2 := mul_nonneg h1 (neg_nonneg.mpr h)
    nlinarith
  -- upper sandwich for the coupling (inside the domain)
  have hdrop : ∀ p, ∀ k, (∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M) → u k p ≤ p.1 - b / 2 * k := by
    intro p k
    induction k with
    | zero => intro _; simp [hu0]
    | succ k ih =>
      intro hd
      have hd' : ∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M := fun j hj => hd j (by omega)
      have i1 := ih hd'
      have s2 := (hS k p hd').2
      push_cast
      linarith
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    refine ⟨(t, mbar), by simp, by simp, hu0 _, hm0 _, ?_⟩
    intro k hk
    have hk0 : k = 0 := by omega
    subst hk0
    rw [hu0, hm0]
    exact ⟨le_rfl, hmbar⟩
  obtain ⟨n', rfl⟩ : ∃ n', n = n' + 1 := ⟨n - 1, by omega⟩
  set a : ℝ := t + 3 * b / 2 * ((n' + 1 : ℕ) : ℝ) with ha
  have hta : t ≤ a := by
    have : (0 : ℝ) ≤ 3 * b / 2 * ((n' + 1 : ℕ) : ℝ) := by positivity
    linarith
  -- Step A: on the line x = a the coupling conditions are automatic; nested intervals in y
  have hA : ∀ k ≤ n' + 1, ∃ p q : ℝ, p ≤ q ∧
      (∀ y ∈ Icc p q, ∀ j ≤ k,
        t + 3 * b / 2 * (((n' + 1 : ℕ) : ℝ) - j) ≤ u j (a, y) ∧ |m j (a, y)| ≤ M) ∧
      (∀ c ∈ Icc (-M) M, ∃ y ∈ Icc p q, m k (a, y) = c) := by
    intro k
    induction k with
    | zero =>
      intro _
      refine ⟨-M, M, by linarith, ?_, ?_⟩
      · intro y hy j hj
        have hj0 : j = 0 := by omega
        subst hj0
        rw [hu0, hm0]
        refine ⟨?_, abs_le.mpr ⟨hy.1, hy.2⟩⟩
        simp [ha]
      · intro c hc
        exact ⟨c, hc, hm0 _⟩
    | succ k ih =>
      intro hk
      obtain ⟨p, q, hpq, hin, hsurj⟩ := ih (by omega)
      have hdom : ∀ y ∈ Icc p q, ∀ j ≤ k, ustar ≤ u j (a, y) ∧ |m j (a, y)| ≤ M := by
        intro y hy j hj
        obtain ⟨h1, h2⟩ := hin y hy j hj
        refine ⟨?_, h2⟩
        have hjn : (j : ℝ) ≤ ((n' + 1 : ℕ) : ℝ) := by exact_mod_cast (show j ≤ n' + 1 by omega)
        have h3 : (0 : ℝ) ≤ 3 * b / 2 * (((n' + 1 : ℕ) : ℝ) - j) := by
          apply mul_nonneg
          · positivity
          · linarith
        linarith
      have hgc : ContinuousOn (fun y : ℝ => m (k + 1) (a, y)) (Icc p q) := by
        have hc1 : ContinuousOn (fun y : ℝ => ((a, y) : ℝ × ℝ)) (Icc p q) :=
          (continuous_const.prodMk continuous_id).continuousOn
        exact (hCm k).comp hc1 (fun y hy => hdom y hy)
      obtain ⟨yl, hyl, hyl'⟩ := hsurj (-M) ⟨le_rfl, by linarith⟩
      obtain ⟨yr, hyr, hyr'⟩ := hsurj M ⟨by linarith, le_rfl⟩
      have hgl : m (k + 1) (a, yl) < -M := by
        have h := hM k (a, yl) (hdom yl hyl)
        rw [hyl'] at h
        have h' := (abs_le.mp h).2
        rw [abs_neg, abs_of_pos hMpos] at h'
        nlinarith
      have hgr : M < m (k + 1) (a, yr) := by
        have h := hM k (a, yr) (hdom yr hyr)
        rw [hyr'] at h
        have h' := (abs_le.mp h).1
        rw [abs_of_pos hMpos] at h'
        nlinarith
      have hsub : uIcc yl yr ⊆ Icc p q := uIcc_subset_Icc hyl hyr
      have hivt := intermediate_value_uIcc (hgc.mono hsub)
      obtain ⟨p', hp', hp'v⟩ := hivt (show -M ∈ uIcc (m (k + 1) (a, yl)) (m (k + 1) (a, yr)) from
        mem_uIcc.mpr (Or.inl ⟨hgl.le, by linarith⟩))
      obtain ⟨q', hq', hq'v⟩ := hivt (show M ∈ uIcc (m (k + 1) (a, yl)) (m (k + 1) (a, yr)) from
        mem_uIcc.mpr (Or.inl ⟨by linarith, hgr.le⟩))
      have hp'I : p' ∈ Icc p q := hsub hp'
      have hq'I : q' ∈ Icc p q := hsub hq'
      have hp'v' : m (k + 1) (a, p') = -M := hp'v
      have hq'v' : m (k + 1) (a, q') = M := hq'v
      have hlt : p' < q' := by
        by_contra hcon
        push_neg at hcon
        rcases eq_or_lt_of_le hcon with h | h
        · rw [h] at hq'v'
          linarith
        · have := hE k a q' p' (hdom q' hq'I) (hdom p' hp'I) h
          linarith
      refine ⟨p', q', hlt.le, ?_, ?_⟩
      · intro y hy j hj
        have hyI : y ∈ Icc p q := ⟨le_trans hp'I.1 hy.1, le_trans hy.2 hq'I.2⟩
        rcases Nat.lt_or_ge j (k + 1) with hlt' | hge
        · exact hin y hyI j (by omega)
        · have hj' : j = k + 1 := by omega
          subst hj'
          constructor
          · have h1 := (hin y hyI k le_rfl).1
            have h2 := (hS k (a, y) (hdom y hyI)).1
            push_cast at h1 ⊢
            linarith
          · have hlo : m (k + 1) (a, p') ≤ m (k + 1) (a, y) := by
              rcases eq_or_lt_of_le hy.1 with h | h
              · rw [h]
              · exact (hE k a p' y (hdom p' hp'I) (hdom y hyI) h).le
            have hhi : m (k + 1) (a, y) ≤ m (k + 1) (a, q') := by
              rcases eq_or_lt_of_le hy.2 with h | h
              · rw [h]
              · exact (hE k a y q' (hdom y hyI) (hdom q' hq'I) h).le
            rw [abs_le]
            constructor <;> linarith
      · intro c hc
        have hgc' : ContinuousOn (fun y : ℝ => m (k + 1) (a, y)) (Icc p' q') :=
          hgc.mono (fun y hy => ⟨le_trans hp'I.1 hy.1, le_trans hy.2 hq'I.2⟩)
        have hivt2 := intermediate_value_Icc hlt.le hgc'
        obtain ⟨y, hy, hyv⟩ := hivt2
          (show c ∈ Icc (m (k + 1) (a, p')) (m (k + 1) (a, q')) from by
            rw [hp'v', hq'v']; exact hc)
        exact ⟨y, hy, hyv⟩
  obtain ⟨pA, qA, hpqA, hinA, hsurjA⟩ := hA (n' + 1) le_rfl
  obtain ⟨y0, hy0, hy0v⟩ := hsurjA mbar (abs_le.mp hmbar)
  -- Step B: the closed set of admissible bare points
  let K' : ℕ → Set (ℝ × ℝ) := fun k =>
    {p | p.1 ∈ Icc t a ∧ p.2 ∈ Icc (-M) M ∧ ∀ j ≤ k, t ≤ u j p ∧ |m j p| ≤ M}
  have hK'dom : ∀ k p, p ∈ K' k → ∀ j ≤ k, ustar ≤ u j p ∧ |m j p| ≤ M :=
    fun k p hp j hj => ⟨le_trans ht (hp.2.2 j hj).1, (hp.2.2 j hj).2⟩
  have hK'closed : ∀ k, IsClosed (K' k) := by
    intro k
    induction k with
    | zero =>
      have h0 : K' 0 = (Prod.fst ⁻¹' Icc t a) ∩ (Prod.snd ⁻¹' Icc (-M) M) := by
        ext p
        constructor
        · intro h
          exact ⟨h.1, h.2.1⟩
        · intro h
          refine ⟨h.1, h.2, fun j hj => ?_⟩
          have hj0 : j = 0 := by omega
          subst hj0
          rw [hu0, hm0]
          exact ⟨h.1.1, abs_le.mpr ⟨h.2.1, h.2.2⟩⟩
      rw [h0]
      exact (isClosed_Icc.preimage continuous_fst).inter (isClosed_Icc.preimage continuous_snd)
    | succ k ih =>
      have hcu : ContinuousOn (u (k + 1)) (K' k) := (hCu k).mono (fun p hp => hK'dom k p hp)
      have hcm : ContinuousOn (m (k + 1)) (K' k) := (hCm k).mono (fun p hp => hK'dom k p hp)
      have hset : K' (k + 1) =
          (K' k ∩ u (k + 1) ⁻¹' Ici t) ∩ (K' k ∩ m (k + 1) ⁻¹' Icc (-M) M) := by
        ext p
        constructor
        · intro h
          have h4 := h.2.2 (k + 1) le_rfl
          have hk' : p ∈ K' k := ⟨h.1, h.2.1, fun j hj => h.2.2 j (by omega)⟩
          exact ⟨⟨hk', h4.1⟩, ⟨hk', abs_le.mp h4.2⟩⟩
        · intro h
          obtain ⟨⟨hk', h4⟩, ⟨_, h5⟩⟩ := h
          refine ⟨hk'.1, hk'.2.1, fun j hj => ?_⟩
          rcases Nat.lt_or_ge j (k + 1) with hlt | hge
          · exact hk'.2.2 j (by omega)
          · have hj' : j = k + 1 := by omega
            subst hj'
            exact ⟨h4, abs_le.mpr h5⟩
      rw [hset]
      exact (hcu.preimage_isClosed_of_isClosed ih isClosed_Ici).inter
        (hcm.preimage_isClosed_of_isClosed ih isClosed_Icc)
  let K : Set (ℝ × ℝ) := K' (n' + 1) ∩ m (n' + 1) ⁻¹' {mbar}
  have hKclosed : IsClosed K :=
    ((hCm n').mono (fun p hp j hj => hK'dom (n' + 1) p hp j (by omega))).preimage_isClosed_of_isClosed
      (hK'closed (n' + 1)) isClosed_singleton
  have hKcompact : IsCompact K :=
    (isCompact_Icc.prod isCompact_Icc : IsCompact (Icc t a ×ˢ Icc (-M) M)).of_isClosed_subset hKclosed
      (fun p hp => Set.mem_prod.mpr ⟨hp.1.1, hp.1.2.1⟩)
  have hKne : K.Nonempty := by
    refine ⟨(a, y0), ⟨⟨hta, le_rfl⟩, ?_, ?_⟩, hy0v⟩
    · have h := (hinA y0 hy0 0 (Nat.zero_le _)).2
      rw [hm0] at h
      exact abs_le.mp h
    · intro j hj
      obtain ⟨h1, h2⟩ := hinA y0 hy0 j hj
      refine ⟨?_, h2⟩
      have hjn : (j : ℝ) ≤ ((n' + 1 : ℕ) : ℝ) := by exact_mod_cast hj
      have h3 : (0 : ℝ) ≤ 3 * b / 2 * (((n' + 1 : ℕ) : ℝ) - j) := by
        apply mul_nonneg
        · positivity
        · linarith
      linarith
  obtain ⟨p0, hp0K, hp0min⟩ := hKcompact.exists_isMinOn hKne continuous_fst.continuousOn
  have hmin : ∀ q ∈ K, p0.1 ≤ q.1 := isMinOn_iff.mp hp0min
  have hp0dom : ∀ j ≤ n' + 1, ustar ≤ u j p0 ∧ |m j p0| ≤ M := hK'dom (n' + 1) p0 hp0K.1
  have hp0m : m (n' + 1) p0 = mbar := hp0K.2
  -- Step C: at the leftmost admissible point the coupling hits the target
  have hus : u (n' + 1) p0 = t := by
    by_contra hne'
    have hgt : t < u (n' + 1) p0 := lt_of_le_of_ne (hp0K.1.2.2 (n' + 1) le_rfl).1 (Ne.symm hne')
    have d1 := hdrop p0 (n' + 1) hp0dom
    have hnpos : (0 : ℝ) < b / 2 * ((n' + 1 : ℕ) : ℝ) := by positivity
    have hst : t < p0.1 := by linarith
    -- the coupling is strictly above the target at every step
    have hall : ∀ k ≤ n' + 1, t < u k p0 := by
      intro k hk
      have mono : ∀ i, k + i ≤ n' + 1 → u (k + i) p0 ≤ u k p0 := by
        intro i
        induction i with
        | zero => intro _; simp
        | succ i ih =>
          intro hi
          have h1 := ih (by omega)
          have h2 := (hS (k + i) p0 (fun j hj => hp0dom j (by omega))).2
          rw [← Nat.add_assoc]
          linarith
      have h := mono (n' + 1 - k) (by omega)
      rw [Nat.add_sub_cancel' hk] at h
      linarith
    -- the mass is strictly inside the window at every step before the last
    have hmlt : ∀ j ≤ n', |m j p0| < M := by
      intro j hj
      have h1 := hM j p0 (fun i hi => hp0dom i (by omega))
      have h2 := (hp0dom (j + 1) (by omega)).2
      have h3 : lam * |m j p0| ≤ |m (j + 1) p0| + |m (j + 1) p0 - lam * m j p0| := by
        have e1 : lam * |m j p0| = |lam * m j p0| := by rw [abs_mul, abs_of_pos hlam0]
        have e2 : |lam * m j p0| ≤ |m (j + 1) p0| + |m (j + 1) p0 - lam * m j p0| := by
          have h := abs_sub (m (j + 1) p0) (m (j + 1) p0 - lam * m j p0)
          rwa [sub_sub_cancel] at h
        linarith
      by_contra hcon
      push_neg at hcon
      have h4 := (hp0dom j (by omega)).2
      have h5 : |m j p0| = M := le_antisymm h4 hcon
      rw [h5] at h1 h3
      nlinarith
    -- openness of the strict conditions up to step n'
    have hopen : ∀ k ≤ n', ∃ δ > 0, ∀ p, dist p p0 < δ → ∀ j ≤ k, t < u j p ∧ |m j p| < M := by
      intro k
      induction k with
      | zero =>
        intro _
        have hm0lt := hmlt 0 (Nat.zero_le _)
        rw [hm0] at hm0lt
        refine ⟨min (p0.1 - t) (M - |p0.2|), lt_min (by linarith) (by linarith),
          fun p hp j hj => ?_⟩
        have hj0 : j = 0 := by omega
        subst hj0
        rw [hu0, hm0]
        have hd1 : dist p.1 p0.1 < p0.1 - t := by
          have h := le_max_left (dist p.1 p0.1) (dist p.2 p0.2)
          rw [← Prod.dist_eq] at h
          exact lt_of_le_of_lt h (lt_of_lt_of_le hp (min_le_left _ _))
        have hd2 : dist p.2 p0.2 < M - |p0.2| := by
          have h := le_max_right (dist p.1 p0.1) (dist p.2 p0.2)
          rw [← Prod.dist_eq] at h
          exact lt_of_le_of_lt h (lt_of_lt_of_le hp (min_le_right _ _))
        rw [Real.dist_eq] at hd1 hd2
        have hd1a := (abs_lt.mp hd1).1
        have hd2a := abs_sub_abs_le_abs_sub p.2 p0.2
        constructor <;> linarith
      | succ k ih =>
        intro hk
        obtain ⟨δ, hδ, hδp⟩ := ih (by omega)
        have hdom0 : ∀ j ≤ k, ustar ≤ u j p0 ∧ |m j p0| ≤ M := fun j hj => hp0dom j (by omega)
        have hcu := hCu k p0 hdom0
        have hcm := hCm k p0 hdom0
        rw [Metric.continuousWithinAt_iff] at hcu hcm
        obtain ⟨δ1, hδ1, hδ1p⟩ := hcu (u (k + 1) p0 - t) (by linarith [hall (k + 1) (by omega)])
        obtain ⟨δ2, hδ2, hδ2p⟩ := hcm (M - |m (k + 1) p0|) (by linarith [hmlt (k + 1) hk])
        refine ⟨min δ (min δ1 δ2), lt_min hδ (lt_min hδ1 hδ2), fun p hp j hj => ?_⟩
        have hp1 : dist p p0 < δ := lt_of_lt_of_le hp (min_le_left _ _)
        have hp2 : dist p p0 < δ1 :=
          lt_of_lt_of_le hp (le_trans (min_le_right _ _) (min_le_left _ _))
        have hp3 : dist p p0 < δ2 :=
          lt_of_lt_of_le hp (le_trans (min_le_right _ _) (min_le_right _ _))
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact hδp p hp1 j (by omega)
        · have hj' : j = k + 1 := by omega
          subst hj'
          have hpdom : ∀ i ≤ k, ustar ≤ u i p ∧ |m i p| ≤ M := fun i hi =>
            ⟨le_trans ht (hδp p hp1 i hi).1.le, (hδp p hp1 i hi).2.le⟩
          have h1 := hδ1p hpdom hp2
          have h2 := hδ2p hpdom hp3
          rw [Real.dist_eq] at h1 h2
          have h1a := (abs_lt.mp h1).1
          have h2a := abs_sub_abs_le_abs_sub (m (k + 1) p) (m (k + 1) p0)
          constructor <;> linarith
    obtain ⟨δ, hδ, hδp⟩ := hopen n' le_rfl
    have hcu := hCu n' p0 (fun j hj => hp0dom j (by omega))
    rw [Metric.continuousWithinAt_iff] at hcu
    obtain ⟨δu, hδu, hδup⟩ := hcu (u (n' + 1) p0 - t) (by linarith)
    obtain ⟨δ', hδ'pos, hδ'1, hδ'2⟩ : ∃ δ' > 0, δ' ≤ δ ∧ δ' ≤ δu :=
      ⟨min δ δu, lt_min hδ hδu, min_le_left _ _, min_le_right _ _⟩
    have hball : ∀ p, dist p p0 < δ' → ∀ j ≤ n', ustar ≤ u j p ∧ |m j p| ≤ M :=
      fun p hp j hj => ⟨le_trans ht (hδp p (lt_of_lt_of_le hp hδ'1) j hj).1.le,
        (hδp p (lt_of_lt_of_le hp hδ'1) j hj).2.le⟩
    have hugt : ∀ p, dist p p0 < δ' → t < u (n' + 1) p := by
      intro p hp
      have h1 := hδup (hball p hp) (lt_of_lt_of_le hp hδ'2)
      rw [Real.dist_eq] at h1
      have h1a := (abs_lt.mp h1).1
      linarith
    obtain ⟨η, hηpos, hηlt⟩ : ∃ η > 0, η < δ' := ⟨δ' / 2, by linarith, by linarith⟩
    have hdist : ∀ x y : ℝ, |x - p0.1| ≤ η → |y - p0.2| ≤ η → dist ((x, y) : ℝ × ℝ) p0 < δ' := by
      intro x y hx hy
      rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
      exact lt_of_le_of_lt (max_le hx hy) hηlt
    have hp0eta : ((p0.1, p0.2) : ℝ × ℝ) = p0 := Prod.mk.eta
    have hdom_mid : ∀ j ≤ n', ustar ≤ u j (p0.1, p0.2) ∧ |m j (p0.1, p0.2)| ≤ M := by
      rw [hp0eta]
      exact fun j hj => hp0dom j (by omega)
    have hdom_lo : ∀ j ≤ n', ustar ≤ u j (p0.1, p0.2 - η) ∧ |m j (p0.1, p0.2 - η)| ≤ M :=
      hball _ (hdist _ _ (by rw [abs_le]; constructor <;> linarith)
        (by rw [abs_le]; constructor <;> linarith))
    have hdom_hi : ∀ j ≤ n', ustar ≤ u j (p0.1, p0.2 + η) ∧ |m j (p0.1, p0.2 + η)| ≤ M :=
      hball _ (hdist _ _ (by rw [abs_le]; constructor <;> linarith)
        (by rw [abs_le]; constructor <;> linarith))
    have hlo : m (n' + 1) (p0.1, p0.2 - η) < mbar := by
      have h := hE n' p0.1 (p0.2 - η) p0.2 hdom_lo hdom_mid (by linarith)
      rw [hp0eta, hp0m] at h
      exact h
    have hhi : mbar < m (n' + 1) (p0.1, p0.2 + η) := by
      have h := hE n' p0.1 p0.2 (p0.2 + η) hdom_mid hdom_hi (by linarith)
      rw [hp0eta, hp0m] at h
      exact h
    have hcm_lo := hCm n' (p0.1, p0.2 - η) hdom_lo
    have hcm_hi := hCm n' (p0.1, p0.2 + η) hdom_hi
    rw [Metric.continuousWithinAt_iff] at hcm_lo hcm_hi
    obtain ⟨δl, hδl, hδlp⟩ := hcm_lo (mbar - m (n' + 1) (p0.1, p0.2 - η)) (by linarith)
    obtain ⟨δh, hδh, hδhp⟩ := hcm_hi (m (n' + 1) (p0.1, p0.2 + η) - mbar) (by linarith)
    obtain ⟨ρ, hρpos, hρη, hρl, hρh, hρt⟩ :
        ∃ ρ > 0, ρ ≤ η ∧ ρ < δl ∧ ρ < δh ∧ ρ < p0.1 - t := by
      refine ⟨min (min η (δl / 2)) (min (δh / 2) ((p0.1 - t) / 2)), ?_, ?_, ?_, ?_, ?_⟩
      · exact lt_min (lt_min hηpos (by linarith)) (lt_min (by linarith) (by linarith))
      · exact le_trans (min_le_left _ _) (min_le_left _ _)
      · exact lt_of_le_of_lt (le_trans (min_le_left _ _) (min_le_right _ _)) (by linarith)
      · exact lt_of_le_of_lt (le_trans (min_le_right _ _) (min_le_left _ _)) (by linarith)
      · exact lt_of_le_of_lt (le_trans (min_le_right _ _) (min_le_right _ _)) (by linarith)
    -- the vertical segment at x = p0.1 − ρ
    have hseg : ∀ y ∈ Icc (p0.2 - η) (p0.2 + η), dist ((p0.1 - ρ, y) : ℝ × ℝ) p0 < δ' := by
      intro y hy
      exact hdist _ _ (by rw [abs_le]; constructor <;> linarith)
        (by rw [abs_le]; constructor <;> linarith [hy.1, hy.2])
    have hηle : p0.2 - η ≤ p0.2 + η := by linarith
    have hxlo : m (n' + 1) (p0.1 - ρ, p0.2 - η) < mbar := by
      have hd : dist ((p0.1 - ρ, p0.2 - η) : ℝ × ℝ) (p0.1, p0.2 - η) < δl := by
        rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
        refine max_lt ?_ ?_
        · show |p0.1 - ρ - p0.1| < δl
          rw [abs_lt]; constructor <;> linarith
        · show |p0.2 - η - (p0.2 - η)| < δl
          rw [sub_self, abs_zero]; exact hδl
      have h := hδlp (hball _ (hseg _ (left_mem_Icc.mpr hηle))) hd
      rw [Real.dist_eq] at h
      have ha' := (abs_lt.mp h).2
      linarith
    have hxhi : mbar < m (n' + 1) (p0.1 - ρ, p0.2 + η) := by
      have hd : dist ((p0.1 - ρ, p0.2 + η) : ℝ × ℝ) (p0.1, p0.2 + η) < δh := by
        rw [Prod.dist_eq, Real.dist_eq, Real.dist_eq]
        refine max_lt ?_ ?_
        · show |p0.1 - ρ - p0.1| < δh
          rw [abs_lt]; constructor <;> linarith
        · show |p0.2 + η - (p0.2 + η)| < δh
          rw [sub_self, abs_zero]; exact hδh
      have h := hδhp (hball _ (hseg _ (right_mem_Icc.mpr hηle))) hd
      rw [Real.dist_eq] at h
      have ha' := (abs_lt.mp h).1
      linarith
    have hgc : ContinuousOn (fun y : ℝ => m (n' + 1) (p0.1 - ρ, y)) (Icc (p0.2 - η) (p0.2 + η)) := by
      have hc1 : ContinuousOn (fun y : ℝ => ((p0.1 - ρ, y) : ℝ × ℝ)) (Icc (p0.2 - η) (p0.2 + η)) :=
        (continuous_const.prodMk continuous_id).continuousOn
      exact (hCm n').comp hc1 (fun y hy => hball _ (hseg y hy))
    obtain ⟨y1, hy1, hy1v⟩ := intermediate_value_Icc hηle hgc
      (show mbar ∈ Icc (m (n' + 1) (p0.1 - ρ, p0.2 - η)) (m (n' + 1) (p0.1 - ρ, p0.2 + η)) from
        ⟨hxlo.le, hxhi.le⟩)
    have hy1v' : m (n' + 1) (p0.1 - ρ, y1) = mbar := hy1v
    have hq_ball := hseg y1 hy1
    have hq_strict := hδp (p0.1 - ρ, y1) (lt_of_lt_of_le hq_ball hδ'1)
    have hqK : ((p0.1 - ρ, y1) : ℝ × ℝ) ∈ K := by
      refine ⟨⟨⟨?_, ?_⟩, ?_, ?_⟩, hy1v'⟩
      · show t ≤ p0.1 - ρ
        linarith
      · show p0.1 - ρ ≤ a
        have := hp0K.1.1.2
        linarith
      · have h := (hq_strict 0 (Nat.zero_le _)).2
        rw [hm0] at h
        exact abs_le.mp h.le
      · intro j hj
        rcases Nat.lt_or_ge j (n' + 1) with hlt | hge
        · exact ⟨(hq_strict j (by omega)).1.le, (hq_strict j (by omega)).2.le⟩
        · have hj' : j = n' + 1 := by omega
          subst hj'
          refine ⟨(hugt _ hq_ball).le, ?_⟩
          rw [hy1v']
          exact hmbar
    have hcontra := hmin _ hqK
    have : p0.1 ≤ p0.1 - ρ := hcontra
    linarith
  refine ⟨p0, ?_, hp0K.1.1.2, hus, hp0m, fun k hk => hp0K.1.2.2 k hk⟩
  have d1 := hdrop p0 (n' + 1) hp0dom
  linarith

/-! ## A model satisfying every premise (non-vacuity) -/

/-- Model coupling flow: `u_k = x − k` (so `b = 1`). -/
noncomputable def uEx (k : ℕ) (p : ℝ × ℝ) : ℝ := p.1 - k

/-- Model mass flow with a coupling-dependent additive shift (the analogue of the additive mass renormalization
of Wilson fermions): `m_{k+1} = 2 m_k + (1/2)/(1 + u_k²)`. -/
noncomputable def mEx : ℕ → ℝ × ℝ → ℝ
  | 0, p => p.2
  | k + 1, p => 2 * mEx k p + (1 / 2) / (1 + (uEx k p) ^ 2)

theorem continuous_uEx (k : ℕ) : Continuous (uEx k) := by
  unfold uEx
  exact continuous_fst.sub continuous_const

theorem continuous_mEx (k : ℕ) : Continuous (mEx k) := by
  induction k with
  | zero => exact continuous_snd
  | succ k ih =>
    have h1 : Continuous (fun p : ℝ × ℝ => 1 + (uEx k p) ^ 2) :=
      continuous_const.add ((continuous_uEx k).pow 2)
    have h2 : Continuous (fun p : ℝ × ℝ => (1 / 2 : ℝ) / (1 + (uEx k p) ^ 2)) :=
      continuous_const.div h1 (fun p => by positivity)
    have h3 : mEx (k + 1) = fun p : ℝ × ℝ => 2 * mEx k p + (1 / 2) / (1 + (uEx k p) ^ 2) := by
      funext p; rfl
    rw [h3]
    exact (continuous_const.mul ih).add h2

theorem mEx_diff (k : ℕ) (x y y' : ℝ) : mEx k (x, y') - mEx k (x, y) = 2 ^ k * (y' - y) := by
  induction k with
  | zero => simp [mEx]
  | succ k ih =>
    have hu : uEx k (x, y') = uEx k (x, y) := rfl
    simp only [mEx, hu]
    rw [pow_succ]
    linear_combination 2 * ih

/-- Model: premise (M) with `λ = 2`, `ε = 0`, `s = 1/2`. -/
theorem mEx_step (k : ℕ) (p : ℝ × ℝ) : |mEx (k + 1) p - 2 * mEx k p| ≤ 0 * |mEx k p| + 1 / 2 := by
  have h1 : mEx (k + 1) p - 2 * mEx k p = (1 / 2) / (1 + (uEx k p) ^ 2) := by
    simp only [mEx]; ring
  rw [h1]
  have h2 : (0 : ℝ) ≤ (1 / 2) / (1 + (uEx k p) ^ 2) := by positivity
  have h3 : (1 / 2 : ℝ) / (1 + (uEx k p) ^ 2) ≤ 1 / 2 :=
    div_le_self (by norm_num) (by nlinarith [sq_nonneg (uEx k p)])
  rw [abs_of_nonneg h2]
  linarith

/-- Model: premise (E). -/
theorem mEx_strictMono (k : ℕ) (x y y' : ℝ) (hy : y < y') : mEx (k + 1) (x, y) < mEx (k + 1) (x, y') := by
  have h := mEx_diff (k + 1) x y y'
  have hpos : (0 : ℝ) < 2 ^ (k + 1) * (y' - y) := by
    apply mul_pos
    · positivity
    · linarith
  linarith

/-- The premises of `exists_bare_coupling_and_mass` hold for the model with
`b = 1`, `u⋆ = 1`, `M = 1`, `λ = 2`, `ε = 0`, `s = 1/2`; hence the conclusion holds for it. -/
theorem tuning_example (t mbar : ℝ) (n : ℕ) (ht : 1 ≤ t) (hmbar : |mbar| ≤ 1) :
    ∃ p : ℝ × ℝ, t + 1 / 2 * n ≤ p.1 ∧ p.1 ≤ t + 3 * 1 / 2 * n ∧ uEx n p = t ∧ mEx n p = mbar ∧
      ∀ k ≤ n, t ≤ uEx k p ∧ |mEx k p| ≤ 1 := by
  refine exists_bare_coupling_and_mass uEx mEx 1 1 t 1 2 0 (1 / 2) mbar n one_pos le_rfl
    (by norm_num) (by norm_num) (by norm_num) (fun p => by simp [uEx]) (fun p => by simp [mEx])
    ?_ ?_ ?_ ?_ ?_ ht hmbar
  · intro k p _
    simp only [uEx]
    push_cast
    constructor <;> linarith
  · intro k p _
    exact mEx_step k p
  · intro k
    exact (continuous_uEx (k + 1)).continuousOn
  · intro k
    exact (continuous_mEx (k + 1)).continuousOn
  · intro k x y y' _ _ hy
    exact mEx_strictMono k x y y' hy

/-! ## Premise (E) from one-step bounds: an invariant cone -/

/-- **Invariant cone.**  `w k p` collects every coordinate other than the mass (coupling, irrelevant part) in a
seminormed group; `Dc k` is the (nested) domain.  If on `Dc k`, for two bare points with the same `x` and `y ≤ y'`,
* `Δm_{k+1} ≥ λ Δm_k − κ₁ ‖Δw_k‖`  (the mass direction expands),
* `‖Δw_{k+1}‖ ≤ L ‖Δw_k‖ + κ₂ Δm_k` (the other directions are Lipschitz),
and the cone opening `θ` satisfies `L θ + κ₂ ≤ θ (λ − κ₁ θ)`, `λ − κ₁ θ > 0`, then the cone
`‖Δw‖ ≤ θ Δm` is invariant and `Δm_{k+1} ≥ (λ − κ₁ θ)^{k+1} (y' − y)`.  In particular premise (E) holds. -/
theorem mass_strictMono_of_cone {W : Type*} [SeminormedAddCommGroup W]
    (m : ℕ → ℝ × ℝ → ℝ) (w : ℕ → ℝ × ℝ → W) (Dc : ℕ → ℝ × ℝ → Prop)
    (lam κ₁ κ₂ L θ : ℝ) (hθ : 0 ≤ θ) (hκ₁ : 0 ≤ κ₁) (hL : 0 ≤ L)
    (hcone : L * θ + κ₂ ≤ θ * (lam - κ₁ * θ)) (hexp : 0 < lam - κ₁ * θ)
    (hm0 : ∀ p, m 0 p = p.2) (hw0 : ∀ x y y', w 0 (x, y) = w 0 (x, y'))
    (hDc : ∀ k p, Dc (k + 1) p → Dc k p)
    (hstepm : ∀ k x y y', Dc k (x, y) → Dc k (x, y') → y ≤ y' →
      lam * (m k (x, y') - m k (x, y)) - κ₁ * ‖w k (x, y') - w k (x, y)‖
        ≤ m (k + 1) (x, y') - m (k + 1) (x, y))
    (hstepw : ∀ k x y y', Dc k (x, y) → Dc k (x, y') → y ≤ y' →
      ‖w (k + 1) (x, y') - w (k + 1) (x, y)‖
        ≤ L * ‖w k (x, y') - w k (x, y)‖ + κ₂ * (m k (x, y') - m k (x, y))) :
    (∀ k x y y', Dc k (x, y) → Dc k (x, y') → y ≤ y' →
      ‖w (k + 1) (x, y') - w (k + 1) (x, y)‖ ≤ θ * (m (k + 1) (x, y') - m (k + 1) (x, y)) ∧
      (lam - κ₁ * θ) ^ (k + 1) * (y' - y) ≤ m (k + 1) (x, y') - m (k + 1) (x, y)) ∧
    (∀ k x y y', Dc k (x, y) → Dc k (x, y') → y < y' → m (k + 1) (x, y) < m (k + 1) (x, y')) := by
  have key : ∀ k x y y', Dc k (x, y) → Dc k (x, y') → y ≤ y' →
      ‖w (k + 1) (x, y') - w (k + 1) (x, y)‖ ≤ θ * (m (k + 1) (x, y') - m (k + 1) (x, y)) ∧
      (lam - κ₁ * θ) ^ (k + 1) * (y' - y) ≤ m (k + 1) (x, y') - m (k + 1) (x, y) := by
    intro k
    induction k with
    | zero =>
      intro x y y' h1 h2 hy
      have hm := hstepm 0 x y y' h1 h2 hy
      have hw := hstepw 0 x y y' h1 h2 hy
      have hw00 : ‖w 0 (x, y') - w 0 (x, y)‖ = 0 := by
        rw [hw0 x y' y, sub_self, norm_zero]
      rw [hw00] at hm hw
      rw [hm0, hm0] at hm hw
      have hd : (0 : ℝ) ≤ y' - y := by linarith
      simp only [mul_zero, sub_zero, zero_add] at hm hw
      have e1 : (0 : ℝ) ≤ κ₁ * θ * (y' - y) := mul_nonneg (mul_nonneg hκ₁ hθ) hd
      have e2 : (0 : ℝ) ≤ L * θ * (y' - y) := mul_nonneg (mul_nonneg hL hθ) hd
      have e3 : (L * θ + κ₂) * (y' - y) ≤ θ * (lam - κ₁ * θ) * (y' - y) :=
        mul_le_mul_of_nonneg_right hcone hd
      have e4 : θ * (lam * (y' - y)) ≤ θ * (m 1 (x, y') - m 1 (x, y)) :=
        mul_le_mul_of_nonneg_left hm hθ
      have e5 : (0 : ℝ) ≤ θ * (κ₁ * θ * (y' - y)) := mul_nonneg hθ e1
      constructor
      · show ‖w 1 (x, y') - w 1 (x, y)‖ ≤ θ * (m 1 (x, y') - m 1 (x, y))
        have hw' : ‖w 1 (x, y') - w 1 (x, y)‖ ≤ κ₂ * (y' - y) := hw
        nlinarith
      · show (lam - κ₁ * θ) ^ 1 * (y' - y) ≤ m 1 (x, y') - m 1 (x, y)
        rw [pow_one]
        have hm' : lam * (y' - y) ≤ m 1 (x, y') - m 1 (x, y) := hm
        nlinarith
    | succ k ih =>
      intro x y y' h1 h2 hy
      obtain ⟨c1, c2⟩ := ih x y y' (hDc k _ h1) (hDc k _ h2) hy
      have hm := hstepm (k + 1) x y y' h1 h2 hy
      have hw := hstepw (k + 1) x y y' h1 h2 hy
      have hd : (0 : ℝ) ≤ y' - y := by linarith
      have hρk : (0 : ℝ) ≤ (lam - κ₁ * θ) ^ (k + 1) * (y' - y) :=
        mul_nonneg (pow_nonneg hexp.le _) hd
      have hdm : (0 : ℝ) ≤ m (k + 1) (x, y') - m (k + 1) (x, y) := le_trans hρk c2
      -- Δm_{k+2} ≥ ρ Δm_{k+1}
      have e1 : κ₁ * ‖w (k + 1) (x, y') - w (k + 1) (x, y)‖
          ≤ κ₁ * (θ * (m (k + 1) (x, y') - m (k + 1) (x, y))) := mul_le_mul_of_nonneg_left c1 hκ₁
      have e2 : (lam - κ₁ * θ) * (m (k + 1) (x, y') - m (k + 1) (x, y))
          ≤ m (k + 1 + 1) (x, y') - m (k + 1 + 1) (x, y) := by nlinarith
      have e3 : L * ‖w (k + 1) (x, y') - w (k + 1) (x, y)‖
          ≤ L * (θ * (m (k + 1) (x, y') - m (k + 1) (x, y))) := mul_le_mul_of_nonneg_left c1 hL
      have e4 : (L * θ + κ₂) * (m (k + 1) (x, y') - m (k + 1) (x, y))
          ≤ θ * (lam - κ₁ * θ) * (m (k + 1) (x, y') - m (k + 1) (x, y)) :=
        mul_le_mul_of_nonneg_right hcone hdm
      have e5 : θ * ((lam - κ₁ * θ) * (m (k + 1) (x, y') - m (k + 1) (x, y)))
          ≤ θ * (m (k + 1 + 1) (x, y') - m (k + 1 + 1) (x, y)) := mul_le_mul_of_nonneg_left e2 hθ
      constructor
      · nlinarith
      · have e6 : (lam - κ₁ * θ) * ((lam - κ₁ * θ) ^ (k + 1) * (y' - y))
            ≤ (lam - κ₁ * θ) * (m (k + 1) (x, y') - m (k + 1) (x, y)) :=
          mul_le_mul_of_nonneg_left c2 hexp.le
        have e7 : (lam - κ₁ * θ) ^ (k + 1 + 1) * (y' - y)
            = (lam - κ₁ * θ) * ((lam - κ₁ * θ) ^ (k + 1) * (y' - y)) := by ring
        rw [e7]
        linarith
  refine ⟨key, ?_⟩
  intro k x y y' h1 h2 hy
  have h := (key k x y y' h1 h2 hy.le).2
  have hpos : (0 : ℝ) < (lam - κ₁ * θ) ^ (k + 1) * (y' - y) :=
    mul_pos (pow_pos hexp _) (by linarith)
  linarith

end FermionTuning

-- ===== new part : FermionChain.part.lean =====

/-! # The chain with two bare parameters (coupling and mass): Theorem W_F, implication part

The fermion version of Theorem W of paper A: the measures are the
determinant-weighted measures (they enter only through `νP`, `μ`, `FineRP`, exactly as in
`FineSupportReflection.chain_end_to_end_fine_support`), and the bare-coupling lemma (W0) is replaced by the
two-parameter tuning (W0').  The second conclusion ((W1)–(W5)) is literally that of the gauge chain and does not
see the coupling flow: it is obtained from `chain_end_to_end_fine_support` with a trivial one-parameter flow. -/
namespace FermionChain

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-- Per-step premises with two bare parameters `p = (x, y)` (inverse coupling, mass).  The fields of
`SmallRemKernel.CouplingStepsKer` on the two-parameter domain
`{p | ∀ j ≤ k, u⋆ ≤ u j p ∧ |mq j p| ≤ Mq}`, plus the mass step (M) and the strict monotonicity (E). -/
structure CouplingMassSteps (u mq z w rs rl : ℕ → ℝ × ℝ → ℝ) (Φ : ℝ → ℝ)
    (b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hδ : 0 ≤ δ
  hC : 0 ≤ C₂
  hD : 0 ≤ D
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  hε : 0 ≤ εm
  hs : 0 ≤ sm
  hlam : 1 + εm < lam
  hgap : sm < (lam - 1 - εm) * Mq
  flow : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) →
    u (k + 1) p = u k p - b + rs k p + rl k p
  small_rem : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) → |rs k p| ≤ δ + C₂ / u k p
  large_rem : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) → |rl k p| ≤ D * z k p
  act_rec : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) →
    z (k + 1) p ≤ ρ * z k p + A * w k p + B * z k p ^ 2
  act_nonneg : ∀ k p, 0 ≤ z k p
  act_init : ∀ p, z 0 p ≤ Z
  supply : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) → w k p ≤ Φ (u k p)
  supply_anti : ∀ a c, ustar ≤ a → a ≤ c → Φ c ≤ Φ a
  fix : ρ * Z + A * Φ ustar + B * Z ^ 2 ≤ Z
  margin : δ + C₂ / ustar + D * Z ≤ b / 2
  mass_step : ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) →
    |mq (k + 1) p - lam * mq k p| ≤ εm * |mq k p| + sm
  mass_mono : ∀ k x y y', (∀ j ≤ k, ustar ≤ u j (x, y) ∧ |mq j (x, y)| ≤ Mq) →
    (∀ j ≤ k, ustar ≤ u j (x, y') ∧ |mq j (x, y')| ≤ Mq) → y < y' →
    mq (k + 1) (x, y) < mq (k + 1) (x, y')

theorem activity_le_two {u mq z w rs rl : ℕ → ℝ × ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ}
    (H : CouplingMassSteps u mq z w rs rl Φ b δ C₂ D ρ A B Z ustar Mq lam εm sm) :
    ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) → z k p ≤ Z := by
  intro k
  induction k with
  | zero => intro p _; exact H.act_init p
  | succ k ih =>
    intro p hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq := fun j hj => hdom j (by omega)
    have hz := ih p hdom'
    have hw : w k p ≤ Φ ustar :=
      le_trans (H.supply k p hdom') (H.supply_anti _ _ le_rfl (hdom' k le_rfl).1)
    have h1 : ρ * z k p ≤ ρ * Z := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k p ≤ A * Φ ustar := mul_le_mul_of_nonneg_left hw H.hA
    have h3 : z k p ^ 2 ≤ Z ^ 2 := pow_le_pow_left₀ (H.act_nonneg k p) hz 2
    have h4 : B * z k p ^ 2 ≤ B * Z ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    linarith [H.act_rec k p hdom', H.fix]

/-- The (H-β) form on the two-parameter domain: `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2`. -/
theorem hbeta_two {u mq z w rs rl : ℕ → ℝ × ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ}
    (H : CouplingMassSteps u mq z w rs rl Φ b δ C₂ D ρ A B Z ustar Mq lam εm sm) :
    ∀ k p, (∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq) →
      u k p - 3 * b / 2 ≤ u (k + 1) p ∧ u (k + 1) p ≤ u k p - b / 2 := by
  intro k p hdom
  have hu : ustar ≤ u k p := (hdom k le_rfl).1
  have hz := activity_le_two H k p hdom
  have hdiv : C₂ / u k p ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hDz : D * z k p ≤ D * Z := mul_le_mul_of_nonneg_left hz H.hD
  have hs := abs_le.mp (le_trans (H.small_rem k p hdom) (add_le_add le_rfl hdiv))
  have hl := abs_le.mp (le_trans (H.large_rem k p hdom) hDz)
  have hf := H.flow k p hdom
  have hm := H.margin
  constructor <;> nlinarith [hs.1, hs.2, hl.1, hl.2]

/-- (W0') from the two-parameter per-step premises and continuity. -/
theorem tuning_of_steps {u mq z w rs rl : ℕ → ℝ × ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ}
    (H : CouplingMassSteps u mq z w rs rl Φ b δ C₂ D ρ A B Z ustar Mq lam εm sm)
    (hu0 : ∀ p, u 0 p = p.1) (hm0 : ∀ p, mq 0 p = p.2)
    (hCu : ∀ k, ContinuousOn (u (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq})
    (hCm : ∀ k, ContinuousOn (mq (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq}) :
    ∀ t, ustar ≤ t → ∀ mbar, |mbar| ≤ Mq → ∀ n : ℕ, ∃ p : ℝ × ℝ,
      t + b / 2 * n ≤ p.1 ∧ p.1 ≤ t + 3 * b / 2 * n ∧ u n p = t ∧ mq n p = mbar ∧
      ∀ k ≤ n, t ≤ u k p ∧ |mq k p| ≤ Mq :=
  fun t ht mbar hmbar n =>
    FermionTuning.exists_bare_coupling_and_mass u mq b ustar t Mq lam εm sm mbar n H.hb
      H.hε H.hs H.hlam H.hgap hu0 hm0 (hbeta_two H) H.mass_step hCu hCm H.mass_mono ht hmbar

/-- The model of `FermionTuning` satisfies the two-parameter per-step premises (the structure is inhabited). -/
theorem model_steps : CouplingMassSteps FermionTuning.uEx FermionTuning.mEx (fun _ _ => 0)
    (fun _ _ => 0) (fun _ _ => 0) (fun _ _ => 0) (fun _ => 0) 1 0 0 0 0 0 0 0 1 1 2 0 (1 / 2) where
  ustar_pos := one_pos
  hb := one_pos
  hδ := le_rfl
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hA := le_rfl
  hB := le_rfl
  hε := le_rfl
  hs := by norm_num
  hlam := by norm_num
  hgap := by norm_num
  flow := fun k p _ => by simp only [FermionTuning.uEx]; push_cast; ring
  small_rem := fun k p _ => by simp
  large_rem := fun k p _ => by simp
  act_rec := fun k p _ => by simp
  act_nonneg := fun k p => le_rfl
  act_init := fun p => le_rfl
  supply := fun k p _ => le_rfl
  supply_anti := fun a c _ _ => le_rfl
  fix := by norm_num
  margin := by norm_num
  mass_step := fun k p _ => FermionTuning.mEx_step k p
  mass_mono := fun k x y y' _ _ hy => FermionTuning.mEx_strictMono k x y y' hy


/-- The set of tuned bare points at fine level `n`: after `n` steps the effective inverse coupling is `t` and
the effective mass is `mbar`, the flow stays in the domain, and the bare coupling is in the a priori bracket. -/
def Tuned (u mq : ℕ → ℝ × ℝ → ℝ) (b Mq t mbar : ℝ) (n : ℕ) : Set (ℝ × ℝ) :=
  {p | t + b / 2 * n ≤ p.1 ∧ p.1 ≤ t + 3 * b / 2 * n ∧ u n p = t ∧ mq n p = mbar ∧
    ∀ k ≤ n, t ≤ u k p ∧ |mq k p| ≤ Mq}

/-- (W0') in the form: the tuned set is nonempty at every level. -/
theorem tuned_nonempty {u mq z w rs rl : ℕ → ℝ × ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ}
    (H : CouplingMassSteps u mq z w rs rl Φ b δ C₂ D ρ A B Z ustar Mq lam εm sm)
    (hu0 : ∀ p, u 0 p = p.1) (hm0 : ∀ p, mq 0 p = p.2)
    (hCu : ∀ k, ContinuousOn (u (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq})
    (hCm : ∀ k, ContinuousOn (mq (k + 1)) {p | ∀ j ≤ k, ustar ≤ u j p ∧ |mq j p| ≤ Mq})
    {t : ℝ} (ht : ustar ≤ t) {mbar : ℝ} (hmbar : |mbar| ≤ Mq) (n : ℕ) :
    (Tuned u mq b Mq t mbar n).Nonempty :=
  tuning_of_steps H hu0 hm0 hCu hCm t ht mbar hmbar n


end FermionChain

namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionChain

variable (L : ℕ) [NeZero L]

/-- **the box chain for the fermion family at the two-parameter tuned points** (bare mass `y_n`, `β_n = 4 x_n`) -/
theorem chain_end_to_end_box_fermion_two_param {r₀ : ℝ} (hr : 0 < r₀) {X : Type*} [MetricSpace X]
    (j : ℕ) (c : ℕ → ℕ)
    {uf mqf zf wf rsf rlf : ℕ → ℕ → ℝ × ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar Mq lam εm sm : ℝ} (t mbar : ℝ)
    (hsteps : ∀ n, CouplingMassSteps (uf n) (mqf n) (zf n) (wf n) (rsf n) (rlf n) Φ
      b δ C₂ D ρ A B Z ustar Mq lam εm sm)
    (hu0 : ∀ n p, uf n 0 p = p.1) (hm0 : ∀ n p, mqf n 0 p = p.2)
    (hCu : ∀ n k, ContinuousOn (uf n (k + 1)) {p | ∀ j ≤ k, ustar ≤ uf n j p ∧ |mqf n j p| ≤ Mq})
    (hCm : ∀ n k, ContinuousOn (mqf n (k + 1)) {p | ∀ j ≤ k, ustar ≤ uf n j p ∧ |mqf n j p| ≤ Mq})
    (ht : ustar ≤ t) (hmbar : |mbar| ≤ Mq) (hMq : Mq < 1) :
    ∃ pn : ℕ → ℝ × ℝ, (∀ n, pn n ∈ Tuned (uf n) (mqf n) b Mq t mbar n) ∧ (∀ n, -1 < (pn n).2) ∧
      ∀ hm : (∀ n, -1 < (pn n).2),
        type_of% (chain_end_to_end_box_fermion L hr (X := X) j (fun n => (pn n).2) (fun n => 4 * (pn n).1) hm c) := by
  choose pn hpn using fun n =>
    tuning_of_steps (hsteps n) (hu0 n) (hm0 n) (hCu n) (hCm n) t ht mbar hmbar n
  have hT : ∀ n, pn n ∈ Tuned (uf n) (mqf n) b Mq t mbar n := hpn
  have hm : ∀ n, -1 < (pn n).2 := by
    intro n
    have h := hT n
    simp only [Tuned, Set.mem_setOf_eq] at h
    obtain ⟨-, -, -, -, hk⟩ := h
    have h0 := (hk 0 (Nat.zero_le n)).2
    rw [hm0] at h0
    have := (abs_le.mp h0).1
    linarith
  exact ⟨pn, hT, hm, fun hm' => chain_end_to_end_box_fermion L hr (X := X) j (fun n => (pn n).2)
    (fun n => 4 * (pn n).1) hm' c⟩

end BoxFermion

#print axioms FermionChain.tuning_of_steps
#print axioms FermionChain.tuned_nonempty
#print axioms BoxFermion.chain_end_to_end_box_fermion_two_param

namespace BoxFermion

open MeasureTheory Filter Topology ChainBlockMap BoxWalk WilsonGauge FermionChain

/-- the toy flow `u_k(x) = x − k` with zero activities satisfies the per-step premise `HE` of the box chain -/
theorem toyE' : TransientChainError.CouplingStepsTransientE (fun k x => x - k) (fun _ _ => 0) (fun _ _ => 0)
    (fun _ _ => 0) (fun _ _ => 0) (fun _ => 0) (fun _ => 0) (fun _ => 0) (fun _ => 0) (fun _ => 0)
    1 1 1 0 0 0 0 0 1 where
  ustar_pos := one_pos
  he := fun _ _ _ _ => le_rfl
  hD := fun _ _ => le_rfl
  hρ := le_rfl
  hA := le_rfl
  hB := le_rfl
  flow := fun k x _ => by push_cast; ring
  small_net := fun _ _ _ => by norm_num
  transient := fun n => by simp
  large_rem := fun _ _ _ => by simp
  act_rec := fun _ _ _ => by simp
  act_nonneg := fun _ _ => le_rfl
  act_init := fun _ _ => le_rfl
  supply := fun _ _ _ => le_rfl
  fix_shift := fun _ _ _ _ _ => by simp
  DW := fun _ _ => by simp
  margin := by norm_num


/-- copied verbatim from `Bridge/FineRPWilsonV7g.lean` : the model flow with mass window `9/10` -/
theorem model_steps_mq : CouplingMassSteps FermionTuning.uEx FermionTuning.mEx (fun _ _ => 0)
    (fun _ _ => 0) (fun _ _ => 0) (fun _ _ => 0) (fun _ => 0) 1 0 0 0 0 0 0 0 1 (9 / 10) 2 0 (1 / 2) where
  ustar_pos := one_pos
  hb := one_pos
  hδ := le_rfl
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hA := le_rfl
  hB := le_rfl
  hε := le_rfl
  hs := by norm_num
  hlam := by norm_num
  hgap := by norm_num
  flow := fun k p _ => by simp only [FermionTuning.uEx]; push_cast; ring
  small_rem := fun k p _ => by simp
  large_rem := fun k p _ => by simp
  act_rec := fun k p _ => by simp
  act_nonneg := fun k p => le_rfl
  act_init := fun p => le_rfl
  supply := fun k p _ => le_rfl
  supply_anti := fun a c _ _ => le_rfl
  fix := by norm_num
  margin := by norm_num
  mass_step := fun k p _ => FermionTuning.mEx_step k p
  mass_mono := fun k x y y' _ _ hy => FermionTuning.mEx_strictMono k x y y' hy

/-- **witness for the two-parameter tuned fermion box chain**: with the model flow (`uEx`, `mEx`, window `9/10`,
targets `t = 1`, `m̄ = 0`) there are tuned points with `y_n > −1`, and with trivial remaining fields the chain gives
a subsequence and limits of the block measures of the fermion family at `(y_n, β_n = 4 x_n)` that are reflection
positive on the strip functions -/
theorem chain_box_fermion_two_param_witness :
    ∃ pn : ℕ → ℝ × ℝ, (∀ n, pn n ∈ Tuned FermionTuning.uEx FermionTuning.mEx 1 (9 / 10) 1 0 n) ∧
      (∀ n, -1 < (pn n).2) ∧
      ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (BoxLk (2 * 1) m)),
        (∀ m, Tendsto (fun k => νP (1 : ℝ) one_pos (boxPaths (2 * 1)) (boxW (2 * 1))
          (fermProbBox 1 1 (fun n => (pn n).2) (fun n => 4 * (pn n).1)) (φ k) m) atTop (𝓝 (νl m))) ∧
        ∀ m, ∀ F ∈ stripSet (2 * 1) 0 m,
          0 ≤ ∫ ω, F (reflCfg (2 * 1) m ω) * F ω ∂(νl m : Measure (Cfg (BoxLk (2 * 1) m))) := by
  obtain ⟨pn, hT, hm, hchain⟩ := chain_end_to_end_box_fermion_two_param 1 (r₀ := 1) one_pos (X := Unit) 1
    (fun _ => 0) (uf := fun _ => FermionTuning.uEx) (mqf := fun _ => FermionTuning.mEx) 1 0
    (fun _ => model_steps_mq) (fun _ _ => by simp [FermionTuning.uEx]) (fun _ _ => by simp [FermionTuning.mEx])
    (fun _ k => (FermionTuning.continuous_uEx (k + 1)).continuousOn)
    (fun _ k => (FermionTuning.continuous_mEx (k + 1)).continuousOn)
    le_rfl (by norm_num) (by norm_num)
  have H := hchain hm
    (u := fun k x => x - k) (z := fun _ _ => 0) (w' := fun _ _ => 0) (rs := fun _ _ => 0) (rl := fun _ _ => 0)
    (Φ := fun _ => 0) (W := fun _ => 0) (Dfun := fun _ => 0) (δ := fun _ => 0) (e := fun _ => 0)
    (b := 1) (binf := 1) (bp := 1) (D₀ := 0) (ρ := 0) (A := 0) (B := 0) (Y := 0) (ustar := 1)
    (ι := fun _ => Unit) (Pl := fun _ => Unit) (Pt := fun _ => Unit)
    (R := fun _ => ∅) (plaq := fun _ _ => ∅) (pts := fun _ _ => ∅) (Yf := fun _ _ _ => 0) (f := fun _ _ _ => 0)
    (yh := fun _ => 0) (θ := fun _ => 0) (P₁ := fun _ => 0) (S := fun _ => 0) (np := fun _ => 0)
    (npt := fun _ => 0) (Dset := Set.univ) (s := fun _ _ => 0) (τ := fun _ => 0) (Ωr := fun _ => 0)
    (HE := toyE')
    (rarity := fun _ => Eventually.of_forall fun _ _ hi => absurd hi (Finset.notMem_empty _))
    (lattice_vanishing := tendsto_const_nhds)
    (shift_vanishing := fun η hη => ⟨1, one_pos, fun _ _ _ => hη.le⟩)
    (split := fun _ _ _ _ _ => by simp)
    (h0 := fun x => by simp)
    (hCu := fun k => (continuous_id.sub continuous_const).continuousOn)
    (Gb := Unit) (actb := fun _ _ => id) (Cset := fun _ => Set.univ)
    (hsc := fun _ _ => continuous_id)
    (hsym := fun _ _ => Eventually.of_forall fun _ _ => rfl)
    (hCc := fun _ => isClosed_univ) (hgood := fun _ => Set.subset_univ _)
    (Bd := 0) (G := Unit) (act := fun _ => id) (εb := fun _ _ _ => 0) (Pset := ∅)
    (hcount := Set.countable_univ) (hdense := dense_univ)
    (hbd := fun _ _ _ => by simp)
    (hac := fun _ => continuous_id) (ham := fun _ _ _ => Set.mem_univ _)
    (hbr := fun _ _ _ _ => by simp)
    (hbv := fun _ _ _ => tendsto_const_nhds)
    (hpos := fun _ hp => absurd hp (Set.notMem_empty _))
    (lev := fun _ => 0) (Fo := fun _ => 0)
    (HR := ⟨fun _ _ => Eventually.of_forall fun _ => by simp⟩)
  obtain ⟨-, φ, hφ, νl, hconv, hBC, -⟩ := H
  exact ⟨pn, hT, hm, φ, hφ, νl, hconv, hBC.reflection_positive⟩

end BoxFermion

#print axioms BoxFermion.chain_box_fermion_two_param_witness
