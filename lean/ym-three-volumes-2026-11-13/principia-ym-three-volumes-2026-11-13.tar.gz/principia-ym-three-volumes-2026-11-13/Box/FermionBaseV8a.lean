import Gauge.WilsonFullV7c
import Chain.BoxWilsonV2

/-! # file A: the Wilson–fermion measure of this column, recompiled next to the box chain

Imports `Gauge.WilsonFullV7c` (this column) and `Chain.BoxWilsonV2` (read-only root `olean`; it contains
the `chain_end_to_end_box`, the block map `blockMap`/`down`, `reflCfg`, `down_refl`, `TorusRP`). Because
`Chain.BoxWilsonV2` and this column's `Chain.ChainFermionV7` both contain copies of `WeakUltravioletExistence` etc.,
they cannot be imported together; the pieces of this column that do not depend on `ChainFermionV7` are copied here
verbatim (sources and sha256 in `oearlier data files):
* `FineSupportReflection.DependsOn`, `FineRP` (ChainFermionV7 lines 1853–1868, the chain's definitions, text-identical);
* `FineRPWilsonV7g` lines 16–223 (posSide, glue, wfWeight, wfMeasure, `fineRP_wilson_fermion`, wfProb, …) and 265–283;
* `MatchV7i` lines 12–346 (pull, toPhys, `refl_pull`, `map_pull`, `wilsonMeasure_eq_map`), now against the
  `TorusRP` of `Chain.BoxWilsonV2` instead of `Gauge.TorusWilsonRPv3`;
* `RP1163V7b` lines 10–89 (`toPhys_mem_posSide`, `wilson_rp_from_column`). -/

namespace FineSupportReflection

open MeasureTheory

/-- `f` is determined by the values of the configuration `ω : L → α` on the set `S`. -/
def DependsOn {L α β : Type*} (S : Set L) (f : (L → α) → β) : Prop :=
  ∀ ω ω' : L → α, (∀ l ∈ S, ω l = ω' l) → f ω = f ω'

/-- Reflection positivity at the fine lattice points (premise form): for bounded measurable functions determined on the positive side `S`. -/
def FineRP {L α : Type*} [MeasurableSpace (L → α)] (μ : Measure (L → α))
    (Θf : (L → α) → (L → α)) (S : Set L) : Prop :=
  ∀ f : (L → α) → ℝ, Measurable f → (∃ C, ∀ ω, |f ω| ≤ C) → DependsOn S f →
    0 ≤ ∫ ω, f (Θf ω) * f ω ∂μ

end FineSupportReflection

namespace WilsonGauge

open MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection FineSupportReflection

/-- the classes of the planes and of the positive side -/
def posClass {N hT : ℕ} : (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT) → Prop
  | Sum.inl _ => True
  | Sum.inr (Sum.inl _) => True
  | Sum.inr (Sum.inr _) => False

/-- the links of the planes `t = 0`, `t = h` and of the positive side `0 < t < h` (time links `t → t+1`, `t < h`) -/
def posSide (N hT : ℕ) : Set (PhysLink N hT) := {l | posClass (linkClass l)}

/-- the configuration with the given plane and positive-side links (negative side `1`) -/
noncomputable def glue {N hT : ℕ} (c : PlaneConf N) (a : PosConf N hT) (l : PhysLink N hT) : SU2 :=
  match linkClass l with
  | Sum.inl (Sum.inl f) => c.1 f
  | Sum.inl (Sum.inr f) => c.2 f
  | Sum.inr (Sum.inl (Sum.inl q)) => a.1 q
  | Sum.inr (Sum.inl (Sum.inr q)) => a.2 q
  | Sum.inr (Sum.inr _) => 1

theorem glue_split_eq {N hT : ℕ} (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (l : PhysLink N hT)
    (hl : l ∈ posSide N hT) :
    glue (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
      (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1 l = ω l := by
  rw [omega_link hpos ω l (linkClass l) rfl]
  unfold glue
  simp only [posSide, Set.mem_setOf_eq] at hl
  revert hl
  generalize linkClass l = y
  intro hl
  rcases y with (f | f) | ((q | q) | q)
  · rfl
  · rfl
  · rfl
  · rfl
  · exact False.elim hl

theorem measurable_glue {N hT : ℕ} : Measurable fun q : PlaneConf N × PosConf N hT => glue q.1 q.2 := by
  rw [measurable_pi_iff]
  intro l
  unfold glue
  generalize linkClass l = y
  rcases y with (f | f) | ((q | q) | q)
  · exact (measurable_pi_apply f).comp (measurable_fst.comp measurable_fst)
  · exact (measurable_pi_apply f).comp (measurable_snd.comp measurable_fst)
  · exact (measurable_pi_apply q).comp (measurable_fst.comp measurable_snd)
  · exact (measurable_pi_apply q).comp (measurable_snd.comp measurable_snd)
  · exact measurable_const

/-- the density `exp(−β S_W) · Re det D^{2j}` -/
noncomputable def wfWeight (N : ℕ) [NeZero N] (hT j : ℕ) (m β : ℝ) (ω : PhysLink N hT → SU2) : ℝ :=
  Real.exp (-β * wilsonAction N hT ω) * ((physDirac N hT m ω).det ^ (2 * j)).re

theorem wfWeight_eq (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) (ω : PhysLink N hT → SU2) :
    wfWeight N hT j m β ω = splitWeight N hT β (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω)
      * fermWeight N hT j m (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω) := by
  unfold wfWeight
  rw [wilsonWeight_split N hT hpos β ω, physDirac_eq_split N hT hpos m ω]
  rfl

theorem fermWeight_nonneg (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ) (p : PlaneConf N × (PosConf N hT × PosConf N hT)) :
    0 ≤ fermWeight N hT j m p := by
  unfold fermWeight
  exact (wilson_weight_nonneg_torus N hT j m _ _ _ _ _ _).1

theorem wfWeight_nonneg (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) (ω : PhysLink N hT → SU2) :
    0 ≤ wfWeight N hT j m β ω := by
  rw [wfWeight_eq N hT hpos j m β ω]
  refine mul_nonneg ?_ (fermWeight_nonneg N hT j m _)
  unfold splitWeight planeWeight halfWeight
  positivity

set_option maxHeartbeats 1600000 in
theorem continuous_fermWeight (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ) : Continuous (fermWeight N hT j m) := by
  have c0 : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1 x i a b :=
    fun x i a b => (continuous_U0of N x i a b).comp continuous_fst
  have ch : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => Uhof N p.1 x i a b :=
    fun x i a b => (continuous_Uhof N x i a b).comp continuous_fst
  have cp : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.1 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_fst.comp continuous_snd)
  have cm : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.2 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_snd.comp continuous_snd)
  have c4p : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.1 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_fst.comp continuous_snd)
  have c4m : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.2 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_snd.comp continuous_snd)
  exact continuous_det_torus_generic N hT j m
    (fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1) (fun p => Uhof N p.1)
    (fun p => Upof N hT p.2.1) (fun p => Upof N hT p.2.2)
    (fun p => U4of N hT p.2.1) (fun p => U4of N hT p.2.2) c0 ch cp cm c4p c4m

theorem measurable_wfWeight (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    Measurable (wfWeight N hT j m β) := by
  haveI i1 : OpensMeasurableSpace (PosConf N hT × PosConf N hT) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  haveI i2 : OpensMeasurableSpace (PlaneConf N × (PosConf N hT × PosConf N hT)) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  have hG : Measurable fun p => splitWeight N hT β p * fermWeight N hT j m p :=
    ((continuous_splitWeight N hT β).mul (continuous_fermWeight N hT j m)).measurable
  have h := hG.comp (phys_split_preserving N hT hpos).measurable
  have e : wfWeight N hT j m β = (fun p => splitWeight N hT β p * fermWeight N hT j m p)
      ∘ configSplit (linkEquiv N hT hpos) (sigInv N hT) := by
    funext ω
    exact wfWeight_eq N hT hpos j m β ω
  rw [e]
  exact h

/-- **the Wilson–fermion measure** (not normalised): `Π Haar` with density `exp(−β S_W) Re det D^{2j}` -/
noncomputable def wfMeasure (N : ℕ) [NeZero N] (hT j : ℕ) (m β : ℝ) : Measure (PhysLink N hT → SU2) :=
  (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)).withDensity
    fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal)

/-- **the chain's premise `FineRP` holds for the Wilson–fermion measure** (every `β ∈ ℝ`, `m > −1`, `j`) -/
theorem fineRP_wilson_fermion (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (hm : -1 < m) (β : ℝ) :
    FineRP (wfMeasure N hT j m β) thetaPhys (posSide N hT) := by
  unfold FineRP
  intro f hf hb hS
  obtain ⟨C, hC⟩ := hb
  have hmeas : Measurable fun ω => (wfWeight N hT j m β ω).toNNReal :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal
  unfold wfMeasure
  rw [integral_withDensity_eq_integral_smul hmeas]
  have h := site_reflection_positive_wilson_theta N hT hpos j m hm β (fun q => f (glue q.1 q.2))
    (hf.comp measurable_glue) C (fun q => hC _)
  refine h.trans_eq ?_
  congr 1
  funext ω
  have e1 : f (glue (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
      (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1) = f ω :=
    hS _ _ fun l hl => glue_split_eq hpos ω l hl
  have e2 : f (glue (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).1
      (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).2.1) = f (thetaPhys ω) :=
    hS _ _ fun l hl => glue_split_eq hpos (thetaPhys ω) l hl
  dsimp only
  rw [e1, e2, NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal _ (wfWeight_nonneg N hT hpos j m β ω)]
  unfold wfWeight
  ring

end WilsonGauge

#print axioms WilsonGauge.glue_split_eq
#print axioms WilsonGauge.wfWeight_eq
#print axioms WilsonGauge.wfWeight_nonneg
#print axioms WilsonGauge.measurable_wfWeight
#print axioms WilsonGauge.fineRP_wilson_fermion

/-! ## The normalised (probability) Wilson–fermion measure and `FineRP` for it -/
namespace WilsonGauge

open MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection FineSupportReflection

/-- `Z = ∫ exp(−β S_W) Re det D^{2j} dΠHaar > 0` -/
theorem wf_partition_pos (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    0 < ∫ ω, wfWeight N hT j m β ω ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) :=
  partition_pos_wilson_phys_op N hT hpos j m β

theorem wfWeight_bounded (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    ∃ C, ∀ ω, |wfWeight N hT j m β ω| ≤ C := by
  obtain ⟨C, hC⟩ := bound_of_continuous _ ((continuous_splitWeight N hT β).mul (continuous_fermWeight N hT j m))
  exact ⟨C, fun ω => by rw [wfWeight_eq N hT hpos j m β ω]; exact hC _⟩

theorem integrable_wfWeight (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    Integrable (wfWeight N hT j m β)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  haveI := haarTop_isProb SU2
  obtain ⟨C, hC⟩ := wfWeight_bounded N hT hpos j m β
  exact Integrable.of_bound (measurable_wfWeight N hT hpos j m β).aestronglyMeasurable C
    (Filter.Eventually.of_forall fun ω => by rw [Real.norm_eq_abs]; exact hC ω)

/-- the normalised Wilson–fermion measure `Z⁻¹ · wfMeasure` -/
noncomputable def wfProb (N : ℕ) [NeZero N] (hT j : ℕ) (m β : ℝ) : Measure (PhysLink N hT → SU2) :=
  (ENNReal.ofReal (∫ ω, wfWeight N hT j m β ω
    ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))))⁻¹ • wfMeasure N hT j m β

theorem wfProb_isProbability (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    IsProbabilityMeasure (wfProb N hT j m β) := by
  constructor
  have hZ := wf_partition_pos N hT hpos j m β
  have h1 : wfMeasure N hT j m β Set.univ = ENNReal.ofReal (∫ ω, wfWeight N hT j m β ω
      ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))) := by
    unfold wfMeasure
    rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
      ofReal_integral_eq_lintegral_ofReal (integrable_wfWeight N hT hpos j m β)
        (Filter.Eventually.of_forall fun ω => wfWeight_nonneg N hT hpos j m β ω)]
    rfl
  unfold wfProb
  rw [Measure.smul_apply, h1, smul_eq_mul]
  exact ENNReal.inv_mul_cancel (ENNReal.ofReal_pos.mpr hZ).ne' ENNReal.ofReal_ne_top

/-- **`FineRP` for the normalised Wilson–fermion measure** (the form of the chain's premise `hRP`) -/
theorem fineRP_wilson_fermion_prob (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (hm : -1 < m)
    (β : ℝ) : FineRP (wfProb N hT j m β) thetaPhys (posSide N hT) := by
  unfold FineRP
  intro f hf hb hS
  unfold wfProb
  rw [integral_smul_measure]
  exact smul_nonneg ENNReal.toReal_nonneg (fineRP_wilson_fermion N hT hpos j m hm β f hf hb hS)

end WilsonGauge

#print axioms WilsonGauge.wfProb_isProbability
#print axioms WilsonGauge.fineRP_wilson_fermion_prob

/-! ## `thetaPhys` is continuous and measurable (the chain's premise `hΘf`) and an involution -/
namespace WilsonGauge

open MeasureTheory FermionSliceBlock FermionSU2Config

theorem continuous_thetaPhys (N hT : ℕ) : Continuous (thetaPhys (N := N) (hT := hT)) := by
  refine continuous_pi fun l => ?_
  by_cases hμ : l.2.2.val < 3
  · simp only [thetaPhys, if_pos hμ]
    exact continuous_apply _
  · simp only [thetaPhys, if_neg hμ]
    exact (continuous_apply _).inv

theorem measurable_thetaPhys (N hT : ℕ) : Measurable (thetaPhys (N := N) (hT := hT)) :=
  (continuous_thetaPhys N hT).measurable

end WilsonGauge

#print axioms WilsonGauge.measurable_thetaPhys

namespace WilsonGauge

open Matrix FermionSliceBlock FermionSU2Config

theorem trace_quatMat' (q : Quaternion ℝ) : (quatMat q).trace = 2 * (q.re : ℂ) := by
  rw [Matrix.trace_fin_two]
  simp only [quatMat, Matrix.of_apply, Matrix.cons_val', Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.empty_val', Matrix.cons_val_fin_one, Matrix.head_cons, Matrix.head_fin_const]
  ring

theorem plaqE_quat' (a b c d : Quaternion ℝ) :
    plaqE (quatMat a) (quatMat b) (quatMat c) (quatMat d) = 1 - (a * b * star c * star d).re := by
  unfold plaqE
  rw [← quatMat_star, ← quatMat_star, ← quatMat_mul, ← quatMat_mul, ← quatMat_mul, trace_quatMat']
  have e : ((2 : ℂ) * ((a * b * star c * star d).re : ℂ)).re = 2 * (a * b * star c * star d).re := by
    simp
  rw [e]
  ring

theorem re_reverse' (a b c d : Quaternion ℝ) :
    (d * c * star b * star a).re = (a * b * star c * star d).re := by
  have h : star (a * b * star c * star d) = d * c * star b * star a := by
    simp only [star_mul, star_star, mul_assoc]
  rw [← h, Quaternion.re_star]

section Match

variable (h : ℕ) [NeZero (2 * h)]

def zf (a : ZMod (2 * h)) : Fin (2 * h) := ⟨a.val, ZMod.val_lt a⟩

/-- directions: `0` (time of 1163) ↦ `3`, `k + 1` ↦ `k` -/
def dirOf (d : Fin 4) : Fin 4 :=
  if d = 0 then 3 else if d = 1 then (0 : Fin 3).castSucc else if d = 2 then (1 : Fin 3).castSucc
  else (2 : Fin 3).castSucc

def toPhys (ℓ : TorusRP.Lk (2 * h)) : PhysLink (2 * h) h :=
  (zf h (ℓ.1 0), fun k => zf h (ℓ.1 k.succ), dirOf ℓ.2)

noncomputable def pull (ω : PhysLink (2 * h) h → SU2) : TorusRP.Lk (2 * h) → TorusRP.QBall :=
  fun ℓ => TorusRP.incl (ω (toPhys h ℓ))

def psi (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) : TorusRP.Site (2 * h) :=
  Fin.cons ((p.1.val : ZMod (2 * h))) (fun k => ((p.2 k).val : ZMod (2 * h)))

theorem zf_cast (t : Fin (2 * h)) : zf h ((t.val : ZMod (2 * h))) = t := by
  apply Fin.ext
  simp only [zf, ZMod.val_natCast, Nat.mod_eq_of_lt t.isLt]

/-- the sites of the two columns -/
def siteEquiv : Fin (2 * h) × (Fin 3 → Fin (2 * h)) ≃ TorusRP.Site (2 * h) where
  toFun := psi h
  invFun := fun y => (zf h (y 0), fun k => zf h (y k.succ))
  left_inv := by
    rintro ⟨t, x⟩
    simp only [psi, Fin.cons_zero, Fin.cons_succ, zf_cast]
  right_inv := by
    intro y
    funext k
    refine Fin.cases ?_ (fun k => ?_) k
    · simp only [psi, Fin.cons_zero, zf, ZMod.natCast_zmod_val]
    · simp only [psi, Fin.cons_succ, zf, ZMod.natCast_zmod_val]

theorem toPhys_psi (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (d : Fin 4) :
    toPhys h (psi h p, d) = (p.1, p.2, dirOf d) := by
  simp only [toPhys, psi, Fin.cons_zero, Fin.cons_succ, zf_cast]

theorem val_cast_add_one [Fact (1 < 2 * h)] (t : Fin (2 * h)) :
    (((t.val : ZMod (2 * h)) + 1).val) = sc h t.val := by
  have ht := t.isLt
  rw [ZMod.val_add, ZMod.val_natCast, ZMod.val_one, Nat.mod_eq_of_lt ht]
  unfold sc
  by_cases h1 : t.val + 1 = 2 * h
  · rw [if_pos h1, h1, Nat.mod_self]
  · rw [if_neg h1]
    exact Nat.mod_eq_of_lt (by omega)

theorem toPhys_psi_time [Fact (1 < 2 * h)] (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (d : Fin 4) :
    toPhys h (psi h p + TorusRP.ev (2 * h) 0, d)
      = (⟨sc h p.1.val, sc_lt h p.1.val p.1.isLt⟩, p.2, dirOf d) := by
  have e0 : TorusRP.ev (2 * h) 0 0 = 1 := by simp [TorusRP.ev]
  have es : ∀ k : Fin 3, TorusRP.ev (2 * h) 0 k.succ = 0 := fun k => by
    simp [TorusRP.ev, Pi.single_apply, Fin.succ_ne_zero]
  simp only [toPhys, Pi.add_apply, psi, Fin.cons_zero, Fin.cons_succ, e0, es, add_zero, zf_cast]
  congr 1
  apply Fin.ext
  exact val_cast_add_one h p.1

theorem toPhys_psi_space [Fact (1 < 2 * h)] (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (k : Fin 3) (d : Fin 4) :
    toPhys h (psi h p + TorusRP.ev (2 * h) k.succ, d) = (p.1, p.2 + Pi.single k 1, dirOf d) := by
  have e0 : TorusRP.ev (2 * h) k.succ 0 = 0 := by
    simp [TorusRP.ev, Pi.single_apply, (Fin.succ_ne_zero k).symm]
  have es : ∀ k' : Fin 3, TorusRP.ev (2 * h) k.succ k'.succ = if k' = k then 1 else 0 := fun k' => by
    simp [TorusRP.ev, Pi.single_apply, Fin.succ_inj]
  simp only [toPhys, Pi.add_apply, psi, Fin.cons_zero, Fin.cons_succ, e0, es, add_zero, zf_cast]
  congr 1
  congr 1
  funext k'
  apply Fin.ext
  by_cases hk : k' = k
  · subst hk
    simp only [if_true, ite_true, zf, Pi.add_apply, Pi.single_eq_same, Fin.val_add, Fin.val_one', ZMod.val_add,
      ZMod.val_natCast, ZMod.val_one, Nat.mod_eq_of_lt (p.2 k').isLt]
    rw [Nat.mod_eq_of_lt (Fact.out : 1 < 2 * h)]
  · simp only [if_neg hk, add_zero, zf, Pi.add_apply, Pi.single_eq_of_ne hk, ZMod.val_natCast,
      Nat.mod_eq_of_lt (p.2 k').isLt]

/-- the plaquette sum at one site -/
noncomputable def siteSum (ω' : TorusRP.Lk (2 * h) → TorusRP.QBall) (y : TorusRP.Site (2 * h)) : ℝ :=
  ∑ μ : Fin 4, ∑ ν : Fin 4, if μ < ν then (TorusRP.hol (2 * h) ω' ((y, μ), ν)).re else 0

theorem action_eq_sum (ω' : TorusRP.Lk (2 * h) → TorusRP.QBall) :
    TorusRP.action (2 * h) ω' = ∑ p : Fin (2 * h) × (Fin 3 → Fin (2 * h)), siteSum h ω' (psi h p) := by
  have e : TorusRP.action (2 * h) ω' = ∑ y, siteSum h ω' y := by
    unfold TorusRP.action TorusRP.plaqs siteSum
    rw [Finset.sum_filter]
    simp only [Fintype.sum_prod_type]
  rw [e]
  exact (Equiv.sum_comp (siteEquiv h) (siteSum h ω')).symm

/-- the plaquettes of this column at one point `(t, x)`: spatial `i < j` on slice `t`, temporal `(i, 4)` -/
noncomputable def pointSum (ω : PhysLink (2 * h) h → SU2) (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) : ℝ :=
  (∑ i : Fin 3, ∑ j ∈ Finset.Ioi i, plaqE (physSp ω p.1.val p.2 i) (physSp ω p.1.val (p.2 + ev (2 * h) i) j)
      (physSp ω p.1.val (p.2 + ev (2 * h) j) i) (physSp ω p.1.val p.2 j))
    + ∑ i : Fin 3, plaqE (physSp ω p.1.val p.2 i) (physT ω p.1.val (p.2 + ev (2 * h) i))
      (physSp ω (sc h p.1.val) p.2 i) (physT ω p.1.val p.2)

theorem wilsonAction_eq_sum (ω : PhysLink (2 * h) h → SU2) :
    wilsonAction (2 * h) h ω = ∑ p : Fin (2 * h) × (Fin 3 → Fin (2 * h)), pointSum h ω p := by
  unfold wilsonAction
  rw [← Fin.sum_univ_eq_sum_range, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun t _ => ?_
  unfold pointSum spS tmS
  rw [Finset.sum_add_distrib]

theorem plaq_tm {N hT : ℕ} (ω : PhysLink N hT → SU2) (t s : ℕ) (ht : t < 2 * hT) (hs : s < 2 * hT)
    (x y : Fin 3 → Fin N) (i : Fin 3) :
    plaqE (physSp ω t x i) (physT ω t y) (physSp ω s x i) (physT ω t x)
      = 1 - ((ω (⟨t, ht⟩, x, 3) : Quaternion ℝ) * (ω (⟨s, hs⟩, x, i.castSucc) : Quaternion ℝ)
          * star (ω (⟨t, ht⟩, y, 3) : Quaternion ℝ) * star (ω (⟨t, ht⟩, x, i.castSucc) : Quaternion ℝ)).re := by
  simp only [physSp, physT, dif_pos ht, dif_pos hs, plaqE_quat']
  rw [re_reverse']

theorem plaq_sp {N hT : ℕ} (ω : PhysLink N hT → SU2) (t : ℕ) (ht : t < 2 * hT)
    (x y z : Fin 3 → Fin N) (i j : Fin 3) :
    plaqE (physSp ω t x i) (physSp ω t y j) (physSp ω t z i) (physSp ω t x j)
      = 1 - ((ω (⟨t, ht⟩, x, i.castSucc) : Quaternion ℝ) * (ω (⟨t, ht⟩, y, j.castSucc) : Quaternion ℝ)
          * star (ω (⟨t, ht⟩, z, i.castSucc) : Quaternion ℝ) * star (ω (⟨t, ht⟩, x, j.castSucc) : Quaternion ℝ)).re := by
  simp only [physSp, dif_pos ht, plaqE_quat']

set_option maxHeartbeats 3200000 in
theorem site_identity [Fact (1 < 2 * h)] (ω : PhysLink (2 * h) h → SU2) (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) :
    siteSum h (pull h ω) (psi h p) + pointSum h ω p = 6 := by
  obtain ⟨t, x⟩ := p
  have s1 : ∀ d, toPhys h (psi h (t, x) + TorusRP.ev (2 * h) 1, d) = (t, x + Pi.single 0 1, dirOf d) :=
    fun d => toPhys_psi_space h (t, x) 0 d
  have s2 : ∀ d, toPhys h (psi h (t, x) + TorusRP.ev (2 * h) 2, d) = (t, x + Pi.single 1 1, dirOf d) :=
    fun d => toPhys_psi_space h (t, x) 1 d
  have s3 : ∀ d, toPhys h (psi h (t, x) + TorusRP.ev (2 * h) 3, d) = (t, x + Pi.single 2 1, dirOf d) :=
    fun d => toPhys_psi_space h (t, x) 2 d
  have s0 := toPhys_psi_time h (t, x)
  have sp := toPhys_psi h (t, x)
  have hsc := sc_lt h t.val t.isLt
  simp only [siteSum, pointSum, Fin.sum_univ_four, Fin.sum_univ_three, ← Finset.filter_lt_eq_Ioi,
    Finset.sum_filter, plaq_tm ω t.val (sc h t.val) t.isLt hsc, plaq_sp ω t.val t.isLt, Fin.eta]
  simp only [TorusRP.hol, TorusRP.holQ, TorusRP.Uq, pull, TorusRP.incl, s0, s1, s2, s3, sp, ev, dirOf]
  simp (config := { decide := true }) only [if_true, if_false, ite_true, ite_false, add_zero, zero_add]
  ring

/-- **the two Wilson actions agree**: `Σ_{μ<ν} Re U_μν + Σ_p (1 − ½ Re tr U_p) (this column) = 6 (2h)⁴`
on the isotropic torus `N = 2h`, for every configuration of this column -/
theorem action_add_wilsonAction [Fact (1 < 2 * h)] (ω : PhysLink (2 * h) h → SU2) :
    TorusRP.action (2 * h) (pull h ω) + wilsonAction (2 * h) h ω
      = 6 * ((2 * h : ℕ) : ℝ) * ((2 * h : ℕ) : ℝ) ^ 3 := by
  rw [action_eq_sum, wilsonAction_eq_sum, ← Finset.sum_add_distrib]
  rw [Finset.sum_congr rfl fun p _ => site_identity h ω p]
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_prod, Fintype.card_fin, Fintype.card_fun,
    nsmul_eq_mul]
  push_cast
  ring

theorem coe_inv_su2 (g : SU2) : ((g⁻¹ : SU2) : Quaternion ℝ) = star (g : Quaternion ℝ) := by
  have hn : ‖(g : Quaternion ℝ)‖ = 1 := mem_sphere_zero_iff_norm.mp g.2
  have h1 : (g : Quaternion ℝ) * star (g : Quaternion ℝ) = 1 := by
    rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hn]
    simp
  rw [Metric.unitSphere.coe_inv, inv_eq_of_mul_eq_one_right h1]

theorem dirOf_lt (d : Fin 4) (hd : d ≠ 0) : (dirOf d).val < 3 := by
  fin_cases d <;> simp_all [dirOf]

theorem dirOf_zero : dirOf 0 = 3 := by simp [dirOf]

theorem toPhys_thS (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (d : Fin 4) :
    toPhys h (TorusRP.thS (2 * h) (psi h p), d) = (⟨th h p.1.val, th_lt h p.1.val p.1.isLt⟩, p.2, dirOf d) := by
  have es : ∀ k : Fin 3, TorusRP.thS (2 * h) (psi h p) k.succ = ((p.2 k).val : ZMod (2 * h)) := fun k => by
    simp [TorusRP.thS, psi, Fin.succ_ne_zero]
  have e0 : TorusRP.thS (2 * h) (psi h p) 0 = -((p.1.val : ZMod (2 * h))) := by
    simp [TorusRP.thS, psi]
  simp only [toPhys, es, e0, zf_cast]
  congr 1
  apply Fin.ext
  show (-((p.1.val : ZMod (2 * h)))).val = th h p.1.val
  have hv : ((p.1.val : ZMod (2 * h))).val = p.1.val := by
    rw [ZMod.val_natCast, Nat.mod_eq_of_lt p.1.isLt]
  unfold th
  by_cases h0 : p.1.val = 0
  · rw [if_pos h0]
    have : ((p.1.val : ZMod (2 * h))) = 0 := by rw [h0, Nat.cast_zero]
    rw [this, neg_zero, ZMod.val_zero]
  · rw [if_neg h0, TorusRP.val_neg' (2 * h) _ (by rw [hv]; exact h0), hv]

theorem toPhys_thS_time (p : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (d : Fin 4) :
    toPhys h (TorusRP.thS (2 * h) (psi h p) - TorusRP.ev (2 * h) 0, d)
      = (⟨2 * h - 1 - p.1.val, by have := p.1.isLt; omega⟩, p.2, dirOf d) := by
  have es : ∀ k : Fin 3, (TorusRP.thS (2 * h) (psi h p) - TorusRP.ev (2 * h) 0) k.succ
      = ((p.2 k).val : ZMod (2 * h)) := fun k => by
    simp [TorusRP.thS, psi, TorusRP.ev, Fin.succ_ne_zero, Pi.single_apply]
  have e0 : (TorusRP.thS (2 * h) (psi h p) - TorusRP.ev (2 * h) 0) 0 = -((p.1.val : ZMod (2 * h))) - 1 := by
    simp [TorusRP.thS, psi, TorusRP.ev]
  simp only [toPhys, es, e0, zf_cast]
  congr 1
  apply Fin.ext
  show (-((p.1.val : ZMod (2 * h))) - 1).val = 2 * h - 1 - p.1.val
  rw [TorusRP.val_neg_sub_one, ZMod.val_natCast, Nat.mod_eq_of_lt p.1.isLt]

/-- **the reflections agree**: the `linkRefl thL sig` of the pulled-back configuration is the pull-back of
`thetaPhys ω` (as quaternions) -/
theorem refl_pull (ω : PhysLink (2 * h) h → SU2) (ℓ : TorusRP.Lk (2 * h)) :
    ((LinkReflection.linkRefl (TorusRP.thL (2 * h)) (TorusRP.sig (2 * h)) (pull h ω) ℓ : TorusRP.QBall)
        : Quaternion ℝ)
      = ((pull h (thetaPhys ω) ℓ : TorusRP.QBall) : Quaternion ℝ) := by
  obtain ⟨y, d⟩ := ℓ
  obtain ⟨p, hp⟩ := (siteEquiv h).surjective y
  have hy : y = psi h p := hp.symm
  subst hy
  rw [TorusRP.refl_apply]
  by_cases hd : d = 0
  · subst hd
    rw [if_pos rfl]
    have e1 : TorusRP.thL (2 * h) (psi h p, 0) = (TorusRP.thS (2 * h) (psi h p) - TorusRP.ev (2 * h) 0, 0) := by
      unfold TorusRP.thL
      rw [if_pos rfl]
    have hμ : ¬ ((dirOf 0).val < 3) := by rw [dirOf_zero]; decide
    rw [e1]
    simp only [pull, TorusRP.incl, toPhys_thS_time, toPhys_psi, thetaPhys, if_neg hμ, coe_inv_su2]
  · rw [if_neg hd]
    have e1 : TorusRP.thL (2 * h) (psi h p, d) = (TorusRP.thS (2 * h) (psi h p), d) := by
      unfold TorusRP.thL
      rw [if_neg hd]
    rw [e1]
    simp only [pull, TorusRP.incl, toPhys_thS, toPhys_psi, thetaPhys, if_pos (dirOf_lt d hd)]

/-- the directions as an equivalence -/
noncomputable def dirEquiv : Fin 4 ≃ Fin 4 := Equiv.ofBijective dirOf (by decide)

/-- `toPhys` as an equivalence of the link sets -/
noncomputable def linkEquivM : TorusRP.Lk (2 * h) ≃ PhysLink (2 * h) h :=
  ((siteEquiv h).symm.prodCongr dirEquiv).trans (Equiv.prodAssoc _ _ _)

theorem toPhys_eq (ℓ : TorusRP.Lk (2 * h)) : toPhys h ℓ = linkEquivM h ℓ := rfl

open MeasureTheory in
/-- **the reference measures agree**: pulling back `Π_{physical links} Haar` gives the `Π_ℓ haarBall` -/
theorem map_pull :
    Measure.map (pull h) (Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2))
      = Measure.pi fun _ : TorusRP.Lk (2 * h) => TorusRP.haarBall := by
  have h1 := measurePreserving_piCongrLeft (fun _ : TorusRP.Lk (2 * h) => (Measure.haarMeasure ⊤ : Measure SU2))
    (linkEquivM h).symm
  have hinc : Measurable fun f : TorusRP.Lk (2 * h) → SU2 => fun ℓ => TorusRP.incl (f ℓ) :=
    measurable_pi_lambda _ fun ℓ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply ℓ)
  have hpull : pull h = (fun f : TorusRP.Lk (2 * h) → SU2 => fun ℓ => TorusRP.incl (f ℓ))
      ∘ (MeasurableEquiv.piCongrLeft (fun _ => SU2) (linkEquivM h).symm) := by
    funext ω ℓ
    simp only [Function.comp, pull, LinkReflection.piCongrLeft_const, Equiv.symm_symm, toPhys_eq]
  rw [hpull, ← Measure.map_map hinc h1.measurable, h1.map_eq]
  rw [Measure.pi_map_pi (fun _ => TorusRP.continuous_incl.measurable.aemeasurable)]
  rfl

open MeasureTheory in
theorem measurable_pull : Measurable (pull h) :=
  measurable_pi_lambda _ fun ℓ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply _)

open MeasureTheory in
theorem map_withDensity_pull (G : (TorusRP.Lk (2 * h) → TorusRP.QBall) → ENNReal) (hG : Measurable G) :
    Measure.map (pull h) ((Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2)).withDensity
        fun ω => G (pull h ω))
      = (Measure.pi fun _ : TorusRP.Lk (2 * h) => TorusRP.haarBall).withDensity G := by
  ext s hs
  rw [Measure.map_apply (measurable_pull h) hs, withDensity_apply _ (measurable_pull h hs),
    withDensity_apply _ hs, ← map_pull h, setLIntegral_map hs hG (measurable_pull h)]

/-- the pure-gauge Wilson measure of this column: `Π Haar` with density `exp(−β S_W)` -/
noncomputable def gaugeMeasure (β : ℝ) : MeasureTheory.Measure (PhysLink (2 * h) h → SU2) :=
  (MeasureTheory.Measure.pi fun _ : PhysLink (2 * h) h => (MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure SU2)).withDensity
    fun ω => ENNReal.ofReal (Real.exp (-β * wilsonAction (2 * h) h ω))

open MeasureTheory in
/-- **the two Wilson measures are the same up to the constant `e^{β·6(2h)⁴}`**: the `wilsonMeasure` is the
push-forward of this column's pure-gauge Wilson measure along `pull` (isotropic `N = 2h`) -/
theorem wilsonMeasure_eq_map [Fact (1 < 2 * h)] (β : ℝ) :
    TorusRP.wilsonMeasure (2 * h) β
      = ENNReal.ofReal (Real.exp (β * (6 * ((2 * h : ℕ) : ℝ) * ((2 * h : ℕ) : ℝ) ^ 3)))
        • Measure.map (pull h) (gaugeMeasure h β) := by
  set C : ℝ := 6 * ((2 * h : ℕ) : ℝ) * ((2 * h : ℕ) : ℝ) ^ 3 with hC
  have hG : Measurable fun ω' => ((Real.toNNReal (TorusRP.wilsonWeight (2 * h) β ω')) : ENNReal) :=
    (TorusRP.continuous_wilsonWeight (2 * h) β).measurable.real_toNNReal.coe_nnreal_ennreal
  have hS : ∀ ω, wilsonAction (2 * h) h ω = C - TorusRP.action (2 * h) (pull h ω) := fun ω => by
    have := action_add_wilsonAction h ω
    rw [hC]; linarith
  have hf : (fun ω : PhysLink (2 * h) h → SU2 => ENNReal.ofReal (Real.exp (-β * wilsonAction (2 * h) h ω)))
      = (fun ω' => ENNReal.ofReal (Real.exp (-β * C) * TorusRP.wilsonWeight (2 * h) β ω')) ∘ pull h := by
    funext ω
    simp only [Function.comp, TorusRP.wilsonWeight, hS ω, ← Real.exp_add]
    congr 2
    ring
  have hfm : Measurable fun ω : PhysLink (2 * h) h → SU2 => ENNReal.ofReal (Real.exp (-β * wilsonAction (2 * h) h ω)) := by
    rw [hf]
    exact (ENNReal.measurable_ofReal.comp (measurable_const.mul
      (TorusRP.continuous_wilsonWeight (2 * h) β).measurable)).comp (measurable_pull h)
  unfold gaugeMeasure TorusRP.wilsonMeasure
  rw [← Measure.map_smul, ← withDensity_smul _ hfm, ← map_withDensity_pull h _ hG]
  congr 2
  funext ω
  simp only [Pi.smul_apply, smul_eq_mul]
  rw [← ENNReal.ofReal_mul (Real.exp_pos _).le, ← Real.exp_add]
  show ENNReal.ofReal (TorusRP.wilsonWeight (2 * h) β (pull h ω)) = _
  unfold TorusRP.wilsonWeight
  congr 2
  rw [hS ω]
  ring

end Match

end WilsonGauge

namespace WilsonGauge

open MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection FineSupportReflection

variable (h : ℕ) [NeZero (2 * h)]

theorem toPhys_mem_posSide (hpos : 0 < h) (ℓ : TorusRP.Lk (2 * h)) :
    (TorusRP.fixP (2 * h) h ℓ ∨ TorusRP.posP (2 * h) h ℓ) → toPhys h ℓ ∈ posSide (2 * h) h := by
  obtain ⟨y, d⟩ := ℓ
  intro hfp
  have ht : (y 0).val < 2 * h := ZMod.val_lt _
  simp only [posSide, Set.mem_setOf_eq, toPhys]
  by_cases hd : d = 0
  · subst hd
    have hlt : (y 0).val < h := by
      rcases hfp with hf | hp
      · exact absurd rfl hf.1
      · simpa [TorusRP.posP, TorusRP.tm] using hp
    have e : dirOf 0 = 3 := dirOf_zero
    rw [e, linkClass_tm_pos (N := 2 * h) (zf h (y 0)) _ hlt]
    trivial
  · have hle : (y 0).val ≤ h := by
      rcases hfp with hf | hp
      · rcases hf.2 with h0 | h1
        · simp only [TorusRP.tm] at h0; omega
        · simp only [TorusRP.tm] at h1; omega
      · simp only [TorusRP.posP, TorusRP.tm, if_neg hd] at hp; omega
    have hμ := dirOf_lt d hd
    have e : dirOf d = (⟨(dirOf d).val, hμ⟩ : Fin 3).castSucc := Fin.ext rfl
    rw [e]
    by_cases h0 : (y 0).val = 0
    · rw [linkClass_sp_zero (zf h (y 0)) _ _ h0]; trivial
    · by_cases hh : (y 0).val = h
      · rw [linkClass_sp_half (zf h (y 0)) _ _ hh hpos]; trivial
      · rw [linkClass_sp_pos (zf h (y 0)) _ _ (by show 0 < (y 0).val; omega) (by show (y 0).val < h; omega)]
        trivial

theorem gaugeMeasure_eq (hpos : 0 < h) (β : ℝ) : gaugeMeasure h β = wfMeasure (2 * h) h 0 0 β := by
  unfold gaugeMeasure wfMeasure
  congr 1
  funext ω
  have e : wfWeight (2 * h) h 0 0 β ω = Real.exp (-β * wilsonAction (2 * h) h ω) := by
    simp [wfWeight]
  rw [e]
  rfl

/-- **the site reflection positivity of the Wilson measure, derived from this column** -/
theorem wilson_rp_from_column [Fact (1 < 2 * h)] (hpos : 0 < h) (β : ℝ)
    (f : (TorusRP.Lk (2 * h) → TorusRP.QBall) → ℝ) (hf : Measurable f)
    (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, TorusRP.fixP (2 * h) h ℓ ∨ TorusRP.posP (2 * h) h ℓ → ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (LinkReflection.linkRefl (TorusRP.thL (2 * h)) (TorusRP.sig (2 * h)) ω) * f ω
      ∂(TorusRP.wilsonMeasure (2 * h) β) := by
  have hp := measurable_pull h
  have hR : ∀ ω, LinkReflection.linkRefl (TorusRP.thL (2 * h)) (TorusRP.sig (2 * h)) (pull h ω)
      = pull h (thetaPhys ω) := fun ω => funext fun ℓ => Subtype.ext (refl_pull h ω ℓ)
  have hRm : Measurable (LinkReflection.linkRefl (TorusRP.thL (2 * h)) (TorusRP.sig (2 * h))
      : (TorusRP.Lk (2 * h) → TorusRP.QBall) → (TorusRP.Lk (2 * h) → TorusRP.QBall)) := by
    refine measurable_pi_lambda _ fun ℓ => ?_
    unfold LinkReflection.linkRefl TorusRP.sig
    split_ifs
    · exact TorusRP.continuous_starB.measurable.comp (measurable_pi_apply _)
    · exact measurable_pi_apply _
  have hm : Measurable fun ω' : TorusRP.Lk (2 * h) → TorusRP.QBall =>
      f (LinkReflection.linkRefl (TorusRP.thL (2 * h)) (TorusRP.sig (2 * h)) ω') * f ω' :=
    (hf.comp hRm).mul hf
  rw [wilsonMeasure_eq_map, integral_smul_measure, integral_map hp.aemeasurable hm.aestronglyMeasurable]
  refine smul_nonneg ENNReal.toReal_nonneg ?_
  simp only [hR]
  rw [gaugeMeasure_eq h hpos β]
  have hF : DependsOn (posSide (2 * h) h) (fun ω => f (pull h ω)) := by
    intro ω ω' heq
    apply hfdep
    intro ℓ hℓ
    simp only [pull]
    rw [heq _ (toPhys_mem_posSide h hpos ℓ hℓ)]
  exact fineRP_wilson_fermion (2 * h) h (by omega) 0 0 (by norm_num) β (fun ω => f (pull h ω))
    (hf.comp hp) ⟨Cf, fun ω => hfC _⟩ hF

end WilsonGauge

#print axioms WilsonGauge.refl_pull
#print axioms WilsonGauge.toPhys_mem_posSide
#print axioms WilsonGauge.wilson_rp_from_column
#print axioms WilsonGauge.fineRP_wilson_fermion_prob
