import Mathlib

/-!
# One-dimensional minimal lift with block-average constraints: the block-level matrix

Paper (T8, d = 1, scalar): on `ℤ` with blocks `B_b = {bL, …, bL + L − 1}`, minimising
`Σ (f_{x+1} − f_x)²` under `(1/L) Σ_{x ∈ B_b} f_x = z_b` gives `−Δ f = μ_{b(x)}`, so
`f = Σ_b μ_b g_b + (affine)`, `g_b(x) = −½ Σ_{y ∈ B_b} |x − y|`. Inserting into the constraint gives
the block-level matrix `m(d) = −(1/(2L)) Σ_{x ∈ B_0, y ∈ B_d} |x − y|`. This file proves:
* `bsum_pos`: `Σ_{x,y < L} |x − (y + dL)| = d L³` for `d ≥ 1`; `bsum_zero`: `3 Σ_{x,y<L} |x − y| = L³ − L`;
  `bsum_neg`: symmetric in `d`;
* `mB` (the block matrix) `= −|d| L²/2` for `d ≠ 0` and `−(L² − 1)/6` for `d = 0`;
* `lapB_zero`, `lapB_one`, `lapB_far`: the second difference in the block index is tridiagonal,
  `−(2L² + 1)/3` on the diagonal, `−(L² − 1)/6` next to it, `0` beyond;
* `decay_root`: `ρ_L = (−s + √(s² − 4))/2`, `s = 4 + 6/(L² − 1)`, solves
  `(L² − 1)(ρ + 1/ρ) + 2(2L² + 1) = 0` and `|ρ_L| ≤ 2 − √3` for every `L ≥ 2`.
Not stated here: the KKT step (that the minimiser has this form) and the row sum of the lift.
-/

namespace BlockLift

open Finset

/-- `Σ_{x, y < L} |x − (y + d L)|`. -/
def bsum (L : ℕ) (d : ℤ) : ℤ := ∑ x ∈ range L, ∑ y ∈ range L, |(x : ℤ) - ((y : ℤ) + d * L)|

theorem sum_sub_zero (L : ℕ) :
    ∑ x ∈ range L, ∑ y ∈ range L, ((y : ℤ) - (x : ℤ)) = 0 := by
  simp only [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  rw [Finset.mul_sum, sub_self]

theorem bsum_pos (L : ℕ) (d : ℕ) (hd : 1 ≤ d) : bsum L d = (d : ℤ) * L ^ 3 := by
  unfold bsum
  have h : ∀ x ∈ range L, ∀ y ∈ range L,
      |(x : ℤ) - ((y : ℤ) + (d : ℤ) * L)| = (d : ℤ) * L + ((y : ℤ) - (x : ℤ)) := by
    intro x hx y _
    have hx' : (x : ℤ) < L := by exact_mod_cast Finset.mem_range.1 hx
    have hdL : (L : ℤ) ≤ (d : ℤ) * L := by
      have : (1 : ℤ) ≤ d := by exact_mod_cast hd
      nlinarith [(Nat.cast_nonneg L : (0 : ℤ) ≤ L)]
    rw [abs_of_neg (by nlinarith [(Nat.cast_nonneg y : (0 : ℤ) ≤ y)])]
    ring
  rw [Finset.sum_congr rfl fun x hx => Finset.sum_congr rfl fun y hy => h x hx y hy]
  simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  rw [sum_sub_zero]
  ring

theorem twice_sum_sub (L : ℕ) : 2 * ∑ x ∈ range L, ((L : ℤ) - x) = (L : ℤ) * (L + 1) := by
  induction L with
  | zero => simp
  | succ L ih =>
    rw [Finset.sum_range_succ]
    have hx : ∀ x : ℕ, (((L + 1 : ℕ) : ℤ) - x) = ((L : ℤ) - x) + 1 := fun x => by push_cast; ring
    simp only [hx, Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, nsmul_eq_mul,
      mul_one]
    push_cast
    nlinarith [ih]

theorem bsum_succ_zero (L : ℕ) : bsum (L + 1) 0 = bsum L 0 + (L : ℤ) * (L + 1) := by
  unfold bsum
  simp only [zero_mul, add_zero]
  rw [Finset.sum_range_succ]
  simp only [Finset.sum_range_succ, Finset.sum_add_distrib]
  have h1 : ∑ x ∈ range L, |(x : ℤ) - (L : ℤ)| = ∑ x ∈ range L, ((L : ℤ) - x) := by
    refine Finset.sum_congr rfl fun x hx => ?_
    have : (x : ℤ) < L := by exact_mod_cast Finset.mem_range.1 hx
    rw [abs_of_neg (by linarith)]; ring
  have h2 : ∑ y ∈ range L, |(L : ℤ) - (y : ℤ)| = ∑ x ∈ range L, ((L : ℤ) - x) := by
    refine Finset.sum_congr rfl fun x hx => ?_
    have : (x : ℤ) < L := by exact_mod_cast Finset.mem_range.1 hx
    rw [abs_of_pos (by linarith)]
  rw [h1, h2, sub_self, abs_zero, add_zero]
  have := twice_sum_sub L
  linarith

theorem bsum_zero (L : ℕ) : 3 * bsum L 0 = (L : ℤ) ^ 3 - L := by
  induction L with
  | zero => simp [bsum]
  | succ L ih => rw [bsum_succ_zero]; push_cast; nlinarith [ih]

theorem bsum_neg (L : ℕ) (d : ℤ) : bsum L (-d) = bsum L d := by
  unfold bsum
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun x _ => ?_
  rw [← abs_neg]; congr 1; ring

/-- `|d| L³` for every `d ≠ 0`. -/
theorem bsum_ne (L : ℕ) (d : ℤ) (hd : d ≠ 0) : bsum L d = |d| * (L : ℤ) ^ 3 := by
  rcases lt_or_gt_of_ne hd with h | h
  · have h' : 0 < -d := by linarith
    rw [← bsum_neg, show -d = ((-d).toNat : ℤ) by omega, bsum_pos L _ (by omega),
      abs_of_neg h]
    congr 1; omega
  · rw [show d = (d.toNat : ℤ) by omega, bsum_pos L _ (by omega)]
    congr 1; rw [abs_of_pos (by omega)]

/-- The block-level matrix `m(d) = −(1/(2L)) Σ_{x ∈ B_0, y ∈ B_d} |x − y|`. -/
noncomputable def mB (L : ℕ) (d : ℤ) : ℚ := -((bsum L d : ℚ)) / (2 * L)

theorem mB_ne (L : ℕ) (hL : 1 ≤ L) (d : ℤ) (hd : d ≠ 0) : mB L d = -(|d| : ℚ) * (L : ℚ) ^ 2 / 2 := by
  have hL' : (L : ℚ) ≠ 0 := Nat.cast_ne_zero.2 (by omega)
  unfold mB; rw [bsum_ne L d hd]; push_cast; field_simp

theorem mB_zero (L : ℕ) (hL : 1 ≤ L) : mB L 0 = -(((L : ℚ) ^ 2 - 1) / 6) := by
  have hL' : (L : ℚ) ≠ 0 := Nat.cast_ne_zero.2 (by omega)
  have h := bsum_zero L
  have h3 : (bsum L 0 : ℚ) = ((L : ℚ) ^ 3 - L) / 3 := by
    have : ((3 * bsum L 0 : ℤ) : ℚ) = (((L : ℤ) ^ 3 - L : ℤ) : ℚ) := by rw [h]
    push_cast at this; linarith
  unfold mB; rw [h3]; field_simp; ring

/-- Second difference in the block index. -/
noncomputable def lapB (L : ℕ) (d : ℤ) : ℚ := mB L (d + 1) - 2 * mB L d + mB L (d - 1)

theorem lapB_zero (L : ℕ) (hL : 1 ≤ L) : lapB L 0 = -((2 * (L : ℚ) ^ 2 + 1) / 3) := by
  unfold lapB
  rw [mB_ne L hL _ (by norm_num), mB_zero L hL, mB_ne L hL _ (by norm_num)]
  norm_num; ring

theorem lapB_one (L : ℕ) (hL : 1 ≤ L) : lapB L 1 = -(((L : ℚ) ^ 2 - 1) / 6) := by
  unfold lapB
  rw [mB_ne L hL _ (by norm_num), mB_ne L hL _ (by norm_num), show (1 : ℤ) - 1 = 0 by norm_num,
    mB_zero L hL]
  norm_num; ring

theorem lapB_neg (L : ℕ) (d : ℤ) : lapB L (-d) = lapB L d := by
  have h : ∀ e : ℤ, mB L (-e) = mB L e := fun e => by unfold mB; rw [bsum_neg]
  unfold lapB
  rw [show -d + 1 = -(d - 1) by ring, show -d - 1 = -(d + 1) by ring, h, h, h]
  ring

theorem lapB_far_pos (L : ℕ) (hL : 1 ≤ L) (d : ℤ) (h2 : 2 ≤ d) : lapB L d = 0 := by
  unfold lapB
  rw [mB_ne L hL _ (by omega), mB_ne L hL _ (by omega), mB_ne L hL _ (by omega)]
  have e1 : |((d + 1 : ℤ) : ℚ)| = (d : ℚ) + 1 := by
    rw [abs_of_pos (by exact_mod_cast (by omega : (0 : ℤ) < d + 1))]; push_cast; ring
  have e2 : |((d : ℤ) : ℚ)| = (d : ℚ) := abs_of_pos (by exact_mod_cast (by omega : (0 : ℤ) < d))
  have e3 : |((d - 1 : ℤ) : ℚ)| = (d : ℚ) - 1 := by
    rw [abs_of_pos (by exact_mod_cast (by omega : (0 : ℤ) < d - 1))]; push_cast; ring
  rw [e1, e2, e3]; ring

theorem lapB_far (L : ℕ) (hL : 1 ≤ L) (d : ℤ) (hd : 2 ≤ |d|) : lapB L d = 0 := by
  rcases le_or_gt 0 d with h | h
  · exact lapB_far_pos L hL d (by rwa [abs_of_nonneg h] at hd)
  · rw [← lapB_neg]; exact lapB_far_pos L hL (-d) (by rw [abs_of_neg h] at hd; exact hd)

/-! ## The decay ratio of the block multipliers -/

/-- `s_L = 4 + 6/(L² − 1)`. -/
noncomputable def sL (L : ℕ) : ℝ := 4 + 6 / ((L : ℝ) ^ 2 - 1)

/-- The root `ρ_L ∈ (−1, 0)` of `ρ² + s_L ρ + 1 = 0`. -/
noncomputable def rhoL (L : ℕ) : ℝ := (-sL L + Real.sqrt (sL L ^ 2 - 4)) / 2

theorem decay_root (L : ℕ) (hL : 2 ≤ L) :
    ((L : ℝ) ^ 2 - 1) * (rhoL L + 1 / rhoL L) + 2 * (2 * (L : ℝ) ^ 2 + 1) = 0 ∧
      rhoL L < 0 ∧ |rhoL L| ≤ 2 - Real.sqrt 3 := by
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hD : 0 < (L : ℝ) ^ 2 - 1 := by linarith
  have hs4 : 4 ≤ sL L := by
    unfold sL; have : 0 ≤ 6 / ((L : ℝ) ^ 2 - 1) := by positivity
    linarith
  set s := sL L with hsdef
  have hq : 0 ≤ s ^ 2 - 4 := by nlinarith
  set q := Real.sqrt (s ^ 2 - 4) with hqdef
  have hq2 : q ^ 2 = s ^ 2 - 4 := Real.sq_sqrt hq
  have hq0 : 0 ≤ q := Real.sqrt_nonneg _
  have hqs : q < s := by nlinarith
  have hρ : rhoL L = (-s + q) / 2 := rfl
  have hneg : rhoL L < 0 := by rw [hρ]; linarith
  have hquad : rhoL L ^ 2 + s * rhoL L + 1 = 0 := by rw [hρ]; nlinarith [hq2]
  refine ⟨?_, hneg, ?_⟩
  · have hne : rhoL L ≠ 0 := hneg.ne
    have hinv : rhoL L + 1 / rhoL L = -s := by
      field_simp
      nlinarith [hquad]
    rw [hinv, hsdef, sL]
    field_simp
    ring
  · rw [abs_of_neg hneg, hρ]
    have h3 : Real.sqrt 3 ^ 2 = 3 := Real.sq_sqrt (by norm_num)
    have h30 : 0 ≤ Real.sqrt 3 := Real.sqrt_nonneg _
    have h3lt : Real.sqrt 3 < 2 := by nlinarith
    -- need s − q ≤ 4 − 2√3, i.e. q ≥ s − 4 + 2√3 (both sides ≥ 0)
    have hrhs : 0 ≤ s - 4 + 2 * Real.sqrt 3 := by linarith
    have key : (s - 4 + 2 * Real.sqrt 3) ^ 2 ≤ q ^ 2 := by
      rw [hq2]; nlinarith [mul_nonneg (by linarith : (0:ℝ) ≤ s - 4) (by linarith : (0:ℝ) ≤ 2 - Real.sqrt 3)]
    have : s - 4 + 2 * Real.sqrt 3 ≤ q := by
      nlinarith [key, hrhs, hq0]
    linarith

end BlockLift

#print axioms BlockLift.bsum_pos
#print axioms BlockLift.bsum_zero
#print axioms BlockLift.lapB_zero
#print axioms BlockLift.lapB_one
#print axioms BlockLift.lapB_far
#print axioms BlockLift.decay_root
