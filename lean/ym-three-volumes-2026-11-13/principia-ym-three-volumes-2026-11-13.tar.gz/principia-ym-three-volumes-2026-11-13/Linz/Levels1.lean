import Linz.Bridge1

/-!
# Every level of the stage push: the box block map at level `j`, linearised, is the step operator

`LatticePush.pushOp m N` composes the steps `stepOp N`, `stepOp (2N)`, `stepOp (2(2N))`, …; the
`j`-th one is `stepOp (fine j N)` (`fine j N = 2^j N`, `LatticePush.fine_eq`; `pushOp_succ`).
`level_linearised`: for the box chain with base `N`, the block map at level `j` (coarse sites
`(ZMod (2^j N))⁴`) linearised at `U = 1` is, colour by colour, the operator
`Cop (betaT 4 (fine j N)) (pathKernel (2 · fine j N))` of `stepOp (fine j N)`, after identifying
`ZMod (2^j N) ≃ ZMod (fine j N)` on the coarse sites and `ZMod (2^(j+1) N) ≃ ZMod (2 · fine j N)` on
the fine sites (`ZMod.ringEquivCongr`). `cop_transport` is the general transport of `Cop` along such
identifications.
-/

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear

local notation "ℍr" => Quaternion ℝ

theorem pushOp_succ (m L : ℕ) [NeZero L]
    (T : LatticePush.Fld (LatticePush.fine (m + 1) L) → LatticePush.Fld (LatticePush.fine (m + 1) L)) :
    LatticePush.pushOp (m + 1) L T = LatticePush.stepOp L (LatticePush.pushOp m (2 * L) T) := rfl

section Transport

variable {p p' q q' : ℕ} [NeZero p] [NeZero p'] [NeZero q] [NeZero q']

/-- Sites carried along a ring identification. -/
def siteMap (e : ZMod q ≃+* ZMod q') : (Fin 4 → ZMod q) ≃ (Fin 4 → ZMod q') :=
  Equiv.piCongrRight fun _ => e.toEquiv

theorem siteMap_apply (e : ZMod q ≃+* ZMod q') (y : Fin 4 → ZMod q) :
    siteMap e y = fun j => e (y j) := rfl

theorem pathKernel_transport (e : ZMod q ≃+* ZMod q') (r : Fin 4 → ZMod q) (μ ν : Fin 4) :
    LatticeTorus.pathKernel q r μ ν = LatticeTorus.pathKernel q' (siteMap e r) μ ν := by
  have key : ∀ z : Fin 4 → ℤ, ((fun j => (z j : ZMod q)) = r ↔
      (fun j => (z j : ZMod q')) = siteMap e r) := fun z => by
    have hc : siteMap e (fun j => (z j : ZMod q)) = fun j => (z j : ZMod q') := by
      funext j; simp [siteMap_apply, map_intCast]
    rw [← hc, (siteMap e).injective.eq_iff]
  unfold LatticeTorus.pathKernel
  simp only [key]

/-- **Transport of the path-kernel operator** along identifications of the coarse and fine moduli
that intertwine the coarse-to-fine maps. -/
theorem cop_transport (eC : ZMod p ≃+* ZMod p') (eF : ZMod q ≃+* ZMod q') (β : ZMod p →+ ZMod q)
    (β' : ZMod p' →+ ZMod q') (hβ : ∀ x, eF (β x) = β' (eC x))
    (F : (Fin 4 → ZMod q') → Fin 4 → ℂ) (X : Fin 4 → ZMod p) (μ : Fin 4) :
    TorusFourier.Cop (β.compLeft (Fin 4)) (LatticeTorus.pathKernel q)
        (fun y ν => F (siteMap eF y) ν) X μ =
      TorusFourier.Cop (β'.compLeft (Fin 4)) (LatticeTorus.pathKernel q') F (siteMap eC X) μ := by
  unfold TorusFourier.Cop
  refine Fintype.sum_equiv (siteMap eF) _ _ (fun r => ?_)
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [pathKernel_transport eF r]
  dsimp only
  congr 2
  funext j
  simp only [siteMap_apply, Pi.add_apply, AddMonoidHom.compLeft_apply, Function.comp_apply,
    map_add, hβ]

end Transport

section Levels

variable (N : ℕ) [NeZero N] (j : ℕ)

/-- Coarse moduli of level `j`: `2^j N = fine j N`. -/
def eC : ZMod (2 ^ j * N) ≃+* ZMod (LatticePush.fine j N) :=
  ZMod.ringEquivCongr (LatticePush.fine_eq j N).symm

/-- Fine moduli of level `j`: `2^(j+1) N = 2 · fine j N`. -/
def eF : ZMod (2 ^ (j + 1) * N) ≃+* ZMod (2 * LatticePush.fine j N) :=
  ZMod.ringEquivCongr (by rw [LatticePush.fine_eq]; ring)

theorem double_intertwine (x : ZMod (2 ^ j * N)) :
    eF N j (BoxWalk.double N j x) = TorusFourier.dbl (LatticePush.fine j N) (eC N j x) := by
  rw [← ZMod.intCast_zmod_cast x, BoxWalk.double_intCast, map_intCast, map_intCast,
    TorusFourier.dbl_intCast]
  push_cast
  ring

/-- **Level `j` of the stage push is the linearised box block map at level `j`.** -/
theorem level_linearised {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (a : BoxWalk.BoxLk N (j + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk N j) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths N) (BoxWalk.boxW N) j (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx N j b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx N j b) a) : ℝ) : ℂ) =
      TorusFourier.Cop (TorusFourier.betaT 4 (LatticePush.fine j N))
        (LatticeTorus.pathKernel (2 * LatticePush.fine j N))
        (fun y ν => ((f (a ((siteMap (eF N j)).symm y, ν)) : ℝ) : ℂ))
        (siteMap (eC N j) b.1) b.2 := by
  obtain ⟨h1, h2⟩ := blockMap_exp_linear N hr hr0 j a ha hM0 hM hε hεM b
  refine ⟨h1, fun f => ?_⟩
  rw [h2 f]
  have := cop_transport (eC N j) (eF N j) (BoxWalk.double N j)
    (TorusFourier.dbl (LatticePush.fine j N)) (double_intertwine N j)
    (fun y ν => ((f (a ((siteMap (eF N j)).symm y, ν)) : ℝ) : ℂ)) b.1 b.2
  simp only [Equiv.symm_apply_apply] at this
  exact this

end Levels

end BlockLinearKernel

#print axioms BlockLinearKernel.cop_transport
#print axioms BlockLinearKernel.level_linearised
