import Linz.LiftKernel1

/-!
# Uniform bounds on the block coefficients of the one-dimensional minimal lift

For `L ≥ 2`: `0 < A L² ≤ 17`, `0 ≤ B L ≤ 9`, `0 ≤ μ_0 L² ≤ 10` (`coeff_bounds`), with `|ρ_L| ≤ 2 − √3`
(`decay_root`) and `|ρ_L| ≥ 1/6`. With `|u| ≤ L/2`, `|u² − κ| ≤ L²/4` the kernel of the lift at
offset `u` is bounded by `1 + 10/8` at `b = 0` and by `(9/2 + 17/8) |ρ|^{|b|}` for `b ≠ 0`
(`kernel_bound`), uniformly in `L`.
-/

namespace BlockLift

variable {L : ℕ}

theorem rho_range (hL : 2 ≤ L) : -(27 / 100 : ℝ) ≤ rhoL L ∧ rhoL L ≤ -(1 / 6 : ℝ) := by
  obtain ⟨-, hneg, habs⟩ := decay_root L hL
  have hq := quad_rho hL
  have h3 : (173 / 100 : ℝ) ≤ Real.sqrt 3 := by
    rw [show (173 / 100 : ℝ) = Real.sqrt ((173 / 100) ^ 2) by rw [Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_le_sqrt (by norm_num)
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hs6 : sL L ≤ 6 := by
    unfold sL
    have : 6 / ((L : ℝ) ^ 2 - 1) ≤ 2 := by
      rw [div_le_iff₀ (by linarith)]; linarith
    linarith
  have hs4 : 4 ≤ sL L := by
    unfold sL; have : 0 ≤ 6 / ((L : ℝ) ^ 2 - 1) := by
      apply div_nonneg <;> linarith
    linarith
  refine ⟨?_, ?_⟩
  · rw [abs_of_neg hneg] at habs; linarith
  · -- −s ρ = 1 + ρ² ≥ 1 and s ≤ 6
    have : -(sL L * rhoL L) ≥ 1 := by nlinarith [sq_nonneg (rhoL L)]
    nlinarith

theorem coeff_bounds (hL : 2 ≤ L) :
    (0 < cA L ∧ cA L * (L : ℝ) ^ 2 ≤ 17) ∧ (0 ≤ cB L ∧ cB L * L ≤ 9) ∧
      (0 ≤ 2 * cA L * rhoL L / (rhoL L - 1) ∧ 2 * cA L * rhoL L / (rhoL L - 1) * (L : ℝ) ^ 2 ≤ 10) := by
  obtain ⟨hlo, hhi⟩ := rho_range hL
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hL0 : (0 : ℝ) < L := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    linarith
  set ρ := rhoL L with hρ
  have hg : gam L = ((L : ℝ) ^ 2 + 2) / 3 := rfl
  set D0 := -(L : ℝ) ^ 2 * (ρ + 1) + gam L * (ρ - 3) with hD0
  have hD : D0 ≤ -(18 / 10) * (L : ℝ) ^ 2 := by
    rw [hD0, hg]; nlinarith
  have hpos : (3 / 10) * (L : ℝ) ^ 2 ≤ ρ * D0 := by nlinarith
  have hpos' : 0 < ρ * D0 := by nlinarith
  have hA : cA L = 4 * (1 - ρ) / (ρ * D0) := by
    unfold cA; rw [← hρ]; ring
  have hA0 : 0 < cA L := by rw [hA]; apply div_pos <;> linarith
  have hAL : cA L * (L : ℝ) ^ 2 ≤ 17 := by
    rw [hA, div_mul_eq_mul_div, div_le_iff₀ hpos']
    nlinarith
  have hB : cB L = (L : ℝ) / 2 * cA L * (1 + ρ) / (1 - ρ) := by
    unfold cB; rw [← hρ]
    have : ρ - 1 ≠ 0 := by linarith
    have : 1 - ρ ≠ 0 := by linarith
    field_simp; ring
  have h1r : 0 < 1 - ρ := by linarith
  refine ⟨⟨hA0, hAL⟩, ⟨?_, ?_⟩, ⟨?_, ?_⟩⟩
  · rw [hB]; apply div_nonneg _ h1r.le; apply mul_nonneg (mul_nonneg (by positivity) hA0.le); linarith
  · rw [hB, div_mul_eq_mul_div, div_le_iff₀ h1r]
    nlinarith [mul_pos hA0 hL0]
  · rw [show 2 * cA L * ρ / (ρ - 1) = 2 * cA L * (-ρ) / (1 - ρ) by
      have : ρ - 1 ≠ 0 := by linarith
      field_simp; ring]
    apply div_nonneg _ h1r.le; nlinarith
  · rw [show 2 * cA L * ρ / (ρ - 1) = 2 * cA L * (-ρ) / (1 - ρ) by
      have : ρ - 1 ≠ 0 := by linarith
      field_simp; ring]
    rw [div_mul_eq_mul_div, div_le_iff₀ h1r]
    nlinarith [hAL, hA0]


/-- The kernel of the lift: value at offset `u` of block `0` for `z = δ_{b}`
(translation: the `δ_0` solution read at block `−b`). -/
noncomputable def kerE (L : ℕ) (u : ℝ) (b : ℤ) : ℝ :=
  zK b + beK L (-b) * u - muK L (-b) / 2 * (u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12)

theorem u_sq_bound (hL : 2 ≤ L) {u : ℝ} (hu : |u| ≤ (L : ℝ) / 2) :
    |u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12| ≤ (L : ℝ) ^ 2 / 4 := by
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hu2 : u ^ 2 ≤ (L : ℝ) ^ 2 / 4 := by
    have h0 : 0 ≤ |u| := abs_nonneg u
    have := pow_le_pow_left₀ h0 hu 2
    rw [sq_abs] at this; nlinarith
  rw [abs_le]; constructor <;> nlinarith [sq_nonneg u]

/-- **Uniform pointwise bound on the kernel of the lift.** -/
theorem kernel_bound (hL : 2 ≤ L) {u : ℝ} (hu : |u| ≤ (L : ℝ) / 2) :
    |kerE L u 0| ≤ 1 + 10 / 8 ∧
      ∀ b : ℤ, b ≠ 0 → |kerE L u b| ≤ (9 / 2 + 17 / 8) * |rhoL L| ^ b.natAbs := by
  obtain ⟨⟨hA0, hAL⟩, ⟨hB0, hBL⟩, ⟨hm0, hmL⟩⟩ := coeff_bounds hL
  have hq := u_sq_bound hL hu
  have hL0 : (0 : ℝ) < L := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    linarith
  refine ⟨?_, fun b hb => ?_⟩
  · unfold kerE
    simp only [zK, beK, muK, neg_zero, if_true, ↓reduceIte, zero_mul, add_zero]
    calc |1 - 2 * cA L * rhoL L / (rhoL L - 1) / 2 * (u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12)|
        ≤ |(1 : ℝ)| + |2 * cA L * rhoL L / (rhoL L - 1) / 2 * (u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12)| :=
          abs_sub _ _
      _ ≤ 1 + 10 / 8 := by
          rw [abs_one, abs_mul, abs_div, abs_of_nonneg hm0, abs_two]
          have : 2 * cA L * rhoL L / (rhoL L - 1) / 2 * |u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12| ≤
              2 * cA L * rhoL L / (rhoL L - 1) / 2 * ((L : ℝ) ^ 2 / 4) :=
            mul_le_mul_of_nonneg_left hq (by positivity)
          nlinarith
  · have hnb : -b ≠ 0 := by omega
    have hn : (-b).natAbs = b.natAbs := Int.natAbs_neg b
    set r := |rhoL L| ^ b.natAbs with hr
    have hr0 : 0 ≤ r := by positivity
    have hbe : |beK L (-b)| = cB L * r := by
      unfold beK
      rw [if_neg hnb, hn, abs_mul, abs_mul, abs_of_nonneg hB0, abs_pow]
      split_ifs <;> simp [hr]
    have hmu : |muK L (-b)| = cA L * r := by
      unfold muK
      rw [if_neg hnb, hn, abs_mul, abs_of_pos hA0, abs_pow]
    unfold kerE
    simp only [zK, if_neg hb, zero_add]
    calc |beK L (-b) * u - muK L (-b) / 2 * (u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12)|
        ≤ |beK L (-b) * u| + |muK L (-b) / 2 * (u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12)| := abs_sub _ _
      _ = cB L * r * |u| + cA L * r / 2 * |u ^ 2 - ((L : ℝ) ^ 2 - 1) / 12| := by
          rw [abs_mul, abs_mul, abs_div, hbe, hmu, abs_two]
      _ ≤ cB L * r * ((L : ℝ) / 2) + cA L * r / 2 * ((L : ℝ) ^ 2 / 4) := by
          gcongr
      _ = r * (cB L * L / 2 + cA L * (L : ℝ) ^ 2 / 8) := by ring
      _ ≤ r * (9 / 2 + 17 / 8) := by
          apply mul_le_mul_of_nonneg_left _ hr0; linarith
      _ = (9 / 2 + 17 / 8) * r := by ring

/-- **Row sum of the lift over the blocks `−n, …, n`, uniform in `L` and `n`.** -/
theorem row_sum_bound (hL : 2 ≤ L) {u : ℝ} (hu : |u| ≤ (L : ℝ) / 2) (n : ℕ) :
    |kerE L u 0| + ∑ k ∈ Finset.range n, (|kerE L u ((k : ℤ) + 1)| + |kerE L u (-((k : ℤ) + 1))|) ≤
      1 + 10 / 8 + 2 * (9 / 2 + 17 / 8) * ((27 / 100) / (1 - 27 / 100)) := by
  obtain ⟨h0, hb⟩ := kernel_bound hL hu
  obtain ⟨hlo, hhi⟩ := rho_range hL
  set r := |rhoL L| with hr
  have hr0 : 0 ≤ r := abs_nonneg _
  have hr1 : r ≤ 27 / 100 := by rw [hr, abs_of_neg (by linarith)]; linarith
  have hterm : ∀ k : ℕ, |kerE L u ((k : ℤ) + 1)| + |kerE L u (-((k : ℤ) + 1))| ≤
      2 * (9 / 2 + 17 / 8) * r ^ (k + 1) := by
    intro k
    have e1 := hb ((k : ℤ) + 1) (by omega)
    have e2 := hb (-((k : ℤ) + 1)) (by omega)
    rw [show ((k : ℤ) + 1).natAbs = k + 1 by omega] at e1
    rw [show (-((k : ℤ) + 1)).natAbs = k + 1 by omega] at e2
    linarith
  have hgeom : ∑ k ∈ Finset.range n, r ^ (k + 1) ≤ (27 / 100) / (1 - 27 / 100) := by
    have h1 : ∑ k ∈ Finset.range n, r ^ (k + 1) = r * ∑ k ∈ Finset.range n, r ^ k := by
      rw [Finset.mul_sum]; refine Finset.sum_congr rfl fun k _ => by ring
    have h2 : ∑ k ∈ Finset.range n, r ^ k ≤ 1 / (1 - r) := by
      have := geom_sum_Ico_le_of_lt_one (m := 0) (n := n) hr0 (by linarith)
      simpa using this
    rw [h1]
    calc r * ∑ k ∈ Finset.range n, r ^ k ≤ r * (1 / (1 - r)) :=
          mul_le_mul_of_nonneg_left h2 hr0
      _ = r / (1 - r) := by ring
      _ ≤ (27 / 100) / (1 - 27 / 100) := by
          rw [div_le_div_iff₀ (by linarith) (by norm_num)]; nlinarith
  calc |kerE L u 0| + ∑ k ∈ Finset.range n, (|kerE L u ((k : ℤ) + 1)| + |kerE L u (-((k : ℤ) + 1))|)
      ≤ (1 + 10 / 8) + ∑ k ∈ Finset.range n, 2 * (9 / 2 + 17 / 8) * r ^ (k + 1) :=
        add_le_add h0 (Finset.sum_le_sum fun k _ => hterm k)
    _ = (1 + 10 / 8) + 2 * (9 / 2 + 17 / 8) * ∑ k ∈ Finset.range n, r ^ (k + 1) := by
        rw [Finset.mul_sum]
    _ ≤ _ := by nlinarith [hgeom]

end BlockLift

#print axioms BlockLift.rho_range
#print axioms BlockLift.coeff_bounds
#print axioms BlockLift.kernel_bound
#print axioms BlockLift.row_sum_bound
