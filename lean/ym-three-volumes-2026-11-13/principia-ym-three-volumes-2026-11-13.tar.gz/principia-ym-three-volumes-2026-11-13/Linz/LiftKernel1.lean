import Linz.BlockLift1

/-!
# The explicit block coefficients of the one-dimensional minimal lift satisfy the seam equations

Paper (T8, d = 1): on block `b` the lift is `z_b + β_b u − (μ_b/2)(u² − κ)`; the two seam equations
between blocks `b − 1` and `b` are
(A) `β_b − β_{b−1} = −(L/2)(μ_b + μ_{b−1})`,
(B) `2(z_b − z_{b−1}) = L(β_b + β_{b−1}) + (γ/2)(μ_b − μ_{b−1})`, `γ = (L² + 2)/3`.
For `z = δ_0` this file defines the decaying coefficients `μ_b = A ρ^{|b|}` (`b ≠ 0`),
`μ_0 = 2Aρ/(ρ − 1)`, `β_b = sgn(b) B ρ^{|b|}` with `ρ = ρ_L` (`BlockLift.rhoL`),
`B = −(L/2) A (ρ + 1)/(ρ − 1)`, `A = −4(ρ − 1)/(ρ(−L²(ρ + 1) + γ(ρ − 3)))`, and proves (A) and (B)
at every `b ∈ ℤ` (`seamA`, `seamB`).
Not stated here: that the minimiser has the block-quadratic form (KKT) and uniqueness.
-/

namespace BlockLift

variable (L : ℕ)

noncomputable def gam : ℝ := ((L : ℝ) ^ 2 + 2) / 3
noncomputable def cA : ℝ :=
  -4 * (rhoL L - 1) / (rhoL L * (-(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3)))
noncomputable def cB : ℝ := -((L : ℝ) / 2) * cA L * (rhoL L + 1) / (rhoL L - 1)

/-- `μ_b`. -/
noncomputable def muK (b : ℤ) : ℝ :=
  if b = 0 then 2 * cA L * rhoL L / (rhoL L - 1) else cA L * rhoL L ^ b.natAbs

/-- `β_b`. -/
noncomputable def beK (b : ℤ) : ℝ :=
  if b = 0 then 0 else (if 0 < b then 1 else -1) * cB L * rhoL L ^ b.natAbs

/-- `z = δ_0`. -/
noncomputable def zK (b : ℤ) : ℝ := if b = 0 then 1 else 0

section
variable {L}

theorem quad_rho (hL : 2 ≤ L) : rhoL L ^ 2 + sL L * rhoL L + 1 = 0 := by
  obtain ⟨h1, hneg, -⟩ := decay_root L hL
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hD : (L : ℝ) ^ 2 - 1 ≠ 0 := by linarith
  have hne : rhoL L ≠ 0 := hneg.ne
  unfold sL
  field_simp at h1 ⊢
  nlinarith [h1]

theorem rho_bounds (hL : 2 ≤ L) : -1 < rhoL L ∧ rhoL L < 0 := by
  obtain ⟨-, hneg, habs⟩ := decay_root L hL
  have h3 : 1 < Real.sqrt 3 := by
    rw [show (1 : ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  refine ⟨?_, hneg⟩
  have := neg_abs_le (rhoL L)
  linarith

/-- The key relation `L²(ρ + 1)² = γ(ρ − 1)²`. -/
theorem key_rel (hL : 2 ≤ L) : (L : ℝ) ^ 2 * (rhoL L + 1) ^ 2 = gam L * (rhoL L - 1) ^ 2 := by
  have hq := quad_rho hL
  have hL2 : (4 : ℝ) ≤ (L : ℝ) ^ 2 := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hD : (L : ℝ) ^ 2 - 1 ≠ 0 := by linarith
  unfold sL at hq
  unfold gam
  field_simp at hq
  nlinarith [hq]

theorem denom_ne (hL : 2 ≤ L) :
    rhoL L * (-(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3)) ≠ 0 := by
  obtain ⟨h1, h2⟩ := rho_bounds hL
  have hg : 0 < gam L := by unfold gam; positivity
  have : -(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3) < 0 := by
    have : 0 ≤ (L : ℝ) ^ 2 := by positivity
    nlinarith
  exact mul_ne_zero h2.ne (by linarith)

/-- The two relations of the coefficients. -/
theorem cB_rel (hL : 2 ≤ L) : cB L * (rhoL L - 1) = -((L : ℝ) / 2) * cA L * (rhoL L + 1) := by
  obtain ⟨-, h2⟩ := rho_bounds hL
  have : rhoL L - 1 ≠ 0 := by linarith
  unfold cB; field_simp

theorem homog (hL : 2 ≤ L) :
    (L : ℝ) * cB L * (rhoL L + 1) + gam L / 2 * cA L * (rhoL L - 1) = 0 := by
  obtain ⟨-, h2⟩ := rho_bounds hL
  have hr1 : rhoL L - 1 ≠ 0 := by linarith
  have hk := key_rel hL
  have e : (L : ℝ) * cB L * (rhoL L + 1) + gam L / 2 * cA L * (rhoL L - 1) =
      cA L / (2 * (rhoL L - 1)) * (-((L : ℝ) ^ 2 * (rhoL L + 1) ^ 2) + gam L * (rhoL L - 1) ^ 2) := by
    unfold cB; field_simp
  rw [e, show -((L : ℝ) ^ 2 * (rhoL L + 1) ^ 2) + gam L * (rhoL L - 1) ^ 2 = 0 by linarith, mul_zero]

theorem first_row (hL : 2 ≤ L) :
    -2 = (L : ℝ) * (cB L * rhoL L) + gam L / 2 * (cA L * rhoL L - 2 * cA L * rhoL L / (rhoL L - 1)) := by
  obtain ⟨-, h2⟩ := rho_bounds hL
  have hr1 : rhoL L - 1 ≠ 0 := by linarith
  have hd := denom_ne hL
  have hρ : rhoL L ≠ 0 := h2.ne
  have hD0 : -(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3) ≠ 0 := right_ne_zero_of_mul hd
  have e : (L : ℝ) * (cB L * rhoL L) + gam L / 2 * (cA L * rhoL L - 2 * cA L * rhoL L / (rhoL L - 1)) =
      cA L * rhoL L * (-(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3)) / (2 * (rhoL L - 1)) := by
    unfold cB; field_simp; ring
  rw [e]
  have hc : cA L * (rhoL L * (-(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3))) =
      -4 * (rhoL L - 1) := by
    unfold cA; exact div_mul_cancel₀ _ hd
  calc (-2 : ℝ) = (-4 * (rhoL L - 1)) / (2 * (rhoL L - 1)) := by field_simp; ring
    _ = cA L * (rhoL L * (-(L : ℝ) ^ 2 * (rhoL L + 1) + gam L * (rhoL L - 3))) /
          (2 * (rhoL L - 1)) := by rw [hc]
    _ = _ := by ring


theorem natAbs_pos2 (n : ℕ) : ((n : ℤ) + 2).natAbs = n + 2 := by omega
theorem natAbs_pos1 (n : ℕ) : ((n : ℤ) + 2 - 1).natAbs = n + 1 := by omega
theorem natAbs_neg1 (n : ℕ) : (-((n : ℤ) + 1)).natAbs = n + 1 := by omega
theorem natAbs_neg2 (n : ℕ) : (-((n : ℤ) + 1) - 1).natAbs = n + 2 := by omega

/-- **Seam equation (A)** at every block boundary. -/
theorem seamA (hL : 2 ≤ L) (b : ℤ) :
    beK L b - beK L (b - 1) = -((L : ℝ) / 2) * (muK L b + muK L (b - 1)) := by
  obtain ⟨-, h2⟩ := rho_bounds hL
  have hr1 : rhoL L - 1 ≠ 0 := by linarith
  have hB := cB_rel hL
  rcases (show b ≤ -1 ∨ b = 0 ∨ b = 1 ∨ 2 ≤ b by omega) with h | h | h | h
  · obtain ⟨n, rfl⟩ : ∃ n : ℕ, b = -((n : ℤ) + 1) := ⟨(-b - 1).toNat, by omega⟩
    simp only [beK, muK, natAbs_neg1, natAbs_neg2,
      if_neg (show -((n : ℤ) + 1) ≠ 0 by omega), if_neg (show -((n : ℤ) + 1) - 1 ≠ 0 by omega),
      if_neg (show ¬ (0 < -((n : ℤ) + 1)) by omega), if_neg (show ¬ (0 < -((n : ℤ) + 1) - 1) by omega)]
    linear_combination (rhoL L) ^ (n + 1) * hB
  · subst h
    simp only [beK, muK, show ((0 : ℤ) - 1) ≠ 0 by omega, if_false, if_true, ↓reduceIte,
      show ¬ (0 < (0 : ℤ) - 1) by omega, show ((0 : ℤ) - 1).natAbs = 1 by rfl, pow_one]
    field_simp
    linear_combination (2 * rhoL L) * hB
  · subst h
    simp only [beK, muK, show (1 : ℤ) ≠ 0 by omega, if_false, show (1 : ℤ) - 1 = 0 by rfl, if_true,
      show (0 : ℤ) < 1 by omega, show (1 : ℤ).natAbs = 1 by rfl, pow_one]
    field_simp
    linear_combination (2 * rhoL L) * hB
  · obtain ⟨n, rfl⟩ : ∃ n : ℕ, b = (n : ℤ) + 2 := ⟨(b - 2).toNat, by omega⟩
    simp only [beK, muK, natAbs_pos2, natAbs_pos1,
      if_neg (show (n : ℤ) + 2 ≠ 0 by omega), if_neg (show (n : ℤ) + 2 - 1 ≠ 0 by omega),
      if_pos (show (0 : ℤ) < (n : ℤ) + 2 by omega), if_pos (show (0 : ℤ) < (n : ℤ) + 2 - 1 by omega)]
    linear_combination (rhoL L) ^ (n + 1) * hB

/-- **Seam equation (B)** at every block boundary, for `z = δ_0`. -/
theorem seamB (hL : 2 ≤ L) (b : ℤ) :
    2 * (zK b - zK (b - 1)) =
      (L : ℝ) * (beK L b + beK L (b - 1)) + gam L / 2 * (muK L b - muK L (b - 1)) := by
  obtain ⟨-, h2⟩ := rho_bounds hL
  have hr1 : rhoL L - 1 ≠ 0 := by linarith
  have hH := homog hL
  have hF := first_row hL
  rcases (show b ≤ -1 ∨ b = 0 ∨ b = 1 ∨ 2 ≤ b by omega) with h | h | h | h
  · obtain ⟨n, rfl⟩ : ∃ n : ℕ, b = -((n : ℤ) + 1) := ⟨(-b - 1).toNat, by omega⟩
    simp only [zK, beK, muK, natAbs_neg1, natAbs_neg2,
      if_neg (show -((n : ℤ) + 1) ≠ 0 by omega), if_neg (show -((n : ℤ) + 1) - 1 ≠ 0 by omega),
      if_neg (show ¬ (0 < -((n : ℤ) + 1)) by omega), if_neg (show ¬ (0 < -((n : ℤ) + 1) - 1) by omega)]
    linear_combination ((rhoL L) ^ (n + 1)) * hH
  · subst h
    simp only [zK, beK, muK, show ((0 : ℤ) - 1) ≠ 0 by omega, if_false, if_true, ↓reduceIte,
      show ¬ (0 < (0 : ℤ) - 1) by omega, show ((0 : ℤ) - 1).natAbs = 1 by rfl, pow_one]
    linear_combination (-1 : ℝ) * hF
  · subst h
    simp only [zK, beK, muK, show (1 : ℤ) ≠ 0 by omega, if_false, show (1 : ℤ) - 1 = 0 by rfl, if_true,
      show (0 : ℤ) < 1 by omega, show (1 : ℤ).natAbs = 1 by rfl, pow_one]
    linear_combination hF
  · obtain ⟨n, rfl⟩ : ∃ n : ℕ, b = (n : ℤ) + 2 := ⟨(b - 2).toNat, by omega⟩
    simp only [zK, beK, muK, natAbs_pos2, natAbs_pos1,
      if_neg (show (n : ℤ) + 2 ≠ 0 by omega), if_neg (show (n : ℤ) + 2 - 1 ≠ 0 by omega),
      if_pos (show (0 : ℤ) < (n : ℤ) + 2 by omega), if_pos (show (0 : ℤ) < (n : ℤ) + 2 - 1 by omega)]
    linear_combination (-(rhoL L) ^ (n + 1)) * hH

end

end BlockLift

#print axioms BlockLift.seamA
#print axioms BlockLift.seamB
