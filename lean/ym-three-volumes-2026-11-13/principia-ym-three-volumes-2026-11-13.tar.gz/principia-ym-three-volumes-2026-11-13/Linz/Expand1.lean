import UVChain.BoxChainV1

/-!
# First-order expansion of the block map near the unit configuration

Paper: the block map of the induction is `retract ∘ (weighted average of oriented path products)`
(`ChainBlockMap.blockMap`, `retract`, `sixAvg`). This file shows, for unit-quaternion link
variables `U ℓ` with `‖U ℓ − 1‖ ≤ δ`, that
* a path product is `1 + Σ_steps (stepVal − 1)` up to `n² δ² / 2` (`pathProd_near_one`),
* the six-order average keeps this (`sixAvg_near_one`),
* the retraction changes `1 + v` only at second order, because the real part of the
  first-order term is itself of second order (`re_sub_one_of_unit`, `retract_one_add`),
* for `U ℓ = exp(ε a ℓ)` with `a ℓ` imaginary, the block value is `exp(ε · Σ w Σ ± a)` up to
  `257 (ε M)²`, `M = sup ‖a‖` (`retract_sixAvg_exp`), when every path has at most 8 steps.
-/

namespace BlockLinear

open ChainBlockMap
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

/-! ## 0. Real parts of sums -/

theorem re_fsum {ι : Type*} (s : Finset ι) (f : ι → ℍr) : (∑ i ∈ s, f i).re = ∑ i ∈ s, (f i).re := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | insert i s hi ih => rw [Finset.sum_insert hi, Finset.sum_insert hi, Quaternion.re_add, ih]

/-! ## 1. Products of factors close to `1` -/

theorem list_prod_near_one {δ : ℝ} (hδ : 0 ≤ δ) :
    ∀ l : List ℍr, (∀ u ∈ l, ‖u‖ ≤ 1) → (∀ u ∈ l, ‖u - 1‖ ≤ δ) →
      ‖l.prod - 1‖ ≤ l.length * δ ∧
      ‖l.prod - 1 - (l.map (fun u => u - 1)).sum‖ ≤ (l.length : ℝ) ^ 2 * δ ^ 2 / 2
  | [], _, _ => by simp
  | u :: l, h1, h2 => by
    have hu1 : ‖u‖ ≤ 1 := h1 u (by simp)
    have hu2 : ‖u - 1‖ ≤ δ := h2 u (by simp)
    obtain ⟨ih1, ih2⟩ := list_prod_near_one hδ l (fun v hv => h1 v (by simp [hv]))
      (fun v hv => h2 v (by simp [hv]))
    have hP : 0 ≤ ‖l.prod - 1‖ := norm_nonneg _
    have e1 : u * l.prod - 1 = u * (l.prod - 1) + (u - 1) := by noncomm_ring
    have e2 : u * l.prod - 1 - ((u - 1) + (l.map (fun u => u - 1)).sum) =
        (l.prod - 1 - (l.map (fun u => u - 1)).sum) + (u - 1) * (l.prod - 1) := by noncomm_ring
    simp only [List.prod_cons, List.map_cons, List.sum_cons, List.length_cons]
    constructor
    · rw [e1]
      calc ‖u * (l.prod - 1) + (u - 1)‖ ≤ ‖u * (l.prod - 1)‖ + ‖u - 1‖ := norm_add_le _ _
        _ = ‖u‖ * ‖l.prod - 1‖ + ‖u - 1‖ := by rw [norm_mul]
        _ ≤ 1 * (l.length * δ) + δ := by gcongr
        _ = ((l.length + 1 : ℕ) : ℝ) * δ := by push_cast; ring
    · rw [e2]
      calc ‖(l.prod - 1 - (l.map (fun u => u - 1)).sum) + (u - 1) * (l.prod - 1)‖
          ≤ ‖l.prod - 1 - (l.map (fun u => u - 1)).sum‖ + ‖u - 1‖ * ‖l.prod - 1‖ := by
            refine (norm_add_le _ _).trans ?_; rw [norm_mul]
        _ ≤ (l.length : ℝ) ^ 2 * δ ^ 2 / 2 + δ * (l.length * δ) := by gcongr
        _ ≤ ((l.length + 1 : ℕ) : ℝ) ^ 2 * δ ^ 2 / 2 := by push_cast; nlinarith [sq_nonneg δ]

/-! ## 2. Oriented steps and path products -/

section Paths

variable {L : Type*}

theorem norm_stepVal (U : L → ℍr) (s : L × Bool) : ‖stepVal U s‖ = ‖U s.1‖ := by
  unfold stepVal; split_ifs <;> simp [norm_star]

theorem stepVal_sub_one (U : L → ℍr) (s : L × Bool) :
    stepVal U s - 1 = if s.2 then star (U s.1 - 1) else U s.1 - 1 := by
  unfold stepVal; split_ifs <;> simp [star_sub]

theorem norm_stepVal_sub_one (U : L → ℍr) (s : L × Bool) : ‖stepVal U s - 1‖ = ‖U s.1 - 1‖ := by
  rw [stepVal_sub_one]; split_ifs
  · exact norm_star _
  · rfl

/-- First-order term of a path product: the sum of `stepVal − 1` over the steps. -/
noncomputable def pathLin (U : L → ℍr) (γ : List (L × Bool)) : ℍr :=
  (γ.map fun s => stepVal U s - 1).sum

theorem pathProd_near_one {U : L → ℍr} {δ : ℝ} (hδ : 0 ≤ δ) (hU1 : ∀ ℓ, ‖U ℓ‖ ≤ 1)
    (hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ) (γ : List (L × Bool)) :
    ‖pathProd U γ - 1‖ ≤ γ.length * δ ∧
      ‖pathProd U γ - 1 - pathLin U γ‖ ≤ (γ.length : ℝ) ^ 2 * δ ^ 2 / 2 := by
  have h := list_prod_near_one hδ (γ.map (stepVal U))
    (by
      intro u hu
      obtain ⟨s, -, rfl⟩ := List.mem_map.1 hu
      rw [norm_stepVal]; exact hU1 _)
    (by
      intro u hu
      obtain ⟨s, -, rfl⟩ := List.mem_map.1 hu
      rw [norm_stepVal_sub_one]; exact hU2 _)
  simpa [pathProd, pathLin, List.map_map, Function.comp_def] using h

theorem norm_pathLin_le {U : L → ℍr} {δ : ℝ} (hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ) (γ : List (L × Bool)) :
    ‖pathLin U γ‖ ≤ γ.length * δ := by
  unfold pathLin
  induction γ with
  | nil => simp
  | cons s γ ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    calc ‖stepVal U s - 1 + (γ.map fun s => stepVal U s - 1).sum‖
        ≤ ‖stepVal U s - 1‖ + ‖(γ.map fun s => stepVal U s - 1).sum‖ := norm_add_le _ _
      _ ≤ δ + γ.length * δ := by rw [norm_stepVal_sub_one]; gcongr; exact hU2 _
      _ = ((γ.length + 1 : ℕ) : ℝ) * δ := by push_cast; ring

/-- For a unit quaternion, `Re (u − 1) = −‖u − 1‖² / 2`. -/
theorem re_sub_one_of_unit (u : ℍr) (hu : ‖u‖ = 1) : (u - 1).re = -(‖u - 1‖ ^ 2) / 2 := by
  have h1 := Quaternion.normSq_eq_norm_mul_self u
  have h2 := Quaternion.normSq_eq_norm_mul_self (u - 1)
  rw [Quaternion.normSq_def'] at h1 h2
  rw [hu] at h1
  simp only [Quaternion.re_sub, Quaternion.re_one, Quaternion.imI_sub, Quaternion.imI_one,
    Quaternion.imJ_sub, Quaternion.imJ_one, Quaternion.imK_sub, Quaternion.imK_one, sub_zero] at h2 ⊢
  nlinarith [h1, h2]

theorem re_pathLin_bound {U : L → ℍr} {δ : ℝ} (hU1 : ∀ ℓ, ‖U ℓ‖ = 1) (hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ)
    (γ : List (L × Bool)) : |(pathLin U γ).re| ≤ γ.length * (δ ^ 2 / 2) := by
  unfold pathLin
  induction γ with
  | nil => simp
  | cons s γ ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons, Quaternion.re_add]
    have hs : (stepVal U s - 1).re = -(‖stepVal U s - 1‖ ^ 2) / 2 :=
      re_sub_one_of_unit _ (by rw [norm_stepVal]; exact hU1 _)
    have hn : ‖stepVal U s - 1‖ ≤ δ := by rw [norm_stepVal_sub_one]; exact hU2 _
    have h0 : 0 ≤ ‖stepVal U s - 1‖ := norm_nonneg _
    have hsq : ‖stepVal U s - 1‖ ^ 2 ≤ δ ^ 2 := pow_le_pow_left₀ h0 hn 2
    rw [hs]
    calc |-(‖stepVal U s - 1‖ ^ 2) / 2 + (γ.map fun s => stepVal U s - 1).sum.re|
        ≤ |-(‖stepVal U s - 1‖ ^ 2) / 2| + |(γ.map fun s => stepVal U s - 1).sum.re| :=
          abs_add_le _ _
      _ ≤ δ ^ 2 / 2 + γ.length * (δ ^ 2 / 2) := by
          gcongr
          rw [abs_le]; constructor <;> nlinarith [sq_nonneg (‖stepVal U s - 1‖)]
      _ = ((γ.length + 1 : ℕ) : ℝ) * (δ ^ 2 / 2) := by push_cast; ring

end Paths

/-! ## 3. The six-order average -/

section Six

variable {L : Type*}

/-- First-order term of the six-order average. -/
noncomputable def sixLin (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) : ℍr :=
  ∑ o, ∑ A, sixWeight A • pathLin U (P o A)

theorem norm_sixSum_le (x : Fin 6 → (Fin 3 → Fin 3) → ℍr) {B : ℝ} (hx : ∀ o A, ‖x o A‖ ≤ B) :
    ‖∑ o, ∑ A, sixWeight A • x o A‖ ≤ B := by
  calc ‖∑ o, ∑ A, sixWeight A • x o A‖ ≤ ∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A * B := by
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun o _ => ?_)
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun A _ => ?_)
        rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (sixWeight_nonneg A)]
        exact mul_le_mul_of_nonneg_left (hx o A) (sixWeight_nonneg A)
    _ = (∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A) * B := by
        rw [Finset.sum_mul]; refine Finset.sum_congr rfl fun o _ => ?_; rw [Finset.sum_mul]
    _ = B := by rw [sixWeight_total, one_mul]

theorem abs_re_sixSum_le (x : Fin 6 → (Fin 3 → Fin 3) → ℍr) {B : ℝ} (hx : ∀ o A, |(x o A).re| ≤ B) :
    |(∑ o, ∑ A, sixWeight A • x o A).re| ≤ B := by
  rw [re_fsum]
  simp_rw [re_fsum, Quaternion.re_smul, smul_eq_mul]
  calc |∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A * (x o A).re|
      ≤ ∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A * B := by
        refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun o _ => ?_)
        refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun A _ => ?_)
        rw [abs_mul, abs_of_nonneg (sixWeight_nonneg A)]
        exact mul_le_mul_of_nonneg_left (hx o A) (sixWeight_nonneg A)
    _ = (∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A) * B := by
        rw [Finset.sum_mul]; refine Finset.sum_congr rfl fun o _ => ?_; rw [Finset.sum_mul]
    _ = B := by rw [sixWeight_total, one_mul]

theorem sixAvg_sub_one (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) :
    sixAvg P U - 1 - sixLin P U =
      ∑ o, ∑ A, sixWeight A • (pathProd U (P o A) - 1 - pathLin U (P o A)) := by
  have h1 : (1 : ℍr) = ∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A • (1 : ℍr) := by
    simp_rw [← Finset.sum_smul]; rw [sixWeight_total, one_smul]
  unfold sixAvg sixLin
  conv_lhs => rw [h1]
  simp only [smul_sub, Finset.sum_sub_distrib]

theorem sixAvg_near_one (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) {U : L → ℍr} {δ : ℝ}
    (hδ : 0 ≤ δ) (hU1 : ∀ ℓ, ‖U ℓ‖ = 1) (hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ) {n : ℕ}
    (hlen : ∀ o A, (P o A).length ≤ n) :
    ‖sixAvg P U - 1 - sixLin P U‖ ≤ (n : ℝ) ^ 2 * δ ^ 2 / 2 ∧
      ‖sixLin P U‖ ≤ n * δ ∧ |(sixLin P U).re| ≤ n * (δ ^ 2 / 2) := by
  refine ⟨?_, ?_, ?_⟩
  · rw [sixAvg_sub_one]
    refine norm_sixSum_le _ fun o A => ?_
    refine (pathProd_near_one hδ (fun ℓ => (hU1 ℓ).le) hU2 (P o A)).2.trans ?_
    gcongr; exact hlen o A
  · refine norm_sixSum_le _ fun o A => (norm_pathLin_le hU2 (P o A)).trans ?_
    gcongr; exact hlen o A
  · refine abs_re_sixSum_le _ fun o A => (re_pathLin_bound hU1 hU2 (P o A)).trans ?_
    gcongr; exact hlen o A

end Six

/-! ## 4. The retraction near `1` -/

theorem norm_one_add_sq (v : ℍr) : ‖1 + v‖ ^ 2 = 1 + 2 * v.re + ‖v‖ ^ 2 := by
  have h1 := Quaternion.normSq_eq_norm_mul_self (1 + v)
  have h2 := Quaternion.normSq_eq_norm_mul_self v
  rw [Quaternion.normSq_def'] at h1 h2
  simp only [Quaternion.re_add, Quaternion.re_one, Quaternion.imI_add, Quaternion.imI_one,
    Quaternion.imJ_add, Quaternion.imJ_one, Quaternion.imK_add, Quaternion.imK_one,
    zero_add] at h1
  nlinarith [h1, h2]

/-- **The retraction is the identity up to second order at `1 + v`**, when `Re v` is small. -/
theorem retract_one_add {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2) {v : ℍr} {s ρ : ℝ}
    (hv : ‖v‖ ≤ s) (hs : s ≤ 1 / 2) (hre : |v.re| ≤ ρ) :
    ‖retract r₀ (1 + v) - (1 + v)‖ ≤ 2 * ρ + s ^ 2 := by
  have hq : 1 - s ≤ ‖1 + v‖ := by
    have := norm_sub_norm_le (1 : ℍr) (-v)
    simp only [norm_one, norm_neg, sub_neg_eq_add] at this
    linarith
  have hq0 : r₀ ≤ ‖1 + v‖ := by linarith
  have hpos : 0 < ‖1 + v‖ := lt_of_lt_of_le hr hq0
  rw [(retract_of_le hr hq0).1]
  have e : ‖1 + v‖⁻¹ • (1 + v) - (1 + v) = (‖1 + v‖⁻¹ - 1) • (1 + v) := by
    rw [sub_smul, one_smul]
  rw [e, norm_smul, Real.norm_eq_abs]
  have ht := norm_one_add_sq v
  set t := ‖1 + v‖ with htdef
  have hk : |t⁻¹ - 1| * t = |1 - t| := by
    rw [show t⁻¹ - 1 = (1 - t) / t by field_simp, abs_div, abs_of_pos hpos, div_mul_cancel₀ _ hpos.ne']
  rw [hk]
  have hv0 : 0 ≤ ‖v‖ := norm_nonneg _
  have hre' := abs_le.1 hre
  have hs0 : 0 ≤ s := hv0.trans hv
  have hvs : ‖v‖ ^ 2 ≤ s ^ 2 := pow_le_pow_left₀ hv0 hv 2
  rw [abs_le]
  constructor <;> nlinarith [hpos, hre'.1, hre'.2]

/-! ## 5. The exponential of an imaginary quaternion -/

theorem exp_imag (v : ℍr) (hv : v.re = 0) (h1 : ‖v‖ ≤ 1) :
    ‖NormedSpace.exp v‖ = 1 ∧ ‖NormedSpace.exp v - 1‖ ≤ ‖v‖ ∧
      ‖NormedSpace.exp v - 1 - v‖ ≤ ‖v‖ ^ 2 := by
  have hn : ‖NormedSpace.exp v‖ = 1 := by
    rw [Quaternion.norm_exp, hv, NormedSpace.exp_zero, norm_one]
  have he := Quaternion.exp_of_re_eq_zero v hv
  set t := ‖v‖ with htdef
  have ht0 : 0 ≤ t := norm_nonneg _
  have hcos1 := Real.cos_le_one t
  have hcos2 : 1 - t ^ 2 / 2 ≤ Real.cos t := Real.one_sub_sq_div_two_le_cos
  refine ⟨hn, ?_, ?_⟩
  · -- ‖e − 1‖² = −2 Re(e − 1) = 2(1 − cos t) ≤ t²
    have hre := re_sub_one_of_unit _ hn
    have hre2 : (NormedSpace.exp v - 1).re = Real.cos t - 1 := by
      rw [he]; simp [hv, Quaternion.re_one]
    have h0 : 0 ≤ ‖NormedSpace.exp v - 1‖ := norm_nonneg _
    have hsq : ‖NormedSpace.exp v - 1‖ ^ 2 ≤ t ^ 2 := by nlinarith
    exact (pow_le_pow_iff_left₀ h0 ht0 two_ne_zero).1 hsq
  · rcases eq_or_lt_of_le ht0 with h | h
    · have : v = 0 := norm_eq_zero.1 h.symm
      subst this; simp; positivity
    · rw [he]
      have e : (↑(Real.cos t) + (Real.sin t / t) • v - 1 - v : ℍr) =
          ↑(Real.cos t - 1) + (Real.sin t / t - 1) • v := by
        rw [Quaternion.coe_sub, Quaternion.coe_one, sub_smul, one_smul]; abel
      rw [e]
      have hsin1 : Real.sin t ≤ t := Real.sin_le ht0
      have hsin2 : t - t ^ 3 / 6 < Real.sin t := Real.sin_gt_sub_cube h
      have hk : |Real.sin t / t - 1| * t = |Real.sin t - t| := by
        rw [show Real.sin t / t - 1 = (Real.sin t - t) / t by field_simp, abs_div, abs_of_pos h,
          div_mul_cancel₀ _ h.ne']
      calc ‖(↑(Real.cos t - 1) : ℍr) + (Real.sin t / t - 1) • v‖
          ≤ ‖(↑(Real.cos t - 1) : ℍr)‖ + ‖(Real.sin t / t - 1) • v‖ := norm_add_le _ _
        _ = |Real.cos t - 1| + |Real.sin t - t| := by
          rw [Quaternion.norm_coe, Real.norm_eq_abs, norm_smul, Real.norm_eq_abs, ← htdef, hk]
        _ ≤ t ^ 2 / 2 + t ^ 3 / 6 := by
          gcongr
          · rw [abs_le]; constructor <;> linarith
          · rw [abs_le]; constructor <;> linarith
        _ ≤ t ^ 2 := by nlinarith [pow_le_pow_left₀ ht0 h1 2]

theorem abs_re_le_norm (q : ℍr) : |q.re| ≤ ‖q‖ := by
  have h := Quaternion.normSq_eq_norm_mul_self q
  rw [Quaternion.normSq_def'] at h
  have h2 : |q.re| ^ 2 ≤ ‖q‖ ^ 2 := by
    rw [sq_abs]; nlinarith [sq_nonneg q.imI, sq_nonneg q.imJ, sq_nonneg q.imK]
  exact (pow_le_pow_iff_left₀ (abs_nonneg _) (norm_nonneg _) two_ne_zero).1 h2

theorem star_of_re_zero (v : ℍr) (hv : v.re = 0) : star v = -v := by
  have h := Quaternion.self_add_star' v
  rw [hv, mul_zero, Quaternion.coe_zero] at h
  calc star v = (v + star v) - v := by abel
    _ = -v := by simp [h]

/-! ## 6. Imaginary link fields `U = exp(ε a)` -/

section Exp

variable {L : Type*}

/-- Signed sum of the field along a path: `+a` on a forward step, `−a` on a backward step. -/
noncomputable def pathSgn (a : L → ℍr) (γ : List (L × Bool)) : ℍr :=
  (γ.map fun s => if s.2 then -a s.1 else a s.1).sum

/-- The signed six-order average of the field: the linear part of the block map at `U = 1`. -/
noncomputable def sixSgn (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (a : L → ℍr) : ℍr :=
  ∑ o, ∑ A, sixWeight A • pathSgn a (P o A)

theorem re_pathSgn {a : L → ℍr} (ha : ∀ ℓ, (a ℓ).re = 0) (γ : List (L × Bool)) :
    (pathSgn a γ).re = 0 := by
  unfold pathSgn
  induction γ with
  | nil => simp
  | cons s γ ih =>
    simp only [List.map_cons, List.sum_cons, Quaternion.re_add, ih, add_zero]
    split_ifs
    · rw [show (-a s.1).re = -(a s.1).re from rfl, ha, neg_zero]
    · exact ha _

theorem re_sixSgn (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) {a : L → ℍr}
    (ha : ∀ ℓ, (a ℓ).re = 0) : (sixSgn P a).re = 0 := by
  unfold sixSgn
  rw [re_fsum]
  simp_rw [re_fsum, Quaternion.re_smul, re_pathSgn ha]
  simp

theorem norm_pathSgn_le {a : L → ℍr} {M : ℝ} (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (γ : List (L × Bool)) :
    ‖pathSgn a γ‖ ≤ γ.length * M := by
  unfold pathSgn
  induction γ with
  | nil => simp
  | cons s γ ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    have h1 : ‖(if s.2 then -a s.1 else a s.1)‖ ≤ M := by
      split_ifs
      · rw [norm_neg]; exact hM _
      · exact hM _
    calc ‖(if s.2 then -a s.1 else a s.1) + (γ.map fun s => if s.2 then -a s.1 else a s.1).sum‖
        ≤ ‖(if s.2 then -a s.1 else a s.1)‖ + ‖(γ.map fun s => if s.2 then -a s.1 else a s.1).sum‖ :=
          norm_add_le _ _
      _ ≤ M + γ.length * M := add_le_add h1 ih
      _ = ((γ.length + 1 : ℕ) : ℝ) * M := by push_cast; ring

/-- One step of `U = exp(ε a)` against its signed linear part. -/
theorem step_exp (a : L → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {ε : ℝ} (s : L × Bool)
    (h1 : ‖ε • a s.1‖ ≤ 1) :
    ‖stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1 -
        (if s.2 then -(ε • a s.1) else ε • a s.1)‖ ≤ ‖ε • a s.1‖ ^ 2 := by
  have hre : (ε • a s.1).re = 0 := by rw [Quaternion.re_smul, ha, smul_zero]
  have hb := (exp_imag _ hre h1).2.2
  unfold stepVal
  split_ifs
  · have e : star (NormedSpace.exp (ε • a s.1)) - 1 - -(ε • a s.1) =
        star (NormedSpace.exp (ε • a s.1) - 1 - ε • a s.1) := by
      rw [star_sub, star_sub, star_one, star_of_re_zero _ hre]
    simp only [e, norm_star]; exact hb
  · simpa using hb

theorem pathLin_exp (a : L → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {ε M : ℝ} (hε : 0 ≤ ε)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (h1 : ε * M ≤ 1) (γ : List (L × Bool)) :
    ‖pathLin (fun ℓ => NormedSpace.exp (ε • a ℓ)) γ - ε • pathSgn a γ‖ ≤
      γ.length * (ε * M) ^ 2 := by
  have hstep : ∀ s : L × Bool, ‖stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1 -
      (if s.2 then -(ε • a s.1) else ε • a s.1)‖ ≤ (ε * M) ^ 2 := by
    intro s
    have hn : ‖ε • a s.1‖ ≤ ε * M := by
      rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
      exact mul_le_mul_of_nonneg_left (hM _) hε
    exact (step_exp a ha s (hn.trans h1)).trans (pow_le_pow_left₀ (norm_nonneg _) hn 2)
  unfold pathLin pathSgn
  induction γ with
  | nil => simp
  | cons s γ ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons, smul_add]
    have e : stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1 +
          (γ.map fun s => stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1).sum -
        (ε • (if s.2 then -a s.1 else a s.1) + ε • (γ.map fun s => if s.2 then -a s.1 else a s.1).sum) =
        (stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1 -
          (if s.2 then -(ε • a s.1) else ε • a s.1)) +
        ((γ.map fun s => stepVal (fun ℓ => NormedSpace.exp (ε • a ℓ)) s - 1).sum -
          ε • (γ.map fun s => if s.2 then -a s.1 else a s.1).sum) := by
      split_ifs <;> (try simp only [smul_neg]) <;> abel
    rw [e]
    calc _ ≤ _ := norm_add_le _ _
      _ ≤ (ε * M) ^ 2 + γ.length * (ε * M) ^ 2 := add_le_add (hstep s) ih
      _ = ((γ.length + 1 : ℕ) : ℝ) * (ε * M) ^ 2 := by push_cast; ring

/-- **First-order expansion of `retract ∘ sixAvg` at `U = exp(ε a)`** (paths of at most 8 steps,
imaginary field `a` with `‖a‖ ≤ M`, `ε M ≤ 1/32`, `r₀ ≤ 1/2`):
the block value is `exp(ε · sixSgn P a)` up to `257 (ε M)²`. -/
theorem retract_sixAvg_exp (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool))
    (hlen : ∀ o A, (P o A).length ≤ 8) {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (a : L → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M) (hM : ∀ ℓ, ‖a ℓ‖ ≤ M)
    (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) :
    ‖retract r₀ (sixAvg P fun ℓ => NormedSpace.exp (ε • a ℓ)) -
        NormedSpace.exp (ε • sixSgn P a)‖ ≤ 257 * (ε * M) ^ 2 := by
  set δ := ε * M with hδdef
  have hδ : 0 ≤ δ := mul_nonneg hε hM0
  set U : L → ℍr := fun ℓ => NormedSpace.exp (ε • a ℓ) with hUdef
  have hna : ∀ ℓ, ‖ε • a ℓ‖ ≤ δ := fun ℓ => by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    exact mul_le_mul_of_nonneg_left (hM _) hε
  have hrea : ∀ ℓ, (ε • a ℓ).re = 0 := fun ℓ => by rw [Quaternion.re_smul, ha, smul_zero]
  have hU1 : ∀ ℓ, ‖U ℓ‖ = 1 := fun ℓ => (exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).1
  have hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ := fun ℓ =>
    ((exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).2.1).trans (hna ℓ)
  obtain ⟨hA, hB, hC⟩ := sixAvg_near_one P hδ hU1 hU2 hlen
  push_cast at hA hB hC
  set lin := sixLin P U
  set e := sixAvg P U - 1 - lin
  set v := sixAvg P U - 1
  have hv : v = lin + e := by simp only [v, e]; abel
  have hvn : ‖v‖ ≤ 8 * δ + 32 * δ ^ 2 := by
    rw [hv]; refine (norm_add_le _ _).trans ?_; nlinarith [hA, hB]
  have hvre : |v.re| ≤ 36 * δ ^ 2 := by
    rw [hv, Quaternion.re_add]
    refine (abs_add_le _ _).trans ?_
    have := abs_re_le_norm e
    nlinarith [hA, hC]
  have hs : 8 * δ + 32 * δ ^ 2 ≤ 1 / 2 := by nlinarith
  have hR := retract_one_add hr hr0 hvn hs hvre
  have h1v : 1 + v = sixAvg P U := by simp only [v]; abel
  rw [h1v] at hR
  -- linear part against the signed field
  set S := sixSgn P a
  have hlinS : ‖lin - ε • S‖ ≤ 8 * δ ^ 2 := by
    have e2 : lin - ε • S = ∑ o, ∑ A, sixWeight A •
        (pathLin U (P o A) - ε • pathSgn a (P o A)) := by
      simp only [lin, S, sixLin, sixSgn, Finset.smul_sum, smul_sub, Finset.sum_sub_distrib]
      congr 1
      refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
      rw [smul_comm]
    rw [e2]
    refine norm_sixSum_le _ fun o A => (pathLin_exp a ha hε hM (by linarith) (P o A)).trans ?_
    have := hlen o A
    have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
    nlinarith [sq_nonneg δ]
  have hSn : ‖ε • S‖ ≤ 8 * δ := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    have : ‖S‖ ≤ 8 * M := norm_sixSum_le _ fun o A => (norm_pathSgn_le hM (P o A)).trans (by
      have := hlen o A
      have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
      nlinarith)
    nlinarith
  have hSre : (ε • S).re = 0 := by rw [Quaternion.re_smul, re_sixSgn P ha, smul_zero]
  have hE := (exp_imag _ hSre (by linarith)).2.2
  have hS2 : ‖ε • S‖ ^ 2 ≤ 64 * δ ^ 2 := by nlinarith [norm_nonneg (ε • S)]
  have key : retract r₀ (sixAvg P U) - NormedSpace.exp (ε • S) =
      (retract r₀ (sixAvg P U) - sixAvg P U) + e + (lin - ε • S) -
        (NormedSpace.exp (ε • S) - 1 - ε • S) := by
    simp only [e]; abel
  rw [key]
  calc _ ≤ ‖retract r₀ (sixAvg P U) - sixAvg P U‖ + ‖e‖ + ‖lin - ε • S‖ +
        ‖NormedSpace.exp (ε • S) - 1 - ε • S‖ := by
        refine (norm_sub_le _ _).trans ?_
        gcongr
        refine (norm_add_le _ _).trans ?_
        gcongr
        exact norm_add_le _ _
    _ ≤ (2 * (36 * δ ^ 2) + (8 * δ + 32 * δ ^ 2) ^ 2) + 32 * δ ^ 2 + 8 * δ ^ 2 + 64 * δ ^ 2 := by
        gcongr
        · nlinarith [hA]
        · exact hE.trans hS2
    _ ≤ 257 * δ ^ 2 := by
        have h9 : 8 * δ + 32 * δ ^ 2 ≤ 9 * δ := by nlinarith
        have h81 : (8 * δ + 32 * δ ^ 2) ^ 2 ≤ (9 * δ) ^ 2 :=
          pow_le_pow_left₀ (by positivity) h9 2
        nlinarith

end Exp

end BlockLinear

#print axioms BlockLinear.pathProd_near_one
#print axioms BlockLinear.sixAvg_near_one
#print axioms BlockLinear.retract_one_add
#print axioms BlockLinear.exp_imag
#print axioms BlockLinear.retract_sixAvg_exp
