import Linz.Kernel1

/-!
# The box level `m` and the torus step at `L' = 2^m L`: the same operator

The box chain at level `m` has coarse sites `(ZMod (2^m L))⁴` and fine sites
`(ZMod (2^(m+1) L))⁴`; the step `LatticePush.stepOp (2^m L)` has the same coarse sites and fine
sites `(ZMod (2 · 2^m L))⁴`. `fineV` identifies the two fine tori (`ZMod.ringEquivCongr` of
`2^(m+1) L = 2 · 2^m L`). Under it the doubling maps agree (`fineV_double`), the path kernels agree
(`pathKernel_fineV`), hence the two `Cop` agree (`box_cop_eq_step_cop`), and the colour identity of
`blockMap_exp_linear` is literally the operator of `stepOp (2^m L)` (`blockMap_linear_stepOp`).
-/

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear

local notation "ℍr" => Quaternion ℝ

section Bridge

variable (L : ℕ) [NeZero L] (m : ℕ)

theorem fine_eq : 2 ^ (m + 1) * L = 2 * (2 ^ m * L) := by ring

/-- The identification of the fine moduli. -/
def fineE : ZMod (2 ^ (m + 1) * L) ≃+* ZMod (2 * (2 ^ m * L)) :=
  ZMod.ringEquivCongr (fine_eq L m)

/-- The identification of the fine sites. -/
def fineV : (Fin 4 → ZMod (2 ^ (m + 1) * L)) ≃ (Fin 4 → ZMod (2 * (2 ^ m * L))) :=
  Equiv.piCongrRight fun _ => (fineE L m).toEquiv

theorem fineV_apply (y : Fin 4 → ZMod (2 ^ (m + 1) * L)) : fineV L m y = fun j => fineE L m (y j) :=
  rfl

theorem fineV_add (y z : Fin 4 → ZMod (2 ^ (m + 1) * L)) :
    fineV L m (y + z) = fineV L m y + fineV L m z := by
  funext j; simp [fineV_apply, map_add]

theorem fineV_cast (z : Fin 4 → ℤ) :
    fineV L m (fun j => (z j : ZMod (2 ^ (m + 1) * L))) = fun j => (z j : ZMod (2 * (2 ^ m * L))) := by
  funext j; simp [fineV_apply, map_intCast]

theorem fineV_double (x : Fin 4 → ZMod (2 ^ m * L)) :
    fineV L m ((BoxWalk.double L m).compLeft (Fin 4) x) = TorusFourier.betaT 4 (2 ^ m * L) x := by
  funext j
  simp only [fineV_apply, AddMonoidHom.compLeft_apply, Function.comp_apply, TorusFourier.betaT]
  rw [← ZMod.intCast_zmod_cast (x j), BoxWalk.double_intCast, TorusFourier.dbl_intCast, map_intCast]
  push_cast
  ring

theorem pathKernel_fineV (r : Fin 4 → ZMod (2 ^ (m + 1) * L)) (μ ν : Fin 4) :
    LatticeTorus.pathKernel (2 ^ (m + 1) * L) r μ ν =
      LatticeTorus.pathKernel (2 * (2 ^ m * L)) (fineV L m r) μ ν := by
  have key : ∀ z : Fin 4 → ℤ, ((fun j => (z j : ZMod (2 ^ (m + 1) * L))) = r ↔
      (fun j => (z j : ZMod (2 * (2 ^ m * L)))) = fineV L m r) := fun z => by
    rw [← fineV_cast L m z, (fineV L m).injective.eq_iff]
  unfold LatticeTorus.pathKernel
  simp only [key]

/-- **The two operators agree** under the identification of the fine sites. -/
theorem box_cop_eq_step_cop (F : (Fin 4 → ZMod (2 * (2 ^ m * L))) → Fin 4 → ℂ)
    (X : Fin 4 → ZMod (2 ^ m * L)) (μ : Fin 4) :
    TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => F (fineV L m y) ν) X μ =
      TorusFourier.Cop (TorusFourier.betaT 4 (2 ^ m * L))
        (LatticeTorus.pathKernel (2 * (2 ^ m * L))) F X μ := by
  unfold TorusFourier.Cop
  refine Fintype.sum_equiv (fineV L m) _ _ (fun r => ?_)
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [pathKernel_fineV L m r]
  dsimp only
  rw [fineV_add, fineV_double]

/-- **The box block map at level `m`, linearised at `U = 1`, is the operator of the torus step
`stepOp (2^m L)`**, colour by colour (the field is carried to the step's fine torus by `fineV`). -/
theorem blockMap_linear_stepOp {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (a : BoxWalk.BoxLk L (m + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk L m) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx L m b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop (TorusFourier.betaT 4 (2 ^ m * L))
        (LatticeTorus.pathKernel (2 * (2 ^ m * L)))
        (fun y ν => ((f (a ((fineV L m).symm y, ν)) : ℝ) : ℂ)) b.1 b.2 := by
  obtain ⟨h1, h2⟩ := blockMap_exp_linear L hr hr0 m a ha hM0 hM hε hεM b
  refine ⟨h1, fun f => ?_⟩
  rw [h2 f, ← box_cop_eq_step_cop L m]
  simp only [Equiv.symm_apply_apply]

end Bridge

end BlockLinearKernel

#print axioms BlockLinearKernel.fineV_double
#print axioms BlockLinearKernel.pathKernel_fineV
#print axioms BlockLinearKernel.box_cop_eq_step_cop
#print axioms BlockLinearKernel.blockMap_linear_stepOp
