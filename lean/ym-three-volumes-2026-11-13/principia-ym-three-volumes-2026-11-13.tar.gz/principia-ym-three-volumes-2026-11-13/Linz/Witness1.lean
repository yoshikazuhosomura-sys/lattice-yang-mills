import Linz.Kernel1

/-!
# Checks of the linearisation statement: satisfiable hypotheses and the degenerate field

* `unitI_norm`: the imaginary unit `i` has norm `1` (a field of norm `≤ 1` exists, `M = 1`).
* `blockMap_exp_linear_example`: all hypotheses of `blockMap_exp_linear` hold for the constant
  field `i` on the box `L = 1`, `m = 0`, `ε = 1/32`, `r₀ = 1/2`; the bound `257/1024 < 2` is below
  the trivial bound `2` for two quaternions of norm `≤ 1`.
* `blockMap_zero_field`: for `a = 0` the statement forces the block value of `U ≡ 1` to be `1`.
-/

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

/-- The imaginary unit `i`. -/
def unitI : ℍr := ⟨0, 1, 0, 0⟩

theorem unitI_re : unitI.re = 0 := rfl

theorem unitI_norm : ‖unitI‖ = 1 := by
  have h := Quaternion.normSq_eq_norm_mul_self unitI
  rw [Quaternion.normSq_def'] at h
  have h1 : ‖unitI‖ * ‖unitI‖ = 1 := by rw [← h]; simp [unitI]
  nlinarith [norm_nonneg unitI]

theorem blockMap_exp_linear_example (b : BoxWalk.BoxLk 1 0) :
    ‖(blockMap (1 / 2) (by norm_num) (BoxWalk.boxPaths 1) (BoxWalk.boxW 1) 0
        (expCfg (fun _ => unitI) (fun _ => unitI_re) (1 / 32)) b : ℍr) -
        NormedSpace.exp ((1 / 32 : ℝ) • sixSgn (BoxWalk.boxPathsIdx 1 0 b) fun _ => unitI)‖ ≤
      257 * ((1 / 32 : ℝ) * 1) ^ 2 ∧ 257 * ((1 / 32 : ℝ) * 1) ^ 2 < 2 :=
  ⟨(blockMap_exp_linear 1 (by norm_num) (by norm_num) 0 (fun _ => unitI) (fun _ => unitI_re)
      (M := 1) (ε := 1 / 32) zero_le_one (fun _ => le_of_eq unitI_norm) (by norm_num)
      (by norm_num) b).1, by norm_num⟩

theorem sixSgn_zero {L : Type*} (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) :
    sixSgn P (fun _ => (0 : ℍr)) = 0 := by
  unfold sixSgn pathSgn
  simp

/-- **Degenerate field**: with `a = 0` the statement says the block value of `U ≡ 1` is `1`. -/
theorem blockMap_zero_field (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (m : ℕ) (ε : ℝ) (hε : 0 ≤ ε) (b : BoxWalk.BoxLk L m) :
    (blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m
      (expCfg (fun _ => (0 : ℍr)) (fun _ => rfl) ε) b : ℍr) = 1 := by
  have h := (blockMap_exp_linear L hr hr0 m (fun _ => (0 : ℍr)) (fun _ => rfl) (M := 0) (ε := ε)
    le_rfl (fun _ => by simp) hε (by simp) b).1
  rw [sixSgn_zero, smul_zero, NormedSpace.exp_zero] at h
  have h0 : ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m
      (expCfg (fun _ => (0 : ℍr)) (fun _ => rfl) ε) b : ℍr) - 1‖ = 0 :=
    le_antisymm (by simpa using h) (norm_nonneg _)
  exact sub_eq_zero.1 (norm_eq_zero.1 h0)

end BlockLinearKernel

#print axioms BlockLinearKernel.unitI_norm
#print axioms BlockLinearKernel.blockMap_exp_linear_example
#print axioms BlockLinearKernel.blockMap_zero_field
