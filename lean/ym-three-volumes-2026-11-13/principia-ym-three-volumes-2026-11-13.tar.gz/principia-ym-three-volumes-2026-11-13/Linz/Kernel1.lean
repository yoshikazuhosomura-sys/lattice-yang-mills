import Linz.Expand1
import Push.Lat1

/-!
# The linearisation of the block map at `U = 1` is the path-kernel operator `Cop (pathKernel)`

Paper: the block map of the induction (`ChainBlockMap.blockMap` on the box, paths
`WalkCast.walk` with weights `sixWeight`, base point `2y`, followed by the radial retraction)
and the linear constraint operator of the Gaussian stage covariance
(`TorusFourier.Cop β (LatticeTorus.pathKernel N)`, used in `LatticePush.stepOp`).

For an imaginary-quaternion (su(2)-valued) link field `a` and `U = exp(ε a)`:
* `walkMap_exp_linear`: the block value at a coarse link is `exp(ε · sixSgn)` up to
  `257 (ε M)²` (`M = sup ‖a‖`, `ε M ≤ 1/32`, `r₀ ≤ 1/2`), and every real-linear component
  (`f = re, imI, imJ, imK`, the colours) of `sixSgn` is `Cop β (pathKernel N)` applied to the
  same component of `a`;
* `blockMap_exp_linear`: the same statement for `ChainBlockMap.blockMap` on the periodic boxes
  `BoxWalk.BoxLk L m` (fine modulus `2^(m+1) L`, coarse-to-fine map `y ↦ 2y`);
* `push_exp_linear`: the same statement on the torus types of `LatticePush` (`betaT 4 L`,
  fine modulus `2 L`), so the operator is literally the one in `LatticePush.stepOp L`.
-/

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

/-! ## 1. Lengths and signs of the walk -/

theorem fwd_length (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : (WalkCast.fwd d z n).length ≤ 1 := by
  unfold WalkCast.fwd; split_ifs <;> simp

theorem back_length (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : (WalkCast.back d w n).length ≤ 1 := by
  unfold WalkCast.back; split_ifs <;> simp

theorem len_shape (l1 l2 l3 s l4 l5 l6 : List WalkCast.Link) (h1 : l1.length ≤ 1)
    (h2 : l2.length ≤ 1) (h3 : l3.length ≤ 1) (hs : s.length = 2) (h4 : l4.length ≤ 1)
    (h5 : l5.length ≤ 1) (h6 : l6.length ≤ 1) :
    (l1 ++ l2 ++ l3 ++ s ++ l4 ++ l5 ++ l6).length ≤ 8 := by
  simp only [List.length_append]; omega

theorem walk_length (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    (WalkCast.walk μ o A).length ≤ 8 := by
  dsimp only [WalkCast.walk]
  exact len_shape _ _ _ _ _ _ _ (fwd_length _ _ _) (fwd_length _ _ _) (fwd_length _ _ _) rfl
    (back_length _ _ _) (back_length _ _ _) (back_length _ _ _)

variable {G : Type*} [AddCommGroup G]

theorem pathsCast_length {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    (b : Lc) (o : Fin 6) (A : Fin 3 → Fin 3) : (pathsCast φ base dir b o A).length ≤ 8 := by
  unfold pathsCast; rw [List.length_map]; exact walk_length _ _ _

/-- On a cast walk the signed sum is the sum of `sign · a` over the steps. -/
theorem pathSgn_cast (φ : (Fin 4 → ℤ) →+ G) (x : G) (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3)
    (a : G × Fin 4 → ℍr) :
    pathSgn a ((WalkCast.walk μ o A).map (linkCast φ x)) =
      ((WalkCast.walk μ o A).map fun l => (l.1 : ℝ) • a (x + φ l.2.1, l.2.2)).sum := by
  unfold pathSgn
  rw [List.map_map]
  congr 1
  refine List.map_congr_left fun l hl => ?_
  simp only [Function.comp_apply, linkCast]
  rcases WalkCast.walk_sign μ o A l hl with h | h
  · simp [h]
  · simp [h]

/-! ## 2. The reduction `ℤ⁴ → (ℤ/N)⁴` and the path kernel -/

/-- The reduction `ℤ⁴ → (ZMod N)⁴`. -/
def redN (N : ℕ) : (Fin 4 → ℤ) →+ (Fin 4 → ZMod N) :=
  AddMonoidHom.compLeft (Int.castAddHom (ZMod N)) (Fin 4)

theorem redN_apply (N : ℕ) (z : Fin 4 → ℤ) : redN N z = fun j => (z j : ZMod N) := rfl

theorem sum_fin3 {M : Type*} [AddCommMonoid M] (g : (Fin 3 → Fin 3) → M) :
    ∑ A, g A = ∑ a0, ∑ a1, ∑ a2, g ![a0, a1, a2] := by
  rw [← (Fin.consEquiv fun _ => Fin 3).sum_comp, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun a0 _ => ?_
  rw [← (Fin.consEquiv fun _ => Fin 3).sum_comp, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun a1 _ => ?_
  rw [← (Fin.consEquiv fun _ => Fin 3).sum_comp, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun a2 _ => ?_
  rw [Fintype.sum_unique]
  congr 1

theorem sixWeight_vec (a0 a1 a2 : Fin 3) :
    sixWeight ![a0, a1, a2] = LatticePath.wt a0 * LatticePath.wt a1 * LatticePath.wt a2 / 6 := by
  unfold sixWeight
  rw [Fin.prod_univ_three]
  simp only [Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.cons_val_two, Matrix.head_cons,
    Matrix.tail_cons]
  show (1 / 6 : ℝ) * (ChainBlockMap.wt a0 * ChainBlockMap.wt a1 * ChainBlockMap.wt a2) = _
  rw [show ChainBlockMap.wt = LatticePath.wt from rfl]
  ring

/-- One list of signed links against the kernel entries it produces. -/
theorem list_kernel (N : ℕ) [NeZero N] (x : Fin 4 → ZMod N) (F : (Fin 4 → ZMod N) → Fin 4 → ℂ)
    (Ls : List WalkCast.Link) :
    ∑ r : Fin 4 → ZMod N, ∑ ν : Fin 4,
        (Ls.map fun l => if l.2.2 = ν ∧ (fun j => (l.2.1 j : ZMod N)) = r then (l.1 : ℂ)
          else 0).sum * F (x + r) ν =
      (Ls.map fun l => (l.1 : ℂ) * F (x + fun j => (l.2.1 j : ZMod N)) l.2.2).sum := by
  induction Ls with
  | nil => simp
  | cons l Ls ih =>
    simp only [List.map_cons, List.sum_cons, add_mul, Finset.sum_add_distrib, ih]
    congr 1
    simp only [ite_and, ite_mul, zero_mul, Finset.sum_ite_eq, Finset.sum_ite_eq', Finset.mem_univ,
      if_true]

/-- Three nested finite sums: move the innermost one outside. -/
theorem sum3_comm {R V O : Type*} [Fintype R] [Fintype V] [Fintype O] (g : R → V → O → ℂ) :
    ∑ r, ∑ ν, ∑ o, g r ν o = ∑ o, ∑ r, ∑ ν, g r ν o :=
  calc ∑ r, ∑ ν, ∑ o, g r ν o = ∑ r, ∑ o, ∑ ν, g r ν o :=
        Finset.sum_congr rfl fun _ _ => Finset.sum_comm
    _ = ∑ o, ∑ r, ∑ ν, g r ν o := Finset.sum_comm

theorem ofReal_f_list (f : ℍr →ₗ[ℝ] ℝ) (l : List ℍr) :
    ((f l.sum : ℝ) : ℂ) = (l.map fun q => ((f q : ℝ) : ℂ)).sum := by
  induction l with
  | nil => simp
  | cons q l ih => simp [ih]

/-- **Colour identity**: a real-linear component of the signed six-order average of `a` along the
cast walk is the path-kernel operator applied to that component of `a`. -/
theorem colour_kernel (N : ℕ) [NeZero N] (x : Fin 4 → ZMod N) (μ : Fin 4)
    (a : (Fin 4 → ZMod N) × Fin 4 → ℍr) (f : ℍr →ₗ[ℝ] ℝ) :
    ((f (∑ o, ∑ A, sixWeight A •
        pathSgn a ((WalkCast.walk μ o A).map (linkCast (redN N) x))) : ℝ) : ℂ) =
      ∑ r, ∑ ν, LatticeTorus.pathKernel N r μ ν * ((f (a (x + r, ν)) : ℝ) : ℂ) := by
  set F : (Fin 4 → ZMod N) → Fin 4 → ℂ := fun y ν => ((f (a (y, ν)) : ℝ) : ℂ) with hF
  have hL : ((f (∑ o, ∑ A, sixWeight A •
        pathSgn a ((WalkCast.walk μ o A).map (linkCast (redN N) x))) : ℝ) : ℂ) =
      ∑ o : Fin 6, ∑ a0 : Fin 3, ∑ a1 : Fin 3, ∑ a2 : Fin 3,
        ((LatticePath.wt a0 * LatticePath.wt a1 * LatticePath.wt a2 / 6 : ℝ) : ℂ) *
          ((LatticePath.walk μ o ![a0, a1, a2]).map fun l =>
            (l.1 : ℂ) * F (x + fun j => (l.2.1 j : ZMod N)) l.2.2).sum := by
    simp only [pathSgn_cast, map_sum, map_smul, smul_eq_mul, Complex.ofReal_sum,
      Complex.ofReal_mul]
    refine Finset.sum_congr rfl fun o _ => ?_
    rw [sum_fin3]
    refine Finset.sum_congr rfl fun a0 _ => Finset.sum_congr rfl fun a1 _ =>
      Finset.sum_congr rfl fun a2 _ => ?_
    rw [sixWeight_vec, ofReal_f_list, List.map_map]
    congr 1
    have hw : WalkCast.walk μ o ![a0, a1, a2] = LatticePath.walk μ o ![a0, a1, a2] := rfl
    rw [hw]
    congr 1
    refine List.map_congr_left fun l _ => ?_
    simp only [Function.comp_apply, map_smul, smul_eq_mul, Complex.ofReal_mul,
      Complex.ofReal_intCast, hF, redN_apply]
  rw [hL]
  unfold LatticeTorus.pathKernel
  simp only [Finset.sum_mul]
  symm
  conv_lhs => rw [sum3_comm]
  refine Finset.sum_congr rfl fun o _ => ?_
  conv_lhs => rw [sum3_comm]
  refine Finset.sum_congr rfl fun a0 _ => ?_
  conv_lhs => rw [sum3_comm]
  refine Finset.sum_congr rfl fun a1 _ => ?_
  conv_lhs => rw [sum3_comm]
  refine Finset.sum_congr rfl fun a2 _ => ?_
  simp only [mul_assoc]
  simp only [← Finset.mul_sum]
  congr 1
  exact list_kernel N x F _

/-! ## 3. The block map at `U = exp(ε a)` -/

/-- **Generic form** (coarse links `H × Fin 4`, coarse-to-fine map `β`, fine modulus `N`). -/
theorem walkMap_exp_linear {N : ℕ} [NeZero N] {H : Type*} [AddCommGroup H]
    (β : H →+ (Fin 4 → ZMod N)) {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (a : (Fin 4 → ZMod N) × Fin 4 → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : H × Fin 4) :
    ‖retract r₀ (sixAvg (pathsCast (redN N) (fun c : H × Fin 4 => β c.1) Prod.snd b)
        fun ℓ => NormedSpace.exp (ε • a ℓ)) -
      NormedSpace.exp (ε • sixSgn (pathsCast (redN N) (fun c : H × Fin 4 => β c.1) Prod.snd b) a)‖
        ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ,
      ((f (sixSgn (pathsCast (redN N) (fun c : H × Fin 4 => β c.1) Prod.snd b) a) : ℝ) : ℂ) =
        TorusFourier.Cop β (LatticeTorus.pathKernel N) (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ))
          b.1 b.2 :=
  ⟨retract_sixAvg_exp _ (pathsCast_length _ _ _ b) hr hr0 a ha hM0 hM hε hεM,
    fun f => colour_kernel N (β b.1) b.2 a f⟩

/-- Unit-quaternion configuration `exp(ε a)` of an imaginary field (a ball-valued configuration). -/
noncomputable def expCfg {Λ : Type*} (a : Λ → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) (ε : ℝ) : Cfg Λ :=
  fun ℓ => ⟨NormedSpace.exp (ε • a ℓ), (mem_ball_iff _).2 (le_of_eq (by
    rw [Quaternion.norm_exp, Quaternion.re_smul, ha, smul_zero, NormedSpace.exp_zero, norm_one]))⟩

/-- **The block map of the box chain, linearised at `U = 1`.** For the imaginary field `a` on the
fine links of the box `(ℤ/2^(m+1)L)⁴` and `U = exp(ε a)`: the block value on the coarse link `b` is
`exp(ε · sixSgn)` up to `257 (ε M)²`, and each real-linear component of `sixSgn` (each colour) is
`Cop (y ↦ 2y) (pathKernel (2^(m+1) L))` applied to that component of `a`. -/
theorem blockMap_exp_linear (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2) (m : ℕ)
    (a : BoxWalk.BoxLk L (m + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk L m) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx L m b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ))
        b.1 b.2 := by
  rw [BoxWalk.boxMap_eq L hr]
  exact walkMap_exp_linear ((BoxWalk.double L m).compLeft (Fin 4)) hr hr0 a ha hM0 hM hε hεM b

/-- **The same on the torus types of `LatticePush`**: the operator is `Cop (betaT 4 L)
(pathKernel (2 L))`, the one in `LatticePush.stepOp L` (`stepOp_eq`). -/
theorem push_exp_linear (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (hr0 : r₀ ≤ 1 / 2)
    (a : (Fin 4 → ZMod (2 * L)) × Fin 4 → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : (Fin 4 → ZMod L) × Fin 4) :
    ‖retract r₀ (sixAvg (pathsCast (redN (2 * L)) (fun c => TorusFourier.betaT 4 L c.1) Prod.snd b)
        fun ℓ => (expCfg a ha ε ℓ : ℍr)) -
      NormedSpace.exp (ε • sixSgn
        (pathsCast (redN (2 * L)) (fun c => TorusFourier.betaT 4 L c.1) Prod.snd b) a)‖
        ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (pathsCast (redN (2 * L))
        (fun c => TorusFourier.betaT 4 L c.1) Prod.snd b) a) : ℝ) : ℂ) =
      TorusFourier.Cop (TorusFourier.betaT 4 L) (LatticeTorus.pathKernel (2 * L))
        (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ)) b.1 b.2 :=
  walkMap_exp_linear (TorusFourier.betaT 4 L) hr hr0 a ha hM0 hM hε hεM b

/-- The operator of the stage step is this `Cop`. -/
theorem stepOp_eq (L : ℕ) [NeZero L] (T : LatticePush.Fld (2 * L) → LatticePush.Fld (2 * L))
    (w : LatticePush.Fld L) :
    LatticePush.stepOp L T w = TorusFourier.Cop (TorusFourier.betaT 4 L)
      (LatticeTorus.pathKernel (2 * L))
      (T (TorusFourier.Cadj (TorusFourier.betaT 4 L) (LatticeTorus.pathKernel (2 * L)) w)) := rfl

/-! ## 4. The three colours -/

/-- The colour components `imI, imJ, imK` as real-linear maps. -/
def colour : Fin 3 → (ℍr →ₗ[ℝ] ℝ)
  | 0 => { toFun := fun q => q.imI, map_add' := fun _ _ => rfl, map_smul' := fun _ _ => rfl }
  | 1 => { toFun := fun q => q.imJ, map_add' := fun _ _ => rfl, map_smul' := fun _ _ => rfl }
  | 2 => { toFun := fun q => q.imK, map_add' := fun _ _ => rfl, map_smul' := fun _ _ => rfl }

/-- The linear part is imaginary, and colour by colour it is `Cop (pathKernel)` of the field. -/
theorem blockMap_linear_colours (L : ℕ) [NeZero L] (m : ℕ) (a : BoxWalk.BoxLk L (m + 1) → ℍr)
    (ha : ∀ ℓ, (a ℓ).re = 0) (b : BoxWalk.BoxLk L m) :
    (sixSgn (BoxWalk.boxPathsIdx L m b) a).re = 0 ∧
    ∀ c : Fin 3, ((colour c (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((colour c (a (y, ν)) : ℝ) : ℂ))
        b.1 b.2 :=
  ⟨re_sixSgn _ ha, fun c => colour_kernel _ _ b.2 a (colour c)⟩

end BlockLinearKernel

#print axioms BlockLinearKernel.colour_kernel
#print axioms BlockLinearKernel.walkMap_exp_linear
#print axioms BlockLinearKernel.blockMap_exp_linear
#print axioms BlockLinearKernel.push_exp_linear
#print axioms BlockLinearKernel.stepOp_eq
#print axioms BlockLinearKernel.blockMap_linear_colours
