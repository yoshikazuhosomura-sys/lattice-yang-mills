import Linz.Kernel1

/-!
# The linearisation for any retraction threshold `r₀ < 1`

`blockMap_exp_linear` assumed `r₀ ≤ 1/2`. Here the threshold may be any `0 < r₀ ≤ 1 − 9 ε M`
(so every `r₀ < 1` for `ε M ≤ min(1/32, (1 − r₀)/9)`): `blockMap_exp_linear_gen`, same remainder
`257 (ε M)²` and the same colour identity.
-/

namespace BlockLinear

open ChainBlockMap
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

/-- The retraction at `1 + v` for any threshold `r₀ ≤ 1 − s`. -/
theorem retract_one_add_gen {r₀ : ℝ} (hr : 0 < r₀) {v : ℍr} {s ρ : ℝ}
    (hv : ‖v‖ ≤ s) (hs : s ≤ 1 / 2) (hrs : r₀ ≤ 1 - s) (hre : |v.re| ≤ ρ) :
    ‖retract r₀ (1 + v) - (1 + v)‖ ≤ 2 * ρ + s ^ 2 := by
  have hq : 1 - s ≤ ‖1 + v‖ := by
    have := norm_sub_norm_le (1 : ℍr) (-v)
    simp only [norm_one, norm_neg, sub_neg_eq_add] at this
    linarith
  have hq0 : r₀ ≤ ‖1 + v‖ := by linarith
  have hpos : 0 < ‖1 + v‖ := lt_of_lt_of_le hr hq0
  rw [(retract_of_le hr hq0).1]
  have e : ‖1 + v‖⁻¹ • (1 + v) - (1 + v) = (‖1 + v‖⁻¹ - 1) • (1 + v) := by
    rw [sub_smul, one_smul]
  rw [e, norm_smul, Real.norm_eq_abs]
  have ht := norm_one_add_sq v
  set t := ‖1 + v‖ with htdef
  have hk : |t⁻¹ - 1| * t = |1 - t| := by
    rw [show t⁻¹ - 1 = (1 - t) / t by field_simp, abs_div, abs_of_pos hpos, div_mul_cancel₀ _ hpos.ne']
  rw [hk]
  have hv0 : 0 ≤ ‖v‖ := norm_nonneg _
  have hre' := abs_le.1 hre
  have hs0 : 0 ≤ s := hv0.trans hv
  have hvs : ‖v‖ ^ 2 ≤ s ^ 2 := pow_le_pow_left₀ hv0 hv 2
  rw [abs_le]
  constructor <;> nlinarith [hpos, hre'.1, hre'.2]


section Exp

variable {L : Type*}

/-- The expansion of `retract ∘ sixAvg` for any threshold `r₀ ≤ 1 − 9 ε M`. -/
theorem retract_sixAvg_exp_gen (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool))
    (hlen : ∀ o A, (P o A).length ≤ 8) {r₀ : ℝ} (hr : 0 < r₀)
    (a : L → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M) (hM : ∀ ℓ, ‖a ℓ‖ ≤ M)
    (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (hr0 : r₀ ≤ 1 - 9 * (ε * M)) :
    ‖retract r₀ (sixAvg P fun ℓ => NormedSpace.exp (ε • a ℓ)) -
        NormedSpace.exp (ε • sixSgn P a)‖ ≤ 257 * (ε * M) ^ 2 := by
  set δ := ε * M with hδdef
  have hδ : 0 ≤ δ := mul_nonneg hε hM0
  set U : L → ℍr := fun ℓ => NormedSpace.exp (ε • a ℓ) with hUdef
  have hna : ∀ ℓ, ‖ε • a ℓ‖ ≤ δ := fun ℓ => by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    exact mul_le_mul_of_nonneg_left (hM _) hε
  have hrea : ∀ ℓ, (ε • a ℓ).re = 0 := fun ℓ => by rw [Quaternion.re_smul, ha, smul_zero]
  have hU1 : ∀ ℓ, ‖U ℓ‖ = 1 := fun ℓ => (exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).1
  have hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ := fun ℓ =>
    ((exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).2.1).trans (hna ℓ)
  obtain ⟨hA, hB, hC⟩ := sixAvg_near_one P hδ hU1 hU2 hlen
  push_cast at hA hB hC
  set lin := sixLin P U
  set e := sixAvg P U - 1 - lin
  set v := sixAvg P U - 1
  have hv : v = lin + e := by simp only [v, e]; abel
  have hvn : ‖v‖ ≤ 8 * δ + 32 * δ ^ 2 := by
    rw [hv]; refine (norm_add_le _ _).trans ?_; nlinarith [hA, hB]
  have hvre : |v.re| ≤ 36 * δ ^ 2 := by
    rw [hv, Quaternion.re_add]
    refine (abs_add_le _ _).trans ?_
    have := abs_re_le_norm e
    nlinarith [hA, hC]
  have hs : 8 * δ + 32 * δ ^ 2 ≤ 1 / 2 := by nlinarith
  have hrs : r₀ ≤ 1 - (8 * δ + 32 * δ ^ 2) := by nlinarith
  have hR := retract_one_add_gen hr hvn hs hrs hvre
  have h1v : 1 + v = sixAvg P U := by simp only [v]; abel
  rw [h1v] at hR
  -- linear part against the signed field
  set S := sixSgn P a
  have hlinS : ‖lin - ε • S‖ ≤ 8 * δ ^ 2 := by
    have e2 : lin - ε • S = ∑ o, ∑ A, sixWeight A •
        (pathLin U (P o A) - ε • pathSgn a (P o A)) := by
      simp only [lin, S, sixLin, sixSgn, Finset.smul_sum, smul_sub, Finset.sum_sub_distrib]
      congr 1
      refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
      rw [smul_comm]
    rw [e2]
    refine norm_sixSum_le _ fun o A => (pathLin_exp a ha hε hM (by linarith) (P o A)).trans ?_
    have := hlen o A
    have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
    nlinarith [sq_nonneg δ]
  have hSn : ‖ε • S‖ ≤ 8 * δ := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    have : ‖S‖ ≤ 8 * M := norm_sixSum_le _ fun o A => (norm_pathSgn_le hM (P o A)).trans (by
      have := hlen o A
      have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
      nlinarith)
    nlinarith
  have hSre : (ε • S).re = 0 := by rw [Quaternion.re_smul, re_sixSgn P ha, smul_zero]
  have hE := (exp_imag _ hSre (by linarith)).2.2
  have hS2 : ‖ε • S‖ ^ 2 ≤ 64 * δ ^ 2 := by nlinarith [norm_nonneg (ε • S)]
  have key : retract r₀ (sixAvg P U) - NormedSpace.exp (ε • S) =
      (retract r₀ (sixAvg P U) - sixAvg P U) + e + (lin - ε • S) -
        (NormedSpace.exp (ε • S) - 1 - ε • S) := by
    simp only [e]; abel
  rw [key]
  calc _ ≤ ‖retract r₀ (sixAvg P U) - sixAvg P U‖ + ‖e‖ + ‖lin - ε • S‖ +
        ‖NormedSpace.exp (ε • S) - 1 - ε • S‖ := by
        refine (norm_sub_le _ _).trans ?_
        gcongr
        refine (norm_add_le _ _).trans ?_
        gcongr
        exact norm_add_le _ _
    _ ≤ (2 * (36 * δ ^ 2) + (8 * δ + 32 * δ ^ 2) ^ 2) + 32 * δ ^ 2 + 8 * δ ^ 2 + 64 * δ ^ 2 := by
        gcongr
        · nlinarith [hA]
        · exact hE.trans hS2
    _ ≤ 257 * δ ^ 2 := by
        have h9 : 8 * δ + 32 * δ ^ 2 ≤ 9 * δ := by nlinarith
        have h81 : (8 * δ + 32 * δ ^ 2) ^ 2 ≤ (9 * δ) ^ 2 :=
          pow_le_pow_left₀ (by positivity) h9 2
        nlinarith

end Exp

end BlockLinear

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear

local notation "ℍr" => Quaternion ℝ

/-- **The box block map, linearised at `U = 1`, for any threshold `0 < r₀ ≤ 1 − 9 ε M`.** -/
theorem blockMap_exp_linear_gen (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ)
    (a : BoxWalk.BoxLk L (m + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (hr0 : r₀ ≤ 1 - 9 * (ε * M))
    (b : BoxWalk.BoxLk L m) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx L m b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ))
        b.1 b.2 := by
  rw [BoxWalk.boxMap_eq L hr]
  exact ⟨retract_sixAvg_exp_gen _ (pathsCast_length _ _ _ b) hr a ha hM0 hM hε hεM hr0,
    fun f => colour_kernel _ (((BoxWalk.double L m).compLeft (Fin 4)) b.1) b.2 a f⟩

end BlockLinearKernel

#print axioms BlockLinear.retract_one_add_gen
#print axioms BlockLinearKernel.blockMap_exp_linear_gen
