import Mathlib

/-!
# Tilting a probability measure by a function of oscillation `2c` moves each set by at most
# `(e^c - 1)/(e^c + 1) = tanh(c/2)` 

Paper correspondence: (the elementary lemma of the Dobrushin route).
`ratio_dev` is the real-number core (the extremal case is a perfect square:
`(1-a)(a s + a + s - 1) - a s² (2 - a (s+1)) = (s-1)(a s - 1 + a)²`), `tilt_tv` the measure form:
for a probability measure `p`, measurable `g` with `m ≤ g ≤ m + 2c` and a measurable set `S`,
`|∫_S e^g dp / ∫ e^g dp - p(S)| ≤ (e^c - 1)/(e^c + 1)`.
-/

namespace Tilt

open MeasureTheory

/-- one side of the core inequality -/
theorem upper_core (a A B e s : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (he : 0 < e) (hs : 1 ≤ s)
    (hA0 : 0 ≤ A) (hA2 : A ≤ a * e * s ^ 2) (hB1 : (1 - a) * e ≤ B) (hAB : 0 < A + B) :
    A / (A + B) - a ≤ (s - 1) / (s + 1) := by
  have hs1 : 0 < s + 1 := by linarith
  rw [div_sub' (ne_of_gt hAB), div_le_div_iff₀ hAB hs1]
  -- goal: (A - (A + B) * a) * (s + 1) ≤ (s - 1) * (A + B)   (shape up to ring)
  have hv : 0 ≤ a * (s + 1) + (s - 1) := by nlinarith
  have hBv : (1 - a) * e * (a * (s + 1) + (s - 1)) ≤ B * (a * (s + 1) + (s - 1)) :=
    mul_le_mul_of_nonneg_right hB1 hv
  have hsq : 0 ≤ (s - 1) * (a * s - 1 + a) ^ 2 := mul_nonneg (by linarith) (sq_nonneg _)
  by_cases hu : 2 - a * (s + 1) ≤ 0
  · have : A * (2 - a * (s + 1)) ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hA0 hu
    have : 0 ≤ (1 - a) * e * (a * (s + 1) + (s - 1)) :=
      mul_nonneg (mul_nonneg (by linarith) he.le) hv
    nlinarith
  · push_neg at hu
    have hAu : A * (2 - a * (s + 1)) ≤ a * e * s ^ 2 * (2 - a * (s + 1)) :=
      mul_le_mul_of_nonneg_right hA2 hu.le
    have key : a * s ^ 2 * (2 - a * (s + 1)) ≤ (1 - a) * (a * (s + 1) + (s - 1)) := by
      nlinarith [hsq]
    have key' : e * (a * s ^ 2 * (2 - a * (s + 1))) ≤ e * ((1 - a) * (a * (s + 1) + (s - 1))) :=
      mul_le_mul_of_nonneg_left key he.le
    nlinarith

/-- **The core inequality.**  If `A ∈ [a e, a e s²]` and `B ∈ [(1-a) e, (1-a) e s²]` then
`|A/(A+B) - a| ≤ (s-1)/(s+1)`. -/
theorem ratio_dev (a A B e s : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (he : 0 < e) (hs : 1 ≤ s)
    (hA1 : a * e ≤ A) (hA2 : A ≤ a * e * s ^ 2)
    (hB1 : (1 - a) * e ≤ B) (hB2 : B ≤ (1 - a) * e * s ^ 2) (hAB : 0 < A + B) :
    |A / (A + B) - a| ≤ (s - 1) / (s + 1) := by
  have hA0 : 0 ≤ A := le_trans (mul_nonneg ha0 he.le) hA1
  have hB0 : 0 ≤ B := le_trans (mul_nonneg (by linarith) he.le) hB1
  rw [abs_le]
  constructor
  · -- lower side: apply the upper side to the complement (a ↦ 1 - a, A ↔ B)
    have h := upper_core (1 - a) B A e s (by linarith) (by linarith) he hs hB0
      (by simpa using hB2) (by simpa using hA1) (by linarith)
    have e1 : B / (B + A) = 1 - A / (A + B) := by
      rw [add_comm B A]
      field_simp
      ring
    rw [e1] at h
    linarith
  · exact upper_core a A B e s ha0 ha1 he hs hA0 hA2 hB1 hAB

/-- **Tilted measure, set by set** (`tanh(c/2) = (e^c - 1)/(e^c + 1)`). -/
theorem tilt_tv {Ω : Type*} [MeasurableSpace Ω] (p : Measure Ω) [IsProbabilityMeasure p]
    (g : Ω → ℝ) (hg : Measurable g) (m c : ℝ) (hc : 0 ≤ c)
    (hlo : ∀ x, m ≤ g x) (hhi : ∀ x, g x ≤ m + 2 * c) (S : Set Ω) (hS : MeasurableSet S) :
    |(∫ x in S, Real.exp (g x) ∂p) / (∫ x, Real.exp (g x) ∂p) - p.real S|
      ≤ (Real.exp c - 1) / (Real.exp c + 1) := by
  have hmeas : Measurable fun x => Real.exp (g x) := Real.measurable_exp.comp hg
  have hbd : ∀ x, ‖Real.exp (g x)‖ ≤ Real.exp (m + 2 * c) := fun x => by
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_exp.2 (hhi x)
  have hint : Integrable (fun x => Real.exp (g x)) p :=
    Integrable.of_bound hmeas.aestronglyMeasurable _ (Filter.Eventually.of_forall hbd)
  have hsplit : ∫ x, Real.exp (g x) ∂p
      = (∫ x in S, Real.exp (g x) ∂p) + ∫ x in Sᶜ, Real.exp (g x) ∂p :=
    (integral_add_compl hS hint).symm
  have hlow : ∀ T : Set Ω, MeasurableSet T →
      p.real T * Real.exp m ≤ ∫ x in T, Real.exp (g x) ∂p := fun T hT => by
    have := setIntegral_mono_on (integrable_const (Real.exp m)).integrableOn hint.integrableOn hT
      (fun x _ => Real.exp_le_exp.2 (hlo x))
    rwa [setIntegral_const, smul_eq_mul] at this
  have hup : ∀ T : Set Ω, MeasurableSet T →
      ∫ x in T, Real.exp (g x) ∂p ≤ p.real T * Real.exp (m + 2 * c) := fun T hT => by
    have := setIntegral_mono_on hint.integrableOn (integrable_const (Real.exp (m + 2 * c))).integrableOn
      hT (fun x _ => Real.exp_le_exp.2 (hhi x))
    rwa [setIntegral_const, smul_eq_mul] at this
  have hcompl : p.real Sᶜ = 1 - p.real S := by
    rw [probReal_compl_eq_one_sub hS]
  have hE : Real.exp (m + 2 * c) = Real.exp m * Real.exp c ^ 2 := by
    rw [Real.exp_add, ← Real.exp_nat_mul]
    push_cast
    ring_nf
  have hA1 := hlow S hS
  have hA2 := hup S hS
  have hB1 := hlow Sᶜ hS.compl
  have hB2 := hup Sᶜ hS.compl
  rw [hcompl] at hB1 hB2
  rw [hE] at hA2 hB2
  have hpos : 0 < ∫ x, Real.exp (g x) ∂p := integral_exp_pos hint
  rw [hsplit] at hpos ⊢
  refine ratio_dev (p.real S) _ _ (Real.exp m) (Real.exp c) measureReal_nonneg
    measureReal_le_one (Real.exp_pos m) (Real.one_le_exp hc) hA1 (by linarith [hA2]) hB1
    (by linarith [hB2]) hpos


/-- **Relative form (the Dobrushin coefficient of one link).**  Two Gibbs weights `e^a`, `e^{a'}`
on the same probability space whose difference has oscillation `≤ 2c` give normalised measures
that differ on every measurable set by at most `(e^c - 1)/(e^c + 1) = tanh(c/2)`.  For the SU(2)
link conditional distributions `∝ e^{β⟨U,A⟩}` with staples `A`, `A'`, `|A - A'| ≤ 2`, one has
`2c = 4|β|`, i.e. the bound `tanh |β|` (paper). -/
theorem tilt_tv_rel {Ω : Type*} [MeasurableSpace Ω] (p : Measure Ω) [IsProbabilityMeasure p]
    (a a' : Ω → ℝ) (ha : Measurable a) (ha' : Measurable a') (K : ℝ)
    (hK : ∀ x, |a x| ≤ K) (hK' : ∀ x, |a' x| ≤ K) (m c : ℝ) (hc : 0 ≤ c)
    (hlo : ∀ x, m ≤ a' x - a x) (hhi : ∀ x, a' x - a x ≤ m + 2 * c)
    (S : Set Ω) (hS : MeasurableSet S) :
    |(∫ x in S, Real.exp (a' x) ∂p) / (∫ x, Real.exp (a' x) ∂p)
      - (∫ x in S, Real.exp (a x) ∂p) / (∫ x, Real.exp (a x) ∂p)|
      ≤ (Real.exp c - 1) / (Real.exp c + 1) := by
  have hbd : ∀ (b : Ω → ℝ), (∀ x, |b x| ≤ K) → ∀ x, ‖Real.exp (b x)‖ ≤ Real.exp K := fun b hb x => by
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    exact Real.exp_le_exp.2 ((le_abs_self _).trans (hb x))
  have hint : Integrable (fun x => Real.exp (a x)) p :=
    Integrable.of_bound (Real.measurable_exp.comp ha).aestronglyMeasurable _
      (Filter.Eventually.of_forall (hbd a hK))
  have hint' : Integrable (fun x => Real.exp (a' x)) p :=
    Integrable.of_bound (Real.measurable_exp.comp ha').aestronglyMeasurable _
      (Filter.Eventually.of_forall (hbd a' hK'))
  have hlow : ∀ T : Set Ω, MeasurableSet T →
      Real.exp m * ∫ x in T, Real.exp (a x) ∂p ≤ ∫ x in T, Real.exp (a' x) ∂p := fun T hT => by
    rw [← integral_const_mul]
    refine setIntegral_mono_on (hint.integrableOn.const_mul _) hint'.integrableOn hT
      (fun x _ => ?_)
    rw [← Real.exp_add]
    exact Real.exp_le_exp.2 (by linarith [hlo x])
  have hup : ∀ T : Set Ω, MeasurableSet T →
      ∫ x in T, Real.exp (a' x) ∂p ≤ Real.exp m * Real.exp c ^ 2 * ∫ x in T, Real.exp (a x) ∂p :=
    fun T hT => by
    rw [← integral_const_mul]
    refine setIntegral_mono_on hint'.integrableOn (hint.integrableOn.const_mul _) hT
      (fun x _ => ?_)
    rw [← Real.exp_nat_mul, ← Real.exp_add, ← Real.exp_add]
    exact Real.exp_le_exp.2 (by push_cast; linarith [hhi x])
  have hsplit : ∀ b : Ω → ℝ, Integrable (fun x => Real.exp (b x)) p →
      ∫ x, Real.exp (b x) ∂p = (∫ x in S, Real.exp (b x) ∂p) + ∫ x in Sᶜ, Real.exp (b x) ∂p :=
    fun b hb => (integral_add_compl hS hb).symm
  set α := ∫ x in S, Real.exp (a x) ∂p with hα
  set γ := ∫ x in Sᶜ, Real.exp (a x) ∂p with hγ
  have hα0 : 0 ≤ α := setIntegral_nonneg hS (fun x _ => (Real.exp_pos _).le)
  have hγ0 : 0 ≤ γ := setIntegral_nonneg hS.compl (fun x _ => (Real.exp_pos _).le)
  have hZ : ∫ x, Real.exp (a x) ∂p = α + γ := hsplit a hint
  have hZpos : 0 < α + γ := by rw [← hZ]; exact integral_exp_pos hint
  have hpos' : 0 < ∫ x, Real.exp (a' x) ∂p := integral_exp_pos hint'
  rw [hZ, hsplit a' hint']
  rw [hsplit a' hint'] at hpos'
  have hA1 := hlow S hS
  have hA2 := hup S hS
  have hB1 := hlow Sᶜ hS.compl
  have hB2 := hup Sᶜ hS.compl
  have hZne : α + γ ≠ 0 := ne_of_gt hZpos
  have ht : α / (α + γ) * (α + γ) = α := div_mul_cancel₀ α hZne
  have e1 : α / (α + γ) * (Real.exp m * (α + γ)) = Real.exp m * α := by
    linear_combination Real.exp m * ht
  have e2 : (1 - α / (α + γ)) * (Real.exp m * (α + γ)) = Real.exp m * γ := by
    linear_combination (-Real.exp m) * ht
  refine ratio_dev (α / (α + γ)) _ _ (Real.exp m * (α + γ)) (Real.exp c)
    (div_nonneg hα0 hZpos.le) ((div_le_one hZpos).2 (by linarith))
    (mul_pos (Real.exp_pos m) hZpos) (Real.one_le_exp hc) ?_ ?_ ?_ ?_ hpos'
  · rw [e1]; exact hA1
  · rw [e1]; linarith [hA2]
  · rw [e2]; exact hB1
  · rw [e2]; linarith [hB2]

end Tilt

#print axioms Tilt.ratio_dev
#print axioms Tilt.tilt_tv
#print axioms Tilt.tilt_tv_rel
