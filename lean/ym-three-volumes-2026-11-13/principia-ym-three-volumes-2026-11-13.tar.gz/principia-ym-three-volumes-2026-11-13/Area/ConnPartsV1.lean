import Area.WilsonFormV1

/-!
# Parts for the connectedness of minimal spanning sets (step 5)

* `minSpanC_exact`: a minimal spanning set `Y` of `c` satisfies `c = ∑_{p ∈ Y} ∂p` exactly
  (all coefficients are `1`).
* `div`: the mod-2 divergence of a link chain at a site,
  `div v z = ∑_μ (v(z, μ) + v(z - e_μ, μ))`; `div_plaqBd`: `div (∂p) = 0` for every plaquette
  (`∂∂ = 0` mod 2), hence `div (∑_{p ∈ A} ∂p) = 0` for every set `A`.
-/

open Finset TorusRP

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-- **Minimal sets are exact.**  If `Y ∈ minSpanC N c`, then `c = ∑_{p ∈ Y} ∂p`. -/
theorem minSpanC_exact (c : Lk N → ZMod 2) (Y : Finset (Lk N × Fin 4))
    (hY : Y ∈ minSpanC N c) : c = ∑ p ∈ Y, plaqBd N p := by
  classical
  have hY' := hY
  unfold minSpanC at hY'
  rw [mem_filter, mem_powerset] at hY'
  obtain ⟨_, hs, hmin⟩ := hY'
  obtain ⟨f, hf⟩ := exists_rep N c Y hs
  set Y1 := Y.filter (fun p => f p = 1) with hY1
  have hc1 : c = ∑ p ∈ Y1, plaqBd N p := by
    rw [hf, hY1, sum_filter]
    apply sum_congr rfl
    intro p _
    rcases zmod2_cases (f p) with h | h
    · rw [h, zero_smul, if_neg (by decide)]
    · rw [h, one_smul, if_pos rfl]
  have hs1 : SpansC N c Y1 := by
    unfold SpansC
    rw [hc1]
    exact Submodule.sum_mem _ (fun p hp => Submodule.subset_span ⟨p, by simpa using hp, rfl⟩)
  have := hmin Y1 (filter_subset _ _) hs1
  rw [← this]
  exact hc1

/-- mod-2 divergence of a link chain at the site `z` -/
def div (v : Lk N → ZMod 2) (z : Site N) : ZMod 2 :=
  ∑ μ : Fin 4, (v (z, μ) + v (z - ev N μ, μ))

theorem div_add (v w : Lk N → ZMod 2) (z : Site N) : div N (v + w) z = div N v z + div N w z := by
  simp only [div, Pi.add_apply, ← sum_add_distrib]
  apply sum_congr rfl; intro μ _; ring

theorem div_zero (z : Site N) : div N 0 z = 0 := by simp [div]

theorem div_sum {ι : Type*} (s : Finset ι) (v : ι → Lk N → ZMod 2) (z : Site N) :
    div N (∑ i ∈ s, v i) z = ∑ i ∈ s, div N (v i) z := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [div_zero]
  | insert a s ha ih => rw [sum_insert ha, sum_insert ha, div_add, ih]

/-- the divergence of one link: its two end points -/
theorem div_single (ℓ : Lk N) (z : Site N) :
    div N (fun e => if ℓ = e then 1 else 0) z
      = (if ℓ.1 = z then 1 else 0) + (if ℓ.1 + ev N ℓ.2 = z then 1 else 0) := by
  unfold div
  rw [sum_add_distrib]
  obtain ⟨x, ν⟩ := ℓ
  congr 1
  · rw [sum_eq_single ν]
    · simp
    · intro μ _ hμ; simp [Ne.symm hμ]
    · simp
  · rw [sum_eq_single ν]
    · simp only [Prod.mk.injEq, and_true]
      congr 1
      apply propext
      constructor
      · intro h; rw [h]; abel
      · intro h; rw [← h]; abel
    · intro μ _ hμ; simp [Ne.symm hμ]
    · simp

theorem div_wordBd (w : Word N) (z : Site N) :
    div N (wordBd N w) z
      = (w.map (fun s => (if s.1.1 = z then (1 : ZMod 2) else 0)
          + (if s.1.1 + ev N s.1.2 = z then 1 else 0))).sum := by
  induction w with
  | nil => simp [wordBd, div]
  | cons s w ih =>
    have : wordBd N (s :: w) = (fun e => if s.1 = e then 1 else 0) + wordBd N w := by
      funext e; simp [wordBd]
    rw [this, div_add, div_single, ih, List.map_cons, List.sum_cons]

/-- **`∂∂ = 0` mod 2**: the boundary of a plaquette has zero divergence at every site. -/
theorem div_plaqBd (p : Lk N × Fin 4) (z : Site N) : div N (plaqBd N p) z = 0 := by
  unfold plaqBd
  rw [div_wordBd]
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  simp only [plaqWord, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero]
  have hc : x + ev N ν + ev N μ = x + ev N μ + ev N ν := by abel
  rw [hc]
  generalize (if x = z then (1 : ZMod 2) else 0) = A
  generalize (if x + ev N μ = z then (1 : ZMod 2) else 0) = B
  generalize (if x + ev N ν = z then (1 : ZMod 2) else 0) = C
  generalize (if x + ev N μ + ev N ν = z then (1 : ZMod 2) else 0) = D
  have h2 : ∀ u : ZMod 2, u + u = 0 := zmod2_add_self
  linear_combination h2 A + h2 B + h2 C + h2 D

/-- the boundary of any set of plaquettes is closed -/
theorem div_sum_plaqBd (A : Finset (Lk N × Fin 4)) (z : Site N) :
    div N (∑ p ∈ A, plaqBd N p) z = 0 := by
  rw [div_sum]
  exact sum_eq_zero fun p _ => div_plaqBd N p z

/-- Sanity: `div` of the empty chain is `0`. -/
theorem sanity_div_nil (z : Site N) : div N (wordBd N []) z = 0 := by
  simp [wordBd, div]

end AreaLaw

#print axioms AreaLaw.minSpanC_exact
#print axioms AreaLaw.div_plaqBd
#print axioms AreaLaw.div_sum_plaqBd
