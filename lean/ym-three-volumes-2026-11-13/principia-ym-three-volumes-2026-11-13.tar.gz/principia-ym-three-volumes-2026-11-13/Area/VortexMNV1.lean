import Wilson.SU2TwistV2
import Area.MixV1
import Area.DominanceSubV1
import Area.AnimalV1

/-!
# Strong-coupling vortex floor on `(ℤ/N)² × (ℤ/M)²`, uniform in the transverse size

The lattice, the Haar measure, the holonomy, the twist signs `zt n₁₂ n₃₄` and the partition
function `ZW β n₁₂ n₃₄` are those of `Wilson.SU2TwistV2` (SU(2), `Site = (ZMod N × ZMod N) ×
(ZMod M × ZMod M)`; the `n₃₄` twist flips the `(2,3)`-plaquettes with `(x₂, x₃) = (0, 0)`, `N²`
of them).

Paper correspondence: strong-coupling vortex free energy (centre-flip expansion, known type).
For `β ≥ 0` with `9216 q < 1`, `q = 1 - e^{-2β}`, and every background `n₁₂`:
`|Z₀ - Z₁| ≤ N² (9216 q)^{M²} / (9216 (1 - 9216 q)) · (Z₀ + Z₁)`, `Z_k = ZW β n₁₂ k`
(**`vortex_floor_MN`**).  The rate `9216 q` depends neither on `N` nor on `M`; the exponent `M²`
is the area of the `(2,3)` torus, which every set of plaquettes carrying the twist must cover.
Steps: positive mixture; centre sign fields act on the weights by the plaquette characters
(`hol_smul`, `haarCfg_inv`); sets on which the twist is a product of plaquette characters
("good" sets) give equal weights; a bad set meets all `M²` translates of the twist set, is
connected when minimal, and is counted from a root in the twist set (`N²` choices).
-/

open Finset MeasureTheory TwistedWilson CoveringInequality AreaLaw

namespace VortexStrongMN

variable (N M : ℕ) [NeZero N] [NeZero M]

/-! ### Mixture weights with signs -/

/-- `σ^z_B = e^{β(z_B Re U_B + 1)} - 1` -/
noncomputable def sigZ (β : ℝ) (z : Plaq N M → ℝ) (ω : Link N M → SU2) (B : Plaq N M) : ℝ :=
  mixVar β (z B * (hol N M ω B).re)

/-- `Z^z_X = ∫ ∏_{B ∈ X} σ^z_B d(∏ Haar)` -/
noncomputable def ZZ (β : ℝ) (z : Plaq N M → ℝ) (X : Finset (Plaq N M)) : ℝ :=
  ∫ ω, ∏ B ∈ X, sigZ N M β z ω B ∂(haarCfg N M)

theorem continuous_mixVar' (β : ℝ) : Continuous (mixVar β) := by
  unfold mixVar
  exact (Real.continuous_exp.comp (continuous_const.mul (continuous_id.add continuous_const))).sub
    continuous_const

theorem sigZ_mem (β : ℝ) (hβ : 0 ≤ β) (z : Plaq N M → ℝ) (hz : ∀ B, |z B| ≤ 1)
    (ω : Link N M → SU2) (B : Plaq N M) :
    0 ≤ sigZ N M β z ω B ∧ sigZ N M β z ω B ≤ Real.exp (2 * β) - 1 := by
  have h1 : |z B * (hol N M ω B).re| ≤ 1 := by
    rw [abs_mul]
    exact mul_le_one₀ (hz B) (abs_nonneg _) (abs_re_le_one _ (norm_hol N M ω B))
  have h := abs_le.mp h1
  exact mixVar_mem β _ hβ h.1 h.2

theorem measurable_sigZ (β : ℝ) (z : Plaq N M → ℝ) (B : Plaq N M) :
    Measurable (fun ω => sigZ N M β z ω B) :=
  ((continuous_mixVar' β).comp (continuous_const.mul (continuous_hol_re N M B))).measurable

theorem integrable_prodZ (β : ℝ) (hβ : 0 ≤ β) (z : Plaq N M → ℝ) (hz : ∀ B, |z B| ≤ 1)
    (X : Finset (Plaq N M)) :
    Integrable (fun ω => ∏ B ∈ X, sigZ N M β z ω B) (haarCfg N M) := by
  have := integrable_term (haarCfg N M) (fun _ => (1 : ℝ)) (fun B ω => sigZ N M β z ω B)
    (Real.exp (2 * β) - 1) measurable_const (fun B => measurable_sigZ N M β z B)
    (fun _ => by simp) (fun B ω => (sigZ_mem N M β hβ z hz ω B).1)
    (fun B ω => (sigZ_mem N M β hβ z hz ω B).2) X
  simpa using this

theorem ZZ_nonneg (β : ℝ) (hβ : 0 ≤ β) (z : Plaq N M → ℝ) (hz : ∀ B, |z B| ≤ 1)
    (X : Finset (Plaq N M)) : 0 ≤ ZZ N M β z X :=
  integral_nonneg fun ω => prod_nonneg fun B _ => (sigZ_mem N M β hβ z hz ω B).1

theorem ZZ_insert_le (β : ℝ) (hβ : 0 ≤ β) (z : Plaq N M → ℝ) (hz : ∀ B, |z B| ≤ 1)
    (S : Finset (Plaq N M)) (B : Plaq N M) (hB : B ∉ S) :
    ZZ N M β z (insert B S) ≤ (Real.exp (2 * β) - 1) * ZZ N M β z S := by
  unfold ZZ
  rw [← integral_const_mul]
  apply integral_mono (integrable_prodZ N M β hβ z hz _)
    ((integrable_prodZ N M β hβ z hz S).const_mul _)
  intro ω
  simp only
  rw [prod_insert hB]
  exact mul_le_mul_of_nonneg_right (sigZ_mem N M β hβ z hz ω B).2
    (prod_nonneg fun B _ => (sigZ_mem N M β hβ z hz ω B).1)

theorem abs_zt_le (n12 n34 : Bool) : ∀ B, |zt N M n12 n34 B| ≤ 1 := fun B =>
  (abs_zt N M n12 n34 B).le

/-- `ZW = e^{-β|P|} Σ_X Z^{zt}_X` -/
theorem ZW_eq_mix (β : ℝ) (hβ : 0 ≤ β) (n12 n34 : Bool) :
    ZW N M β n12 n34 = Real.exp (-β) ^ (univ : Finset (Plaq N M)).card *
      ∑ X ∈ (univ : Finset (Plaq N M)).powerset, ZZ N M β (zt N M n12 n34) X := by
  have hpt : ∀ ω : Link N M → SU2,
      Real.exp (β * ∑ B, zt N M n12 n34 B * (hol N M ω B).re)
        = Real.exp (-β) ^ (univ : Finset (Plaq N M)).card *
          ∑ X ∈ (univ : Finset (Plaq N M)).powerset, ∏ B ∈ X, sigZ N M β (zt N M n12 n34) ω B := by
    intro ω
    rw [mul_sum, Real.exp_sum]
    simp_rw [exp_eq_mix β]
    rw [prod_mul_distrib, prod_const, prod_one_add]
    rfl
  unfold ZW
  simp_rw [hpt]
  rw [integral_const_mul, integral_finsetSum]
  · rfl
  · intro X _
    exact integrable_prodZ N M β hβ _ (abs_zt_le N M n12 n34) X

/-! ### Centre sign fields -/

/-- **Gauge covariance**: if `z_B χ_B(g) = z'_B` on `X`, then `Z^z_X = Z^{z'}_X`. -/
theorem ZZ_gauge (β : ℝ) (z z' : Plaq N M → ℝ) (g : Link N M → ℤˣ) (X : Finset (Plaq N M))
    (h : ∀ B ∈ X, z B * chiB N M B g = z' B) : ZZ N M β z X = ZZ N M β z' X := by
  have key := haarCfg_inv N M g (fun ω => ∏ B ∈ X, sigZ N M β z ω B)
  unfold ZZ
  refine key.symm.trans ?_
  congr 1
  funext ω
  apply prod_congr rfl
  intro B hB
  simp only [sigZ]
  rw [hol_smul, ← mul_assoc, h B hB]

/-- the `(2,3)` plaquettes at `(x₂, x₃) = c`, as a sign mask -/
noncomputable def Dmask (c : ZMod M × ZMod M) (B : Plaq N M) : ℝ :=
  if B.2 = p23 ∧ B.1.2 = c then -1 else 1

theorem Dmask_sq (c : ZMod M × ZMod M) (B : Plaq N M) : Dmask N M c B * Dmask N M c B = 1 := by
  unfold Dmask; split_ifs <;> norm_num

theorem zt_true (n12 : Bool) (B : Plaq N M) :
    zt N M n12 true B = zt N M n12 false B * Dmask N M 0 B := by
  unfold zt Dmask tw
  split_ifs <;> simp_all

/-- the twist `D` is a product of plaquette characters on `X` -/
def Good (D : Plaq N M → ℝ) (X : Finset (Plaq N M)) : Prop :=
  ∃ g : Link N M → ℤˣ, ∀ B ∈ X, chiB N M B g = D B

theorem ZZ_good (β : ℝ) (n12 : Bool) (X : Finset (Plaq N M)) (hX : Good N M (Dmask N M 0) X) :
    ZZ N M β (zt N M n12 false) X = ZZ N M β (zt N M n12 true) X := by
  obtain ⟨g, hg⟩ := hX
  apply ZZ_gauge N M β _ _ g X
  intro B hB
  rw [hg B hB, zt_true]

theorem chiB_mul (B : Plaq N M) (g h : Link N M → ℤˣ) :
    chiB N M B (g * h) = chiB N M B g * chiB N M B h := (chiB_isSignChar N M B).1 g h

theorem chiB_sq (B : Plaq N M) (g : Link N M → ℤˣ) : chiB N M B g * chiB N M B g = 1 := by
  rcases (chiB_isSignChar N M B).2 g with h | h <;> rw [h] <;> norm_num

theorem chiB_one (B : Plaq N M) : chiB N M B 1 = 1 := by
  simp [chiB, sgn]

theorem good_of_shift (D D' : Plaq N M → ℝ) (h : Link N M → ℤˣ) (X : Finset (Plaq N M))
    (hs : ∀ B, D' B = D B * chiB N M B h) (hg : Good N M D X) : Good N M D' X := by
  obtain ⟨g, hg⟩ := hg
  exact ⟨g * h, fun B hB => by rw [chiB_mul, hg B hB, hs B]⟩

theorem good_iff_of_shift (D D' : Plaq N M → ℝ) (h : Link N M → ℤˣ) (X : Finset (Plaq N M))
    (hs : ∀ B, D' B = D B * chiB N M B h) : Good N M D X ↔ Good N M D' X := by
  refine ⟨good_of_shift N M D D' h X hs, good_of_shift N M D' D h X fun B => ?_⟩
  rw [hs B, mul_assoc, chiB_sq, mul_one]

/-- the direction-2 links at `(x₂, x₃) = c` -/
def rowF (c : ZMod M × ZMod M) : Link N M → ℤˣ := fun ℓ => if ℓ.2 = 2 ∧ ℓ.1.2 = c then -1 else 1

/-- the direction-3 links at `(x₂, x₃) = c` -/
def colF (c : ZMod M × ZMod M) : Link N M → ℤˣ := fun ℓ => if ℓ.2 = 3 ∧ ℓ.1.2 = c then -1 else 1

lemma sgn_ite (P : Prop) [Decidable P] : sgn (if P then (-1 : ℤˣ) else 1) = if P then -1 else 1 := by
  split_ifs <;> simp [sgn]

theorem chiB_rowF (c : ZMod M × ZMod M) (B : Plaq N M) :
    chiB N M B (rowF N M c) = Dmask N M c B * Dmask N M (c - (0, 1)) B := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [chiB, rowF, sgn_ite, Dmask, l1, l2, l3, l4, p23]
  fin_cases μ <;> fin_cases ν <;> simp_all [ev, eq_sub_iff_add_eq, sgn, Prod.mk_zero_zero] <;> (try split_ifs) <;> simp_all [Prod.mk_zero_zero]

theorem chiB_colF (c : ZMod M × ZMod M) (B : Plaq N M) :
    chiB N M B (colF N M c) = Dmask N M c B * Dmask N M (c - (1, 0)) B := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [chiB, colF, sgn_ite, Dmask, l1, l2, l3, l4, p23]
  fin_cases μ <;> fin_cases ν <;> simp_all [ev, eq_sub_iff_add_eq, sgn, Prod.mk_zero_zero] <;> (try split_ifs) <;> simp_all [Prod.mk_zero_zero]

theorem good_row (X : Finset (Plaq N M)) (k : ℕ) :
    Good N M (Dmask N M 0) X ↔ Good N M (Dmask N M (0, (k : ZMod M))) X := by
  induction k with
  | zero => simp [Prod.mk_zero_zero]
  | succ k ih =>
    rw [ih]
    apply good_iff_of_shift N M _ _ (rowF N M (0, ((k + 1 : ℕ) : ZMod M))) X
    intro B
    rw [chiB_rowF]
    have hk : ((0 : ZMod M), ((k + 1 : ℕ) : ZMod M)) - (0, 1) = (0, (k : ZMod M)) := by
      ext <;> simp
    rw [hk, mul_comm (Dmask N M _ B), mul_assoc, Dmask_sq, mul_one]

theorem good_col (X : Finset (Plaq N M)) (b : ZMod M) (k : ℕ) :
    Good N M (Dmask N M (0, b)) X ↔ Good N M (Dmask N M ((k : ZMod M), b)) X := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [ih]
    apply good_iff_of_shift N M _ _ (colF N M (((k + 1 : ℕ) : ZMod M), b)) X
    intro B
    rw [chiB_colF]
    have hk : (((k + 1 : ℕ) : ZMod M), b) - (1, 0) = ((k : ZMod M), b) := by
      ext <;> simp
    rw [hk, mul_comm (Dmask N M _ B), mul_assoc, Dmask_sq, mul_one]

theorem good_iff_translate (X : Finset (Plaq N M)) (c : ZMod M × ZMod M) :
    Good N M (Dmask N M 0) X ↔ Good N M (Dmask N M c) X := by
  obtain ⟨a, b⟩ := c
  rw [good_row N M X b.val, ZMod.natCast_zmod_val, good_col N M X b a.val, ZMod.natCast_zmod_val]

theorem bad_meets (X : Finset (Plaq N M)) (hb : ¬ Good N M (Dmask N M 0) X)
    (c : ZMod M × ZMod M) : ∃ B ∈ X, B.2 = p23 ∧ B.1.2 = c := by
  by_contra hno
  push_neg at hno
  apply hb
  rw [good_iff_translate N M X c]
  refine ⟨1, fun B hB => ?_⟩
  rw [chiB_one]
  unfold Dmask
  rw [if_neg (fun h => hno B hB h.1 h.2)]

/-- **Area lower bound**: a bad set has at least `M²` plaquettes. -/
theorem card_bad_ge (X : Finset (Plaq N M)) (hb : ¬ Good N M (Dmask N M 0) X) :
    M * M ≤ X.card := by
  classical
  have hsub : (univ : Finset (ZMod M × ZMod M)) ⊆ X.image (fun B => B.1.2) := by
    intro c _
    obtain ⟨B, hB, -, hc⟩ := bad_meets N M X hb c
    exact mem_image.mpr ⟨B, hB, hc⟩
  have h1 := card_le_card hsub
  rw [card_univ, Fintype.card_prod, ZMod.card] at h1
  exact h1.trans card_image_le

/-! ### Minimal bad sets: connected -/

open Classical in
noncomputable def minBad : Finset (Finset (Plaq N M)) :=
  (univ : Finset (Plaq N M)).powerset.filter (fun Y => ¬ Good N M (Dmask N M 0) Y ∧
    ∀ Y' ⊆ Y, ¬ Good N M (Dmask N M 0) Y' → Y' = Y)

theorem minBad_mem (Y : Finset (Plaq N M)) (hY : Y ∈ minBad N M) :
    ¬ Good N M (Dmask N M 0) Y ∧ ∀ Y' ⊆ Y, ¬ Good N M (Dmask N M 0) Y' → Y' = Y := by
  classical
  unfold minBad at hY
  rw [mem_filter] at hY
  exact hY.2

theorem exists_minBad_subset (X : Finset (Plaq N M)) (hb : ¬ Good N M (Dmask N M 0) X) :
    ∃ Y ∈ minBad N M, Y ⊆ X := by
  classical
  have hne : (X.powerset.filter (fun Y => ¬ Good N M (Dmask N M 0) Y)).Nonempty :=
    ⟨X, mem_filter.mpr ⟨mem_powerset_self X, hb⟩⟩
  obtain ⟨Y, hY, hmin⟩ := exists_min_image _ card hne
  rw [mem_filter, mem_powerset] at hY
  refine ⟨Y, ?_, hY.1⟩
  unfold minBad
  rw [mem_filter, mem_powerset]
  refine ⟨subset_univ _, hY.2, fun Y' hY' hs' => ?_⟩
  have := hmin Y' (mem_filter.mpr ⟨mem_powerset.mpr (hY'.trans hY.1), hs'⟩)
  exact eq_of_subset_of_card_le hY' this

/-- the four links of a plaquette -/
def links (B : Plaq N M) : Finset (Link N M) := {l1 N M B, l2 N M B, l3 N M B, l4 N M B}

theorem chiB_congr (B : Plaq N M) (g g' : Link N M → ℤˣ) (h : ∀ e ∈ links N M B, g e = g' e) :
    chiB N M B g = chiB N M B g' := by
  simp only [chiB]
  rw [h (l1 N M B) (by simp [links]), h (l2 N M B) (by simp [links]),
    h (l3 N M B) (by simp [links]), h (l4 N M B) (by simp [links])]

/-- plaquettes sharing a link -/
def nbL (B : Plaq N M) : Finset (Plaq N M) := univ.filter (fun B' => ∃ e ∈ links N M B, e ∈ links N M B')

theorem nbL_symm (a b : Plaq N M) : b ∈ nbL N M a ↔ a ∈ nbL N M b := by
  simp only [nbL, mem_filter, mem_univ, true_and]
  constructor <;> rintro ⟨e, h1, h2⟩ <;> exact ⟨e, h2, h1⟩

theorem minBad_conn (Y : Finset (Plaq N M)) (hY : Y ∈ minBad N M) : CutConn (nbL N M) Y := by
  classical
  obtain ⟨hYb, hYmin⟩ := minBad_mem N M Y hY
  intro S hSY hSne hSneq
  by_contra hno
  push_neg at hno
  have hSg : Good N M (Dmask N M 0) S := by
    by_contra h; exact hSneq (hYmin S hSY h)
  have hRg : Good N M (Dmask N M 0) (Y \ S) := by
    by_contra h
    have := hYmin (Y \ S) sdiff_subset h
    obtain ⟨s, hs⟩ := hSne
    have hsY : s ∈ Y := hSY hs
    rw [← this, mem_sdiff] at hsY
    exact hsY.2 hs
  obtain ⟨g1, hg1⟩ := hSg
  obtain ⟨g2, hg2⟩ := hRg
  set U := S.biUnion (links N M) with hU
  apply hYb
  refine ⟨fun e => if e ∈ U then g1 e else g2 e, fun B hB => ?_⟩
  by_cases hBS : B ∈ S
  · rw [← hg1 B hBS]
    apply chiB_congr
    intro e he
    have : e ∈ U := mem_biUnion.mpr ⟨B, hBS, he⟩
    simp [this]
  · have hBR : B ∈ Y \ S := mem_sdiff.mpr ⟨hB, hBS⟩
    rw [← hg2 B hBR]
    apply chiB_congr
    intro e he
    have hne : e ∉ U := by
      intro heU
      obtain ⟨a, ha, hea⟩ := mem_biUnion.mp heU
      apply hno a ha B hBR
      simp only [nbL, mem_filter, mem_univ, true_and]
      exact ⟨e, hea, he⟩
    simp [hne]

/-! ### Counting -/

/-- the plaquette with the link `e` in position `k` and plane `P` -/
def placeL (e : Link N M) (kP : Fin 4 × Plane) : Plaq N M :=
  if kP.1 = 0 then (e.1, kP.2)
  else if kP.1 = 1 then (e.1 - ev N M kP.2.1.1, kP.2)
  else if kP.1 = 2 then (e.1 - ev N M kP.2.1.2, kP.2)
  else (e.1, kP.2)

theorem card_rootL_le (e : Link N M) : (univ.filter (fun B => e ∈ links N M B)).card ≤ 24 := by
  have hsub : univ.filter (fun B => e ∈ links N M B) ⊆ univ.image (placeL N M e) := by
    intro B hB
    simp only [mem_filter, mem_univ, true_and, links, mem_insert, mem_singleton] at hB
    rw [mem_image]
    rcases hB with h | h | h | h <;> subst h
    · exact ⟨(0, B.2), mem_univ _, by simp [placeL, l1]⟩
    · exact ⟨(1, B.2), mem_univ _, by simp [placeL, l2]⟩
    · exact ⟨(2, B.2), mem_univ _, by simp [placeL, l3]⟩
    · exact ⟨(3, B.2), mem_univ _, by simp [placeL, l4]⟩
  calc (univ.filter (fun B => e ∈ links N M B)).card ≤ (univ.image (placeL N M e)).card :=
        card_le_card hsub
    _ ≤ (univ : Finset (Fin 4 × Plane)).card := card_image_le
    _ = 24 := by rw [card_univ]; decide

theorem card_links_le (B : Plaq N M) : (links N M B).card ≤ 4 := by
  unfold links
  refine (card_insert_le _ _).trans ?_
  refine Nat.succ_le_succ ((card_insert_le _ _).trans ?_)
  refine Nat.succ_le_succ ((card_insert_le _ _).trans ?_)
  simp

theorem card_nbL_le (B : Plaq N M) : (nbL N M B).card ≤ 96 := by
  have hsub : nbL N M B ⊆ (links N M B).biUnion (fun e => univ.filter (fun B' => e ∈ links N M B')) := by
    intro B' hB'
    simp only [nbL, mem_filter, mem_univ, true_and] at hB'
    obtain ⟨e, he, he'⟩ := hB'
    rw [mem_biUnion]
    exact ⟨e, he, by simp [he']⟩
  calc (nbL N M B).card
      ≤ ((links N M B).biUnion (fun e => univ.filter (fun B' => e ∈ links N M B'))).card :=
        card_le_card hsub
    _ ≤ ∑ e ∈ links N M B, (univ.filter (fun B' => e ∈ links N M B')).card := card_biUnion_le
    _ ≤ ∑ _e ∈ links N M B, 24 := sum_le_sum fun e _ => card_rootL_le N M e
    _ = (links N M B).card * 24 := by rw [sum_const, smul_eq_mul]
    _ ≤ 4 * 24 := Nat.mul_le_mul_right _ (card_links_le N M B)
    _ = 96 := by norm_num

/-- the twist plaquettes -/
def twistSetMN : Finset (Plaq N M) := univ.filter (fun B => B.2 = p23 ∧ B.1.2 = 0)

theorem card_twistSetMN_le : (twistSetMN N M).card ≤ N * N := by
  have h := card_le_card_of_injOn (fun B : Plaq N M => B.1.1)
    (s := twistSetMN N M) (t := (univ : Finset (ZMod N × ZMod N))) (fun _ _ => by simp) ?_
  · rwa [card_univ, Fintype.card_prod, ZMod.card] at h
  · intro B hB B' hB' hBB
    simp only [twistSetMN, coe_filter, mem_univ, true_and, Set.mem_setOf_eq] at hB hB'
    obtain ⟨⟨x1, x2⟩, P⟩ := B
    obtain ⟨⟨x1', x2'⟩, P'⟩ := B'
    simp only at hB hB' hBB
    rw [hBB, hB.1, hB'.1, hB.2, hB'.2]

open Classical in
theorem sum_minBad_le (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minBad N M, x ^ Y.card
      ≤ (N * N : ℕ) * ∑ n ∈ Ico (M * M) ((univ : Finset (Plaq N M)).card + 1),
          (9216 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minBad N M with hF
  set A := M * M with hA
  set K := (univ : Finset (Plaq N M)).card with hK
  have hA1 : 1 ≤ A := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne M) (NeZero.ne M))
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ twistSetMN N M, (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨B, hB, hB2, hB1⟩ := bad_meets N M Y (minBad_mem N M Y hY).1 0
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [twistSetMN, hB2, hB1], hB⟩)
      _ = ∑ r ∈ twistSetMN N M, ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  have h2 : ∀ r, ∑ Y ∈ F with r ∈ Y, x ^ Y.card
      ≤ ∑ n ∈ Ico A (K + 1), (9216 : ℝ) ^ (n - 1) * x ^ n := by
    intro r
    have hmaps : ∀ Y ∈ F.filter (fun Y => r ∈ Y), Y.card ∈ Ico A (K + 1) := by
      intro Y hY
      have hYF := (mem_filter.mp hY).1
      rw [mem_Ico]
      exact ⟨card_bad_ge N M Y (minBad_mem N M Y hYF).1,
        Nat.lt_succ_of_le (card_le_card (subset_univ Y))⟩
    rw [← sum_fiberwise_of_maps_to hmaps]
    apply sum_le_sum
    intro n hn
    have hnA : A ≤ n := (mem_Ico.mp hn).1
    have hcongr : ∑ Y ∈ F.filter (fun Y => r ∈ Y) with Y.card = n, x ^ Y.card
        = ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)).card * x ^ n := by
      rw [sum_congr rfl (fun Y hY => by rw [(mem_filter.mp hY).2]), sum_const, nsmul_eq_mul]
    rw [hcongr]
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hx _)
    have hcount := card_conn_le (nbL N M) (nbL_symm N M) 96 (card_nbL_le N M) r n (by omega)
      ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)) (by
        intro Y hY
        rw [mem_filter, mem_filter] at hY
        exact ⟨hY.1.2, hY.2, minBad_conn N M Y hY.1.1⟩)
    have h96 : (96 : ℕ) ^ (2 * (n - 1)) = 9216 ^ (n - 1) := by
      rw [pow_mul]; norm_num
    rw [h96] at hcount
    exact_mod_cast hcount
  have hsum0 : 0 ≤ ∑ n ∈ Ico A (K + 1), (9216 : ℝ) ^ (n - 1) * x ^ n :=
    sum_nonneg fun n _ => mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _)
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ twistSetMN N M, ∑ n ∈ Ico A (K + 1), (9216 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => h2 r
    _ = (twistSetMN N M).card * ∑ n ∈ Ico A (K + 1), (9216 : ℝ) ^ (n - 1) * x ^ n := by
        rw [sum_const, nsmul_eq_mul]
    _ ≤ (N * N : ℕ) * ∑ n ∈ Ico A (K + 1), (9216 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ hsum0
        exact_mod_cast card_twistSetMN_le N M

/-! ### The floor -/

open Classical in
theorem sum_bad_le (β : ℝ) (hβ : 0 ≤ β) (z : Plaq N M → ℝ) (hz : ∀ B, |z B| ≤ 1) :
    ∑ X ∈ (univ : Finset (Plaq N M)).powerset with ¬ Good N M (Dmask N M 0) X, ZZ N M β z X
      ≤ (∑ Y ∈ minBad N M, (1 - Real.exp (-2 * β)) ^ Y.card)
          * ∑ X ∈ (univ : Finset (Plaq N M)).powerset, ZZ N M β z X := by
  set t := Real.exp (2 * β) - 1 with ht_def
  have ht : 0 ≤ t := by
    have := Real.one_le_exp (by linarith : (0:ℝ) ≤ 2 * β)
    linarith
  set pw := (univ : Finset (Plaq N M)).powerset
  have h4 : ∑ X ∈ pw with ¬ Good N M (Dmask N M 0) X, ZZ N M β z X
      ≤ ∑ Y ∈ minBad N M, ∑ X ∈ pw with Y ⊆ X, ZZ N M β z X := by
    calc ∑ X ∈ pw with ¬ Good N M (Dmask N M 0) X, ZZ N M β z X
        ≤ ∑ X ∈ pw with ¬ Good N M (Dmask N M 0) X,
            ∑ Y ∈ minBad N M, (if Y ⊆ X then ZZ N M β z X else 0) := by
          apply sum_le_sum
          intro X hX
          rw [mem_filter] at hX
          obtain ⟨Y, hY, hYX⟩ := exists_minBad_subset N M X hX.2
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => ZZ N M β z X) (fun _ _ => ZZ_nonneg N M β hβ z hz X)
            (mem_filter.mpr ⟨hY, hYX⟩)
      _ = ∑ Y ∈ minBad N M, ∑ X ∈ pw with ¬ Good N M (Dmask N M 0) X,
            (if Y ⊆ X then ZZ N M β z X else 0) := sum_comm
      _ ≤ ∑ Y ∈ minBad N M, ∑ X ∈ pw, (if Y ⊆ X then ZZ N M β z X else 0) := by
          apply sum_le_sum
          intro Y _
          apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
          intro X _ _
          split_ifs
          · exact ZZ_nonneg N M β hβ z hz X
          · exact le_refl 0
      _ = ∑ Y ∈ minBad N M, ∑ X ∈ pw with Y ⊆ X, ZZ N M β z X := by
          apply sum_congr rfl
          intro Y _
          rw [sum_filter]
  have hq : t / (1 + t) = 1 - Real.exp (-2 * β) := by
    have h : Real.exp (-2 * β) = (Real.exp (2 * β))⁻¹ := by
      rw [← Real.exp_neg]; ring_nf
    rw [ht_def, h, add_sub_cancel]
    field_simp
  have h5 : ∀ Y ∈ minBad N M,
      ∑ X ∈ pw with Y ⊆ X, ZZ N M β z X ≤ (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZZ N M β z X :=
    fun Y _ => sum_superset_le_in univ (ZZ N M β z) t ht
      (fun S _ B _ hB => ZZ_insert_le N M β hβ z hz S B hB) Y (subset_univ Y)
  rw [hq] at h5
  rw [sum_mul]
  exact h4.trans (sum_le_sum h5)

open Classical in
theorem abs_ZW_sub_le (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool) :
    |ZW N M β n12 false - ZW N M β n12 true|
      ≤ (∑ Y ∈ minBad N M, (1 - Real.exp (-2 * β)) ^ Y.card)
          * (ZW N M β n12 false + ZW N M β n12 true) := by
  set c := Real.exp (-β) ^ (univ : Finset (Plaq N M)).card with hc_def
  have hc : 0 ≤ c := pow_nonneg (Real.exp_pos _).le _
  set pw := (univ : Finset (Plaq N M)).powerset
  set G := fun X => Good N M (Dmask N M 0) X
  set S := ∑ Y ∈ minBad N M, (1 - Real.exp (-2 * β)) ^ Y.card
  set z0 := zt N M n12 false
  set z1 := zt N M n12 true
  have hz0 := abs_zt_le N M n12 false
  have hz1 := abs_zt_le N M n12 true
  rw [ZW_eq_mix N M β hβ, ZW_eq_mix N M β hβ]
  have hdiff : ∑ X ∈ pw, ZZ N M β z0 X - ∑ X ∈ pw, ZZ N M β z1 X
      = ∑ X ∈ pw with ¬ G X, (ZZ N M β z0 X - ZZ N M β z1 X) := by
    rw [← sum_sub_distrib, ← sum_filter_add_sum_filter_not pw G]
    have : ∑ X ∈ pw with G X, (ZZ N M β z0 X - ZZ N M β z1 X) = 0 := by
      apply sum_eq_zero
      intro X hX
      rw [mem_filter] at hX
      rw [ZZ_good N M β n12 X hX.2, sub_self]
    rw [this, zero_add]
  have habs : |∑ X ∈ pw with ¬ G X, (ZZ N M β z0 X - ZZ N M β z1 X)|
      ≤ ∑ X ∈ pw with ¬ G X, ZZ N M β z0 X + ∑ X ∈ pw with ¬ G X, ZZ N M β z1 X := by
    rw [← sum_add_distrib]
    refine (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun X _ => ?_)
    have h0 := ZZ_nonneg N M β hβ z0 hz0 X
    have h1 := ZZ_nonneg N M β hβ z1 hz1 X
    rw [abs_le]; constructor <;> linarith
  have hb0 := sum_bad_le N M β hβ z0 hz0
  have hb1 := sum_bad_le N M β hβ z1 hz1
  rw [← mul_sub, hdiff, abs_mul, abs_of_nonneg hc]
  calc c * |∑ X ∈ pw with ¬ G X, (ZZ N M β z0 X - ZZ N M β z1 X)|
      ≤ c * (S * ∑ X ∈ pw, ZZ N M β z0 X + S * ∑ X ∈ pw, ZZ N M β z1 X) :=
        mul_le_mul_of_nonneg_left (habs.trans (add_le_add hb0 hb1)) hc
    _ = S * (c * ∑ X ∈ pw, ZZ N M β z0 X + c * ∑ X ∈ pw, ZZ N M β z1 X) := by ring

theorem tail_le_K' (K : ℝ) (hK0 : 0 < K) (A L : ℕ) (hA : 1 ≤ A) (x : ℝ) (hx : 0 ≤ x)
    (hKx : K * x < 1) :
    ∑ n ∈ Ico A (L + 1), K ^ (n - 1) * x ^ n ≤ (K * x) ^ A / (K * (1 - K * x)) := by
  have hterm : ∀ n ∈ Ico A (L + 1), K ^ (n - 1) * x ^ n = (K * x) ^ n / K := by
    intro n hn
    have hn1 : 1 ≤ n := le_trans hA (mem_Ico.mp hn).1
    rw [mul_pow, eq_div_iff hK0.ne']
    have : K ^ n = K ^ (n - 1) * K := by
      rw [← pow_succ, Nat.sub_add_cancel hn1]
    rw [this]; ring
  rw [sum_congr rfl hterm, ← sum_div]
  have hg := geom_sum_Ico_le_of_lt_one (m := A) (n := L + 1) (by positivity : 0 ≤ K * x) hKx
  have h1 : 0 < 1 - K * x := by linarith
  rw [div_le_div_iff₀ hK0 (by positivity)]
  calc (∑ i ∈ Ico A (L + 1), (K * x) ^ i) * (K * (1 - K * x))
      ≤ (K * x) ^ A / (1 - K * x) * (K * (1 - K * x)) :=
        mul_le_mul_of_nonneg_right hg (by positivity)
    _ = (K * x) ^ A * K := by field_simp

/-- **Vortex floor at strong coupling on `(ℤ/N)² × (ℤ/M)²`, rate uniform in `N` and `M`.**
For `β ≥ 0` with `9216 (1 - e^{-2β}) < 1` and every background `n₁₂`,
`|Z₀ - Z₁| ≤ N² (9216 q)^{M²} / (9216 (1 - 9216 q)) · (Z₀ + Z₁)`, `Z_k = ZW β n₁₂ k`,
`q = 1 - e^{-2β}`. -/
theorem vortex_floor_MN (β : ℝ) (hβ : 0 ≤ β) (hK : 9216 * (1 - Real.exp (-2 * β)) < 1)
    (n12 : Bool) :
    |ZW N M β n12 false - ZW N M β n12 true|
      ≤ (N * N : ℕ) * ((9216 * (1 - Real.exp (-2 * β))) ^ (M * M)
          / (9216 * (1 - 9216 * (1 - Real.exp (-2 * β)))))
          * (ZW N M β n12 false + ZW N M β n12 true) := by
  classical
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hA1 : 1 ≤ M * M := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne M) (NeZero.ne M))
  have hZ0 : 0 ≤ ZW N M β n12 false := integral_nonneg fun _ => (Real.exp_pos _).le
  have hZ1 : 0 ≤ ZW N M β n12 true := integral_nonneg fun _ => (Real.exp_pos _).le
  refine (abs_ZW_sub_le N M β hβ n12).trans (mul_le_mul_of_nonneg_right ?_ (by linarith))
  refine (sum_minBad_le N M _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact tail_le_K' 9216 (by norm_num) _ _ hA1 _ hq0 hK

/-! ### Sanity -/

/-- Sanity: the window contains `β = 1/100000`. -/
theorem sanity_window_MN :
    (0 : ℝ) ≤ 1 / 100000 ∧ 9216 * (1 - Real.exp (-2 * (1 / 100000 : ℝ))) < 1 := by
  refine ⟨by norm_num, ?_⟩
  have h := Real.add_one_le_exp (-2 * (1 / 100000 : ℝ))
  nlinarith

/-- Sanity: the twist set is not empty (`((0,0),p23)` is in it), and the empty set is good. -/
theorem sanity_twist_MN : (((0, 0), p23) : Plaq N M) ∈ twistSetMN N M ∧
    Good N M (Dmask N M 0) ∅ :=
  ⟨by simp [twistSetMN], ⟨1, fun B hB => by simp at hB⟩⟩

end VortexStrongMN

#print axioms VortexStrongMN.ZZ_gauge
#print axioms VortexStrongMN.card_bad_ge
#print axioms VortexStrongMN.minBad_conn
#print axioms VortexStrongMN.vortex_floor_MN
#print axioms VortexStrongMN.sanity_window_MN
