import Mathlib

/-!
# Separation by a mod-2 cochain

Paper correspondence: step 2 of the strong-coupling area-law argument
(the linear algebra over `F₂ = ZMod 2`).  Links form a finite set `E`, a chain is a
vector `E → ZMod 2`, and `d p` is the mod-2 boundary of the plaquette `p`.
If the loop `c` is not in the span of `{d p : p ∈ X}`, there is a set of links `T`
(its indicator `T : E → ZMod 2`) that meets every `∂p`, `p ∈ X`, evenly and `c` oddly.
Conversely such a `T` rules out `c` being in the span.
-/

open Finset

namespace AreaLaw

/-- The mod-2 pairing `⟨T, v⟩ = ∑_e T_e v_e` as a linear map in `v`. -/
def pairF2 {E : Type*} [Fintype E] (T : E → ZMod 2) : (E → ZMod 2) →ₗ[ZMod 2] ZMod 2 where
  toFun v := ∑ e, T e * v e
  map_add' v w := by simp [mul_add, sum_add_distrib]
  map_smul' a v := by simp [mul_sum, mul_left_comm]

lemma zmod2_eq_one_of_ne_zero : ∀ z : ZMod 2, z ≠ 0 → z = 1 := by decide

/-- **Separation.**  If `c ∉ span {d p : p ∈ X}` over `ZMod 2`, there is `T` with
`⟨T, d p⟩ = 0` for all `p ∈ X` and `⟨T, c⟩ = 1`. -/
theorem exists_sep_of_not_mem_span {E P : Type*} [Fintype E] [DecidableEq E]
    (c : E → ZMod 2) (d : P → E → ZMod 2) (X : Finset P)
    (h : c ∉ Submodule.span (ZMod 2) (d '' (X : Set P))) :
    ∃ T : E → ZMod 2, (∀ p ∈ X, ∑ e, T e * d p e = 0) ∧ ∑ e, T e * c e = 1 := by
  obtain ⟨f, hfc, hmap⟩ :=
    Submodule.exists_dual_map_eq_bot_of_notMem h (Module.Projective.of_free)
  let T : E → ZMod 2 := fun e => f (fun j => if e = j then 1 else 0)
  have hf : ∀ v, f v = ∑ e, T e * v e := by
    intro v
    rw [LinearMap.pi_apply_eq_sum_univ f v]
    apply sum_congr rfl
    intro e _
    rw [smul_eq_mul, mul_comm]
  refine ⟨T, ?_, ?_⟩
  · intro p hp
    rw [← hf]
    have hmem : d p ∈ Submodule.span (ZMod 2) (d '' (X : Set P)) :=
      Submodule.subset_span ⟨p, hp, rfl⟩
    have : f (d p) ∈ Submodule.map f (Submodule.span (ZMod 2) (d '' (X : Set P))) :=
      Submodule.mem_map_of_mem hmem
    rw [hmap, Submodule.mem_bot] at this
    exact this
  · rw [← hf]
    exact zmod2_eq_one_of_ne_zero _ hfc

/-- **Converse.**  A separating `T` shows `c ∉ span {d p : p ∈ X}`. -/
theorem not_mem_span_of_sep {E P : Type*} [Fintype E]
    (c : E → ZMod 2) (d : P → E → ZMod 2) (X : Finset P) (T : E → ZMod 2)
    (hX : ∀ p ∈ X, ∑ e, T e * d p e = 0) (hc : ∑ e, T e * c e = 1) :
    c ∉ Submodule.span (ZMod 2) (d '' (X : Set P)) := by
  intro hmem
  have hle : Submodule.span (ZMod 2) (d '' (X : Set P)) ≤ LinearMap.ker (pairF2 T) := by
    rw [Submodule.span_le]
    rintro _ ⟨p, hp, rfl⟩
    exact hX p hp
  have := hle hmem
  rw [LinearMap.mem_ker] at this
  change ∑ e, T e * c e = 0 at this
  rw [hc] at this
  exact one_ne_zero this

/-- The two statements together: `c` lies outside the span iff a separating `T` exists. -/
theorem not_mem_span_iff_exists_sep {E P : Type*} [Fintype E] [DecidableEq E]
    (c : E → ZMod 2) (d : P → E → ZMod 2) (X : Finset P) :
    c ∉ Submodule.span (ZMod 2) (d '' (X : Set P)) ↔
      ∃ T : E → ZMod 2, (∀ p ∈ X, ∑ e, T e * d p e = 0) ∧ ∑ e, T e * c e = 1 :=
  ⟨exists_sep_of_not_mem_span c d X, fun ⟨T, hX, hc⟩ => not_mem_span_of_sep c d X T hX hc⟩

/-- Sanity (both sides occur): with two links and one face whose boundary is the first
link, the loop `c = (0,1)` is outside the span (separated by `T = (0,1)`), while
`c = (1,0)` is inside it. -/
theorem sanity_two_links :
    (![0, 1] : Fin 2 → ZMod 2) ∉
        Submodule.span (ZMod 2) ((fun _ : Unit => (![1, 0] : Fin 2 → ZMod 2)) '' ({()} : Set Unit))
      ∧ (![1, 0] : Fin 2 → ZMod 2) ∈
        Submodule.span (ZMod 2) ((fun _ : Unit => (![1, 0] : Fin 2 → ZMod 2)) '' ({()} : Set Unit)) := by
  constructor
  · have := not_mem_span_of_sep (E := Fin 2) (![0, 1]) (fun _ : Unit => ![1, 0]) {()}
      ![0, 1] (by intro p _; simp [Fin.sum_univ_two]) (by simp [Fin.sum_univ_two])
    simpa using this
  · exact Submodule.subset_span ⟨(), rfl, rfl⟩

end AreaLaw

#print axioms AreaLaw.not_mem_span_iff_exists_sep
#print axioms AreaLaw.sanity_two_links
