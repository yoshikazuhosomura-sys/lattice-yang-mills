import Area.ConnPartsV1

/-!
# The rectangle is a simple cycle mod 2

Paper correspondence: the step-5 input "the only closed mod-2 chains supported in the loop
`C` are `0` and `C`" for the boundary of the `R × T` rectangle (`1 ≤ R < N`, `1 ≤ T < N`).

* `sum_mul_delta_eq_zero`: summation by parts — a closed chain (`div v = 0`) pairs to `0` with
  the coboundary of the indicator of any site set `S`.
* `sum_mul_eq_word`: if `v` is supported in the support of `wordBd w`, a pairing with `v` is a sum
  along the word.
* with `S` = the sites projecting to one corner/edge point `(a, b)` of the rectangle, the two
  rectangle links at that point carry equal values of `v`; going around, `v` is constant on the
  rectangle, so `v = 0` or `v = wordBd (rectWord)`.
-/

open Finset TorusRP

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-- **Summation by parts.** -/
theorem sum_mul_delta_eq_zero (v : Lk N → ZMod 2) (hv : ∀ z, div N v z = 0)
    (S : Site N → Prop) [DecidablePred S] :
    ∑ e : Lk N, v e * ((if S e.1 then 1 else 0) + (if S (e.1 + ev N e.2) then 1 else 0)) = 0 := by
  have h0 : ∑ z : Site N, (if S z then (1 : ZMod 2) else 0) * div N v z = 0 := by
    simp [hv]
  have hshift : ∀ μ : Fin 4, ∑ z : Site N, (if S z then (1 : ZMod 2) else 0) * v (z - ev N μ, μ)
      = ∑ y : Site N, (if S (y + ev N μ) then (1 : ZMod 2) else 0) * v (y, μ) := by
    intro μ
    exact (Fintype.sum_equiv (Equiv.addRight (ev N μ)) _ _
      (fun y => by simp only [Equiv.coe_addRight, add_sub_cancel_right]; rfl)).symm
  refine Eq.trans ?_ h0
  rw [Fintype.sum_prod_type]
  calc ∑ z : Site N, ∑ μ : Fin 4, v (z, μ) * ((if S (z, μ).1 then 1 else 0)
          + (if S ((z, μ).1 + ev N (z, μ).2) then 1 else 0))
      = (∑ z : Site N, ∑ μ : Fin 4, (if S z then (1 : ZMod 2) else 0) * v (z, μ))
        + ∑ z : Site N, ∑ μ : Fin 4, (if S (z + ev N μ) then (1 : ZMod 2) else 0) * v (z, μ) := by
        rw [← sum_add_distrib]
        apply sum_congr rfl; intro z _
        rw [← sum_add_distrib]
        apply sum_congr rfl; intro μ _
        ring
    _ = (∑ z : Site N, ∑ μ : Fin 4, (if S z then (1 : ZMod 2) else 0) * v (z, μ))
        + ∑ μ : Fin 4, ∑ z : Site N, (if S z then (1 : ZMod 2) else 0) * v (z - ev N μ, μ) := by
        simp only [hshift]
        congr 1
        exact sum_comm
    _ = ∑ z : Site N, (if S z then (1 : ZMod 2) else 0) * div N v z := by
        rw [sum_comm (s := (univ : Finset (Fin 4))), ← sum_add_distrib]
        apply sum_congr rfl; intro z _
        rw [div, mul_sum, ← sum_add_distrib]
        apply sum_congr rfl; intro μ _
        ring

/-- a pairing with a chain supported in `supp (wordBd w)` is a sum along `w` -/
theorem sum_mul_eq_word (w : Word N) (v g : Lk N → ZMod 2)
    (hsupp : ∀ e, v e ≠ 0 → wordBd N w e ≠ 0) :
    ∑ e, v e * g e = (w.map (fun s => v s.1 * g s.1)).sum := by
  rw [← pair_wordBd N (fun e => v e * g e) w]
  apply sum_congr rfl
  intro e _
  by_cases h : v e = 0
  · simp [h]
  · have h1 : wordBd N w e = 1 := by
      rcases zmod2_cases (wordBd N w e) with h' | h'
      · exact absurd h' (hsupp e h)
      · exact h'
    rw [h1, mul_one]

lemma listsum_range (f : ℕ → ZMod 2) (n : ℕ) : ((List.range n).map f).sum = ∑ i ∈ range n, f i := by
  induction n with
  | zero => simp
  | succ n ih => rw [List.range_succ, List.map_append, List.sum_append, ih, sum_range_succ]; simp

lemma pt_add_ev0_0 (i j : ℕ) : (pt N i j + ev N 0) 0 = ((i + 1 : ℕ) : ZMod N) := by
  simp [pt, ev]
lemma pt_add_ev0_1 (i j : ℕ) : (pt N i j + ev N 0) 1 = (j : ZMod N) := by
  simp [pt, ev]
lemma pt_add_ev1_0 (i j : ℕ) : (pt N i j + ev N 1) 0 = (i : ZMod N) := by
  simp [pt, ev]
lemma pt_add_ev1_1 (i j : ℕ) : (pt N i j + ev N 1) 1 = ((j + 1 : ℕ) : ZMod N) := by
  simp [pt, ev]

section Rect

variable (R T : ℕ)

/-- the four sides of the rectangle -/
def bL (i : ℕ) : Lk N := (pt N i 0, 0)
def rL (j : ℕ) : Lk N := (pt N R j, 1)
def tL (i : ℕ) : Lk N := (pt N i T, 0)
def lL (j : ℕ) : Lk N := (pt N 0 j, 1)

/-- **Relation at a projected point** `(a', b')`: the chain values of the rectangle links meeting
the sites `{z : z₀ = a', z₁ = b'}` sum to `0`. -/
theorem rect_rel (hR : R < N) (hT : T < N) (v : Lk N → ZMod 2) (hv : ∀ z, div N v z = 0)
    (hsupp : ∀ e, v e ≠ 0 → wordBd N (rectWord N R T) e ≠ 0) (a' b' : ℕ) (ha : a' < N)
    (hb : b' < N) :
    (∑ i ∈ range R, v (bL N i) * ((if i = a' ∧ 0 = b' then 1 else 0)
        + (if i + 1 = a' ∧ 0 = b' then 1 else 0)))
    + (∑ j ∈ range T, v (rL N R j) * ((if R = a' ∧ j = b' then 1 else 0)
        + (if R = a' ∧ j + 1 = b' then 1 else 0)))
    + (∑ i ∈ range R, v (tL N T i) * ((if i = a' ∧ T = b' then 1 else 0)
        + (if i + 1 = a' ∧ T = b' then 1 else 0)))
    + (∑ j ∈ range T, v (lL N j) * ((if 0 = a' ∧ j = b' then 1 else 0)
        + (if 0 = a' ∧ j + 1 = b' then 1 else 0))) = 0 := by
  classical
  have h := sum_mul_delta_eq_zero N v hv (fun z => z 0 = (a' : ZMod N) ∧ z 1 = (b' : ZMod N))
  rw [sum_mul_eq_word N (rectWord N R T) v _ hsupp] at h
  refine Eq.trans ?_ h
  simp only [rectWord, List.map_append, List.sum_append, List.map_map, List.map_reverse,
    List.sum_reverse, Function.comp_def, listsum_range]
  have c0 : ∀ i j : ℕ, i < N → j < N → ((i : ZMod N) = (j : ZMod N) ↔ i = j) :=
    fun i j hi hj => natCast_inj_lt N hi hj
  congr 1; congr 1; congr 1
  · apply sum_congr rfl; intro i hi; rw [mem_range] at hi
    simp only [bL, pt_apply0, pt_apply1, pt_add_ev0_0, pt_add_ev0_1, c0 i a' (by omega) ha,
      c0 0 b' (by omega) hb, c0 (i+1) a' (by omega) ha]
  · apply sum_congr rfl; intro j hj; rw [mem_range] at hj
    simp only [rL, pt_apply0, pt_apply1, pt_add_ev1_0, pt_add_ev1_1, c0 R a' (by omega) ha,
      c0 j b' (by omega) hb, c0 (j+1) b' (by omega) hb]
  · apply sum_congr rfl; intro i hi; rw [mem_range] at hi
    simp only [tL, pt_apply0, pt_apply1, pt_add_ev0_0, pt_add_ev0_1, c0 i a' (by omega) ha,
      c0 T b' (by omega) hb, c0 (i+1) a' (by omega) ha]
  · apply sum_congr rfl; intro j hj; rw [mem_range] at hj
    simp only [lL, pt_apply0, pt_apply1, pt_add_ev1_0, pt_add_ev1_1, c0 0 a' (by omega) ha,
      c0 j b' (by omega) hb, c0 (j+1) b' (by omega) hb]


lemma sum_ind_eq (f : ℕ → ZMod 2) (n k : ℕ) :
    ∑ i ∈ range n, f i * (if i = k then 1 else 0) = if k < n then f k else 0 := by
  simp only [mul_ite, mul_one, mul_zero]
  rw [sum_ite_eq']
  simp [mem_range]

lemma sum_ind_succ (f : ℕ → ZMod 2) (n k : ℕ) :
    ∑ i ∈ range n, f i * (if i + 1 = k then 1 else 0)
      = if 1 ≤ k ∧ k ≤ n then f (k - 1) else 0 := by
  by_cases hk : 1 ≤ k
  · have : ∀ i, (i + 1 = k ↔ i = k - 1) := fun i => by omega
    simp only [this, sum_ind_eq]
    by_cases h : k - 1 < n
    · rw [if_pos h, if_pos ⟨hk, by omega⟩]
    · rw [if_neg h, if_neg (by omega)]
  · rw [if_neg (by omega)]
    apply sum_eq_zero
    intro i _
    rw [if_neg (by omega), mul_zero]

/-- evaluation of a side sum whose transverse condition `P` is constant -/
lemma side_eval (f : ℕ → ZMod 2) (n k : ℕ) (P : Prop) [Decidable P] :
    ∑ i ∈ range n, f i * ((if i = k ∧ P then 1 else 0) + (if i + 1 = k ∧ P then 1 else 0))
      = if P then (if k < n then f k else 0) + (if 1 ≤ k ∧ k ≤ n then f (k - 1) else 0)
        else 0 := by
  by_cases hP : P
  · simp only [hP, and_true, if_true, mul_add, sum_add_distrib, sum_ind_eq, sum_ind_succ]
  · simp [hP]

lemma side_eval' (f : ℕ → ZMod 2) (n k : ℕ) (P : Prop) [Decidable P] :
    ∑ i ∈ range n, f i * ((if P ∧ i = k then 1 else 0) + (if P ∧ i + 1 = k then 1 else 0))
      = if P then (if k < n then f k else 0) + (if 1 ≤ k ∧ k ≤ n then f (k - 1) else 0)
        else 0 := by
  simp only [and_comm (a := P)]
  exact side_eval f n k P

lemma zmod2_eq_of_add (a b : ZMod 2) (h : a + b = 0) : a = b := by
  revert a b; decide

/-- the four local relations, in evaluated form -/
theorem rect_rel_eval (hR : R < N) (hT : T < N) (v : Lk N → ZMod 2) (hv : ∀ z, div N v z = 0)
    (hsupp : ∀ e, v e ≠ 0 → wordBd N (rectWord N R T) e ≠ 0) (a' b' : ℕ) (ha : a' < N)
    (hb : b' < N) :
    ((if 0 = b' then (if a' < R then v (bL N a') else 0)
        + (if 1 ≤ a' ∧ a' ≤ R then v (bL N (a' - 1)) else 0) else 0)
    + (if R = a' then (if b' < T then v (rL N R b') else 0)
        + (if 1 ≤ b' ∧ b' ≤ T then v (rL N R (b' - 1)) else 0) else 0)
    + (if T = b' then (if a' < R then v (tL N T a') else 0)
        + (if 1 ≤ a' ∧ a' ≤ R then v (tL N T (a' - 1)) else 0) else 0)
    + (if 0 = a' then (if b' < T then v (lL N b') else 0)
        + (if 1 ≤ b' ∧ b' ≤ T then v (lL N (b' - 1)) else 0) else 0)) = 0 := by
  have h := rect_rel N R T hR hT v hv hsupp a' b' ha hb
  rw [side_eval (fun i => v (bL N i)), side_eval' (fun j => v (rL N R j)),
    side_eval (fun i => v (tL N T i)), side_eval' (fun j => v (lL N j))] at h
  exact h

/-- **The rectangle is a simple cycle mod 2.**  For `1 ≤ R < N`, `1 ≤ T < N`, a closed mod-2
chain supported in the support of the rectangle's boundary is constant along the rectangle. -/
theorem rect_const (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N) (v : Lk N → ZMod 2)
    (hv : ∀ z, div N v z = 0) (hsupp : ∀ e, v e ≠ 0 → wordBd N (rectWord N R T) e ≠ 0) :
    (∀ i < R, v (bL N i) = v (bL N 0)) ∧ (∀ j < T, v (rL N R j) = v (bL N 0)) ∧
    (∀ i < R, v (tL N T i) = v (bL N 0)) ∧ (∀ j < T, v (lL N j) = v (bL N 0)) := by
  have E := rect_rel_eval N R T hR hT v hv hsupp
  -- bottom
  have hb : ∀ i < R, v (bL N i) = v (bL N 0) := by
    intro i
    induction i with
    | zero => intro _; rfl
    | succ i ih =>
      intro hi
      have h := E (i + 1) 0 (by omega) (by omega)
      simp only [↓reduceIte, if_pos rfl, if_pos hi, if_pos (show 1 ≤ i + 1 ∧ i + 1 ≤ R by omega),
        Nat.add_sub_cancel, if_neg (show R ≠ i + 1 by omega), if_neg (show T ≠ 0 by omega),
        if_neg (show 0 ≠ i + 1 by omega), add_zero] at h
      rw [zmod2_eq_of_add _ _ h, ih (by omega)]
  -- right
  have hr : ∀ j < T, v (rL N R j) = v (bL N 0) := by
    intro j
    induction j with
    | zero =>
      intro _
      have h := E R 0 (by omega) (by omega)
      simp only [↓reduceIte, if_pos rfl, if_neg (show ¬ R < R by omega),
        if_pos (show 1 ≤ R ∧ R ≤ R by omega), if_pos (show 0 < T by omega),
        if_neg (show ¬ (1 ≤ 0 ∧ 0 ≤ T) by omega), if_neg (show T ≠ 0 by omega),
        if_neg (show 0 ≠ R by omega), zero_add, add_zero] at h
      rw [← zmod2_eq_of_add _ _ h, hb (R - 1) (by omega)]
    | succ j ih =>
      intro hj
      have h := E R (j + 1) (by omega) (by omega)
      simp only [↓reduceIte, if_neg (show 0 ≠ j + 1 by omega), if_pos rfl, if_pos hj,
        if_pos (show 1 ≤ j + 1 ∧ j + 1 ≤ T by omega), Nat.add_sub_cancel,
        if_neg (show T ≠ j + 1 by omega), if_neg (show 0 ≠ R by omega), zero_add,
        add_zero] at h
      rw [zmod2_eq_of_add _ _ h, ih (by omega)]
  -- top, from the right end downwards
  have ht : ∀ k < R, v (tL N T (R - 1 - k)) = v (bL N 0) := by
    intro k
    induction k with
    | zero =>
      intro _
      have h := E R T (by omega) (by omega)
      simp only [↓reduceIte, if_neg (show 0 ≠ T by omega), if_pos rfl, if_neg (show ¬ T < T by omega),
        if_pos (show 1 ≤ T ∧ T ≤ T by omega), if_neg (show ¬ R < R by omega),
        if_pos (show 1 ≤ R ∧ R ≤ R by omega), if_neg (show 0 ≠ R by omega), zero_add,
        add_zero] at h
      rw [Nat.sub_zero, ← zmod2_eq_of_add _ _ h, hr (T - 1) (by omega)]
    | succ k ih =>
      intro hk
      have h := E (R - 1 - k) T (by omega) (by omega)
      simp only [↓reduceIte, if_neg (show 0 ≠ T by omega), if_neg (show R ≠ R - 1 - k by omega),
        if_pos rfl, if_pos (show R - 1 - k < R by omega),
        if_pos (show 1 ≤ R - 1 - k ∧ R - 1 - k ≤ R by omega),
        if_neg (show 0 ≠ R - 1 - k by omega), zero_add, add_zero] at h
      rw [show R - 1 - (k + 1) = R - 1 - k - 1 by omega, ← zmod2_eq_of_add _ _ h, ih (by omega)]
  -- left, from the top downwards
  have hl : ∀ k < T, v (lL N (T - 1 - k)) = v (bL N 0) := by
    intro k
    induction k with
    | zero =>
      intro _
      have h := E 0 T (by omega) (by omega)
      simp only [↓reduceIte, if_neg (show 0 ≠ T by omega), if_neg (show R ≠ 0 by omega), if_pos rfl,
        if_pos (show 0 < R by omega), if_neg (show ¬ (1 ≤ 0 ∧ 0 ≤ R) by omega),
        if_neg (show ¬ T < T by omega), if_pos (show 1 ≤ T ∧ T ≤ T by omega), zero_add,
        add_zero] at h
      have h0 := ht (R - 1) (by omega)
      rw [show R - 1 - (R - 1) = 0 by omega] at h0
      rw [Nat.sub_zero, ← zmod2_eq_of_add _ _ h, h0]
    | succ k ih =>
      intro hk
      have h := E 0 (T - 1 - k) (by omega) (by omega)
      simp only [↓reduceIte, if_neg (show 0 ≠ T - 1 - k by omega), if_neg (show R ≠ 0 by omega),
        if_neg (show T ≠ T - 1 - k by omega), if_pos rfl, if_pos (show T - 1 - k < T by omega),
        if_pos (show 1 ≤ T - 1 - k ∧ T - 1 - k ≤ T by omega), zero_add] at h
      rw [show T - 1 - (k + 1) = T - 1 - k - 1 by omega, ← zmod2_eq_of_add _ _ h, ih (by omega)]
  refine ⟨hb, hr, fun i hi => ?_, fun j hj => ?_⟩
  · have := ht (R - 1 - i) (by omega)
    rwa [show R - 1 - (R - 1 - i) = i by omega] at this
  · have := hl (T - 1 - j) (by omega)
    rwa [show T - 1 - (T - 1 - j) = j by omega] at this


theorem mem_word_of_wordBd_ne (w : Word N) (e : Lk N) (h : wordBd N w e ≠ 0) : ∃ s ∈ w, s.1 = e := by
  induction w with
  | nil => simp [wordBd] at h
  | cons s w ih =>
    by_cases hs : s.1 = e
    · exact ⟨s, List.mem_cons_self, hs⟩
    · have : wordBd N w e ≠ 0 := by simpa [wordBd, hs] using h
      obtain ⟨s', hs', he⟩ := ih this
      exact ⟨s', List.mem_cons_of_mem _ hs', he⟩

/-- the links of the rectangle word -/
theorem rect_link_cases (e : Lk N) (h : wordBd N (rectWord N R T) e ≠ 0) :
    (∃ i < R, e = bL N i) ∨ (∃ j < T, e = rL N R j) ∨ (∃ i < R, e = tL N T i) ∨
      (∃ j < T, e = lL N j) := by
  obtain ⟨s, hs, rfl⟩ := mem_word_of_wordBd_ne N _ e h
  simp only [rectWord, List.mem_append, List.mem_map, List.mem_reverse, List.mem_range] at hs
  rcases hs with ((⟨i, hi, rfl⟩ | ⟨j, hj, rfl⟩) | ⟨i, hi, rfl⟩) | ⟨j, hj, rfl⟩
  · exact Or.inl ⟨i, hi, rfl⟩
  · exact Or.inr (Or.inl ⟨j, hj, rfl⟩)
  · exact Or.inr (Or.inr (Or.inl ⟨i, hi, rfl⟩))
  · exact Or.inr (Or.inr (Or.inr ⟨j, hj, rfl⟩))

/-- **The rectangle is a simple cycle mod 2**: a closed mod-2 chain supported in the support
of the rectangle's boundary is `0` or the boundary itself (`1 ≤ R < N`, `1 ≤ T < N`). -/
theorem rect_closed_cases (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N)
    (v : Lk N → ZMod 2) (hv : ∀ z, div N v z = 0)
    (hsupp : ∀ e, v e ≠ 0 → wordBd N (rectWord N R T) e ≠ 0) :
    v = 0 ∨ v = wordBd N (rectWord N R T) := by
  obtain ⟨hb, hr, ht, hl⟩ := rect_const N R T hR1 hT1 hR hT v hv hsupp
  have key : ∀ e, v e = v (bL N 0) * wordBd N (rectWord N R T) e := by
    intro e
    by_cases hc : wordBd N (rectWord N R T) e = 0
    · rw [hc, mul_zero]
      by_contra hve
      exact hsupp e hve hc
    · have h1 : wordBd N (rectWord N R T) e = 1 := by
        rcases zmod2_cases (wordBd N (rectWord N R T) e) with h' | h'
        · exact absurd h' hc
        · exact h'
      rw [h1, mul_one]
      rcases rect_link_cases N R T e hc with ⟨i, hi, rfl⟩ | ⟨j, hj, rfl⟩ | ⟨i, hi, rfl⟩ | ⟨j, hj, rfl⟩
      · exact hb i hi
      · exact hr j hj
      · exact ht i hi
      · exact hl j hj
  rcases zmod2_cases (v (bL N 0)) with h0 | h0
  · left; funext e; rw [key e, h0, zero_mul]; rfl
  · right; funext e; rw [key e, h0, one_mul]

end Rect

end AreaLaw

#print axioms AreaLaw.rect_closed_cases
