import Area.SimpleCycleV1
import Area.AnimalV1

/-!
# Minimal spanning sets of the rectangle are connected and rooted; the counting bound

Paper correspondence: steps 5 and 7 of the strong-coupling area-law argument, for the
`R × T` rectangle (`1 ≤ R < N`, `1 ≤ T < N`) on `(ℤ/N)⁴`.

* `plaqLinks p` (the four links of `p`), `nbP p` (plaquettes sharing a link with `p`).
* `minSpan_rect_conn`: every minimal spanning set is connected in the cut sense (if a proper
  part shared no link with the rest, its boundary would be a closed chain supported in the
  rectangle, hence `0` or the whole rectangle — contradicting minimality).
* `minSpan_rect_root`: every minimal spanning set contains a plaquette through the first
  bottom link `bL 0`.
* `card_rootSet_le`: at most `16` plaquettes (with `p.1.2, p.2` arbitrary directions) contain a
  given link; `card_nbP_le`: at most `64` neighbours.
* `sum_minSpan_rect_le`: `∑_{Y minimal} x^{|Y|} ≤ 16 ∑_{A ≤ n ≤ M} 4096^{n-1} x^n`,
  `A = R·min(T, N-T)`.
-/

open Finset TorusRP

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-- the four links of a plaquette -/
def plaqLinks (p : Lk N × Fin 4) : Finset (Lk N) := ((plaqWord N p).map Prod.fst).toFinset

theorem mem_plaqLinks_of_bd (p : Lk N × Fin 4) (e : Lk N) (h : plaqBd N p e ≠ 0) :
    e ∈ plaqLinks N p := by
  obtain ⟨s, hs, rfl⟩ := mem_word_of_wordBd_ne N _ e h
  unfold plaqLinks
  rw [List.mem_toFinset, List.mem_map]
  exact ⟨s, hs, rfl⟩

/-- plaquettes sharing a link with `p` -/
def nbP (p : Lk N × Fin 4) : Finset (Lk N × Fin 4) :=
  univ.filter (fun p' => ∃ e ∈ plaqLinks N p, e ∈ plaqLinks N p')

theorem nbP_symm (a b : Lk N × Fin 4) : b ∈ nbP N a ↔ a ∈ nbP N b := by
  simp only [nbP, mem_filter, mem_univ, true_and]
  constructor <;> rintro ⟨e, h1, h2⟩ <;> exact ⟨e, h2, h1⟩

theorem exists_of_sum_bd_ne (A : Finset (Lk N × Fin 4)) (e : Lk N)
    (h : (∑ p ∈ A, plaqBd N p) e ≠ 0) : ∃ p ∈ A, plaqBd N p e ≠ 0 := by
  rw [Finset.sum_apply] at h
  exact exists_ne_zero_of_sum_ne_zero h

theorem minSpanC_min (c : Lk N → ZMod 2) (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpanC N c) :
    ∀ Y' ⊆ Y, SpansC N c Y' → Y' = Y := by
  classical
  unfold minSpanC at hY
  rw [mem_filter] at hY
  exact hY.2.2

theorem spans_sum (c : Lk N → ZMod 2) (S : Finset (Lk N × Fin 4))
    (h : c = ∑ p ∈ S, plaqBd N p) : SpansC N c S := by
  unfold SpansC
  rw [h]
  exact Submodule.sum_mem _ (fun p hp => Submodule.subset_span ⟨p, by simpa using hp, rfl⟩)

/-- **Minimal spanning sets of the rectangle are connected.** -/
theorem minSpan_rect_conn (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N)
    (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpanC N (wordBd N (rectWord N R T))) :
    CutConn (nbP N) Y := by
  classical
  intro S hSY hSne hSneq
  by_contra hno
  push Not at hno
  set c := wordBd N (rectWord N R T) with hc_def
  have hc : c = ∑ p ∈ S, plaqBd N p + ∑ p ∈ Y \ S, plaqBd N p := by
    rw [minSpanC_exact N c Y hY, ← sum_sdiff hSY, add_comm]
  set v := ∑ p ∈ S, plaqBd N p with hv_def
  have hdisj : ∀ e, v e ≠ 0 → (∑ p ∈ Y \ S, plaqBd N p) e = 0 := by
    intro e hve
    by_contra hne
    obtain ⟨a, ha, hae⟩ := exists_of_sum_bd_ne N S e hve
    obtain ⟨b, hb, hbe⟩ := exists_of_sum_bd_ne N (Y \ S) e hne
    apply hno a ha b hb
    simp only [nbP, mem_filter, mem_univ, true_and]
    exact ⟨e, mem_plaqLinks_of_bd N a e hae, mem_plaqLinks_of_bd N b e hbe⟩
  have hsupp : ∀ e, v e ≠ 0 → c e ≠ 0 := by
    intro e hve
    rw [hc, Pi.add_apply, hdisj e hve, add_zero]
    exact hve
  have hclosed : ∀ z, div N v z = 0 := fun z => div_sum_plaqBd N S z
  rcases rect_closed_cases N R T hR1 hT1 hR hT v hclosed hsupp with h0 | hcv
  · have hYS : SpansC N c (Y \ S) := by
      apply spans_sum
      rw [hc, h0, zero_add]
    have := minSpanC_min N c Y hY (Y \ S) sdiff_subset hYS
    obtain ⟨x, hx⟩ := hSne
    have hxY : x ∈ Y := hSY hx
    rw [← this, mem_sdiff] at hxY
    exact hxY.2 hx
  · have hS : SpansC N c S := spans_sum N c S (by rw [← hv_def, hcv])
    exact hSneq (minSpanC_min N c Y hY S hSY hS)

/-- the rectangle's boundary contains the first bottom link -/
theorem rect_bL0 (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N) :
    wordBd N (rectWord N R T) (bL N 0) ≠ 0 := by
  classical
  have hpair := pair_rowT_rect N R T 0 (by omega) (by omega) 0
  have hT0 : (0 : ZMod N) ≠ (T : ZMod N) := by
    rw [← Nat.cast_zero, Ne, natCast_inj_lt N (by omega) hT]; omega
  rw [if_pos rfl, if_neg hT0, add_zero] at hpair
  rw [sum_eq_single (bL N 0)] at hpair
  · intro h0
    rw [h0, mul_zero] at hpair
    exact zero_ne_one hpair
  · intro e _ he
    by_cases hc : wordBd N (rectWord N R T) e = 0
    · rw [hc, mul_zero]
    · have hrow : rowT N ((0 : ℕ) : ZMod N) 0 e = 0 := by
        rcases rect_link_cases N R T e hc with ⟨i, hi, rfl⟩ | ⟨j, hj, rfl⟩ | ⟨i, hi, rfl⟩ |
          ⟨j, hj, rfl⟩
        · have hi0 : i ≠ 0 := by rintro rfl; exact he rfl
          simp only [rowT, bL, pt_apply0, pt_apply1]
          rw [if_neg]
          rintro ⟨_, h1, _⟩
          rw [natCast_inj_lt N (by omega) (by omega)] at h1
          exact hi0 h1
        · simp [rowT, rL]
        · simp only [rowT, tL, pt_apply0, pt_apply1]
          rw [if_neg]
          rintro ⟨_, _, h2⟩
          exact hT0 h2.symm
        · simp [rowT, lL]
      rw [hrow, zero_mul]
  · intro h; exact absurd (mem_univ _) h

/-- **Rooting.**  Every minimal spanning set contains a plaquette through `bL 0`. -/
theorem minSpan_rect_root (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N)
    (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpanC N (wordBd N (rectWord N R T))) :
    ∃ p ∈ Y, bL N 0 ∈ plaqLinks N p := by
  have h := rect_bL0 N R T hR1 hT1 hR hT
  rw [minSpanC_exact N _ Y hY] at h
  obtain ⟨p, hp, hpe⟩ := exists_of_sum_bd_ne N Y _ h
  exact ⟨p, hp, mem_plaqLinks_of_bd N p _ hpe⟩

/-- plaquettes containing a link `ℓ` -/
def rootSet (ℓ : Lk N) : Finset (Lk N × Fin 4) := univ.filter (fun p => ℓ ∈ plaqLinks N p)

/-- the plaquette with `ℓ` in position `k` and other direction `d` -/
def placeAt (ℓ : Lk N) (kd : Fin 4 × Fin 4) : Lk N × Fin 4 :=
  if kd.1 = 0 then ((ℓ.1, ℓ.2), kd.2)
  else if kd.1 = 1 then ((ℓ.1 - ev N kd.2, kd.2), ℓ.2)
  else if kd.1 = 2 then ((ℓ.1 - ev N kd.2, ℓ.2), kd.2)
  else ((ℓ.1, kd.2), ℓ.2)

theorem card_rootSet_le (ℓ : Lk N) : (rootSet N ℓ).card ≤ 16 := by
  have hsub : rootSet N ℓ ⊆ univ.image (placeAt N ℓ) := by
    intro p hp
    simp only [rootSet, mem_filter, mem_univ, true_and, plaqLinks, plaqWord, List.map_cons,
      List.map_nil, List.mem_toFinset, List.mem_cons, List.not_mem_nil, or_false] at hp
    rw [mem_image]
    obtain ⟨⟨x, μ⟩, ν⟩ := p
    rcases hp with h | h | h | h
    · exact ⟨(0, ν), mem_univ _, by simp [placeAt, h]⟩
    · exact ⟨(1, μ), mem_univ _, by simp [placeAt, h]⟩
    · exact ⟨(2, ν), mem_univ _, by simp [placeAt, h]⟩
    · exact ⟨(3, μ), mem_univ _, by simp [placeAt, h]⟩
  calc (rootSet N ℓ).card ≤ (univ.image (placeAt N ℓ)).card := card_le_card hsub
    _ ≤ (univ : Finset (Fin 4 × Fin 4)).card := card_image_le
    _ = 16 := by simp

theorem card_plaqLinks_le (p : Lk N × Fin 4) : (plaqLinks N p).card ≤ 4 := by
  unfold plaqLinks
  refine (List.toFinset_card_le _).trans ?_
  simp [plaqWord]

theorem card_nbP_le (p : Lk N × Fin 4) : (nbP N p).card ≤ 64 := by
  have hsub : nbP N p ⊆ (plaqLinks N p).biUnion (rootSet N) := by
    intro p' hp'
    simp only [nbP, mem_filter, mem_univ, true_and] at hp'
    obtain ⟨e, he, he'⟩ := hp'
    rw [mem_biUnion]
    exact ⟨e, he, by simp [rootSet, he']⟩
  calc (nbP N p).card ≤ ((plaqLinks N p).biUnion (rootSet N)).card := card_le_card hsub
    _ ≤ ∑ e ∈ plaqLinks N p, (rootSet N e).card := card_biUnion_le
    _ ≤ ∑ _e ∈ plaqLinks N p, 16 := sum_le_sum fun e _ => card_rootSet_le N e
    _ = (plaqLinks N p).card * 16 := by rw [sum_const, smul_eq_mul]
    _ ≤ 4 * 16 := Nat.mul_le_mul_right _ (card_plaqLinks_le N p)
    _ = 64 := by norm_num

open Classical in
/-- **Counting.**  For `x ≥ 0`, with `A = R·min(T, N-T)` and `M = #plaqs`,
`∑_{Y minimal} x^{|Y|} ≤ 16 ∑_{n ∈ [A, M]} 4096^{n-1} x^n`. -/
theorem sum_minSpan_rect_le (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N)
    (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minSpanC N (wordBd N (rectWord N R T)), x ^ Y.card
      ≤ 16 * ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minSpanC N (wordBd N (rectWord N R T)) with hF
  set A := R * min T (N - T) with hA
  set M := (plaqs N).card with hM
  have hA1 : 1 ≤ A := Nat.mul_le_mul hR1 (le_min hT1 (by omega))
  -- step 1: roots
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ rootSet N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ rootSet N (bL N 0), (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨p, hp, hpl⟩ := minSpan_rect_root N R T hR1 hT1 hR hT Y hY
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [rootSet, hpl], hp⟩)
      _ = ∑ r ∈ rootSet N (bL N 0), ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ rootSet N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  -- step 2: for one root, sort by size
  have h2 : ∀ r, ∑ Y ∈ F with r ∈ Y, x ^ Y.card
      ≤ ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
    intro r
    have hmaps : ∀ Y ∈ F.filter (fun Y => r ∈ Y), Y.card ∈ Ico A (M + 1) := by
      intro Y hY
      have hYF := (mem_filter.mp hY).1
      have hsub := minSpanC_sub N _ Y hYF
      rw [mem_Ico]
      exact ⟨card_ge_of_spans_rect N R T hR.le (by omega) hT Y hsub.1 hsub.2,
        Nat.lt_succ_of_le (card_le_card hsub.1)⟩
    rw [← sum_fiberwise_of_maps_to hmaps]
    apply sum_le_sum
    intro n hn
    have hnA : A ≤ n := (mem_Ico.mp hn).1
    have hcongr : ∑ Y ∈ F.filter (fun Y => r ∈ Y) with Y.card = n, x ^ Y.card
        = ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)).card * x ^ n := by
      rw [sum_congr rfl (fun Y hY => by rw [(mem_filter.mp hY).2]), sum_const, nsmul_eq_mul]
    rw [hcongr]
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hx _)
    have hcount := card_conn_le (nbP N) (nbP_symm N) 64 (card_nbP_le N) r n (by omega)
      ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)) (by
        intro Y hY
        rw [mem_filter, mem_filter] at hY
        exact ⟨hY.1.2, hY.2, minSpan_rect_conn N R T hR1 hT1 hR hT Y hY.1.1⟩)
    have h64 : (64 : ℕ) ^ (2 * (n - 1)) = 4096 ^ (n - 1) := by
      rw [pow_mul]; norm_num
    rw [h64] at hcount
    exact_mod_cast hcount
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ rootSet N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ rootSet N (bL N 0), ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => h2 r
    _ = (rootSet N (bL N 0)).card * ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
        rw [sum_const, nsmul_eq_mul]
    _ ≤ 16 * ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ (sum_nonneg fun n _ =>
          mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _))
        exact_mod_cast card_rootSet_le N (bL N 0)

end AreaLaw

#print axioms AreaLaw.minSpan_rect_conn
#print axioms AreaLaw.sum_minSpan_rect_le
