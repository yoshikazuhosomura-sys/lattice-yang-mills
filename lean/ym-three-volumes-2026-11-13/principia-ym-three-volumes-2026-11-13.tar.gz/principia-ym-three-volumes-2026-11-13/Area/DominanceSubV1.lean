import Mathlib

/-!
# The domination lemma inside an ambient finite set

Same statement as `Area.DominanceV1` (`AreaLaw.sum_superset_le`) with the sets ranging over the
subsets of a fixed `s : Finset α` (the plaquettes of the torus) instead of a whole finite type.
Paper correspondence: step 3 of the strong-coupling area-law argument.
-/

open Finset

namespace AreaLaw

variable {α : Type*} [DecidableEq α]

/-- `∑_{X ⊆ s, Y ⊆ X} Z X` -/
def supSumIn (s : Finset α) (Z : Finset α → ℝ) (Y : Finset α) : ℝ :=
  ∑ X ∈ s.powerset with Y ⊆ X, Z X

lemma supSumIn_split (s : Finset α) (Z : Finset α → ℝ) (Y : Finset α) (p : α) :
    supSumIn s Z Y = supSumIn s Z (insert p Y)
      + ∑ X ∈ s.powerset with (Y ⊆ X ∧ p ∉ X), Z X := by
  unfold supSumIn
  rw [← sum_filter_add_sum_filter_not (s.powerset.filter (fun X => Y ⊆ X))
    (fun X => p ∈ X) Z, filter_filter, filter_filter]
  congr 1
  apply sum_congr _ (fun _ _ => rfl)
  ext X
  simp [insert_subset_iff, and_comm]

lemma supSumIn_insert_le (s : Finset α) (Z : Finset α → ℝ) (t : ℝ)
    (hZ : ∀ S ⊆ s, ∀ p ∈ s, p ∉ S → Z (insert p S) ≤ t * Z S)
    (Y : Finset α) (p : α) (hps : p ∈ s) (hp : p ∉ Y) :
    supSumIn s Z (insert p Y) ≤ t * ∑ X ∈ s.powerset with (Y ⊆ X ∧ p ∉ X), Z X := by
  unfold supSumIn
  have hbij : ∑ X ∈ s.powerset with insert p Y ⊆ X, Z X
      = ∑ X ∈ s.powerset with (Y ⊆ X ∧ p ∉ X), Z (insert p X) := by
    apply sum_nbij' (fun X => X.erase p) (fun X => insert p X)
    · intro X hX
      simp only [mem_filter, mem_powerset, insert_subset_iff] at hX ⊢
      refine ⟨(erase_subset p X).trans hX.1, ?_, notMem_erase p X⟩
      intro y hy
      rw [mem_erase]
      refine ⟨?_, hX.2.2 hy⟩
      rintro rfl
      exact hp hy
    · intro X hX
      simp only [mem_filter, mem_powerset, insert_subset_iff] at hX ⊢
      exact ⟨⟨hps, hX.1⟩, mem_insert_self p X, hX.2.1.trans (subset_insert p X)⟩
    · intro X hX
      simp only [mem_filter, mem_powerset, insert_subset_iff] at hX
      exact insert_erase hX.2.1
    · intro X hX
      simp only [mem_filter, mem_powerset] at hX
      exact erase_insert hX.2.2
    · intro X hX
      simp only [mem_filter, mem_powerset, insert_subset_iff] at hX
      rw [insert_erase hX.2.1]
  rw [hbij, mul_sum]
  apply sum_le_sum
  intro X hX
  simp only [mem_filter, mem_powerset] at hX
  exact hZ X hX.1 p hps hX.2.2

/-- **Domination lemma (ambient set `s`).**  If `0 ≤ t` and `Z (S ∪ {p}) ≤ t Z S` for
`S ⊆ s`, `p ∈ s ∖ S`, then for every `Y ⊆ s`,
`∑_{Y ⊆ X ⊆ s} Z X ≤ (t/(1+t))^{|Y|} ∑_{X ⊆ s} Z X`. -/
theorem sum_superset_le_in (s : Finset α) (Z : Finset α → ℝ) (t : ℝ) (ht : 0 ≤ t)
    (hZ : ∀ S ⊆ s, ∀ p ∈ s, p ∉ S → Z (insert p S) ≤ t * Z S) (Y : Finset α) (hY : Y ⊆ s) :
    ∑ X ∈ s.powerset with Y ⊆ X, Z X ≤ (t / (1 + t)) ^ Y.card * ∑ X ∈ s.powerset, Z X := by
  have h1t : 0 < 1 + t := by linarith
  have hq0 : 0 ≤ t / (1 + t) := div_nonneg ht h1t.le
  change supSumIn s Z Y ≤ _
  induction Y using Finset.induction_on with
  | empty => simp [supSumIn]
  | insert p Y hp ih =>
    rw [insert_subset_iff] at hY
    rw [card_insert_of_notMem hp, pow_succ]
    have hsplit := supSumIn_split s Z Y p
    have hle := supSumIn_insert_le s Z t hZ Y p hY.1 hp
    have hkey : supSumIn s Z (insert p Y) ≤ t / (1 + t) * supSumIn s Z Y := by
      rw [div_mul_eq_mul_div, le_div_iff₀ h1t]
      nlinarith
    calc supSumIn s Z (insert p Y) ≤ t / (1 + t) * supSumIn s Z Y := hkey
      _ ≤ t / (1 + t) * ((t / (1 + t)) ^ Y.card * ∑ X ∈ s.powerset, Z X) :=
          mul_le_mul_of_nonneg_left (ih hY.2) hq0
      _ = (t / (1 + t)) ^ Y.card * (t / (1 + t)) * ∑ X ∈ s.powerset, Z X := by ring

/-- Sanity: the weights `t^{|X|}` meet the hypothesis inside any `s`. -/
theorem sanity_in_pow (s : Finset α) (t : ℝ) :
    ∀ S ⊆ s, ∀ p ∈ s, p ∉ S → t ^ (insert p S).card ≤ t * t ^ S.card := by
  intro S _ p _ hp
  rw [card_insert_of_notMem hp, pow_succ, mul_comm]

end AreaLaw

#print axioms AreaLaw.sum_superset_le_in
