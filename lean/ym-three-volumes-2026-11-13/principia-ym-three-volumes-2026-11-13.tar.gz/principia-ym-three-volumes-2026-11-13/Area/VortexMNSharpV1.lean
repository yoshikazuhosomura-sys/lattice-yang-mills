import Area.VortexMNV1

/-!
# Vortex floor on `(ℤ/N)² × (ℤ/M)²` with the sharp local constants `6` and `21`

A link lies in at most `6` plaquettes (`card_rootL_le_six`), a plaquette shares a link with at
most `21` plaquettes, itself included (`card_nbL_le_21`).  Hence, for `β ≥ 0` with `441 q < 1`,
`|Z₀ - Z₁| ≤ N² (441 q)^{M²} / (441 (1 - 441 q)) · (Z₀ + Z₁)` (`vortex_floor_MN_sharp`).
-/

open Finset MeasureTheory TwistedWilson CoveringInequality AreaLaw

namespace VortexStrongMN

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- the admissible (position, plane) pairs for a link of direction `μ` -/
def okKP (μ : Fin 4) (kP : Fin 4 × Plane) : Prop :=
  ((kP.1 = 0 ∨ kP.1 = 2) ∧ kP.2.1.1 = μ) ∨ ((kP.1 = 1 ∨ kP.1 = 3) ∧ kP.2.1.2 = μ)

instance (μ : Fin 4) : DecidablePred (okKP μ) := fun kP => by unfold okKP; infer_instance

theorem card_okKP (μ : Fin 4) : (univ.filter (okKP μ)).card = 6 := by
  revert μ; decide

theorem card_rootL_le_six (e : Link N M) :
    (univ.filter (fun B => e ∈ links N M B)).card ≤ 6 := by
  have hsub : univ.filter (fun B => e ∈ links N M B)
      ⊆ (univ.filter (okKP e.2)).image (placeL N M e) := by
    intro B hB
    simp only [mem_filter, mem_univ, true_and, links, mem_insert, mem_singleton] at hB
    rw [mem_image]
    rcases hB with h | h | h | h <;> subst h
    · exact ⟨(0, B.2), mem_filter.mpr ⟨mem_univ _, Or.inl ⟨Or.inl rfl, rfl⟩⟩, by simp [placeL, l1]⟩
    · exact ⟨(1, B.2), mem_filter.mpr ⟨mem_univ _, Or.inr ⟨Or.inl rfl, rfl⟩⟩, by simp [placeL, l2]⟩
    · exact ⟨(2, B.2), mem_filter.mpr ⟨mem_univ _, Or.inl ⟨Or.inr rfl, rfl⟩⟩, by simp [placeL, l3]⟩
    · exact ⟨(3, B.2), mem_filter.mpr ⟨mem_univ _, Or.inr ⟨Or.inr rfl, rfl⟩⟩, by simp [placeL, l4]⟩
  calc (univ.filter (fun B => e ∈ links N M B)).card
      ≤ ((univ.filter (okKP e.2)).image (placeL N M e)).card := card_le_card hsub
    _ ≤ (univ.filter (okKP e.2)).card := card_image_le
    _ = 6 := card_okKP e.2

theorem card_nbL_le_21 (B : Plaq N M) : (nbL N M B).card ≤ 21 := by
  have hsub : nbL N M B ⊆ insert B ((links N M B).biUnion
      (fun e => (univ.filter (fun B' => e ∈ links N M B')).erase B)) := by
    intro B' hB'
    simp only [nbL, mem_filter, mem_univ, true_and] at hB'
    obtain ⟨e, he, he'⟩ := hB'
    rw [mem_insert]
    by_cases hBB : B' = B
    · exact Or.inl hBB
    · right
      rw [mem_biUnion]
      exact ⟨e, he, mem_erase.mpr ⟨hBB, by simp [he']⟩⟩
  have hmem : ∀ e ∈ links N M B, B ∈ univ.filter (fun B' => e ∈ links N M B') := fun e he => by
    simp [he]
  calc (nbL N M B).card
      ≤ (insert B ((links N M B).biUnion
          (fun e => (univ.filter (fun B' => e ∈ links N M B')).erase B))).card := card_le_card hsub
    _ ≤ ((links N M B).biUnion
          (fun e => (univ.filter (fun B' => e ∈ links N M B')).erase B)).card + 1 :=
        card_insert_le _ _
    _ ≤ (∑ e ∈ links N M B, ((univ.filter (fun B' => e ∈ links N M B')).erase B).card) + 1 := by
        gcongr; exact card_biUnion_le
    _ ≤ (∑ _e ∈ links N M B, 5) + 1 := by
        gcongr with e he
        rw [card_erase_of_mem (hmem e he)]
        have := card_rootL_le_six N M e
        omega
    _ = (links N M B).card * 5 + 1 := by rw [sum_const, smul_eq_mul]
    _ ≤ 4 * 5 + 1 := by gcongr; exact card_links_le N M B
    _ = 21 := by norm_num

open Classical in
theorem sum_minBad_le_sharp (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minBad N M, x ^ Y.card
      ≤ (N * N : ℕ) * ∑ n ∈ Ico (M * M) ((univ : Finset (Plaq N M)).card + 1),
          (441 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minBad N M with hF
  set A := M * M with hA
  set K := (univ : Finset (Plaq N M)).card with hK
  have hA1 : 1 ≤ A := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne M) (NeZero.ne M))
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ twistSetMN N M, (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨B, hB, hB2, hB1⟩ := bad_meets N M Y (minBad_mem N M Y hY).1 0
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [twistSetMN, hB2, hB1], hB⟩)
      _ = ∑ r ∈ twistSetMN N M, ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  have h2 : ∀ r, ∑ Y ∈ F with r ∈ Y, x ^ Y.card
      ≤ ∑ n ∈ Ico A (K + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
    intro r
    have hmaps : ∀ Y ∈ F.filter (fun Y => r ∈ Y), Y.card ∈ Ico A (K + 1) := by
      intro Y hY
      have hYF := (mem_filter.mp hY).1
      rw [mem_Ico]
      exact ⟨card_bad_ge N M Y (minBad_mem N M Y hYF).1,
        Nat.lt_succ_of_le (card_le_card (subset_univ Y))⟩
    rw [← sum_fiberwise_of_maps_to hmaps]
    apply sum_le_sum
    intro n hn
    have hnA : A ≤ n := (mem_Ico.mp hn).1
    have hcongr : ∑ Y ∈ F.filter (fun Y => r ∈ Y) with Y.card = n, x ^ Y.card
        = ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)).card * x ^ n := by
      rw [sum_congr rfl (fun Y hY => by rw [(mem_filter.mp hY).2]), sum_const, nsmul_eq_mul]
    rw [hcongr]
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hx _)
    have hcount := card_conn_le (nbL N M) (nbL_symm N M) 21 (card_nbL_le_21 N M) r n (by omega)
      ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)) (by
        intro Y hY
        rw [mem_filter, mem_filter] at hY
        exact ⟨hY.1.2, hY.2, minBad_conn N M Y hY.1.1⟩)
    have h21 : (21 : ℕ) ^ (2 * (n - 1)) = 441 ^ (n - 1) := by
      rw [pow_mul]; norm_num
    rw [h21] at hcount
    exact_mod_cast hcount
  have hsum0 : 0 ≤ ∑ n ∈ Ico A (K + 1), (441 : ℝ) ^ (n - 1) * x ^ n :=
    sum_nonneg fun n _ => mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _)
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ twistSetMN N M, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ twistSetMN N M, ∑ n ∈ Ico A (K + 1), (441 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => h2 r
    _ = (twistSetMN N M).card * ∑ n ∈ Ico A (K + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
        rw [sum_const, nsmul_eq_mul]
    _ ≤ (N * N : ℕ) * ∑ n ∈ Ico A (K + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ hsum0
        exact_mod_cast card_twistSetMN_le N M

/-- **Vortex floor on `(ℤ/N)² × (ℤ/M)²`, sharp constants.**  For `β ≥ 0` with
`441 (1 - e^{-2β}) < 1` and every background `n₁₂`,
`|Z₀ - Z₁| ≤ N² (441 q)^{M²} / (441 (1 - 441 q)) · (Z₀ + Z₁)`, `Z_k = ZW β n₁₂ k`. -/
theorem vortex_floor_MN_sharp (β : ℝ) (hβ : 0 ≤ β) (hK : 441 * (1 - Real.exp (-2 * β)) < 1)
    (n12 : Bool) :
    |ZW N M β n12 false - ZW N M β n12 true|
      ≤ (N * N : ℕ) * ((441 * (1 - Real.exp (-2 * β))) ^ (M * M)
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β)))))
          * (ZW N M β n12 false + ZW N M β n12 true) := by
  classical
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hA1 : 1 ≤ M * M := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne M) (NeZero.ne M))
  have hZ0 : 0 ≤ ZW N M β n12 false := integral_nonneg fun _ => (Real.exp_pos _).le
  have hZ1 : 0 ≤ ZW N M β n12 true := integral_nonneg fun _ => (Real.exp_pos _).le
  refine (abs_ZW_sub_le N M β hβ n12).trans (mul_le_mul_of_nonneg_right ?_ (by linarith))
  refine (sum_minBad_le_sharp N M _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact tail_le_K' 441 (by norm_num) _ _ hA1 _ hq0 hK

/-- Sanity: `β = 1/1000` is in the window. -/
theorem sanity_window_MN_sharp :
    (0 : ℝ) ≤ 1 / 1000 ∧ 441 * (1 - Real.exp (-2 * (1 / 1000 : ℝ))) < 1 := by
  refine ⟨by norm_num, ?_⟩
  have h := Real.add_one_le_exp (-2 * (1 / 1000 : ℝ))
  nlinarith

end VortexStrongMN

#print axioms VortexStrongMN.card_rootL_le_six
#print axioms VortexStrongMN.card_nbL_le_21
#print axioms VortexStrongMN.vortex_floor_MN_sharp
#print axioms VortexStrongMN.sanity_window_MN_sharp
