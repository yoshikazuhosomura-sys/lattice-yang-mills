import Area.WordBoundV1

/-!
# Area lower bound for plaquette sets spanning a rectangular loop (mod 2)

Paper correspondence: step 6 of the strong-coupling area-law argument.
The loop is the boundary of the `R × T` rectangle in the `(0,1)` plane with corner at the
origin of `(ℤ/N)⁴`.  For a column `a < R` and a row `y`, the cochain `rowT a y` (the
direction-0 links at `x₀ = a`, `x₁ = y`, any `x₂, x₃`) pairs with a plaquette boundary only
for the `(0,1)` plaquettes at `x₀ = a`, `x₁ ∈ {y-1, y}`, and pairs with the loop as
`[y = 0] + [y = T]`.  Hence the mod-2 count of the `(0,1)` plaquettes of a spanning
representation at `(a, y)` changes exactly at `y = 0` and `y = T`: every column carries at
least `min(T, N - T)` of them.  Conclusion: every set spanning the loop has at least
`R · min(T, N - T)` plaquettes.
-/

open Finset TorusRP

namespace AreaLaw

section Lower

variable (N : ℕ) [NeZero N]

/-- pairing of a cochain with the mod-2 content of a word = sum along the word -/
theorem pair_wordBd (T : Lk N → ZMod 2) (w : Word N) :
    ∑ e, T e * wordBd N w e = (w.map (fun s => T s.1)).sum := by
  induction w with
  | nil => simp [wordBd]
  | cons s w ih => rw [pair_wordBd_cons, ih, List.map_cons, List.sum_cons]

/-- the direction-0 links at `x₀ = a`, `x₁ = y` (all `x₂, x₃`) -/
def rowT (a y : ZMod N) : Lk N → ZMod 2 :=
  fun ℓ => if ℓ.2 = 0 ∧ ℓ.1 0 = a ∧ ℓ.1 1 = y then 1 else 0

/-- the `(0,1)` plaquettes at `x₀ = a`, `x₁ = y` -/
def InQ (a y : ZMod N) (p : Lk N × Fin 4) : Prop :=
  p.1.2 = 0 ∧ p.2 = 1 ∧ p.1.1 0 = a ∧ p.1.1 1 = y

instance (a y : ZMod N) : DecidablePred (InQ N a y) := fun p => by
  unfold InQ; infer_instance

lemma zmod2_add_self (z : ZMod 2) : z + z = 0 := by
  revert z; decide

/-- **Plaquette pairing.**  For `p ∈ plaqs N`,
`⟨rowT a y, ∂p⟩ = [p ∈ Q(a,y)] + [p ∈ Q(a,y-1)]`. -/
theorem pair_rowT_plaq (a y : ZMod N) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ∑ e, rowT N a y e * plaqBd N p e
      = (if InQ N a y p then 1 else 0) + (if InQ N a (y - 1) p then 1 else 0) := by
  have hlt : p.1.2 < p.2 := (Finset.mem_filter.mp hp).2
  unfold plaqBd
  rw [pair_wordBd]
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  simp only at hlt
  simp only [plaqWord, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero,
    rowT, InQ]
  fin_cases μ <;> fin_cases ν <;> simp_all [ev, zmod2_add_self] <;> split_ifs <;>
    simp_all [eq_comm]

/-- the site `(i, j, 0, 0)` -/
def pt (i j : ℕ) : Site N := ![(i : ZMod N), (j : ZMod N), 0, 0]

/-- the boundary of the `R × T` rectangle in the `(0,1)` plane with corner at the origin, as a
closed link path: bottom (forwards in `x₀`), right side (forwards in `x₁`), top (backwards),
left side (backwards). -/
def rectWord (R T : ℕ) : Word N :=
  (List.range R).map (fun i => ((pt N i 0, (0 : Fin 4)), true)) ++
  (List.range T).map (fun j => ((pt N R j, (1 : Fin 4)), true)) ++
  (List.range R).reverse.map (fun i => ((pt N i T, (0 : Fin 4)), false)) ++
  (List.range T).reverse.map (fun j => ((pt N 0 j, (1 : Fin 4)), false))

lemma natCast_inj_lt {i j : ℕ} (hi : i < N) (hj : j < N) :
    (i : ZMod N) = (j : ZMod N) ↔ i = j := by
  rw [ZMod.natCast_eq_natCast_iff', Nat.mod_eq_of_lt hi, Nat.mod_eq_of_lt hj]

lemma count_range (a' : ℕ) (ha : a' < N) (v : ZMod 2) :
    ∀ R, R ≤ N → ((List.range R).map
      (fun i : ℕ => if (i : ZMod N) = (a' : ZMod N) then v else 0)).sum = if a' < R then v else 0 := by
  intro R
  induction R with
  | zero => intro _; simp
  | succ R ih =>
    intro hR
    rw [List.range_succ, List.map_append, List.sum_append, ih (by omega)]
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero]
    simp only [natCast_inj_lt N (show R < N by omega) ha]
    by_cases h1 : a' < R
    · rw [if_pos h1, if_neg (by omega), if_pos (by omega), add_zero]
    · by_cases h2 : R = a'
      · rw [if_neg h1, if_pos h2, if_pos (by omega), zero_add]
      · rw [if_neg h1, if_neg h2, if_neg (by omega), add_zero]

lemma pt_apply0 (i j : ℕ) : pt N i j 0 = (i : ZMod N) := rfl
lemma pt_apply1 (i j : ℕ) : pt N i j 1 = (j : ZMod N) := rfl

/-- **Loop pairing.**  For a column `a' < R ≤ N`,
`⟨rowT a' y, ∂(rectangle)⟩ = [y = 0] + [y = T]`. -/
theorem pair_rowT_rect (R T a' : ℕ) (hR : R ≤ N) (ha : a' < R) (y : ZMod N) :
    ∑ e, rowT N (a' : ZMod N) y e * wordBd N (rectWord N R T) e
      = (if y = 0 then 1 else 0) + (if y = (T : ZMod N) then 1 else 0) := by
  rw [pair_wordBd]
  simp only [rectWord, List.map_append, List.sum_append, List.map_map, List.map_reverse,
    List.sum_reverse, Function.comp_def, rowT, pt_apply0, pt_apply1]
  have h10 : (1 : Fin 4) ≠ 0 := by decide
  simp only [h10, false_and, if_false, true_and]
  simp only [List.map_const', List.sum_replicate, smul_zero, add_zero]
  have hb : ∀ y' : ZMod N, ((List.range R).map
      (fun i : ℕ => if (i : ZMod N) = (a' : ZMod N) ∧ y' = y then (1 : ZMod 2) else 0)).sum
      = if y' = y then 1 else 0 := by
    intro y'
    by_cases hy : y' = y
    · simp only [hy, and_true]
      rw [count_range N a' (by omega) 1 R hR, if_pos ha]; simp
    · simp [hy]
  have e1 := hb 0
  have e2 := hb (T : ZMod N)
  simp only [Nat.cast_zero] at e1 ⊢
  rw [e1, e2]
  by_cases h0 : y = 0 <;> by_cases hT : y = (T : ZMod N) <;> simp [h0, hT, eq_comm]

/-- a spanning vector is a `ZMod 2`-combination of the boundaries of the plaquettes of `X` -/
theorem exists_rep (c : Lk N → ZMod 2) (X : Finset (Lk N × Fin 4)) (h : SpansC N c X) :
    ∃ f : Lk N × Fin 4 → ZMod 2, c = ∑ p ∈ X, f p • plaqBd N p := by
  classical
  unfold SpansC at h
  induction h using Submodule.span_induction with
  | mem x hx =>
    obtain ⟨p, hp, rfl⟩ := hx
    refine ⟨fun q => if q = p then 1 else 0, ?_⟩
    simp only [ite_smul, one_smul, zero_smul]
    rw [sum_ite_eq' X p, if_pos (Finset.mem_coe.mp hp)]
  | zero => exact ⟨0, by simp⟩
  | add x y _ _ hx hy =>
    obtain ⟨f, rfl⟩ := hx
    obtain ⟨g, rfl⟩ := hy
    exact ⟨f + g, by simp [add_smul, sum_add_distrib]⟩
  | smul a x _ hx =>
    obtain ⟨f, rfl⟩ := hx
    exact ⟨fun p => a * f p, by simp [smul_sum, mul_smul]⟩

/-- the mod-2 count of the `(0,1)` plaquettes at `(a, y)` in the representation `f` -/
def nRow (f : Lk N × Fin 4 → ZMod 2) (X : Finset (Lk N × Fin 4)) (a y : ZMod N) : ZMod 2 :=
  ∑ p ∈ X, f p * (if InQ N a y p then 1 else 0)

theorem nRow_rel (R T a' : ℕ) (hR : R ≤ N) (ha : a' < R) (X : Finset (Lk N × Fin 4))
    (hX : X ⊆ plaqs N) (f : Lk N × Fin 4 → ZMod 2)
    (hc : wordBd N (rectWord N R T) = ∑ p ∈ X, f p • plaqBd N p) (y : ZMod N) :
    nRow N f X a' y + nRow N f X a' (y - 1)
      = (if y = 0 then 1 else 0) + (if y = (T : ZMod N) then 1 else 0) := by
  rw [← pair_rowT_rect N R T a' hR ha y, hc]
  have hlin : ∑ e, rowT N a' y e * (∑ p ∈ X, f p • plaqBd N p) e
      = ∑ p ∈ X, f p * ∑ e, rowT N a' y e * plaqBd N p e := by
    simp only [Finset.sum_apply, Pi.smul_apply, smul_eq_mul, mul_sum]
    rw [sum_comm]
    apply sum_congr rfl
    intro p _
    apply sum_congr rfl
    intro e _
    ring
  rw [hlin, sum_congr rfl (fun p hp => by rw [pair_rowT_plaq N _ _ p (hX hp)])]
  simp only [nRow, mul_add, sum_add_distrib]

lemma zmod2_solve : ∀ a b c : ZMod 2, a + b = c → a = c + b := by decide

theorem nRow_low (R T a' : ℕ) (hR : R ≤ N) (ha : a' < R) (hTN : T < N)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (f : Lk N × Fin 4 → ZMod 2)
    (hc : wordBd N (rectWord N R T) = ∑ p ∈ X, f p • plaqBd N p) :
    ∀ j : ℕ, j < T → nRow N f X a' (j : ZMod N) = nRow N f X a' 0 := by
  intro j
  induction j with
  | zero => intro _; simp
  | succ j ih =>
    intro hj
    have h := nRow_rel N R T a' hR ha X hX f hc ((j + 1 : ℕ) : ZMod N)
    have hm : ((j + 1 : ℕ) : ZMod N) - 1 = (j : ZMod N) := by push_cast; ring
    have h0 : ((j + 1 : ℕ) : ZMod N) ≠ 0 := by
      rw [← Nat.cast_zero, Ne, natCast_inj_lt N (by omega) (by omega)]; omega
    have hT : ((j + 1 : ℕ) : ZMod N) ≠ (T : ZMod N) := by
      rw [Ne, natCast_inj_lt N (by omega) (by omega)]; omega
    rw [hm, if_neg h0, if_neg hT, add_zero] at h
    rw [zmod2_solve _ _ _ h, zero_add, ih (by omega)]

theorem nRow_high (R T a' : ℕ) (hR : R ≤ N) (ha : a' < R) (hT0 : 0 < T) (hTN : T < N)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (f : Lk N × Fin 4 → ZMod 2)
    (hc : wordBd N (rectWord N R T) = ∑ p ∈ X, f p • plaqBd N p) :
    ∀ k : ℕ, T + k < N → nRow N f X a' ((T + k : ℕ) : ZMod N) = nRow N f X a' 0 + 1 := by
  intro k
  induction k with
  | zero =>
    intro _
    have h := nRow_rel N R T a' hR ha X hX f hc ((T : ℕ) : ZMod N)
    have hm : ((T : ℕ) : ZMod N) - 1 = ((T - 1 : ℕ) : ZMod N) := by
      rw [Nat.cast_sub (by omega)]; push_cast; ring
    have h0 : ((T : ℕ) : ZMod N) ≠ 0 := by
      rw [← Nat.cast_zero, Ne, natCast_inj_lt N (by omega) (by omega)]; omega
    rw [hm, if_neg h0, if_pos rfl, zero_add,
      nRow_low N R T a' hR ha hTN X hX f hc (T - 1) (by omega)] at h
    simp only [add_zero]
    rw [zmod2_solve _ _ _ h, add_comm]
  | succ k ih =>
    intro hk
    have h := nRow_rel N R T a' hR ha X hX f hc ((T + (k + 1) : ℕ) : ZMod N)
    have hm : ((T + (k + 1) : ℕ) : ZMod N) - 1 = ((T + k : ℕ) : ZMod N) := by push_cast; ring
    have h0 : ((T + (k + 1) : ℕ) : ZMod N) ≠ 0 := by
      rw [← Nat.cast_zero, Ne, natCast_inj_lt N (by omega) (by omega)]; omega
    have hT : ((T + (k + 1) : ℕ) : ZMod N) ≠ (T : ZMod N) := by
      rw [Ne, natCast_inj_lt N (by omega) (by omega)]; omega
    rw [hm, if_neg h0, if_neg hT, add_zero, ih (by omega)] at h
    rw [zmod2_solve _ _ _ h, zero_add]

theorem exists_of_nRow_ne (f : Lk N × Fin 4 → ZMod 2) (X : Finset (Lk N × Fin 4)) (a y : ZMod N)
    (h : nRow N f X a y ≠ 0) : ∃ p ∈ X, InQ N a y p := by
  by_contra hne
  push Not at hne
  apply h
  apply sum_eq_zero
  intro p hp
  rw [if_neg (hne p hp), mul_zero]

/-- every column `a' < R` carries at least `min(T, N - T)` rows met by `X` -/
theorem col_count (R T a' : ℕ) (hR : R ≤ N) (ha : a' < R) (hT0 : 0 < T) (hTN : T < N)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (f : Lk N × Fin 4 → ZMod 2)
    (hc : wordBd N (rectWord N R T) = ∑ p ∈ X, f p • plaqBd N p) :
    min T (N - T) ≤ ((range N).filter (fun j : ℕ => ∃ p ∈ X, InQ N (a' : ZMod N) (j : ZMod N) p)).card := by
  rcases zmod2_cases (nRow N f X a' 0) with h0 | h0
  · refine (min_le_right _ _).trans ?_
    have hsub : Ico T N ⊆ (range N).filter (fun j : ℕ => ∃ p ∈ X, InQ N (a' : ZMod N) (j : ZMod N) p) := by
      intro j hj
      rw [mem_Ico] at hj
      rw [mem_filter, mem_range]
      refine ⟨hj.2, exists_of_nRow_ne N f X _ _ ?_⟩
      have := nRow_high N R T a' hR ha hT0 hTN X hX f hc (j - T) (by omega)
      rw [show T + (j - T) = j by omega, h0, zero_add] at this
      rw [this]; exact one_ne_zero
    simpa using card_le_card hsub
  · refine (min_le_left _ _).trans ?_
    have hsub : range T ⊆ (range N).filter (fun j : ℕ => ∃ p ∈ X, InQ N (a' : ZMod N) (j : ZMod N) p) := by
      intro j hj
      rw [mem_range] at hj
      rw [mem_filter, mem_range]
      refine ⟨by omega, exists_of_nRow_ne N f X _ _ ?_⟩
      rw [nRow_low N R T a' hR ha hTN X hX f hc j hj, h0]; exact one_ne_zero
    simpa using card_le_card hsub

/-- **Area lower bound.**  For `R ≤ N` and `0 < T < N`, every set of plaquettes whose mod-2
boundaries span the boundary of the `R × T` rectangle has at least `R · min(T, N - T)`
plaquettes (`R · T` when `2T ≤ N`). -/
theorem card_ge_of_spans_rect (R T : ℕ) (hR : R ≤ N) (hT0 : 0 < T) (hTN : T < N)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N)
    (hs : SpansC N (wordBd N (rectWord N R T)) X) : R * min T (N - T) ≤ X.card := by
  classical
  obtain ⟨f, hf⟩ := exists_rep N _ X hs
  let P : ℕ × ℕ → Prop := fun ij => ∃ p ∈ X, InQ N (ij.1 : ZMod N) (ij.2 : ZMod N) p
  let I := (range R ×ˢ range N).filter P
  have h1 : R * min T (N - T) ≤ I.card := by
    have hI : I.card = ∑ a' ∈ range R,
        ((range N).filter (fun j : ℕ => ∃ p ∈ X, InQ N (a' : ZMod N) (j : ZMod N) p)).card := by
      simp only [I, card_filter, sum_product]
      apply sum_congr rfl
      intro x _
      apply sum_congr rfl
      intro y _
      exact if_congr Iff.rfl rfl rfl
    rw [hI]
    calc R * min T (N - T) = (range R).card • min T (N - T) := by simp
      _ ≤ _ := card_nsmul_le_sum _ _ _ (fun a' ha' =>
          col_count N R T a' hR (mem_range.mp ha') hT0 hTN X hX f hf)
  have h2 : I.card ≤ X.card := by
    let g : ℕ × ℕ → Lk N × Fin 4 := fun ij =>
      if h : P ij then Classical.choose h else ((0, 0), 0)
    have hg : ∀ ij ∈ I, g ij ∈ X ∧ InQ N (ij.1 : ZMod N) (ij.2 : ZMod N) (g ij) := by
      intro ij hij
      have hP : P ij := (mem_filter.mp hij).2
      simp only [g, dif_pos hP]
      exact Classical.choose_spec hP
    apply card_le_card_of_injOn g
    · intro ij hij
      exact (hg ij hij).1
    · intro ij hij kl hkl he
      have h1 := (hg ij hij).2
      have h2 := (hg kl hkl).2
      rw [he] at h1
      have hij' := mem_product.mp (mem_filter.mp hij).1
      have hkl' := mem_product.mp (mem_filter.mp hkl).1
      simp only [mem_range] at hij' hkl'
      have ea : (ij.1 : ZMod N) = (kl.1 : ZMod N) := h1.2.2.1.symm.trans h2.2.2.1
      have eb : (ij.2 : ZMod N) = (kl.2 : ZMod N) := h1.2.2.2.symm.trans h2.2.2.2
      rw [natCast_inj_lt N (by omega) (by omega)] at ea
      rw [natCast_inj_lt N (by omega) (by omega)] at eb
      exact Prod.ext ea eb
  exact h1.trans h2

open Classical in
/-- **Area law at strong coupling, finite-volume form.**  For `β ≥ 0`, `R ≤ N`, `0 < T < N`:
`|⟨Re W(∂(R×T))⟩_β| ≤ #(minimal spanning sets) · (1 - e^{-2β})^{R · min(T, N-T)}`. -/
theorem abs_rectExpect_le (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR : R ≤ N) (hT0 : 0 < T)
    (hTN : T < N) :
    |wordExpect N β (rectWord N R T)|
      ≤ (minSpanC N (wordBd N (rectWord N R T))).card
          * (1 - Real.exp (-2 * β)) ^ (R * min T (N - T)) :=
  abs_wordExpect_le_of_card N β hβ (rectWord N R T) (R * min T (N - T))
    (fun Y hY hs => card_ge_of_spans_rect N R T hR hT0 hTN Y hY hs)

/-- Sanity (empty object): for `R ≥ 1`, the empty set does not span the rectangle. -/
theorem sanity_rect_not_empty (R T : ℕ) (hR1 : 1 ≤ R) (hR : R ≤ N) (hT0 : 0 < T) (hTN : T < N) :
    ¬ SpansC N (wordBd N (rectWord N R T)) ∅ := by
  intro hs
  have := card_ge_of_spans_rect N R T hR hT0 hTN ∅ (empty_subset _) hs
  rw [card_empty] at this
  have hpos : 0 < R * min T (N - T) := Nat.mul_pos (by omega) (lt_min hT0 (by omega))
  omega

end Lower

/-- Sanity: the hypotheses of `abs_rectExpect_le` are met, e.g. `N = 8`, `R = T = 3`, `β = 1/100`,
where the exponent is `R · min(T, N - T) = 9 = R T`. -/
theorem sanity_rect_hyps : (0 : ℝ) ≤ 1/100 ∧ (3 : ℕ) ≤ 8 ∧ 0 < (3 : ℕ) ∧ (3 : ℕ) < 8 ∧
    3 * min 3 (8 - 3) = 3 * 3 := by
  refine ⟨by norm_num, by norm_num, by norm_num, by norm_num, by norm_num⟩

end AreaLaw

#print axioms AreaLaw.card_ge_of_spans_rect
#print axioms AreaLaw.abs_rectExpect_le
#print axioms AreaLaw.sanity_rect_not_empty
