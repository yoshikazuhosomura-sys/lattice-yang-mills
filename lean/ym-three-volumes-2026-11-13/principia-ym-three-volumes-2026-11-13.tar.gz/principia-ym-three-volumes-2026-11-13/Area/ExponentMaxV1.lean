import Area.SharpConstV1

/-!
# The area-law exponent `max(R·min(T, N-T), T·min(R, N-R))`

Paper correspondence: the area lower bound used row cochains (direction `0` links), which gives
the exponent `R·min(T, N-T)`.  Exchanging the directions `0 ↔ 1` maps the rectangle `R × T` to
a loop whose mod-2 link content is that of the rectangle `T × R` (`wordBd_swap_rect`; only the
order and the orientation of the links change), and the Wilson measure is invariant under the
exchange, so the bound also holds with `T·min(R, N-R)`, hence with the larger of the two.
For `R, T ≤ N/2` both are the area `RT`; for `T > N/2 ≥ R` the exponent is now `RT` as well.
-/

open MeasureTheory Finset TorusRP PeierlsPerm

namespace AreaLaw

variable (N : ℕ) [NeZero N]

theorem wordBd_eq_count (w : Word N) (e : Lk N) :
    wordBd N w e = (((w.map Prod.fst).count e : ℕ) : ZMod 2) := by
  induction w with
  | nil => simp [wordBd]
  | cons s w ih =>
    simp only [wordBd, ih, List.map_cons, List.count_cons]
    by_cases h : s.1 = e
    · simp [h, add_comm]
    · simp [h]

/-- the exchange of the directions `0` and `1` -/
def sw01 : Fin 4 → Fin 4 := Equiv.swap 0 1

theorem sw01_invol : ∀ j, sw01 (sw01 j) = j := fun j => by simp [sw01]

theorem site_sw01 (i j : ℕ) : sitePerm N sw01 (pt N i j) = pt N j i := by
  funext k
  fin_cases k <;> simp [sitePerm, pt, sw01, Equiv.swap_apply_def]

/-- the exchanged rectangle `R × T` has the mod-2 link content of the rectangle `T × R` -/
theorem wordBd_swap_rect (R T : ℕ) :
    wordBd N ((rectWord N R T).map (fun s => (linkPerm N sw01 s.1, s.2)))
      = wordBd N (rectWord N T R) := by
  funext e
  rw [wordBd_eq_count, wordBd_eq_count]
  congr 1
  have h0 : sw01 0 = 1 := by simp [sw01]
  have h1 : sw01 1 = 0 := by simp [sw01]
  simp only [rectWord, List.map_append, List.map_map, Function.comp_def, linkPerm, site_sw01,
    h0, h1, List.count_append, List.map_reverse, List.count_reverse]
  omega

/-- the transposed exponent: `|⟨Re W(∂(R×T))⟩| ≤ 16 (4096 q)^{T·min(R, N-R)} / (4096 (1 - 4096 q))` -/
theorem area_law_wilson_transposed (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (hT : T < N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (T * min R (N - R))
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  rw [← expect_perm N β sw01 sw01_invol (rectWord N R T), ← wordExpect_eq_wilson]
  refine (abs_wordExpect_le N β hβ _).trans ?_
  rw [wordBd_swap_rect]
  refine (sum_minSpan_rect_le N T R hT1 hR1 hT hR _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  exact tail_le _ _ (Nat.mul_le_mul hT1 (le_min hR1 (by omega))) _ hq0 hK

/-- the transposed exponent with the sharp constants -/
theorem area_law_wilson_transposed_sharp (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R)
    (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N) (hK : 441 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 6 * ((441 * (1 - Real.exp (-2 * β))) ^ (T * min R (N - R))
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β))))) := by
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  rw [← expect_perm N β sw01 sw01_invol (rectWord N R T), ← wordExpect_eq_wilson]
  refine (abs_wordExpect_le N β hβ _).trans ?_
  rw [wordBd_swap_rect]
  refine (sum_minSpan_rect_le_sharp N T R hT1 hR1 hT hR _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  exact tail_le_K 441 (by norm_num) _ _ (Nat.mul_le_mul hT1 (le_min hR1 (by omega))) _ hq0 hK

/-- **Area law with the exponent `max(R·min(T,N-T), T·min(R,N-R))`** (sharp constants).
For `β ≥ 0` with `441 (1 - e^{-2β}) < 1`, `1 ≤ R < N`, `1 ≤ T < N`,
`|⟨Re W(∂(R×T))⟩| ≤ 6 (441 q)^{max(R·min(T,N-T), T·min(R,N-R))} / (441 (1 - 441 q))`. -/
theorem area_law_wilson_max_sharp (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R)
    (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N) (hK : 441 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 6 * ((441 * (1 - Real.exp (-2 * β))) ^ (max (R * min T (N - T)) (T * min R (N - R)))
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β))))) := by
  rcases le_total (R * min T (N - T)) (T * min R (N - R)) with h | h
  · rw [max_eq_right h]
    exact area_law_wilson_transposed_sharp N β hβ R T hR1 hT1 hR hT hK
  · rw [max_eq_left h]
    exact area_law_wilson_sharp N β hβ R T hR1 hT1 hR hT hK

/-- Sanity: for `N = 8`, `R = 3`, `T = 6` (`T > N/2`) the new exponent is the area `18`, while
`R·min(T, N-T) = 6`. -/
theorem sanity_max_exponent :
    max (3 * min 6 (8 - 6)) (6 * min 3 (8 - 3)) = 18 ∧ 3 * min 6 (8 - 6) = 6 := by
  decide

/-- Sanity: `wordBd_swap_rect` is not vacuous: for `R = T = 1` the exchanged plaquette loop has
the content of the same plaquette. -/
theorem sanity_swap_square :
    wordBd N ((rectWord N 1 1).map (fun s => (linkPerm N sw01 s.1, s.2)))
      = wordBd N (rectWord N 1 1) :=
  wordBd_swap_rect N 1 1

end AreaLaw

#print axioms AreaLaw.wordBd_swap_rect
#print axioms AreaLaw.area_law_wilson_transposed
#print axioms AreaLaw.area_law_wilson_max_sharp
#print axioms AreaLaw.sanity_max_exponent
