import Area.AreaMainV1
import Lattice.WilsonGapV2
import Infvol.MainV2

/-!
# The area law in the infinite-volume limit (strong coupling)

Paper correspondence: corollary of the finite-volume area law (`area_law_wilson_area`), combined
with the strong-coupling infinite-volume theorem `InfMain2.wilson_infvol_main2` (convergence of
the whole sequence of periodically lifted torus Wilson measures, in the Dobrushin window
`dobConst β < 1`).
(Revision of `InfVolV1`: docstrings aligned with the hypotheses; the check that the rectangle
word of size `1 × 1` is the plaquette word is added as `rectWord_one_one`.)
The rectangle loop is placed in `ℤ⁴` (`zRectWord`), its Wilson loop `zWordHol` is a bounded
continuous function of the link configuration `x : Cfg = ZLk → QBall` depending on finitely
many links, and on the lifted torus configurations it is the torus Wilson loop.  Since the
lifted Wilson measures `liftProb β n` converge weakly to `ν`, the `N`-uniform finite-volume bound
passes to the limit.
-/

open MeasureTheory Filter Topology Finset TorusRP WilsonLimit
open scoped BoundedContinuousFunction

local notation "ℍr" => Quaternion ℝ

namespace AreaLaw

/-- the site `(i, j, 0, 0)` of `ℤ⁴` -/
def zpt (i j : ℕ) : ZSite := ![(i : ℤ), (j : ℤ), 0, 0]

/-- the boundary of the `R × T` rectangle in `ℤ⁴`, as a closed link path -/
def zRectWord (R T : ℕ) : List (ZLk × Bool) :=
  (List.range R).map (fun i => ((zpt i 0, (0 : Fin 4)), true)) ++
  (List.range T).map (fun j => ((zpt R j, (1 : Fin 4)), true)) ++
  (List.range R).reverse.map (fun i => ((zpt i T, (0 : Fin 4)), false)) ++
  (List.range T).reverse.map (fun j => ((zpt 0 j, (1 : Fin 4)), false))

/-- ordered product of the link variables along a word in `ℤ⁴` -/
noncomputable def zWordHol (x : Cfg) : List (ZLk × Bool) → ℍr
  | [] => 1
  | s :: w => (if s.2 then ((x s.1 : QBall) : ℍr) else star ((x s.1 : QBall) : ℍr)) * zWordHol x w

theorem zWordHol_perLift (N : ℕ) [NeZero N] (ω : Lk N → QBall) (w : List (ZLk × Bool)) :
    zWordHol (perLift N ω) w = wordHol N ω (w.map (fun s => (zproj N s.1, s.2))) := by
  induction w with
  | nil => simp [zWordHol, wordHol]
  | cons s w ih => simp only [zWordHol, wordHol, List.map_cons, ih, perLift, Uq]

theorem zproj_zpt (N : ℕ) [NeZero N] (i j : ℕ) (μ : Fin 4) :
    zproj N (zpt i j, μ) = (pt N i j, μ) := by
  refine Prod.ext ?_ rfl
  funext k
  fin_cases k <;> simp [zproj, zpt, pt]

theorem zRect_map (N : ℕ) [NeZero N] (R T : ℕ) :
    (zRectWord R T).map (fun s => (zproj N s.1, s.2)) = rectWord N R T := by
  simp only [zRectWord, rectWord, List.map_append, List.map_map, List.map_reverse,
    Function.comp_def, zproj_zpt]

theorem continuous_zWordHol (w : List (ZLk × Bool)) :
    Continuous (fun x : Cfg => zWordHol x w) := by
  induction w with
  | nil => simp only [zWordHol]; exact continuous_const
  | cons s w ih =>
    simp only [zWordHol]
    have hc : Continuous (fun x : Cfg => ((x s.1 : QBall) : ℍr)) :=
      continuous_subtype_val.comp (continuous_apply s.1)
    split_ifs
    · exact hc.mul ih
    · exact hc.star.mul ih

/-- the rectangle Wilson loop as a bounded continuous function on `Cfg` -/
noncomputable def zLoopFn (R T : ℕ) : Cfg →ᵇ ℝ :=
  BoundedContinuousFunction.mkOfCompact
    ⟨fun x => (zWordHol x (zRectWord R T)).re,
      Quaternion.continuous_re.comp (continuous_zWordHol _)⟩

/-- normalised Wilson integral = ratio of Wilson-measure integrals -/
theorem integral_wilsonProb_ratio (N : ℕ) [NeZero N] (β : ℝ) (g : (Lk N → QBall) → ℝ) :
    ∫ ω, g ω ∂(wilsonProb N β : Measure (Lk N → QBall))
      = (∫ ω, g ω ∂(wilsonMeasure N β)) / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
  rw [wilsonProb_toMeasure, integral_smul_measure, ENNReal.toReal_inv, smul_eq_mul,
    integral_const, smul_eq_mul, mul_one, measureReal_def, div_eq_inv_mul]

/-- The `1 × 1` rectangle word is the plaquette word of the `(0,1)` plaquette at the origin
(the path order and orientation of `rectWord` agree with `plaqWord`). -/
theorem rectWord_one_one (N : ℕ) [NeZero N] :
    rectWord N 1 1 = plaqWord N ((pt N 0 0, 0), 1) := by
  have h1 : pt N 1 0 = pt N 0 0 + ev N 0 := by
    funext k; fin_cases k <;> simp [pt, ev]
  have h2 : pt N 0 1 = pt N 0 0 + ev N 1 := by
    funext k; fin_cases k <;> simp [pt, ev]
  simp [rectWord, plaqWord, h1, h2]

/-- **Area law for the limit of the lifted Wilson measures.**  For `β ≥ 0` with
`4096 (1 - e^{-2β}) < 1`, `R, T ≥ 1`, and a probability measure `ν` such that the whole
sequence `liftProb β n` converges weakly to `ν`,
`|∫ Re W(∂(R×T)) dν| ≤ 16 (4096 q)^{R T} / (4096 (1 - 4096 q))`, `q = 1 - e^{-2β}`. -/
theorem area_law_limit (β : ℝ) (hβ : 0 ≤ β) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1)
    (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (ν : ProbabilityMeasure Cfg)
    (hν : Tendsto (fun n => liftProb β n) atTop (𝓝 ν)) :
    |∫ x, (zWordHol x (zRectWord R T)).re ∂(ν : Measure Cfg)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * T)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have hlim := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hν) (zLoopFn R T)
  simp only [zLoopFn, BoundedContinuousFunction.mkOfCompact_apply, ContinuousMap.coe_mk] at hlim
  apply le_of_tendsto hlim.abs
  filter_upwards [eventually_ge_atTop (R + T)] with n hn
  have hcont : Continuous (fun x : Cfg => (zWordHol x (zRectWord R T)).re) :=
    Quaternion.continuous_re.comp (continuous_zWordHol _)
  rw [integral_lift β n (fun x : Cfg => (zWordHol x (zRectWord R T)).re) hcont]
  simp only [zWordHol_perLift, zRect_map]
  rw [integral_wilsonProb_ratio]
  exact area_law_wilson_area (Nn n) β hβ R T hR1 hT1 (by rw [Nn_eq]; omega)
    (by rw [Nn_eq]; omega) hK

/-- **Area law at strong coupling in infinite volume.**  For `β > 0` with `dobConst β < 1` and
`4096 (1 - e^{-2β}) < 1`, the infinite-volume Wilson measure `ν_β` of
`InfMain2.wilson_infvol_main2` (the weak limit of the whole sequence of lifted torus measures)
satisfies, for every `R, T ≥ 1`,
`|⟨Re W(∂(R×T))⟩_{ν_β}| ≤ 16 (4096 q)^{R T} / (4096 (1 - 4096 q))`. -/
theorem area_law_infvol (β : ℝ) (hβ : 0 < β) (hq : dobConst β < 1)
    (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    ∃ ν : ProbabilityMeasure Cfg, Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      ∀ R T : ℕ, 1 ≤ R → 1 ≤ T →
        |∫ x, (zWordHol x (zRectWord R T)).re ∂(ν : Measure Cfg)|
          ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * T)
              / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  obtain ⟨ν, ⟨hν, -⟩, -⟩ := InfMain2.wilson_infvol_main2 β hβ hq
  exact ⟨ν, hν, fun R T hR1 hT1 => area_law_limit β hβ.le hK R T hR1 hT1 ν hν⟩

/-- Sanity: the two windows intersect: `β = 1/100000` has `β > 0`, `dobConst β < 1` and
`4096 (1 - e^{-2β}) < 1`. -/
theorem sanity_window_infvol :
    (0 : ℝ) < 1 / 100000 ∧ dobConst (1 / 100000) < 1 ∧
      4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ))) < 1 := by
  refine ⟨by norm_num, ?_, (sanity_window).2⟩
  unfold dobConst
  rw [abs_of_pos (by norm_num : (0 : ℝ) < 1 / 100000)]
  have he := Real.exp_bound_div_one_sub_of_interval' (x := 2 * (1 / 100000 : ℝ)) (by norm_num)
    (by norm_num)
  have hpos : 1 ≤ Real.exp (2 * (1 / 100000 : ℝ)) := Real.one_le_exp (by norm_num)
  have hden : 0 < Real.exp (2 * (1 / 100000 : ℝ)) + 1 := by linarith
  rw [mul_div_assoc', div_lt_one hden]
  have : (1 : ℝ) / (1 - 2 * (1 / 100000)) < 1 + 1 / 1000 := by norm_num
  nlinarith

end AreaLaw

#print axioms AreaLaw.area_law_limit
#print axioms AreaLaw.area_law_infvol
#print axioms AreaLaw.sanity_window_infvol
#print axioms AreaLaw.rectWord_one_one
