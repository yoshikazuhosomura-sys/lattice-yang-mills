import Mathlib

/-!
# Positive mixture expansion of the Wilson weight

Paper correspondence: step 1 of the strong-coupling area-law argument.
For `s ∈ ℝ` and `β ∈ ℝ`, `exp (β s) = exp (-β) * (1 + σ)` with
`σ = exp (β (s+1)) - 1`, and `σ ∈ [0, exp (2β) - 1]` when `β ≥ 0`, `s ∈ [-1,1]`.
The product over a finite set of plaquettes expands as a sum over subsets
(`Finset.prod_one_add`), also under an integral.
-/

open Finset MeasureTheory

namespace AreaLaw

/-- The mixture variable `σ = exp(β(s+1)) - 1`. -/
noncomputable def mixVar (β s : ℝ) : ℝ := Real.exp (β * (s + 1)) - 1

/-- `exp(β s) = exp(-β) (1 + σ)`. -/
theorem exp_eq_mix (β s : ℝ) : Real.exp (β * s) = Real.exp (-β) * (1 + mixVar β s) := by
  unfold mixVar
  rw [add_sub_cancel, ← Real.exp_add]
  congr 1; ring

/-- `0 ≤ σ ≤ exp(2β) - 1` for `β ≥ 0` and `-1 ≤ s ≤ 1`. -/
theorem mixVar_mem (β s : ℝ) (hβ : 0 ≤ β) (hs1 : -1 ≤ s) (hs2 : s ≤ 1) :
    0 ≤ mixVar β s ∧ mixVar β s ≤ Real.exp (2 * β) - 1 := by
  unfold mixVar
  constructor
  · have : 0 ≤ β * (s + 1) := mul_nonneg hβ (by linarith)
    have := Real.one_le_exp this
    linarith
  · have : β * (s + 1) ≤ 2 * β := by nlinarith
    have := Real.exp_le_exp.mpr this
    linarith

/-- The finite expansion `∏_p (1 + a_p) = ∑_X ∏_{p ∈ X} a_p` over all subsets `X`. -/
theorem prod_one_add_univ {P : Type*} [Fintype P] (a : P → ℝ) :
    ∏ p, (1 + a p) = ∑ X : Finset P, ∏ p ∈ X, a p := by
  rw [prod_one_add, powerset_univ]

/-- The product of the Wilson weights as a positive mixture:
`∏_p exp(β s_p) = exp(-β |P|) ∑_X ∏_{p∈X} σ_p`. -/
theorem prod_exp_eq_mix {P : Type*} [Fintype P] (β : ℝ) (s : P → ℝ) :
    ∏ p, Real.exp (β * s p)
      = Real.exp (-β) ^ Fintype.card P * ∑ X : Finset P, ∏ p ∈ X, mixVar β (s p) := by
  simp_rw [exp_eq_mix β]
  rw [prod_mul_distrib, prod_const, prod_one_add_univ]
  rfl

/-- The expansion under an integral: for a finite measure-space integrand
`f · ∏_p (1 + a_p)`, with every term `f · ∏_{p∈X} a_p` integrable,
`∫ f ∏_p (1+a_p) = ∑_X ∫ f ∏_{p∈X} a_p`. -/
theorem integral_mul_prod_one_add {Ω P : Type*} [MeasurableSpace Ω] [Fintype P]
    (μ : Measure Ω) (f : Ω → ℝ) (a : P → Ω → ℝ)
    (hint : ∀ X : Finset P, Integrable (fun ω => f ω * ∏ p ∈ X, a p ω) μ) :
    ∫ ω, f ω * ∏ p, (1 + a p ω) ∂μ = ∑ X : Finset P, ∫ ω, f ω * ∏ p ∈ X, a p ω ∂μ := by
  have : (fun ω => f ω * ∏ p, (1 + a p ω)) = fun ω => ∑ X : Finset P, f ω * ∏ p ∈ X, a p ω := by
    funext ω
    rw [prod_one_add_univ (fun p => a p ω), mul_sum]
  rw [this, integral_finsetSum]
  intro X _
  exact hint X

/-- The integrability hypothesis is met by bounded measurable integrands on a finite
measure: if `|f| ≤ 1` and `0 ≤ a_p ≤ t` with all of them measurable, each term is integrable. -/
theorem integrable_term {Ω P : Type*} [MeasurableSpace Ω] [Fintype P]
    (μ : Measure Ω) [IsFiniteMeasure μ] (f : Ω → ℝ) (a : P → Ω → ℝ) (t : ℝ)
    (hf : Measurable f) (ha : ∀ p, Measurable (a p))
    (hf1 : ∀ ω, |f ω| ≤ 1) (ha0 : ∀ p ω, 0 ≤ a p ω) (hat : ∀ p ω, a p ω ≤ t)
    (X : Finset P) : Integrable (fun ω => f ω * ∏ p ∈ X, a p ω) μ := by
  have hmeas : Measurable (fun ω => f ω * ∏ p ∈ X, a p ω) :=
    hf.mul (Finset.measurable_prod X (fun p _ => ha p))
  refine Integrable.of_bound (C := |t| ^ X.card) hmeas.aestronglyMeasurable
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_mul, abs_prod]
  calc |f ω| * ∏ p ∈ X, |a p ω| ≤ 1 * ∏ _p ∈ X, |t| := by
        apply mul_le_mul (hf1 ω) _ (prod_nonneg fun _ _ => abs_nonneg _) zero_le_one
        apply prod_le_prod (fun _ _ => abs_nonneg _)
        intro p _
        rw [abs_of_nonneg (ha0 p ω)]
        exact (hat p ω).trans (le_abs_self t)
    _ = |t| ^ X.card := by rw [one_mul, prod_const]

/-- Sanity: the expansion on a two-point set, `(1+a)(1+b) = 1 + a + b + ab`, is the
familiar one (checked as an instance of `prod_one_add_univ` with explicit values). -/
theorem sanity_two_points :
    ∏ p : Fin 2, (1 + ((![2, 3] : Fin 2 → ℝ) p)) = 12 ∧
    ∑ X : Finset (Fin 2), ∏ p ∈ X, ((![2, 3] : Fin 2 → ℝ) p) = 12 := by
  refine ⟨?_, ?_⟩
  · simp [Fin.prod_univ_two]; norm_num
  · rw [← prod_one_add_univ]; simp [Fin.prod_univ_two]; norm_num

/-- Sanity: the mixture bounds are met (non-vacuously) at `β = 1/100`, `s = 1`,
with `σ > 0`. -/
theorem sanity_mixVar_pos : 0 < mixVar (1/100) 1 := by
  unfold mixVar
  have : (0:ℝ) < 1/100 * (1 + 1) := by norm_num
  have := Real.add_one_lt_exp (ne_of_gt this)
  linarith

end AreaLaw

#print axioms AreaLaw.prod_exp_eq_mix
#print axioms AreaLaw.integral_mul_prod_one_add
#print axioms AreaLaw.integrable_term
#print axioms AreaLaw.sanity_two_points
