import Area.VortexSanityV1
import Area.RectMoveV1

/-!
# Sharper counting constants: `6` plaquettes through a link, `21` neighbours of a plaquette

Paper correspondence: step 7 (counting) of the strong-coupling area law and of the vortex floor,
with the actual local constants of `(ℤ/N)⁴`:
* a link lies in at most `6` plaquettes of `plaqs N` (`card_rootP_le`; `2` for each of the three
  other directions);
* a plaquette of `plaqs N` shares a link with at most `21` plaquettes of `plaqs N`, itself
  included (`card_nbQ_le`; `1 + 4·5`).
The connected-set count becomes `21^{2(n-1)} = 441^{n-1}`, the window `441 q < 1`
(`β < 1.13·10⁻³`), and
* `area_law_wilson_sharp`: `|⟨Re W(∂(R×T))⟩| ≤ 6 (441 q)^{R·min(T,N-T)} / (441 (1 - 441 q))`,
  for any corner and any plane (`area_law_wilson_general_sharp`);
* `vortex_floor_sharp`: `|Z₀ - Z₁| ≤ N² (441 q)^{N²} / (441 (1 - 441 q)) · (Z₀ + Z₁)`.
-/

open MeasureTheory Finset TorusRP OSGap

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-- the admissible (position, other direction) pairs for a link of direction `μ` -/
def okKD (μ : Fin 4) (kd : Fin 4 × Fin 4) : Prop :=
  (kd.1 = 0 ∧ μ < kd.2) ∨ (kd.1 = 1 ∧ kd.2 < μ) ∨ (kd.1 = 2 ∧ μ < kd.2) ∨ (kd.1 = 3 ∧ kd.2 < μ)

instance (μ : Fin 4) : DecidablePred (okKD μ) := fun kd => by unfold okKD; infer_instance

theorem card_okKD (μ : Fin 4) : (univ.filter (okKD μ)).card = 6 := by
  revert μ; decide

/-- plaquettes of `plaqs N` containing a link `ℓ` -/
def rootP (ℓ : Lk N) : Finset (Lk N × Fin 4) := (rootSet N ℓ).filter (· ∈ plaqs N)

theorem card_rootP_le (ℓ : Lk N) : (rootP N ℓ).card ≤ 6 := by
  have hsub : rootP N ℓ ⊆ (univ.filter (okKD ℓ.2)).image (placeAt N ℓ) := by
    intro p hp
    simp only [rootP, rootSet, mem_filter, mem_univ, true_and, plaqLinks, plaqWord, List.map_cons,
      List.map_nil, List.mem_toFinset, List.mem_cons, List.not_mem_nil, or_false] at hp
    obtain ⟨hl, hpl⟩ := hp
    have hlt : p.1.2 < p.2 := (Finset.mem_filter.mp hpl).2
    rw [mem_image]
    obtain ⟨⟨x, μ⟩, ν⟩ := p
    simp only at hlt
    rcases hl with h | h | h | h <;> subst h
    · exact ⟨(0, ν), by simp [okKD, hlt], by simp [placeAt]⟩
    · exact ⟨(1, μ), by simp [okKD, hlt], by simp [placeAt]⟩
    · exact ⟨(2, ν), by simp [okKD, hlt], by simp [placeAt]⟩
    · exact ⟨(3, μ), by simp [okKD, hlt], by simp [placeAt]⟩
  calc (rootP N ℓ).card ≤ ((univ.filter (okKD ℓ.2)).image (placeAt N ℓ)).card := card_le_card hsub
    _ ≤ (univ.filter (okKD ℓ.2)).card := card_image_le
    _ = 6 := card_okKD ℓ.2

/-- neighbours inside `plaqs N` (empty outside `plaqs N`) -/
def nbQ (p : Lk N × Fin 4) : Finset (Lk N × Fin 4) :=
  if p ∈ plaqs N then (nbP N p).filter (· ∈ plaqs N) else ∅

theorem mem_nbQ (a b : Lk N × Fin 4) : b ∈ nbQ N a ↔ a ∈ plaqs N ∧ b ∈ plaqs N ∧ b ∈ nbP N a := by
  unfold nbQ
  split_ifs with h
  · rw [mem_filter]; tauto
  · simp [h]

theorem nbQ_symm (a b : Lk N × Fin 4) : b ∈ nbQ N a ↔ a ∈ nbQ N b := by
  rw [mem_nbQ, mem_nbQ, nbP_symm]; tauto

theorem card_nbQ_le (p : Lk N × Fin 4) : (nbQ N p).card ≤ 21 := by
  unfold nbQ
  split_ifs with hp
  · have hsub : (nbP N p).filter (· ∈ plaqs N)
        ⊆ insert p ((plaqLinks N p).biUnion (fun e => (rootP N e).erase p)) := by
      intro p' hp'
      simp only [nbP, mem_filter, mem_univ, true_and] at hp'
      obtain ⟨⟨e, he, he'⟩, hp'P⟩ := hp'
      rw [mem_insert]
      by_cases hpp : p' = p
      · exact Or.inl hpp
      · right
        rw [mem_biUnion]
        exact ⟨e, he, mem_erase.mpr ⟨hpp, by simp [rootP, rootSet, he', hp'P]⟩⟩
    have hmem : ∀ e ∈ plaqLinks N p, p ∈ rootP N e := fun e he => by
      simp [rootP, rootSet, he, hp]
    calc ((nbP N p).filter (· ∈ plaqs N)).card
        ≤ (insert p ((plaqLinks N p).biUnion (fun e => (rootP N e).erase p))).card :=
          card_le_card hsub
      _ ≤ ((plaqLinks N p).biUnion (fun e => (rootP N e).erase p)).card + 1 := card_insert_le _ _
      _ ≤ (∑ e ∈ plaqLinks N p, ((rootP N e).erase p).card) + 1 := by
          gcongr; exact card_biUnion_le
      _ ≤ (∑ _e ∈ plaqLinks N p, 5) + 1 := by
          gcongr with e he
          rw [card_erase_of_mem (hmem e he)]
          have := card_rootP_le N e
          omega
      _ = (plaqLinks N p).card * 5 + 1 := by rw [sum_const, smul_eq_mul]
      _ ≤ 4 * 5 + 1 := by gcongr; exact card_plaqLinks_le N p
      _ = 21 := by norm_num
  · simp

theorem cutConn_nbQ (Y : Finset (Lk N × Fin 4)) (hY : Y ⊆ plaqs N) (h : CutConn (nbP N) Y) :
    CutConn (nbQ N) Y := by
  intro S hSY hSne hSneq
  obtain ⟨a, ha, b, hb, hab⟩ := h S hSY hSne hSneq
  refine ⟨a, ha, b, hb, (mem_nbQ N a b).mpr ⟨hY (hSY ha), hY (mem_sdiff.mp hb).1, hab⟩⟩

/-- the geometric tail with a general constant `K > 0` -/
theorem tail_le_K (K : ℝ) (hK0 : 0 < K) (A M : ℕ) (hA : 1 ≤ A) (x : ℝ) (hx : 0 ≤ x)
    (hKx : K * x < 1) :
    ∑ n ∈ Ico A (M + 1), K ^ (n - 1) * x ^ n ≤ (K * x) ^ A / (K * (1 - K * x)) := by
  have hterm : ∀ n ∈ Ico A (M + 1), K ^ (n - 1) * x ^ n = (K * x) ^ n / K := by
    intro n hn
    have hn1 : 1 ≤ n := le_trans hA (mem_Ico.mp hn).1
    rw [mul_pow, eq_div_iff hK0.ne']
    have : K ^ n = K ^ (n - 1) * K := by
      rw [← pow_succ, Nat.sub_add_cancel hn1]
    rw [this]; ring
  rw [sum_congr rfl hterm, ← sum_div]
  have hg := geom_sum_Ico_le_of_lt_one (m := A) (n := M + 1) (by positivity : 0 ≤ K * x) hKx
  have h1 : 0 < 1 - K * x := by linarith
  rw [div_le_div_iff₀ hK0 (by positivity)]
  calc (∑ i ∈ Ico A (M + 1), (K * x) ^ i) * (K * (1 - K * x))
      ≤ (K * x) ^ A / (1 - K * x) * (K * (1 - K * x)) :=
        mul_le_mul_of_nonneg_right hg (by positivity)
    _ = (K * x) ^ A * K := by field_simp

/-- for one root, the connected sets of each size are at most `441^{n-1}` -/
theorem sum_root_le_441 (F : Finset (Finset (Lk N × Fin 4))) (A M : ℕ) (hA1 : 1 ≤ A)
    (hF : ∀ Y ∈ F, Y ⊆ plaqs N ∧ A ≤ Y.card ∧ CutConn (nbP N) Y) (hM : M = (plaqs N).card)
    (r : Lk N × Fin 4) (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ F with r ∈ Y, x ^ Y.card ≤ ∑ n ∈ Ico A (M + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
  have hmaps : ∀ Y ∈ F.filter (fun Y => r ∈ Y), Y.card ∈ Ico A (M + 1) := by
    intro Y hY
    obtain ⟨hYP, hYA, -⟩ := hF Y (mem_filter.mp hY).1
    rw [mem_Ico, hM]
    exact ⟨hYA, Nat.lt_succ_of_le (card_le_card hYP)⟩
  rw [← sum_fiberwise_of_maps_to hmaps]
  apply sum_le_sum
  intro n hn
  have hnA : A ≤ n := (mem_Ico.mp hn).1
  have hcongr : ∑ Y ∈ F.filter (fun Y => r ∈ Y) with Y.card = n, x ^ Y.card
      = ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)).card * x ^ n := by
    rw [sum_congr rfl (fun Y hY => by rw [(mem_filter.mp hY).2]), sum_const, nsmul_eq_mul]
  rw [hcongr]
  apply mul_le_mul_of_nonneg_right _ (pow_nonneg hx _)
  have hcount := card_conn_le (nbQ N) (nbQ_symm N) 21 (card_nbQ_le N) r n (by omega)
    ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)) (by
      intro Y hY
      rw [mem_filter, mem_filter] at hY
      obtain ⟨hYP, -, hc⟩ := hF Y hY.1.1
      exact ⟨hY.1.2, hY.2, cutConn_nbQ N Y hYP hc⟩)
  have h21 : (21 : ℕ) ^ (2 * (n - 1)) = 441 ^ (n - 1) := by
    rw [pow_mul]; norm_num
  rw [h21] at hcount
  exact_mod_cast hcount

open Classical in
/-- **Counting with the sharp constants (rectangle).** -/
theorem sum_minSpan_rect_le_sharp (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (hR : R < N)
    (hT : T < N) (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minSpanC N (wordBd N (rectWord N R T)), x ^ Y.card
      ≤ 6 * ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minSpanC N (wordBd N (rectWord N R T)) with hF
  have hA1 : 1 ≤ R * min T (N - T) := Nat.mul_le_mul hR1 (le_min hT1 (by omega))
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ rootP N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ rootP N (bL N 0), (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨p, hp, hpl⟩ := minSpan_rect_root N R T hR1 hT1 hR hT Y hY
          have hpP := (minSpanC_sub N _ Y hY).1 hp
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [rootP, rootSet, hpl, hpP], hp⟩)
      _ = ∑ r ∈ rootP N (bL N 0), ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ rootP N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  have hF' : ∀ Y ∈ F, Y ⊆ plaqs N ∧ R * min T (N - T) ≤ Y.card ∧ CutConn (nbP N) Y := by
    intro Y hY
    have hsub := minSpanC_sub N _ Y hY
    exact ⟨hsub.1, card_ge_of_spans_rect N R T hR.le (by omega) hT Y hsub.1 hsub.2,
      minSpan_rect_conn N R T hR1 hT1 hR hT Y hY⟩
  have hsum0 : 0 ≤ ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1),
      (441 : ℝ) ^ (n - 1) * x ^ n :=
    sum_nonneg fun n _ => mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _)
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ rootP N (bL N 0), ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ rootP N (bL N 0), ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1),
          (441 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => sum_root_le_441 N F _ _ hA1 hF' rfl r x hx
    _ = (rootP N (bL N 0)).card * ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1),
          (441 : ℝ) ^ (n - 1) * x ^ n := by rw [sum_const, nsmul_eq_mul]
    _ ≤ 6 * ∑ n ∈ Ico (R * min T (N - T)) ((plaqs N).card + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ hsum0
        exact_mod_cast card_rootP_le N (bL N 0)

/-- **Area law with the sharp constants.**  For `β ≥ 0` with `441 (1 - e^{-2β}) < 1`,
`1 ≤ R < N`, `1 ≤ T < N`, under the normalised Wilson measure on `(ℤ/N)⁴`,
`|⟨Re W(∂(R×T))⟩| ≤ 6 (441 q)^{R·min(T, N-T)} / (441 (1 - 441 q))`, `q = 1 - e^{-2β}`. -/
theorem area_law_wilson_sharp (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (hT : T < N) (hK : 441 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 6 * ((441 * (1 - Real.exp (-2 * β))) ^ (R * min T (N - T))
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β))))) := by
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  rw [← wordExpect_eq_wilson]
  refine (abs_wordExpect_le N β hβ (rectWord N R T)).trans ?_
  refine (sum_minSpan_rect_le_sharp N R T hR1 hT1 hR hT _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  exact tail_le_K 441 (by norm_num) _ _ (Nat.mul_le_mul hR1 (le_min hT1 (by omega))) _ hq0 hK

/-- **Area law with the sharp constants, any corner, any plane.** -/
theorem area_law_wilson_general_sharp (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R)
    (hT1 : 1 ≤ T) (hR : R < N) (hT : T < N) (hK : 441 * (1 - Real.exp (-2 * β)) < 1)
    (a : Site N) (μ ν : Fin 4) (h : μ ≠ ν) :
    |(∫ ω, (wordHol N ω (rectWordG N a μ ν R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 6 * ((441 * (1 - Real.exp (-2 * β))) ^ (R * min T (N - T))
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β))))) := by
  rw [← moved_rect_eq N a μ ν h R T, expect_shift, expect_perm N β _ (tau2_invol μ ν),
    expect_perm N β _ (tau1_invol μ)]
  exact area_law_wilson_sharp N β hβ R T hR1 hT1 hR hT hK

end AreaLaw

namespace VortexStrong

open AreaLaw

variable (N : ℕ) [NeZero N]

open Classical in
/-- **Counting with the sharp constants (vortex).** -/
theorem sum_minBad_le_sharp (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minBad N, x ^ Y.card
      ≤ (N * N : ℕ) * ∑ n ∈ Ico (N * N) ((plaqs N).card + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minBad N with hF
  have hA1 : 1 ≤ N * N := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne N) (NeZero.ne N))
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ twistSet N, (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨hYP, hYb, -⟩ := minBad_sub N Y hY
          obtain ⟨p, hp, hpq⟩ := bad_meets N Y hYP hYb 0 0
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [twistSet, hpq], hp⟩)
      _ = ∑ r ∈ twistSet N, ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  have hF' : ∀ Y ∈ F, Y ⊆ plaqs N ∧ N * N ≤ Y.card ∧ CutConn (nbP N) Y := by
    intro Y hY
    obtain ⟨hYP, hYb, -⟩ := minBad_sub N Y hY
    exact ⟨hYP, card_bad_ge N Y hYP hYb, minBad_conn N Y hY⟩
  have hsum0 : 0 ≤ ∑ n ∈ Ico (N * N) ((plaqs N).card + 1), (441 : ℝ) ^ (n - 1) * x ^ n :=
    sum_nonneg fun n _ => mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _)
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ twistSet N, ∑ n ∈ Ico (N * N) ((plaqs N).card + 1),
          (441 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => sum_root_le_441 N F _ _ hA1 hF' rfl r x hx
    _ = (twistSet N).card * ∑ n ∈ Ico (N * N) ((plaqs N).card + 1),
          (441 : ℝ) ^ (n - 1) * x ^ n := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (N * N : ℕ) * ∑ n ∈ Ico (N * N) ((plaqs N).card + 1), (441 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ hsum0
        exact_mod_cast card_twistSet_le N

/-- **Vortex floor with the sharp constants.**  For `β ≥ 0` with `441 (1 - e^{-2β}) < 1`,
`|Z₀ - Z₁| ≤ N² (441 q)^{N²} / (441 (1 - 441 q)) · (Z₀ + Z₁)`, `q = 1 - e^{-2β}`. -/
theorem vortex_floor_sharp (β : ℝ) (hβ : 0 ≤ β) (hK : 441 * (1 - Real.exp (-2 * β)) < 1) :
    |Ztw N β (fun _ => 0) - Ztw N β (twist N)|
      ≤ (N * N : ℕ) * ((441 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β)))))
          * (Ztw N β (fun _ => 0) + Ztw N β (twist N)) := by
  classical
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hA1 : 1 ≤ N * N := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne N) (NeZero.ne N))
  have hZ0 : 0 ≤ Ztw N β (fun _ => 0) := integral_nonneg fun _ => (Real.exp_pos _).le
  have hZ1 : 0 ≤ Ztw N β (twist N) := integral_nonneg fun _ => (Real.exp_pos _).le
  refine (abs_Z_sub_le N β hβ).trans (mul_le_mul_of_nonneg_right ?_ (by linarith))
  refine (sum_minBad_le_sharp N _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact tail_le_K 441 (by norm_num) _ _ hA1 _ hq0 hK

/-- Sanity: the sharp window contains `β = 1/1000`. -/
theorem sanity_window_sharp :
    (0 : ℝ) ≤ 1 / 1000 ∧ 441 * (1 - Real.exp (-2 * (1 / 1000 : ℝ))) < 1 := by
  refine ⟨by norm_num, ?_⟩
  have h := Real.add_one_le_exp (-2 * (1 / 1000 : ℝ))
  nlinarith

lemma small_sharp_aux (q : ℝ) (hq0 : 0 ≤ q) (hqs : 441 * q ≤ 1 / 10) :
    6 * ((441 * q) ^ (3 * 3) / (441 * (1 - 441 * q))) < 1 := by
  have hden : 0 < 441 * (1 - 441 * q) := by linarith
  have hp : (441 * q) ^ (3 * 3) ≤ (1 / 10) ^ (3 * 3) :=
    pow_le_pow_left₀ (by positivity) hqs _
  have h9 : ((1 : ℝ) / 10) ^ (3 * 3) = 1 / 1000000000 := by norm_num
  rw [h9] at hp
  rw [mul_div_assoc', div_lt_one hden]
  generalize (441 * q) ^ (3 * 3) = X at hp ⊢
  nlinarith

/-- Sanity (the sharp area-law bound is nontrivial): at `β = 1/10000`, `R = T = 3`, the right side
is below `1`. -/
theorem sanity_bound_small_sharp :
    6 * ((441 * (1 - Real.exp (-2 * (1 / 10000 : ℝ)))) ^ (3 * 3)
      / (441 * (1 - 441 * (1 - Real.exp (-2 * (1 / 10000 : ℝ)))))) < 1 := by
  have h1 := Real.add_one_le_exp (-2 * (1 / 10000 : ℝ))
  have h2 := Real.exp_le_one_iff.mpr (by norm_num : -2 * (1 / 10000 : ℝ) ≤ 0)
  exact small_sharp_aux _ (by linarith) (by linarith)

end VortexStrong

#print axioms AreaLaw.card_rootP_le
#print axioms AreaLaw.card_nbQ_le
#print axioms AreaLaw.area_law_wilson_sharp
#print axioms AreaLaw.area_law_wilson_general_sharp
#print axioms VortexStrong.vortex_floor_sharp
#print axioms VortexStrong.sanity_window_sharp
#print axioms VortexStrong.sanity_bound_small_sharp
