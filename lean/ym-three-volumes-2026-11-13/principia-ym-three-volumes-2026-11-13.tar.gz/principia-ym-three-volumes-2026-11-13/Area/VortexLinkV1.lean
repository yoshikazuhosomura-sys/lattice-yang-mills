import Area.SharpConstV1

/-!
# The untwisted partition function of the vortex floor is the total mass of the Wilson measure

`Z₀ = Ztw N β 0` (product-Haar integral of `exp(β Σ_p Re U_p)`) is `∫ 1 d(wilsonMeasure N β)`, the
normaliser of the Wilson measure of `Lattice.TorusDecV2`.  So the vortex floor reads, with the
Wilson measure's own normaliser, `|Z₀ - Z₁| ≤ ε (Z₀ + Z₁)`.
-/

open MeasureTheory Finset TorusRP OSGap AreaLaw

namespace VortexStrong

variable (N : ℕ) [NeZero N]

theorem Ztw_zero_eq_wilson (β : ℝ) :
    Ztw N β (fun _ => 0) = ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
  rw [Ztw_zero, integral_wilson]
  simp only [one_mul, wilsonWeight]

/-- **Vortex floor with the Wilson normaliser** (sharp constants). -/
theorem vortex_floor_wilson (β : ℝ) (hβ : 0 ≤ β) (hK : 441 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)) - Ztw N β (twist N)|
      ≤ (N * N : ℕ) * ((441 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (441 * (1 - 441 * (1 - Real.exp (-2 * β)))))
          * ((∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)) + Ztw N β (twist N)) := by
  rw [← Ztw_zero_eq_wilson]
  exact vortex_floor_sharp N β hβ hK

end VortexStrong

#print axioms VortexStrong.Ztw_zero_eq_wilson
#print axioms VortexStrong.vortex_floor_wilson
