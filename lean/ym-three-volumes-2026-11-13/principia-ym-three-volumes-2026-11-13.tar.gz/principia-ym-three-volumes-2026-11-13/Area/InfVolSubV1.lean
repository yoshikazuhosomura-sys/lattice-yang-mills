import Area.InfVolV2

/-!
# The area law at every subsequential weak limit of the lifted Wilson measures

Paper correspondence: the corollary `area_law_limit` stated for the limit of a subsequence
`liftProb β (φ n)` (`φ` strictly increasing), so it applies to every limit point, not only to
the limit of the whole sequence.  Same proof: the finite-volume bound is uniform in the torus
size.
-/

open MeasureTheory Filter Topology Finset TorusRP WilsonLimit
open scoped BoundedContinuousFunction

namespace AreaLaw

/-- **Area law at every subsequential limit.**  For `β ≥ 0` with `4096 (1 - e^{-2β}) < 1`,
`R, T ≥ 1`, a strictly increasing `φ : ℕ → ℕ` and a probability measure `ν` with
`liftProb β (φ n) → ν` weakly,
`|∫ Re W(∂(R×T)) dν| ≤ 16 (4096 q)^{R T} / (4096 (1 - 4096 q))`, `q = 1 - e^{-2β}`. -/
theorem area_law_limit_sub (β : ℝ) (hβ : 0 ≤ β) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1)
    (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (ν : ProbabilityMeasure Cfg) (hν : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    |∫ x, (zWordHol x (zRectWord R T)).re ∂(ν : Measure Cfg)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * T)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have hlim := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hν) (zLoopFn R T)
  simp only [zLoopFn, BoundedContinuousFunction.mkOfCompact_apply, ContinuousMap.coe_mk] at hlim
  apply le_of_tendsto hlim.abs
  filter_upwards [hφ.tendsto_atTop.eventually (eventually_ge_atTop (R + T))] with n hn
  have hcont : Continuous (fun x : Cfg => (zWordHol x (zRectWord R T)).re) :=
    Quaternion.continuous_re.comp (continuous_zWordHol _)
  rw [integral_lift β (φ n) (fun x : Cfg => (zWordHol x (zRectWord R T)).re) hcont]
  simp only [zWordHol_perLift, zRect_map]
  rw [integral_wilsonProb_ratio]
  exact area_law_wilson_area (Nn (φ n)) β hβ R T hR1 hT1 (by rw [Nn_eq]; omega)
    (by rw [Nn_eq]; omega) hK

/-- Sanity: the whole sequence is the case `φ = id`. -/
theorem sanity_sub_id : StrictMono (id : ℕ → ℕ) := strictMono_id

end AreaLaw

#print axioms AreaLaw.area_law_limit_sub
