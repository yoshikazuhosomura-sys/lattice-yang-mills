import Area.AreaLowerV1

/-!
# The bounds in terms of `TorusRP.wilsonMeasure`

`wordExpect N β w` (ratio of product-Haar integrals) is the normalised expectation of
`Re W(w)` under the Wilson measure `TorusRP.wilsonMeasure N β` of `Lattice.TorusDecV2`
(via `TorusRP.integral_wilson`).  Restating the rectangle bound in that form.
-/

open MeasureTheory Finset TorusRP

namespace AreaLaw

variable (N : ℕ) [NeZero N]

theorem wordExpect_eq_wilson (β : ℝ) (w : Word N) :
    wordExpect N β w
      = (∫ ω, (wordHol N ω w).re ∂(wilsonMeasure N β)) / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
  unfold wordExpect
  rw [integral_wilson, integral_wilson]
  simp only [one_mul, wilsonWeight]

open Classical in
/-- **Rectangle bound for the Wilson measure.**  For `β ≥ 0`, `R ≤ N`, `0 < T < N`, under the
normalised Wilson measure on `(ℤ/N)⁴`,
`|⟨Re W(∂(R×T))⟩| ≤ #(minimal spanning sets) · (1 - e^{-2β})^{R · min(T, N-T)}`. -/
theorem abs_wilson_rect_le (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR : R ≤ N) (hT0 : 0 < T)
    (hTN : T < N) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ (minSpanC N (wordBd N (rectWord N R T))).card
          * (1 - Real.exp (-2 * β)) ^ (R * min T (N - T)) := by
  rw [← wordExpect_eq_wilson]
  exact abs_rectExpect_le N β hβ R T hR hT0 hTN

end AreaLaw

#print axioms AreaLaw.abs_wilson_rect_le
