import Mathlib

/-!
# The domination lemma for positive mixtures

Paper correspondence: step 3 of the strong-coupling area-law argument
(Osterwalder–Seiler type).  Let `P` be a finite set (plaquettes) and
`Z : Finset P → ℝ` real weights with `Z (S ∪ {p}) ≤ t Z S` whenever
`p ∉ S`.  Then, with `q = t/(1+t)`,
`∑_{X ⊇ Y} Z X ≤ q^{|Y|} ∑_X Z X` for every `Y`.
-/

open Finset

namespace AreaLaw

variable {P : Type*} [Fintype P] [DecidableEq P]

/-- The sum of the weights over all sets containing `Y`. -/
noncomputable def supSum (Z : Finset P → ℝ) (Y : Finset P) : ℝ :=
  ∑ X ∈ (univ : Finset (Finset P)) with Y ⊆ X, Z X

lemma supSum_empty (Z : Finset P → ℝ) : supSum Z ∅ = ∑ X, Z X := by
  unfold supSum
  simp

/-- Splitting the sets containing `Y` by whether they contain `p`. -/
lemma supSum_split (Z : Finset P → ℝ) (Y : Finset P) (p : P) :
    supSum Z Y = supSum Z (insert p Y)
      + ∑ X ∈ (univ : Finset (Finset P)) with (Y ⊆ X ∧ p ∉ X), Z X := by
  unfold supSum
  rw [← sum_filter_add_sum_filter_not ((univ : Finset (Finset P)).filter (fun X => Y ⊆ X))
    (fun X => p ∈ X) Z, filter_filter, filter_filter]
  congr 1
  apply sum_congr _ (fun _ _ => rfl)
  ext X
  simp [insert_subset_iff, and_comm]

/-- The sets containing `insert p Y` are in bijection with the sets containing `Y`
and not `p`; one step of the domination hypothesis gives a factor `t`. -/
lemma supSum_insert_le (Z : Finset P → ℝ) (t : ℝ)
    (hZ : ∀ (S : Finset P) (p : P), p ∉ S → Z (insert p S) ≤ t * Z S)
    (Y : Finset P) (p : P) (hp : p ∉ Y) :
    supSum Z (insert p Y)
      ≤ t * ∑ X ∈ (univ : Finset (Finset P)) with (Y ⊆ X ∧ p ∉ X), Z X := by
  unfold supSum
  have hbij : ∑ X ∈ (univ : Finset (Finset P)) with insert p Y ⊆ X, Z X
      = ∑ X ∈ (univ : Finset (Finset P)) with (Y ⊆ X ∧ p ∉ X), Z (insert p X) := by
    apply sum_nbij' (fun X => X.erase p) (fun X => insert p X)
    · intro X hX
      simp only [mem_filter, mem_univ, true_and, insert_subset_iff] at hX ⊢
      refine ⟨?_, notMem_erase p X⟩
      intro y hy
      rw [mem_erase]
      refine ⟨?_, hX.2 hy⟩
      rintro rfl
      exact hp hy
    · intro X hX
      simp only [mem_filter, mem_univ, true_and, insert_subset_iff] at hX ⊢
      exact ⟨mem_insert_self p X, hX.1.trans (subset_insert p X)⟩
    · intro X hX
      simp only [mem_filter, mem_univ, true_and, insert_subset_iff] at hX
      exact insert_erase hX.1
    · intro X hX
      simp only [mem_filter, mem_univ, true_and] at hX
      exact erase_insert hX.2
    · intro X hX
      simp only [mem_filter, mem_univ, true_and, insert_subset_iff] at hX
      rw [insert_erase hX.1]
  rw [hbij, mul_sum]
  apply sum_le_sum
  intro X hX
  simp only [mem_filter, mem_univ, true_and] at hX
  exact hZ X p hX.2

/-- **Domination lemma.**  If `0 ≤ t` and adding one element multiplies
the weight by at most `t`, then (no sign condition on `Z` is needed) the total weight of the sets containing `Y` is at most
`(t/(1+t))^{|Y|}` times the total weight. -/
theorem sum_superset_le (Z : Finset P → ℝ) (t : ℝ) (ht : 0 ≤ t)
    (hZ : ∀ (S : Finset P) (p : P), p ∉ S → Z (insert p S) ≤ t * Z S) (Y : Finset P) :
    ∑ X ∈ (univ : Finset (Finset P)) with Y ⊆ X, Z X
      ≤ (t / (1 + t)) ^ Y.card * ∑ X, Z X := by
  have h1t : 0 < 1 + t := by linarith
  have hq0 : 0 ≤ t / (1 + t) := div_nonneg ht h1t.le
  change supSum Z Y ≤ _
  induction Y using Finset.induction_on with
  | empty => simp [supSum_empty]
  | insert p Y hp ih =>
    rw [card_insert_of_notMem hp, pow_succ]
    have hsplit := supSum_split Z Y p
    have hle := supSum_insert_le Z t hZ Y p hp
    -- (1+t) a_{pY} ≤ t a_Y
    have hkey : supSum Z (insert p Y) ≤ t / (1 + t) * supSum Z Y := by
      rw [div_mul_eq_mul_div, le_div_iff₀ h1t]
      nlinarith
    calc supSum Z (insert p Y) ≤ t / (1 + t) * supSum Z Y := hkey
      _ ≤ t / (1 + t) * ((t / (1 + t)) ^ Y.card * ∑ X, Z X) :=
          mul_le_mul_of_nonneg_left ih hq0
      _ = (t / (1 + t)) ^ Y.card * (t / (1 + t)) * ∑ X, Z X := by ring

omit [Fintype P] in
/-- Sanity (non-vacuity): the weights `Z X = t^{|X|}` satisfy all hypotheses for every
`t ≥ 0` (with equality in the one-step bound). -/
theorem sanity_pow_weights (t : ℝ) (ht : 0 ≤ t) :
    (∀ S : Finset P, 0 ≤ t ^ S.card) ∧
    (∀ (S : Finset P) (p : P), p ∉ S → t ^ (insert p S).card ≤ t * t ^ S.card) := by
  refine ⟨fun S => pow_nonneg ht _, fun S p hp => ?_⟩
  rw [card_insert_of_notMem hp, pow_succ, mul_comm]

/-- Sanity (sharpness): on a one-point set with `Z ≡ 1`, `t = 1` and `Y = univ`,
both sides equal `1`: the bound is attained. -/
theorem sanity_sharp_one_point :
    (∑ X ∈ (univ : Finset (Finset (Fin 1))) with ({0} : Finset (Fin 1)) ⊆ X, (1 : ℝ)) = 1 ∧
    (1 / (1 + 1 : ℝ)) ^ ({0} : Finset (Fin 1)).card * ∑ _X : Finset (Fin 1), (1 : ℝ) = 1 := by
  constructor
  · rw [sum_const, nsmul_eq_mul, mul_one]
    have : ((univ : Finset (Finset (Fin 1))).filter (fun X => ({0} : Finset (Fin 1)) ⊆ X))
        = {univ} := by decide
    rw [this]; simp
  · simp [Finset.card_univ, Fintype.card_finset]
    norm_num

end AreaLaw

#print axioms AreaLaw.sum_superset_le
#print axioms AreaLaw.sanity_sharp_one_point
