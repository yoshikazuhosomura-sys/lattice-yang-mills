import Lattice.TorusDecV2
import Area.DualF2V1

/-!
# Vanishing of the non-spanning terms by centre sign flips (SU(2) on `(ℤ/N)⁴`)

Paper correspondence: step 2 of the strong-coupling area-law argument
(Osterwalder–Seiler type), on the lattice objects of `Lattice.TorusDecV2`
(`QBall`, `haarBall`, `Lk N`, `plaqs N`, `hol`).

* `flipZ T`: multiply by `-1` (the centre of SU(2)) the links `ℓ` with `T ℓ = 1`,
  `T : Lk N → ZMod 2`.  It preserves the product Haar measure and is an involution.
* A *link word* `w : List (Lk N × Bool)` is a sequence of links traversed forwards (`true`,
  factor `U_ℓ`) or backwards (`false`, factor `U_ℓ*`); `wordHol ω w` is the ordered product and
  `wordBd w : Lk N → ZMod 2` its mod-2 link content.  The plaquette holonomy `hol N ω p` is the
  word `plaqWord p`, and every Wilson loop along a closed lattice path is such a word.
* `wordHol_flip`: `wordHol (flipZ T ω) w = (-1)^{⟨T, wordBd w⟩} wordHol ω w` (no condition on
  `N`; a link occurring twice contributes twice, which is why `wordBd` counts mod 2).
* **`integral_word_mul_prod_eq_zero_of_not_mem_span`**: if the mod-2 content of the loop is not
  in the span of the mod-2 boundaries of the plaquettes of `X`, then for every function `g`,
  `∫ Re W(w) · ∏_{p∈X} g(Re U_p) d(∏ Haar) = 0`.

`negBall` / `negBall_preserving` are copied from `Tuned.HaarMeanV1`
(`TunedCoupling.negB`, `negB_preserving`), renamed.
-/

open MeasureTheory Finset TorusRP OSGap

local notation "ℍr" => Quaternion ℝ

namespace AreaLaw

/-- `q ↦ -q` on the closed unit ball of `ℍ` (multiplication by the centre element `-1`). -/
noncomputable def negBall (q : QBall) : QBall :=
  ⟨-(q : ℍr), by rw [mem_closedBall_zero_iff, norm_neg]; exact mem_closedBall_zero_iff.mp q.2⟩

theorem continuous_negBall : Continuous negBall :=
  (continuous_subtype_val.neg).subtype_mk _

/-- `-1 ∈ SU(2)`. -/
def mOneSU2 : SU2 := ⟨-1, by rw [mem_sphere_zero_iff_norm, norm_neg, norm_one]⟩

theorem negBall_incl (q : SU2) : negBall (incl q) = incl (mOneSU2 * q) := by
  apply Subtype.ext
  show -((q : ℍr)) = ((mOneSU2 * q : SU2) : ℍr)
  rw [Metric.unitSphere.coe_mul]
  show -((q : ℍr)) = (-1 : ℍr) * (q : ℍr)
  rw [neg_one_mul]

theorem negBall_preserving : MeasurePreserving negBall haarBall haarBall := by
  refine ⟨continuous_negBall.measurable, ?_⟩
  unfold haarBall
  rw [Measure.map_map continuous_negBall.measurable continuous_incl.measurable]
  have hc : negBall ∘ incl = incl ∘ (fun q : SU2 => mOneSU2 * q) := funext negBall_incl
  rw [hc, ← Measure.map_map continuous_incl.measurable (continuous_const_mul mOneSU2).measurable]
  congr 1
  exact map_mul_left_eq_self _ mOneSU2

theorem negBall_negBall (q : QBall) : negBall (negBall q) = q := by
  apply Subtype.ext
  show -(-(q : ℍr)) = q
  rw [neg_neg]

section Flip

variable (N : ℕ) [NeZero N]

/-- the sign `(-1)^z` of `z ∈ ZMod 2` -/
noncomputable def sgn (z : ZMod 2) : ℝ := if z = 0 then 1 else -1

lemma zmod2_cases (z : ZMod 2) : z = 0 ∨ z = 1 := by
  revert z; decide

lemma sgn_add (a b : ZMod 2) : sgn (a + b) = sgn a * sgn b := by
  rcases zmod2_cases a with rfl | rfl <;> rcases zmod2_cases b with rfl | rfl
  · simp [sgn]
  · simp [sgn]
  · simp [sgn]
  · have : (1 + 1 : ZMod 2) = 0 := by decide
    simp [sgn, this]

lemma sgn_one : sgn 1 = -1 := by simp [sgn]

/-- the flip on one link -/
noncomputable def linkFlip (T : Lk N → ZMod 2) (ℓ : Lk N) : QBall → QBall :=
  if T ℓ = 1 then negBall else id

/-- multiply by `-1` the links `ℓ` with `T ℓ = 1` -/
noncomputable def flipZ (T : Lk N → ZMod 2) (ω : Lk N → QBall) : Lk N → QBall :=
  fun ℓ => linkFlip N T ℓ (ω ℓ)

theorem flipZ_preserving (T : Lk N → ZMod 2) :
    MeasurePreserving (flipZ N T) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) :=
  measurePreserving_pi _ _ (fun ℓ => by
    unfold linkFlip
    split_ifs
    · exact negBall_preserving
    · exact MeasurePreserving.id _)

theorem flipZ_flipZ (T : Lk N → ZMod 2) (ω : Lk N → QBall) : flipZ N T (flipZ N T ω) = ω := by
  funext ℓ
  unfold flipZ linkFlip
  split_ifs
  · exact negBall_negBall _
  · rfl

theorem continuous_flipZ (T : Lk N → ZMod 2) : Continuous (flipZ N T) := by
  refine continuous_pi fun ℓ => ?_
  unfold flipZ linkFlip
  split_ifs
  · exact continuous_negBall.comp (continuous_apply ℓ)
  · exact continuous_apply ℓ

/-- the flip as a measurable involution -/
noncomputable def flipEquiv (T : Lk N → ZMod 2) : (Lk N → QBall) ≃ᵐ (Lk N → QBall) where
  toFun := flipZ N T
  invFun := flipZ N T
  left_inv := flipZ_flipZ N T
  right_inv := flipZ_flipZ N T
  measurable_toFun := (continuous_flipZ N T).measurable
  measurable_invFun := (continuous_flipZ N T).measurable

theorem Uq_flipZ (T : Lk N → ZMod 2) (ω : Lk N → QBall) (ℓ : Lk N) :
    Uq N (flipZ N T ω) ℓ = sgn (T ℓ) • Uq N ω ℓ := by
  unfold Uq flipZ linkFlip
  rcases zmod2_cases (T ℓ) with h | h
  · rw [h, if_neg (by decide)]
    simp [sgn]
  · rw [h, if_pos rfl, sgn_one, neg_one_smul]
    rfl

/-- a link word: links traversed forwards (`true`) or backwards (`false`) -/
abbrev Word := List (Lk N × Bool)

/-- ordered product of the link variables along a word -/
noncomputable def wordHol (ω : Lk N → QBall) : Word N → ℍr
  | [] => 1
  | s :: w => (if s.2 then Uq N ω s.1 else star (Uq N ω s.1)) * wordHol ω w

/-- mod-2 link content of a word (`1` at the links occurring an odd number of times) -/
def wordBd : Word N → Lk N → ZMod 2
  | [] => fun _ => 0
  | s :: w => fun e => (if s.1 = e then 1 else 0) + wordBd w e

theorem pair_wordBd_cons (T : Lk N → ZMod 2) (s : Lk N × Bool) (w : Word N) :
    ∑ e, T e * wordBd N (s :: w) e = T s.1 + ∑ e, T e * wordBd N w e := by
  simp only [wordBd, mul_add, sum_add_distrib, mul_ite, mul_one, mul_zero, sum_ite_eq,
    mem_univ, if_true]

/-- **Flip covariance of a word**: `W(flip_T ω) = (-1)^{⟨T, ∂w⟩} W(ω)`. -/
theorem wordHol_flip (T : Lk N → ZMod 2) (ω : Lk N → QBall) (w : Word N) :
    wordHol N (flipZ N T ω) w = sgn (∑ e, T e * wordBd N w e) • wordHol N ω w := by
  induction w with
  | nil => simp [wordHol, wordBd, sgn]
  | cons s w ih =>
    rw [pair_wordBd_cons, sgn_add]
    simp only [wordHol]
    rw [ih, Uq_flipZ]
    have hfac : (if s.2 then sgn (T s.1) • Uq N ω s.1 else star (sgn (T s.1) • Uq N ω s.1))
        = sgn (T s.1) • (if s.2 then Uq N ω s.1 else star (Uq N ω s.1)) := by
      split_ifs
      · rfl
      · ext <;> simp
    rw [hfac, smul_mul_smul_comm]

/-- the word of the plaquette `(x, μ, ν)`: `U(x,μ) U(x+μ,ν) U(x+ν,μ)* U(x,ν)*` -/
def plaqWord (p : Lk N × Fin 4) : Word N :=
  [(p.1, true), ((p.1.1 + ev N p.1.2, p.2), true), ((p.1.1 + ev N p.2, p.1.2), false),
    ((p.1.1, p.2), false)]

theorem hol_eq_wordHol (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N ω p = wordHol N ω (plaqWord N p) := by
  simp only [hol, holQ, wordHol, plaqWord, Bool.false_eq_true, if_true, if_false, mul_one,
    mul_assoc]

/-- the mod-2 boundary of a plaquette (with multiplicity mod 2) -/
def plaqBd (p : Lk N × Fin 4) : Lk N → ZMod 2 := wordBd N (plaqWord N p)

/-- A function that changes sign under a measure-preserving flip has Haar integral `0`. -/
theorem integral_eq_zero_of_flip_odd (T : Lk N → ZMod 2) (F : (Lk N → QBall) → ℝ)
    (hF : ∀ ω, F (flipZ N T ω) = - F ω) :
    ∫ ω, F ω ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  have h := (flipZ_preserving N T).integral_comp' (f := flipEquiv N T) F
  have h2 : ∫ ω, F (flipEquiv N T ω) ∂(Measure.pi fun _ : Lk N => haarBall)
      = - ∫ ω, F ω ∂(Measure.pi fun _ : Lk N => haarBall) := by
    rw [← integral_neg]
    exact integral_congr_ae (Filter.Eventually.of_forall fun ω => hF ω)
  linarith

/-- **Vanishing with an explicit separating set.**  If `T` meets the boundary of every plaquette
of `X` evenly and the word `w` oddly, then for every `g : ℝ → ℝ`,
`∫ Re W(w) · ∏_{p ∈ X} g(Re U_p) d(∏ Haar) = 0`. -/
theorem integral_word_mul_prod_eq_zero (w : Word N) (X : Finset (Lk N × Fin 4)) (g : ℝ → ℝ)
    (T : Lk N → ZMod 2) (hX : ∀ p ∈ X, ∑ e, T e * plaqBd N p e = 0)
    (hc : ∑ e, T e * wordBd N w e = 1) :
    ∫ ω, (wordHol N ω w).re * ∏ p ∈ X, g (hol N ω p).re
      ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  apply integral_eq_zero_of_flip_odd N T
  intro ω
  rw [wordHol_flip, hc, sgn_one, neg_one_smul, Quaternion.re_neg, neg_mul]
  congr 2
  apply prod_congr rfl
  intro p hp
  rw [hol_eq_wordHol, hol_eq_wordHol, wordHol_flip]
  have h0 := hX p hp
  unfold plaqBd at h0
  rw [h0]
  simp [sgn]

/-- **Vanishing of the non-spanning terms.**  If the mod-2 link content of the loop `w` is not in
the `ZMod 2`-span of the mod-2 boundaries of the plaquettes of `X` (i.e. `X` contains no mod-2
surface bounded by the loop), then for every `g : ℝ → ℝ`,
`∫ Re W(w) · ∏_{p ∈ X} g(Re U_p) d(∏ Haar) = 0`.  No condition on `N`. -/
theorem integral_word_mul_prod_eq_zero_of_not_mem_span (w : Word N) (X : Finset (Lk N × Fin 4))
    (g : ℝ → ℝ)
    (hspan : wordBd N w ∉ Submodule.span (ZMod 2) ((plaqBd N) '' (X : Set (Lk N × Fin 4)))) :
    ∫ ω, (wordHol N ω w).re * ∏ p ∈ X, g (hol N ω p).re
      ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  obtain ⟨T, hX, hc⟩ := exists_sep_of_not_mem_span (wordBd N w) (plaqBd N) X hspan
  exact integral_word_mul_prod_eq_zero N w X g T hX hc

/-- The single-plaquette Wilson loop: `Re U_{p₀} = Re W(plaqWord p₀)`; vanishing of the terms
whose plaquette set does not span `∂p₀` mod 2. -/
theorem integral_plaq_mul_prod_eq_zero_of_not_mem_span (p₀ : Lk N × Fin 4)
    (X : Finset (Lk N × Fin 4)) (g : ℝ → ℝ)
    (hspan : plaqBd N p₀ ∉ Submodule.span (ZMod 2) ((plaqBd N) '' (X : Set (Lk N × Fin 4)))) :
    ∫ ω, (hol N ω p₀).re * ∏ p ∈ X, g (hol N ω p).re
      ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  simp_rw [hol_eq_wordHol N _ p₀]
  exact integral_word_mul_prod_eq_zero_of_not_mem_span N (plaqWord N p₀) X g hspan

/-! ### Sanity -/

/-- For `N ≥ 2` the first link of a plaquette `p ∈ plaqs N` occurs exactly once in its word,
so `∂p ≠ 0` mod 2 (the hypothesis with `X = ∅` is met). -/
theorem plaqBd_first (hN : 1 < N) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) : plaqBd N p p.1 = 1 := by
  have : Fact (1 < N) := ⟨hN⟩
  have hlt : p.1.2 < p.2 := (Finset.mem_filter.mp hp).2
  have hne : p.1.2 ≠ p.2 := ne_of_lt hlt
  have h2 : ((p.1.1 + ev N p.1.2, p.2) : Lk N) ≠ p.1 := fun h => hne (congrArg Prod.snd h).symm
  have h4 : ((p.1.1, p.2) : Lk N) ≠ p.1 := fun h => hne (congrArg Prod.snd h).symm
  have h3 : ((p.1.1 + ev N p.2, p.1.2) : Lk N) ≠ p.1 := by
    intro h
    have hx := congrArg (fun l : Lk N => l.1 p.2) h
    simp only [ev, Pi.add_apply, Pi.single_eq_same] at hx
    exact one_ne_zero (add_eq_left.mp hx)
  simp [plaqBd, plaqWord, wordBd, h2, h3, h4]

theorem sanity_empty_spans_nothing (hN : 1 < N) (p₀ : Lk N × Fin 4) (hp : p₀ ∈ plaqs N) :
    plaqBd N p₀ ∉ Submodule.span (ZMod 2)
      ((plaqBd N) '' ((∅ : Finset (Lk N × Fin 4)) : Set (Lk N × Fin 4))) := by
  intro h
  simp only [coe_empty, Set.image_empty, Submodule.span_empty, Submodule.mem_bot] at h
  have := congrFun h p₀.1
  rw [plaqBd_first N hN p₀ hp] at this
  exact one_ne_zero this

/-- Sanity (consistency with the known Haar mean): `X = ∅` recovers `∫ Re U_{p₀} d(∏ Haar) = 0`
for `N ≥ 2`. -/
theorem sanity_haar_mean (hN : 1 < N) (p₀ : Lk N × Fin 4) (hp : p₀ ∈ plaqs N) :
    ∫ ω, (hol N ω p₀).re ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  have := integral_plaq_mul_prod_eq_zero_of_not_mem_span N p₀ ∅ (fun _ => 0)
    (sanity_empty_spans_nothing N hN p₀ hp)
  simpa using this

/-- Sanity (the hypothesis is not automatic): `X = {p₀}` spans `∂p₀`, so the vanishing
theorem says nothing about the term `∫ Re U_{p₀} g(Re U_{p₀})`. -/
theorem sanity_self_spans (p₀ : Lk N × Fin 4) :
    plaqBd N p₀ ∈ Submodule.span (ZMod 2)
      ((plaqBd N) '' (({p₀} : Finset (Lk N × Fin 4)) : Set (Lk N × Fin 4))) :=
  Submodule.subset_span ⟨p₀, by simp, rfl⟩

/-- Sanity: the lattice `(ℤ/2)⁴` has a plaquette in `plaqs`, so the hypotheses of
`sanity_haar_mean` are met. -/
theorem sanity_plaq_exists : ((0, 0), 1) ∈ plaqs 2 := by
  simp [plaqs]

end Flip

end AreaLaw

#print axioms AreaLaw.integral_word_mul_prod_eq_zero_of_not_mem_span
#print axioms AreaLaw.integral_plaq_mul_prod_eq_zero_of_not_mem_span
#print axioms AreaLaw.sanity_haar_mean
#print axioms AreaLaw.sanity_plaq_exists
