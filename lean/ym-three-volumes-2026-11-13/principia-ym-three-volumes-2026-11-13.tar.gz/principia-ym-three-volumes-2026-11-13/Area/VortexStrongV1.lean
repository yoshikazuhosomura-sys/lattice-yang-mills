import Area.AreaMainV1

/-!
# The twisted partition function at strong coupling: a floor uniform in the torus size

SU(2) on `(ℤ/N)⁴`, product Haar measure on the links, Wilson weight
`exp(β Σ_{p ∈ plaqs N} η_p Re U_p)` with a centre twist `η_p = -1` on the set
`D = {(0,1)-plaquettes at x₀ = x₁ = 0}` (`N²` plaquettes, extended in `x₂, x₃`) and `η_p = 1`
otherwise (a 't Hooft twist in the `(0,1)` plane).  `Z₀` is the untwisted partition function
(`η ≡ 1`), `Z₁` the twisted one.

Paper correspondence: the strong-coupling vortex free energy (centre-flip expansion, known type).

* `ZM_gauge`: the centre flip `flipZ T` of the links turns the mask `m` into `m + δT` on the
  plaquettes of `X` (`hol (flipZ T ω) p = (-1)^{⟨T,∂p⟩} hol ω p`), so the mixture weight
  `Z^m_X = ∫ ∏_{p∈X} σ(η_p Re U_p)` only depends on the class of `m` on `X`.
* A set `X` is *good* if the twist mask is a coboundary on `X`
  (`∃ T, ∀ p ∈ X, ⟨T, ∂p⟩ = [p ∈ D]`).  Good sets give equal twisted and untwisted weights;
  so `|Z₀ - Z₁| ≤ (Σ_{Y minimal bad} q^{|Y|}) (Z₀ + Z₁)`, `q = 1 - e^{-2β}` (domination lemma).
* A minimal bad set is connected (sharing links), meets each of the `N²` translates
  `D_{a,b} = {(0,1)-plaquettes at x₀ = a, x₁ = b}` (the twist masks of `D_{a,b}` and `D` differ by
  the coboundary of explicit link sets), hence has at least `N²` plaquettes and contains a
  plaquette of `D`.
* **`vortex_floor`**: for `β ≥ 0` with `4096 q < 1`,
  `|Z₀ - Z₁| ≤ N² (4096 q)^{N²} / (4096 (1 - 4096 q)) · (Z₀ + Z₁)`; the rate `4096 q` does not
  depend on `N`.
-/

open MeasureTheory Finset TorusRP OSGap AreaLaw

namespace VortexStrong

variable (N : ℕ) [NeZero N]

/-! ### Signed mixture weights -/

lemma abs_sgn_mul_le (z : ZMod 2) (r : ℝ) (hr : |r| ≤ 1) : |sgn z * r| ≤ 1 := by
  rcases zmod2_cases z with h | h <;> simp [sgn, h, hr]

/-- the signed mixture variable `σ^m_p = e^{β(η_p Re U_p + 1)} - 1`, `η_p = (-1)^{m p}` -/
noncomputable def sigM (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (ω : Lk N → QBall)
    (p : Lk N × Fin 4) : ℝ :=
  mixVar β (sgn (m p) * (hol N ω p).re)

/-- `Z^m_X = ∫ ∏_{p ∈ X} σ^m_p d(∏ Haar)` -/
noncomputable def ZM (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (X : Finset (Lk N × Fin 4)) : ℝ :=
  ∫ ω, ∏ p ∈ X, sigM N β m ω p ∂haarPi N

/-- the action with the signs `η_p = (-1)^{m p}` -/
noncomputable def actionM (m : Lk N × Fin 4 → ZMod 2) (ω : Lk N → QBall) : ℝ :=
  ∑ p ∈ plaqs N, sgn (m p) * (hol N ω p).re

/-- the partition function with the signs `(-1)^{m p}` -/
noncomputable def Ztw (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) : ℝ :=
  ∫ ω, Real.exp (β * actionM N m ω) ∂haarPi N

theorem actionM_zero (ω : Lk N → QBall) : actionM N (fun _ => 0) ω = action N ω := by
  simp [actionM, action, sgn]

theorem Ztw_zero (β : ℝ) :
    Ztw N β (fun _ => 0) = ∫ ω, Real.exp (β * action N ω) ∂haarPi N := by
  simp only [Ztw, actionM_zero]

theorem sigM_mem (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2) (ω : Lk N → QBall)
    (p : Lk N × Fin 4) : 0 ≤ sigM N β m ω p ∧ sigM N β m ω p ≤ Real.exp (2 * β) - 1 := by
  have h := abs_le.mp (abs_sgn_mul_le (m p) _ (abs_hol_re N ω p))
  exact mixVar_mem β _ hβ h.1 h.2

theorem measurable_sigM (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (p : Lk N × Fin 4) :
    Measurable (fun ω => sigM N β m ω p) :=
  ((continuous_mixVar β).comp (continuous_const.mul
    (Quaternion.continuous_re.comp (continuous_hol N p)))).measurable

theorem integrable_prodM (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2)
    (X : Finset (Lk N × Fin 4)) :
    Integrable (fun ω => ∏ p ∈ X, sigM N β m ω p) (haarPi N) := by
  have := integrable_term (haarPi N) (fun _ => (1 : ℝ)) (fun p ω => sigM N β m ω p)
    (Real.exp (2 * β) - 1) measurable_const (fun p => measurable_sigM N β m p)
    (fun _ => by simp) (fun p ω => (sigM_mem N β hβ m ω p).1)
    (fun p ω => (sigM_mem N β hβ m ω p).2) X
  simpa using this

theorem ZM_nonneg (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2)
    (X : Finset (Lk N × Fin 4)) : 0 ≤ ZM N β m X :=
  integral_nonneg fun ω => prod_nonneg fun p _ => (sigM_mem N β hβ m ω p).1

theorem ZM_insert_le (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2)
    (S : Finset (Lk N × Fin 4)) (p : Lk N × Fin 4) (hp : p ∉ S) :
    ZM N β m (insert p S) ≤ (Real.exp (2 * β) - 1) * ZM N β m S := by
  unfold ZM
  rw [← integral_const_mul]
  apply integral_mono (integrable_prodM N β hβ m _) ((integrable_prodM N β hβ m S).const_mul _)
  intro ω
  simp only
  rw [prod_insert hp]
  exact mul_le_mul_of_nonneg_right (sigM_mem N β hβ m ω p).2
    (prod_nonneg fun p _ => (sigM_mem N β hβ m ω p).1)

theorem exp_actionM_eq_mix (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (ω : Lk N → QBall) :
    Real.exp (β * actionM N m ω)
      = Real.exp (-β) ^ (plaqs N).card * ∑ X ∈ (plaqs N).powerset, ∏ p ∈ X, sigM N β m ω p := by
  unfold actionM
  rw [mul_sum, Real.exp_sum]
  simp_rw [exp_eq_mix β]
  rw [prod_mul_distrib, prod_const, prod_one_add]
  rfl

theorem Ztw_eq (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2) :
    Ztw N β m = Real.exp (-β) ^ (plaqs N).card * ∑ X ∈ (plaqs N).powerset, ZM N β m X := by
  unfold Ztw
  simp_rw [exp_actionM_eq_mix N β m]
  rw [integral_const_mul, integral_finsetSum]
  · rfl
  · intro X _
    exact integrable_prodM N β hβ m X

/-! ### Centre flips change the mask by a coboundary -/

theorem hol_flip (T : Lk N → ZMod 2) (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (flipZ N T ω) p = sgn (∑ e, T e * plaqBd N p e) • hol N ω p := by
  rw [hol_eq_wordHol, hol_eq_wordHol, wordHol_flip]
  rfl

theorem sigM_flip (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (T : Lk N → ZMod 2)
    (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    sigM N β m (flipZ N T ω) p = sigM N β (fun p => m p + ∑ e, T e * plaqBd N p e) ω p := by
  unfold sigM
  rw [hol_flip, sgn_add, Quaternion.re_smul, smul_eq_mul, mul_assoc]

/-- **Gauge covariance of the weights.**  If `m' = m + δT` on `X`, then `Z^m_X = Z^{m'}_X`. -/
theorem ZM_gauge (β : ℝ) (m m' : Lk N × Fin 4 → ZMod 2) (T : Lk N → ZMod 2)
    (X : Finset (Lk N × Fin 4)) (h : ∀ p ∈ X, m p + ∑ e, T e * plaqBd N p e = m' p) :
    ZM N β m X = ZM N β m' X := by
  have key := (flipZ_preserving N T).integral_comp' (f := flipEquiv N T)
    (fun ω => ∏ p ∈ X, sigM N β m ω p)
  unfold ZM
  refine Eq.trans key.symm ?_
  apply integral_congr_ae
  filter_upwards with ω
  apply prod_congr rfl
  intro p hp
  have hω : (flipEquiv N T ω) = flipZ N T ω := rfl
  rw [hω, sigM_flip]
  simp only [sigM]
  rw [h p hp]

/-! ### Good and bad sets -/

/-- the mask `m` is a coboundary on `X` -/
def Good (m : Lk N × Fin 4 → ZMod 2) (X : Finset (Lk N × Fin 4)) : Prop :=
  ∃ T : Lk N → ZMod 2, ∀ p ∈ X, ∑ e, T e * plaqBd N p e = m p

theorem ZM_good (β : ℝ) (m : Lk N × Fin 4 → ZMod 2) (X : Finset (Lk N × Fin 4))
    (hX : Good N m X) : ZM N β m X = ZM N β (fun _ => 0) X := by
  obtain ⟨T, hT⟩ := hX
  apply ZM_gauge N β m (fun _ => 0) T X
  intro p hp
  rw [hT p hp, zmod2_add_self]

/-- the mask of the `(0,1)` plaquettes at `x₀ = a`, `x₁ = b` -/
def mask (a b : ZMod N) : Lk N × Fin 4 → ZMod 2 := fun p => if InQ N a b p then 1 else 0

/-- the twist: the mask of `D = D_{0,0}` -/
def twist : Lk N × Fin 4 → ZMod 2 := mask N 0 0

theorem good_of_shift (m m' : Lk N × Fin 4 → ZMod 2) (S : Lk N → ZMod 2)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N)
    (h : ∀ p ∈ plaqs N, m' p = m p + ∑ e, S e * plaqBd N p e) (hg : Good N m X) :
    Good N m' X := by
  obtain ⟨T, hT⟩ := hg
  refine ⟨T + S, fun p hp => ?_⟩
  simp only [Pi.add_apply, add_mul, sum_add_distrib]
  rw [hT p hp, h p (hX hp)]

theorem good_iff_of_shift (m m' : Lk N × Fin 4 → ZMod 2) (S : Lk N → ZMod 2)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N)
    (h : ∀ p ∈ plaqs N, m' p = m p + ∑ e, S e * plaqBd N p e) :
    Good N m X ↔ Good N m' X := by
  refine ⟨good_of_shift N m m' S X hX h, good_of_shift N m' m S X hX fun p hp => ?_⟩
  rw [h p hp, add_assoc, zmod2_add_self, add_zero]

/-- the direction-1 links at `x₀ = a`, `x₁ = y` (all `x₂, x₃`) -/
def colT (a y : ZMod N) : Lk N → ZMod 2 :=
  fun ℓ => if ℓ.2 = 1 ∧ ℓ.1 0 = a ∧ ℓ.1 1 = y then 1 else 0

/-- `⟨colT a y, ∂p⟩ = [p ∈ D_{a,y}] + [p ∈ D_{a-1,y}]` for `p ∈ plaqs N` -/
theorem pair_colT_plaq (a y : ZMod N) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ∑ e, colT N a y e * plaqBd N p e
      = (if InQ N a y p then 1 else 0) + (if InQ N (a - 1) y p then 1 else 0) := by
  have hlt : p.1.2 < p.2 := (Finset.mem_filter.mp hp).2
  unfold plaqBd
  rw [pair_wordBd]
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  simp only at hlt
  simp only [plaqWord, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero,
    colT, InQ]
  fin_cases μ <;> fin_cases ν <;> simp_all [ev, zmod2_add_self, eq_sub_iff_add_eq] <;>
    split_ifs <;> simp_all [eq_comm]

theorem good_mask_row (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (a : ZMod N) (k : ℕ) :
    Good N (mask N a 0) X ↔ Good N (mask N a (k : ZMod N)) X := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [ih]
    apply good_iff_of_shift N _ _ (rowT N a ((k + 1 : ℕ) : ZMod N)) X hX
    intro p hp
    rw [pair_rowT_plaq N a _ p hp]
    simp only [mask]
    have hk : ((k + 1 : ℕ) : ZMod N) - 1 = (k : ZMod N) := by push_cast; ring
    rw [hk, add_comm (if InQ N a ((k + 1 : ℕ) : ZMod N) p then (1 : ZMod 2) else 0), ← add_assoc,
      zmod2_add_self, zero_add]

theorem good_mask_col (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (b : ZMod N) (k : ℕ) :
    Good N (mask N 0 b) X ↔ Good N (mask N (k : ZMod N) b) X := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [ih]
    apply good_iff_of_shift N _ _ (colT N ((k + 1 : ℕ) : ZMod N) b) X hX
    intro p hp
    rw [pair_colT_plaq N _ b p hp]
    simp only [mask]
    have hk : ((k + 1 : ℕ) : ZMod N) - 1 = (k : ZMod N) := by push_cast; ring
    rw [hk, add_comm (if InQ N ((k + 1 : ℕ) : ZMod N) b p then (1 : ZMod 2) else 0), ← add_assoc,
      zmod2_add_self, zero_add]

/-- the twist masks of all the translates `D_{a,b}` define the same good sets -/
theorem good_twist_iff (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (a b : ZMod N) :
    Good N (twist N) X ↔ Good N (mask N a b) X := by
  unfold twist
  rw [good_mask_row N X hX 0 b.val, ZMod.natCast_zmod_val, good_mask_col N X hX b a.val,
    ZMod.natCast_zmod_val]

/-- **A bad set meets every translate `D_{a,b}`.** -/
theorem bad_meets (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) (hb : ¬ Good N (twist N) X)
    (a b : ZMod N) : ∃ p ∈ X, InQ N a b p := by
  by_contra hno
  push_neg at hno
  apply hb
  rw [good_twist_iff N X hX a b]
  refine ⟨0, fun p hp => ?_⟩
  simp [mask, hno p hp]

/-- **Area lower bound.**  A bad set has at least `N²` plaquettes. -/
theorem card_bad_ge (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N)
    (hb : ¬ Good N (twist N) X) : N * N ≤ X.card := by
  classical
  have hsub : (univ : Finset (ZMod N × ZMod N)) ⊆ X.image (fun p => (p.1.1 0, p.1.1 1)) := by
    rintro ⟨a, b⟩ _
    obtain ⟨p, hp, hq⟩ := bad_meets N X hX hb a b
    rw [mem_image]
    exact ⟨p, hp, by rw [hq.2.2.1, hq.2.2.2]⟩
  have h1 := card_le_card hsub
  rw [card_univ, Fintype.card_prod, ZMod.card] at h1
  exact h1.trans card_image_le

/-! ### Minimal bad sets -/

open Classical in
/-- the minimal bad sets of plaquettes -/
noncomputable def minBad : Finset (Finset (Lk N × Fin 4)) :=
  (plaqs N).powerset.filter (fun Y => ¬ Good N (twist N) Y ∧
    ∀ Y' ⊆ Y, ¬ Good N (twist N) Y' → Y' = Y)

theorem minBad_sub (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minBad N) :
    Y ⊆ plaqs N ∧ ¬ Good N (twist N) Y ∧ ∀ Y' ⊆ Y, ¬ Good N (twist N) Y' → Y' = Y := by
  classical
  unfold minBad at hY
  rw [mem_filter, mem_powerset] at hY
  exact ⟨hY.1, hY.2.1, hY.2.2⟩

theorem exists_minBad_subset (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N)
    (hb : ¬ Good N (twist N) X) : ∃ Y ∈ minBad N, Y ⊆ X := by
  classical
  have hne : (X.powerset.filter (fun Y => ¬ Good N (twist N) Y)).Nonempty :=
    ⟨X, mem_filter.mpr ⟨mem_powerset_self X, hb⟩⟩
  obtain ⟨Y, hY, hmin⟩ := exists_min_image _ card hne
  rw [mem_filter, mem_powerset] at hY
  refine ⟨Y, ?_, hY.1⟩
  unfold minBad
  rw [mem_filter, mem_powerset]
  refine ⟨hY.1.trans hX, hY.2, fun Y' hY' hs' => ?_⟩
  have := hmin Y' (mem_filter.mpr ⟨mem_powerset.mpr (hY'.trans hY.1), hs'⟩)
  exact eq_of_subset_of_card_le hY' this

/-- **Minimal bad sets are connected** (two parts sharing no link could be gauged separately). -/
theorem minBad_conn (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minBad N) : CutConn (nbP N) Y := by
  classical
  obtain ⟨hYP, hYb, hYmin⟩ := minBad_sub N Y hY
  intro S hSY hSne hSneq
  by_contra hno
  push_neg at hno
  -- both parts are good
  have hSg : Good N (twist N) S := by
    by_contra h; exact hSneq (hYmin S hSY h)
  have hRg : Good N (twist N) (Y \ S) := by
    by_contra h
    have := hYmin (Y \ S) sdiff_subset h
    obtain ⟨s, hs⟩ := hSne
    have hsY : s ∈ Y := hSY hs
    rw [← this, mem_sdiff] at hsY
    exact hsY.2 hs
  obtain ⟨T1, hT1⟩ := hSg
  obtain ⟨T2, hT2⟩ := hRg
  set U := S.biUnion (AreaLaw.plaqLinks N) with hU
  apply hYb
  refine ⟨fun e => if e ∈ U then T1 e else T2 e, fun p hp => ?_⟩
  by_cases hpS : p ∈ S
  · rw [← hT1 p hpS]
    apply sum_congr rfl
    intro e _
    by_cases h0 : plaqBd N p e = 0
    · simp [h0]
    · have : e ∈ U := mem_biUnion.mpr ⟨p, hpS, mem_plaqLinks_of_bd N p e h0⟩
      simp [this]
  · have hpR : p ∈ Y \ S := mem_sdiff.mpr ⟨hp, hpS⟩
    rw [← hT2 p hpR]
    apply sum_congr rfl
    intro e _
    by_cases h0 : plaqBd N p e = 0
    · simp [h0]
    · have hne : e ∉ U := by
        intro heU
        obtain ⟨a, ha, hea⟩ := mem_biUnion.mp heU
        apply hno a ha p hpR
        simp only [nbP, mem_filter, mem_univ, true_and]
        exact ⟨e, hea, mem_plaqLinks_of_bd N p e h0⟩
      simp [hne]

/-! ### Counting -/

/-- the twist plaquettes `D` -/
def twistSet : Finset (Lk N × Fin 4) := univ.filter (InQ N 0 0)

theorem card_twistSet_le : (twistSet N).card ≤ N * N := by
  classical
  have h := card_le_card_of_injOn (fun p : Lk N × Fin 4 => (p.1.1 2, p.1.1 3))
    (s := twistSet N) (t := (univ : Finset (ZMod N × ZMod N))) (fun _ _ => by simp) ?_
  · rwa [card_univ, Fintype.card_prod, ZMod.card] at h
  · intro p hp p' hp' hpp
    simp only [twistSet, coe_filter, mem_univ, true_and, Set.mem_setOf_eq, InQ] at hp hp'
    simp only [Prod.mk.injEq] at hpp
    obtain ⟨⟨x, μ⟩, ν⟩ := p
    obtain ⟨⟨x', μ'⟩, ν'⟩ := p'
    simp only at hp hp' hpp
    have hx : x = x' := by
      funext k
      fin_cases k
      · simp [hp.2.2.1, hp'.2.2.1]
      · simp [hp.2.2.2, hp'.2.2.2]
      · exact hpp.1
      · exact hpp.2
    rw [hx, hp.1, hp'.1, hp.2.1, hp'.2.1]

open Classical in
/-- **Counting.**  For `x ≥ 0`, with `M = #plaqs`,
`∑_{Y minimal bad} x^{|Y|} ≤ N² ∑_{n ∈ [N², M]} 4096^{n-1} x^n`. -/
theorem sum_minBad_le (x : ℝ) (hx : 0 ≤ x) :
    ∑ Y ∈ minBad N, x ^ Y.card
      ≤ (N * N : ℕ) * ∑ n ∈ Ico (N * N) ((plaqs N).card + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
  set F := minBad N with hF
  set A := N * N with hA
  set M := (plaqs N).card with hM
  have hN1 : 1 ≤ N := Nat.one_le_iff_ne_zero.mpr (NeZero.ne N)
  have hA1 : 1 ≤ A := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne N) (NeZero.ne N))
  -- step 1: roots in `D`
  have h1 : ∑ Y ∈ F, x ^ Y.card ≤ ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
    calc ∑ Y ∈ F, x ^ Y.card
        ≤ ∑ Y ∈ F, ∑ r ∈ twistSet N, (if r ∈ Y then x ^ Y.card else 0) := by
          apply sum_le_sum
          intro Y hY
          obtain ⟨hYP, hYb, -⟩ := minBad_sub N Y hY
          obtain ⟨p, hp, hpq⟩ := bad_meets N Y hYP hYb 0 0
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => x ^ Y.card) (fun _ _ => pow_nonneg hx _)
            (mem_filter.mpr ⟨by simp [twistSet, hpq], hp⟩)
      _ = ∑ r ∈ twistSet N, ∑ Y ∈ F, (if r ∈ Y then x ^ Y.card else 0) := sum_comm
      _ = ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := by
          apply sum_congr rfl; intro r _; rw [sum_filter]
  -- step 2: for one root, sort by size
  have h2 : ∀ r, ∑ Y ∈ F with r ∈ Y, x ^ Y.card
      ≤ ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
    intro r
    have hmaps : ∀ Y ∈ F.filter (fun Y => r ∈ Y), Y.card ∈ Ico A (M + 1) := by
      intro Y hY
      have hYF := (mem_filter.mp hY).1
      obtain ⟨hYP, hYb, -⟩ := minBad_sub N Y hYF
      rw [mem_Ico]
      exact ⟨card_bad_ge N Y hYP hYb, Nat.lt_succ_of_le (card_le_card hYP)⟩
    rw [← sum_fiberwise_of_maps_to hmaps]
    apply sum_le_sum
    intro n hn
    have hnA : A ≤ n := (mem_Ico.mp hn).1
    have hcongr : ∑ Y ∈ F.filter (fun Y => r ∈ Y) with Y.card = n, x ^ Y.card
        = ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)).card * x ^ n := by
      rw [sum_congr rfl (fun Y hY => by rw [(mem_filter.mp hY).2]), sum_const, nsmul_eq_mul]
    rw [hcongr]
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hx _)
    have hcount := card_conn_le (nbP N) (nbP_symm N) 64 (card_nbP_le N) r n (by omega)
      ((F.filter (fun Y => r ∈ Y)).filter (fun Y => Y.card = n)) (by
        intro Y hY
        rw [mem_filter, mem_filter] at hY
        exact ⟨hY.1.2, hY.2, minBad_conn N Y hY.1.1⟩)
    have h64 : (64 : ℕ) ^ (2 * (n - 1)) = 4096 ^ (n - 1) := by
      rw [pow_mul]; norm_num
    rw [h64] at hcount
    exact_mod_cast hcount
  have hsum0 : 0 ≤ ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n :=
    sum_nonneg fun n _ => mul_nonneg (pow_nonneg (by norm_num) _) (pow_nonneg hx _)
  calc ∑ Y ∈ F, x ^ Y.card
      ≤ ∑ r ∈ twistSet N, ∑ Y ∈ F with r ∈ Y, x ^ Y.card := h1
    _ ≤ ∑ _r ∈ twistSet N, ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n :=
        sum_le_sum fun r _ => h2 r
    _ = (twistSet N).card * ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
        rw [sum_const, nsmul_eq_mul]
    _ ≤ (A : ℕ) * ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n := by
        apply mul_le_mul_of_nonneg_right _ hsum0
        exact_mod_cast card_twistSet_le N

/-! ### The floor -/

open Classical in
/-- the bad sets carry the whole difference; each class is dominated by the minimal bad sets -/
theorem sum_bad_le (β : ℝ) (hβ : 0 ≤ β) (m : Lk N × Fin 4 → ZMod 2) :
    ∑ X ∈ (plaqs N).powerset with ¬ Good N (twist N) X, ZM N β m X
      ≤ (∑ Y ∈ minBad N, (1 - Real.exp (-2 * β)) ^ Y.card)
          * ∑ X ∈ (plaqs N).powerset, ZM N β m X := by
  set t := Real.exp (2 * β) - 1 with ht_def
  have ht : 0 ≤ t := by
    have := Real.one_le_exp (by linarith : (0:ℝ) ≤ 2 * β)
    linarith
  set pw := (plaqs N).powerset
  have h4 : ∑ X ∈ pw with ¬ Good N (twist N) X, ZM N β m X
      ≤ ∑ Y ∈ minBad N, ∑ X ∈ pw with Y ⊆ X, ZM N β m X := by
    calc ∑ X ∈ pw with ¬ Good N (twist N) X, ZM N β m X
        ≤ ∑ X ∈ pw with ¬ Good N (twist N) X,
            ∑ Y ∈ minBad N, (if Y ⊆ X then ZM N β m X else 0) := by
          apply sum_le_sum
          intro X hX
          rw [mem_filter, mem_powerset] at hX
          obtain ⟨Y, hY, hYX⟩ := exists_minBad_subset N X hX.1 hX.2
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => ZM N β m X) (fun _ _ => ZM_nonneg N β hβ m X)
            (mem_filter.mpr ⟨hY, hYX⟩)
      _ = ∑ Y ∈ minBad N, ∑ X ∈ pw with ¬ Good N (twist N) X,
            (if Y ⊆ X then ZM N β m X else 0) := sum_comm
      _ ≤ ∑ Y ∈ minBad N, ∑ X ∈ pw, (if Y ⊆ X then ZM N β m X else 0) := by
          apply sum_le_sum
          intro Y _
          apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
          intro X _ _
          split_ifs
          · exact ZM_nonneg N β hβ m X
          · exact le_refl 0
      _ = ∑ Y ∈ minBad N, ∑ X ∈ pw with Y ⊆ X, ZM N β m X := by
          apply sum_congr rfl
          intro Y _
          rw [sum_filter]
  have h5 : ∀ Y ∈ minBad N,
      ∑ X ∈ pw with Y ⊆ X, ZM N β m X ≤ (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZM N β m X :=
    fun Y hY => sum_superset_le_in (plaqs N) (ZM N β m) t ht
      (fun S _ p _ hp => ZM_insert_le N β hβ m S p hp) Y (minBad_sub N Y hY).1
  rw [q_eq β] at h5
  rw [sum_mul]
  exact h4.trans (sum_le_sum h5)

open Classical in
/-- **The twisted and untwisted partition functions (mixture form).**  For `β ≥ 0`,
`|Z₀ - Z₁| ≤ (Σ_{Y minimal bad} q^{|Y|}) (Z₀ + Z₁)`, `q = 1 - e^{-2β}`. -/
theorem abs_Z_sub_le (β : ℝ) (hβ : 0 ≤ β) :
    |Ztw N β (fun _ => 0) - Ztw N β (twist N)|
      ≤ (∑ Y ∈ minBad N, (1 - Real.exp (-2 * β)) ^ Y.card)
          * (Ztw N β (fun _ => 0) + Ztw N β (twist N)) := by
  set c := Real.exp (-β) ^ (plaqs N).card with hc_def
  have hc : 0 ≤ c := pow_nonneg (Real.exp_pos _).le _
  set pw := (plaqs N).powerset
  set G := fun X => Good N (twist N) X
  set S := ∑ Y ∈ minBad N, (1 - Real.exp (-2 * β)) ^ Y.card
  rw [Ztw_eq N β hβ, Ztw_eq N β hβ]
  have hdiff : ∑ X ∈ pw, ZM N β (fun _ => 0) X - ∑ X ∈ pw, ZM N β (twist N) X
      = ∑ X ∈ pw with ¬ G X, (ZM N β (fun _ => 0) X - ZM N β (twist N) X) := by
    rw [← sum_sub_distrib, ← sum_filter_add_sum_filter_not pw G]
    have : ∑ X ∈ pw with G X, (ZM N β (fun _ => 0) X - ZM N β (twist N) X) = 0 := by
      apply sum_eq_zero
      intro X hX
      rw [mem_filter] at hX
      rw [ZM_good N β (twist N) X hX.2, sub_self]
    rw [this, zero_add]
  have habs : |∑ X ∈ pw with ¬ G X, (ZM N β (fun _ => 0) X - ZM N β (twist N) X)|
      ≤ ∑ X ∈ pw with ¬ G X, ZM N β (fun _ => 0) X + ∑ X ∈ pw with ¬ G X, ZM N β (twist N) X := by
    rw [← sum_add_distrib]
    refine (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun X _ => ?_)
    have h0 := ZM_nonneg N β hβ (fun _ => 0) X
    have h1 := ZM_nonneg N β hβ (twist N) X
    rw [abs_le]; constructor <;> linarith
  have hb0 := sum_bad_le N β hβ (fun _ => 0)
  have hb1 := sum_bad_le N β hβ (twist N)
  rw [← mul_sub, hdiff, abs_mul, abs_of_nonneg hc]
  calc c * |∑ X ∈ pw with ¬ G X, (ZM N β (fun _ => 0) X - ZM N β (twist N) X)|
      ≤ c * (S * ∑ X ∈ pw, ZM N β (fun _ => 0) X + S * ∑ X ∈ pw, ZM N β (twist N) X) :=
        mul_le_mul_of_nonneg_left (habs.trans (add_le_add hb0 hb1)) hc
    _ = S * (c * ∑ X ∈ pw, ZM N β (fun _ => 0) X + c * ∑ X ∈ pw, ZM N β (twist N) X) := by
        ring

/-- **Vortex floor at strong coupling, uniform in `N`.**  SU(2) on `(ℤ/N)⁴`.  For `β ≥ 0` with
`4096 (1 - e^{-2β}) < 1`, the untwisted partition function `Z₀` and the partition function `Z₁`
with the centre twist on the `N²` plaquettes `D` satisfy
`|Z₀ - Z₁| ≤ N² (4096 q)^{N²} / (4096 (1 - 4096 q)) · (Z₀ + Z₁)`, `q = 1 - e^{-2β}`. -/
theorem vortex_floor (β : ℝ) (hβ : 0 ≤ β) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    |Ztw N β (fun _ => 0) - Ztw N β (twist N)|
      ≤ (N * N : ℕ) * ((4096 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β)))))
          * (Ztw N β (fun _ => 0) + Ztw N β (twist N)) := by
  classical
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hA1 : 1 ≤ N * N := Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero (NeZero.ne N) (NeZero.ne N))
  have hZ0 : 0 ≤ Ztw N β (fun _ => 0) := integral_nonneg fun _ => (Real.exp_pos _).le
  have hZ1 : 0 ≤ Ztw N β (twist N) := integral_nonneg fun _ => (Real.exp_pos _).le
  refine (abs_Z_sub_le N β hβ).trans (mul_le_mul_of_nonneg_right ?_ (by linarith))
  refine (sum_minBad_le N _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by positivity)
  exact tail_le _ _ hA1 _ hq0 hK

/-- arithmetic: `|a - b| ≤ ε (a + b)` with `0 ≤ ε < 1` gives `|a - b| ≤ 2ε/(1-ε) · a` -/
lemma abs_sub_le_rel (a b ε : ℝ) (hε0 : 0 ≤ ε) (hε1 : ε < 1)
    (hd : |a - b| ≤ ε * (a + b)) : |a - b| ≤ 2 * ε / (1 - ε) * a := by
  have h1 : 0 < 1 - ε := by linarith
  have hab := abs_le.mp hd
  rw [div_mul_eq_mul_div, le_div_iff₀ h1]
  have h2 : (a + b) * (1 - ε) ≤ 2 * a := by nlinarith [hab.1]
  calc |a - b| * (1 - ε) ≤ ε * (a + b) * (1 - ε) := mul_le_mul_of_nonneg_right hd h1.le
    _ = ε * ((a + b) * (1 - ε)) := by ring
    _ ≤ ε * (2 * a) := mul_le_mul_of_nonneg_left h2 hε0
    _ = 2 * ε * a := by ring

/-- **Vortex floor relative to `Z₀`.**  With `ε = N² (4096 q)^{N²} / (4096 (1 - 4096 q))` and
`ε < 1`: `|Z₀ - Z₁| ≤ 2ε/(1-ε) · Z₀`. -/
theorem vortex_floor_rel (β : ℝ) (hβ : 0 ≤ β) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1)
    (hε : (N * N : ℕ) * ((4096 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) < 1) :
    |Ztw N β (fun _ => 0) - Ztw N β (twist N)|
      ≤ 2 * ((N * N : ℕ) * ((4096 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))))
        / (1 - (N * N : ℕ) * ((4096 * (1 - Real.exp (-2 * β))) ^ (N * N)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))))
        * Ztw N β (fun _ => 0) := by
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hden : 0 < 4096 * (1 - 4096 * (1 - Real.exp (-2 * β))) := by linarith
  apply abs_sub_le_rel _ _ _ (by positivity) hε (vortex_floor N β hβ hK)

/-! ### Sanity -/

/-- Sanity: the twist is not empty: the plaquette `((0,0),1)` at the origin is in `D` and in
`plaqs N`. -/
theorem sanity_twist_nonempty : ((0, 0), 1) ∈ twistSet N ∧ ((0, 0), (1 : Fin 4)) ∈ plaqs N := by
  constructor
  · simp [twistSet, InQ]
  · simp [plaqs]

/-- Sanity: with no twist every set is good (the statement is about the twist, not automatic). -/
theorem sanity_zero_good (X : Finset (Lk N × Fin 4)) : Good N (fun _ => 0) X :=
  ⟨0, fun p _ => by simp⟩

/-- Sanity: the empty set is good for the twist (so `minBad` does not contain `∅`). -/
theorem sanity_empty_good : Good N (twist N) ∅ := ⟨0, fun p hp => by simp at hp⟩

lemma small_floor_aux (q : ℝ) (hq0 : 0 ≤ q) (hqs : 4096 * q ≤ 1 / 10) :
    ((2 * 2 : ℕ) : ℝ) * ((4096 * q) ^ (2 * 2) / (4096 * (1 - 4096 * q))) < 1 := by
  have hden : 0 < 4096 * (1 - 4096 * q) := by linarith
  have hp : (4096 * q) ^ (2 * 2) ≤ (1 / 10) ^ (2 * 2) :=
    pow_le_pow_left₀ (by positivity) hqs _
  have h4 : ((1 : ℝ) / 10) ^ (2 * 2) = 1 / 10000 := by norm_num
  rw [h4] at hp
  rw [mul_div_assoc', div_lt_one hden]
  generalize (4096 * q) ^ (2 * 2) = X at hp ⊢
  push_cast
  nlinarith

/-- Sanity (the bound is nontrivial): at `β = 1/100000` and `N = 2` the factor in front of
`Z₀ + Z₁` is below `1`. -/
theorem sanity_floor_small :
    ((2 * 2 : ℕ) : ℝ) * ((4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ)))) ^ (2 * 2)
      / (4096 * (1 - 4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ)))))) < 1 := by
  have h1 := Real.add_one_le_exp (-2 * (1 / 100000 : ℝ))
  have h2 := Real.exp_le_one_iff.mpr (by norm_num : -2 * (1 / 100000 : ℝ) ≤ 0)
  exact small_floor_aux _ (by linarith) (by linarith)

end VortexStrong

#print axioms VortexStrong.ZM_gauge
#print axioms VortexStrong.minBad_conn
#print axioms VortexStrong.card_bad_ge
#print axioms VortexStrong.sum_minBad_le
#print axioms VortexStrong.abs_Z_sub_le
#print axioms VortexStrong.vortex_floor
#print axioms VortexStrong.vortex_floor_rel
#print axioms VortexStrong.sanity_twist_nonempty
#print axioms VortexStrong.sanity_floor_small
