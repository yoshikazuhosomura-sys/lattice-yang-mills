import Area.ConnRectV1

/-!
# Area law for the Wilson loop at strong coupling (SU(2), `(ℤ/N)⁴`)

Paper correspondence: the statement of §1 of the strong-coupling area-law note
(Osterwalder–Seiler type; no novelty claimed): for the boundary `C` of the `R × T` rectangle
in the `(0,1)` plane, `1 ≤ R < N`, `1 ≤ T < N`, with `q = 1 - e^{-2β}` and `K = 4096`
(`= 64²`, `64` bounding the number of plaquettes sharing a link with a given one),
whenever `β ≥ 0` and `K q < 1`,

  `|⟨Re W(C)⟩_β| ≤ 16 (K q)^{R · min(T, N - T)} / (K (1 - K q))`,

for the normalised Wilson measure `TorusRP.wilsonMeasure N β`.  For `2T ≤ N` the exponent is
the area `R T`; the constant does not depend on `N`.
-/

open MeasureTheory Finset TorusRP

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-- the geometric tail -/
theorem tail_le (A M : ℕ) (hA : 1 ≤ A) (x : ℝ) (hx : 0 ≤ x) (hKx : 4096 * x < 1) :
    ∑ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n
      ≤ (4096 * x) ^ A / (4096 * (1 - 4096 * x)) := by
  have hterm : ∀ n ∈ Ico A (M + 1), (4096 : ℝ) ^ (n - 1) * x ^ n = (4096 * x) ^ n / 4096 := by
    intro n hn
    have hn1 : 1 ≤ n := le_trans hA (mem_Ico.mp hn).1
    rw [mul_pow, eq_div_iff (by norm_num : (4096 : ℝ) ≠ 0)]
    have : (4096 : ℝ) ^ n = 4096 ^ (n - 1) * 4096 := by
      rw [← pow_succ, Nat.sub_add_cancel hn1]
    rw [this]; ring
  rw [sum_congr rfl hterm, ← sum_div]
  have hg := geom_sum_Ico_le_of_lt_one (m := A) (n := M + 1) (by positivity : 0 ≤ 4096 * x) hKx
  have h1 : 0 < 1 - 4096 * x := by linarith
  rw [div_le_div_iff₀ (by norm_num) (by positivity)]
  calc (∑ i ∈ Ico A (M + 1), (4096 * x) ^ i) * (4096 * (1 - 4096 * x))
      ≤ (4096 * x) ^ A / (1 - 4096 * x) * (4096 * (1 - 4096 * x)) :=
        mul_le_mul_of_nonneg_right hg (by positivity)
    _ = (4096 * x) ^ A * 4096 := by field_simp

open Classical in
/-- **Area law (finite volume, expectation as a ratio of product-Haar integrals).** -/
theorem area_law_wordExpect (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (hT : T < N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    |wordExpect N β (rectWord N R T)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * min T (N - T))
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  refine (abs_wordExpect_le N β hβ (rectWord N R T)).trans ?_
  refine (sum_minSpan_rect_le N R T hR1 hT1 hR hT _ hq0).trans ?_
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  exact tail_le _ _ (Nat.mul_le_mul hR1 (le_min hT1 (by omega))) _ hq0 hK

/-- **Area law at strong coupling for the Wilson measure.**  For `β ≥ 0` with
`4096 (1 - e^{-2β}) < 1`, `1 ≤ R < N`, `1 ≤ T < N`, under the normalised Wilson measure on
`(ℤ/N)⁴`,
`|⟨Re W(∂(R×T))⟩| ≤ 16 (4096 q)^{R·min(T, N-T)} / (4096 (1 - 4096 q))`, `q = 1 - e^{-2β}`. -/
theorem area_law_wilson (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (hT : T < N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * min T (N - T))
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  rw [← wordExpect_eq_wilson]
  exact area_law_wordExpect N β hβ R T hR1 hT1 hR hT hK

/-- **Area law, `2T ≤ N`**: the exponent is the area `R T`. -/
theorem area_law_wilson_area (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (h2T : 2 * T ≤ N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1) :
    |(∫ ω, (wordHol N ω (rectWord N R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * T)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have h := area_law_wilson N β hβ R T hR1 hT1 hR (by omega) hK
  rwa [min_eq_left (by omega : T ≤ N - T)] at h

/-- Sanity: the coupling window is not empty: `β = 1/100000` satisfies `β ≥ 0` and
`4096 (1 - e^{-2β}) < 1`. -/
theorem sanity_window : (0 : ℝ) ≤ 1 / 100000 ∧ 4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ))) < 1 := by
  refine ⟨by norm_num, ?_⟩
  have h := Real.add_one_le_exp (-2 * (1 / 100000 : ℝ))
  nlinarith

/-- Sanity: the lattice hypotheses are met, e.g. `N = 8`, `R = T = 3` (`2T ≤ N`, exponent `9`). -/
theorem sanity_rect_dims : 1 ≤ (3 : ℕ) ∧ (3 : ℕ) < 8 ∧ 2 * 3 ≤ (8 : ℕ) := by
  refine ⟨by norm_num, by norm_num, by norm_num⟩

lemma small_bound_aux (q : ℝ) (hq0 : 0 ≤ q) (hqs : 4096 * q ≤ 1 / 10) :
    16 * ((4096 * q) ^ (3 * 3) / (4096 * (1 - 4096 * q))) < 1 := by
  have hden : 0 < 4096 * (1 - 4096 * q) := by linarith
  have hp : (4096 * q) ^ (3 * 3) ≤ (1 / 10) ^ (3 * 3) :=
    pow_le_pow_left₀ (by positivity) hqs _
  have h9 : ((1 : ℝ) / 10) ^ (3 * 3) = 1 / 1000000000 := by norm_num
  rw [h9] at hp
  rw [mul_div_assoc', div_lt_one hden]
  generalize (4096 * q) ^ (3 * 3) = X at hp ⊢
  nlinarith

/-- Sanity (the bound is nontrivial): at `β = 1/100000` and `R = T = 3`, the right side is
below `1`. -/
theorem sanity_bound_small :
    16 * ((4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ)))) ^ (3 * 3)
      / (4096 * (1 - 4096 * (1 - Real.exp (-2 * (1 / 100000 : ℝ)))))) < 1 := by
  have h1 := Real.add_one_le_exp (-2 * (1 / 100000 : ℝ))
  have h2 := Real.exp_le_one_iff.mpr (by norm_num : -2 * (1 / 100000 : ℝ) ≤ 0)
  exact small_bound_aux _ (by linarith) (by linarith)

end AreaLaw

#print axioms AreaLaw.area_law_wilson
#print axioms AreaLaw.area_law_wilson_area
#print axioms AreaLaw.sanity_window
#print axioms AreaLaw.sanity_bound_small
