import Area.VortexStrongV1

/-!
# Sanity for the strong-coupling vortex floor: the twist is not a coboundary

The `(0,1)` plane at `x₂ = x₃ = 0` (`N²` plaquettes) is a closed mod-2 surface meeting the twist
set `D` in exactly one plaquette, so it is a *bad* set: the twist mask is not a coboundary on it.
Hence the family of minimal bad sets in `VortexStrong.vortex_floor` is not empty for any `N ≥ 1`
(the bound is not obtained by an empty sum), and its smallest possible size `N²` is attained.
-/

open MeasureTheory Finset TorusRP OSGap AreaLaw

namespace VortexStrong

variable (N : ℕ) [NeZero N]

/-- the site `(a, b, 0, 0)` -/
def ptab (a b : ZMod N) : Site N := ![a, b, 0, 0]

/-- the `(0,1)` plaquette at `(a, b, 0, 0)` -/
def planePlaq (ab : ZMod N × ZMod N) : Lk N × Fin 4 := ((ptab N ab.1 ab.2, 0), 1)

/-- the `(0,1)` plane at `x₂ = x₃ = 0` -/
def planeSet : Finset (Lk N × Fin 4) := univ.image (planePlaq N)

theorem planeSet_sub : planeSet N ⊆ plaqs N := by
  intro p hp
  obtain ⟨ab, -, rfl⟩ := mem_image.mp hp
  simp [plaqs, planePlaq]

theorem pair_planePlaq (T : Lk N → ZMod 2) (ab : ZMod N × ZMod N) :
    ∑ e, T e * plaqBd N (planePlaq N ab) e
      = T (ptab N ab.1 ab.2, 0) + T (ptab N (ab.1 + 1) ab.2, 1)
        + T (ptab N ab.1 (ab.2 + 1), 0) + T (ptab N ab.1 ab.2, 1) := by
  unfold plaqBd
  rw [pair_wordBd]
  have e0 : ptab N ab.1 ab.2 + ev N 0 = ptab N (ab.1 + 1) ab.2 := by
    funext k; fin_cases k <;> simp [ptab, ev]
  have e1 : ptab N ab.1 ab.2 + ev N 1 = ptab N ab.1 (ab.2 + 1) := by
    funext k; fin_cases k <;> simp [ptab, ev]
  simp only [planePlaq, plaqWord, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil,
    add_zero, e0, e1]
  ring

theorem twist_planePlaq (ab : ZMod N × ZMod N) :
    twist N (planePlaq N ab) = if ab = (0, 0) then 1 else 0 := by
  obtain ⟨a, b⟩ := ab
  simp [twist, mask, InQ, planePlaq, ptab, Prod.ext_iff]

/-- **The plane is bad**: no link set `T` has `⟨T, ∂p⟩ = [p ∈ D]` on the whole plane. -/
theorem plane_bad : ¬ Good N (twist N) (planeSet N) := by
  rintro ⟨T, hT⟩
  have hsum : ∑ ab : ZMod N × ZMod N, ∑ e, T e * plaqBd N (planePlaq N ab) e
      = ∑ ab : ZMod N × ZMod N, twist N (planePlaq N ab) :=
    Fintype.sum_congr _ _ fun ab => hT _ (mem_image.mpr ⟨ab, mem_univ _, rfl⟩)
  have hR : ∑ ab : ZMod N × ZMod N, twist N (planePlaq N ab) = 1 := by
    simp only [twist_planePlaq]
    simp
  have hs0 : ∑ ab : ZMod N × ZMod N, T (ptab N (ab.1 + 1) ab.2, 1)
      = ∑ ab : ZMod N × ZMod N, T (ptab N ab.1 ab.2, 1) :=
    Fintype.sum_equiv ((Equiv.addRight 1).prodCongr (Equiv.refl _)) _ _ (fun ab => rfl)
  have hs1 : ∑ ab : ZMod N × ZMod N, T (ptab N ab.1 (ab.2 + 1), 0)
      = ∑ ab : ZMod N × ZMod N, T (ptab N ab.1 ab.2, 0) :=
    Fintype.sum_equiv ((Equiv.refl _).prodCongr (Equiv.addRight 1)) _ _ (fun ab => rfl)
  have hL : ∑ ab : ZMod N × ZMod N, ∑ e, T e * plaqBd N (planePlaq N ab) e = 0 := by
    simp only [pair_planePlaq, sum_add_distrib, hs0, hs1]
    set A := ∑ ab : ZMod N × ZMod N, T (ptab N ab.1 ab.2, 0)
    set B := ∑ ab : ZMod N × ZMod N, T (ptab N ab.1 ab.2, 1)
    calc A + B + A + B = (A + A) + (B + B) := by ring
      _ = 0 := by rw [zmod2_add_self, zmod2_add_self, add_zero]
  rw [hL, hR] at hsum
  exact zero_ne_one hsum

/-- Sanity: the family of minimal bad sets is not empty. -/
theorem minBad_nonempty : (minBad N).Nonempty := by
  obtain ⟨Y, hY, -⟩ := exists_minBad_subset N (planeSet N) (planeSet_sub N) (plane_bad N)
  exact ⟨Y, hY⟩

/-- Sanity: the plane has exactly `N²` plaquettes (the lower bound `card_bad_ge` is attained). -/
theorem card_planeSet : (planeSet N).card = N * N := by
  unfold planeSet
  rw [card_image_of_injective _ ?_, card_univ, Fintype.card_prod, ZMod.card]
  intro ab ab' h
  have h0 := congrArg (fun p : Lk N × Fin 4 => p.1.1 0) h
  have h1 := congrArg (fun p : Lk N × Fin 4 => p.1.1 1) h
  simp only [planePlaq, ptab] at h0 h1
  exact Prod.ext (by simpa using h0) (by simpa using h1)

end VortexStrong

#print axioms VortexStrong.plane_bad
#print axioms VortexStrong.minBad_nonempty
#print axioms VortexStrong.card_planeSet
