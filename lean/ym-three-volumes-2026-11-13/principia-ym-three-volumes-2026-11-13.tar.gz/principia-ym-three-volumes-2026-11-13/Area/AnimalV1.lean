import Mathlib

/-!
# Counting rooted connected sets by closed walks (step 7, abstract)

In a graph on `α` given by neighbour sets `nb a` (symmetric), with every `nb a` of size at
most `Δ`, a finite set `Y` that is connected in the cut sense (every proper nonempty
`S ⊆ Y` has an edge from `S` to `Y \ S`) and contains `r`, with `|Y| = n ≥ 1`, is the vertex
set of a closed walk of length `2(n-1)` from `r` (grow the walk by detours `a → b → a`).
Hence the number of such sets is at most `Δ^{2(n-1)}`.
Paper correspondence: step 7 of the strong-coupling area-law argument (the lattice-animal
bound).
-/

open Finset

namespace AreaLaw

variable {α : Type*} [DecidableEq α]

/-- walks of length `L` ending at `r`, stored with the current end at the head -/
def walksRev (nb : α → Finset α) (r : α) : ℕ → Finset (List α)
  | 0 => {[r]}
  | L + 1 => (walksRev nb r L).biUnion (fun w => (nb (w.headD r)).image (fun b => b :: w))

theorem card_walksRev_le (nb : α → Finset α) (Δ : ℕ) (hΔ : ∀ a, (nb a).card ≤ Δ) (r : α) :
    ∀ L, (walksRev nb r L).card ≤ Δ ^ L := by
  intro L
  induction L with
  | zero => simp [walksRev]
  | succ L ih =>
    simp only [walksRev]
    refine card_biUnion_le.trans ?_
    calc ∑ w ∈ walksRev nb r L, ((nb (w.headD r)).image (fun b => b :: w)).card
        ≤ ∑ _w ∈ walksRev nb r L, Δ := sum_le_sum fun w _ => card_image_le.trans (hΔ _)
      _ = (walksRev nb r L).card * Δ := by rw [sum_const, smul_eq_mul]
      _ ≤ Δ ^ L * Δ := Nat.mul_le_mul_right _ ih
      _ = Δ ^ (L + 1) := by rw [pow_succ]

/-- a walk of length `L` ending at `r` (head = current end) -/
def IsWalk (nb : α → Finset α) (r : α) (L : ℕ) (w : List α) : Prop :=
  w.length = L + 1 ∧ w.getLast? = some r ∧ List.IsChain (fun x y => x ∈ nb y) w

theorem mem_walksRev (nb : α → Finset α) (r : α) :
    ∀ L w, IsWalk nb r L w → w ∈ walksRev nb r L := by
  intro L
  induction L with
  | zero =>
    intro w ⟨hl, hlast, _⟩
    match w, hl with
    | [x], _ =>
      simp only [List.getLast?_singleton, Option.some.injEq] at hlast
      simp [walksRev, hlast]
  | succ L ih =>
    intro w ⟨hl, hlast, hc⟩
    match w, hl with
    | b :: w', hl' =>
      have hlen : w'.length = L + 1 := by simpa using hl'
      have hne : w' ≠ [] := by intro h; rw [h] at hlen; simp at hlen
      obtain ⟨c, w'', rfl⟩ := List.exists_cons_of_ne_nil hne
      rw [List.isChain_cons_cons] at hc
      have hw' : IsWalk nb r L (c :: w'') := by
        refine ⟨hlen, ?_, hc.2⟩
        rw [List.getLast?_cons_cons] at hlast
        exact hlast
      simp only [walksRev, mem_biUnion, mem_image]
      exact ⟨c :: w'', ih _ hw', b, by simpa using hc.1, rfl⟩

/-- cut-connectedness of `Y` -/
def CutConn (nb : α → Finset α) (Y : Finset α) : Prop :=
  ∀ S ⊆ Y, S.Nonempty → S ≠ Y → ∃ a ∈ S, ∃ b ∈ Y \ S, b ∈ nb a

/-- growing a closed walk inside a connected set -/
theorem exists_walk_grow (nb : α → Finset α) (hsymm : ∀ a b, b ∈ nb a ↔ a ∈ nb b)
    (r : α) (Y : Finset α) (hr : r ∈ Y) (hY : CutConn nb Y) :
    ∀ k, 1 ≤ k → k ≤ Y.card → ∃ w, IsWalk nb r (2 * (k - 1)) w ∧ w.toFinset ⊆ Y ∧
      w.toFinset.card = k := by
  intro k hk1
  induction k, hk1 using Nat.le_induction with
  | base =>
    intro _
    refine ⟨[r], ⟨by simp, by simp, List.isChain_singleton r⟩, by simpa using hr, by simp⟩
  | succ k hk ih =>
    intro hkY
    obtain ⟨w, ⟨hl, hlast, hc⟩, hsub, hcard⟩ := ih (by omega)
    have hne : w.toFinset.Nonempty := by
      rw [← card_pos, hcard]; omega
    have hneq : w.toFinset ≠ Y := by
      intro h; rw [h] at hcard; omega
    obtain ⟨a, ha, b, hb, hab⟩ := hY _ hsub hne hneq
    rw [mem_sdiff] at hb
    rw [List.mem_toFinset] at ha
    obtain ⟨w1, w2, rfl⟩ := List.append_of_mem ha
    refine ⟨w1 ++ a :: b :: a :: w2, ⟨?_, ?_, ?_⟩, ?_, ?_⟩
    · simp only [List.length_append, List.length_cons] at hl ⊢
      omega
    · have e1 : w1 ++ a :: b :: a :: w2 = (w1 ++ [a, b]) ++ (a :: w2) := by simp
      rw [e1, List.getLast?_append_of_ne_nil _ (List.cons_ne_nil _ _)]
      rw [List.getLast?_append_of_ne_nil _ (List.cons_ne_nil _ _)] at hlast
      exact hlast
    · rw [List.isChain_append] at hc ⊢
      obtain ⟨h1, h2, h3⟩ := hc
      refine ⟨h1, ?_, ?_⟩
      · rw [List.isChain_cons_cons, List.isChain_cons_cons]
        exact ⟨(hsymm a b).mp hab, hab, h2⟩
      · simpa using h3
    · intro x hx
      simp only [List.mem_toFinset, List.mem_append, List.mem_cons] at hx
      rcases hx with hx | hx | hx | hx | hx
      · exact hsub (by simp [hx])
      · subst hx; exact hsub (by simp)
      · subst hx; exact hb.1
      · subst hx; exact hsub (by simp)
      · exact hsub (by simp [hx])
    · have : (w1 ++ a :: b :: a :: w2).toFinset = insert b (w1 ++ a :: w2).toFinset := by
        ext x; simp only [List.mem_toFinset, List.mem_append, List.mem_cons, mem_insert]; tauto
      rw [this, card_insert_of_notMem hb.2, hcard]

/-- **Lattice-animal bound.**  The number of cut-connected sets of size `n ≥ 1` containing
`r` is at most `Δ^{2(n-1)}`. -/
theorem card_conn_le (nb : α → Finset α) (hsymm : ∀ a b, b ∈ nb a ↔ a ∈ nb b) (Δ : ℕ)
    (hΔ : ∀ a, (nb a).card ≤ Δ) (r : α) (n : ℕ) (hn : 1 ≤ n) (F : Finset (Finset α))
    (hF : ∀ Y ∈ F, r ∈ Y ∧ Y.card = n ∧ CutConn nb Y) :
    F.card ≤ Δ ^ (2 * (n - 1)) := by
  have hsub : F ⊆ (walksRev nb r (2 * (n - 1))).image List.toFinset := by
    intro Y hY
    obtain ⟨hr, hc, hconn⟩ := hF Y hY
    obtain ⟨w, hw, hws, hwc⟩ := exists_walk_grow nb hsymm r Y hr hconn n hn (by omega)
    rw [mem_image]
    exact ⟨w, mem_walksRev nb r _ w hw, eq_of_subset_of_card_le hws (by omega)⟩
  exact (card_le_card hsub).trans (card_image_le.trans (card_walksRev_le nb Δ hΔ r _))

/-- Sanity: on `Fin 3` with the complete graph (`nb a = univ`, `Δ = 3`), the whole set is
cut-connected (so the hypothesis of `card_conn_le` is met by a nontrivial family). -/
theorem sanity_complete_conn : CutConn (fun _ : Fin 3 => (univ : Finset (Fin 3))) univ := by
  intro S _ hS hne
  obtain ⟨a, ha⟩ := hS
  have : ∃ b, b ∉ S := by
    by_contra h
    push Not at h
    exact hne (eq_univ_of_forall h)
  obtain ⟨b, hb⟩ := this
  exact ⟨a, ha, b, by simp [hb], mem_univ _⟩

end AreaLaw

#print axioms AreaLaw.card_conn_le
#print axioms AreaLaw.sanity_complete_conn
