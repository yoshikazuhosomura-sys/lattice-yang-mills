import Area.FlipVanishV1
import Area.MixV1
import Area.DominanceSubV1

/-!
# The single-plaquette Wilson loop at strong coupling: bound by minimal spanning sets

Paper correspondence: steps 1–4 of the strong-coupling area-law argument
(Osterwalder–Seiler type), for the loop `C = ∂p₀` (one plaquette), on `(ℤ/N)⁴`, SU(2),
Wilson weight `exp(β Σ_{p ∈ plaqs N} Re U_p)` against the product Haar measure.

With `q = 1 - exp(-2β)` and `minSpan N p₀` the minimal sets `Y ⊆ plaqs N` of plaquettes whose
mod-2 boundaries span `∂p₀` mod 2,

  `|∫ Re U_{p₀} e^{βS} d(∏ Haar)| ≤ (∑_{Y ∈ minSpan N p₀} q^{|Y|}) · ∫ e^{βS} d(∏ Haar)`

for every `β ≥ 0` and every `N` (no other hypothesis).  The counting of minimal spanning sets
(connectedness, area lower bound) is not done here.
-/

open MeasureTheory Finset TorusRP OSGap

namespace AreaLaw

section Bound

variable (N : ℕ) [NeZero N]

/-- the product Haar measure on the link configurations -/
noncomputable abbrev haarPi : Measure (Lk N → QBall) := Measure.pi fun _ : Lk N => haarBall

/-- the mixture variable of the plaquette `p`: `σ_p = exp(β(Re U_p + 1)) - 1` -/
noncomputable def sigP (β : ℝ) (ω : Lk N → QBall) (p : Lk N × Fin 4) : ℝ :=
  mixVar β (hol N ω p).re

/-- `Z_X = ∫ ∏_{p ∈ X} σ_p d(∏ Haar)` -/
noncomputable def ZX (β : ℝ) (X : Finset (Lk N × Fin 4)) : ℝ :=
  ∫ ω, ∏ p ∈ X, sigP N β ω p ∂haarPi N

/-- `X` spans the boundary of `p₀` mod 2 -/
def Spans (p₀ : Lk N × Fin 4) (X : Finset (Lk N × Fin 4)) : Prop :=
  plaqBd N p₀ ∈ Submodule.span (ZMod 2) ((plaqBd N) '' (X : Set (Lk N × Fin 4)))

open Classical in
/-- the minimal spanning sets of plaquettes -/
noncomputable def minSpan (p₀ : Lk N × Fin 4) : Finset (Finset (Lk N × Fin 4)) :=
  (plaqs N).powerset.filter (fun Y => Spans N p₀ Y ∧ ∀ Y' ⊆ Y, Spans N p₀ Y' → Y' = Y)

theorem continuous_mixVar (β : ℝ) : Continuous (mixVar β) := by
  unfold mixVar
  exact (Real.continuous_exp.comp (continuous_const.mul (continuous_id.add continuous_const))).sub
    continuous_const

theorem measurable_sigP (β : ℝ) (p : Lk N × Fin 4) : Measurable (fun ω => sigP N β ω p) :=
  ((continuous_mixVar β).comp (Quaternion.continuous_re.comp (continuous_hol N p))).measurable

theorem sigP_mem (β : ℝ) (hβ : 0 ≤ β) (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    0 ≤ sigP N β ω p ∧ sigP N β ω p ≤ Real.exp (2 * β) - 1 := by
  have h := abs_le.mp (abs_hol_re N ω p)
  exact mixVar_mem β _ hβ h.1 h.2

theorem integrable_W_prod (β : ℝ) (hβ : 0 ≤ β) (f : (Lk N → QBall) → ℝ) (hf : Measurable f)
    (hf1 : ∀ ω, |f ω| ≤ 1) (X : Finset (Lk N × Fin 4)) :
    Integrable (fun ω => f ω * ∏ p ∈ X, sigP N β ω p) (haarPi N) :=
  integrable_term (haarPi N) f (fun p ω => sigP N β ω p) (Real.exp (2 * β) - 1) hf
    (fun p => measurable_sigP N β p) hf1 (fun p ω => (sigP_mem N β hβ ω p).1)
    (fun p ω => (sigP_mem N β hβ ω p).2) X

theorem integrable_prod (β : ℝ) (hβ : 0 ≤ β) (X : Finset (Lk N × Fin 4)) :
    Integrable (fun ω => ∏ p ∈ X, sigP N β ω p) (haarPi N) := by
  have := integrable_W_prod N β hβ (fun _ => 1) measurable_const (fun _ => by simp) X
  simpa using this

theorem ZX_nonneg (β : ℝ) (hβ : 0 ≤ β) (X : Finset (Lk N × Fin 4)) : 0 ≤ ZX N β X :=
  integral_nonneg fun ω => prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1

/-- one more plaquette costs at most `t = e^{2β} - 1` -/
theorem ZX_insert_le (β : ℝ) (hβ : 0 ≤ β) (S : Finset (Lk N × Fin 4)) (p : Lk N × Fin 4)
    (hp : p ∉ S) : ZX N β (insert p S) ≤ (Real.exp (2 * β) - 1) * ZX N β S := by
  unfold ZX
  rw [← integral_const_mul]
  apply integral_mono (integrable_prod N β hβ _) ((integrable_prod N β hβ S).const_mul _)
  intro ω
  simp only
  rw [prod_insert hp]
  exact mul_le_mul_of_nonneg_right (sigP_mem N β hβ ω p).2
    (prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1)

/-- the Wilson weight as a positive mixture over the subsets of `plaqs N` -/
theorem exp_action_eq_mix (β : ℝ) (ω : Lk N → QBall) :
    Real.exp (β * action N ω)
      = Real.exp (-β) ^ (plaqs N).card * ∑ X ∈ (plaqs N).powerset, ∏ p ∈ X, sigP N β ω p := by
  unfold action
  rw [mul_sum, Real.exp_sum]
  simp_rw [exp_eq_mix β]
  rw [prod_mul_distrib, prod_const, prod_one_add]
  rfl

/-- `∫ f e^{βS} = e^{-β|P|} ∑_{X ⊆ P} ∫ f ∏_X σ` for bounded measurable `f` -/
theorem integral_mul_exp_action (β : ℝ) (hβ : 0 ≤ β) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hf1 : ∀ ω, |f ω| ≤ 1) :
    ∫ ω, f ω * Real.exp (β * action N ω) ∂haarPi N
      = Real.exp (-β) ^ (plaqs N).card *
          ∑ X ∈ (plaqs N).powerset, ∫ ω, f ω * ∏ p ∈ X, sigP N β ω p ∂haarPi N := by
  have : (fun ω => f ω * Real.exp (β * action N ω)) = fun ω =>
      Real.exp (-β) ^ (plaqs N).card *
        ∑ X ∈ (plaqs N).powerset, f ω * ∏ p ∈ X, sigP N β ω p := by
    funext ω
    rw [exp_action_eq_mix, mul_sum, mul_sum, mul_sum]
    apply sum_congr rfl
    intro X _
    ring
  rw [this, integral_const_mul, integral_finsetSum]
  intro X _
  exact integrable_W_prod N β hβ f hf hf1 X

theorem integral_exp_action_eq (β : ℝ) (hβ : 0 ≤ β) :
    ∫ ω, Real.exp (β * action N ω) ∂haarPi N
      = Real.exp (-β) ^ (plaqs N).card * ∑ X ∈ (plaqs N).powerset, ZX N β X := by
  have := integral_mul_exp_action N β hβ (fun _ => 1) measurable_const (fun _ => by simp)
  simpa [ZX] using this

/-- every spanning set contains a minimal spanning set -/
theorem exists_minSpan_subset (p₀ : Lk N × Fin 4) (X : Finset (Lk N × Fin 4))
    (hX : X ⊆ plaqs N) (hs : Spans N p₀ X) : ∃ Y ∈ minSpan N p₀, Y ⊆ X := by
  classical
  have hne : (X.powerset.filter (fun Y => Spans N p₀ Y)).Nonempty :=
    ⟨X, mem_filter.mpr ⟨mem_powerset_self X, hs⟩⟩
  obtain ⟨Y, hY, hmin⟩ := exists_min_image _ card hne
  rw [mem_filter, mem_powerset] at hY
  refine ⟨Y, ?_, hY.1⟩
  unfold minSpan
  rw [mem_filter, mem_powerset]
  refine ⟨hY.1.trans hX, hY.2, fun Y' hY' hs' => ?_⟩
  have := hmin Y' (mem_filter.mpr ⟨mem_powerset.mpr (hY'.trans hY.1), hs'⟩)
  exact eq_of_subset_of_card_le hY' this

theorem minSpan_sub (p₀ : Lk N × Fin 4) (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpan N p₀) :
    Y ⊆ plaqs N ∧ Spans N p₀ Y := by
  classical
  unfold minSpan at hY
  rw [mem_filter, mem_powerset] at hY
  exact ⟨hY.1, hY.2.1⟩

theorem q_eq (β : ℝ) :
    (Real.exp (2 * β) - 1) / (1 + (Real.exp (2 * β) - 1)) = 1 - Real.exp (-2 * β) := by
  have h : Real.exp (-2 * β) = (Real.exp (2 * β))⁻¹ := by
    rw [← Real.exp_neg]; ring_nf
  have hpos := Real.exp_pos (2 * β)
  rw [h, add_sub_cancel]
  field_simp

open Classical in
/-- **Single-plaquette Wilson loop at strong coupling (product-Haar form).**
For every `β ≥ 0`, every `N` and every plaquette `p₀`, with `q = 1 - e^{-2β}`,
`|∫ Re U_{p₀} e^{βS} d(∏ Haar)| ≤ (∑_{Y ∈ minSpan N p₀} q^{|Y|}) ∫ e^{βS} d(∏ Haar)`. -/
theorem abs_integral_plaq_wilson_le (β : ℝ) (hβ : 0 ≤ β) (p₀ : Lk N × Fin 4) :
    |∫ ω, (hol N ω p₀).re * Real.exp (β * action N ω) ∂haarPi N|
      ≤ (∑ Y ∈ minSpan N p₀, (1 - Real.exp (-2 * β)) ^ Y.card)
          * ∫ ω, Real.exp (β * action N ω) ∂haarPi N := by
  set t := Real.exp (2 * β) - 1 with ht_def
  have ht : 0 ≤ t := by
    have := Real.one_le_exp (by linarith : (0:ℝ) ≤ 2 * β)
    linarith
  set c := Real.exp (-β) ^ (plaqs N).card with hc_def
  have hc : 0 ≤ c := pow_nonneg (Real.exp_pos _).le _
  set W : (Lk N → QBall) → ℝ := fun ω => (hol N ω p₀).re with hW
  have hWm : Measurable W := (Quaternion.continuous_re.comp (continuous_hol N p₀)).measurable
  have hW1 : ∀ ω, |W ω| ≤ 1 := fun ω => abs_hol_re N ω p₀
  set pw := (plaqs N).powerset
  set term : Finset (Lk N × Fin 4) → ℝ := fun X => ∫ ω, W ω * ∏ p ∈ X, sigP N β ω p ∂haarPi N
  -- step 1: expansion
  have h1 : ∫ ω, (hol N ω p₀).re * Real.exp (β * action N ω) ∂haarPi N = c * ∑ X ∈ pw, term X :=
    integral_mul_exp_action N β hβ W hWm hW1
  -- step 2: the non-spanning terms vanish
  have h2 : ∑ X ∈ pw, term X = ∑ X ∈ pw with Spans N p₀ X, term X := by
    rw [← sum_filter_add_sum_filter_not pw (Spans N p₀) term]
    have : ∑ X ∈ pw with ¬ Spans N p₀ X, term X = 0 := by
      apply sum_eq_zero
      intro X hX
      rw [mem_filter] at hX
      exact integral_plaq_mul_prod_eq_zero_of_not_mem_span N p₀ X (mixVar β) hX.2
    rw [this, add_zero]
  -- step 3: |term X| ≤ Z_X
  have h3 : ∀ X, |term X| ≤ ZX N β X := by
    intro X
    refine (abs_integral_le_integral_abs).trans ?_
    apply integral_mono (integrable_W_prod N β hβ W hWm hW1 X).abs (integrable_prod N β hβ X)
    intro ω
    simp only
    rw [abs_mul, abs_of_nonneg (prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1)]
    exact mul_le_of_le_one_left (prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1) (hW1 ω)
  -- step 4: spanning sets contain minimal ones
  have h4 : ∑ X ∈ pw with Spans N p₀ X, ZX N β X
      ≤ ∑ Y ∈ minSpan N p₀, ∑ X ∈ pw with Y ⊆ X, ZX N β X := by
    calc ∑ X ∈ pw with Spans N p₀ X, ZX N β X
        ≤ ∑ X ∈ pw with Spans N p₀ X, ∑ Y ∈ minSpan N p₀, (if Y ⊆ X then ZX N β X else 0) := by
          apply sum_le_sum
          intro X hX
          rw [mem_filter, mem_powerset] at hX
          obtain ⟨Y, hY, hYX⟩ := exists_minSpan_subset N p₀ X hX.1 hX.2
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => ZX N β X) (fun _ _ => ZX_nonneg N β hβ X)
            (mem_filter.mpr ⟨hY, hYX⟩)
      _ = ∑ Y ∈ minSpan N p₀, ∑ X ∈ pw with Spans N p₀ X, (if Y ⊆ X then ZX N β X else 0) :=
          sum_comm
      _ ≤ ∑ Y ∈ minSpan N p₀, ∑ X ∈ pw, (if Y ⊆ X then ZX N β X else 0) := by
          apply sum_le_sum
          intro Y _
          apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
          intro X _ _
          split_ifs
          · exact ZX_nonneg N β hβ X
          · exact le_refl 0
      _ = ∑ Y ∈ minSpan N p₀, ∑ X ∈ pw with Y ⊆ X, ZX N β X := by
          apply sum_congr rfl
          intro Y _
          rw [sum_filter]
  -- step 5: domination
  have h5 : ∀ Y ∈ minSpan N p₀,
      ∑ X ∈ pw with Y ⊆ X, ZX N β X ≤ (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZX N β X :=
    fun Y hY => sum_superset_le_in (plaqs N) (ZX N β) t ht
      (fun S _ p _ hp => ZX_insert_le N β hβ S p hp) Y (minSpan_sub N p₀ Y hY).1
  have hq : t / (1 + t) = 1 - Real.exp (-2 * β) := q_eq β
  rw [h1, h2, integral_exp_action_eq N β hβ, abs_mul, abs_of_nonneg hc]
  calc c * |∑ X ∈ pw with Spans N p₀ X, term X|
      ≤ c * ∑ X ∈ pw with Spans N p₀ X, ZX N β X := by
        apply mul_le_mul_of_nonneg_left _ hc
        exact (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun X _ => h3 X)
    _ ≤ c * ∑ Y ∈ minSpan N p₀, (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZX N β X := by
        apply mul_le_mul_of_nonneg_left _ hc
        exact h4.trans (sum_le_sum h5)
    _ = (∑ Y ∈ minSpan N p₀, (1 - Real.exp (-2 * β)) ^ Y.card)
          * (c * ∑ X ∈ pw, ZX N β X) := by
        rw [← sum_mul, hq]; ring

/-- the normalised expectation `⟨Re U_{p₀}⟩_β` for the Wilson weight -/
noncomputable def plaqExpect (β : ℝ) (p₀ : Lk N × Fin 4) : ℝ :=
  (∫ ω, (hol N ω p₀).re * Real.exp (β * action N ω) ∂haarPi N)
    / ∫ ω, Real.exp (β * action N ω) ∂haarPi N

theorem integral_exp_action_pos (β : ℝ) (hβ : 0 ≤ β) :
    0 < ∫ ω, Real.exp (β * action N ω) ∂haarPi N := by
  rw [integral_exp_action_eq N β hβ]
  apply mul_pos (pow_pos (Real.exp_pos _) _)
  have hZ0 : ZX N β ∅ = 1 := by simp [ZX]
  calc (0:ℝ) < ZX N β ∅ := by rw [hZ0]; exact one_pos
    _ ≤ ∑ X ∈ (plaqs N).powerset, ZX N β X :=
        single_le_sum (fun X _ => ZX_nonneg N β hβ X) (empty_mem_powerset _)

open Classical in
/-- **Single-plaquette Wilson loop at strong coupling.**  For every `β ≥ 0`, every `N` and every
plaquette `p₀`, `|⟨Re U_{p₀}⟩_β| ≤ ∑_{Y ∈ minSpan N p₀} (1 - e^{-2β})^{|Y|}`. -/
theorem abs_plaqExpect_le (β : ℝ) (hβ : 0 ≤ β) (p₀ : Lk N × Fin 4) :
    |plaqExpect N β p₀| ≤ ∑ Y ∈ minSpan N p₀, (1 - Real.exp (-2 * β)) ^ Y.card := by
  unfold plaqExpect
  have hpos := integral_exp_action_pos N β hβ
  rw [abs_div, abs_of_pos hpos, div_le_iff₀ hpos]
  exact abs_integral_plaq_wilson_le N β hβ p₀

/-! ### Sanity -/

/-- For `N ≥ 2` and `p₀ ∈ plaqs N`, the empty set does not span, so every minimal spanning set
is nonempty. -/
theorem minSpan_card_pos (hN : 1 < N) (p₀ : Lk N × Fin 4) (hp : p₀ ∈ plaqs N)
    (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpan N p₀) : 0 < Y.card := by
  rw [card_pos]
  rcases Y.eq_empty_or_nonempty with h | h
  · exfalso
    have hs := (minSpan_sub N p₀ Y hY).2
    rw [h] at hs
    exact sanity_empty_spans_nothing N hN p₀ hp hs
  · exact h

/-- Sanity: `{p₀}` is a minimal spanning set (so `minSpan` is nonempty and the bound is not an
empty sum). -/
theorem singleton_mem_minSpan (hN : 1 < N) (p₀ : Lk N × Fin 4) (hp : p₀ ∈ plaqs N) :
    {p₀} ∈ minSpan N p₀ := by
  classical
  unfold minSpan
  rw [mem_filter, mem_powerset]
  refine ⟨singleton_subset_iff.mpr hp, sanity_self_spans N p₀, fun Y' hY' hs => ?_⟩
  rcases subset_singleton_iff.mp hY' with h | h
  · exfalso
    rw [h] at hs
    exact sanity_empty_spans_nothing N hN p₀ hp hs
  · exact h

open Classical in
/-- Sanity: at `β = 0` the bound is `0` (`N ≥ 2`), matching the vanishing Haar mean. -/
theorem sanity_bound_beta_zero (hN : 1 < N) (p₀ : Lk N × Fin 4) (hp : p₀ ∈ plaqs N) :
    ∑ Y ∈ minSpan N p₀, (1 - Real.exp (-2 * (0:ℝ))) ^ Y.card = 0 := by
  apply sum_eq_zero
  intro Y hY
  have := minSpan_card_pos N hN p₀ hp Y hY
  simp [zero_pow (Nat.pos_iff_ne_zero.mp this)]

end Bound

end AreaLaw

#print axioms AreaLaw.abs_integral_plaq_wilson_le
#print axioms AreaLaw.abs_plaqExpect_le
#print axioms AreaLaw.singleton_mem_minSpan
#print axioms AreaLaw.sanity_bound_beta_zero
