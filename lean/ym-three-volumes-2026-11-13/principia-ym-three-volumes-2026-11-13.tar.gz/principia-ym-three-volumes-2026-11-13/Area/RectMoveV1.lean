import Area.AreaMainV1
import Peierls.PermRPV2

/-!
# The area law for a rectangle at any base point and in any coordinate plane

Paper correspondence: the lattice symmetries of the Wilson measure on `(ℤ/N)⁴`.
* `wilson_cfgShift_invariant`: translation by any `a ∈ (ℤ/N)⁴`, `(S_a ω)_ℓ = ω_{ℓ + a}`, preserves
  the Wilson measure (the one-step time translation `TorusRP.wilson_shift_invariant`, for every
  vector `a`).
* The relabelling of directions by an involution `τ` of `{0,1,2,3}` preserves it
  (`PeierlsPerm.wilson_perm_invariant`).
* The Wilson loop of a word is moved accordingly (`wordHol_cfgShift`, `wordHol_cfgPerm`).
* `rectWordG a μ ν R T`: the boundary of the `R × T` rectangle with corner `a` in the plane of the
  directions `μ ≠ ν` (sides `R` along `μ`, `T` along `ν`); it is the image of `rectWord N R T`
  under two transpositions of the directions and the translation by `a` (`moved_rect_eq`).
* **`area_law_wilson_general`**: the bound of `area_law_wilson` holds for `rectWordG a μ ν R T`.
-/

open MeasureTheory Finset TorusRP PeierlsPerm

namespace AreaLaw

variable (N : ℕ) [NeZero N]

/-! ### Translations by an arbitrary vector -/

/-- translation of a link by `a` -/
def shA (a : Site N) (ℓ : Lk N) : Lk N := (ℓ.1 + a, ℓ.2)

def shAEquiv (a : Site N) : Lk N ≃ Lk N where
  toFun ℓ := (ℓ.1 - a, ℓ.2)
  invFun := shA N a
  left_inv ℓ := by simp [shA]
  right_inv ℓ := by simp [shA]

/-- the translated configuration `(S_a ω)_ℓ = ω_{ℓ + a}` -/
def cfgShift (a : Site N) (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (shA N a ℓ)

theorem cfgShift_preserving (a : Site N) :
    MeasurePreserving (cfgShift N a) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) (shAEquiv N a)
  convert hre using 1
  funext ω
  funext ℓ
  rw [LinkReflection.piCongrLeft_const]
  rfl

theorem hol_cfgShift (a : Site N) (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (cfgShift N a ω) p = hol N ω ((p.1.1 + a, p.1.2), p.2) := by
  simp only [hol, holQ, Uq, cfgShift, shA]
  rw [add_right_comm p.1.1 (ev N p.1.2) a, add_right_comm p.1.1 (ev N p.2) a]

theorem action_cfgShift (a : Site N) (ω : Lk N → QBall) :
    action N (cfgShift N a ω) = action N ω := by
  unfold action
  simp_rw [hol_cfgShift]
  apply Finset.sum_nbij' (fun p => ((p.1.1 + a, p.1.2), p.2)) (fun p => ((p.1.1 - a, p.1.2), p.2))
  · intro p hp; simpa [plaqs] using hp
  · intro p hp; simpa [plaqs] using hp
  · intro p _; simp
  · intro p _; simp
  · intro p _; rfl

/-- **Translation invariance of the Wilson measure** (every `β`, every `a`, measurable `f`). -/
theorem wilson_cfgShift_invariant (β : ℝ) (a : Site N) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) :
    ∫ ω, f (cfgShift N a ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := cfgShift_preserving N a
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) • f ω) := hWm.smul hf
  conv_rhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  unfold wilsonWeight
  rw [action_cfgShift]

/-! ### Words under the symmetries -/

theorem wordHol_cfgShift (a : Site N) (ω : Lk N → QBall) (w : Word N) :
    wordHol N (cfgShift N a ω) w = wordHol N ω (w.map (fun s => (shA N a s.1, s.2))) := by
  induction w with
  | nil => simp [wordHol]
  | cons s w ih => simp only [wordHol, List.map_cons, ih, Uq, cfgShift]

theorem wordHol_cfgPerm (τ : Fin 4 → Fin 4) (ω : Lk N → QBall) (w : Word N) :
    wordHol N (cfgPerm N τ ω) w = wordHol N ω (w.map (fun s => (linkPerm N τ s.1, s.2))) := by
  induction w with
  | nil => simp [wordHol]
  | cons s w ih => simp only [wordHol, List.map_cons, ih, Uq, cfgPerm]

theorem measurable_wordHol_re (w : Word N) :
    Measurable (fun ω : Lk N → QBall => (wordHol N ω w).re) :=
  (Quaternion.continuous_re.comp (continuous_wordHol N w)).measurable

theorem expect_shift (β : ℝ) (a : Site N) (w : Word N) :
    ∫ ω, (wordHol N ω (w.map (fun s => (shA N a s.1, s.2)))).re ∂(wilsonMeasure N β)
      = ∫ ω, (wordHol N ω w).re ∂(wilsonMeasure N β) := by
  rw [← wilson_cfgShift_invariant N β a _ (measurable_wordHol_re N w)]
  simp_rw [wordHol_cfgShift]

theorem expect_perm (β : ℝ) (τ : Fin 4 → Fin 4) (hτ : ∀ j, τ (τ j) = j) (w : Word N) :
    ∫ ω, (wordHol N ω (w.map (fun s => (linkPerm N τ s.1, s.2)))).re ∂(wilsonMeasure N β)
      = ∫ ω, (wordHol N ω w).re ∂(wilsonMeasure N β) := by
  rw [← wilson_perm_invariant N τ hτ β _ (measurable_wordHol_re N w)]
  simp_rw [wordHol_cfgPerm]

/-! ### The general rectangle -/

/-- the first relabelling: the transposition of `0` and `μ` -/
def tau1 (μ : Fin 4) : Fin 4 → Fin 4 := Equiv.swap 0 μ

/-- the second relabelling: the transposition of `tau1 μ 1` and `ν` -/
def tau2 (μ ν : Fin 4) : Fin 4 → Fin 4 := Equiv.swap (tau1 μ 1) ν

theorem tau1_invol (μ : Fin 4) : ∀ j, tau1 μ (tau1 μ j) = j := fun j => by
  simp [tau1]

theorem tau2_invol (μ ν : Fin 4) : ∀ j, tau2 μ ν (tau2 μ ν j) = j := fun j => by
  simp [tau2]

/-- the site `a + i e_μ + j e_ν` -/
def ptG (a : Site N) (μ ν : Fin 4) (i j : ℕ) : Site N :=
  ((i : ZMod N) • ev N μ + (j : ZMod N) • ev N ν) + a

/-- the boundary of the `R × T` rectangle with corner `a` in the `(μ, ν)` plane, as a closed link
path: `R` steps forwards along `μ`, `T` forwards along `ν`, `R` backwards along `μ`, `T` backwards
along `ν`. -/
def rectWordG (a : Site N) (μ ν : Fin 4) (R T : ℕ) : Word N :=
  (List.range R).map (fun i => ((ptG N a μ ν i 0, μ), true)) ++
  (List.range T).map (fun j => ((ptG N a μ ν R j, ν), true)) ++
  (List.range R).reverse.map (fun i => ((ptG N a μ ν i T, μ), false)) ++
  (List.range T).reverse.map (fun j => ((ptG N a μ ν 0 j, ν), false))

theorem tau_dirs (μ ν : Fin 4) (h : μ ≠ ν) :
    tau2 μ ν (tau1 μ 0) = μ ∧ tau2 μ ν (tau1 μ 1) = ν := by
  fin_cases μ <;> fin_cases ν <;> simp_all [tau1, tau2, Equiv.swap_apply_def] <;> decide

theorem site_moved (μ ν : Fin 4) (h : μ ≠ ν) (i j : ZMod N) :
    sitePerm N (tau2 μ ν) (sitePerm N (tau1 μ) ![i, j, 0, 0]) = i • ev N μ + j • ev N ν := by
  funext k
  fin_cases μ <;> fin_cases ν <;> simp_all <;> fin_cases k <;>
    simp [sitePerm, tau1, tau2, ev, Equiv.swap_apply_def, Pi.single_apply]

/-- the moved standard rectangle is the general rectangle -/
theorem moved_rect_eq (a : Site N) (μ ν : Fin 4) (h : μ ≠ ν) (R T : ℕ) :
    (((rectWord N R T).map (fun s => (linkPerm N (tau1 μ) s.1, s.2))).map
        (fun s => (linkPerm N (tau2 μ ν) s.1, s.2))).map (fun s => (shA N a s.1, s.2))
      = rectWordG N a μ ν R T := by
  obtain ⟨h0, h1⟩ := tau_dirs μ ν h
  have hs : ∀ i j : ℕ, sitePerm N (tau2 μ ν) (sitePerm N (tau1 μ) (pt N i j)) + a
      = ptG N a μ ν i j := by
    intro i j
    unfold pt ptG
    rw [site_moved N μ ν h]
  simp only [rectWord, rectWordG, List.map_append, List.map_map, Function.comp_def, linkPerm,
    shA, hs, h0, h1]

/-- **Area law for a rectangle at any base point and in any coordinate plane.**  For `β ≥ 0`
with `4096 (1 - e^{-2β}) < 1`, `1 ≤ R < N`, `1 ≤ T < N`, any corner `a ∈ (ℤ/N)⁴` and any two
directions `μ ≠ ν`, under the normalised Wilson measure on `(ℤ/N)⁴`,
`|⟨Re W(∂(R×T))⟩| ≤ 16 (4096 q)^{R·min(T, N-T)} / (4096 (1 - 4096 q))`, `q = 1 - e^{-2β}`. -/
theorem area_law_wilson_general (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R) (hT1 : 1 ≤ T)
    (hR : R < N) (hT : T < N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1)
    (a : Site N) (μ ν : Fin 4) (h : μ ≠ ν) :
    |(∫ ω, (wordHol N ω (rectWordG N a μ ν R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * min T (N - T))
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  rw [← moved_rect_eq N a μ ν h R T, expect_shift, expect_perm N β _ (tau2_invol μ ν),
    expect_perm N β _ (tau1_invol μ)]
  exact area_law_wilson N β hβ R T hR1 hT1 hR hT hK

/-- **Area law, general rectangle, `2T ≤ N`**: the exponent is the area `R T`. -/
theorem area_law_wilson_general_area (β : ℝ) (hβ : 0 ≤ β) (R T : ℕ) (hR1 : 1 ≤ R)
    (hT1 : 1 ≤ T) (hR : R < N) (h2T : 2 * T ≤ N) (hK : 4096 * (1 - Real.exp (-2 * β)) < 1)
    (a : Site N) (μ ν : Fin 4) (h : μ ≠ ν) :
    |(∫ ω, (wordHol N ω (rectWordG N a μ ν R T)).re ∂(wilsonMeasure N β))
        / ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)|
      ≤ 16 * ((4096 * (1 - Real.exp (-2 * β))) ^ (R * T)
          / (4096 * (1 - 4096 * (1 - Real.exp (-2 * β))))) := by
  have h' := area_law_wilson_general N β hβ R T hR1 hT1 hR (by omega) hK a μ ν h
  rwa [min_eq_left (by omega : T ≤ N - T)] at h'

/-! ### Sanity -/

/-- Sanity: with corner `0` and `(μ, ν) = (0, 1)` the general rectangle is the standard one. -/
theorem sanity_rectWordG_std (R T : ℕ) : rectWordG N 0 0 1 R T = rectWord N R T := by
  have hp : ∀ i j : ℕ, ptG N 0 0 1 i j = pt N i j := by
    intro i j
    funext k
    fin_cases k <;> simp [ptG, pt, ev]
  simp only [rectWordG, rectWord, hp]

/-- Sanity: a rectangle in the `(2,3)` plane with corner `(1,0,0,0)` is covered (the hypotheses
`μ ≠ ν` are met by a plane not containing the direction `0`). -/
theorem sanity_plane_23 : (2 : Fin 4) ≠ 3 ∧ tau2 2 3 (tau1 2 0) = 2 ∧ tau2 2 3 (tau1 2 1) = 3 :=
  ⟨by decide, tau_dirs 2 3 (by decide)⟩

/-- Sanity: the general rectangle is a closed path of `2(R+T)` links. -/
theorem sanity_rectWordG_length (a : Site N) (μ ν : Fin 4) (R T : ℕ) :
    (rectWordG N a μ ν R T).length = 2 * (R + T) := by
  simp [rectWordG]; ring

end AreaLaw

#print axioms AreaLaw.wilson_cfgShift_invariant
#print axioms AreaLaw.moved_rect_eq
#print axioms AreaLaw.area_law_wilson_general
#print axioms AreaLaw.area_law_wilson_general_area
#print axioms AreaLaw.sanity_rectWordG_std
#print axioms AreaLaw.sanity_plane_23
