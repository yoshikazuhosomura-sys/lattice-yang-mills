import Area.PlaqBoundV1

/-!
# A Wilson loop along any link word at strong coupling: bound by minimal spanning sets

Paper correspondence: steps 1–4 of the strong-coupling area-law argument, for a general loop
given as a link word `w` (e.g. the boundary of an `R × T` rectangle), on `(ℤ/N)⁴`, SU(2).
With `q = 1 - e^{-2β}` and `minSpanW N w` the minimal sets `Y ⊆ plaqs N` whose mod-2
boundaries span the mod-2 link content `wordBd N w`,

  `|⟨Re W(w)⟩_β| ≤ ∑_{Y ∈ minSpanW N w} q^{|Y|}`   for every `β ≥ 0` and every `N`.
-/

open MeasureTheory Finset TorusRP OSGap

local notation "ℍr" => Quaternion ℝ

namespace AreaLaw

section WordBound

variable (N : ℕ) [NeZero N]

theorem norm_wordHol_le (ω : Lk N → QBall) (w : Word N) : ‖wordHol N ω w‖ ≤ 1 := by
  induction w with
  | nil => simp [wordHol]
  | cons s w ih =>
    simp only [wordHol]
    rw [norm_mul]
    have hb : ‖Uq N ω s.1‖ ≤ 1 := mem_closedBall_zero_iff.1 (ω s.1).2
    have hf : ‖(if s.2 then Uq N ω s.1 else star (Uq N ω s.1))‖ ≤ 1 := by
      split_ifs
      · exact hb
      · rw [norm_star]; exact hb
    exact mul_le_one₀ hf (norm_nonneg _) ih

theorem abs_re_wordHol_le (ω : Lk N → QBall) (w : Word N) : |(wordHol N ω w).re| ≤ 1 :=
  (abs_re_le _).trans (norm_wordHol_le N ω w)

theorem continuous_wordHol (w : Word N) : Continuous (fun ω : Lk N → QBall => wordHol N ω w) := by
  induction w with
  | nil => simp only [wordHol]; exact continuous_const
  | cons s w ih =>
    simp only [wordHol]
    split_ifs
    · exact (continuous_Uq N s.1).mul ih
    · exact (continuous_Uq N s.1).star.mul ih

/-- `X` spans the mod-2 vector `c` -/
def SpansC (c : Lk N → ZMod 2) (X : Finset (Lk N × Fin 4)) : Prop :=
  c ∈ Submodule.span (ZMod 2) ((plaqBd N) '' (X : Set (Lk N × Fin 4)))

open Classical in
/-- the minimal sets of plaquettes spanning `c` -/
noncomputable def minSpanC (c : Lk N → ZMod 2) : Finset (Finset (Lk N × Fin 4)) :=
  (plaqs N).powerset.filter (fun Y => SpansC N c Y ∧ ∀ Y' ⊆ Y, SpansC N c Y' → Y' = Y)

theorem exists_minSpanC_subset (c : Lk N → ZMod 2) (X : Finset (Lk N × Fin 4))
    (hX : X ⊆ plaqs N) (hs : SpansC N c X) : ∃ Y ∈ minSpanC N c, Y ⊆ X := by
  classical
  have hne : (X.powerset.filter (fun Y => SpansC N c Y)).Nonempty :=
    ⟨X, mem_filter.mpr ⟨mem_powerset_self X, hs⟩⟩
  obtain ⟨Y, hY, hmin⟩ := exists_min_image _ card hne
  rw [mem_filter, mem_powerset] at hY
  refine ⟨Y, ?_, hY.1⟩
  unfold minSpanC
  rw [mem_filter, mem_powerset]
  refine ⟨hY.1.trans hX, hY.2, fun Y' hY' hs' => ?_⟩
  have := hmin Y' (mem_filter.mpr ⟨mem_powerset.mpr (hY'.trans hY.1), hs'⟩)
  exact eq_of_subset_of_card_le hY' this

theorem minSpanC_sub (c : Lk N → ZMod 2) (Y : Finset (Lk N × Fin 4)) (hY : Y ∈ minSpanC N c) :
    Y ⊆ plaqs N ∧ SpansC N c Y := by
  classical
  unfold minSpanC at hY
  rw [mem_filter, mem_powerset] at hY
  exact ⟨hY.1, hY.2.1⟩

open Classical in
/-- **Wilson loop along a word at strong coupling (product-Haar form).** -/
theorem abs_integral_word_wilson_le (β : ℝ) (hβ : 0 ≤ β) (w : Word N) :
    |∫ ω, (wordHol N ω w).re * Real.exp (β * action N ω) ∂haarPi N|
      ≤ (∑ Y ∈ minSpanC N (wordBd N w), (1 - Real.exp (-2 * β)) ^ Y.card)
          * ∫ ω, Real.exp (β * action N ω) ∂haarPi N := by
  set t := Real.exp (2 * β) - 1 with ht_def
  have ht : 0 ≤ t := by
    have := Real.one_le_exp (by linarith : (0:ℝ) ≤ 2 * β)
    linarith
  set c := Real.exp (-β) ^ (plaqs N).card with hc_def
  have hc : 0 ≤ c := pow_nonneg (Real.exp_pos _).le _
  set W : (Lk N → QBall) → ℝ := fun ω => (wordHol N ω w).re with hW
  have hWm : Measurable W := (Quaternion.continuous_re.comp (continuous_wordHol N w)).measurable
  have hW1 : ∀ ω, |W ω| ≤ 1 := fun ω => abs_re_wordHol_le N ω w
  set pw := (plaqs N).powerset
  set term : Finset (Lk N × Fin 4) → ℝ := fun X => ∫ ω, W ω * ∏ p ∈ X, sigP N β ω p ∂haarPi N
  have h1 : ∫ ω, (wordHol N ω w).re * Real.exp (β * action N ω) ∂haarPi N
      = c * ∑ X ∈ pw, term X :=
    integral_mul_exp_action N β hβ W hWm hW1
  have h2 : ∑ X ∈ pw, term X = ∑ X ∈ pw with SpansC N (wordBd N w) X, term X := by
    rw [← sum_filter_add_sum_filter_not pw (SpansC N (wordBd N w)) term]
    have : ∑ X ∈ pw with ¬ SpansC N (wordBd N w) X, term X = 0 := by
      apply sum_eq_zero
      intro X hX
      rw [mem_filter] at hX
      exact integral_word_mul_prod_eq_zero_of_not_mem_span N w X (mixVar β) hX.2
    rw [this, add_zero]
  have h3 : ∀ X, |term X| ≤ ZX N β X := by
    intro X
    refine (abs_integral_le_integral_abs).trans ?_
    apply integral_mono (integrable_W_prod N β hβ W hWm hW1 X).abs (integrable_prod N β hβ X)
    intro ω
    simp only
    rw [abs_mul, abs_of_nonneg (prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1)]
    exact mul_le_of_le_one_left (prod_nonneg fun p _ => (sigP_mem N β hβ ω p).1) (hW1 ω)
  have h4 : ∑ X ∈ pw with SpansC N (wordBd N w) X, ZX N β X
      ≤ ∑ Y ∈ minSpanC N (wordBd N w), ∑ X ∈ pw with Y ⊆ X, ZX N β X := by
    calc ∑ X ∈ pw with SpansC N (wordBd N w) X, ZX N β X
        ≤ ∑ X ∈ pw with SpansC N (wordBd N w) X,
            ∑ Y ∈ minSpanC N (wordBd N w), (if Y ⊆ X then ZX N β X else 0) := by
          apply sum_le_sum
          intro X hX
          rw [mem_filter, mem_powerset] at hX
          obtain ⟨Y, hY, hYX⟩ := exists_minSpanC_subset N (wordBd N w) X hX.1 hX.2
          rw [← sum_filter]
          exact single_le_sum (f := fun _ => ZX N β X) (fun _ _ => ZX_nonneg N β hβ X)
            (mem_filter.mpr ⟨hY, hYX⟩)
      _ = ∑ Y ∈ minSpanC N (wordBd N w), ∑ X ∈ pw with SpansC N (wordBd N w) X,
            (if Y ⊆ X then ZX N β X else 0) := sum_comm
      _ ≤ ∑ Y ∈ minSpanC N (wordBd N w), ∑ X ∈ pw, (if Y ⊆ X then ZX N β X else 0) := by
          apply sum_le_sum
          intro Y _
          apply sum_le_sum_of_subset_of_nonneg (filter_subset _ _)
          intro X _ _
          split_ifs
          · exact ZX_nonneg N β hβ X
          · exact le_refl 0
      _ = ∑ Y ∈ minSpanC N (wordBd N w), ∑ X ∈ pw with Y ⊆ X, ZX N β X := by
          apply sum_congr rfl
          intro Y _
          rw [sum_filter]
  have h5 : ∀ Y ∈ minSpanC N (wordBd N w),
      ∑ X ∈ pw with Y ⊆ X, ZX N β X ≤ (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZX N β X :=
    fun Y hY => sum_superset_le_in (plaqs N) (ZX N β) t ht
      (fun S _ p _ hp => ZX_insert_le N β hβ S p hp) Y (minSpanC_sub N _ Y hY).1
  have hq : t / (1 + t) = 1 - Real.exp (-2 * β) := q_eq β
  rw [h1, h2, integral_exp_action_eq N β hβ, abs_mul, abs_of_nonneg hc]
  calc c * |∑ X ∈ pw with SpansC N (wordBd N w) X, term X|
      ≤ c * ∑ X ∈ pw with SpansC N (wordBd N w) X, ZX N β X := by
        apply mul_le_mul_of_nonneg_left _ hc
        exact (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun X _ => h3 X)
    _ ≤ c * ∑ Y ∈ minSpanC N (wordBd N w), (t / (1 + t)) ^ Y.card * ∑ X ∈ pw, ZX N β X := by
        apply mul_le_mul_of_nonneg_left _ hc
        exact h4.trans (sum_le_sum h5)
    _ = (∑ Y ∈ minSpanC N (wordBd N w), (1 - Real.exp (-2 * β)) ^ Y.card)
          * (c * ∑ X ∈ pw, ZX N β X) := by
        rw [← sum_mul, hq]; ring

/-- the normalised expectation `⟨Re W(w)⟩_β` -/
noncomputable def wordExpect (β : ℝ) (w : Word N) : ℝ :=
  (∫ ω, (wordHol N ω w).re * Real.exp (β * action N ω) ∂haarPi N)
    / ∫ ω, Real.exp (β * action N ω) ∂haarPi N

open Classical in
/-- **Wilson loop along a word at strong coupling.**  For every `β ≥ 0`, every `N` and every
link word `w`, `|⟨Re W(w)⟩_β| ≤ ∑_{Y ∈ minSpanC N (wordBd N w)} (1 - e^{-2β})^{|Y|}`. -/
theorem abs_wordExpect_le (β : ℝ) (hβ : 0 ≤ β) (w : Word N) :
    |wordExpect N β w| ≤ ∑ Y ∈ minSpanC N (wordBd N w), (1 - Real.exp (-2 * β)) ^ Y.card := by
  unfold wordExpect
  have hpos := integral_exp_action_pos N β hβ
  rw [abs_div, abs_of_pos hpos, div_le_iff₀ hpos]
  exact abs_integral_word_wilson_le N β hβ w

open Classical in
/-- **Uniform area factor.**  If every set of plaquettes spanning `wordBd N w` has at least `A`
elements, then `|⟨Re W(w)⟩_β| ≤ #(minSpanC) · (1 - e^{-2β})^A`. -/
theorem abs_wordExpect_le_of_card (β : ℝ) (hβ : 0 ≤ β) (w : Word N) (A : ℕ)
    (hA : ∀ Y ⊆ plaqs N, SpansC N (wordBd N w) Y → A ≤ Y.card) :
    |wordExpect N β w| ≤ (minSpanC N (wordBd N w)).card * (1 - Real.exp (-2 * β)) ^ A := by
  refine (abs_wordExpect_le N β hβ w).trans ?_
  have hq0 : 0 ≤ 1 - Real.exp (-2 * β) := by
    have := Real.exp_le_one_iff.mpr (by linarith : -2 * β ≤ 0)
    linarith
  have hq1 : 1 - Real.exp (-2 * β) ≤ 1 := by
    have := Real.exp_pos (-2 * β)
    linarith
  rw [← nsmul_eq_mul, ← sum_const]
  apply sum_le_sum
  intro Y hY
  have h := minSpanC_sub N _ Y hY
  exact pow_le_pow_of_le_one hq0 hq1 (hA Y h.1 h.2)

/-- Sanity: the plaquette word is a word, and the general bound specialises to it
(`wordBd (plaqWord p₀) = plaqBd p₀`). -/
theorem sanity_word_plaq (β : ℝ) (p₀ : Lk N × Fin 4) :
    wordExpect N β (plaqWord N p₀) = plaqExpect N β p₀ := by
  unfold wordExpect plaqExpect
  simp_rw [hol_eq_wordHol N _ p₀]

end WordBound

end AreaLaw

#print axioms AreaLaw.abs_wordExpect_le
#print axioms AreaLaw.abs_wordExpect_le_of_card
#print axioms AreaLaw.sanity_word_plaq
