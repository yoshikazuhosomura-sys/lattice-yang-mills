import FoldChess.QuarterBV1
/-!
Rate 1/4, plaquette forms and one statement.
* `rarity_plaq4`・`rarity_sites4` : for a set S of sites with even coordinates off the plane (μ, ν),
  ∫ ∏_{x∈S} 1[(x; μν) large] dμ_W ≤ Z q₄^{|S|},  q₄ = e^{β(48 r² − y/4)} / h(r)⁴.
* `rarity_all4` : every finite set X of plaquettes: ≤ Z q₄^{⌊|X|/24⌋} (24 classes: orientation × parity off the plane).
* `rarity_uniform4` : for 0 < y ≤ 2 there are r > 0 and β₀ with q₄ < 1 for β ≥ β₀ and the bound for every m ≥ 1.

Paper correspondence: Proposition P (rate 1/4), uniform in the volume, every even side.
-/

namespace FoldQuarter

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy Finset

variable (N : ℕ) [NeZero N] (m : ℕ)

theorem rarity_plaq4 (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ) (hr : 0 < r)
    (X : Finset (Z4 N)) (hX : X ⊆ E4 N μ ν) :
    ∫ ω, ∏ w ∈ X, (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
  set F : ZMod N → ZMod N → ZMod N → ZMod N → Bool := fun t0 t1 t2 t3 => decide ((t0, t1, t2, t3) ∈ X)
  have hr' := rarity_four N m hN β hβ μ ν hμν y r (ballQ_pos r hr) F
  have hterm : ∀ (ω : Cfg N) (q : Z4 N), Hf N μ ν y (F q.1 q.2.1 q.2.2.1 q.2.2.2) (Ψ N q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      if q ∈ X then (if y < 1 - (hol N ω ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
      else 1 := by
    intro ω q
    by_cases hq : q ∈ X
    · have he := hX hq
      simp only [E4, mem_product] at he
      simp only [F, Prod.mk.eta, hq, decide_true, Hf, if_true, big, re_hol_Ψ N _ _ _ _ ω μ ν hμν,
        bvec_eq N _ _ _ _ μ ν he.1 he.2.1 he.2.2.1 he.2.2.2]
    · simp [F, hq, Hf]
  have eL : V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F = ∫ ω, ∏ w ∈ X,
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) := by
    unfold V4; congr 1; funext ω
    rw [prod4]
    simp only [hterm]
    rw [Finset.prod_ite_mem, univ_inter]
  have eR : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
      Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 else 1) =
      (Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
    rw [prod4]
    simp only [F, Prod.mk.eta, decide_eq_true_eq]
    rw [Finset.prod_ite_mem, univ_inter, prod_const]
  rw [← eL, ← eR]
  exact hr'

/-- rarity for a set of sites with even coordinates off the plane -/
theorem rarity_sites4 (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ) (hr : 0 < r)
    (S : Finset (Site N)) (hS : ∀ x ∈ S, ∀ j, ¬ (j = μ ∨ j = ν) → par N (x j) = false) :
    ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  have hinj : Set.InjOn (toZ4 N) S := by
    intro x _ x' _ h
    rw [← vec_toZ4 N x, ← vec_toZ4 N x']
    simp only [toZ4, Prod.mk.injEq] at h
    rw [h.1, h.2.1, h.2.2.1, h.2.2.2]
  have hX : S.image (toZ4 N) ⊆ E4 N μ ν := by
    intro w hw
    obtain ⟨x, hx, rfl⟩ := mem_image.mp hw
    have hd : ∀ d : Fin 4, x d ∈ Sd N d μ ν := by
      intro d; unfold Sd
      split_ifs with h
      · exact mem_univ _
      · simp only [evens, mem_filter, mem_univ, true_and]; exact hS x hx d h
    simp only [toZ4, E4, mem_product]
    exact ⟨hd 0, hd 1, hd 2, hd 3⟩
  have h := rarity_plaq4 N m hN β hβ μ ν hμν y r hr (S.image (toZ4 N)) hX
  rw [card_image_of_injOn hinj] at h
  have e : ∫ ω, ∏ w ∈ S.image (toZ4 N),
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := by
    congr 1; funext ω
    rw [prod_image hinj]
    apply prod_congr rfl; intro x _
    simp only [toZ4, vec_toZ4, bigP]
  rw [← e]; exact h

/-- **Volume-uniform rarity for every finite set of plaquettes, 24 classes.** -/
theorem rarity_all4 (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (hq1 : Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 ≤ 1)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) :
    ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 24) := by
  set q := Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 with hqdef
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg (ballQ_pos r hr).le _)
  -- the classes
  let cls : Lk N × Fin 4 → (Fin 4 → Bool) × (Fin 4 × Fin 4) :=
    fun p => (fun j => if j = p.1.2 ∨ j = p.2 then false else par N (p.1.1 j), (p.1.2, p.2))
  let T : Finset ((Fin 4 → Bool) × (Fin 4 × Fin 4)) :=
    (univ ×ˢ univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2)).filter
      (fun c => c.1 c.2.1 = false ∧ c.1 c.2.2 = false)
  have hT : T.card = 24 := by decide
  have hmaps : ∀ p ∈ X, cls p ∈ T := by
    intro p hp
    have := hX hp
    simp only [plaqs, mem_filter, mem_univ, true_and] at this
    simp only [T, cls, mem_product, mem_univ, mem_filter, true_and]
    exact ⟨this, by simp, by simp⟩
  have hTne : T.Nonempty := ⟨(fun _ => false, (0, 1)), by simp [T]⟩
  obtain ⟨c, hcT, hc⟩ := Finset.exists_le_card_fiber_of_mul_le_card_of_maps_to hmaps hTne
    (by rw [hT]; exact Nat.mul_div_le X.card 24)
  set Xc := X.filter (fun p => cls p = c) with hXc
  obtain ⟨π, μ, ν⟩ := c
  have hμν : μ < ν := by simp only [T, mem_product, mem_univ, mem_filter, true_and] at hcT; exact hcT.1
  -- monotonicity
  have hmono : ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) := by
    have hbd : ∀ (s : Finset (Lk N × Fin 4)), Integrable (fun ω => ∏ p ∈ s, bigP N y ω p) (wilsonMeasure N β) := by
      intro s
      refine Integrable.of_bound (Finset.measurable_prod s (fun p _ => measurable_bigP N y p)).aestronglyMeasurable 1
        (Filter.Eventually.of_forall fun ω => ?_)
      rw [Real.norm_eq_abs, abs_of_nonneg (prod_nonneg fun p _ => bigP_nonneg N y ω p)]
      exact prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
    refine integral_mono (hbd X) (hbd Xc) (fun ω => ?_)
    show ∏ p ∈ X, bigP N y ω p ≤ ∏ p ∈ Xc, bigP N y ω p
    rw [← prod_filter_mul_prod_filter_not X (fun p => cls p = (π, μ, ν))]
    have h1 : ∏ p ∈ X.filter (fun p => ¬ cls p = (π, μ, ν)), bigP N y ω p ≤ 1 :=
      prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
    have h0 : 0 ≤ ∏ p ∈ Xc, bigP N y ω p := prod_nonneg fun p _ => bigP_nonneg N y ω p
    calc (∏ p ∈ Xc, bigP N y ω p) * ∏ p ∈ X.filter (fun p => ¬ cls p = (π, μ, ν)), bigP N y ω p
        ≤ (∏ p ∈ Xc, bigP N y ω p) * 1 := mul_le_mul_of_nonneg_left h1 h0
      _ = _ := mul_one _
  -- translation to the even sublattice
  set v : Site N := fun j => if π j then (1 : ZMod N) else 0 with hv
  set S : Finset (Site N) := Xc.image (fun p => p.1.1 - v) with hSdef
  have hmem : ∀ p ∈ Xc, p = ((p.1.1, μ), ν) ∧
      ∀ j, (if j = μ ∨ j = ν then false else par N (p.1.1 j)) = π j := by
    intro p hp
    simp only [hXc, mem_filter, cls, Prod.mk.injEq] at hp
    obtain ⟨_, hπ, hμ, hν⟩ := hp
    refine ⟨?_, fun j => ?_⟩
    · rw [← hμ, ← hν]
    · have := congrFun hπ j
      rw [hμ, hν] at this
      exact this
  have hinj : Set.InjOn (fun p : Lk N × Fin 4 => p.1.1 - v) Xc := by
    intro p hp p' hp' h
    simp only at h
    have e : p.1.1 = p'.1.1 := sub_left_injective h
    rw [(hmem p hp).1, (hmem p' hp').1, e]
  have hS : ∀ x ∈ S, ∀ j, ¬ (j = μ ∨ j = ν) → par N (x j) = false := by
    intro x hx j hj
    obtain ⟨p, hp, rfl⟩ := mem_image.mp hx
    have hpj := (hmem p hp).2 j
    rw [if_neg hj] at hpj
    simp only [Pi.sub_apply, hv]
    cases hπj : π j
    · simp only [hπj, Bool.false_eq_true, if_false, sub_zero]; rw [hpj, hπj]
    · simp only [hπj, if_true]; rw [par_sub_one N m hN, hpj, hπj]; rfl
  have hshift : ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) =
      ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := by
    have hm : Measurable (fun ω : Cfg N => ∏ x ∈ S, bigP N y ω ((x, μ), ν)) :=
      Finset.measurable_prod S (fun x _ => measurable_bigP N y _)
    rw [← wilson_shV_invariant N v β _ hm]
    congr 1; funext ω
    rw [hSdef, prod_image hinj]
    apply prod_congr rfl
    intro p hp
    rw [congrArg (bigP N y ω) (hmem p hp).1]
    simp only [bigP, hol_shV, sub_add_cancel]
  have hcard : X.card / 24 ≤ S.card := by
    rw [hSdef, card_image_of_injOn hinj]; exact hc
  have hrs := rarity_sites4 N m hN β hβ μ ν hμν y r hr S hS
  calc ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β)
      ≤ ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) := hmono
    _ = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := hshift
    _ ≤ Zw N β * q ^ S.card := hrs
    _ ≤ Zw N β * q ^ (X.card / 24) :=
        mul_le_mul_of_nonneg_left (pow_le_pow_of_le_one hq0 hq1 hcard) (Zw_nonneg N β)

theorem rarity_uniform4 (y : ℝ) (hy0 : 0 < y) (hy2 : y ≤ 2) :
    ∃ r : ℝ, 0 < r ∧ ∃ β₀ : ℝ, ∀ β : ℝ, β₀ ≤ β →
      Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 < 1 ∧
      ∀ (N : ℕ) [NeZero N] (m : ℕ), N = 2 * m → ∀ X : Finset (Lk N × Fin 4), X ⊆ plaqs N →
        ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
          Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 24) := by
  set r : ℝ := y / 1000 with hr
  have hr0 : 0 < r := by rw [hr]; positivity
  have hh := ballQ_pos r hr0
  set g : ℝ := y / 4 - 48 * r ^ 2 with hg
  have hg0 : 0 < g := by rw [hg, hr]; nlinarith
  refine ⟨r, hr0, max 0 (4 * Real.log (1 / haarBall.real (ballQ r)) / g + 1), fun β hβ => ?_⟩
  have hβ0 : 0 ≤ β := le_trans (le_max_left _ _) hβ
  have hβ1 : 4 * Real.log (1 / haarBall.real (ballQ r)) / g + 1 ≤ β := le_trans (le_max_right _ _) hβ
  have hlt : 4 * Real.log (1 / haarBall.real (ballQ r)) < β * (y / 4 - 48 * r ^ 2) := by
    rw [← hg]
    have : 4 * Real.log (1 / haarBall.real (ballQ r)) / g < β := by linarith
    rw [div_lt_iff₀ hg0] at this
    linarith
  have hq : Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 < 1 := by
    have h4 := q_lt_one β (4 * y) r _ hh (by rw [show 4 * y / 16 = y / 4 by ring]; exact hlt)
    rwa [show 4 * y / 16 = y / 4 by ring] at h4
  refine ⟨hq, fun N _ m hN X hX => ?_⟩
  exact rarity_all4 N m hN β hβ0 y r hr0 hq.le X hX

end FoldQuarter

#print axioms FoldQuarter.rarity_plaq4
#print axioms FoldQuarter.rarity_sites4
#print axioms FoldQuarter.rarity_all4
#print axioms FoldQuarter.rarity_uniform4
