import FoldChess.AffineV1
import FoldChess.BridgeV1
/-!
The chessboard estimate for the concrete SU(2) Wilson measure on (ℤ/N)⁴, N = 2m, for every m ≥ 1.

Blocks w = (t0, t1, t2, t3) ∈ (ZMod N)⁴ are the unit cubes w + [0,1]⁴.  The transport Ψ w is the product over the
directions d of Φ d (t_d): the translation x_d ↦ x_d + t (t even) or the reflection x_d ↦ t + 1 − x_d (t odd), so
that Φ d (t) maps the cube at the origin to the cube at t.  The reflection through the lattice plane x_k = a is
R k a : x_k ↦ 2a − x_k.  The block functions are bounded measurable functions of the links of the cube at the origin
(links (x, μ) with x_μ = 0 and x_j ∈ {0, 1}).  We verify every field of `FoldChess.Data4`:
* Cauchy–Schwarz and positivity of the reflected pairing (from `PeierlsPermCS.wilson_refl_cs_dir` and
  `PeierlsPerm.wilson_rp_dir` by the translation invariance of the measure),
* the transport rule Ψ(ρ_a w) = Ψ w ∘ R k a (composition of affine maps; no finite check),
* the locality of the transported block functions (a computation of the k-th coordinate),
and obtain for every family F of block functions
  |∫ ∏_w Hf (F w) (Ψ w ω) dμ_W|^(N⁴) ≤ ∏_w ∫ ∏_{w'} Hf (F w) (Ψ w' ω) dμ_W.

Paper correspondence: one-scale rarity, the chessboard estimate on (ℤ/2h)⁴ for every h ≥ 1 (Fröhlich–Israel–Lieb–Simon).
-/

namespace FoldWilson

open MeasureTheory TorusRP LinkReflection PeierlsPerm PeierlsPermCS FoldAffine FoldChess

variable (N : ℕ) [NeZero N] (m : ℕ)

abbrev Cfg := Lk N → QBall

/-- parity of a block coordinate -/
def par (t : ZMod N) : Bool := decide (((t.val : ℕ) : ZMod 2) = 1)

/-- the transport of the blocks of one direction -/
noncomputable def Φ (d : Fin 4) (t : ZMod N) : Cfg N → Cfg N :=
  affC N d (par N t) (if par N t then t + 1 else t)

/-- the transport to the block (t0, t1, t2, t3) -/
noncomputable def Ψ (t0 t1 t2 t3 : ZMod N) (ω : Cfg N) : Cfg N :=
  Φ N 0 t0 (Φ N 1 t1 (Φ N 2 t2 (Φ N 3 t3 ω)))

/-- the reflection through the lattice plane x_k = a -/
noncomputable def R (k : Fin 4) (a : ZMod N) : Cfg N → Cfg N := affC N k true (a + a)

theorem par_rho (hN : N = 2 * m) (a t : ZMod N) : par N (rho a t) = !(par N t) := by
  have h2 : 2 ∣ N := ⟨m, by omega⟩
  have key : ∀ x : ZMod N, ((x.val : ℕ) : ZMod 2) = ZMod.castHom h2 (ZMod 2) x := fun x => by
    rw [ZMod.castHom_apply, ZMod.cast_eq_val]
  unfold par
  rw [key, key]
  unfold rho
  simp only [map_sub, map_add, map_one]
  generalize ZMod.castHom h2 (ZMod 2) a = p
  generalize ZMod.castHom h2 (ZMod 2) t = q
  revert p q; decide

theorem Φ_rho (hN : N = 2 * m) (d : Fin 4) (a t : ZMod N) (X : Cfg N) :
    Φ N d (rho a t) X = Φ N d t (affC N d true (a + a) X) := by
  unfold Φ
  rw [affC_comp, par_rho N m hN]
  cases hp : par N t
  · have e : rho a t + 1 = a + a - t := by unfold rho; ring
    simp [e]
  · have e : rho a t = a + a - (t + 1) := by unfold rho; ring
    simp [e]

theorem Φ_R_comm (j k : Fin 4) (hjk : j ≠ k) (t a : ZMod N) (ω : Cfg N) :
    Φ N j t (R N k a ω) = R N k a (Φ N j t ω) := by
  unfold Φ R; exact affC_comm N j k hjk _ _ _ _ ω

theorem tr0 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψ N (rho a t0) t1 t2 t3 ω = Ψ N t0 t1 t2 t3 (R N 0 a ω) := by
  simp only [Ψ]
  rw [Φ_R_comm N 3 0 (by decide), Φ_R_comm N 2 0 (by decide), Φ_R_comm N 1 0 (by decide), R,
    ← Φ_rho N m hN]

theorem tr1 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψ N t0 (rho a t1) t2 t3 ω = Ψ N t0 t1 t2 t3 (R N 1 a ω) := by
  simp only [Ψ]
  rw [Φ_R_comm N 3 1 (by decide), Φ_R_comm N 2 1 (by decide), R, ← Φ_rho N m hN]

theorem tr2 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψ N t0 t1 (rho a t2) t3 ω = Ψ N t0 t1 t2 t3 (R N 2 a ω) := by
  simp only [Ψ]
  rw [Φ_R_comm N 3 2 (by decide), R, ← Φ_rho N m hN]

theorem tr3 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψ N t0 t1 t2 (rho a t3) ω = Ψ N t0 t1 t2 t3 (R N 3 a ω) := by
  simp only [Ψ]
  rw [R, ← Φ_rho N m hN]

/-! ### the classes of functions and the reflection inequalities -/

/-- the shift bringing the plane `a` to the plane `0` -/
noncomputable def S (k : Fin 4) (a : ZMod N) : Cfg N → Cfg N := affC N k false (-a)

/-- the closed plus half of the plane `x_k = a` -/
def Good (k : Fin 4) (a : ZMod N) (f : Cfg N → ℝ) : Prop :=
  Measurable f ∧ HalfFunPerm N (Equiv.swap 0 k) m (fun ω => f (S N k a ω))

theorem R_S (k : Fin 4) (a : ZMod N) (ω : Cfg N) :
    R N k a (S N k a ω) = S N k a (reflPerm N (Equiv.swap 0 k) ω) := by
  unfold R S
  rw [← affC_true_zero, affC_comp, affC_comp]
  simp

theorem good_one (k : Fin 4) (a : ZMod N) : Good N m k a fun _ => 1 :=
  ⟨measurable_const, measurable_const, ⟨1, fun _ => by simp⟩, fun _ _ _ => rfl⟩

theorem good_mul (k : Fin 4) (a : ZMod N) (f g : Cfg N → ℝ) (hf : Good N m k a f) (hg : Good N m k a g) :
    Good N m k a fun ω => f ω * g ω := by
  obtain ⟨hfm, hfm', ⟨Cf, hCf⟩, hfd⟩ := hf
  obtain ⟨hgm, hgm', ⟨Cg, hCg⟩, hgd⟩ := hg
  refine ⟨hfm.mul hgm, hfm'.mul hgm', ⟨Cf * Cg, fun ω => ?_⟩, fun ω ω' h => ?_⟩
  · rw [abs_mul]; exact mul_le_mul (hCf ω) (hCg ω) (abs_nonneg _) (le_trans (abs_nonneg _) (hCf ω))
  · exact congrArg₂ (· * ·) (hfd ω ω' h) (hgd ω ω' h)

theorem pair_S (k : Fin 4) (a : ZMod N) (β : ℝ) (f g : Cfg N → ℝ) (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (R N k a ω) * g ω ∂(wilsonMeasure N β) =
      ∫ ω, f (S N k a (reflPerm N (Equiv.swap 0 k) ω)) * g (S N k a ω) ∂(wilsonMeasure N β) := by
  have hR : Measurable (R N k a) := measurable_affC N k true _
  have hm : Measurable (fun ω => f (R N k a ω) * g ω) := (hf.comp hR).mul hg
  rw [← wilson_affC_false_invariant N k (-a) β _ hm]
  congr 1; funext ω
  show f (R N k a (S N k a ω)) * g (S N k a ω) = _
  rw [R_S]

theorem cs_R (hN : N = 2 * m) (k : Fin 4) (a : ZMod N) (β : ℝ) (f g : Cfg N → ℝ)
    (hf : Good N m k a f) (hg : Good N m k a g) :
    (∫ ω, f (R N k a ω) * g ω ∂(wilsonMeasure N β)) ^ 2 ≤
      (∫ ω, f (R N k a ω) * f ω ∂(wilsonMeasure N β)) *
        (∫ ω, g (R N k a ω) * g ω ∂(wilsonMeasure N β)) := by
  rw [pair_S N k a β f g hf.1 hg.1, pair_S N k a β f f hf.1 hf.1, pair_S N k a β g g hg.1 hg.1]
  exact wilson_refl_cs_dir N k m hN β _ _ hf.2 hg.2

theorem rp_R (hN : N = 2 * m) (k : Fin 4) (a : ZMod N) (β : ℝ) (f : Cfg N → ℝ) (hf : Good N m k a f) :
    0 ≤ ∫ ω, f (R N k a ω) * f ω ∂(wilsonMeasure N β) := by
  rw [pair_S N k a β f f hf.1 hf.1]
  obtain ⟨_, hm, ⟨C, hC⟩, hd⟩ := hf
  exact wilson_rp_dir N id (fun _ => rfl) k m hN β _ hm C hC hd

/-! ### locality -/

/-- the links of the cube at the origin -/
def InCube (ℓ : Lk N) : Prop := ℓ.1 ℓ.2 = 0 ∧ ∀ j, ℓ.1 j = 0 ∨ ℓ.1 j = 1

/-- bounded measurable functions of the links of the cube at the origin -/
def Base (h : Cfg N → ℝ) : Prop :=
  Measurable h ∧ (∃ C, ∀ ω, |h ω| ≤ C) ∧ (∀ ω ω', (∀ ℓ, InCube N ℓ → ω ℓ = ω' ℓ) → h ω = h ω')

theorem affL_coord (j k : Fin 4) (f : Bool) (c : ZMod N) (ℓ : Lk N) :
    (affL N j f c ℓ).1 k = if k = j then nv N j f c ℓ else ℓ.1 k := by
  simp only [affL, Function.update_apply]

theorem det_affC (d : Fin 4) (f : Bool) (c : ZMod N) (ω ω' : Cfg N) (ℓ : Lk N)
    (h : ω (affL N d f c ℓ) = ω' (affL N d f c ℓ)) : affC N d f c ω ℓ = affC N d f c ω' ℓ := by
  unfold affC; rw [h]

theorem half_of_val (k : Fin 4) (ℓ : Lk N)
    (h : if ℓ.2 = k then (ℓ.1 k).val < m else (ℓ.1 k).val ≤ m) :
    fixP N m (linkPerm N (Equiv.swap 0 k) ℓ) ∨ posP N m (linkPerm N (Equiv.swap 0 k) ℓ) := by
  have e1 : tm N (linkPerm N (Equiv.swap 0 k) ℓ) = (ℓ.1 k).val := by
    simp [tm, linkPerm, sitePerm, Equiv.swap_apply_left]
  have e2 : (linkPerm N (Equiv.swap 0 k) ℓ).2 = 0 ↔ ℓ.2 = k := by
    simp only [linkPerm]; exact swap_eq_zero k ℓ.2
  unfold fixP posP
  rw [e1]
  by_cases hk : ℓ.2 = k
  · rw [if_pos hk] at h
    right; rw [if_pos (e2.2 hk)]; exact h
  · rw [if_neg hk] at h
    have hne : ¬ (linkPerm N (Equiv.swap 0 k) ℓ).2 = 0 := fun h' => hk (e2.1 h')
    rw [if_neg hne]
    rcases Nat.lt_or_ge 0 (ℓ.1 k).val with h0 | h0
    · rcases Nat.lt_or_ge (ℓ.1 k).val m with h1 | h1
      · right; exact ⟨h0, h1⟩
      · left; exact ⟨hne, Or.inr (by omega)⟩
    · left; exact ⟨hne, Or.inl (by omega)⟩

/-- the k-th coordinate after the transport of one block coordinate and the shift -/
theorem coord_value (hN : N = 2 * m) (k : Fin 4) (a t : ZMod N) (ht : inH m a t) (x : Site N) (μ : Fin 4)
    (hx : x k = 0 ∨ x k = 1) (hμ : μ = k → x k = 0) :
    let v := nv N k (par N t) (if par N t then t + 1 else t) (x, μ) + -a
    if μ = k then v.val < m else v.val ≤ m := by
  intro v
  unfold inH at ht
  have hlt : (t - a).val + 1 < N := by omega
  have hv : v = t - a ∨ (v = t - a + 1 ∧ μ ≠ k) := by
    simp only [v, nv]
    cases hp : par N t
    · rcases hx with hx | hx
      · left; simp [hx]; ring
      · right; refine ⟨by simp [hx]; ring, fun h => ?_⟩
        rw [hμ h] at hx
        have h1 := congrArg ZMod.val hx
        rw [ZMod.val_zero, ZMod.val_one_eq_one_mod, Nat.mod_eq_of_lt (by omega)] at h1
        omega
    · by_cases h : μ = k
      · left; simp [h, hμ h]; ring
      · rcases hx with hx | hx
        · right; exact ⟨by simp [h, hx]; ring, h⟩
        · left; simp [h, hx]; ring
  rcases hv with hv | ⟨hv, hne⟩
  · rw [hv]; split_ifs <;> omega
  · rw [hv, TorusRP.val_add_one N _ hlt, if_neg hne]; omega

end FoldWilson

#print axioms FoldWilson.tr0
#print axioms FoldWilson.cs_R
#print axioms FoldWilson.rp_R
#print axioms FoldWilson.coord_value
