import FoldChess.MixAV1
import FoldChess.QuarterCV1
/-!
The mixed chessboard for the plaquettes of the plane (0, 1): lattice-plane reflections in the directions 0, 1
(blocks = unit intervals) and link mid-plane reflections in the directions 2, 3 (blocks = sites).  The transport
in the directions 2, 3 is Φm_d(t) = (x_d ↦ x_d + t) for t even, (x_d ↦ t − x_d) for t odd.  Here: the transport
rules, the classes and the reflection inequalities of every direction, the locality of the transported block
functions (for the mid-plane directions: the plaquette indicator is gauge invariant), i.e. all fields of
`FoldChess.Data4` for the Wilson measure, N = 2m, m ≥ 2, β ≥ 0.

Paper correspondence: one-scale rarity, the mixed chessboard (rate 1 for one orientation).
-/

namespace FoldMix

open MeasureTheory TorusRP LinkReflection PeierlsPerm FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy
  FoldMid MidRP TorusGauge GaugeFix Finset

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the transport of the sites of the directions 2, 3 -/
noncomputable def Φm (d : Fin 4) (t : ZMod N) : Cfg N → Cfg N := affC N d (par N t) t

/-- the mixed transport to the block (t0, t1, t2, t3) -/
noncomputable def Ψm (t0 t1 t2 t3 : ZMod N) (ω : Cfg N) : Cfg N :=
  FoldWilson.Φ N 0 t0 (FoldWilson.Φ N 1 t1 (Φm N 2 t2 (Φm N 3 t3 ω)))

/-- the reflections: lattice planes in the directions 0, 1, mid-planes in 2, 3 -/
noncomputable def Rx (k : Fin 4) (a : ZMod N) : Cfg N → Cfg N := if k = 2 ∨ k = 3 then Rm N k a else R N k a

/-- the classes -/
def Gx (k : Fin 4) (a : ZMod N) (f : Cfg N → ℝ) : Prop := if k = 2 ∨ k = 3 then MidGood N m k a f else Good N m k a f

theorem Φm_rho (hN : N = 2 * m) (d : Fin 4) (a t : ZMod N) (X : Cfg N) :
    Φm N d (rho a t) X = Φm N d t (affC N d true (a + a - 1) X) := by
  unfold Φm
  rw [affC_comp, par_rho N m hN]
  cases hp : par N t <;> simp [rho]

theorem Φm_comm (j k : Fin 4) (hjk : j ≠ k) (t : ZMod N) (f : Bool) (c : ZMod N) (ω : Cfg N) :
    Φm N j t (affC N k f c ω) = affC N k f c (Φm N j t ω) := by
  unfold Φm; exact affC_comm N j k hjk _ _ _ _ ω

theorem Φ_comm (j k : Fin 4) (hjk : j ≠ k) (t : ZMod N) (f : Bool) (c : ZMod N) (ω : Cfg N) :
    FoldWilson.Φ N j t (affC N k f c ω) = affC N k f c (FoldWilson.Φ N j t ω) := by
  unfold FoldWilson.Φ; exact affC_comm N j k hjk _ _ _ _ ω

theorem trx0 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψm N (rho a t0) t1 t2 t3 ω = Ψm N t0 t1 t2 t3 (Rx N 0 a ω) := by
  simp only [Ψm]
  rw [Rx, if_neg (by decide), R, Φm_comm N 3 0 (by decide), Φm_comm N 2 0 (by decide), Φ_comm N 1 0 (by decide), ← Φ_rho N m hN]

theorem trx1 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψm N t0 (rho a t1) t2 t3 ω = Ψm N t0 t1 t2 t3 (Rx N 1 a ω) := by
  simp only [Ψm]
  rw [Rx, if_neg (by decide), R, Φm_comm N 3 1 (by decide), Φm_comm N 2 1 (by decide), ← Φ_rho N m hN]

theorem trx2 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψm N t0 t1 (rho a t2) t3 ω = Ψm N t0 t1 t2 t3 (Rx N 2 a ω) := by
  simp only [Ψm]
  rw [Rx, if_pos (by decide), Rm, Φm_comm N 3 2 (by decide), ← Φm_rho N m hN]

theorem trx3 (hN : N = 2 * m) (a t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    Ψm N t0 t1 t2 (rho a t3) ω = Ψm N t0 t1 t2 t3 (Rx N 3 a ω) := by
  simp only [Ψm]
  rw [Rx, if_pos (by decide), Rm, ← Φm_rho N m hN]

/-- the link read by the mixed transport -/
def Ltm (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) : Lk N :=
  affL N 3 (par N t3) t3 (affL N 2 (par N t2) t2
    (affL N 1 (par N t1) (cof N t1) (affL N 0 (par N t0) (cof N t0) ℓ)))

theorem measurable_Ψm (t0 t1 t2 t3 : ZMod N) : Measurable (Ψm N t0 t1 t2 t3) := by
  unfold Ψm FoldWilson.Φ Φm
  exact (measurable_affC N 0 _ _).comp ((measurable_affC N 1 _ _).comp
    ((measurable_affC N 2 _ _).comp (measurable_affC N 3 _ _)))

theorem det_Ψm (t0 t1 t2 t3 : ZMod N) (ω ω' : Cfg N) (ℓ : Lk N)
    (h : ω (Ltm N t0 t1 t2 t3 ℓ) = ω' (Ltm N t0 t1 t2 t3 ℓ)) : Ψm N t0 t1 t2 t3 ω ℓ = Ψm N t0 t1 t2 t3 ω' ℓ := by
  unfold Ψm FoldWilson.Φ Φm
  apply det_affC; apply det_affC; apply det_affC; apply det_affC
  exact h

theorem Ltm_coord0 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Ltm N t0 t1 t2 t3 ℓ).1 0 = nv N 0 (par N t0) (cof N t0) ℓ := by
  simp only [Ltm]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_neg (by decide),
    affL_coord, if_pos rfl]

theorem Ltm_coord1 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Ltm N t0 t1 t2 t3 ℓ).1 1 = nv N 1 (par N t1) (cof N t1) ℓ := by
  simp only [Ltm]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_pos rfl,
    nv_affL N 0 1 (by decide)]

theorem Ltm_coord2 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Ltm N t0 t1 t2 t3 ℓ).1 2 = nv N 2 (par N t2) t2 ℓ := by
  simp only [Ltm]
  rw [affL_coord, if_neg (by decide), affL_coord, if_pos rfl, nv_affL N 1 2 (by decide),
    nv_affL N 0 2 (by decide)]

theorem Ltm_coord3 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Ltm N t0 t1 t2 t3 ℓ).1 3 = nv N 3 (par N t3) t3 ℓ := by
  simp only [Ltm]
  rw [affL_coord, if_pos rfl, nv_affL N 2 3 (by decide), nv_affL N 1 3 (by decide),
    nv_affL N 0 3 (by decide)]

/-- the links of the plaquette square at the origin of the plane (0, 1) -/
def InSq (ℓ : Lk N) : Prop := (ℓ.2 = 0 ∨ ℓ.2 = 1) ∧ ℓ.1 2 = 0 ∧ ℓ.1 3 = 0

/-- **Mid-plane locality**: a function of the square, transported, is in the mid-plane class. -/
theorem midloc (hN : N = 2 * m) (k : Fin 4) (hk : k = 2 ∨ k = 3) (a t : ZMod N) (L : Lk N → Lk N)
    (P : Cfg N → Cfg N) (hP : Measurable P) (hdet : ∀ ω ω' ℓ, ω (L ℓ) = ω' (L ℓ) → P ω ℓ = P ω' ℓ)
    (hsnd : ∀ ℓ, (L ℓ).2 = ℓ.2) (hcoord : ∀ ℓ, (L ℓ).1 k = nv N k (par N t) t ℓ)
    (ht : inH m a t) (h : Cfg N → ℝ) (hm : Measurable h) (C : ℝ) (hC : ∀ ω, |h ω| ≤ C)
    (hd : ∀ ω ω', (∀ ℓ, InSq N ℓ → ω ℓ = ω' ℓ) → h ω = h ω')
    (hgi : ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : ℍr)‖ = 1) → ∀ ω,
      h (P (Sm N k a (cfgPerm N (Equiv.swap 0 k) (act (src N) (tgt N) g ω)))) =
        h (P (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω)))) :
    MidGood N m k a (fun ω => h (P ω)) := by
  refine ⟨hm.comp hP, ⟨C, fun ω => hC _⟩, fun ω ω' hag => ?_, fun g hg ω => hgi g hg ω⟩
  show h (P (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω))) = h (P (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω')))
  apply hd
  intro ℓ hℓ
  apply hdet
  apply det_affC
  show ω (linkPerm N (Equiv.swap 0 k) (affL N k false (1 - a) (L ℓ))) =
    ω' (linkPerm N (Equiv.swap 0 k) (affL N k false (1 - a) (L ℓ)))
  apply hag
  right
  obtain ⟨x, μ⟩ := ℓ
  obtain ⟨hμ, hx2, hx3⟩ := hℓ
  have hxk : x k = 0 := by rcases hk with rfl | rfl; exact hx2; exact hx3
  have hμk : μ ≠ k := by
    intro e; subst e; rcases hk with h' | h' <;> rcases hμ with h'' | h'' <;> simp_all
  have hv : (affL N k false (1 - a) (L (x, μ))).1 k = (t - a) + 1 := by
    rw [affL_coord, if_pos rfl]
    show (L (x, μ)).1 k + (1 - a) = _
    rw [hcoord]
    unfold nv
    cases par N t <;> simp [hμk, hxk] <;> ring
  have htm : tm N (linkPerm N (Equiv.swap 0 k) (affL N k false (1 - a) (L (x, μ)))) =
      ((affL N k false (1 - a) (L (x, μ))).1 k).val := by
    simp [tm, linkPerm, sitePerm, Equiv.swap_apply_left]
  have hsnd' : (linkPerm N (Equiv.swap 0 k) (affL N k false (1 - a) (L (x, μ)))).2 ≠ 0 := by
    simp only [linkPerm, affL_snd, hsnd]
    intro h0; exact hμk ((swap_eq_zero k μ).1 h0)
  unfold posM
  rw [if_neg hsnd', htm, hv]
  unfold inH at ht
  rw [TorusRP.val_add_one N _ (by omega)]
  omega

end FoldMix

#print axioms FoldMix.trx0
#print axioms FoldMix.trx2
#print axioms FoldMix.midloc
