import FoldChess.RarityEvenV1
/-!
Volume-uniform rarity in plaquette form, and the threshold.

* `ballQ_pos` : h(r) = Haar{U ∈ SU(2) : ‖U − 1‖ < r} > 0 for r > 0 (the hypothesis of `rarity_even` is satisfiable).
* `rarity_plaq` : for X a set of blocks with all coordinates even (the sublattice (2ℤ/2m)⁴),
    ∫ ∏_{w ∈ X} 1[y < 1 − Re U_{(w; μν)}] dμ_W ≤ Z · q^{|X|},   q = e^{β(48 r² − y/16)} / h(r)⁴,
  every m ≥ 1, β ≥ 0, r > 0; q does not depend on m.
* `q_lt_one` : q < 1 as soon as β (y/16 − 48 r²) > 4 log(1/h(r)).

Paper correspondence: one-scale rarity (Proposition P), rate 1/16, threshold in terms of the cap volume h(r).
-/

namespace FoldEntropy

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls Finset OSGap

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- **The cap has positive Haar measure.** -/
theorem ballQ_pos (r : ℝ) (hr : 0 < r) : 0 < haarBall.real (ballQ r) := by
  have hmeas : MeasurableSet (ballQ r) := measurableSet_ballQ r
  have hpre : incl ⁻¹' ballQ r = {U : SU2 | ‖(U : ℍr) - 1‖ < r} := by
    ext U
    simp only [Set.mem_preimage, ballQ, Set.mem_setOf_eq, incl]
    constructor
    · exact fun h => h.1
    · intro h; exact ⟨h, mem_sphere_zero_iff_norm.1 U.2⟩
  have hopen : IsOpen {U : SU2 | ‖(U : ℍr) - 1‖ < r} :=
    isOpen_lt (continuous_norm.comp (continuous_subtype_val.sub continuous_const)) continuous_const
  have hne : ({U : SU2 | ‖(U : ℍr) - 1‖ < r}).Nonempty := ⟨1, by simp [hr]⟩
  have hpos := hopen.measure_pos (haarProb SU2) hne
  rw [Measure.real, haarBall, Measure.map_apply continuous_incl.measurable hmeas, hpre]
  exact ENNReal.toReal_pos hpos.ne' (measure_ne_top _ _)

/-- **The threshold**: q < 1 when β (y/16 − 48 r²) > 4 log(1/h). -/
theorem q_lt_one (β y r h : ℝ) (hh : 0 < h) (hβ : 4 * Real.log (1 / h) < β * (y / 16 - 48 * r ^ 2)) :
    Real.exp (β * (48 * r ^ 2 - y / 16)) / h ^ 4 < 1 := by
  rw [div_lt_one (pow_pos hh 4)]
  have e : h ^ 4 = Real.exp (4 * Real.log h) := by
    rw [show (4 : ℝ) * Real.log h = ((4 : ℕ) : ℝ) * Real.log h by norm_num, Real.exp_nat_mul, Real.exp_log hh]
  rw [e, Real.exp_lt_exp]
  have hl : Real.log (1 / h) = - Real.log h := by rw [one_div, Real.log_inv]
  rw [hl] at hβ
  linarith

/-- **Volume-uniform rarity of large plaquettes on the even sublattice**, every m ≥ 1. -/
theorem rarity_plaq (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ) (hr : 0 < r)
    (X : Finset (Z4 N)) (hX : X ⊆ evens N ×ˢ (evens N ×ˢ (evens N ×ˢ evens N))) :
    ∫ ω, ∏ w ∈ X, (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
  set F : ZMod N → ZMod N → ZMod N → ZMod N → Bool := fun t0 t1 t2 t3 => decide ((t0, t1, t2, t3) ∈ X)
  have hr' := rarity_even N m hN β hβ μ ν hμν y r (ballQ_pos r hr) F
  have hterm : ∀ (ω : Cfg N) (q : Z4 N), Hf N μ ν y (F q.1 q.2.1 q.2.2.1 q.2.2.2) (Ψ N q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      if q ∈ X then (if y < 1 - (hol N ω ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
      else 1 := by
    intro ω q
    by_cases hq : q ∈ X
    · have he := hX hq
      simp only [mem_product, evens, mem_filter, mem_univ, true_and] at he
      simp only [F, Prod.mk.eta, hq, decide_true, Hf, if_true, big,
        re_hol_Ψ_even N _ _ _ _ he.1 he.2.1 he.2.2.1 he.2.2.2]
    · simp [F, hq, Hf]
  have eL : V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F = ∫ ω, ∏ w ∈ X,
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) := by
    unfold V4; congr 1; funext ω
    rw [prod4]
    simp only [hterm]
    rw [Finset.prod_ite_mem, univ_inter]
  have eR : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
      Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4 else 1) =
      (Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
    rw [prod4]
    simp only [F, Prod.mk.eta, decide_eq_true_eq]
    rw [Finset.prod_ite_mem, univ_inter, prod_const]
  rw [← eL, ← eR]
  exact hr'

end FoldEntropy

#print axioms FoldEntropy.ballQ_pos
#print axioms FoldEntropy.q_lt_one
#print axioms FoldEntropy.rarity_plaq
