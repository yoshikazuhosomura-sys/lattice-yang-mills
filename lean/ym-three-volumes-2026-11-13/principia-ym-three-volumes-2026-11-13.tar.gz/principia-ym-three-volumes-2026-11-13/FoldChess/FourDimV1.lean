import FoldChess.OneDimV1
/-!
The chessboard estimate on the four-dimensional torus of even side n = 2m, abstract form, every m ≥ 1.

Families are F : ZMod n → ZMod n → ZMod n → ZMod n → I (one value per block).  The folds in the direction k act on
the k-th argument (the families of the remaining directions are the values).  If V satisfies the reflection
Cauchy–Schwarz inequality for the folds at every plane of every direction, and V ≥ 0 on the families that are
constant in the first direction, then
  |V(F)|^(n⁴) ≤ ∏ over the blocks w of V(the constant family F w),
and, if moreover V(constant family i) ≤ c(i)^(n⁴) with c ≥ 0, then |V(F)| ≤ ∏_w c(F w).

Paper correspondence: one-scale rarity, the chessboard estimate on (ℤ/2h)⁴ for every h ≥ 1.
-/

namespace FoldChess

open Finset

theorem lift_pow {ι : Type*} [Fintype ι] (x : ℝ) (hx : 0 ≤ x) (A B : ι → ℝ) (k : ℕ)
    (hA : ∀ i, 0 ≤ A i) (h1 : x ≤ ∏ i, A i) (h2 : ∀ i, A i ^ k ≤ B i) : x ^ k ≤ ∏ i, B i :=
  calc x ^ k ≤ (∏ i, A i) ^ k := pow_le_pow_left₀ hx h1 k
    _ = ∏ i, A i ^ k := (Finset.prod_pow _ _ _).symm
    _ ≤ ∏ i, B i := Finset.prod_le_prod (fun i _ => pow_nonneg (hA i) k) (fun i _ => h2 i)

theorem prod_pow_le {ι : Type*} [Fintype ι] (A B : ι → ℝ) (k : ℕ) (hA : ∀ i, 0 ≤ A i)
    (h : ∀ i, A i ^ k ≤ B i) : (∏ i, A i) ^ k ≤ ∏ i, B i :=
  lift_pow _ (Finset.prod_nonneg (fun i _ => hA i)) A B k hA le_rfl h

variable {n : ℕ} [NeZero n] (m : ℕ) {I : Type*}

/-- **The four-dimensional chessboard estimate (abstract), every even side `n = 2m`.** -/
theorem chess_four (hn : n = 2 * m) (V : (ZMod n → ZMod n → ZMod n → ZMod n → I) → ℝ)
    (h0 : ∀ a F, V F ^ 2 ≤ V (foldP m a F) * V (foldM m a F))
    (h1 : ∀ a F, V F ^ 2 ≤ V (fun t0 => foldP m a (F t0)) * V (fun t0 => foldM m a (F t0)))
    (h2 : ∀ a F, V F ^ 2 ≤
      V (fun t0 t1 => foldP m a (F t0 t1)) * V (fun t0 t1 => foldM m a (F t0 t1)))
    (h3 : ∀ a F, V F ^ 2 ≤
      V (fun t0 t1 t2 => foldP m a (F t0 t1 t2)) * V (fun t0 t1 t2 => foldM m a (F t0 t1 t2)))
    (hpos : ∀ G, 0 ≤ V (fun _ => G)) (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    |V F| ^ (n ^ 4) ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, V (fun _ _ _ _ => F t0 t1 t2 t3) := by
  -- level 0
  have s0 : |V F| ^ n ≤ ∏ t0, V (fun _ => F t0) := chess_one m hn V h0 (fun i => hpos i) F
  -- level 1
  have s1 : ∀ t0, V (fun _ => F t0) ^ n ≤ ∏ t1, V (fun _ _ => F t0 t1) := by
    intro t0
    have := chess_one m hn (fun G => V (fun _ => G)) (fun a G => h1 a (fun _ => G))
      (fun i => hpos (fun _ => i)) (F t0)
    rwa [abs_of_nonneg (hpos _)] at this
  -- level 2
  have s2 : ∀ t0 t1, V (fun _ _ => F t0 t1) ^ n ≤ ∏ t2, V (fun _ _ _ => F t0 t1 t2) := by
    intro t0 t1
    have := chess_one m hn (fun G => V (fun _ _ => G)) (fun a G => h2 a (fun _ _ => G))
      (fun i => hpos (fun _ _ => i)) (F t0 t1)
    rwa [abs_of_nonneg (hpos _)] at this
  -- level 3
  have s3 : ∀ t0 t1 t2, V (fun _ _ _ => F t0 t1 t2) ^ n ≤ ∏ t3, V (fun _ _ _ _ => F t0 t1 t2 t3) := by
    intro t0 t1 t2
    have := chess_one m hn (fun G => V (fun _ _ _ => G)) (fun a G => h3 a (fun _ _ _ => G))
      (fun i => hpos (fun _ _ _ => i)) (F t0 t1 t2)
    rwa [abs_of_nonneg (hpos _)] at this
  have p1 : ∀ t0 t1, 0 ≤ V (fun _ _ => F t0 t1) := fun t0 t1 => hpos _
  have p2 : ∀ t0 t1 t2, 0 ≤ V (fun _ _ _ => F t0 t1 t2) := fun t0 t1 t2 => hpos _
  -- combine
  have c1 : (|V F| ^ n) ^ n ≤ ∏ t0, ∏ t1, V (fun _ _ => F t0 t1) :=
    lift_pow _ (pow_nonneg (abs_nonneg _) _) _ _ n (fun t0 => hpos _) s0 s1
  have c2 : ((|V F| ^ n) ^ n) ^ n ≤ ∏ t0, ∏ t1, ∏ t2, V (fun _ _ _ => F t0 t1 t2) :=
    lift_pow _ (pow_nonneg (pow_nonneg (abs_nonneg _) _) _) _ _ n
      (fun t0 => Finset.prod_nonneg (fun t1 _ => p1 t0 t1)) c1
      (fun t0 => prod_pow_le _ _ n (p1 t0) (s2 t0))
  have c3 : (((|V F| ^ n) ^ n) ^ n) ^ n ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, V (fun _ _ _ _ => F t0 t1 t2 t3) :=
    lift_pow _ (pow_nonneg (pow_nonneg (pow_nonneg (abs_nonneg _) _) _) _) _ _ n
      (fun t0 => Finset.prod_nonneg (fun t1 _ => Finset.prod_nonneg (fun t2 _ => p2 t0 t1 t2))) c2
      (fun t0 => prod_pow_le _ _ n (fun t1 => Finset.prod_nonneg (fun t2 _ => p2 t0 t1 t2))
        (fun t1 => prod_pow_le _ _ n (p2 t0 t1) (s3 t0 t1)))
  have e : (((|V F| ^ n) ^ n) ^ n) ^ n = |V F| ^ (n ^ 4) := by
    rw [← pow_mul, ← pow_mul, ← pow_mul]; ring_nf
  rw [e] at c3; exact c3

/-- **The root form**: per-block bounds on the constant families give a product bound. -/
theorem chess_four_root (hn : n = 2 * m) (V : (ZMod n → ZMod n → ZMod n → ZMod n → I) → ℝ)
    (h0 : ∀ a F, V F ^ 2 ≤ V (foldP m a F) * V (foldM m a F))
    (h1 : ∀ a F, V F ^ 2 ≤ V (fun t0 => foldP m a (F t0)) * V (fun t0 => foldM m a (F t0)))
    (h2 : ∀ a F, V F ^ 2 ≤
      V (fun t0 t1 => foldP m a (F t0 t1)) * V (fun t0 t1 => foldM m a (F t0 t1)))
    (h3 : ∀ a F, V F ^ 2 ≤
      V (fun t0 t1 t2 => foldP m a (F t0 t1 t2)) * V (fun t0 t1 t2 => foldM m a (F t0 t1 t2)))
    (hpos : ∀ G, 0 ≤ V (fun _ => G)) (c : I → ℝ) (hc : ∀ i, 0 ≤ c i)
    (hconst : ∀ i, V (fun _ _ _ _ => i) ≤ c i ^ (n ^ 4))
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    |V F| ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3) := by
  have hmain := chess_four m hn V h0 h1 h2 h3 hpos F
  have hP : 0 ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3) :=
    Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ =>
      Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => hc _
  have hle : |V F| ^ (n ^ 4) ≤ (∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3)) ^ (n ^ 4) := by
    refine le_trans hmain ?_
    simp only [← Finset.prod_pow]
    exact Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ =>
        Finset.prod_nonneg fun _ _ => hpos _)
      (fun t0 _ => Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ =>
        Finset.prod_nonneg fun _ _ => hpos _)
      (fun t1 _ => Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ => hpos _)
      (fun t2 _ => Finset.prod_le_prod (fun _ _ => hpos _) (fun t3 _ => hconst _))))
  have hn4 : n ^ 4 ≠ 0 := pow_ne_zero _ (NeZero.ne n)
  exact (pow_le_pow_iff_left₀ (abs_nonneg _) hP hn4).mp hle

end FoldChess

#print axioms FoldChess.chess_four
#print axioms FoldChess.chess_four_root
