import FoldChess.MixBV1
/-!
**The mixed chessboard and the rarity with rate 1 for the plaquettes of the plane (0, 1)** on (ℤ/2m)⁴, m ≥ 2, β ≥ 0.
All fields of `FoldChess.Data4` for the mixed transport (`dataMix`); the uniform family forces all N⁴ plaquettes
(w; 01) to be large (the mixed transport moves (0; 01) to (w; 01) for every block w), so
  ∫ ∏_{x∈S} 1[y < 1 − Re U_{(x;01)}] dμ_W ≤ Z q₁^{|S|},   q₁ = e^{β(48 r² − y)} / h(r)⁴,
for every finite set S of sites (`rarity_sites_mix`).

Paper correspondence: one-scale rarity, the mixed chessboard (lattice planes in the plane, link mid-planes off it).
-/

namespace FoldMix

open MeasureTheory TorusRP LinkReflection PeierlsPerm FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy
  FoldMid FoldQuarter MidRP TorusGauge GaugeFix Finset

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ)

theorem big_dep_sq (y : ℝ) (ω ω' : Cfg N) (h : ∀ ℓ, InSq N ℓ → ω ℓ = ω' ℓ) : big N 0 1 y ω = big N 0 1 y ω' := by
  have i1 : InSq N ((0 : Site N), 0) := ⟨Or.inl rfl, rfl, rfl⟩
  have i4 : InSq N ((0 : Site N), 1) := ⟨Or.inr rfl, rfl, rfl⟩
  have i2 : InSq N ((0 : Site N) + ev N 0, 1) := ⟨Or.inr rfl, by simp [ev, Pi.single_apply], by simp [ev, Pi.single_apply]⟩
  have i3 : InSq N ((0 : Site N) + ev N 1, 0) := ⟨Or.inl rfl, by simp [ev, Pi.single_apply], by simp [ev, Pi.single_apply]⟩
  have e : hol N ω (p0 N 0 1) = hol N ω' (p0 N 0 1) := by
    simp only [hol, holQ, Uq, p0]
    rw [h _ i1, h _ i2, h _ i3, h _ i4]
  unfold big; rw [e]

theorem re_conj (g q : ℍr) (hg : ‖g‖ = 1) : (g * q * star g).re = q.re := by
  rw [re_cyc, ← mul_assoc, Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, hg]
  simp

/-- one step of the image base point -/
def sq (d : Fin 4) (f : Bool) (c : ZMod N) (x : Site N) : Site N := Function.update x d (nb N d f c 0 1 x)

/-- the plaquette read by the transported block function through the shift and the relabelling -/
def qf (k : Fin 4) (a t0 t1 t2 t3 : ZMod N) : Lk N × Fin 4 :=
  plaqPerm N (Equiv.swap 0 k) ((sq N k false (1 - a) (sq N 3 (par N t3) t3 (sq N 2 (par N t2) t2
    (sq N 1 (par N t1) (if par N t1 then t1 + 1 else t1) (sq N 0 (par N t0) (if par N t0 then t0 + 1 else t0) 0)))),
    0), 1)

theorem big_gauge (k : Fin 4) (a t0 t1 t2 t3 : ZMod N) (y : ℝ) (g : Site N → QBall)
    (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1) (ω : Cfg N) :
    big N 0 1 y (Ψm N t0 t1 t2 t3 (Sm N k a (cfgPerm N (Equiv.swap 0 k) (act (src N) (tgt N) g ω)))) =
      big N 0 1 y (Ψm N t0 t1 t2 t3 (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω))) := by
  have hτ : ∀ j, (Equiv.swap 0 k) ((Equiv.swap 0 k) j) = j := fun j => Equiv.swap_apply_self 0 k j
  have hq : ∀ X : Cfg N,
      (hol N (Ψm N t0 t1 t2 t3 (Sm N k a (cfgPerm N (Equiv.swap 0 k) X))) (p0 N 0 1)).re =
        (hol N X (qf N k a t0 t1 t2 t3)).re := by
    intro X
    unfold Ψm FoldWilson.Φ Φm Sm p0
    rw [re_hol_affC N 0 _ _ _ _ 0 1 (by decide), re_hol_affC N 1 _ _ _ _ 0 1 (by decide),
      re_hol_affC N 2 _ _ _ _ 0 1 (by decide), re_hol_affC N 3 _ _ _ _ 0 1 (by decide),
      re_hol_affC N k _ _ _ _ 0 1 (by decide), re_hol_cfgPerm N _ hτ]
    rfl
  set q := qf N k a t0 t1 t2 t3
  have e : (hol N (act (src N) (tgt N) g ω) q).re = (hol N ω q).re := by
    rw [hol_act N g hg]; exact re_conj _ _ (hg _)
  simp only [big, hq, e]

theorem loc_mid_Hf (hN : N = 2 * m) (k : Fin 4) (hk : k = 2 ∨ k = 3) (a t0 t1 t2 t3 : ZMod N) (y : ℝ) (i : Bool)
    (t : ZMod N) (hcoord : ∀ ℓ, (Ltm N t0 t1 t2 t3 ℓ).1 k = nv N k (par N t) t ℓ) (ht : inH m a t) :
    MidGood N m k a (fun ω => Hf N 0 1 y i (Ψm N t0 t1 t2 t3 ω)) := by
  cases i
  · exact midloc N m hN k hk a t (Ltm N t0 t1 t2 t3) (Ψm N t0 t1 t2 t3) (measurable_Ψm N t0 t1 t2 t3)
      (det_Ψm N t0 t1 t2 t3) (fun ℓ => rfl) hcoord ht (fun _ => 1) measurable_const 1 (fun _ => by simp)
      (fun _ _ _ => rfl) (fun _ _ _ => rfl)
  · exact midloc N m hN k hk a t (Ltm N t0 t1 t2 t3) (Ψm N t0 t1 t2 t3) (measurable_Ψm N t0 t1 t2 t3)
      (det_Ψm N t0 t1 t2 t3) (fun ℓ => rfl) hcoord ht (big N 0 1 y) (base_big N 0 1 (by decide) y).1 1
      (fun ω => by unfold big; split_ifs <;> simp) (big_dep_sq N y)
      (fun g hg ω => big_gauge N k a t0 t1 t2 t3 y g hg ω)

/-- **All the data of the mixed chessboard for the Wilson measure** (N = 2m, m ≥ 2, β ≥ 0). -/
theorem dataMix (hN : N = 2 * m) (hM : 2 ≤ m) (β : ℝ) (hβ : 0 ≤ β) (y : ℝ) :
    Data4 m (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) (Rx N) (Gx N m) where
  one := fun k a => by
    unfold Gx; split_ifs
    · exact midGood_one N m k a
    · exact good_one N m k a
  mul := fun k a f g hf hg => by
    unfold Gx at hf hg ⊢; split_ifs at hf hg ⊢
    · exact midGood_mul N m k a f g hf hg
    · exact good_mul N m k a f g hf hg
  cs := fun k a f g hf hg => by
    unfold Gx at hf hg; unfold Rx; split_ifs at hf hg ⊢
    · exact cs_mid N m hN hM k a β hβ f g hf hg
    · exact cs_R N m hN k a β f g hf hg
  rp := fun k a f hf => by
    unfold Gx at hf; unfold Rx; split_ifs at hf ⊢
    · exact rp_mid N m hN hM k a β hβ f hf
    · exact rp_R N m hN k a β f hf
  tr0 := trx0 N m hN
  tr1 := trx1 N m hN
  tr2 := trx2 N m hN
  tr3 := trx3 N m hN
  loc0 := fun a t0 t1 t2 t3 i ht => by
    unfold Gx; rw [if_neg (by decide)]
    exact loc_general N m hN 0 a t0 (Ltm N t0 t1 t2 t3) (Ψm N t0 t1 t2 t3) (measurable_Ψm N t0 t1 t2 t3)
      (det_Ψm N t0 t1 t2 t3) (fun ℓ => rfl) (Ltm_coord0 N t0 t1 t2 t3) ht (Hf N 0 1 y i) (base_Hf N 0 1 (by decide) y i)
  loc1 := fun a t0 t1 t2 t3 i ht => by
    unfold Gx; rw [if_neg (by decide)]
    exact loc_general N m hN 1 a t1 (Ltm N t0 t1 t2 t3) (Ψm N t0 t1 t2 t3) (measurable_Ψm N t0 t1 t2 t3)
      (det_Ψm N t0 t1 t2 t3) (fun ℓ => rfl) (Ltm_coord1 N t0 t1 t2 t3) ht (Hf N 0 1 y i) (base_Hf N 0 1 (by decide) y i)
  loc2 := fun a t0 t1 t2 t3 i ht => by
    unfold Gx; rw [if_pos (by decide)]
    exact loc_mid_Hf N m hN 2 (Or.inl rfl) a t0 t1 t2 t3 y i t2 (Ltm_coord2 N t0 t1 t2 t3) ht
  loc3 := fun a t0 t1 t2 t3 i ht => by
    unfold Gx; rw [if_pos (by decide)]
    exact loc_mid_Hf N m hN 3 (Or.inr rfl) a t0 t1 t2 t3 y i t3 (Ltm_coord3 N t0 t1 t2 t3) ht

theorem V4_false_mix (β : ℝ) (y : ℝ) :
    V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) (fun _ _ _ _ => false) = Zw N β := by
  unfold V4 Zw; simp [Hf]

/-- the mixed transport moves (0; 01) to (w; 01) -/
theorem re_hol_Ψm (t0 t1 t2 t3 : ZMod N) (ω : Cfg N) :
    (hol N (Ψm N t0 t1 t2 t3 ω) (p0 N 0 1)).re = (hol N ω ((vec N t0 t1 t2 t3, 0), 1)).re := by
  unfold Ψm FoldWilson.Φ Φm p0
  rw [re_hol_affC N 0 _ _ _ _ 0 1 (by decide), re_hol_affC N 1 _ _ _ _ 0 1 (by decide),
    re_hol_affC N 2 _ _ _ _ 0 1 (by decide), re_hol_affC N 3 _ _ _ _ 0 1 (by decide)]
  apply congrArg (fun q : Lk N × Fin 4 => (hol N ω q).re)
  refine Prod.ext (Prod.ext ?_ rfl) rfl
  funext j
  fin_cases j <;> simp [nb, vec, Function.update_apply, Pi.single_apply] <;>
    first | (cases par N t0 <;> simp) | (cases par N t1 <;> simp) | (cases par N t2 <;> simp) |
      (cases par N t3 <;> simp)

theorem action_le_mix (y : ℝ) (ω : Cfg N)
    (h : ∀ t0 t1 t2 t3, big N 0 1 y (Ψm N t0 t1 t2 t3 ω) ≠ 0) :
    action N ω ≤ (plaqs N).card - y * N ^ 4 := by
  set E : Finset (ZMod N × ZMod N × ZMod N × ZMod N) := univ
  have hE : E.card = N ^ 4 := by
    simp only [E, card_univ, Fintype.card_prod, ZMod.card]; ring
  let pl : ZMod N × ZMod N × ZMod N × ZMod N → Lk N × Fin 4 :=
    fun q => ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, 0), 1)
  have hinj : Set.InjOn pl E := by
    intro q _ q' _ hq
    have := vec_inj N (congrArg (fun p : Lk N × Fin 4 => p.1.1) hq)
    obtain ⟨a, b, c, d⟩ := this
    exact Prod.ext a (Prod.ext b (Prod.ext c d))
  have hsub : E.image pl ⊆ plaqs N := by
    intro p hp
    obtain ⟨q, _, rfl⟩ := mem_image.mp hp
    simp only [plaqs, mem_filter, mem_univ, true_and, pl]; decide
  have hbig : ∀ q ∈ E, y < 1 - (hol N ω (pl q)).re := by
    intro q _
    have hb := h q.1 q.2.1 q.2.2.1 q.2.2.2
    unfold big at hb
    rw [re_hol_Ψm N _ _ _ _ ω] at hb
    by_contra hc
    exact hb (if_neg hc)
  have hs1 : y * N ^ 4 ≤ ∑ p ∈ E.image pl, (1 - (hol N ω p).re) := by
    rw [sum_image (fun a ha b hb h => hinj ha hb h)]
    have e : y * (N : ℝ) ^ 4 = ∑ _q ∈ E, y := by
      rw [sum_const, hE, nsmul_eq_mul]; push_cast; ring
    rw [e]
    exact sum_le_sum (fun q hq => (hbig q hq).le)
  have hs2 : ∑ p ∈ E.image pl, (1 - (hol N ω p).re) ≤ ∑ p ∈ plaqs N, (1 - (hol N ω p).re) :=
    sum_le_sum_of_subset_of_nonneg hsub (fun p _ _ => by
      have := abs_hol_re N ω p; linarith [(abs_le.mp this).2])
  have hs3 : ∑ p ∈ plaqs N, (1 - (hol N ω p).re) = (plaqs N).card - ∑ p ∈ plaqs N, (hol N ω p).re := by
    rw [sum_sub_distrib, sum_const, nsmul_eq_mul, mul_one]
  unfold action
  linarith

/-- **The uniform family of the mixed transport**: V(true) ≤ e^{β(#P − y N⁴)}. -/
theorem V4_true_le_mix (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y : ℝ) :
    V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) (fun _ _ _ _ => true) ≤
      Real.exp (β * ((plaqs N).card - y * N ^ 4)) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  unfold V4
  simp only [Hf, if_true]
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  set G : Cfg N → ℝ := fun ω => ∏ t0, ∏ t1, ∏ t2, ∏ t3, big N 0 1 y (Ψm N t0 t1 t2 t3 ω) with hG
  have hG0 : ∀ ω, 0 ≤ G ω := fun ω => prod_nonneg fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N 0 1 y _
  have hG1 : ∀ ω, G ω ≤ 1 := fun ω => prod_le_one (fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N 0 1 y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N 0 1 y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => big_nonneg N 0 1 y _) (fun _ _ =>
    prod_le_one (fun _ _ => big_nonneg N 0 1 y _) (fun _ _ => big_le_one N 0 1 y _))))
  have hpt : ∀ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ≤ Real.exp (β * ((plaqs N).card - y * N ^ 4)) := by
    intro ω
    have hw0 : 0 ≤ wilsonWeight N β ω := by unfold wilsonWeight; positivity
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal _ hw0]
    by_cases hz : G ω = 0
    · rw [hz, mul_zero]; exact (Real.exp_pos _).le
    · have hall : ∀ t0 t1 t2 t3, big N 0 1 y (Ψm N t0 t1 t2 t3 ω) ≠ 0 := by
        intro t0 t1 t2 t3
        have h1 := (prod_ne_zero_iff.mp hz) t0 (mem_univ _)
        have h2 := (prod_ne_zero_iff.mp h1) t1 (mem_univ _)
        have h3 := (prod_ne_zero_iff.mp h2) t2 (mem_univ _)
        exact (prod_ne_zero_iff.mp h3) t3 (mem_univ _)
      have ha := action_le_mix N y ω hall
      have hw : wilsonWeight N β ω ≤ Real.exp (β * ((plaqs N).card - y * N ^ 4)) := by
        unfold wilsonWeight; apply Real.exp_le_exp.mpr; exact mul_le_mul_of_nonneg_left ha hβ
      calc wilsonWeight N β ω * G ω ≤ wilsonWeight N β ω * 1 :=
            mul_le_mul_of_nonneg_left (hG1 ω) hw0
        _ ≤ _ := by rw [mul_one]; exact hw
  have hint : Integrable (fun _ : Cfg N => Real.exp (β * ((plaqs N).card - y * N ^ 4)))
      (Measure.pi fun _ : Lk N => haarBall) := integrable_const _
  have hnn : 0 ≤ᵐ[Measure.pi fun _ : Lk N => haarBall]
      (fun ω => Real.toNNReal (wilsonWeight N β ω) • G ω) :=
    Filter.Eventually.of_forall fun ω => by
      show (0 : ℝ) ≤ Real.toNNReal (wilsonWeight N β ω) • G ω
      rw [NNReal.smul_def, smul_eq_mul]; exact mul_nonneg (by positivity) (hG0 ω)
  calc ∫ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ∂(Measure.pi fun _ : Lk N => haarBall)
      ≤ ∫ _ω, Real.exp (β * ((plaqs N).card - y * N ^ 4)) ∂(Measure.pi fun _ : Lk N => haarBall) :=
        integral_mono_of_nonneg hnn hint (Filter.Eventually.of_forall hpt)
    _ = Real.exp (β * ((plaqs N).card - y * N ^ 4)) := by simp

/-- **The Peierls bound on (ℤ/2m)⁴ from the chessboard estimate (mixed, energy form, rate 1)**. -/
theorem peierls_mix (hM : 2 ≤ m) (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y : ℝ)
    (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    |V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) F| ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * ((plaqs N).card - y * N ^ 4) / (N ^ 4 : ℕ)) else Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ))) := by
  have hN4 : ((N ^ 4 : ℕ) : ℝ) ≠ 0 := by exact_mod_cast pow_ne_zero 4 (NeZero.ne N)
  set A : ℝ := Real.exp (β * ((plaqs N).card - y * N ^ 4) / (N ^ 4 : ℕ)) with hA
  set B : ℝ := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hc : ∀ b : Bool, 0 ≤ (if b then A else B) := by
    intro b; cases b
    · exact Real.rpow_nonneg (Zw_nonneg N β) _
    · exact (Real.exp_pos _).le
  have hconst : ∀ b : Bool, V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) (fun _ _ _ _ => b) ≤
      (if b then A else B) ^ (N ^ 4) := by
    intro b; cases b
    · rw [V4_false_mix]
      show Zw N β ≤ B ^ (N ^ 4)
      rw [hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β), one_div_mul_cancel hN4, Real.rpow_one]
    · show _ ≤ A ^ (N ^ 4)
      rw [hA, ← Real.exp_nat_mul, mul_div_cancel₀ _ hN4]
      exact V4_true_le_mix N m hN β hβ y
  exact chess_data_root m _ hN (Hf N 0 1 y) (Ψm N) (Rx N) (Gx N m) (dataMix N m hN hM β hβ y)
    (fun b => if b then A else B) hc hconst F

/-- **Volume-uniform rarity, mixed chessboard, rate 1.** -/
theorem rarity_mix (hM : 2 ≤ m) (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ)
    (hh : 0 < haarBall.real (ballQ r)) (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) F ≤
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 else 1) := by
  have hp := peierls_mix N m hM hN β hβ y F
  set h := haarBall.real (ballQ r) with hhdef
  set q := Real.exp (β * (48 * r ^ 2 - y)) / h ^ 4 with hq
  set A := Real.exp (β * ((plaqs N).card - y * N ^ 4) / (N ^ 4 : ℕ)) with hA
  set B := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hNpos : (0 : ℝ) < ((N ^ 4 : ℕ) : ℝ) := by exact_mod_cast pow_pos (Nat.pos_of_ne_zero (NeZero.ne N)) 4
  have hNr : (N : ℝ) = 2 * m := by exact_mod_cast hN
  have hm0 : (0 : ℝ) < m := by
    have : 0 < N := Nat.pos_of_ne_zero (NeZero.ne N)
    have : 0 < m := by omega
    exact_mod_cast this
  -- the lower bound for B
  have hZ := Zw_ge N β hβ r
  rw [card_plaqs, card_lk] at hZ
  have hlow : Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 ≤ B := by
    have e : (Real.exp (β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2))) * h ^ (4 * N ^ 4)) ^
        ((1 : ℝ) / (N ^ 4 : ℕ)) = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 := by
      rw [Real.mul_rpow (Real.exp_pos _).le (pow_nonneg hh.le _), ← Real.exp_mul,
        ← Real.rpow_natCast h (4 * N ^ 4), ← Real.rpow_mul hh.le]
      have e1 : β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2)) * (1 / ((N ^ 4 : ℕ) : ℝ)) =
          β * (6 - 48 * r ^ 2) := by
        field_simp; push_cast; ring
      have e2 : (((4 * N ^ 4 : ℕ) : ℝ)) * (1 / ((N ^ 4 : ℕ) : ℝ)) = ((4 : ℕ) : ℝ) := by
        field_simp; push_cast; ring
      rw [e1, e2, Real.rpow_natCast]
    rw [← e, hB]
    exact Real.rpow_le_rpow (by positivity) hZ (by positivity)
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg hh.le _)
  have hB0 : 0 ≤ B := Real.rpow_nonneg (Zw_nonneg N β) _
  have hAeq : A = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 * q := by
    rw [hA, hq, card_plaqs]
    rw [mul_div_assoc', mul_comm (Real.exp _) (h ^ 4), mul_assoc, ← Real.exp_add,
      mul_div_assoc, mul_div_cancel_left₀ _ (pow_ne_zero 4 hh.ne')]
    congr 1
    have hN4 : ((N ^ 4 : ℕ) : ℝ) = 16 * (m : ℝ) ^ 4 := by push_cast; rw [hNr]; ring
    rw [hN4]
    field_simp
    push_cast
    rw [hNr]
    ring
  have hAB : A ≤ B * q := by rw [hAeq]; exact mul_le_mul_of_nonneg_right hlow hq0
  have hstep : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then A else B) ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) := by
    apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t0 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t1 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t2 _; apply prod_le_prod (fun _ _ => by split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t3 _; split_ifs
    · exact hAB
    · rw [mul_one]
  have hsplit : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) =
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then q else 1) := by
    simp only [prod_mul_distrib, prod_const, card_univ, ZMod.card]
    congr 1
    rw [← pow_mul, ← pow_mul, ← pow_mul, hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β)]
    have : (1 : ℝ) / ((N ^ 4 : ℕ) : ℝ) * ((N * (N * (N * N)) : ℕ) : ℝ) = 1 := by
      field_simp; push_cast; ring
    rw [this, Real.rpow_one]
  calc V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) F ≤ |V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) F| :=
        le_abs_self _
    _ ≤ _ := hp
    _ ≤ _ := hstep
    _ = _ := hsplit


theorem rarity_plaq_mix (hM : 2 ≤ m) (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (X : Finset (Z4 N)) :
    ∫ ω, ∏ w ∈ X, (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, 0), 1)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
  set F : ZMod N → ZMod N → ZMod N → ZMod N → Bool := fun t0 t1 t2 t3 => decide ((t0, t1, t2, t3) ∈ X)
  have hr' := rarity_mix N m hM hN β hβ y r (ballQ_pos r hr) F
  have hterm : ∀ (ω : Cfg N) (q : Z4 N), Hf N 0 1 y (F q.1 q.2.1 q.2.2.1 q.2.2.2) (Ψm N q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      if q ∈ X then (if y < 1 - (hol N ω ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, 0), 1)).re then (1 : ℝ) else 0)
      else 1 := by
    intro ω q
    by_cases hq : q ∈ X
    · simp only [F, Prod.mk.eta, hq, decide_true, Hf, if_true, big, re_hol_Ψm N _ _ _ _ ω]
    · simp [F, hq, Hf]
  have eL : V4 (wilsonMeasure N β) (Hf N 0 1 y) (Ψm N) F = ∫ ω, ∏ w ∈ X,
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, 0), 1)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) := by
    unfold V4; congr 1; funext ω
    rw [prod4]
    simp only [hterm]
    rw [Finset.prod_ite_mem, univ_inter]
  have eR : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
      Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 else 1) =
      (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ X.card := by
    rw [prod4]
    simp only [F, Prod.mk.eta, decide_eq_true_eq]
    rw [Finset.prod_ite_mem, univ_inter, prod_const]
  rw [← eL, ← eR]
  exact hr'

/-- **Rarity for every finite set of plaquettes of the plane (0, 1)**, rate 1. -/
theorem rarity_sites_mix (hM : 2 ≤ m) (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (S : Finset (Site N)) :
    ∫ ω, ∏ x ∈ S, bigP N y ω ((x, 0), 1) ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  have hinj : Set.InjOn (toZ4 N) S := by
    intro x _ x' _ h
    rw [← vec_toZ4 N x, ← vec_toZ4 N x']
    simp only [toZ4, Prod.mk.injEq] at h
    rw [h.1, h.2.1, h.2.2.1, h.2.2.2]
  have h := rarity_plaq_mix N m hM hN β hβ y r hr (S.image (toZ4 N))
  rw [card_image_of_injOn hinj] at h
  have e : ∫ ω, ∏ w ∈ S.image (toZ4 N),
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, 0), 1)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, 0), 1) ∂(wilsonMeasure N β) := by
    congr 1; funext ω
    rw [prod_image hinj]
    apply prod_congr rfl; intro x _
    simp only [toZ4, vec_toZ4, bigP]
  rw [← e]; exact h


end FoldMix

#print axioms FoldMix.dataMix
#print axioms FoldMix.rarity_mix
#print axioms FoldMix.rarity_sites_mix
