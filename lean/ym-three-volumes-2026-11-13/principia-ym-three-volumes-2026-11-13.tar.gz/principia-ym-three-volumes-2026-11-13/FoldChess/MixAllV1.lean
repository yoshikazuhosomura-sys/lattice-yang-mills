import FoldChess.MixUniformV1
/-!
Rate 1 for every orientation and rate 1/6 for every finite set of plaquettes (mixed chessboard), m ≥ 2, β ≥ 0.
* `rarity_orient` : for an orientation (μ, ν), μ < ν, and every finite set S of sites,
  ∫ ∏_{x∈S} 1[(x; μν) large] dμ_W ≤ Z q₁^{|S|} (a relabelling of the directions moves (μ, ν) to (0, 1)).
* `rarity_all_mix` : for every finite set X of plaquettes, ≤ Z q₁^{⌊|X|/6⌋} when q₁ ≤ 1.
* `rarity_uniform_all_mix` : one statement with r = y/20 and an explicit β₀.

Paper correspondence: one-scale rarity (Proposition P), rate 1/6 per plaquette for an arbitrary set.
-/

namespace FoldMix

open MeasureTheory TorusRP LinkReflection PeierlsPerm FoldChess FoldWilson FoldPeierls FoldEntropy Finset

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the orientation (0, 1) moved by a relabelling τ with {τ 0, τ 1} = {μ, ν} -/
theorem rarity_orient_tau (hN : N = 2 * m) (hM : 2 ≤ m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (τ : Fin 4 → Fin 4) (hτ : ∀ j, τ (τ j) = j) (μ ν : Fin 4)
    (hτμν : plaqPerm N τ (((0 : Site N), 0), 1) = (((0 : Site N), μ), ν))
    (S : Finset (Site N)) :
    ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  have hinj : Set.InjOn (sitePerm N τ) S := by
    intro x _ x' _ h
    have := congrArg (sitePerm N τ) h
    rwa [sitePerm_invol N τ hτ, sitePerm_invol N τ hτ] at this
  have hpp : ∀ x : Site N, plaqPerm N τ ((sitePerm N τ x, 0), 1) = ((x, μ), ν) := by
    intro x
    have h0 := hτμν
    unfold plaqPerm at h0 ⊢
    split_ifs at h0 ⊢ with h1 h2
    · simp only [Prod.mk.injEq] at h0 ⊢
      exact ⟨⟨sitePerm_invol N τ hτ x, h0.1.2⟩, h0.2⟩
    · simp only [Prod.mk.injEq] at h0 ⊢
      exact ⟨⟨sitePerm_invol N τ hτ x, h0.1.2⟩, h0.2⟩
  have hmeas : Measurable (fun ω : Cfg N => ∏ x ∈ S.image (sitePerm N τ), bigP N y ω ((x, 0), 1)) :=
    Finset.measurable_prod _ (fun x _ => measurable_bigP N y _)
  have hinv := wilson_perm_invariant N τ hτ β _ hmeas
  have hS := rarity_sites_mix N m hM hN β hβ y r hr (S.image (sitePerm N τ))
  rw [card_image_of_injOn hinj] at hS
  rw [← hinv] at hS
  have e : ∀ ω, ∏ x ∈ S.image (sitePerm N τ), bigP N y (cfgPerm N τ ω) ((x, 0), 1) =
      ∏ x ∈ S, bigP N y ω ((x, μ), ν) := by
    intro ω
    rw [prod_image hinj]
    apply prod_congr rfl
    intro x _
    simp only [bigP, re_hol_cfgPerm N τ hτ, hpp]
  simp only [e] at hS
  exact hS

theorem exists_tau (μ ν : Fin 4) (h : μ < ν) :
    ∃ τ : Fin 4 → Fin 4, (∀ j, τ (τ j) = j) ∧ plaqPerm N τ (((0 : Site N), 0), 1) = (((0 : Site N), μ), ν) := by
  have hsite : ∀ τ : Fin 4 → Fin 4, sitePerm N τ (0 : Site N) = 0 := fun τ => rfl
  fin_cases μ <;> fin_cases ν <;> simp at h
  · exact ⟨id, fun _ => rfl, by simp [plaqPerm, hsite]⟩
  · exact ⟨![0, 2, 1, 3], by decide, by simp [plaqPerm, hsite]⟩
  · exact ⟨![0, 3, 2, 1], by decide, by simp [plaqPerm, hsite]⟩
  · exact ⟨![2, 1, 0, 3], by decide, by simp [plaqPerm, hsite]⟩
  · exact ⟨![3, 1, 2, 0], by decide, by simp [plaqPerm, hsite]⟩
  · exact ⟨![2, 3, 0, 1], by decide, by simp [plaqPerm, hsite]⟩

/-- **Rate 1 for every orientation.** -/
theorem rarity_orient (hN : N = 2 * m) (hM : 2 ≤ m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (μ ν : Fin 4) (hμν : μ < ν) (S : Finset (Site N)) :
    ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  obtain ⟨τ, hτ, h⟩ := exists_tau N μ ν hμν
  exact rarity_orient_tau N m hN hM β hβ y r hr τ hτ μ ν h S

/-- **Rate 1/6 for every finite set of plaquettes.** -/
theorem rarity_all_mix (hN : N = 2 * m) (hM : 2 ≤ m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (hq1 : Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 ≤ 1)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) :
    ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 6) := by
  set q := Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 with hqdef
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg (ballQ_pos r hr).le _)
  let T : Finset (Fin 4 × Fin 4) := univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2)
  have hT : T.card = 6 := by decide
  have hmaps : ∀ p ∈ X, (p.1.2, p.2) ∈ T := by
    intro p hp
    have := hX hp
    simp only [plaqs, mem_filter, mem_univ, true_and] at this
    simp only [T, mem_filter, mem_univ, true_and]; exact this
  have hTne : T.Nonempty := ⟨(0, 1), by simp [T]⟩
  obtain ⟨o, hoT, ho⟩ := Finset.exists_le_card_fiber_of_mul_le_card_of_maps_to hmaps hTne
    (by rw [hT]; exact Nat.mul_div_le X.card 6)
  set Xo := X.filter (fun p => (p.1.2, p.2) = o) with hXo
  obtain ⟨μ, ν⟩ := o
  have hμν : μ < ν := by simp only [T, mem_filter, mem_univ, true_and] at hoT; exact hoT
  have hbd : ∀ (s : Finset (Lk N × Fin 4)), Integrable (fun ω => ∏ p ∈ s, bigP N y ω p) (wilsonMeasure N β) := by
    intro s
    refine Integrable.of_bound (Finset.measurable_prod s (fun p _ => measurable_bigP N y p)).aestronglyMeasurable 1
      (Filter.Eventually.of_forall fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (prod_nonneg fun p _ => bigP_nonneg N y ω p)]
    exact prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
  have hmono : ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      ∫ ω, ∏ p ∈ Xo, bigP N y ω p ∂(wilsonMeasure N β) := by
    refine integral_mono (hbd X) (hbd Xo) (fun ω => ?_)
    show ∏ p ∈ X, bigP N y ω p ≤ ∏ p ∈ Xo, bigP N y ω p
    rw [← prod_filter_mul_prod_filter_not X (fun p => (p.1.2, p.2) = (μ, ν))]
    have h1 : ∏ p ∈ X.filter (fun p => ¬ (p.1.2, p.2) = (μ, ν)), bigP N y ω p ≤ 1 :=
      prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
    have h0 : 0 ≤ ∏ p ∈ Xo, bigP N y ω p := prod_nonneg fun p _ => bigP_nonneg N y ω p
    calc (∏ p ∈ Xo, bigP N y ω p) * ∏ p ∈ X.filter (fun p => ¬ (p.1.2, p.2) = (μ, ν)), bigP N y ω p
        ≤ (∏ p ∈ Xo, bigP N y ω p) * 1 := mul_le_mul_of_nonneg_left h1 h0
      _ = _ := mul_one _
  have hform : ∀ p ∈ Xo, p = ((p.1.1, μ), ν) := by
    intro p hp
    simp only [hXo, mem_filter, Prod.mk.injEq] at hp
    obtain ⟨_, h1, h2⟩ := hp
    rw [← h1, ← h2]
  have hinj : Set.InjOn (fun p : Lk N × Fin 4 => p.1.1) Xo := by
    intro p hp p' hp' h
    simp only at h
    rw [hform p hp, hform p' hp', h]
  set S := Xo.image (fun p : Lk N × Fin 4 => p.1.1) with hS
  have eS : ∫ ω, ∏ p ∈ Xo, bigP N y ω p ∂(wilsonMeasure N β) =
      ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := by
    congr 1; funext ω
    rw [hS, prod_image hinj]
    apply prod_congr rfl
    intro p hp
    rw [← hform p hp]
  have hcard : X.card / 6 ≤ S.card := by rw [hS, card_image_of_injOn hinj]; exact ho
  calc ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β)
      ≤ ∫ ω, ∏ p ∈ Xo, bigP N y ω p ∂(wilsonMeasure N β) := hmono
    _ = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := eS
    _ ≤ Zw N β * q ^ S.card := rarity_orient N m hN hM β hβ y r hr μ ν hμν S
    _ ≤ Zw N β * q ^ (X.card / 6) :=
        mul_le_mul_of_nonneg_left (pow_le_pow_of_le_one hq0 hq1 hcard) (Zw_nonneg N β)

end FoldMix

#print axioms FoldMix.rarity_orient
#print axioms FoldMix.rarity_all_mix
