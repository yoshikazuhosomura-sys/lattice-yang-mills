import Peierls.PermCSV1
/-!
Affine maps of one coordinate of the torus (ℤ/N)⁴ acting on the link variables of the concrete SU(2) Wilson
measure: in the direction d, x_d ↦ x_d + c (translation) or x_d ↦ c − x_d (reflection; the links in the direction d
are reversed, hence the variable is starred and the base point moves by −1).
* `affC_comp` : composition in one direction (the parameters compose as affine maps of ZMod N);
* `affC_comm` : maps in different directions commute;
* `affC_true_zero` : the reflection with c = 0 is the site reflection `reflPerm N (swap 0 d)`;
* `wilson_affC_false_invariant` : the Wilson measure is invariant under translations x ↦ x + c e_d.

Paper correspondence: one-scale rarity; the reflections through all lattice planes of all directions.
-/

namespace FoldAffine

open MeasureTheory TorusRP LinkReflection PeierlsPerm

variable (N : ℕ) [NeZero N]

/-- the new value of the d-th coordinate of the base point -/
def nv (d : Fin 4) (f : Bool) (c : ZMod N) (ℓ : Lk N) : ZMod N :=
  if f then (if ℓ.2 = d then c - ℓ.1 d - 1 else c - ℓ.1 d) else ℓ.1 d + c

/-- the link map -/
def affL (d : Fin 4) (f : Bool) (c : ZMod N) (ℓ : Lk N) : Lk N :=
  (Function.update ℓ.1 d (nv N d f c ℓ), ℓ.2)

/-- the map of the configurations -/
noncomputable def affC (d : Fin 4) (f : Bool) (c : ZMod N) (ω : Lk N → QBall) : Lk N → QBall :=
  fun ℓ => if f = true ∧ ℓ.2 = d then starB (ω (affL N d f c ℓ)) else ω (affL N d f c ℓ)

theorem starB_starB (q : QBall) : starB (starB q) = q := by
  apply Subtype.ext; exact star_star _

@[simp] theorem affL_snd (d : Fin 4) (f : Bool) (c : ZMod N) (ℓ : Lk N) : (affL N d f c ℓ).2 = ℓ.2 := rfl

theorem affL_comp (d : Fin 4) (f1 f2 : Bool) (c1 c2 : ZMod N) (ℓ : Lk N) :
    affL N d f2 c2 (affL N d f1 c1 ℓ) = affL N d (Bool.xor f1 f2) (if f2 then c2 - c1 else c1 + c2) ℓ := by
  obtain ⟨x, μ⟩ := ℓ
  refine Prod.ext ?_ rfl
  funext j
  by_cases hj : j = d
  · subst hj
    cases f1 <;> cases f2 <;> by_cases h : μ = j <;> simp [affL, nv, h] <;> ring
  · simp [affL, hj]

theorem affC_comp (d : Fin 4) (f1 f2 : Bool) (c1 c2 : ZMod N) (ω : Lk N → QBall) :
    affC N d f1 c1 (affC N d f2 c2 ω) = affC N d (Bool.xor f1 f2) (if f2 then c2 - c1 else c1 + c2) ω := by
  funext ℓ
  obtain ⟨x, μ⟩ := ℓ
  simp only [affC, affL_snd]
  rw [affL_comp]
  cases f1 <;> cases f2 <;> by_cases h : μ = d <;> simp [h, starB_starB]

theorem affL_comm (d e : Fin 4) (hde : d ≠ e) (f g : Bool) (c c' : ZMod N) (ℓ : Lk N) :
    affL N d f c (affL N e g c' ℓ) = affL N e g c' (affL N d f c ℓ) := by
  obtain ⟨x, μ⟩ := ℓ
  refine Prod.ext ?_ rfl
  funext j
  simp only [affL, nv, Function.update_apply, if_neg hde, if_neg (Ne.symm hde)]
  by_cases hjd : j = d <;> by_cases hje : j = e
  · exact absurd (hjd.symm.trans hje) hde
  · simp [hjd, hje, hde, Ne.symm hde]
  · simp [hjd, hje, hde, Ne.symm hde]
  · simp [hjd, hje, hde, Ne.symm hde]

theorem affC_comm (d e : Fin 4) (hde : d ≠ e) (f g : Bool) (c c' : ZMod N) (ω : Lk N → QBall) :
    affC N d f c (affC N e g c' ω) = affC N e g c' (affC N d f c ω) := by
  funext ℓ
  obtain ⟨x, μ⟩ := ℓ
  simp only [affC, affL_snd]
  rw [affL_comm N d e hde]
  by_cases hd : μ = d
  · have he : μ ≠ e := fun h => hde (hd.symm.trans h)
    simp [hd, he, hde, Ne.symm hde]
  · by_cases he : μ = e
    · simp [hd, he, hde, Ne.symm hde]
    · simp [hd, he]

theorem measurable_affC (d : Fin 4) (f : Bool) (c : ZMod N) : Measurable (affC N d f c) := by
  refine measurable_pi_lambda _ (fun ℓ => ?_)
  by_cases hc : f = true ∧ ℓ.2 = d
  · simp only [affC, hc, and_self, if_true]
    exact continuous_starB.measurable.comp (measurable_pi_apply _)
  · simp only [affC, hc, if_false]
    exact measurable_pi_apply _

theorem swap_eq_zero (d j : Fin 4) : (Equiv.swap 0 d) j = 0 ↔ j = d := by
  constructor
  · intro h
    have := congrArg (Equiv.swap 0 d) h
    rwa [Equiv.swap_apply_self, Equiv.swap_apply_left] at this
  · rintro rfl; exact Equiv.swap_apply_right 0 j

theorem link_eq (d : Fin 4) (x : Site N) (μ : Fin 4) :
    linkPerm N (Equiv.swap 0 d) (thL N (linkPerm N (Equiv.swap 0 d) (x, μ))) = affL N d true 0 (x, μ) := by
  by_cases h : μ = d
  · subst h
    have h0 : (Equiv.swap 0 μ) μ = 0 := Equiv.swap_apply_right 0 μ
    simp only [linkPerm, thL, h0, if_true, affL, nv]
    refine Prod.ext ?_ (Equiv.swap_apply_left 0 μ)
    funext j
    simp only [sitePerm, thS, Pi.sub_apply, ev, Pi.single_apply, Function.update_apply, Equiv.swap_apply_self]
    by_cases hj : j = μ
    · subst hj; simp [h0]
    · have hj' : ¬ (Equiv.swap 0 μ) j = 0 := fun h' => hj ((swap_eq_zero μ j).1 h')
      simp [hj, hj']
  · have h0 : ¬ (Equiv.swap 0 d) μ = 0 := fun h' => h ((swap_eq_zero d μ).1 h')
    simp only [linkPerm, thL, h0, if_false, affL, nv, h]
    refine Prod.ext ?_ (Equiv.swap_apply_self 0 d μ)
    funext j
    simp only [sitePerm, thS, Function.update_apply, Equiv.swap_apply_self]
    by_cases hj : j = d
    · subst hj; simp [Equiv.swap_apply_right]
    · have hj' : ¬ (Equiv.swap 0 d) j = 0 := fun h' => hj ((swap_eq_zero d j).1 h')
      simp [hj, hj']

theorem flag_eq (d : Fin 4) (x : Site N) (μ : Fin 4) :
    sig N (linkPerm N (Equiv.swap 0 d) (x, μ)) = if μ = d then starB else id := by
  simp only [sig, linkPerm, swap_eq_zero]

/-- the reflection with `c = 0` is the site reflection of `PeierlsPerm` -/
theorem affC_true_zero (d : Fin 4) : affC N d true 0 = reflPerm N (Equiv.swap 0 d) := by
  funext ω ℓ
  obtain ⟨x, μ⟩ := ℓ
  simp only [reflPerm, cfgPerm, linkRefl]
  rw [flag_eq, link_eq]
  by_cases h : μ = d
  · simp [affC, h]
  · simp [affC, h]

/-- translation by a vector -/
def shV (v : Site N) (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (ℓ.1 + v, ℓ.2)

def shVEquiv (v : Site N) : Lk N ≃ Lk N where
  toFun ℓ := (ℓ.1 - v, ℓ.2)
  invFun ℓ := (ℓ.1 + v, ℓ.2)
  left_inv ℓ := by simp
  right_inv ℓ := by simp

theorem shV_preserving (v : Site N) :
    MeasurePreserving (shV N v) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) (shVEquiv N v)
  convert hre using 1
  funext ω
  funext ℓ
  rw [LinkReflection.piCongrLeft_const]
  rfl

theorem hol_shV (v : Site N) (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (shV N v ω) p = hol N ω ((p.1.1 + v, p.1.2), p.2) := by
  simp only [hol, holQ, Uq, shV]
  rw [add_right_comm p.1.1 (ev N p.1.2) v, add_right_comm p.1.1 (ev N p.2) v]

theorem action_shV (v : Site N) (ω : Lk N → QBall) : action N (shV N v ω) = action N ω := by
  unfold action
  simp_rw [hol_shV]
  apply Finset.sum_nbij' (fun p => ((p.1.1 + v, p.1.2), p.2)) (fun p => ((p.1.1 - v, p.1.2), p.2))
  · intro p hp; simpa [plaqs] using hp
  · intro p hp; simpa [plaqs] using hp
  · intro p _; simp
  · intro p _; simp
  · intro p _; rfl

/-- **Translation invariance of the Wilson measure by any vector.** -/
theorem wilson_shV_invariant (v : Site N) (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    ∫ ω, f (shV N v ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := shV_preserving N v
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) • f ω) := hWm.smul hf
  conv_rhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  unfold wilsonWeight
  rw [action_shV]

theorem affC_false_eq (d : Fin 4) (c : ZMod N) : affC N d false c = shV N (Pi.single d c) := by
  funext ω ℓ
  obtain ⟨x, μ⟩ := ℓ
  simp only [affC, shV, affL, nv, Bool.false_eq_true, false_and, if_false]
  congr 2
  funext j
  simp only [Function.update_apply, Pi.add_apply, Pi.single_apply]
  by_cases hj : j = d
  · subst hj; simp
  · simp [hj]

/-- **Translation invariance in the direction d.** -/
theorem wilson_affC_false_invariant (d : Fin 4) (c : ZMod N) (β : ℝ) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) :
    ∫ ω, f (affC N d false c ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  rw [affC_false_eq]; exact wilson_shV_invariant N _ β f hf

end FoldAffine

#print axioms FoldAffine.affC_comp
#print axioms FoldAffine.affC_comm
#print axioms FoldAffine.affC_true_zero
#print axioms FoldAffine.wilson_affC_false_invariant
