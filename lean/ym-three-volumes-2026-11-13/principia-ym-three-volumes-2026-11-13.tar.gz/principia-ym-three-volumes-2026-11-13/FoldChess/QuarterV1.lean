import FoldChess.RarityAllV1
/-!
Rate 1/4: the images of the plaquette (0; μν) under all the transports.

`re_hol_affC`: for a plaquette (x; μν) (μ < ν), Re U_{(x;μν)}(affC d f c ω) = Re U_{(x';μν)}(ω), where x' changes only
the d-th coordinate: x_d ↦ x_d + c (translation), c − x_d (reflection, d ∉ {μ, ν}) or c − x_d − 1 (reflection,
d ∈ {μ, ν}; the plaquette is reversed and Re is unchanged).  Hence Ψ_w moves (0; μν) to (b_w; μν) with
b_w,d = t_d (d ∈ {μ, ν}) and t_d + [t_d odd] (d ∉ {μ, ν}); on the N²m² blocks with even coordinates off the plane,
b_w = w.  The uniform family then forces N⁴/4 distinct large plaquettes:
  V(true) ≤ e^{β(#P − y N⁴/4)},   q₄ := e^{β(48 r² − y/4)} / h(r)⁴,   ∫ ∏_{x∈S} 1[(x;μν) large] ≤ Z q₄^{|S|}
for S in the sublattice with even coordinates off the plane (μ, ν).

Paper correspondence: Proposition P with the rate 1/4 (threshold β > 229 at y = 1 for the optimal r).
-/

namespace FoldQuarter

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy Finset

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the new base coordinate -/
def nb (d : Fin 4) (f : Bool) (c : ZMod N) (μ ν : Fin 4) (x : Site N) : ZMod N :=
  if f then (if d = μ ∨ d = ν then c - x d - 1 else c - x d) else x d + c

theorem ev_ne (μ d : Fin 4) (h : d ≠ μ) : ev N μ d = 0 := by simp [ev, Pi.single_apply, h]

theorem ev_self (d : Fin 4) : ev N d d = 1 := by simp [ev]

theorem re_hol_affC (d : Fin 4) (f : Bool) (c : ZMod N) (ω : Cfg N) (x : Site N) (μ ν : Fin 4) (hμν : μ < ν) :
    (hol N (affC N d f c ω) ((x, μ), ν)).re =
      (hol N ω ((Function.update x d (nb N d f c μ ν x), μ), ν)).re := by
  have hμν' : μ ≠ ν := ne_of_lt hμν
  cases f
  · -- translation
    rw [affC_false_eq, hol_shV]
    have e : x + Pi.single d c = Function.update x d (nb N d false c μ ν x) := by
      funext j
      by_cases hj : j = d
      · subst hj; simp [nb, Pi.single_apply]
      · simp [nb, hj, Pi.single_apply, Ne.symm hj]
    dsimp only
    rw [e]
  · by_cases hd : d = μ ∨ d = ν
    · rcases hd with hd | hd
      · -- d = μ
        subst hd
        have hνd : ν ≠ d := Ne.symm hμν'
        have l1 : affL N d true c (x, d) = (Function.update x d (c - x d - 1), d) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv]
          · simp [affL, hj]
        have l2 : affL N d true c (x + ev N d, ν) = (Function.update x d (c - x d - 1), ν) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, hνd, ev_self]; ring
          · simp [affL, hj, ev_ne N d j hj]
        have l3 : affL N d true c (x + ev N ν, d) = (Function.update x d (c - x d - 1) + ev N ν, d) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, ev_ne N ν j (Ne.symm hνd)]
          · simp [affL, hj]
        have l4 : affL N d true c (x, ν) = (Function.update x d (c - x d - 1) + ev N d, ν) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, hνd, ev_self]
          · simp [affL, hj, ev_ne N d j hj]
        have u1 : ((affC N d true c ω (x, d) : QBall) : ℍr) =
            star ((ω (Function.update x d (c - x d - 1), d) : QBall) : ℍr) := by
          rw [show affC N d true c ω (x, d) = starB (ω (Function.update x d (c - x d - 1), d)) by
            simp [affC, l1]]
          rfl
        have u2 : affC N d true c ω (x + ev N d, ν) = ω (Function.update x d (c - x d - 1), ν) := by
          simp [affC, l2, hνd]
        have u3 : ((affC N d true c ω (x + ev N ν, d) : QBall) : ℍr) =
            star ((ω (Function.update x d (c - x d - 1) + ev N ν, d) : QBall) : ℍr) := by
          rw [show affC N d true c ω (x + ev N ν, d) = starB (ω (Function.update x d (c - x d - 1) + ev N ν, d)) by
            simp [affC, l3]]
          rfl
        have u4 : affC N d true c ω (x, ν) = ω (Function.update x d (c - x d - 1) + ev N d, ν) := by
          simp [affC, l4, hνd]
        have hn : nb N d true c d ν x = c - x d - 1 := by simp [nb]
        rw [hn]
        simp only [hol, holQ, Uq]
        rw [u1, u2, u3, u4, quat4]
      · -- d = ν
        subst hd
        have hμd : μ ≠ d := hμν'
        have l1 : affL N d true c (x, μ) = (Function.update x d (c - x d - 1) + ev N d, μ) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, hμd, ev_self]
          · simp [affL, hj, ev_ne N d j hj]
        have l2 : affL N d true c (x + ev N μ, d) = (Function.update x d (c - x d - 1) + ev N μ, d) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, ev_ne N μ j (Ne.symm hμd)]
          · simp [affL, hj]
        have l3 : affL N d true c (x + ev N d, μ) = (Function.update x d (c - x d - 1), μ) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv, hμd, ev_self]; ring
          · simp [affL, hj, ev_ne N d j hj]
        have l4 : affL N d true c (x, d) = (Function.update x d (c - x d - 1), d) := by
          refine Prod.ext ?_ rfl; funext j
          by_cases hj : j = d
          · subst hj; simp [affL, nv]
          · simp [affL, hj]
        have u1 : affC N d true c ω (x, μ) = ω (Function.update x d (c - x d - 1) + ev N d, μ) := by
          simp [affC, l1, hμd]
        have u2 : ((affC N d true c ω (x + ev N μ, d) : QBall) : ℍr) =
            star ((ω (Function.update x d (c - x d - 1) + ev N μ, d) : QBall) : ℍr) := by
          rw [show affC N d true c ω (x + ev N μ, d) = starB (ω (Function.update x d (c - x d - 1) + ev N μ, d)) by
            simp [affC, l2]]
          rfl
        have u3 : affC N d true c ω (x + ev N d, μ) = ω (Function.update x d (c - x d - 1), μ) := by
          simp [affC, l3, hμd]
        have u4 : ((affC N d true c ω (x, d) : QBall) : ℍr) =
            star ((ω (Function.update x d (c - x d - 1), d) : QBall) : ℍr) := by
          rw [show affC N d true c ω (x, d) = starB (ω (Function.update x d (c - x d - 1), d)) by
            simp [affC, l4]]
          rfl
        have hn : nb N d true c μ d x = c - x d - 1 := by simp [nb]
        rw [hn]
        simp only [hol, holQ, Uq]
        rw [u1, u2, u3, u4, star_star]
        set A : ℍr := ((ω (Function.update x d (c - x d - 1) + ev N d, μ) : QBall) : ℍr)
        set B : ℍr := ((ω (Function.update x d (c - x d - 1) + ev N μ, d) : QBall) : ℍr)
        set C : ℍr := ((ω (Function.update x d (c - x d - 1), μ) : QBall) : ℍr)
        set D : ℍr := ((ω (Function.update x d (c - x d - 1), d) : QBall) : ℍr)
        have h1 : (A * star B * star C * D).re = (D * (A * star B * star C)).re := re_cyc _ _
        have h2 : D * (A * star B * star C) = D * A * star B * star C := by simp only [mul_assoc]
        calc (A * star B * star C * D).re = (D * A * star B * star C).re := by rw [h1, h2]
          _ = (star (D * A * star B * star C)).re := (Quaternion.re_star _).symm
          _ = (C * B * star A * star D).re := by simp only [star_mul, star_star, mul_assoc]
    · -- d off the plane
      push Not at hd
      obtain ⟨hdμ, hdν⟩ := hd
      have l1 : affL N d true c (x, μ) = (Function.update x d (c - x d), μ) := by
        refine Prod.ext ?_ rfl; funext j
        by_cases hj : j = d
        · subst hj; simp [affL, nv, Ne.symm hdμ]
        · simp [affL, hj]
      have l2 : affL N d true c (x + ev N μ, ν) = (Function.update x d (c - x d) + ev N μ, ν) := by
        refine Prod.ext ?_ rfl; funext j
        by_cases hj : j = d
        · subst hj; simp [affL, nv, Ne.symm hdν, ev_ne N μ j hdμ]
        · simp [affL, hj]
      have l3 : affL N d true c (x + ev N ν, μ) = (Function.update x d (c - x d) + ev N ν, μ) := by
        refine Prod.ext ?_ rfl; funext j
        by_cases hj : j = d
        · subst hj; simp [affL, nv, Ne.symm hdμ, ev_ne N ν j hdν]
        · simp [affL, hj]
      have l4 : affL N d true c (x, ν) = (Function.update x d (c - x d), ν) := by
        refine Prod.ext ?_ rfl; funext j
        by_cases hj : j = d
        · subst hj; simp [affL, nv, Ne.symm hdν]
        · simp [affL, hj]
      have u1 : affC N d true c ω (x, μ) = ω (Function.update x d (c - x d), μ) := by
        simp [affC, l1, Ne.symm hdμ]
      have u2 : affC N d true c ω (x + ev N μ, ν) = ω (Function.update x d (c - x d) + ev N μ, ν) := by
        simp [affC, l2, Ne.symm hdν]
      have u3 : affC N d true c ω (x + ev N ν, μ) = ω (Function.update x d (c - x d) + ev N ν, μ) := by
        simp [affC, l3, Ne.symm hdμ]
      have u4 : affC N d true c ω (x, ν) = ω (Function.update x d (c - x d), ν) := by
        simp [affC, l4, Ne.symm hdν]
      have hn : nb N d true c μ ν x = c - x d := by simp [nb, hdμ, hdν]
      rw [hn]
      simp only [hol, holQ, Uq]
      rw [u1, u2, u3, u4]

end FoldQuarter

#print axioms FoldQuarter.re_hol_affC
