import FoldChess.MidV1
/-!
Link mid-plane reflections in every direction and at every position, for the mixed chessboard.
* `cs_of_rp` (abstract): reflection positivity on a class closed under f + t g, with a symmetric pairing,
  gives the Cauchy–Schwarz inequality of the reflected pairing.
* `cfgPerm_affC` : relabelling the directions moves an affine map of the direction 0 to the direction τ 0.
* the class `MidGood k a` (bounded measurable gauge invariant functions of the closed plus side of the link
  mid-plane between x_k = a − 1 and x_k = a, read through the shift and the relabelling), and for the reflection
  R = (x_k ↦ 2a − 1 − x_k): `rp_mid` (positivity, β ≥ 0, N = 2M, M ≥ 2) and `cs_mid` (Cauchy–Schwarz).

Paper correspondence: one-scale rarity, the mixed chessboard (link mid-planes in the directions off the plane).
-/

namespace FoldMid

open MeasureTheory TorusRP LinkReflection PeierlsPerm FoldAffine MidRP TorusGauge GaugeFix

theorem cs_of_rp {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) (R : Ω → Ω) (C : (Ω → ℝ) → Prop)
    (hadd : ∀ f g (t : ℝ), C f → C g → C (fun ω => f ω + t * g ω))
    (hrp : ∀ f, C f → 0 ≤ ∫ ω, f (R ω) * f ω ∂μ)
    (hsym : ∀ f g, C f → C g → ∫ ω, f (R ω) * g ω ∂μ = ∫ ω, g (R ω) * f ω ∂μ)
    (hint : ∀ f g, C f → C g → Integrable (fun ω => f (R ω) * g ω) μ)
    (f g : Ω → ℝ) (hf : C f) (hg : C g) :
    (∫ ω, f (R ω) * g ω ∂μ) ^ 2 ≤ (∫ ω, f (R ω) * f ω ∂μ) * (∫ ω, g (R ω) * g ω ∂μ) := by
  set a := ∫ ω, f (R ω) * f ω ∂μ
  set b := ∫ ω, f (R ω) * g ω ∂μ
  set c := ∫ ω, g (R ω) * g ω ∂μ
  have hb' : ∫ ω, g (R ω) * f ω ∂μ = b := (hsym f g hf hg).symm
  have hQ : ∀ t : ℝ, 0 ≤ c * (t * t) + (2 * b) * t + a := by
    intro t
    have hpos := hrp _ (hadd f g t hf hg)
    have hexp : ∀ ω, (f (R ω) + t * g (R ω)) * (f ω + t * g ω) =
        f (R ω) * f ω + t * (f (R ω) * g ω) + t * (g (R ω) * f ω) + (t * t) * (g (R ω) * g ω) := by
      intro ω; ring
    simp_rw [hexp] at hpos
    have i1 : Integrable (fun ω => f (R ω) * f ω + t * (f (R ω) * g ω)) μ :=
      (hint f f hf hf).add ((hint f g hf hg).const_mul t)
    have i2 : Integrable (fun ω => f (R ω) * f ω + t * (f (R ω) * g ω) + t * (g (R ω) * f ω)) μ :=
      i1.add ((hint g f hg hf).const_mul t)
    have s3 := integral_add i2 ((hint g g hg hg).const_mul (t * t))
    have s2 := integral_add i1 ((hint g f hg hf).const_mul t)
    have s1 := integral_add (hint f f hf hf) ((hint f g hf hg).const_mul t)
    rw [s3, s2, s1, integral_const_mul, integral_const_mul, integral_const_mul, hb'] at hpos
    nlinarith [hpos]
  have hd := discrim_le_zero hQ
  unfold discrim at hd
  nlinarith [hd]

variable (N : ℕ) [NeZero N]

theorem cfgPerm_affC (k : Fin 4) (f : Bool) (c : ZMod N) (ω : Lk N → QBall) :
    cfgPerm N (Equiv.swap 0 k) (affC N 0 f c (cfgPerm N (Equiv.swap 0 k) ω)) = affC N k f c ω := by
  funext ℓ
  obtain ⟨x, μ⟩ := ℓ
  have hsw : ∀ j, (Equiv.swap 0 k) ((Equiv.swap 0 k) j) = j := fun j => Equiv.swap_apply_self 0 k j
  have hlink : linkPerm N (Equiv.swap 0 k) (affL N 0 f c (linkPerm N (Equiv.swap 0 k) (x, μ))) =
      affL N k f c (x, μ) := by
    refine Prod.ext ?_ ?_
    · funext j
      simp only [linkPerm, sitePerm, affL, nv, Function.update_apply]
      by_cases hj : j = k
      · subst hj
        have h0 : (Equiv.swap 0 j) j = 0 := Equiv.swap_apply_right 0 j
        simp only [h0, if_true, swap_eq_zero]
        rw [Equiv.swap_apply_left]
      · have hj' : ¬ (Equiv.swap 0 k) j = 0 := fun h => hj ((swap_eq_zero k j).1 h)
        simp only [hj', hj, if_false]
        rw [hsw]
    · simp only [linkPerm, affL]; exact hsw μ
  simp only [cfgPerm, affC]
  rw [hlink]
  have hflag : (linkPerm N (Equiv.swap 0 k) (x, μ)).2 = 0 ↔ μ = k := swap_eq_zero k μ
  simp only [linkPerm] at hflag
  by_cases hμ : μ = k
  · subst hμ; simp [linkPerm, Equiv.swap_apply_right]
  · have : ¬ (Equiv.swap 0 k) μ = 0 := fun h => hμ (hflag.1 h)
    simp [linkPerm, this, hμ]

/-- the shift bringing the mid-plane between a − 1 and a to the mid-plane between 0 and 1 -/
noncomputable def Sm (k : Fin 4) (a : ZMod N) : (Lk N → QBall) → (Lk N → QBall) := affC N k false (1 - a)

/-- the reflection through the mid-plane between x_k = a − 1 and x_k = a -/
noncomputable def Rm (k : Fin 4) (a : ZMod N) : (Lk N → QBall) → (Lk N → QBall) := affC N k true (a + a - 1)

/-- read a function through the shift and the relabelling -/
noncomputable def readM (k : Fin 4) (a : ZMod N) (f : (Lk N → QBall) → ℝ) : (Lk N → QBall) → ℝ :=
  fun ω => f (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω))

/-- the closed plus side of the mid-plane (gauge invariant) -/
def MidGood (M : ℕ) (k : Fin 4) (a : ZMod N) (f : (Lk N → QBall) → ℝ) : Prop :=
  Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
    (∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → readM N k a f ω = readM N k a f ω') ∧
    (∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : Quaternion ℝ)‖ = 1) → ∀ ω,
      readM N k a f (act (src N) (tgt N) g ω) = readM N k a f ω)

theorem Rm_Sm (k : Fin 4) (a : ZMod N) (ω : Lk N → QBall) :
    Rm N k a (Sm N k a ω) = Sm N k a (affC N k true 1 ω) := by
  unfold Rm Sm
  rw [affC_comp, affC_comp]
  simp only [Bool.true_xor, Bool.false_xor, Bool.not_false, if_true, if_false, Bool.false_eq_true]
  congr 1; ring

theorem measurable_cfgPerm (k : Fin 4) : Measurable (cfgPerm N (Equiv.swap 0 k)) :=
  (cfgPerm_preserving N _ (fun j => Equiv.swap_apply_self 0 k j)).measurable

/-- the reflected pairing read through the shift and the relabelling -/
theorem pair_read (M : ℕ) (hN : N = 2 * M) (k : Fin 4) (a : ZMod N) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (Rm N k a ω) * g ω ∂(wilsonMeasure N β) =
      ∫ ω, readM N k a f (affC N 0 true 1 ω) * readM N k a g ω ∂(wilsonMeasure N β) := by
  have hτ : ∀ j, (Equiv.swap 0 k) ((Equiv.swap 0 k) j) = j := fun j => Equiv.swap_apply_self 0 k j
  have hR : Measurable (Rm N k a) := measurable_affC N k true _
  have hS : Measurable (Sm N k a) := measurable_affC N k false _
  have h1 := wilson_affC_invariant N M hN k false (1 - a) β (fun ω => f (Rm N k a ω) * g ω) ((hf.comp hR).mul hg)
  rw [← h1]
  have h2 := wilson_perm_invariant N _ hτ β
    (fun ω => f (Rm N k a (affC N k false (1 - a) ω)) * g (affC N k false (1 - a) ω))
    ((hf.comp (hR.comp hS)).mul (hg.comp hS))
  rw [← h2]
  congr 1; funext ω
  have e2 : affC N k true 1 (cfgPerm N (Equiv.swap 0 k) ω) = cfgPerm N (Equiv.swap 0 k) (affC N 0 true 1 ω) := by
    have := cfgPerm_affC N k true 1 (cfgPerm N (Equiv.swap 0 k) ω)
    rw [cfgPerm_invol N _ hτ] at this
    exact this.symm
  have e : Rm N k a (affC N k false (1 - a) (cfgPerm N (Equiv.swap 0 k) ω)) =
      Sm N k a (cfgPerm N (Equiv.swap 0 k) (affC N 0 true 1 ω)) := by
    show Rm N k a (Sm N k a (cfgPerm N (Equiv.swap 0 k) ω)) = _
    rw [Rm_Sm, e2]
  simp only [readM]
  rw [e]
  rfl

theorem readM_measurable (k : Fin 4) (a : ZMod N) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    Measurable (readM N k a f) :=
  hf.comp ((measurable_affC N k false _).comp (measurable_cfgPerm N k))

theorem midGood_add (M : ℕ) (k : Fin 4) (a : ZMod N) (f g : (Lk N → QBall) → ℝ) (t : ℝ)
    (hf : MidGood N M k a f) (hg : MidGood N M k a g) : MidGood N M k a (fun ω => f ω + t * g ω) := by
  obtain ⟨hfm, ⟨Cf, hCf⟩, hfd, hfi⟩ := hf
  obtain ⟨hgm, ⟨Cg, hCg⟩, hgd, hgi⟩ := hg
  refine ⟨hfm.add (measurable_const.mul hgm), ⟨Cf + |t| * Cg, fun ω => ?_⟩, fun ω ω' h => ?_, fun g' hg' ω => ?_⟩
  · calc |f ω + t * g ω| ≤ |f ω| + |t * g ω| := abs_add_le _ _
      _ ≤ Cf + |t| * Cg := by rw [abs_mul]; gcongr; exact hCf ω; exact hCg ω
  · have e1 := hfd ω ω' h; have e2 := hgd ω ω' h
    simp only [readM] at e1 e2 ⊢; rw [e1, e2]
  · have e1 := hfi g' hg' ω; have e2 := hgi g' hg' ω
    simp only [readM] at e1 e2 ⊢; rw [e1, e2]

theorem midGood_mul (M : ℕ) (k : Fin 4) (a : ZMod N) (f g : (Lk N → QBall) → ℝ)
    (hf : MidGood N M k a f) (hg : MidGood N M k a g) : MidGood N M k a (fun ω => f ω * g ω) := by
  obtain ⟨hfm, ⟨Cf, hCf⟩, hfd, hfi⟩ := hf
  obtain ⟨hgm, ⟨Cg, hCg⟩, hgd, hgi⟩ := hg
  refine ⟨hfm.mul hgm, ⟨Cf * Cg, fun ω => ?_⟩, fun ω ω' h => ?_, fun g' hg' ω => ?_⟩
  · rw [abs_mul]; exact mul_le_mul (hCf ω) (hCg ω) (abs_nonneg _) (le_trans (abs_nonneg _) (hCf ω))
  · have e1 := hfd ω ω' h; have e2 := hgd ω ω' h
    simp only [readM] at e1 e2 ⊢; rw [e1, e2]
  · have e1 := hfi g' hg' ω; have e2 := hgi g' hg' ω
    simp only [readM] at e1 e2 ⊢; rw [e1, e2]

theorem midGood_one (M : ℕ) (k : Fin 4) (a : ZMod N) : MidGood N M k a (fun _ => 1) :=
  ⟨measurable_const, ⟨1, fun _ => by simp⟩, fun _ _ _ => rfl, fun _ _ _ => rfl⟩

/-- **Mid-plane reflection positivity, every direction and position** (β ≥ 0, N = 2M, M ≥ 2). -/
theorem rp_mid (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (k : Fin 4) (a : ZMod N) (β : ℝ) (hβ : 0 ≤ β)
    (f : (Lk N → QBall) → ℝ) (hf : MidGood N M k a f) :
    0 ≤ ∫ ω, f (Rm N k a ω) * f ω ∂(wilsonMeasure N β) := by
  rw [pair_read N M hN k a β f f hf.1 hf.1]
  obtain ⟨hm, ⟨C, hC⟩, hd, hi⟩ := hf
  exact wilson_rp_mid_affC N M hN hM β hβ (readM N k a f) (readM_measurable N k a f hm) C (fun ω => hC _) hd hi

theorem integrable_pairM (β : ℝ) (k : Fin 4) (a : ZMod N) (M : ℕ) (f g : (Lk N → QBall) → ℝ)
    (hf : MidGood N M k a f) (hg : MidGood N M k a g) :
    Integrable (fun ω => f (Rm N k a ω) * g ω) (wilsonMeasure N β) := by
  obtain ⟨hfm, ⟨Cf, hCf⟩, _, _⟩ := hf
  obtain ⟨hgm, ⟨Cg, hCg⟩, _, _⟩ := hg
  refine Integrable.of_bound ((hfm.comp (measurable_affC N k true _)).mul hgm).aestronglyMeasurable (Cf * Cg)
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_mul]
  exact mul_le_mul (hCf _) (hCg ω) (abs_nonneg _) (le_trans (abs_nonneg _) (hCf (Rm N k a ω)))

/-- **Mid-plane Cauchy–Schwarz, every direction and position.** -/
theorem cs_mid (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (k : Fin 4) (a : ZMod N) (β : ℝ) (hβ : 0 ≤ β)
    (f g : (Lk N → QBall) → ℝ) (hf : MidGood N M k a f) (hg : MidGood N M k a g) :
    (∫ ω, f (Rm N k a ω) * g ω ∂(wilsonMeasure N β)) ^ 2 ≤
      (∫ ω, f (Rm N k a ω) * f ω ∂(wilsonMeasure N β)) * (∫ ω, g (Rm N k a ω) * g ω ∂(wilsonMeasure N β)) :=
  cs_of_rp (wilsonMeasure N β) (Rm N k a) (MidGood N M k a)
    (fun f g t hf hg => midGood_add N M k a f g t hf hg)
    (fun f hf => rp_mid N M hN hM k a β hβ f hf)
    (fun f g hf hg => pair_symm N M hN k (a + a - 1) β f g hf.1 hg.1)
    (fun f g hf hg => integrable_pairM N β k a M f g hf hg) f g hf hg

end FoldMid

#print axioms FoldMid.cs_of_rp
#print axioms FoldMid.cfgPerm_affC
#print axioms FoldMid.rp_mid
#print axioms FoldMid.cs_mid
