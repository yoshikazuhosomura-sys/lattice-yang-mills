import FoldChess.MixCV1
/-!
**Volume-uniform rarity with rate 1 (mixed chessboard), one statement.**  For 0 < y ≤ 2 there are r = y/20 > 0
and β₀ such that for all β ≥ β₀ the number q₁ = e^{β(48 r² − y)} / h(r)⁴ is < 1 and, for every m ≥ 2 (N = 2m) and
every finite set S of sites of (ℤ/N)⁴,
  ∫ ∏_{x ∈ S} 1[y < 1 − Re U_{(x; 01)}] dμ_W ≤ Z · q₁^{|S|}.
β₀ = 4 log(1/h(r)) / (y − 48 r²) + 1 (and ≥ 0); the value of h(r) is not computed in Lean.

Paper correspondence: one-scale rarity (Proposition P with rate 1 for one orientation), uniform in the volume.
-/

namespace FoldMix

open MeasureTheory TorusRP FoldChess FoldWilson FoldPeierls FoldEntropy Finset

theorem rarity_uniform_mix (y : ℝ) (hy0 : 0 < y) (hy2 : y ≤ 2) :
    ∃ r : ℝ, 0 < r ∧ ∃ β₀ : ℝ, ∀ β : ℝ, β₀ ≤ β →
      Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 < 1 ∧
      ∀ (N : ℕ) [NeZero N] (m : ℕ), N = 2 * m → 2 ≤ m → ∀ S : Finset (Site N),
        ∫ ω, ∏ x ∈ S, bigP N y ω ((x, 0), 1) ∂(wilsonMeasure N β) ≤
          Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  set r : ℝ := y / 20 with hr
  have hr0 : 0 < r := by rw [hr]; positivity
  have hh := ballQ_pos r hr0
  set g : ℝ := y - 48 * r ^ 2 with hg
  have hg0 : 0 < g := by rw [hg, hr]; nlinarith
  refine ⟨r, hr0, max 0 (4 * Real.log (1 / haarBall.real (ballQ r)) / g + 1), fun β hβ => ?_⟩
  have hβ0 : 0 ≤ β := le_trans (le_max_left _ _) hβ
  have hβ1 : 4 * Real.log (1 / haarBall.real (ballQ r)) / g + 1 ≤ β := le_trans (le_max_right _ _) hβ
  have hlt : 4 * Real.log (1 / haarBall.real (ballQ r)) < β * (y - 48 * r ^ 2) := by
    rw [← hg]
    have : 4 * Real.log (1 / haarBall.real (ballQ r)) / g < β := by linarith
    rw [div_lt_iff₀ hg0] at this
    linarith
  have hq : Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 < 1 := by
    have h4 := q_lt_one β (16 * y) r _ hh (by rw [show 16 * y / 16 = y by ring]; exact hlt)
    rwa [show 16 * y / 16 = y by ring] at h4
  refine ⟨hq, fun N _ m hN hM S => ?_⟩
  exact rarity_sites_mix N m hM hN β hβ0 y r hr0 S

end FoldMix

#print axioms FoldMix.rarity_uniform_mix
