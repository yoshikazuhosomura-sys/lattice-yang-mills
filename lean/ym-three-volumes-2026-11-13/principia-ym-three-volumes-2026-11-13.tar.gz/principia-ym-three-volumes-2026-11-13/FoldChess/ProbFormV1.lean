import FoldChess.MixAllUniformV1
/-!
The probability form of the volume-uniform rarity: Z > 0 and
  μ_W(all plaquettes of X are large) / Z ≤ q₁^{⌊|X|/6⌋},   q₁ < 1 for β ≥ β₀(y),
for every m ≥ 2 and every finite set X of plaquettes of (ℤ/2m)⁴.

Paper correspondence: one-scale rarity (Proposition P), normalised.
-/

namespace FoldMix

open MeasureTheory TorusRP FoldChess FoldWilson FoldPeierls FoldEntropy Finset

theorem Zw_pos (N : ℕ) [NeZero N] (β : ℝ) (hβ : 0 ≤ β) (r : ℝ) (hr : 0 < r) : 0 < Zw N β :=
  lt_of_lt_of_le (mul_pos (Real.exp_pos _) (pow_pos (ballQ_pos r hr) _)) (Zw_ge N β hβ r)

/-- **Volume-uniform rarity, normalised.** -/
theorem rarity_prob (y : ℝ) (hy0 : 0 < y) (hy2 : y ≤ 2) :
    ∃ r : ℝ, 0 < r ∧ ∃ β₀ : ℝ, ∀ β : ℝ, β₀ ≤ β →
      Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 < 1 ∧
      ∀ (N : ℕ) [NeZero N] (m : ℕ), N = 2 * m → 2 ≤ m → ∀ X : Finset (Lk N × Fin 4), X ⊆ plaqs N →
        0 < Zw N β ∧ (∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β)) / Zw N β ≤
          (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 6) := by
  obtain ⟨r, hr0, β₀, h⟩ := rarity_uniform_all_mix y hy0 hy2
  refine ⟨r, hr0, max β₀ 0, fun β hβ => ?_⟩
  have hβ1 : β₀ ≤ β := le_trans (le_max_left _ _) hβ
  have hβ0 : 0 ≤ β := le_trans (le_max_right _ _) hβ
  obtain ⟨hq, hall⟩ := h β hβ1
  refine ⟨hq, fun N _ m hN hM X hX => ?_⟩
  have hZ := Zw_pos N β hβ0 r hr0
  refine ⟨hZ, ?_⟩
  rw [div_le_iff₀ hZ, mul_comm]
  exact hall N m hN hM X hX

end FoldMix

#print axioms FoldMix.rarity_prob
