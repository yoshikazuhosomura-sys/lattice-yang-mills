import FoldChess.WilsonDataV1
/-!
**The chessboard estimate for the concrete SU(2) Wilson measure on (ℤ/2m)⁴, every m ≥ 1.**

For every family Hf of bounded measurable functions of the links of the unit cube at the origin and every
assignment F of these functions to the N⁴ unit cubes (N = 2m),
  |∫ ∏_w Hf (F w) (Ψ w ω) dμ_W|^(N⁴) ≤ ∏_w ∫ ∏_{w'} Hf (F w) (Ψ w' ω) dμ_W,
where Ψ w transports the cube at the origin to the cube w (translations and site reflections), and μ_W is the
(unnormalised) Wilson measure `wilsonMeasure N β` of the second-order lattice library, every real β.
The root form: if every uniform value is at most c(i)^(N⁴), the value of F is at most ∏_w c(F w).

Paper correspondence: one-scale rarity; the chessboard estimate of Fröhlich–Israel–Lieb–Simon on (ℤ/2h)⁴.
-/

namespace FoldWilson

open MeasureTheory TorusRP LinkReflection PeierlsPerm PeierlsPermCS FoldAffine FoldChess

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the offset of the transport of one block coordinate -/
def cof (t : ZMod N) : ZMod N := if par N t then t + 1 else t

/-- the link read by the transport -/
def Lt (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) : Lk N :=
  affL N 3 (par N t3) (cof N t3) (affL N 2 (par N t2) (cof N t2)
    (affL N 1 (par N t1) (cof N t1) (affL N 0 (par N t0) (cof N t0) ℓ)))

theorem measurable_Ψ (t0 t1 t2 t3 : ZMod N) : Measurable (Ψ N t0 t1 t2 t3) := by
  unfold Ψ Φ
  exact (measurable_affC N 0 _ _).comp ((measurable_affC N 1 _ _).comp
    ((measurable_affC N 2 _ _).comp (measurable_affC N 3 _ _)))

theorem det_Ψ (t0 t1 t2 t3 : ZMod N) (ω ω' : Cfg N) (ℓ : Lk N)
    (h : ω (Lt N t0 t1 t2 t3 ℓ) = ω' (Lt N t0 t1 t2 t3 ℓ)) : Ψ N t0 t1 t2 t3 ω ℓ = Ψ N t0 t1 t2 t3 ω' ℓ := by
  unfold Ψ Φ
  apply det_affC; apply det_affC; apply det_affC; apply det_affC
  exact h

theorem Lt_snd (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) : (Lt N t0 t1 t2 t3 ℓ).2 = ℓ.2 := rfl

theorem nv_affL (j k : Fin 4) (hkj : k ≠ j) (f g : Bool) (c c' : ZMod N) (ℓ : Lk N) :
    nv N k f c (affL N j g c' ℓ) = nv N k f c ℓ := by
  unfold nv; rw [affL_coord, if_neg hkj, affL_snd]

theorem Lt_coord0 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Lt N t0 t1 t2 t3 ℓ).1 0 = nv N 0 (par N t0) (cof N t0) ℓ := by
  simp only [Lt]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_neg (by decide),
    affL_coord, if_pos rfl]

theorem Lt_coord1 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Lt N t0 t1 t2 t3 ℓ).1 1 = nv N 1 (par N t1) (cof N t1) ℓ := by
  simp only [Lt]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_pos rfl,
    nv_affL N 0 1 (by decide)]

theorem Lt_coord2 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Lt N t0 t1 t2 t3 ℓ).1 2 = nv N 2 (par N t2) (cof N t2) ℓ := by
  simp only [Lt]
  rw [affL_coord, if_neg (by decide), affL_coord, if_pos rfl, nv_affL N 1 2 (by decide),
    nv_affL N 0 2 (by decide)]

theorem Lt_coord3 (t0 t1 t2 t3 : ZMod N) (ℓ : Lk N) :
    (Lt N t0 t1 t2 t3 ℓ).1 3 = nv N 3 (par N t3) (cof N t3) ℓ := by
  simp only [Lt]
  rw [affL_coord, if_pos rfl, nv_affL N 2 3 (by decide), nv_affL N 1 3 (by decide),
    nv_affL N 0 3 (by decide)]

/-- **Locality**: a transported block function with the k-th block coordinate in the plus half is in the class. -/
theorem loc_general (hN : N = 2 * m) (k : Fin 4) (a t : ZMod N) (L : Lk N → Lk N) (P : Cfg N → Cfg N)
    (hP : Measurable P) (hdet : ∀ ω ω' ℓ, ω (L ℓ) = ω' (L ℓ) → P ω ℓ = P ω' ℓ)
    (hsnd : ∀ ℓ, (L ℓ).2 = ℓ.2) (hcoord : ∀ ℓ, (L ℓ).1 k = nv N k (par N t) (cof N t) ℓ)
    (ht : inH m a t) (h : Cfg N → ℝ) (hh : Base N h) : Good N m k a (fun ω => h (P ω)) := by
  obtain ⟨hm, ⟨C, hC⟩, hd⟩ := hh
  refine ⟨hm.comp hP, hm.comp (hP.comp (measurable_affC N k false _)), ⟨C, fun ω => hC _⟩,
    fun ω ω' hag => ?_⟩
  show h (P (S N k a ω)) = h (P (S N k a ω'))
  apply hd
  intro ℓ hℓ
  apply hdet
  apply det_affC
  apply hag
  apply half_of_val
  obtain ⟨x, μ⟩ := ℓ
  have e1 : (affL N k false (-a) (L (x, μ))).1 k = nv N k (par N t) (cof N t) (x, μ) + -a := by
    rw [affL_coord, if_pos rfl]
    show (L (x, μ)).1 k + -a = _
    rw [hcoord]
  rw [affL_snd, hsnd, e1]
  exact coord_value N m hN k a t ht x μ (hℓ.2 k) (fun h' => h' ▸ hℓ.1)

/-- **All the data of the chessboard estimate for the Wilson measure.** -/
theorem data (hN : N = 2 * m) (β : ℝ) {I : Type*} (Hf : I → Cfg N → ℝ) (hH : ∀ i, Base N (Hf i)) :
    Data4 m (wilsonMeasure N β) Hf (Ψ N) (R N) (Good N m) where
  one := good_one N m
  mul := good_mul N m
  cs := fun k a f g hf hg => cs_R N m hN k a β f g hf hg
  rp := fun k a f hf => rp_R N m hN k a β f hf
  tr0 := tr0 N m hN
  tr1 := tr1 N m hN
  tr2 := tr2 N m hN
  tr3 := tr3 N m hN
  loc0 := fun a t0 t1 t2 t3 i ht => loc_general N m hN 0 a t0 (Lt N t0 t1 t2 t3) (Ψ N t0 t1 t2 t3)
    (measurable_Ψ N t0 t1 t2 t3) (det_Ψ N t0 t1 t2 t3) (Lt_snd N t0 t1 t2 t3) (Lt_coord0 N t0 t1 t2 t3) ht
    (Hf i) (hH i)
  loc1 := fun a t0 t1 t2 t3 i ht => loc_general N m hN 1 a t1 (Lt N t0 t1 t2 t3) (Ψ N t0 t1 t2 t3)
    (measurable_Ψ N t0 t1 t2 t3) (det_Ψ N t0 t1 t2 t3) (Lt_snd N t0 t1 t2 t3) (Lt_coord1 N t0 t1 t2 t3) ht
    (Hf i) (hH i)
  loc2 := fun a t0 t1 t2 t3 i ht => loc_general N m hN 2 a t2 (Lt N t0 t1 t2 t3) (Ψ N t0 t1 t2 t3)
    (measurable_Ψ N t0 t1 t2 t3) (det_Ψ N t0 t1 t2 t3) (Lt_snd N t0 t1 t2 t3) (Lt_coord2 N t0 t1 t2 t3) ht
    (Hf i) (hH i)
  loc3 := fun a t0 t1 t2 t3 i ht => loc_general N m hN 3 a t3 (Lt N t0 t1 t2 t3) (Ψ N t0 t1 t2 t3)
    (measurable_Ψ N t0 t1 t2 t3) (det_Ψ N t0 t1 t2 t3) (Lt_snd N t0 t1 t2 t3) (Lt_coord3 N t0 t1 t2 t3) ht
    (Hf i) (hH i)

/-- **The chessboard estimate for the SU(2) Wilson measure on (ℤ/2m)⁴, every m ≥ 1, every β.** -/
theorem wilson_chessboard_even (hN : N = 2 * m) (β : ℝ) {I : Type*} (Hf : I → Cfg N → ℝ)
    (hH : ∀ i, Base N (Hf i)) (F : ZMod N → ZMod N → ZMod N → ZMod N → I) :
    |V4 (wilsonMeasure N β) Hf (Ψ N) F| ^ (N ^ 4) ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, V4 (wilsonMeasure N β) Hf (Ψ N) (fun _ _ _ _ => F t0 t1 t2 t3) :=
  chess_data m _ hN Hf (Ψ N) (R N) (Good N m) (data N m hN β Hf hH) F

/-- **The root form**: uniform bounds per block give the product bound. -/
theorem wilson_chessboard_even_root (hN : N = 2 * m) (β : ℝ) {I : Type*} (Hf : I → Cfg N → ℝ)
    (hH : ∀ i, Base N (Hf i)) (c : I → ℝ) (hc : ∀ i, 0 ≤ c i)
    (hconst : ∀ i, V4 (wilsonMeasure N β) Hf (Ψ N) (fun _ _ _ _ => i) ≤ c i ^ (N ^ 4))
    (F : ZMod N → ZMod N → ZMod N → ZMod N → I) :
    |V4 (wilsonMeasure N β) Hf (Ψ N) F| ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3) :=
  chess_data_root m _ hN Hf (Ψ N) (R N) (Good N m) (data N m hN β Hf hH) c hc hconst F

end FoldWilson

#print axioms FoldWilson.data
#print axioms FoldWilson.wilson_chessboard_even
#print axioms FoldWilson.wilson_chessboard_even_root
