import FoldChess.AffineV1
import Lattice.MidRPV2
/-!
Toward the mixed chessboard (lattice planes and link mid-planes): invariance of the Wilson measure under every affine
map of one coordinate, the symmetry of the reflected pairing, and the link mid-plane reflection of the time direction
as an affine map.
* `wilson_affC_invariant` : ∫ F(affC d f c ω) dμ_W = ∫ F dμ_W (N even), every d, f, c.
* `pair_symm` : ∫ F(R ω) G(ω) dμ_W = ∫ G(R ω) F(ω) dμ_W for R = (x_d ↦ c − x_d), every c (lattice or mid-plane).
* `midRefl_eq` : the reflection through the link mid-plane x₀ = ½ of the positivity theorem `MidRP.wilson_rp_mid`
  is the affine map x₀ ↦ 1 − x₀; hence `wilson_rp_mid_affC`.

Paper correspondence: one-scale rarity, the mixed chessboard (link mid-planes in the directions off the plane).
-/

namespace FoldMid

open MeasureTheory TorusRP LinkReflection PeierlsPerm FoldAffine MidRP TorusGauge GaugeFix

variable (N : ℕ) [NeZero N]

theorem affC_false_zero (d : Fin 4) (ω : Lk N → QBall) : affC N d false 0 ω = ω := by
  rw [affC_false_eq]; funext ℓ; simp [shV]

theorem affC_invol (d : Fin 4) (c : ZMod N) (ω : Lk N → QBall) :
    affC N d true c (affC N d true c ω) = ω := by
  rw [affC_comp]; simp only [Bool.xor_self, if_true, sub_self]; exact affC_false_zero N d ω

theorem wilson_linkRefl_invariant (M : ℕ) (hN : N = 2 * M) (β : ℝ) (F : (Lk N → QBall) → ℝ)
    (hF : Measurable F) :
    ∫ ω, F (linkRefl (thL N) (sig N) ω) ∂(wilsonMeasure N β) = ∫ ω, F ω ∂(wilsonMeasure N β) := by
  have h := wilson_refl_symm N M hN β F (fun _ => (1 : ℝ)) hF measurable_const
  simpa using h

theorem wilson_reflPerm_invariant (M : ℕ) (hN : N = 2 * M) (d : Fin 4) (β : ℝ) (F : (Lk N → QBall) → ℝ)
    (hF : Measurable F) :
    ∫ ω, F (reflPerm N (Equiv.swap 0 d) ω) ∂(wilsonMeasure N β) = ∫ ω, F ω ∂(wilsonMeasure N β) := by
  have hτ : ∀ j, (Equiv.swap 0 d) ((Equiv.swap 0 d) j) = j := fun j => Equiv.swap_apply_self 0 d j
  have hPm : Measurable (cfgPerm N (Equiv.swap 0 d)) := (cfgPerm_preserving N _ hτ).measurable
  have hRm : Measurable (linkRefl (thL N) (sig N)) := (linkRefl_preserving N).measurable
  unfold reflPerm
  rw [wilson_perm_invariant N _ hτ β (fun ω => F (cfgPerm N _ (linkRefl (thL N) (sig N) ω))) (hF.comp (hPm.comp hRm)),
    wilson_linkRefl_invariant N M hN β (fun ω => F (cfgPerm N _ ω)) (hF.comp hPm),
    wilson_perm_invariant N _ hτ β F hF]

/-- **Invariance of the Wilson measure under every affine map of one coordinate** (N even). -/
theorem wilson_affC_invariant (M : ℕ) (hN : N = 2 * M) (d : Fin 4) (f : Bool) (c : ZMod N) (β : ℝ)
    (F : (Lk N → QBall) → ℝ) (hF : Measurable F) :
    ∫ ω, F (affC N d f c ω) ∂(wilsonMeasure N β) = ∫ ω, F ω ∂(wilsonMeasure N β) := by
  cases f
  · exact wilson_affC_false_invariant N d c β F hF
  · have e : ∀ ω, affC N d true c ω = affC N d false (-c) (reflPerm N (Equiv.swap 0 d) ω) := by
      intro ω
      rw [← affC_true_zero, affC_comp]; simp
    simp_rw [e]
    rw [wilson_reflPerm_invariant N M hN d β (fun ω => F (affC N d false (-c) ω))
      (hF.comp (measurable_affC N d false _)), wilson_affC_false_invariant N d (-c) β F hF]

/-- **Symmetry of the reflected pairing** for every reflection x_d ↦ c − x_d. -/
theorem pair_symm (M : ℕ) (hN : N = 2 * M) (d : Fin 4) (c : ZMod N) (β : ℝ) (F G : (Lk N → QBall) → ℝ)
    (hF : Measurable F) (hG : Measurable G) :
    ∫ ω, F (affC N d true c ω) * G ω ∂(wilsonMeasure N β) =
      ∫ ω, G (affC N d true c ω) * F ω ∂(wilsonMeasure N β) := by
  have hR := measurable_affC N d true c
  have h := wilson_affC_invariant N M hN d true c β (fun ω => F (affC N d true c ω) * G ω)
    ((hF.comp hR).mul hG)
  rw [← h]
  congr 1; funext ω
  simp only [affC_invol]
  rw [mul_comm]

/-- the link mid-plane reflection of the time direction is x₀ ↦ 1 − x₀ -/
theorem midRefl_eq : linkRefl (thM N) (sigT N) = affC N 0 true 1 := by
  funext ω ℓ
  obtain ⟨x, μ⟩ := ℓ
  have hl : thM N (x, μ) = affL N 0 true 1 (x, μ) := by
    refine Prod.ext ?_ (thM_snd N _)
    funext j
    by_cases hj : j = 0
    · subst hj
      rw [thM_time]
      by_cases hμ : μ = 0
      · subst hμ; simp [affL, nv]
      · simp [affL, nv, hμ]
    · unfold thM shL thL
      by_cases hμ : μ = 0
      · subst hμ; simp [affL, hj, thS, ev, Pi.single_apply]
      · simp [affL, hj, hμ, thS, ev, Pi.single_apply]
  simp only [linkRefl, sigT, affC, hl]
  by_cases hμ : μ = 0
  · simp [hμ]
  · simp [hμ]

/-- **Mid-plane reflection positivity in the affine form** (the time direction, the plane x₀ = ½, β ≥ 0). -/
theorem wilson_rp_mid_affC (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (F : (Lk N → QBall) → ℝ) (hF : Measurable F) (CF : ℝ) (hFb : ∀ ω, |F ω| ≤ CF)
    (hFdep : ∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω')
    (hinv : ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : Quaternion ℝ)‖ = 1) → ∀ ω,
      F (act (src N) (tgt N) g ω) = F ω) :
    0 ≤ ∫ ω, F (affC N 0 true 1 ω) * F ω ∂(wilsonMeasure N β) := by
  have h := MidRP.wilson_rp_mid N M hN hM β hβ F hF CF hFb hFdep hinv
  rw [midRefl_eq] at h
  simpa only [mul_comm] using h

end FoldMid

#print axioms FoldMid.wilson_affC_invariant
#print axioms FoldMid.pair_symm
#print axioms FoldMid.midRefl_eq
#print axioms FoldMid.wilson_rp_mid_affC
