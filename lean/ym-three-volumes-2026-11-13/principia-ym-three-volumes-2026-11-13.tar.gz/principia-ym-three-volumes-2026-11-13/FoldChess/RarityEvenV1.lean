import FoldChess.PeierlsEvenV1
/-!
**Volume-uniform rarity of large plaquettes for the SU(2) Wilson measure on (ℤ/2m)⁴, every m ≥ 1.**

Entropy half: Z ≥ e^{β #P (1 − 8r²)} h(r)^{#links}, h(r) := Haar{U : ‖U − 1‖ < r} (all links in the ball; then
1 − Re U_p ≤ 8r² for every plaquette).  Counting: #P = 6N⁴, #links = 4N⁴, the even sublattice has m⁴ = N⁴/16 blocks.
With the chessboard estimate (`FoldPeierls.peierls_even`):
  ∫ ∏_w Hf (F w) (Ψ_w ω) dμ_W ≤ Z · q^{#{w : F w}},   q := e^{β(48 r² − y/16)} / h(r)⁴,
for every β ≥ 0, y, r with h(r) > 0, every m ≥ 1 and every family F of the N⁴ blocks.  The constant q does not depend
on m.  In particular, for blocks with all coordinates even the event of the block w is "the plaquette (w; μν) is
large", so μ_W(the plaquettes (w; μν), w ∈ X, are all large) ≤ q^{|X|} for X in the even sublattice.

Paper correspondence: one-scale rarity (Proposition P), rate 1/16, the entropy constant by the ball of radius r.
-/

namespace FoldEntropy

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls Finset

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ)

theorem norm_mul_sub_one (a b : ℍr) (ha : ‖a‖ = 1) : ‖a * b - 1‖ ≤ ‖a - 1‖ + ‖b - 1‖ := by
  have e : a * b - 1 = a * (b - 1) + (a - 1) := by rw [mul_sub, mul_one]; abel
  rw [e]
  calc ‖a * (b - 1) + (a - 1)‖ ≤ ‖a * (b - 1)‖ + ‖a - 1‖ := norm_add_le _ _
    _ = ‖b - 1‖ + ‖a - 1‖ := by rw [norm_mul, ha, one_mul]
    _ = ‖a - 1‖ + ‖b - 1‖ := add_comm _ _

theorem norm_star_sub_one (a : ℍr) : ‖star a - 1‖ = ‖a - 1‖ := by
  have e : star a - 1 = star (a - 1) := by simp
  rw [e, norm_star]

theorem one_sub_re (q : ℍr) (hq : ‖q‖ = 1) : 1 - q.re = ‖q - 1‖ ^ 2 / 2 := by
  have h1 : ‖q - 1‖ ^ 2 = Quaternion.normSq (q - 1) := by
    rw [Quaternion.normSq_eq_norm_mul_self, sq]
  have h2 : Quaternion.normSq q = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, hq, one_mul]
  have h3 : Quaternion.normSq (q - 1) =
      (q.re - 1) ^ 2 + (q.imI - 0) ^ 2 + (q.imJ - 0) ^ 2 + (q.imK - 0) ^ 2 := by
    rw [Quaternion.normSq_def']; rfl
  have h4 : Quaternion.normSq q = q.re ^ 2 + q.imI ^ 2 + q.imJ ^ 2 + q.imK ^ 2 := by
    rw [Quaternion.normSq_def']
  rw [h1, h3]
  rw [h4] at h2
  simp only [sub_zero]
  nlinarith [h2]

/-- unit quaternions within r of 1 -/
def ballQ (r : ℝ) : Set QBall := {q | ‖(q : ℍr) - 1‖ < r ∧ ‖(q : ℍr)‖ = 1}

/-- configurations with every link in the ball -/
def cfgBallQ (r : ℝ) : Set (Cfg N) := Set.pi Set.univ (fun _ => ballQ r)

theorem measurableSet_ballQ (r : ℝ) : MeasurableSet (ballQ r) := by
  have h1 : IsOpen {q : QBall | ‖(q : ℍr) - 1‖ < r} :=
    isOpen_lt (continuous_norm.comp (continuous_subtype_val.sub continuous_const)) continuous_const
  have h2 : IsClosed {q : QBall | ‖(q : ℍr)‖ = 1} :=
    isClosed_eq (continuous_norm.comp continuous_subtype_val) continuous_const
  exact h1.measurableSet.inter h2.measurableSet

theorem cost_on_ball (r : ℝ) (ω : Cfg N) (hω : ω ∈ cfgBallQ N r) (p : Lk N × Fin 4) :
    1 - (hol N ω p).re ≤ 8 * r ^ 2 := by
  have hb : ∀ ℓ, ‖(ω ℓ : ℍr) - 1‖ < r ∧ ‖(ω ℓ : ℍr)‖ = 1 := fun ℓ => hω ℓ (Set.mem_univ ℓ)
  set a : ℍr := (ω p.1 : ℍr)
  set b : ℍr := (ω (p.1.1 + ev N p.1.2, p.2) : ℍr)
  set c : ℍr := (ω (p.1.1 + ev N p.2, p.1.2) : ℍr)
  set d : ℍr := (ω (p.1.1, p.2) : ℍr)
  have ha := hb p.1; have hb' := hb (p.1.1 + ev N p.1.2, p.2)
  have hc := hb (p.1.1 + ev N p.2, p.1.2); have hd := hb (p.1.1, p.2)
  have eh : hol N ω p = a * b * star c * star d := rfl
  have n12 : ‖a * b‖ = 1 := by rw [norm_mul, ha.2, hb'.2, one_mul]
  have n123 : ‖a * b * star c‖ = 1 := by rw [norm_mul, n12, norm_star, hc.2, one_mul]
  have nh : ‖a * b * star c * star d‖ = 1 := by rw [norm_mul, n123, norm_star, hd.2, one_mul]
  have hlt : ‖a * b * star c * star d - 1‖ < 4 * r := by
    calc ‖a * b * star c * star d - 1‖ ≤ ‖a * b * star c - 1‖ + ‖star d - 1‖ := norm_mul_sub_one _ _ n123
      _ ≤ (‖a * b - 1‖ + ‖star c - 1‖) + ‖star d - 1‖ := by gcongr; exact norm_mul_sub_one _ _ n12
      _ ≤ ((‖a - 1‖ + ‖b - 1‖) + ‖star c - 1‖) + ‖star d - 1‖ := by
          gcongr; exact norm_mul_sub_one _ _ ha.2
      _ < 4 * r := by rw [norm_star_sub_one, norm_star_sub_one]; linarith [ha.1, hb'.1, hc.1, hd.1]
  rw [eh, one_sub_re _ nh]
  have h0 : 0 ≤ ‖a * b * star c * star d - 1‖ := norm_nonneg _
  nlinarith

theorem card_lk : Fintype.card (Lk N) = 4 * N ^ 4 := by
  simp only [Lk, Site, Fintype.card_prod, Fintype.card_fun, ZMod.card, Fintype.card_fin]; ring

theorem card_plaqs : (plaqs N).card = 6 * N ^ 4 := by
  have e : (plaqs N).card =
      ((univ : Finset (Site N)) ×ˢ (univ.filter (fun q : Fin 4 × Fin 4 => q.1 < q.2))).card := by
    apply Finset.card_nbij' (fun p => (p.1.1, (p.1.2, p.2))) (fun q => ((q.1, q.2.1), q.2.2))
    · intro p hp; simp only [plaqs, coe_filter, mem_univ, true_and, Set.mem_setOf_eq] at hp
      simp only [coe_product, coe_univ, coe_filter, mem_univ, true_and, Set.mem_prod, Set.mem_univ,
        Set.mem_setOf_eq]; exact hp
    · intro q hq; simp only [coe_product, coe_univ, coe_filter, mem_univ, true_and, Set.mem_prod,
        Set.mem_univ, Set.mem_setOf_eq] at hq
      simp only [plaqs, coe_filter, mem_univ, true_and, Set.mem_setOf_eq]; exact hq
    · intro p _; rfl
    · intro q _; rfl
  have h6 : (univ.filter (fun q : Fin 4 × Fin 4 => q.1 < q.2)).card = 6 := by decide
  rw [e, card_product, card_univ, h6, Fintype.card_fun, ZMod.card, Fintype.card_fin]; ring

/-- **Entropy half**: Z ≥ e^{β #P (1 − 8r²)} h(r)^{#links}, β ≥ 0. -/
theorem Zw_ge (β : ℝ) (hβ : 0 ≤ β) (r : ℝ) :
    Real.exp (β * ((plaqs N).card * (1 - 8 * r ^ 2))) * (haarBall.real (ballQ r)) ^ Fintype.card (Lk N) ≤
      Zw N β := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  set L := Real.exp (β * ((plaqs N).card * (1 - 8 * r ^ 2)))
  have hS : MeasurableSet (cfgBallQ N r) := MeasurableSet.univ_pi (fun _ => measurableSet_ballQ r)
  have hpt : ∀ ω, (cfgBallQ N r).indicator (fun _ => L) ω ≤ Real.toNNReal (wilsonWeight N β ω) • (1 : ℝ) := by
    intro ω
    have hw0 : 0 ≤ wilsonWeight N β ω := by unfold wilsonWeight; positivity
    rw [NNReal.smul_def, smul_eq_mul, mul_one, Real.coe_toNNReal _ hw0]
    by_cases hω : ω ∈ cfgBallQ N r
    · rw [Set.indicator_of_mem hω]
      unfold wilsonWeight
      apply Real.exp_le_exp.mpr
      apply mul_le_mul_of_nonneg_left _ hβ
      unfold action
      have : ∑ _p ∈ plaqs N, (1 - 8 * r ^ 2) ≤ ∑ p ∈ plaqs N, (hol N ω p).re :=
        sum_le_sum (fun p _ => by linarith [cost_on_ball N r ω hω p])
      rw [sum_const, nsmul_eq_mul] at this
      exact this
    · rw [Set.indicator_of_notMem hω]; exact hw0
  have hint_ind : Integrable ((cfgBallQ N r).indicator (fun _ => L)) (Measure.pi fun _ : Lk N => haarBall) :=
    (integrable_const L).indicator hS
  have hint : Integrable (fun ω => Real.toNNReal (wilsonWeight N β ω) • (1 : ℝ))
      (Measure.pi fun _ : Lk N => haarBall) := by
    refine Integrable.of_bound (hWm.smul measurable_const).aestronglyMeasurable
      (Real.exp (|β| * (plaqs N).card)) (Filter.Eventually.of_forall fun ω => ?_)
    have hw0 : 0 ≤ wilsonWeight N β ω := by unfold wilsonWeight; positivity
    rw [NNReal.smul_def, smul_eq_mul, mul_one, Real.coe_toNNReal _ hw0, Real.norm_eq_abs, abs_of_nonneg hw0]
    exact wilsonWeight_le N β ω
  have hmono := integral_mono hint_ind hint hpt
  rw [integral_indicator_const L hS, smul_eq_mul] at hmono
  have hpi : (Measure.pi fun _ : Lk N => haarBall).real (cfgBallQ N r) =
      (haarBall.real (ballQ r)) ^ Fintype.card (Lk N) := by
    unfold cfgBallQ
    rw [Measure.real, Measure.pi_pi, ENNReal.toReal_prod, Finset.prod_const, Finset.card_univ]
    rfl
  rw [hpi] at hmono
  unfold Zw
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  linarith [hmono]

/-- **Volume-uniform rarity on (ℤ/2m)⁴, every m ≥ 1.** -/
theorem rarity_even (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ)
    (hh : 0 < haarBall.real (ballQ r)) (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F ≤
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4 else 1) := by
  have hp := peierls_even N m hN β hβ μ ν hμν y F
  set h := haarBall.real (ballQ r) with hhdef
  set q := Real.exp (β * (48 * r ^ 2 - y / 16)) / h ^ 4 with hq
  set A := Real.exp (β * ((plaqs N).card - y * m ^ 4) / (N ^ 4 : ℕ)) with hA
  set B := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hNpos : (0 : ℝ) < ((N ^ 4 : ℕ) : ℝ) := by exact_mod_cast pow_pos (Nat.pos_of_ne_zero (NeZero.ne N)) 4
  have hNr : (N : ℝ) = 2 * m := by exact_mod_cast hN
  have hm0 : (0 : ℝ) < m := by
    have : 0 < N := Nat.pos_of_ne_zero (NeZero.ne N)
    have : 0 < m := by omega
    exact_mod_cast this
  -- the lower bound for B
  have hZ := Zw_ge N β hβ r
  rw [card_plaqs, card_lk] at hZ
  have hlow : Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 ≤ B := by
    have e : (Real.exp (β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2))) * h ^ (4 * N ^ 4)) ^
        ((1 : ℝ) / (N ^ 4 : ℕ)) = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 := by
      rw [Real.mul_rpow (Real.exp_pos _).le (pow_nonneg hh.le _), ← Real.exp_mul,
        ← Real.rpow_natCast h (4 * N ^ 4), ← Real.rpow_mul hh.le]
      have e1 : β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2)) * (1 / ((N ^ 4 : ℕ) : ℝ)) =
          β * (6 - 48 * r ^ 2) := by
        field_simp; push_cast; ring
      have e2 : (((4 * N ^ 4 : ℕ) : ℝ)) * (1 / ((N ^ 4 : ℕ) : ℝ)) = ((4 : ℕ) : ℝ) := by
        field_simp; push_cast; ring
      rw [e1, e2, Real.rpow_natCast]
    rw [← e, hB]
    exact Real.rpow_le_rpow (by positivity) hZ (by positivity)
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg hh.le _)
  have hB0 : 0 ≤ B := Real.rpow_nonneg (Zw_nonneg N β) _
  have hAeq : A = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 * q := by
    rw [hA, hq, card_plaqs]
    rw [mul_div_assoc', mul_comm (Real.exp _) (h ^ 4), mul_assoc, ← Real.exp_add,
      mul_div_assoc, mul_div_cancel_left₀ _ (pow_ne_zero 4 hh.ne')]
    congr 1
    have hN4 : ((N ^ 4 : ℕ) : ℝ) = 16 * (m : ℝ) ^ 4 := by push_cast; rw [hNr]; ring
    rw [hN4]
    field_simp
    push_cast
    rw [hNr]
    ring
  have hAB : A ≤ B * q := by rw [hAeq]; exact mul_le_mul_of_nonneg_right hlow hq0
  have hstep : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then A else B) ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) := by
    apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t0 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t1 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t2 _; apply prod_le_prod (fun _ _ => by split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t3 _; split_ifs
    · exact hAB
    · rw [mul_one]
  have hsplit : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) =
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then q else 1) := by
    simp only [prod_mul_distrib, prod_const, card_univ, ZMod.card]
    congr 1
    rw [← pow_mul, ← pow_mul, ← pow_mul, hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β)]
    have : (1 : ℝ) / ((N ^ 4 : ℕ) : ℝ) * ((N * (N * (N * N)) : ℕ) : ℝ) = 1 := by
      field_simp; push_cast; ring
    rw [this, Real.rpow_one]
  calc V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F ≤ |V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F| :=
        le_abs_self _
    _ ≤ _ := hp
    _ ≤ _ := hstep
    _ = _ := hsplit

end FoldEntropy

#print axioms FoldEntropy.Zw_ge
#print axioms FoldEntropy.rarity_even
