import FoldChess.QuarterV1
/-!
Rate 1/4 for the volume-uniform rarity on (ℤ/2m)⁴, every m ≥ 1.

The transport Ψ_w moves (0; μν) to (b_w; μν), b_w,d = t_d for d ∈ {μ, ν} and t_d + [t_d odd] otherwise
(`re_hol_Ψ`, from `FoldQuarter.re_hol_affC`).  On the N²m² blocks whose coordinates off the plane (μ, ν) are even,
b_w = w, so the uniform family forces N⁴/4 distinct large plaquettes of the orientation (μ, ν):
  V(true) ≤ e^{β(#P − y N² m²)},   q₄ := e^{β(48 r² − y/4)} / h(r)⁴,
  ∫ ∏_w Hf (F w)(Ψ_w ω) dμ_W ≤ Z ∏_w (F w ? q₄ : 1),
and for a set S of sites with even coordinates off the plane, ∫ ∏_{x∈S} 1[(x; μν) large] ≤ Z q₄^{|S|}.

Paper correspondence: Proposition P with the rate 1/4.
-/

namespace FoldQuarter

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy Finset

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the image coordinate of the plaquette (0; μν) under Φ_d(t) -/
def bpos (d : Fin 4) (t : ZMod N) (μ ν : Fin 4) : ZMod N := if d = μ ∨ d = ν then t else (if par N t then t + 1 else t)

theorem nb_zero (d : Fin 4) (t : ZMod N) (μ ν : Fin 4) (x : Site N) (hx : x d = 0) :
    nb N d (par N t) (if par N t then t + 1 else t) μ ν x = bpos N d t μ ν := by
  unfold nb bpos
  cases par N t <;> by_cases h : d = μ ∨ d = ν <;> simp [h, hx]

/-- the image base point -/
def bvec (t0 t1 t2 t3 : ZMod N) (μ ν : Fin 4) : Site N :=
  Function.update (Function.update (Function.update (Function.update (0 : Site N) 0 (bpos N 0 t0 μ ν))
    1 (bpos N 1 t1 μ ν)) 2 (bpos N 2 t2 μ ν)) 3 (bpos N 3 t3 μ ν)

theorem re_hol_Ψ (t0 t1 t2 t3 : ZMod N) (ω : Cfg N) (μ ν : Fin 4) (hμν : μ < ν) :
    (hol N (Ψ N t0 t1 t2 t3 ω) (p0 N μ ν)).re = (hol N ω ((bvec N t0 t1 t2 t3 μ ν, μ), ν)).re := by
  unfold Ψ Φ p0 bvec
  rw [re_hol_affC N 0 _ _ _ _ μ ν hμν, nb_zero N 0 t0 μ ν _ rfl,
    re_hol_affC N 1 _ _ _ _ μ ν hμν, nb_zero N 1 t1 μ ν _ (by simp),
    re_hol_affC N 2 _ _ _ _ μ ν hμν, nb_zero N 2 t2 μ ν _ (by simp),
    re_hol_affC N 3 _ _ _ _ μ ν hμν, nb_zero N 3 t3 μ ν _ (by simp)]

/-- the block coordinates allowed in the direction d -/
def Sd (d : Fin 4) (μ ν : Fin 4) : Finset (ZMod N) := if d = μ ∨ d = ν then univ else evens N

theorem bpos_eq (d : Fin 4) (t : ZMod N) (μ ν : Fin 4) (ht : t ∈ Sd N d μ ν) : bpos N d t μ ν = t := by
  unfold bpos; unfold Sd at ht
  by_cases h : d = μ ∨ d = ν
  · simp [h]
  · simp only [h, if_false, evens, mem_filter, mem_univ, true_and] at ht ⊢
    simp [ht]

theorem bvec_eq (t0 t1 t2 t3 : ZMod N) (μ ν : Fin 4) (h0 : t0 ∈ Sd N 0 μ ν) (h1 : t1 ∈ Sd N 1 μ ν)
    (h2 : t2 ∈ Sd N 2 μ ν) (h3 : t3 ∈ Sd N 3 μ ν) : bvec N t0 t1 t2 t3 μ ν = vec N t0 t1 t2 t3 := by
  unfold bvec
  rw [bpos_eq N 0 t0 μ ν h0, bpos_eq N 1 t1 μ ν h1, bpos_eq N 2 t2 μ ν h2, bpos_eq N 3 t3 μ ν h3]
  funext j; fin_cases j <;> simp [vec, Function.update_apply, Pi.single_apply]

/-- the blocks with even coordinates off the plane -/
def E4 (μ ν : Fin 4) : Finset (ZMod N × ZMod N × ZMod N × ZMod N) :=
  Sd N 0 μ ν ×ˢ (Sd N 1 μ ν ×ˢ (Sd N 2 μ ν ×ˢ Sd N 3 μ ν))

theorem card_E4 (hN : N = 2 * m) (μ ν : Fin 4) (hμν : μ < ν) : (E4 N μ ν).card = N ^ 2 * m ^ 2 := by
  have hc := card_evens N m hN
  have hu : (univ : Finset (ZMod N)).card = N := by rw [card_univ, ZMod.card]
  unfold E4 Sd
  simp only [card_product]
  fin_cases μ <;> fin_cases ν <;> simp at hμν <;> simp [hc, hu] <;> ring

theorem action_le_quarter (hN : N = 2 * m) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) (ω : Cfg N)
    (h : ∀ t0 t1 t2 t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) ≠ 0) :
    action N ω ≤ (plaqs N).card - y * (N ^ 2 * m ^ 2) := by
  set E := E4 N μ ν
  have hE : E.card = N ^ 2 * m ^ 2 := card_E4 N m hN μ ν hμν
  let pl : ZMod N × ZMod N × ZMod N × ZMod N → Lk N × Fin 4 :=
    fun q => ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, μ), ν)
  have hinj : Set.InjOn pl E := by
    intro q _ q' _ hq
    have := vec_inj N (congrArg (fun p : Lk N × Fin 4 => p.1.1) hq)
    obtain ⟨a, b, c, d⟩ := this
    exact Prod.ext a (Prod.ext b (Prod.ext c d))
  have hsub : E.image pl ⊆ plaqs N := by
    intro p hp
    obtain ⟨q, _, rfl⟩ := mem_image.mp hp
    simp only [plaqs, mem_filter, mem_univ, true_and, pl]; exact hμν
  have hbig : ∀ q ∈ E, y < 1 - (hol N ω (pl q)).re := by
    intro q hq
    simp only [E, E4, mem_product] at hq
    have hb := h q.1 q.2.1 q.2.2.1 q.2.2.2
    unfold big at hb
    rw [re_hol_Ψ N _ _ _ _ ω μ ν hμν, bvec_eq N _ _ _ _ μ ν hq.1 hq.2.1 hq.2.2.1 hq.2.2.2] at hb
    by_contra hc
    exact hb (if_neg hc)
  have hs1 : y * (N ^ 2 * m ^ 2) ≤ ∑ p ∈ E.image pl, (1 - (hol N ω p).re) := by
    rw [sum_image (fun a ha b hb h => hinj ha hb h)]
    have e : y * ((N : ℝ) ^ 2 * (m : ℝ) ^ 2) = ∑ _q ∈ E, y := by
      rw [sum_const, hE, nsmul_eq_mul]; push_cast; ring
    rw [e]
    exact sum_le_sum (fun q hq => (hbig q hq).le)
  have hs2 : ∑ p ∈ E.image pl, (1 - (hol N ω p).re) ≤ ∑ p ∈ plaqs N, (1 - (hol N ω p).re) :=
    sum_le_sum_of_subset_of_nonneg hsub (fun p _ _ => by
      have := abs_hol_re N ω p; linarith [(abs_le.mp this).2])
  have hs3 : ∑ p ∈ plaqs N, (1 - (hol N ω p).re) = (plaqs N).card - ∑ p ∈ plaqs N, (hol N ω p).re := by
    rw [sum_sub_distrib, sum_const, nsmul_eq_mul, mul_one]
  unfold action
  linarith

/-- **The uniform family, all images**: V(true) ≤ e^{β(#P − y N² m²)}. -/
theorem V4_true_le4 (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) :
    V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) (fun _ _ _ _ => true) ≤
      Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  unfold V4
  simp only [Hf, if_true]
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  set G : Cfg N → ℝ := fun ω => ∏ t0, ∏ t1, ∏ t2, ∏ t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) with hG
  have hG0 : ∀ ω, 0 ≤ G ω := fun ω => prod_nonneg fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _
  have hG1 : ∀ ω, G ω ≤ 1 := fun ω => prod_le_one (fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => big_nonneg N μ ν y _) (fun _ _ => big_le_one N μ ν y _))))
  have hpt : ∀ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ≤ Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))) := by
    intro ω
    have hw0 : 0 ≤ wilsonWeight N β ω := by unfold wilsonWeight; positivity
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal _ hw0]
    by_cases hz : G ω = 0
    · rw [hz, mul_zero]; exact (Real.exp_pos _).le
    · have hall : ∀ t0 t1 t2 t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) ≠ 0 := by
        intro t0 t1 t2 t3
        have h1 := (prod_ne_zero_iff.mp hz) t0 (mem_univ _)
        have h2 := (prod_ne_zero_iff.mp h1) t1 (mem_univ _)
        have h3 := (prod_ne_zero_iff.mp h2) t2 (mem_univ _)
        exact (prod_ne_zero_iff.mp h3) t3 (mem_univ _)
      have ha := action_le_quarter N m hN μ ν hμν y ω hall
      have hw : wilsonWeight N β ω ≤ Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))) := by
        unfold wilsonWeight; apply Real.exp_le_exp.mpr; exact mul_le_mul_of_nonneg_left ha hβ
      calc wilsonWeight N β ω * G ω ≤ wilsonWeight N β ω * 1 :=
            mul_le_mul_of_nonneg_left (hG1 ω) hw0
        _ ≤ _ := by rw [mul_one]; exact hw
  have hint : Integrable (fun _ : Cfg N => Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))))
      (Measure.pi fun _ : Lk N => haarBall) := integrable_const _
  have hnn : 0 ≤ᵐ[Measure.pi fun _ : Lk N => haarBall]
      (fun ω => Real.toNNReal (wilsonWeight N β ω) • G ω) :=
    Filter.Eventually.of_forall fun ω => by
      show (0 : ℝ) ≤ Real.toNNReal (wilsonWeight N β ω) • G ω
      rw [NNReal.smul_def, smul_eq_mul]; exact mul_nonneg (by positivity) (hG0 ω)
  calc ∫ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ∂(Measure.pi fun _ : Lk N => haarBall)
      ≤ ∫ _ω, Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))) ∂(Measure.pi fun _ : Lk N => haarBall) :=
        integral_mono_of_nonneg hnn hint (Filter.Eventually.of_forall hpt)
    _ = Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2))) := by simp

/-- **The Peierls bound on (ℤ/2m)⁴ from the chessboard estimate (energy form, rate 1/4)**. -/
theorem peierls_four (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ)
    (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    |V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F| ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2)) / (N ^ 4 : ℕ)) else Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ))) := by
  have hN4 : ((N ^ 4 : ℕ) : ℝ) ≠ 0 := by exact_mod_cast pow_ne_zero 4 (NeZero.ne N)
  set A : ℝ := Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2)) / (N ^ 4 : ℕ)) with hA
  set B : ℝ := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hc : ∀ b : Bool, 0 ≤ (if b then A else B) := by
    intro b; cases b
    · exact Real.rpow_nonneg (Zw_nonneg N β) _
    · exact (Real.exp_pos _).le
  have hconst : ∀ b : Bool, V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) (fun _ _ _ _ => b) ≤
      (if b then A else B) ^ (N ^ 4) := by
    intro b; cases b
    · rw [V4_false]
      show Zw N β ≤ B ^ (N ^ 4)
      rw [hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β), one_div_mul_cancel hN4, Real.rpow_one]
    · show _ ≤ A ^ (N ^ 4)
      rw [hA, ← Real.exp_nat_mul, mul_div_cancel₀ _ hN4]
      exact V4_true_le4 N m hN β hβ μ ν hμν y
  exact wilson_chessboard_even_root N m hN β (Hf N μ ν y) (base_Hf N μ ν (ne_of_lt hμν) y)
    (fun b => if b then A else B) hc hconst F

/-- **Volume-uniform rarity, rate 1/4.** -/
theorem rarity_four (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ)
    (hh : 0 < haarBall.real (ballQ r)) (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F ≤
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * (48 * r ^ 2 - y / 4)) / haarBall.real (ballQ r) ^ 4 else 1) := by
  have hp := peierls_four N m hN β hβ μ ν hμν y F
  set h := haarBall.real (ballQ r) with hhdef
  set q := Real.exp (β * (48 * r ^ 2 - y / 4)) / h ^ 4 with hq
  set A := Real.exp (β * ((plaqs N).card - y * (N ^ 2 * m ^ 2)) / (N ^ 4 : ℕ)) with hA
  set B := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hNpos : (0 : ℝ) < ((N ^ 4 : ℕ) : ℝ) := by exact_mod_cast pow_pos (Nat.pos_of_ne_zero (NeZero.ne N)) 4
  have hNr : (N : ℝ) = 2 * m := by exact_mod_cast hN
  have hm0 : (0 : ℝ) < m := by
    have : 0 < N := Nat.pos_of_ne_zero (NeZero.ne N)
    have : 0 < m := by omega
    exact_mod_cast this
  -- the lower bound for B
  have hZ := Zw_ge N β hβ r
  rw [card_plaqs, card_lk] at hZ
  have hlow : Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 ≤ B := by
    have e : (Real.exp (β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2))) * h ^ (4 * N ^ 4)) ^
        ((1 : ℝ) / (N ^ 4 : ℕ)) = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 := by
      rw [Real.mul_rpow (Real.exp_pos _).le (pow_nonneg hh.le _), ← Real.exp_mul,
        ← Real.rpow_natCast h (4 * N ^ 4), ← Real.rpow_mul hh.le]
      have e1 : β * (((6 * N ^ 4 : ℕ) : ℝ) * (1 - 8 * r ^ 2)) * (1 / ((N ^ 4 : ℕ) : ℝ)) =
          β * (6 - 48 * r ^ 2) := by
        field_simp; push_cast; ring
      have e2 : (((4 * N ^ 4 : ℕ) : ℝ)) * (1 / ((N ^ 4 : ℕ) : ℝ)) = ((4 : ℕ) : ℝ) := by
        field_simp; push_cast; ring
      rw [e1, e2, Real.rpow_natCast]
    rw [← e, hB]
    exact Real.rpow_le_rpow (by positivity) hZ (by positivity)
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg hh.le _)
  have hB0 : 0 ≤ B := Real.rpow_nonneg (Zw_nonneg N β) _
  have hAeq : A = Real.exp (β * (6 - 48 * r ^ 2)) * h ^ 4 * q := by
    rw [hA, hq, card_plaqs]
    rw [mul_div_assoc', mul_comm (Real.exp _) (h ^ 4), mul_assoc, ← Real.exp_add,
      mul_div_assoc, mul_div_cancel_left₀ _ (pow_ne_zero 4 hh.ne')]
    congr 1
    have hN4 : ((N ^ 4 : ℕ) : ℝ) = 16 * (m : ℝ) ^ 4 := by push_cast; rw [hNr]; ring
    rw [hN4]
    field_simp
    push_cast
    rw [hNr]
    ring
  have hAB : A ≤ B * q := by rw [hAeq]; exact mul_le_mul_of_nonneg_right hlow hq0
  have hstep : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then A else B) ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) := by
    apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t0 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t1 _; apply prod_le_prod (fun _ _ => prod_nonneg fun _ _ => by
      split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t2 _; apply prod_le_prod (fun _ _ => by split_ifs; exact (Real.exp_pos _).le; exact hB0)
    intro t3 _; split_ifs
    · exact hAB
    · rw [mul_one]
  have hsplit : ∏ t0, ∏ t1, ∏ t2, ∏ t3, (B * (if F t0 t1 t2 t3 then q else 1)) =
      Zw N β * ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then q else 1) := by
    simp only [prod_mul_distrib, prod_const, card_univ, ZMod.card]
    congr 1
    rw [← pow_mul, ← pow_mul, ← pow_mul, hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β)]
    have : (1 : ℝ) / ((N ^ 4 : ℕ) : ℝ) * ((N * (N * (N * N)) : ℕ) : ℝ) = 1 := by
      field_simp; push_cast; ring
    rw [this, Real.rpow_one]
  calc V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F ≤ |V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F| :=
        le_abs_self _
    _ ≤ _ := hp
    _ ≤ _ := hstep
    _ = _ := hsplit


end FoldQuarter

#print axioms FoldQuarter.re_hol_Ψ
#print axioms FoldQuarter.card_E4
#print axioms FoldQuarter.V4_true_le4
#print axioms FoldQuarter.peierls_four
#print axioms FoldQuarter.rarity_four
