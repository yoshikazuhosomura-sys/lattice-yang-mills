import FoldChess.RarityPlaqV1
/-!
**Volume-uniform rarity for every set of plaquettes** on (ℤ/2m)⁴, every m ≥ 1:
  ∫ ∏_{p ∈ X} 1[y < 1 − Re U_p] dμ_W ≤ Z · q^{⌊|X|/96⌋},   q = e^{β(48 r² − y/16)} / h(r)⁴ ≤ 1,
for every finite set X of (unoriented) plaquettes.  Proof: the 96 classes (parity of the base point × orientation)
— some class X_c has at least ⌊|X|/96⌋ plaquettes (pigeonhole); dropping the other factors only increases the
integrand; a translation by the parity vector (invariance of the Wilson measure) moves X_c to the even sublattice,
where `rarity_plaq` applies.

Paper correspondence: one-scale rarity (Proposition P) for an arbitrary set X, rate 1/(16·96) per plaquette in the
exponent of e^{−βy}; constants uniform in the volume.
-/

namespace FoldEntropy

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson FoldPeierls Finset

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the indicator that the plaquette p is large -/
noncomputable def bigP (y : ℝ) (ω : Cfg N) (p : Lk N × Fin 4) : ℝ := if y < 1 - (hol N ω p).re then 1 else 0

theorem bigP_nonneg (y : ℝ) (ω : Cfg N) (p : Lk N × Fin 4) : 0 ≤ bigP N y ω p := by
  unfold bigP; split_ifs <;> norm_num

theorem bigP_le_one (y : ℝ) (ω : Cfg N) (p : Lk N × Fin 4) : bigP N y ω p ≤ 1 := by
  unfold bigP; split_ifs <;> norm_num

theorem measurable_bigP (y : ℝ) (p : Lk N × Fin 4) : Measurable (fun ω : Cfg N => bigP N y ω p) :=
  Measurable.ite (measurableSet_lt measurable_const
    (measurable_const.sub (Quaternion.continuous_re.comp (continuous_hol N _)).measurable))
    measurable_const measurable_const

def toZ4 (x : Site N) : Z4 N := (x 0, x 1, x 2, x 3)

omit [NeZero N] in
theorem vec_toZ4 (x : Site N) : vec N (x 0) (x 1) (x 2) (x 3) = x := by
  funext j; fin_cases j <;> simp [vec]

/-- rarity for a set of sites of the even sublattice -/
theorem rarity_sites (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y r : ℝ) (hr : 0 < r)
    (S : Finset (Site N)) (hS : ∀ x ∈ S, ∀ j, par N (x j) = false) :
    ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4) ^ S.card := by
  have hinj : Set.InjOn (toZ4 N) S := by
    intro x _ x' _ h
    rw [← vec_toZ4 N x, ← vec_toZ4 N x']
    simp only [toZ4, Prod.mk.injEq] at h
    rw [h.1, h.2.1, h.2.2.1, h.2.2.2]
  have hX : S.image (toZ4 N) ⊆ evens N ×ˢ (evens N ×ˢ (evens N ×ˢ evens N)) := by
    intro w hw
    obtain ⟨x, hx, rfl⟩ := mem_image.mp hw
    simp only [toZ4, mem_product, evens, mem_filter, mem_univ, true_and]
    exact ⟨hS x hx 0, hS x hx 1, hS x hx 2, hS x hx 3⟩
  have h := rarity_plaq N m hN β hβ μ ν hμν y r hr (S.image (toZ4 N)) hX
  rw [card_image_of_injOn hinj] at h
  have e : ∫ ω, ∏ w ∈ S.image (toZ4 N),
      (if y < 1 - (hol N ω ((vec N w.1 w.2.1 w.2.2.1 w.2.2.2, μ), ν)).re then (1 : ℝ) else 0)
        ∂(wilsonMeasure N β) = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := by
    congr 1; funext ω
    rw [prod_image hinj]
    apply prod_congr rfl; intro x _
    simp only [toZ4, vec_toZ4, bigP]
  rw [← e]; exact h

theorem par_sub_one (hN : N = 2 * m) (t : ZMod N) : par N (t - 1) = !(par N t) := by
  have := par_add_one N m hN (t - 1)
  rw [sub_add_cancel] at this
  rw [this, Bool.not_not]

/-- **Volume-uniform rarity for every finite set of plaquettes.** -/
theorem rarity_all (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (y r : ℝ) (hr : 0 < r)
    (hq1 : Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4 ≤ 1)
    (X : Finset (Lk N × Fin 4)) (hX : X ⊆ plaqs N) :
    ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      Zw N β * (Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 96) := by
  set q := Real.exp (β * (48 * r ^ 2 - y / 16)) / haarBall.real (ballQ r) ^ 4 with hqdef
  have hq0 : 0 ≤ q := div_nonneg (Real.exp_pos _).le (pow_nonneg (ballQ_pos r hr).le _)
  -- the classes
  let cls : Lk N × Fin 4 → (Fin 4 → Bool) × (Fin 4 × Fin 4) := fun p => (fun j => par N (p.1.1 j), (p.1.2, p.2))
  let T : Finset ((Fin 4 → Bool) × (Fin 4 × Fin 4)) := univ ×ˢ univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2)
  have hT : T.card = 96 := by
    have h6 : (univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2)).card = 6 := by decide
    simp only [T, card_product, card_univ, h6, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]
    norm_num
  have hmaps : ∀ p ∈ X, cls p ∈ T := by
    intro p hp
    have := hX hp
    simp only [plaqs, mem_filter, mem_univ, true_and] at this
    simp only [T, cls, mem_product, mem_univ, mem_filter, true_and]; exact this
  have hTne : T.Nonempty := ⟨(fun _ => false, (0, 1)), by simp [T]⟩
  obtain ⟨c, hcT, hc⟩ := Finset.exists_le_card_fiber_of_mul_le_card_of_maps_to hmaps hTne
    (by rw [hT]; exact Nat.mul_div_le X.card 96)
  set Xc := X.filter (fun p => cls p = c) with hXc
  obtain ⟨π, μ, ν⟩ := c
  have hμν : μ < ν := by simp only [T, mem_product, mem_univ, mem_filter, true_and] at hcT; exact hcT
  -- monotonicity
  have hmono : ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
      ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) := by
    have hbd : ∀ (s : Finset (Lk N × Fin 4)), Integrable (fun ω => ∏ p ∈ s, bigP N y ω p) (wilsonMeasure N β) := by
      intro s
      refine Integrable.of_bound (Finset.measurable_prod s (fun p _ => measurable_bigP N y p)).aestronglyMeasurable 1
        (Filter.Eventually.of_forall fun ω => ?_)
      rw [Real.norm_eq_abs, abs_of_nonneg (prod_nonneg fun p _ => bigP_nonneg N y ω p)]
      exact prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
    refine integral_mono (hbd X) (hbd Xc) (fun ω => ?_)
    show ∏ p ∈ X, bigP N y ω p ≤ ∏ p ∈ Xc, bigP N y ω p
    rw [← prod_filter_mul_prod_filter_not X (fun p => cls p = (π, μ, ν))]
    have h1 : ∏ p ∈ X.filter (fun p => ¬ cls p = (π, μ, ν)), bigP N y ω p ≤ 1 :=
      prod_le_one (fun p _ => bigP_nonneg N y ω p) (fun p _ => bigP_le_one N y ω p)
    have h0 : 0 ≤ ∏ p ∈ Xc, bigP N y ω p := prod_nonneg fun p _ => bigP_nonneg N y ω p
    calc (∏ p ∈ Xc, bigP N y ω p) * ∏ p ∈ X.filter (fun p => ¬ cls p = (π, μ, ν)), bigP N y ω p
        ≤ (∏ p ∈ Xc, bigP N y ω p) * 1 := mul_le_mul_of_nonneg_left h1 h0
      _ = _ := mul_one _
  -- translation to the even sublattice
  set v : Site N := fun j => if π j then (1 : ZMod N) else 0 with hv
  set S : Finset (Site N) := Xc.image (fun p => p.1.1 - v) with hSdef
  have hmem : ∀ p ∈ Xc, p = ((p.1.1, μ), ν) ∧ ∀ j, par N (p.1.1 j) = π j := by
    intro p hp
    simp only [hXc, mem_filter, cls, Prod.mk.injEq] at hp
    obtain ⟨_, hπ, hμ, hν⟩ := hp
    refine ⟨?_, fun j => congrFun hπ j⟩
    rw [← hμ, ← hν]
  have hinj : Set.InjOn (fun p : Lk N × Fin 4 => p.1.1 - v) Xc := by
    intro p hp p' hp' h
    simp only at h
    have e : p.1.1 = p'.1.1 := sub_left_injective h
    rw [(hmem p hp).1, (hmem p' hp').1, e]
  have hS : ∀ x ∈ S, ∀ j, par N (x j) = false := by
    intro x hx j
    obtain ⟨p, hp, rfl⟩ := mem_image.mp hx
    have hpj := (hmem p hp).2 j
    simp only [Pi.sub_apply, hv]
    cases hπj : π j
    · simp only [hπj, Bool.false_eq_true, if_false, sub_zero]; rw [hpj, hπj]
    · simp only [hπj, if_true]; rw [par_sub_one N m hN, hpj, hπj]; rfl
  have hshift : ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) =
      ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := by
    have hm : Measurable (fun ω : Cfg N => ∏ x ∈ S, bigP N y ω ((x, μ), ν)) :=
      Finset.measurable_prod S (fun x _ => measurable_bigP N y _)
    rw [← wilson_shV_invariant N v β _ hm]
    congr 1; funext ω
    rw [hSdef, prod_image hinj]
    apply prod_congr rfl
    intro p hp
    rw [congrArg (bigP N y ω) (hmem p hp).1]
    simp only [bigP, hol_shV, sub_add_cancel]
  have hcard : X.card / 96 ≤ S.card := by
    rw [hSdef, card_image_of_injOn hinj]; exact hc
  have hrs := rarity_sites N m hN β hβ μ ν hμν y r hr S hS
  calc ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β)
      ≤ ∫ ω, ∏ p ∈ Xc, bigP N y ω p ∂(wilsonMeasure N β) := hmono
    _ = ∫ ω, ∏ x ∈ S, bigP N y ω ((x, μ), ν) ∂(wilsonMeasure N β) := hshift
    _ ≤ Zw N β * q ^ S.card := hrs
    _ ≤ Zw N β * q ^ (X.card / 96) :=
        mul_le_mul_of_nonneg_left (pow_le_pow_of_le_one hq0 hq1 hcard) (Zw_nonneg N β)

end FoldEntropy

#print axioms FoldEntropy.rarity_sites
#print axioms FoldEntropy.rarity_all
