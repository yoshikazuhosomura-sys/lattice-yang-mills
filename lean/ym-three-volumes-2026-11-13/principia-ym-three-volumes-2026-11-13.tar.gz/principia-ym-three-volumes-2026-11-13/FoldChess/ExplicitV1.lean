import FoldChess.CapV1
/-!
**A fully explicit volume-uniform rarity (threshold y = 1).**  With r = 1/20 the cap volume satisfies
h(1/20) ≥ 1/83⁴ (`FoldCap.ballQ_ge` with K = 41), hence for every β ≥ 81
  q₁ = e^{β(48/400 − 1)} / h(1/20)⁴ ≤ e^{−0.88 β} · 83¹⁶ < 1,
and for every m ≥ 2 and every finite set X of plaquettes of (ℤ/2m)⁴
  μ_W(1 − Re U_p > 1 for all p ∈ X) ≤ Z · q₁^{⌊|X|/6⌋}.

Paper correspondence: one-scale rarity (Proposition P) with an explicit threshold β ≥ 81 at y = 1.
-/

namespace FoldCap

open MeasureTheory TorusRP FoldChess FoldWilson FoldPeierls FoldEntropy FoldMix Finset

theorem h_ge : 1 / ((83 : ℝ) ^ 4) ≤ haarBall.real (ballQ (1 / 20)) := by
  have h := ballQ_ge 41 (by norm_num) (1 / 20) (by norm_num)
  norm_num at h ⊢
  exact h

theorem q_lt_one_explicit (β : ℝ) (hβ : 81 ≤ β) :
    Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) / haarBall.real (ballQ (1 / 20)) ^ 4 < 1 := by
  set h := haarBall.real (ballQ (1 / 20))
  have hh : 1 / ((83 : ℝ) ^ 4) ≤ h := h_ge
  have hpos : 0 < h := lt_of_lt_of_le (by norm_num) hh
  have h4 : 1 / ((83 : ℝ) ^ 16) ≤ h ^ 4 := by
    calc 1 / ((83 : ℝ) ^ 16) = (1 / ((83 : ℝ) ^ 4)) ^ 4 := by norm_num
      _ ≤ h ^ 4 := pow_le_pow_left₀ (by norm_num) hh 4
  have he : (2.718 : ℝ) < Real.exp 1 := lt_trans (by norm_num) Real.exp_one_gt_d9
  have h71 : (2.718 : ℝ) ^ 71 < Real.exp 71 := by
    rw [show (71 : ℝ) = ((71 : ℕ) : ℝ) * 1 by norm_num, Real.exp_nat_mul]
    exact pow_lt_pow_left₀ he (by norm_num) (by norm_num)
  have hnum : (83 : ℝ) ^ 16 < (2.718 : ℝ) ^ 71 := by norm_num
  have hexp : Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) ≤ Real.exp (-71) := by
    apply Real.exp_le_exp.mpr; nlinarith
  have hE : Real.exp (-71) * (83 : ℝ) ^ 16 < 1 := by
    rw [Real.exp_neg, inv_mul_lt_iff₀ (Real.exp_pos _), mul_one]; linarith
  rw [div_lt_one (pow_pos hpos 4)]
  have : Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) < 1 / ((83 : ℝ) ^ 16) := by
    rw [lt_div_iff₀ (by norm_num)]
    calc Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) * (83 : ℝ) ^ 16 ≤ Real.exp (-71) * (83 : ℝ) ^ 16 :=
          mul_le_mul_of_nonneg_right hexp (by norm_num)
      _ < 1 := hE
  linarith

/-- **Volume-uniform rarity with an explicit threshold** (y = 1, β ≥ 81, every m ≥ 2, every finite X). -/
theorem rarity_explicit (β : ℝ) (hβ : 81 ≤ β) :
    Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) / haarBall.real (ballQ (1 / 20)) ^ 4 < 1 ∧
      ∀ (N : ℕ) [NeZero N] (m : ℕ), N = 2 * m → 2 ≤ m → ∀ X : Finset (Lk N × Fin 4), X ⊆ plaqs N →
        ∫ ω, ∏ p ∈ X, bigP N 1 ω p ∂(wilsonMeasure N β) ≤
          Zw N β * (Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) / haarBall.real (ballQ (1 / 20)) ^ 4) ^ (X.card / 6) := by
  have hq := q_lt_one_explicit β hβ
  refine ⟨hq, fun N _ m hN hM X hX => ?_⟩
  exact rarity_all_mix N m hN hM β (by linarith) 1 (1 / 20) (by norm_num) hq.le X hX

end FoldCap

#print axioms FoldCap.h_ge
#print axioms FoldCap.q_lt_one_explicit
#print axioms FoldCap.rarity_explicit
