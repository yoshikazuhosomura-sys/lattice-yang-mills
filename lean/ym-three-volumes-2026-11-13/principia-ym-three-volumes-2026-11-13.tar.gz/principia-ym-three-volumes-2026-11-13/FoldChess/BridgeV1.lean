import FoldChess.FourDimV1
/-!
From reflection positivity to the fold inequalities (abstract, every even side n = 2m).

A block of the torus is w = (t0, t1, t2, t3) ∈ (ZMod n)⁴; Ψ w transports the block at the origin to the block w;
the block functions are Hf i (i ∈ I).  The value of a family F is
  V(F) = ∫ ∏_w Hf (F w) (Ψ w ω) dμ.
`Data4` lists what a concrete measure has to provide, for each direction k and plane a: a reflection R k a, a class
Good k a of functions (the closed plus half) closed under products, Cauchy–Schwarz and positivity of the reflected
pairing on Good k a, the transport rule Ψ(ρ_a w) = Ψ w ∘ R k a in the k-th coordinate, and the locality of the
transported block functions (blocks with w_k in the plus half of a are in Good k a).  Then every fold inequality of
the four-dimensional chessboard estimate holds, and
  |V(F)|^(n⁴) ≤ ∏_w V(the constant family F w).

Paper correspondence: one-scale rarity; the chessboard estimate on (ℤ/2h)⁴ from reflection positivity.
-/

namespace FoldChess

open Finset MeasureTheory

section Bridge

variable {n : ℕ} [NeZero n] (m : ℕ) {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) {I K : Type*} [Fintype K]

theorem good_prod {Good : (Ω → ℝ) → Prop} (one : Good fun _ => 1)
    (mul : ∀ f g, Good f → Good g → Good fun ω => f ω * g ω) {ι : Type*} (S : Finset ι) (f : ι → Ω → ℝ)
    (h : ∀ i ∈ S, Good (f i)) : Good (fun ω => ∏ i ∈ S, f i ω) := by
  classical
  induction S using Finset.induction_on with
  | empty => simpa using one
  | insert x S hx ih =>
    have := mul (f x) (fun ω => ∏ i ∈ S, f i ω) (h x (mem_insert_self x S))
      (ih (fun i hi => h i (mem_insert_of_mem hi)))
    simpa [prod_insert hx] using this

omit [MeasurableSpace Ω] in
theorem split_rho (hn : n = 2 * m) (a : ZMod n) (Y : ZMod n → Ω → ℝ) (ω : Ω) :
    ∏ t, Y t ω = (∏ t ∈ univ.filter (fun t => inH m a t), Y t ω) *
      ∏ t ∈ univ.filter (fun t => inH m a t), Y (rho a t) ω := by
  rw [← prod_filter_mul_prod_filter_not univ (fun t => inH m a t)]
  congr 1
  have := prod_rho m hn a (fun t => Y (rho a t) ω)
  simp only [rho_rho] at this
  exact this

/-- the value of a family with one distinguished direction -/
noncomputable def W (Hf : I → Ω → ℝ) (Ψ : ZMod n → K → Ω → Ω) (F : ZMod n → K → I) : ℝ :=
  ∫ ω, ∏ t, ∏ s, Hf (F t s) (Ψ t s ω) ∂μ

/-- **One fold inequality from Cauchy–Schwarz.** -/
theorem fold_bridge (hn : n = 2 * m) (Hf : I → Ω → ℝ) (Ψ : ZMod n → K → Ω → Ω) (R : Ω → Ω)
    (Good : (Ω → ℝ) → Prop) (one : Good fun _ => 1) (mul : ∀ f g, Good f → Good g → Good fun ω => f ω * g ω)
    (a : ZMod n) (loc : ∀ t, inH m a t → ∀ s i, Good (fun ω => Hf i (Ψ t s ω)))
    (tr : ∀ t s ω, Ψ (rho a t) s ω = Ψ t s (R ω))
    (cs : ∀ f g, Good f → Good g →
      (∫ ω, f (R ω) * g ω ∂μ) ^ 2 ≤ (∫ ω, f (R ω) * f ω ∂μ) * (∫ ω, g (R ω) * g ω ∂μ))
    (F : ZMod n → K → I) :
    W μ Hf Ψ F ^ 2 ≤ W μ Hf Ψ (foldP m a F) * W μ Hf Ψ (foldM m a F) := by
  have gA : Good (fun ω => ∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F t s) (Ψ t s ω)) :=
    good_prod one mul _ _ (fun t ht => good_prod one mul univ _
      (fun s _ => loc t (mem_filter.mp ht).2 s _))
  have gB : Good (fun ω => ∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F (rho a t) s) (Ψ t s ω)) :=
    good_prod one mul _ _ (fun t ht => good_prod one mul univ _
      (fun s _ => loc t (mem_filter.mp ht).2 s _))
  have e0 : W μ Hf Ψ F = ∫ ω, (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F (rho a t) s) (Ψ t s (R ω))) *
      (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F t s) (Ψ t s ω)) ∂μ := by
    unfold W; congr 1; funext ω
    rw [split_rho m hn a (fun t ω => ∏ s, Hf (F t s) (Ψ t s ω)) ω, mul_comm]
    congr 1
    apply prod_congr rfl; intro t _; apply prod_congr rfl; intro s _; rw [tr]
  have eP : W μ Hf Ψ (foldP m a F) =
      ∫ ω, (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F t s) (Ψ t s (R ω))) *
      (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F t s) (Ψ t s ω)) ∂μ := by
    unfold W; congr 1; funext ω
    rw [split_rho m hn a (fun t ω => ∏ s, Hf (foldP m a F t s) (Ψ t s ω)) ω, mul_comm]
    congr 1
    · apply prod_congr rfl; intro t ht
      have ht' := (mem_filter.mp ht).2
      have hr : ¬ inH m a (rho a t) := fun h => ((inH_rho m hn a t).1 h) ht'
      apply prod_congr rfl; intro s _
      simp only [foldP, hr, if_false, rho_rho, tr]
    · apply prod_congr rfl; intro t ht
      have ht' := (mem_filter.mp ht).2
      apply prod_congr rfl; intro s _
      simp only [foldP, ht', if_true]
  have eM : W μ Hf Ψ (foldM m a F) =
      ∫ ω, (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F (rho a t) s) (Ψ t s (R ω))) *
      (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (F (rho a t) s) (Ψ t s ω)) ∂μ := by
    unfold W; congr 1; funext ω
    rw [split_rho m hn a (fun t ω => ∏ s, Hf (foldM m a F t s) (Ψ t s ω)) ω, mul_comm]
    congr 1
    · apply prod_congr rfl; intro t ht
      have ht' := (mem_filter.mp ht).2
      have hr : ¬ inH m a (rho a t) := fun h => ((inH_rho m hn a t).1 h) ht'
      apply prod_congr rfl; intro s _
      simp only [foldM, hr, if_false, tr]
    · apply prod_congr rfl; intro t ht
      have ht' := (mem_filter.mp ht).2
      apply prod_congr rfl; intro s _
      simp only [foldM, ht', if_true]
  rw [e0, eP, eM, mul_comm (∫ ω, _ ∂μ)]
  exact cs _ _ gB gA

/-- **Positivity of a family fixed by a fold.** -/
theorem fold_pos (hn : n = 2 * m) (Hf : I → Ω → ℝ) (Ψ : ZMod n → K → Ω → Ω) (R : Ω → Ω)
    (Good : (Ω → ℝ) → Prop) (one : Good fun _ => 1) (mul : ∀ f g, Good f → Good g → Good fun ω => f ω * g ω)
    (a : ZMod n) (loc : ∀ t, inH m a t → ∀ s i, Good (fun ω => Hf i (Ψ t s ω)))
    (tr : ∀ t s ω, Ψ (rho a t) s ω = Ψ t s (R ω))
    (rp : ∀ f, Good f → 0 ≤ ∫ ω, f (R ω) * f ω ∂μ)
    (G : K → I) : 0 ≤ W μ Hf Ψ (fun _ => G) := by
  have gA : Good (fun ω => ∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (G s) (Ψ t s ω)) :=
    good_prod one mul _ _ (fun t ht => good_prod one mul univ _
      (fun s _ => loc t (mem_filter.mp ht).2 s _))
  have e : W μ Hf Ψ (fun _ => G) =
      ∫ ω, (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (G s) (Ψ t s (R ω))) *
      (∏ t ∈ univ.filter (fun t => inH m a t), ∏ s, Hf (G s) (Ψ t s ω)) ∂μ := by
    unfold W; congr 1; funext ω
    rw [split_rho m hn a (fun t ω => ∏ s, Hf (G s) (Ψ t s ω)) ω, mul_comm]
    congr 1
    apply prod_congr rfl; intro t _; apply prod_congr rfl; intro s _; rw [tr]
  rw [e]; exact rp _ gA

end Bridge

section Four

variable {n : ℕ} [NeZero n] (m : ℕ) {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω) {I : Type*}

abbrev Z4 (n : ℕ) := ZMod n × ZMod n × ZMod n × ZMod n

/-- the value of a family on the four-dimensional block torus -/
noncomputable def V4 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) : ℝ :=
  ∫ ω, ∏ t0, ∏ t1, ∏ t2, ∏ t3, Hf (F t0 t1 t2 t3) (Ψ t0 t1 t2 t3 ω) ∂μ

/-- what a concrete measure has to provide -/
structure Data4 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (R : Fin 4 → ZMod n → Ω → Ω) (Good : Fin 4 → ZMod n → (Ω → ℝ) → Prop) : Prop where
  one : ∀ k a, Good k a fun _ => 1
  mul : ∀ k a f g, Good k a f → Good k a g → Good k a fun ω => f ω * g ω
  cs : ∀ k a f g, Good k a f → Good k a g →
    (∫ ω, f (R k a ω) * g ω ∂μ) ^ 2 ≤ (∫ ω, f (R k a ω) * f ω ∂μ) * (∫ ω, g (R k a ω) * g ω ∂μ)
  rp : ∀ k a f, Good k a f → 0 ≤ ∫ ω, f (R k a ω) * f ω ∂μ
  tr0 : ∀ a t0 t1 t2 t3 ω, Ψ (rho a t0) t1 t2 t3 ω = Ψ t0 t1 t2 t3 (R 0 a ω)
  tr1 : ∀ a t0 t1 t2 t3 ω, Ψ t0 (rho a t1) t2 t3 ω = Ψ t0 t1 t2 t3 (R 1 a ω)
  tr2 : ∀ a t0 t1 t2 t3 ω, Ψ t0 t1 (rho a t2) t3 ω = Ψ t0 t1 t2 t3 (R 2 a ω)
  tr3 : ∀ a t0 t1 t2 t3 ω, Ψ t0 t1 t2 (rho a t3) ω = Ψ t0 t1 t2 t3 (R 3 a ω)
  loc0 : ∀ a t0 t1 t2 t3 i, inH m a t0 → Good 0 a fun ω => Hf i (Ψ t0 t1 t2 t3 ω)
  loc1 : ∀ a t0 t1 t2 t3 i, inH m a t1 → Good 1 a fun ω => Hf i (Ψ t0 t1 t2 t3 ω)
  loc2 : ∀ a t0 t1 t2 t3 i, inH m a t2 → Good 2 a fun ω => Hf i (Ψ t0 t1 t2 t3 ω)
  loc3 : ∀ a t0 t1 t2 t3 i, inH m a t3 → Good 3 a fun ω => Hf i (Ψ t0 t1 t2 t3 ω)

theorem prod4 {M : Type*} [CommMonoid M] (X : ZMod n → ZMod n → ZMod n → ZMod n → M) :
    ∏ t0, ∏ t1, ∏ t2, ∏ t3, X t0 t1 t2 t3 = ∏ q : Z4 n, X q.1 q.2.1 q.2.2.1 q.2.2.2 := by
  simp only [Fintype.prod_prod_type]

theorem prod13 {M : Type*} [CommMonoid M] (Y : ZMod n → ZMod n × ZMod n × ZMod n → M) :
    ∏ t, ∏ s, Y t s = ∏ q : Z4 n, Y q.1 (q.2.1, q.2.2.1, q.2.2.2) := by
  simp only [Fintype.prod_prod_type]

/-- direction 0 in the one-direction form -/
theorem V4_eq0 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    V4 μ Hf Ψ F = W μ Hf (fun t (s : ZMod n × ZMod n × ZMod n) => Ψ t s.1 s.2.1 s.2.2)
      (fun t (s : ZMod n × ZMod n × ZMod n) => F t s.1 s.2.1 s.2.2) := by
  unfold V4 W; congr 1; funext ω; rw [prod4, prod13]

theorem V4_eq1 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    V4 μ Hf Ψ F = W μ Hf (fun t (s : ZMod n × ZMod n × ZMod n) => Ψ s.1 t s.2.1 s.2.2)
      (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 t s.2.1 s.2.2) := by
  unfold V4 W; congr 1; funext ω; rw [prod4, prod13]
  exact Fintype.prod_equiv
    ⟨fun q => (q.2.1, q.1, q.2.2.1, q.2.2.2), fun q => (q.2.1, q.1, q.2.2.1, q.2.2.2),
      fun _ => rfl, fun _ => rfl⟩ _ _ (fun _ => rfl)

theorem V4_eq2 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    V4 μ Hf Ψ F = W μ Hf (fun t (s : ZMod n × ZMod n × ZMod n) => Ψ s.1 s.2.1 t s.2.2)
      (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 s.2.1 t s.2.2) := by
  unfold V4 W; congr 1; funext ω; rw [prod4, prod13]
  exact Fintype.prod_equiv
    ⟨fun q => (q.2.2.1, q.1, q.2.1, q.2.2.2), fun q => (q.2.1, q.2.2.1, q.1, q.2.2.2),
      fun _ => rfl, fun _ => rfl⟩ _ _ (fun _ => rfl)

theorem V4_eq3 (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    V4 μ Hf Ψ F = W μ Hf (fun t (s : ZMod n × ZMod n × ZMod n) => Ψ s.1 s.2.1 s.2.2 t)
      (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 s.2.1 s.2.2 t) := by
  unfold V4 W; congr 1; funext ω; rw [prod4, prod13]
  exact Fintype.prod_equiv
    ⟨fun q => (q.2.2.2, q.1, q.2.1, q.2.2.1), fun q => (q.2.1, q.2.2.1, q.2.2.2, q.1),
      fun _ => rfl, fun _ => rfl⟩ _ _ (fun _ => rfl)

theorem W_ext {K : Type*} [Fintype K] (Hf : I → Ω → ℝ) (Ψ : ZMod n → K → Ω → Ω) (F G : ZMod n → K → I)
    (h : ∀ t s, F t s = G t s) : W μ Hf Ψ F = W μ Hf Ψ G := by
  unfold W; congr 1; funext ω; apply prod_congr rfl; intro t _; apply prod_congr rfl; intro s _; rw [h]

/-- **The chessboard estimate from the concrete data**, every even side `n = 2m`. -/
theorem chess_data (hn : n = 2 * m) (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (R : Fin 4 → ZMod n → Ω → Ω) (Good : Fin 4 → ZMod n → (Ω → ℝ) → Prop)
    (hD : Data4 m μ Hf Ψ R Good) (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    |V4 μ Hf Ψ F| ^ (n ^ 4) ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, V4 μ Hf Ψ (fun _ _ _ _ => F t0 t1 t2 t3) := by
  apply chess_four m hn (V4 μ Hf Ψ)
  · intro a F
    have h := fold_bridge m μ hn Hf _ (R 0 a) (Good 0 a) (hD.one 0 a) (hD.mul 0 a) a
      (fun t ht s i => hD.loc0 a t s.1 s.2.1 s.2.2 i ht) (fun t s ω => hD.tr0 a t s.1 s.2.1 s.2.2 ω)
      (hD.cs 0 a) (fun t (s : ZMod n × ZMod n × ZMod n) => F t s.1 s.2.1 s.2.2)
    calc V4 μ Hf Ψ F ^ 2 = _ := by rw [V4_eq0]
      _ ≤ _ := h
      _ = V4 μ Hf Ψ (foldP m a F) * V4 μ Hf Ψ (foldM m a F) := by
        rw [V4_eq0, V4_eq0]
        congr 1 <;> apply W_ext <;> intro t s <;> simp only [foldP, foldM] <;> split_ifs <;> rfl
  · intro a F
    have h := fold_bridge m μ hn Hf _ (R 1 a) (Good 1 a) (hD.one 1 a) (hD.mul 1 a) a
      (fun t ht s i => hD.loc1 a s.1 t s.2.1 s.2.2 i ht) (fun t s ω => hD.tr1 a s.1 t s.2.1 s.2.2 ω)
      (hD.cs 1 a) (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 t s.2.1 s.2.2)
    calc V4 μ Hf Ψ F ^ 2 = _ := by rw [V4_eq1]
      _ ≤ _ := h
      _ = V4 μ Hf Ψ (fun t0 => foldP m a (F t0)) * V4 μ Hf Ψ (fun t0 => foldM m a (F t0)) := by
        rw [V4_eq1, V4_eq1]
        congr 1 <;> apply W_ext <;> intro t s <;> simp only [foldP, foldM] <;> split_ifs <;> rfl
  · intro a F
    have h := fold_bridge m μ hn Hf _ (R 2 a) (Good 2 a) (hD.one 2 a) (hD.mul 2 a) a
      (fun t ht s i => hD.loc2 a s.1 s.2.1 t s.2.2 i ht) (fun t s ω => hD.tr2 a s.1 s.2.1 t s.2.2 ω)
      (hD.cs 2 a) (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 s.2.1 t s.2.2)
    calc V4 μ Hf Ψ F ^ 2 = _ := by rw [V4_eq2]
      _ ≤ _ := h
      _ = V4 μ Hf Ψ (fun t0 t1 => foldP m a (F t0 t1)) * V4 μ Hf Ψ (fun t0 t1 => foldM m a (F t0 t1)) := by
        rw [V4_eq2, V4_eq2]
        congr 1 <;> apply W_ext <;> intro t s <;> simp only [foldP, foldM] <;> split_ifs <;> rfl
  · intro a F
    have h := fold_bridge m μ hn Hf _ (R 3 a) (Good 3 a) (hD.one 3 a) (hD.mul 3 a) a
      (fun t ht s i => hD.loc3 a s.1 s.2.1 s.2.2 t i ht) (fun t s ω => hD.tr3 a s.1 s.2.1 s.2.2 t ω)
      (hD.cs 3 a) (fun t (s : ZMod n × ZMod n × ZMod n) => F s.1 s.2.1 s.2.2 t)
    calc V4 μ Hf Ψ F ^ 2 = _ := by rw [V4_eq3]
      _ ≤ _ := h
      _ = V4 μ Hf Ψ (fun t0 t1 t2 => foldP m a (F t0 t1 t2)) * V4 μ Hf Ψ (fun t0 t1 t2 => foldM m a (F t0 t1 t2)) := by
        rw [V4_eq3, V4_eq3]
        congr 1 <;> apply W_ext <;> intro t s <;> simp only [foldP, foldM] <;> split_ifs <;> rfl
  · intro G
    rw [V4_eq0]
    exact fold_pos m μ hn Hf _ (R 0 0) (Good 0 0) (hD.one 0 0) (hD.mul 0 0) 0
      (fun t ht s i => hD.loc0 0 t s.1 s.2.1 s.2.2 i ht) (fun t s ω => hD.tr0 0 t s.1 s.2.1 s.2.2 ω)
      (hD.rp 0 0) _

/-- **The root form from the concrete data**: per-block bounds give a product bound. -/
theorem chess_data_root (hn : n = 2 * m) (Hf : I → Ω → ℝ) (Ψ : ZMod n → ZMod n → ZMod n → ZMod n → Ω → Ω)
    (R : Fin 4 → ZMod n → Ω → Ω) (Good : Fin 4 → ZMod n → (Ω → ℝ) → Prop)
    (hD : Data4 m μ Hf Ψ R Good) (c : I → ℝ) (hc : ∀ i, 0 ≤ c i)
    (hconst : ∀ i, V4 μ Hf Ψ (fun _ _ _ _ => i) ≤ c i ^ (n ^ 4))
    (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    |V4 μ Hf Ψ F| ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3) := by
  have hmain := chess_data m μ hn Hf Ψ R Good hD F
  have hpos : ∀ G, 0 ≤ V4 μ Hf Ψ (fun _ => G) := by
    intro G; rw [V4_eq0]
    exact fold_pos m μ hn Hf _ (R 0 0) (Good 0 0) (hD.one 0 0) (hD.mul 0 0) 0
      (fun t ht s i => hD.loc0 0 t s.1 s.2.1 s.2.2 i ht) (fun t s ω => hD.tr0 0 t s.1 s.2.1 s.2.2 ω)
      (hD.rp 0 0) _
  have hP : 0 ≤ ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3) :=
    Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ =>
      Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ => hc _
  have hle : |V4 μ Hf Ψ F| ^ (n ^ 4) ≤ (∏ t0, ∏ t1, ∏ t2, ∏ t3, c (F t0 t1 t2 t3)) ^ (n ^ 4) := by
    refine le_trans hmain ?_
    simp only [← Finset.prod_pow]
    exact Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ => Finset.prod_nonneg fun _ _ =>
        Finset.prod_nonneg fun _ _ => hpos _)
      (fun t0 _ => Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ =>
        Finset.prod_nonneg fun _ _ => hpos _)
      (fun t1 _ => Finset.prod_le_prod (fun _ _ => Finset.prod_nonneg fun _ _ => hpos _)
      (fun t2 _ => Finset.prod_le_prod (fun _ _ => hpos _) (fun t3 _ => hconst _))))
  have hn4 : n ^ 4 ≠ 0 := pow_ne_zero _ (NeZero.ne n)
  exact (pow_le_pow_iff_left₀ (abs_nonneg _) hP hn4).mp hle

end Four

end FoldChess

#print axioms FoldChess.fold_bridge
#print axioms FoldChess.chess_data
#print axioms FoldChess.chess_data_root
