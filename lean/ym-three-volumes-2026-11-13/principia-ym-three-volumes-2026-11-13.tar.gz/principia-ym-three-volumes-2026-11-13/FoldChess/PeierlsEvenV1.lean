import FoldChess.WilsonChessV1
/-!
The Peierls bound from the chessboard estimate on (ℤ/2m)⁴, every m ≥ 1 (energy half).

Block function: big(ω) = 1[y < 1 − Re U_{p₀}(ω)], p₀ = (0; μν) the plaquette of the cube at the origin in the plane
(μ, ν), μ < ν; the value `false` is the constant 1.  The uniform family `true` puts big(Ψ_w ω) in every block; on its
support the plaquettes p₀ + w for the m⁴ blocks w with all coordinates even (where Ψ_w is the translation by w) are
all large, hence the Wilson weight is at most e^{β(#plaquettes − y m⁴)}.  With the chessboard estimate:
  |∫ ∏_w Hf (F w) (Ψ_w ω) dμ_W| ≤ ∏_w c(F w),  c(true) = e^{β(#P − y m⁴)/N⁴},  c(false) = Z^{1/N⁴},
for every family F of the N⁴ blocks (N = 2m), β ≥ 0.

Paper correspondence: one-scale rarity (Proposition P), the energy half, rate 1/16 (the even sublattice).
-/

namespace FoldPeierls

open MeasureTheory TorusRP LinkReflection FoldAffine FoldChess FoldWilson Finset

variable (N : ℕ) [NeZero N] (m : ℕ)

/-- the plaquette (0; μν) -/
def p0 (μ ν : Fin 4) : Lk N × Fin 4 := (((0 : Site N), μ), ν)

/-- the indicator that the plaquette (0; μν) is large -/
noncomputable def big (μ ν : Fin 4) (y : ℝ) (ω : Cfg N) : ℝ :=
  if y < 1 - (hol N ω (p0 N μ ν)).re then 1 else 0

/-- the two block functions -/
noncomputable def Hf (μ ν : Fin 4) (y : ℝ) : Bool → Cfg N → ℝ :=
  fun b => if b then big N μ ν y else fun _ => 1

theorem ev_val (μ j : Fin 4) : ev N μ j = 0 ∨ ev N μ j = 1 := by
  simp only [ev, Pi.single_apply]; split_ifs <;> simp

theorem base_big (μ ν : Fin 4) (hμν : μ ≠ ν) (y : ℝ) : Base N (big N μ ν y) := by
  refine ⟨?_, ⟨1, fun ω => ?_⟩, fun ω ω' h => ?_⟩
  · exact Measurable.ite (measurableSet_lt measurable_const
      (measurable_const.sub (Quaternion.continuous_re.comp (continuous_hol N _)).measurable))
      measurable_const measurable_const
  · unfold big; split_ifs <;> simp
  · have i1 : InCube N ((0 : Site N), μ) := ⟨rfl, fun j => Or.inl rfl⟩
    have i4 : InCube N ((0 : Site N), ν) := ⟨rfl, fun j => Or.inl rfl⟩
    have i2 : InCube N ((0 : Site N) + ev N μ, ν) := by
      refine ⟨?_, fun j => ?_⟩
      · simp [ev, Pi.single_apply, Ne.symm hμν]
      · simpa using ev_val N μ j
    have i3 : InCube N ((0 : Site N) + ev N ν, μ) := by
      refine ⟨?_, fun j => ?_⟩
      · simp [ev, Pi.single_apply, hμν]
      · simpa using ev_val N ν j
    have e : hol N ω (p0 N μ ν) = hol N ω' (p0 N μ ν) := by
      simp only [hol, holQ, Uq, p0]
      rw [h _ i1, h _ i2, h _ i3, h _ i4]
    unfold big; rw [e]

theorem base_Hf (μ ν : Fin 4) (hμν : μ ≠ ν) (y : ℝ) (b : Bool) : Base N (Hf N μ ν y b) := by
  cases b
  · exact ⟨measurable_const, ⟨1, fun _ => by simp [Hf]⟩, fun _ _ _ => rfl⟩
  · exact base_big N μ ν hμν y

/-! ### the even blocks -/

theorem par_add_one (hN : N = 2 * m) (t : ZMod N) : par N (t + 1) = !(par N t) := by
  have h2 : 2 ∣ N := ⟨m, by omega⟩
  have key : ∀ x : ZMod N, ((x.val : ℕ) : ZMod 2) = ZMod.castHom h2 (ZMod 2) x := fun x => by
    rw [ZMod.castHom_apply, ZMod.cast_eq_val]
  unfold par
  rw [key, key]
  simp only [map_add, map_one]
  generalize ZMod.castHom h2 (ZMod 2) t = q
  revert q; decide

/-- the even block coordinates -/
def evens : Finset (ZMod N) := univ.filter (fun t => par N t = false)

theorem card_evens (hN : N = 2 * m) : (evens N).card = m := by
  have hb : (univ.filter (fun t : ZMod N => par N t = false)).card =
      (univ.filter (fun t : ZMod N => ¬ par N t = false)).card := by
    apply Finset.card_bij (fun t _ => t + 1)
    · intro t ht
      simp only [mem_filter, mem_univ, true_and] at ht ⊢
      rw [par_add_one N m hN, ht]; decide
    · intro a _ b _ h; simpa using h
    · intro b hb
      refine ⟨b - 1, ?_, by ring⟩
      simp only [mem_filter, mem_univ, true_and] at hb ⊢
      have := par_add_one N m hN (b - 1)
      rw [sub_add_cancel] at this
      cases hp : par N (b - 1)
      · rfl
      · rw [hp] at this; exact absurd this hb
  have hsum := Finset.card_filter_add_card_filter_not (s := (univ : Finset (ZMod N)))
    (fun t => par N t = false)
  rw [card_univ, ZMod.card, ← hb] at hsum
  unfold evens; omega

theorem Φ_even (d : Fin 4) (t : ZMod N) (ht : par N t = false) (ω : Cfg N) :
    Φ N d t ω = shV N (Pi.single d t) ω := by
  unfold Φ; rw [ht]; simp only [Bool.false_eq_true, if_false]; rw [affC_false_eq]

theorem shV_shV (v w : Site N) (ω : Cfg N) : shV N v (shV N w ω) = shV N (v + w) ω := by
  funext ℓ; simp only [shV]; rw [add_assoc]

/-- the vector of a block -/
def vec (t0 t1 t2 t3 : ZMod N) : Site N :=
  Pi.single 0 t0 + (Pi.single 1 t1 + (Pi.single 2 t2 + Pi.single 3 t3))

theorem vec_inj {t0 t1 t2 t3 s0 s1 s2 s3 : ZMod N} (h : vec N t0 t1 t2 t3 = vec N s0 s1 s2 s3) :
    t0 = s0 ∧ t1 = s1 ∧ t2 = s2 ∧ t3 = s3 := by
  have h0 := congrFun h 0; have h1 := congrFun h 1; have h2 := congrFun h 2; have h3 := congrFun h 3
  simp [vec, Pi.single_apply] at h0 h1 h2 h3
  exact ⟨h0, h1, h2, h3⟩

theorem re_hol_Ψ_even (t0 t1 t2 t3 : ZMod N) (h0 : par N t0 = false) (h1 : par N t1 = false)
    (h2 : par N t2 = false) (h3 : par N t3 = false) (ω : Cfg N) (μ ν : Fin 4) :
    hol N (Ψ N t0 t1 t2 t3 ω) (p0 N μ ν) = hol N ω (((vec N t0 t1 t2 t3), μ), ν) := by
  unfold Ψ
  rw [Φ_even N 3 t3 h3, Φ_even N 2 t2 h2, Φ_even N 1 t1 h1, Φ_even N 0 t0 h0, shV_shV, shV_shV, shV_shV,
    hol_shV]
  simp [p0, vec, add_assoc]

/-! ### the energy half for the uniform family -/

theorem action_le_even (hN : N = 2 * m) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) (ω : Cfg N)
    (h : ∀ t0 t1 t2 t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) ≠ 0) :
    action N ω ≤ (plaqs N).card - y * m ^ 4 := by
  set E : Finset (ZMod N × ZMod N × ZMod N × ZMod N) := evens N ×ˢ (evens N ×ˢ (evens N ×ˢ evens N))
  have hE : E.card = m ^ 4 := by
    simp only [E, card_product, card_evens N m hN]; ring
  let pl : ZMod N × ZMod N × ZMod N × ZMod N → Lk N × Fin 4 :=
    fun q => ((vec N q.1 q.2.1 q.2.2.1 q.2.2.2, μ), ν)
  have hinj : Set.InjOn pl E := by
    intro q _ q' _ hq
    have := vec_inj N (congrArg (fun p : Lk N × Fin 4 => p.1.1) hq)
    obtain ⟨a, b, c, d⟩ := this
    exact Prod.ext a (Prod.ext b (Prod.ext c d))
  have hsub : E.image pl ⊆ plaqs N := by
    intro p hp
    obtain ⟨q, _, rfl⟩ := mem_image.mp hp
    simp only [plaqs, mem_filter, mem_univ, true_and, pl]; exact hμν
  have hbig : ∀ q ∈ E, y < 1 - (hol N ω (pl q)).re := by
    intro q hq
    simp only [E, mem_product, evens, mem_filter, mem_univ, true_and] at hq
    have hb := h q.1 q.2.1 q.2.2.1 q.2.2.2
    unfold big at hb
    rw [re_hol_Ψ_even N _ _ _ _ hq.1 hq.2.1 hq.2.2.1 hq.2.2.2] at hb
    by_contra hc
    exact hb (if_neg hc)
  have hs1 : y * m ^ 4 ≤ ∑ p ∈ E.image pl, (1 - (hol N ω p).re) := by
    rw [sum_image (fun a ha b hb h => hinj ha hb h)]
    have e : y * (m : ℝ) ^ 4 = ∑ _q ∈ E, y := by
      rw [sum_const, hE, nsmul_eq_mul]; push_cast; ring
    rw [e]
    exact sum_le_sum (fun q hq => (hbig q hq).le)
  have hs2 : ∑ p ∈ E.image pl, (1 - (hol N ω p).re) ≤ ∑ p ∈ plaqs N, (1 - (hol N ω p).re) :=
    sum_le_sum_of_subset_of_nonneg hsub (fun p _ _ => by
      have := abs_hol_re N ω p; linarith [(abs_le.mp this).2])
  have hs3 : ∑ p ∈ plaqs N, (1 - (hol N ω p).re) = (plaqs N).card - ∑ p ∈ plaqs N, (hol N ω p).re := by
    rw [sum_sub_distrib, sum_const, nsmul_eq_mul, mul_one]
  unfold action
  linarith

theorem big_le_one (μ ν : Fin 4) (y : ℝ) (ω : Cfg N) : big N μ ν y ω ≤ 1 := by
  unfold big; split_ifs <;> norm_num

theorem big_nonneg (μ ν : Fin 4) (y : ℝ) (ω : Cfg N) : 0 ≤ big N μ ν y ω := by
  unfold big; split_ifs <;> norm_num

/-- **The uniform family of large plaquettes**: V(true) ≤ e^{β(#P − y m⁴)}. -/
theorem V4_true_le (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) :
    V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) (fun _ _ _ _ => true) ≤
      Real.exp (β * ((plaqs N).card - y * m ^ 4)) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  unfold V4
  simp only [Hf, if_true]
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  set G : Cfg N → ℝ := fun ω => ∏ t0, ∏ t1, ∏ t2, ∏ t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) with hG
  have hG0 : ∀ ω, 0 ≤ G ω := fun ω => prod_nonneg fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _
  have hG1 : ∀ ω, G ω ≤ 1 := fun ω => prod_le_one (fun _ _ => prod_nonneg fun _ _ =>
    prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => prod_nonneg fun _ _ => big_nonneg N μ ν y _) (fun _ _ =>
    prod_le_one (fun _ _ => big_nonneg N μ ν y _) (fun _ _ => big_le_one N μ ν y _))))
  have hpt : ∀ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ≤ Real.exp (β * ((plaqs N).card - y * m ^ 4)) := by
    intro ω
    have hw0 : 0 ≤ wilsonWeight N β ω := by unfold wilsonWeight; positivity
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal _ hw0]
    by_cases hz : G ω = 0
    · rw [hz, mul_zero]; exact (Real.exp_pos _).le
    · have hall : ∀ t0 t1 t2 t3, big N μ ν y (Ψ N t0 t1 t2 t3 ω) ≠ 0 := by
        intro t0 t1 t2 t3
        have h1 := (prod_ne_zero_iff.mp hz) t0 (mem_univ _)
        have h2 := (prod_ne_zero_iff.mp h1) t1 (mem_univ _)
        have h3 := (prod_ne_zero_iff.mp h2) t2 (mem_univ _)
        exact (prod_ne_zero_iff.mp h3) t3 (mem_univ _)
      have ha := action_le_even N m hN μ ν hμν y ω hall
      have hw : wilsonWeight N β ω ≤ Real.exp (β * ((plaqs N).card - y * m ^ 4)) := by
        unfold wilsonWeight; apply Real.exp_le_exp.mpr; exact mul_le_mul_of_nonneg_left ha hβ
      calc wilsonWeight N β ω * G ω ≤ wilsonWeight N β ω * 1 :=
            mul_le_mul_of_nonneg_left (hG1 ω) hw0
        _ ≤ _ := by rw [mul_one]; exact hw
  have hint : Integrable (fun _ : Cfg N => Real.exp (β * ((plaqs N).card - y * m ^ 4)))
      (Measure.pi fun _ : Lk N => haarBall) := integrable_const _
  have hnn : 0 ≤ᵐ[Measure.pi fun _ : Lk N => haarBall]
      (fun ω => Real.toNNReal (wilsonWeight N β ω) • G ω) :=
    Filter.Eventually.of_forall fun ω => by
      show (0 : ℝ) ≤ Real.toNNReal (wilsonWeight N β ω) • G ω
      rw [NNReal.smul_def, smul_eq_mul]; exact mul_nonneg (by positivity) (hG0 ω)
  calc ∫ ω, Real.toNNReal (wilsonWeight N β ω) • G ω ∂(Measure.pi fun _ : Lk N => haarBall)
      ≤ ∫ _ω, Real.exp (β * ((plaqs N).card - y * m ^ 4)) ∂(Measure.pi fun _ : Lk N => haarBall) :=
        integral_mono_of_nonneg hnn hint (Filter.Eventually.of_forall hpt)
    _ = Real.exp (β * ((plaqs N).card - y * m ^ 4)) := by simp

/-- the partition function `Z = ∫ 1 dμ_W` -/
noncomputable def Zw (β : ℝ) : ℝ := ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)

theorem V4_false (β : ℝ) (μ ν : Fin 4) (y : ℝ) :
    V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) (fun _ _ _ _ => false) = Zw N β := by
  unfold V4 Zw; simp [Hf]

theorem Zw_nonneg (β : ℝ) : 0 ≤ Zw N β := integral_nonneg fun _ => zero_le_one

/-- **The Peierls bound on (ℤ/2m)⁴ from the chessboard estimate (energy form)**, every m ≥ 1, β ≥ 0. -/
theorem peierls_even (hN : N = 2 * m) (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ)
    (F : ZMod N → ZMod N → ZMod N → ZMod N → Bool) :
    |V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) F| ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, (if F t0 t1 t2 t3 then
        Real.exp (β * ((plaqs N).card - y * m ^ 4) / (N ^ 4 : ℕ)) else Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ))) := by
  have hN4 : ((N ^ 4 : ℕ) : ℝ) ≠ 0 := by exact_mod_cast pow_ne_zero 4 (NeZero.ne N)
  set A : ℝ := Real.exp (β * ((plaqs N).card - y * m ^ 4) / (N ^ 4 : ℕ)) with hA
  set B : ℝ := Zw N β ^ ((1 : ℝ) / (N ^ 4 : ℕ)) with hB
  have hc : ∀ b : Bool, 0 ≤ (if b then A else B) := by
    intro b; cases b
    · exact Real.rpow_nonneg (Zw_nonneg N β) _
    · exact (Real.exp_pos _).le
  have hconst : ∀ b : Bool, V4 (wilsonMeasure N β) (Hf N μ ν y) (Ψ N) (fun _ _ _ _ => b) ≤
      (if b then A else B) ^ (N ^ 4) := by
    intro b; cases b
    · rw [V4_false]
      show Zw N β ≤ B ^ (N ^ 4)
      rw [hB, ← Real.rpow_natCast, ← Real.rpow_mul (Zw_nonneg N β), one_div_mul_cancel hN4, Real.rpow_one]
    · show _ ≤ A ^ (N ^ 4)
      rw [hA, ← Real.exp_nat_mul, mul_div_cancel₀ _ hN4]
      exact V4_true_le N m hN β hβ μ ν hμν y
  exact wilson_chessboard_even_root N m hN β (Hf N μ ν y) (base_Hf N μ ν (ne_of_lt hμν) y)
    (fun b => if b then A else B) hc hconst F

end FoldPeierls

#print axioms FoldPeierls.V4_true_le
#print axioms FoldPeierls.peierls_even
