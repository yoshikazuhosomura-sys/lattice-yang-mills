import Mathlib
/-!
The chessboard estimate on a torus of even side n = 2m, abstract form, for every m ≥ 1 (no power of two).

Positions are t ∈ ZMod n (the blocks of one direction).  The site reflection through the plane a maps the block t
to ρ_a t = 2a − 1 − t; its plus half is H_a = {a, a+1, …, a+m−1} (and ρ_a exchanges H_a and its complement).
For a family F : ZMod n → I the two folds are
  F⁺ = F on H_a and F ∘ ρ_a off H_a,      F⁻ = F ∘ ρ_a on H_a and F off H_a.
If a functional V on families satisfies the reflection Cauchy–Schwarz inequality V(F)² ≤ V(F⁺)·V(F⁻) for every
plane a, and V ≥ 0 on constant families, then
  |V(F)|ⁿ ≤ ∏_t V(the constant family F t).
Proof: the maximum argument of Fröhlich–Israel–Lieb–Simon on the finite set of families with values in the range
of F (the ratio |V|ⁿ / ∏ (V(const) + ε) does not decrease under the folds, a fold doubles a run of equal values,
a run of length m folds to a constant family), then ε → 0.  The four-dimensional form iterates the one-dimensional
form direction by direction (families of the remaining directions are the values).

Paper correspondence: one-scale rarity, the chessboard estimate for a torus of every even side length.
-/

namespace FoldChess

open Finset

section OneDim

variable {n : ℕ} [NeZero n] (m : ℕ)

/-- the plus half of the plane `a` -/
def inH (a t : ZMod n) : Prop := (t - a).val < m

instance (a t : ZMod n) : Decidable (inH m a t) := by unfold inH; infer_instance

/-- the reflection of the blocks through the plane `a` -/
def rho (a t : ZMod n) : ZMod n := a + a - 1 - t

theorem rho_rho (a t : ZMod n) : rho a (rho a t) = t := by unfold rho; ring

theorem neg_cast_eq (x : ZMod n) : (-(x + 1) : ZMod n) = ((n - 1 - x.val : ℕ) : ZMod n) := by
  have hv := x.val_lt
  have h1 : 1 ≤ n := Nat.one_le_iff_ne_zero.mpr (NeZero.ne n)
  rw [Nat.cast_sub (by omega), Nat.cast_sub h1, ZMod.natCast_self, ZMod.natCast_zmod_val]
  push_cast; ring

theorem val_neg_succ (x : ZMod n) : (-(x + 1) : ZMod n).val = n - 1 - x.val := by
  rw [neg_cast_eq, ZMod.val_natCast_of_lt]
  have := x.val_lt; omega

theorem inH_rho (hn : n = 2 * m) (a t : ZMod n) : inH m a (rho a t) ↔ ¬ inH m a t := by
  unfold inH
  have e : rho a t - a = -((t - a) + 1) := by unfold rho; ring
  rw [e, val_neg_succ]
  have := (t - a).val_lt
  omega

variable {I : Type*}

/-- the fold keeping the plus half -/
def foldP (a : ZMod n) (F : ZMod n → I) : ZMod n → I := fun t => if inH m a t then F t else F (rho a t)

/-- the fold keeping the minus half -/
def foldM (a : ZMod n) (F : ZMod n → I) : ZMod n → I := fun t => if inH m a t then F (rho a t) else F t

theorem prod_rho (hn : n = 2 * m) (a : ZMod n) (g : ZMod n → ℝ) :
    ∏ t ∈ univ.filter (fun t => ¬ inH m a t), g (rho a t) = ∏ t ∈ univ.filter (fun t => inH m a t), g t := by
  apply Finset.prod_nbij' (rho a) (rho a)
  · intro t ht
    simp only [mem_filter, mem_univ, true_and] at ht ⊢
    exact (inH_rho m hn a t).2 ht
  · intro t ht
    simp only [mem_filter, mem_univ, true_and] at ht ⊢
    rw [inH_rho m hn a t]; exact not_not.2 ht
  · intro t _; exact rho_rho a t
  · intro t _; exact rho_rho a t
  · intro t _; rfl

/-- the counting identity: the folds use every value of a half twice -/
theorem prod_fold (hn : n = 2 * m) (a : ZMod n) (F : ZMod n → I) (c : I → ℝ) :
    (∏ t, c (F t)) ^ 2 = (∏ t, c (foldP m a F t)) * ∏ t, c (foldM m a F t) := by
  have hP : ∏ t, c (foldP m a F t) =
      (∏ t ∈ univ.filter (fun t => inH m a t), c (F t)) ^ 2 := by
    rw [← Finset.prod_filter_mul_prod_filter_not univ (fun t => inH m a t), sq]
    congr 1
    · apply Finset.prod_congr rfl; intro t ht
      simp only [mem_filter, mem_univ, true_and] at ht; simp [foldP, ht]
    · rw [← prod_rho m hn a (fun t => c (F t))]
      apply Finset.prod_congr rfl; intro t ht
      simp only [mem_filter, mem_univ, true_and] at ht; simp [foldP, ht]
  have hM : ∏ t, c (foldM m a F t) =
      (∏ t ∈ univ.filter (fun t => ¬ inH m a t), c (F t)) ^ 2 := by
    rw [← Finset.prod_filter_mul_prod_filter_not univ (fun t => inH m a t), sq, mul_comm]
    congr 1
    · apply Finset.prod_congr rfl; intro t ht
      simp only [mem_filter, mem_univ, true_and] at ht; simp [foldM, ht]
    · have := prod_rho m hn a (fun t => c (F (rho a t)))
      simp only [rho_rho] at this
      rw [this]
      apply Finset.prod_congr rfl; intro t ht
      simp only [mem_filter, mem_univ, true_and] at ht; simp [foldM, ht]
  rw [hP, hM, ← mul_pow, Finset.prod_filter_mul_prod_filter_not]

/-- a run of `ℓ` equal values starting at `s` -/
def Run (F : ZMod n → I) (s : ZMod n) (ℓ : ℕ) : Prop := ∀ j : ℕ, j < ℓ → F (s + (j : ZMod n)) = F s

theorem run_mono {F : ZMod n → I} {s : ZMod n} {ℓ ℓ' : ℕ} (h : Run F s ℓ) (hl : ℓ' ≤ ℓ) : Run F s ℓ' :=
  fun j hj => h j (lt_of_lt_of_le hj hl)

theorem run_one (F : ZMod n → I) (s : ZMod n) : Run F s 1 := by
  intro j hj; have : j = 0 := by omega
  subst this; simp

theorem val_add_cast (s : ZMod n) (k : ℕ) (hk : k < n) : ((s + (k : ZMod n)) - s).val = k := by
  rw [add_sub_cancel_left, ZMod.val_natCast_of_lt hk]

/-- a fold at the start of a run of length `ℓ ≤ m` doubles it -/
theorem run_double (hn : n = 2 * m) {F : ZMod n → I} {s : ZMod n} {ℓ : ℕ} (h : Run F s ℓ) (h1 : 1 ≤ ℓ)
    (hl : ℓ ≤ m) : Run (foldP m s F) (s - (ℓ : ZMod n)) (2 * ℓ) ∧ foldP m s F (s - (ℓ : ZMod n)) = F s := by
  -- the value at every position of the new run is F s
  have key : ∀ j : ℕ, j < 2 * ℓ → foldP m s F (s - (ℓ : ZMod n) + (j : ZMod n)) = F s := by
    intro j hj
    by_cases hjl : ℓ ≤ j
    · -- position s + (j - ℓ), inside the plus half
      have ep : s - (ℓ : ZMod n) + (j : ZMod n) = s + ((j - ℓ : ℕ) : ZMod n) := by
        rw [Nat.cast_sub hjl]; ring
      have hin : inH m s (s + ((j - ℓ : ℕ) : ZMod n)) := by
        unfold inH; rw [val_add_cast s (j - ℓ) (by omega)]; omega
      rw [ep]; simp only [foldP, hin, if_true]
      exact h (j - ℓ) (by omega)
    · -- position s − (ℓ − j), outside; its mirror is s + (ℓ − 1 − j)
      push Not at hjl
      have ep : s - (ℓ : ZMod n) + (j : ZMod n) = s + (-(((ℓ - 1 - j : ℕ) : ZMod n) + 1)) := by
        rw [Nat.cast_sub (by omega), Nat.cast_sub (by omega)]; push_cast; ring
      have hout : ¬ inH m s (s + (-(((ℓ - 1 - j : ℕ) : ZMod n) + 1))) := by
        unfold inH; rw [add_sub_cancel_left, val_neg_succ, ZMod.val_natCast_of_lt (by omega)]; omega
      have er : rho s (s + (-(((ℓ - 1 - j : ℕ) : ZMod n) + 1))) = s + ((ℓ - 1 - j : ℕ) : ZMod n) := by
        unfold rho; ring
      rw [ep]; simp only [foldP, hout, if_false, er]
      exact h (ℓ - 1 - j) (by omega)
  have h0 : foldP m s F (s - (ℓ : ZMod n)) = F s := by
    have := key 0 (by omega); simpa using this
  refine ⟨fun j hj => ?_, h0⟩
  rw [key j hj, h0]

/-- a fold at the start of a run of length `m` gives a constant family -/
theorem run_const (hn : n = 2 * m) {F : ZMod n → I} {s : ZMod n} (h : Run F s m) :
    foldP m s F = fun _ => F s := by
  funext t
  have hs : ∀ u : ZMod n, inH m s u → F u = F s := by
    intro u hu
    have eu : u = s + (((u - s).val : ℕ) : ZMod n) := by rw [ZMod.natCast_zmod_val]; ring
    rw [eu]; exact h _ hu
  by_cases ht : inH m s t
  · simp only [foldP, ht, if_true]; exact hs t ht
  · simp only [foldP, ht, if_false]; exact hs _ ((inH_rho m hn s t).2 ht)

theorem foldP_comp {J : Type*} (g : I → J) (a : ZMod n) (F : ZMod n → I) :
    (fun t => g (foldP m a F t)) = foldP m a (fun t => g (F t)) := by
  funext t; unfold foldP; split_ifs <;> rfl

theorem foldM_comp {J : Type*} (g : I → J) (a : ZMod n) (F : ZMod n → I) :
    (fun t => g (foldM m a F t)) = foldM m a (fun t => g (F t)) := by
  funext t; unfold foldM; split_ifs <;> rfl

/-- **The one-dimensional chessboard estimate (abstract), every even side `n = 2m`.** -/
theorem chess_one (hn : n = 2 * m) (V : (ZMod n → I) → ℝ)
    (hfold : ∀ a F, V F ^ 2 ≤ V (foldP m a F) * V (foldM m a F))
    (hconst : ∀ i, 0 ≤ V (fun _ => i)) (F : ZMod n → I) :
    |V F| ^ n ≤ ∏ t, V (fun _ => F t) := by
  classical
  have hm : 1 ≤ m := by have := NeZero.ne n; omega
  -- the ε-version
  have hε : ∀ ε : ℝ, 0 < ε → |V F| ^ n ≤ ∏ t, (V (fun _ => F t) + ε) := by
    intro ε hε
    set S : Finset I := univ.image F with hS
    let W : (ZMod n → S) → ℝ := fun G => V (fun t => (G t : I))
    let D : (ZMod n → S) → ℝ := fun G => ∏ t, (V (fun _ => (G t : I)) + ε)
    have hDpos : ∀ G, 0 < D G := fun G =>
      Finset.prod_pos (fun t _ => add_pos_of_nonneg_of_pos (hconst _) hε)
    let r : (ZMod n → S) → ℝ := fun G => |W G| ^ n / D G
    have hr0 : ∀ G, 0 ≤ r G := fun G => div_nonneg (pow_nonneg (abs_nonneg _) _) (hDpos G).le
    -- folds of `S`-families
    have hWP : ∀ a G, W (foldP m a G) = V (foldP m a (fun t => (G t : I))) := by
      intro a G; show V _ = _; rw [foldP_comp]
    have hWM : ∀ a G, W (foldM m a G) = V (foldM m a (fun t => (G t : I))) := by
      intro a G; show V _ = _; rw [foldM_comp]
    have hDf : ∀ a G, D G ^ 2 = D (foldP m a G) * D (foldM m a G) :=
      fun a G => prod_fold m hn a G (fun i => V (fun _ => (i : I)) + ε)
    have hrfold : ∀ a G, r G ^ 2 ≤ r (foldP m a G) * r (foldM m a G) := by
      intro a G
      have hv : |W G| ^ 2 ≤ |W (foldP m a G)| * |W (foldM m a G)| := by
        rw [sq_abs, hWP, hWM]
        exact le_trans (hfold a _) (le_trans (le_abs_self _) (by rw [abs_mul]))
      have hv' : (|W G| ^ n) ^ 2 ≤ |W (foldP m a G)| ^ n * |W (foldM m a G)| ^ n := by
        rw [← pow_mul, mul_comm n 2, pow_mul, ← mul_pow]
        exact pow_le_pow_left₀ (sq_nonneg _) hv n
      show (|W G| ^ n / D G) ^ 2 ≤ (|W _| ^ n / D _) * (|W _| ^ n / D _)
      rw [div_pow, hDf a G, div_mul_div_comm]
      exact div_le_div_of_nonneg_right hv' (mul_pos (hDpos _) (hDpos _)).le
    -- a maximiser
    haveI hne : Nonempty (ZMod n → S) := ⟨fun _ => ⟨F 0, by simp [hS]⟩⟩
    obtain ⟨G0, hG0⟩ := Finite.exists_max r
    set M := r G0 with hMdef
    have hF : r (fun t => ⟨F t, by simp [hS]⟩) ≤ M := hG0 _
    by_cases hM0 : M ≤ 0
    · -- every ratio vanishes
      have h0 : r (fun t => ⟨F t, by simp [hS]⟩) = 0 := le_antisymm (le_trans hF hM0) (hr0 _)
      have : |V F| ^ n = 0 := by
        have := (div_eq_zero_iff.mp h0)
        rcases this with h | h
        · exact h
        · exact absurd h (hDpos _).ne'
      rw [this]; exact (hDpos (fun t => ⟨F t, by simp [hS]⟩)).le
    push_neg at hM0
    -- maximisers are closed under folds
    have hclosed : ∀ G, r G = M → ∀ a, r (foldP m a G) = M := by
      intro G hG a
      have h1 := hrfold a G
      have hp := hG0 (foldP m a G)
      have hq := hG0 (foldM m a G)
      by_contra hne'
      have hlt : r (foldP m a G) < M := lt_of_le_of_ne hp hne'
      have : r (foldP m a G) * r (foldM m a G) < M * M := by
        calc r (foldP m a G) * r (foldM m a G) ≤ r (foldP m a G) * M :=
              mul_le_mul_of_nonneg_left hq (hr0 _)
          _ < M * M := mul_lt_mul_of_pos_right hlt hM0
      rw [hG] at h1; nlinarith
    -- runs grow to length m
    have hgrow : ∀ k : ℕ, ∃ G s, r G = M ∧ Run G s (min (2 ^ k) m) := by
      intro k
      induction k with
      | zero => exact ⟨G0, 0, rfl, run_mono (run_one G0 0) (by simp)⟩
      | succ k ih =>
        obtain ⟨G, s, hG, hrun⟩ := ih
        by_cases hk : m ≤ 2 ^ k
        · refine ⟨G, s, hG, run_mono hrun ?_⟩
          rw [min_eq_right hk]; exact min_le_right _ _
        · push Not at hk
          rw [min_eq_left hk.le] at hrun
          obtain ⟨hd, _⟩ := run_double m hn hrun (Nat.one_le_two_pow) hk.le
          refine ⟨foldP m s G, s - ((2 ^ k : ℕ) : ZMod n), hclosed G hG s, run_mono hd ?_⟩
          rw [pow_succ]; omega
    obtain ⟨G, s, hG, hrun⟩ := hgrow m
    have hm2 : min (2 ^ m) m = m := min_eq_right (Nat.lt_two_pow_self).le
    rw [hm2] at hrun
    have hc := run_const m hn hrun
    have hrc : r (foldP m s G) = M := hclosed G hG s
    rw [hc] at hrc
    -- the ratio of a constant family is at most 1
    have hle1 : r (fun _ => G s) ≤ 1 := by
      show |V (fun _ => ((G s : S) : I))| ^ n / ∏ t : ZMod n, (V (fun _ => ((G s : S) : I)) + ε) ≤ 1
      rw [Finset.prod_const, Finset.card_univ, ZMod.card, abs_of_nonneg (hconst _)]
      rw [div_le_one (pow_pos (add_pos_of_nonneg_of_pos (hconst _) hε) _)]
      exact pow_le_pow_left₀ (hconst _) (by linarith) _
    have : r (fun t => ⟨F t, by simp [hS]⟩) ≤ 1 := le_trans hF (hrc ▸ hle1)
    have hD := hDpos (fun t => ⟨F t, by simp [hS]⟩)
    rw [div_le_one hD] at this
    exact this
  -- ε → 0
  have hcont : Continuous (fun ε : ℝ => ∏ t, (V (fun _ => F t) + ε)) := by fun_prop
  have ht : Filter.Tendsto (fun ε : ℝ => ∏ t, (V (fun _ => F t) + ε)) (nhdsWithin 0 (Set.Ioi 0))
      (nhds (∏ t, (V (fun _ => F t) + 0))) := (hcont.tendsto 0).mono_left nhdsWithin_le_nhds
  simp only [add_zero] at ht
  exact ge_of_tendsto ht (by filter_upwards [self_mem_nhdsWithin] with ε hε' using hε ε hε')

end OneDim

end FoldChess

#print axioms FoldChess.chess_one
