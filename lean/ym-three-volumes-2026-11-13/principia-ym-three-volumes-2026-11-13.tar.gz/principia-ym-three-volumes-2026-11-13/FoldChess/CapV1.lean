import FoldChess.ProbFormV1
/-!
A lower bound for the Haar volume of a cap of SU(2) by a covering:
  h(r) = Haar{U : ‖U − 1‖ < r} ≥ 1/(2K+1)⁴   whenever K ≥ 2 and 2/K < r.
(The points of the grid (1/K)ℤ⁴ ∩ [−1, 1]⁴, normalised, are 2/K-dense in SU(2) = S³; by left invariance every
ball of radius r has the same Haar measure h(r); the union bound gives 1 ≤ (2K+1)⁴ h(r).)

Paper correspondence: one-scale rarity, the entropy constant made explicit.
-/

namespace FoldCap

open MeasureTheory OSGap TorusRP FoldEntropy Finset

local notation "ℍr" => Quaternion ℝ

/-- the ball of radius r around g in SU(2) -/
def ballS (r : ℝ) (g : SU2) : Set SU2 := {U | ‖(U : ℍr) - (g : ℍr)‖ < r}

theorem norm_su2 (U : SU2) : ‖(U : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp U.2

theorem ballS_eq (r : ℝ) (g : SU2) : ballS r g = (fun h => g⁻¹ * h) ⁻¹' ballS r 1 := by
  ext U
  simp only [ballS, Set.mem_preimage, Set.mem_setOf_eq, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv]
  have hg : (g : ℍr) ≠ 0 := by
    intro h; have := norm_su2 g; rw [h, norm_zero] at this; exact zero_ne_one this
  have e : (g : ℍr)⁻¹ * (U : ℍr) - ((1 : SU2) : ℍr) = (g : ℍr)⁻¹ * ((U : ℍr) - (g : ℍr)) := by
    rw [mul_sub, inv_mul_cancel₀ hg]; rfl
  rw [e, norm_mul, norm_inv, norm_su2 g, inv_one, one_mul]

theorem measurableSet_ballS (r : ℝ) (g : SU2) : MeasurableSet (ballS r g) :=
  (isOpen_lt (continuous_norm.comp (continuous_subtype_val.sub continuous_const)) continuous_const).measurableSet

theorem measure_ballS (r : ℝ) (g : SU2) : haarProb SU2 (ballS r g) = haarProb SU2 (ballS r 1) := by
  rw [ballS_eq, measure_preimage_mul]

/-- the grid point of an integer vector -/
noncomputable def qk (K : ℕ) (k : ℤ × ℤ × ℤ × ℤ) : ℍr :=
  ⟨(k.1 : ℝ) / K, (k.2.1 : ℝ) / K, (k.2.2.1 : ℝ) / K, (k.2.2.2 : ℝ) / K⟩

open Classical in
/-- the normalised grid point -/
noncomputable def gk (K : ℕ) (k : ℤ × ℤ × ℤ × ℤ) : SU2 :=
  if h : qk K k ≠ 0 then
    ⟨(‖qk K k‖⁻¹ : ℝ) • qk K k, by
      rw [mem_sphere_zero_iff_norm, norm_smul, Real.norm_eq_abs, abs_inv, abs_norm,
        inv_mul_cancel₀ (norm_ne_zero_iff.mpr h)]⟩
  else 1

/-- the index set -/
noncomputable def Ik (K : ℕ) : Finset (ℤ × ℤ × ℤ × ℤ) :=
  Icc (-(K : ℤ)) K ×ˢ (Icc (-(K : ℤ)) K ×ˢ (Icc (-(K : ℤ)) K ×ˢ Icc (-(K : ℤ)) K))

theorem card_Ik (K : ℕ) : (Ik K).card = (2 * K + 1) ^ 4 := by
  have h : (Icc (-(K : ℤ)) K).card = 2 * K + 1 := by rw [Int.card_Icc]; omega
  simp only [Ik, card_product, h]; ring

theorem comp_le_one (q : ℍr) (hq : ‖q‖ = 1) :
    |q.re| ≤ 1 ∧ |q.imI| ≤ 1 ∧ |q.imJ| ≤ 1 ∧ |q.imK| ≤ 1 := by
  have h : q.re ^ 2 + q.imI ^ 2 + q.imJ ^ 2 + q.imK ^ 2 = 1 := by
    have := Quaternion.normSq_eq_norm_mul_self q
    rw [hq, mul_one, Quaternion.normSq_def'] at this; exact this
  refine ⟨?_, ?_, ?_, ?_⟩ <;> rw [abs_le] <;> constructor <;>
    nlinarith [sq_nonneg q.re, sq_nonneg q.imI, sq_nonneg q.imJ, sq_nonneg q.imK]

theorem round_mem (K : ℕ) (x : ℝ) (hx : |x| ≤ 1) : round ((K : ℝ) * x) ∈ Icc (-(K : ℤ)) K := by
  have h := abs_sub_round ((K : ℝ) * x)
  rw [abs_le] at h hx
  have hK : (0 : ℝ) ≤ K := Nat.cast_nonneg K
  rw [mem_Icc]
  constructor
  · have : ((-(K : ℤ) : ℤ) : ℝ) < (round ((K : ℝ) * x) : ℝ) + 1 := by push_cast; nlinarith
    have := (Int.cast_lt (R := ℝ)).mp (by push_cast at this ⊢; linarith : ((-(K : ℤ) - 1 : ℤ) : ℝ) < (round ((K : ℝ) * x) : ℝ))
    omega
  · have : ((round ((K : ℝ) * x) : ℤ) : ℝ) < ((K : ℤ) : ℝ) + 1 := by push_cast; nlinarith
    have := (Int.cast_lt (R := ℝ)).mp (by push_cast at this ⊢; linarith : ((round ((K : ℝ) * x) : ℤ) : ℝ) < (((K : ℤ) + 1 : ℤ) : ℝ))
    omega

theorem round_close (K : ℕ) (hK : 0 < K) (x : ℝ) : |x - (round ((K : ℝ) * x) : ℝ) / K| ≤ 1 / (2 * K) := by
  have h := abs_sub_round ((K : ℝ) * x)
  have hKr : (0 : ℝ) < K := Nat.cast_pos.mpr hK
  have e : x - (round ((K : ℝ) * x) : ℝ) / K = ((K : ℝ) * x - round ((K : ℝ) * x)) / K := by
    field_simp
  rw [e, abs_div, abs_of_pos hKr, div_le_div_iff₀ hKr (by positivity)]
  nlinarith [abs_nonneg ((K : ℝ) * x - round ((K : ℝ) * x))]

/-- **the covering**: every U is within 2/K of a normalised grid point -/
theorem cover (K : ℕ) (hK : 2 ≤ K) (U : SU2) :
    ∃ k ∈ Ik K, ‖(U : ℍr) - (gk K k : ℍr)‖ ≤ 2 / K := by
  have hKpos : 0 < K := by omega
  have hKr : (0 : ℝ) < K := Nat.cast_pos.mpr hKpos
  have hK2 : (2 : ℝ) ≤ K := by exact_mod_cast hK
  set q : ℍr := (U : ℍr)
  have hq := norm_su2 U
  obtain ⟨h0, h1, h2, h3⟩ := comp_le_one q hq
  set k : ℤ × ℤ × ℤ × ℤ := (round ((K : ℝ) * q.re), round ((K : ℝ) * q.imI), round ((K : ℝ) * q.imJ),
    round ((K : ℝ) * q.imK))
  refine ⟨k, ?_, ?_⟩
  · simp only [Ik, mem_product]
    exact ⟨round_mem K _ h0, round_mem K _ h1, round_mem K _ h2, round_mem K _ h3⟩
  set z := qk K k
  have c0 := round_close K hKpos q.re; have c1 := round_close K hKpos q.imI
  have c2 := round_close K hKpos q.imJ; have c3 := round_close K hKpos q.imK
  have hsq : ‖q - z‖ * ‖q - z‖ ≤ 1 / (K : ℝ) * (1 / K) := by
    rw [← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
    have r0 : (q - z).re = q.re - (round ((K : ℝ) * q.re) : ℝ) / K := rfl
    have r1 : (q - z).imI = q.imI - (round ((K : ℝ) * q.imI) : ℝ) / K := rfl
    have r2 : (q - z).imJ = q.imJ - (round ((K : ℝ) * q.imJ) : ℝ) / K := rfl
    have r3 : (q - z).imK = q.imK - (round ((K : ℝ) * q.imK) : ℝ) / K := rfl
    rw [r0, r1, r2, r3]
    have b : ∀ a : ℝ, |a| ≤ 1 / (2 * K) → a ^ 2 ≤ 1 / (4 * (K : ℝ) ^ 2) := by
      intro a ha
      have : a ^ 2 = |a| ^ 2 := (sq_abs a).symm
      rw [this]
      have hb : (1 : ℝ) / (2 * K) ≥ 0 := by positivity
      calc |a| ^ 2 ≤ (1 / (2 * K)) ^ 2 := pow_le_pow_left₀ (abs_nonneg a) ha 2
        _ = 1 / (4 * (K : ℝ) ^ 2) := by ring
    have e4 : 1 / (K : ℝ) * (1 / K) = 4 * (1 / (4 * (K : ℝ) ^ 2)) := by ring
    rw [e4]
    nlinarith [b _ c0, b _ c1, b _ c2, b _ c3]
  have hqz : ‖q - z‖ ≤ 1 / K := by
    by_contra hc; push Not at hc
    have : (1 / (K : ℝ)) * (1 / K) < ‖q - z‖ * ‖q - z‖ :=
      mul_lt_mul'' hc hc (by positivity) (by positivity)
    linarith
  have hz : z ≠ 0 := by
    intro h
    rw [h, sub_zero, hq] at hqz
    have : (1 : ℝ) / K ≤ 1 / 2 := by rw [div_le_div_iff₀ hKr (by norm_num)]; linarith
    linarith
  have hzn : 0 < ‖z‖ := norm_pos_iff.mpr hz
  have hg : (gk K k : ℍr) = (‖z‖⁻¹ : ℝ) • z := by
    simp only [gk]; rw [dif_pos hz]
  have hzg : ‖z - (‖z‖⁻¹ : ℝ) • z‖ ≤ ‖q - z‖ := by
    have e : z - (‖z‖⁻¹ : ℝ) • z = (1 - ‖z‖⁻¹ : ℝ) • z := by rw [sub_smul, one_smul]
    rw [e, norm_smul, Real.norm_eq_abs]
    have e2 : |1 - ‖z‖⁻¹| * ‖z‖ = |‖z‖ - 1| := by
      rw [← abs_of_pos hzn, ← abs_mul, abs_of_pos hzn]; congr 1; field_simp
    rw [e2, ← hq]
    have := abs_norm_sub_norm_le z q
    rw [norm_sub_rev] at this
    exact this
  rw [hg]
  calc ‖q - (‖z‖⁻¹ : ℝ) • z‖ ≤ ‖q - z‖ + ‖z - (‖z‖⁻¹ : ℝ) • z‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ 1 / K + 1 / K := add_le_add hqz (le_trans hzg hqz)
    _ = 2 / K := by ring

/-- **The cap volume**: h(r) ≥ 1/(2K+1)⁴ when K ≥ 2 and 2/K < r. -/
theorem ballQ_ge (K : ℕ) (hK : 2 ≤ K) (r : ℝ) (hr : 2 / (K : ℝ) < r) :
    1 / (((2 * K + 1 : ℕ) : ℝ) ^ 4) ≤ haarBall.real (ballQ r) := by
  set μ := haarProb SU2
  have hpre : incl ⁻¹' ballQ r = ballS r 1 := by
    ext U
    simp only [Set.mem_preimage, ballQ, ballS, Set.mem_setOf_eq, incl]
    constructor
    · exact fun h => h.1
    · intro h; exact ⟨h, mem_sphere_zero_iff_norm.1 U.2⟩
  have hreal : haarBall.real (ballQ r) = (μ (ballS r 1)).toReal := by
    rw [Measure.real, haarBall, Measure.map_apply continuous_incl.measurable (measurableSet_ballQ r), hpre]
  -- the union bound
  have hcov : (Set.univ : Set SU2) ⊆ ⋃ k ∈ Ik K, ballS r (gk K k) := by
    intro U _
    obtain ⟨k, hk, hd⟩ := cover K hK U
    exact Set.mem_biUnion hk (show ‖(U : ℍr) - (gk K k : ℍr)‖ < r from lt_of_le_of_lt hd hr)
  have hle : (1 : ENNReal) ≤ ((Ik K).card : ENNReal) * μ (ballS r 1) := by
    calc (1 : ENNReal) = μ Set.univ := measure_univ.symm
      _ ≤ μ (⋃ k ∈ Ik K, ballS r (gk K k)) := measure_mono hcov
      _ ≤ ∑ k ∈ Ik K, μ (ballS r (gk K k)) := measure_biUnion_finset_le _ _
      _ = ∑ _k ∈ Ik K, μ (ballS r 1) := by
          apply sum_congr rfl; intro k _; exact measure_ballS r _
      _ = ((Ik K).card : ENNReal) * μ (ballS r 1) := by rw [sum_const, nsmul_eq_mul]
  have hfin : ((Ik K).card : ENNReal) * μ (ballS r 1) ≠ ⊤ :=
    ENNReal.mul_ne_top (ENNReal.natCast_ne_top _) (measure_ne_top _ _)
  have h2 := ENNReal.toReal_mono hfin hle
  rw [ENNReal.toReal_one, ENNReal.toReal_mul, ENNReal.toReal_natCast, card_Ik] at h2
  rw [hreal]
  have hpos : (0 : ℝ) < (((2 * K + 1) ^ 4 : ℕ) : ℝ) := by positivity
  rw [div_le_iff₀ (by push_cast; positivity)]
  push_cast at h2 ⊢
  linarith

end FoldCap

#print axioms FoldCap.cover
#print axioms FoldCap.ballQ_ge
