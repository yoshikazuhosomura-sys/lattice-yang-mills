import FoldChess.MixAllV1
/-!
**Volume-uniform rarity for every finite set of plaquettes, rate 1/6, one statement.**  For 0 < y ≤ 2 there are
r = y/20 and β₀ such that for β ≥ β₀ the number q₁ = e^{β(48 r² − y)} / h(r)⁴ is < 1 and, for every m ≥ 2 (N = 2m)
and every finite set X of plaquettes of (ℤ/N)⁴,
  ∫ ∏_{p ∈ X} 1[y < 1 − Re U_p] dμ_W ≤ Z · q₁^{⌊|X|/6⌋}.

Paper correspondence: one-scale rarity (Proposition P), uniform in the volume, every even side ≥ 4.
-/

namespace FoldMix

open MeasureTheory TorusRP FoldChess FoldWilson FoldPeierls FoldEntropy Finset

theorem rarity_uniform_all_mix (y : ℝ) (hy0 : 0 < y) (hy2 : y ≤ 2) :
    ∃ r : ℝ, 0 < r ∧ ∃ β₀ : ℝ, ∀ β : ℝ, β₀ ≤ β →
      Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4 < 1 ∧
      ∀ (N : ℕ) [NeZero N] (m : ℕ), N = 2 * m → 2 ≤ m → ∀ X : Finset (Lk N × Fin 4), X ⊆ plaqs N →
        ∫ ω, ∏ p ∈ X, bigP N y ω p ∂(wilsonMeasure N β) ≤
          Zw N β * (Real.exp (β * (48 * r ^ 2 - y)) / haarBall.real (ballQ r) ^ 4) ^ (X.card / 6) := by
  obtain ⟨r, hr0, β₀, h⟩ := rarity_uniform_mix y hy0 hy2
  refine ⟨r, hr0, max β₀ 0, fun β hβ => ?_⟩
  have hβ1 : β₀ ≤ β := le_trans (le_max_left _ _) hβ
  have hβ0 : 0 ≤ β := le_trans (le_max_right _ _) hβ
  obtain ⟨hq, _⟩ := h β hβ1
  exact ⟨hq, fun N _ m hN hM X hX => rarity_all_mix N m hN hM β hβ0 y r hr0 hq.le X hX⟩

end FoldMix

#print axioms FoldMix.rarity_uniform_all_mix
