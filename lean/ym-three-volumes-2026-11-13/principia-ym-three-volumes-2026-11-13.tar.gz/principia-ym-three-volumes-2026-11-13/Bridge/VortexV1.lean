import Bridge.ProbV1

/-!
# The vortex ratio as an expectation in the normalised Wilson measure of the strong-coupling side

`Z₁ / Z₀ = ZW N N β false true / ZW N N β false false` equals the `TorusRP.wilsonProb N β`-expectation
of the twist observable `exp(β Σ_B (z_B − 1) Re U_B)` (`z = zt false true`: `z_B − 1 = −2` on the
`N²` plaquettes of directions `(2,3)` (paper `(3,4)`) at `(x₃, x₄) = (0, 0)`, `0` elsewhere), read
through the time-aligned bridge.  With `TwistedWilson.twisted_vortex_bound` this gives the vortex
bound stated on the strong-coupling side's probability measure.
-/

open MeasureTheory

namespace WilsonBridgeV

variable (N : ℕ) [NeZero N]

/-- the twist observable `exp(β Σ_B (z_B − 1) Re U_B)`, `z = zt false true` -/
noncomputable def twistObs (β : ℝ) (U : TwistedWilson.Link N N → TwistedWilson.SU2) : ℝ :=
  Real.exp (β * ∑ B : TwistedWilson.Plaq N N,
    (TwistedWilson.zt N N false true B - 1) * (TwistedWilson.hol N N U B).re)

theorem zt_false_true_sub_one (B : TwistedWilson.Plaq N N) :
    TwistedWilson.zt N N false true B - 1
      = if B.2 = TwistedWilson.p23 ∧ B.1.2 = 0 then -2 else 0 := by
  unfold TwistedWilson.zt TwistedWilson.tw
  by_cases h : B.2 = TwistedWilson.p23 ∧ B.1.2 = 0
  · rw [if_pos h, if_pos h]; norm_num
  · rw [if_neg h, if_neg h]; simp

theorem measurable_twistObs (β : ℝ) : Measurable (twistObs N β) :=
  (Real.continuous_exp.comp (continuous_const.mul (continuous_finsetSum _ fun B _ =>
    continuous_const.mul (TwistedWilson.continuous_hol_re N N B)))).measurable

theorem ZW_twist_eq (β : ℝ) :
    TwistedWilson.ZW N N β false true
      = ∫ U, twistObs N β U * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N) := by
  unfold TwistedWilson.ZW
  refine integral_congr_ae (Filter.Eventually.of_forall fun U => ?_)
  simp only [twistObs]
  rw [← Real.exp_add, ← mul_add, ← Finset.sum_add_distrib]
  congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  ring

/-- **the vortex ratio is a `wilsonProb` expectation**:
`Z₁ / Z₀ = ∫ twistObs(fromBallT ω) d(wilsonProb N β)(ω)` -/
theorem vortex_ratio_eq (β : ℝ) :
    TwistedWilson.ZW N N β false true / TwistedWilson.ZW N N β false false
      = ∫ ω, twistObs N β (WilsonBridgeT.fromBallT N ω)
          ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall)) := by
  rw [← WilsonBridgeP.integral_twisted_wilsonProbT N β (twistObs N β) (measurable_twistObs N β),
    ← ZW_twist_eq, div_eq_inv_mul]

/-- **the thin-vortex bound on the strong-coupling side** (`M = N`, no background twist, every real `β`):
with `r = ⟨twistObs ∘ fromBallT⟩_{wilsonProb N β}`, `(1 − r)/(1 + r) ≤ tanh(N²|β|)^{N²}`. -/
theorem vortex_bound_wilsonProb (β : ℝ) :
    (1 - ∫ ω, twistObs N β (WilsonBridgeT.fromBallT N ω)
          ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall)))
      / (1 + ∫ ω, twistObs N β (WilsonBridgeT.fromBallT N ω)
          ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall)))
      ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (N ^ 2) := by
  rw [← vortex_ratio_eq]
  have h := TwistedWilson.twisted_vortex_bound N N β false
  have h0 := TwistedWilson.ZW_pos N N β false false
  have e : (1 - TwistedWilson.ZW N N β false true / TwistedWilson.ZW N N β false false)
      / (1 + TwistedWilson.ZW N N β false true / TwistedWilson.ZW N N β false false)
      = (TwistedWilson.ZW N N β false false - TwistedWilson.ZW N N β false true)
        / (TwistedWilson.ZW N N β false false + TwistedWilson.ZW N N β false true) := by
    rw [one_sub_div h0.ne', one_add_div h0.ne', div_div_div_cancel_right₀ h0.ne']
  rw [e]
  exact h

/-- check `β = 0`: the twist observable is `1`, the ratio is `1` -/
theorem vortex_ratio_zero : TwistedWilson.ZW N N 0 false true / TwistedWilson.ZW N N 0 false false = 1 := by
  rw [vortex_ratio_eq]
  simp only [twistObs, zero_mul, Real.exp_zero]
  simp

end WilsonBridgeV

#print axioms WilsonBridgeV.ZW_twist_eq
#print axioms WilsonBridgeV.vortex_ratio_eq
#print axioms WilsonBridgeV.vortex_bound_wilsonProb
#print axioms WilsonBridgeV.zt_false_true_sub_one
#print axioms WilsonBridgeV.vortex_ratio_zero
