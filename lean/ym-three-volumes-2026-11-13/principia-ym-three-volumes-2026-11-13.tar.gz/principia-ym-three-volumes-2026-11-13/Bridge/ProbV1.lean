import Bridge.TimeAlignV1
import Lattice.WilsonGapV2

/-!
# The normalised Wilson measure `TorusRP.wilsonProb` in terms of the untwisted `ZW`

`∫ F d(wilsonProb N β) = (ZW N N β false false)⁻¹ ∫ F(e U) exp(β Σ_B Re hol U B) d(haarCfg N N)(U)`
for both correspondences `e = toBall N` (directions kept) and `e = toBallT N` (time aligned).
-/

open MeasureTheory

namespace WilsonBridgeP

variable (N : ℕ) [NeZero N]

theorem integral_wilsonProb (β : ℝ) (F : (TorusRP.Lk N → TorusRP.QBall) → ℝ) (hF : Measurable F) :
    ∫ ω, F ω ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall))
      = (TwistedWilson.ZW N N β false false)⁻¹ *
        ∫ U, F (WilsonBridge.toBall N U)
          * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N) := by
  rw [TorusRP.wilsonProb_toMeasure, integral_smul_measure, ENNReal.toReal_inv,
    WilsonBridge.wilsonMeasure_univ, ENNReal.toReal_ofReal (TwistedWilson.ZW_pos N N β _ _).le,
    WilsonBridge.integral_wilsonMeasure N β F hF, smul_eq_mul]

theorem integral_wilsonProbT (β : ℝ) (F : (TorusRP.Lk N → TorusRP.QBall) → ℝ) (hF : Measurable F) :
    ∫ ω, F ω ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall))
      = (TwistedWilson.ZW N N β false false)⁻¹ *
        ∫ U, F (WilsonBridgeT.toBallT N U)
          * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N) := by
  rw [TorusRP.wilsonProb_toMeasure, integral_smul_measure, ENNReal.toReal_inv,
    WilsonBridge.wilsonMeasure_univ, ENNReal.toReal_ofReal (TwistedWilson.ZW_pos N N β _ _).le,
    WilsonBridgeT.integral_wilsonMeasureT N β F hF, smul_eq_mul]

/-- the converse direction for functions of `SU2`-configurations (time aligned) -/
theorem integral_twisted_wilsonProbT (β : ℝ) (G : (TwistedWilson.Link N N → TwistedWilson.SU2) → ℝ)
    (hG : Measurable G) :
    (TwistedWilson.ZW N N β false false)⁻¹ *
        ∫ U, G U * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N)
      = ∫ ω, G (WilsonBridgeT.fromBallT N ω)
          ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall)) := by
  rw [integral_wilsonProbT N β (fun ω => G (WilsonBridgeT.fromBallT N ω))
    (hG.comp (WilsonBridgeT.measurable_fromBallT N))]
  simp only [WilsonBridgeT.fromBallT_toBallT]

/-- check `F = 1`: both sides are `1` -/
theorem integral_wilsonProb_one (β : ℝ) :
    ∫ _ω, (1 : ℝ) ∂(TorusRP.wilsonProb N β : Measure (TorusRP.Lk N → TorusRP.QBall)) = 1 := by
  rw [integral_wilsonProb N β (fun _ => 1) measurable_const]
  have h := WilsonBridge.ZW_false_false N β
  simp only [one_mul]
  rw [show (∫ U, Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
      ∂(TwistedWilson.haarCfg N N)) = TwistedWilson.ZW N N β false false from h.symm]
  exact inv_mul_cancel₀ (TwistedWilson.ZW_pos N N β _ _).ne'

end WilsonBridgeP

#print axioms WilsonBridgeP.integral_wilsonProb
#print axioms WilsonBridgeP.integral_wilsonProbT
#print axioms WilsonBridgeP.integral_twisted_wilsonProbT
#print axioms WilsonBridgeP.integral_wilsonProb_one
