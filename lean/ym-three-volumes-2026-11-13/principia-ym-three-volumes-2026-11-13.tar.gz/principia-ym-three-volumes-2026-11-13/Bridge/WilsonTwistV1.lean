import Lattice.TorusDecV2
import Wilson.SU2TwistV2

/-!
# The two SU(2) Wilson measures on the periodic lattice `(ℤ/N)⁴` are the same measure

Two formalisations of the Wilson measure of `SU(2)` on the periodic lattice `(ℤ/N)⁴`:

* `TorusRP.wilsonMeasure N β` : links `Lk N = (Fin 4 → ZMod N) × Fin 4`, link values in the closed
  unit ball `QBall` of the quaternions, reference measure `haarBall` (the Haar measure of the unit
  sphere pushed into the ball), weight `exp(β Σ_{p ∈ plaqs N} Re hol ω p)`, unnormalised.
* `TwistedWilson.ZW N M β n12 n34` : links `Link N M = ((ZMod N × ZMod N) × (ZMod M × ZMod M)) × Fin 4`,
  link values in the unit sphere `SU2`, reference measure `haarCfg` (product of the Haar measures),
  weight `exp(β Σ_B zt B · Re hol U B)`.

The correspondence `toBall N : (Link N N → SU2) → (Lk N → QBall)` is defined by the site map
`x ↦ ((x 0, x 1), (x 2, x 3))` (directions unchanged: direction `μ` of one is direction `μ` of the
other) and the inclusion of the sphere into the ball.  Plaquettes `((x, μ), ν)`, `μ < ν` correspond
to `(siteTo x, ⟨(μ, ν), _⟩)`; both holonomies are `U(x,μ) U(x+e_μ,ν) U(x+e_ν,μ)* U(x,ν)*`.

Main statements:
* `map_toBall` : `toBall` pushes `haarCfg N N` to `Measure.pi (fun _ => haarBall)`.
* `action_toBall` : `TorusRP.action N (toBall N U) = Σ_B Re hol U B`.
* `wilsonMeasure_eq_map` : `wilsonMeasure N β` is the push-forward along `toBall` of
  `haarCfg N N` with density `exp(β Σ_B Re hol U B)`.
* `integral_wilsonMeasure` (bridge B) : `∫ F d(wilsonMeasure N β) = ∫ F(toBall U) e^{β Σ_B Re hol U B} dhaarCfg`
  for every measurable `F`.
* `wilsonMeasure_univ` (bridge A) : `wilsonMeasure N β univ = ENNReal.ofReal (ZW N N β false false)`.
-/

open MeasureTheory

namespace WilsonBridge

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N]

/-! ## sites and links -/

/-- the site map `x ↦ ((x₀, x₁), (x₂, x₃))` -/
def siteTo (x : TorusRP.Site N) : TwistedWilson.Site N N := ((x 0, x 1), (x 2, x 3))

/-- its inverse -/
def siteOf (y : TwistedWilson.Site N N) : TorusRP.Site N := ![y.1.1, y.1.2, y.2.1, y.2.2]

theorem siteOf_siteTo (x : TorusRP.Site N) : siteOf N (siteTo N x) = x := by
  funext i; fin_cases i <;> rfl

theorem siteTo_siteOf (y : TwistedWilson.Site N N) : siteTo N (siteOf N y) = y := rfl

def siteEquiv : TorusRP.Site N ≃ TwistedWilson.Site N N where
  toFun := siteTo N
  invFun := siteOf N
  left_inv := siteOf_siteTo N
  right_inv := siteTo_siteOf N

theorem siteTo_add (x y : TorusRP.Site N) : siteTo N (x + y) = siteTo N x + siteTo N y := rfl

theorem siteTo_ev (μ : Fin 4) : siteTo N (TorusRP.ev N μ) = TwistedWilson.ev N N μ := by
  fin_cases μ <;> simp [siteTo, TorusRP.ev, TwistedWilson.ev, Pi.single_apply]

/-- links: `(x, μ) ↦ (siteTo x, μ)` -/
def linkEquiv : TorusRP.Lk N ≃ TwistedWilson.Link N N := (siteEquiv N).prodCongr (Equiv.refl _)

theorem linkEquiv_apply (x : TorusRP.Site N) (μ : Fin 4) : linkEquiv N (x, μ) = (siteTo N x, μ) := rfl

/-! ## the correspondence of configurations -/

/-- **the correspondence** `e = toBall N`: an `SU2`-configuration of the twisted lattice with `M = N`
gives the ball-valued configuration `ℓ ↦ U (linkEquiv ℓ)` -/
noncomputable def toBall (U : TwistedWilson.Link N N → TwistedWilson.SU2) : TorusRP.Lk N → TorusRP.QBall :=
  fun ℓ => TorusRP.incl (U (linkEquiv N ℓ))

theorem measurable_toBall : Measurable (toBall N) :=
  measurable_pi_lambda _ fun _ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply _)

theorem toBall_injective : Function.Injective (toBall N) := by
  intro U V h
  funext ℓ'
  have h1 := congrFun h ((linkEquiv N).symm ℓ')
  simp only [toBall, Equiv.apply_symm_apply] at h1
  have h2 : ((TorusRP.incl (U ℓ') : TorusRP.QBall) : ℍr) = ((TorusRP.incl (V ℓ') : TorusRP.QBall) : ℍr) :=
    congrArg Subtype.val h1
  exact Subtype.ext h2

/-- **the reference measures agree**: `toBall` pushes `Π Haar` to `Π haarBall` -/
theorem map_toBall :
    Measure.map (toBall N) (TwistedWilson.haarCfg N N)
      = Measure.pi fun _ : TorusRP.Lk N => TorusRP.haarBall := by
  have h1 : MeasurePreserving (MeasurableEquiv.piCongrLeft (fun _ => TwistedWilson.SU2) (linkEquiv N).symm)
      (TwistedWilson.haarCfg N N) (Measure.pi fun _ : TorusRP.Lk N => TwistedWilson.haarSU2) := by
    unfold TwistedWilson.haarCfg
    exact measurePreserving_piCongrLeft (fun _ : TorusRP.Lk N => TwistedWilson.haarSU2) (linkEquiv N).symm
  have hinc : Measurable fun f : TorusRP.Lk N → TwistedWilson.SU2 => fun ℓ => TorusRP.incl (f ℓ) :=
    measurable_pi_lambda _ fun ℓ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply ℓ)
  have hpull : toBall N = (fun f : TorusRP.Lk N → TwistedWilson.SU2 => fun ℓ => TorusRP.incl (f ℓ))
      ∘ (MeasurableEquiv.piCongrLeft (fun _ => TwistedWilson.SU2) (linkEquiv N).symm) := by
    funext U ℓ
    simp only [Function.comp, toBall, LinkReflection.piCongrLeft_const, Equiv.symm_symm]
  rw [hpull, ← Measure.map_map hinc h1.measurable, h1.map_eq,
    Measure.pi_map_pi (fun _ => TorusRP.continuous_incl.measurable.aemeasurable)]
  rfl

/-! ## plaquettes and the action -/

theorem hol_toBall (U : TwistedWilson.Link N N → TwistedWilson.SU2) (x : TorusRP.Site N) (μ ν : Fin 4)
    (h : μ < ν) :
    TorusRP.hol N (toBall N U) ((x, μ), ν) = TwistedWilson.hol N N U (siteTo N x, ⟨(μ, ν), h⟩) := by
  show (U (linkEquiv N (x, μ)) : ℍr) * (U (linkEquiv N (x + TorusRP.ev N μ, ν)) : ℍr)
      * star (U (linkEquiv N (x + TorusRP.ev N ν, μ)) : ℍr) * star (U (linkEquiv N (x, ν)) : ℍr) = _
  simp only [linkEquiv_apply, siteTo_add, siteTo_ev]
  rfl

/-- **the actions agree**: the unoriented plaquettes `μ < ν` of both lattices correspond -/
theorem action_toBall (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    TorusRP.action N (toBall N U) = ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re := by
  unfold TorusRP.action
  refine Finset.sum_bij'
    (fun p hp => (siteTo N p.1.1, ⟨(p.1.2, p.2), (Finset.mem_filter.1 hp).2⟩))
    (fun B _ => ((siteOf N B.1, B.2.1.1), B.2.1.2)) (fun _ _ => Finset.mem_univ _) ?_ ?_ ?_ ?_
  · intro B _
    exact Finset.mem_filter.2 ⟨Finset.mem_univ _, B.2.2⟩
  · rintro ⟨⟨x, μ⟩, ν⟩ _
    show ((siteOf N (siteTo N x), μ), ν) = ((x, μ), ν)
    rw [siteOf_siteTo]
  · rintro ⟨y, ⟨⟨μ, ν⟩, h⟩⟩ _
    rfl
  · rintro ⟨⟨x, μ⟩, ν⟩ hp
    rw [hol_toBall N U x μ ν (Finset.mem_filter.1 hp).2]

/-! ## the bridge -/

/-- the untwisted weight of the twisted side, `exp(β Σ_B Re hol U B)` -/
noncomputable def wTw (β : ℝ) (U : TwistedWilson.Link N N → TwistedWilson.SU2) : ℝ :=
  Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)

theorem wilsonWeight_toBall (β : ℝ) (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    TorusRP.wilsonWeight N β (toBall N U) = wTw N β U := by
  unfold TorusRP.wilsonWeight wTw
  rw [action_toBall]

/-- **the two Wilson measures are one measure**: `TorusRP.wilsonMeasure N β` is the push-forward along
`toBall` of `haarCfg N N` with density `exp(β Σ_B Re hol U B)` (the untwisted weight of `ZW`). -/
theorem wilsonMeasure_eq_map (β : ℝ) :
    TorusRP.wilsonMeasure N β = Measure.map (toBall N)
      ((TwistedWilson.haarCfg N N).withDensity fun U => ENNReal.ofReal (wTw N β U)) := by
  have hG : Measurable fun ω => ((Real.toNNReal (TorusRP.wilsonWeight N β ω)) : ENNReal) :=
    (TorusRP.continuous_wilsonWeight N β).measurable.real_toNNReal.coe_nnreal_ennreal
  ext s hs
  rw [Measure.map_apply (measurable_toBall N) hs, withDensity_apply _ (measurable_toBall N hs),
    TorusRP.wilsonMeasure, withDensity_apply _ hs, ← map_toBall N,
    setLIntegral_map hs hG (measurable_toBall N)]
  refine lintegral_congr fun U => ?_
  show ENNReal.ofReal (TorusRP.wilsonWeight N β (toBall N U)) = _
  rw [wilsonWeight_toBall]

/-- **Bridge B (expectations).**  For every measurable `F` of the ball-valued configurations,
`∫ F d(wilsonMeasure N β) = ∫ F(toBall U) · exp(β Σ_B Re hol U B) d(haarCfg N N)(U)`. -/
theorem integral_wilsonMeasure (β : ℝ) (F : (TorusRP.Lk N → TorusRP.QBall) → ℝ) (hF : Measurable F) :
    ∫ ω, F ω ∂(TorusRP.wilsonMeasure N β)
      = ∫ U, F (toBall N U) * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N) := by
  have hWm : Measurable fun ω => Real.toNNReal (TorusRP.wilsonWeight N β ω) :=
    (TorusRP.continuous_wilsonWeight N β).measurable.real_toNNReal
  have hsm : Measurable fun ω => Real.toNNReal (TorusRP.wilsonWeight N β ω) • F ω := hWm.smul hF
  rw [TorusRP.wilsonMeasure, integral_withDensity_eq_integral_smul hWm, ← map_toBall N,
    integral_map (measurable_toBall N).aemeasurable hsm.aestronglyMeasurable]
  refine integral_congr_ae (Filter.Eventually.of_forall fun U => ?_)
  show Real.toNNReal (TorusRP.wilsonWeight N β (toBall N U)) • F (toBall N U) = _
  rw [NNReal.smul_def, smul_eq_mul, wilsonWeight_toBall]
  unfold wTw
  rw [Real.coe_toNNReal _ (Real.exp_pos _).le]
  exact mul_comm _ _

theorem zt_false_false (B : TwistedWilson.Plaq N N) : TwistedWilson.zt N N false false B = 1 := by
  simp [TwistedWilson.zt, TwistedWilson.tw]

/-- the untwisted `ZW` is the integral of `wTw` -/
theorem ZW_false_false (β : ℝ) :
    TwistedWilson.ZW N N β false false = ∫ U, wTw N β U ∂(TwistedWilson.haarCfg N N) := by
  unfold TwistedWilson.ZW wTw
  simp only [zt_false_false, one_mul]

theorem integrable_wTw (β : ℝ) : Integrable (wTw N β) (TwistedWilson.haarCfg N N) := by
  have hI := TwistedWilson.integrable_exp N N β (TwistedWilson.zt N N false false) (fun _ => 1)
  refine hI.congr (Filter.Eventually.of_forall fun U => ?_)
  simp only [TwistedWilson.Jc, zt_false_false, one_mul, mul_one, wTw, Finset.mul_sum]

/-- **Bridge A (total mass).**  `wilsonMeasure N β univ = ENNReal.ofReal (ZW N N β false false)`. -/
theorem wilsonMeasure_univ (β : ℝ) :
    TorusRP.wilsonMeasure N β Set.univ = ENNReal.ofReal (TwistedWilson.ZW N N β false false) := by
  rw [wilsonMeasure_eq_map N β, Measure.map_apply (measurable_toBall N) MeasurableSet.univ,
    Set.preimage_univ, withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
    ZW_false_false, ofReal_integral_eq_lintegral_ofReal (integrable_wTw N β)
      (Filter.Eventually.of_forall fun U => (Real.exp_pos _).le)]

/-- bridge A, real form -/
theorem wilsonMeasure_real_univ (β : ℝ) :
    (TorusRP.wilsonMeasure N β).real Set.univ = TwistedWilson.ZW N N β false false := by
  rw [measureReal_def, wilsonMeasure_univ, ENNReal.toReal_ofReal (TwistedWilson.ZW_pos N N β _ _).le]

/-- `F = 1` in bridge B gives back the total mass of bridge A -/
theorem integral_one_bridge (β : ℝ) :
    ∫ _ω, (1 : ℝ) ∂(TorusRP.wilsonMeasure N β) = TwistedWilson.ZW N N β false false := by
  rw [integral_wilsonMeasure N β (fun _ => 1) measurable_const, ZW_false_false]
  simp only [one_mul, wTw]

/-- the normalised expectations agree -/
theorem expectation_bridge (β : ℝ) (F : (TorusRP.Lk N → TorusRP.QBall) → ℝ) (hF : Measurable F) :
    (∫ ω, F ω ∂(TorusRP.wilsonMeasure N β)) / (TorusRP.wilsonMeasure N β).real Set.univ
      = (∫ U, F (toBall N U) * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N)) / TwistedWilson.ZW N N β false false := by
  rw [integral_wilsonMeasure N β F hF, wilsonMeasure_real_univ]

/-- degenerate check: at `β = 0` both total masses are `1` -/
theorem wilsonMeasure_univ_zero : TorusRP.wilsonMeasure N 0 Set.univ = 1 := by
  rw [wilsonMeasure_univ, ZW_false_false]
  simp [wTw]

/-! ## the site reflection in the coordinates of the twisted lattice -/

/-- the site reflection `linkRefl (thL N) (sig N)` of the strong-coupling side, written on
`SU2`-configurations of `Link N N`: a link `ℓ'` with direction `0` takes the inverse of the value at the
reflected link, the other links take the value at the reflected link -/
noncomputable def thetaW (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    TwistedWilson.Link N N → TwistedWilson.SU2 := fun ℓ' =>
  if ℓ'.2 = 0 then (U (linkEquiv N (TorusRP.thL N ((linkEquiv N).symm ℓ'))))⁻¹
  else U (linkEquiv N (TorusRP.thL N ((linkEquiv N).symm ℓ')))

theorem refl_toBall (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    LinkReflection.linkRefl (TorusRP.thL N) (TorusRP.sig N) (toBall N U) = toBall N (thetaW N U) := by
  funext ℓ
  show TorusRP.sig N ℓ (TorusRP.incl (U (linkEquiv N (TorusRP.thL N ℓ))))
    = TorusRP.incl (thetaW N U (linkEquiv N ℓ))
  have h2 : (linkEquiv N ℓ).2 = ℓ.2 := rfl
  unfold thetaW TorusRP.sig
  rw [h2, Equiv.symm_apply_apply]
  by_cases h : ℓ.2 = 0
  · rw [if_pos h, if_pos h, TorusRP.starB_incl]
  · rw [if_neg h, if_neg h]; rfl

/-! ## a measurable left inverse of `toBall` -/

/-- the value on the sphere: `q` itself when `‖q‖ = 1`, else `1` -/
noncomputable def projQ (q : TorusRP.QBall) : ℍr := if ‖(q : ℍr)‖ = 1 then (q : ℍr) else 1

theorem projQ_mem (q : TorusRP.QBall) : projQ q ∈ Metric.sphere (0 : ℍr) 1 := by
  rw [mem_sphere_zero_iff_norm]
  unfold projQ
  split_ifs with h
  · exact h
  · exact norm_one

noncomputable def proj (q : TorusRP.QBall) : TwistedWilson.SU2 := ⟨projQ q, projQ_mem q⟩

theorem proj_incl (q : TwistedWilson.SU2) : proj (TorusRP.incl q) = q := by
  apply Subtype.ext
  show projQ (TorusRP.incl q) = (q : ℍr)
  have hq : ‖((TorusRP.incl q : TorusRP.QBall) : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  unfold projQ
  rw [if_pos hq]
  rfl

theorem measurable_proj : Measurable proj := by
  have hQ : Measurable projQ := by
    refine Measurable.ite ?_ continuous_subtype_val.measurable measurable_const
    exact measurableSet_eq_fun (continuous_norm.comp continuous_subtype_val).measurable measurable_const
  have hsub : @Measurable _ _ _ (Subtype.instMeasurableSpace) proj := hQ.subtype_mk
  have heq : (Subtype.instMeasurableSpace : MeasurableSpace TwistedWilson.SU2) = borel TwistedWilson.SU2 :=
    (Subtype.borelSpace (Metric.sphere (0 : ℍr) 1)).measurable_eq
  rw [heq] at hsub
  exact hsub

/-- the left inverse of `toBall` -/
noncomputable def fromBall (ω : TorusRP.Lk N → TorusRP.QBall) : TwistedWilson.Link N N → TwistedWilson.SU2 :=
  fun ℓ' => proj (ω ((linkEquiv N).symm ℓ'))

theorem fromBall_toBall (U : TwistedWilson.Link N N → TwistedWilson.SU2) : fromBall N (toBall N U) = U := by
  funext ℓ'
  simp only [fromBall, toBall, Equiv.apply_symm_apply, proj_incl]

theorem measurable_fromBall : Measurable (fromBall N) :=
  measurable_pi_lambda _ fun _ => measurable_proj.comp (measurable_pi_apply _)

/-- **Bridge B, the other direction**: every measurable `G` of the `SU2`-configurations of the twisted
lattice (`M = N`, no twist) has its `ZW`-weighted integral as a `wilsonMeasure` integral. -/
theorem integral_twisted_eq (β : ℝ) (G : (TwistedWilson.Link N N → TwistedWilson.SU2) → ℝ) (hG : Measurable G) :
    ∫ U, G U * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
        ∂(TwistedWilson.haarCfg N N)
      = ∫ ω, G (fromBall N ω) ∂(TorusRP.wilsonMeasure N β) := by
  rw [integral_wilsonMeasure N β (fun ω => G (fromBall N ω)) (hG.comp (measurable_fromBall N))]
  simp only [fromBall_toBall]

/-- the Wilson measure of the strong-coupling side lives on `SU(2)`-valued configurations -/
theorem ae_sphere (β : ℝ) :
    ∀ᵐ ω ∂(TorusRP.wilsonMeasure N β), ∀ ℓ, ‖((ω ℓ : TorusRP.QBall) : ℍr)‖ = 1 := by
  have hS : MeasurableSet {ω : TorusRP.Lk N → TorusRP.QBall | ∀ ℓ, ‖((ω ℓ : TorusRP.QBall) : ℍr)‖ = 1} := by
    have : {ω : TorusRP.Lk N → TorusRP.QBall | ∀ ℓ, ‖((ω ℓ : TorusRP.QBall) : ℍr)‖ = 1}
        = ⋂ ℓ, {ω | ‖((ω ℓ : TorusRP.QBall) : ℍr)‖ = 1} := by ext; simp
    rw [this]
    exact MeasurableSet.iInter fun ℓ => measurableSet_eq_fun
      ((continuous_norm.comp continuous_subtype_val).measurable.comp (measurable_pi_apply ℓ)) measurable_const
  rw [wilsonMeasure_eq_map N β, ae_map_iff (measurable_toBall N).aemeasurable hS]
  exact Filter.Eventually.of_forall fun U ℓ => mem_sphere_zero_iff_norm.mp (U (linkEquiv N ℓ)).2

/-- **Site reflection positivity in the language of the twisted lattice** (`M = N = 2K`, no twist,
every real `β`).  `TorusRP.wilson_rp` transported along the bridge: for `g` bounded, measurable,
depending only on the links `linkEquiv ℓ` of the closed positive half (`fixP ∨ posP` of the
strong-coupling side),
`0 ≤ ∫ g(thetaW U) g(U) exp(β Σ_B Re hol U B) d(haarCfg N N)(U)`. -/
theorem twisted_rp (K : ℕ) (hN : N = 2 * K) (β : ℝ)
    (g : (TwistedWilson.Link N N → TwistedWilson.SU2) → ℝ) (hg : Measurable g)
    (C : ℝ) (hgC : ∀ U, |g U| ≤ C)
    (hgdep : ∀ U V, (∀ ℓ, TorusRP.fixP N K ℓ ∨ TorusRP.posP N K ℓ →
      U (linkEquiv N ℓ) = V (linkEquiv N ℓ)) → g U = g V) :
    0 ≤ ∫ U, g (thetaW N U) * g U
        * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
        ∂(TwistedWilson.haarCfg N N) := by
  set f : (TorusRP.Lk N → TorusRP.QBall) → ℝ := fun ω => g (fromBall N ω) with hfdef
  have hf : Measurable f := hg.comp (measurable_fromBall N)
  have hfdep : ∀ ω ω', (∀ ℓ, TorusRP.fixP N K ℓ ∨ TorusRP.posP N K ℓ → ω ℓ = ω' ℓ) → f ω = f ω' := by
    intro ω ω' h
    refine hgdep _ _ fun ℓ hℓ => ?_
    simp only [fromBall, Equiv.symm_apply_apply, h ℓ hℓ]
  have hRP := TorusRP.wilson_rp N K hN β f hf C (fun ω => hgC _) hfdep
  have hm : Measurable fun ω => f (LinkReflection.linkRefl (TorusRP.thL N) (TorusRP.sig N) ω) * f ω :=
    (hf.comp (TorusRP.linkRefl_preserving N).measurable).mul hf
  rw [integral_wilsonMeasure N β _ hm] at hRP
  simpa only [hfdef, refl_toBall, fromBall_toBall] using hRP

end WilsonBridge

#print axioms WilsonBridge.map_toBall
#print axioms WilsonBridge.action_toBall
#print axioms WilsonBridge.toBall_injective
#print axioms WilsonBridge.wilsonMeasure_eq_map
#print axioms WilsonBridge.integral_wilsonMeasure
#print axioms WilsonBridge.wilsonMeasure_univ
#print axioms WilsonBridge.wilsonMeasure_real_univ
#print axioms WilsonBridge.integral_one_bridge
#print axioms WilsonBridge.expectation_bridge
#print axioms WilsonBridge.wilsonMeasure_univ_zero
#print axioms WilsonBridge.refl_toBall
#print axioms WilsonBridge.fromBall_toBall
#print axioms WilsonBridge.integral_twisted_eq
#print axioms WilsonBridge.ae_sphere
#print axioms WilsonBridge.twisted_rp
