import Bridge.WilsonTwistV1
import Blocks.ThickFloorHalfSplitV1

/-!
# The bridge with the time directions aligned

`Bridge.WilsonTwistV1` identifies direction `μ` of `TorusRP.Lk N` with direction `μ` of
`TwistedWilson.Link N N`.  The strong-coupling side calls direction `0` time (its site reflection is
`x₀ ↦ −x₀`), the vortex side calls direction `3` (`x₄`) time (`HalfSplit.Th` reflects `x₄ ↦ −x₄`).
Here the correspondence sends direction `0` to direction `3` and `k` to `k − 1` (`dirT = ![3,0,1,2]`),
sites `x ↦ ((x₁, x₂), (x₃, x₀))`.  A plaquette `(x; 0, ν)` of one side is the plaquette
`(siteT x; ν − 1, 3)` of the other with the opposite orientation (`Re` is unchanged).

* `wilsonMeasure_eq_mapT`, `integral_wilsonMeasureT`, `wilsonMeasure_univT` : the bridge (measure,
  expectations, total mass) along this correspondence.
* `refl_toBallT` : the site reflection of the strong-coupling side is `HalfSplit.Th N N` (the
  `x₄`-reflection of the vortex side): `linkRefl thL sig (toBallT U) = toBallT (HalfSplit.Th N N U)`.
* `twisted_rpT` : `TorusRP.wilson_rp` stated with `HalfSplit.Th` and the untwisted `ZW`-weight.
-/

open MeasureTheory

namespace WilsonBridgeT

local notation "ℍr" => Quaternion ℝ

/-! ## directions -/

def dirT : Fin 4 → Fin 4 := ![3, 0, 1, 2]
def dirTi : Fin 4 → Fin 4 := ![1, 2, 3, 0]

theorem dirTi_dirT (μ : Fin 4) : dirTi (dirT μ) = μ := by fin_cases μ <;> rfl
theorem dirT_dirTi (a : Fin 4) : dirT (dirTi a) = a := by fin_cases a <;> rfl

theorem dirT_lt_three : ∀ ν : Fin 4, ν ≠ 0 → dirT ν < 3 := by decide
theorem dirT_mono : ∀ μ ν : Fin 4, μ < ν → μ ≠ 0 → dirT μ < dirT ν := by decide
theorem dirT_eq_three : ∀ μ : Fin 4, dirT μ = 3 ↔ μ = 0 := by decide
theorem dirTi_pos : ∀ a b : Fin 4, a < b → b = 3 → 0 < dirTi a := by decide
theorem dirTi_mono : ∀ a b : Fin 4, a < b → b ≠ 3 → dirTi a < dirTi b := by decide
theorem dirTi_ne_zero : ∀ a b : Fin 4, a < b → b ≠ 3 → dirTi a ≠ 0 := by decide

variable (N : ℕ) [NeZero N]

/-! ## sites and links -/

def siteT (x : TorusRP.Site N) : TwistedWilson.Site N N := ((x 1, x 2), (x 3, x 0))
def siteTi (y : TwistedWilson.Site N N) : TorusRP.Site N := ![y.2.2, y.1.1, y.1.2, y.2.1]

theorem siteTi_siteT (x : TorusRP.Site N) : siteTi N (siteT N x) = x := by
  funext i; fin_cases i <;> rfl

theorem siteT_siteTi (y : TwistedWilson.Site N N) : siteT N (siteTi N y) = y := rfl

theorem siteT_add (x y : TorusRP.Site N) : siteT N (x + y) = siteT N x + siteT N y := rfl

theorem siteT_ev (μ : Fin 4) : siteT N (TorusRP.ev N μ) = TwistedWilson.ev N N (dirT μ) := by
  fin_cases μ <;> simp [siteT, TorusRP.ev, TwistedWilson.ev, dirT, Pi.single_apply]

def linkT : TorusRP.Lk N ≃ TwistedWilson.Link N N where
  toFun ℓ := (siteT N ℓ.1, dirT ℓ.2)
  invFun ℓ' := (siteTi N ℓ'.1, dirTi ℓ'.2)
  left_inv ℓ := by
    obtain ⟨x, μ⟩ := ℓ
    show (siteTi N (siteT N x), dirTi (dirT μ)) = (x, μ)
    rw [siteTi_siteT, dirTi_dirT]
  right_inv ℓ' := by
    obtain ⟨y, a⟩ := ℓ'
    show (siteT N (siteTi N y), dirT (dirTi a)) = (y, a)
    rw [siteT_siteTi, dirT_dirTi]

theorem linkT_apply (x : TorusRP.Site N) (μ : Fin 4) : linkT N (x, μ) = (siteT N x, dirT μ) := rfl

/-- **the time-aligned correspondence** -/
noncomputable def toBallT (U : TwistedWilson.Link N N → TwistedWilson.SU2) : TorusRP.Lk N → TorusRP.QBall :=
  fun ℓ => TorusRP.incl (U (linkT N ℓ))

theorem measurable_toBallT : Measurable (toBallT N) :=
  measurable_pi_lambda _ fun _ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply _)

theorem map_toBallT :
    Measure.map (toBallT N) (TwistedWilson.haarCfg N N)
      = Measure.pi fun _ : TorusRP.Lk N => TorusRP.haarBall := by
  have h1 : MeasurePreserving (MeasurableEquiv.piCongrLeft (fun _ => TwistedWilson.SU2) (linkT N).symm)
      (TwistedWilson.haarCfg N N) (Measure.pi fun _ : TorusRP.Lk N => TwistedWilson.haarSU2) := by
    unfold TwistedWilson.haarCfg
    exact measurePreserving_piCongrLeft (fun _ : TorusRP.Lk N => TwistedWilson.haarSU2) (linkT N).symm
  have hinc : Measurable fun f : TorusRP.Lk N → TwistedWilson.SU2 => fun ℓ => TorusRP.incl (f ℓ) :=
    measurable_pi_lambda _ fun ℓ => TorusRP.continuous_incl.measurable.comp (measurable_pi_apply ℓ)
  have hpull : toBallT N = (fun f : TorusRP.Lk N → TwistedWilson.SU2 => fun ℓ => TorusRP.incl (f ℓ))
      ∘ (MeasurableEquiv.piCongrLeft (fun _ => TwistedWilson.SU2) (linkT N).symm) := by
    funext U ℓ
    simp only [Function.comp, toBallT, LinkReflection.piCongrLeft_const, Equiv.symm_symm]
  rw [hpull, ← Measure.map_map hinc h1.measurable, h1.map_eq,
    Measure.pi_map_pi (fun _ => TorusRP.continuous_incl.measurable.aemeasurable)]
  rfl

/-! ## plaquettes -/

theorem re_reverse (a b c d : ℍr) : (d * c * star b * star a).re = (a * b * star c * star d).re := by
  have h : star (a * b * star c * star d) = d * c * star b * star a := by
    simp only [star_mul, star_star, mul_assoc]
  rw [← h, Quaternion.re_star]

theorem hol_toBallT (U : TwistedWilson.Link N N → TwistedWilson.SU2) (x : TorusRP.Site N) (μ ν : Fin 4) :
    TorusRP.hol N (toBallT N U) ((x, μ), ν)
      = (U (siteT N x, dirT μ) : ℍr) * (U (siteT N x + TwistedWilson.ev N N (dirT μ), dirT ν) : ℍr)
        * star (U (siteT N x + TwistedWilson.ev N N (dirT ν), dirT μ) : ℍr)
        * star (U (siteT N x, dirT ν) : ℍr) := by
  show (U (linkT N (x, μ)) : ℍr) * (U (linkT N (x + TorusRP.ev N μ, ν)) : ℍr)
      * star (U (linkT N (x + TorusRP.ev N ν, μ)) : ℍr) * star (U (linkT N (x, ν)) : ℍr) = _
  simp only [linkT_apply, siteT_add, siteT_ev]

theorem hol_tw (U : TwistedWilson.Link N N → TwistedWilson.SU2) (y : TwistedWilson.Site N N) (a b : Fin 4)
    (h : a < b) :
    TwistedWilson.hol N N U (y, ⟨(a, b), h⟩)
      = (U (y, a) : ℍr) * (U (y + TwistedWilson.ev N N a, b) : ℍr)
        * star (U (y + TwistedWilson.ev N N b, a) : ℍr) * star (U (y, b) : ℍr) := rfl

/-- the plaquette map: `(x; 0, ν) ↦ (siteT x; dirT ν, 3)`, `(x; μ, ν) ↦ (siteT x; dirT μ, dirT ν)` for `μ ≠ 0` -/
def plaqT (p : TorusRP.Lk N × Fin 4) (hp : p.1.2 < p.2) : TwistedWilson.Plaq N N :=
  if h0 : p.1.2 = 0 then (siteT N p.1.1, ⟨(dirT p.2, 3), dirT_lt_three _ (by
      intro h; simp [h, h0] at hp)⟩)
  else (siteT N p.1.1, ⟨(dirT p.1.2, dirT p.2), dirT_mono _ _ hp h0⟩)

def plaqTi (B : TwistedWilson.Plaq N N) : TorusRP.Lk N × Fin 4 :=
  if B.2.1.2 = 3 then ((siteTi N B.1, 0), dirTi B.2.1.1)
  else ((siteTi N B.1, dirTi B.2.1.1), dirTi B.2.1.2)

theorem action_toBallT (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    TorusRP.action N (toBallT N U) = ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re := by
  unfold TorusRP.action
  refine Finset.sum_bij' (fun p hp => plaqT N p (Finset.mem_filter.1 hp).2)
    (fun B _ => plaqTi N B) (fun _ _ => Finset.mem_univ _) ?_ ?_ ?_ ?_
  · rintro ⟨y, ⟨⟨a, b⟩, hab⟩⟩ _
    refine Finset.mem_filter.2 ⟨Finset.mem_univ _, ?_⟩
    unfold plaqTi
    by_cases hb : b = 3
    · rw [if_pos hb]; exact dirTi_pos a b hab hb
    · rw [if_neg hb]; exact dirTi_mono a b hab hb
  · rintro ⟨⟨x, μ⟩, ν⟩ hp
    have hlt : μ < ν := (Finset.mem_filter.1 hp).2
    unfold plaqT plaqTi
    by_cases h0 : μ = 0
    · subst h0
      simp only [dif_pos, if_pos, siteTi_siteT, dirTi_dirT]
    · have h3 : dirT ν ≠ 3 := fun h => by
        rw [dirT_eq_three] at h; rw [h] at hlt; exact absurd hlt (Fin.not_lt_zero μ)
      simp only [dif_neg h0, if_neg h3, siteTi_siteT, dirTi_dirT]
  · rintro ⟨y, ⟨⟨a, b⟩, hab⟩⟩ _
    unfold plaqT plaqTi
    by_cases hb : b = 3
    · subst hb
      simp only [if_pos, dif_pos, siteT_siteTi, dirT_dirTi]
    · have ha0 : dirTi a ≠ 0 := dirTi_ne_zero a b hab hb
      simp only [if_neg hb, dif_neg ha0, siteT_siteTi, dirT_dirTi]
  · rintro ⟨⟨x, μ⟩, ν⟩ hp
    have hlt : μ < ν := (Finset.mem_filter.1 hp).2
    rw [hol_toBallT]
    unfold plaqT
    by_cases h0 : μ = 0
    · subst h0
      simp only [dif_pos]
      rw [hol_tw]
      have e3 : dirT 0 = 3 := rfl
      rw [e3, ← re_reverse]
    · simp only [dif_neg h0]
      rw [hol_tw]

/-! ## the bridge, time-aligned -/

theorem wilsonWeight_toBallT (β : ℝ) (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    TorusRP.wilsonWeight N β (toBallT N U) = WilsonBridge.wTw N β U := by
  unfold TorusRP.wilsonWeight WilsonBridge.wTw
  rw [action_toBallT]

theorem wilsonMeasure_eq_mapT (β : ℝ) :
    TorusRP.wilsonMeasure N β = Measure.map (toBallT N)
      ((TwistedWilson.haarCfg N N).withDensity fun U => ENNReal.ofReal (WilsonBridge.wTw N β U)) := by
  have hG : Measurable fun ω => ((Real.toNNReal (TorusRP.wilsonWeight N β ω)) : ENNReal) :=
    (TorusRP.continuous_wilsonWeight N β).measurable.real_toNNReal.coe_nnreal_ennreal
  ext s hs
  rw [Measure.map_apply (measurable_toBallT N) hs, withDensity_apply _ (measurable_toBallT N hs),
    TorusRP.wilsonMeasure, withDensity_apply _ hs, ← map_toBallT N,
    setLIntegral_map hs hG (measurable_toBallT N)]
  refine lintegral_congr fun U => ?_
  show ENNReal.ofReal (TorusRP.wilsonWeight N β (toBallT N U)) = _
  rw [wilsonWeight_toBallT]

/-- **Bridge B, time-aligned.** -/
theorem integral_wilsonMeasureT (β : ℝ) (F : (TorusRP.Lk N → TorusRP.QBall) → ℝ) (hF : Measurable F) :
    ∫ ω, F ω ∂(TorusRP.wilsonMeasure N β)
      = ∫ U, F (toBallT N U) * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
          ∂(TwistedWilson.haarCfg N N) := by
  have hWm : Measurable fun ω => Real.toNNReal (TorusRP.wilsonWeight N β ω) :=
    (TorusRP.continuous_wilsonWeight N β).measurable.real_toNNReal
  have hsm : Measurable fun ω => Real.toNNReal (TorusRP.wilsonWeight N β ω) • F ω := hWm.smul hF
  rw [TorusRP.wilsonMeasure, integral_withDensity_eq_integral_smul hWm, ← map_toBallT N,
    integral_map (measurable_toBallT N).aemeasurable hsm.aestronglyMeasurable]
  refine integral_congr_ae (Filter.Eventually.of_forall fun U => ?_)
  show Real.toNNReal (TorusRP.wilsonWeight N β (toBallT N U)) • F (toBallT N U) = _
  rw [NNReal.smul_def, smul_eq_mul, wilsonWeight_toBallT]
  unfold WilsonBridge.wTw
  rw [Real.coe_toNNReal _ (Real.exp_pos _).le]
  exact mul_comm _ _

/-- **Bridge A, time-aligned.** -/
theorem wilsonMeasure_univT (β : ℝ) :
    TorusRP.wilsonMeasure N β Set.univ = ENNReal.ofReal (TwistedWilson.ZW N N β false false) := by
  rw [wilsonMeasure_eq_mapT N β, Measure.map_apply (measurable_toBallT N) MeasurableSet.univ,
    Set.preimage_univ, withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
    WilsonBridge.ZW_false_false, ofReal_integral_eq_lintegral_ofReal (WilsonBridge.integrable_wTw N β)
      (Filter.Eventually.of_forall fun U => (Real.exp_pos _).le)]

/-! ## the two site reflections are one -/

theorem siteT_thS_time (x : TorusRP.Site N) :
    siteT N (TorusRP.thS N x - TorusRP.ev N 0) = HalfSplit.rS N N (siteT N x + TwistedWilson.ev N N 3) := by
  simp only [siteT, TorusRP.thS, TorusRP.ev, HalfSplit.rS, TwistedWilson.ev]
  ext <;> simp [TorusRP.thS, Pi.single_apply] <;> abel

theorem siteT_thS (x : TorusRP.Site N) : siteT N (TorusRP.thS N x) = HalfSplit.rS N N (siteT N x) := by
  simp only [siteT, TorusRP.thS, HalfSplit.rS]
  ext <;> simp

/-- **the site reflection of the strong-coupling side is the `x₄`-reflection `HalfSplit.Th` of the
vortex side** (time-aligned correspondence) -/
theorem refl_toBallT (U : TwistedWilson.Link N N → TwistedWilson.SU2) :
    LinkReflection.linkRefl (TorusRP.thL N) (TorusRP.sig N) (toBallT N U) = toBallT N (HalfSplit.Th N N U) := by
  funext ℓ
  obtain ⟨x, μ⟩ := ℓ
  show TorusRP.sig N (x, μ) (TorusRP.incl (U (linkT N (TorusRP.thL N (x, μ)))))
    = TorusRP.incl (HalfSplit.sgL N N (linkT N (x, μ)) (U (HalfSplit.thL N N (linkT N (x, μ)))))
  by_cases h0 : μ = 0
  · subst h0
    have hl0 : TorusRP.thL N (x, 0) = (TorusRP.thS N x - TorusRP.ev N 0, 0) := if_pos rfl
    have hr0 : HalfSplit.thL N N (siteT N x, 3) = (HalfSplit.rS N N (siteT N x + TwistedWilson.ev N N 3), 3) :=
      if_pos rfl
    have hs0 : TorusRP.sig N (x, 0) = TorusRP.starB := if_pos rfl
    have hg0 : HalfSplit.sgL N N (siteT N x, 3) = Inv.inv := if_pos rfl
    have hd : dirT 0 = 3 := rfl
    rw [hl0, linkT_apply, linkT_apply, hd, hr0, hs0, hg0, siteT_thS_time, TorusRP.starB_incl]
  · have h3 : dirT μ ≠ 3 := fun h => h0 ((dirT_eq_three μ).1 h)
    have hl : TorusRP.thL N (x, μ) = (TorusRP.thS N x, μ) := if_neg h0
    have hr : HalfSplit.thL N N (siteT N x, dirT μ) = (HalfSplit.rS N N (siteT N x), dirT μ) := if_neg h3
    have hs : TorusRP.sig N (x, μ) = id := if_neg h0
    have hg : HalfSplit.sgL N N (siteT N x, dirT μ) = id := if_neg h3
    rw [hl, linkT_apply, linkT_apply, hr, hs, hg, siteT_thS]
    rfl

/-- the left inverse of `toBallT` -/
noncomputable def fromBallT (ω : TorusRP.Lk N → TorusRP.QBall) : TwistedWilson.Link N N → TwistedWilson.SU2 :=
  fun ℓ' => WilsonBridge.proj (ω ((linkT N).symm ℓ'))

theorem fromBallT_toBallT (U : TwistedWilson.Link N N → TwistedWilson.SU2) : fromBallT N (toBallT N U) = U := by
  funext ℓ'
  simp only [fromBallT, toBallT, Equiv.apply_symm_apply, WilsonBridge.proj_incl]

theorem measurable_fromBallT : Measurable (fromBallT N) :=
  measurable_pi_lambda _ fun _ => WilsonBridge.measurable_proj.comp (measurable_pi_apply _)

/-- **`TorusRP.wilson_rp` in the language of the vortex side** (time-aligned; `N = 2K`, no twist,
every real `β`): for `g` bounded, measurable, depending only on the links `linkT ℓ` with `ℓ` in the
closed positive half of the strong-coupling side,
`0 ≤ ∫ g(HalfSplit.Th U) g(U) exp(β Σ_B Re hol U B) d(haarCfg N N)(U)`. -/
theorem twisted_rpT (K : ℕ) (hN : N = 2 * K) (β : ℝ)
    (g : (TwistedWilson.Link N N → TwistedWilson.SU2) → ℝ) (hg : Measurable g)
    (C : ℝ) (hgC : ∀ U, |g U| ≤ C)
    (hgdep : ∀ U V, (∀ ℓ, TorusRP.fixP N K ℓ ∨ TorusRP.posP N K ℓ →
      U (linkT N ℓ) = V (linkT N ℓ)) → g U = g V) :
    0 ≤ ∫ U, g (HalfSplit.Th N N U) * g U
        * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
        ∂(TwistedWilson.haarCfg N N) := by
  set f : (TorusRP.Lk N → TorusRP.QBall) → ℝ := fun ω => g (fromBallT N ω) with hfdef
  have hf : Measurable f := hg.comp (measurable_fromBallT N)
  have hfdep : ∀ ω ω', (∀ ℓ, TorusRP.fixP N K ℓ ∨ TorusRP.posP N K ℓ → ω ℓ = ω' ℓ) → f ω = f ω' := by
    intro ω ω' h
    refine hgdep _ _ fun ℓ hℓ => ?_
    simp only [fromBallT, Equiv.symm_apply_apply, h ℓ hℓ]
  have hRP := TorusRP.wilson_rp N K hN β f hf C (fun ω => hgC _) hfdep
  have hm : Measurable fun ω => f (LinkReflection.linkRefl (TorusRP.thL N) (TorusRP.sig N) ω) * f ω :=
    (hf.comp (TorusRP.linkRefl_preserving N).measurable).mul hf
  rw [integral_wilsonMeasureT N β _ hm] at hRP
  simpa only [hfdef, refl_toBallT, fromBallT_toBallT] using hRP

/-- the hypotheses of `twisted_rpT` are met by a non-constant `g`: `N = 2`, `K = 1`,
`g U = Re U(ℓ₀)` for the link `ℓ₀ = linkT (0, 1)` (direction `x₁` at the site `0`, in the plane `x₄ = 0`) -/
theorem twisted_rpT_witness (β : ℝ) :
    0 ≤ ∫ U, (HalfSplit.Th 2 2 U (linkT 2 (0, 1)) : ℍr).re * (U (linkT 2 (0, 1)) : ℍr).re
        * Real.exp (β * ∑ B : TwistedWilson.Plaq 2 2, (TwistedWilson.hol 2 2 U B).re)
        ∂(TwistedWilson.haarCfg 2 2) := by
  have hc : Continuous fun U : TwistedWilson.Link 2 2 → TwistedWilson.SU2 =>
      ((U (linkT 2 (0, 1)) : TwistedWilson.SU2) : ℍr).re :=
    Quaternion.continuous_re.comp (continuous_subtype_val.comp (continuous_apply (linkT 2 (0, 1))))
  have hC : ∀ U : TwistedWilson.Link 2 2 → TwistedWilson.SU2, |(U (linkT 2 (0, 1)) : ℍr).re| ≤ 1 :=
    fun U => TwistedWilson.abs_re_le_one _ (mem_sphere_zero_iff_norm.mp (U _).2)
  have hfix : TorusRP.fixP 2 1 ((0 : TorusRP.Site 2), (1 : Fin 4)) := by
    refine ⟨by decide, Or.inl ?_⟩
    rfl
  exact twisted_rpT 2 1 rfl β (fun U => (U (linkT 2 (0, 1)) : ℍr).re) hc.measurable 1 hC
    (fun U V h => congrArg (fun q : TwistedWilson.SU2 => (q : ℍr).re) (h _ (Or.inl hfix)))

/-! ## the closed positive halves agree -/

theorem fixL_linkT (K : ℕ) (hN : N = 2 * K) (x : TorusRP.Site N) (μ : Fin 4)
    (h : HalfSplit.fixL N N (linkT N (x, μ))) : TorusRP.fixP N K (x, μ) := by
  obtain ⟨h3, ht⟩ := h
  refine ⟨fun h0 => h3 ((dirT_eq_three μ).2 h0), ?_⟩
  change (x 0).val = 0 ∨ 2 * (x 0).val = N at ht
  show (x 0).val = 0 ∨ (x 0).val = K
  omega

theorem posL_linkT (K : ℕ) (hN : N = 2 * K) (x : TorusRP.Site N) (μ : Fin 4)
    (h : HalfSplit.posL N N (linkT N (x, μ))) : TorusRP.posP N K (x, μ) := by
  change (dirT μ ≠ 3 ∧ 0 < (x 0).val ∧ 2 * (x 0).val < N) ∨ (dirT μ = 3 ∧ 2 * (x 0).val < N) at h
  show (if μ = 0 then (x 0).val < K else (0 < (x 0).val ∧ (x 0).val < K))
  by_cases h0 : μ = 0
  · have h3 : dirT μ = 3 := (dirT_eq_three μ).2 h0
    rw [if_pos h0]
    rcases h with ⟨h3', _⟩ | ⟨_, h2⟩
    · exact absurd h3 h3'
    · omega
  · have h3 : dirT μ ≠ 3 := fun h => h0 ((dirT_eq_three μ).1 h)
    rw [if_neg h0]
    rcases h with ⟨_, h1, h2⟩ | ⟨h3', _⟩
    · exact ⟨h1, by omega⟩
    · exact absurd h3' h3

/-- **Site reflection positivity of the untwisted Wilson weight, stated entirely on the vortex side**
(`N = 2K`, every real `β`): for `g` bounded, measurable, depending only on the links of the closed
upper half `fixL ∨ posL` of `HalfSplit` (with `M = N`),
`0 ≤ ∫ g(HalfSplit.Th U) g(U) exp(β Σ_B Re hol U B) d(haarCfg N N)(U)`.
Obtained from `TorusRP.wilson_rp` through the time-aligned bridge. -/
theorem wilson_rp_vortexSide (K : ℕ) (hN : N = 2 * K) (β : ℝ)
    (g : (TwistedWilson.Link N N → TwistedWilson.SU2) → ℝ) (hg : Measurable g)
    (C : ℝ) (hgC : ∀ U, |g U| ≤ C)
    (hgdep : ∀ U V, (∀ ℓ', HalfSplit.fixL N N ℓ' ∨ HalfSplit.posL N N ℓ' → U ℓ' = V ℓ') → g U = g V) :
    0 ≤ ∫ U, g (HalfSplit.Th N N U) * g U
        * Real.exp (β * ∑ B : TwistedWilson.Plaq N N, (TwistedWilson.hol N N U B).re)
        ∂(TwistedWilson.haarCfg N N) := by
  refine twisted_rpT N K hN β g hg C hgC (fun U V h => hgdep U V (fun ℓ' hℓ' => ?_))
  obtain ⟨⟨x, μ⟩, rfl⟩ : ∃ ℓ, linkT N ℓ = ℓ' := (linkT N).surjective ℓ'
  rcases hℓ' with hf | hp
  · exact h _ (Or.inl (fixL_linkT N K hN x μ hf))
  · exact h _ (Or.inr (posL_linkT N K hN x μ hp))

end WilsonBridgeT

#print axioms WilsonBridgeT.action_toBallT
#print axioms WilsonBridgeT.map_toBallT
#print axioms WilsonBridgeT.wilsonMeasure_eq_mapT
#print axioms WilsonBridgeT.integral_wilsonMeasureT
#print axioms WilsonBridgeT.wilsonMeasure_univT
#print axioms WilsonBridgeT.refl_toBallT
#print axioms WilsonBridgeT.twisted_rpT
#print axioms WilsonBridgeT.twisted_rpT_witness
#print axioms WilsonBridgeT.wilson_rp_vortexSide
