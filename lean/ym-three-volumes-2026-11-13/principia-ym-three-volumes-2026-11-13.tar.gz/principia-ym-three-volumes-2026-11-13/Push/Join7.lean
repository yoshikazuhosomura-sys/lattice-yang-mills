import Push.Herm1

/-! # One statement: the lattice face covariance, its identification with `posC N m`, and `Λ ≤ 640/9`

`LatticeFace.faceCov m N` (defined in `Push.Lat2`): the covariance of the lattice field strength
`(curl A)_p(X) = (A_a(X + e_b) − A_a(X)) − (A_b(X + e_a) − A_b(X))` (`curl_apply`) on `(ℤ/N)⁴`, where `A` is the free
lattice vector field in the Feynman gauge on `(ℤ/(2^m N))⁴` (covariance diagonal in the characters with eigenvalue
`λ(ψ)⁻¹`, `λ` the eigenvalue of `−Δ`, `lap_char`; constant mode removed) pushed `m` times by the block average with
the path kernel (`T ↦ C T C†`). -/

noncomputable section

namespace LatticeFace

/-- **T1h on the lattice object.** For `N ≥ 2` and every `m`: the face covariance `faceCov m N` is self-adjoint,
equals `TorusPos.posC N m` after relabelling the sites, and its Rayleigh top `latLamMax`, diagonal entries `latDiag`
satisfy `latLamMax ≤ 1`, `latDiag ≥ (c₀/2)(1 − N⁻⁴)` (`c₀ = 3/100`), `latDiag ≤ latLamMax`,
`latLamMax/latDiag ≤ 640/9`, at every site `X₀` and face `p`. No hypothesis. -/
theorem lattice_face_T1h {N : ℕ} [NeZero N] (hN : 2 ≤ N) (m : ℕ) :
    SelfAdj (faceCov m N) ∧
    (∀ y, ofLat N (faceCov m N (toLat N y)) = TorusPos.posC N m y) ∧
    (∀ z : Fld6 N, latQ m N z ≤ latNorm N z) ∧ latLamMax m N ≤ 1 ∧
    ∀ (X₀ : Fin 4 → ZMod N) (p : Fin 6),
      (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ latDiag m N X₀ p ∧
      latDiag m N X₀ p ≤ latLamMax m N ∧ latLamMax m N / latDiag m N X₀ p ≤ 640 / 9 := by
  have h0 := lattice_face_lambda hN m 0 0
  refine ⟨faceCov_selfAdj m N, faceCov_eq_posC m, h0.1, h0.2.1, fun X₀ p => ?_⟩
  obtain ⟨-, -, h3, h4, h5⟩ := lattice_face_lambda hN m X₀ p
  exact ⟨h3, h4, h5⟩

end LatticeFace

end

#print axioms LatticeFace.lattice_face_T1h
#print axioms T1h.t1h_lattice
