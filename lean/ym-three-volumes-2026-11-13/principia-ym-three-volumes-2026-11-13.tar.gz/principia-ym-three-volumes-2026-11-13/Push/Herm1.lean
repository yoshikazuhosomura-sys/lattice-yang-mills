import Push.Final7

/-! # The lattice face covariance is self-adjoint

`pair a b = Σ_X Σ_i conj(a_i(X)) b_i(X)`. The free covariance is self-adjoint (its eigenvalues `λ(ψ)⁻¹` are real),
each step `T ↦ C T C†` keeps self-adjointness (`TorusFourier.Cop_adjoint`), hence `stageCov m N` and
`faceCov m N = curl ∘ stageCov m N ∘ curl†` are self-adjoint (`faceCov_selfAdj`). -/

noncomputable section

namespace LatticeFace

open Complex Finset TorusFourier LatticePath LatticeTorus LatticePush
open scoped ComplexConjugate

def pair {G ι : Type*} [Fintype G] [Fintype ι] (a b : G → ι → ℂ) : ℂ := ∑ X, ∑ i, conj (a X i) * b X i

def SelfAdj {G ι : Type*} [Fintype G] [Fintype ι] (T : (G → ι → ℂ) → (G → ι → ℂ)) : Prop :=
  ∀ a b, pair a (T b) = pair (T a) b

theorem pair_conj {G ι : Type*} [Fintype G] [Fintype ι] (a b : G → ι → ℂ) : conj (pair a b) = pair b a := by
  simp only [pair, map_sum, map_mul, Complex.conj_conj]
  exact Finset.sum_congr rfl fun X _ => Finset.sum_congr rfl fun i _ => mul_comm _ _

section Adj

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

theorem pair_Cop (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (a : F → ι → ℂ) :
    pair w (Cop β c a) = pair (Cadj β c w) a := Cop_adjoint β c a w

theorem pair_Cop' (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (a : F → ι → ℂ) :
    pair (Cop β c a) w = pair a (Cadj β c w) := by
  rw [← pair_conj, pair_Cop, pair_conj]

end Adj

theorem stepOp_selfAdj (L : ℕ) [NeZero L] (T : Fld (2 * L) → Fld (2 * L)) (hT : SelfAdj T) :
    SelfAdj (stepOp L T) := by
  intro a b
  unfold stepOp
  rw [pair_Cop, hT, pair_Cop']

theorem pushOp_selfAdj (m : ℕ) : ∀ (L : ℕ) [NeZero L] (T : Fld (fine m L) → Fld (fine m L)),
    SelfAdj T → SelfAdj (pushOp m L T) := by
  induction m with
  | zero => intro L _ T h; exact h
  | succ m ih =>
    intro L _ T h
    rw [pushOp_succ]
    exact stepOp_selfAdj L _ (ih (2 * L) T h)

theorem pair_freeCov (N : ℕ) [NeZero N] (a b : Fld N) :
    pair a (freeCov N b) = (Fintype.card (Fin 4 → ZMod N) : ℂ)⁻¹ *
      ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, (((lapEig N ψ)⁻¹ : ℝ) : ℂ) *
        ∑ μ, conj (ftv a ψ μ) * ftv b ψ μ := by
  have hc : ∀ ψ μ, conj (ftv a ψ μ) = ∑ X, ψ X * conj (a X μ) := fun ψ μ => conj_ft _ ψ
  simp only [hc]
  unfold pair freeCov
  set c : ℂ := (Fintype.card (Fin 4 → ZMod N) : ℂ)⁻¹
  calc ∑ X, ∑ μ, conj (a X μ) * (c * ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ,
          ψ X * (((lapEig N ψ)⁻¹ : ℝ) : ℂ) * ftv b ψ μ)
      = ∑ X, ∑ μ, ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ,
          c * ((((lapEig N ψ)⁻¹ : ℝ) : ℂ) * (ψ X * conj (a X μ) * ftv b ψ μ)) := by
        refine Finset.sum_congr rfl fun X _ => Finset.sum_congr rfl fun μ _ => ?_
        rw [Finset.mul_sum, Finset.mul_sum]
        exact Finset.sum_congr rfl fun ψ _ => by ring
    _ = ∑ X, ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, ∑ μ,
          c * ((((lapEig N ψ)⁻¹ : ℝ) : ℂ) * (ψ X * conj (a X μ) * ftv b ψ μ)) :=
        Finset.sum_congr rfl fun X _ => Finset.sum_comm
    _ = ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, ∑ X, ∑ μ,
          c * ((((lapEig N ψ)⁻¹ : ℝ) : ℂ) * (ψ X * conj (a X μ) * ftv b ψ μ)) := Finset.sum_comm
    _ = ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, ∑ μ, ∑ X,
          c * ((((lapEig N ψ)⁻¹ : ℝ) : ℂ) * (ψ X * conj (a X μ) * ftv b ψ μ)) :=
        Finset.sum_congr rfl fun ψ _ => Finset.sum_comm
    _ = _ := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun ψ _ => ?_
        rw [Finset.mul_sum, Finset.mul_sum]
        refine Finset.sum_congr rfl fun μ _ => ?_
        rw [Finset.sum_mul, Finset.mul_sum, Finset.mul_sum]

theorem freeCov_selfAdj (N : ℕ) [NeZero N] : SelfAdj (freeCov N) := by
  intro a b
  rw [← pair_conj b (freeCov N a), pair_freeCov, pair_freeCov]
  simp only [map_mul, map_sum, map_inv₀, Complex.conj_ofReal, Complex.conj_natCast, Complex.conj_conj]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  congr 1
  exact Finset.sum_congr rfl fun μ _ => mul_comm _ _

theorem stageCov_selfAdj (m L : ℕ) [NeZero L] : SelfAdj (stageCov m L) :=
  pushOp_selfAdj m L _ (freeCov_selfAdj (fine m L))

/-- **The lattice face covariance is self-adjoint.** -/
theorem faceCov_selfAdj (m N : ℕ) [NeZero N] : SelfAdj (faceCov m N) := by
  intro a b
  unfold faceCov curl curlAdj
  rw [pair_Cop, stageCov_selfAdj, pair_Cop']

end LatticeFace

end

#print axioms LatticeFace.faceCov_selfAdj
#print axioms LatticeFace.stageCov_selfAdj
