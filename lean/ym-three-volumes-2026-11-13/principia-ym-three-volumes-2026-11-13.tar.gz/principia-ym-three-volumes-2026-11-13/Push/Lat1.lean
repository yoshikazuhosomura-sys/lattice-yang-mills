import Push.Rec1

/-! # The free lattice field pushed `m` times by the block average: its symbol

Setting (`LatticeTorus`, `LatticeRec`): vector fields `w : (ℤ/N)⁴ → ℂ⁴` on the torus, the Fourier transform
`ŵ(ψ) = Σ_y ψ(-y) w(y)` over the characters `ψ`, the characters `chi N n` (`n ∈ ℤ⁴`) at the angle
`θ = thOf N n = πn/(2N)` (`= q/4`, `q = 2πn/N`), and the one-step map of a stage operator
`T ↦ C T C†` (`C` = the real-space path kernel `pathKernel` along `X ↦ 2X`).

* (i) `pushOp m L T`: `m` steps from the torus `(ℤ/(2^m L))⁴` (`fine m L`) down to `(ℤ/L)⁴`;
  `push_phase`: if `T` has the phase form `X`, then `pushOp m L T` has the phase form `RM^m X`
  (`torus_step` applied `m` times).
* (ii) `freeCov N`: the covariance of the free lattice vector field in the Feynman gauge on `(ℤ/N)⁴`,
  defined as the operator that is diagonal in the characters with eigenvalue `1/λ(ψ)`,
  `λ(ψ) = Σ_ν |1 − ψ(e_ν)|²` the eigenvalue of the lattice Laplacian `−Δ` on `ψ` (`lap_char`), and `0` on
  the constant mode (`λ = 0`; Lean's `0⁻¹ = 0`, i.e. the zero mode is removed). `freeCov_phase`: it has the
  phase form `X0 = I/ω` (with the same convention at `ω = 0`).
* `stageCov m L = pushOp m L (freeCov (fine m L))` and `stageCov_phase`: it has the phase form `RM^m X0`;
  `projFam_stage`: its physical part `P (RM^m X0) P` is `𝓜^m (P/ω)` (`rec_iterate`, `projFam_X0`). -/

noncomputable section

namespace LatticePush

open Complex Finset TorusFourier LatticePath LatticeTorus LatticeRec
open scoped ComplexConjugate Real

/-- Vector fields (four components) on the torus `(ℤ/N)⁴`. -/
abbrev Fld (N : ℕ) := (Fin 4 → ZMod N) → Fin 4 → ℂ

/-! ## (i) the `m`-step chain -/

/-- The side of the fine torus after `m` halvings down to `L`: `fine m L = 2^m L`. -/
def fine : ℕ → ℕ → ℕ
  | 0, L => L
  | m + 1, L => fine m (2 * L)

theorem fine_eq : ∀ m L, fine m L = 2 ^ m * L
  | 0, L => by simp [fine]
  | m + 1, L => by rw [fine, fine_eq m (2 * L)]; ring

theorem fine_pos : ∀ m L, 0 < L → 0 < fine m L
  | 0, _, h => h
  | m + 1, L, h => fine_pos m (2 * L) (by omega)

instance fine_neZero (m L : ℕ) [NeZero L] : NeZero (fine m L) :=
  ⟨(fine_pos m L (Nat.pos_of_ne_zero (NeZero.ne L))).ne'⟩

/-- One step of the block average on a stage operator: `T ↦ C T C†` from `(ℤ/2L)⁴` to `(ℤ/L)⁴`. -/
def stepOp (L : ℕ) [NeZero L] (T : Fld (2 * L) → Fld (2 * L)) : Fld L → Fld L := fun w =>
  Cop (betaT 4 L) (pathKernel (2 * L)) (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w))

/-- `m` steps from `(ℤ/(2^m L))⁴` to `(ℤ/L)⁴`. -/
def pushOp (m : ℕ) : ∀ (L : ℕ) [NeZero L], (Fld (fine m L) → Fld (fine m L)) → Fld L → Fld L := by
  induction m with
  | zero => intro L _ T; exact T
  | succ m ih => intro L _ T; exact stepOp L (ih (2 * L) T)

theorem pushOp_zero (L : ℕ) [NeZero L] (T : Fld (fine 0 L) → Fld (fine 0 L)) : pushOp 0 L T = T := rfl

theorem pushOp_succ (m L : ℕ) [NeZero L] (T : Fld (fine (m + 1) L) → Fld (fine (m + 1) L)) :
    pushOp (m + 1) L T = stepOp L (pushOp m (2 * L) T) := rfl

/-- **(i) The `m`-step chain on the torus**: the phase form is carried by `RM` at each step. -/
theorem push_phase (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (m : ℕ) :
    ∀ (L : ℕ) [NeZero L] (T : Fld (fine m L) → Fld (fine m L)),
      PhaseSym (fine m L) T X → PhaseSym L (pushOp m L T) ((RM)^[m] X) := by
  induction m with
  | zero => intro L _ T h; exact h
  | succ m ih =>
    intro L _ T h
    rw [Function.iterate_succ_apply', pushOp_succ]
    exact torus_step L (pushOp m (2 * L) T) ((RM)^[m] X) (ih (2 * L) T h)

/-! ## (ii) stage 0: the free field -/

theorem char_orth {F : Type*} [AddCommGroup F] [Fintype F] (ψ ψ' : AddChar F ℂ) :
    ∑ x, ψ' (-x) * ψ x = if ψ = ψ' then (Fintype.card F : ℂ) else 0 := by
  classical
  by_cases h : ψ = ψ'
  · subst h
    rw [if_pos rfl]
    have : ∀ x, ψ (-x) * ψ x = 1 := fun x => by
      rw [← AddChar.map_add_eq_mul, neg_add_cancel, AddChar.map_zero_eq_one]
    simp [this]
  · rw [if_neg h]
    have hne : ψ'⁻¹ * ψ ≠ 0 := by
      intro h0
      apply h
      ext x
      have h1 := congrArg (fun χ : AddChar F ℂ => χ x) h0
      simp only [AddChar.mul_apply, AddChar.inv_apply] at h1
      have h2 : ψ' (-x) * ψ' x = 1 := by
        rw [← AddChar.map_add_eq_mul, neg_add_cancel, AddChar.map_zero_eq_one]
      have h3 : (0 : AddChar F ℂ) x = 1 := AddChar.zero_apply x
      rw [h3] at h1
      have h4 : ψ' (-x) ≠ 0 := fun h0' => by rw [h0', zero_mul] at h2; exact zero_ne_one h2
      exact mul_left_cancel₀ h4 (h1.trans h2.symm)
    have := (AddChar.sum_eq_zero_iff_ne_zero (ψ := ψ'⁻¹ * ψ)).mpr hne
    simpa [AddChar.mul_apply, AddChar.inv_apply] using this

/-- The unit vector `e_ν` of `(ℤ/N)⁴`. -/
def eμ (N : ℕ) (ν : Fin 4) : Fin 4 → ZMod N := fun j => ((ev ν j : ℤ) : ZMod N)

/-- The lattice Laplacian `(−Δ f)(X) = Σ_ν (2 f(X) − f(X + e_ν) − f(X − e_ν))` on scalar functions. -/
def lap (N : ℕ) (f : (Fin 4 → ZMod N) → ℂ) (X : Fin 4 → ZMod N) : ℂ :=
  ∑ ν, (2 * f X - f (X + eμ N ν) - f (X - eμ N ν))

/-- `λ(ψ) = Σ_ν |1 − ψ(e_ν)|²`. -/
def lapEig (N : ℕ) (ψ : AddChar (Fin 4 → ZMod N) ℂ) : ℝ := ∑ ν, ‖1 - ψ (eμ N ν)‖ ^ 2

/-- Each character is an eigenfunction of `−Δ` with eigenvalue `λ(ψ)`. -/
theorem lap_char (N : ℕ) [NeZero N] (ψ : AddChar (Fin 4 → ZMod N) ℂ) (X : Fin 4 → ZMod N) :
    lap N (⇑ψ) X = (lapEig N ψ : ℂ) * ψ X := by
  unfold lap lapEig
  rw [Complex.ofReal_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun ν _ => ?_
  have hn : ψ (-eμ N ν) = conj (ψ (eμ N ν)) := AddChar.map_neg_eq_conj ψ _
  have hu : conj (ψ (eμ N ν)) * ψ (eμ N ν) = 1 := by
    rw [← hn, ← AddChar.map_add_eq_mul, neg_add_cancel, AddChar.map_zero_eq_one]
  have hz : ((‖1 - ψ (eμ N ν)‖ ^ 2 : ℝ) : ℂ) = (1 - ψ (eμ N ν)) * conj (1 - ψ (eμ N ν)) := by
    rw [← Complex.normSq_eq_norm_sq, Complex.mul_conj]
  rw [hz, sub_eq_add_neg X, AddChar.map_add_eq_mul, AddChar.map_add_eq_mul, hn, map_sub, map_one]
  linear_combination (-(ψ X)) * hu

/-- **The free field covariance** (Feynman gauge) on `(ℤ/N)⁴`: diagonal in the characters with eigenvalue
`λ(ψ)⁻¹` (and `0` on the constant mode). -/
def freeCov (N : ℕ) [NeZero N] (w : Fld N) : Fld N := fun X μ =>
  (Fintype.card (Fin 4 → ZMod N) : ℂ)⁻¹ *
    ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, ψ X * (((lapEig N ψ)⁻¹ : ℝ) : ℂ) * ftv w ψ μ

theorem ftv_freeCov (N : ℕ) [NeZero N] (w : Fld N) (ψ' : AddChar (Fin 4 → ZMod N) ℂ) (μ : Fin 4) :
    ftv (freeCov N w) ψ' μ = (((lapEig N ψ')⁻¹ : ℝ) : ℂ) * ftv w ψ' μ := by
  classical
  set c : ℂ := (Fintype.card (Fin 4 → ZMod N) : ℂ) with hcdef
  have hc : c ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  set a : AddChar (Fin 4 → ZMod N) ℂ → ℂ := fun ψ => (((lapEig N ψ)⁻¹ : ℝ) : ℂ) * ftv w ψ μ with ha
  show ∑ X, ψ' (-X) * freeCov N w X μ = a ψ'
  calc ∑ X, ψ' (-X) * freeCov N w X μ
      = ∑ X, ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, c⁻¹ * (a ψ * (ψ' (-X) * ψ X)) := by
        refine Finset.sum_congr rfl fun X _ => ?_
        simp only [freeCov]
        rw [Finset.mul_sum, Finset.mul_sum]
        refine Finset.sum_congr rfl fun ψ _ => ?_
        simp only [ha]; ring
    _ = ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, c⁻¹ * (a ψ * ∑ X, ψ' (-X) * ψ X) := by
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl fun ψ _ => ?_
        rw [Finset.mul_sum, Finset.mul_sum]
    _ = ∑ ψ : AddChar (Fin 4 → ZMod N) ℂ, c⁻¹ * (a ψ * if ψ = ψ' then c else 0) := by
        simp only [char_orth, ← hcdef]
    _ = c⁻¹ * (a ψ' * c) := by
        rw [Finset.sum_eq_single ψ' (fun ψ _ h => by rw [if_neg h]; ring)
          (fun h => absurd (Finset.mem_univ _) h), if_pos rfl]
    _ = a ψ' := by field_simp

theorem norm_one_sub_exp (x : ℝ) : ‖1 - cexp (I * ((2 * x : ℝ) : ℂ))‖ ^ 2 = 4 * Real.sin x ^ 2 := by
  have e : I * ((2 * x : ℝ) : ℂ) = ((2 * x : ℝ) : ℂ) * I := by ring
  rw [e, Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin, Complex.sq_norm,
    Complex.normSq_apply]
  simp only [Complex.sub_re, Complex.one_re, Complex.add_re, Complex.ofReal_re, Complex.mul_re,
    Complex.I_re, Complex.I_im, Complex.ofReal_im, Complex.sub_im, Complex.one_im, Complex.add_im,
    Complex.mul_im]
  rw [Real.cos_two_mul, Real.sin_two_mul]
  linear_combination (4 * (Real.sin x ^ 2 + Real.cos x ^ 2 - 1) - 4 * Real.sin x ^ 2) *
    Real.sin_sq_add_cos_sq x

/-- `λ(chi N n) = ω(θ)`, `θ = thOf N n`. -/
theorem lapEig_chi (N : ℕ) [NeZero N] (n : Fin 4 → ℤ) : lapEig N (chi N n) = om (thOf N n) := by
  unfold lapEig om
  refine Finset.sum_congr rfl fun ν _ => ?_
  have hN : (N : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne N)
  have e : (2 * π * n ν / N : ℝ) = 2 * (2 * thOf N n ν) := by
    unfold thOf; field_simp
  rw [show eμ N ν = fun j => ((ev ν j : ℤ) : ZMod N) from rfl, chi_unit, e, norm_one_sub_exp]
  rfl

/-- **(ii) Stage 0**: the free field covariance has the phase form `X0 = I/ω`. -/
theorem freeCov_phase (N : ℕ) [NeZero N] : PhaseSym N (freeCov N) X0 := by
  intro w n μ
  rw [ftv_freeCov, lapEig_chi]
  rw [Finset.sum_eq_single μ]
  · have h := conj_ph_mul (thOf N n) μ
    simp only [X0, Matrix.smul_apply, Matrix.one_apply_eq, smul_eq_mul, mul_one]
    linear_combination (-((((om (thOf N n))⁻¹ : ℝ) : ℂ) * ftv w (chi N n) μ)) * h
  · intro l _ hl
    simp [X0, Matrix.one_apply_ne (Ne.symm hl)]
  · simp

/-- The stage-`m` covariance on `(ℤ/L)⁴`: the free field on `(ℤ/(2^m L))⁴` pushed `m` times. -/
def stageCov (m L : ℕ) [NeZero L] : Fld L → Fld L := pushOp m L (freeCov (fine m L))

theorem stageCov_phase (m L : ℕ) [NeZero L] : PhaseSym L (stageCov m L) ((RM)^[m] X0) :=
  push_phase X0 m L _ (freeCov_phase (fine m L))

/-- Its physical part on `Qpos` is the stage of the family map: `P (RM^m X0) P = 𝓜^m (P/ω)`. -/
theorem projFam_stage (m : ℕ) (q : OneStepFinal.Qpos) :
    projFam Subtype.val ((RM)^[m] X0) q =
      (⇑(OneStepBridge.Mfam (Subtype.val : OneStepFinal.Qpos → _) OneStepFinal.rqPos))^[m]
        (fun q => (OneStepET.omF Subtype.val q)⁻¹ • OneStepBridge.Pfam Subtype.val q) q := by
  rw [rec_iterate Subtype.val OneStepFinal.rqPos (fun _ _ => rfl), projFam_X0]

end LatticePush

end

#print axioms LatticePush.push_phase
#print axioms LatticePush.freeCov_phase
#print axioms LatticePush.stageCov_phase
#print axioms LatticePush.projFam_stage
#print axioms LatticePush.lap_char
