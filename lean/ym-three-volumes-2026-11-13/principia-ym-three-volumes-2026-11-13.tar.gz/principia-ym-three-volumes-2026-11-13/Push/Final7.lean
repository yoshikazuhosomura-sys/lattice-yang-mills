import Push.Lat2

/-! # `Λ ≤ 640/9` for the face covariance of the pushed free lattice field

The lattice object (`LatticeFace.faceCov m N`, defined in `Push.Lat2` from `LatticePush.stageCov`): the covariance
of the field strength `curl A` on the torus `(ℤ/N)⁴` when `A` is the free lattice vector field in the Feynman gauge
on `(ℤ/(2^m N))⁴` (constant mode removed) pushed `m` times by the block average with the path kernel.
Its quadratic form, norm, Rayleigh top and diagonal entries are defined here directly on the lattice fields
`z : (ℤ/N)⁴ → ℂ⁶` (`latQ`, `latNorm`, `latLamMax`, `latDiag`). `lattice_face_lambda`: for `N ≥ 2` and every `m`,
site `X₀` and face `p`, `λ_max ≤ 1`, `diag ≥ (c₀/2)(1 − N⁻⁴)` with `c₀ = 3/100`, `diag ≤ λ_max` and
`λ_max/diag ≤ 640/9`. `t1h_lattice` joins it with `c₀` (`HsSplit.hS_split`) and the stage `τ` with `τ = τ̄₁₇(1/c₀)`. -/

noncomputable section

namespace LatticeFace

open Complex Finset TorusFourier LatticePush
open scoped ComplexConjugate InnerProductSpace

variable {N : ℕ}

theorem ofLat_toLat [NeZero N] (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : ofLat N (toLat N y) = y := by
  funext x
  show WithLp.toLp 2 (fun p => y ((siteEquiv N).symm (siteEquiv N x)) p) = y x
  rw [Equiv.symm_apply_apply]

/-- `Σ_X Σ_p |z_p(X)|²`. -/
def latNorm (N : ℕ) [NeZero N] (z : Fld6 N) : ℝ := ∑ X, ∑ p, ‖z X p‖ ^ 2

/-- `re Σ_X Σ_p conj(z_p(X)) (faceCov z)_p(X)`. -/
def latQ (m N : ℕ) [NeZero N] (z : Fld6 N) : ℝ := (∑ X, ∑ p, conj (z X p) * faceCov m N z X p).re

def latSet (m N : ℕ) [NeZero N] : Set ℝ :=
  {r | ∃ z : Fld6 N, 0 < latNorm N z ∧ r = latQ m N z / latNorm N z}

/-- The top of the Rayleigh quotient of `faceCov m N`. -/
def latLamMax (m N : ℕ) [NeZero N] : ℝ := sSup (latSet m N)

/-- The diagonal entry of `faceCov m N` at the site `X₀` and the face `p`. -/
def latDiag (m N : ℕ) [NeZero N] (X₀ : Fin 4 → ZMod N) (p : Fin 6) : ℝ :=
  (faceCov m N (fun X q => if X = X₀ ∧ q = p then 1 else 0) X₀ p).re

theorem latNorm_eq [NeZero N] (z : Fld6 N) : latNorm N z = TorusPos.posNorm N (ofLat N z) := by
  unfold latNorm TorusPos.posNorm
  rw [← (siteEquiv N).sum_comp]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [EuclideanSpace.norm_sq_eq]
  rfl

theorem latQ_eq [NeZero N] (m : ℕ) (z : Fld6 N) : latQ m N z = TorusPos.posQ N m (ofLat N z) := by
  unfold latQ TorusPos.posQ
  rw [← faceCov_eq_posC, toLat_ofLat]
  congr 1
  rw [← (siteEquiv N).sum_comp]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [PiLp.inner_apply]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [RCLike.inner_apply, mul_comm]
  rfl

theorem latSet_eq [NeZero N] (m : ℕ) : latSet m N = TorusPos.posSet N m := by
  ext r
  constructor
  · rintro ⟨z, hz, rfl⟩
    exact ⟨ofLat N z, by rwa [← latNorm_eq], by rw [latQ_eq, latNorm_eq]⟩
  · rintro ⟨y, hy, rfl⟩
    refine ⟨toLat N y, ?_, ?_⟩
    · rw [latNorm_eq, ofLat_toLat]; exact hy
    · rw [latQ_eq, latNorm_eq, ofLat_toLat]

theorem latLamMax_eq [NeZero N] (m : ℕ) : latLamMax m N = TorusPos.posLamMax N m := by
  unfold latLamMax TorusPos.posLamMax
  rw [latSet_eq]

theorem latDiag_eq [NeZero N] (m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) :
    latDiag m N (siteEquiv N x0) p = TorusPos.posDiag N m x0 p := by
  unfold latDiag TorusPos.posDiag
  have hd : (fun X q => if X = siteEquiv N x0 ∧ q = p then (1 : ℂ) else 0) =
      toLat N (PlanchK.delta x0 (EuclideanSpace.single p 1)) := by
    funext X q
    simp only [toLat, PlanchK.delta]
    by_cases hX : X = siteEquiv N x0
    · subst hX
      by_cases hq : q = p
      · subst hq; simp
      · simp [hq]
    · have h' : (siteEquiv N).symm X ≠ x0 := fun h => hX (by rw [← h, Equiv.apply_symm_apply])
      simp [hX, h']
  rw [hd, ← faceCov_eq_posC]
  simp [ofLat, EuclideanSpace.inner_single_left]

/-- **`Λ ≤ 640/9` for the lattice face covariance** (T1h on the lattice object). For the face covariance
`faceCov m N = curl ∘ stageCov m N ∘ curl†` of the free lattice field pushed `m` times, on the torus `(ℤ/N)⁴`,
`N ≥ 2`: the Rayleigh quotient is `≤ 1`, the diagonal entry at every site and face is `≥ (c₀/2)(1 − N⁻⁴)`,
`c₀ = 3/100`, `diag ≤ λ_max`, and `λ_max/diag ≤ 640/9`, for every `m`. No hypothesis. -/
theorem lattice_face_lambda [NeZero N] (hN : 2 ≤ N) (m : ℕ) (X₀ : Fin 4 → ZMod N) (p : Fin 6) :
    (∀ z : Fld6 N, latQ m N z ≤ latNorm N z) ∧ latLamMax m N ≤ 1 ∧
    (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ latDiag m N X₀ p ∧
    latDiag m N X₀ p ≤ latLamMax m N ∧ latLamMax m N / latDiag m N X₀ p ≤ 640 / 9 := by
  obtain ⟨h1, h2, h3, h4, h5⟩ := TorusPos.torus_position_face_lambda hN m ((siteEquiv N).symm X₀) p
  have hD : latDiag m N X₀ p = TorusPos.posDiag N m ((siteEquiv N).symm X₀) p := by
    rw [← latDiag_eq, Equiv.apply_symm_apply]
  rw [hD, latLamMax_eq]
  exact ⟨fun z => by rw [latQ_eq, latNorm_eq]; exact h1 _, h2, h3, h4, h5⟩

end LatticeFace

open scoped RealInnerProductSpace

namespace T1h

/-- T1 with T1h on the lattice object: `c₀ = 3/100` (no hypothesis), the stage `τ` with `τ = τ̄₁₇(1/c₀)` and
`τ < 1/170`, and `Λ ≤ 640/9` for the lattice face covariance `LatticeFace.faceCov m N` on every torus `N ≥ 2`. -/
theorem t1h_lattice : ∃ c₀ : ℝ, c₀ = 3 / 100 ∧
    (∀ θ : Fin 4 → ℝ, 0 < NearAliasB.omT θ →
      c₀ ≤ NearAliasB.gpt 0 2 θ ∨ ∀ ν, c₀ ≤ NearAliasB.omT θ * NearAliasB.Dn 5 θ ν) ∧
    (∃ τ : ℝ, τ = StageArith.tauM (1 / c₀) (3 / 5) 17 ∧ τ < 1 / 170 ∧
      ∀ (k : ℕ) (q : OneStepFinal.Qpos) (x : OneStepBridge.V),
      ⟪x, ((⇑(OneStepBridge.Mfam (Subtype.val : OneStepFinal.Qpos → _) OneStepFinal.rqPos))^[17]
          (fun q => OneStepET.omF Subtype.val q • TauSplit.Gs Subtype.val OneStepFinal.rqPos k q)) q x⟫ ≤
        τ * (OneStepET.omF Subtype.val q * ⟪x, TauSplit.Gs Subtype.val OneStepFinal.rqPos (k + 17) q x⟫)) ∧
    (∀ {N : ℕ} [NeZero N], 2 ≤ N → ∀ (m : ℕ) (X₀ : Fin 4 → ZMod N) (p : Fin 6),
      c₀ / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ LatticeFace.latDiag m N X₀ p ∧
      LatticeFace.latDiag m N X₀ p ≤ LatticeFace.latLamMax m N ∧
      LatticeFace.latLamMax m N ≤ 1 ∧
      LatticeFace.latLamMax m N / LatticeFace.latDiag m N X₀ p ≤ 640 / 9) := by
  refine ⟨3 / 100, rfl, HsSplit.hS_split, TorusLam.stage_tau_17, fun {N} _ hN m X₀ p => ?_⟩
  obtain ⟨-, h1, h2, h3, h4⟩ := LatticeFace.lattice_face_lambda hN m X₀ p
  exact ⟨h2, h3, h1, h4⟩

end T1h

#print axioms LatticeFace.faceCov_eq_posC
#print axioms LatticeFace.lattice_face_lambda
#print axioms LatticeFace.latDiag_eq
#print axioms T1h.t1h_lattice
#print axioms LatticePush.stageCov_phase
