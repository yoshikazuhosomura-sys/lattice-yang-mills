import Push.Lat1
import Lam.TorusPos1

/-! # The face covariance of the pushed free lattice field equals `posC N m`

Objects (all defined from the lattice):
* `LatticePush.stageCov m N`: the free lattice vector field (Feynman gauge, constant mode removed) on `(ℤ/(2^m N))⁴`,
  pushed `m` times by the block average `T ↦ C T C†` (path kernel `pathKernel`, `X ↦ 2X`), on `(ℤ/N)⁴`;
* `curl N`: the lattice field strength of the face `p = (a, b)` (`a = fa p < b = fb p`),
  `(curl A)_p(X) = (A_a(X + e_b) − A_a(X)) − (A_b(X + e_a) − A_b(X))` (`curl_apply`), and `curlAdj N` its adjoint;
* `faceCov m N = curl ∘ stageCov m N ∘ curlAdj`: the covariance of the face field `curl A` when `A` has the
  covariance `stageCov m N`.
`faceCov_eq_posC`: after relabelling the sites `(Fin N)⁴ ≃ (ℤ/N)⁴` (`siteEquiv`), `faceCov m N` is the operator
`TorusPos.posC N m`. Hence `lattice_face_lambda`: the statement of `TorusPos.torus_position_face_lambda` holds for
the lattice operator `faceCov m N`. -/

noncomputable section

namespace LatticeFace

open Complex Finset TorusFourier LatticePath LatticeTorus LatticeRec LatticePush FaceBracket FaceReal FaceTorus
  TorusLam
open scoped ComplexConjugate Real InnerProductSpace Matrix

variable {N : ℕ}

/-! ## sites and characters -/

/-- The sites `(Fin N)⁴ ≃ (ℤ/N)⁴`, `x ↦ (x_j mod N)`. -/
def siteEquiv (N : ℕ) [NeZero N] : (Fin 4 → Fin N) ≃ (Fin 4 → ZMod N) where
  toFun x j := (((x j : ℕ) : ℤ) : ZMod N)
  invFun X j := ⟨(X j).val, ZMod.val_lt (X j)⟩
  left_inv x := by
    funext j; apply Fin.ext
    simp only [Int.cast_natCast, ZMod.val_natCast]
    exact Nat.mod_eq_of_lt (x j).isLt
  right_inv X := by
    funext j
    simp only [Int.cast_natCast, ZMod.natCast_zmod_val]

/-- The momentum label `k ∈ (Fin N)⁴` as an integer vector. -/
def nk (N : ℕ) (k : Fin 4 → Fin N) : Fin 4 → ℤ := fun j => ((k j : ℕ) : ℤ)

theorem chi_site [NeZero N] (k x : Fin 4 → Fin N) :
    chi N (nk N k) (siteEquiv N x) = TorusChar.ch N k x := by
  rw [show siteEquiv N x = fun j => ((nk N x j : ℤ) : ZMod N) from rfl, chi_intCast]
  unfold LatticePath.E kOf TorusChar.ch TorusChar.ch1
  rw [Finset.mul_sum, Complex.exp_sum]
  refine Finset.prod_congr rfl fun j _ => ?_
  congr 1
  simp only [nk]
  push_cast
  ring

theorem ch_symm (k x : Fin 4 → Fin N) : TorusChar.ch N k x = TorusChar.ch N x k := by
  unfold TorusChar.ch TorusChar.ch1
  refine Finset.prod_congr rfl fun μ _ => ?_
  congr 1
  ring

/-! ## the two pictures of the face field -/

abbrev Fld6 (N : ℕ) := (Fin 4 → ZMod N) → Fin 6 → ℂ

def toLat (N : ℕ) [NeZero N] (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : Fld6 N :=
  fun X p => y ((siteEquiv N).symm X) p

def ofLat (N : ℕ) [NeZero N] (z : Fld6 N) : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6) :=
  fun x => WithLp.toLp 2 (z (siteEquiv N x))

theorem toLat_ofLat [NeZero N] (z : Fld6 N) : toLat N (ofLat N z) = z := by
  funext X p
  simp [toLat, ofLat]

theorem ftv_toLat [NeZero N] (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) (k : Fin 4 → Fin N)
    (p : Fin 6) : ftv (toLat N y) (chi N (nk N k)) p = (PlanchK.ft (TorusChar.ch N) y k) p := by
  show ∑ X, chi N (nk N k) (-X) * toLat N y X p = _
  rw [← (siteEquiv N).sum_comp]
  simp only [toLat, Equiv.symm_apply_apply, AddChar.map_neg_eq_conj, chi_site]
  simp [PlanchK.ft]

theorem ft_ofLat [NeZero N] (z : Fld6 N) (k : Fin 4 → Fin N) :
    PlanchK.ft (TorusChar.ch N) (ofLat N z) k = WithLp.toLp 2 (fun p => ftv z (chi N (nk N k)) p) := by
  ext p
  rw [← ftv_toLat, toLat_ofLat]

theorem sum_smul_sum {K G E : Type*} [Fintype K] [Fintype G] [AddCommGroup E] [Module ℂ E]
    (a : G → ℂ) (c : ℂ) (b : K → G → ℂ) (v : K → E) :
    ∑ x, a x • (c • ∑ k, b k x • v k) = c • ∑ k, (∑ x, a x * b k x) • v k := by
  simp only [Finset.smul_sum, Finset.sum_smul, smul_smul]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun k _ => Finset.sum_congr rfl fun x _ => ?_
  congr 1
  ring

theorem inv_formula (f : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) (x : Fin 4 → Fin N) :
    (Fintype.card (Fin 4 → Fin N) : ℂ) • f x =
      ∑ k, TorusChar.ch N k x • PlanchK.ft (TorusChar.ch N) f k := by
  have h := sum_smul_sum (fun k : Fin 4 → Fin N => TorusChar.ch N k x) 1
    (fun x' k => conj (TorusChar.ch N k x')) f
  simp only [one_smul] at h
  have e : ∀ x' : Fin 4 → Fin N, (∑ k, TorusChar.ch N k x * conj (TorusChar.ch N k x')) =
      if x = x' then (Fintype.card (Fin 4 → Fin N) : ℂ) else 0 := by
    intro x'
    rw [← TorusChar.ortho x' x]
    exact Finset.sum_congr rfl fun k _ => by ring
  simp only [e, ite_smul, zero_smul, Finset.sum_ite_eq, Finset.mem_univ, if_true] at h
  rw [← h]
  simp only [PlanchK.ft]

theorem eq_of_ft (f g : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6))
    (h : ∀ k, PlanchK.ft (TorusChar.ch N) f k = PlanchK.ft (TorusChar.ch N) g k) : f = g := by
  funext x
  have hN : (Fintype.card (Fin 4 → Fin N) : ℂ) ≠ 0 := by
    by_cases hN0 : N = 0
    · subst hN0; exact x 0 |>.elim0
    · haveI : Nonempty (Fin 4 → Fin N) := ⟨x⟩
      exact Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have h1 := inv_formula f x
  have h2 := inv_formula g x
  simp only [h] at h1
  exact smul_right_injective _ hN (h1.trans h2.symm)

theorem ft_opC (M : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6) →ₗ[ℂ] EuclideanSpace ℂ (Fin 6))
    (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) (k : Fin 4 → Fin N) :
    PlanchK.ft (TorusChar.ch N) (PlanchK.opC (TorusChar.ch N) M y) k = M k (PlanchK.ft (TorusChar.ch N) y k) := by
  have hN : (Fintype.card (Fin 4 → Fin N) : ℂ) ≠ 0 := by
    by_cases hN0 : N = 0
    · subst hN0; exact k 0 |>.elim0
    · haveI : Nonempty (Fin 4 → Fin N) := ⟨k⟩
      exact Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  unfold PlanchK.opC
  rw [show PlanchK.ft (TorusChar.ch N) (fun x => ((Fintype.card (Fin 4 → Fin N) : ℂ))⁻¹ •
      ∑ k', TorusChar.ch N k' x • M k' (PlanchK.ft (TorusChar.ch N) y k')) k =
      ∑ x, conj (TorusChar.ch N k x) • (((Fintype.card (Fin 4 → Fin N) : ℂ))⁻¹ •
      ∑ k', TorusChar.ch N k' x • M k' (PlanchK.ft (TorusChar.ch N) y k')) from rfl, sum_smul_sum]
  have e : ∀ k' : Fin 4 → Fin N, (∑ x, conj (TorusChar.ch N k x) * TorusChar.ch N k' x) =
      if k' = k then (Fintype.card (Fin 4 → Fin N) : ℂ) else 0 := by
    intro k'
    rw [← TorusChar.ortho k k']
    exact Finset.sum_congr rfl fun x _ => by rw [ch_symm k x, ch_symm k' x]
  simp only [e, ite_smul, zero_smul, Finset.sum_ite_eq', Finset.mem_univ, if_true, smul_smul,
    inv_mul_cancel₀ hN, one_smul]

/-! ## the lattice curl -/

theorem fa_ne_fb (p : Fin 6) : fa p ≠ fb p := by fin_cases p <;> decide

/-- The kernel of the lattice curl: `(curl A)_p(X) = Σ_r Σ_ν curlKer r p ν A_ν(X + r)`. -/
def curlKer (N : ℕ) [NeZero N] : (Fin 4 → ZMod N) → Fin 6 → Fin 4 → ℂ := fun r p ν =>
  (if ν = fa p then ((if r = eμ N (fb p) then 1 else 0) - (if r = 0 then 1 else 0)) else 0) +
  (if ν = fb p then ((if r = 0 then 1 else 0) - (if r = eμ N (fa p) then 1 else 0)) else 0)

/-- The lattice curl (the face field of a vector field). -/
def curl (N : ℕ) [NeZero N] (A : Fld N) : Fld6 N := Cop (AddMonoidHom.id _) (curlKer N) A

/-- Its adjoint for the `ℓ²` pairings (`TorusFourier.Cop_adjoint`). -/
def curlAdj (N : ℕ) [NeZero N] (z : Fld6 N) : Fld N := Cadj (AddMonoidHom.id _) (curlKer N) z

theorem curl_apply [NeZero N] (A : Fld N) (X : Fin 4 → ZMod N) (p : Fin 6) :
    curl N A X p = (A (X + eμ N (fb p)) (fa p) - A X (fa p)) - (A (X + eμ N (fa p)) (fb p) - A X (fb p)) := by
  have hab := fa_ne_fb p
  simp only [curl, Cop, AddMonoidHom.id_apply, curlKer, add_mul, sub_mul, ite_mul, one_mul, zero_mul,
    Finset.sum_add_distrib, Finset.sum_sub_distrib, Finset.sum_ite_eq', Finset.mem_univ, if_true,
    add_zero]
  ring

theorem ftv_curl [NeZero N] (A : Fld N) (ψ : AddChar (Fin 4 → ZMod N) ℂ) (p : Fin 6) :
    ftv (curl N A) ψ p = ∑ ν, sym (curlKer N) ψ p ν * ftv A ψ ν :=
  ft_shiftSum (curlKer N) A p ψ

theorem ftv_curlAdj [NeZero N] (z : Fld6 N) (ψ : AddChar (Fin 4 → ZMod N) ℂ) (ν : Fin 4) :
    ftv (curlAdj N z) ψ ν = ∑ p, conj (sym (curlKer N) ψ p ν) * ftv z ψ p := by
  rw [curlAdj, ftv_Cadj]
  rfl

theorem sym_curl [NeZero N] (ψ : AddChar (Fin 4 → ZMod N) ℂ) (p : Fin 6) (ν : Fin 4) :
    sym (curlKer N) ψ p ν = (if ν = fa p then ψ (eμ N (fb p)) - 1 else 0) +
      (if ν = fb p then 1 - ψ (eμ N (fa p)) else 0) := by
  by_cases ha : ν = fa p <;> by_cases hb : ν = fb p <;>
    simp [sym, curlKer, ha, hb, ite_mul, add_mul, sub_mul, Finset.sum_sub_distrib, Finset.sum_add_distrib,
      AddChar.map_zero_eq_one]

theorem chi_e [NeZero N] (k : Fin 4 → Fin N) (μ : Fin 4) : chi N (nk N k) (eμ N μ) = 1 - FaceTorus.qk N k μ := by
  rw [show eμ N μ = fun j => ((ev μ j : ℤ) : ZMod N) from rfl, chi_unit]
  unfold FaceTorus.qk nk
  rw [sub_sub_cancel]
  congr 1
  push_cast
  ring

theorem dmat_entry (q : Fin 4 → ℂ) (p : Fin 6) (ν : Fin 4) :
    dmat q p ν = (if ν = fa p then -q (fb p) else 0) + (if ν = fb p then q (fa p) else 0) := by
  fin_cases p <;> fin_cases ν <;> simp [dmat, fa, fb]

theorem sym_curl_chi [NeZero N] (k : Fin 4 → Fin N) (p : Fin 6) (ν : Fin 4) :
    sym (curlKer N) (chi N (nk N k)) p ν = dmat (FaceTorus.qk N k) p ν := by
  rw [sym_curl, chi_e, chi_e, dmat_entry]
  congr 1 <;> split_ifs <;> ring

/-! ## the face covariance and its symbol -/

/-- **The covariance of the face field of the stage-`m` lattice field** on `(ℤ/N)⁴`. -/
def faceCov (m N : ℕ) [NeZero N] (z : Fld6 N) : Fld6 N := curl N (stageCov m N (curlAdj N z))

theorem ftv_faceCov [NeZero N] (m : ℕ) (z : Fld6 N) (k : Fin 4 → Fin N) (p : Fin 6) :
    ftv (faceCov m N z) (chi N (nk N k)) p =
      ∑ ν, dmat (FaceTorus.qk N k) p ν * ∑ l, ph (thOf N (nk N k)) ν * (((RM)^[m] X0 (thOf N (nk N k)) ν l : ℝ) : ℂ) *
        conj (ph (thOf N (nk N k)) l) * ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * ftv z (chi N (nk N k)) p' := by
  rw [faceCov, ftv_curl]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [sym_curl_chi, stageCov_phase m N (curlAdj N z) (nk N k) ν]
  congr 1
  refine Finset.sum_congr rfl fun l _ => ?_
  rw [ftv_curlAdj]
  simp only [sym_curl_chi]

/-- Removing the projection on `s^⊥` on both sides. -/
theorem key_proj (Dp : Fin 4 → ℂ) (s : Fin 4 → ℝ) (X : Matrix (Fin 4) (Fin 4) ℝ) (w : Fin 4 → ℂ)
    (hD : ∑ ν, Dp ν * (s ν : ℂ) = 0) (hw : ∑ l, (s l : ℂ) * w l = 0) :
    ∑ ν, Dp ν * ∑ l, (((OneStepBridge.projM s * X * OneStepBridge.projM s) ν l : ℝ) : ℂ) * w l =
      ∑ ν, Dp ν * ∑ l, ((X ν l : ℝ) : ℂ) * w l := by
  set Pc := (OneStepBridge.projM s).map Complex.ofRealHom
  set Xc := X.map Complex.ofRealHom
  have hPw : Pc *ᵥ w = w := by
    funext b
    show ∑ l, ((OneStepBridge.projM s b l : ℝ) : ℂ) * w l = w b
    simp only [OneStepBridge.projM, Matrix.of_apply]
    push_cast
    simp only [sub_mul, Finset.sum_sub_distrib, ite_mul, one_mul, zero_mul, Finset.sum_ite_eq,
      Finset.mem_univ, if_true]
    have e : ∑ l, (s b : ℂ) * (s l : ℂ) / (OneStepHrep.dot s s : ℂ) * w l =
        (s b : ℂ) / (OneStepHrep.dot s s : ℂ) * ∑ l, (s l : ℂ) * w l := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun l _ => by ring
    rw [e, hw, mul_zero, sub_zero]
    rw [Finset.sum_eq_single b (fun x _ hx => by simp [Ne.symm hx]) (by simp)]
    simp
  have hDP : Dp ᵥ* Pc = Dp := by
    funext a
    show ∑ ν, Dp ν * ((OneStepBridge.projM s ν a : ℝ) : ℂ) = Dp a
    simp only [OneStepBridge.projM, Matrix.of_apply]
    push_cast
    simp only [mul_sub, Finset.sum_sub_distrib, mul_ite, mul_one, mul_zero, Finset.sum_ite_eq',
      Finset.mem_univ, if_true]
    have e : ∑ ν, Dp ν * ((s ν : ℂ) * (s a : ℂ) / (OneStepHrep.dot s s : ℂ)) =
        (s a : ℂ) / (OneStepHrep.dot s s : ℂ) * ∑ ν, Dp ν * (s ν : ℂ) := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun l _ => by ring
    rw [e, hD, mul_zero, sub_zero]
    rw [Finset.sum_eq_single a (fun x _ hx => by simp [hx]) (by simp)]
    simp
  have hm : (OneStepBridge.projM s * X * OneStepBridge.projM s).map Complex.ofRealHom = Pc * Xc * Pc := by
    simp only [Pc, Xc, Matrix.map_mul]
  change Dp ⬝ᵥ ((OneStepBridge.projM s * X * OneStepBridge.projM s).map Complex.ofRealHom *ᵥ w) =
    Dp ⬝ᵥ (Xc *ᵥ w)
  rw [hm, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, Matrix.dotProduct_mulVec, hPw, hDP]


/-! ## the symbol of the face covariance is `faceM` -/

theorem torG_toE (M : Matrix (Fin 4) (Fin 4) ℝ) : torG (Matrix.toEuclideanLin M) = M := by
  ext i j
  simp [torG, OneStepBridge.toE_apply, EuclideanSpace.inner_single_left, Matrix.mulVec, dotProduct,
    Pi.single_apply]

theorem torTh_eq (k : Fin 4 → Fin N) : torTh N k = thOf N (nk N k) := by
  funext ν; unfold torTh torQv thOf nk; push_cast; ring

theorem torU_ph (k : Fin 4 → Fin N) (ν : Fin 4) : torU N k ν = -I * ph (thOf N (nk N k)) ν := by
  unfold torU ph
  congr 2
  unfold torQv thOf nk
  push_cast
  ring

theorem torS_eq (k : Fin 4 → Fin N) : torS N k = OneStepHrep.sQ (thOf N (nk N k)) := by
  rw [← torTh_eq, sQ_torTh]

theorem Gst_eq (m : ℕ) (k : Fin 4 → Fin N) (hk : 0 < omg (FaceTorus.qk N k)) :
    torG (Gst m (torPt k hk)) = OneStepBridge.projM (OneStepHrep.sQ (thOf N (nk N k))) *
      (RM)^[m] X0 (thOf N (nk N k)) * OneStepBridge.projM (OneStepHrep.sQ (thOf N (nk N k))) := by
  have h : Gst m (torPt k hk) = projFam Subtype.val ((RM)^[m] X0) (torPt k hk) := (projFam_stage m _).symm
  rw [h]
  show torG (Matrix.toEuclideanLin (OneStepBridge.projM (OneStepHrep.sQ (torTh N k)) *
    (RM)^[m] X0 (torTh N k) * OneStepBridge.projM (OneStepHrep.sQ (torTh N k)))) = _
  rw [torG_toE, torTh_eq]

theorem toE_c {m n : Type*} [Fintype n] [DecidableEq n] (A : Matrix m n ℂ) (v : EuclideanSpace ℂ n) :
    Matrix.toEuclideanLin A v = WithLp.toLp 2 (A *ᵥ WithLp.ofLp v) := rfl

theorem face_symbol [NeZero N] (m : ℕ) (k : Fin 4 → Fin N) (v : EuclideanSpace ℂ (Fin 6)) (p : Fin 6) :
    ∑ ν, dmat (FaceTorus.qk N k) p ν * ∑ l, ph (thOf N (nk N k)) ν *
        (((RM)^[m] X0 (thOf N (nk N k)) ν l : ℝ) : ℂ) * conj (ph (thOf N (nk N k)) l) *
        ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * v p' = (faceM N m k v) p := by
  have hfM : faceM N m k v = Matrix.toEuclideanLin (dmat (FaceTorus.qk N k))
      (symb N m k (Matrix.toEuclideanLin (dmat (FaceTorus.qk N k))ᴴ v)) := by
    simp only [faceM, LinearMap.comp_apply, ← Matrix.toEuclideanLin_conjTranspose_eq_adjoint]
  by_cases hk : 0 < omg (FaceTorus.qk N k)
  · have hsymb : symb N m k = Matrix.toEuclideanLin (Gc (torU N k) (torG (Gst m (torPt k hk)))) := by
      unfold symb; rw [dif_pos hk]
    rw [hfM, hsymb, Gst_eq m k hk]
    -- the gauge direction
    have hq : ∀ ν, FaceTorus.qk N k ν =
        -2 * I * ph (thOf N (nk N k)) ν * ((OneStepHrep.sQ (thOf N (nk N k)) ν : ℝ) : ℂ) := by
      intro ν
      rw [qk_eq]
      simp only [qhat, torU_ph, torS_eq]
      ring
    have hD : ∀ p', ∑ l, dmat (FaceTorus.qk N k) p' l * ph (thOf N (nk N k)) l *
        ((OneStepHrep.sQ (thOf N (nk N k)) l : ℝ) : ℂ) = 0 := by
      intro p'
      have h0 := congrFun (dmat_q (FaceTorus.qk N k)) p'
      simp only [Matrix.mulVec, dotProduct, Pi.zero_apply] at h0
      have h1 : (-2 * I) * ∑ l, dmat (FaceTorus.qk N k) p' l * ph (thOf N (nk N k)) l *
          ((OneStepHrep.sQ (thOf N (nk N k)) l : ℝ) : ℂ) = 0 := by
        rw [Finset.mul_sum, ← h0]
        refine Finset.sum_congr rfl fun l _ => ?_
        rw [hq l]; ring
      have h2 : (-2 * I : ℂ) ≠ 0 := by simp
      exact (mul_eq_zero.mp h1).resolve_left h2
    have hw : ∑ l, ((OneStepHrep.sQ (thOf N (nk N k)) l : ℝ) : ℂ) *
        (conj (ph (thOf N (nk N k)) l) * ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * v p') = 0 := by
      calc _ = ∑ p', v p' * conj (∑ l, dmat (FaceTorus.qk N k) p' l * ph (thOf N (nk N k)) l *
            ((OneStepHrep.sQ (thOf N (nk N k)) l : ℝ) : ℂ)) := by
            simp only [map_sum, map_mul, Complex.conj_ofReal, Finset.mul_sum]
            rw [Finset.sum_comm]
            exact Finset.sum_congr rfl fun p' _ => Finset.sum_congr rfl fun l _ => by ring
        _ = 0 := by simp [hD]
    have hkey := key_proj (fun ν => dmat (FaceTorus.qk N k) p ν * ph (thOf N (nk N k)) ν)
      (OneStepHrep.sQ (thOf N (nk N k))) ((RM)^[m] X0 (thOf N (nk N k)))
      (fun l => conj (ph (thOf N (nk N k)) l) * ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * v p') (hD p) hw
    have hU2 : ∀ l, star (torU N k l) = I * conj (ph (thOf N (nk N k)) l) := by
      intro l
      rw [torU_ph]
      simp [Complex.conj_I]
    rw [toE_c, toE_c, toE_c]
    show _ = ∑ ν, dmat (FaceTorus.qk N k) p ν * ∑ l, Gc (torU N k) _ ν l *
      ∑ p', (dmat (FaceTorus.qk N k))ᴴ l p' * v p'
    simp only [Gc, Matrix.of_apply, Matrix.conjTranspose_apply, hU2]
    simp only [torU_ph, Complex.star_def]
    calc _ = ∑ ν, dmat (FaceTorus.qk N k) p ν * ph (thOf N (nk N k)) ν *
          ∑ l, (((RM)^[m] X0 (thOf N (nk N k)) ν l : ℝ) : ℂ) *
          (conj (ph (thOf N (nk N k)) l) * ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * v p') := by
          refine Finset.sum_congr rfl fun ν _ => ?_
          rw [Finset.mul_sum, Finset.mul_sum]
          exact Finset.sum_congr rfl fun l _ => by ring
      _ = _ := hkey.symm
      _ = _ := by
          refine Finset.sum_congr rfl fun ν _ => ?_
          rw [Finset.mul_sum, Finset.mul_sum]
          refine Finset.sum_congr rfl fun l _ => ?_
          have hI : (-I) * I = (1 : ℂ) := by rw [neg_mul, Complex.I_mul_I, neg_neg]
          linear_combination (-1 : ℂ) * (dmat (FaceTorus.qk N k) p ν * ph (thOf N (nk N k)) ν *
            ((((OneStepBridge.projM (OneStepHrep.sQ (thOf N (nk N k))) * (RM)^[m] X0 (thOf N (nk N k)) *
              OneStepBridge.projM (OneStepHrep.sQ (thOf N (nk N k)))) ν l : ℝ) : ℂ)) *
            (conj (ph (thOf N (nk N k)) l) * ∑ p', conj (dmat (FaceTorus.qk N k) p' l) * v p')) * hI
  · have hq0 : FaceTorus.qk N k = 0 := by
      have hle : omg (FaceTorus.qk N k) ≤ 0 := not_lt.mp hk
      have hz := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg ‖FaceTorus.qk N k i‖)).mp
        (le_antisymm hle (omg_nonneg _))
      funext μ
      have := hz μ (Finset.mem_univ _)
      simpa using this
    have hD0 : dmat (FaceTorus.qk N k) = 0 := by rw [hq0, dmat_zero]
    rw [hfM, hD0]
    simp

/-- **The face covariance of the stage-`m` lattice field is `posC N m`** (after relabelling the sites). -/
theorem faceCov_eq_posC [NeZero N] (m : ℕ) (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) :
    ofLat N (faceCov m N (toLat N y)) = TorusPos.posC N m y := by
  apply eq_of_ft
  intro k
  rw [ft_ofLat]
  show _ = PlanchK.ft (TorusChar.ch N) (PlanchK.opC (TorusChar.ch N) (faceM N m) y) k
  rw [ft_opC]
  ext p
  show ftv (faceCov m N (toLat N y)) (chi N (nk N k)) p = _
  rw [ftv_faceCov]
  simp only [ftv_toLat]
  exact face_symbol m k _ p

end LatticeFace

end

#print axioms LatticeFace.faceCov_eq_posC
#print axioms LatticeFace.face_symbol
#print axioms LatticeFace.ftv_faceCov
#print axioms LatticeFace.key_proj
#print axioms LatticeFace.ft_opC
#print axioms LatticeFace.eq_of_ft
#print axioms LatticeFace.curl_apply
#print axioms LatticeFace.ftv_toLat
