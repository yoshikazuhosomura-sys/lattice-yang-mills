import T1.Split1

/-! # The block average on the torus, its path kernel, and the recursion of the stage symbol

Copied from the common source after the prefix that `T1.Split1` already contains (the lines after
`end OneStepCell`, through `end LatticeRec`), with section markers and source labels removed from comments.
Contents: `OneStepLift`, `LatticePath`, `LatticeTorus` (`torus_step`), `LatticeRec` (`rec_step`, `rec_iterate`). -/



/-!
# From the real lowest-alias bound to the hypothesis `hc₀` of `torus_Cadj_lower`

If the complex symbol at the chosen alias has the closed form of §1.2,
`Q(k) = 2 diag(e^{ia}) · W · K̃ · diag(e^{−ib})` with `W = diag cos(k/2)`, `K̃ = N(k)` and real
phases `a`, `b`, at the alias `ζ*` nearest to the origin, then `|Q(k)† v|² ≥ (121/1152)|v|²`
for every complex `v`.  The phases are unitary and `W K̃` is real, so the complex bound is the
real bound `lowest_alias_lower` on the real and imaginary parts.
-/

noncomputable section

namespace OneStepLift

open Finset OneStepHrep OneStepBridge OneStepET OneStepLower OneStepCell
open scoped ComplexConjugate

/-- The unimodular phase `e(t) = exp(i t)`. -/
def ph (t : ℝ) : ℂ := Complex.exp ((t : ℂ) * Complex.I)

theorem norm_ph (t : ℝ) : ‖ph t‖ = 1 := Complex.norm_exp_ofReal_mul_I t

theorem conj_ph (t : ℝ) : conj (ph t) = ph (-t) := by
  unfold ph
  rw [← Complex.exp_conj, map_mul, Complex.conj_ofReal, Complex.conj_I]
  congr 1
  push_cast
  ring

theorem conj_entry (a b A : ℝ) :
    conj (2 * ph a * (A : ℂ) * ph (-b)) = ph b * (2 * ((A : ℂ) * ph (-a))) := by
  rw [map_mul, map_mul, map_mul, conj_ph, conj_ph, Complex.conj_ofReal, neg_neg]
  have : conj (2 : ℂ) = 2 := by
    rw [show (2 : ℂ) = ((2 : ℝ) : ℂ) by norm_num, Complex.conj_ofReal]
  rw [this]
  ring

/-- **The complex lift**: a real bound `c₀|x|² ≤ 4 Σ_ν (Σ_μ A_{μν} x_μ)²` gives
`c₀|v|² ≤ Σ_ν |Σ_μ conj(Q_{μν}) v_μ|²` for `Q_{μν} = 2 e^{i a_μ} A_{μν} e^{−i b_ν}`. -/
theorem lift_core (A : Fin 4 → Fin 4 → ℝ) (a b : Fin 4 → ℝ) {c₀ : ℝ}
    (hA : ∀ x : Fin 4 → ℝ, c₀ * ∑ μ, x μ ^ 2 ≤ 4 * ∑ ν, (∑ μ, A μ ν * x μ) ^ 2)
    (v : Fin 4 → ℂ) :
    c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (2 * ph (a μ) * (A μ ν : ℂ) * ph (-(b ν))) * v μ‖ ^ 2 := by
  set z : Fin 4 → ℂ := fun μ => ph (-(a μ)) * v μ with hz_def
  have hz : ∀ μ, ‖v μ‖ ^ 2 = (z μ).re ^ 2 + (z μ).im ^ 2 := by
    intro μ
    have : ‖z μ‖ = ‖v μ‖ := by rw [hz_def]; simp only [norm_mul, norm_ph, one_mul]
    rw [← this, Complex.sq_norm, Complex.normSq_apply]; ring
  have hterm : ∀ ν, ‖∑ μ, conj (2 * ph (a μ) * (A μ ν : ℂ) * ph (-(b ν))) * v μ‖ ^ 2 =
      4 * ((∑ μ, A μ ν * (z μ).re) ^ 2 + (∑ μ, A μ ν * (z μ).im) ^ 2) := by
    intro ν
    have e : ∑ μ, conj (2 * ph (a μ) * (A μ ν : ℂ) * ph (-(b ν))) * v μ =
        ph (b ν) * (2 * ∑ μ, (A μ ν : ℂ) * z μ) := by
      rw [Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      rw [conj_entry, hz_def]
      ring
    rw [e, norm_mul, norm_ph, one_mul, norm_mul, Complex.norm_two, mul_pow,
      Complex.sq_norm, Complex.normSq_apply, Complex.re_sum, Complex.im_sum]
    simp only [Complex.re_ofReal_mul, Complex.im_ofReal_mul]
    ring
  simp only [hterm, hz]
  have hre := hA fun μ => (z μ).re
  have him := hA fun μ => (z μ).im
  rw [← Finset.mul_sum]
  have : ∑ μ, ((z μ).re ^ 2 + (z μ).im ^ 2) = ∑ μ, (z μ).re ^ 2 + ∑ μ, (z μ).im ^ 2 :=
    Finset.sum_add_distrib
  rw [this, mul_add]
  have : ∑ ν, ((∑ μ, A μ ν * (z μ).re) ^ 2 + (∑ μ, A μ ν * (z μ).im) ^ 2) =
      ∑ ν, (∑ μ, A μ ν * (z μ).re) ^ 2 + ∑ ν, (∑ μ, A μ ν * (z μ).im) ^ 2 :=
    Finset.sum_add_distrib
  rw [this]
  linarith

/-- The real entries `A_{μν} = cos(r_μ/2) N(r)_{μν}` at the alias `ζ*` satisfy the real bound
with `c₀ = 121/1152` (`lowest_alias_lower`). -/
theorem lowest_entries (θ x : Fin 4 → ℝ) :
    121 / 1152 * ∑ μ, x μ ^ 2 ≤
      4 * ∑ ν, (∑ μ, (cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) μ *
        NM (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2)) μ ν) * x μ) ^ 2 := by
  set ζ := zstar fun ν => Real.sin (θ ν) ^ 2
  have h := lowest_alias_lower θ x
  have hsymm : ∀ μ ν, NM (sR θ ζ) μ ν = NM (sR θ ζ) ν μ := fun μ ν => by
    have := congrFun (congrFun (NM_transpose (sR θ ζ)) ν) μ
    rw [Matrix.transpose_apply] at this
    exact this
  have hrow : ∀ ν, ∑ μ, (cR θ ζ μ * NM (sR θ ζ) μ ν) * x μ =
      Nm (sR θ ζ) (fun μ => cR θ ζ μ * x μ) ν := by
    intro ν
    rw [← NM_mulVec]
    simp only [Matrix.mulVec, dotProduct]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [hsymm μ ν]; ring
  simp only [hrow]
  have e1 : dot x x = ∑ μ, x μ ^ 2 := by
    unfold dot; exact Finset.sum_congr rfl fun i _ => by ring
  have e2 : dot (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * x ν) μ)
      (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * x ν) μ) =
      4 * ∑ ν, Nm (sR θ ζ) (fun μ => cR θ ζ μ * x μ) ν ^ 2 := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
  rw [e1, e2] at h
  exact h

/-- **`hc₀` from the closed form of the symbol at the lowest alias**: if, for every coarse
momentum `φ`, the symbol at the alias `sec φ` is `2 e^{ia} · W K̃ · e^{−ib}` with `W K̃` the
real matrix `cos(r_μ/2) N(r)_{μν}` at `r = r_{ζ*}(θ(φ))`, then the one-alias bound of
`torus_Cadj_lower` holds with `c₀ = 121/1152`. -/
theorem hc0_of_symbol {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
    (c : F → Fin 4 → Fin 4 → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (θ a b : AddChar G ℂ → Fin 4 → ℝ)
    (hQ : ∀ φ μ ν, TorusFourier.sym c (sec φ) μ ν =
      2 * ph (a φ μ) *
        ((cR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2) μ *
          NM (sR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2)) μ ν : ℝ) : ℂ) *
        ph (-(b φ ν)))
    (φ : AddChar G ℂ) (v : Fin 4 → ℂ) :
    121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (TorusFourier.sym c (sec φ) μ ν) * v μ‖ ^ 2 := by
  simp only [hQ]
  exact lift_core _ (a φ) (b φ) (lowest_entries (θ φ)) v

/-- **The real-space bound of the constraint on the four-dimensional torus from the closed
form alone**: `‖C†w‖² ≥ (121/18432)‖w‖²` with only the symbol identity `hQ` at the lowest
alias as hypothesis (the bound `hc₀` is discharged). -/
theorem torus_Cadj_lower_of_symbol (L : ℕ) [NeZero L]
    (c : (Fin 4 → ZMod (2 * L)) → Fin 4 → Fin 4 → ℂ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, TorusFourier.res (TorusFourier.betaT 4 L) (sec φ) = φ)
    (θ a b : AddChar (Fin 4 → ZMod L) ℂ → Fin 4 → ℝ)
    (hQ : ∀ φ μ ν, TorusFourier.sym c (sec φ) μ ν =
      2 * ph (a φ μ) *
        ((cR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2) μ *
          NM (sR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2)) μ ν : ℝ) : ℂ) *
        ph (-(b φ ν)))
    (w : (Fin 4 → ZMod L) → Fin 4 → ℂ) :
    121 / 18432 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤
      ∑ y, ∑ ν, ‖TorusFourier.Cadj (TorusFourier.betaT 4 L) c w y ν‖ ^ 2 :=
  TorusFourier.torus_Cadj_lower L c sec hsec (hc0_of_symbol c sec θ a b hQ) w

/-- **The real constraint operator on the four-dimensional torus is onto**, with only the
symbol identity at the lowest alias as hypothesis. -/
theorem torus_CopR_surjective_of_symbol (L : ℕ) [NeZero L]
    (c : (Fin 4 → ZMod (2 * L)) → Fin 4 → Fin 4 → ℝ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, TorusFourier.res (TorusFourier.betaT 4 L) (sec φ) = φ)
    (θ a b : AddChar (Fin 4 → ZMod L) ℂ → Fin 4 → ℝ)
    (hQ : ∀ φ μ ν, TorusFourier.sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν =
      2 * ph (a φ μ) *
        ((cR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2) μ *
          NM (sR (θ φ) (zstar fun ν => Real.sin (θ φ ν) ^ 2)) μ ν : ℝ) : ℂ) *
        ph (-(b φ ν))) :
    Function.Surjective (TorusFourier.CopR (TorusFourier.betaT 4 L) c) :=
  TorusFourier.torus_CopR_surjective L c sec hsec (hc0_of_symbol _ sec θ a b hQ)

end OneStepLift

end



/-!
# (L5) The paths of the block average and the closed form of their symbol

The linearised constraint at `U = 1`: for the coarse link `(X, μ)`
(fine base point `x = 2X`), for each transverse displacement `d ∈ {-1,0,1}³` (weights
`(1/8, 3/4, 1/8)` per transverse direction) and each of the `3! = 6` orders of the transverse
steps, walk the transverse steps, two `μ` steps, and the transverse steps back in reversed
order; the linearisation is the signed sum of the links walked, with coefficient `w(d)/6`.

`walk μ o A` is that list of signed links (relative to `x`), `pathSym k μ ν` the weighted sum of
`exp(i k·pos)` over the links in direction `ν` (the symbol `Σ_r c(r)_{μν} ψ(r)` at the character
`ψ(r) = exp(i k·r)`).  **`pathSym_closed`**:

  `pathSym k μ ν = e^{i k_μ} · 2 cos(k_μ/2) N(s(k))_{μν} · e^{-i k_ν/2}`,   `s(k) = sin(k/2)`,

with `N = NM` the transverse average of `OneStepBridge` (`α = 1/8`), i.e. the complex symbol is
`Q(k) = diag(e^{ik}) Q̃(k) diag(e^{-ik/2})`, `Q̃ = 2 C N`.
-/

noncomputable section

namespace LatticePath

open Complex Finset OneStepNorm OneStepHrep OneStepBridge

/-! ## The paths -/

/-- The transverse directions of `μ`, in increasing order. -/
def tr : Fin 4 → Fin 3 → Fin 4 := ![![1, 2, 3], ![0, 2, 3], ![0, 1, 3], ![0, 1, 2]]

/-- The six orders of the three transverse slots. -/
def ord : Fin 6 → Fin 3 → Fin 3 :=
  ![![0, 1, 2], ![0, 2, 1], ![1, 0, 2], ![1, 2, 0], ![2, 0, 1], ![2, 1, 0]]

theorem ord_injective (o : Fin 6) : Function.Injective (ord o) := by
  fin_cases o <;> decide

theorem ord_distinct : Function.Injective ord := by decide

theorem tr_ne (μ : Fin 4) (t : Fin 3) : tr μ t ≠ μ := by
  fin_cases μ <;> fin_cases t <;> decide

theorem tr_injective (μ : Fin 4) : Function.Injective (tr μ) := by
  fin_cases μ <;> decide

/-- Displacement values and weights `(α, 1 − 2α, α)`, `α = 1/8`. -/
def dv : Fin 3 → ℤ := ![-1, 0, 1]
def wt : Fin 3 → ℝ := ![1 / 8, 3 / 4, 1 / 8]

theorem wt_sum : ∑ a, wt a = 1 := by simp [wt, Fin.sum_univ_three]; norm_num

def ev (n : Fin 4) : Fin 4 → ℤ := Pi.single n 1

/-- A signed link: (sign, base point, direction). -/
abbrev Link := ℤ × (Fin 4 → ℤ) × Fin 4

/-- A forward transverse step of displacement `d` from `z` in direction `n`. -/
def fwd (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(1, z, n)] else if d = -1 then [(-1, z - ev n, n)] else []

/-- The step undoing it, from the point `w` reached after it. -/
def back (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(-1, w - ev n, n)] else if d = -1 then [(1, w, n)] else []

/-- The path of the coarse link in direction `μ` for the order `o` and the displacement
indices `A` (slot `t` is displaced by `dv (A t)` in direction `tr μ t`). -/
def walk (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : List Link :=
  let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  let z1 := d 0 • ev (n 0)
  let z2 := z1 + d 1 • ev (n 1)
  let z3 := z2 + d 2 • ev (n 2)
  let w3 := z3 + 2 • ev μ
  let w2 := w3 - d 2 • ev (n 2)
  let w1 := w2 - d 1 • ev (n 1)
  fwd (d 0) 0 (n 0) ++ fwd (d 1) z1 (n 1) ++ fwd (d 2) z2 (n 2) ++
    [(1, z3, μ), (1, z3 + ev μ, μ)] ++
    back (d 2) w3 (n 2) ++ back (d 1) w2 (n 1) ++ back (d 0) w1 (n 0)

/-- The path closes on `x + 2 e_μ`: the last return step lands there. -/
theorem walk_end (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
    let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
    d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ
      - d 2 • ev (n 2) - d 1 • ev (n 1) - d 0 • ev (n 0) = 2 • ev μ := by
  intro n d
  abel

/-! ## Symbols -/

/-- `E(z) = exp(i k·z)`. -/
def E (k : Fin 4 → ℝ) (z : Fin 4 → ℤ) : ℂ := cexp (I * ∑ n, (k n : ℂ) * (z n : ℂ))

def linkSym (k : Fin 4 → ℝ) (ν : Fin 4) (l : Link) : ℂ :=
  if l.2.2 = ν then (l.1 : ℂ) * E k l.2.1 else 0

def listSym (k : Fin 4 → ℝ) (ν : Fin 4) (L : List Link) : ℂ := (L.map (linkSym k ν)).sum

/-- **The symbol of the averaged paths**, entry `(μ, ν)`. -/
def pathSym (k : Fin 4 → ℝ) (μ ν : Fin 4) : ℂ :=
  ∑ o : Fin 6, ∑ a0 : Fin 3, ∑ a1 : Fin 3, ∑ a2 : Fin 3,
    ((wt a0 * wt a1 * wt a2 / 6 : ℝ) : ℂ) * listSym k ν (walk μ o ![a0, a1, a2])

theorem listSym_append (k : Fin 4 → ℝ) (ν : Fin 4) (L₁ L₂ : List Link) :
    listSym k ν (L₁ ++ L₂) = listSym k ν L₁ + listSym k ν L₂ := by
  simp [listSym, List.map_append, List.sum_append]

theorem E_add (k : Fin 4 → ℝ) (z w : Fin 4 → ℤ) : E k (z + w) = E k z * E k w := by
  unfold E
  rw [← Complex.exp_add]
  congr 1
  simp only [Pi.add_apply, Int.cast_add, mul_add, Finset.sum_add_distrib]

theorem E_zero (k : Fin 4 → ℝ) : E k 0 = 1 := by simp [E]

theorem E_neg (k : Fin 4 → ℝ) (z : Fin 4 → ℤ) : E k (-z) = (E k z)⁻¹ := by
  unfold E
  rw [← Complex.exp_neg]
  congr 1
  simp only [Pi.neg_apply, Int.cast_neg, mul_neg, Finset.sum_neg_distrib]

theorem E_sub (k : Fin 4 → ℝ) (z w : Fin 4 → ℤ) : E k (z - w) = E k z * E k (-w) := by
  rw [sub_eq_add_neg, E_add]

/-- `E(m e_n) = exp(i k_n m)`. -/
theorem E_smul_ev (k : Fin 4 → ℝ) (m : ℤ) (n : Fin 4) :
    E k (m • ev n) = cexp (I * (k n : ℂ) * (m : ℂ)) := by
  unfold E ev
  congr 1
  rw [mul_assoc]
  congr 1
  rw [Finset.sum_eq_single n]
  · simp
  · intro b _ hb; simp [Pi.single_apply, hb]
  · simp

theorem E_ev (k : Fin 4 → ℝ) (n : Fin 4) : E k (ev n) = cexp (I * (k n : ℂ)) := by
  have := E_smul_ev k 1 n
  simpa using this

theorem E_neg_ev (k : Fin 4 → ℝ) (n : Fin 4) : E k (-ev n) = cexp (-(I * (k n : ℂ))) := by
  rw [E_neg, E_ev, Complex.exp_neg]

/-- The momentum phases `p_n = e^{ik_n}`, `q_n = e^{-ik_n}`. -/
def pk (k : Fin 4 → ℝ) (n : Fin 4) : ℂ := cexp (I * (k n : ℂ))
def qk (k : Fin 4 → ℝ) (n : Fin 4) : ℂ := cexp (-(I * (k n : ℂ)))

/-- The phase of a transverse step of displacement index `a`: `![q_n, 1, p_n] a`. -/
def gvA (p q : Fin 4 → ℂ) (n : Fin 4) : Fin 3 → ℂ := ![q n, 1, p n]

/-- The out-and-back value of a transverse step: `![-q_n, 0, 1] a`. -/
def pvA (q : Fin 4 → ℂ) (n : Fin 4) : Fin 3 → ℂ := ![-q n, 0, 1]

theorem E_dv (k : Fin 4 → ℝ) (n : Fin 4) (a : Fin 3) :
    E k (dv a • ev n) = gvA (pk k) (qk k) n a := by
  rw [E_smul_ev]
  fin_cases a <;> simp [dv, gvA, pk, qk]

theorem fwd_neg (z : Fin 4 → ℤ) (n : Fin 4) : fwd (-1) z n = [(-1, z - ev n, n)] := by
  simp [fwd]
theorem back_neg (w : Fin 4 → ℤ) (n : Fin 4) : back (-1) w n = [(1, w, n)] := by simp [back]
theorem fwd_zero (z : Fin 4 → ℤ) (n : Fin 4) : fwd 0 z n = [] := by simp [fwd]
theorem back_zero (w : Fin 4 → ℤ) (n : Fin 4) : back 0 w n = [] := by simp [back]
theorem fwd_pos (z : Fin 4 → ℤ) (n : Fin 4) : fwd 1 z n = [(1, z, n)] := by simp [fwd]
theorem back_pos (w : Fin 4 → ℤ) (n : Fin 4) : back 1 w n = [(-1, w - ev n, n)] := by
  simp [back]

theorem listSym_one (k : Fin 4 → ℝ) (ν : Fin 4) (l : Link) :
    listSym k ν [l] = linkSym k ν l := by simp [listSym]

theorem pair_neg (k : Fin 4 → ℝ) (ν μ n : Fin 4) (z : Fin 4 → ℤ) :
    listSym k ν (fwd (dv 0) z n) + listSym k ν (back (dv 0) (z + dv 0 • ev n + 2 • ev μ) n) =
      if n = ν then E k z * pvA (qk k) n 0 * (1 - E k (2 • ev μ)) else 0 := by
  rw [show dv 0 = -1 from rfl, fwd_neg, back_neg, listSym_one, listSym_one]
  simp only [linkSym]
  split_ifs with h
  · have e : z + (-1 : ℤ) • ev n + 2 • ev μ = z + -ev n + 2 • ev μ := by
      rw [neg_one_smul]
    rw [e, E_sub, E_add, E_add, E_neg_ev]
    simp only [pvA, qk, Matrix.cons_val_zero]
    push_cast; ring
  · simp

theorem pair_zero (k : Fin 4 → ℝ) (ν μ n : Fin 4) (z : Fin 4 → ℤ) :
    listSym k ν (fwd (dv 1) z n) + listSym k ν (back (dv 1) (z + dv 1 • ev n + 2 • ev μ) n) =
      if n = ν then E k z * pvA (qk k) n 1 * (1 - E k (2 • ev μ)) else 0 := by
  rw [show dv 1 = 0 from rfl, fwd_zero, back_zero]
  simp [listSym, pvA]

theorem pair_pos (k : Fin 4 → ℝ) (ν μ n : Fin 4) (z : Fin 4 → ℤ) :
    listSym k ν (fwd (dv 2) z n) + listSym k ν (back (dv 2) (z + dv 2 • ev n + 2 • ev μ) n) =
      if n = ν then E k z * pvA (qk k) n 2 * (1 - E k (2 • ev μ)) else 0 := by
  rw [show dv 2 = 1 from rfl, fwd_pos, back_pos, listSym_one, listSym_one]
  simp only [linkSym]
  split_ifs with h
  · have e : z + (1 : ℤ) • ev n + 2 • ev μ - ev n = z + 2 • ev μ := by
      rw [one_smul]; abel
    rw [e, E_add]
    simp only [pvA, Matrix.cons_val_two, Matrix.tail_cons, Matrix.head_cons]
    push_cast; ring
  · simp

/-- **A transverse step and its return** contribute `E(z) pv (1 − E(2e_μ))` in direction `n`. -/
theorem pair_sym (k : Fin 4 → ℝ) (ν μ n : Fin 4) (z : Fin 4 → ℤ) (a : Fin 3) :
    listSym k ν (fwd (dv a) z n) + listSym k ν (back (dv a) (z + dv a • ev n + 2 • ev μ) n) =
      if n = ν then E k z * pvA (qk k) n a * (1 - E k (2 • ev μ)) else 0 := by
  fin_cases a
  · exact pair_neg k ν μ n z
  · exact pair_zero k ν μ n z
  · exact pair_pos k ν μ n z

/-- The value of one path in terms of the phases (`p, q` free). -/
def pathA (p q : Fin 4 → ℂ) (μ ν : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : ℂ :=
  (if μ = ν then gvA p q (tr μ (ord o 0)) (A (ord o 0)) * gvA p q (tr μ (ord o 1)) (A (ord o 1)) *
      gvA p q (tr μ (ord o 2)) (A (ord o 2)) * (1 + p μ) else 0) +
  ((if tr μ (ord o 0) = ν then pvA q (tr μ (ord o 0)) (A (ord o 0)) * (1 - p μ ^ 2) else 0) +
   (if tr μ (ord o 1) = ν then gvA p q (tr μ (ord o 0)) (A (ord o 0)) *
      pvA q (tr μ (ord o 1)) (A (ord o 1)) * (1 - p μ ^ 2) else 0) +
   (if tr μ (ord o 2) = ν then gvA p q (tr μ (ord o 0)) (A (ord o 0)) *
      gvA p q (tr μ (ord o 1)) (A (ord o 1)) * pvA q (tr μ (ord o 2)) (A (ord o 2)) *
      (1 - p μ ^ 2) else 0))

theorem E_two_ev (k : Fin 4 → ℝ) (μ : Fin 4) : E k (2 • ev μ) = pk k μ ^ 2 := by
  rw [two_smul, E_add, E_ev, sq]; rfl

/-- **One path**: spine plus three out-and-back pairs. -/
theorem walk_sym (k : Fin 4 → ℝ) (μ ν : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    listSym k ν (walk μ o A) = pathA (pk k) (qk k) μ ν o A := by
  set n : Fin 3 → Fin 4 := fun j => tr μ (ord o j) with hn
  set a : Fin 3 → Fin 3 := fun j => A (ord o j) with ha
  set z1 : Fin 4 → ℤ := dv (a 0) • ev (n 0) with hz1
  set z2 : Fin 4 → ℤ := z1 + dv (a 1) • ev (n 1) with hz2
  set z3 : Fin 4 → ℤ := z2 + dv (a 2) • ev (n 2) with hz3
  have hw : walk μ o A = fwd (dv (a 0)) 0 (n 0) ++ fwd (dv (a 1)) z1 (n 1) ++
      fwd (dv (a 2)) z2 (n 2) ++ [(1, z3, μ), (1, z3 + ev μ, μ)] ++
      back (dv (a 2)) (z2 + dv (a 2) • ev (n 2) + 2 • ev μ) (n 2) ++
      back (dv (a 1)) (z1 + dv (a 1) • ev (n 1) + 2 • ev μ) (n 1) ++
      back (dv (a 0)) (0 + dv (a 0) • ev (n 0) + 2 • ev μ) (n 0) := by
    have e2 : z3 + 2 • ev μ - dv (a 2) • ev (n 2) = z1 + dv (a 1) • ev (n 1) + 2 • ev μ := by
      rw [hz3, hz2]; abel
    have e1 : z3 + 2 • ev μ - dv (a 2) • ev (n 2) - dv (a 1) • ev (n 1) =
        0 + dv (a 0) • ev (n 0) + 2 • ev μ := by
      rw [hz3, hz2, hz1]; abel
    simp only [walk]
    rw [← e1, ← e2]
  rw [hw]
  simp only [listSym_append]
  have p0 := pair_sym k ν μ (n 0) 0 (a 0)
  have p1 := pair_sym k ν μ (n 1) z1 (a 1)
  have p2 := pair_sym k ν μ (n 2) z2 (a 2)
  have hs : listSym k ν [(1, z3, μ), (1, z3 + ev μ, μ)] =
      if μ = ν then E k z3 * (1 + E k (ev μ)) else 0 := by
    simp only [listSym, linkSym, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
    split_ifs
    · rw [E_add k z3 (ev μ)]; push_cast; ring
    · simp
  have hz1' : E k z1 = gvA (pk k) (qk k) (n 0) (a 0) := E_dv k (n 0) (a 0)
  have hz2' : E k z2 = gvA (pk k) (qk k) (n 0) (a 0) * gvA (pk k) (qk k) (n 1) (a 1) := by
    rw [hz2, E_add, hz1', E_dv]
  have hz3' : E k z3 = gvA (pk k) (qk k) (n 0) (a 0) * gvA (pk k) (qk k) (n 1) (a 1) *
      gvA (pk k) (qk k) (n 2) (a 2) := by
    rw [hz3, E_add, hz2', E_dv]
  rw [hs, hz3']
  rw [E_zero] at p0
  rw [hz1'] at p1
  rw [hz2'] at p2
  have hre : ∀ x0 x1 x2 x3 x4 x5 x7 : ℂ,
      x0 + x1 + x2 + x7 + x3 + x4 + x5 = x7 + ((x0 + x5) + (x1 + x4) + (x2 + x3)) := by
    intros; ring
  rw [hre, p0, p1, p2, E_two_ev, E_ev]
  simp only [one_mul, pathA]
  rfl

/-! ## The Laurent form of the averaged symbol -/

/-- `m_n = α q_n + (1 − 2α) + α p_n` (the transverse average of one direction). -/
def MvA (p q : Fin 4 → ℂ) (n : Fin 4) : ℂ := (1 / 8) * q n + 3 / 4 + (1 / 8) * p n

/-- `𝔅` for the complementary pair `(x, y)`: the average over the orders of the product of the
`m` of the directions walked before. -/
def BvA (p q : Fin 4 → ℂ) (x y : Fin 4) : ℂ :=
  1 / 3 + (MvA p q x + MvA p q y) / 6 + MvA p q x * MvA p q y / 3

def piVA (p q : Fin 4 → ℂ) : Fin 4 → ℂ :=
  ![MvA p q 1 * MvA p q 2 * MvA p q 3, MvA p q 0 * MvA p q 2 * MvA p q 3,
    MvA p q 0 * MvA p q 1 * MvA p q 3, MvA p q 0 * MvA p q 1 * MvA p q 2]

def BVA (p q : Fin 4 → ℂ) : Fin 4 → Fin 4 → ℂ :=
  ![![0, BvA p q 2 3, BvA p q 1 3, BvA p q 1 2],
    ![BvA p q 2 3, 0, BvA p q 0 3, BvA p q 0 2],
    ![BvA p q 1 3, BvA p q 0 3, 0, BvA p q 0 1],
    ![BvA p q 1 2, BvA p q 0 2, BvA p q 0 1, 0]]

/-- The Laurent form: diagonal `π_μ (1 + p_μ)`, off-diagonal `α (1 − q_ν)(1 − p_μ²) 𝔅_{μν}`. -/
def lauA (p q : Fin 4 → ℂ) (μ ν : Fin 4) : ℂ :=
  if μ = ν then piVA p q μ * (1 + p μ) else (1 / 8) * (1 - q ν) * (1 - p μ ^ 2) * BVA p q μ ν

/-- The weighted average over orders and displacements. -/
def avgA (p q : Fin 4 → ℂ) (μ ν : Fin 4) : ℂ :=
  ∑ o : Fin 6, ∑ a0 : Fin 3, ∑ a1 : Fin 3, ∑ a2 : Fin 3,
    ((wt a0 * wt a1 * wt a2 / 6 : ℝ) : ℂ) * pathA p q μ ν o ![a0, a1, a2]

set_option maxHeartbeats 4000000 in
theorem lau0 (p q : Fin 4 → ℂ) (ν : Fin 4) : avgA p q 0 ν = lauA p q 0 ν := by
  fin_cases ν <;>
    simp [avgA, pathA, lauA, BVA, BvA, MvA, gvA, pvA, Fin.sum_univ_succ, ord, tr, wt, piVA] <;>
    ring
set_option maxHeartbeats 4000000 in
theorem lau1 (p q : Fin 4 → ℂ) (ν : Fin 4) : avgA p q 1 ν = lauA p q 1 ν := by
  fin_cases ν <;>
    simp [avgA, pathA, lauA, BVA, BvA, MvA, gvA, pvA, Fin.sum_univ_succ, ord, tr, wt, piVA] <;>
    ring
set_option maxHeartbeats 4000000 in
theorem lau2 (p q : Fin 4 → ℂ) (ν : Fin 4) : avgA p q 2 ν = lauA p q 2 ν := by
  fin_cases ν <;>
    simp [avgA, pathA, lauA, BVA, BvA, MvA, gvA, pvA, Fin.sum_univ_succ, ord, tr, wt, piVA] <;>
    ring
set_option maxHeartbeats 4000000 in
theorem lau3 (p q : Fin 4 → ℂ) (ν : Fin 4) : avgA p q 3 ν = lauA p q 3 ν := by
  fin_cases ν <;>
    simp [avgA, pathA, lauA, BVA, BvA, MvA, gvA, pvA, Fin.sum_univ_succ, ord, tr, wt, piVA] <;>
    ring

theorem avg_lau (p q : Fin 4 → ℂ) (μ ν : Fin 4) : avgA p q μ ν = lauA p q μ ν := by
  fin_cases μ
  · exact lau0 p q ν
  · exact lau1 p q ν
  · exact lau2 p q ν
  · exact lau3 p q ν

/-- **The averaged path sum in Laurent form.** -/
theorem pathSym_lau (k : Fin 4 → ℝ) (μ ν : Fin 4) :
    pathSym k μ ν = lauA (pk k) (qk k) μ ν := by
  rw [← avg_lau]
  unfold pathSym avgA
  simp only [walk_sym]

/-! ## The closed form -/

/-- `s(k) = sin(k/2)` (componentwise). -/
def sk (k : Fin 4 → ℝ) : Fin 4 → ℝ := fun n => Real.sin (k n / 2)

theorem exp_mul_nat (t : ℝ) (m : ℕ) :
    cexp (I * ((m * t : ℝ) : ℂ)) = cexp (I * (t : ℂ)) ^ m := by
  rw [← Complex.exp_nat_mul]; congr 1; push_cast; ring

theorem cos_sin_exp (t : ℝ) :
    cexp (I * (t : ℂ)) = (Real.cos t : ℂ) + (Real.sin t : ℂ) * I := by
  rw [mul_comm, Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]

theorem cos_sin_exp_neg (t : ℝ) :
    cexp (-(I * (t : ℂ))) = (Real.cos t : ℂ) - (Real.sin t : ℂ) * I := by
  have h := cos_sin_exp (-t)
  rw [Real.cos_neg, Real.sin_neg, Complex.ofReal_neg, mul_neg] at h
  rw [h, Complex.ofReal_neg]; ring

theorem alg_off (ca sa cb sb : ℂ) (h1 : sa ^ 2 + ca ^ 2 = 1) (h2 : sb ^ 2 + cb ^ 2 = 1) :
    (1 / 8 : ℂ) * (1 - (cb - sb * I) ^ 2) * (1 - ((ca + sa * I) ^ 2) ^ 2) =
      (ca + sa * I) ^ 2 * (ca * sa * sb) * (cb - sb * I) := by
  have hI : I ^ 2 = -1 := Complex.I_sq
  linear_combination (3*Complex.I^4*sa^2*sb^2/4 + Complex.I^3*ca*sa*sb^2/2 - 3*Complex.I^3*cb*sa^2*sb/2 + Complex.I^2*ca^2*sb^2/8 - Complex.I^2*ca*cb*sa*sb + 3*Complex.I^2*cb^2*sa^2/4 + 15*Complex.I^2*sa^2*sb^2/8 - 3*Complex.I^2*sa^2/4 + Complex.I^2*sb^2/8 - Complex.I*ca^2*cb*sb/4 + Complex.I*ca*cb^2*sa/2 + Complex.I*ca*sa*sb^2 - Complex.I*ca*sa/2 - 7*Complex.I*cb*sa^2*sb/4 - Complex.I*cb*sb/4 + ca^2*cb^2/8 - ca^2/8 - ca*cb*sa*sb - cb^2*sa^2/8 + cb^2/8 + sa^2/8 - 1/8) * h1 + (Complex.I^4*sa^4/8 + Complex.I^3*ca*sa^3/2 - 3*Complex.I^2*sa^4/4 + 3*Complex.I^2*sa^2/4 - Complex.I*ca*sa^3/2 + Complex.I*ca*sa/2 + sa^4/8 - sa^2/4) * h2 + (Complex.I^4*sa^4*sb^2/8 + Complex.I^3*ca*sa^3*sb^2/2 - Complex.I^3*cb*sa^4*sb/4 - Complex.I^2*ca*cb*sa^3*sb - Complex.I^2*sa^4*sb^2 + 3*Complex.I^2*sa^2*sb^2/4 - Complex.I*ca*sa^3*sb^2/2 + Complex.I*ca*sa*sb^2/2 + 7*Complex.I*cb*sa^4*sb/4 - 3*Complex.I*cb*sa^2*sb/2 + ca*cb*sa^3*sb - ca*cb*sa*sb - sa^4*sb^2/8 + sa^2*sb^2/4) * hI

theorem alg_one (ca sa : ℂ) (h1 : sa ^ 2 + ca ^ 2 = 1) :
    1 + (ca + sa * I) ^ 2 = 2 * ca * (ca + sa * I) := by
  have hI : I ^ 2 = -1 := Complex.I_sq
  linear_combination (-1) * h1 + (sa^2) * hI

theorem sc_one (t : ℝ) : (Real.sin t : ℂ) ^ 2 + (Real.cos t : ℂ) ^ 2 = 1 := by
  exact_mod_cast Real.sin_sq_add_cos_sq t

theorem half_twice (t : ℝ) : t = 2 * (t / 2) := by ring

/-- `1 + e^{it} = 2 cos(t/2) e^{it/2}`. -/
theorem one_add_exp (t : ℝ) :
    1 + cexp (I * (t : ℂ)) = 2 * (Real.cos (t / 2) : ℂ) * cexp (I * ((t / 2 : ℝ) : ℂ)) := by
  conv_lhs => rw [half_twice t]
  have e : ((2 * (t / 2) : ℝ) : ℂ) = (((2 : ℕ) : ℝ) * (t / 2) : ℝ) := by norm_num
  rw [e, exp_mul_nat, cos_sin_exp]
  exact alg_one _ _ (sc_one _)

/-- `α (1 − e^{-ib}) (1 − e^{2ia}) = e^{ia} cos(a/2) sin(a/2) sin(b/2) e^{-ib/2}` (`α = 1/8`). -/
theorem off_factor (a b : ℝ) :
    (1 / 8 : ℂ) * (1 - cexp (-(I * (b : ℂ)))) * (1 - cexp (I * (a : ℂ)) ^ 2) =
      cexp (I * (a : ℂ)) * ((Real.cos (a / 2) * Real.sin (a / 2) * Real.sin (b / 2) : ℝ) : ℂ) *
        cexp (-(I * ((b / 2 : ℝ) : ℂ))) := by
  have ea : cexp (I * (a : ℂ)) = cexp (I * ((a / 2 : ℝ) : ℂ)) ^ 2 := by
    rw [← exp_mul_nat]; congr 3; push_cast; ring
  have eb : cexp (-(I * (b : ℂ))) = cexp (-(I * ((b / 2 : ℝ) : ℂ))) ^ 2 := by
    rw [← Complex.exp_nat_mul]; congr 1; push_cast; ring
  rw [eb, ea, cos_sin_exp, cos_sin_exp_neg, Complex.ofReal_mul, Complex.ofReal_mul]
  exact alg_off _ _ _ _ (sc_one _) (sc_one _)

/-- `m_n = 1 − x_n` with `x_n = s_n²/2` (`α = 1/8`). -/
theorem Mv_eq (k : Fin 4 → ℝ) (n : Fin 4) :
    MvA (pk k) (qk k) n = ((1 - xs (sk k) n : ℝ) : ℂ) := by
  unfold MvA xs sk pk qk
  rw [cos_sin_exp, cos_sin_exp_neg]
  have hc : Real.cos (k n) = 1 - 2 * Real.sin (k n / 2) ^ 2 := by
    conv_lhs => rw [half_twice (k n)]
    rw [Real.cos_two_mul, Real.cos_sq']; ring
  rw [hc]
  simp only [Complex.ofReal_sub, Complex.ofReal_one, Complex.ofReal_mul, Complex.ofReal_div,
    Complex.ofReal_pow, Complex.ofReal_ofNat]
  ring

theorem Bv_eq (k : Fin 4 → ℝ) (x y : Fin 4) :
    BvA (pk k) (qk k) x y = ((1 - Ef (xs (sk k) x) (xs (sk k) y) : ℝ) : ℂ) := by
  unfold BvA Ef
  rw [Mv_eq, Mv_eq]
  push_cast; ring

theorem piV_eq (k : Fin 4 → ℝ) (μ : Fin 4) :
    piVA (pk k) (qk k) μ = ((piF (xs (sk k)) μ : ℝ) : ℂ) := by
  fin_cases μ <;> simp [piVA, piF, Mv_eq]

theorem BV_eq (k : Fin 4 → ℝ) (μ ν : Fin 4) (h : μ ≠ ν) :
    BVA (pk k) (qk k) μ ν = ((1 - EF (xs (sk k)) μ ν : ℝ) : ℂ) := by
  fin_cases μ <;> fin_cases ν <;> simp_all [BVA, EF, Bv_eq]

/-- **(L5) The closed form of the path symbol**:
`Σ_paths w/6 Σ_links ± e^{ik·pos} = e^{ik_μ} · 2 cos(k_μ/2) N(s(k))_{μν} · e^{-ik_ν/2}`. -/
theorem pathSym_closed (k : Fin 4 → ℝ) (μ ν : Fin 4) :
    pathSym k μ ν = cexp (I * (k μ : ℂ)) *
      ((2 * Real.cos (k μ / 2) * NM (sk k) μ ν : ℝ) : ℂ) * cexp (-(I * ((k ν / 2 : ℝ) : ℂ))) := by
  rw [pathSym_lau]
  unfold lauA
  by_cases h : μ = ν
  · subst h
    rw [if_pos rfl, piV_eq, show pk k μ = cexp (I * (k μ : ℂ)) from rfl, one_add_exp]
    simp only [NM, Matrix.of_apply, if_true]
    have e : cexp (I * (k μ : ℂ)) * cexp (-(I * ((k μ / 2 : ℝ) : ℂ))) =
        cexp (I * ((k μ / 2 : ℝ) : ℂ)) := by
      rw [← Complex.exp_add]; congr 1; push_cast; ring
    simp only [Complex.ofReal_mul, Complex.ofReal_ofNat]
    linear_combination (-(2 * (Real.cos (k μ / 2) : ℂ) * ((piF (xs (sk k)) μ : ℝ) : ℂ))) * e
  · rw [if_neg h, show pk k μ = cexp (I * (k μ : ℂ)) from rfl,
      show qk k ν = cexp (-(I * (k ν : ℂ))) from rfl, off_factor, BV_eq k μ ν h]
    simp only [NM, Matrix.of_apply, if_neg h, sk]
    simp only [Complex.ofReal_mul, Complex.ofReal_sub, Complex.ofReal_one, Complex.ofReal_ofNat,
      Complex.ofReal_div]
    ring

end LatticePath

end

/-!
# (L4) Characters of the torus, the path kernel in real space, its symbol, and the aliases;
# (L2) the phases; the one-step map of a stage covariance on the torus

* `chi N n` is the character `y ↦ exp(2πi n·y/N)` of `(ℤ/N)⁴` (`ZMod.stdAddChar`);
  `chi_intCast`: on integer points it is `E k z = exp(i k·z)` with `k = 2πn/N`.
* `pathKernel N` is the real-space kernel of the block average: `c(r)_{μν}` is the weighted
  signed count of the links `(r, ν)` on the paths of `LatticePath.walk μ` (as in
  a generating script); `sym_pathKernel`: its symbol at `chi N n` is `pathSym (2πn/N)`.
* `res_chi`, `chi_alias_injective`, `sum_alias`: the aliases of `chi L m` under `X ↦ 2X` are
  exactly the sixteen `chi (2L) (m + Lη)`, `η ∈ {0,1}⁴` (count from `torus_card_alias`).
* `sym_alias`: (L2) at the alias `η` the symbol is
  `e^{2iθ_μ} (S_η Q̃(r_η))_{μν} e^{-2iθ'_ν}` with `θ = q/4`, `θ' = thR θ η = r_η/4` and
  `Q̃ = 2 C N` real (the phases of §0).
* `torus_step`: if a translation-invariant stage operator on the fine torus has the phase form
  `e^{2iθ'} X(θ') e^{-2iθ'}`, then `C T C†` on the coarse torus has the phase form with the real
  recursion `RM X` (`(RM X)(θ) = (1/16) Σ_η S_ηQ̃ X(thR θ η) (S_ηQ̃)ᵀ`).
-/

noncomputable section

namespace LatticeTorus

open Complex Finset TorusFourier LatticePath OneStepHrep OneStepBridge
open scoped ComplexConjugate Real Matrix

/-! ## Characters -/

/-- `y ↦ Σ_j n_j y_j` on `(ℤ/N)⁴`. -/
def dotHom (N : ℕ) (n : Fin 4 → ℤ) : (Fin 4 → ZMod N) →+ ZMod N where
  toFun y := ∑ j, (n j : ZMod N) * y j
  map_zero' := by simp
  map_add' x y := by simp [mul_add, Finset.sum_add_distrib]

/-- The character `y ↦ exp(2πi n·y/N)`. -/
def chi (N : ℕ) [NeZero N] (n : Fin 4 → ℤ) : AddChar (Fin 4 → ZMod N) ℂ :=
  (ZMod.stdAddChar (N := N)).compAddMonoidHom (dotHom N n)

/-- The real momentum `k = 2πn/N`. -/
def kOf (N : ℕ) (n : Fin 4 → ℤ) : Fin 4 → ℝ := fun j => 2 * π * n j / N

theorem chi_intCast (N : ℕ) [NeZero N] (n z : Fin 4 → ℤ) :
    chi N n (fun j => (z j : ZMod N)) = E (kOf N n) z := by
  unfold chi E kOf
  rw [AddChar.compAddMonoidHom_apply]
  have e : dotHom N n (fun j => (z j : ZMod N)) = ((∑ j, n j * z j : ℤ) : ZMod N) := by
    simp [dotHom]
  rw [e, ZMod.stdAddChar_coe]
  congr 1
  push_cast
  rw [Finset.mul_sum, Finset.sum_div, Finset.mul_sum]
  refine Finset.sum_congr rfl fun j _ => ?_
  ring

/-! ## The path kernel in real space -/

/-- The coefficient of the fine link `(x + r, ν)` in the coarse link `(X, μ)`, `x = 2X`. -/
def pathKernel (N : ℕ) : (Fin 4 → ZMod N) → Fin 4 → Fin 4 → ℂ := fun r μ ν =>
  ∑ o : Fin 6, ∑ a0 : Fin 3, ∑ a1 : Fin 3, ∑ a2 : Fin 3,
    ((wt a0 * wt a1 * wt a2 / 6 : ℝ) : ℂ) * ((walk μ o ![a0, a1, a2]).map fun l =>
      if l.2.2 = ν ∧ (fun j => (l.2.1 j : ZMod N)) = r then (l.1 : ℂ) else 0).sum

theorem list_sum_mul {R : Type*} [Fintype R] (L : List Link) (f : Link → R → ℂ) (g : R → ℂ) :
    ∑ r, (L.map fun l => f l r).sum * g r = (L.map fun l => ∑ r, f l r * g r).sum := by
  induction L with
  | nil => simp
  | cons l L ih =>
    simp only [List.map_cons, List.sum_cons, add_mul, Finset.sum_add_distrib, ih]

/-- **The symbol of the real-space path kernel** at `chi N n` is the path sum at `k = 2πn/N`. -/
theorem sym_pathKernel (N : ℕ) [NeZero N] (n : Fin 4 → ℤ) (μ ν : Fin 4) :
    sym (pathKernel N) (chi N n) μ ν = pathSym (kOf N n) μ ν := by
  unfold sym pathKernel pathSym
  simp only [Finset.sum_mul]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun o _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun a0 _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun a1 _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun a2 _ => ?_
  simp only [mul_assoc]
  rw [← Finset.mul_sum]
  congr 1
  rw [list_sum_mul]
  unfold listSym
  congr 1
  refine List.map_congr_left fun l _ => ?_
  unfold linkSym
  by_cases h : l.2.2 = ν
  · simp only [h, true_and, if_true]
    rw [Finset.sum_eq_single (fun j => (l.2.1 j : ZMod N))]
    · rw [if_pos rfl, chi_intCast]
    · intro b _ hb; rw [if_neg (Ne.symm hb), zero_mul]
    · simp
  · simp [h]

/-! ## The aliases -/

def bz (b : Bool) : ℤ := if b then 1 else 0

/-- The fine label `m + Lη`. -/
def aliasN (L : ℕ) (m : Fin 4 → ℤ) (η : Fin 4 → Bool) : Fin 4 → ℤ := fun j => m j + L * bz (η j)

theorem exp_two_pi_int (z : ℤ) : cexp (2 * π * I * z) = 1 := by
  rw [show 2 * π * I * (z : ℂ) = z * (2 * π * I) by ring, Complex.exp_int_mul_two_pi_mul_I]

theorem res_chi (L : ℕ) [NeZero L] (m : Fin 4 → ℤ) (η : Fin 4 → Bool) :
    res (betaT 4 L) (chi (2 * L) (aliasN L m η)) = chi L m := by
  ext X
  rw [res_apply]
  have hX : X = fun j => (((X j).val : ℤ) : ZMod L) := by
    funext j; simp
  rw [hX]
  have hb : betaT 4 L (fun j => (((X j).val : ℤ) : ZMod L)) =
      fun j => ((2 * ((X j).val : ℤ) : ℤ) : ZMod (2 * L)) := by
    funext j
    simp only [betaT, AddMonoidHom.compLeft_apply, Function.comp_apply, dbl_intCast]
    push_cast; ring
  rw [hb, chi_intCast, chi_intCast]
  unfold E kOf aliasN
  have hL : (L : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  have e : I * ∑ n, ((2 * π * ((m n + L * bz (η n) : ℤ) : ℝ) / ((2 * L : ℕ) : ℝ) : ℝ) : ℂ) *
      (((2 * ((X n).val : ℤ) : ℤ)) : ℂ) =
      I * ∑ n, ((2 * π * (m n : ℝ) / (L : ℝ) : ℝ) : ℂ) * ((((X n).val : ℤ)) : ℂ) +
        2 * π * I * ((∑ n, bz (η n) * ((X n).val : ℤ) : ℤ) : ℂ) := by
    push_cast
    rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun n _ => ?_
    field_simp
  rw [e, Complex.exp_add, exp_two_pi_int, mul_one]

theorem chi_unit (N : ℕ) [NeZero N] (n : Fin 4 → ℤ) (ρ : Fin 4) :
    chi N n (fun j => ((ev ρ j : ℤ) : ZMod N)) = cexp (I * ((2 * π * n ρ / N : ℝ) : ℂ)) := by
  rw [chi_intCast, E_ev]
  rfl

theorem chi_alias_injective (L : ℕ) [NeZero L] (m : Fin 4 → ℤ) :
    Function.Injective fun η : Fin 4 → Bool => chi (2 * L) (aliasN L m η) := by
  intro η η' h
  funext ρ
  have h1 := congrArg (fun ψ : AddChar (Fin 4 → ZMod (2 * L)) ℂ =>
    ψ (fun j => ((ev ρ j : ℤ) : ZMod (2 * L)))) h
  simp only [chi_unit] at h1
  by_contra hne
  have hL : (L : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  have hLc : (L : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  -- the two values differ by the factor `e^{iπ} = -1`
  have key : ∀ b : Bool, cexp (I * ((2 * π * (aliasN L m (fun _ => b) ρ : ℤ) /
      ((2 * L : ℕ) : ℝ) : ℝ) : ℂ)) = cexp (I * ((π * m ρ / L : ℝ) : ℂ)) * (if b then -1 else 1) := by
    intro b
    unfold aliasN bz
    cases b
    · simp only [if_false, Bool.false_eq_true, mul_one]
      congr 1; push_cast; field_simp; ring
    · simp only [if_true]
      rw [show I * ((2 * π * ((m ρ + L * 1 : ℤ) : ℝ) / ((2 * L : ℕ) : ℝ) : ℝ) : ℂ) =
          I * ((π * m ρ / L : ℝ) : ℂ) + π * I by push_cast; field_simp,
        Complex.exp_add, Complex.exp_pi_mul_I]
  have k1 := key (η ρ)
  have k2 := key (η' ρ)
  have e1 : aliasN L m (fun _ => η ρ) ρ = aliasN L m η ρ := rfl
  have e2 : aliasN L m (fun _ => η' ρ) ρ = aliasN L m η' ρ := rfl
  rw [e1] at k1; rw [e2] at k2
  rw [k1, k2] at h1
  have hne0 : cexp (I * ((π * m ρ / L : ℝ) : ℂ)) ≠ 0 := Complex.exp_ne_zero _
  have := mul_left_cancel₀ hne0 h1
  cases hη : η ρ <;> cases hη' : η' ρ
  · exact hne (hη.trans hη'.symm)
  · rw [hη, hη'] at this; norm_num at this
  · rw [hη, hη'] at this; norm_num at this
  · exact hne (hη.trans hη'.symm)

/-- **The alias sum on the torus** is the sum over the sixteen `η`. -/
theorem sum_alias (L : ℕ) [NeZero L] (m : Fin 4 → ℤ) (F : AddChar (Fin 4 → ZMod (2 * L)) ℂ → ℂ) :
    ∑ ψ : AddChar (Fin 4 → ZMod (2 * L)) ℂ, (if res (betaT 4 L) ψ = chi L m then F ψ else 0) =
      ∑ η : Fin 4 → Bool, F (chi (2 * L) (aliasN L m η)) := by
  classical
  rw [← Finset.sum_filter]
  have himg : (Finset.univ.image fun η : Fin 4 → Bool => chi (2 * L) (aliasN L m η)) =
      Finset.univ.filter fun ψ => res (betaT 4 L) ψ = chi L m := by
    apply Finset.eq_of_subset_of_card_le
    · intro ψ hψ
      obtain ⟨η, -, rfl⟩ := Finset.mem_image.mp hψ
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, res_chi L m η⟩
    · rw [torus_card_alias, Finset.card_image_of_injective _ (chi_alias_injective L m)]
      simp
  rw [← himg, Finset.sum_image fun x _ y _ h => chi_alias_injective L m h]

/-! ## (L2) The phases at the aliases -/

/-- The momentum in the coordinates of `OneStepBridge`: `θ = k/4 = πn/(2N)`. -/
def thOf (N : ℕ) (n : Fin 4 → ℤ) : Fin 4 → ℝ := fun j => π * n j / (2 * N)

theorem kOf_eq (N : ℕ) (n : Fin 4 → ℤ) : kOf N n = fun j => 4 * thOf N n j := by
  funext j; unfold kOf thOf
  by_cases h : (N : ℝ) = 0
  · simp [h]
  · field_simp; ring

theorem thOf_alias (L : ℕ) [NeZero L] (m : Fin 4 → ℤ) (η : Fin 4 → Bool) :
    thOf (2 * L) (aliasN L m η) = thR (thOf L m) η := by
  funext j
  have hL : (L : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne L)
  unfold thOf aliasN thR bz
  cases η j <;> simp <;> field_simp <;> ring

/-- The phase `e^{2iθ_μ}` (`= e^{iq_μ/2}`). -/
def ph (θ : Fin 4 → ℝ) (μ : Fin 4) : ℂ := cexp (I * ((2 * θ μ : ℝ) : ℂ))

theorem conj_ph_mul (θ : Fin 4 → ℝ) (μ : Fin 4) : conj (ph θ μ) * ph θ μ = 1 := by
  unfold ph
  rw [← Complex.exp_conj, ← Complex.exp_add, map_mul, Complex.conj_I, Complex.conj_ofReal]
  simp

/-- The real symbol at the alias, `S_η Q̃(r_η)` with `Q̃ = 2 C N`. -/
def SQ (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun μ ν => sg ζ μ * (2 * cR θ ζ μ) * NM (sR θ ζ) μ ν

theorem sk_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    sk (fun j => 4 * thR θ ζ j) = sR θ ζ := by
  funext j; unfold sk sR phi thR; congr 1; by_cases h : ζ j <;> simp [h] <;> ring

theorem cos_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (μ : Fin 4) :
    Real.cos (4 * thR θ ζ μ / 2) = cR θ ζ μ := by
  unfold cR phi thR; congr 1; by_cases h : ζ μ <;> simp [h] <;> ring

theorem exp_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (μ : Fin 4) :
    cexp (I * ((4 * thR θ ζ μ : ℝ) : ℂ)) = ph θ μ * (sg ζ μ : ℂ) := by
  unfold ph sg thR
  split_ifs
  · rw [show I * ((4 * (θ μ / 2 + π / 4) : ℝ) : ℂ) = I * ((2 * θ μ : ℝ) : ℂ) + π * I by
      push_cast; ring, Complex.exp_add, Complex.exp_pi_mul_I]
    push_cast; ring
  · rw [show (4 * (θ μ / 2 + 0) : ℝ) = 2 * θ μ by ring]; push_cast; ring

/-- **(L2) The complex symbol at an alias in phase form.** -/
theorem sym_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (μ ν : Fin 4) :
    pathSym (fun j => 4 * thR θ ζ j) μ ν =
      ph θ μ * (SQ θ ζ μ ν : ℂ) * conj (ph (thR θ ζ) ν) := by
  rw [pathSym_closed, sk_thR, cos_thR, exp_thR]
  have hc : conj (ph (thR θ ζ) ν) = cexp (-(I * ((4 * thR θ ζ ν / 2 : ℝ) : ℂ))) := by
    unfold ph
    rw [← Complex.exp_conj, map_mul, Complex.conj_I, Complex.conj_ofReal]
    congr 1; push_cast; ring
  rw [hc]
  simp only [SQ, Matrix.of_apply]
  push_cast
  ring

/-! ## The one-step map of a stage covariance -/

/-- A translation-invariant stage operator `T` on the torus `(ℤ/N)⁴` **has the phase form `X`**:
its symbol at `chi N n` is `e^{2iθ} X(θ) e^{-2iθ}`, `θ = thOf N n`. -/
def PhaseSym (N : ℕ) [NeZero N]
    (T : ((Fin 4 → ZMod N) → Fin 4 → ℂ) → ((Fin 4 → ZMod N) → Fin 4 → ℂ))
    (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) : Prop :=
  ∀ w (n : Fin 4 → ℤ) μ, ftv (T w) (chi N n) μ =
    ∑ l, ph (thOf N n) μ * (X (thOf N n) μ l : ℂ) * conj (ph (thOf N n) l) * ftv w (chi N n) l

/-- **The real recursion** `(RM X)(θ) = (1/16) Σ_η (S_ηQ̃) X(thR θ η) (S_ηQ̃)ᵀ`
(`X_{k+1} = 𝓡 X_k`, in the coordinates `θ = q/4`). -/
def RM (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (θ : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  (1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, SQ θ ζ * X (thR θ ζ) * (SQ θ ζ)ᵀ

/-- The sandwich of phases: `Σ_ν Q_{μν} Σ_{l'} t_{νl'} Σ_l conj(Q_{ll'}) w_l`
with `Q = a S b̄`, `t = b X b̄`, `|b| = 1`. -/
theorem sandwich (a b : Fin 4 → ℂ) (hb : ∀ ν, conj (b ν) * b ν = 1)
    (S X : Matrix (Fin 4) (Fin 4) ℝ) (w : Fin 4 → ℂ) (μ : Fin 4) :
    ∑ ν, a μ * (S μ ν : ℂ) * conj (b ν) *
      ∑ l', b ν * (X ν l' : ℂ) * conj (b l') *
        ∑ l, conj (a l * (S l l' : ℂ) * conj (b l')) * w l =
    ∑ l, a μ * ((S * X * Sᵀ) μ l : ℂ) * conj (a l) * w l := by
  have hS : ∀ l, ((S * X * Sᵀ) μ l : ℂ) = ∑ l', ∑ ν, (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) := by
    intro l
    simp only [Matrix.mul_apply, Matrix.transpose_apply, Finset.sum_mul]
    push_cast
    rfl
  calc _ = ∑ ν, ∑ l', ∑ l, a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) * conj (a l) * w l := by
        refine Finset.sum_congr rfl fun ν _ => ?_
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun l' _ => ?_
        rw [Finset.mul_sum, Finset.mul_sum]
        refine Finset.sum_congr rfl fun l _ => ?_
        simp only [map_mul, Complex.conj_ofReal, Complex.conj_conj]
        have h1 := hb ν
        have h2 := hb l'
        linear_combination (a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) * conj (a l) * w l *
          conj (b l') * b l') * h1 + (a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) *
          conj (a l) * w l) * h2
    _ = ∑ l', ∑ ν, ∑ l, a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) * conj (a l) * w l :=
        Finset.sum_comm
    _ = ∑ l', ∑ l, ∑ ν, a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) * conj (a l) * w l :=
        Finset.sum_congr rfl fun _ _ => Finset.sum_comm
    _ = ∑ l, ∑ l', ∑ ν, a μ * (S μ ν : ℂ) * (X ν l' : ℂ) * (S l l' : ℂ) * conj (a l) * w l :=
        Finset.sum_comm
    _ = _ := by
        refine Finset.sum_congr rfl fun l _ => ?_
        rw [hS]
        simp only [Finset.mul_sum, Finset.sum_mul]
        exact Finset.sum_congr rfl fun l' _ => Finset.sum_congr rfl fun ν _ => by ring

theorem card_ratio (L : ℕ) [NeZero L] :
    (Fintype.card (Fin 4 → ZMod (2 * L)) : ℂ) = 16 * Fintype.card (Fin 4 → ZMod L) := by
  rw [card_fine]; push_cast; ring

/-- **One step on the torus** (the content of (L2)(L4)(L5) together): if the fine stage operator
`T` has the phase form `X`, then `C T C†` (with `C` the real-space path kernel and `β : X ↦ 2X`)
has the phase form `RM X` on the coarse torus. -/
theorem torus_step (L : ℕ) [NeZero L]
    (T : ((Fin 4 → ZMod (2 * L)) → Fin 4 → ℂ) → ((Fin 4 → ZMod (2 * L)) → Fin 4 → ℂ))
    (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (hT : PhaseSym (2 * L) T X) :
    PhaseSym L (fun w => Cop (betaT 4 L) (pathKernel (2 * L))
      (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w))) (RM X) := by
  intro w m μ
  have h := alias_C (betaT 4 L) (pathKernel (2 * L))
    (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w)) (chi L m) μ
  rw [sum_alias, card_ratio] at h
  have hG : (Fintype.card (Fin 4 → ZMod L) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have h' : ftv (Cop (betaT 4 L) (pathKernel (2 * L))
      (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w))) (chi L m) μ =
      (1 / 16 : ℂ) * ∑ η : Fin 4 → Bool, ∑ ν, sym (pathKernel (2 * L)) (chi (2 * L) (aliasN L m η)) μ ν *
        ftv (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w)) (chi (2 * L) (aliasN L m η)) ν := by
    have h16 : (16 : ℂ) ≠ 0 := by norm_num
    apply mul_left_cancel₀ (mul_ne_zero h16 hG)
    rw [h]; field_simp
  rw [h']
  -- each alias
  have hal : ∀ η : Fin 4 → Bool, ∑ ν, sym (pathKernel (2 * L)) (chi (2 * L) (aliasN L m η)) μ ν *
      ftv (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w)) (chi (2 * L) (aliasN L m η)) ν =
      ∑ l, ph (thOf L m) μ * ((SQ (thOf L m) η * X (thR (thOf L m) η) * (SQ (thOf L m) η)ᵀ) μ l : ℂ) *
        conj (ph (thOf L m) l) * ftv w (chi L m) l := by
    intro η
    set θ := thOf L m
    have hsym : ∀ μ' ν', sym (pathKernel (2 * L)) (chi (2 * L) (aliasN L m η)) μ' ν' =
        ph θ μ' * (SQ θ η μ' ν' : ℂ) * conj (ph (thR θ η) ν') := by
      intro μ' ν'
      rw [sym_pathKernel, kOf_eq, thOf_alias, sym_alias]
    have hTn : ∀ ν, ftv (T (Cadj (betaT 4 L) (pathKernel (2 * L)) w)) (chi (2 * L) (aliasN L m η)) ν =
        ∑ l', ph (thR θ η) ν * (X (thR θ η) ν l' : ℂ) * conj (ph (thR θ η) l') *
          ∑ l, conj (ph θ l * (SQ θ η l l' : ℂ) * conj (ph (thR θ η) l')) * ftv w (chi L m) l := by
      intro ν
      rw [hT, thOf_alias]
      refine Finset.sum_congr rfl fun l' _ => ?_
      rw [ftv_Cadj, res_chi]
      congr 1
      refine Finset.sum_congr rfl fun l _ => ?_
      rw [hsym]
    simp only [hsym, hTn]
    exact sandwich (ph θ) (ph (thR θ η)) (conj_ph_mul _) (SQ θ η) (X (thR θ η)) _ μ
  simp only [hal]
  have hRM : ∀ l, ((RM X (thOf L m)) μ l : ℂ) = ∑ ζ : Fin 4 → Bool, (1 / 16 : ℂ) *
      ((SQ (thOf L m) ζ * X (thR (thOf L m) ζ) * (SQ (thOf L m) ζ)ᵀ) μ l : ℂ) := by
    intro l
    unfold RM
    simp only [Matrix.smul_apply, Matrix.sum_apply, smul_eq_mul]
    push_cast
    rw [Finset.mul_sum]
  calc _ = ∑ l, ∑ η : Fin 4 → Bool, (1 / 16 : ℂ) * (ph (thOf L m) μ *
        ((SQ (thOf L m) η * X (thR (thOf L m) η) * (SQ (thOf L m) η)ᵀ) μ l : ℂ) *
        conj (ph (thOf L m) l) * ftv w (chi L m) l) := by
        rw [Finset.mul_sum]
        simp_rw [Finset.mul_sum]
        exact Finset.sum_comm
    _ = _ := by
        refine Finset.sum_congr rfl fun l _ => ?_
        rw [hRM, Finset.mul_sum, Finset.sum_mul, Finset.sum_mul]
        exact Finset.sum_congr rfl fun η _ => by ring

end LatticeTorus

end

/-!
# (L5′) The lattice recursion `X_{k+1} = 𝓡 X_k` and the family map `𝓜`

`RM` (in `LatticeTorus`) is the recursion of the stage covariance in the real phase form,
`(RM X)(θ) = (1/16) Σ_ζ S_ζQ̃(r_ζ) X(r_ζ) (S_ζQ̃(r_ζ))ᵀ` (no projection).  Here:

* `AM_eq`: `A_ζ = P(q) S_ζ Q̃(r_ζ) P(r_ζ)` (the matrix `AM` of `OneStepBridge`);
* `gauge_drop`: `P(q) S_ζ Q̃(r_ζ) P(r_ζ) = P(q) S_ζ Q̃(r_ζ)` (`S_ζ Q̃(r_ζ) s(r_ζ) = s(q)`);
* `rec_step`: `P (RM X) P = 𝓜 (P X P)` for every `X` (the projection commutes with the step);
* `rec_iterate`: `P (RM^k X₀) P = 𝓜^k (P X₀ P)`;
* **`lattice_bracket`**: with `X₀ = I/ω` (the free propagator in the Feynman gauge),
  `G_k = P X_k P` has an inverse `H_k` on `ran P` and `(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every
  stage `k` and every momentum with `ω > 0`; `lattice_bracket_sharp` with `74`.

Together with `LatticeTorus.torus_step` (the symbol of `C T C†` on the torus has the phase form
`RM X` when `T` has the phase form `X`), this says that the object of `bracket_Qpos_free` is the
physical part of the stage covariance of the lattice block average.
-/

noncomputable section

namespace LatticeRec

open Finset OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower LatticeTorus Matrix
open scoped Real RealInnerProductSpace

/-! ## Vector identities -/

theorem Nm_sub_smul (s u : Fin 4 → ℝ) (c : ℝ) :
    Nm s (fun i => u i - c * s i) = fun i => Nm s u i - c * Nm s s i := by
  funext μ
  unfold Nm
  simp only [sum_erase4]
  ring

theorem Nm_proj (s u : Fin 4 → ℝ) : Nm s (proj s u) = proj s (Nm s u) := by
  have h1 : dot s (Nm s u) = dot s u := by rw [Nm_symm, Nm_self]
  unfold proj
  rw [Nm_sub_smul, Nm_self, h1]

theorem proj_sub_smul_self (s y : Fin 4 → ℝ) (c : ℝ) :
    proj s (fun i => y i - c * s i) = proj s y := by
  funext i
  by_cases h : dot s s = 0
  · have hs : ∀ j, s j = 0 := by
      intro j
      have h' : ∑ j, s j * s j = 0 := h
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' j
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    simp [proj, hs]
  · unfold proj
    have e : dot s (fun i => y i - c * s i) = dot s y - c * dot s s := by
      unfold dot
      rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
      exact Finset.sum_congr rfl fun j _ => by ring
    rw [e]
    field_simp
    ring

theorem proj_smul (s y : Fin 4 → ℝ) (c : ℝ) :
    proj s (fun i => c * y i) = fun i => c * proj s y i := by
  funext i
  unfold proj
  have e : dot s (fun i => c * y i) = c * dot s y := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun j _ => by ring
  rw [e]; ring

theorem mat_ext {A B : Matrix (Fin 4) (Fin 4) ℝ} (h : ∀ v, A *ᵥ v = B *ᵥ v) : A = B :=
  Matrix.toLin'.injective (LinearMap.ext fun v => by simpa [Matrix.toLin'_apply] using h v)

theorem SQ_mulVec (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (v : Fin 4 → ℝ) :
    SQ θ ζ *ᵥ v = fun μ => sg ζ μ * (2 * cR θ ζ μ) * Nm (sR θ ζ) v μ := by
  funext μ
  rw [← NM_mulVec]
  simp only [SQ, Matrix.mulVec, dotProduct, Matrix.of_apply, Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by ring

/-- `S_ζ Q̃(r_ζ) s(r_ζ) = s(q)`. -/
theorem SQ_sR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : SQ θ ζ *ᵥ sR θ ζ = sQ θ := by
  rw [SQ_mulVec, Nm_self]
  funext μ
  have h := OneStepNorm.alias_orth (θ μ) (ζ μ)
  unfold sg cR sR phi sQ
  linear_combination 2 * h

theorem projM_mul_self (s : Fin 4 → ℝ) : projM s * projM s = projM s := by
  apply mat_ext; intro v
  rw [← Matrix.mulVec_mulVec, projM_mulVec, projM_mulVec, proj_of_dot (dot_proj _ _)]

/-- **`A_ζ = P(q) S_ζ Q̃(r_ζ) P(r_ζ)`.** -/
theorem AM_eq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    AM θ ζ = projM (sQ θ) * SQ θ ζ * projM (sR θ ζ) := by
  apply mat_ext; intro v
  unfold AM
  rw [Matrix.smul_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec,
    ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [projM_mulVec, diag_mulVec, NM_mulVec, SQ_mulVec]
  rw [← Nm_proj]
  have e : (fun μ => sg ζ μ * (2 * cR θ ζ μ) * Nm (sR θ ζ) (proj (sR θ ζ) v) μ) =
      fun μ => 2 * (cR θ ζ μ * sg ζ μ * Nm (sR θ ζ) (proj (sR θ ζ) v) μ) := by
    funext μ; ring
  rw [e, proj_smul]
  funext i
  simp only [Pi.smul_apply, smul_eq_mul]

/-- **The gauge direction drops out**: `P(q) S_ζ Q̃ P(r_ζ) = P(q) S_ζ Q̃`. -/
theorem gauge_drop (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    projM (sQ θ) * SQ θ ζ * projM (sR θ ζ) = projM (sQ θ) * SQ θ ζ := by
  apply mat_ext; intro v
  rw [← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, projM_mulVec,
    projM_mulVec, projM_mulVec]
  have e : SQ θ ζ *ᵥ proj (sR θ ζ) v =
      fun i => (SQ θ ζ *ᵥ v) i - (dot (sR θ ζ) v / dot (sR θ ζ) (sR θ ζ)) * sQ θ i := by
    have hp : proj (sR θ ζ) v = v - (dot (sR θ ζ) v / dot (sR θ ζ) (sR θ ζ)) • sR θ ζ := by
      funext i; simp [proj]
    rw [hp, Matrix.mulVec_sub, Matrix.mulVec_smul, SQ_sR]
    funext i; simp
  rw [e, proj_sub_smul_self]

theorem toE_mul (A B : Matrix (Fin 4) (Fin 4) ℝ) :
    Matrix.toEuclideanLin (A * B) = Matrix.toEuclideanLin A ∘ₗ Matrix.toEuclideanLin B := by
  apply LinearMap.ext; intro v
  simp only [LinearMap.comp_apply, toE_apply, Matrix.mulVec_mulVec]

/-- One term: `P (S Q̃ X (S Q̃)ᵀ) P = A_ζ (P_r X P_r) A_ζᵀ`. -/
theorem term_eq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (Y : Matrix (Fin 4) (Fin 4) ℝ) :
    projM (sQ θ) * (SQ θ ζ * Y * (SQ θ ζ)ᵀ) * projM (sQ θ) =
      AM θ ζ * (projM (sR θ ζ) * Y * projM (sR θ ζ)) * AtM θ ζ := by
  rw [← AM_transpose, AM_eq]
  have hP : (projM (sR θ ζ))ᵀ = projM (sR θ ζ) := projM_transpose _
  have hQ : (projM (sQ θ))ᵀ = projM (sQ θ) := projM_transpose _
  have hg := gauge_drop θ ζ
  have hgt : (projM (sR θ ζ)) * (SQ θ ζ)ᵀ * projM (sQ θ) = (SQ θ ζ)ᵀ * projM (sQ θ) := by
    have := congrArg Matrix.transpose hg
    simpa [Matrix.transpose_mul, hP, hQ, Matrix.mul_assoc] using this
  have hRR := projM_mul_self (sR θ ζ)
  calc projM (sQ θ) * (SQ θ ζ * Y * (SQ θ ζ)ᵀ) * projM (sQ θ)
      = (projM (sQ θ) * SQ θ ζ) * Y * ((SQ θ ζ)ᵀ * projM (sQ θ)) := by
        simp only [Matrix.mul_assoc]
    _ = (projM (sQ θ) * SQ θ ζ * projM (sR θ ζ)) * Y *
          (projM (sR θ ζ) * (SQ θ ζ)ᵀ * projM (sQ θ)) := by rw [hg, hgt]
    _ = (projM (sQ θ) * SQ θ ζ * projM (sR θ ζ)) * (projM (sR θ ζ) * Y * projM (sR θ ζ)) *
          (projM (sR θ ζ) * (SQ θ ζ)ᵀ * projM (sQ θ)) := by
        simp only [Matrix.mul_assoc]
        rw [← Matrix.mul_assoc (projM (sR θ ζ)) (projM (sR θ ζ)), hRR,
          ← Matrix.mul_assoc (projM (sR θ ζ)) (projM (sR θ ζ)), hRR]
    _ = _ := by
        rw [Matrix.transpose_mul, Matrix.transpose_mul, hP, hQ]
        simp only [Matrix.mul_assoc]

/-! ## The step and its iterates -/

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The projected family `q ↦ P(q) X(θ(q)) P(q)` as linear maps. -/
def projFam (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (q : Q) : V →ₗ[ℝ] V :=
  Matrix.toEuclideanLin (projM (sQ (th q)) * X (th q) * projM (sQ (th q)))

/-- **`P (RM X) P = 𝓜 (P X P)`.** -/
theorem rec_step (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (X : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (q : Q) :
    projFam th (RM X) q = Mfam th rq (projFam th X) q := by
  show _ = (1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      projFam th X (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)
  unfold projFam RM
  rw [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_sum, Matrix.sum_mul, map_smul, map_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [term_eq, hrq, sQ_thR, toE_mul, toE_mul]
  rfl

theorem rec_iterate (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (X₀ : (Fin 4 → ℝ) → Matrix (Fin 4) (Fin 4) ℝ) (k : ℕ) (q : Q) :
    projFam th ((RM)^[k] X₀) q = (⇑(Mfam th rq))^[k] (projFam th X₀) q := by
  induction k generalizing q with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply', rec_step th rq hrq,
      show projFam th ((RM)^[k] X₀) = (⇑(Mfam th rq))^[k] (projFam th X₀) from funext ih]

/-! ## Stage 0 and the bracket -/

/-- `ω(θ) = Σ 4 sin²(2θ_ν)` (`= |q̂|²`). -/
def om (θ : Fin 4 → ℝ) : ℝ := ∑ ν, 4 * sQ θ ν ^ 2

/-- **The free propagator** `X₀ = I/ω` (Feynman gauge). -/
def X0 (θ : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ := (om θ)⁻¹ • (1 : Matrix (Fin 4) (Fin 4) ℝ)

theorem projFam_X0 : projFam th X0 = fun q => (omF th q)⁻¹ • Pfam th q := by
  funext q
  unfold projFam X0 Pfam
  rw [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one, projM_mul_self, map_smul]
  rfl

/-- **Theorem 1 for the lattice stage covariance** (`k` steps of the block average from the free
propagator): the physical part `G_k = P X_k P` of `X_k = RM^k (I/ω)` has an inverse `H_k` on
`ran P`, and `(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every `k` and every momentum with `ω > 0`. -/
theorem lattice_bracket :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, projFam Subtype.val ((RM)^[k] X0) q (H k q x) = Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  obtain ⟨H, h1, h2, h3⟩ := bracket_Qpos_free
  refine ⟨H, fun k q x => ?_, h2, h3⟩
  rw [rec_iterate Subtype.val rqPos (fun _ _ => rfl), projFam_X0]
  exact h1 k q x

/-- The same with the sharper upper constant `74` (`OneStepCell.bracket_Qpos_sharp`). -/
theorem lattice_bracket_sharp :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, projFam Subtype.val ((RM)^[k] X0) q (H k q x) = Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 74 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  obtain ⟨H, h1, h2, h3⟩ := OneStepCell.bracket_Qpos_sharp
  refine ⟨H, fun k q x => ?_, h2, h3⟩
  rw [rec_iterate Subtype.val rqPos (fun _ _ => rfl), projFam_X0]
  exact h1 k q x

end LatticeRec

