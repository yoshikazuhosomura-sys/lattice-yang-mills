-- ===== AliasA3Combined: CouplingGammaAliasCombined (verbatim) + T4Form (namespace T4Form only, #print axioms removed) + LiftSize.part + CNValueCombined lines 3746-3978 (OneStepCell §1-2, verbatim) + AliasPoinc.part =====
-- ===== CouplingGammaCombined: Coupling35Combined (verbatim, #print axioms removed) + QuadLipF.part + GammaDiff.lean body + CouplingGamma.part =====
-- ===== pruned verbatim pieces: All1135 lines 1-3726 and 5453-5798 (CouplingLimit); RowSplit part (RowSplitCombined 5900-6167); NmBracket..CouplingQuad (CouplingQuadCombined 5891-6897, #print axioms removed) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
import Mathlib

/-!
# A uniform bracket for an order-preserving linear iteration (skeleton of Theorem 1)

Setting.  `E` is a real inner product space, `Q` an index type (the momenta), and we work with
families of linear operators `A : Q → E →ₗ[ℝ] E`.  The Loewner order of families is pointwise in
`q` and in the quadratic form:

  `Lw A B  :↔  ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫`.

`M` is a linear map on families which preserves this order (`OrderPreserving M`).  The stages are
`G k = M^[k] G0`.

Part 1 (upper side, order and linearity only).  If `M P ≼ λ P` and `M B ≼ B + e P`
(in : `B = P/ω`, `λ = λ̄`, `e = e_T`), then from `G0 ≼ B + c0 P`
  `G k ≼ B + (λ^k c0 + e Σ_{j<k} λ^j) P`                       (`iterate_upper`, `cSeq_eq`),
and, for `0 ≤ λ < 1`, `P ≽ 0`, `c0 ≤ e/(1-λ)`: `G k ≼ B + (e/(1-λ)) P` for all `k`
(`uniform_upper`).  Two-sided geometric bounds for the differences and convergence of every
quadratic form `⟪x, G k q x⟫` with rate `λ^k/(1-λ)` (`iterate_two_sided`, `quad_tendsto`).
The sharp form: `M G0 ≼ G0` implies `G (k+1) ≼ G k` for all `k` (`iterate_antitone`).

Part 2 (inverse on the range of a projection).  `InvOnRange P G H`: `P` symmetric,
`G (H x) = P x`, `P (H x) = H x` (so `H` is the inverse of `G` on `ran P`, e.g. `H = G⁺` when
`G = P X P`).  No square roots and no C*-algebra are used: the variational inequality
`2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` (equality at `v = H x`) gives the antitonicity of the inverse
on `ran P` (`antitone_inv`), hence
  `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H`   (`inv_lower`),   `m P ≼ G ⇒ H ≼ m⁻¹ P`   (`inv_upper`).

Part 3 (the bracket).  `bracket`: with `B = P/ω`, `h k = ¼ H k`,
  `¼ (ω⁻¹ + e/(1-λ))⁻¹ P ≼ h k ≼ (ω/(4a)) P`   for all `k`, `q`;
`bracket_numeric`: with `ω ≤ 16`, `λ ≤ 0.838`, `e ≤ 15/8`, `a = (4/π²) σ²`, `σ ≥ 0.04452`:
  `(ω/745) P ≼ h k ≼ 312 ω P`.
(`311` needs `σ ≥ 0.04454`, see `const_upper_311`.)
-/

noncomputable section

open scoped RealInnerProductSpace
open Filter Topology
open scoped Real

namespace UniformBracket

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-! ## 0. The Loewner order of families -/

/-- The Loewner order of families of operators, pointwise in `q`. -/
def Lw (A B : Q → E →ₗ[ℝ] E) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

namespace Lw

theorem refl (A : Q → E →ₗ[ℝ] E) : Lw A A := fun _ _ => le_rfl

theorem trans {A B C : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw B C) : Lw A C :=
  fun q x => (h₁ q x).trans (h₂ q x)

theorem add {A B C D : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw C D) : Lw (A + C) (B + D) := by
  intro q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right]
  exact add_le_add (h₁ q x) (h₂ q x)

theorem smul {A B : Q → E →ₗ[ℝ] E} {t : ℝ} (ht : 0 ≤ t) (h : Lw A B) : Lw (t • A) (t • B) := by
  intro q x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_left (h q x) ht

theorem neg {A B : Q → E →ₗ[ℝ] E} (h : Lw A B) : Lw (-B) (-A) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
  linarith [h q x]

/-- Scaling a nonnegative family is monotone in the scalar. -/
theorem smul_left {A : Q → E →ₗ[ℝ] E} {s t : ℝ} (hst : s ≤ t) (hA : Lw 0 A) :
    Lw (s • A) (t • A) := by
  intro q x
  have h0 := hA q x
  simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_right hst h0

end Lw

/-- `M` preserves the Loewner order of families. -/
def OrderPreserving (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E)) : Prop :=
  ∀ A B, Lw A B → Lw (M A) (M B)

/-! ## 1. Part 1: the upper side from order and linearity -/

section Part1

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- The scalar recursion `c_{k+1} = e + λ c_k`, `c_0 = c0`. -/
def cSeq (lam e c0 : ℝ) : ℕ → ℝ
  | 0 => c0
  | k + 1 => e + lam * cSeq lam e c0 k

theorem cSeq_eq (lam e c0 : ℝ) (k : ℕ) :
    cSeq lam e c0 k = lam ^ k * c0 + e * ∑ j ∈ Finset.range k, lam ^ j := by
  induction k with
  | zero => simp [cSeq]
  | succ k ih =>
    have hs : ∑ j ∈ Finset.range k, lam ^ (j + 1) = lam * ∑ j ∈ Finset.range k, lam ^ j := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => pow_succ' lam j)
    rw [cSeq, ih, Finset.sum_range_succ', hs]
    ring

theorem cSeq_nonneg {lam e c0 : ℝ} (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0) (k : ℕ) :
    0 ≤ cSeq lam e c0 k := by
  induction k with
  | zero => exact hc0
  | succ k ih => exact add_nonneg he (mul_nonneg hlam ih)

theorem cSeq_le {lam e c0 : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hc0 : c0 ≤ e / (1 - lam)) (k : ℕ) : cSeq lam e c0 k ≤ e / (1 - lam) := by
  have h1 : (1 - lam) ≠ 0 := by linarith
  have hd : e / (1 - lam) * (1 - lam) = e := div_mul_cancel₀ e h1
  induction k with
  | zero => exact hc0
  | succ k ih =>
    have h := mul_le_mul_of_nonneg_left ih hlam0
    show e + lam * cSeq lam e c0 k ≤ e / (1 - lam)
    nlinarith

/-- One step of the upper comparison. -/
theorem step_upper (hM : OrderPreserving M) {P B G : Q → E →ₗ[ℝ] E} {lam e c : ℝ}
    (hc : 0 ≤ c) (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P))
    (hG : Lw G (B + c • P)) : Lw (M G) (B + (e + lam * c) • P) := by
  have h1 : Lw (M G) (M B + c • M P) := by
    have := hM _ _ hG
    rwa [map_add, map_smul] at this
  have h2 : Lw (M B + c • M P) ((B + e • P) + c • (lam • P)) := Lw.add hB (Lw.smul hc hP)
  have h3 : (B + e • P) + c • (lam • P) = B + (e + lam * c) • P := by
    rw [smul_smul, add_assoc, ← add_smul, mul_comm c lam]
  rw [h3] at h2
  exact h1.trans h2

/-- **Upper side, all stages** (with the source term): `G k ≼ B + c_k P`,
`c_k = λ^k c0 + e Σ_{j<k} λ^j` (`cSeq_eq`). -/
theorem iterate_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + cSeq lam e c0 k • P) := by
  intro k
  induction k with
  | zero => simpa [cSeq] using hG0
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact step_upper M hM (cSeq_nonneg hlam he hc0 k) hP hB ih

/-- **Uniform upper bound**: `G k ≼ B + (e/(1-λ)) P` for all `k`. -/
theorem uniform_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hc0' : c0 ≤ e / (1 - lam)) (hP0 : Lw 0 P)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + (e / (1 - lam)) • P) := by
  intro k
  exact (iterate_upper M hM hlam0 he hc0 hP hB hG0 k).trans
    (Lw.add (Lw.refl B) (Lw.smul_left (cSeq_le hlam0 hlam1 hc0' k) hP0))

/-- The pure contraction (no source): `G0 ≼ c P ⇒ G k ≼ λ^k c P`. -/
theorem iterate_P_le (hM : OrderPreserving M) {P : Q → E →ₗ[ℝ] E} {lam : ℝ}
    (hlam : 0 ≤ lam) (hP : Lw (M P) (lam • P)) : ∀ k, Lw ((⇑M)^[k] P) (lam ^ k • P) := by
  intro k
  induction k with
  | zero => simpa using Lw.refl P
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have h1 : Lw (M ((⇑M)^[k] P)) (lam ^ k • M P) := by
      have := hM _ _ ih
      rwa [map_smul] at this
    have h2 : Lw (lam ^ k • M P) (lam ^ k • lam • P) := Lw.smul (pow_nonneg hlam k) hP
    rw [smul_smul, ← pow_succ] at h2
    exact h1.trans h2

theorem upper_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw X (c • P)) : Lw (M X) ((c * lam) • P) := by
  have h1 : Lw (M X) (c • M P) := by
    have := hM _ _ hX
    rwa [map_smul] at this
  have h2 : Lw (c • M P) (c • lam • P) := Lw.smul hc hP
  rw [smul_smul] at h2
  exact h1.trans h2

theorem lower_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw (-(c • P)) X) : Lw (-((c * lam) • P)) (M X) := by
  have h1 : Lw (-(c • M P)) (M X) := by
    have := hM _ _ hX
    rwa [map_neg, map_smul] at this
  have h2 : Lw (-(c • lam • P)) (-(c • M P)) := Lw.neg (Lw.smul hc hP)
  rw [smul_smul] at h2
  exact h2.trans h1

/-- Two-sided geometric bounds propagate: `-bP ≼ D ≼ bP ⇒ -bλ^k P ≼ M^[k] D ≼ bλ^k P`. -/
theorem iterate_two_sided (hM : OrderPreserving M) {P D : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) D) (hhi : Lw D (b • P)) :
    ∀ k, Lw (-((b * lam ^ k) • P)) ((⇑M)^[k] D) ∧ Lw ((⇑M)^[k] D) ((b * lam ^ k) • P) := by
  intro k
  induction k with
  | zero => simpa using And.intro hlo hhi
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have hc : 0 ≤ b * lam ^ k := mul_nonneg hb (pow_nonneg hlam0 k)
    have e1 : b * lam ^ (k + 1) = b * lam ^ k * lam := by ring
    rw [e1]
    exact ⟨lower_step' M hM hc hP ih.1, upper_step' M hM hc hP ih.2⟩

theorem iter_sub (k : ℕ) (a b : Q → E →ₗ[ℝ] E) :
    (⇑M)^[k] (a - b) = (⇑M)^[k] a - (⇑M)^[k] b := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [Function.iterate_succ_apply', ih, map_sub]

/-- **Geometric convergence of every quadratic form** `⟪x, G k q x⟫`, from the two-sided bound
`-bP ≼ G 1 - G 0 ≼ bP`. -/
theorem quad_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P)) (q : Q) (x : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q x⟫) atTop (𝓝 L) ∧
      ∀ k, |⟪x, (⇑M)^[k] G0 q x⟫ - L| ≤ b * ⟪x, P q x⟫ * lam ^ k / (1 - lam) := by
  set s : ℕ → ℝ := fun k => ⟪x, (⇑M)^[k] G0 q x⟫ with hs
  have hdiff : ∀ k, s (k + 1) - s k = ⟪x, (⇑M)^[k] (M G0 - G0) q x⟫ := by
    intro k
    simp only [hs]
    rw [iter_sub, Function.iterate_succ_apply]
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hu : ∀ k, dist (s k) (s (k + 1)) ≤ b * ⟪x, P q x⟫ * lam ^ k := by
    intro k
    obtain ⟨h1, h2⟩ := iterate_two_sided M hM hlam0 hb hP hlo hhi k
    have l1 := h1 q x
    have l2 := h2 q x
    simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right, Pi.smul_apply,
      LinearMap.smul_apply, real_inner_smul_right] at l1 l2
    rw [Real.dist_eq, abs_sub_comm, abs_le, hdiff k]
    constructor <;> nlinarith
  obtain ⟨L, hL⟩ := cauchySeq_tendsto_of_complete
    (cauchySeq_of_le_geometric lam (b * ⟪x, P q x⟫) hlam1 hu)
  refine ⟨L, hL, fun k => ?_⟩
  have := dist_le_of_le_geometric_of_tendsto lam (b * ⟪x, P q x⟫) hlam1 hu hL k
  rwa [Real.dist_eq] at this

/-- **Sharp form (ii′)**: one step `M G0 ≼ G0` makes the whole sequence decrease. -/
theorem iterate_antitone (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0) :
    ∀ k, Lw ((⇑M)^[k + 1] G0) ((⇑M)^[k] G0) := by
  intro k
  induction k with
  | zero => simpa using h1
  | succ k ih =>
    simp only [Function.iterate_succ_apply'] at ih ⊢
    exact hM _ _ ih

/-- `M` maps the cone `0 ≼ ·` into itself. -/
theorem nonneg_iterate (hM : OrderPreserving M) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw 0 ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => simpa using hG
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have := hM _ _ ih
    rwa [map_zero] at this

/-- **Dominated comparison** (the order part of dropping the alias terms):
if `M₀ ≼ M` on the cone and both preserve the order, then `M₀^[k] G ≼ M^[k] G` for `G ≽ 0`. -/
theorem iterate_dominated (M₀ : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))
    (hM : OrderPreserving M) (hM₀ : OrderPreserving M₀)
    (hdom : ∀ A, Lw 0 A → Lw (M₀ A) (M A)) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw ((⇑M₀)^[k] G) ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => exact Lw.refl G
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply']
    exact (hM₀ _ _ ih).trans (hdom _ (nonneg_iterate M hM hG k))

/-- Polarization: for symmetric `A`, `⟪x, A y⟫` is a combination of quadratic forms. -/
theorem polarization {A : E →ₗ[ℝ] E} (hA : A.IsSymmetric) (x y : E) :
    ⟪x, A y⟫ = (⟪x + y, A (x + y)⟫ - ⟪x - y, A (x - y)⟫) / 4 := by
  have h1 : ⟪y, A x⟫ = ⟪x, A y⟫ := by rw [← hA x y, real_inner_comm]
  simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left, inner_sub_right]
  linarith [h1]

/-- **Convergence of every matrix entry** `⟪x, G k q y⟫` (symmetric stages, by polarization). -/
theorem bilin_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric) (q : Q) (x y : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q y⟫) atTop (𝓝 L) := by
  obtain ⟨L1, h1, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x + y)
  obtain ⟨L2, h2, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x - y)
  refine ⟨(L1 - L2) / 4, ?_⟩
  exact Tendsto.congr (fun k => (polarization (hsym k q) x y).symm) ((h1.sub h2).div_const 4)

end Part1

/-! ## 2. Part 2: the inverse on the range of a projection -/

section Part2

variable {P G H : E →ₗ[ℝ] E}

/-- `H` inverts `G` on the range of the symmetric projection `P`. -/
structure InvOnRange (P G H : E →ₗ[ℝ] E) : Prop where
  symm_P : P.IsSymmetric
  comp : ∀ x, G (H x) = P x
  range : ∀ x, P (H x) = H x

theorem proj_nonneg (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) (v : E) :
    0 ≤ ⟪v, P v⟫ := by
  have : ⟪v, P v⟫ = ⟪P v, P v⟫ := by rw [hPs v (P v), hPP]
  rw [this]
  exact real_inner_self_nonneg

theorem quad_eq (h : InvOnRange P G H) (x : E) : ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  calc ⟪H x, G (H x)⟫ = ⟪H x, P x⟫ := by rw [h.comp]
    _ = ⟪P (H x), x⟫ := (h.symm_P (H x) x).symm
    _ = ⟪H x, x⟫ := by rw [h.range]
    _ = ⟪x, H x⟫ := real_inner_comm _ _

/-- The variational inequality: `2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` for all `v`. -/
theorem variational (h : InvOnRange P G H) (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (x v : E) : 2 * ⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫ := by
  have key := hGp (v - H x)
  have f1 : ⟪H x, G v⟫ = ⟪P x, v⟫ := by rw [← hGs (H x) v, h.comp]
  have f2 : ⟪H x, P x⟫ = ⟪x, H x⟫ := by
    rw [← h.symm_P (H x) x, h.range]
    exact real_inner_comm _ _
  have f3 : ⟪v, P x⟫ = ⟪P x, v⟫ := real_inner_comm _ _
  simp only [map_sub, h.comp, inner_sub_left, inner_sub_right] at key
  rw [f1, f2, f3] at key
  linarith

/-- Equality in the variational inequality at `v = H x`. -/
theorem variational_eq (h : InvOnRange P G H) (x : E) :
    2 * ⟪P x, H x⟫ - ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  rw [quad_eq h x, h.symm_P x (H x), h.range]
  ring

/-- **Antitonicity of the inverse on `ran P`**: `G ≼ G'` (`G` symmetric, `≽ 0`) gives
`H' ≼ H`. -/
theorem antitone_inv {G' H' : E →ₗ[ℝ] E} (h : InvOnRange P G H) (h' : InvOnRange P G' H')
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫) (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫)
    (x : E) : ⟪x, H' x⟫ ≤ ⟪x, H x⟫ := by
  have h1 := variational_eq h' x
  have h2 := variational h hGs hGp x (H' x)
  have h3 := hle (H' x)
  linarith

theorem invOnRange_smul (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) {m : ℝ} (hm : m ≠ 0) :
    InvOnRange P (m • P) (m⁻¹ • P) where
  symm_P := hPs
  comp x := by
    rw [LinearMap.smul_apply, LinearMap.smul_apply, map_smul, hPP, smul_smul,
      mul_inv_cancel₀ hm, one_smul]
  range x := by simp only [LinearMap.smul_apply, map_smul, hPP]

theorem isSymmetric_smul (hPs : P.IsSymmetric) (m : ℝ) : (m • P).IsSymmetric := by
  intro a b
  simp only [LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right, hPs a b]

/-- **Lower bound on the inverse**: `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H` on all of `E`. -/
theorem inv_lower {Mx : ℝ} (hMx : 0 < Mx) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ Mx * ⟪v, P v⟫) (x : E) :
    Mx⁻¹ * ⟪x, P x⟫ ≤ ⟪x, H x⟫ := by
  have := antitone_inv h (invOnRange_smul h.symm_P hPP hMx.ne') hGs hGp
    (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hle v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

/-- **Upper bound on the inverse**: `m P ≼ G ⇒ H ≼ m⁻¹ P` on all of `E`. -/
theorem inv_upper {m : ℝ} (hm : 0 < m) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hge : ∀ v, m * ⟪v, P v⟫ ≤ ⟪v, G v⟫) (x : E) :
    ⟪x, H x⟫ ≤ m⁻¹ * ⟪x, P x⟫ := by
  have hpos : ∀ v, 0 ≤ ⟪v, (m • P) v⟫ := by
    intro v
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg hm.le (proj_nonneg h.symm_P hPP v)
  have := antitone_inv (invOnRange_smul h.symm_P hPP hm.ne') h (isSymmetric_smul h.symm_P m)
    hpos (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hge v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

end Part2

/-! ## 3. Part 3: the bracket -/

section Part3

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The bracket (abstract form of Theorem 1).**  `B = P/ω`, the stages `G k = M^[k] G0`,
`H k q` the inverse of `G k q` on `ran P q`, and `h = ¼ H`.  Inputs: the one-step bounds
`M P ≼ λ P`, `M B ≼ B + e P` (upper side), and the lower bound `a B ≼ G k` for all `k`
(kept as a hypothesis). -/
theorem bracket (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q)
    {lam e a : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (ha : 0 < a)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    (1 / 4) * ((ω q)⁻¹ + e / (1 - lam))⁻¹ * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ ω q / (4 * a) * ⟪x, P q x⟫ := by
  set B : Q → E →ₗ[ℝ] E := fun q => (ω q)⁻¹ • P q with hBdef
  set c : ℝ := e / (1 - lam) with hcdef
  have h1lam : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he h1lam.le
  have hP0 : Lw 0 P := by
    intro q' v
    simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right]
    exact proj_nonneg (hPs q') (hPP q') v
  have hG0' : Lw G0 (B + (0 : ℝ) • P) := by simpa using hG0
  have hup := uniform_upper M hM hlam0 hlam1 he le_rfl (div_nonneg he h1lam.le) hP0 hPstep
    hBstep hG0' k
  set G := (⇑M)^[k] G0 with hGdef
  have hinv : InvOnRange (P q) (G q) (H k q) := ⟨hPs q, hH k q, hHP k q⟩
  have hupv : ∀ v, ⟪v, G q v⟫ ≤ ((ω q)⁻¹ + c) * ⟪v, P q v⟫ := by
    intro v
    have := hup q v
    simp only [hBdef, Pi.add_apply, LinearMap.add_apply, Pi.smul_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right] at this
    linarith
  have hlowv : ∀ v, (a * (ω q)⁻¹) * ⟪v, P q v⟫ ≤ ⟪v, G q v⟫ := by
    intro v
    have := hlow k q v
    simp only [hBdef, Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at this
    linarith
  have hωi : 0 < (ω q)⁻¹ := inv_pos.mpr (hω q)
  have hm : 0 < a * (ω q)⁻¹ := mul_pos ha hωi
  have hGp : ∀ v, 0 ≤ ⟪v, G q v⟫ := fun v =>
    le_trans (mul_nonneg hm.le (proj_nonneg (hPs q) (hPP q) v)) (hlowv v)
  have hMx : 0 < (ω q)⁻¹ + c := by linarith
  have lo := inv_lower hMx hinv (hPP q) (hsym k q) hGp hupv x
  have up := inv_upper hm hinv (hPP q) hlowv x
  have hinv' : (a * (ω q)⁻¹)⁻¹ = ω q / a := by rw [mul_inv, inv_inv]; ring
  rw [hinv'] at up
  have e2 : ω q / (4 * a) * ⟪x, P q x⟫ = (1 / 4) * (ω q / a * ⟪x, P q x⟫) := by ring
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  constructor
  · nlinarith
  · rw [e2]; nlinarith

/-- Arithmetic of the lower constant: `ω/745 ≤ ¼ (ω⁻¹ + e/(1-λ))⁻¹`. -/
theorem const_lower {ω lam e : ℝ} (hω : 0 < ω) (hω16 : ω ≤ 16) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8) :
    ω / 745 ≤ (1 / 4) * (ω⁻¹ + e / (1 - lam))⁻¹ := by
  set c := e / (1 - lam) with hcdef
  have h1 : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he0 h1.le
  have hc : c * (1 - lam) = e := div_mul_cancel₀ e h1.ne'
  have hc1 : c * 0.162 ≤ 15 / 8 := by nlinarith
  have ht : 0 < ω⁻¹ + c := by positivity
  have e1 : 4 * (ω⁻¹ + c) * ω = 4 + 4 * (c * ω) := by
    rw [mul_assoc, add_mul, inv_mul_cancel₀ hω.ne']; ring
  have hkey : 4 * (ω⁻¹ + c) * ω ≤ 745 := by
    rw [e1]
    nlinarith [mul_le_mul_of_nonneg_left hω16 hc0]
  have e3 : (1 / 4 : ℝ) * (ω⁻¹ + c)⁻¹ = 1 / (4 * (ω⁻¹ + c)) := by
    rw [one_div, one_div, mul_inv]
  rw [e3, div_le_div_iff₀ (by norm_num) (by positivity)]
  nlinarith

/-- Arithmetic of the upper constant: `σ ≥ 0.04452`, `a = (4/π²) σ²` give `ω/(4a) ≤ 312 ω`. -/
theorem const_upper {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2) :
    ω / (4 * a) ≤ 312 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hσ2 : (0.0019820304 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1248 * a := by
    rw [ha, show 1248 * (4 / π ^ 2 * σ ^ 2) = 4992 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- The constant `311` needs `σ ≥ 0.04454` (from `σ ≥ 0.04452` one gets only `311.2`). -/
theorem const_upper_311 {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04454 ≤ σ)
    (ha : a = 4 / π ^ 2 * σ ^ 2) : ω / (4 * a) ≤ 311 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.8697 := by nlinarith
  have hσ2 : (0.0019838116 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1244 * a := by
    rw [ha, show 1244 * (4 / π ^ 2 * σ ^ 2) = 4976 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- **The bracket with numbers** (Theorem 1 of + §2.9, numbers as hypotheses):
`(ω/745) P ≼ h k ≼ 312 ω P` for all stages `k` and momenta `q`. -/
theorem bracket_numeric (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q) (hω16 : ∀ q, ω q ≤ 16)
    {lam e σ a : ℝ} (hlam0 : 0 ≤ lam) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8)
    (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    ω q / 745 * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * ω q * ⟪x, P q x⟫ := by
  have hlam1 : lam < 1 := by linarith
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  obtain ⟨lo, up⟩ := bracket M hM hPs hPP hω hlam0 hlam1 he0 ha0 hPstep hBstep hG0 hlow hsym
    hH hHP k q x
  have hPx := proj_nonneg (hPs q) (hPP q) x
  have c1 := const_lower (hω q) (hω16 q) hlam he0 he
  have c2 := const_upper (hω q) hσ ha
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo,
    le_trans up (mul_le_mul_of_nonneg_right c2 hPx)⟩

/-- **Sharp form on the inverse side**: if `G (k+1) ≼ G k` then `h k ≼ h (k+1)`. -/
theorem stage_action_increasing {P G G' H H' : E →ₗ[ℝ] E} (h : InvOnRange P G H)
    (h' : InvOnRange P G' H') (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫) (x : E) :
    ⟪x, ((1 / 4 : ℝ) • H') x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H) x⟫ := by
  have := antitone_inv h h' hGs hGp hle x
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  linarith

end Part3

end UniformBracket


-- ===== verbatim copy of an earlier file (without its import line and #print axioms) =====

/-!
# The one-step norm `λ̄ ≤ 0.838` : the polynomial stages

Setting: `α = 1/8`, four directions.  For one direction `ν` the two aliases `ζ_ν ∈ {0,1}` of
`r_ζ = (q + 2πζ)/2` give `x_ν(r_ζ) = 4α sin²(r_{ζ,ν}/2)` equal to `σ_ν/2` (`ζ_ν = 0`) and
`(1-σ_ν)/2` (`ζ_ν = 1`), where `σ_ν = sin²(q_ν/4) ∈ [0,1]`.  The weight `cos²(r_{ζ,c}/2)` of the
distinguished direction `c` is `1-σ_c` and `σ_c` (`alias_x`, `alias_w`).

Stages, from the back:
* S6 `Dlin_le`: the linear inequality in `y = σ_c(1-σ_c) ≥ 0` with `t = 3/10`:
  `D(y) = 429/512 - (13/40) y ≤ 429/512 ≤ 0.838`.
* S5 one-direction alias sums (`sumT_*`, `sumS_*`) and the transverse bounds on `σ ∈ [0,1]`
  (`Tq_le`, `Tx2_le`, `Tq_antitone`).
* S4 the alias sum over `ζ ∈ {0,1}⁴` of a monomial is the product of one-direction sums
  (`alias_factor`); the closed forms `Msum_eq`, `Lsum_eq`.
* S4' `Msum_le`, `Lsum_le`, `Dsum_le`: `(1+t) M_c + (1+1/t) L̄_c ≤ 429/512` on the box `[0,1]⁴`.
* S2 (matrix level, any finite index type): Lemma 4 of `comp_identity`
  `(N u)_μ = (π_μ - x_μ) u_μ - s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν` for `u ⊥ s̃`, and the square bound
  `normSq_le` (`(a-b)² ≤ (1+t)a² + (1+1/t)b²` and weighted Cauchy–Schwarz).
-/

noncomputable section

open scoped Real
open Finset

namespace OneStepNorm

/-! ## S6. The linear inequality in one variable -/

/-- `D(y)` of after the transverse directions are set to `σ = 0`
(splitting parameter `t`):
`(1+t)·¼(125/64 − 19y/4) + (1+1/t)·(3/8)(3y/4 + 1/8)`. -/
def Dlin (t y : ℝ) : ℝ :=
  (1 + t) * ((1 / 4) * (125 / 64 - 19 / 4 * y)) + (1 + 1 / t) * ((3 / 8) * (3 / 4 * y + 1 / 8))

theorem Dlin_eq (y : ℝ) : Dlin (3 / 10) y = 429 / 512 - 13 / 40 * y := by
  unfold Dlin
  ring

theorem Dlin_le {y : ℝ} (hy : 0 ≤ y) : Dlin (3 / 10) y ≤ 429 / 512 := by
  rw [Dlin_eq]
  linarith

/-- The value at the end point `y = 1/4` (0.7566). -/
theorem Dlin_quarter : Dlin (3 / 10) (1 / 4) = 1937 / 2560 := by
  rw [Dlin_eq]
  norm_num

theorem const_429 : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-! ## S5. One direction: the two aliases -/

/-- `x = 4α sin²(r/2)` (`α = 1/8`) at the two aliases of one direction, `σ = sin²(q/4)`. -/
def xa (σ : ℝ) : Bool → ℝ
  | false => σ / 2
  | true => (1 - σ) / 2

/-- The weight `cos²(r_c/2)` at the two aliases of the distinguished direction. -/
def wa (σ : ℝ) : Bool → ℝ
  | false => 1 - σ
  | true => σ

/-- Trigonometric bridge for `x`: with `θ = q/4` the alias `ζ = 1` shifts `θ` by `π/2`. -/
theorem alias_x (θ : ℝ) (b : Bool) :
    (1 / 2) * Real.sin (θ + (if b then π / 2 else 0)) ^ 2 = xa (Real.sin θ ^ 2) b := by
  cases b <;> simp [xa, Real.sin_add_pi_div_two, Real.cos_sq'] <;> ring

/-- Trigonometric bridge for the weight `cos²(r_c/2)`. -/
theorem alias_w (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) ^ 2 = wa (Real.sin θ ^ 2) b := by
  cases b <;> simp [wa, Real.cos_add_pi_div_two, Real.cos_sq']

theorem sigma_mem (θ : ℝ) : 0 ≤ Real.sin θ ^ 2 ∧ Real.sin θ ^ 2 ≤ 1 :=
  ⟨sq_nonneg _, Real.sin_sq_le_one θ⟩

theorem xa_mem {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ xa σ b ∧ xa σ b ≤ 1 / 2 := by
  cases b <;> simp only [xa] <;> constructor <;> linarith

/-- `T[(1-x)²]`, the transverse factor of `M_c`. -/
def Tq (σ : ℝ) : ℝ := 5 / 4 - σ / 2 + σ ^ 2 / 2

/-- `T[x²]`. -/
def Tx2 (σ : ℝ) : ℝ := (σ ^ 2 + (1 - σ) ^ 2) / 4

/-- `y = σ(1-σ) = S_c[x]`. -/
def yv (σ : ℝ) : ℝ := σ * (1 - σ)

theorem sumT_one : ∑ _b : Bool, (1 : ℝ) = 2 := by
  rw [Fintype.sum_bool]
  norm_num

theorem sumT_x (σ : ℝ) : ∑ b, xa σ b = 1 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_x2 (σ : ℝ) : ∑ b, xa σ b ^ 2 = Tx2 σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tx2]
  ring

theorem sumT_1mx (σ : ℝ) : ∑ b, (1 - xa σ b) = 3 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_1mx2 (σ : ℝ) : ∑ b, (1 - xa σ b) ^ 2 = Tq σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tq]
  ring

theorem sumS_one (σ : ℝ) : ∑ b, wa σ b = 1 := by
  rw [Fintype.sum_bool]
  simp only [wa]
  ring

theorem sumS_x (σ : ℝ) : ∑ b, wa σ b * xa σ b = yv σ := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

theorem sumS_x2 (σ : ℝ) : ∑ b, wa σ b * xa σ b ^ 2 = yv σ / 4 := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

/-! Transverse bounds on `σ ∈ [0,1]` (the maximum is at `σ = 0`). -/

theorem Tq_pos (σ : ℝ) : 0 < Tq σ := by
  unfold Tq
  nlinarith [sq_nonneg (σ - 1 / 2)]

theorem Tq_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tq σ ≤ 5 / 4 := by
  unfold Tq
  nlinarith

/-- The factor `T[(1-x)²]` decreases on `[0, 1/2]` ("正かつ減る"). -/
theorem Tq_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) : Tq σ' ≤ Tq σ := by
  unfold Tq
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem Tx2_nonneg (σ : ℝ) : 0 ≤ Tx2 σ := by
  unfold Tx2
  positivity

theorem Tx2_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tx2 σ ≤ 1 / 4 := by
  unfold Tx2
  nlinarith

theorem Tx2_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) :
    Tx2 σ' ≤ Tx2 σ := by
  unfold Tx2
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem yv_nonneg {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ := by
  unfold yv
  exact mul_nonneg h0 (by linarith)

theorem yv_le (σ : ℝ) : yv σ ≤ 1 / 4 := by
  unfold yv
  nlinarith [sq_nonneg (σ - 1 / 2)]

/-! ## S4. Four directions: the alias sum factors monomial by monomial -/

/-- The alias sum over `ζ ∈ {0,1}⁴` of a product of one-direction factors is the product of the
one-direction sums. -/
theorem alias_factor (f0 f1 f2 f3 : Bool → ℝ) :
    ∑ b0, ∑ b1, ∑ b2, ∑ b3, f0 b0 * f1 b1 * f2 b2 * f3 b3 =
      (∑ b, f0 b) * (∑ b, f1 b) * (∑ b, f2 b) * (∑ b, f3 b) := by
  simp only [Fintype.sum_bool]
  ring

/-- `π_c − x_c` at the alias `(bc, b1, b2, b3)` (`c` the distinguished direction). -/
def pmx (σc σ1 σ2 σ3 : ℝ) (bc b1 b2 b3 : Bool) : ℝ :=
  (1 - xa σ1 b1) * (1 - xa σ2 b2) * (1 - xa σ3 b3) - xa σc bc

/-- `η̄_c = Σ_{μ≠c} x_μ (x_a + x_b)/2 · e₂(x_c, x_a, x_b)` (`{a,b}` the complement of `{μ,c}`). -/
def etaBar (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * ((x2 + x3) / 2) * (xc * x2 + xc * x3 + x2 * x3) +
  x2 * ((x1 + x3) / 2) * (xc * x1 + xc * x3 + x1 * x3) +
  x3 * ((x1 + x2) / 2) * (xc * x1 + xc * x2 + x1 * x2)

/-- `M_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) (π_c − x_c)²(r_ζ)`. -/
def Msum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2

/-- `L̄_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) η̄_c(r_ζ)`. -/
def Lsum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
    wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)

/-- Closed form of `M_c` (`¼[Π_{ν≠c}(5/4 − σ_ν/2 + σ_ν²/2) − (19/4) y_c]`). -/
theorem Msum_eq (σc σ1 σ2 σ3 : ℝ) :
    Msum σc σ1 σ2 σ3 = (1 / 4) * (Tq σ1 * Tq σ2 * Tq σ3 - 19 / 4 * yv σc) := by
  simp only [Msum, pmx, Fintype.sum_bool, xa, wa, Tq, yv]
  ring

/-- Closed form of `L̄_c` (`¼ Σ_{μ≠c} ½[y_c(T_a + T_b + ¼) + (T_a + T_b)/4]`). -/
theorem Lsum_eq (σc σ1 σ2 σ3 : ℝ) :
    Lsum σc σ1 σ2 σ3 = (1 / 4) *
      ((1 / 2) * (yv σc * (Tx2 σ2 + Tx2 σ3 + 1 / 4) + (Tx2 σ2 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ3 + 1 / 4) + (Tx2 σ1 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ2 + 1 / 4) + (Tx2 σ1 + Tx2 σ2) / 4)) := by
  simp only [Lsum, etaBar, Fintype.sum_bool, xa, wa, Tx2, yv]
  ring

/-! ## S4'. The bound on the box -/

theorem Msum_le {σc σ1 σ2 σ3 : ℝ} (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1)
    (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Msum σc σ1 σ2 σ3 ≤ (1 / 4) * (125 / 64 - 19 / 4 * yv σc) := by
  rw [Msum_eq]
  have hprod : Tq σ1 * Tq σ2 * Tq σ3 ≤ (5 / 4) * (5 / 4) * (5 / 4) := by
    apply mul_le_mul _ (Tq_le h3.1 h3.2) (Tq_pos _).le (by norm_num)
    exact mul_le_mul (Tq_le h1.1 h1.2) (Tq_le h2.1 h2.2) (Tq_pos _).le (by norm_num)
  linarith

theorem Lsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Lsum σc σ1 σ2 σ3 ≤ (3 / 8) * (3 / 4 * yv σc + 1 / 8) := by
  rw [Lsum_eq]
  have hy := yv_nonneg hc.1 hc.2
  have t1 := Tx2_le h1.1 h1.2
  have t2 := Tx2_le h2.1 h2.2
  have t3 := Tx2_le h3.1 h3.2
  have m1 := mul_le_mul_of_nonneg_left t1 hy
  have m2 := mul_le_mul_of_nonneg_left t2 hy
  have m3 := mul_le_mul_of_nonneg_left t3 hy
  nlinarith

/-- **The one-step bound on the box** (`t = 3/10`): for every direction `c` and every
`σ ∈ [0,1]⁴`, `D_c = (1+t) M_c + (1+1/t) L̄_c ≤ 429/512`. -/
theorem Dsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 429 / 512 := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have hD := Dlin_le (yv_nonneg hc.1 hc.2)
  unfold Dlin at hD
  have e1 : (1 + 1 / (3 / 10 : ℝ)) = 13 / 3 := by norm_num
  rw [e1]
  rw [e1] at hD
  nlinarith

/-- The same with the number of the request: `≤ 0.838`. -/
theorem Dsum_le_0838 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 0.838 :=
  (Dsum_le hc h1 h2 h3).trans const_429

/-- The same in the trigonometric variables: `σ_ν = sin²(θ_ν)`, `θ_ν = q_ν/4`. -/
theorem Dsum_le_trig (θc θ1 θ2 θ3 : ℝ) :
    (1 + 3 / 10) * Msum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) +
      (1 + 1 / (3 / 10)) *
        Lsum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) ≤
      429 / 512 :=
  Dsum_le (sigma_mem θc) (sigma_mem θ1) (sigma_mem θ2) (sigma_mem θ3)

/-! ## S6'. A general splitting parameter `t`, and `t = 31/100` -/

/-- For any `t > 0` the box bound reduces to the one-variable `D(y)`. -/
theorem Dsum_le_Dlin {t σc σ1 σ2 σ3 : ℝ} (ht : 0 < t) (hc : 0 ≤ σc ∧ σc ≤ 1)
    (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + t) * Msum σc σ1 σ2 σ3 + (1 + 1 / t) * Lsum σc σ1 σ2 σ3 ≤ Dlin t (yv σc) := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have a : 0 ≤ 1 + t := by linarith
  have b : 0 ≤ 1 + 1 / t := by positivity
  unfold Dlin
  have k1 := mul_le_mul_of_nonneg_left hM a
  have k2 := mul_le_mul_of_nonneg_left hL b
  linarith

theorem Dlin31_eq (y : ℝ) : Dlin (31 / 100) y = 26593 / 31744 - 18209 / 49600 * y := by
  unfold Dlin
  ring

/-- With `t = 31/100` (close to the optimal `√(12/125)` at `y = 0`):
`D_c ≤ 26593/31744 = 0.83773…`. -/
theorem Dsum_le_31 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 31 / 100) * Msum σc σ1 σ2 σ3 + (1 + 1 / (31 / 100)) * Lsum σc σ1 σ2 σ3 ≤
      26593 / 31744 := by
  have h := Dsum_le_Dlin (t := 31 / 100) (by norm_num) hc h1 h2 h3
  rw [Dlin31_eq] at h
  have hy := yv_nonneg hc.1 hc.2
  linarith

theorem const_31_0838 : (26593 / 31744 : ℝ) ≤ 0.838 := by norm_num

/-- With `λ = 26593/31744` and `e = 15/8`: `1 + 16 e/(1-λ) ≤ 186`, i.e. `c₁ ≥ 1/186`
(found that `λ = 0.838` gives `186.19`). -/
theorem const_c1_186 : 1 + 16 * ((15 / 8 : ℝ) / (1 - 26593 / 31744)) ≤ 186 := by norm_num

/-! ## S1(b). The alias vector stays physical: `w_ζ ⊥ s(r_ζ)` -/

/-- One direction, with `θ = q/4` and `r/2 = θ + [ζ]π/2`:
`cos(r/2)·(−1)^ζ·sin(r/2) = ½ sin(q/2)`  (`C(r) s(r) = s(2r)/2` and `s(2r_ζ) = S_ζ s(q)`). -/
theorem alias_orth (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) * (if b then -1 else 1) *
      Real.sin (θ + (if b then π / 2 else 0)) = (1 / 2) * Real.sin (2 * θ) := by
  cases b <;> simp [Real.cos_add_pi_div_two, Real.sin_add_pi_div_two, Real.sin_two_mul] <;> ring

/-- **`w_ζ ⊥ s(r_ζ)`**: with `w_ν = cos(r_ν/2)(−1)^{ζ_ν} u_ν` and `s_ν(r_ζ) = sin(r_ν/2)`,
`⟨w_ζ, s(r_ζ)⟩ = ½ ⟨u, s(q)⟩` (`s_ν(q) = sin(q_ν/2) = sin(2θ_ν)`); so `u ⊥ s(q)` gives
`w_ζ ⊥ s(r_ζ)`. -/
theorem alias_orth_sum {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) =
      (1 / 2) * ∑ ν, u ν * Real.sin (2 * θ ν) := by
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro ν _
  have h := alias_orth (θ ν) (ζ ν)
  calc (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))
      = u ν * (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))) := by ring
    _ = u ν * ((1 / 2) * Real.sin (2 * θ ν)) := by rw [h]
    _ = 1 / 2 * (u ν * Real.sin (2 * θ ν)) := by ring

theorem alias_orth_zero {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ)
    (hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) = 0 := by
  rw [alias_orth_sum, hu, mul_zero]

/-! ## e_T ≤ 15/8 : the scalar part -/

/-- `4 sin²(q/2) = 16 σ (1 − σ)` with `σ = sin²(q/4)` (`θ = q/4`). -/
theorem omega_dir (θ : ℝ) :
    4 * Real.sin (2 * θ) ^ 2 = 16 * (Real.sin θ ^ 2) * (1 - Real.sin θ ^ 2) := by
  rw [Real.sin_two_mul]
  have h := Real.sin_sq_add_cos_sq θ
  have hc : Real.cos θ ^ 2 = 1 - Real.sin θ ^ 2 := by linarith
  calc 4 * (2 * Real.sin θ * Real.cos θ) ^ 2 = 16 * Real.sin θ ^ 2 * Real.cos θ ^ 2 := by ring
    _ = _ := by rw [hc]

/-- `4 ω(q/2) − ω(q) = Σ 16 σ_ν² ≥ 0` in the `σ` variables
(`ω(q/2) = Σ 4σ_ν`, `ω(q) = Σ 16 σ_ν(1−σ_ν)`). -/
theorem omega_half (s0 s1 s2 s3 : ℝ) :
    16 * (s0 * (1 - s0) + s1 * (1 - s1) + s2 * (1 - s2) + s3 * (1 - s3)) ≤
      4 * (4 * s0 + 4 * s1 + 4 * s2 + 4 * s3) := by
  nlinarith [sq_nonneg s0, sq_nonneg s1, sq_nonneg s2, sq_nonneg s3]

/-- `ω` at the alias `ζ`: `Σ_ν 4 (σ_ν or 1 − σ_ν)`; for `ζ ≠ 0` and `σ ∈ [0, 1/2]⁴` it is `≥ 2`. -/
def omA (s0 s1 s2 s3 : ℝ) (b0 b1 b2 b3 : Bool) : ℝ :=
  4 * (if b0 then 1 - s0 else s0) + 4 * (if b1 then 1 - s1 else s1) +
    4 * (if b2 then 1 - s2 else s2) + 4 * (if b3 then 1 - s3 else s3)

theorem omA_ge_two {s0 s1 s2 s3 : ℝ} (h0 : 0 ≤ s0 ∧ s0 ≤ 1 / 2) (h1 : 0 ≤ s1 ∧ s1 ≤ 1 / 2)
    (h2 : 0 ≤ s2 ∧ s2 ≤ 1 / 2) (h3 : 0 ≤ s3 ∧ s3 ≤ 1 / 2) (b0 b1 b2 b3 : Bool)
    (hb : (b0 || b1 || b2 || b3) = true) : 2 ≤ omA s0 s1 s2 s3 b0 b1 b2 b3 := by
  unfold omA
  cases b0 <;> cases b1 <;> cases b2 <;> cases b3 <;> simp at hb ⊢ <;> linarith

/-- **The scalar step of `e_T ≤ 15/8`**: if the `ζ = 0` term satisfies `¼ F₀ ≤ 1/ω` and the
fifteen others `F_ζ ≤ 1/2` (from `ν² cos² ≤ 1` and `ω(r_ζ) ≥ 2`), then `¼ Σ_ζ F_ζ ≤ 1/ω + 15/8`. -/
theorem eT_sum (F : Bool → Bool → Bool → Bool → ℝ) {w : ℝ}
    (h0 : (1 / 4) * F false false false false ≤ w)
    (hF : ∀ b0 b1 b2 b3, (b0 || b1 || b2 || b3) = true → F b0 b1 b2 b3 ≤ 1 / 2) :
    (1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, F b0 b1 b2 b3 ≤ w + 15 / 8 := by
  simp only [Fintype.sum_bool]
  have := hF true true true true rfl
  have := hF true true true false rfl
  have := hF true true false true rfl
  have := hF true true false false rfl
  have := hF true false true true rfl
  have := hF true false true false rfl
  have := hF true false false true rfl
  have := hF true false false false rfl
  have := hF false true true true rfl
  have := hF false true true false rfl
  have := hF false true false true rfl
  have := hF false true false false rfl
  have := hF false false true true rfl
  have := hF false false true false rfl
  have := hF false false false true rfl
  linarith

/-! ## S2. Matrix level: Lemma 4 and the square bound -/

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- `(N u)_μ = π_μ u_μ + s̃_μ Σ_{ν≠μ} (1 − E_{μν}) s̃_ν u_ν`
(`N = diag π + diag s̃ 𝔅 diag s̃`, `𝔅_{μν} = 1 − E_{μν}` off the diagonal, `𝔅_{μμ} = 0`). -/
def Nap (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ) (μ : ι) : ℝ :=
  pi μ * u μ + st μ * ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)

/-- **Lemma 4 of **: for `u ⊥ s̃`,
`(N u)_μ = (π_μ − s̃_μ²) u_μ − s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν`. -/
theorem comp_identity (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (μ : ι) :
    Nap pi st E u μ =
      (pi μ - st μ ^ 2) * u μ - st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
  unfold Nap
  have h1 : ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)
      = ∑ ν ∈ univ.erase μ, st ν * u ν - ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro ν _
    ring
  have h2 : ∑ ν ∈ univ.erase μ, st ν * u ν = -(st μ * u μ) := by
    rw [Finset.sum_erase_eq_sub (Finset.mem_univ μ), hu]
    ring
  rw [h1, h2]
  ring

/-- `(a − b)² ≤ (1+t) a² + (1+1/t) b²` for `t > 0`. -/
theorem sq_split (a b : ℝ) {t : ℝ} (ht : 0 < t) :
    (a - b) ^ 2 ≤ (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 := by
  have key : (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 - (a - b) ^ 2 = (t * a + b) ^ 2 / t := by
    field_simp
    ring
  have : 0 ≤ (t * a + b) ^ 2 / t := by positivity
  linarith

omit [Fintype ι] [DecidableEq ι] in
/-- Weighted Cauchy–Schwarz: `(Σ w a b)² ≤ (Σ w a²)(Σ w b²)` for `w ≥ 0`. -/
theorem wcs (s : Finset ι) (w a b : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s, w i * (a i * b i)) ^ 2 ≤ (∑ i ∈ s, w i * a i ^ 2) * ∑ i ∈ s, w i * b i ^ 2 := by
  apply Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul s
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i _
    apply le_of_eq
    ring

/-- The componentwise square bound (the corollary of Lemma 4). -/
theorem comp_sq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) := by
  rw [comp_identity pi st E u hu μ]
  have h := sq_split ((pi μ - st μ ^ 2) * u μ)
    (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ht
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ 1 + 1 / t := by positivity
  have hb : (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ^ 2 ≤
      st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
    rw [mul_pow]
    exact mul_le_mul_of_nonneg_left hcs (sq_nonneg _)
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hb hc
  linarith

/-- **The square bound** `|N u|² ≤ Σ_μ [(1+t)(π_μ − x_μ)² u_μ² + (1+1/t) x_μ ρ'_μ Σ_{ν≠μ} E_{μν} u_ν²]`
for `u ⊥ s̃`, `E ≥ 0`, `x = s̃²`, `ρ'_μ = Σ_{ν≠μ} E_{μν} x_ν`. -/
theorem normSq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2))) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le pi st E u hu hE ht μ

end MatrixLevel

/-! ## S3. The specific `E` and `η ≤ η̄` (directions `c, 1, 2, 3`, all `x ∈ [0, 1/2]`) -/

/-- `E_{μν} = (x_ρ + x_σ)/2 − x_ρ x_σ/3` as a function of the complementary pair `{ρ, σ}`. -/
def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

theorem Ef_nonneg {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) : 0 ≤ Ef y z := by
  unfold Ef
  nlinarith [mul_le_mul_of_nonneg_left hz.2 hy.1]

theorem Ef_le {y z : ℝ} (hy : 0 ≤ y) (hz : 0 ≤ z) : Ef y z ≤ (y + z) / 2 := by
  unfold Ef
  nlinarith [mul_nonneg hy hz]

/-- `ρ'_μ = Σ_{λ≠μ} E_{μλ} x_λ`, the other three directions being `c, a, b`. -/
def rhoP (xc xa xb : ℝ) : ℝ := Ef xa xb * xc + Ef xc xb * xa + Ef xc xa * xb

theorem rhoP_nonneg {xc xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (ha : 0 ≤ xa ∧ xa ≤ 1 / 2)
    (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) : 0 ≤ rhoP xc xa xb := by
  unfold rhoP
  have e1 := mul_nonneg (Ef_nonneg ha hb) hc.1
  have e2 := mul_nonneg (Ef_nonneg hc hb) ha.1
  have e3 := mul_nonneg (Ef_nonneg hc ha) hb.1
  linarith

/-- `ρ'_μ ≤ e₂(x_{−μ})`. -/
theorem rhoP_le {xc xa xb : ℝ} (hc : 0 ≤ xc) (ha : 0 ≤ xa) (hb : 0 ≤ xb) :
    rhoP xc xa xb ≤ xc * xa + xc * xb + xa * xb := by
  unfold rhoP
  have e1 := mul_le_mul_of_nonneg_right (Ef_le ha hb) hc
  have e2 := mul_le_mul_of_nonneg_right (Ef_le hc hb) ha
  have e3 := mul_le_mul_of_nonneg_right (Ef_le hc ha) hb
  nlinarith

/-- `η_c = Σ_{μ≠c} x_μ E_{μc} ρ'_μ` (directions `c, 1, 2, 3`). -/
def eta (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * Ef x2 x3 * rhoP xc x2 x3 + x2 * Ef x1 x3 * rhoP xc x1 x3 + x3 * Ef x1 x2 * rhoP xc x1 x2

/-- One term of `η ≤ η̄`. -/
theorem eta_term_le {xc xm xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (hm : 0 ≤ xm)
    (ha : 0 ≤ xa ∧ xa ≤ 1 / 2) (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) :
    xm * Ef xa xb * rhoP xc xa xb ≤ xm * ((xa + xb) / 2) * (xc * xa + xc * xb + xa * xb) := by
  apply mul_le_mul (mul_le_mul_of_nonneg_left (Ef_le ha.1 hb.1) hm)
    (rhoP_le hc.1 ha.1 hb.1) (rhoP_nonneg hc ha hb)
  exact mul_nonneg hm (by linarith [ha.1, hb.1])

/-- **`η_c ≤ η̄_c`** (`0 ≤ E_{μν} ≤ (x_ρ + x_σ)/2`, `0 ≤ ρ'_μ ≤ e₂(x_{−μ})`). -/
theorem eta_le_etaBar {xc x1 x2 x3 : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (h1 : 0 ≤ x1 ∧ x1 ≤ 1 / 2)
    (h2 : 0 ≤ x2 ∧ x2 ≤ 1 / 2) (h3 : 0 ≤ x3 ∧ x3 ≤ 1 / 2) :
    eta xc x1 x2 x3 ≤ etaBar xc x1 x2 x3 := by
  unfold eta etaBar
  have k1 := eta_term_le hc h1.1 h2 h3
  have k2 := eta_term_le hc h2.1 h1 h3
  have k3 := eta_term_le hc h3.1 h1 h2
  linarith

/-- The coefficient of `u_c²` in the alias sum with the true `η_c` is bounded by `D_c`
(`(1+t) M_c + (1+1/t) L̄_c` with `η̄_c`), alias by alias. -/
theorem alias_coeff_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤ 429 / 512 := by
  have hw : ∀ b, 0 ≤ wa σc b := by
    intro b
    cases b <;> simp only [wa] <;> linarith [hc.1, hc.2]
  have step : ∀ bc b1 b2 b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      (1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) := by
    intro bc b1 b2 b3
    have he := eta_le_etaBar (xa_mem hc.1 hc.2 bc) (xa_mem h1.1 h1.2 b1) (xa_mem h2.1 h2.2 b2)
      (xa_mem h3.1 h3.2 b3)
    have hm := mul_le_mul_of_nonneg_left he (hw bc)
    have hpos : (0 : ℝ) ≤ 1 + 1 / (3 / 10) := by norm_num
    nlinarith [mul_le_mul_of_nonneg_left hm hpos]
  have hD := Dsum_le hc h1 h2 h3
  unfold Msum Lsum at hD
  have hsum : ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) := by
    apply Finset.sum_le_sum; intro bc _
    apply Finset.sum_le_sum; intro b1 _
    apply Finset.sum_le_sum; intro b2 _
    apply Finset.sum_le_sum; intro b3 _
    exact step bc b1 b2 b3
  have hsplit : ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) =
      (1 + 3 / 10) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
      (1 + 1 / (3 / 10)) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) := by
    simp only [Fintype.sum_bool]
    ring
  rw [hsplit] at hsum
  nlinarith

/-! ## S2'. Swapping the off-diagonal double sum (`Σ_μ a_μ Σ_{ν≠μ} E_{μν} v_ν = Σ_ν v_ν η_ν`) -/

section Swap

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem swap_erase (a : ι → ℝ) (E : ι → ι → ℝ) (v : ι → ℝ) :
    ∑ μ, a μ * ∑ ν ∈ univ.erase μ, E μ ν * v ν =
      ∑ ν, v ν * ∑ μ ∈ univ.erase ν, a μ * E μ ν := by
  simp only [Finset.sum_erase_eq_sub (Finset.mem_univ _), mul_sub, Finset.sum_sub_distrib,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  congr 1
  · apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro y _
    ring
  · apply Finset.sum_congr rfl
    intro x _
    ring

end Swap

/-! ## Bridge to `UniformBracket` : a coordinate bound gives `M P ≼ λ P` -/

section Bridge

open scoped RealInnerProductSpace

variable {Q : Type*} {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The Loewner order of families, copied verbatim from `UniformBracket.Lw`. -/
def Lw (A B : Q → V →ₗ[ℝ] V) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

/-- If, in orthonormal coordinates `coord`, the quadratic form of `M P` is bounded by a diagonal
form `Σ_c D_c (P x)_c²` with every `D_c ≤ λ`, then `M P ≼ λ P` (the hypothesis `hPstep` of
`UniformBracket.bracket`). -/
theorem lw_of_coord_bound (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (D : Q → Fin 4 → ℝ) {lam : ℝ}
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, D q c * coord (P q x) c ^ 2)
    (hD : ∀ q c, D q c ≤ lam) : Lw MP (lam • P) := by
  intro q x
  have hPx : ⟪x, P q x⟫ = ∑ c, coord (P q x) c ^ 2 := by
    have h := hPs q x (P q x)
    rw [hPP q x] at h
    rw [← h, hcoord]
  have hsum : ∑ c, D q c * coord (P q x) c ^ 2 ≤ ∑ c, lam * coord (P q x) c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (hD q c) (sq_nonneg _)
  rw [← Finset.mul_sum] at hsum
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [hPx]
  exact (hrep q x).trans hsum

/-- The `D_c` of for the four directions (the other three in increasing order). -/
def Dc (σ : Fin 4 → ℝ) (c : Fin 4) : ℝ :=
  ![(1 + 3 / 10) * Msum (σ 0) (σ 1) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 0) (σ 1) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 1) (σ 0) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 1) (σ 0) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 2) (σ 0) (σ 1) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 2) (σ 0) (σ 1) (σ 3),
    (1 + 3 / 10) * Msum (σ 3) (σ 0) (σ 1) (σ 2) + (1 + 1 / (3 / 10)) * Lsum (σ 3) (σ 0) (σ 1) (σ 2)]
    c

theorem Dc_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) : Dc σ c ≤ 429 / 512 := by
  fin_cases c
  · exact Dsum_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact Dsum_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-- **The hand-over to `UniformBracket`**: if the quadratic form of `M P` at `q` is bounded by
`Σ_c D_c(σ(q)) (P x)_c²` (the alias representation, not formalized here), with
`σ_ν(q) = sin²(q_ν/4) ∈ [0,1]`, then `M P ≼ λ P` with `λ = 429/512 ≤ 0.838`. -/
theorem MP_le (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (σ : Q → Fin 4 → ℝ)
    (hσ : ∀ q ν, 0 ≤ σ q ν ∧ σ q ν ≤ 1)
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, Dc (σ q) c * coord (P q x) c ^ 2) :
    Lw MP ((429 / 512 : ℝ) • P) :=
  lw_of_coord_bound MP P hPs hPP coord hcoord (fun q c => Dc (σ q) c) hrep
    (fun q c => Dc_le (hσ q) c)

end Bridge

end OneStepNorm


-- ===== body of an earlier file (without its import line and #print axioms) =====

/-!
# Fourier analysis on a finite abelian group, decimation by a homomorphism, and the
symbols of the block-constraint operator

Momenta are the characters `ψ : AddChar F ℂ` of a finite additive group `F`
(for the torus `F = (ℤ/2L)^d` these are `y ↦ exp(i k·y)`).  Convention
`f̂(ψ) = Σ_y ψ(-y) f(y)`.

* §1 the transform: translation, convolution, inversion, Plancherel, injectivity;
* §2 decimation along `β : G →+ F` (coarse points `X ↦ β X`): the sampled function has the
  alias-sum transform `|F| (f∘β)^(φ) = |G| Σ_{ψ ∘ β = φ} f̂(ψ)`;
* §3 the constraint operator `(Ca)(X) = Σ_r c(r) a(βX + r)` and its adjoint: alias sums for
  `C`, `C†`, `C C†` and `C T C†` (`T` translation invariant on the fine group);
* §4 a lower bound on the symbol at one alias per coarse momentum gives a real-space lower bound
  `‖C† w‖² ≥ (|G|/|F|) c₀ ‖w‖²`, and `C` is onto (complex and real kernels);
* §5 intertwining of gradients from a symbol identity (`C ∇ = ∇ ∘ res`);
* §6 the torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X`, where `|F|/|G| = 2^d`;
* §7 the alias representation of the one-step map on the projection (linear algebra).
-/

open Finset
open scoped ComplexConjugate

noncomputable section

namespace TorusFourier

/-! ## §1 The transform -/

section Transform

variable {F : Type*} [AddCommGroup F] [Fintype F]

/-- Fourier transform, `f̂(ψ) = Σ_y ψ(-y) f(y)`. -/
def ft (f : F → ℂ) (ψ : AddChar F ℂ) : ℂ := ∑ y, ψ (-y) * f y

theorem ft_add (f g : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => f y + g y) ψ = ft f ψ + ft g ψ := by
  unfold ft; rw [← Finset.sum_add_distrib]; congr 1; ext y; ring

theorem ft_const_mul (k : ℂ) (f : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => k * f y) ψ = k * ft f ψ := by
  unfold ft; rw [Finset.mul_sum]; congr 1; ext y; ring

theorem ft_sum {α : Type*} (s : Finset α) (f : α → F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ i ∈ s, f i y) ψ = ∑ i ∈ s, ft (f i) ψ := by
  unfold ft
  simp_rw [Finset.mul_sum]
  exact Finset.sum_comm

/-- Translation becomes multiplication by the character. -/
theorem ft_translate (f : F → ℂ) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => f (y + r)) ψ = ψ r * ft f ψ := by
  unfold ft
  rw [Finset.mul_sum]
  refine Fintype.sum_equiv (Equiv.addRight r) _ _ (fun y => ?_)
  simp only [Equiv.coe_addRight]
  rw [show -y = -(y + r) + r by abel, AddChar.map_add_eq_mul]
  ring

/-- Convolution `(f ⋆ g)(x) = Σ_y f(y) g(x - y)`. -/
def conv (f g : F → ℂ) (x : F) : ℂ := ∑ y, f y * g (x - y)

/-- Convolution becomes multiplication. -/
theorem ft_conv (f g : F → ℂ) (ψ : AddChar F ℂ) : ft (conv f g) ψ = ft f ψ * ft g ψ := by
  unfold conv
  rw [ft_sum]
  have h : ∀ y, ft (fun x => f y * g (x - y)) ψ = ψ (-y) * f y * ft g ψ := by
    intro y
    rw [ft_const_mul]
    have := ft_translate g (-y) ψ
    simp only [← sub_eq_add_neg] at this
    rw [this]; ring
  simp_rw [h]
  unfold ft
  rw [Finset.sum_mul]

/-- Inversion: `Σ_ψ ψ(y) f̂(ψ) = |F| f(y)`. -/
theorem ft_inv (f : F → ℂ) (y : F) :
    ∑ ψ : AddChar F ℂ, ψ y * ft f ψ = (Fintype.card F : ℂ) * f y := by
  classical
  unfold ft
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  have h : ∀ x, ∑ ψ : AddChar F ℂ, ψ y * (ψ (-x) * f x) =
      (if y - x = 0 then (Fintype.card F : ℂ) else 0) * f x := by
    intro x
    rw [← AddChar.sum_apply_eq_ite, Finset.sum_mul]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    rw [sub_eq_add_neg, AddChar.map_add_eq_mul]; ring
  simp_rw [h, sub_eq_zero, ite_mul, zero_mul]
  rw [Finset.sum_ite_eq]
  simp

/-- The transform is injective. -/
theorem ft_injective {f g : F → ℂ} (h : ∀ ψ, ft f ψ = ft g ψ) : f = g := by
  funext y
  have h1 := ft_inv f y
  have h2 := ft_inv g y
  simp_rw [h] at h1
  have hc : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  exact mul_left_cancel₀ hc (h1.symm.trans h2)

theorem conj_ft (f : F → ℂ) (ψ : AddChar F ℂ) : conj (ft f ψ) = ∑ y, ψ y * conj (f y) := by
  unfold ft
  rw [map_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj, Complex.conj_conj]

/-- Plancherel (sesquilinear form). -/
theorem plancherel (f g : F → ℂ) :
    ∑ ψ : AddChar F ℂ, conj (ft f ψ) * ft g ψ =
      (Fintype.card F : ℂ) * ∑ y, conj (f y) * g y := by
  simp_rw [conj_ft, Finset.sum_mul]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  calc ∑ ψ : AddChar F ℂ, ψ y * conj (f y) * ft g ψ
        = conj (f y) * ∑ ψ : AddChar F ℂ, ψ y * ft g ψ := by
          rw [Finset.mul_sum]; refine Finset.sum_congr rfl fun ψ _ => ?_; ring
    _ = _ := by rw [ft_inv]; ring

/-- Plancherel (norms). -/
theorem plancherel_norm (f : F → ℂ) :
    ∑ ψ : AddChar F ℂ, ‖ft f ψ‖ ^ 2 = (Fintype.card F : ℝ) * ∑ y, ‖f y‖ ^ 2 := by
  have h := plancherel f f
  simp_rw [Complex.conj_mul'] at h
  exact_mod_cast h

end Transform

/-! ## §2 Decimation along a homomorphism -/

section Decimation

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]

/-- Restriction of a fine momentum to the coarse group (for the torus: `k ↦ 2k`). -/
def res (β : G →+ F) (ψ : AddChar F ℂ) : AddChar G ℂ := ψ.compAddMonoidHom β

omit [Fintype F] [Fintype G] in
@[simp] theorem res_apply (β : G →+ F) (ψ : AddChar F ℂ) (X : G) : res β ψ X = ψ (β X) := rfl

omit [Fintype F] in
/-- Orthogonality on the coarse group: `Σ_X φ(-X) ψ(βX) = |G| [ψ ∘ β = φ]`. -/
theorem sum_res_mul (β : G →+ F) (ψ : AddChar F ℂ) (φ : AddChar G ℂ) :
    ∑ X, φ (-X) * ψ (β X) = if res β ψ = φ then (Fintype.card G : ℂ) else 0 := by
  classical
  have h := AddChar.sum_eq_ite (res β ψ - φ)
  have e : ∀ X, (res β ψ - φ) X = φ (-X) * ψ (β X) := by
    intro X
    rw [sub_eq_add_neg, AddChar.add_apply, AddChar.neg_apply, res_apply]
    ring
  simp_rw [e] at h
  rw [h]
  simp only [sub_eq_zero]

/-- **Decimation is an alias sum**: `|F| (f ∘ β)^(φ) = |G| Σ_{ψ : ψ∘β = φ} f̂(ψ)`. -/
theorem ft_sample (β : G →+ F) (f : F → ℂ) (φ : AddChar G ℂ) :
    (Fintype.card F : ℂ) * ft (fun X => f (β X)) φ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ, if res β ψ = φ then ft f ψ else 0 := by
  rw [ft, Finset.mul_sum]
  have h : ∀ X, (Fintype.card F : ℂ) * (φ (-X) * f (β X)) =
      ∑ ψ : AddChar F ℂ, φ (-X) * ψ (β X) * ft f ψ := by
    intro X
    rw [mul_left_comm, ← ft_inv f (β X), Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    ring
  simp_rw [h]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ψ _ => ?_
  rw [← Finset.sum_mul, sum_res_mul]
  split_ifs <;> ring

/-- **The number of aliases**: for an injective `β`, every coarse momentum has exactly
`|F|/|G|` fine momenta above it (`f = δ₀` in `ft_sample`). -/
theorem card_alias (β : G →+ F) (hβ : Function.Injective β) (φ : AddChar G ℂ) :
    (Fintype.card G : ℂ) * ((Finset.univ.filter fun ψ : AddChar F ℂ => res β ψ = φ).card : ℂ) =
      Fintype.card F := by
  classical
  have h := ft_sample β (fun y => if y = 0 then (1 : ℂ) else 0) φ
  have h1 : ∀ ψ : AddChar F ℂ, ft (fun y => if y = 0 then (1 : ℂ) else 0) ψ = 1 := by
    intro ψ
    unfold ft
    simp
  have h2 : ft (fun X => if β X = 0 then (1 : ℂ) else 0) φ = 1 := by
    unfold ft
    have e : ∀ X, (φ (-X) * if β X = 0 then (1 : ℂ) else 0) = if X = 0 then 1 else 0 := by
      intro X
      by_cases hX : X = 0
      · subst hX; simp
      · have : β X ≠ 0 := fun h0 => hX (hβ (h0.trans (map_zero β).symm))
        simp [hX, this]
    simp_rw [e]
    simp
  simp only [h1, h2, mul_one] at h
  rw [h, Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, nsmul_eq_mul, mul_one]

end Decimation

/-! ## §3 The constraint operator, its adjoint, and their symbols -/

section Constraint

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- Componentwise transform of a vector-valued field. -/
def ftv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (a : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ft (fun y => a y ν) ψ

/-- The constraint operator `(Ca)_μ(X) = Σ_r Σ_ν c(r)_{μν} a_ν(βX + r)`. -/
def Cop (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) : G → κ → ℂ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- Its symbol `Q(ψ)_{μν} = Σ_r c(r)_{μν} ψ(r)`. -/
def sym (c : F → κ → ι → ℂ) (ψ : AddChar F ℂ) (μ : κ) (ν : ι) : ℂ := ∑ r, c r μ ν * ψ r

/-- The adjoint `(C†w)_ν(y) = Σ_X Σ_μ conj(c(y - βX)_{μν}) w_μ(X)`. -/
def Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ X, ∑ μ, conj (c (y - β X) μ ν) * w X μ

omit [Fintype ι] in
theorem ft_translate_v (a : F → ι → ℂ) (ν : ι) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => a (y + r) ν) ψ = ψ r * ftv a ψ ν :=
  ft_translate (fun y => a y ν) r ψ

omit [Fintype κ] in
theorem ft_shiftSum (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (μ : κ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) ψ = ∑ ν, sym c ψ μ ν * ftv a ψ ν := by
  rw [ft_sum]
  have h : ∀ r, ft (fun y => ∑ ν, c r μ ν * a (y + r) ν) ψ =
      ∑ ν, c r μ ν * (ψ r * ftv a ψ ν) := by
    intro r
    rw [ft_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ft_const_mul, ft_translate_v]
  simp_rw [h]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ν _ => ?_
  unfold sym
  rw [Finset.sum_mul]
  refine Finset.sum_congr rfl fun r _ => ?_
  ring

omit [Fintype κ] in
/-- **Alias sum for `C`**: `|F| (Ca)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) â(ψ)`. -/
theorem alias_C (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c a) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then ∑ ν, sym c ψ μ ν * ftv a ψ ν else 0 := by
  have h := ft_sample β (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) φ
  simp only [ft_shiftSum] at h
  exact h

omit [Fintype ι] [Fintype κ] in
theorem ft_conj_kernel (c : F → κ → ι → ℂ) (μ : κ) (ν : ι) (ψ : AddChar F ℂ) :
    ft (fun z => conj (c z μ ν)) ψ = conj (sym c ψ μ ν) := by
  unfold ft sym
  rw [map_sum]
  refine Finset.sum_congr rfl fun r _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj]
  ring

omit [Fintype ι] in
/-- **Symbol of the adjoint**: `(C†w)^(ψ) = Q(ψ)† ŵ(ψ ∘ β)`. -/
theorem ftv_Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Cadj β c w) ψ ν = ∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ := by
  unfold ftv Cadj
  rw [ft_sum]
  have h1 : ∀ X, ft (fun y => ∑ μ, conj (c (y - β X) μ ν) * w X μ) ψ =
      ∑ μ, w X μ * (ψ (-(β X)) * conj (sym c ψ μ ν)) := by
    intro X
    rw [ft_sum]
    refine Finset.sum_congr rfl fun μ _ => ?_
    have ht := ft_translate (fun z => conj (c z μ ν)) (-(β X)) ψ
    beta_reduce at ht
    have e : (fun y => conj (c (y - β X) μ ν) * w X μ) =
        fun y => w X μ * conj (c (y + -(β X)) μ ν) := by
      funext y
      rw [sub_eq_add_neg]
      ring
    rw [e, ft_const_mul, ht, ft_conj_kernel]
  simp_rw [h1]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun μ _ => ?_
  unfold ft
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [res_apply, map_neg β X]
  ring

/-- **Symbol of `C C†`** (命題 E): `|F| (CC†w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CCadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (φ : AddChar G ℂ)
    (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Cadj β c w)) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- A translation-invariant operator on the fine group, `(Ta)_ν(y) = Σ_z Σ_ν' t(z)_{νν'} a_ν'(y - z)`. -/
def Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν'

theorem ftv_Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Tconv t a) ψ ν = ∑ ν', ft (fun z => t z ν ν') ψ * ftv a ψ ν' := by
  unfold ftv Tconv
  have e : (fun y => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν') =
      fun y => ∑ ν', conv (fun z => t z ν ν') (fun z => a z ν') y := by
    funext y
    unfold conv
    exact Finset.sum_comm
  rw [e, ft_sum]
  refine Finset.sum_congr rfl fun ν' _ => ?_
  rw [ft_conv]

/-- **Symbol of `C T C†`** (the push-forward of a covariance, the form of the map `𝓡`):
`|F| (C T C† w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) t̂(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CTCadj (β : G →+ F) (c : F → κ → ι → ℂ) (t : F → ι → ι → ℂ) (w : G → κ → ℂ)
    (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Tconv t (Cadj β c w))) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ ν', ft (fun z => t z ν ν') ψ *
            ∑ l, conj (sym c ψ l ν') * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Tconv]
    congr 1
    refine Finset.sum_congr rfl fun ν' _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- `C†` is the adjoint of `C` for the sesquilinear forms `Σ conj(u) v`. -/
theorem Cop_adjoint (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (w : G → κ → ℂ) :
    ∑ X, ∑ μ, conj (w X μ) * Cop β c a X μ = ∑ y, ∑ ν, conj (Cadj β c w y ν) * a y ν := by
  have hL : ∀ X μ, conj (w X μ) * Cop β c a X μ =
      ∑ ν, ∑ r, conj (w X μ) * (c r μ ν * a (β X + r) ν) := by
    intro X μ
    unfold Cop
    rw [Finset.mul_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [Finset.mul_sum]
  have hR : ∀ y ν, conj (Cadj β c w y ν) * a y ν =
      ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    intro y ν
    unfold Cadj
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun X _ => ?_
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [map_mul, Complex.conj_conj]
    ring
  simp_rw [hL, hR]
  -- right side: Σ_y Σ_ν Σ_X Σ_μ  →  Σ_X Σ_μ Σ_ν Σ_y
  have s1 : ∑ y, ∑ ν, ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) =
      ∑ X, ∑ μ, ∑ ν, ∑ y, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    rw [Finset.sum_comm]
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset G))]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun X _ => ?_
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset κ))]
    rw [Finset.sum_comm]
  rw [s1]
  refine Finset.sum_congr rfl fun X _ => ?_
  refine Finset.sum_congr rfl fun μ _ => ?_
  refine Finset.sum_congr rfl fun ν _ => ?_
  refine Fintype.sum_equiv (Equiv.addLeft (β X)) _ _ (fun r => ?_)
  simp only [Equiv.coe_addLeft, add_sub_cancel_left]

end Constraint

/-! ## §4 Lower bound from one alias per coarse momentum; `C` is onto -/

section Onto

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **Real-space lower bound for `C†`**: if for every coarse momentum `φ` one alias `sec φ`
(`sec φ ∘ β = φ`) has `|Q(sec φ)† v|² ≥ c₀ |v|²`, then `|F| ‖C†w‖² ≥ |G| c₀ ‖w‖²`. -/
theorem Cadj_lower (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ}
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : G → κ → ℂ) :
    (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤
      (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 := by
  classical
  set g : AddChar F ℂ → ℝ := fun ψ =>
    ∑ ν, ‖∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ‖ ^ 2 with hg
  have hR : (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = ∑ ψ, g ψ := by
    rw [Finset.sum_comm, Finset.mul_sum]
    have h : ∀ ν, (Fintype.card F : ℝ) * ∑ y, ‖Cadj β c w y ν‖ ^ 2 =
        ∑ ψ : AddChar F ℂ, ‖ftv (Cadj β c w) ψ ν‖ ^ 2 := fun ν =>
      (plancherel_norm (fun y => Cadj β c w y ν)).symm
    simp_rw [h, ftv_Cadj]
    rw [Finset.sum_comm]
  have hinj : Function.Injective sec := fun a b h => by rw [← hsec a, ← hsec b, h]
  have hg0 : ∀ ψ, 0 ≤ g ψ := fun ψ => Finset.sum_nonneg fun ν _ => sq_nonneg _
  have hsub : ∑ φ, g (sec φ) ≤ ∑ ψ, g ψ := by
    rw [← Finset.sum_image (fun a _ b _ h => hinj h)]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      (fun ψ _ _ => hg0 ψ)
  have hlow : ∀ φ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 ≤ g (sec φ) := by
    intro φ
    rw [hg]
    simp only [hsec]
    exact hc₀ φ (fun μ => ftv w φ μ)
  have hL : (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 =
      ∑ φ : AddChar G ℂ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 := by
    rw [← Finset.mul_sum, Finset.sum_comm (s := (Finset.univ : Finset (AddChar G ℂ))),
      Finset.sum_comm (s := (Finset.univ : Finset G))]
    have h : ∀ μ, ∑ φ : AddChar G ℂ, ‖ftv w φ μ‖ ^ 2 =
        (Fintype.card G : ℝ) * ∑ X, ‖w X μ‖ ^ 2 := fun μ => plancherel_norm (fun X => w X μ)
    simp_rw [h]
    rw [← Finset.mul_sum]
    ring
  rw [hL, hR]
  exact (Finset.sum_le_sum fun φ _ => hlow φ).trans hsub

/-- `C C†` as a complex-linear map on coarse fields. -/
def CCL (β : G →+ F) (c : F → κ → ι → ℂ) : (G → κ → ℂ) →ₗ[ℂ] (G → κ → ℂ) where
  toFun w := Cop β c (Cadj β c w)
  map_add' w v := by
    funext X μ
    simp only [Cop, Cadj, Pi.add_apply, mul_add, Finset.sum_add_distrib]
  map_smul' k w := by
    funext X μ
    simp only [Cop, Cadj, Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    refine Finset.sum_congr rfl fun r _ => Finset.sum_congr rfl fun ν _ => ?_
    refine Finset.sum_congr rfl fun X' _ => Finset.sum_congr rfl fun μ' _ => ?_
    ring

/-- **`C` is onto** under the one-alias symbol bound with `c₀ > 0`. -/
theorem Cop_surjective (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (Cop β c) := by
  have hinj : Function.Injective (CCL β c) := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    have hw' : Cop β c (Cadj β c w) = 0 := hw
    have hadj := Cop_adjoint β c (Cadj β c w) w
    rw [hw'] at hadj
    simp only [Pi.zero_apply, mul_zero, Finset.sum_const_zero] at hadj
    simp_rw [Complex.conj_mul'] at hadj
    have hzero : ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = 0 := by exact_mod_cast hadj.symm
    have hlow := Cadj_lower β c sec hsec hc₀ w
    rw [hzero, mul_zero] at hlow
    have hG : (0 : ℝ) < Fintype.card G := Nat.cast_pos.mpr Fintype.card_pos
    have hs0 : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ 0 := by
      by_contra hne
      have hne' : 0 < ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos (mul_pos hG hpos) hne'
      linarith
    have hs : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 = 0 :=
      le_antisymm hs0 (Finset.sum_nonneg fun X _ => Finset.sum_nonneg fun μ _ => sq_nonneg _)
    funext X μ
    have h1 := (Finset.sum_eq_zero_iff_of_nonneg (fun X _ =>
      Finset.sum_nonneg fun μ _ => sq_nonneg ‖w X μ‖)).mp hs X (Finset.mem_univ _)
    have h2 := (Finset.sum_eq_zero_iff_of_nonneg (fun μ _ =>
      sq_nonneg ‖w X μ‖)).mp h1 μ (Finset.mem_univ _)
    simpa using h2
  have hsurj := LinearMap.injective_iff_surjective.mp hinj
  intro v
  obtain ⟨w, hw⟩ := hsurj v
  exact ⟨Cadj β c w, hw⟩

/-- The constraint operator with a real kernel on real fields. -/
def CopR (β : G →+ F) (c : F → κ → ι → ℝ) (a : F → ι → ℝ) : G → κ → ℝ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- **The real constraint operator is onto** (take the real part of a complex preimage). -/
theorem CopR_surjective (β : G →+ F) (c : F → κ → ι → ℝ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ), c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR β c) := by
  intro w
  obtain ⟨a, ha⟩ := Cop_surjective β (fun r μ ν => (c r μ ν : ℂ)) sec hsec hpos hc₀
    (fun X μ => (w X μ : ℂ))
  refine ⟨fun y ν => (a y ν).re, ?_⟩
  funext X μ
  have h := congrFun (congrFun ha X) μ
  have h2 := congrArg Complex.re h
  simp only [Cop, Complex.re_sum, Complex.re_ofReal_mul, Complex.ofReal_re] at h2
  exact h2

end Onto

/-! ## §5 Gradients: `C ∇ = ∇ ∘ res` from a symbol identity -/

section Gradient

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- A translation-invariant "gradient" `(∇χ)_ν(y) = Σ_z d(z)_ν χ(y + z)`. -/
def grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ) (χ : H → ℂ) :
    H → τ → ℂ :=
  fun y ν => ∑ z, d z ν * χ (y + z)

/-- Its symbol `v(ψ)_ν = Σ_z d(z)_ν ψ(z)`. -/
def symv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ∑ z, d z ν * ψ z

theorem ftv_grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (χ : H → ℂ) (ψ : AddChar H ℂ) (ν : τ) :
    ftv (grad d χ) ψ ν = symv d ψ ν * ft χ ψ := by
  unfold ftv grad symv
  rw [ft_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun z _ => ?_
  rw [ft_const_mul, ft_translate]
  ring

omit [Fintype κ] in
/-- **Intertwining**: if `Q(ψ) v_F(ψ) = v_G(ψ ∘ β)` for every fine momentum, then
`C (∇_F χ) = ∇_G (χ ∘ β)` for every `χ` (命題 E の `C∇ = ∇res`). -/
theorem Cop_grad (β : G →+ F) (c : F → κ → ι → ℂ) (dF : F → ι → ℂ) (dG : G → κ → ℂ)
    (hsym : ∀ ψ μ, ∑ ν, sym c ψ μ ν * symv dF ψ ν = symv dG (res β ψ) μ) (χ : F → ℂ) :
    Cop β c (grad dF χ) = grad dG (fun X => χ (β X)) := by
  funext X μ
  have hcF : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have key : ∀ φ, ftv (Cop β c (grad dF χ)) φ μ = ftv (grad dG (fun X => χ (β X))) φ μ := by
    intro φ
    apply mul_left_cancel₀ hcF
    rw [alias_C, ftv_grad, mul_left_comm (Fintype.card F : ℂ), ft_sample,
      mul_left_comm (symv dG φ μ)]
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    split_ifs with h
    · have e : ∑ ν, sym c ψ μ ν * ftv (grad dF χ) ψ ν = symv dG φ μ * ft χ ψ := by
        simp_rw [ftv_grad, ← mul_assoc]
        rw [← Finset.sum_mul, hsym, h]
      rw [e]
    · simp
  exact congrFun (ft_injective (f := fun X => Cop β c (grad dF χ) X μ)
    (g := fun X => grad dG (fun X => χ (β X)) X μ) key) X

end Gradient

/-! ## §6 The torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X` -/

section Torus

instance neZero_two_mul (L : ℕ) [NeZero L] : NeZero (2 * L) :=
  ⟨by have := NeZero.ne L; omega⟩

/-- The doubling embedding `ℤ/L → ℤ/2L`, `x ↦ 2x`. -/
def dbl (L : ℕ) : ZMod L →+ ZMod (2 * L) :=
  ZMod.lift L ⟨zmultiplesHom (ZMod (2 * L)) 2, by
    rw [zmultiplesHom_apply, zsmul_eq_mul, Int.cast_natCast]
    have h := ZMod.natCast_self (2 * L)
    push_cast at h
    linear_combination h⟩

theorem dbl_intCast (L : ℕ) (x : ℤ) : dbl L (x : ZMod L) = 2 * (x : ZMod (2 * L)) := by
  unfold dbl
  rw [ZMod.lift_coe, zmultiplesHom_apply, zsmul_eq_mul]
  ring

/-- Coarse points of the torus: `X ↦ 2X` componentwise. -/
def betaT (d L : ℕ) : (Fin d → ZMod L) →+ (Fin d → ZMod (2 * L)) :=
  AddMonoidHom.compLeft (dbl L) (Fin d)

theorem card_fine (d L : ℕ) [NeZero L] :
    Fintype.card (Fin d → ZMod (2 * L)) = 2 ^ d * Fintype.card (Fin d → ZMod L) := by
  simp only [Fintype.card_fun, ZMod.card, Fintype.card_fin, mul_pow]

theorem dbl_injective (L : ℕ) [NeZero L] : Function.Injective (dbl L) := by
  rw [injective_iff_map_eq_zero]
  intro x hx
  have hx' : dbl L ((x.val : ℤ) : ZMod L) = 0 := by
    rwa [Int.cast_natCast, ZMod.natCast_zmod_val]
  rw [dbl_intCast] at hx'
  have h2 : ((2 * x.val : ℕ) : ZMod (2 * L)) = 0 := by push_cast; simpa using hx'
  rw [ZMod.natCast_eq_zero_iff] at h2
  have h3 : L ∣ x.val := Nat.dvd_of_mul_dvd_mul_left (by norm_num) h2
  have h4 : x.val = 0 := Nat.eq_zero_of_dvd_of_lt h3 (ZMod.val_lt x)
  exact (ZMod.val_eq_zero x).mp h4

theorem betaT_injective (d L : ℕ) [NeZero L] : Function.Injective (betaT d L) := by
  intro x y h
  funext μ
  exact dbl_injective L (congrFun h μ)

/-- **Exactly `2^d` aliases** on the torus: every coarse momentum has `2^d` fine momenta `ψ`
with `ψ ∘ β = φ` (the `k_η = p + πη`, `η ∈ {0,1}^d`). -/
theorem torus_card_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card = 2 ^ d := by
  have h := card_alias (betaT d L) (betaT_injective d L) φ
  rw [card_fine, Nat.cast_mul, mul_comm ((2 ^ d : ℕ) : ℂ) _] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have := mul_left_cancel₀ hG h
  exact_mod_cast this

/-- Every coarse momentum on the torus has a fine momentum above it (a section `sec` exists). -/
theorem torus_exists_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    ∃ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ, res (betaT d L) ψ = φ := by
  have h := torus_card_alias d L φ
  have hpos : 0 < (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card := by rw [h]; positivity
  obtain ⟨ψ, hψ⟩ := Finset.card_pos.mp hpos
  exact ⟨ψ, (Finset.mem_filter.mp hψ).2⟩

variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **(命題 E) the symbol of `C C†` on the torus**:
`(CC†w)^(φ) = 2^{-d} Σ_{ψ : ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`, the `2^d` aliases of `φ`. -/
theorem torus_CCadj (d L : ℕ) [NeZero L] (c : (Fin d → ZMod (2 * L)) → κ → ι → ℂ)
    (w : (Fin d → ZMod L) → κ → ℂ) (φ : AddChar (Fin d → ZMod L) ℂ) (μ : κ) :
    (2 ^ d : ℂ) * ftv (Cop (betaT d L) c (Cadj (betaT d L) c w)) φ μ =
      ∑ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ,
        if res (betaT d L) ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  have h := alias_CCadj (betaT d L) c w φ μ
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 :=
    Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  apply mul_left_cancel₀ hG
  rw [← h]
  ring

/-- **The constant of 命題 E on the four-dimensional torus**: the one-alias bound
`|Q(k_0)† v|² ≥ (121/1152)|v|²` (that is, `σ_min(Q(k_0)) ≥ 11√2/48`) gives
`‖C†w‖² ≥ (121/18432)‖w‖²` in real space. -/
theorem torus_Cadj_lower (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℂ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : (Fin 4 → ZMod L) → κ → ℂ) :
    121 / 18432 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2 := by
  have h := Cadj_lower (betaT 4 L) c sec hsec hc₀ w
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (0 : ℝ) < Fintype.card (Fin 4 → ZMod L) := Nat.cast_pos.mpr Fintype.card_pos
  have h' : (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (121 / 1152 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2) ≤
      (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (2 ^ 4 * ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2) := by
    calc _ = (Fintype.card (Fin 4 → ZMod L) : ℝ) * (121 / 1152) * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := by
            ring
      _ ≤ _ := h
      _ = _ := by ring
  have h'' := le_of_mul_le_mul_left h' hG
  linarith

/-- **The real constraint operator on the four-dimensional torus is onto** under the same
one-alias bound (the hypothesis `hsurj` of the tower theorems, for one stage). -/
theorem torus_CopR_surjective (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℝ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR (betaT 4 L) c) :=
  CopR_surjective (betaT 4 L) c sec hsec (by norm_num) hc₀

end Torus

/-! ## §7 The alias representation of the one-step map on the projection (S1(a)) -/

section AliasRep

open scoped InnerProductSpace

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
variable {Z : Type*} [Fintype Z]

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def Aop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Pq (Sg ζ (Cr ζ (Pr ζ (Nr ζ y))))

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)` (all factors symmetric). -/
def Atr (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Nr ζ (Pr ζ (Cr ζ (Sg ζ (Pq y))))

/-- The one-step map applied to the projection, `(𝓜P)(q) x = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ x`. -/
def MPop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (x : V) : V :=
  (1 / 16 : ℝ) • ∑ ζ, Aop Pq Pr Cr Sg Nr ζ (Pr ζ (Atr Pq Pr Cr Sg Nr ζ x))

omit [Fintype Z] in
theorem Aop_adjoint (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric) (ζ : Z) (x y : V) :
    ⟪x, Aop Pq Pr Cr Sg Nr ζ y⟫_ℝ = ⟪Atr Pq Pr Cr Sg Nr ζ x, y⟫_ℝ := by
  unfold Aop Atr
  rw [inner_smul_right, inner_smul_left, ← hPq, ← hSg, ← hCr, ← hPr, ← hNr]
  simp

/-- **S1(a)**: if `P(r_ζ)` is an orthogonal projection commuting with `N(r_ζ)` and
`w_ζ := C(r_ζ) S_ζ P(q) x` lies in the range of `P(r_ζ)` (S1(b)), then
`⟨x, (𝓜P)(q) x⟩ = ¼ Σ_ζ |N(r_ζ) w_ζ|²`. -/
theorem alias_rep (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x))) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ = (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 := by
  unfold MPop
  rw [inner_smul_right, inner_sum, Finset.mul_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [Aop_adjoint Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr]
  have hA : Atr Pq Pr Cr Sg Nr ζ x = (2 : ℝ) • Nr ζ (Cr ζ (Sg ζ (Pq x))) := by
    unfold Atr
    rw [horth]
  rw [hA, map_smul, hNP, horth, inner_smul_left, inner_smul_right, real_inner_self_eq_norm_sq]
  simp only [RCLike.conj_to_real]
  ring

/-- With `w_ζ ⊥ s(r_ζ)` and a bound per alias `|N(r_ζ) w_ζ|² ≤ Σ_c b(ζ)_c u_c²` on coordinates
of `u = P(q)x`, the coordinate bound `hrep` of `OneStepNorm.MP_le` follows with
`D_c = ¼ Σ_ζ b(ζ)_c`. -/
theorem alias_rep_le (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) {ι : Type*} [Fintype ι]
    (coord : V → ι → ℝ) (b : Z → ι → ℝ) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x)))
    (hb : ∀ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 ≤ ∑ c, b ζ c * coord (Pq x) c ^ 2) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ ≤ ∑ c, ((1 / 4) * ∑ ζ, b ζ c) * coord (Pq x) c ^ 2 := by
  rw [alias_rep Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr hNP x horth]
  calc (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2
      ≤ (1 / 4) * ∑ ζ, ∑ c, b ζ c * coord (Pq x) c ^ 2 := by
        gcongr with ζ
        exact hb ζ
    _ = _ := by
        rw [Finset.sum_comm, Finset.mul_sum]
        refine Finset.sum_congr rfl fun c _ => ?_
        rw [mul_assoc, Finset.sum_mul]

end AliasRep

end TorusFourier

end


-- ===== new part : HrepConcrete.part.lean =====
/-!
# The coordinate bound `hrep` for the concrete one-step map 

Coordinates `Fin 4 → ℝ`, `θ = q/4`, aliases `ζ : Fin 4 → Bool`, `r_ζ/2 = θ + [ζ]π/2`.
* `s(r_ζ)_ν = sin(r_ν/2)`, `x_ν = 4α sin²(r_ν/2) = s_ν²/2` (`α = 1/8`), `C(r_ζ) = diag cos(r_ν/2)`,
  `S_ζ = diag (−1)^{ζ_ν}`, `s(q)_ν = sin(q_ν/2) = sin(2θ_ν)`;
* `N(r) u = diag(π) u + ½ diag(s) 𝔅 diag(s) u` with `𝔅 = 1 − E` off the diagonal;
* `P(p) y = y − (⟨s(p), y⟩/|s(p)|²) s(p)`;
* the quadratic form of the one-step map on the projection,
  `Qf(x) = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`, `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`
  (this is `⟨x, (𝓜P)(q) x⟩` for `𝓜P = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ`).

Main results: `hrep_coord` `Qf(x) ≤ Σ_c D_c(σ) (P(q)x)_c²` with `σ_ν = sin²θ_ν` and the
alias coefficients `D_c`, `Dal_le` `D_c ≤ 429/512`, and `MP_coord_le`
`Qf(x) ≤ (429/512) ⟨x, P(q) x⟩` for every `θ` and `x` (no hypotheses).
-/

noncomputable section

namespace OneStepHrep

open Finset OneStepNorm
open scoped Real

/-! ## Coordinates -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

/-- The orthogonal projection onto `s^⊥` (the identity when `s = 0`). -/
def proj (s y : Fin 4 → ℝ) : Fin 4 → ℝ := fun i => y i - (dot s y / dot s s) * s i

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem dot_proj (s y : Fin 4 → ℝ) : dot s (proj s y) = 0 := by
  by_cases h : dot s s = 0
  · have hs : ∀ i, s i = 0 := by
      intro i
      have h' : ∑ j, s j * s j = 0 := h
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' i
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    unfold dot
    simp [hs]
  · have e : dot s (proj s y) = dot s y - (dot s y / dot s s) * dot s s := by
      unfold proj
      conv_lhs => unfold dot
      simp only [mul_sub, Finset.sum_sub_distrib]
      congr 1
      unfold dot
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      ring
    rw [e]
    field_simp
    ring

theorem proj_of_dot {s y : Fin 4 → ℝ} (h : dot s y = 0) : proj s y = y := by
  funext i; simp [proj, h]

theorem dot_proj_self (s y : Fin 4 → ℝ) : dot (proj s y) (proj s y) = dot y (proj s y) := by
  have h := dot_proj s y
  set p := proj s y with hp_def
  set a := dot s y / dot s s with ha_def
  have hp : ∀ i, p i = y i - a * s i := fun i => rfl
  have e : dot p p = dot y p - a * dot s p := by
    unfold dot
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [show p i * p i = (y i - a * s i) * p i by rw [← hp i]]
    ring
  rw [e, h, mul_zero, sub_zero]

/-! ## The concrete symbols -/

def phi (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := θ ν + (if ζ ν then π / 2 else 0)
def sR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.sin (phi θ ζ ν)
def cR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.cos (phi θ ζ ν)
def sg (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := if ζ ν then -1 else 1
def sQ (θ : Fin 4 → ℝ) (ν : Fin 4) : ℝ := Real.sin (2 * θ ν)

/-- `x = 4α s² = s²/2` (`α = 1/8`). -/
def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

/-- `π_μ = Π_{ν≠μ} (1 − x_ν)`. -/
def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

/-- `E_{μν} = Ef(x_ρ, x_σ)` with `{ρ, σ}` the complement of `{μ, ν}`; zero on the diagonal. -/
def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

/-- `A_ζᵀ x = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q) x`. -/
def Atr (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  fun μ => 2 * Nm (sR θ ζ)
    (proj (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) μ

/-- The quadratic form `⟨x, (𝓜P)(q) x⟩ = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`. -/
def Qf (θ x : Fin 4 → ℝ) : ℝ :=
  (1 / 16) * ∑ ζ : Fin 4 → Bool, dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x))

/-! ## Properties of `N` -/

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

/-- `N` is symmetric. -/
theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

/-- `N s = s` (the leg identity `Σ_{ν≠μ} x_ν 𝔅_{μν} = 1 − π_μ`). -/
theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- `N` preserves `s^⊥`. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-! ## The square bound for one alias (S2 with the concrete `π`, `E`) -/

/-- The per-direction coefficient `(1+t)(π_c − x_c)² + (1+1/t) η_c`, with direction `c` first. -/
def coefT (t xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + t) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 + (1 + 1 / t) * eta xc x1 x2 x3

theorem EF_nonneg {x : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ EF x μ ν := by
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_nonneg (hx _) (hx _)

theorem Nm_eq_Nap (s u : Fin 4 → ℝ) (μ : Fin 4) :
    Nm s u μ = Nap (piF (xs s)) (fun ν => Real.sqrt (1 / 2) * s ν) (EF (xs s)) u μ := by
  have hc : Real.sqrt (1 / 2) * Real.sqrt (1 / 2) = 1 / 2 :=
    Real.mul_self_sqrt (by norm_num)
  unfold Nm Nap
  have e : ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (Real.sqrt (1 / 2) * s ν * u ν) =
      Real.sqrt (1 / 2) * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    ring
  rw [e]
  have : Real.sqrt (1 / 2) * s μ * (Real.sqrt (1 / 2) *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)) =
      (Real.sqrt (1 / 2) * Real.sqrt (1 / 2)) * s μ *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by ring
  rw [this, hc]

set_option maxRecDepth 8000 in
/-- **One alias**: for `w ⊥ s` and `x = s²/2 ∈ [0, 1/2]`,
`|N w|² ≤ Σ_c coef_c(x) w_c²` (directions `c` first, the others in increasing order). -/
theorem normSq_alias (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefT (3 / 10) (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefT (3 / 10) (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefT (3 / 10) (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefT (3 / 10) (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3 / 10)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefT, eta, rhoP, Ef, Matrix.cons_val]
  ring

/-! ## The alias values and the sum over aliases -/

theorem xs_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    xs (sR θ ζ) ν = xa (Real.sin (θ ν) ^ 2) (ζ ν) := by
  rw [← alias_x]
  unfold xs sR phi
  ring

theorem w_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (u : Fin 4 → ℝ) (ν : Fin 4) :
    (cR θ ζ ν * sg ζ ν * u ν) ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := by
  rw [← alias_w]
  unfold cR sg phi
  split_ifs <;> ring

theorem sum_bool4 (F : (Fin 4 → Bool) → ℝ) :
    ∑ ζ, F ζ = ∑ b0, ∑ b1, ∑ b2, ∑ b3, F ![b0, b1, b2, b3] := by
  let e : (Fin 4 → Bool) ≃ Bool × Bool × Bool × Bool :=
    { toFun := fun ζ => (ζ 0, ζ 1, ζ 2, ζ 3)
      invFun := fun b => ![b.1, b.2.1, b.2.2.1, b.2.2.2]
      left_inv := fun ζ => by funext i; fin_cases i <;> rfl
      right_inv := fun b => rfl }
  rw [← e.symm.sum_comp]
  simp only [Fintype.sum_prod_type]
  rfl

/-- The alias coefficients `D_c(σ) = ¼ Σ_ζ cos²(r_{ζ,c}/2) coef_c(x(r_ζ))`. -/
def Dal (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefT (3 / 10) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefT (3 / 10) (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefT (3 / 10) (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefT (3 / 10) (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

/-- **`D_c ≤ 429/512`** on the box `σ ∈ [0,1]⁴` (from `alias_coeff_le`, S3–S6). -/
theorem Dal_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    Dal σ c ≤ 429 / 512 := by
  fin_cases c
  · exact alias_coeff_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact alias_coeff_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-! ## The coordinate bound -/

/-- One alias in full: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4|N(r_ζ) w_ζ|²` and the square bound. -/
theorem alias_term_le (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefT (3 / 10) (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  -- S1(b): `w ⊥ s(r_ζ)`
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

/-- **`hrep` in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ Σ_c D_c(σ) (P(q)x)_c²`, `σ_ν = sin²(q_ν/4)`. -/
theorem hrep_coord (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, Dal, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ (429/512) ⟨x, P(q) x⟩` for every
`q` and `x` (the coordinate form of `M P ≼ (429/512) P`, no hypotheses). -/
theorem MP_coord_le (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (429 / 512) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (429 / 512) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (Dal_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end OneStepHrep

end

-- ===== new part : Bridge.part.lean =====
/-!
# The concrete one-step map `𝓜` on families over `EuclideanSpace ℝ (Fin 4)` and the hypotheses
`hM`, `hPstep`, `hPs`, `hPP` of `UniformBracket.bracket_numeric`

`Q` is any index type of momenta with a coordinate map `th : Q → (Fin 4 → ℝ)` (`th q = q/4`) and
alias maps `rq : Q → (Fin 4 → Bool) → Q` with `th (rq q ζ) = th q / 2 + ζ π/4` (`r_ζ = (q+2πζ)/2`).
`(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`, `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`.
-/

noncomputable section

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

abbrev V := EuclideanSpace ℝ (Fin 4)

/-! ## Matrices for the coordinate maps -/

def projM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun i j => (if i = j then 1 else 0) - s i * s j / dot s s

def NM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun μ ν =>
    if μ = ν then piF (xs s) μ else (1 / 2) * s μ * (1 - EF (xs s) μ ν) * s ν

theorem toE_apply (B : Matrix (Fin 4) (Fin 4) ℝ) (v : V) :
    Matrix.toEuclideanLin B v = WithLp.toLp 2 (B *ᵥ WithLp.ofLp v) := rfl

theorem diag_mulVec (d v : Fin 4 → ℝ) : Matrix.diagonal d *ᵥ v = fun i => d i * v i :=
  funext (Matrix.mulVec_diagonal d v)

theorem projM_mulVec (s y : Fin 4 → ℝ) : projM s *ᵥ y = proj s y := by
  funext i
  simp only [projM, Matrix.mulVec, dotProduct, Matrix.of_apply, sub_mul, Finset.sum_sub_distrib,
    ite_mul, one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true, proj, dot]
  congr 1
  rw [div_mul_eq_mul_div, Finset.sum_mul, Finset.sum_div]
  refine Finset.sum_congr rfl fun j _ => ?_
  ring

theorem NM_mulVec (s u : Fin 4 → ℝ) : NM s *ᵥ u = Nm s u := by
  funext μ
  simp only [NM, Matrix.mulVec, dotProduct, Matrix.of_apply, Nm]
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ μ), if_pos rfl, Finset.mul_sum]
  congr 1
  refine Finset.sum_congr rfl fun ν hν => ?_
  rw [if_neg (Finset.ne_of_mem_erase hν).symm]
  ring

theorem projM_transpose (s : Fin 4 → ℝ) : (projM s)ᵀ = projM s := by
  ext i j
  simp only [projM, Matrix.transpose_apply, Matrix.of_apply]
  rw [mul_comm (s j) (s i)]
  by_cases h : i = j
  · subst h; rfl
  · rw [if_neg h, if_neg (Ne.symm h)]

theorem NM_transpose (s : Fin 4 → ℝ) : (NM s)ᵀ = NM s := by
  ext i j
  simp only [NM, Matrix.transpose_apply, Matrix.of_apply]
  fin_cases i <;> fin_cases j <;> simp [EF] <;> ring

/-! ## The alias data -/

/-- `θ(r_ζ) = θ/2 + ζ π/4`. -/
def thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Fin 4 → ℝ :=
  fun ν => θ ν / 2 + (if ζ ν then π / 4 else 0)

theorem sQ_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : sQ (thR θ ζ) = sR θ ζ := by
  funext ν
  unfold sQ thR sR phi
  congr 1
  split_ifs <;> ring

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`. -/
def AtM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (NM (sR θ ζ) * projM (sR θ ζ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) *
    projM (sQ θ))

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (projM (sQ θ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) * projM (sR θ ζ) *
    NM (sR θ ζ))

theorem AM_transpose (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : (AM θ ζ)ᵀ = AtM θ ζ := by
  unfold AM AtM
  rw [Matrix.transpose_smul]
  simp only [Matrix.transpose_mul, projM_transpose, NM_transpose, Matrix.diagonal_transpose,
    Matrix.mul_assoc]

theorem AtM_mulVec (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : AtM θ ζ *ᵥ x = Atr θ ζ x := by
  unfold AtM Atr
  rw [Matrix.smul_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [projM_mulVec, diag_mulVec, NM_mulVec]
  funext μ
  simp only [Pi.smul_apply, smul_eq_mul]

/-! ## Inner products in coordinates -/

theorem inner_coord (x y : V) : ⟪x, y⟫ = dot (WithLp.ofLp x) (WithLp.ofLp y) := by
  rw [EuclideanSpace.inner_eq_star_dotProduct]
  unfold dot dotProduct
  simp only [star_trivial]
  exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem inner_toE (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (x y : V) :
    ⟪x, Matrix.toEuclideanLin B y⟫ = ⟪Matrix.toEuclideanLin Bt x, y⟫ := by
  rw [inner_coord, inner_coord, toE_apply, toE_apply,
    WithLp.ofLp_toLp, WithLp.ofLp_toLp, ← hB]
  unfold dot
  have h := Matrix.dotProduct_mulVec (WithLp.ofLp x) B (WithLp.ofLp y)
  rw [← Matrix.mulVec_transpose] at h
  exact h

/-! ## The family map -/

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The projection family `P(q)`. -/
def Pfam (q : Q) : V →ₗ[ℝ] V := Matrix.toEuclideanLin (projM (sQ (th q)))

/-- **The concrete one-step map** `(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`. -/
def Mfam : (Q → V →ₗ[ℝ] V) →ₗ[ℝ] (Q → V →ₗ[ℝ] V) where
  toFun G q := (1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool,
    Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)
  map_add' G H := by
    funext q
    simp only [Pi.add_apply, LinearMap.add_comp, LinearMap.comp_add, Finset.sum_add_distrib,
      smul_add]
  map_smul' c G := by
    funext q
    simp only [Pi.smul_apply, RingHom.id_apply, LinearMap.smul_comp, LinearMap.comp_smul,
      ← Finset.smul_sum, smul_comm c (1 / 16 : ℝ)]

theorem Mfam_inner (G : Q → V →ₗ[ℝ] V) (q : Q) (x : V) :
    ⟪x, Mfam th rq G q x⟫ = (1 / 16) * ∑ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
  show ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x⟫ = _
  rw [LinearMap.smul_apply, real_inner_smul_right, LinearMap.sum_apply, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  exact inner_toE _ _ (AM_transpose (th q) ζ) _ _

/-- **`hM`: the concrete `𝓜` preserves the Loewner order of families.** -/
theorem Mfam_orderPreserving : UniformBracket.OrderPreserving (Mfam th rq) := by
  intro A B hAB q x
  rw [Mfam_inner, Mfam_inner]
  gcongr with ζ
  exact hAB _ _

/-- **`hPs`**: `P(q)` is symmetric. -/
theorem Pfam_symm (q : Q) : (Pfam th q).IsSymmetric := by
  intro x y
  unfold Pfam
  rw [real_inner_comm, inner_toE _ _ (projM_transpose _) y x, real_inner_comm]

/-- **`hPP`**: `P(q)` is idempotent. -/
theorem Pfam_idem (q : Q) (x : V) : Pfam th q (Pfam th q x) = Pfam th q x := by
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp,
    projM_mulVec, projM_mulVec, proj_of_dot (dot_proj _ _)]

/-- `⟨x, (𝓜P)(q) x⟩ = Qf(x)` (the quadratic form bounded in `OneStepHrep`). -/
theorem Mfam_P_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (x : V) :
    ⟪x, Mfam th rq (Pfam th) q x⟫ = Qf (th q) (WithLp.ofLp x) := by
  rw [Mfam_inner]
  unfold Qf
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp,
    WithLp.ofLp_toLp, AtM_mulVec, projM_mulVec]

/-- **`hPstep` for the concrete `𝓜`**: `𝓜 P ≼ (429/512) P` (no hypotheses beyond the alias maps). -/
theorem Mfam_P_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((429 / 512 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact MP_coord_le (th q) (WithLp.ofLp x)

/-- `429/512 ≤ 0.838` (the `hlam` of `bracket_numeric`). -/
theorem lam_le : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-- The model index set `Q = ℝ⁴` (`θ = q/4`) with `r_ζ` as alias maps. -/
theorem Mfam_P_le_R4 :
    UniformBracket.Lw (Mfam (fun θ : Fin 4 → ℝ => θ) thR (Pfam fun θ => θ))
      ((429 / 512 : ℝ) • Pfam fun θ : Fin 4 → ℝ => θ) :=
  Mfam_P_le (fun θ => θ) thR (fun _ _ => rfl)

end OneStepBridge

end

-- ===== new part : ETBridge.part.lean =====
/-!
# `‖N‖ ≤ 1`, the step `𝓜(P/ω) ≼ P/ω + (15/8) P` (`e_T ≤ 15/8`), and `bracket_numeric` for the
concrete `𝓜`

* `IminusN_form`, `IplusN_form`: `⟨u, (I ∓ N)u⟩` as sums of squares (Lemma 2(b) of and its
  `+` companion), so `−I ≼ N ≼ I`; `Nm_normSq_le`: `|N u|² ≤ |u|²` from these two without the
  spectral theorem (`2(|u|² − |Nu|²) = ⟨v,(I−N)v⟩ + ⟨w,(I+N)w⟩`, `v = u + Nu`, `w = u − Nu`).
* `eT_alias`: for `σ ∈ [0,1]⁴` with `ω(q) > 0`, `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`
  (the alias nearest to the origin `ζ*` plays the role of `ζ = 0`, so no box for `q` is needed).
* `Mfam_B_le`: `𝓜(P/ω) ≼ P/ω + (15/8) P` (the hypothesis `hBstep`).
* `bracket_concrete`: `UniformBracket.bracket_numeric` for the concrete `𝓜`, `P`, `ω`; the
  remaining hypotheses are the lower side `hlow`, symmetry `hsym` and the inverse `H`.
-/

noncomputable section

namespace OneStepET

open Finset OneStepNorm OneStepHrep OneStepBridge Matrix
open scoped Real RealInnerProductSpace

/-! ## Bilinearity of `dot` and linearity of `N` -/

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (b + c) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.add_apply]; ring

theorem dot_sub_right (a b c : Fin 4 → ℝ) : dot a (b - c) = dot a b - dot a c := by
  unfold dot; rw [← Finset.sum_sub_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.sub_apply]; ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (a + b) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_sub_left (a b c : Fin 4 → ℝ) : dot (a - b) c = dot a c - dot b c := by
  rw [dot_comm, dot_sub_right, dot_comm c a, dot_comm c b]

theorem Nm_add (s u v : Fin 4 → ℝ) : Nm s (u + v) = Nm s u + Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_add]

theorem Nm_sub (s u v : Fin 4 → ℝ) : Nm s (u - v) = Nm s u - Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_sub]

/-! ## `−I ≼ N ≼ I` and `|N u| ≤ |u|` -/

/-- `𝔅_{μν} = 1 − E_{μν}`. -/
def BF (s : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := 1 - EF (xs s) μ ν

set_option maxRecDepth 8000 in
/-- **Lemma 2(b)**: `⟨u, (I − N)u⟩ = ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ − s_μ u_ν)²`. -/
theorem IminusN_form (s u : Fin 4 → ℝ) :
    dot u u - dot u (Nm s u) =
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

set_option maxRecDepth 8000 in
/-- `⟨u, (I + N)u⟩ = 2 Σ_μ π_μ u_μ² + ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ + s_μ u_ν)²`. -/
theorem IplusN_form (s u : Fin 4 → ℝ) :
    dot u u + dot u (Nm s u) = 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 +
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem Ef_le_one {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) :
    Ef y z ≤ 1 := by
  have := Ef_le hy.1 hz.1
  linarith [hy.2, hz.2]

theorem BF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ BF s μ ν := by
  unfold BF
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_le_one (hx _) (hx _)

theorem piF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ : Fin 4) :
    0 ≤ piF (xs s) μ := by
  have h0 : 0 ≤ 1 - xs s 0 := by linarith [(hx 0).2]
  have h1 : 0 ≤ 1 - xs s 1 := by linarith [(hx 1).2]
  have h2 : 0 ≤ 1 - xs s 2 := by linarith [(hx 2).2]
  have h3 : 0 ≤ 1 - xs s 3 := by linarith [(hx 3).2]
  fin_cases μ <;> simp [piF] <;> positivity

theorem IminusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot u (Nm s u) ≤ dot u u := by
  have h := IminusN_form s u
  have : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

theorem IplusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : -dot u u ≤ dot u (Nm s u) := by
  have h := IplusN_form s u
  have h1 : 0 ≤ 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => mul_nonneg (piF_nonneg hx μ) (sq_nonneg _)
  have h2 : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

/-- **`‖N‖ ≤ 1`** (Lemma 2(c), `ν ≤ 1`): `|N u|² ≤ |u|²`. -/
theorem Nm_normSq_le {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot (Nm s u) (Nm s u) ≤ dot u u := by
  set A := Nm s u with hA
  set AA := Nm s A with hAA
  have h1 := IminusN_nonneg hx (u + A)
  have h2 := IplusN_nonneg hx (u - A)
  rw [Nm_add, Nm_sub] at *
  rw [← hA, ← hAA] at h1 h2
  simp only [dot_add_left, dot_add_right, dot_sub_left, dot_sub_right] at h1 h2
  have s1 : dot u AA = dot A A := by rw [hAA, Nm_symm]
  have s2 : dot A u = dot u A := dot_comm _ _
  have s3 : dot AA u = dot A A := by rw [dot_comm, s1]
  have s4 : dot AA A = dot A AA := dot_comm _ _
  linarith

/-! ## The scalar step `e_T ≤ 15/8` with the nearest alias -/

/-- `ω(r_ζ) = Σ_ν 8 x_ν(r_ζ)`. -/
def omR (σ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : ℝ := ∑ ν, 8 * xa (σ ν) (ζ ν)

/-- `ω(q) = Σ_ν 16 σ_ν (1 − σ_ν)`. -/
def omQ (σ : Fin 4 → ℝ) : ℝ := ∑ ν, 16 * (σ ν * (1 - σ ν))

/-- The alias nearest to the origin. -/
def zstar (σ : Fin 4 → ℝ) : Fin 4 → Bool := fun ν => decide (1 / 2 < σ ν)

theorem xa_far {σ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} (ν : Fin 4)
    (h : ζ ν ≠ zstar σ ν) : 1 / 4 ≤ xa (σ ν) (ζ ν) := by
  unfold zstar at h
  by_cases hs : 1 / 2 < σ ν
  · have : ζ ν = false := by
      cases hz : ζ ν
      · rfl
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
    rw [this]; simp only [xa]; linarith
  · have : ζ ν = true := by
      cases hz : ζ ν
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
      · rfl
    have hs' : σ ν ≤ 1 / 2 := le_of_not_gt hs
    rw [this]; simp only [xa]; linarith

theorem omR_far {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) {ζ : Fin 4 → Bool}
    (h : ζ ≠ zstar σ) : 2 ≤ omR σ ζ := by
  obtain ⟨ν, hν⟩ : ∃ ν, ζ ν ≠ zstar σ ν := by
    by_contra hc
    exact h (funext fun ν => by by_contra h'; exact hc ⟨ν, h'⟩)
  have hf := xa_far ν hν
  unfold omR
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ ν)]
  have : 0 ≤ ∑ x ∈ univ.erase ν, 8 * xa (σ x) (ζ x) :=
    Finset.sum_nonneg fun x _ => by
      have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
  linarith

theorem omR_near {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) :
    omQ σ ≤ 4 * omR σ (zstar σ) := by
  unfold omQ omR
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  unfold zstar
  have h0 := (hσ ν).1
  have h1 := (hσ ν).2
  by_cases hs : 1 / 2 < σ ν
  · simp only [hs, decide_true, xa]; nlinarith
  · simp only [hs, decide_false, xa]; nlinarith

theorem wa_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ wa σ b ∧ wa σ b ≤ 1 := by
  cases b <;> simp only [wa] <;> constructor <;> linarith

/-- **The alias sum of `e_T`**: `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`. -/
theorem eT_alias {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (hω : 0 < omQ σ) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omQ σ)⁻¹ + 15 / 8 := by
  have hnear := omR_near hσ
  have hpos : 0 < omR σ (zstar σ) := by linarith
  have hF : ∀ ζ, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omR σ ζ)⁻¹ := by
    intro ζ
    have hw := wa_le (hσ μ).1 (hσ μ).2 (ζ μ)
    have : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    nlinarith
  have hstar : (omR σ (zstar σ))⁻¹ ≤ 4 * (omQ σ)⁻¹ := by
    rw [inv_le_comm₀ hpos (by positivity), mul_inv, inv_inv]
    calc 4⁻¹ * omQ σ ≤ 4⁻¹ * (4 * omR σ (zstar σ)) := by gcongr
      _ = omR σ (zstar σ) := by ring
  have hfar : ∀ ζ ∈ (univ : Finset (Fin 4 → Bool)).erase (zstar σ),
      wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ 1 / 2 := by
    intro ζ hζ
    have h2 := omR_far hσ (Finset.ne_of_mem_erase hζ)
    have : (omR σ ζ)⁻¹ ≤ 1 / 2 := by
      rw [inv_le_comm₀ (by linarith) (by norm_num)]; norm_num; linarith
    exact (hF ζ).trans this
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ (zstar σ))]
  have hsum := Finset.sum_le_sum hfar
  have hcard : ((univ : Finset (Fin 4 → Bool)).erase (zstar σ)).card = 15 := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, Fintype.card_fun,
      Fintype.card_bool, Fintype.card_fin]
    rfl
  rw [Finset.sum_const, hcard, nsmul_eq_mul] at hsum
  have h0 := (hF (zstar σ)).trans hstar
  push_cast at hsum
  linarith

/-! ## The step `𝓜(P/ω) ≼ P/ω + (15/8) P` -/

/-- `ω(q) = Σ_ν 4 sin²(q_ν/2)` from the coordinate `θ = q/4`. -/
def omF {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : ℝ := ∑ ν, 4 * sQ (th q) ν ^ 2

theorem omF_eq {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) :
    omF th q = omQ (fun ν => Real.sin (th q ν) ^ 2) := by
  unfold omF omQ sQ
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [omega_dir]; ring

theorem omF_alias {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool) :
    omF th (rq q ζ) = omR (fun ν => Real.sin (th q ν) ^ 2) ζ := by
  unfold omF omR
  rw [hrq, sQ_thR]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [← xs_alias]; unfold xs; ring

theorem omF_le {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : omF th q ≤ 16 := by
  unfold omF sQ
  rw [Fin.sum_univ_four]
  have h0 := Real.sin_sq_le_one (2 * th q 0)
  have h1 := Real.sin_sq_le_one (2 * th q 1)
  have h2 := Real.sin_sq_le_one (2 * th q 2)
  have h3 := Real.sin_sq_le_one (2 * th q 3)
  linarith

/-- One alias, as an equality: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4 |N(r_ζ) w_ζ|²`. -/
theorem alias_term_eq (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) =
      4 * dot (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν))
        (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) := by
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [proj_of_dot hw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun μ _ => by ring

/-- One alias, the `e_T` bound: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_one (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have h := Nm_normSq_le hx (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
  have e : dot (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
      (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν) =
      ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  rw [e] at h
  linarith

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hBstep` for the concrete `𝓜`**: `𝓜(P/ω) ≼ P/ω + (15/8) P` (where `ω > 0`). -/
theorem Mfam_B_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_one (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 ≤
      ∑ μ, ((omQ σ)⁻¹ + 15 / 8) * u μ ^ 2 :=
    Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right (eT_alias hσ hω' μ) (sq_nonneg _)
  have hRHS : ⟪x, ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) q x⟫ =
      ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by
    simp only [Pi.add_apply, Pi.smul_apply, LinearMap.add_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
    ring
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-! ## `bracket_numeric` for the concrete `𝓜` -/

/-- **The bracket for the concrete one-step map**: with `ω(q) = Σ 4 sin²(q_ν/2) > 0` on `Q` and the
alias maps, every hypothesis of `UniformBracket.bracket_numeric` about `𝓜`, `P`, `ω`, `λ`, `e`
and `G₀ = P/ω` is discharged; what remains is the lower side `hlow`, the symmetry `hsym` of the
stages and the inverse `H` on the range of `P`. -/
theorem bracket_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
    (hsym : ∀ k q, ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric)
    {H : ℕ → Q → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q (H k q x) =
      Pfam th q x)
    (hHP : ∀ k q x, Pfam th q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : V) :
    omF th q / 745 * ⟪x, Pfam th q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF th q * ⟪x, Pfam th q x⟫ :=
  UniformBracket.bracket_numeric (Mfam th rq) (Mfam_orderPreserving th rq) (Pfam_symm th)
    (Pfam_idem th) hω (omF_le th) (by norm_num : (0 : ℝ) ≤ 429 / 512) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl hσ ha (Mfam_P_le th rq hrq) (Mfam_B_le th rq hrq hω)
    (UniformBracket.Lw.refl _) hlow hsym hH hHP k q x

end OneStepET

end

-- ===== new part : Final.part.lean =====
/-!
# The symmetry of the stages and the index set `ω > 0`

* `Mfam_symm`, `iterate_symm`: `𝓜` maps symmetric families to symmetric families, so every stage
  `G_k = 𝓜^k(P/ω)` is symmetric (the hypothesis `hsym`).
* `Qpos`: the momenta with `ω(q) > 0` (`q ∉ 2πℤ⁴`), closed under the aliases `q ↦ r_ζ`
  (`s(q)_ν = ±2 sin(r_ν/2) cos(r_ν/2)`), and `bracket_Qpos`: the bracket with the remaining
  hypotheses `hlow`, `hH`, `hHP` only.
-/

noncomputable section

namespace OneStepFinal

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem term_symm (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (G : V →ₗ[ℝ] V)
    (hG : G.IsSymmetric) (x y : V) :
    ⟪(Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) x, y⟫ =
      ⟪x, (Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) y⟫ := by
  simp only [LinearMap.comp_apply]
  rw [real_inner_comm, inner_toE B Bt hB, inner_toE B Bt hB x, ← hG]
  exact real_inner_comm _ _

/-- `𝓜` preserves symmetric families. -/
theorem Mfam_symm (G : Q → V →ₗ[ℝ] V) (hG : ∀ r, (G r).IsSymmetric) (q : Q) :
    (Mfam th rq G q).IsSymmetric := by
  intro x y
  show ⟪((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x, y⟫ =
    ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y⟫
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    LinearMap.sum_apply, LinearMap.sum_apply, sum_inner, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  exact term_symm _ _ (AM_transpose (th q) ζ) _ (hG _) x y

theorem smul_symm {T : V →ₗ[ℝ] V} (hT : T.IsSymmetric) (c : ℝ) : (c • T).IsSymmetric := by
  intro x y
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    hT]

/-- **`hsym`**: every stage `𝓜^k(P/ω)` is symmetric. -/
theorem iterate_symm (k : ℕ) (q : Q) :
    ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric := by
  induction k generalizing q with
  | zero => exact smul_symm (Pfam_symm th q) _
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact Mfam_symm th rq _ ih q

/-! ## The momenta with `ω > 0` -/

/-- Momenta `q = 4θ` with `ω(q) > 0`. -/
abbrev Qpos : Type := {θ : Fin 4 → ℝ // 0 < ∑ ν, 4 * sQ θ ν ^ 2}

theorem sQ_eq_zero_of_sR {θ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} {ν : Fin 4}
    (h : sR θ ζ ν = 0) : sQ θ ν = 0 := by
  unfold sR phi at h
  unfold sQ
  rw [Real.sin_two_mul]
  cases hz : ζ ν
  · rw [hz] at h; simp at h; rw [h]; ring
  · rw [hz] at h; simp [Real.sin_add_pi_div_two] at h; rw [h]; ring

theorem pos_alias {θ : Fin 4 → ℝ} (hθ : 0 < ∑ ν, 4 * sQ θ ν ^ 2) (ζ : Fin 4 → Bool) :
    0 < ∑ ν, 4 * sQ (thR θ ζ) ν ^ 2 := by
  rw [sQ_thR]
  by_contra hc
  have hle : ∑ ν, 4 * sR θ ζ ν ^ 2 ≤ 0 := le_of_not_gt hc
  have h0 : ∀ ν, sR θ ζ ν = 0 := by
    intro ν
    have hs := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => by positivity)).mp
      (le_antisymm hle (Finset.sum_nonneg fun i _ => by positivity)) ν (Finset.mem_univ _)
    have : sR θ ζ ν ^ 2 = 0 := by linarith
    exact pow_eq_zero_iff (n := 2) (by norm_num) |>.mp this
  have : ∑ ν, 4 * sQ θ ν ^ 2 = 0 := by
    refine Finset.sum_eq_zero fun ν _ => ?_
    rw [sQ_eq_zero_of_sR (h0 ν)]; ring
  linarith

/-- The aliases on `Qpos`. -/
def rqPos (q : Qpos) (ζ : Fin 4 → Bool) : Qpos := ⟨thR q.1 ζ, pos_alias q.2 ζ⟩

/-- **The bracket on `Qpos` for the concrete `𝓜`**: everything is discharged except the lower
side `hlow` and the inverse `H` on the range of `P`. -/
theorem bracket_Qpos {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)))
    {H : ℕ → Qpos → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) = Pfam Subtype.val q x)
    (hHP : ∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) (k : ℕ) (q : Qpos) (x : V) :
    omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_concrete Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) hσ ha hlow
    (iterate_symm Subtype.val rqPos) hH hHP k q x

/-! ## The inverse on the range of `P` from the lower side -/

/-- In finite dimension, a lower bound `c ⟨x, Px⟩ ≤ ⟨x, Gx⟩` (`c > 0`) with `ran G ⊆ ran P`
gives `H` with `G H = P` and `P H = H` (the inverse of `G` on `ran P`). -/
theorem exists_inv_on_range {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] (P G : E →ₗ[ℝ] E) (hPP : ∀ x, P (P x) = P x)
    (hPG : ∀ x, P (G x) = G x) {c : ℝ} (hc : 0 < c) (hlow : ∀ x, c * ⟪x, P x⟫ ≤ ⟪x, G x⟫) :
    ∃ H : E →ₗ[ℝ] E, (∀ x, G (H x) = P x) ∧ (∀ x, P (H x) = H x) := by
  set W := LinearMap.range P
  have hGW : ∀ w ∈ W, G w ∈ W := fun w _ => ⟨G w, hPG w⟩
  let GW : W →ₗ[ℝ] W := G.restrict hGW
  have hinj : Function.Injective GW := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    obtain ⟨y, hy⟩ := w.2
    have h0 : G (w : E) = 0 := congrArg Subtype.val hw
    have hPw : P (w : E) = w := by rw [← hy, hPP]
    have h1 := hlow (w : E)
    rw [h0, inner_zero_right, hPw, real_inner_self_eq_norm_sq] at h1
    have h2 : ‖(w : E)‖ ^ 2 ≤ 0 := by
      by_contra hne
      have : 0 < ‖(w : E)‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos hc this
      linarith
    have h3 : ‖(w : E)‖ = 0 := by nlinarith [norm_nonneg (w : E)]
    exact Subtype.ext (norm_eq_zero.mp h3)
  let e := LinearEquiv.ofInjectiveEndo GW hinj
  refine ⟨W.subtype ∘ₗ (e.symm : W →ₗ[ℝ] W) ∘ₗ P.rangeRestrict, ?_, ?_⟩
  · intro x
    exact congrArg Subtype.val (e.apply_symm_apply (P.rangeRestrict x))
  · intro x
    obtain ⟨y, hy⟩ := (e.symm (P.rangeRestrict x)).2
    show P ((e.symm (P.rangeRestrict x) : W) : E) = ((e.symm (P.rangeRestrict x) : W) : E)
    rw [← hy, hPP]

theorem projM_AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (w : Fin 4 → ℝ) :
    projM (sQ θ) *ᵥ (AM θ ζ *ᵥ w) = AM θ ζ *ᵥ w := by
  unfold AM
  simp only [Matrix.smul_mulVec, Matrix.mulVec_smul, ← Matrix.mulVec_mulVec, projM_mulVec]
  rw [proj_of_dot (dot_proj _ _)]

/-- `ran (𝓜G)(q) ⊆ ran P(q)`. -/
theorem Pfam_Mfam (G : Q → V →ₗ[ℝ] V) (q : Q) (y : V) :
    Pfam th q (Mfam th rq G q y) = Mfam th rq G q y := by
  show Pfam th q (((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y) =
    ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y
  rw [LinearMap.smul_apply, map_smul, LinearMap.sum_apply, map_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp, projM_AM]

/-- Every stage has range in `ran P`. -/
theorem iterate_P (k : ℕ) (q : Q) (y : V) :
    Pfam th q ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y) =
      (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y := by
  cases k with
  | zero =>
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, map_smul, Pfam_idem]
  | succ k =>
    rw [Function.iterate_succ_apply']
    exact Pfam_Mfam th rq _ q y

/-- **The bracket on `Qpos` with the lower side as the only hypothesis**: the inverses `H_k` on
`ran P` exist, and `(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage. -/
theorem bracket_Qpos_low {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  have hex : ∀ k (q : Qpos), ∃ H : V →ₗ[ℝ] V,
      (∀ x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H x) = Pfam Subtype.val q x) ∧
      (∀ x, Pfam Subtype.val q (H x) = H x) := by
    intro k q
    have hω : 0 < omF Subtype.val q := q.2
    refine exists_inv_on_range (Pfam Subtype.val q) _ (Pfam_idem Subtype.val q)
      (iterate_P Subtype.val rqPos k q) (mul_pos ha0 (inv_pos.mpr hω)) fun x => ?_
    have h := hlow k q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h
    linarith
  choose H hH hHP using hex
  exact ⟨H, hH, hHP, fun k q x => bracket_Qpos hσ ha hlow hH hHP k q x⟩

end OneStepFinal

end


-- ===== new part : LowerSide.part.lean =====
/-!
# The lower side `hlow` of Theorem 1 without the box 

For every stage `k` and every momentum `q` with `ω(q) > 0` (no box `q ∈ [−π, π]⁴`):
`G_k(q) = 𝓜^k(P/ω)(q) ≽ a P(q)/ω(q)` with `a = (4/π²)·0.04452²`.

The argument keeps one alias per stage, the alias `ζ*` nearest to the origin
(`ζ*_ν = 1` exactly when `sin²(q_ν/4) > 1/2`), and uses three facts:
* the scale: if `sin²(q_ν/2) ≤ sin²(β)` (`β = π/2^{m+1}`) for all `ν`, then at `r = r_{ζ*}`
  `sin²(r_ν/2) ≤ sin²(β/2)` (`alias_scale`);
* one alias from below: with `w = C(r) S_ζ P(q) x ⊥ s(r)`, `|N(r) w| ≥ n(ξ)|w|` (`Nm_lower`,
  `Nm_sq_lower`) and `|w|² ≥ (1 − b)|P(q)x|²`; the ratio `ω(q) ≥ 4(1 − b) ω(r)` (`omega_ratio`);
* the potentials `τ_m = (2Γ_m/π)⁴ ν_m` with `Γ_m = 2^m sin(π/2^{m+1})`, telescoping exactly in
  the cosine factors (`Gam_rec`, Viète), and `ν_m` absorbing the factors `n(ξ_{m+1})²`.
-/

noncomputable section

namespace OneStepLower

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. `N` on `s^⊥` from below -/

/-- `n(ξ) = (1 − ξ)³ − ξ − ξ²/2 − ξ³` (Lemma 2(e)). -/
def nlow (ξ : ℝ) : ℝ := (1 - ξ) ^ 3 - ξ - ξ ^ 2 / 2 - ξ ^ 3

/-- The multiplier of `⟨s, u⟩` in the identity `Nm_form_perp`. -/
def Lmul (s u : Fin 4 → ℝ) : ℝ :=
  (s 0 ^ 3 * u 0 - s 0 ^ 2 * s 1 * u 1 - s 0 ^ 2 * s 2 * u 2 - s 0 ^ 2 * s 3 * u 3
    - s 0 * s 1 ^ 2 * u 0 - s 0 * s 2 ^ 2 * u 0 - s 0 * s 3 ^ 2 * u 0 + 4 * s 0 * u 0
    + s 1 ^ 3 * u 1 - s 1 ^ 2 * s 2 * u 2 - s 1 ^ 2 * s 3 * u 3 - s 1 * s 2 ^ 2 * u 1
    - s 1 * s 3 ^ 2 * u 1 + 4 * s 1 * u 1 + s 2 ^ 3 * u 2 - s 2 ^ 2 * s 3 * u 3
    - s 2 * s 3 ^ 2 * u 2 + 4 * s 2 * u 2 + s 3 ^ 3 * u 3 + 4 * s 3 * u 3) / 8

/-- The diagonal coefficient `d_μ = π_μ − x_μ(1 + x_μ − X/2)`. -/
def dco (x : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF x μ - x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2)

/-- The cubic remainder `Σ_{μ<ν} x_ρ x_σ s_μ s_ν u_μ u_ν`. -/
def Rem (s u : Fin 4 → ℝ) : ℝ :=
  xs s 2 * xs s 3 * (s 0 * s 1 * u 0 * u 1) + xs s 1 * xs s 3 * (s 0 * s 2 * u 0 * u 2)
  + xs s 1 * xs s 2 * (s 0 * s 3 * u 0 * u 3) + xs s 0 * xs s 3 * (s 1 * s 2 * u 1 * u 2)
  + xs s 0 * xs s 2 * (s 1 * s 3 * u 1 * u 3) + xs s 0 * xs s 1 * (s 2 * s 3 * u 2 * u 3)

set_option maxRecDepth 8000 in
/-- **The identity of Lemma 2(e)**: `⟨u, N u⟩ = Σ d_μ u_μ² + ⅓ Rem + ⟨s, u⟩ L`. -/
theorem Nm_form_perp (s u : Fin 4 → ℝ) :
    dot u (Nm s u) = ∑ μ, dco (xs s) μ * u μ ^ 2 + (1 / 3) * Rem s u + dot s u * Lmul s u := by
  unfold dot Nm dco Rem Lmul
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem prod3_lower {a b c ξ : ℝ} (ha : 0 ≤ a ∧ a ≤ ξ) (hb : 0 ≤ b ∧ b ≤ ξ)
    (hc : 0 ≤ c ∧ c ≤ ξ) (hξ : ξ ≤ 1) : (1 - ξ) ^ 3 ≤ (1 - a) * (1 - b) * (1 - c) := by
  have h1 : 0 ≤ 1 - ξ := by linarith
  have h2 : 1 - ξ ≤ 1 - a := by linarith
  have h3 : 1 - ξ ≤ 1 - b := by linarith
  have h4 : 1 - ξ ≤ 1 - c := by linarith
  have hab : (1 - ξ) * (1 - ξ) ≤ (1 - a) * (1 - b) := mul_le_mul h2 h3 h1 (by linarith)
  have hab0 : 0 ≤ (1 - a) * (1 - b) := mul_nonneg (by linarith) (by linarith)
  calc (1 - ξ) ^ 3 = (1 - ξ) * (1 - ξ) * (1 - ξ) := by ring
    _ ≤ (1 - a) * (1 - b) * (1 - c) := mul_le_mul hab h4 h1 hab0

theorem piF_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : (1 - ξ) ^ 3 ≤ piF x μ := by
  fin_cases μ
  · exact prod3_lower (hx 1) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 2) hξ

theorem dco_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : nlow ξ + ξ ^ 3 ≤ dco x μ := by
  have hp := piF_lower hx hξ μ
  have hX : x μ ≤ x 0 + x 1 + x 2 + x 3 := by
    have h0 := hx 0; have h1 := hx 1; have h2 := hx 2; have h3 := hx 3
    fin_cases μ <;> simp <;> linarith
  have hm := hx μ
  have hprod : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ ξ + ξ ^ 2 / 2 := by
    have e1 : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ x μ * (1 + x μ / 2) :=
      mul_le_mul_of_nonneg_left (by linarith) hm.1
    have e2 : x μ * (1 + x μ / 2) ≤ ξ * (1 + ξ / 2) := by nlinarith
    nlinarith
  unfold dco nlow
  nlinarith

/-- One pair of the remainder: `0 ≤ ξ³(a² + b²) + p · s_a s_b a b` for `0 ≤ p ≤ ξ²`,
`s_a², s_b² ≤ 2ξ`. -/
theorem pair_nonneg {a b sa sb p ξ : ℝ} (hp0 : 0 ≤ p) (hp : p ≤ ξ ^ 2) (hξ : 0 ≤ ξ)
    (ha : sa ^ 2 ≤ 2 * ξ) (hb : sb ^ 2 ≤ 2 * ξ) :
    0 ≤ ξ ^ 3 * (a ^ 2 + b ^ 2) + p * (sa * sb * a * b) := by
  have h1 : 0 ≤ (sa * b + sb * a) ^ 2 := sq_nonneg _
  have h2 : sa ^ 2 * b ^ 2 ≤ 2 * ξ * b ^ 2 := mul_le_mul_of_nonneg_right ha (sq_nonneg b)
  have h3 : sb ^ 2 * a ^ 2 ≤ 2 * ξ * a ^ 2 := mul_le_mul_of_nonneg_right hb (sq_nonneg a)
  have hz : -(ξ * (a ^ 2 + b ^ 2)) ≤ sa * sb * a * b := by nlinarith
  have h4 : p * (-(ξ * (a ^ 2 + b ^ 2))) ≤ p * (sa * sb * a * b) :=
    mul_le_mul_of_nonneg_left hz hp0
  have h5 : p * (ξ * (a ^ 2 + b ^ 2)) ≤ ξ ^ 2 * (ξ * (a ^ 2 + b ^ 2)) :=
    mul_le_mul_of_nonneg_right hp (by positivity)
  nlinarith

/-- **`N ≽ n(ξ)` on `s^⊥`** when every `x_ν = s_ν²/2 ≤ ξ ≤ 1`. -/
theorem Nm_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) : nlow ξ * dot w w ≤ dot w (Nm s w) := by
  have hx' : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ ξ := fun ν => ⟨by unfold xs; positivity, hx ν⟩
  have hs : ∀ ν, s ν ^ 2 ≤ 2 * ξ := fun ν => by have := hx ν; unfold xs at this; linarith
  have hp : ∀ μ ν, 0 ≤ xs s μ * xs s ν ∧ xs s μ * xs s ν ≤ ξ ^ 2 := fun μ ν =>
    ⟨mul_nonneg (hx' μ).1 (hx' ν).1, by
      have := hx' μ; have := hx' ν
      calc xs s μ * xs s ν ≤ ξ * ξ := mul_le_mul (hx' μ).2 (hx' ν).2 (hx' ν).1 hξ0
        _ = ξ ^ 2 := by ring⟩
  rw [Nm_form_perp, hw, zero_mul, add_zero]
  have p01 := pair_nonneg (a := w 0) (b := w 1) (hp 2 3).1 (hp 2 3).2 hξ0 (hs 0) (hs 1)
  have p02 := pair_nonneg (a := w 0) (b := w 2) (hp 1 3).1 (hp 1 3).2 hξ0 (hs 0) (hs 2)
  have p03 := pair_nonneg (a := w 0) (b := w 3) (hp 1 2).1 (hp 1 2).2 hξ0 (hs 0) (hs 3)
  have p12 := pair_nonneg (a := w 1) (b := w 2) (hp 0 3).1 (hp 0 3).2 hξ0 (hs 1) (hs 2)
  have p13 := pair_nonneg (a := w 1) (b := w 3) (hp 0 2).1 (hp 0 2).2 hξ0 (hs 1) (hs 3)
  have p23 := pair_nonneg (a := w 2) (b := w 3) (hp 0 1).1 (hp 0 1).2 hξ0 (hs 2) (hs 3)
  have d0 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 0) (sq_nonneg (w 0))
  have d1 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 1) (sq_nonneg (w 1))
  have d2 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 2) (sq_nonneg (w 2))
  have d3 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 3) (sq_nonneg (w 3))
  unfold dot Rem
  simp only [Fin.sum_univ_four]
  linarith

theorem dot_self_nonneg (a : Fin 4 → ℝ) : 0 ≤ dot a a := by
  unfold dot; exact Finset.sum_nonneg fun i _ => mul_self_nonneg (a i)

theorem dot_cs (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa only [sq] using h

/-- `|N w|² ≥ n(ξ)² |w|²` on `s^⊥` (Cauchy–Schwarz with `Nm_lower`). -/
theorem Nm_sq_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) (hn : 0 ≤ nlow ξ) :
    nlow ξ ^ 2 * dot w w ≤ dot (Nm s w) (Nm s w) := by
  have h1 := Nm_lower hξ0 hξ hx hw
  have hA := dot_self_nonneg w
  have hB := dot_self_nonneg (Nm s w)
  have hcs := dot_cs w (Nm s w)
  have hc0 : 0 ≤ nlow ξ * dot w w := mul_nonneg hn hA
  have hsq : (nlow ξ * dot w w) ^ 2 ≤ dot w (Nm s w) ^ 2 := pow_le_pow_left₀ hc0 h1 2
  rcases eq_or_lt_of_le hA with h0 | hpos
  · rw [← h0]; simpa using hB
  · have : dot w w * (nlow ξ ^ 2 * dot w w) ≤ dot w w * dot (Nm s w) (Nm s w) := by
      nlinarith
    exact le_of_mul_le_mul_left this hpos

/-! ## 2. The scale of the nearest alias -/

/-- `b_m = sin²(π/2^{m+1})`. -/
def bS (m : ℕ) : ℝ := Real.sin (π / 2 ^ (m + 1)) ^ 2

theorem ang_half (m : ℕ) : π / 2 ^ (m + 1 + 1) = (π / 2 ^ (m + 1)) / 2 := by
  rw [pow_succ 2 (m + 1), div_div]

theorem ang_pos (m : ℕ) : 0 < π / 2 ^ (m + 1) := by positivity

theorem ang_le (m : ℕ) : π / 2 ^ (m + 1) ≤ π / 2 := by
  have h2 : (2 : ℝ) ≤ 2 ^ (m + 1) := by
    calc (2 : ℝ) = 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (m + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith [Real.pi_pos]

theorem cos_ang_nonneg (m : ℕ) : 0 ≤ Real.cos (π / 2 ^ (m + 1)) :=
  Real.cos_nonneg_of_mem_Icc ⟨by linarith [ang_pos m, Real.pi_pos], ang_le m⟩

theorem bS_eq (m : ℕ) : bS m = 1 - Real.cos (π / 2 ^ (m + 1)) ^ 2 := by
  unfold bS; rw [Real.sin_sq]

theorem bS_succ (m : ℕ) : bS (m + 1) = (1 - Real.cos (π / 2 ^ (m + 1))) / 2 := by
  unfold bS
  rw [ang_half, Real.sin_sq, Real.cos_sq (π / 2 ^ (m + 1) / 2)]
  have : 2 * (π / 2 ^ (m + 1) / 2) = π / 2 ^ (m + 1) := by ring
  rw [this]; ring

theorem bS_zero : bS 0 = 1 := by
  unfold bS; norm_num

theorem bS_le_one (m : ℕ) : bS m ≤ 1 := Real.sin_sq_le_one _

theorem bS_nonneg (m : ℕ) : 0 ≤ bS m := sq_nonneg _

/-- **The scale of the nearest alias**: if `sin²(q_ν/2) ≤ b_m` for all `ν`, then
`sin²(r_ν/2) ≤ b_{m+1}` at `r = r_{ζ*}` (no box on `q`). -/
theorem alias_scale (θ : Fin 4 → ℝ) (m : ℕ) (h : ∀ ν, sQ θ ν ^ 2 ≤ bS m) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ bS (m + 1) := by
  have hσ := sigma_mem (θ ν)
  have hx := xs_alias θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν
  unfold xs at hx
  have hq := omega_dir (θ ν)
  have hc0 := cos_ang_nonneg m
  have hb := h ν
  rw [bS_eq] at hb
  rw [bS_succ]
  unfold sQ at hb
  set c := Real.cos (π / 2 ^ (m + 1))
  set σ := Real.sin (θ ν) ^ 2
  set t := sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2
  by_cases hs : 1 / 2 < σ
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = true := by
      simp only [zstar, decide_eq_true_eq]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = 1 - σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 2 * σ - 1)]
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = false := by
      simp only [zstar, decide_eq_false_iff_not]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    have hs' : σ ≤ 1 / 2 := le_of_not_gt hs
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 1 - 2 * σ)]

/-! ## 3. The potentials -/

/-- `Γ_m = 2^m sin(π/2^{m+1})` (`Γ_0 = 1`, increasing to `π/2`). -/
def Gam (m : ℕ) : ℝ := 2 ^ m * Real.sin (π / 2 ^ (m + 1))

/-- `κ_{m+1} = cos(π/2^{m+2})`. -/
def kap (m : ℕ) : ℝ := Real.cos (π / 2 ^ (m + 1 + 1))

theorem Gam_rec (m : ℕ) : Gam (m + 1) * kap m = Gam m := by
  unfold Gam kap
  have h := Real.sin_two_mul (π / 2 ^ (m + 1 + 1))
  have e : 2 * (π / 2 ^ (m + 1 + 1)) = π / 2 ^ (m + 1) := by rw [ang_half]; ring
  rw [e] at h
  rw [h, pow_succ]
  ring

theorem one_sub_bS (m : ℕ) : 1 - bS (m + 1) = kap m ^ 2 := by
  unfold bS kap
  have := Real.sin_sq_add_cos_sq (π / 2 ^ (m + 1 + 1))
  linarith

theorem Gam_nonneg (m : ℕ) : 0 ≤ Gam m := by
  unfold Gam
  apply mul_nonneg (by positivity)
  apply Real.sin_nonneg_of_nonneg_of_le_pi (ang_pos m).le
  linarith [ang_le m, Real.pi_pos]

theorem Gam_le (m : ℕ) : Gam m ≤ π / 2 := by
  unfold Gam
  have h := Real.sin_le (ang_pos m).le
  calc 2 ^ m * Real.sin (π / 2 ^ (m + 1)) ≤ 2 ^ m * (π / 2 ^ (m + 1)) :=
        mul_le_mul_of_nonneg_left h (by positivity)
    _ = π / 2 := by rw [pow_succ]; field_simp

theorem Gam_zero : Gam 0 = 1 := by
  unfold Gam; norm_num

/-- `ξ_2 = 3.1416²/128 ≥ sin²(π/8)/2`. -/
def xi2 : ℝ := (3927 / 1250) ^ 2 / 128

/-- The bound `ξ` for `x = sin²(r/2)/2` at the scale `m + 1`. -/
def xiB : ℕ → ℝ
  | 0 => 1 / 4
  | 1 => xi2
  | m + 2 => (π / 2 ^ (m + 4)) ^ 2 / 2

/-- The `N`-part of the potential. -/
def nuT : ℕ → ℝ
  | 0 => nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160))
  | 1 => nlow xi2 ^ 2 * (1 - 33 / 160)
  | m + 2 => 1 - 33 / 10 / (2 ^ (m + 2)) ^ 2

/-- The potential `τ_m = (2Γ_m/π)⁴ ν_m`. -/
def tau (m : ℕ) : ℝ := (2 * Gam m / π) ^ 4 * nuT m

theorem nlow_ge {ξ : ℝ} (_h0 : 0 ≤ ξ) (h1 : ξ ≤ 1) : 1 - 4 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg (sq_nonneg ξ) (by linarith : (0 : ℝ) ≤ 5 / 2 - 2 * ξ)]

theorem sin_sq_le_sq {y : ℝ} (h0 : 0 ≤ y) (h1 : y ≤ π) : Real.sin y ^ 2 ≤ y ^ 2 :=
  pow_le_pow_left₀ (Real.sin_nonneg_of_nonneg_of_le_pi h0 h1) (Real.sin_le h0) 2

theorem bS_half_le (m : ℕ) : bS (m + 1) / 2 ≤ xiB m := by
  match m with
  | 0 =>
    show Real.sin (π / 2 ^ (0 + 1 + 1)) ^ 2 / 2 ≤ 1 / 4
    have e : π / 2 ^ (0 + 1 + 1) = π / 4 := by norm_num
    rw [e, Real.sin_pi_div_four, div_pow, Real.sq_sqrt (by norm_num)]
    norm_num
  | 1 =>
    show Real.sin (π / 2 ^ (1 + 1 + 1)) ^ 2 / 2 ≤ xi2
    have e : π / 2 ^ (1 + 1 + 1) = π / 8 := by norm_num
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 8) (by linarith [Real.pi_pos])
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have : (π / 8) ^ 2 ≤ (3927 / 1250 / 8) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (by norm_num at hp ⊢; linarith) 2
    unfold xi2
    nlinarith
  | k + 2 =>
    show Real.sin (π / 2 ^ (k + 2 + 1 + 1)) ^ 2 / 2 ≤ (π / 2 ^ (k + 4)) ^ 2 / 2
    have e : k + 2 + 1 + 1 = k + 4 := by omega
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 2 ^ (k + 4))
      (by
        have : (1 : ℝ) ≤ 2 ^ (k + 4) := one_le_pow₀ (by norm_num)
        rw [div_le_iff₀ (by positivity)]
        nlinarith [Real.pi_pos])
    linarith

theorem xiB_nonneg (m : ℕ) : 0 ≤ xiB m := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 => simp only [xiB]; positivity

theorem xiB_le (m : ℕ) : xiB m ≤ 1 / 4 := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 =>
    simp only [xiB]
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have h16 : (16 : ℝ) ≤ 2 ^ (k + 4) := by
      calc (16 : ℝ) = 2 ^ 4 := by norm_num
        _ ≤ 2 ^ (k + 4) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h1 : π / 2 ^ (k + 4) ≤ 1 / 4 := by
      rw [div_le_iff₀ (by positivity)]; nlinarith
    have h2 : 0 ≤ π / 2 ^ (k + 4) := by positivity
    nlinarith

theorem nlow_xiB_nonneg (m : ℕ) : 0 ≤ nlow (xiB m) := by
  have := nlow_ge (xiB_nonneg m) (by linarith [xiB_le m])
  linarith [xiB_le m]

theorem nuT_step (m : ℕ) : nuT m ≤ nuT (m + 1) * nlow (xiB m) ^ 2 := by
  match m with
  | 0 => show nuT 0 ≤ nuT 1 * nlow (1 / 4) ^ 2; simp only [nuT]; nlinarith
  | 1 =>
    show nuT 1 ≤ nuT 2 * nlow xi2 ^ 2
    simp only [nuT]
    norm_num
    linarith
  | k + 2 =>
    show 1 - 33 / 10 / (2 ^ (k + 2)) ^ 2 ≤
      (1 - 33 / 10 / (2 ^ (k + 3)) ^ 2) * nlow ((π / 2 ^ (k + 4)) ^ 2 / 2) ^ 2
    set p : ℝ := 2 ^ (k + 2) with hp_def
    have hp4 : (4 : ℝ) ≤ p := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have e3 : (2 : ℝ) ^ (k + 3) = 2 * p := by rw [hp_def, pow_succ]; ring
    have e4 : (2 : ℝ) ^ (k + 4) = 4 * p := by
      rw [hp_def, show k + 4 = k + 2 + 2 by omega, pow_add]; ring
    rw [e3, e4]
    have hπ := Real.pi_lt_d4
    have hπ0 := Real.pi_pos
    have hπ2 : π ^ 2 < 9.87 := by nlinarith
    set e : ℝ := 1 / p ^ 2 with he_def
    have hp0 : 0 < p := by linarith
    have he0 : 0 < e := by positivity
    have he1 : e ≤ 1 / 16 := by
      rw [he_def, div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith
    have hξ : (π / (4 * p)) ^ 2 / 2 = π ^ 2 * e / 32 := by
      rw [he_def]; field_simp; ring
    rw [hξ]
    have hξ0 : 0 ≤ π ^ 2 * e / 32 := by positivity
    have hξ1 : π ^ 2 * e / 32 ≤ 1 := by nlinarith
    have hn := nlow_ge hξ0 hξ1
    have hn0 : 0 ≤ 1 - 4 * (π ^ 2 * e / 32) := by nlinarith
    have hn2 : (1 - 4 * (π ^ 2 * e / 32)) ^ 2 ≤ nlow (π ^ 2 * e / 32) ^ 2 :=
      pow_le_pow_left₀ hn0 hn 2
    have l1 : 33 / 10 / p ^ 2 = 33 / 10 * e := by rw [he_def]; ring
    have l2 : 33 / 10 / (2 * p) ^ 2 = 33 / 10 * e / 4 := by rw [he_def]; field_simp; ring
    rw [l1, l2]
    have hA : 0 ≤ 1 - 33 / 10 * e / 4 := by nlinarith
    have hstep : 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
      have h1 : 1 - 2 * (4 * (π ^ 2 * e / 32)) ≤ (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
        nlinarith [sq_nonneg (4 * (π ^ 2 * e / 32))]
      have h2 := mul_le_mul_of_nonneg_left h1 hA
      have h3 : π ^ 2 * e < 9.87 * e := mul_lt_mul_of_pos_right hπ2 he0
      have h4 : 0 ≤ e * e * π ^ 2 := mul_nonneg (mul_nonneg he0.le he0.le) (sq_nonneg π)
      nlinarith
    calc 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := hstep
      _ ≤ (1 - 33 / 10 * e / 4) * nlow (π ^ 2 * e / 32) ^ 2 :=
        mul_le_mul_of_nonneg_left hn2 hA

theorem nuT_bounds (m : ℕ) : 0 ≤ nuT m ∧ nuT m ≤ 1 := by
  match m with
  | 0 => simp only [nuT]; norm_num [nlow, xi2]
  | 1 => simp only [nuT]; norm_num [nlow, xi2]
  | k + 2 =>
    simp only [nuT]
    have h4 : (4 : ℝ) ≤ 2 ^ (k + 2) := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h16 : (16 : ℝ) ≤ (2 ^ (k + 2)) ^ 2 := by nlinarith
    have h0 : 0 ≤ 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 := by positivity
    have h1 : 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 ≤ 1 := by
      rw [div_le_one (by positivity)]; linarith
    constructor <;> linarith

theorem pref_bounds (m : ℕ) : 0 ≤ (2 * Gam m / π) ^ 4 ∧ (2 * Gam m / π) ^ 4 ≤ 1 := by
  have h0 : 0 ≤ 2 * Gam m / π := div_nonneg (by linarith [Gam_nonneg m]) Real.pi_pos.le
  have h1 : 2 * Gam m / π ≤ 1 := by
    rw [div_le_one Real.pi_pos]; linarith [Gam_le m]
  exact ⟨by positivity, pow_le_one₀ h0 h1⟩

theorem tau_nonneg (m : ℕ) : 0 ≤ tau m :=
  mul_nonneg (pref_bounds m).1 (nuT_bounds m).1

theorem tau_le_one (m : ℕ) : tau m ≤ 1 := by
  unfold tau
  have := pref_bounds m
  have := nuT_bounds m
  nlinarith

/-- **One stage of the potentials**: `τ_m ≤ τ_{m+1} n(ξ_{m+1})² (1 − b_{m+1})²`. -/
theorem tau_step (m : ℕ) :
    tau m ≤ tau (m + 1) * nlow (xiB m) ^ 2 * (1 - bS (m + 1)) ^ 2 := by
  unfold tau
  rw [one_sub_bS, ← Gam_rec m]
  have hs := nuT_step m
  have h0 : 0 ≤ (2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4 := by positivity
  calc (2 * (Gam (m + 1) * kap m) / π) ^ 4 * nuT m
      = ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * nuT m := by ring
    _ ≤ ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * (nuT (m + 1) * nlow (xiB m) ^ 2) :=
      mul_le_mul_of_nonneg_left hs h0
    _ = (2 * Gam (m + 1) / π) ^ 4 * nuT (m + 1) * nlow (xiB m) ^ 2 * (kap m ^ 2) ^ 2 := by ring

/-- `a = (4/π²)·0.04452² ≤ τ_0 = (2/π)⁴ ν_0`. -/
theorem a_le_tau : 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 ≤ tau 0 := by
  unfold tau
  rw [Gam_zero]
  have hν : nuT 0 = nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160)) := rfl
  have hν' : (0.0049 : ℝ) ≤ nuT 0 := by rw [hν]; norm_num [nlow, xi2]
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hp : 0 < π ^ 2 := by positivity
  have e : (2 * 1 / π) ^ 4 = 16 / (π ^ 2) ^ 2 := by field_simp; ring
  rw [e]
  rw [show 16 / (π ^ 2) ^ 2 * nuT 0 = (16 * nuT 0 / π ^ 2) / π ^ 2 by field_simp]
  rw [show 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 = (4 * 0.04452 ^ 2) / π ^ 2 by ring]
  apply div_le_div_of_nonneg_right _ hp.le
  rw [le_div_iff₀ hp]
  nlinarith

/-! ## 4. One alias from below and the ratio of `ω` -/

theorem cR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    cR θ ζ ν ^ 2 = 1 - sR θ ζ ν ^ 2 := by
  unfold cR sR; rw [Real.cos_sq']

theorem sg_sq (ζ : Fin 4 → Bool) (ν : Fin 4) : sg ζ ν ^ 2 = 1 := by
  unfold sg; split_ifs <;> norm_num

theorem sQ_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * sR θ ζ ν ^ 2 * cR θ ζ ν ^ 2 := by
  unfold sQ sR cR phi
  cases ζ ν
  · simp only [Bool.false_eq_true, if_false, add_zero, Real.sin_two_mul]; ring
  · simp only [if_true, Real.sin_add_pi_div_two, Real.cos_add_pi_div_two, Real.sin_two_mul]; ring

/-- **One alias from below**: `4 n(ξ)² (1 − b) |P(q)x|² ≤ ⟨A_ζᵀx, P(r_ζ) A_ζᵀx⟩`
when `sin²(r_ν/2) ≤ b` for all `ν` and `b/2 ≤ ξ ≤ 1`, `n(ξ) ≥ 0`. -/
theorem one_alias_lower (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b ξ : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (hξ : b / 2 ≤ ξ) (hξ1 : ξ ≤ 1) (hn : 0 ≤ nlow ξ) :
    4 * nlow ξ ^ 2 * (1 - b) * dot (proj (sQ θ) x) (proj (sQ θ) x) ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb0 : 0 ≤ b := le_trans (sq_nonneg _) (hsR 0)
  have hξ0 : 0 ≤ ξ := by linarith
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ ξ := fun ν => by unfold xs; linarith [hsR ν]
  have hN := Nm_sq_lower hξ0 hξ1 hx hw hn
  have hww : (1 - b) * dot u u ≤ dot w w := by
    unfold dot
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have e : w ν * w ν = cR θ ζ ν ^ 2 * (u ν * u ν) := by
      rw [hw_def]
      have := sg_sq ζ ν
      calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
          = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * (u ν * u ν) := by ring
        _ = _ := by rw [this, mul_one]
    rw [e, cR_sq]
    exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)
  have hn2 : 0 ≤ nlow ξ ^ 2 := sq_nonneg _
  calc 4 * nlow ξ ^ 2 * (1 - b) * dot u u = 4 * (nlow ξ ^ 2 * ((1 - b) * dot u u)) := by ring
    _ ≤ 4 * (nlow ξ ^ 2 * dot w w) := by gcongr
    _ ≤ 4 * dot (Nm (sR θ ζ) w) (Nm (sR θ ζ) w) := by gcongr

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **The ratio of `ω`**: `4(1 − b) ω(r_ζ) ≤ ω(q)` when `sin²(r_ν/2) ≤ b`. -/
theorem omega_ratio (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    {b : ℝ} (hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ b) :
    4 * (1 - b) * omF th (rq q ζ) ≤ omF th q := by
  unfold omF
  rw [hrq, sQ_thR, Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  rw [sQ_sq_alias (th q) ζ ν, cR_sq]
  have h := hsR ν
  have h0 := sq_nonneg (sR (th q) ζ ν)
  nlinarith

theorem inner_P (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) := by
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, dot_proj_self]

theorem inner_P_nonneg (q : Q) (x : V) : 0 ≤ ⟪x, Pfam th q x⟫ := by
  rw [inner_P]; exact dot_self_nonneg _

theorem alias_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    (x : V) :
    ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        Pfam th (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ =
      dot (Atr (th q) ζ (WithLp.ofLp x)) (proj (sR (th q) ζ) (Atr (th q) ζ (WithLp.ofLp x))) := by
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
    projM_mulVec]

theorem scale_zero (q : Q) (ν : Fin 4) : sQ (th q) ν ^ 2 ≤ bS 0 := by
  rw [bS_zero]; exact Real.sin_sq_le_one _

/-! ## 5. The induction over the stages -/

/-- **The lower side at every scale**: for every stage `k`, scale `m` and momentum `q` with
`sin²(q_ν/2) ≤ b_m`, `τ_m P(q)/ω(q) ≼ G_k(q)`. -/
theorem lower_inv (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) : ∀ (m : ℕ) (q : Q), (∀ ν, sQ (th q) ν ^ 2 ≤ bS m) → ∀ x : V,
      tau m * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ := by
  induction k with
  | zero =>
    intro m q _ x
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
    have h1 := tau_le_one m
    have h0 := inner_P_nonneg th q x
    have hw := (inv_pos.mpr (hω q)).le
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw h0
    nlinarith
  | succ k ih =>
    intro m q hq x
    rw [Function.iterate_succ_apply', Mfam_inner]
    set G := (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) with hG
    set ζs := zstar fun ν => Real.sin (th q ν) ^ 2 with hζs
    set y := Matrix.toEuclideanLin (AtM (th q) ζs) x with hy
    have hnn : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
      intro ζ
      refine le_trans ?_ (ih 0 (rq q ζ) (scale_zero th (rq q ζ)) _)
      exact mul_nonneg (mul_nonneg (tau_nonneg 0) (inv_pos.mpr (hω _)).le)
        (inner_P_nonneg th _ _)
    have hsingle : ⟪y, G (rq q ζs) y⟫ ≤ ∑ ζ : Fin 4 → Bool,
        ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
      Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hnn ζ)
        (Finset.mem_univ ζs)
    have hscale : ∀ ν, sR (th q) ζs ν ^ 2 ≤ bS (m + 1) := alias_scale (th q) m hq
    have hq' : ∀ ν, sQ (th (rq q ζs)) ν ^ 2 ≤ bS (m + 1) := by
      rw [hrq, sQ_thR]; exact hscale
    have hIH := ih (m + 1) (rq q ζs) hq' y
    rw [hy, alias_inner th rq hrq q ζs x] at hIH
    rw [← hy] at hIH
    have hA := one_alias_lower (th q) (WithLp.ofLp x) ζs hscale (bS_half_le m)
      (by linarith [xiB_le m]) (nlow_xiB_nonneg m)
    have hωr := omega_ratio th rq hrq q ζs hscale
    have hτ := tau_step m
    rw [← inner_P th q x] at hA
    -- abbreviations
    set b := bS (m + 1)
    set n2 := nlow (xiB m) ^ 2
    set U := ⟪x, Pfam th q x⟫
    set Y := dot (Atr (th q) ζs (WithLp.ofLp x))
      (proj (sR (th q) ζs) (Atr (th q) ζs (WithLp.ofLp x)))
    set wq := (omF th q)⁻¹
    set wr := (omF th (rq q ζs))⁻¹
    have hU : 0 ≤ U := inner_P_nonneg th q x
    have hb1 : 0 ≤ 1 - b := by linarith [bS_le_one (m + 1)]
    have hτ' : 0 ≤ tau (m + 1) := tau_nonneg _
    have hn2 : 0 ≤ n2 := sq_nonneg _
    have hwq : 0 ≤ wq := (inv_pos.mpr (hω q)).le
    have hwr : 0 ≤ wr := (inv_pos.mpr (hω _)).le
    have e1 : omF th q * wq = 1 := mul_inv_cancel₀ (hω q).ne'
    have e2 : omF th (rq q ζs) * wr = 1 := mul_inv_cancel₀ (hω _).ne'
    have key : 4 * (1 - b) * wq ≤ wr := by
      calc 4 * (1 - b) * wq = 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) := by
            rw [show 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) =
              4 * (1 - b) * wq * (omF th (rq q ζs) * wr) by ring, e2, mul_one]
        _ ≤ omF th q * (wq * wr) := mul_le_mul_of_nonneg_right hωr (mul_nonneg hwq hwr)
        _ = wr := by rw [← mul_assoc, e1, one_mul]
    have hc : 0 ≤ tau (m + 1) * n2 * (1 - b) := mul_nonneg (mul_nonneg hτ' hn2) hb1
    calc tau m * wq * U ≤ (tau (m + 1) * n2 * (1 - b) ^ 2) * wq * U :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hτ hwq) hU
      _ = (tau (m + 1) * n2 * (1 - b)) * ((1 - b) * wq) * U := by ring
      _ ≤ (tau (m + 1) * n2 * (1 - b)) * (wr / 4) * U := by
          apply mul_le_mul_of_nonneg_right _ hU
          apply mul_le_mul_of_nonneg_left _ hc
          linarith
      _ = (1 / 16) * (tau (m + 1) * wr * (4 * n2 * (1 - b) * U)) := by ring
      _ ≤ (1 / 16) * (tau (m + 1) * wr * Y) := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact mul_le_mul_of_nonneg_left hA (mul_nonneg hτ' hwr)
      _ ≤ (1 / 16) * ⟪y, G (rq q ζs) y⟫ := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact hIH
      _ ≤ _ := mul_le_mul_of_nonneg_left hsingle (by norm_num)

/-- **`hlow` without the box**: `(4/π²)·0.04452² · P/ω ≼ 𝓜^k(P/ω)` for every stage `k`. -/
theorem lower_side (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) :
    UniformBracket.Lw ((4 / π ^ 2 * (0.04452 : ℝ) ^ 2) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  have h := lower_inv th rq hrq hω k 0 q (scale_zero th q) x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  have ha := a_le_tau
  have hP := inner_P_nonneg th q x
  have hw := (inv_pos.mpr (hω q)).le
  calc 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫)
      ≤ tau 0 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
        mul_le_mul_of_nonneg_right ha (mul_nonneg hw hP)
    _ = tau 0 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
    _ ≤ _ := h

/-! ## 6. Theorem 1 on `Qpos` without hypotheses -/

/-- **Theorem 1 (the uniform bracket of the stage actions) on every momentum with `ω > 0`**:
the inverses `H_k` of `G_k = 𝓜^k(P/ω)` on `ran P` exist and
`(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage `k`, with no remaining hypothesis. -/
theorem bracket_Qpos_free :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_Qpos_low (σ := 0.04452) (a := 4 / π ^ 2 * (0.04452 : ℝ) ^ 2) le_rfl rfl
    (lower_side Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2))

end OneStepLower

end

-- ===== new part : CouplingLimit.part.lean =====
/-!
# (R3) The coupling coefficient `b_k → b_∞` from Theorem 1 

`b_k := Ξ(G_k)` with `G_k = 𝓜^k(P/ω)` (the physical stage covariance, `LatticeRec.rec_iterate`)
and `Ξ` Lipschitz relative to `P` on a set containing every `G_k`:
`−cP ≼ A − B ≼ cP  ⟹  |Ξ A − Ξ B| ≤ L c`  (`RelLip`).

* `coupling_limit` (abstract): if `M` preserves the order, `M P ≼ λ P` (`0 ≤ λ < 1`) and
  `−dP ≼ M G₀ − G₀ ≼ dP`, then `b_k = Ξ(M^k G₀)` converges to some `b_∞` with
  `|b_k − b_∞| ≤ L d λ^k/(1−λ)`, the bracket `b_∞ − Ld/(1−λ) ≤ b_k ≤ b_∞ + Ld/(1−λ)`,
  `Σ|b_k − b_∞|` summable with every partial sum `≤ L d/(1−λ)²`, hence the transient field
  `Σ_{k<n} max(−δ_k, 0) ≤ L d/(1−λ)²` of `CouplingStepsTransientE` (`δ_k = b_k − b_∞`).
* `D_lower` (the lower half of (R4)): `M(P/ω) − P/ω ≽ −2P` on `Qpos`; with `Mfam_B_le`
  (`≼ (15/8) P`) this gives `d = 2`.
* `coupling_converges`: the concrete statement for the family of Theorem 1 (`λ = 429/512`, `d = 2`).
* `quadLip`: every finite combination `Ξ(A) = Σ_i w_i ⟪v_i, A(q_i) v_i⟫` (on a finite torus,
  `(1/|Λ|) Σ_q tr(V(q) G(q))` is of this form) is `RelLip` with `L = Σ |w_i| ⟪v_i, P(q_i) v_i⟫`.
-/

noncomputable section

namespace CouplingLimit

open Finset Filter Topology UniformBracket
open scoped Real RealInnerProductSpace

section Abstract

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- `Ξ` is Lipschitz relative to `P` on `S` with constant `L`. -/
def RelLip (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (P : Q → E →ₗ[ℝ] E) (L : ℝ) (S : Set (Q → E →ₗ[ℝ] E)) :
    Prop :=
  ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c → Lw (-(c • P)) (A - B) → Lw (A - B) (c • P) →
    |Ξ A - Ξ B| ≤ L * c

theorem geom_partial_le {lam : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (n : ℕ) :
    ∑ k ∈ range n, lam ^ k ≤ 1 / (1 - lam) := by
  have h1 : 0 < 1 - lam := by linarith
  have e := geom_sum_mul lam n
  rw [le_div_iff₀ h1]
  have : (∑ k ∈ range n, lam ^ k) * (1 - lam) = 1 - lam ^ n := by linarith
  rw [this]
  have := pow_nonneg hlam0 n
  linarith

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The coupling coefficient converges geometrically** (abstract form). -/
theorem coupling_limit (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam d L : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hd : 0 ≤ d) (hL : 0 ≤ L)
    (hP : Lw (M P) (lam • P)) (hlo : Lw (-(d • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (d • P))
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (S : Set (Q → E →ₗ[ℝ] E)) (hS : ∀ k, (⇑M)^[k] G0 ∈ S)
    (hΞ : RelLip Ξ P L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d * lam ^ k / (1 - lam)) ∧
      (∀ k, binf - L * d / (1 - lam) ≤ Ξ ((⇑M)^[k] G0) ∧
        Ξ ((⇑M)^[k] G0) ≤ binf + L * d / (1 - lam)) ∧
      Summable (fun k => |Ξ ((⇑M)^[k] G0) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d / (1 - lam) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 ≤ L * d / (1 - lam) ^ 2) := by
  set b : ℕ → ℝ := fun k => Ξ ((⇑M)^[k] G0) with hb
  have h1 : 0 < 1 - lam := by linarith
  -- one step
  have hstep : ∀ k, dist (b k) (b (k + 1)) ≤ (L * d) * lam ^ k := by
    intro k
    obtain ⟨lo, hi⟩ := iterate_two_sided M hM hlam0 hd hP hlo hhi k
    have e : (⇑M)^[k] (M G0 - G0) = (⇑M)^[k + 1] G0 - (⇑M)^[k] G0 := by
      rw [iter_sub, Function.iterate_succ_apply]
    rw [e] at lo hi
    have hc : 0 ≤ d * lam ^ k := mul_nonneg hd (pow_nonneg hlam0 k)
    have := hΞ _ (hS (k + 1)) _ (hS k) _ hc lo hi
    rw [Real.dist_eq, abs_sub_comm]
    calc |b (k + 1) - b k| ≤ L * (d * lam ^ k) := this
      _ = L * d * lam ^ k := by ring
  have hcs : CauchySeq b := cauchySeq_of_le_geometric lam (L * d) hlam1 hstep
  obtain ⟨binf, hlim⟩ := cauchySeq_tendsto_of_complete hcs
  have hdist : ∀ k, |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := by
    intro k
    have := dist_le_of_le_geometric_of_tendsto lam (L * d) hlam1 hstep hlim k
    rwa [Real.dist_eq] at this
  have hLd : 0 ≤ L * d := mul_nonneg hL hd
  have hbr : ∀ k, |b k - binf| ≤ L * d / (1 - lam) := by
    intro k
    refine (hdist k).trans ?_
    rw [div_le_div_iff_of_pos_right h1]
    calc L * d * lam ^ k ≤ L * d * 1 := mul_le_mul_of_nonneg_left (pow_le_one₀ hlam0 hlam1.le) hLd
      _ = L * d := by ring
  have hsum : Summable (fun k => |b k - binf|) := by
    refine Summable.of_nonneg_of_le (fun k => abs_nonneg _) hdist ?_
    have := (summable_geometric_of_lt_one hlam0 hlam1).mul_left (L * d / (1 - lam))
    refine this.congr fun k => ?_
    ring
  have hpart : ∀ n, ∑ k ∈ range n, |b k - binf| ≤ L * d / (1 - lam) ^ 2 := by
    intro n
    calc ∑ k ∈ range n, |b k - binf| ≤ ∑ k ∈ range n, L * d / (1 - lam) * lam ^ k :=
          Finset.sum_le_sum fun k _ => by
            have := hdist k
            calc |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := this
              _ = L * d / (1 - lam) * lam ^ k := by ring
      _ = L * d / (1 - lam) * ∑ k ∈ range n, lam ^ k := by rw [Finset.mul_sum]
      _ ≤ L * d / (1 - lam) * (1 / (1 - lam)) :=
          mul_le_mul_of_nonneg_left (geom_partial_le hlam0 hlam1 n) (div_nonneg hLd h1.le)
      _ = L * d / (1 - lam) ^ 2 := by field_simp
  refine ⟨binf, hlim, hdist, fun k => ?_, hsum, hpart, fun n => ?_⟩
  · have := abs_le.mp (hbr k)
    constructor <;> linarith [this.1, this.2]
  · refine le_trans (Finset.sum_le_sum fun k _ => ?_) (hpart n)
    exact max_le (neg_le_abs _) (abs_nonneg _)

/-- A finite combination of quadratic-form evaluations is Lipschitz relative to `P` on all
families, with `L = Σ_i |w_i| ⟪v_i, P(q_i) v_i⟫`. -/
theorem quadLip {ι : Type*} (s : Finset ι) (w : ι → ℝ) (qs : ι → Q) (vs : ι → E)
    (P : Q → E →ₗ[ℝ] E) :
    RelLip (fun A => ∑ i ∈ s, w i * ⟪vs i, A (qs i) (vs i)⟫) P
      (∑ i ∈ s, |w i| * ⟪vs i, P (qs i) (vs i)⟫) Set.univ := by
  intro A _ B _ c hc lo hi
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
  have l := lo (qs i) (vs i)
  have h := hi (qs i) (vs i)
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.neg_apply,
    LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply, inner_neg_right,
    real_inner_smul_right] at l h
  rw [← mul_sub, abs_mul]
  have hab : |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫| ≤ c * ⟪vs i, P (qs i) (vs i)⟫ :=
    abs_le.mpr ⟨by linarith, by linarith⟩
  calc |w i| * |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫|
      ≤ |w i| * (c * ⟪vs i, P (qs i) (vs i)⟫) := mul_le_mul_of_nonneg_left hab (abs_nonneg _)
    _ = |w i| * ⟪vs i, P (qs i) (vs i)⟫ * c := by ring


/-- **With the sharp form (OS↑) the transient vanishes**: if `M G₀ ≼ G₀` and `Ξ` is monotone for
the Loewner order, then `b_k` decreases to its limit, so `δ_k = b_k − b_∞ ≥ 0` and every term
`max(−δ_k, 0)` of the transient field is `0` (`D₀ = 0`). -/
theorem transient_zero (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0)
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (hmono : ∀ A B, Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑M)^[k] G0) ∧ max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 = 0 := by
  have hanti : Antitone fun k => Ξ ((⇑M)^[k] G0) :=
    antitone_nat_of_succ_le fun n => hmono _ _ (iterate_antitone M hM h1 n)
  have hle : binf ≤ Ξ ((⇑M)^[k] G0) := hanti.le_of_tendsto hlim k
  exact ⟨hle, max_eq_right (by linarith)⟩

end Abstract

/-! ## The family of Theorem 1: `d = 2` -/

section Concrete

open OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower

/-- The alias nearest to the origin is at most half as far: `sin²(r*/2) ≤ ½ sin²(q/2)`. -/
theorem sR_zstar_le (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ sQ θ ν ^ 2 / 2 := by
  have hs := Real.sin_sq_add_cos_sq (θ ν)
  have hQ : sQ θ ν ^ 2 = 4 * Real.sin (θ ν) ^ 2 * Real.cos (θ ν) ^ 2 := by
    unfold sQ; rw [Real.sin_two_mul]; ring
  rw [hQ]
  unfold sR phi zstar
  by_cases h : 1 / 2 < Real.sin (θ ν) ^ 2
  · simp only [h, decide_true, if_true, Real.sin_add_pi_div_two]
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]
  · simp only [h, decide_false, Bool.false_eq_true, if_false, add_zero]
    replace h := le_of_not_gt h
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]

theorem nlow_ge {ξ : ℝ} (h0 : 0 ≤ ξ) (h1 : ξ ≤ 1 / 32) : 1 - 5 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0]

/-- The scalar inequality behind `D_lower`: `1 − n(b/2)²(1−b)² ≤ 16 b` for `0 ≤ b ≤ 1/16`. -/
theorem deficit_le {b : ℝ} (h0 : 0 ≤ b) (h1 : b ≤ 1 / 16) :
    1 - nlow (b / 2) ^ 2 * (1 - b) ^ 2 ≤ 16 * b := by
  have hn := nlow_ge (ξ := b / 2) (by linarith) (by linarith)
  have hn0 : 0 ≤ 1 - 5 * (b / 2) := by linarith
  have hsq : (1 - 5 * (b / 2)) ^ 2 ≤ nlow (b / 2) ^ 2 := pow_le_pow_left₀ hn0 hn 2
  have hb1 : 0 ≤ (1 - b) ^ 2 := sq_nonneg _
  have : (1 - 5 * (b / 2)) ^ 2 * (1 - b) ^ 2 ≤ nlow (b / 2) ^ 2 * (1 - b) ^ 2 :=
    mul_le_mul_of_nonneg_right hsq hb1
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0,
    mul_nonneg (mul_nonneg (mul_nonneg h0 h0) h0) h0]

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem inner_P_dot (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) :=
  inner_P th q x

/-- **(R4), lower half**: `𝓜(P/ω) − P/ω ≽ −2P`. -/
theorem D_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (-((2 : ℝ) • Pfam th))
      (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply,
    inner_neg_right, real_inner_smul_right, Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hP := inner_P_nonneg th q x
  have hωq := hω q
  set G0 : Q → V →ₗ[ℝ] V := fun q => (omF th q)⁻¹ • Pfam th q with hG0
  -- the terms of `𝓜 G0` are nonnegative
  have hterm : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
      G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
    intro ζ
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω _).le) (inner_P_nonneg th _ _)
  have hM := Mfam_inner th rq G0 q x
  have hG : ⟪x, G0 q x⟫ = (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
  by_cases hbig : 1 / 2 ≤ omF th q
  · -- far from the origin: `𝓜 G0 ≽ 0` and `G0 ≼ 2P`
    have h0 : 0 ≤ ⟪x, Mfam th rq G0 q x⟫ := by
      rw [hM]; exact mul_nonneg (by norm_num) (Finset.sum_nonneg fun ζ _ => hterm ζ)
    have h2 : (omF th q)⁻¹ ≤ 2 := by
      rw [inv_le_comm₀ hωq (by norm_num)]; linarith
    nlinarith [mul_le_mul_of_nonneg_right h2 hP]
  · -- near the origin: keep the alias `ζ*` only
    replace hbig := lt_of_not_ge hbig
    set ζ := zstar fun ν => Real.sin (th q ν) ^ 2
    set bb := omF th q / 8 with hbb
    have hb0 : 0 ≤ bb := by rw [hbb]; linarith
    have hb1 : bb ≤ 1 / 16 := by rw [hbb]; linarith
    have hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ bb := by
      intro ν
      refine (sR_zstar_le (th q) ν).trans ?_
      have hle : 4 * sQ (th q) ν ^ 2 ≤ omF th q := by
        unfold omF
        exact Finset.single_le_sum (f := fun ν => 4 * sQ (th q) ν ^ 2)
          (fun i _ => by positivity) (Finset.mem_univ ν)
      rw [hbb]; linarith
    have hn : 0 ≤ nlow (bb / 2) := by
      have := nlow_ge (ξ := bb / 2) (by linarith) (by linarith); linarith
    have h1 := one_alias_lower (th q) (WithLp.ofLp x) ζ hsR le_rfl (by linarith) hn
    rw [← alias_inner th rq hrq q ζ x] at h1
    have hrat := omega_ratio th rq hrq q ζ hsR
    have hωr := hω (rq q ζ)
    have hPx : ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x))
        (proj (sQ (th q)) (WithLp.ofLp x)) := inner_P th q x
    rw [← hPx] at h1
    -- one term of `𝓜 G0`
    set y := Matrix.toEuclideanLin (AtM (th q) ζ) x
    have hone : ⟪y, G0 (rq q ζ) y⟫ ≤ ⟪x, Mfam th rq G0 q x⟫ * 16 := by
      rw [hM]
      have := Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hterm ζ)
        (Finset.mem_univ ζ)
      linarith
    have hyG : ⟪y, G0 (rq q ζ) y⟫ = (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
      simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    -- `⟨y, P_r y⟩ / ω(r) ≥ 4 n² (1−b) |Px|² · 4(1−b)/ω(q)`
    have hb1' : 0 < 1 - bb := by linarith
    have hinv : 4 * (1 - bb) / omF th q ≤ (omF th (rq q ζ))⁻¹ := by
      rw [div_le_iff₀ hωq]
      calc 4 * (1 - bb) = (omF th (rq q ζ))⁻¹ * (4 * (1 - bb) * omF th (rq q ζ)) := by
            field_simp
        _ ≤ (omF th (rq q ζ))⁻¹ * omF th q :=
            mul_le_mul_of_nonneg_left hrat (inv_nonneg.mpr hωr.le)
    have hyP : 0 ≤ ⟪y, Pfam th (rq q ζ) y⟫ := inner_P_nonneg th _ _
    have hkey : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ ≤
        ⟪y, G0 (rq q ζ) y⟫ := by
      rw [hyG]
      calc nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫
          = (4 * (1 - bb) / omF th q) * (4 * nlow (bb / 2) ^ 2 * (1 - bb) * ⟪x, Pfam th q x⟫) := by
            ring
        _ ≤ (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
            apply mul_le_mul hinv h1
            · exact mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _)) hb1'.le) hP
            · exact inv_nonneg.mpr hωr.le
    have hdef := deficit_le hb0 hb1
    -- assemble: `⟨x,𝓜G0 x⟩ − ω⁻¹⟨x,Px⟩ ≥ −2⟨x,Px⟩`
    have hA : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, Mfam th rq G0 q x⟫ := by
      have : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ =
          16 * (nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫) := by
        field_simp
      linarith
    have hB : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
        nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        2 * ⟪x, Pfam th q x⟫ := by
      have e : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
          nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ =
          (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
      rw [e]
      have h16 : (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ ≤ 2 := by
        rw [← div_eq_mul_inv, div_le_iff₀ hωq]
        have e16 : 16 * bb = 2 * omF th q := by rw [hbb]; ring
        linarith
      exact mul_le_mul_of_nonneg_right h16 hP
    linarith

/-- **(R4), upper half** from `Mfam_B_le`: `𝓜(P/ω) − P/ω ≼ 2P`. -/
theorem D_upper (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q)
      ((2 : ℝ) • Pfam th) := by
  intro q x
  have h := Mfam_B_le th rq hrq hω q x
  have hP := inner_P_nonneg th q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right] at h
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right]
  nlinarith

/-- **b_k → b_∞ for the family of Theorem 1** (`λ = 429/512`, `d = 2`): for any `Ξ` Lipschitz
relative to `P` (constant `L`) on a set containing all `G_k = 𝓜^k(P/ω)`. -/
theorem coupling_converges (Ξ : (Qpos → V →ₗ[ℝ] V) → ℝ) (S : Set (Qpos → V →ₗ[ℝ] V)) {L : ℝ}
    (hL : 0 ≤ L)
    (hS : ∀ k, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) ∈ S)
    (hΞ : RelLip Ξ (Pfam Subtype.val) L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (429 / 512 : ℝ) ^ k / (1 - 429 / 512)) ∧
      (∀ k, binf - L * 2 / (1 - 429 / 512) ≤ Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ∧
        Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
          (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ≤ binf + L * 2 / (1 - 429 / 512)) ∧
      Summable (fun k => |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 / (1 - 429 / 512) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 429 / 512) ^ 2) := by
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  exact coupling_limit (Mfam (Subtype.val : Qpos → _) rqPos) (Mfam_orderPreserving _ _)
    (by norm_num) (by norm_num) (by norm_num) hL (Mfam_P_le _ _ hrq)
    (D_lower _ _ hrq hω) (D_upper _ _ hrq hω) Ξ S hS hΞ

/-- The numerical constants: `2/(1 − 429/512) = 1024/83 < 12.4` and
`2/(1 − 429/512)² = 524288/6889 < 76.2`. -/
theorem consts : (2 : ℝ) / (1 - 429 / 512) = 1024 / 83 ∧
    (2 : ℝ) / (1 - 429 / 512) ^ 2 = 524288 / 6889 := by
  constructor <;> norm_num

end Concrete

end CouplingLimit

end



-- ===== new part : RowSplit.part.lean =====
/-! # L3(ii) (round two): `𝓜 P ≼ (3/5) P` by the row-wise Cauchy split

work-08. All1135 `OneStepNorm.comp_sq_le` splits every row `μ`
of `N u` with one common `t = 3/10`, giving `λ̄ = 429/512` (`OneStepBridge.Mfam_P_le`). Here row
`μ` is split with `t_μ = 3 x_μ` (`row_split`, no division by `x_μ`), the cross terms keep the exact
`E`, `ρ′` (no `η̄`), and the coefficient of `u_c²` is `coefK`. The alias sum is the polynomial `Gk`
of `y_ν = σ_ν(1 − σ_ν)` and `Gk ≤ 3/5` on `[0, 1/4]⁴` (affine in each transverse `y`, a concave
quadratic in `y_c` at each vertex; largest `0.5902`).
Main: **`MP_coord_le_row`** `Qf θ x ≤ (3/5) ⟨x, P x⟩` and **`Mfam_P_le_row`** `𝓜 P ≼ (3/5) P`
(the `hPstep` of the bracket with `λ̄′ = 3/5` in place of `429/512`).
The hypothesis `hrq` of `Mfam_P_le_row` is the defining equation of the alias maps of the family
(the same convention as All1135 `rqPos`, `thR`), not an assumption on the measure.
-/

noncomputable section

namespace RowSplit

open Finset OneStepNorm OneStepHrep
open scoped Real

/-! ## 1. The row split -/

/-- `(a − sS)² ≤ (1 + k s²) a² + (s² + 1/k) S²` (`k > 0`): the split with `t = k s²`. -/
theorem row_split (a s S : ℝ) {k : ℝ} (hk : 0 < k) :
    (a - s * S) ^ 2 ≤ (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 := by
  have h : 0 ≤ (k * s * a + S) ^ 2 / k := div_nonneg (sq_nonneg _) hk.le
  have e : (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 - (a - s * S) ^ 2 =
      (k * s * a + S) ^ 2 / k := by
    field_simp; ring
  linarith

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Row `μ` with `t_μ = k s̃_μ²`. -/
theorem comp_sq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
  rw [comp_identity pi st E u hu μ]
  have h := row_split ((pi μ - st μ ^ 2) * u μ) (st μ)
    (∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) hk
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ st μ ^ 2 + 1 / k := by positivity
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hcs hc
  linarith

theorem normSq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le_row pi st E u hu hE hk μ

end MatrixLevel

/-! ## 2. The coefficient and the polynomial bound -/

/-- The row-split coefficient of `u_c²` with `t_μ = 3 x_μ` (direction `c` first). -/
def coefK (xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + 3 * xc) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 +
    ((x1 + 1 / 3) * Ef x2 x3 * rhoP xc x2 x3 + (x2 + 1 / 3) * Ef x1 x3 * rhoP xc x1 x3 +
      (x3 + 1 / 3) * Ef x1 x2 * rhoP xc x1 x2)

/-- The alias sum as a polynomial in `y_c, y_1, y_2, y_3`. -/
def Gk (y0 y1 y2 y3 : ℝ) : ℝ :=
  (-3/2) * y0^2 + (-3/32) * y0 * y1 * y2 * y3 + (149/576) * y0 * y1 * y2 +
    (149/576) * y0 * y1 * y3 + (-899/1152) * y0 * y1 + (149/576) * y0 * y2 * y3 +
    (-899/1152) * y0 * y2 + (-899/1152) * y0 * y3 + (65/256) * y0 + (-1/32) * y1 * y2 * y3 +
    (31/576) * y1 * y2 + (31/576) * y1 * y3 + (-281/1152) * y1 + (31/576) * y2 * y3 +
    (-281/1152) * y2 + (-281/1152) * y3 + (445/768)

theorem aliasK_eq (σc σ1 σ2 σ3 : ℝ) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) =
      Gk (yv σc) (yv σ1) (yv σ2) (yv σ3) := by
  simp only [Fintype.sum_bool, xa, wa, coefK, Ef, rhoP, yv, Gk]
  ring

theorem yv_mem' {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ ∧ yv σ ≤ 1 / 4 := by
  unfold yv
  constructor
  · exact mul_nonneg h0 (by linarith)
  · nlinarith [sq_nonneg (σ - 1 / 2)]

theorem affine_le {f : ℝ → ℝ} {L y : ℝ} (hf : f y = (1 - 4 * y) * f 0 + 4 * y * f (1 / 4))
    (hy0 : 0 ≤ y) (hy1 : y ≤ 1 / 4) (h0 : f 0 ≤ L) (h1 : f (1 / 4) ≤ L) : f y ≤ L := by
  rw [hf]
  have ha : 0 ≤ 1 - 4 * y := by linarith
  have hb : 0 ≤ 4 * y := by linarith
  nlinarith [mul_le_mul_of_nonneg_left h0 ha, mul_le_mul_of_nonneg_left h1 hb]

theorem Gk_vertex {y0 : ℝ} (h0 : 0 ≤ y0) (h1 : y0 ≤ 1 / 4) (v1 v2 v3 : ℝ)
    (hv1 : v1 = 0 ∨ v1 = 1 / 4) (hv2 : v2 = 0 ∨ v2 = 1 / 4) (hv3 : v3 = 0 ∨ v3 = 1 / 4) :
    Gk y0 v1 v2 v3 ≤ 3 / 5 := by
  unfold Gk
  rcases hv1 with rfl | rfl <;> rcases hv2 with rfl | rfl <;> rcases hv3 with rfl | rfl <;>
    nlinarith [sq_nonneg (y0 - 65 / 768), sq_nonneg (y0 - 271 / 13824)]

theorem Gk_le {y0 y1 y2 y3 : ℝ} (h0 : 0 ≤ y0 ∧ y0 ≤ 1 / 4) (h1 : 0 ≤ y1 ∧ y1 ≤ 1 / 4)
    (h2 : 0 ≤ y2 ∧ y2 ≤ 1 / 4) (h3 : 0 ≤ y3 ∧ y3 ≤ 1 / 4) : Gk y0 y1 y2 y3 ≤ 3 / 5 := by
  have V := fun v1 v2 v3 hv1 hv2 hv3 => Gk_vertex h0.1 h0.2 v1 v2 v3 hv1 hv2 hv3
  have s3 : ∀ v1 v2, (v1 = 0 ∨ v1 = 1 / 4) → (v2 = 0 ∨ v2 = 1 / 4) → Gk y0 v1 v2 y3 ≤ 3 / 5 :=
    fun v1 v2 hv1 hv2 => affine_le (f := fun z => Gk y0 v1 v2 z) (by simp only [Gk]; ring)
      h3.1 h3.2 (V v1 v2 0 hv1 hv2 (Or.inl rfl)) (V v1 v2 (1 / 4) hv1 hv2 (Or.inr rfl))
  have s2 : ∀ v1, (v1 = 0 ∨ v1 = 1 / 4) → Gk y0 v1 y2 y3 ≤ 3 / 5 :=
    fun v1 hv1 => affine_le (f := fun z => Gk y0 v1 z y3) (by simp only [Gk]; ring)
      h2.1 h2.2 (s3 v1 0 hv1 (Or.inl rfl)) (s3 v1 (1 / 4) hv1 (Or.inr rfl))
  exact affine_le (f := fun z => Gk y0 z y2 y3) (by simp only [Gk]; ring)
    h1.1 h1.2 (s2 0 (Or.inl rfl)) (s2 (1 / 4) (Or.inr rfl))

theorem aliasK_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) ≤ 3 / 5 := by
  rw [aliasK_eq]
  exact Gk_le (yv_mem' hc.1 hc.2) (yv_mem' h1.1 h1.2) (yv_mem' h2.1 h2.2) (yv_mem' h3.1 h3.2)

/-! ## 3. One alias with the row split -/

set_option maxRecDepth 8000 in
theorem normSq_alias_row (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefK (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefK (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefK (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefK (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le_row _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefK, rhoP, Ef, Matrix.cons_val]
  ring

/-- The alias coefficients with the row split. -/
def DalK (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefK (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefK (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefK (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefK (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

theorem DalK_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    DalK σ c ≤ 3 / 5 := by
  fin_cases c
  · exact aliasK_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact aliasK_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

theorem alias_term_le_row (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefK (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefK (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefK (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefK (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias_row (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

theorem hrep_coord_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le_row θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, DalK, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound with the row split**: `⟨x, (𝓜P)(q) x⟩ ≤ (3/5) ⟨x, P(q) x⟩`. -/
theorem MP_coord_le_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (3 / 5) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord_row θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (3 / 5) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (DalK_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end RowSplit

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hPstep` with `λ̄′ = 3/5`**: `𝓜 P ≼ (3/5) P` (row-wise split). -/
theorem Mfam_P_le_row (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((3 / 5 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact RowSplit.MP_coord_le_row (th q) (WithLp.ofLp x)

end OneStepBridge

end

namespace NmBracket

noncomputable section

open Finset

/-! ## Copied definitions  -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- Linearity of `N` in `u` (one combination). -/
theorem Nm_lin (s u v : Fin 4 → ℝ) (t : ℝ) :
    Nm s (fun i => u i + t * v i) = fun i => Nm s u i + t * Nm s v i := by
  funext μ
  unfold Nm
  simp only [sum_erase4]
  ring

/-! ## The `M`-form : `N u = u − ½ M u`, `M = Σ_{μ<ν} B_{μν} ρ ρᵀ` -/

/-- `B_{μν}` of the complementary pair `{ρ, ρ'}`, in `b = s²`. -/
def Bw (b b' : ℝ) : ℝ := 1 - (b + b') / 4 + b * b' / 12

theorem one_sub_Ef (b b' : ℝ) : 1 - Ef (b / 2) (b' / 2) = Bw b b' := by
  unfold Ef Bw; ring

/-- `D_{μν} = s_ν u_μ − s_μ u_ν`. -/
def Dp (s u : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := s ν * u μ - s μ * u ν

/-- The quadratic form `⟨u, M u⟩ = Σ_{μ<ν} B_{μν} D_{μν}²` written out over the six faces. -/
def Mq (s u : Fin 4 → ℝ) : ℝ :=
  Bw (s 2 ^ 2) (s 3 ^ 2) * Dp s u 0 1 ^ 2 + Bw (s 1 ^ 2) (s 3 ^ 2) * Dp s u 0 2 ^ 2 +
  Bw (s 1 ^ 2) (s 2 ^ 2) * Dp s u 0 3 ^ 2 + Bw (s 0 ^ 2) (s 3 ^ 2) * Dp s u 1 2 ^ 2 +
  Bw (s 0 ^ 2) (s 2 ^ 2) * Dp s u 1 3 ^ 2 + Bw (s 0 ^ 2) (s 1 ^ 2) * Dp s u 2 3 ^ 2

set_option maxRecDepth 8000 in
/-- `⟨u, N u⟩ = |u|² − ½ ⟨u, M u⟩` (unordered faces `μ < ν`). -/
theorem Nm_form (s u : Fin 4 → ℝ) : dot u (Nm s u) = dot u u - (1 / 2) * Mq s u := by
  unfold dot Nm Mq Dp Bw
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  simp
  ring

/-! ## Per-face bounds on `B` (P3, P3′) -/

theorem Bw_le_refined {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') (hb1 : b ≤ 1) (hb1' : b' ≤ 1) :
    Bw b b' ≤ 1 - 5 * (b + b') / 24 := by
  unfold Bw; nlinarith [mul_nonneg hb hb', mul_nonneg (sub_nonneg.2 hb1) hb',
    mul_nonneg hb (sub_nonneg.2 hb1'), sq_nonneg (b - b')]

theorem Bw_ge_lin {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') : 1 - (b + b') / 4 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg hb hb']

theorem Bw_lower {b b' : ℝ} (hb1 : b ≤ 1) (hb1' : b' ≤ 1) : 7 / 12 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg (sub_nonneg.2 hb1) (sub_nonneg.2 hb1')]

/-! ## The bracket on `s^⊥` -/

def llo (X bm sb : ℝ) : ℝ := 1 - 1/2*((1 - 5/24*X)*X + 5/24*(X*bm + sb))
def lup (X sb : ℝ) : ℝ := min (1 - 7/24*X) (1 - (X - X^2/4 + sb/4)/2)

def Xs (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 2
def Sb (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 4

section Bracket

variable {s u : Fin 4 → ℝ}

/-- Upper side of `⟨u, M u⟩` (gives `λ_lo`): with `u ⊥ s`,
`⟨u,Mu⟩ ≤ (1 − 5X/24) X |u|² + 5/24 (X Σ s²u² + Σ s⁴ |u|²)`. -/
theorem Mq_le (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    Mq s u ≤ (1 - 5/24 * Xs s) * Xs s * dot u u +
      5/24 * (Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 + Sb s * dot u u) := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have f01 := mul_le_mul_of_nonneg_right (Bw_le_refined p2 p3 h2 h3) (sq_nonneg (Dp s u 0 1))
  have f02 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p3 h1 h3) (sq_nonneg (Dp s u 0 2))
  have f03 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p2 h1 h2) (sq_nonneg (Dp s u 0 3))
  have f12 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p3 h0 h3) (sq_nonneg (Dp s u 1 2))
  have f13 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p2 h0 h2) (sq_nonneg (Dp s u 1 3))
  have f23 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p1 h0 h1) (sq_nonneg (Dp s u 2 3))
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  unfold Mq
  simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at f01 f02 f03 f12 f13 f23 ⊢
  linarith

/-- Lower sides of `⟨u, M u⟩` (give `λ_up`). -/
theorem Mq_ge (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    7/12 * (Xs s * dot u u) ≤ Mq s u ∧
      (Xs s - Xs s ^ 2 / 4 + Sb s / 4) * dot u u ≤ Mq s u := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  constructor
  · have g01 := mul_le_mul_of_nonneg_right (Bw_lower h2 h3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_lower h1 h3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_lower h1 h2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_lower h0 h3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_lower h0 h2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_lower h0 h1) (sq_nonneg (Dp s u 2 3))
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith
  · have g01 := mul_le_mul_of_nonneg_right (Bw_ge_lin p2 p3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p1) (sq_nonneg (Dp s u 2 3))
    have hX : 0 ≤ (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
        (s 0 ^ 2 * u 0 ^ 2 + s 1 ^ 2 * u 1 ^ 2 + s 2 ^ 2 * u 2 ^ 2 + s 3 ^ 2 * u 3 ^ 2) := by
      positivity
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith

theorem dot_self_nonneg (u : Fin 4 → ℝ) : 0 ≤ dot u u :=
  Finset.sum_nonneg fun i _ => mul_self_nonneg (u i)

theorem Xs_nonneg (s : Fin 4 → ℝ) : 0 ≤ Xs s := Finset.sum_nonneg fun i _ => sq_nonneg _

/-- **Lower end of the bracket**: `λ_lo |u|² ≤ ⟨u, N u⟩` on `s^⊥`. -/
theorem Nm_bracket_lo {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1) (hbm : ∀ ν, s ν ^ 2 ≤ bm)
    (hu : dot s u = 0) : llo (Xs s) bm (Sb s) * dot u u ≤ dot u (Nm s u) := by
  rw [Nm_form]
  have h := Mq_le hb hu
  have hw : ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ bm * dot u u := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun ν _ => by
      have := mul_le_mul_of_nonneg_right (hbm ν) (sq_nonneg (u ν)); nlinarith
  have hX := Xs_nonneg s
  have : Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ Xs s * (bm * dot u u) :=
    mul_le_mul_of_nonneg_left hw hX
  unfold llo
  nlinarith

/-- **Upper end of the bracket**: `⟨u, N u⟩ ≤ λ_up |u|²` on `s^⊥`. -/
theorem Nm_bracket_up (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    dot u (Nm s u) ≤ lup (Xs s) (Sb s) * dot u u := by
  rw [Nm_form]
  obtain ⟨h1, h2⟩ := Mq_ge hb hu
  unfold lup
  rw [min_mul_of_nonneg _ _ (dot_self_nonneg u)]
  refine le_min ?_ ?_ <;> nlinarith

end Bracket

/-! ## From the bracket to the norm bounds `κ⁻`, `κ⁺` -/

section Norm

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (fun i => b i + c i) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_smul_right (a b : Fin 4 → ℝ) (t : ℝ) : dot a (fun i => t * b i) = t * dot a b := by
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (fun i => a i + b i) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_smul_left (a b : Fin 4 → ℝ) (t : ℝ) : dot (fun i => t * a i) b = t * dot a b := by
  rw [dot_comm, dot_smul_right, dot_comm]

/-- `N` maps `s^⊥` into itself. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-- Cauchy–Schwarz for `dot`. -/
theorem dot_sq_le (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa [sq] using h

variable {s u : Fin 4 → ℝ}

/-- The frame inequality on `s^⊥`: `|N u − lo u|² ≤ (up − lo)(⟨u,Nu⟩ − lo|u|²)`. -/
theorem frame_ineq {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) ≤
      (up - lo) * (dot u (Nm s u) - lo * dot u u) := by
  set y : Fin 4 → ℝ := fun i => Nm s u i + (-lo) * u i with hy
  -- the positive form p(v) = ⟨v, N v⟩ - lo |v|² on s^⊥
  have hys : dot s y = 0 := by
    rw [hy, dot_add_right, dot_smul_right, dot_Nm_of_dot hu, hu]; ring
  have hNy : Nm s y = fun i => Nm s (Nm s u) i + (-lo) * Nm s u i := by
    rw [hy, Nm_lin]
  -- c = ⟨u, P y⟩ = |y|²
  have hc : dot u (Nm s y) + (-lo) * dot u y = dot y y := by
    rw [hNy, dot_add_right, dot_smul_right, Nm_symm s (Nm s u) u]
    conv_rhs => rw [hy, dot_add_left, dot_smul_left]
    rw [hy, dot_add_right, dot_smul_right]
    rw [dot_comm (Nm s u) (Nm s u)]
    have : dot (Nm s u) u = dot u (Nm s u) := dot_comm _ _
    rw [dot_add_right, dot_smul_right, this]
  set p := dot u (Nm s u) - lo * dot u u
  set c := dot y y
  set d := dot y (Nm s y) - lo * dot y y
  have hp : 0 ≤ p := by have := hlo u hu; simp only [p]; linarith
  have hyy : 0 ≤ c := dot_self_nonneg y
  have hd : d ≤ (up - lo) * c := by
    have := hup y hys; simp only [d, c]; linarith
  -- positivity of the form along u + t y
  have hf : ∀ t : ℝ, 0 ≤ p + 2 * t * c + t ^ 2 * d := by
    intro t
    set v : Fin 4 → ℝ := fun i => u i + t * y i with hv
    have hvs : dot s v = 0 := by rw [hv, dot_add_right, dot_smul_right, hu, hys]; ring
    have h0 := hlo v hvs
    have hNv : Nm s v = fun i => Nm s u i + t * Nm s y i := by rw [hv, Nm_lin]
    have hyu : dot y (Nm s u) = dot u (Nm s y) := by rw [Nm_symm, dot_comm]
    have e1 : dot v (Nm s v) = dot u (Nm s u) + 2 * t * dot u (Nm s y) +
        t ^ 2 * dot y (Nm s y) := by
      rw [hNv, hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, hyu]
      ring
    have e2 : dot v v = dot u u + 2 * t * dot u y + t ^ 2 * dot y y := by
      rw [hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, dot_comm y u]
      ring
    have hc' : dot u (Nm s y) - lo * dot u y = c := by simp only [c]; linarith [hc]
    rw [e1, e2] at h0
    have h2c : 2 * t * (dot u (Nm s y) - lo * dot u y) = 2 * t * c := by rw [hc']
    simp only [p, d]
    nlinarith [h2c]
  by_cases hD : 0 < up - lo
  · have h1 := hf (-(1 / (up - lo)))
    have hdiv : d * (1 / (up - lo)) ^ 2 ≤ c * (1 / (up - lo)) := by
      have hpos : 0 < 1 / (up - lo) := by positivity
      have := mul_le_mul_of_nonneg_right hd (sq_nonneg (1 / (up - lo)))
      have e : (up - lo) * c * (1 / (up - lo)) ^ 2 = c * (1 / (up - lo)) := by
        field_simp
      linarith
    have h2 : 0 ≤ p - c * (1 / (up - lo)) := by nlinarith
    have h3 : c * (1 / (up - lo)) ≤ p := by linarith
    have := mul_le_mul_of_nonneg_left h3 hD.le
    have e : (up - lo) * (c * (1 / (up - lo))) = c := by field_simp
    linarith
  · -- `up ≤ lo`: then `p = 0`, `d ≤ 0`, and positivity along `u + t y` forces `c = 0`
    have hd0 : d ≤ 0 := by nlinarith
    have hpa : p ≤ 0 := by
      have h1 := hup u hu
      have ha := dot_self_nonneg u
      have : (up - lo) * dot u u ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) ha
      simp only [p]; nlinarith
    have hp0 : p = 0 := le_antisymm hpa hp
    rw [hp0, mul_zero]
    by_contra hcon
    have hcpos : 0 < c := lt_of_not_ge hcon
    have h1 := hf (-1 / (2 * c))
    rw [hp0] at h1
    have e : 2 * (-1 / (2 * c)) * c = -1 := by field_simp
    have hn : (-1 / (2 * c)) ^ 2 * d ≤ 0 := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg _) hd0
    linarith

/-- **`κ⁺`**: on `s^⊥`, `|N u|² ≤ max (lo²) (up²) |u|²`. -/
theorem Nm_sq_le_of_bracket {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤ max (lo ^ 2) (up ^ 2) * dot u u := by
  have hF := frame_ineq hlo hup hu
  have e : dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) =
      dot (Nm s u) (Nm s u) - 2 * lo * dot u (Nm s u) + lo ^ 2 * dot u u := by
    rw [dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
      dot_smul_right, dot_smul_right, dot_comm (Nm s u) u]
    ring
  rw [e] at hF
  set t := dot u (Nm s u)
  set a := dot u u
  have ha : 0 ≤ a := dot_self_nonneg u
  have h1 := hlo u hu
  have h2 := hup u hu
  have hm1 := le_max_left (lo ^ 2) (up ^ 2)
  have hm2 := le_max_right (lo ^ 2) (up ^ 2)
  -- `N² ≤ (up + lo) t − up lo a`, linear in `t ∈ [lo a, up a]`
  rcases le_total 0 (up + lo) with hs | hs
  · have : (up + lo) * t ≤ (up + lo) * (up * a) := mul_le_mul_of_nonneg_left h2 hs
    nlinarith [mul_le_mul_of_nonneg_right hm2 ha]
  · have : (up + lo) * (lo * a) ≥ (up + lo) * t := mul_le_mul_of_nonpos_left h1 hs
    nlinarith [mul_le_mul_of_nonneg_right hm1 ha]

/-- **`κ⁻`**: on `s^⊥`, `(max lo 0)² |u|² ≤ |N u|²`. -/
theorem le_Nm_sq_of_bracket {lo : ℝ}
    (hlo : lo * dot u u ≤ dot u (Nm s u)) :
    (max lo 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) := by
  have ha := dot_self_nonneg u
  have hcs := dot_sq_le u (Nm s u)
  rcases le_total lo 0 with h | h
  · rw [max_eq_right h]; simp; exact dot_self_nonneg _
  · rw [max_eq_left h]
    have ht : lo * dot u u ≤ dot u (Nm s u) := hlo
    have h0 : 0 ≤ lo * dot u u := mul_nonneg h ha
    have hsq : (lo * dot u u) ^ 2 ≤ dot u (Nm s u) ^ 2 := pow_le_pow_left₀ h0 ht 2
    rcases lt_or_eq_of_le ha with hpos | hzero
    · have : lo ^ 2 * dot u u * dot u u ≤ dot (Nm s u) (Nm s u) * dot u u := by nlinarith
      exact le_of_mul_le_mul_right this hpos
    · rw [← hzero]; simp; exact dot_self_nonneg _

end Norm

/-! ## The concrete `κ⁻`, `κ⁺` of TauStageZero -/

theorem Nm_sq_le_kplus {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤
      max (llo (Xs s) bm (Sb s) ^ 2) (lup (Xs s) (Sb s) ^ 2) * dot u u :=
  Nm_sq_le_of_bracket (fun _ hv => Nm_bracket_lo hb hbm hv) (fun _ hv => Nm_bracket_up hb hv) hu

theorem kminus_le_Nm_sq {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    (max (llo (Xs s) bm (Sb s)) 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) :=
  le_Nm_sq_of_bracket (Nm_bracket_lo hb hbm hu)


end

end NmBracket

/-! # L2-3: (OS↑) `𝓜(P/ω) ≼ P/ω` from `E_ν ≤ 4`, and the transient `D₀ = 0`

Paper: theorem 3 (`E_ν < 4 ⇒ (OS↑)`), §8.57 ("紙のまま: E_ν < 4 ⇒ (OS↑)、Lean の EE と紙の
E_ν の同一"). Lean: `os_up` is `UniformBracket.Lw (Mfam th rq G₀) G₀`, `G₀ = P/ω`, i.e. the field
`h1` of `CouplingLimit.transient_zero`, under the hypothesis `hEE : EE σ(q) ν ≤ 4` where `EE` is
the definition of (`EE s ν = Σ_e HH s / XX s e * kplus s e * (1 − bb s e ν)`) copied
verbatim, and `σ(q)_ν = sin²(th q ν)`. The hypothesis is the conclusion of 
`FreeStageOS.E_lt_four_s` (`Adm σ`, i.e. `σ ≤ 1/2`, and `σ ≠ 0`).

Dictionary (proved here): `xa = bb/2`, `wa = 1 − bb`, `omR = 4·XX`, `omQ = 4·HH`,
`sR² = bb`, `Σ sR² = XX`, `Σ sR⁴ = SS`; the per-alias bound `alias_term_le_kplus` replaces
`alias_term_le_one` (κ⁺ in place of 1) via `NmBracket.Nm_sq_le_kplus`. -/

namespace OSUpBridge

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

/-! ## Copies of the definitions (ℝ) -/

def bb (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (μ : Fin 4) : ℝ := if e μ then 1 - s μ else s μ
def XX (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, bb s e μ
def SS (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, (bb s e μ)^2
def BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max (max (bb s e 0) (bb s e 1)) (max (bb s e 2) (bb s e 3))
def HH (s : Fin 4 → ℝ) : ℝ := 4 * ∑ μ, s μ * (1 - s μ)
noncomputable def lamLo (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.llo (XX s e) (BM s e) (SS s e)
noncomputable def lamUp (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.lup (XX s e) (SS s e)
noncomputable def kplus (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max ((lamLo s e)^2) ((lamUp s e)^2)
noncomputable def EE (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  ∑ e, HH s / XX s e * kplus s e * (1 - bb s e ν)

/-! ## The dictionary -/

theorem xa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    xa (s ν) (e ν) = bb s e ν / 2 := by
  unfold bb; cases e ν <;> simp [xa]

theorem wa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    wa (s ν) (e ν) = 1 - bb s e ν := by
  unfold bb; cases e ν <;> simp [wa]

theorem omR_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : omR s e = 4 * XX s e := by
  unfold omR XX; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by rw [xa_eq]; ring

theorem omQ_eq (s : Fin 4 → ℝ) : omQ s = 4 * HH s := by
  unfold omQ HH; rw [Finset.mul_sum, Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by ring

theorem sR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sR θ ζ ν ^ 2 = bb (fun ν => Real.sin (θ ν) ^ 2) ζ ν := by
  have h := xs_alias θ ζ ν
  unfold xs at h
  rw [xa_eq (fun ν => Real.sin (θ ν) ^ 2) ζ ν] at h
  linarith

theorem bb_le_BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) : bb s e ν ≤ BM s e := by
  unfold BM
  fin_cases ν
  · exact le_trans (le_max_left _ _) (le_max_left _ _)
  · exact le_trans (le_max_right _ _) (le_max_left _ _)
  · exact le_trans (le_max_left _ _) (le_max_right _ _)
  · exact le_trans (le_max_right _ _) (le_max_right _ _)

/-- `N` of All1135 is the `N` of `NmBracket` (same definition). -/
theorem Nm_eq (s u : Fin 4 → ℝ) : Nm s u = NmBracket.Nm s u := rfl

theorem dot_eq (a b : Fin 4 → ℝ) : dot a b = NmBracket.dot a b := rfl

/-! ## One alias with `κ⁺` -/

/-- **`alias_term_le_kplus`**: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 κ⁺_ζ Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_kplus (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * kplus (fun ν => Real.sin (θ ν) ^ 2) ζ *
        ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  set σ : Fin 4 → ℝ := fun ν => Real.sin (θ ν) ^ 2 with hσ
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb : ∀ ν, sR θ ζ ν ^ 2 ≤ 1 := fun ν => by
    unfold sR; exact Real.sin_sq_le_one _
  have hbm : ∀ ν, sR θ ζ ν ^ 2 ≤ BM σ ζ := fun ν => by
    rw [sR_sq]; exact bb_le_BM σ ζ ν
  have hK := NmBracket.Nm_sq_le_kplus hb hbm (by rw [← dot_eq]; exact hw)
  have hX : NmBracket.Xs (sR θ ζ) = XX σ ζ := by
    unfold NmBracket.Xs XX; exact Finset.sum_congr rfl fun ν _ => sR_sq θ ζ ν
  have hS : NmBracket.Sb (sR θ ζ) = SS σ ζ := by
    unfold NmBracket.Sb SS
    exact Finset.sum_congr rfl fun ν _ => by
      rw [← sR_sq]; ring
  rw [hX, hS] at hK
  have e : dot w w = ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * u μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  have hk : kplus σ ζ = max (NmBracket.llo (XX σ ζ) (BM σ ζ) (SS σ ζ) ^ 2)
      (NmBracket.lup (XX σ ζ) (SS σ ζ) ^ 2) := rfl
  rw [← dot_eq, ← dot_eq, ← Nm_eq, ← hk, e] at hK
  linarith

/-! ## The coefficient identity and (OS↑) -/

theorem coef_eq (σ : Fin 4 → ℝ) (hH : HH σ ≠ 0) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹ =
      EE σ μ / (4 * omQ σ) := by
  unfold EE
  rw [omQ_eq, Finset.mul_sum, Finset.sum_div]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [wa_eq, omR_eq]
  field_simp

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **(OS↑)**: `𝓜(P/ω) ≼ P/ω` when every `E_ν ≤ 4`. -/
theorem os_up (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_kplus (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hH : HH σ ≠ 0 := by rw [omQ_eq] at hω'; intro h; rw [h] at hω'; simp at hω'
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) *
        u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ *
      (omR σ ζ)⁻¹) * u μ ^ 2 ≤ ∑ μ, (omQ σ)⁻¹ * u μ ^ 2 := by
    refine Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)
    rw [coef_eq σ hH μ]
    have h4 : 0 < 4 * omQ σ := by linarith
    rw [div_le_iff₀ h4]
    have := hEE q μ
    have e : (omQ σ)⁻¹ * (4 * omQ σ) = 4 := by field_simp
    linarith
  have hRHS : ⟪x, (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ =
      (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-- `Adm` of (same text). -/
def Adm (s : Fin 4 → ℝ) : Prop := ∀ μ, 0 ≤ s μ ∧ s μ ≤ 1/2

theorem sin_sq_le_half {x : ℝ} (hx : |x| ≤ π / 4) : Real.sin x ^ 2 ≤ 1 / 2 := by
  have h := abs_le.mp hx
  have hc : 0 ≤ Real.cos (2 * x) :=
    Real.cos_nonneg_of_mem_Icc ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  have e : Real.sin x ^ 2 = 1 / 2 - Real.cos (2 * x) / 2 := by
    rw [Real.sin_sq, Real.cos_sq x]; ring
  rw [e]; linarith

/-- **(OS↑) with the free-stage input as a hypothesis in the exact form of 
`FreeStageOS.E_lt_four_s`** (`hE`), for momenta with `|θ_ν| ≤ π/4` (i.e. `|q_ν| ≤ π`). -/
theorem os_up_of_free (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hth : ∀ q ν, |th q ν| ≤ π / 4)
    (hE : ∀ {s : Fin 4 → ℝ}, Adm s → (∃ μ, 0 < s μ) → ∀ ν, EE s ν < 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  refine os_up th rq hrq hω fun q ν => le_of_lt (hE ?_ ?_ ν)
  · intro μ; exact ⟨sq_nonneg _, sin_sq_le_half (hth q μ)⟩
  · by_contra hne
    push_neg at hne
    have hz : ∀ μ, Real.sin (th q μ) = 0 := fun μ => by
      have := hne μ
      have h0 : Real.sin (th q μ) ^ 2 = 0 := le_antisymm this (sq_nonneg _)
      exact pow_eq_zero_iff (two_ne_zero) |>.mp h0
    have h0 : omF th q = 0 := by
      unfold omF sQ
      refine Finset.sum_eq_zero fun μ _ => ?_
      rw [Real.sin_two_mul, hz μ]; ring
    linarith [hω q]

open Filter Topology in
/-- **`transient_zero_concrete`**: with (OS↑) from `E_ν ≤ 4`, a Loewner-monotone `Ξ` along the
concrete stages decreases to its limit: `δ_k ≥ 0`, every transient term vanishes (`D₀ = 0`). -/
theorem transient_zero_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4)
    (Ξ : (Q → V →ₗ[ℝ] V) → ℝ) (hmono : ∀ A B, UniformBracket.Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
      atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) ∧
      max (-(Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) - binf)) 0 = 0 :=
  CouplingLimit.transient_zero (Mfam th rq) (Mfam_orderPreserving th rq)
    (os_up th rq hrq hω hEE) Ξ hmono hlim k

end OSUpBridge


/-!
# L6-1: a quadratic `Ξ` is Lipschitz relative to `P` on the bracket set (`relLip_of_quadratic`)

Paper: table 10, plan-06 §1 and : the one-loop coefficient
`b_k = Ξ(G_k)` with `E = −½ log det K(B)`, `G = K⁻¹`, second-order response
`−½ tr(G V₂) + ½ tr(G V₁ G V₁)` (`V₁ = K′`, `V₂ = K″`) is a polynomial of degree two in the
covariance, possibly through a linear order-preserving map `L` (`Γ_k = L G_k`). On a finite torus
the traces are finite sums of matrix elements, so
`Ξ(A) = a + Σ_i w_i ⟪x_i, (L A)(p_i) x_i⟫ + Σ_j w'_j ⟪v_j, (L A)(q_j) u_j⟫ ⟪u'_j, (L A)(q'_j) v'_j⟫`.

Lean: `Lw`, `RelLip` are copied from an earlier file (`UniformBracket.Lw`, `CouplingLimit.RelLip`, same
text). `relLip_of_quadratic`: on `S = {A symmetric, −C P ≼ A ≼ C P}` this `Ξ` is `RelLip` with
`L = Σ|w_i|⟪x_i,P′x_i⟫ + Σ |w'_j| · 2C · m₁(j) m₂(j)` (`m₁ = (⟪v,P′v⟫ + ⟪u,P′u⟫)/2`, `m₂` likewise),
given `L` linear, order preserving, preserving symmetry, `L P ≼ P′`, `P′` symmetric.
`trace_term_bound`: the per-momentum bound with the named input `hV1 : ‖V₁ q‖² ≤ CV ω(q)`
(the vertex vanishes at `q → 0`; paper input), which makes the quadratic constant finite.
-/

namespace QuadLip

open Finset
open scoped RealInnerProductSpace

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
variable {Q' E' : Type*} [NormedAddCommGroup E'] [InnerProductSpace ℝ E']

/-- (= `UniformBracket.Lw`). -/
def Lw (A B : Q → E →ₗ[ℝ] E) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

/-- (= `CouplingLimit.RelLip`). -/
def RelLip (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (P : Q → E →ₗ[ℝ] E) (L : ℝ) (S : Set (Q → E →ₗ[ℝ] E)) :
    Prop :=
  ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c → Lw (-(c • P)) (A - B) → Lw (A - B) (c • P) →
    |Ξ A - Ξ B| ≤ L * c

def SymFam (A : Q → E →ₗ[ℝ] E) : Prop := ∀ q, (A q).IsSymmetric

/-- Matrix elements of a symmetric `D` with `−c P ≼ D ≼ c P` (P symmetric):
`|⟪v, D u⟫| ≤ c (⟪v,Pv⟫ + ⟪u,Pu⟫)/2`. -/
theorem elem_bound (D P : E →ₗ[ℝ] E) (hD : D.IsSymmetric) (hP : P.IsSymmetric) {c : ℝ}
    (hlo : ∀ x, -(c * ⟪x, P x⟫) ≤ ⟪x, D x⟫) (hhi : ∀ x, ⟪x, D x⟫ ≤ c * ⟪x, P x⟫) (v u : E) :
    |⟪v, D u⟫| ≤ c * (⟪v, P v⟫ + ⟪u, P u⟫) / 2 := by
  have pol : ∀ T : E →ₗ[ℝ] E, T.IsSymmetric →
      ⟪v + u, T (v + u)⟫ - ⟪v - u, T (v - u)⟫ = 4 * ⟪v, T u⟫ ∧
      ⟪v + u, T (v + u)⟫ + ⟪v - u, T (v - u)⟫ = 2 * ⟪v, T v⟫ + 2 * ⟪u, T u⟫ := by
    intro T hT
    have h1 : ⟪u, T v⟫ = ⟪v, T u⟫ := by rw [← hT, real_inner_comm]
    simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left,
      inner_sub_right]
    constructor <;> linarith
  obtain ⟨d1, d2⟩ := pol D hD
  obtain ⟨_, p2⟩ := pol P hP
  have a1 := hhi (v + u); have a2 := hlo (v - u)
  have b1 := hlo (v + u); have b2 := hhi (v - u)
  have cp : c * (⟪v + u, P (v + u)⟫ + ⟪v - u, P (v - u)⟫) =
      c * (2 * ⟪v, P v⟫ + 2 * ⟪u, P u⟫) := by rw [p2]
  rw [abs_le]; constructor <;> nlinarith

/-- `−c P ≼ A − B ≼ c P` passes through `L` to `−c P′ ≼ L(A − B) ≼ c P′`. -/
theorem push_bracket (Lm : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q' → E' →ₗ[ℝ] E'))
    (hord : ∀ A B, Lw A B → Lw (Lm A) (Lm B)) (P : Q → E →ₗ[ℝ] E) (P' : Q' → E' →ₗ[ℝ] E')
    (hLP : Lw (Lm P) P') {D : Q → E →ₗ[ℝ] E} {c : ℝ} (hc : 0 ≤ c)
    (hlo : Lw (-(c • P)) D) (hhi : Lw D (c • P)) :
    (∀ q x, -(c * ⟪x, P' q x⟫) ≤ ⟪x, Lm D q x⟫) ∧ (∀ q x, ⟪x, Lm D q x⟫ ≤ c * ⟪x, P' q x⟫) := by
  have h1 := hord _ _ hlo
  have h2 := hord _ _ hhi
  rw [map_neg, map_smul] at h1
  rw [map_smul] at h2
  constructor
  · intro q x
    have := h1 q x
    have hp := hLP q x
    simp only [Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
      inner_neg_right, real_inner_smul_right] at this
    nlinarith [mul_le_mul_of_nonneg_left hp hc]
  · intro q x
    have := h2 q x
    have hp := hLP q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at this
    nlinarith [mul_le_mul_of_nonneg_left hp hc]

/-- The quadratic `Ξ` through `L`. -/
noncomputable def XiQ (Lm : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q' → E' →ₗ[ℝ] E')) (a : ℝ)
    {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Q') (x : ι → E')
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Q') (v u u2 v2 : κ → E')
    (A : Q → E →ₗ[ℝ] E) : ℝ :=
  a + ∑ i ∈ s, w i * ⟪x i, Lm A (p i) (x i)⟫ +
    ∑ j ∈ t, w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫)

/-- **`relLip_of_quadratic`**. -/
theorem relLip_of_quadratic (Lm : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q' → E' →ₗ[ℝ] E'))
    (hord : ∀ A B, Lw A B → Lw (Lm A) (Lm B)) (hsym : ∀ A, SymFam A → SymFam (Lm A))
    (P : Q → E →ₗ[ℝ] E) (P' : Q' → E' →ₗ[ℝ] E') (hLP : Lw (Lm P) P') (hP' : SymFam P')
    {C : ℝ} (hC : 0 ≤ C) (a : ℝ)
    {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Q') (x : ι → E')
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Q') (v u u2 v2 : κ → E') :
    RelLip (XiQ Lm a s w p x t w2 q q2 v u u2 v2) P
      (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (2 * C * ((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
          ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)))
      {A | SymFam A ∧ Lw (-(C • P)) A ∧ Lw A (C • P)} := by
  rintro A ⟨hAs, hAlo, hAhi⟩ B ⟨hBs, hBlo, hBhi⟩ c hc hlo hhi
  -- brackets after `L`
  obtain ⟨dlo, dhi⟩ := push_bracket Lm hord P P' hLP hc hlo hhi
  obtain ⟨alo, ahi⟩ := push_bracket Lm hord P P' hLP hC hAlo hAhi
  obtain ⟨blo, bhi⟩ := push_bracket Lm hord P P' hLP hC hBlo hBhi
  have hDsym : SymFam (Lm (A - B)) := hsym _ fun q => by
    have h1 := hAs q; have h2 := hBs q
    intro y z
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_left, inner_sub_right, h1 y z, h2 y z]
  have eD : ∀ q', Lm (A - B) q' = Lm A q' - Lm B q' := fun q' => by rw [map_sub]; rfl
  -- bounds on single elements
  have bD : ∀ (q' : Q') (y z : E'), |⟪y, Lm (A - B) q' z⟫| ≤
      c * (⟪y, P' q' y⟫ + ⟪z, P' q' z⟫) / 2 := fun q' y z =>
    elem_bound _ _ (hDsym q') (hP' q') (dlo q') (dhi q') y z
  have bA : ∀ (q' : Q') (y z : E'), |⟪y, Lm A q' z⟫| ≤ C * (⟪y, P' q' y⟫ + ⟪z, P' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsym A hAs q') (hP' q') (alo q') (ahi q') y z
  have bB : ∀ (q' : Q') (y z : E'), |⟪y, Lm B q' z⟫| ≤ C * (⟪y, P' q' y⟫ + ⟪z, P' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsym B hBs q') (hP' q') (blo q') (bhi q') y z
  have hpos : ∀ (q' : Q') (y : E'), -(c * ⟪y, P' q' y⟫) ≤ c * ⟪y, P' q' y⟫ := fun q' y =>
    (dlo q' y).trans (dhi q' y)
  -- linear part
  have lin : ∀ i ∈ s, |w i * ⟪x i, Lm A (p i) (x i)⟫ - w i * ⟪x i, Lm B (p i) (x i)⟫| ≤
      |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by
    intro i _
    rw [← mul_sub, abs_mul]
    have e : ⟪x i, Lm A (p i) (x i)⟫ - ⟪x i, Lm B (p i) (x i)⟫ = ⟪x i, Lm (A - B) (p i) (x i)⟫ := by
      rw [eD, LinearMap.sub_apply, inner_sub_right]
    rw [e]
    have := abs_le.mpr ⟨dlo (p i) (x i), dhi (p i) (x i)⟩
    calc |w i| * |⟪x i, Lm (A - B) (p i) (x i)⟫| ≤ |w i| * (c * ⟪x i, P' (p i) (x i)⟫) :=
          mul_le_mul_of_nonneg_left this (abs_nonneg _)
      _ = |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by ring
  -- quadratic part
  have quad : ∀ j ∈ t, |w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
      w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)| ≤
      |w2 j| * (2 * C * ((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
          ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)) * c := by
    intro j _
    set m1 := (⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2
    set m2 := (⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2
    set a1 := ⟪v j, Lm A (q j) (u j)⟫
    set b1 := ⟪u2 j, Lm A (q2 j) (v2 j)⟫
    set a2 := ⟪v j, Lm B (q j) (u j)⟫
    set b2 := ⟪u2 j, Lm B (q2 j) (v2 j)⟫
    have hda : |a1 - a2| ≤ c * m1 := by
      have e : a1 - a2 = ⟪v j, Lm (A - B) (q j) (u j)⟫ := by
        simp only [a1, a2]; rw [eD, LinearMap.sub_apply, inner_sub_right]
      rw [e]; have := bD (q j) (v j) (u j); simp only [m1]; linarith
    have hdb : |b1 - b2| ≤ c * m2 := by
      have e : b1 - b2 = ⟪u2 j, Lm (A - B) (q2 j) (v2 j)⟫ := by
        simp only [b1, b2]; rw [eD, LinearMap.sub_apply, inner_sub_right]
      rw [e]; have := bD (q2 j) (u2 j) (v2 j); simp only [m2]; linarith
    have hb1 : |b1| ≤ C * m2 := by have := bA (q2 j) (u2 j) (v2 j); simp only [m2]; linarith
    have ha2 : |a2| ≤ C * m1 := by have := bB (q j) (v j) (u j); simp only [m1]; linarith
    have key : |a1 * b1 - a2 * b2| ≤ 2 * C * m1 * m2 * c := by
      have e : a1 * b1 - a2 * b2 = (a1 - a2) * b1 + a2 * (b1 - b2) := by ring
      rw [e]
      calc |(a1 - a2) * b1 + a2 * (b1 - b2)| ≤ |a1 - a2| * |b1| + |a2| * |b1 - b2| := by
            refine (abs_add_le _ _).trans ?_; rw [abs_mul, abs_mul]
        _ ≤ (c * m1) * (C * m2) + (C * m1) * (c * m2) := add_le_add
            (mul_le_mul hda hb1 (abs_nonneg _) ((abs_nonneg _).trans hda))
            (mul_le_mul ha2 hdb (abs_nonneg _) ((abs_nonneg _).trans ha2))
        _ = 2 * C * m1 * m2 * c := by ring
    rw [← mul_sub, abs_mul]
    calc |w2 j| * |a1 * b1 - a2 * b2| ≤ |w2 j| * (2 * C * m1 * m2 * c) :=
          mul_le_mul_of_nonneg_left key (abs_nonneg _)
      _ = |w2 j| * (2 * C * m1 * m2) * c := by ring
  -- assemble
  unfold XiQ
  have e : a + ∑ i ∈ s, w i * ⟪x i, Lm A (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
      (a + ∑ i ∈ s, w i * ⟪x i, Lm B (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)) =
      ∑ i ∈ s, (w i * ⟪x i, Lm A (p i) (x i)⟫ - w i * ⟪x i, Lm B (p i) (x i)⟫) +
      ∑ j ∈ t, (w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
        w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)) := by
    rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib]; ring
  rw [e, add_mul, Finset.sum_mul, Finset.sum_mul]
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum lin)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum quad)

/-- **`relLip_of_quadratic₂`**: as `relLip_of_quadratic`, with the bracket set measured by a second
family `Pb` (e.g. `P/ω`, the size of the covariances themselves) and `L Pb ≼ Pb′`; the differences
stay relative to `P`. -/
theorem relLip_of_quadratic₂ (Lm : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q' → E' →ₗ[ℝ] E'))
    (hord : ∀ A B, Lw A B → Lw (Lm A) (Lm B)) (hsym : ∀ A, SymFam A → SymFam (Lm A))
    (P : Q → E →ₗ[ℝ] E) (P' : Q' → E' →ₗ[ℝ] E') (hLP : Lw (Lm P) P') (hP' : SymFam P')
    (Pb : Q → E →ₗ[ℝ] E) (Pb' : Q' → E' →ₗ[ℝ] E') (hLPb : Lw (Lm Pb) Pb') (hPb' : SymFam Pb')
    {C : ℝ} (hC : 0 ≤ C) (a : ℝ)
    {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Q') (x : ι → E')
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Q') (v u u2 v2 : κ → E') :
    RelLip (XiQ Lm a s w p x t w2 q q2 v u u2 v2) P
      (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (C *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2))))
      {A | SymFam A ∧ Lw (-(C • Pb)) A ∧ Lw A (C • Pb)} := by
  rintro A ⟨hAs, hAlo, hAhi⟩ B ⟨hBs, hBlo, hBhi⟩ c hc hlo hhi
  -- brackets after `L`
  obtain ⟨dlo, dhi⟩ := push_bracket Lm hord P P' hLP hc hlo hhi
  obtain ⟨alo, ahi⟩ := push_bracket Lm hord Pb Pb' hLPb hC hAlo hAhi
  obtain ⟨blo, bhi⟩ := push_bracket Lm hord Pb Pb' hLPb hC hBlo hBhi
  have hDsym : SymFam (Lm (A - B)) := hsym _ fun q => by
    have h1 := hAs q; have h2 := hBs q
    intro y z
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_left, inner_sub_right, h1 y z, h2 y z]
  have eD : ∀ q', Lm (A - B) q' = Lm A q' - Lm B q' := fun q' => by rw [map_sub]; rfl
  -- bounds on single elements
  have bD : ∀ (q' : Q') (y z : E'), |⟪y, Lm (A - B) q' z⟫| ≤
      c * (⟪y, P' q' y⟫ + ⟪z, P' q' z⟫) / 2 := fun q' y z =>
    elem_bound _ _ (hDsym q') (hP' q') (dlo q') (dhi q') y z
  have bA : ∀ (q' : Q') (y z : E'), |⟪y, Lm A q' z⟫| ≤ C * (⟪y, Pb' q' y⟫ + ⟪z, Pb' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsym A hAs q') (hPb' q') (alo q') (ahi q') y z
  have bB : ∀ (q' : Q') (y z : E'), |⟪y, Lm B q' z⟫| ≤ C * (⟪y, Pb' q' y⟫ + ⟪z, Pb' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsym B hBs q') (hPb' q') (blo q') (bhi q') y z
  have hpos : ∀ (q' : Q') (y : E'), -(c * ⟪y, P' q' y⟫) ≤ c * ⟪y, P' q' y⟫ := fun q' y =>
    (dlo q' y).trans (dhi q' y)
  -- linear part
  have lin : ∀ i ∈ s, |w i * ⟪x i, Lm A (p i) (x i)⟫ - w i * ⟪x i, Lm B (p i) (x i)⟫| ≤
      |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by
    intro i _
    rw [← mul_sub, abs_mul]
    have e : ⟪x i, Lm A (p i) (x i)⟫ - ⟪x i, Lm B (p i) (x i)⟫ = ⟪x i, Lm (A - B) (p i) (x i)⟫ := by
      rw [eD, LinearMap.sub_apply, inner_sub_right]
    rw [e]
    have := abs_le.mpr ⟨dlo (p i) (x i), dhi (p i) (x i)⟩
    calc |w i| * |⟪x i, Lm (A - B) (p i) (x i)⟫| ≤ |w i| * (c * ⟪x i, P' (p i) (x i)⟫) :=
          mul_le_mul_of_nonneg_left this (abs_nonneg _)
      _ = |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by ring
  -- quadratic part
  have quad : ∀ j ∈ t, |w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
      w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)| ≤
      |w2 j| * (C *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2))) * c := by
    intro j _
    set m1 := (⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2
    set m2 := (⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2
    set n1 := (⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2
    set n2 := (⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2
    set a1 := ⟪v j, Lm A (q j) (u j)⟫
    set b1 := ⟪u2 j, Lm A (q2 j) (v2 j)⟫
    set a2 := ⟪v j, Lm B (q j) (u j)⟫
    set b2 := ⟪u2 j, Lm B (q2 j) (v2 j)⟫
    have hda : |a1 - a2| ≤ c * m1 := by
      have e : a1 - a2 = ⟪v j, Lm (A - B) (q j) (u j)⟫ := by
        simp only [a1, a2]; rw [eD, LinearMap.sub_apply, inner_sub_right]
      rw [e]; have := bD (q j) (v j) (u j); simp only [m1]; linarith
    have hdb : |b1 - b2| ≤ c * m2 := by
      have e : b1 - b2 = ⟪u2 j, Lm (A - B) (q2 j) (v2 j)⟫ := by
        simp only [b1, b2]; rw [eD, LinearMap.sub_apply, inner_sub_right]
      rw [e]; have := bD (q2 j) (u2 j) (v2 j); simp only [m2]; linarith
    have hb1 : |b1| ≤ C * n2 := by have := bA (q2 j) (u2 j) (v2 j); simp only [n2]; linarith
    have ha2 : |a2| ≤ C * n1 := by have := bB (q j) (v j) (u j); simp only [n1]; linarith
    have key : |a1 * b1 - a2 * b2| ≤ C * (m1 * n2 + n1 * m2) * c := by
      have e : a1 * b1 - a2 * b2 = (a1 - a2) * b1 + a2 * (b1 - b2) := by ring
      rw [e]
      calc |(a1 - a2) * b1 + a2 * (b1 - b2)| ≤ |a1 - a2| * |b1| + |a2| * |b1 - b2| := by
            refine (abs_add_le _ _).trans ?_; rw [abs_mul, abs_mul]
        _ ≤ (c * m1) * (C * n2) + (C * n1) * (c * m2) := add_le_add
            (mul_le_mul hda hb1 (abs_nonneg _) ((abs_nonneg _).trans hda))
            (mul_le_mul ha2 hdb (abs_nonneg _) ((abs_nonneg _).trans ha2))
        _ = C * (m1 * n2 + n1 * m2) * c := by ring
    rw [← mul_sub, abs_mul]
    calc |w2 j| * |a1 * b1 - a2 * b2| ≤ |w2 j| * (C * (m1 * n2 + n1 * m2) * c) :=
          mul_le_mul_of_nonneg_left key (abs_nonneg _)
      _ = |w2 j| * (C * (m1 * n2 + n1 * m2)) * c := by ring
  -- assemble
  unfold XiQ
  have e : a + ∑ i ∈ s, w i * ⟪x i, Lm A (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
      (a + ∑ i ∈ s, w i * ⟪x i, Lm B (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)) =
      ∑ i ∈ s, (w i * ⟪x i, Lm A (p i) (x i)⟫ - w i * ⟪x i, Lm B (p i) (x i)⟫) +
      ∑ j ∈ t, (w2 j * (⟪v j, Lm A (q j) (u j)⟫ * ⟪u2 j, Lm A (q2 j) (v2 j)⟫) -
        w2 j * (⟪v j, Lm B (q j) (u j)⟫ * ⟪u2 j, Lm B (q2 j) (v2 j)⟫)) := by
    rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib]; ring
  rw [e, add_mul, Finset.sum_mul, Finset.sum_mul]
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum lin)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum quad)

/-- **Per-momentum quadratic term with the named vertex input** `hV1 : ‖V₁ q‖² ≤ CV ω(q)`:
if `|β_q| ≤ ‖V₁ q‖² d_q g_q`, `d_q ≤ c/ω(q)`, `g_q ≤ C/ω(q)`, then `|β_q| ≤ CV C c / ω(q)`. -/
theorem trace_term_bound {beta V1sq om d g CV C c : ℝ} (hom : 0 < om) (hd0 : 0 ≤ d)
    (hg0 : 0 ≤ g) (hCV : 0 ≤ CV) (hV1 : V1sq ≤ CV * om) (_hV0 : 0 ≤ V1sq)
    (hd : d ≤ c / om) (hg : g ≤ C / om) (hb : |beta| ≤ V1sq * d * g) :
    |beta| ≤ CV * C * c / om := by
  have hc : 0 ≤ c / om := hd0.trans hd
  have hC : 0 ≤ C / om := hg0.trans hg
  calc |beta| ≤ V1sq * d * g := hb
    _ ≤ (CV * om) * (c / om) * (C / om) := by gcongr
    _ = CV * C * c / om := by field_simp


end QuadLip

/-! # L6-2: `b_k = Ξ(G_k)` converges for the quadratic one-loop `Ξ` (concrete family of theorem 1)

Paper: A3 / table 10, plan-06 §1. `Ξ` is the quadratic form of `QuadLip.XiQ`
(no extra map: `L = id`), the bracket set is `{A symmetric, −P/ω ≼ A ≼ P/ω}` (`C = 1`), and the
covariances `G_k = 𝓜^k(P/ω)` lie in it: `0 ≼ G_k` (order preservation) and `G_k ≼ P/ω` from
(OS↑) (`OSUpBridge.os_up`, hypothesis `hEE`, i.e. `E_lt_four_s` by the text-matched seam).
Symmetry of the stages is the hypothesis `hsym` (as in `bracket_concrete`); the nonnegativity
of the relative constant is `hL`. Conclusion: that of `CouplingLimit.coupling_converges`. -/

namespace CouplingQuad

open Finset Filter Topology UniformBracket OneStepBridge OneStepET OneStepFinal CouplingLimit
open scoped RealInnerProductSpace

theorem coupling_converges_quadratic
    (hEE : ∀ q : Qpos, ∀ ν, OSUpBridge.EE (fun ν => Real.sin (q.1 ν) ^ 2) ν ≤ 4)
    (hsym : ∀ k q, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q).IsSymmetric)
    (a : ℝ) {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → V)
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Qpos) (v u u2 v2 : κ → V) {L : ℝ} (hL : 0 ≤ L)
    (hLdef : L = ∑ i ∈ s, |w i| * ⟪x i, Pfam Subtype.val (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (1 *
          (((⟪v j, Pfam Subtype.val (q j) (v j)⟫ + ⟪u j, Pfam Subtype.val (q j) (u j)⟫) / 2) *
            ((⟪u2 j, ((omF Subtype.val (q2 j))⁻¹ • Pfam Subtype.val (q2 j)) (u2 j)⟫ +
              ⟪v2 j, ((omF Subtype.val (q2 j))⁻¹ • Pfam Subtype.val (q2 j)) (v2 j)⟫) / 2) +
           ((⟪v j, ((omF Subtype.val (q j))⁻¹ • Pfam Subtype.val (q j)) (v j)⟫ +
              ⟪u j, ((omF Subtype.val (q j))⁻¹ • Pfam Subtype.val (q j)) (u j)⟫) / 2) *
            ((⟪u2 j, Pfam Subtype.val (q2 j) (u2 j)⟫ + ⟪v2 j, Pfam Subtype.val (q2 j) (v2 j)⟫) /
              2)))) :
    ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (429 / 512 : ℝ) ^ k / (1 - 429 / 512)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 429 / 512) ^ 2) := by
  set G0 : Qpos → V →ₗ[ℝ] V := fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q
  set M := Mfam (Subtype.val : Qpos → _) rqPos
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hM : OrderPreserving M := Mfam_orderPreserving _ _
  have h1 : Lw (M G0) G0 := OSUpBridge.os_up Subtype.val rqPos hrq hω hEE
  have hG0sym : ∀ q, (G0 q).IsSymmetric := fun q y z => by
    simp only [G0, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right]
    rw [Pfam_symm Subtype.val q y z]
  have hG0pos : Lw 0 G0 := fun q y => by
    simp only [G0, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω q).le)
      (proj_nonneg (Pfam_symm Subtype.val q) (Pfam_idem Subtype.val q) y)
  have hdec : ∀ k, Lw ((⇑M)^[k] G0) G0 := by
    intro k
    induction k with
    | zero => exact fun _ _ => le_rfl
    | succ k ih => exact fun q y => ((iterate_antitone M hM h1 k) q y).trans (ih q y)
  have hS : ∀ k, (⇑M)^[k] G0 ∈ {A : Qpos → V →ₗ[ℝ] V | QuadLip.SymFam A ∧
      QuadLip.Lw (-((1 : ℝ) • G0)) A ∧ QuadLip.Lw A ((1 : ℝ) • G0)} := by
    intro k
    refine ⟨hsym k, fun q y => ?_, fun q y => ?_⟩
    · have h0 := nonneg_iterate M hM hG0pos k q y
      have hg := hG0pos q y
      simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0 hg
      simp only [one_smul, Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
      linarith
    · simpa only [one_smul] using hdec k q y
  have hΞ := QuadLip.relLip_of_quadratic₂ (LinearMap.id) (fun A B h => h)
    (fun A h => h) (Pfam Subtype.val) (Pfam Subtype.val) (fun _ _ => le_rfl)
    (fun q => Pfam_symm Subtype.val q) G0 G0 (fun _ _ => le_rfl) hG0sym (C := 1) zero_le_one a
    s w p x t w2 q q2 v u u2 v2
  rw [← hLdef] at hΞ
  obtain ⟨binf, hlim, hrate, _, _, _, htr⟩ := coupling_converges
    (QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2) _ hL hS hΞ
  exact ⟨binf, hlim, hrate, htr⟩

end CouplingQuad


-- ===== new part : Coupling35.part.lean =====
/-! # The rate `429/512` replaced by `3/5` (L3(ii), `Mfam_P_le_row`)

Same statements as 
`CouplingLimit.coupling_converges` and `CouplingQuad.coupling_converges_quadratic`, with
`hPstep` from `OneStepBridge.Mfam_P_le_row` (`𝓜P ≼ (3/5)P`) in place of `Mfam_P_le`
(`429/512`). Constants: `2/(1 − 3/5) = 5`, `2/(1 − 3/5)² = 25/2`. -/

noncomputable section

namespace Coupling35

open Finset Filter Topology UniformBracket OneStepBridge OneStepET OneStepFinal CouplingLimit
open scoped RealInnerProductSpace

/-- **b_k → b_∞ with rate `3/5`** (`d = 2`). -/
theorem coupling_converges_35 (Ξ : (Qpos → V →ₗ[ℝ] V) → ℝ) (S : Set (Qpos → V →ₗ[ℝ] V))
    {L : ℝ} (hL : 0 ≤ L)
    (hS : ∀ k, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) ∈ S)
    (hΞ : RelLip Ξ (Pfam Subtype.val) L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (3 / 5 : ℝ) ^ k / (1 - 3 / 5)) ∧
      (∀ k, binf - L * 2 / (1 - 3 / 5) ≤ Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ∧
        Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
          (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ≤ binf + L * 2 / (1 - 3 / 5)) ∧
      Summable (fun k => |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 / (1 - 3 / 5) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 3 / 5) ^ 2) := by
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  exact coupling_limit (Mfam (Subtype.val : Qpos → _) rqPos) (Mfam_orderPreserving _ _)
    (by norm_num) (by norm_num) (by norm_num) hL (Mfam_P_le_row _ _ hrq)
    (D_lower _ _ hrq hω) (D_upper _ _ hrq hω) Ξ S hS hΞ

theorem consts_35 : (2 : ℝ) / (1 - 3 / 5) = 5 ∧ (2 : ℝ) / (1 - 3 / 5) ^ 2 = 25 / 2 := by
  constructor <;> norm_num

/-- **The quadratic one-loop `Ξ` with rate `3/5`** (hypotheses as `coupling_converges_quadratic`). -/
theorem coupling_converges_quadratic_35
    (hEE : ∀ q : Qpos, ∀ ν, OSUpBridge.EE (fun ν => Real.sin (q.1 ν) ^ 2) ν ≤ 4)
    (hsym : ∀ k q, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q).IsSymmetric)
    (a : ℝ) {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → V)
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Qpos) (v u u2 v2 : κ → V) {L : ℝ} (hL : 0 ≤ L)
    (hLdef : L = ∑ i ∈ s, |w i| * ⟪x i, Pfam Subtype.val (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (1 *
          (((⟪v j, Pfam Subtype.val (q j) (v j)⟫ + ⟪u j, Pfam Subtype.val (q j) (u j)⟫) / 2) *
            ((⟪u2 j, ((omF Subtype.val (q2 j))⁻¹ • Pfam Subtype.val (q2 j)) (u2 j)⟫ +
              ⟪v2 j, ((omF Subtype.val (q2 j))⁻¹ • Pfam Subtype.val (q2 j)) (v2 j)⟫) / 2) +
           ((⟪v j, ((omF Subtype.val (q j))⁻¹ • Pfam Subtype.val (q j)) (v j)⟫ +
              ⟪u j, ((omF Subtype.val (q j))⁻¹ • Pfam Subtype.val (q j)) (u j)⟫) / 2) *
            ((⟪u2 j, Pfam Subtype.val (q2 j) (u2 j)⟫ + ⟪v2 j, Pfam Subtype.val (q2 j) (v2 j)⟫) /
              2)))) :
    ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (3 / 5 : ℝ) ^ k / (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 3 / 5) ^ 2) := by
  set G0 : Qpos → V →ₗ[ℝ] V := fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q
  set M := Mfam (Subtype.val : Qpos → _) rqPos
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hM : OrderPreserving M := Mfam_orderPreserving _ _
  have h1 : Lw (M G0) G0 := OSUpBridge.os_up Subtype.val rqPos hrq hω hEE
  have hG0sym : ∀ q, (G0 q).IsSymmetric := fun q y z => by
    simp only [G0, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right]
    rw [Pfam_symm Subtype.val q y z]
  have hG0pos : Lw 0 G0 := fun q y => by
    simp only [G0, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω q).le)
      (proj_nonneg (Pfam_symm Subtype.val q) (Pfam_idem Subtype.val q) y)
  have hdec : ∀ k, Lw ((⇑M)^[k] G0) G0 := by
    intro k
    induction k with
    | zero => exact fun _ _ => le_rfl
    | succ k ih => exact fun q y => ((iterate_antitone M hM h1 k) q y).trans (ih q y)
  have hS : ∀ k, (⇑M)^[k] G0 ∈ {A : Qpos → V →ₗ[ℝ] V | QuadLip.SymFam A ∧
      QuadLip.Lw (-((1 : ℝ) • G0)) A ∧ QuadLip.Lw A ((1 : ℝ) • G0)} := by
    intro k
    refine ⟨hsym k, fun q y => ?_, fun q y => ?_⟩
    · have h0 := nonneg_iterate M hM hG0pos k q y
      have hg := hG0pos q y
      simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0 hg
      simp only [one_smul, Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
      linarith
    · simpa only [one_smul] using hdec k q y
  have hΞ := QuadLip.relLip_of_quadratic₂ (LinearMap.id) (fun A B h => h)
    (fun A h => h) (Pfam Subtype.val) (Pfam Subtype.val) (fun _ _ => le_rfl)
    (fun q => Pfam_symm Subtype.val q) G0 G0 (fun _ _ => le_rfl) hG0sym (C := 1) zero_le_one a
    s w p x t w2 q q2 v u u2 v2
  rw [← hLdef] at hΞ
  obtain ⟨binf, hlim, hrate, _, _, _, htr⟩ := coupling_converges_35
    (QuadLip.XiQ LinearMap.id a s w p x t w2 q q2 v u u2 v2) _ hL hS hΞ
  exact ⟨binf, hlim, hrate, htr⟩

end Coupling35

end



-- ===== new part : QuadLipF.part.lean =====
/-! # `relLip_of_quadratic₃`: the quadratic `Ξ` through a nonlinear `Γ` (plan-10 §2b, plan-11 §2a)

Paper (for checking): `XiQf Γ` is `XiQ` with the linear map `Lm` replaced
by an arbitrary function `Γ` of the family (`Γ_k = G_k − Π G_k Π†`, nonlinear in `G_k`). The proof
of `relLip_of_quadratic₂` uses the order of `Lm` only to push the brackets; here those are the
hypotheses, per pair `(A, B)` of the bracket set:
* `hpush`: `−cP ≼ A − B ≼ cP ⇒ −cP′ ≼ Γ A − Γ B ≼ cP′` (from `Γ A − Γ B = (1−Π_A)(A−B)(1−Π_B)†`,
  `GammaDiff.gam_push`, with `P′ = κ²·1`);
* `hbnd`: `−C Pb′ ≼ Γ A ≼ C Pb′` (from `gamma_norm_le`, `Pb′ = γ∞·1`);
* `hsymΓ`: `Γ A` symmetric. -/

namespace QuadLip

open Finset
open scoped RealInnerProductSpace

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
variable {Q' E' : Type*} [NormedAddCommGroup E'] [InnerProductSpace ℝ E']

/-- The quadratic `Ξ` through an arbitrary `Γ`. -/
noncomputable def XiQf (Γ : (Q → E →ₗ[ℝ] E) → (Q' → E' →ₗ[ℝ] E')) (a : ℝ)
    {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Q') (x : ι → E')
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Q') (v u u2 v2 : κ → E')
    (A : Q → E →ₗ[ℝ] E) : ℝ :=
  a + ∑ i ∈ s, w i * ⟪x i, Γ A (p i) (x i)⟫ +
    ∑ j ∈ t, w2 j * (⟪v j, Γ A (q j) (u j)⟫ * ⟪u2 j, Γ A (q2 j) (v2 j)⟫)

theorem lw_lo {P' D : Q' → E' →ₗ[ℝ] E'} {c : ℝ} (h : Lw (-(c • P')) D) :
    ∀ q x, -(c * ⟪x, P' q x⟫) ≤ ⟪x, D q x⟫ := fun q x => by
  have := h q x
  simpa only [Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
    inner_neg_right, real_inner_smul_right] using this

theorem lw_hi {P' D : Q' → E' →ₗ[ℝ] E'} {c : ℝ} (h : Lw D (c • P')) :
    ∀ q x, ⟪x, D q x⟫ ≤ c * ⟪x, P' q x⟫ := fun q x => by
  have := h q x
  simpa only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] using this

/-- **`relLip_of_quadratic₃`**. -/
theorem relLip_of_quadratic₃ (Γ : (Q → E →ₗ[ℝ] E) → (Q' → E' →ₗ[ℝ] E'))
    (S : Set (Q → E →ₗ[ℝ] E)) (P : Q → E →ₗ[ℝ] E) (P' : Q' → E' →ₗ[ℝ] E') (hP' : SymFam P')
    (Pb' : Q' → E' →ₗ[ℝ] E') (hPb' : SymFam Pb') {C : ℝ}
    (hpush : ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c → Lw (-(c • P)) (A - B) → Lw (A - B) (c • P) →
      Lw (-(c • P')) (Γ A - Γ B) ∧ Lw (Γ A - Γ B) (c • P'))
    (hbnd : ∀ A ∈ S, Lw (-(C • Pb')) (Γ A) ∧ Lw (Γ A) (C • Pb'))
    (hsymΓ : ∀ A ∈ S, SymFam (Γ A)) (a : ℝ)
    {ι κ : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Q') (x : ι → E')
    (t : Finset κ) (w2 : κ → ℝ) (q q2 : κ → Q') (v u u2 v2 : κ → E') :
    RelLip (XiQf Γ a s w p x t w2 q q2 v u u2 v2) P
      (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (C *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)))) S := by
  intro A hA B hB c hc hlo hhi
  obtain ⟨dlo, dhi⟩ := hpush A hA B hB c hc hlo hhi
  obtain ⟨alo, ahi⟩ := hbnd A hA
  obtain ⟨blo, bhi⟩ := hbnd B hB
  have hDsym : SymFam (Γ A - Γ B) := fun q' y z => by
    have h1 := hsymΓ A hA q'; have h2 := hsymΓ B hB q'
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_left, inner_sub_right, h1 y z, h2 y z]
  have eD : ∀ (q' : Q') (y z : E'), ⟪y, Γ A q' z⟫ - ⟪y, Γ B q' z⟫ = ⟪y, (Γ A - Γ B) q' z⟫ :=
    fun q' y z => by rw [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have bD : ∀ (q' : Q') (y z : E'), |⟪y, (Γ A - Γ B) q' z⟫| ≤
      c * (⟪y, P' q' y⟫ + ⟪z, P' q' z⟫) / 2 := fun q' y z =>
    elem_bound _ _ (hDsym q') (hP' q') (lw_lo dlo q') (lw_hi dhi q') y z
  have bA : ∀ (q' : Q') (y z : E'), |⟪y, Γ A q' z⟫| ≤ C * (⟪y, Pb' q' y⟫ + ⟪z, Pb' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsymΓ A hA q') (hPb' q') (lw_lo alo q') (lw_hi ahi q') y z
  have bB : ∀ (q' : Q') (y z : E'), |⟪y, Γ B q' z⟫| ≤ C * (⟪y, Pb' q' y⟫ + ⟪z, Pb' q' z⟫) / 2 :=
    fun q' y z => elem_bound _ _ (hsymΓ B hB q') (hPb' q') (lw_lo blo q') (lw_hi bhi q') y z
  have lin : ∀ i ∈ s, |w i * ⟪x i, Γ A (p i) (x i)⟫ - w i * ⟪x i, Γ B (p i) (x i)⟫| ≤
      |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by
    intro i _
    rw [← mul_sub, abs_mul, eD]
    have := abs_le.mpr ⟨lw_lo dlo (p i) (x i), lw_hi dhi (p i) (x i)⟩
    calc |w i| * |⟪x i, (Γ A - Γ B) (p i) (x i)⟫| ≤ |w i| * (c * ⟪x i, P' (p i) (x i)⟫) :=
          mul_le_mul_of_nonneg_left this (abs_nonneg _)
      _ = |w i| * ⟪x i, P' (p i) (x i)⟫ * c := by ring
  have quad : ∀ j ∈ t, |w2 j * (⟪v j, Γ A (q j) (u j)⟫ * ⟪u2 j, Γ A (q2 j) (v2 j)⟫) -
      w2 j * (⟪v j, Γ B (q j) (u j)⟫ * ⟪u2 j, Γ B (q2 j) (v2 j)⟫)| ≤
      |w2 j| * (C *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2))) * c := by
    intro j _
    set m1 := (⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2
    set m2 := (⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2
    set n1 := (⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2
    set n2 := (⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2
    set a1 := ⟪v j, Γ A (q j) (u j)⟫
    set b1 := ⟪u2 j, Γ A (q2 j) (v2 j)⟫
    set a2 := ⟪v j, Γ B (q j) (u j)⟫
    set b2 := ⟪u2 j, Γ B (q2 j) (v2 j)⟫
    have hda : |a1 - a2| ≤ c * m1 := by
      rw [eD]; have := bD (q j) (v j) (u j); simp only [m1]; linarith
    have hdb : |b1 - b2| ≤ c * m2 := by
      rw [eD]; have := bD (q2 j) (u2 j) (v2 j); simp only [m2]; linarith
    have hb1 : |b1| ≤ C * n2 := by have := bA (q2 j) (u2 j) (v2 j); simp only [n2]; linarith
    have ha2 : |a2| ≤ C * n1 := by have := bB (q j) (v j) (u j); simp only [n1]; linarith
    have key : |a1 * b1 - a2 * b2| ≤ C * (m1 * n2 + n1 * m2) * c := by
      have e : a1 * b1 - a2 * b2 = (a1 - a2) * b1 + a2 * (b1 - b2) := by ring
      rw [e]
      calc |(a1 - a2) * b1 + a2 * (b1 - b2)| ≤ |a1 - a2| * |b1| + |a2| * |b1 - b2| := by
            refine (abs_add_le _ _).trans ?_; rw [abs_mul, abs_mul]
        _ ≤ (c * m1) * (C * n2) + (C * n1) * (c * m2) := add_le_add
            (mul_le_mul hda hb1 (abs_nonneg _) ((abs_nonneg _).trans hda))
            (mul_le_mul ha2 hdb (abs_nonneg _) ((abs_nonneg _).trans ha2))
        _ = C * (m1 * n2 + n1 * m2) * c := by ring
    rw [← mul_sub, abs_mul]
    calc |w2 j| * |a1 * b1 - a2 * b2| ≤ |w2 j| * (C * (m1 * n2 + n1 * m2) * c) :=
          mul_le_mul_of_nonneg_left key (abs_nonneg _)
      _ = |w2 j| * (C * (m1 * n2 + n1 * m2)) * c := by ring
  unfold XiQf
  have e : a + ∑ i ∈ s, w i * ⟪x i, Γ A (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Γ A (q j) (u j)⟫ * ⟪u2 j, Γ A (q2 j) (v2 j)⟫) -
      (a + ∑ i ∈ s, w i * ⟪x i, Γ B (p i) (x i)⟫ +
      ∑ j ∈ t, w2 j * (⟪v j, Γ B (q j) (u j)⟫ * ⟪u2 j, Γ B (q2 j) (v2 j)⟫)) =
      ∑ i ∈ s, (w i * ⟪x i, Γ A (p i) (x i)⟫ - w i * ⟪x i, Γ B (p i) (x i)⟫) +
      ∑ j ∈ t, (w2 j * (⟪v j, Γ A (q j) (u j)⟫ * ⟪u2 j, Γ A (q2 j) (v2 j)⟫) -
        w2 j * (⟪v j, Γ B (q j) (u j)⟫ * ⟪u2 j, Γ B (q2 j) (v2 j)⟫)) := by
    rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib]; ring
  rw [e, add_mul, Finset.sum_mul, Finset.sum_mul]
  refine (abs_add_le _ _).trans (add_le_add ?_ ?_)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum lin)
  · exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum quad)

end QuadLip

-- ===== body of an earlier file (without import and #print axioms) =====

/-! # The difference identity `Γ(A) − Γ(B) = (1 − Π_A)(A − B)(1 − Π_B)†` (plan-11 §1, §2b)

Paper (for checking): `A` is the covariance of a stage (self-adjoint),
`C` the constraint, `E` a lift with `C E = 1` and the KKT relation `Π A = A Π†` (`Π = E C`, as in
 `GammaBound.gamma_eq`). The fluctuation covariance is `Γ(A) = A − Π A Π†`; it is
the same object as `VertexBound.gamma_linear`/`GammaBound.gamma_eq`.
* `gam_eq`: `Γ = A − Π A`; `gam_eq'`: `Γ = A − A Π†`; `C_gam`: `C Γ = 0`; `gam_adj`: `Γ† = Γ`.
* **`gam_sub`**: `Γ(A) − Γ(B) = (1 − Π_A)(A − B)(1 − Π_B)†` (exact; `Π_A Γ(B) = 0`, `Γ(A) Π_B† = 0`).
* **`gam_push`**: if `−cP ≼ A − B ≼ cP`, `⟪u, P u⟫ ≤ ‖u‖²` and `‖(1 − Π)† x‖ ≤ κ‖x‖` for both lifts,
  then `|⟪x, (Γ(A) − Γ(B)) x⟫| ≤ c κ² ‖x‖²` (`P′ = κ²·1` in `relLip_of_quadratic₃`).
`κ` is an argument: `‖1 − Π‖ ≤ 1 + ‖E‖‖C‖` with `‖E‖² ≤ 4 + Kω` from (T4) for every `h` of the
bracket. -/

namespace GammaDiff

open LinearMap
open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

/-- `Π = E C`. -/
def Pi (C : V →ₗ[ℝ] W) (E : W →ₗ[ℝ] V) : V →ₗ[ℝ] V := E ∘ₗ C

/-- `Γ(A) = A − Π A Π†`. -/
noncomputable def Gam (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) : V →ₗ[ℝ] V :=
  A - Pi C E ∘ₗ A ∘ₗ adjoint (Pi C E)

variable (C : V →ₗ[ℝ] W) (A B : V →ₗ[ℝ] V) (EA EB : W →ₗ[ℝ] V)

theorem C_Pi (hCE : C ∘ₗ EA = LinearMap.id) : C ∘ₗ Pi C EA = C := by
  unfold Pi; rw [← LinearMap.comp_assoc, hCE, LinearMap.id_comp]

theorem Pi_idem (hCE : C ∘ₗ EA = LinearMap.id) : Pi C EA ∘ₗ Pi C EA = Pi C EA := by
  conv_lhs => rw [show Pi C EA ∘ₗ Pi C EA = EA ∘ₗ (C ∘ₗ Pi C EA) by rfl]
  rw [C_Pi C EA hCE]; rfl

theorem gam_eq (hCE : C ∘ₗ EA = LinearMap.id)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA = A - Pi C EA ∘ₗ A := by
  unfold Gam
  rw [← hkkt, ← LinearMap.comp_assoc, Pi_idem C EA hCE]

theorem gam_eq' (hCE : C ∘ₗ EA = LinearMap.id)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA = A - A ∘ₗ adjoint (Pi C EA) := by
  rw [gam_eq C A EA hCE hkkt, hkkt]

theorem C_gam (hCE : C ∘ₗ EA = LinearMap.id)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    C ∘ₗ Gam C A EA = 0 := by
  rw [gam_eq C A EA hCE hkkt, LinearMap.comp_sub, ← LinearMap.comp_assoc, C_Pi C EA hCE, sub_self]

theorem gam_adj (hA : adjoint A = A) (hCE : C ∘ₗ EA = LinearMap.id)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    adjoint (Gam C A EA) = Gam C A EA := by
  rw [gam_eq C A EA hCE hkkt, map_sub, LinearMap.adjoint_comp, hA, ← gam_eq' C A EA hCE hkkt,
    gam_eq C A EA hCE hkkt]

theorem gam_Cadj (hA : adjoint A = A) (hCE : C ∘ₗ EA = LinearMap.id)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA ∘ₗ adjoint C = 0 := by
  have h := congrArg adjoint (C_gam C A EA hCE hkkt)
  rw [LinearMap.adjoint_comp, gam_adj C A EA hA hCE hkkt, map_zero] at h
  exact h

/-- **`Γ(A) − Γ(B) = (1 − Π_A)(A − B)(1 − Π_B)†`**. -/
theorem gam_sub (hA : adjoint A = A) (hCEA : C ∘ₗ EA = LinearMap.id)
    (hkA : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA))
    (hCEB : C ∘ₗ EB = LinearMap.id) (hkB : Pi C EB ∘ₗ B = B ∘ₗ adjoint (Pi C EB)) :
    Gam C A EA - Gam C B EB =
      (LinearMap.id - Pi C EA) ∘ₗ (A - B) ∘ₗ adjoint (LinearMap.id - Pi C EB) := by
  -- `(1 − Π_A) A = Γ_A`, `B (1 − Π_B)† = Γ_B`
  have e1 : (LinearMap.id - Pi C EA) ∘ₗ A = Gam C A EA := by
    rw [gam_eq C A EA hCEA hkA, LinearMap.sub_comp, LinearMap.id_comp]
  have e2 : B ∘ₗ adjoint (LinearMap.id - Pi C EB) = Gam C B EB := by
    rw [gam_eq' C B EB hCEB hkB, map_sub, LinearMap.adjoint_id, LinearMap.comp_sub,
      LinearMap.comp_id]
  -- `Γ_A Π_B† = 0`, `Π_A Γ_B = 0`
  have z1 : Gam C A EA ∘ₗ adjoint (Pi C EB) = 0 := by
    unfold Pi
    rw [LinearMap.adjoint_comp, ← LinearMap.comp_assoc, gam_Cadj C A EA hA hCEA hkA,
      LinearMap.zero_comp]
  have z2 : Pi C EA ∘ₗ Gam C B EB = 0 := by
    unfold Pi
    rw [LinearMap.comp_assoc, C_gam C B EB hCEB hkB, LinearMap.comp_zero]
  have hX : adjoint (LinearMap.id - Pi C EB) = LinearMap.id - adjoint (Pi C EB) := by
    rw [map_sub, LinearMap.adjoint_id]
  have p1 : ∀ y, ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) (A y) = Gam C A EA y := fun y => by
    rw [← e1]; rfl
  have p2 : ∀ y, B (adjoint (LinearMap.id - Pi C EB) y) = Gam C B EB y := fun y => by
    rw [← e2]; rfl
  have p3 : ∀ y, Gam C A EA (adjoint (LinearMap.id - Pi C EB) y) = Gam C A EA y := fun y => by
    have h0 := LinearMap.congr_fun z1 y
    simp only [LinearMap.comp_apply, LinearMap.zero_apply] at h0
    rw [hX, LinearMap.sub_apply, LinearMap.id_apply, map_sub, h0, sub_zero]
  have p4 : ∀ y, ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) (Gam C B EB y) = Gam C B EB y := fun y => by
    have h0 := LinearMap.congr_fun z2 y
    simp only [LinearMap.comp_apply, LinearMap.zero_apply] at h0
    rw [LinearMap.sub_apply, LinearMap.id_apply, h0, sub_zero]
  set X := adjoint (LinearMap.id - Pi C EB) with hXdef
  ext y
  show Gam C A EA y - Gam C B EB y = ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) ((A - B) (X y))
  rw [LinearMap.sub_apply A B (X y), map_sub, p1, p2, p3, p4]

/-- Matrix elements of a symmetric `D` with `−cP ≼ D ≼ cP` (= `QuadLip.elem_bound`). -/
theorem elem_bound' (D P : V →ₗ[ℝ] V) (hD : D.IsSymmetric) (hP : P.IsSymmetric) {c : ℝ}
    (hlo : ∀ x, -(c * ⟪x, P x⟫) ≤ ⟪x, D x⟫) (hhi : ∀ x, ⟪x, D x⟫ ≤ c * ⟪x, P x⟫) (v u : V) :
    |⟪v, D u⟫| ≤ c * (⟪v, P v⟫ + ⟪u, P u⟫) / 2 := by
  have pol : ∀ T : V →ₗ[ℝ] V, T.IsSymmetric →
      ⟪v + u, T (v + u)⟫ - ⟪v - u, T (v - u)⟫ = 4 * ⟪v, T u⟫ ∧
      ⟪v + u, T (v + u)⟫ + ⟪v - u, T (v - u)⟫ = 2 * ⟪v, T v⟫ + 2 * ⟪u, T u⟫ := by
    intro T hT
    have h1 : ⟪u, T v⟫ = ⟪v, T u⟫ := by rw [← hT, real_inner_comm]
    simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left,
      inner_sub_right]
    constructor <;> linarith
  obtain ⟨d1, d2⟩ := pol D hD
  obtain ⟨_, p2⟩ := pol P hP
  have a1 := hhi (v + u); have a2 := hlo (v - u)
  have b1 := hlo (v + u); have b2 := hhi (v - u)
  have cp : c * (⟪v + u, P (v + u)⟫ + ⟪v - u, P (v - u)⟫) =
      c * (2 * ⟪v, P v⟫ + 2 * ⟪u, P u⟫) := by rw [p2]
  rw [abs_le]; constructor <;> nlinarith

/-- **The push of the bracket through `Γ`**: `|⟪x, (Γ_A − Γ_B) x⟫| ≤ c κ² ‖x‖²`. -/
theorem gam_push (hA : adjoint A = A) (hB : adjoint B = B) (hCEA : C ∘ₗ EA = LinearMap.id)
    (hkA : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA))
    (hCEB : C ∘ₗ EB = LinearMap.id) (hkB : Pi C EB ∘ₗ B = B ∘ₗ adjoint (Pi C EB))
    (P : V →ₗ[ℝ] V) (hP : P.IsSymmetric) (hP1 : ∀ u, ⟪u, P u⟫ ≤ ‖u‖ ^ 2) {c κ : ℝ} (hc : 0 ≤ c)
    (hκA : ∀ x, ‖adjoint (LinearMap.id - Pi C EA) x‖ ≤ κ * ‖x‖)
    (hκB : ∀ x, ‖adjoint (LinearMap.id - Pi C EB) x‖ ≤ κ * ‖x‖)
    (hlo : ∀ x, -(c * ⟪x, P x⟫) ≤ ⟪x, (A - B) x⟫) (hhi : ∀ x, ⟪x, (A - B) x⟫ ≤ c * ⟪x, P x⟫)
    (x : V) : |⟪x, (Gam C A EA - Gam C B EB) x⟫| ≤ c * κ ^ 2 * ‖x‖ ^ 2 := by
  rw [gam_sub C A B EA EB hA hCEA hkA hCEB hkB]
  set u := adjoint (LinearMap.id - Pi C EA) x
  set v := adjoint (LinearMap.id - Pi C EB) x
  have e : ⟪x, ((LinearMap.id - Pi C EA) ∘ₗ (A - B) ∘ₗ adjoint (LinearMap.id - Pi C EB)) x⟫ =
      ⟪u, (A - B) v⟫ := by
    simp only [LinearMap.comp_apply, u, v]
    rw [← LinearMap.adjoint_inner_left]
  rw [e]
  have hDs : (A - B).IsSymmetric := by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    show adjoint (A - B) = A - B
    rw [map_sub, hA, hB]
  have hb := elem_bound' (A - B) P hDs hP hlo hhi u v
  have hu := hP1 u; have hv := hP1 v
  have hu2 : ‖u‖ ^ 2 ≤ (κ * ‖x‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hκA x) 2
  have hv2 : ‖v‖ ^ 2 ≤ (κ * ‖x‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hκB x) 2
  have : c * (⟪u, P u⟫ + ⟪v, P v⟫) / 2 ≤ c * κ ^ 2 * ‖x‖ ^ 2 := by
    have h2 : ⟪u, P u⟫ + ⟪v, P v⟫ ≤ 2 * (κ ^ 2 * ‖x‖ ^ 2) := by nlinarith
    have := mul_le_mul_of_nonneg_left h2 hc
    nlinarith
  linarith

end GammaDiff



-- ===== new part : CouplingGamma.part.lean =====
/-! # L6-3: `b_k = Ξ(Γ_k)` converges with rate `3/5` (plan-11 §2c)

Paper (for checking): `Γ_k = G_k − Π_k G_k Π_k†` (`Π_k = E_k C`, `E_k` the
minimal lift of `h_k = G_k⁻¹`; (2): the same object as b_k's one-loop).
`Ξ = XiQf Γ` (quadratic in `Γ`). Inputs (named hypotheses): `hCE` (`C E = 1`), `hkkt` (`Π A = A Π†`),
`hκ` (`‖(1 − Π)†‖ ≤ κ`, uniform from (T4)), `hbnd` (`0 ≼ Γ(A) ≼ γ∞·1`, from `gamma_norm_le`),
on the bracket set `S = {A sym, −G₀ ≼ A ≼ G₀}`, plus `hEE`, `hsym` as in
`coupling_converges_quadratic`. Conclusion: that of `coupling_converges_35` with
`L′ = κ² (Σ|w_i| ‖x_i‖² + γ∞ Σ|w2_j| (‖v_j‖² + ‖u_j‖²)(‖u2_j‖² + ‖v2_j‖²)/2)`
(independent of the momenta and of the box). -/

noncomputable section

namespace CouplingGamma

open Finset Filter Topology UniformBracket OneStepBridge OneStepET OneStepFinal CouplingLimit
open scoped RealInnerProductSpace

theorem inner_P_le_norm (q : Qpos) (u : V) : ⟪u, Pfam Subtype.val q u⟫ ≤ ‖u‖ ^ 2 := by
  have hs := Pfam_symm Subtype.val q
  have hi := Pfam_idem Subtype.val q
  have e : ⟪u, Pfam Subtype.val q u⟫ = ‖Pfam Subtype.val q u‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq]
    conv_lhs => rw [← hi u]
    rw [hs]
  have hcs : ⟪u, Pfam Subtype.val q u⟫ ≤ ‖u‖ * ‖Pfam Subtype.val q u‖ := real_inner_le_norm _ _
  rw [e] at hcs ⊢
  have h0 := norm_nonneg (Pfam Subtype.val q u)
  have h1 := norm_nonneg u
  have hle : ‖Pfam Subtype.val q u‖ ≤ ‖u‖ := by
    rcases eq_or_lt_of_le h0 with h | h
    · rw [← h]; exact h1
    · nlinarith
  nlinarith

variable {W : Type*} [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

/-- The fluctuation covariance of a family. -/
def GamF (Cq : Qpos → V →ₗ[ℝ] W) (Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → W →ₗ[ℝ] V)
    (A : Qpos → V →ₗ[ℝ] V) : Qpos → V →ₗ[ℝ] V :=
  fun q => GammaDiff.Gam (Cq q) (A q) (Esel A q)

/-- The constant `L′`. -/
def Lgam (κ γ : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (x : ι → V)
    (t : Finset κ') (w2 : κ' → ℝ) (v u u2 v2 : κ' → V) : ℝ :=
  κ ^ 2 * (∑ i ∈ s, |w i| * ‖x i‖ ^ 2 +
    γ * ∑ j ∈ t, |w2 j| * ((‖v j‖ ^ 2 + ‖u j‖ ^ 2) * (‖u2 j‖ ^ 2 + ‖v2 j‖ ^ 2) / 2))

theorem coupling_converges_gamma
    (hEE : ∀ q : Qpos, ∀ ν, OSUpBridge.EE (fun ν => Real.sin (q.1 ν) ^ 2) ν ≤ 4)
    (hsym : ∀ k q, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q).IsSymmetric)
    (Cq : Qpos → V →ₗ[ℝ] W) (Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → W →ₗ[ℝ] V) {κ γ : ℝ}
    (hγ : 0 ≤ γ)
    (hCE : ∀ A : Qpos → V →ₗ[ℝ] V, QuadLip.SymFam A →
      ∀ q, Cq q ∘ₗ Esel A q = LinearMap.id)
    (hkkt : ∀ A : Qpos → V →ₗ[ℝ] V, QuadLip.SymFam A → ∀ q,
      GammaDiff.Pi (Cq q) (Esel A q) ∘ₗ A q = A q ∘ₗ LinearMap.adjoint (GammaDiff.Pi (Cq q) (Esel A q)))
    (hκ : ∀ A : Qpos → V →ₗ[ℝ] V, QuadLip.SymFam A → ∀ q x,
      ‖LinearMap.adjoint (LinearMap.id - GammaDiff.Pi (Cq q) (Esel A q)) x‖ ≤ κ * ‖x‖)
    (hbnd : ∀ A : Qpos → V →ₗ[ℝ] V, QuadLip.SymFam A →
      QuadLip.Lw (-((fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) A →
      QuadLip.Lw A (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) →
      ∀ q x, -(γ * ⟪x, x⟫) ≤ ⟪x, GamF Cq Esel A q x⟫ ∧ ⟪x, GamF Cq Esel A q x⟫ ≤ γ * ⟪x, x⟫)
    (a : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → V)
    (t : Finset κ') (w2 : κ' → ℝ) (q q2 : κ' → Qpos) (v u u2 v2 : κ' → V) :
    ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          Lgam κ γ s w x t w2 v u u2 v2 * 2 * (3 / 5 : ℝ) ^ k / (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2
        ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          Lgam κ γ s w x t w2 v u u2 v2 * 2 / (1 - 3 / 5) ^ 2) := by
  set G0 : Qpos → V →ₗ[ℝ] V := fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q
  set M := Mfam (Subtype.val : Qpos → _) rqPos
  set S := {A : Qpos → V →ₗ[ℝ] V | QuadLip.SymFam A ∧
      QuadLip.Lw (-((1 : ℝ) • G0)) A ∧ QuadLip.Lw A ((1 : ℝ) • G0)} with hSdef
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hM : OrderPreserving M := Mfam_orderPreserving _ _
  have h1 : Lw (M G0) G0 := OSUpBridge.os_up Subtype.val rqPos hrq hω hEE
  have hG0pos : Lw 0 G0 := fun q y => by
    simp only [G0, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω q).le)
      (proj_nonneg (Pfam_symm Subtype.val q) (Pfam_idem Subtype.val q) y)
  have hdec : ∀ k, Lw ((⇑M)^[k] G0) G0 := by
    intro k
    induction k with
    | zero => exact fun _ _ => le_rfl
    | succ k ih => exact fun q y => ((iterate_antitone M hM h1 k) q y).trans (ih q y)
  have hS : ∀ k, (⇑M)^[k] G0 ∈ S := by
    intro k
    refine ⟨hsym k, fun q y => ?_, fun q y => ?_⟩
    · have h0 := nonneg_iterate M hM hG0pos k q y
      have hg := hG0pos q y
      simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0 hg
      simp only [one_smul, Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
      linarith
    · simpa only [one_smul] using hdec k q y
  have hadj : ∀ A : Qpos → V →ₗ[ℝ] V, QuadLip.SymFam A → ∀ q, LinearMap.adjoint (A q) = A q :=
    fun A hA q => ((LinearMap.isSymmetric_iff_isSelfAdjoint (A q)).mp (hA q))
  set P' : Qpos → V →ₗ[ℝ] V := fun _ => (κ ^ 2) • LinearMap.id
  set Pb' : Qpos → V →ₗ[ℝ] V := fun _ => LinearMap.id
  have hP' : QuadLip.SymFam P' := fun _ y z => by
    simp only [P', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_left,
      real_inner_smul_right]
  have hPb' : QuadLip.SymFam Pb' := fun _ y z => by simp only [Pb', LinearMap.id_apply]
  have hsymΓ : ∀ A ∈ S, QuadLip.SymFam (GamF Cq Esel A) := fun A hA q => by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    exact GammaDiff.gam_adj (Cq q) (A q) (Esel A q) (hadj A hA.1 q) (hCE A hA.1 q) (hkkt A hA.1 q)
  have hpush : ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c →
      QuadLip.Lw (-(c • Pfam Subtype.val)) (A - B) → QuadLip.Lw (A - B) (c • Pfam Subtype.val) →
      QuadLip.Lw (-(c • P')) (GamF Cq Esel A - GamF Cq Esel B) ∧
        QuadLip.Lw (GamF Cq Esel A - GamF Cq Esel B) (c • P') := by
    intro A hA B hB c hc hlo hhi
    have key : ∀ q y, |⟪y, (GamF Cq Esel A - GamF Cq Esel B) q y⟫| ≤ c * κ ^ 2 * ‖y‖ ^ 2 := by
      intro q y
      have hl : ∀ x, -(c * ⟪x, Pfam Subtype.val q x⟫) ≤ ⟪x, (A q - B q) x⟫ := fun x => by
        have := hlo q x
        simpa only [Pi.neg_apply, Pi.smul_apply, Pi.sub_apply, LinearMap.neg_apply,
          LinearMap.smul_apply, inner_neg_right, real_inner_smul_right] using this
      have hh : ∀ x, ⟪x, (A q - B q) x⟫ ≤ c * ⟪x, Pfam Subtype.val q x⟫ := fun x => by
        have := hhi q x
        simpa only [Pi.smul_apply, Pi.sub_apply, LinearMap.smul_apply,
          real_inner_smul_right] using this
      have := GammaDiff.gam_push (Cq q) (A q) (B q) (Esel A q) (Esel B q) (hadj A hA.1 q)
        (hadj B hB.1 q) (hCE A hA.1 q) (hkkt A hA.1 q) (hCE B hB.1 q) (hkkt B hB.1 q)
        (Pfam Subtype.val q) (Pfam_symm Subtype.val q) (inner_P_le_norm q) hc
        (hκ A hA.1 q) (hκ B hB.1 q) hl hh y
      simpa only [GamF, Pi.sub_apply] using this
    constructor
    · intro q y
      have := (abs_le.mp (key q y)).1
      simp only [P', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
    · intro q y
      have := (abs_le.mp (key q y)).2
      simp only [P', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
  have hbnd' : ∀ A ∈ S, QuadLip.Lw (-(γ • Pb')) (GamF Cq Esel A) ∧
      QuadLip.Lw (GamF Cq Esel A) (γ • Pb') := by
    intro A hA
    have hlo : QuadLip.Lw (-G0) A := fun q y => by
      have := hA.2.1 q y; simpa only [one_smul] using this
    have hhi : QuadLip.Lw A G0 := fun q y => by
      have := hA.2.2 q y; simpa only [one_smul] using this
    have hb := hbnd A hA.1 hlo hhi
    constructor
    · intro q y
      simp only [Pb', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right]
      exact (hb q y).1
    · intro q y
      simp only [Pb', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right]
      exact (hb q y).2
  have hΞ := QuadLip.relLip_of_quadratic₃ (GamF Cq Esel) S (Pfam Subtype.val) P' hP' Pb' hPb'
    hpush hbnd' hsymΓ a s w p x t w2 q q2 v u u2 v2
  have hLeq : (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (γ *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)))) =
      Lgam κ γ s w x t w2 v u u2 v2 := by
    simp only [P', Pb', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_right,
      real_inner_self_eq_norm_sq, Lgam]
    rw [mul_add, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
    congr 1
    · exact Finset.sum_congr rfl fun i _ => by ring
    · exact Finset.sum_congr rfl fun j _ => by ring
  rw [hLeq] at hΞ
  have hL0 : 0 ≤ Lgam κ γ s w x t w2 v u u2 v2 := by
    unfold Lgam
    apply mul_nonneg (sq_nonneg _)
    apply add_nonneg
    · exact Finset.sum_nonneg fun i _ => mul_nonneg (abs_nonneg _) (sq_nonneg _)
    · exact mul_nonneg hγ (Finset.sum_nonneg fun j _ => mul_nonneg (abs_nonneg _)
        (div_nonneg (mul_nonneg (by positivity) (by positivity)) (by norm_num)))
  obtain ⟨binf, hlim, hrate, _, _, _, htr⟩ := Coupling35.coupling_converges_35
    (QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2) S hL0 hS hΞ
  exact ⟨binf, hlim, hrate, htr⟩

end CouplingGamma

end


-- ===== body of an earlier file (without import and #print axioms) =====

/-! # Paying `κ` and `γ∞` of `coupling_converges_gamma` (plan-18 §1.2, §1.3)


* **`kappa_of_lift`**: `‖E w‖ ≤ e‖w‖`, `‖C v‖ ≤ c‖v‖` ⇒ `‖(1 − E C)† x‖ ≤ (1 + e c)‖x‖`
  (finite dimension, `LinearMap.adjoint`; the input `hκ` of `coupling_converges_gamma`).
  `kappa_value`: with `‖E‖² ≤ 4 + 16K` ((T4), `ω ≤ 16`) and `‖C‖² ≤ 4` (`CNormSq.C_normSq_le`),
  `κ = 1 + 2√(4 + 16K)`.
* `alias_lower_H`: on the alias `ζ ≠ ζ*` the bracket `(ω/745)P ≼ ¼H` (`lattice_bracket`) and
  `ω(r_ζ) ≥ 2` (`omR_far`) give `(8/745)|a_ζ|² ≤ H_ζ(a_ζ)` — the `hhm` of `ker_poincare` with
  `m = 8/745` for **`H`** (not `h = ¼H`). With `Pc = 1 + C_N` (`C_N_value`), `gamma_norm_le`
  gives **`γ∞ = (1 + C_N)·745/8`**; `gamma_infty_value`: `= 69241·745/968` (`C_N = 69120/121`). -/

namespace KappaGamma

open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

theorem kappa_of_lift (C : V →ₗ[ℝ] W) (E : W →ₗ[ℝ] V) {e c : ℝ} (he : 0 ≤ e) (hc : 0 ≤ c)
    (hE : ∀ w, ‖E w‖ ≤ e * ‖w‖) (hC : ∀ v, ‖C v‖ ≤ c * ‖v‖) (x : V) :
    ‖LinearMap.adjoint (LinearMap.id - E ∘ₗ C) x‖ ≤ (1 + e * c) * ‖x‖ := by
  set A : V →ₗ[ℝ] V := LinearMap.id - E ∘ₗ C
  set y := LinearMap.adjoint A x
  have hA : ∀ v, ‖A v‖ ≤ (1 + e * c) * ‖v‖ := by
    intro v
    simp only [A, LinearMap.sub_apply, LinearMap.id_apply, LinearMap.comp_apply]
    calc ‖v - E (C v)‖ ≤ ‖v‖ + ‖E (C v)‖ := norm_sub_le _ _
      _ ≤ ‖v‖ + e * (c * ‖v‖) := by
          have := (hE (C v)).trans (mul_le_mul_of_nonneg_left (hC v) he); linarith
      _ = (1 + e * c) * ‖v‖ := by ring
  have h1 : ‖y‖ ^ 2 = ⟪x, A y⟫ := by
    rw [← real_inner_self_eq_norm_sq, LinearMap.adjoint_inner_left]
  have h2 : ⟪x, A y⟫ ≤ ‖x‖ * ((1 + e * c) * ‖y‖) :=
    (real_inner_le_norm _ _).trans (mul_le_mul_of_nonneg_left (hA y) (norm_nonneg _))
  have hy := norm_nonneg y
  have hx := norm_nonneg x
  have hk : 0 ≤ 1 + e * c := by positivity
  rcases eq_or_lt_of_le hy with h0 | hpos
  · rw [← h0]; positivity
  · nlinarith

theorem kappa_value (C : V →ₗ[ℝ] W) (E : W →ₗ[ℝ] V) {K : ℝ} (hK : 0 ≤ K)
    (hE : ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2) (hC : ∀ v, ‖C v‖ ^ 2 ≤ 4 * ‖v‖ ^ 2) (x : V) :
    ‖LinearMap.adjoint (LinearMap.id - E ∘ₗ C) x‖ ≤ (1 + 2 * Real.sqrt (4 + 16 * K)) * ‖x‖ := by
  have hE' : ∀ w, ‖E w‖ ≤ Real.sqrt (4 + 16 * K) * ‖w‖ := fun w => by
    rw [← Real.sqrt_sq (norm_nonneg (E w)), ← Real.sqrt_sq (norm_nonneg w), ← Real.sqrt_mul
      (by positivity)]
    exact Real.sqrt_le_sqrt (hE w)
  have hC' : ∀ v, ‖C v‖ ≤ 2 * ‖v‖ := fun v => by
    have := hC v
    nlinarith [norm_nonneg (C v), norm_nonneg v]
  have := kappa_of_lift C E (Real.sqrt_nonneg _) (by norm_num) hE' hC' x
  have e : (1 + Real.sqrt (4 + 16 * K) * 2) = 1 + 2 * Real.sqrt (4 + 16 * K) := by ring
  rwa [e] at this

/-- The alias lower bound for `H` (no `¼`): `(8/745)|a|² ≤ H`. -/
theorem alias_lower_H {om Ha na : ℝ} (hbr : om / 745 * na ≤ (1 / 4) * Ha) (hom : 2 ≤ om)
    (hna : 0 ≤ na) : 8 / 745 * na ≤ Ha := by
  nlinarith

theorem gamma_infty_value : (1 + 69120 / 121 : ℝ) / (8 / 745) = 69241 * 745 / 968 ∧
    (69241 * 745 / 968 : ℝ) ≤ 53300 := by
  constructor <;> norm_num

end KappaGamma



-- ===== new part : LiftPsd =====
/-! # The KKT lift for every positive semidefinite `A` (gauge directions allowed)

Paper (for checking): (for "CE・KKT").
`A` symmetric and positive semidefinite (no invertibility: `ker A` may contain the gauge
directions `ker P`), `C` onto. With `T = C A C†`:
* `null_of_psd`: `⟪y, A y⟫ = 0 ⇒ A y = 0`; hence `ker T ⊆ ker (A C†)` and
  `ran (C A) = (ker (A C†))ᗮ ⊆ (ker T)ᗮ = ran T`.
* **`psd_kkt_lift`**: there is `E` with `C E = 1` and `Π A = A Π†` (`Π = E C`): on `ran T` put
  `E = A C† g` (`T g = 1` there), on a complement any right inverse of `C`. The symmetry of
  `E C A` uses only `T g = 1` on `ran T`: `⟪A C†μ, y⟫ = ⟪μ, T ν⟫ = ⟪T μ, ν⟫ = ⟪x, A C†ν⟫`.
* `pi_A_indep`, **`gam_indep`**: `Π A` and `Γ(A) = A − Π A Π†` do not depend on the choice of the
  lift (any two lifts with `C E = 1` and the KKT relation).
* **`gam_nonneg`**, **`gam_le`**: `0 ≼ Γ(A) ≼ A` (so the lower side `−γ∞` of `hbnd` is free).
This replaces the invertibility of `A` in `LiftOnS.lift_on_S` (the "ran P only" point of
 is no longer a convention). -/

namespace LiftPsd

open GammaDiff
open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

theorem null_of_psd (A : V →ₗ[ℝ] V) (hAs : A.IsSymmetric) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫) {y : V}
    (hy : ⟪y, A y⟫ = 0) : A y = 0 := by
  have key : ∀ z, ⟪z, A y⟫ = 0 := by
    intro z
    have hs : ⟪y, A z⟫ = ⟪z, A y⟫ := by rw [← hAs, real_inner_comm]
    have lin : ∀ t : ℝ, 0 ≤ 2 * t * ⟪z, A y⟫ + ⟪z, A z⟫ := by
      intro t
      have h1 := hAp (t • y + z)
      simp only [map_add, map_smul, inner_add_left, inner_add_right, real_inner_smul_left,
        real_inner_smul_right] at h1
      rw [hy, hs] at h1
      nlinarith
    by_contra hne
    have h1 := lin (-(⟪z, A z⟫ + 1) / (2 * ⟪z, A y⟫))
    have h2 : 2 * (-(⟪z, A z⟫ + 1) / (2 * ⟪z, A y⟫)) * ⟪z, A y⟫ = -(⟪z, A z⟫ + 1) := by
      field_simp
    linarith
  exact inner_self_eq_zero.mp (key (A y))

/-- **The KKT lift for a positive semidefinite `A`**. -/
theorem psd_kkt_lift (C : V →ₗ[ℝ] W) (hsurj : Function.Surjective C) (A : V →ₗ[ℝ] V)
    (hAs : A.IsSymmetric) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫) :
    ∃ E : W →ₗ[ℝ] V, C ∘ₗ E = LinearMap.id ∧
      Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E) := by
  have hA' : LinearMap.adjoint A = A := (LinearMap.isSymmetric_iff_isSelfAdjoint A).mp hAs
  set T : W →ₗ[ℝ] W := C ∘ₗ A ∘ₗ LinearMap.adjoint C with hT
  have hTapp : ∀ l, T l = C (A (LinearMap.adjoint C l)) := fun _ => rfl
  have hker : LinearMap.ker T ≤ LinearMap.ker (A ∘ₗ LinearMap.adjoint C) := by
    intro l hl
    rw [LinearMap.mem_ker] at hl ⊢
    apply null_of_psd A hAs hAp
    have e := LinearMap.adjoint_inner_left C (A (LinearMap.adjoint C l)) l
    rw [← hTapp, hl, inner_zero_right] at e
    exact e
  have hTadj : LinearMap.adjoint T = T := by
    rw [hT, LinearMap.adjoint_comp, LinearMap.adjoint_comp, LinearMap.adjoint_adjoint, hA']
    rfl
  have hCAadj : LinearMap.adjoint (A ∘ₗ LinearMap.adjoint C) = C ∘ₗ A := by
    rw [LinearMap.adjoint_comp, LinearMap.adjoint_adjoint, hA']
  have hran : LinearMap.range (C ∘ₗ A) ≤ LinearMap.range T := by
    rw [← hCAadj, ← LinearMap.orthogonal_ker, ← hTadj, ← LinearMap.orthogonal_ker]
    exact Submodule.orthogonal_le hker
  obtain ⟨g, hg⟩ := T.rangeRestrict.exists_rightInverse_of_surjective T.range_rangeRestrict
  obtain ⟨U', hU⟩ := (LinearMap.range T).exists_isCompl
  obtain ⟨E₀, hE₀⟩ := C.exists_rightInverse_of_surjective (LinearMap.range_eq_top.mpr hsurj)
  set E : W →ₗ[ℝ] V :=
    LinearMap.ofIsCompl hU (A ∘ₗ LinearMap.adjoint C ∘ₗ g) (E₀ ∘ₗ U'.subtype) with hEdef
  have hTg : ∀ u : LinearMap.range T, T (g u) = u := by
    intro u
    have := LinearMap.congr_fun hg u
    exact congrArg Subtype.val this
  have hEU : ∀ u : LinearMap.range T, E u = A (LinearMap.adjoint C (g u)) := fun u =>
    LinearMap.ofIsCompl_apply_left hU u
  have hCE : C ∘ₗ E = LinearMap.id := by
    apply LinearMap.ext; intro w
    have hw : w ∈ LinearMap.range T ⊔ U' := by rw [hU.sup_eq_top]; trivial
    obtain ⟨u, hu, u', hu', rfl⟩ := Submodule.mem_sup.mp hw
    have e2 : E u' = E₀ u' := LinearMap.ofIsCompl_apply_right hU ⟨u', hu'⟩
    simp only [LinearMap.comp_apply, LinearMap.id_apply, map_add]
    rw [show u = ((⟨u, hu⟩ : LinearMap.range T) : W) from rfl, hEU, e2]
    congr 1
    · exact hTg ⟨u, hu⟩
    · exact LinearMap.congr_fun hE₀ u'
  have hPA : ∀ x y, ⟪E (C (A x)), y⟫ = ⟪x, E (C (A y))⟫ := by
    intro x y
    have hx : C (A x) ∈ LinearMap.range T := hran ⟨x, rfl⟩
    have hy : C (A y) ∈ LinearMap.range T := hran ⟨y, rfl⟩
    have ex : E (C (A x)) = A (LinearMap.adjoint C (g ⟨_, hx⟩)) := hEU ⟨_, hx⟩
    have ey : E (C (A y)) = A (LinearMap.adjoint C (g ⟨_, hy⟩)) := hEU ⟨_, hy⟩
    have tx : T (g ⟨_, hx⟩) = C (A x) := hTg ⟨_, hx⟩
    have ty : T (g ⟨_, hy⟩) = C (A y) := hTg ⟨_, hy⟩
    rw [ex, ey]
    generalize g ⟨_, hx⟩ = μ at tx ⊢
    generalize g ⟨_, hy⟩ = ν at ty ⊢
    have s1 : ⟪A (LinearMap.adjoint C μ), y⟫ = ⟪μ, C (A y)⟫ := by
      rw [hAs, LinearMap.adjoint_inner_left]
    have s2 : ⟪x, A (LinearMap.adjoint C ν)⟫ = ⟪C (A x), ν⟫ := by
      rw [← hAs, LinearMap.adjoint_inner_right]
    have s3 : ⟪T μ, ν⟫ = ⟪μ, T ν⟫ := by
      rw [hTapp, hTapp, ← LinearMap.adjoint_inner_right, hAs, LinearMap.adjoint_inner_left]
    rw [s1, s2, ← tx, ← ty, s3]
  refine ⟨E, hCE, ?_⟩
  show (E ∘ₗ C) ∘ₗ A = A ∘ₗ LinearMap.adjoint (E ∘ₗ C)
  apply LinearMap.ext; intro x
  apply ext_inner_left ℝ; intro y
  simp only [LinearMap.comp_apply]
  have hr : ⟪y, A (LinearMap.adjoint (E ∘ₗ C) x)⟫ = ⟪E (C (A y)), x⟫ := by
    rw [← hAs, LinearMap.adjoint_inner_right]; rfl
  rw [hr]
  have h1 := hPA x y
  have c1 := real_inner_comm y (E (C (A x)))
  have c2 := real_inner_comm x (E (C (A y)))
  linarith

/-- `Π A` does not depend on the lift. -/
theorem pi_A_indep (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E E' : W →ₗ[ℝ] V)
    (hCE : C ∘ₗ E = LinearMap.id) (hk : Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E))
    (hCE' : C ∘ₗ E' = LinearMap.id) (hk' : Pi C E' ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E')) :
    Pi C E ∘ₗ A = Pi C E' ∘ₗ A := by
  have hPP : Pi C E' ∘ₗ Pi C E = Pi C E' := by
    show E' ∘ₗ (C ∘ₗ (E ∘ₗ C)) = E' ∘ₗ C
    rw [← LinearMap.comp_assoc C E C, hCE, LinearMap.id_comp]
  have hCP : C ∘ₗ Pi C E' = C := C_Pi C E' hCE'
  calc Pi C E ∘ₗ A = E ∘ₗ (C ∘ₗ Pi C E') ∘ₗ A := by rw [hCP]; rfl
    _ = Pi C E ∘ₗ (Pi C E' ∘ₗ A) := rfl
    _ = Pi C E ∘ₗ (A ∘ₗ LinearMap.adjoint (Pi C E')) := by rw [hk']
    _ = (Pi C E ∘ₗ A) ∘ₗ LinearMap.adjoint (Pi C E') := rfl
    _ = (A ∘ₗ LinearMap.adjoint (Pi C E)) ∘ₗ LinearMap.adjoint (Pi C E') := by rw [hk]
    _ = A ∘ₗ LinearMap.adjoint (Pi C E' ∘ₗ Pi C E) := by rw [LinearMap.adjoint_comp]; rfl
    _ = A ∘ₗ LinearMap.adjoint (Pi C E') := by rw [hPP]
    _ = Pi C E' ∘ₗ A := hk'.symm

/-- **`Γ(A)` does not depend on the lift.** -/
theorem gam_indep (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E E' : W →ₗ[ℝ] V)
    (hCE : C ∘ₗ E = LinearMap.id) (hk : Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E))
    (hCE' : C ∘ₗ E' = LinearMap.id) (hk' : Pi C E' ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E')) :
    Gam C A E = Gam C A E' := by
  rw [gam_eq C A E hCE hk, gam_eq C A E' hCE' hk', pi_A_indep C A E E' hCE hk hCE' hk']

/-- **`0 ≼ Γ(A)`** for `A ≽ 0`. -/
theorem gam_nonneg (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V)
    (hA : LinearMap.adjoint A = A) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫)
    (hCE : C ∘ₗ E = LinearMap.id) (hk : Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E)) (x : V) :
    0 ≤ ⟪x, Gam C A E x⟫ := by
  have hk0 : Pi C E ∘ₗ (0 : V →ₗ[ℝ] V) = 0 ∘ₗ LinearMap.adjoint (Pi C E) := by
    rw [LinearMap.comp_zero, LinearMap.zero_comp]
  have h := gam_sub C A 0 E E hA hCE hk hCE hk0
  have h0 : Gam C 0 E = 0 := by
    unfold Gam; rw [LinearMap.zero_comp, LinearMap.comp_zero, sub_zero]
  rw [h0, sub_zero, sub_zero] at h
  rw [h]
  simp only [LinearMap.comp_apply]
  rw [← LinearMap.adjoint_inner_left]
  exact hAp _

/-- **`Γ(A) ≼ A`** for `A ≽ 0`. -/
theorem gam_le (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫)
    (x : V) : ⟪x, Gam C A E x⟫ ≤ ⟪x, A x⟫ := by
  have h := hAp (LinearMap.adjoint (Pi C E) x)
  rw [LinearMap.adjoint_inner_left] at h
  simp only [Gam, LinearMap.sub_apply, LinearMap.comp_apply, inner_sub_right]
  linarith

/-- `Γ(A)` vanishes against `ker A` (so for `A = A_k`, which kills `ker P`, `Γ` lives in `ran P`):
`Γ = A (1 − Π)†` (`gam_eq'`). -/
theorem gam_kill (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) (hAs : A.IsSymmetric)
    (hCE : C ∘ₗ E = LinearMap.id) (hk : Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E))
    {z : V} (hz : A z = 0) (x : V) : ⟪z, Gam C A E x⟫ = 0 := by
  rw [gam_eq' C A E hCE hk]
  simp only [LinearMap.sub_apply, LinearMap.comp_apply, inner_sub_right]
  rw [← hAs z x, ← hAs z (LinearMap.adjoint (Pi C E) x), hz, inner_zero_left, inner_zero_left,
    sub_zero]

/-- The explicit lift `E = A C† M`, `M = (C A C†)⁻¹` (plan-19 §1; the KKT form `e = h⁺Q̃†λ`). -/
theorem lift_explicit (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (hA : LinearMap.adjoint A = A)
    (M : W →ₗ[ℝ] W) (hM : LinearMap.adjoint M = M)
    (hMinv : (C ∘ₗ A ∘ₗ LinearMap.adjoint C) ∘ₗ M = LinearMap.id) :
    C ∘ₗ (A ∘ₗ LinearMap.adjoint C ∘ₗ M) = LinearMap.id ∧
      Pi C (A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ A =
        A ∘ₗ LinearMap.adjoint (Pi C (A ∘ₗ LinearMap.adjoint C ∘ₗ M)) := by
  refine ⟨hMinv, ?_⟩
  show (A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ C ∘ₗ A =
    A ∘ₗ LinearMap.adjoint ((A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ C)
  rw [LinearMap.adjoint_comp, LinearMap.adjoint_comp, LinearMap.adjoint_comp,
    LinearMap.adjoint_adjoint, hA, hM]
  rfl

end LiftPsd


-- ===== new part : CouplingGammaLift.part.lean =====
/-! # L6-3: `κ`, `CE = 1`/KKT and the lower side of `hbnd` put into `coupling_converges_gamma`

Main theorem
**`coupling_converges_gamma_lift`**: the conclusion of `coupling_converges_gamma`
(`|Ξ(Γ_k) − b_∞| ≤ 5 L′ (3/5)^k`, transient sum), with
* the quantifier on the stage set `S_it = {A_k = 𝓜^k G₀}` only (the bracket set contains singular
  and indefinite `A`, for which a KKT lift need not exist; `V = ℝ⁴` and `A_k` kills `ker P`);
* `hsym` paid by `OneStepFinal.iterate_symm`;
* `hCE`, `hkkt`: `Esel` chosen by `Classical.choose` from `hlift`; the conclusion states it;
* `hκ` paid by `KappaGamma.kappa_value`: `κ = 1 + 2√(4 + 16K)`;
* the lower side of `hbnd` paid by `LiftPsd.gam_nonneg` (`A_k ≽ 0` by `nonneg_iterate`);
* the upper side `hΓup` is stated for every lift (`Γ` does not depend on it: `LiftPsd.gam_indep`),
  the same object as `gamma_norm_le` (`γ∞ = 69241·745/968`, `gamma_infty_value`).
`hEE` (used in only through `os_up` for `A_k ≼ G₀`) is not needed on `S_it`.
Named momentum-wise inputs that remain: `hC4` (`CNormSq.C_normSq_le`), the norm bound in
`hlift` ((T4): `T4_full`, `T4_exact`; existence of the lift itself: `LiftPsd.psd_kkt_lift`),
`hΓup` (`gamma_norm_le`). -/

noncomputable section

namespace CouplingGammaLift

open Finset Filter Topology UniformBracket OneStepBridge OneStepET OneStepFinal CouplingLimit
  CouplingGamma
open scoped RealInnerProductSpace

variable {W : Type*} [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

/-- The stage `A_k = 𝓜^k G₀`. -/
abbrev Ak (k : ℕ) : Qpos → V →ₗ[ℝ] V :=
  (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k] (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)

/-- The stage set. -/
def Sit : Set (Qpos → V →ₗ[ℝ] V) := {A | ∃ k, A = Ak k}

/-- A lift: `C E = 1` and the KKT relation. -/
def IsLift (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) : Prop :=
  C ∘ₗ E = LinearMap.id ∧ GammaDiff.Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (GammaDiff.Pi C E)

/-- The choice of lifts on a set (`Classical.choose`), any type of momenta. -/
theorem esel_of_lift {Q X Y : Type*} (T : Set (Q → X)) (Pprop : (Q → X) → Q → Y → Prop)
    [Inhabited Y] (hlift : ∀ A ∈ T, ∀ q, ∃ E, Pprop A q E) :
    ∃ Esel : (Q → X) → Q → Y, ∀ A ∈ T, ∀ q, Pprop A q (Esel A q) := by
  classical
  refine ⟨fun A q => if h : A ∈ T then Classical.choose (hlift A h q) else default, ?_⟩
  intro A hA q
  simp only [dif_pos hA]
  exact Classical.choose_spec (hlift A hA q)

theorem coupling_converges_gamma_lift
    (Cq : Qpos → V →ₗ[ℝ] W) {K γ : ℝ} (hK : 0 ≤ K) (hγ : 0 ≤ γ)
    (hC4 : ∀ q v, ‖Cq q v‖ ^ 2 ≤ 4 * ‖v‖ ^ 2)
    (hlift : ∀ k q, ∃ E : W →ₗ[ℝ] V, IsLift (Cq q) (Ak k q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2)
    (hΓup : ∀ k q (E : W →ₗ[ℝ] V), IsLift (Cq q) (Ak k q) E →
      ∀ x, ⟪x, GammaDiff.Gam (Cq q) (Ak k q) E x⟫ ≤ γ * ⟪x, x⟫)
    (a : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → V)
    (t : Finset κ') (w2 : κ' → ℝ) (q q2 : κ' → Qpos) (v u u2 v2 : κ' → V) :
    ∃ Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → W →ₗ[ℝ] V,
      (∀ k q, IsLift (Cq q) (Ak k q) (Esel (Ak k) q)) ∧
      ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k)) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2 (Ak k) - binf| ≤
          Lgam (1 + 2 * Real.sqrt (4 + 16 * K)) γ s w x t w2 v u u2 v2 * 2 * (3 / 5 : ℝ) ^ k /
            (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k) - binf)) 0 ≤
          Lgam (1 + 2 * Real.sqrt (4 + 16 * K)) γ s w x t w2 v u u2 v2 * 2 / (1 - 3 / 5) ^ 2) := by
  set κ : ℝ := 1 + 2 * Real.sqrt (4 + 16 * K) with hκdef
  set G0 : Qpos → V →ₗ[ℝ] V := fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q with hG0
  set M := Mfam (Subtype.val : Qpos → _) rqPos
  have hlift' : ∀ A ∈ Sit, ∀ q, ∃ E : W →ₗ[ℝ] V, IsLift (Cq q) (A q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2 := by
    rintro A ⟨k, rfl⟩ q
    exact hlift k q
  obtain ⟨Esel, hEsel⟩ := esel_of_lift Sit
    (fun A q E => IsLift (Cq q) (A q) E ∧ ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2) hlift'
  refine ⟨Esel, fun k q => (hEsel (Ak k) ⟨k, rfl⟩ q).1, ?_⟩
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hM : OrderPreserving M := Mfam_orderPreserving _ _
  have hG0pos : Lw 0 G0 := fun q y => by
    simp only [G0, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω q).le)
      (proj_nonneg (Pfam_symm Subtype.val q) (Pfam_idem Subtype.val q) y)
  have hS : ∀ k, (⇑M)^[k] G0 ∈ Sit := fun k => ⟨k, rfl⟩
  have hsymA : ∀ A ∈ Sit, QuadLip.SymFam A := by
    rintro A ⟨k, rfl⟩ q
    exact iterate_symm Subtype.val rqPos k q
  have hposA : ∀ A ∈ Sit, ∀ q y, 0 ≤ ⟪y, A q y⟫ := by
    rintro A ⟨k, rfl⟩ q y
    have h0 := nonneg_iterate M hM hG0pos k q y
    simpa only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] using h0
  have hadj : ∀ A ∈ Sit, ∀ q, LinearMap.adjoint (A q) = A q :=
    fun A hA q => ((LinearMap.isSymmetric_iff_isSelfAdjoint (A q)).mp (hsymA A hA q))
  have hκ : ∀ A ∈ Sit, ∀ q x,
      ‖LinearMap.adjoint (LinearMap.id - GammaDiff.Pi (Cq q) (Esel A q)) x‖ ≤ κ * ‖x‖ :=
    fun A hA q x => KappaGamma.kappa_value (Cq q) (Esel A q) hK (hEsel A hA q).2 (hC4 q) x
  have hκ0 : 0 ≤ κ := by positivity
  set P' : Qpos → V →ₗ[ℝ] V := fun _ => (κ ^ 2) • LinearMap.id
  set Pb' : Qpos → V →ₗ[ℝ] V := fun _ => LinearMap.id
  have hP' : QuadLip.SymFam P' := fun _ y z => by
    simp only [P', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_left,
      real_inner_smul_right]
  have hPb' : QuadLip.SymFam Pb' := fun _ y z => by simp only [Pb', LinearMap.id_apply]
  have hsymΓ : ∀ A ∈ Sit, QuadLip.SymFam (GamF Cq Esel A) := fun A hA q => by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    exact GammaDiff.gam_adj (Cq q) (A q) (Esel A q) (hadj A hA q) (hEsel A hA q).1.1
      (hEsel A hA q).1.2
  have hpush : ∀ A ∈ Sit, ∀ B ∈ Sit, ∀ c : ℝ, 0 ≤ c →
      QuadLip.Lw (-(c • Pfam Subtype.val)) (A - B) → QuadLip.Lw (A - B) (c • Pfam Subtype.val) →
      QuadLip.Lw (-(c • P')) (GamF Cq Esel A - GamF Cq Esel B) ∧
        QuadLip.Lw (GamF Cq Esel A - GamF Cq Esel B) (c • P') := by
    intro A hA B hB c hc hlo hhi
    have key : ∀ q y, |⟪y, (GamF Cq Esel A - GamF Cq Esel B) q y⟫| ≤ c * κ ^ 2 * ‖y‖ ^ 2 := by
      intro q y
      have hl : ∀ x, -(c * ⟪x, Pfam Subtype.val q x⟫) ≤ ⟪x, (A q - B q) x⟫ := fun x => by
        have := hlo q x
        simpa only [Pi.neg_apply, Pi.smul_apply, Pi.sub_apply, LinearMap.neg_apply,
          LinearMap.smul_apply, inner_neg_right, real_inner_smul_right] using this
      have hh : ∀ x, ⟪x, (A q - B q) x⟫ ≤ c * ⟪x, Pfam Subtype.val q x⟫ := fun x => by
        have := hhi q x
        simpa only [Pi.smul_apply, Pi.sub_apply, LinearMap.smul_apply,
          real_inner_smul_right] using this
      have := GammaDiff.gam_push (Cq q) (A q) (B q) (Esel A q) (Esel B q) (hadj A hA q)
        (hadj B hB q) (hEsel A hA q).1.1 (hEsel A hA q).1.2 (hEsel B hB q).1.1
        (hEsel B hB q).1.2
        (Pfam Subtype.val q) (Pfam_symm Subtype.val q) (inner_P_le_norm q) hc
        (hκ A hA q) (hκ B hB q) hl hh y
      simpa only [GamF, Pi.sub_apply] using this
    constructor
    · intro q y
      have := (abs_le.mp (key q y)).1
      simp only [P', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
    · intro q y
      have := (abs_le.mp (key q y)).2
      simp only [P', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
  have hbnd' : ∀ A ∈ Sit, QuadLip.Lw (-(γ • Pb')) (GamF Cq Esel A) ∧
      QuadLip.Lw (GamF Cq Esel A) (γ • Pb') := by
    rintro A ⟨k, rfl⟩
    have hA : Ak k ∈ Sit := ⟨k, rfl⟩
    constructor
    · intro q y
      simp only [Pb', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right]
      have h0 := LiftPsd.gam_nonneg (Cq q) (Ak k q) (Esel (Ak k) q) (hadj _ hA q)
        (hposA _ hA q) (hEsel _ hA q).1.1 (hEsel _ hA q).1.2 y
      have h1 : 0 ≤ γ * ⟪y, y⟫ := mul_nonneg hγ real_inner_self_nonneg
      simp only [GamF]
      linarith
    · intro q y
      simp only [Pb', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right]
      exact hΓup k q (Esel (Ak k) q) (hEsel _ hA q).1 y
  have hΞ := QuadLip.relLip_of_quadratic₃ (GamF Cq Esel) Sit (Pfam Subtype.val) P' hP' Pb' hPb'
    hpush hbnd' hsymΓ a s w p x t w2 q q2 v u u2 v2
  have hLeq : (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (γ *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)))) =
      Lgam κ γ s w x t w2 v u u2 v2 := by
    simp only [P', Pb', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_right,
      real_inner_self_eq_norm_sq, Lgam]
    rw [mul_add, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
    congr 1
    · exact Finset.sum_congr rfl fun i _ => by ring
    · exact Finset.sum_congr rfl fun j _ => by ring
  rw [hLeq] at hΞ
  have hL0 : 0 ≤ Lgam κ γ s w x t w2 v u u2 v2 := by
    unfold Lgam
    apply mul_nonneg (sq_nonneg _)
    apply add_nonneg
    · exact Finset.sum_nonneg fun i _ => mul_nonneg (abs_nonneg _) (sq_nonneg _)
    · exact mul_nonneg hγ (Finset.sum_nonneg fun j _ => mul_nonneg (abs_nonneg _)
        (div_nonneg (mul_nonneg (by positivity) (by positivity)) (by norm_num)))
  obtain ⟨binf, hlim, hrate, _, _, _, htr⟩ := Coupling35.coupling_converges_35
    (QuadLip.XiQf (GamF Cq Esel) a s w p x t w2 q q2 v u u2 v2) Sit hL0 hS hΞ
  exact ⟨binf, hlim, hrate, htr⟩

/-- **`Γ_k` lives in `ran P`** : `P Γ_k = Γ_k = Γ_k P` for every
lift. `P A_k = A_k` (`iterate_P`, from the definition of `𝓜`) and the symmetry give `A_k = A_k P`,
so `A_k` kills `ker P`; `Γ_k = A_k (1 − Π)†` (`gam_kill`) is orthogonal to `ker P`, and `Γ_k` is
symmetric (`gam_adj`). No `hEE`. It does not depend on whether `ran E ⊆ ran P` (the gauge part of
the lift is not in `ran P`). -/
theorem gam_range (C : V →ₗ[ℝ] W) (k : ℕ) (q : Qpos) (E : W →ₗ[ℝ] V) (hL : IsLift C (Ak k q) E)
    (x : V) :
    Pfam Subtype.val q (GammaDiff.Gam C (Ak k q) E x) = GammaDiff.Gam C (Ak k q) E x ∧
      GammaDiff.Gam C (Ak k q) E (Pfam Subtype.val q x) = GammaDiff.Gam C (Ak k q) E x := by
  set Γ := GammaDiff.Gam C (Ak k q) E with hΓ
  have hAs : (Ak k q).IsSymmetric := iterate_symm Subtype.val rqPos k q
  have hA' : LinearMap.adjoint (Ak k q) = Ak k q :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint (Ak k q)).mp hAs
  have hPA : ∀ y, Pfam Subtype.val q (Ak k q y) = Ak k q y := iterate_P Subtype.val rqPos k q
  have hAP : ∀ z, Ak k q (Pfam Subtype.val q z) = Ak k q z := fun z => by
    apply ext_inner_left ℝ; intro y
    rw [← hAs, ← Pfam_symm Subtype.val q, hPA, hAs]
  have hΓs : Γ.IsSymmetric := by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    exact GammaDiff.gam_adj C (Ak k q) E hA' hL.1 hL.2
  have hPΓ : ∀ y z, ⟪Pfam Subtype.val q y, Γ z⟫ = ⟪y, Γ z⟫ := fun y z => by
    have h0 : Ak k q (y - Pfam Subtype.val q y) = 0 := by rw [map_sub, hAP, sub_self]
    have h := LiftPsd.gam_kill C (Ak k q) E hAs hL.1 hL.2 h0 z
    rw [inner_sub_left, sub_eq_zero] at h
    exact h.symm
  have h1 : ∀ z, Pfam Subtype.val q (Γ z) = Γ z := fun z => by
    apply ext_inner_left ℝ; intro y
    rw [← Pfam_symm Subtype.val q, hPΓ]
  refine ⟨h1 x, ?_⟩
  apply ext_inner_left ℝ; intro y
  rw [← hΓs, ← Pfam_symm Subtype.val q, h1 y, hΓs]

end CouplingGammaLift

end


-- ===== an earlier file (without import and #print axioms) =====

/-! # Block-diagonal operators on the alias sum `⊕_ζ V` (PiLp 2)

Paper (for checking): For a family `A : Z → (V →ₗ V)` (one operator per
alias `ζ`), `blk A` acts on `PiLp 2 (fun _ : Z => V)` componentwise. Quadratic forms add up over the
aliases (`blk_inner`), so symmetry, `≽ 0`, `⟪u, blk P u⟫ ≤ ‖u‖²` and the two-sided bracket
`−cP ≼ A − B ≼ cP` pass from the components to `blk`. -/

namespace AliasBlock

open scoped RealInnerProductSpace

variable {Z : Type*} [Fintype Z] {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The block-diagonal operator. -/
noncomputable def blk (A : Z → V →ₗ[ℝ] V) : PiLp 2 (fun _ : Z => V) →ₗ[ℝ] PiLp 2 (fun _ : Z => V) :=
  (WithLp.linearEquiv 2 ℝ (Z → V)).symm.toLinearMap ∘ₗ
    LinearMap.pi (fun ζ => A ζ ∘ₗ PiLp.projₗ 2 (fun _ : Z => V) ζ)

theorem blk_apply (A : Z → V →ₗ[ℝ] V) (u : PiLp 2 (fun _ : Z => V)) (ζ : Z) :
    blk A u ζ = A ζ (u ζ) := rfl

theorem blk_inner (A : Z → V →ₗ[ℝ] V) (u w : PiLp 2 (fun _ : Z => V)) :
    ⟪u, blk A w⟫ = ∑ ζ, ⟪u ζ, A ζ (w ζ)⟫ := by
  rw [PiLp.inner_apply]; rfl

theorem blk_symm {A : Z → V →ₗ[ℝ] V} (hA : ∀ ζ, (A ζ).IsSymmetric) : (blk A).IsSymmetric := by
  intro u w
  rw [real_inner_comm, blk_inner, blk_inner]
  exact Finset.sum_congr rfl fun ζ _ => by rw [← hA ζ, real_inner_comm]

theorem blk_nonneg {A : Z → V →ₗ[ℝ] V} (hA : ∀ ζ v, 0 ≤ ⟪v, A ζ v⟫)
    (u : PiLp 2 (fun _ : Z => V)) : 0 ≤ ⟪u, blk A u⟫ := by
  rw [blk_inner]; exact Finset.sum_nonneg fun ζ _ => hA ζ _

theorem blk_le_norm {P : Z → V →ₗ[ℝ] V} (hP : ∀ ζ v, ⟪v, P ζ v⟫ ≤ ‖v‖ ^ 2)
    (u : PiLp 2 (fun _ : Z => V)) : ⟪u, blk P u⟫ ≤ ‖u‖ ^ 2 := by
  rw [blk_inner, PiLp.norm_sq_eq_of_L2]
  exact Finset.sum_le_sum fun ζ _ => hP ζ _

theorem blk_lo {A B P : Z → V →ₗ[ℝ] V} {c : ℝ}
    (hlo : ∀ ζ v, -(c * ⟪v, P ζ v⟫) ≤ ⟪v, (A ζ - B ζ) v⟫) (u : PiLp 2 (fun _ : Z => V)) :
    -(c * ⟪u, blk P u⟫) ≤ ⟪u, (blk A - blk B) u⟫ := by
  rw [LinearMap.sub_apply, inner_sub_right, blk_inner, blk_inner, blk_inner, Finset.mul_sum,
    ← Finset.sum_neg_distrib, ← Finset.sum_sub_distrib]
  refine Finset.sum_le_sum fun ζ _ => ?_
  have := hlo ζ (u ζ)
  rwa [LinearMap.sub_apply, inner_sub_right] at this

theorem blk_hi {A B P : Z → V →ₗ[ℝ] V} {c : ℝ}
    (hhi : ∀ ζ v, ⟪v, (A ζ - B ζ) v⟫ ≤ c * ⟪v, P ζ v⟫) (u : PiLp 2 (fun _ : Z => V)) :
    ⟪u, (blk A - blk B) u⟫ ≤ c * ⟪u, blk P u⟫ := by
  rw [LinearMap.sub_apply, inner_sub_right, blk_inner, blk_inner, blk_inner, Finset.mul_sum,
    ← Finset.sum_sub_distrib]
  refine Finset.sum_le_sum fun ζ _ => ?_
  have := hhi ζ (u ζ)
  rwa [LinearMap.sub_apply, inner_sub_right] at this

end AliasBlock


-- ===== new part : GammaDiffR (GammaDiff with `C E = 1` weakened to `C Π = C`) =====
/-! `C ∘ E = 1` is used in `GammaDiff` only through `C_Pi : C Π = C`. Here that is the
hypothesis, so `C` need not be onto (the alias constraint `C(q) = ¼ Σ_ζ A_ζ` has range `ran P(q)`;
a lift then has `C E = P(q)`, and `C E C = C`). All statements are otherwise those of `GammaDiff`.
-/
namespace GammaDiffR

open LinearMap
open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

/-- `Π = E C`. -/
def Pi (C : V →ₗ[ℝ] W) (E : W →ₗ[ℝ] V) : V →ₗ[ℝ] V := E ∘ₗ C

/-- `Γ(A) = A − Π A Π†`. -/
noncomputable def Gam (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) : V →ₗ[ℝ] V :=
  A - Pi C E ∘ₗ A ∘ₗ adjoint (Pi C E)

variable (C : V →ₗ[ℝ] W) (A B : V →ₗ[ℝ] V) (EA EB : W →ₗ[ℝ] V)

theorem C_Pi (hCE : C ∘ₗ Pi C EA = C) : C ∘ₗ Pi C EA = C := hCE

theorem Pi_idem (hCE : C ∘ₗ Pi C EA = C) : Pi C EA ∘ₗ Pi C EA = Pi C EA := by
  conv_lhs => rw [show Pi C EA ∘ₗ Pi C EA = EA ∘ₗ (C ∘ₗ Pi C EA) by rfl]
  rw [C_Pi C EA hCE]; rfl

theorem gam_eq (hCE : C ∘ₗ Pi C EA = C)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA = A - Pi C EA ∘ₗ A := by
  unfold Gam
  rw [← hkkt, ← LinearMap.comp_assoc, Pi_idem C EA hCE]

theorem gam_eq' (hCE : C ∘ₗ Pi C EA = C)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA = A - A ∘ₗ adjoint (Pi C EA) := by
  rw [gam_eq C A EA hCE hkkt, hkkt]

theorem C_gam (hCE : C ∘ₗ Pi C EA = C)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    C ∘ₗ Gam C A EA = 0 := by
  rw [gam_eq C A EA hCE hkkt, LinearMap.comp_sub, ← LinearMap.comp_assoc, C_Pi C EA hCE, sub_self]

theorem gam_adj (hA : adjoint A = A) (hCE : C ∘ₗ Pi C EA = C)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    adjoint (Gam C A EA) = Gam C A EA := by
  rw [gam_eq C A EA hCE hkkt, map_sub, LinearMap.adjoint_comp, hA, ← gam_eq' C A EA hCE hkkt,
    gam_eq C A EA hCE hkkt]

theorem gam_Cadj (hA : adjoint A = A) (hCE : C ∘ₗ Pi C EA = C)
    (hkkt : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) :
    Gam C A EA ∘ₗ adjoint C = 0 := by
  have h := congrArg adjoint (C_gam C A EA hCE hkkt)
  rw [LinearMap.adjoint_comp, gam_adj C A EA hA hCE hkkt, map_zero] at h
  exact h

/-- **`Γ(A) − Γ(B) = (1 − Π_A)(A − B)(1 − Π_B)†`**. -/
theorem gam_sub (hA : adjoint A = A) (hCEA : C ∘ₗ Pi C EA = C)
    (hkA : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA))
    (hCEB : C ∘ₗ Pi C EB = C) (hkB : Pi C EB ∘ₗ B = B ∘ₗ adjoint (Pi C EB)) :
    Gam C A EA - Gam C B EB =
      (LinearMap.id - Pi C EA) ∘ₗ (A - B) ∘ₗ adjoint (LinearMap.id - Pi C EB) := by
  -- `(1 − Π_A) A = Γ_A`, `B (1 − Π_B)† = Γ_B`
  have e1 : (LinearMap.id - Pi C EA) ∘ₗ A = Gam C A EA := by
    rw [gam_eq C A EA hCEA hkA, LinearMap.sub_comp, LinearMap.id_comp]
  have e2 : B ∘ₗ adjoint (LinearMap.id - Pi C EB) = Gam C B EB := by
    rw [gam_eq' C B EB hCEB hkB, map_sub, LinearMap.adjoint_id, LinearMap.comp_sub,
      LinearMap.comp_id]
  -- `Γ_A Π_B† = 0`, `Π_A Γ_B = 0`
  have z1 : Gam C A EA ∘ₗ adjoint (Pi C EB) = 0 := by
    unfold Pi
    rw [LinearMap.adjoint_comp, ← LinearMap.comp_assoc, gam_Cadj C A EA hA hCEA hkA,
      LinearMap.zero_comp]
  have z2 : Pi C EA ∘ₗ Gam C B EB = 0 := by
    unfold Pi
    rw [LinearMap.comp_assoc, C_gam C B EB hCEB hkB, LinearMap.comp_zero]
  have hX : adjoint (LinearMap.id - Pi C EB) = LinearMap.id - adjoint (Pi C EB) := by
    rw [map_sub, LinearMap.adjoint_id]
  have p1 : ∀ y, ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) (A y) = Gam C A EA y := fun y => by
    rw [← e1]; rfl
  have p2 : ∀ y, B (adjoint (LinearMap.id - Pi C EB) y) = Gam C B EB y := fun y => by
    rw [← e2]; rfl
  have p3 : ∀ y, Gam C A EA (adjoint (LinearMap.id - Pi C EB) y) = Gam C A EA y := fun y => by
    have h0 := LinearMap.congr_fun z1 y
    simp only [LinearMap.comp_apply, LinearMap.zero_apply] at h0
    rw [hX, LinearMap.sub_apply, LinearMap.id_apply, map_sub, h0, sub_zero]
  have p4 : ∀ y, ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) (Gam C B EB y) = Gam C B EB y := fun y => by
    have h0 := LinearMap.congr_fun z2 y
    simp only [LinearMap.comp_apply, LinearMap.zero_apply] at h0
    rw [LinearMap.sub_apply, LinearMap.id_apply, h0, sub_zero]
  set X := adjoint (LinearMap.id - Pi C EB) with hXdef
  ext y
  show Gam C A EA y - Gam C B EB y = ((LinearMap.id : V →ₗ[ℝ] V) - Pi C EA) ((A - B) (X y))
  rw [LinearMap.sub_apply A B (X y), map_sub, p1, p2, p3, p4]

/-- Matrix elements of a symmetric `D` with `−cP ≼ D ≼ cP` (= `QuadLip.elem_bound`). -/
theorem elem_bound' (D P : V →ₗ[ℝ] V) (hD : D.IsSymmetric) (hP : P.IsSymmetric) {c : ℝ}
    (hlo : ∀ x, -(c * ⟪x, P x⟫) ≤ ⟪x, D x⟫) (hhi : ∀ x, ⟪x, D x⟫ ≤ c * ⟪x, P x⟫) (v u : V) :
    |⟪v, D u⟫| ≤ c * (⟪v, P v⟫ + ⟪u, P u⟫) / 2 := by
  have pol : ∀ T : V →ₗ[ℝ] V, T.IsSymmetric →
      ⟪v + u, T (v + u)⟫ - ⟪v - u, T (v - u)⟫ = 4 * ⟪v, T u⟫ ∧
      ⟪v + u, T (v + u)⟫ + ⟪v - u, T (v - u)⟫ = 2 * ⟪v, T v⟫ + 2 * ⟪u, T u⟫ := by
    intro T hT
    have h1 : ⟪u, T v⟫ = ⟪v, T u⟫ := by rw [← hT, real_inner_comm]
    simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left,
      inner_sub_right]
    constructor <;> linarith
  obtain ⟨d1, d2⟩ := pol D hD
  obtain ⟨_, p2⟩ := pol P hP
  have a1 := hhi (v + u); have a2 := hlo (v - u)
  have b1 := hlo (v + u); have b2 := hhi (v - u)
  have cp : c * (⟪v + u, P (v + u)⟫ + ⟪v - u, P (v - u)⟫) =
      c * (2 * ⟪v, P v⟫ + 2 * ⟪u, P u⟫) := by rw [p2]
  rw [abs_le]; constructor <;> nlinarith

/-- **The push of the bracket through `Γ`**: `|⟪x, (Γ_A − Γ_B) x⟫| ≤ c κ² ‖x‖²`. -/
theorem gam_push (hA : adjoint A = A) (hB : adjoint B = B) (hCEA : C ∘ₗ Pi C EA = C)
    (hkA : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA))
    (hCEB : C ∘ₗ Pi C EB = C) (hkB : Pi C EB ∘ₗ B = B ∘ₗ adjoint (Pi C EB))
    (P : V →ₗ[ℝ] V) (hP : P.IsSymmetric) (hP1 : ∀ u, ⟪u, P u⟫ ≤ ‖u‖ ^ 2) {c κ : ℝ} (hc : 0 ≤ c)
    (hκA : ∀ x, ‖adjoint (LinearMap.id - Pi C EA) x‖ ≤ κ * ‖x‖)
    (hκB : ∀ x, ‖adjoint (LinearMap.id - Pi C EB) x‖ ≤ κ * ‖x‖)
    (hlo : ∀ x, -(c * ⟪x, P x⟫) ≤ ⟪x, (A - B) x⟫) (hhi : ∀ x, ⟪x, (A - B) x⟫ ≤ c * ⟪x, P x⟫)
    (x : V) : |⟪x, (Gam C A EA - Gam C B EB) x⟫| ≤ c * κ ^ 2 * ‖x‖ ^ 2 := by
  rw [gam_sub C A B EA EB hA hCEA hkA hCEB hkB]
  set u := adjoint (LinearMap.id - Pi C EA) x
  set v := adjoint (LinearMap.id - Pi C EB) x
  have e : ⟪x, ((LinearMap.id - Pi C EA) ∘ₗ (A - B) ∘ₗ adjoint (LinearMap.id - Pi C EB)) x⟫ =
      ⟪u, (A - B) v⟫ := by
    simp only [LinearMap.comp_apply, u, v]
    rw [← LinearMap.adjoint_inner_left]
  rw [e]
  have hDs : (A - B).IsSymmetric := by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    show adjoint (A - B) = A - B
    rw [map_sub, hA, hB]
  have hb := elem_bound' (A - B) P hDs hP hlo hhi u v
  have hu := hP1 u; have hv := hP1 v
  have hu2 : ‖u‖ ^ 2 ≤ (κ * ‖x‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hκA x) 2
  have hv2 : ‖v‖ ^ 2 ≤ (κ * ‖x‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (hκB x) 2
  have : c * (⟪u, P u⟫ + ⟪v, P v⟫) / 2 ≤ c * κ ^ 2 * ‖x‖ ^ 2 := by
    have h2 : ⟪u, P u⟫ + ⟪v, P v⟫ ≤ 2 * (κ ^ 2 * ‖x‖ ^ 2) := by nlinarith
    have := mul_le_mul_of_nonneg_left h2 hc
    nlinarith
  linarith


/-- `0 ≼ Γ(A)` for `A ≽ 0` (= `LiftPsd.gam_nonneg`, lift up to the range of `C`). -/
theorem gam_nonneg (hA : adjoint A = A) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫)
    (hCE : C ∘ₗ Pi C EA = C) (hk : Pi C EA ∘ₗ A = A ∘ₗ adjoint (Pi C EA)) (x : V) :
    0 ≤ ⟪x, Gam C A EA x⟫ := by
  have hk0 : Pi C EA ∘ₗ (0 : V →ₗ[ℝ] V) = 0 ∘ₗ adjoint (Pi C EA) := by
    rw [LinearMap.comp_zero, LinearMap.zero_comp]
  have h := gam_sub C A 0 EA EA hA hCE hk hCE hk0
  have h0 : Gam C 0 EA = 0 := by
    unfold Gam; rw [LinearMap.zero_comp, LinearMap.comp_zero, sub_zero]
  rw [h0, sub_zero, sub_zero] at h
  rw [h]
  simp only [LinearMap.comp_apply]
  rw [← LinearMap.adjoint_inner_left]
  exact hAp _

end GammaDiffR

-- ===== new part : CouplingGammaAlias.part.lean =====
/-! # L6-3 on the alias sum: the constraint is the one of `𝓜`, and `‖C‖² ≤ 4` is inside

The fluctuation side lives on the
alias sum `⊕_ζ V = PiLp 2 (Z → V)` (`Z = Fin 4 → Bool`), with the block covariance
`blkF A q = ⊕_ζ A(r_ζ q)` and the constraint **`Calias q u = ¼ Σ_ζ A_ζ(q) u_ζ`**, so that
`𝓜G(q) = Calias q (blkF G q) Calias q†` (`mfam_eq`, `Calias_adj`): `C` is the constraint of the
stage map itself.
* `Atr_normSq_le`, `AM_norm_le`: `‖A_ζ v‖ ≤ 2‖v‖` (`‖N‖ ≤ 1`, projections, `|cos| ≤ 1`).
* **`Calias_normSq_le`**: `‖C u‖² ≤ 4‖u‖²` (the seam `hC4` is a theorem here; the same bound as
   `CNormSq.C_normSq_le`, for the projected `A_ζ` of `𝓜`).
* `P_Calias`: `ran C ⊆ ran P(q)`, so a lift has `C E = P(q)` and `C Π = C`
  (`GammaDiffR`: `GammaDiff` with `C E = 1` weakened to `C Π = C`).
* **`coupling_converges_gamma_alias`**: `|Ξ(Γ_k) − b_∞| ≤ 5 L′ (3/5)^k` and the transient sum, on
  the orbit `S_it`, `κ = 1 + 2√(4 + 16K)`. Seams left, now on the types of `T4_full` and
  `gamma_norm_le` (the alias sum): the size of the lift in `hlift`, and `hΓup`
  (`GammaUp.gam_up_of_poincare`). -/

noncomputable section

namespace CouplingGammaAlias

open Finset Filter Topology UniformBracket OneStepNorm OneStepBridge OneStepET OneStepFinal
  CouplingLimit CouplingGamma CouplingGammaLift
open scoped RealInnerProductSpace

/-- The aliases. -/
abbrev Z := Fin 4 → Bool

/-- The alias sum `⊕_ζ V`. -/
abbrev Bsum := PiLp 2 (fun _ : Z => V)

/-- The block covariance `⊕_ζ A(r_ζ q)`. -/
def blkF (A : Qpos → V →ₗ[ℝ] V) (q : Qpos) : Bsum →ₗ[ℝ] Bsum :=
  AliasBlock.blk (fun ζ => A (rqPos q ζ))

/-- The constraint `C u = ¼ Σ_ζ A_ζ u_ζ`. -/
def Calias (q : Qpos) : Bsum →ₗ[ℝ] V :=
  (1 / 4 : ℝ) • ∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) ∘ₗ PiLp.projₗ 2 (fun _ : Z => V) ζ

/-- Its adjoint `v ↦ (¼ A_ζᵀ v)_ζ`. -/
def CaliasT (q : Qpos) : V →ₗ[ℝ] Bsum :=
  (WithLp.linearEquiv 2 ℝ (Z → V)).symm.toLinearMap ∘ₗ
    LinearMap.pi (fun ζ => (1 / 4 : ℝ) • Matrix.toEuclideanLin (AtM q.1 ζ))

theorem Calias_apply (q : Qpos) (u : Bsum) :
    Calias q u = (1 / 4 : ℝ) • ∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) (u ζ) := by
  show ((1 / 4 : ℝ) • ∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) ∘ₗ
    PiLp.projₗ 2 (fun _ : Z => V) ζ) u = _
  rw [LinearMap.smul_apply, LinearMap.sum_apply]
  rfl

theorem CaliasT_apply (q : Qpos) (v : V) (ζ : Z) :
    CaliasT q v ζ = (1 / 4 : ℝ) • Matrix.toEuclideanLin (AtM q.1 ζ) v := rfl

theorem Calias_adj (q : Qpos) (u : Bsum) (v : V) : ⟪Calias q u, v⟫ = ⟪u, CaliasT q v⟫ := by
  rw [Calias_apply, real_inner_smul_left, sum_inner, PiLp.inner_apply, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [CaliasT_apply, real_inner_smul_right, real_inner_comm,
    inner_toE (AM q.1 ζ) (AtM q.1 ζ) (AM_transpose q.1 ζ), real_inner_comm]

/-- **`𝓜G(q) = C (⊕_ζ G(r_ζ)) C†`**. -/
theorem mfam_eq (G : Qpos → V →ₗ[ℝ] V) (q : Qpos) (x : V) :
    Mfam (Subtype.val : Qpos → _) rqPos G q x = Calias q (blkF G q (CaliasT q x)) := by
  rw [Calias_apply]
  show ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM q.1 ζ) ∘ₗ
      G (rqPos q ζ) ∘ₗ Matrix.toEuclideanLin (AtM q.1 ζ)) x = _
  rw [LinearMap.smul_apply, LinearMap.sum_apply, Finset.smul_sum, Finset.smul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [show blkF G q (CaliasT q x) ζ = G (rqPos q ζ) (CaliasT q x ζ) from rfl, CaliasT_apply,
    map_smul, map_smul, smul_smul, LinearMap.comp_apply, LinearMap.comp_apply]
  norm_num

theorem P_Calias (q : Qpos) (u : Bsum) : Pfam Subtype.val q (Calias q u) = Calias q u := by
  rw [Calias_apply, map_smul, map_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← projM_mulVec, projM_AM]

theorem proj_contract (s y : Fin 4 → ℝ) :
    OneStepHrep.dot (OneStepHrep.proj s y) (OneStepHrep.proj s y) ≤ OneStepHrep.dot y y := by
  rw [OneStepHrep.dot_proj_self]
  have hys : OneStepHrep.dot y s = OneStepHrep.dot s y := by
    unfold OneStepHrep.dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _
  have hss : 0 ≤ OneStepHrep.dot s s := Finset.sum_nonneg fun i _ => mul_self_nonneg _
  have e : OneStepHrep.dot y (OneStepHrep.proj s y) = OneStepHrep.dot y y -
      (OneStepHrep.dot s y / OneStepHrep.dot s s) * OneStepHrep.dot y s := by
    set t := OneStepHrep.dot s y / OneStepHrep.dot s s with ht
    have hp : OneStepHrep.proj s y = fun i => y i - t * s i := rfl
    rw [hp]
    unfold OneStepHrep.dot
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    exact Finset.sum_congr rfl fun i _ => by ring
  have h0 : 0 ≤ (OneStepHrep.dot s y / OneStepHrep.dot s s) * OneStepHrep.dot y s := by
    rw [hys, div_mul_eq_mul_div]; exact div_nonneg (mul_self_nonneg _) hss
  linarith

theorem Atr_normSq_le (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (x : Fin 4 → ℝ) :
    OneStepHrep.dot (OneStepHrep.Atr θ ζ x) (OneStepHrep.Atr θ ζ x) ≤ 4 * OneStepHrep.dot x x := by
  set w := OneStepHrep.proj (OneStepHrep.sQ θ) x with hw
  set y : Fin 4 → ℝ := fun ν => OneStepHrep.cR θ ζ ν * OneStepHrep.sg ζ ν * w ν with hy
  set z := OneStepHrep.proj (OneStepHrep.sR θ ζ) y with hz
  have hA : OneStepHrep.Atr θ ζ x = fun μ => 2 * OneStepHrep.Nm (OneStepHrep.sR θ ζ) z μ := rfl
  have hx : ∀ ν, 0 ≤ OneStepHrep.xs (OneStepHrep.sR θ ζ) ν ∧
      OneStepHrep.xs (OneStepHrep.sR θ ζ) ν ≤ 1 / 2 := fun ν => by
    rw [OneStepHrep.xs_alias]; exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have h1 : OneStepHrep.dot (OneStepHrep.Atr θ ζ x) (OneStepHrep.Atr θ ζ x) =
      4 * OneStepHrep.dot (OneStepHrep.Nm (OneStepHrep.sR θ ζ) z)
        (OneStepHrep.Nm (OneStepHrep.sR θ ζ) z) := by
    rw [hA]; unfold OneStepHrep.dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  have h2 := Nm_normSq_le hx z
  have h3 := proj_contract (OneStepHrep.sR θ ζ) y
  have h4 : OneStepHrep.dot y y ≤ OneStepHrep.dot w w := by
    unfold OneStepHrep.dot
    refine Finset.sum_le_sum fun ν _ => ?_
    have hsg : OneStepHrep.sg ζ ν * OneStepHrep.sg ζ ν = 1 := by
      unfold OneStepHrep.sg; split_ifs <;> norm_num
    have hc : OneStepHrep.cR θ ζ ν ^ 2 ≤ 1 := by
      unfold OneStepHrep.cR; exact Real.cos_sq_le_one _
    have e : y ν * y ν = OneStepHrep.cR θ ζ ν ^ 2 *
        (OneStepHrep.sg ζ ν * OneStepHrep.sg ζ ν) * (w ν * w ν) := by
      simp only [hy]; ring
    rw [e, hsg, mul_one]
    nlinarith [mul_self_nonneg (w ν)]
  have h5 := proj_contract (OneStepHrep.sQ θ) x
  linarith

theorem normSq_coord (v : V) : ‖v‖ ^ 2 = OneStepHrep.dot (WithLp.ofLp v) (WithLp.ofLp v) := by
  rw [← real_inner_self_eq_norm_sq, inner_coord]

theorem AtM_norm_le (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (w : V) :
    ‖Matrix.toEuclideanLin (AtM θ ζ) w‖ ^ 2 ≤ 4 * ‖w‖ ^ 2 := by
  rw [normSq_coord, normSq_coord, toE_apply, WithLp.ofLp_toLp, AtM_mulVec]
  exact Atr_normSq_le θ ζ _

theorem AM_norm_le (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (v : V) :
    ‖Matrix.toEuclideanLin (AM θ ζ) v‖ ≤ 2 * ‖v‖ := by
  set y := Matrix.toEuclideanLin (AM θ ζ) v
  have e : ‖y‖ ^ 2 = ⟪Matrix.toEuclideanLin (AtM θ ζ) y, v⟫ := by
    rw [← real_inner_self_eq_norm_sq]
    exact inner_toE (AM θ ζ) (AtM θ ζ) (AM_transpose θ ζ) y v
  have h1 : ⟪Matrix.toEuclideanLin (AtM θ ζ) y, v⟫ ≤ ‖Matrix.toEuclideanLin (AtM θ ζ) y‖ * ‖v‖ :=
    real_inner_le_norm _ _
  have h2 : ‖Matrix.toEuclideanLin (AtM θ ζ) y‖ ≤ 2 * ‖y‖ := by
    have := AtM_norm_le θ ζ y
    nlinarith [norm_nonneg (Matrix.toEuclideanLin (AtM θ ζ) y), norm_nonneg y]
  have hy := norm_nonneg y
  have hv := norm_nonneg v
  have h3 : ‖y‖ ^ 2 ≤ 2 * ‖y‖ * ‖v‖ := by nlinarith
  rcases eq_or_lt_of_le hy with h0 | hpos
  · rw [← h0]; positivity
  · nlinarith

/-- **`‖C u‖² ≤ 4‖u‖²`** (the seam `hC4`). -/
theorem Calias_normSq_le (q : Qpos) (u : Bsum) : ‖Calias q u‖ ^ 2 ≤ 4 * ‖u‖ ^ 2 := by
  rw [Calias_apply, norm_smul, PiLp.norm_sq_eq_of_L2]
  have h1 : ‖∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) (u ζ)‖ ≤ ∑ ζ : Z, 2 * ‖u ζ‖ :=
    (norm_sum_le _ _).trans (Finset.sum_le_sum fun ζ _ => AM_norm_le q.1 ζ (u ζ))
  have h2 : (∑ ζ : Z, 2 * ‖u ζ‖) ^ 2 ≤ (Finset.univ : Finset Z).card * ∑ ζ : Z, (2 * ‖u ζ‖) ^ 2 :=
    sq_sum_le_card_mul_sum_sq
  have hcard : ((Finset.univ : Finset Z).card : ℝ) = 16 := by
    rw [Finset.card_univ, Fintype.card_fun, Fintype.card_bool, Fintype.card_fin]; norm_num
  rw [hcard] at h2
  have h3 : ∑ ζ : Z, (2 * ‖u ζ‖) ^ 2 = 4 * ∑ ζ : Z, ‖u ζ‖ ^ 2 := by
    rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ζ _ => by ring
  rw [h3] at h2
  have h0 : 0 ≤ ‖∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) (u ζ)‖ := norm_nonneg _
  have h4 : ‖∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) (u ζ)‖ ^ 2 ≤ (∑ ζ : Z, 2 * ‖u ζ‖) ^ 2 :=
    pow_le_pow_left₀ h0 h1 2
  have e : ‖(1 / 4 : ℝ)‖ = 1 / 4 := by norm_num
  rw [e, mul_pow]
  nlinarith

/-- A lift for the alias constraint (`C Π = C`, KKT). -/
def IsLiftR (C : Bsum →ₗ[ℝ] V) (A : Bsum →ₗ[ℝ] Bsum) (E : V →ₗ[ℝ] Bsum) : Prop :=
  C ∘ₗ GammaDiffR.Pi C E = C ∧
    GammaDiffR.Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (GammaDiffR.Pi C E)

/-- The fluctuation covariance on the alias sum. -/
def GamA (Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → V →ₗ[ℝ] Bsum) (A : Qpos → V →ₗ[ℝ] V) :
    Qpos → Bsum →ₗ[ℝ] Bsum :=
  fun q => GammaDiffR.Gam (Calias q) (blkF A q) (Esel A q)

/-- The constant `L′` on the alias sum. -/
def LgamA (κ γ : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (x : ι → Bsum)
    (t : Finset κ') (w2 : κ' → ℝ) (v u u2 v2 : κ' → Bsum) : ℝ :=
  κ ^ 2 * (∑ i ∈ s, |w i| * ‖x i‖ ^ 2 +
    γ * ∑ j ∈ t, |w2 j| * ((‖v j‖ ^ 2 + ‖u j‖ ^ 2) * (‖u2 j‖ ^ 2 + ‖v2 j‖ ^ 2) / 2))

theorem blkF_symm (A : Qpos → V →ₗ[ℝ] V) (hA : QuadLip.SymFam A) (q : Qpos) :
    (blkF A q).IsSymmetric := AliasBlock.blk_symm fun ζ => hA _

theorem blkP_le (q : Qpos) (u : Bsum) : ⟪u, blkF (Pfam Subtype.val) q u⟫ ≤ ‖u‖ ^ 2 :=
  AliasBlock.blk_le_norm (fun ζ v => inner_P_le_norm (rqPos q ζ) v) u

theorem coupling_converges_gamma_alias {K γ : ℝ} (hK : 0 ≤ K) (hγ : 0 ≤ γ)
    (hlift : ∀ k q, ∃ E : V →ₗ[ℝ] Bsum, IsLiftR (Calias q) (blkF (Ak k) q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2)
    (hΓup : ∀ k q (E : V →ₗ[ℝ] Bsum), IsLiftR (Calias q) (blkF (Ak k) q) E →
      ∀ x, ⟪x, GammaDiffR.Gam (Calias q) (blkF (Ak k) q) E x⟫ ≤ γ * ⟪x, x⟫)
    (a : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → Bsum)
    (t : Finset κ') (w2 : κ' → ℝ) (q q2 : κ' → Qpos) (v u u2 v2 : κ' → Bsum) :
    ∃ Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → V →ₗ[ℝ] Bsum,
      (∀ k q, IsLiftR (Calias q) (blkF (Ak k) q) (Esel (Ak k) q)) ∧
      ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k)) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2 (Ak k) - binf| ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * K)) γ s w x t w2 v u u2 v2 * 2 * (3 / 5 : ℝ) ^ k /
            (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k) - binf)) 0 ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * K)) γ s w x t w2 v u u2 v2 * 2 / (1 - 3 / 5) ^ 2) := by
  set κ : ℝ := 1 + 2 * Real.sqrt (4 + 16 * K) with hκdef
  set G0 : Qpos → V →ₗ[ℝ] V := fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q with hG0
  set M := Mfam (Subtype.val : Qpos → _) rqPos
  have hlift' : ∀ A ∈ Sit, ∀ q, ∃ E : V →ₗ[ℝ] Bsum, IsLiftR (Calias q) (blkF A q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2 := by
    rintro A ⟨k, rfl⟩ q
    exact hlift k q
  obtain ⟨Esel, hEsel⟩ := esel_of_lift Sit
    (fun A q E => IsLiftR (Calias q) (blkF A q) E ∧ ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2)
    hlift'
  refine ⟨Esel, fun k q => (hEsel (Ak k) ⟨k, rfl⟩ q).1, ?_⟩
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hM : OrderPreserving M := Mfam_orderPreserving _ _
  have hG0pos : UniformBracket.Lw 0 G0 := fun q y => by
    simp only [G0, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω q).le)
      (proj_nonneg (Pfam_symm Subtype.val q) (Pfam_idem Subtype.val q) y)
  have hS : ∀ k, (⇑M)^[k] G0 ∈ Sit := fun k => ⟨k, rfl⟩
  have hsymA : ∀ A ∈ Sit, QuadLip.SymFam A := by
    rintro A ⟨k, rfl⟩ q
    exact iterate_symm Subtype.val rqPos k q
  have hposA : ∀ A ∈ Sit, ∀ q y, 0 ≤ ⟪y, A q y⟫ := by
    rintro A ⟨k, rfl⟩ q y
    have h0 := nonneg_iterate M hM hG0pos k q y
    simpa only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] using h0
  have hadj : ∀ A ∈ Sit, ∀ q, LinearMap.adjoint (blkF A q) = blkF A q :=
    fun A hA q => ((LinearMap.isSymmetric_iff_isSelfAdjoint (blkF A q)).mp
      (blkF_symm A (hsymA A hA) q))
  have hκ : ∀ A ∈ Sit, ∀ q y,
      ‖LinearMap.adjoint (LinearMap.id - GammaDiffR.Pi (Calias q) (Esel A q)) y‖ ≤ κ * ‖y‖ :=
    fun A hA q y => KappaGamma.kappa_value (Calias q) (Esel A q) hK (hEsel A hA q).2
      (Calias_normSq_le q) y
  set P' : Qpos → Bsum →ₗ[ℝ] Bsum := fun _ => (κ ^ 2) • LinearMap.id
  set Pb' : Qpos → Bsum →ₗ[ℝ] Bsum := fun _ => LinearMap.id
  have hP' : QuadLip.SymFam P' := fun _ y z => by
    simp only [P', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_left,
      real_inner_smul_right]
  have hPb' : QuadLip.SymFam Pb' := fun _ y z => by simp only [Pb', LinearMap.id_apply]
  have hsymΓ : ∀ A ∈ Sit, QuadLip.SymFam (GamA Esel A) := fun A hA q => by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    exact GammaDiffR.gam_adj (Calias q) (blkF A q) (Esel A q) (hadj A hA q) (hEsel A hA q).1.1
      (hEsel A hA q).1.2
  have hpush : ∀ A ∈ Sit, ∀ B ∈ Sit, ∀ c : ℝ, 0 ≤ c →
      QuadLip.Lw (-(c • Pfam Subtype.val)) (A - B) → QuadLip.Lw (A - B) (c • Pfam Subtype.val) →
      QuadLip.Lw (-(c • P')) (GamA Esel A - GamA Esel B) ∧
        QuadLip.Lw (GamA Esel A - GamA Esel B) (c • P') := by
    intro A hA B hB c hc hlo hhi
    have key : ∀ q y, |⟪y, (GamA Esel A - GamA Esel B) q y⟫| ≤ c * κ ^ 2 * ‖y‖ ^ 2 := by
      intro q y
      have cl : ∀ ζ (z : V), -(c * ⟪z, Pfam Subtype.val (rqPos q ζ) z⟫) ≤
          ⟪z, (A (rqPos q ζ) - B (rqPos q ζ)) z⟫ := fun ζ z => by
        have := hlo (rqPos q ζ) z
        simpa only [Pi.neg_apply, Pi.smul_apply, Pi.sub_apply, LinearMap.neg_apply,
          LinearMap.smul_apply, inner_neg_right, real_inner_smul_right] using this
      have ch : ∀ ζ (z : V), ⟪z, (A (rqPos q ζ) - B (rqPos q ζ)) z⟫ ≤
          c * ⟪z, Pfam Subtype.val (rqPos q ζ) z⟫ := fun ζ z => by
        have := hhi (rqPos q ζ) z
        simpa only [Pi.smul_apply, Pi.sub_apply, LinearMap.smul_apply,
          real_inner_smul_right] using this
      have hl := AliasBlock.blk_lo (A := fun ζ => A (rqPos q ζ)) (B := fun ζ => B (rqPos q ζ))
        (P := fun ζ => Pfam Subtype.val (rqPos q ζ)) cl
      have hh := AliasBlock.blk_hi (A := fun ζ => A (rqPos q ζ)) (B := fun ζ => B (rqPos q ζ))
        (P := fun ζ => Pfam Subtype.val (rqPos q ζ)) ch
      have := GammaDiffR.gam_push (Calias q) (blkF A q) (blkF B q) (Esel A q) (Esel B q)
        (hadj A hA q) (hadj B hB q) (hEsel A hA q).1.1 (hEsel A hA q).1.2 (hEsel B hB q).1.1
        (hEsel B hB q).1.2
        (blkF (Pfam Subtype.val) q) (blkF_symm _ (fun q' => Pfam_symm Subtype.val q') q)
        (blkP_le q) hc (hκ A hA q) (hκ B hB q) hl hh y
      simpa only [GamA, Pi.sub_apply] using this
    constructor
    · intro q y
      have := (abs_le.mp (key q y)).1
      simp only [P', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
    · intro q y
      have := (abs_le.mp (key q y)).2
      simp only [P', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right, real_inner_self_eq_norm_sq]
      linarith
  have hbnd' : ∀ A ∈ Sit, QuadLip.Lw (-(γ • Pb')) (GamA Esel A) ∧
      QuadLip.Lw (GamA Esel A) (γ • Pb') := by
    rintro A ⟨k, rfl⟩
    have hA : Ak k ∈ Sit := ⟨k, rfl⟩
    constructor
    · intro q y
      simp only [Pb', Pi.neg_apply, Pi.smul_apply, LinearMap.neg_apply, LinearMap.smul_apply,
        LinearMap.id_apply, inner_neg_right, real_inner_smul_right]
      have h0 := GammaDiffR.gam_nonneg (Calias q) (blkF (Ak k) q) (Esel (Ak k) q) (hadj _ hA q)
        (AliasBlock.blk_nonneg (fun ζ z => hposA _ hA (rqPos q ζ) z))
        (hEsel _ hA q).1.1 (hEsel _ hA q).1.2 y
      have h1 : 0 ≤ γ * ⟪y, y⟫ := mul_nonneg hγ real_inner_self_nonneg
      simp only [GamA]
      linarith
    · intro q y
      simp only [Pb', Pi.smul_apply, LinearMap.smul_apply, LinearMap.id_apply,
        real_inner_smul_right]
      exact hΓup k q (Esel (Ak k) q) (hEsel _ hA q).1 y
  have hΞ := QuadLip.relLip_of_quadratic₃ (GamA Esel) Sit (Pfam Subtype.val) P' hP' Pb' hPb'
    hpush hbnd' hsymΓ a s w p x t w2 q q2 v u u2 v2
  have hLeq : (∑ i ∈ s, |w i| * ⟪x i, P' (p i) (x i)⟫ +
        ∑ j ∈ t, |w2 j| * (γ *
          (((⟪v j, P' (q j) (v j)⟫ + ⟪u j, P' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, Pb' (q2 j) (u2 j)⟫ + ⟪v2 j, Pb' (q2 j) (v2 j)⟫) / 2) +
           ((⟪v j, Pb' (q j) (v j)⟫ + ⟪u j, Pb' (q j) (u j)⟫) / 2) *
            ((⟪u2 j, P' (q2 j) (u2 j)⟫ + ⟪v2 j, P' (q2 j) (v2 j)⟫) / 2)))) =
      LgamA κ γ s w x t w2 v u u2 v2 := by
    simp only [P', Pb', LinearMap.smul_apply, LinearMap.id_apply, real_inner_smul_right,
      real_inner_self_eq_norm_sq, LgamA]
    rw [mul_add, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
    congr 1
    · exact Finset.sum_congr rfl fun i _ => by ring
    · exact Finset.sum_congr rfl fun j _ => by ring
  rw [hLeq] at hΞ
  have hL0 : 0 ≤ LgamA κ γ s w x t w2 v u u2 v2 := by
    unfold LgamA
    apply mul_nonneg (sq_nonneg _)
    apply add_nonneg
    · exact Finset.sum_nonneg fun i _ => mul_nonneg (abs_nonneg _) (sq_nonneg _)
    · exact mul_nonneg hγ (Finset.sum_nonneg fun j _ => mul_nonneg (abs_nonneg _)
        (div_nonneg (mul_nonneg (by positivity) (by positivity)) (by norm_num)))
  obtain ⟨binf, hlim, hrate, _, _, _, htr⟩ := Coupling35.coupling_converges_35
    (QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2) Sit hL0 hS hΞ
  exact ⟨binf, hlim, hrate, htr⟩

end CouplingGammaAlias

end

-- ===== verbatim copy of an earlier file, lines 8-37 =====
namespace LiftNorm

open scoped RealInnerProductSpace

variable {A B : Type*} [NormedAddCommGroup A] [InnerProductSpace ℝ A] [AddCommGroup B]
  [Module ℝ B]

theorem gamma_norm_le (C : A →ₗ[ℝ] B) (h : LinearMap.BilinForm ℝ A) (hp : ∀ x, 0 ≤ h x x)
    {m Pc : ℝ} (hm : 0 < m) (hPc : 0 ≤ Pc)
    (hpoinc : ∀ d, C d = 0 → m * ‖d‖ ^ 2 ≤ Pc * h d d) {x g : A} (hg : C g = 0)
    (hrep : ∀ k, C k = 0 → h g k = ⟪x, k⟫) :
    ⟪x, g⟫ ≤ Pc / m * ‖x‖ ^ 2 := by
  have hgg : h g g = ⟪x, g⟫ := hrep g hg
  have hP := hpoinc g hg
  have hcs : ⟪x, g⟫ ≤ ‖x‖ * ‖g‖ := real_inner_le_norm x g
  have hh0 := hp g
  -- t := ⟨x,g⟩ = h(g,g) ≥ 0, m‖g‖² ≤ P t, t ≤ ‖x‖‖g‖ ⇒ m t² ≤ P t ‖x‖² ...
  set t := ⟪x, g⟫ with ht
  have ht0 : 0 ≤ t := by rw [← hgg]; exact hh0
  rw [div_mul_eq_mul_div, le_div_iff₀ hm]
  have h1 : m * t ^ 2 ≤ m * (‖x‖ ^ 2 * ‖g‖ ^ 2) := by
    have : t ^ 2 ≤ (‖x‖ * ‖g‖) ^ 2 := pow_le_pow_left₀ ht0 hcs 2
    nlinarith
  have h2 : m * ‖g‖ ^ 2 ≤ Pc * t := by rw [← hgg]; exact hP
  by_cases ht0' : t = 0
  · rw [ht0']; nlinarith [sq_nonneg ‖x‖]
  · have htpos : 0 < t := lt_of_le_of_ne ht0 (Ne.symm ht0')
    have : m * t ^ 2 ≤ ‖x‖ ^ 2 * (Pc * t) := by nlinarith [sq_nonneg ‖x‖]
    nlinarith
end LiftNorm

-- ===== new part : LiftRange =====
/-! # Lifts when `C` is not onto (`C Π = C`), and `hΓup` in that form

Paper (for checking): For the alias constraint `C(q) = ¼ Σ_ζ A_ζ`
(`ran C ⊆ ran P(q)`, not onto):
* **`psd_kkt_lift_range`**: `A` symmetric, positive semidefinite, `C` any linear map ⇒ there is `E`
  with `C Π = C` and `Π A = A Π†` (`Π = E C`). On `ran T` (`T = C A C†`) `E = A C† g`, on a
  complement `U′` of `ran T` `E = g₀ ∘ π_R` with `g₀` a right inverse of `C` onto `R = ran C` and
  `π_R` a projection onto `R`; for `C v = t + u′` one has `u′ ∈ R`, so `C E C v = t + u′`.
* **`gam_up_of_poincareR`**: `GammaUp.gam_up_of_poincare` with `C E = 1` weakened to `C Π = C`. -/

namespace LiftRange

open GammaDiffR
open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

theorem psd_kkt_lift_range (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V)
    (hAs : A.IsSymmetric) (hAp : ∀ x, 0 ≤ ⟪x, A x⟫) :
    ∃ E : W →ₗ[ℝ] V, C ∘ₗ Pi C E = C ∧ Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E) := by
  have hA' : LinearMap.adjoint A = A := (LinearMap.isSymmetric_iff_isSelfAdjoint A).mp hAs
  set T : W →ₗ[ℝ] W := C ∘ₗ A ∘ₗ LinearMap.adjoint C with hT
  have hTapp : ∀ l, T l = C (A (LinearMap.adjoint C l)) := fun _ => rfl
  have hker : LinearMap.ker T ≤ LinearMap.ker (A ∘ₗ LinearMap.adjoint C) := by
    intro l hl
    rw [LinearMap.mem_ker] at hl ⊢
    apply LiftPsd.null_of_psd A hAs hAp
    have e := LinearMap.adjoint_inner_left C (A (LinearMap.adjoint C l)) l
    rw [← hTapp, hl, inner_zero_right] at e
    exact e
  have hTadj : LinearMap.adjoint T = T := by
    rw [hT, LinearMap.adjoint_comp, LinearMap.adjoint_comp, LinearMap.adjoint_adjoint, hA']
    rfl
  have hCAadj : LinearMap.adjoint (A ∘ₗ LinearMap.adjoint C) = C ∘ₗ A := by
    rw [LinearMap.adjoint_comp, LinearMap.adjoint_adjoint, hA']
  have hran : LinearMap.range (C ∘ₗ A) ≤ LinearMap.range T := by
    rw [← hCAadj, ← LinearMap.orthogonal_ker, ← hTadj, ← LinearMap.orthogonal_ker]
    exact Submodule.orthogonal_le hker
  have hTR : LinearMap.range T ≤ LinearMap.range C := by
    rintro _ ⟨l, rfl⟩; exact ⟨A (LinearMap.adjoint C l), rfl⟩
  obtain ⟨g, hg⟩ := T.rangeRestrict.exists_rightInverse_of_surjective T.range_rangeRestrict
  obtain ⟨g₀, hg₀⟩ := C.rangeRestrict.exists_rightInverse_of_surjective C.range_rangeRestrict
  obtain ⟨U', hU⟩ := (LinearMap.range T).exists_isCompl
  obtain ⟨R', hR⟩ := (LinearMap.range C).exists_isCompl
  set πR := Submodule.linearProjOfIsCompl (LinearMap.range C) R' hR
  set E : W →ₗ[ℝ] V :=
    LinearMap.ofIsCompl hU (A ∘ₗ LinearMap.adjoint C ∘ₗ g) (g₀ ∘ₗ πR ∘ₗ U'.subtype) with hEdef
  have hTg : ∀ u : LinearMap.range T, T (g u) = u := by
    intro u
    exact congrArg Subtype.val (LinearMap.congr_fun hg u)
  have hCg₀ : ∀ r : LinearMap.range C, C (g₀ r) = r := by
    intro r
    exact congrArg Subtype.val (LinearMap.congr_fun hg₀ r)
  have hEU : ∀ u : LinearMap.range T, E u = A (LinearMap.adjoint C (g u)) := fun u =>
    LinearMap.ofIsCompl_apply_left hU u
  have hCE : C ∘ₗ Pi C E = C := by
    apply LinearMap.ext; intro v
    show C (E (C v)) = C v
    have hw : C v ∈ LinearMap.range T ⊔ U' := by rw [hU.sup_eq_top]; trivial
    obtain ⟨t, ht, u', hu', htu⟩ := Submodule.mem_sup.mp hw
    have hu'R : u' ∈ LinearMap.range C := by
      have : u' = C v - t := by rw [← htu]; abel
      rw [this]; exact Submodule.sub_mem _ ⟨v, rfl⟩ (hTR ht)
    have e2 : E u' = g₀ (πR u') := LinearMap.ofIsCompl_apply_right hU ⟨u', hu'⟩
    have e3 : πR u' = ⟨u', hu'R⟩ :=
      Submodule.linearProjOfIsCompl_apply_left hR ⟨u', hu'R⟩
    rw [← htu, map_add, map_add,
      show t = ((⟨t, ht⟩ : LinearMap.range T) : W) from rfl, hEU, e2, e3]
    congr 1
    · exact hTg ⟨t, ht⟩
    · exact hCg₀ ⟨u', hu'R⟩
  have hPA : ∀ x y, ⟪E (C (A x)), y⟫ = ⟪x, E (C (A y))⟫ := by
    intro x y
    have hx : C (A x) ∈ LinearMap.range T := hran ⟨x, rfl⟩
    have hy : C (A y) ∈ LinearMap.range T := hran ⟨y, rfl⟩
    have ex : E (C (A x)) = A (LinearMap.adjoint C (g ⟨_, hx⟩)) := hEU ⟨_, hx⟩
    have ey : E (C (A y)) = A (LinearMap.adjoint C (g ⟨_, hy⟩)) := hEU ⟨_, hy⟩
    have tx : T (g ⟨_, hx⟩) = C (A x) := hTg ⟨_, hx⟩
    have ty : T (g ⟨_, hy⟩) = C (A y) := hTg ⟨_, hy⟩
    rw [ex, ey]
    generalize g ⟨_, hx⟩ = μ at tx ⊢
    generalize g ⟨_, hy⟩ = ν at ty ⊢
    have s1 : ⟪A (LinearMap.adjoint C μ), y⟫ = ⟪μ, C (A y)⟫ := by
      rw [hAs, LinearMap.adjoint_inner_left]
    have s2 : ⟪x, A (LinearMap.adjoint C ν)⟫ = ⟪C (A x), ν⟫ := by
      rw [← hAs, LinearMap.adjoint_inner_right]
    have s3 : ⟪T μ, ν⟫ = ⟪μ, T ν⟫ := by
      rw [hTapp, hTapp, ← LinearMap.adjoint_inner_right, hAs, LinearMap.adjoint_inner_left]
    rw [s1, s2, ← tx, ← ty, s3]
  refine ⟨E, hCE, ?_⟩
  show (E ∘ₗ C) ∘ₗ A = A ∘ₗ LinearMap.adjoint (E ∘ₗ C)
  apply LinearMap.ext; intro x
  apply ext_inner_left ℝ; intro y
  simp only [LinearMap.comp_apply]
  have hr : ⟪y, A (LinearMap.adjoint (E ∘ₗ C) x)⟫ = ⟪E (C (A y)), x⟫ := by
    rw [← hAs, LinearMap.adjoint_inner_right]; rfl
  rw [hr]
  have h1 := hPA x y
  have c1 := real_inner_comm y (E (C (A x)))
  have c2 := real_inner_comm x (E (C (A y)))
  linarith

theorem gam_up_of_poincareR (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (E : W →ₗ[ℝ] V) (P : V →ₗ[ℝ] V)
    (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x)
    (hCE : C ∘ₗ Pi C E = C) (hk : Pi C E ∘ₗ A = A ∘ₗ LinearMap.adjoint (Pi C E))
    (hΓP : ∀ z, P (Gam C A E z) = Gam C A E z) (hΓs : (Gam C A E).IsSymmetric)
    (h : LinearMap.BilinForm ℝ V) (hp : ∀ x, 0 ≤ h x x) (hHA : ∀ y k, h (A y) k = ⟪y, P k⟫)
    {m Pc : ℝ} (hm : 0 < m) (hPc : 0 ≤ Pc)
    (hpoinc : ∀ d, C d = 0 → P d = d → m * ‖d‖ ^ 2 ≤ Pc * h d d) (x : V) :
    ⟪x, Gam C A E x⟫ ≤ Pc / m * ‖x‖ ^ 2 := by
  set Γ := Gam C A E with hΓdef
  have hΓP' : ∀ z, Γ (P z) = Γ z := fun z => by
    apply ext_inner_left ℝ; intro y
    rw [← hΓs, ← hPs, hΓP, hΓs]
  have e0 : ⟪x, Γ x⟫ = ⟪P x, Γ (P x)⟫ := by
    rw [hΓP', hPs, hΓP]
  set C' : V →ₗ[ℝ] W × V := LinearMap.prod C (LinearMap.id - P) with hC'
  have hC'0 : ∀ d, C' d = 0 ↔ C d = 0 ∧ P d = d := fun d => by
    have e : C' d = (C d, d - P d) := rfl
    rw [e, Prod.mk_eq_zero, sub_eq_zero]
    exact ⟨fun h => ⟨h.1, h.2.symm⟩, fun h => ⟨h.1, h.2.symm⟩⟩
  have hg : C' (Γ (P x)) = 0 := by
    rw [hC'0]
    refine ⟨?_, hΓP _⟩
    have := LinearMap.congr_fun (C_gam C A E hCE hk) (P x)
    simpa only [LinearMap.comp_apply, LinearMap.zero_apply] using this
  have hrep : ∀ k, C' k = 0 → h (Γ (P x)) k = ⟪P x, k⟫ := by
    intro k hk0
    obtain ⟨hCk, hPk⟩ := (hC'0 k).mp hk0
    have hΓe : Γ (P x) = A (P x - LinearMap.adjoint (Pi C E) (P x)) := by
      rw [hΓdef, gam_eq' C A E hCE hk, map_sub]; rfl
    rw [hΓe, hHA, hPk, inner_sub_left, LinearMap.adjoint_inner_left]
    have : Pi C E k = 0 := by show E (C k) = 0; rw [hCk, map_zero]
    rw [this, inner_zero_right, sub_zero]
  have hpo : ∀ d, C' d = 0 → m * ‖d‖ ^ 2 ≤ Pc * h d d := fun d hd => by
    obtain ⟨h1, h2⟩ := (hC'0 d).mp hd
    exact hpoinc d h1 h2
  have key := LiftNorm.gamma_norm_le C' h hp hm hPc hpo hg hrep
  have hPn : ‖P x‖ ^ 2 ≤ ‖x‖ ^ 2 := by
    have e1 : ‖P x‖ ^ 2 = ⟪x, P x⟫ := by
      rw [← real_inner_self_eq_norm_sq]; conv_lhs => rw [hPs, hPP]
    have hcs : ⟪x, P x⟫ ≤ ‖x‖ * ‖P x‖ := real_inner_le_norm _ _
    have h0 := norm_nonneg (P x)
    have h1 := norm_nonneg x
    nlinarith
  have hc : 0 ≤ Pc / m := div_nonneg hPc hm.le
  rw [e0]
  calc ⟪P x, Γ (P x)⟫ ≤ Pc / m * ‖P x‖ ^ 2 := key
    _ ≤ Pc / m * ‖x‖ ^ 2 := mul_le_mul_of_nonneg_left hPn hc

end LiftRange


-- ===== new part : CouplingGammaAliasPoinc.part.lean =====
/-! # The seam `hΓup` on the alias sum reduced to the Poincaré input (plan-23)

Paper (for checking): `b_k` is determined by the transverse sector only:
the lift has `C E = P(q)` (the transverse half; the gauge part `∇ι` is lifted separately and does
not enter `Γ`), and `Π = E C` is still a projection (`(EC)² = E P C = E C`).
* `gam_rangeA`: `P′ Γ_k = Γ_k` on the alias sum (`P′ = ⊕_ζ P(r_ζ q)`), as `gam_range`.
* **`coupling_converges_gamma_poincare`**: `coupling_converges_gamma_alias` with `hΓup` replaced
  by the Poincaré input: a positive semidefinite form `h_k` with `h_k(A_k y, z) = ⟪y, P′ z⟫`
  (`A_k` is the inverse of `H_k` on `ran P`: `h(y, z) = ⟪y, H_k z⟫` with `A_k H_k = P`,
  `bracket_Qpos_low`) and `m‖d‖² ≤ Pc·h_k(d, d)` on `ker C ∩ ran P′`; then `γ = Pc/m`
  (`LiftRange.gam_up_of_poincareR`). The existence of a lift with `C Π = C` and KKT is
  `LiftRange.psd_kkt_lift_range` (no surjectivity); its size remains the (T4) seam. -/

noncomputable section

namespace CouplingGammaAlias

open Finset Filter Topology UniformBracket OneStepBridge OneStepET OneStepFinal
  CouplingLimit CouplingGamma CouplingGammaLift
open scoped RealInnerProductSpace

theorem blkP_symm (q : Qpos) : (blkF (Pfam Subtype.val) q).IsSymmetric :=
  AliasBlock.blk_symm fun ζ => Pfam_symm Subtype.val _

theorem blkP_idem (q : Qpos) (u : Bsum) :
    blkF (Pfam Subtype.val) q (blkF (Pfam Subtype.val) q u) = blkF (Pfam Subtype.val) q u := by
  apply WithLp.ofLp_injective; funext ζ
  exact Pfam_idem Subtype.val _ _

theorem blkA_P (k : ℕ) (q : Qpos) (z : Bsum) :
    blkF (Ak k) q (blkF (Pfam Subtype.val) q z) = blkF (Ak k) q z := by
  apply WithLp.ofLp_injective; funext ζ
  show Ak k (rqPos q ζ) (Pfam Subtype.val (rqPos q ζ) (z ζ)) = Ak k (rqPos q ζ) (z ζ)
  have hAs : (Ak k (rqPos q ζ)).IsSymmetric := iterate_symm Subtype.val rqPos k _
  have hPA : ∀ y, Pfam Subtype.val (rqPos q ζ) (Ak k (rqPos q ζ) y) = Ak k (rqPos q ζ) y :=
    iterate_P Subtype.val rqPos k _
  apply ext_inner_left ℝ; intro y
  rw [← hAs, ← Pfam_symm Subtype.val, hPA, hAs]

theorem gam_rangeA (k : ℕ) (q : Qpos) (E : V →ₗ[ℝ] Bsum)
    (hL : IsLiftR (Calias q) (blkF (Ak k) q) E) (x : Bsum) :
    blkF (Pfam Subtype.val) q (GammaDiffR.Gam (Calias q) (blkF (Ak k) q) E x) =
      GammaDiffR.Gam (Calias q) (blkF (Ak k) q) E x := by
  set Γ := GammaDiffR.Gam (Calias q) (blkF (Ak k) q) E with hΓ
  set P' := blkF (Pfam Subtype.val) q
  have hAs : (blkF (Ak k) q).IsSymmetric := blkF_symm _ (fun q' => iterate_symm Subtype.val rqPos k q') q
  have hPΓ : ∀ y z, ⟪P' y, Γ z⟫ = ⟪y, Γ z⟫ := fun y z => by
    have h0 : blkF (Ak k) q (y - P' y) = 0 := by rw [map_sub, blkA_P, sub_self]
    have e : Γ z = blkF (Ak k) q z - blkF (Ak k) q (LinearMap.adjoint (GammaDiffR.Pi (Calias q) E) z) := by
      rw [hΓ, GammaDiffR.gam_eq' _ _ _ hL.1 hL.2]; rfl
    have h : ⟪y - P' y, Γ z⟫ = 0 := by
      rw [e, inner_sub_right, ← hAs, ← hAs, h0, inner_zero_left, inner_zero_left, sub_zero]
    rw [inner_sub_left, sub_eq_zero] at h
    exact h.symm
  apply ext_inner_left ℝ; intro y
  rw [← blkP_symm q, hPΓ]

theorem coupling_converges_gamma_poincare {K m Pc : ℝ} (hK : 0 ≤ K) (hm : 0 < m) (hPc : 0 ≤ Pc)
    (hlift : ∀ k q, ∃ E : V →ₗ[ℝ] Bsum, IsLiftR (Calias q) (blkF (Ak k) q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * K) * ‖w‖ ^ 2)
    (hH : ∀ k q, ∃ h : LinearMap.BilinForm ℝ Bsum, (∀ y, 0 ≤ h y y) ∧
      (∀ y z, h (blkF (Ak k) q y) z = ⟪y, blkF (Pfam Subtype.val) q z⟫) ∧
      ∀ d, Calias q d = 0 → blkF (Pfam Subtype.val) q d = d → m * ‖d‖ ^ 2 ≤ Pc * h d d)
    (a : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ) (p : ι → Qpos) (x : ι → Bsum)
    (t : Finset κ') (w2 : κ' → ℝ) (q q2 : κ' → Qpos) (v u u2 v2 : κ' → Bsum) :
    ∃ Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → V →ₗ[ℝ] Bsum,
      (∀ k q, IsLiftR (Calias q) (blkF (Ak k) q) (Esel (Ak k) q)) ∧
      ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k)) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2 (Ak k) - binf| ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * K)) (Pc / m) s w x t w2 v u u2 v2 * 2 *
            (3 / 5 : ℝ) ^ k / (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k) - binf)) 0 ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * K)) (Pc / m) s w x t w2 v u u2 v2 * 2 /
            (1 - 3 / 5) ^ 2) := by
  have hγ : 0 ≤ Pc / m := div_nonneg hPc hm.le
  refine coupling_converges_gamma_alias hK hγ hlift ?_ a s w p x t w2 q q2 v u u2 v2
  intro k q E hL y
  obtain ⟨h, hp, hHA, hpo⟩ := hH k q
  have hA' : LinearMap.adjoint (blkF (Ak k) q) = blkF (Ak k) q :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint _).mp
      (blkF_symm _ (fun q' => iterate_symm Subtype.val rqPos k q') q)
  have hΓs : (GammaDiffR.Gam (Calias q) (blkF (Ak k) q) E).IsSymmetric := by
    rw [LinearMap.isSymmetric_iff_isSelfAdjoint]
    exact GammaDiffR.gam_adj _ _ _ hA' hL.1 hL.2
  have := LiftRange.gam_up_of_poincareR (Calias q) (blkF (Ak k) q) E
    (blkF (Pfam Subtype.val) q) (blkP_symm q) (blkP_idem q) hL.1 hL.2 (gam_rangeA k q E hL)
    hΓs h hp hHA hm hPc hpo y
  rw [real_inner_self_eq_norm_sq]
  exact this

end CouplingGammaAlias

end

#print axioms CouplingGammaAlias.mfam_eq
#print axioms CouplingGammaAlias.Calias_adj
#print axioms CouplingGammaAlias.P_Calias
#print axioms CouplingGammaAlias.Calias_normSq_le
#print axioms CouplingGammaAlias.coupling_converges_gamma_alias

#print axioms LiftPsd.psd_kkt_lift
#print axioms LiftPsd.gam_indep
#print axioms LiftPsd.gam_nonneg
#print axioms CouplingGammaLift.coupling_converges_gamma_lift
#print axioms CouplingGammaLift.gam_range
#print axioms GammaDiffR.gam_push
#print axioms LiftRange.psd_kkt_lift_range
#print axioms LiftRange.gam_up_of_poincareR
#print axioms CouplingGammaAlias.gam_rangeA
#print axioms CouplingGammaAlias.coupling_converges_gamma_poincare

-- ===== verbatim: an earlier file lines 540-end (namespace T4Form), #print axioms removed =====
namespace T4Form

open GammaDiffR
open scoped RealInnerProductSpace

variable {V W : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V] [FiniteDimensional ℝ V]
  [NormedAddCommGroup W] [InnerProductSpace ℝ W] [FiniteDimensional ℝ W]

theorem lift_explicitR (C : V →ₗ[ℝ] W) (A : V →ₗ[ℝ] V) (hA : LinearMap.adjoint A = A)
    (M Q : W →ₗ[ℝ] W) (hM : LinearMap.adjoint M = M) (hQC : Q ∘ₗ C = C)
    (hMinv : (C ∘ₗ A ∘ₗ LinearMap.adjoint C) ∘ₗ M = Q) :
    C ∘ₗ Pi C (A ∘ₗ LinearMap.adjoint C ∘ₗ M) = C ∧
      Pi C (A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ A =
        A ∘ₗ LinearMap.adjoint (Pi C (A ∘ₗ LinearMap.adjoint C ∘ₗ M)) := by
  constructor
  · show (C ∘ₗ A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ C = C
    have e : (C ∘ₗ A ∘ₗ LinearMap.adjoint C ∘ₗ M) = (C ∘ₗ A ∘ₗ LinearMap.adjoint C) ∘ₗ M := rfl
    rw [e, hMinv, hQC]
  · show (A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ C ∘ₗ A =
      A ∘ₗ LinearMap.adjoint ((A ∘ₗ LinearMap.adjoint C ∘ₗ M) ∘ₗ C)
    rw [LinearMap.adjoint_comp, LinearMap.adjoint_comp, LinearMap.adjoint_comp,
      LinearMap.adjoint_adjoint, hA, hM]
    rfl

theorem hcon_of_CE {ι : Type*} [Fintype ι] [DecidableEq ι] (Cc : ι → V →ₗ[ℝ] W) (e : ι → V)
    (w : W) (hCE : ∑ i, Cc i (e i) = w) (z : ι) :
    Cc z (e z) = w - ∑ i ∈ Finset.univ.erase z, Cc i (e i) := by
  rw [← hCE, ← Finset.add_sum_erase _ _ (Finset.mem_univ z)]
  abel

theorem psd_cs (h : V →ₗ[ℝ] V) (hs : h.IsSymmetric) (hp : ∀ x, 0 ≤ ⟪x, h x⟫) (y w : V) :
    ⟪y, h w⟫ ^ 2 ≤ ⟪y, h y⟫ * ⟪w, h w⟫ := by
  have hsw : ⟪w, h y⟫ = ⟪y, h w⟫ := by rw [← hs, real_inner_comm]
  have key : ∀ t : ℝ, 0 ≤ ⟪y, h y⟫ + 2 * t * ⟪y, h w⟫ + t ^ 2 * ⟪w, h w⟫ := by
    intro t
    have h1 := hp (y + t • w)
    simp only [map_add, map_smul, inner_add_left, inner_add_right, real_inner_smul_left,
      real_inner_smul_right] at h1
    rw [hsw] at h1
    nlinarith
  by_cases ha : ⟪w, h w⟫ = 0
  · have hw0 : h w = 0 := LiftPsd.null_of_psd h hs hp ha
    rw [hw0, inner_zero_right, inner_zero_right]; norm_num
  · have ha' : 0 < ⟪w, h w⟫ := lt_of_le_of_ne (hp w) (Ne.symm ha)
    have h1 := key (-⟪y, h w⟫ / ⟪w, h w⟫)
    have e : ⟪y, h y⟫ + 2 * (-⟪y, h w⟫ / ⟪w, h w⟫) * ⟪y, h w⟫ +
        (-⟪y, h w⟫ / ⟪w, h w⟫) ^ 2 * ⟪w, h w⟫ = ⟪y, h y⟫ - ⟪y, h w⟫ ^ 2 / ⟪w, h w⟫ := by
      field_simp; ring
    rw [e] at h1
    have h2 : ⟪y, h w⟫ ^ 2 / ⟪w, h w⟫ ≤ ⟪y, h y⟫ := by linarith
    rwa [div_le_iff₀ ha'] at h2

/-- **`‖h⁻¹ v‖ ≤ ‖v‖ / c` on `ran P` from the lower side `c P ≼ h`**. -/
theorem inv_le_of_lower (h g P : V →ₗ[ℝ] V) (hPs : P.IsSymmetric) {c : ℝ} (hc : 0 < c)
    (hlow : ∀ x, c * ⟪x, P x⟫ ≤ ⟪x, h x⟫) (hhg : ∀ v, h (g v) = P v) (hPg : ∀ v, P (g v) = g v)
    (v : V) : ‖g v‖ ≤ ‖v‖ / c := by
  have h1 := hlow (g v)
  rw [hPg, hhg, real_inner_self_eq_norm_sq] at h1
  have e : ⟪g v, P v⟫ = ⟪g v, v⟫ := by rw [← hPs, hPg]
  rw [e] at h1
  have h2 : ⟪g v, v⟫ ≤ ‖g v‖ * ‖v‖ := real_inner_le_norm _ _
  rw [le_div_iff₀ hc]
  have hg := norm_nonneg (g v)
  rcases eq_or_lt_of_le hg with h0 | hpos
  · rw [← h0, zero_mul]; exact norm_nonneg v
  · nlinarith

/-- **`‖h w‖ ≤ b ‖w‖` from `0 ≼ h ≼ b`**. -/
theorem upper_norm_of_le (h : V →ₗ[ℝ] V) (hs : h.IsSymmetric) (hp : ∀ x, 0 ≤ ⟪x, h x⟫) {b : ℝ}
    (hb : 0 ≤ b) (hup : ∀ x, ⟪x, h x⟫ ≤ b * ‖x‖ ^ 2) (w : V) : ‖h w‖ ≤ b * ‖w‖ := by
  have hcs := psd_cs h hs hp (h w) w
  have e : ⟪h w, h w⟫ = ‖h w‖ ^ 2 := real_inner_self_eq_norm_sq _
  rw [e] at hcs
  have u1 := hup (h w)
  have u2 := hup w
  have p1 := hp (h w)
  have p2 := hp w
  have h3 : (‖h w‖ ^ 2) ^ 2 ≤ (b * ‖h w‖ ^ 2) * (b * ‖w‖ ^ 2) :=
    hcs.trans (mul_le_mul u1 u2 p2 (by positivity))
  have hn := norm_nonneg (h w)
  rcases eq_or_lt_of_le hn with h0 | hpos
  · rw [← h0]; positivity
  · have h4 : ‖h w‖ ^ 2 ≤ (b * ‖w‖) ^ 2 := by
      have hq : 0 < ‖h w‖ ^ 2 := by positivity
      nlinarith
    have hy : 0 ≤ b * ‖w‖ := mul_nonneg hb (norm_nonneg w)
    nlinarith [h4, hy, hpos]

end T4Form


-- ===== new part : LiftSize.part.lean =====
/-! # A3, seam (i): the size of the lift on the alias sum is a theorem

Paper (for checking): (A3 の継ぎ目 (i)). At every stage `k` and coarse
momentum `q`, the explicit KKT lift `E = blkF A_k q ∘ C† ∘ H_{k+1}(q)` (`T4Form.lift_explicitR`,
`H_{k+1}` the inverse of `A_{k+1} = C blkF(A_k) C†` on `ran P(q)`, from `bracket_Qpos_free`) has
`‖E w‖² ≤ 16 · 464880² ‖w‖²`, uniformly in `k` and `q`:
* `‖A_k(r) v‖ ≤ 745/(4ω(r)) ‖v‖` (lower side `(ω/745)P ≼ ¼H_k` of the bracket, `inv_le_of_lower`,
  with `H_k A_k = P` from the injectivity of `A_k` on `ran P`, `lower_side`);
* `‖C† v‖_ζ ≤ ½‖v‖` (`AtM_norm_le`); `‖H_{k+1}(q) w‖ ≤ 1248 ω(q) ‖w‖` (upper side, `H` symmetric);
* `ω(q) ≤ 4 ω(r_ζ)` for every alias (`sin²2θ = 4 sin²θ cos²θ`).
The `ω`'s cancel: `745/(4ω_r) · ½ · 1248 ω_q ≤ 745 · 624 = 464880`. The constant `4` of (T4) is not
needed for the convergence of `b_k`; any uniform constant gives a finite `κ`.
* **`hlift_holds`**: the seam `hlift` of `coupling_converges_gamma_alias` with `K = 464880²`. -/

noncomputable section

namespace AliasLiftSize

open Finset UniformBracket OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal
  OneStepLower CouplingGammaLift CouplingGammaAlias
open scoped RealInnerProductSpace

/-- `ω(q) ≤ 4 ω(r_ζ)`. -/
theorem omF_le_four_alias (q : Qpos) (ζ : Fin 4 → Bool) :
    omF Subtype.val q ≤ 4 * omF Subtype.val (rqPos q ζ) := by
  unfold omF
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  show 4 * sQ q.1 ν ^ 2 ≤ 4 * (4 * sQ (thR q.1 ζ) ν ^ 2)
  rw [sQ_thR, sQ_sq_alias q.1 ζ ν]
  have h1 : cR q.1 ζ ν ^ 2 ≤ 1 := by rw [cR_sq]; nlinarith [sq_nonneg (sR q.1 ζ ν)]
  have h0 := sq_nonneg (sR q.1 ζ ν)
  nlinarith

theorem omF_pos (q : Qpos) : 0 < omF Subtype.val q := q.2

theorem Ak_P (k : ℕ) (q : Qpos) (v : V) : Ak k q (Pfam Subtype.val q v) = Ak k q v := by
  have hAs := iterate_symm Subtype.val rqPos k q
  have hPA := iterate_P Subtype.val rqPos k q
  apply ext_inner_left ℝ; intro y
  rw [← hAs, ← Pfam_symm Subtype.val, hPA, hAs]

theorem a_pos : (0 : ℝ) < 4 / Real.pi ^ 2 * (0.04452 : ℝ) ^ 2 := by positivity

theorem Ak_lower (k : ℕ) (q : Qpos) (x : V) :
    4 / Real.pi ^ 2 * (0.04452 : ℝ) ^ 2 * ((omF Subtype.val q)⁻¹ * ⟪x, Pfam Subtype.val q x⟫) ≤
      ⟪x, Ak k q x⟫ := by
  have h := lower_side Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) k q x
  simpa only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] using h

theorem Ak_inj (k : ℕ) (q : Qpos) {d : V} (hPd : Pfam Subtype.val q d = d)
    (hAd : Ak k q d = 0) : d = 0 := by
  have h := Ak_lower k q d
  rw [hAd, inner_zero_right, hPd, real_inner_self_eq_norm_sq] at h
  have ha := a_pos
  have hw : 0 < (omF Subtype.val q)⁻¹ := inv_pos.mpr (omF_pos q)
  have h2 : ‖d‖ ^ 2 ≤ 0 := by
    by_contra hne
    push_neg at hne
    have := mul_pos ha (mul_pos hw hne)
    linarith
  have h3 : ‖d‖ = 0 := by nlinarith [norm_nonneg d]
  exact norm_eq_zero.mp h3

section WithH

variable (H : ℕ → Qpos → V →ₗ[ℝ] V)
  (hH : ∀ k q x, Ak k q (H k q x) = Pfam Subtype.val q x)
  (hHP : ∀ k q x, Pfam Subtype.val q (H k q x) = H k q x)
  (hbr : ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
    ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫)

include hH hHP in
theorem H_A (k : ℕ) (q : Qpos) (v : V) : H k q (Ak k q v) = Pfam Subtype.val q v := by
  have hd : H k q (Ak k q v) - Pfam Subtype.val q v = 0 := by
    apply Ak_inj k q
    · rw [map_sub, hHP, Pfam_idem]
    · rw [map_sub, hH, Ak_P, iterate_P Subtype.val rqPos k q v, sub_self]
  exact sub_eq_zero.mp hd

include hH hHP in
theorem H_symm (k : ℕ) (q : Qpos) : (H k q).IsSymmetric := by
  intro x y
  have hAs := iterate_symm Subtype.val rqPos k q
  have hPs := Pfam_symm Subtype.val q
  calc ⟪H k q x, y⟫ = ⟪Pfam Subtype.val q (H k q x), y⟫ := by rw [hHP]
    _ = ⟪H k q x, Pfam Subtype.val q y⟫ := hPs _ _
    _ = ⟪H k q x, Ak k q (H k q y)⟫ := by rw [hH]
    _ = ⟪Ak k q (H k q x), H k q y⟫ := (hAs _ _).symm
    _ = ⟪Pfam Subtype.val q x, H k q y⟫ := by rw [hH]
    _ = ⟪x, Pfam Subtype.val q (H k q y)⟫ := hPs _ _
    _ = ⟪x, H k q y⟫ := by rw [hHP]

include hH hHP hbr in
/-- `4 ω(q) ‖A_k(q) v‖ ≤ 745 ‖v‖`. -/
theorem Ak_norm_le (k : ℕ) (q : Qpos) (v : V) :
    4 * omF Subtype.val q * ‖Ak k q v‖ ≤ 745 * ‖v‖ := by
  have hc : 0 < omF Subtype.val q / 745 := div_pos (omF_pos q) (by norm_num)
  have h := T4Form.inv_le_of_lower ((1 / 4 : ℝ) • H k q) ((4 : ℝ) • Ak k q) (Pfam Subtype.val q)
    (Pfam_symm Subtype.val q) hc (fun x => (hbr k q x).1)
    (fun v => by
      rw [LinearMap.smul_apply, LinearMap.smul_apply, map_smul, H_A H hH hHP, smul_smul]
      norm_num)
    (fun v => by rw [LinearMap.smul_apply, map_smul, iterate_P Subtype.val rqPos k q v]) v
  rw [LinearMap.smul_apply, norm_smul, le_div_iff₀ hc] at h
  have e : ‖(4 : ℝ)‖ = 4 := by norm_num
  rw [e] at h
  have hw := omF_pos q
  nlinarith [norm_nonneg (Ak k q v), norm_nonneg v]

include hH hHP hbr in
/-- `‖H_k(q) w‖ ≤ 1248 ω(q) ‖w‖`. -/
theorem H_norm_le (k : ℕ) (q : Qpos) (w : V) :
    ‖H k q w‖ ≤ 1248 * omF Subtype.val q * ‖w‖ := by
  have hw := omF_pos q
  refine T4Form.upper_norm_of_le (H k q) (H_symm H hH hHP k q) (fun x => ?_) (by positivity)
    (fun x => ?_) w
  · have h1 := (hbr k q x).1
    have h2 := CouplingGamma.inner_P_le_norm q x
    have h3 : 0 ≤ ⟪x, Pfam Subtype.val q x⟫ := inner_P_nonneg Subtype.val q x
    rw [LinearMap.smul_apply, real_inner_smul_right] at h1
    have : 0 ≤ omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ := by positivity
    linarith
  · have h1 := (hbr k q x).2
    have h2 := CouplingGamma.inner_P_le_norm q x
    rw [LinearMap.smul_apply, real_inner_smul_right] at h1
    nlinarith

end WithH

theorem Calias_adjoint (q : Qpos) : LinearMap.adjoint (Calias q) = CaliasT q := by
  symm
  rw [LinearMap.eq_adjoint_iff]
  intro x y
  calc ⟪CaliasT q x, y⟫ = ⟪y, CaliasT q x⟫ := real_inner_comm _ _
    _ = ⟪Calias q y, x⟫ := (Calias_adj q y x).symm
    _ = ⟪x, Calias q y⟫ := real_inner_comm _ _

theorem CaliasT_norm_le (q : Qpos) (v : V) (ζ : Z) : ‖CaliasT q v ζ‖ ≤ (1 / 2) * ‖v‖ := by
  rw [CaliasT_apply, norm_smul]
  have h := AtM_norm_le q.1 ζ v
  have h2 : ‖Matrix.toEuclideanLin (AtM q.1 ζ) v‖ ≤ 2 * ‖v‖ := by
    nlinarith [norm_nonneg (Matrix.toEuclideanLin (AtM q.1 ζ) v), norm_nonneg v]
  have e : ‖(1 / 4 : ℝ)‖ = 1 / 4 := by norm_num
  rw [e]
  linarith

theorem stage_succ (k : ℕ) (q : Qpos) (x : V) :
    Calias q (blkF (Ak k) q (CaliasT q x)) = Ak (k + 1) q x := by
  rw [← mfam_eq]
  show _ = ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k + 1]
    (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) q x
  rw [Function.iterate_succ_apply']

/-- The constant of the lift. -/
def Klift : ℝ := 464880 ^ 2

/-- **A3 seam (i)**: the lift exists with a size uniform in `k` and `q`. -/
theorem hlift_holds (k : ℕ) (q : Qpos) :
    ∃ E : V →ₗ[ℝ] Bsum, IsLiftR (Calias q) (blkF (Ak k) q) E ∧
      ∀ w, ‖E w‖ ^ 2 ≤ (4 + 16 * Klift) * ‖w‖ ^ 2 := by
  obtain ⟨H, hH, hHP, hbr⟩ := bracket_Qpos_free
  set M := H (k + 1) q with hMdef
  have hMs : (M).IsSymmetric := H_symm H hH hHP (k + 1) q
  have hMadj : LinearMap.adjoint M = M :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint M).mp hMs
  have hBadj : LinearMap.adjoint (blkF (Ak k) q) = blkF (Ak k) q :=
    (LinearMap.isSymmetric_iff_isSelfAdjoint _).mp
      (blkF_symm _ (fun q' => iterate_symm Subtype.val rqPos k q') q)
  have hQC : Pfam Subtype.val q ∘ₗ Calias q = Calias q :=
    LinearMap.ext fun u => P_Calias q u
  have hMinv : (Calias q ∘ₗ blkF (Ak k) q ∘ₗ LinearMap.adjoint (Calias q)) ∘ₗ M =
      Pfam Subtype.val q := by
    ext x
    rw [Calias_adjoint]
    simp only [LinearMap.comp_apply]
    rw [stage_succ, hMdef, hH]
  obtain ⟨h1, h2⟩ := T4Form.lift_explicitR (Calias q) (blkF (Ak k) q) hBadj M
    (Pfam Subtype.val q) hMadj hQC hMinv
  refine ⟨blkF (Ak k) q ∘ₗ LinearMap.adjoint (Calias q) ∘ₗ M, ⟨h1, h2⟩, fun w => ?_⟩
  -- the size
  have hcomp : ∀ ζ : Z, ‖(blkF (Ak k) q ∘ₗ LinearMap.adjoint (Calias q) ∘ₗ M) w ζ‖ ≤
      464880 * ‖w‖ := by
    intro ζ
    rw [Calias_adjoint]
    set r := rqPos q ζ
    have e : (blkF (Ak k) q ∘ₗ CaliasT q ∘ₗ M) w ζ = Ak k r (CaliasT q (M w) ζ) := rfl
    rw [e]
    have hA := Ak_norm_le H hH hHP hbr k r (CaliasT q (M w) ζ)
    have hC := CaliasT_norm_le q (M w) ζ
    have hM := H_norm_le H hH hHP hbr (k + 1) q w
    have hωr := omF_pos r
    have hωq := omF_pos q
    have h4 := omF_le_four_alias q ζ
    have hn0 := norm_nonneg w
    have hMn := norm_nonneg (M w)
    have key : 4 * omF Subtype.val r * ‖Ak k r (CaliasT q (M w) ζ)‖ ≤
        4 * omF Subtype.val r * (464880 * ‖w‖) := by
      calc 4 * omF Subtype.val r * ‖Ak k r (CaliasT q (M w) ζ)‖
          ≤ 745 * ‖CaliasT q (M w) ζ‖ := hA
        _ ≤ 745 * ((1 / 2) * ‖M w‖) := by linarith
        _ ≤ 745 * ((1 / 2) * (1248 * omF Subtype.val q * ‖w‖)) := by
            have := mul_le_mul_of_nonneg_left hM (by norm_num : (0 : ℝ) ≤ 745 * (1 / 2))
            linarith
        _ ≤ 745 * ((1 / 2) * (1248 * (4 * omF Subtype.val r) * ‖w‖)) := by
            have := mul_le_mul_of_nonneg_right h4 hn0
            nlinarith
        _ = 4 * omF Subtype.val r * (464880 * ‖w‖) := by ring
    exact le_of_mul_le_mul_left key (by positivity)
  rw [PiLp.norm_sq_eq_of_L2]
  calc ∑ ζ : Z, ‖(blkF (Ak k) q ∘ₗ LinearMap.adjoint (Calias q) ∘ₗ M) w ζ‖ ^ 2
      ≤ ∑ _ζ : Z, (464880 * ‖w‖) ^ 2 :=
        Finset.sum_le_sum fun ζ _ => pow_le_pow_left₀ (norm_nonneg _) (hcomp ζ) 2
    _ = 16 * (464880 * ‖w‖) ^ 2 := by
        rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_bool,
          Fintype.card_fin, nsmul_eq_mul]; norm_num
    _ ≤ (4 + 16 * Klift) * ‖w‖ ^ 2 := by
        unfold Klift; nlinarith [sq_nonneg ‖w‖]

end AliasLiftSize

end


-- ===== verbatim: an earlier file lines 3746-3978 (OneStepCell §1-2) =====
noncomputable section
namespace OneStepCell

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. Proposition 1: `N ≽ 11/48` on the lowest cell -/

set_option maxRecDepth 8000 in
/-- `|u|² − ⟨u, N u⟩ = ½ Σ_{μ<ν} 𝔅_{μν} (s_ν u_μ − s_μ u_ν)²`. -/
theorem IminusN_pairs (s u : Fin 4 → ℝ) :
    dot u u - dot u (Nm s u) = (1 / 2) * (
      (1 - Ef (xs s 2) (xs s 3)) * (s 1 * u 0 - s 0 * u 1) ^ 2
    + (1 - Ef (xs s 1) (xs s 3)) * (s 2 * u 0 - s 0 * u 2) ^ 2
    + (1 - Ef (xs s 1) (xs s 2)) * (s 3 * u 0 - s 0 * u 3) ^ 2
    + (1 - Ef (xs s 0) (xs s 3)) * (s 2 * u 1 - s 1 * u 2) ^ 2
    + (1 - Ef (xs s 0) (xs s 2)) * (s 3 * u 1 - s 1 * u 3) ^ 2
    + (1 - Ef (xs s 0) (xs s 1)) * (s 3 * u 2 - s 2 * u 3) ^ 2) := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

/-- Lagrange: `Σ_{μ<ν} (s_ν u_μ − s_μ u_ν)² = |s|²|u|² − ⟨s, u⟩²`. -/
theorem lagrange4 (s u : Fin 4 → ℝ) :
    (s 1 * u 0 - s 0 * u 1) ^ 2 + (s 2 * u 0 - s 0 * u 2) ^ 2 + (s 3 * u 0 - s 0 * u 3) ^ 2
      + (s 2 * u 1 - s 1 * u 2) ^ 2 + (s 3 * u 1 - s 1 * u 3) ^ 2 + (s 3 * u 2 - s 2 * u 3) ^ 2
      = dot s s * dot u u - dot s u ^ 2 := by
  unfold dot; simp only [Fin.sum_univ_four]; ring

/-- `𝔅 |s|² ≤ 37/24` for one pair (`f(s, t) ≤ f(½, ½)` of Proposition 1). -/
theorem pair_bound {y z S : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 4) (hz : 0 ≤ z ∧ z ≤ 1 / 4)
    (_hS0 : 0 ≤ S) (hS : S ≤ 1 + 2 * (y + z)) : (1 - Ef y z) * S ≤ 37 / 24 := by
  unfold Ef
  have hB : 0 ≤ 1 - ((y + z) / 2 - y * z / 3) := by nlinarith
  have h1 : (1 - ((y + z) / 2 - y * z / 3)) * S ≤
      (1 - ((y + z) / 2 - y * z / 3)) * (1 + 2 * (y + z)) := mul_le_mul_of_nonneg_left hS hB
  have ha : 0 ≤ 1 / 4 - y := by linarith
  have hb : 0 ≤ 1 / 4 - z := by linarith
  nlinarith [mul_nonneg (mul_nonneg ha ha) hb, mul_nonneg (mul_nonneg ha hb) hb, mul_nonneg ha hb,
    mul_nonneg ha ha, mul_nonneg hb hb]

theorem sum6_bound {S W B1 B2 B3 B4 B5 B6 r1 r2 r3 r4 r5 r6 : ℝ}
    (h1 : B1 * S * r1 ≤ 37 / 24 * r1) (h2 : B2 * S * r2 ≤ 37 / 24 * r2)
    (h3 : B3 * S * r3 ≤ 37 / 24 * r3) (h4 : B4 * S * r4 ≤ 37 / 24 * r4)
    (h5 : B5 * S * r5 ≤ 37 / 24 * r5) (h6 : B6 * S * r6 ≤ 37 / 24 * r6)
    (hl : r1 + r2 + r3 + r4 + r5 + r6 = S * W) :
    S * ((1 / 2) * (B1 * r1 + B2 * r2 + B3 * r3 + B4 * r4 + B5 * r5 + B6 * r6)) ≤
      S * ((37 / 48) * W) := by
  have e : S * ((1 / 2) * (B1 * r1 + B2 * r2 + B3 * r3 + B4 * r4 + B5 * r5 + B6 * r6)) =
      (1 / 2) * (B1 * S * r1 + B2 * S * r2 + B3 * S * r3 + B4 * S * r4 + B5 * S * r5 +
        B6 * S * r6) := by ring
  have e2 : S * ((37 / 48) * W) = (1 / 2) * (37 / 24 * (S * W)) := by ring
  rw [e, e2, ← hl]
  linarith

theorem Ef_le_one' {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 4) (hz : 0 ≤ z ∧ z ≤ 1 / 4) :
    0 ≤ 1 - Ef y z := by
  unfold Ef; nlinarith

/-- **Proposition 1**: `N ≽ 11/48` on `s^⊥` when every `x_ν = s_ν²/2 ≤ ¼`. -/
theorem Nm_cell_lower {s w : Fin 4 → ℝ} (hx : ∀ ν, xs s ν ≤ 1 / 4) (hw : dot s w = 0) :
    (11 / 48) * dot w w ≤ dot w (Nm s w) := by
  have hx' : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 4 := fun ν => ⟨by unfold xs; positivity, hx ν⟩
  have hsq : ∀ ν, s ν ^ 2 = 2 * xs s ν := fun ν => by unfold xs; ring
  have hSdef : dot s s = 2 * (xs s 0 + xs s 1 + xs s 2 + xs s 3) := by
    unfold dot; simp only [Fin.sum_univ_four]
    have := hsq 0; have := hsq 1; have := hsq 2; have := hsq 3
    nlinarith
  have hS0 := dot_self_nonneg s
  have hW0 := dot_self_nonneg w
  have hform := IminusN_pairs s w
  have hlag := lagrange4 s w
  rw [hw] at hlag
  set S := dot s s
  have b01 := pair_bound (hx' 2) (hx' 3) hS0 (by linarith [hx' 0, hx' 1])
  have b02 := pair_bound (hx' 1) (hx' 3) hS0 (by linarith [hx' 0, hx' 2])
  have b03 := pair_bound (hx' 1) (hx' 2) hS0 (by linarith [hx' 0, hx' 3])
  have b12 := pair_bound (hx' 0) (hx' 3) hS0 (by linarith [hx' 1, hx' 2])
  have b13 := pair_bound (hx' 0) (hx' 2) hS0 (by linarith [hx' 1, hx' 3])
  have b23 := pair_bound (hx' 0) (hx' 1) hS0 (by linarith [hx' 2, hx' 3])
  have t01 := mul_le_mul_of_nonneg_right b01 (sq_nonneg (s 1 * w 0 - s 0 * w 1))
  have t02 := mul_le_mul_of_nonneg_right b02 (sq_nonneg (s 2 * w 0 - s 0 * w 2))
  have t03 := mul_le_mul_of_nonneg_right b03 (sq_nonneg (s 3 * w 0 - s 0 * w 3))
  have t12 := mul_le_mul_of_nonneg_right b12 (sq_nonneg (s 2 * w 1 - s 1 * w 2))
  have t13 := mul_le_mul_of_nonneg_right b13 (sq_nonneg (s 3 * w 1 - s 1 * w 3))
  have t23 := mul_le_mul_of_nonneg_right b23 (sq_nonneg (s 3 * w 2 - s 2 * w 3))
  -- `S (|w|² − ⟨w, N w⟩) ≤ (37/48) S |w|²`
  have hlag' : (s 1 * w 0 - s 0 * w 1) ^ 2 + (s 2 * w 0 - s 0 * w 2) ^ 2
      + (s 3 * w 0 - s 0 * w 3) ^ 2 + (s 2 * w 1 - s 1 * w 2) ^ 2
      + (s 3 * w 1 - s 1 * w 3) ^ 2 + (s 3 * w 2 - s 2 * w 3) ^ 2 = S * dot w w := by
    rw [hlag]; ring
  have hmain : S * (dot w w - dot w (Nm s w)) ≤ S * ((37 / 48) * dot w w) := by
    rw [hform]
    exact sum6_bound t01 t02 t03 t12 t13 t23 hlag'
  rcases eq_or_lt_of_le hS0 with h0 | hpos
  · -- `s = 0`
    have hs0 : ∀ ν, s ν = 0 := by
      intro ν
      have h' : ∑ j, s j * s j = 0 := h0.symm
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' ν
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    have : dot w w - dot w (Nm s w) = 0 := by
      rw [hform]; simp only [hs0]; ring
    linarith only [this, hW0]
  · have h37 := le_of_mul_le_mul_left hmain hpos
    linarith only [h37]

theorem Nm_smul (s v : Fin 4 → ℝ) (a : ℝ) :
    Nm s (fun i => a * v i) = fun μ => a * Nm s v μ := by
  funext μ
  show piF (xs s) μ * (a * v μ) + 1 / 2 * s μ *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * (a * v ν)) =
    a * (piF (xs s) μ * v μ + 1 / 2 * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * v ν))
  have h : ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * (a * v ν)) =
      a * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * v ν) := by
    rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ν _ => by ring
  rw [h]; ring

/-- **`N ≽ 11/48` on all of `ℝ⁴`** in the lowest cell (`N s = s`, `N` symmetric). -/
theorem Nm_cell_full {s : Fin 4 → ℝ} (hx : ∀ ν, xs s ν ≤ 1 / 4) (u : Fin 4 → ℝ) :
    (11 / 48) * dot u u ≤ dot u (Nm s u) := by
  set a := dot s u / dot s s
  set w := proj s u with hw_def
  have hw : dot s w = 0 := dot_proj s u
  have hu : u = w + fun i => a * s i := by
    funext i; simp only [Pi.add_apply, hw_def, proj]; ring
  have hNw := Nm_cell_lower hx hw
  have hNu : Nm s u = Nm s w + fun i => a * s i := by
    rw [hu, Nm_add, Nm_smul, Nm_self]
  have hsNw : dot s (Nm s w) = 0 := by rw [Nm_symm, Nm_self, hw]
  have hws : dot w s = 0 := by rw [dot_comm, hw]
  have hSs := dot_self_nonneg s
  have e1 : dot u u = dot w w + a ^ 2 * dot s s := by
    rw [hu]
    simp only [dot_add_left, dot_add_right]
    have h1 : dot w (fun i => a * s i) = a * dot w s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h2 : dot (fun i => a * s i) w = a * dot s w := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h3 : dot (fun i => a * s i) (fun i => a * s i) = a ^ 2 * dot s s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [h1, h2, h3, hws, hw]; ring
  have e2 : dot u (Nm s u) = dot w (Nm s w) + a ^ 2 * dot s s := by
    rw [hNu]
    conv_lhs => rw [hu]
    simp only [dot_add_left, dot_add_right]
    have h1 : dot w (fun i => a * s i) = a * dot w s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h2 : dot (fun i => a * s i) (Nm s w) = a * dot s (Nm s w) := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h3 : dot (fun i => a * s i) (fun i => a * s i) = a ^ 2 * dot s s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [h1, h2, h3, hws, hsNw]; ring
  rw [e1, e2]
  nlinarith [mul_nonneg (sq_nonneg a) hSs]

/-- From a form bound to a norm bound: `c|u|² ≤ ⟨u, N u⟩`, `c ≥ 0` give `c²|u|² ≤ |N u|²`. -/
theorem sq_of_form {s u : Fin 4 → ℝ} {c : ℝ} (hc : 0 ≤ c) (h : c * dot u u ≤ dot u (Nm s u)) :
    c ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) := by
  have hA := dot_self_nonneg u
  have hB := dot_self_nonneg (Nm s u)
  have hcs := dot_cs u (Nm s u)
  have hc0 : 0 ≤ c * dot u u := mul_nonneg hc hA
  have hsq : (c * dot u u) ^ 2 ≤ dot u (Nm s u) ^ 2 := pow_le_pow_left₀ hc0 h 2
  rcases eq_or_lt_of_le hA with h0 | hpos
  · rw [← h0]; simpa using hB
  · have : dot u u * (c ^ 2 * dot u u) ≤ dot u u * dot (Nm s u) (Nm s u) := by nlinarith
    exact le_of_mul_le_mul_left this hpos

/-! ## 2. Proposition 2 at the alias nearest to the origin -/

/-- The alias nearest to the origin is in the lowest cell: `sin²(r_ν/2) ≤ ½` for every `θ`. -/
theorem zstar_cell (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ 1 / 2 := by
  have h := alias_scale θ 0 (fun ν => by rw [bS_zero]; exact Real.sin_sq_le_one _) ν
  have e : bS (0 + 1) = 1 / 2 := by
    rw [bS_succ]
    have : π / 2 ^ (0 + 1) = π / 2 := by norm_num
    rw [this, Real.cos_pi_div_two]; norm_num
  linarith

theorem dot_C_lower (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (v : Fin 4 → ℝ) :
    (1 - b) * dot v v ≤ dot (fun ν => cR θ ζ ν * v ν) (fun ν => cR θ ζ ν * v ν) := by
  unfold dot
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  have e : cR θ ζ ν * v ν * (cR θ ζ ν * v ν) = cR θ ζ ν ^ 2 * (v ν * v ν) := by ring
  rw [e, cR_sq]
  exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)

/-- **Proposition 2 (real form) at the lowest alias `ζ*`**: with `Q̃ = 2 C N` (`C = diag cos`),
`|Q̃ᵀ v|² = |2 N C v|² ≥ (121/1152)|v|²` for every `θ` and `v`. -/
theorem lowest_alias_lower (θ v : Fin 4 → ℝ) :
    (121 / 1152) * dot v v ≤
      dot (fun μ => 2 * Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2))
          (fun ν => cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν * v ν) μ)
        (fun μ => 2 * Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2))
          (fun ν => cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν * v ν) μ) := by
  set ζ := zstar fun ν => Real.sin (θ ν) ^ 2
  have hcell := zstar_cell θ
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ 1 / 4 := fun ν => by unfold xs; linarith [hcell ν]
  have h1 := sq_of_form (by norm_num : (0 : ℝ) ≤ 11 / 48)
    (Nm_cell_full hx (fun ν => cR θ ζ ν * v ν))
  have h2 := dot_C_lower θ ζ hcell v
  have e : dot (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν) μ)
      (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν) μ) =
      4 * dot (Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν)) (Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν)) := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
  rw [e]
  have hv := dot_self_nonneg v
  nlinarith

/-- The other order, `|Q̃ v|² = |2 C N v|² ≥ (121/1152)|v|²` at `ζ*`. -/
theorem lowest_alias_lower' (θ v : Fin 4 → ℝ) :
    (121 / 1152) * dot v v ≤
      dot (fun μ => 2 * (cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) μ *
          Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2)) v μ))
        (fun μ => 2 * (cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) μ *
          Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2)) v μ)) := by
  set ζ := zstar fun ν => Real.sin (θ ν) ^ 2
  have hcell := zstar_cell θ
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ 1 / 4 := fun ν => by unfold xs; linarith [hcell ν]
  have h1 := sq_of_form (by norm_num : (0 : ℝ) ≤ 11 / 48) (Nm_cell_full hx v)
  have h2 := dot_C_lower θ ζ hcell (Nm (sR θ ζ) v)
  have e : dot (fun μ => 2 * (cR θ ζ μ * Nm (sR θ ζ) v μ))
      (fun μ => 2 * (cR θ ζ μ * Nm (sR θ ζ) v μ)) =
      4 * dot (fun μ => cR θ ζ μ * Nm (sR θ ζ) v μ) (fun μ => cR θ ζ μ * Nm (sR θ ζ) v μ) := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
  rw [e]
  have hv := dot_self_nonneg v
  nlinarith

end OneStepCell
end

-- ===== new part : AliasPoinc.part.lean =====
/-! # A3, seam (ii): the Poincaré input on the alias sum is a theorem, and `b_k` converges

Paper (for checking): (A3 の継ぎ目 (ii)) and §3 (合成).
* `low_core`, **`AM_low`**: at the lowest alias `ζ*`, on `ran P(r_{ζ*})` the alias map of `𝓜`
  (`A_{ζ*} = 2 P(q) S C P(r) N`, with the projection `P(q)` in front) is bounded below with the
  constant of proposition N: `(121/1152)‖v‖² ≤ ‖A_{ζ*} v‖²`. Reason: `A_{ζ*}` without `P(q)` maps
  `s = sR` to `g = sQ` (`N s = s`, `sQ = 2 sR cR sg`), so `P(q) Q̃ v = Q̃(v − 2t s)` and
  `‖v − 2t s‖ ≥ ‖v‖` for `v ⊥ s` (`lowest_alias_lower'` applied to `v − 2t s`).
* `ker_lowest`: on `ker C ∩ ran P′`, `‖d_{ζ*}‖² ≤ (69120/121) Σ_{ζ≠ζ*} ‖d_ζ‖²`
  (`‖A_ζ‖ ≤ 2`, fifteen other aliases; the same `C_N` as `C_N_value`).
* **`hH_holds`**: the input of `coupling_converges_gamma_poincare` with `h_k(y,z) = ⟨y, ⊕H_k z⟩`,
  `m = 8/745`, `Pc = 1 + 69120/121` (`ω(r_ζ) ≥ 2` off `ζ*`, `omR_far`).
* **`coupling_converges_gamma_closed`**: `b_k = Ξ(Γ_k)` converges with rate `(3/5)^k` and a finite
  transient sum, on the alias sum, **with no hypothesis**. -/

noncomputable section

namespace AliasPoinc

open Finset Filter Topology UniformBracket OneStepNorm OneStepHrep OneStepBridge OneStepET
  OneStepFinal OneStepLower OneStepCell Matrix CouplingGammaLift CouplingGammaAlias AliasLiftSize
open scoped RealInnerProductSpace

/-- `sQ = 2 sR cR sg` on every alias. -/
theorem sQ_eq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sQ θ ν = 2 * sR θ ζ ν * cR θ ζ ν * sg ζ ν := by
  unfold sQ sR cR phi sg
  cases ζ ν
  · simp only [Bool.false_eq_true, if_false, add_zero, Real.sin_two_mul]; ring
  · simp only [if_true, Real.sin_add_pi_div_two, Real.cos_add_pi_div_two, Real.sin_two_mul]; ring

theorem AM_mulVec (θ v : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    AM θ ζ *ᵥ v = fun μ => 2 * proj (sQ θ)
      (fun ν => cR θ ζ ν * sg ζ ν * proj (sR θ ζ) (Nm (sR θ ζ) v) ν) μ := by
  unfold AM
  rw [Matrix.smul_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [projM_mulVec, diag_mulVec, NM_mulVec]
  funext μ
  simp only [Pi.smul_apply, smul_eq_mul]

/-- The core: the projection `P(q)` in front does not lower the bound of proposition N. -/
theorem low_core (s c sgv g v : Fin 4 → ℝ) (hg : ∀ ν, g ν = 2 * s ν * c ν * sgv ν)
    (hsg : ∀ ν, sgv ν ^ 2 = 1) (hv : dot s v = 0)
    (hlow : ∀ w, (121 / 1152) * dot w w ≤
      dot (fun μ => 2 * (c μ * Nm s w μ)) (fun μ => 2 * (c μ * Nm s w μ))) :
    (121 / 1152) * dot v v ≤
      dot (fun μ => 2 * proj g (fun ν => c ν * sgv ν * proj s (Nm s v) ν) μ)
        (fun μ => 2 * proj g (fun ν => c ν * sgv ν * proj s (Nm s v) ν) μ) := by
  have hsu : dot s (Nm s v) = 0 := dot_Nm_of_dot hv
  rw [proj_of_dot hsu]
  obtain ⟨t, ht⟩ : ∃ t : ℝ, t = dot g (fun ν => c ν * sgv ν * Nm s v ν) / dot g g := ⟨_, rfl⟩
  have key : (fun μ => 2 * proj g (fun ν => c ν * sgv ν * Nm s v ν) μ) =
      fun μ => sgv μ * (2 * (c μ * Nm s (v - fun i => (2 * t) * s i) μ)) := by
    funext μ
    rw [Nm_sub, Nm_smul, Nm_self]
    simp only [proj, Pi.sub_apply]
    rw [← ht, hg μ]
    ring
  rw [key]
  set X : Fin 4 → ℝ := fun μ => 2 * (c μ * Nm s (v - fun i => (2 * t) * s i) μ) with hX
  have hd : dot (fun μ => sgv μ * X μ) (fun μ => sgv μ * X μ) = dot X X := by
    unfold dot
    refine Finset.sum_congr rfl fun i _ => ?_
    have := hsg i
    linear_combination (X i * X i) * this
  rw [hd]
  have h1 := hlow (v - fun i => (2 * t) * s i)
  have h2 : dot v v ≤ dot (v - fun i => (2 * t) * s i) (v - fun i => (2 * t) * s i) := by
    have e : dot (v - fun i => (2 * t) * s i) (v - fun i => (2 * t) * s i) =
        dot v v + (2 * t) ^ 2 * dot s s - 2 * (2 * t) * dot s v := by
      unfold dot
      simp only [Pi.sub_apply, Fin.sum_univ_four]
      ring
    rw [e, hv]
    nlinarith [dot_self_nonneg s, sq_nonneg (2 * t)]
  linarith

/-- The lowest alias of the coarse momentum `q`. -/
abbrev zst (q : Qpos) : Fin 4 → Bool := zstar fun ν => Real.sin (q.1 ν) ^ 2

/-- **`(121/1152)‖v‖² ≤ ‖A_{ζ*} v‖²` on `ran P(r_{ζ*})`**. -/
theorem AM_low (q : Qpos) (v : V) (hv : Pfam Subtype.val (rqPos q (zst q)) v = v) :
    (121 / 1152) * ‖v‖ ^ 2 ≤ ‖Matrix.toEuclideanLin (AM q.1 (zst q)) v‖ ^ 2 := by
  have hp : proj (sR q.1 (zst q)) (WithLp.ofLp v) = WithLp.ofLp v := by
    have h := congrArg WithLp.ofLp hv
    unfold Pfam at h
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec] at h
    have e : sQ (rqPos q (zst q)).1 = sR q.1 (zst q) := sQ_thR q.1 (zst q)
    rw [e] at h
    exact h
  have hd : dot (sR q.1 (zst q)) (WithLp.ofLp v) = 0 := by
    rw [← hp]; exact dot_proj _ _
  rw [normSq_coord, normSq_coord, toE_apply, WithLp.ofLp_toLp, AM_mulVec]
  exact low_core (sR q.1 (zst q)) (cR q.1 (zst q)) (sg (zst q)) (sQ q.1) (WithLp.ofLp v)
    (sQ_eq q.1 (zst q)) (sg_sq (zst q)) hd (lowest_alias_lower' q.1)

/-- On `ker C ∩ ran P′` the lowest alias component is bounded by the others. -/
theorem ker_lowest (q : Qpos) (d : Bsum) (hC : Calias q d = 0)
    (hP : ∀ ζ, Pfam Subtype.val (rqPos q ζ) (d ζ) = d ζ) :
    ‖d (zst q)‖ ^ 2 ≤ 69120 / 121 * ∑ ζ ∈ univ.erase (zst q), ‖d ζ‖ ^ 2 := by
  have hsum : ∑ ζ : Z, Matrix.toEuclideanLin (AM q.1 ζ) (d ζ) = 0 := by
    rw [Calias_apply] at hC
    exact (smul_eq_zero.mp hC).resolve_left (by norm_num)
  rw [← Finset.add_sum_erase _ _ (mem_univ (zst q))] at hsum
  have hsplit : Matrix.toEuclideanLin (AM q.1 (zst q)) (d (zst q)) =
      -∑ ζ ∈ univ.erase (zst q), Matrix.toEuclideanLin (AM q.1 ζ) (d ζ) :=
    eq_neg_of_add_eq_zero_left hsum
  have hlow := AM_low q (d (zst q)) (hP (zst q))
  rw [hsplit, norm_neg] at hlow
  have hn : ‖∑ ζ ∈ univ.erase (zst q), Matrix.toEuclideanLin (AM q.1 ζ) (d ζ)‖ ≤
      ∑ ζ ∈ univ.erase (zst q), 2 * ‖d ζ‖ :=
    (norm_sum_le _ _).trans (Finset.sum_le_sum fun ζ _ => AM_norm_le q.1 ζ (d ζ))
  have hcs : (∑ ζ ∈ univ.erase (zst q), 2 * ‖d ζ‖) ^ 2 ≤
      ((univ.erase (zst q)).card : ℝ) * ∑ ζ ∈ univ.erase (zst q), (2 * ‖d ζ‖) ^ 2 :=
    sq_sum_le_card_mul_sum_sq
  have hcard : ((univ.erase (zst q)).card : ℝ) = 15 := by
    rw [card_erase_of_mem (mem_univ _), card_univ, Fintype.card_fun, Fintype.card_bool,
      Fintype.card_fin]; norm_num
  rw [hcard] at hcs
  have e : ∑ ζ ∈ univ.erase (zst q), (2 * ‖d ζ‖) ^ 2 =
      4 * ∑ ζ ∈ univ.erase (zst q), ‖d ζ‖ ^ 2 := by
    rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ζ _ => by ring
  rw [e] at hcs
  have hn2 : ‖∑ ζ ∈ univ.erase (zst q), Matrix.toEuclideanLin (AM q.1 ζ) (d ζ)‖ ^ 2 ≤
      (∑ ζ ∈ univ.erase (zst q), 2 * ‖d ζ‖) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) hn 2
  nlinarith

/-- `ω(r_ζ) ≥ 2` off the lowest alias. -/
theorem omF_far (q : Qpos) {ζ : Fin 4 → Bool} (h : ζ ≠ zst q) :
    2 ≤ omF Subtype.val (rqPos q ζ) := by
  rw [omF_alias Subtype.val rqPos (fun _ _ => rfl) q ζ]
  exact omR_far (fun ν => sigma_mem (q.1 ν)) h

/-- **A3 seam (ii)**: the Poincaré input on the alias sum, `m = 8/745`, `Pc = 1 + 69120/121`. -/
theorem hH_holds (k : ℕ) (q : Qpos) :
    ∃ h : LinearMap.BilinForm ℝ Bsum, (∀ y, 0 ≤ h y y) ∧
      (∀ y z, h (blkF (Ak k) q y) z = ⟪y, blkF (Pfam Subtype.val) q z⟫) ∧
      ∀ d, Calias q d = 0 → blkF (Pfam Subtype.val) q d = d →
        (8 / 745 : ℝ) * ‖d‖ ^ 2 ≤ (1 + 69120 / 121) * h d d := by
  obtain ⟨H, hH, hHP, hbr⟩ := bracket_Qpos_free
  set B := blkF (H k) q with hB
  have hloc : ∀ (r : Qpos) (x : V), 0 ≤ ⟪x, H k r x⟫ ∧
      (Pfam Subtype.val r x = x → 4 * omF Subtype.val r / 745 * ‖x‖ ^ 2 ≤ ⟪x, H k r x⟫) := by
    intro r x
    have h1 := (hbr k r x).1
    rw [LinearMap.smul_apply, real_inner_smul_right] at h1
    have hP0 := inner_P_nonneg Subtype.val r x
    have hω := omF_pos r
    refine ⟨by nlinarith [div_nonneg hω.le (by norm_num : (0 : ℝ) ≤ 745)], fun hPx => ?_⟩
    rw [hPx, real_inner_self_eq_norm_sq] at h1
    linarith
  refine ⟨LinearMap.mk₂ ℝ (fun y z => ⟪y, B z⟫) (fun a b c => inner_add_left _ _ _)
    (fun c a b => by rw [real_inner_smul_left, smul_eq_mul])
    (fun a b c => by rw [map_add, inner_add_right])
    (fun c a b => by rw [map_smul, real_inner_smul_right, smul_eq_mul]), ?_, ?_, ?_⟩
  · intro y
    rw [LinearMap.mk₂_apply, hB]
    unfold blkF
    rw [AliasBlock.blk_inner]
    exact Finset.sum_nonneg fun ζ _ => (hloc _ _).1
  · intro y z
    rw [LinearMap.mk₂_apply, hB]
    unfold blkF
    rw [AliasBlock.blk_inner, AliasBlock.blk_inner]
    refine Finset.sum_congr rfl fun ζ _ => ?_
    rw [AliasBlock.blk_apply]
    have hAs := iterate_symm Subtype.val rqPos k (rqPos q ζ)
    rw [hAs]
    exact congrArg (fun x => ⟪y ζ, x⟫) (hH k (rqPos q ζ) (z ζ))
  · intro d hC hPd
    have hP : ∀ ζ, Pfam Subtype.val (rqPos q ζ) (d ζ) = d ζ := fun ζ => by
      have := congrArg (fun u : Bsum => u ζ) hPd
      exact this
    rw [LinearMap.mk₂_apply, hB]
    unfold blkF
    rw [AliasBlock.blk_inner, PiLp.norm_sq_eq_of_L2]
    set z := zst q
    have hk := ker_lowest q d hC hP
    rw [← Finset.add_sum_erase _ _ (mem_univ z), ← Finset.add_sum_erase _ _ (mem_univ z)]
    have hfar : (8 / 745 : ℝ) * ∑ ζ ∈ univ.erase z, ‖d ζ‖ ^ 2 ≤
        ∑ ζ ∈ univ.erase z, ⟪d ζ, H k (rqPos q ζ) (d ζ)⟫ := by
      rw [Finset.mul_sum]
      refine Finset.sum_le_sum fun ζ hζ => ?_
      have h2 := omF_far q (Finset.ne_of_mem_erase hζ)
      have h3 := (hloc (rqPos q ζ) (d ζ)).2 (hP ζ)
      have h4 : (8 / 745 : ℝ) * ‖d ζ‖ ^ 2 ≤ 4 * omF Subtype.val (rqPos q ζ) / 745 * ‖d ζ‖ ^ 2 :=
        mul_le_mul_of_nonneg_right (by linarith) (sq_nonneg _)
      linarith
    have hz0 := (hloc (rqPos q z) (d z)).1
    have hS0 : 0 ≤ ∑ ζ ∈ univ.erase z, ‖d ζ‖ ^ 2 := Finset.sum_nonneg fun ζ _ => sq_nonneg _
    nlinarith

/-- **`b_k = Ξ(Γ_k)` converges on the alias sum with no remaining hypothesis**:
`|Ξ(Γ_k) − b_∞| ≤ 5 L′ (3/5)^k` and the transient sum is `≤ (25/2) L′`, with
`κ = 1 + 2√(4 + 16·464880²)` and `γ = (1 + 69120/121)/(8/745)`. -/
theorem coupling_converges_gamma_closed (a : ℝ) {ι κ' : Type*} (s : Finset ι) (w : ι → ℝ)
    (p : ι → Qpos) (x : ι → Bsum) (t : Finset κ') (w2 : κ' → ℝ) (q q2 : κ' → Qpos)
    (v u u2 v2 : κ' → Bsum) :
    ∃ Esel : (Qpos → V →ₗ[ℝ] V) → Qpos → V →ₗ[ℝ] Bsum,
      (∀ k q, IsLiftR (Calias q) (blkF (Ak k) q) (Esel (Ak k) q)) ∧
      ∃ binf : ℝ, Tendsto (fun k => QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k)) atTop (𝓝 binf) ∧
      (∀ k, |QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2 (Ak k) - binf| ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * Klift)) ((1 + 69120 / 121) / (8 / 745))
            s w x t w2 v u u2 v2 * 2 * (3 / 5 : ℝ) ^ k / (1 - 3 / 5)) ∧
      (∀ n, ∑ k ∈ range n, max (-(QuadLip.XiQf (GamA Esel) a s w p x t w2 q q2 v u u2 v2
        (Ak k) - binf)) 0 ≤
          LgamA (1 + 2 * Real.sqrt (4 + 16 * Klift)) ((1 + 69120 / 121) / (8 / 745))
            s w x t w2 v u u2 v2 * 2 / (1 - 3 / 5) ^ 2) :=
  coupling_converges_gamma_poincare (K := Klift) (m := 8 / 745) (Pc := 1 + 69120 / 121)
    (by unfold Klift; positivity) (by norm_num) (by norm_num) hlift_holds hH_holds
    a s w p x t w2 q q2 v u u2 v2

end AliasPoinc

end

#print axioms AliasPoinc.low_core
#print axioms AliasPoinc.AM_low
#print axioms AliasPoinc.ker_lowest
#print axioms AliasPoinc.hH_holds
#print axioms AliasPoinc.coupling_converges_gamma_closed
#print axioms AliasLiftSize.hlift_holds
