/-
Chain with a transient bracket: the step decrease may be negative at finitely many scales.
Opening part: a copy of ChainAsymptotic.lean (unchanged, with its own header comments and #print lines:
WeakUltravioletExistence, SmallRemKernel, TwoStageSmallField, ChainEndToEnd, ChainMoving, AsymptoticPremises,
AsymptoticChain). Then the namespace TransientPremises of TransientPremises.lean (the elementary lemmas).
Then namespace TransientChain:
  D1 per-step hypotheses with a transient net bracket binf + δ_k − C₂/u_k ≤ b − r^sf_k ≤ bp + C₂/u_k,
     Σ_{k<n} max(−δ_k, 0) ≤ D₀, the invariant interval from s to every s' ≤ s + D₀
     (`CouplingStepsTransient`, `activity_le_transient`, `hbeta_of_steps_transient`); the signed per-step
     hypotheses are the case δ ≡ 0, D₀ = 0 (`transient_of_signed`, `hbeta_signed_via_transient`, `rfl`);
  D2 the transient chain end to end (`chain_end_to_end_transient`); the signed chain end to end is its
     special case (`chain_end_to_end_signed_of_transient`, same statement checked by `rfl`);
  D3 the asymptotic premises with a transient bracket (`AsymptoticStepsTransient`), the explicit point
     u⋆ = `ustarTransient`, the composition `chain_end_to_end_asymptotic_transient`, (W0) alone
     (`bare_value_of_asymptotic_transient`), and the signed premises as the case δ ≡ 0, D₀ = 0
     (`asymptoticTransient_of_signed`);
  D4 non-vacuity: a toy model with a rising first step satisfies the transient premises (`toy_transient`),
     lies outside the signed premises for every choice of constants (`toy_not_signed`), and attains the
     lower end of the (W0) bracket (`toy_bare_value`);
  D5 (W0) with the one-loop slope binf and a logarithmic correction from the error sum
     (`refined_step_of_asymptotic`, `bare_value_log_of_asymptotic_transient`);
  D6 the coefficient D₁u·y_s(u) in the transient form (`AsymptoticStepsTransientGrowing`,
     `transient_of_asymptotic_growing`), and the toy path family against the abstract signed per-step
     hypotheses (`toy_not_signed_steps`).
Single file; checks with `import Mathlib` only.
-/
/-
Chain under the asymptotic premises (A∞″).
Opening part: a copy of an earlier file (unchanged, with its own
header comment and #print lines). Then a copy of AsymptoticThreshold.lean (namespace AsymptoticPremises:
(a) the point u⋆ under the threshold 2(log u)/σ + y₀, (b) the signed bare-coupling lemma). Then namespace
AsymptoticChain:
  C1 per-step hypotheses with a signed net bracket (`CouplingStepsSigned`, `hbeta_of_steps_signed`); the moving
     chain is the special case bm = b − δ, bp = b + δ (`signed_of_movingD`, `hbeta_movingD_via_signed`), and
     conversely the signed chain under bp + 4e ≤ 3bm is the moving chain (`ratio_of_movingD`, `movingD_of_signed`);
  C2 the signed chain end to end (`chain_end_to_end_signed`);
  C3 the asymptotic premises (A∞″) in two forms (`AsymptoticStepsCentred`, `AsymptoticStepsSigned`), the explicit
     point u⋆ (`ustarCentred`, `ustarSigned`), and the compositions `chain_end_to_end_asymptotic` (through
     `ChainMoving.chain_end_to_end_moving`, unchanged) and `chain_end_to_end_asymptotic_signed`; the coefficient
     D₁u·y_s(u) in the signed form (`AsymptoticStepsSignedGrowing`, `signed_of_asymptotic_growing`).
Single file; checks with `import Mathlib` only.
-/
/-
Chain with a moving invariant interval. In `CouplingStepsKer` of ChainEndToEnd (copy, unchanged up to comments) the fields
  large_rem : |r^ℓ| ≤ D·z (constant D), act_init/fix/margin : z ≤ Z (constant Z), δ + C₂/u⋆ + DZ ≤ b/2
are replaced by
  large_rem : |r^ℓ_k| ≤ D₁·u_k·z_k, z_0 ≤ W(u_0), ρW(s) + AΦ(s) + BW(s)² ≤ W(s) for each s ≥ u⋆, W decreasing,
  s·W(s) ≤ Y, δ + C₂/u⋆ + D₁Y ≤ b/2
(`CouplingStepsMoving`). The activity bound and the coupling steps are handled in one induction (`hbeta_of_steps_moving`).
The end-to-end conclusion of the chain is the same as `ChainEndToEnd.chain_end_to_end` (`chain_end_to_end_moving`).
§M3: with the logarithmic threshold y_h(s) = (log s)/t + c, supply Φ(s) = K e^{−t y_h(s)} and W = 2AΦ/(1−ρ),
the margin fields hold uniformly in s (`moving_of_log_threshold`).
Single file; checks with `import Mathlib` only. The opening part is a copy of ChainEndToEnd.lean.
-/
import Mathlib

/-! Copy of WeakUltravioletExistence (unchanged up to comments) -/
namespace WeakUltravioletExistence

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## 1. Tuning the coupling (the bare-coupling lemma (W0)) -/

/-- the bare-coupling lemma (W0) (with domain). `u k x` is the effective inverse coupling `1/g_k²` after `k` steps, starting from the bare inverse coupling
`x = 1/g₀²`. Only inside the domain `{x | ∀ j ≤ k, u⋆ ≤ u j x}` (coupling ≤ `γ₁ = u⋆^{-1/2}` at all previous steps) do we assume
(S) the one-step remainder bound `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2` and (C) continuity of `x ↦ u_{k+1} x`. For a target `t ≥ u⋆` and
number of steps `n` there is a bare inverse coupling `x` reaching exactly `t` after `n` steps, staying ≥ `t` at all intermediate steps,
with `t + (b/2)n ≤ x ≤ t + (3b/2)n` (one-loop type sandwich). -/
theorem exists_bare_inverse_coupling (u : ℕ → ℝ → ℝ) (b ustar t : ℝ) (n : ℕ)
    (hb : 0 < b) (h0 : ∀ x, u 0 x = x)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2)
    (hC : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (ht : ustar ≤ t) :
    ∃ x : ℝ, t + b / 2 * n ≤ x ∧ x ≤ t + 3 * b / 2 * n ∧ u n x = t ∧
      ∀ k ≤ n, t ≤ u k x := by
  -- sandwich for the sequence of steps (while inside the domain)
  have hdrop : ∀ x, ∀ k, (∀ j ≤ k, ustar ≤ u j x) →
      u k x ≤ x - b / 2 * k ∧ x - 3 * b / 2 * k ≤ u k x := by
    intro x k
    induction k with
    | zero => intro _; simp [h0]
    | succ k ih =>
      intro hd
      have hd' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hd j (by omega)
      obtain ⟨i1, i2⟩ := ih hd'
      obtain ⟨s1, s2⟩ := hS k x hd'
      push_cast
      constructor <;> linarith
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    refine ⟨t, by simp, by simp, h0 t, ?_⟩
    intro k hk
    have : k = 0 := by omega
    subst this; simp [h0]
  set a : ℝ := t + 3 * b / 2 * n with ha
  -- K_k: starting points in [t, a] that stay ≥ t up to step k
  let K : ℕ → Set ℝ := fun k => {x | x ∈ Icc t a ∧ ∀ j ≤ k, t ≤ u j x}
  have hKdom : ∀ k x, x ∈ K k → ∀ j ≤ k, ustar ≤ u j x :=
    fun k x hx j hj => le_trans ht (hx.2 j hj)
  have hKclosed : ∀ k, IsClosed (K k) := by
    intro k
    induction k with
    | zero =>
      have : K 0 = Icc t a := by
        ext x
        simp only [K, mem_ofPred_eq, mem_Icc]
        constructor
        · intro h; exact h.1
        · intro h
          refine ⟨h, fun j hj => ?_⟩
          have : j = 0 := by omega
          subst this; rw [h0]; exact h.1
      rw [this]; exact isClosed_Icc
    | succ k ih =>
      have hco : ContinuousOn (u (k + 1)) (K k) :=
        (hC k).mono (fun x hx => hKdom k x hx)
      have hset : K (k + 1) = K k ∩ u (k + 1) ⁻¹' Ici t := by
        ext x
        simp only [K, mem_ofPred_eq, mem_inter_iff, mem_preimage, mem_Ici]
        constructor
        · rintro ⟨h1, h2⟩
          exact ⟨⟨h1, fun j hj => h2 j (by omega)⟩, h2 (k + 1) le_rfl⟩
        · rintro ⟨⟨h1, h2⟩, h3⟩
          refine ⟨h1, fun j hj => ?_⟩
          rcases Nat.lt_or_ge j (k + 1) with hlt | hge
          · exact h2 j (by omega)
          · have : j = k + 1 := by omega
            subst this; exact h3
      rw [hset]
      exact hco.preimage_isClosed_of_isClosed ih isClosed_Ici
  -- a lies in K n
  have hta : t ≤ a := by
    have : (0 : ℝ) ≤ 3 * b / 2 * n := by positivity
    linarith
  have ha_mem : a ∈ K n := by
    have key : ∀ k ≤ n, (∀ j ≤ k, t + 3 * b / 2 * ((n : ℝ) - j) ≤ u j a) := by
      intro k
      induction k with
      | zero => intro _ j hj; have : j = 0 := by omega
                subst this; simp [h0, ha]
      | succ k ih =>
        intro hk j hj
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact ih (by omega) j (by omega)
        · have : j = k + 1 := by omega
          subst this
          have ih' := ih (by omega)
          have hd : ∀ i ≤ k, ustar ≤ u i a := by
            intro i hi
            have h1 := ih' i hi
            have hin : (i : ℝ) ≤ n := by exact_mod_cast (show i ≤ n by omega)
            have : (0 : ℝ) ≤ 3 * b / 2 * ((n : ℝ) - i) := by
              apply mul_nonneg; positivity; linarith
            linarith
          have s1 := (hS k a hd).1
          have hk' := ih' k le_rfl
          push_cast
          linarith
    refine ⟨⟨hta, le_rfl⟩, fun j hj => ?_⟩
    have h1 := key n le_rfl j hj
    have hin : (j : ℝ) ≤ n := by exact_mod_cast hj
    have : (0 : ℝ) ≤ 3 * b / 2 * ((n : ℝ) - j) := by
      apply mul_nonneg; positivity; linarith
    linarith
  have hne : (K n).Nonempty := ⟨a, ha_mem⟩
  have hbdd : BddBelow (K n) := ⟨t, fun x hx => hx.1.1⟩
  set s := sInf (K n) with hs
  have hs_mem : s ∈ K n := (hKclosed n).csInf_mem hne hbdd
  have hsdom : ∀ j ≤ n, ustar ≤ u j s := hKdom n s hs_mem
  obtain ⟨d1, d2⟩ := hdrop s n hsdom
  -- u n s = t
  have hus : u n s = t := by
    by_contra hne'
    have hgt : t < u n s := lt_of_le_of_ne (hs_mem.2 n le_rfl) (Ne.symm hne')
    have hnpos : (0 : ℝ) < b / 2 * n := by
      have : (0 : ℝ) < n := by exact_mod_cast hn
      positivity
    have hst : t < s := by linarith
    -- strictly greater than t at every step
    have hall : ∀ k ≤ n, t < u k s := by
      intro k hk
      have mono : ∀ i, k + i ≤ n → u (k + i) s ≤ u k s := by
        intro i
        induction i with
        | zero => intro _; simp
        | succ i ih =>
          intro hi
          have h1 := ih (by omega)
          have h2 := (hS (k + i) s (fun j hj => hsdom j (by omega))).2
          rw [← Nat.add_assoc]
          linarith
      have := mono (n - k) (by omega)
      rw [Nat.add_sub_cancel' hk] at this
      linarith
    -- still greater than t near s (induction on the number of steps)
    have hopen : ∀ k ≤ n, ∃ ε > 0, ∀ y, dist y s < ε → ∀ j ≤ k, t < u j y := by
      intro k
      induction k with
      | zero =>
        intro _
        refine ⟨s - t, by linarith, fun y hy j hj => ?_⟩
        have : j = 0 := by omega
        subst this
        rw [h0]
        rw [Real.dist_eq, abs_lt] at hy
        linarith
      | succ k ih =>
        intro hk
        obtain ⟨ε, hε, hεy⟩ := ih (by omega)
        have hcw : ContinuousWithinAt (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x} s :=
          hC k s (fun j hj => hsdom j (by omega))
        rw [Metric.continuousWithinAt_iff] at hcw
        obtain ⟨ε', hε', hε'y⟩ := hcw (u (k + 1) s - t) (by linarith [hall (k + 1) hk])
        refine ⟨min ε ε', lt_min hε hε', fun y hy j hj => ?_⟩
        have hy1 : dist y s < ε := lt_of_lt_of_le hy (min_le_left _ _)
        have hy2 : dist y s < ε' := lt_of_lt_of_le hy (min_le_right _ _)
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact hεy y hy1 j (by omega)
        · have : j = k + 1 := by omega
          subst this
          have hydom : ∀ i ≤ k, ustar ≤ u i y := fun i hi => le_trans ht (hεy y hy1 i hi).le
          have := hε'y hydom hy2
          rw [Real.dist_eq, abs_lt] at this
          linarith
    obtain ⟨ε, hε, hεy⟩ := hopen n le_rfl
    set y := s - min (ε / 2) ((s - t) / 2) with hy
    have hm : 0 < min (ε / 2) ((s - t) / 2) := lt_min (by linarith) (by linarith)
    have hm1 : min (ε / 2) ((s - t) / 2) ≤ ε / 2 := min_le_left _ _
    have hm2 : min (ε / 2) ((s - t) / 2) ≤ (s - t) / 2 := min_le_right _ _
    have hyd : dist y s < ε := by
      rw [Real.dist_eq, hy]
      rw [abs_lt]; constructor <;> linarith
    have hyK : y ∈ K n := by
      refine ⟨⟨by linarith, by linarith [hs_mem.1.2]⟩, fun j hj => (hεy y hyd j hj).le⟩
    have := csInf_le hbdd hyK
    linarith
  refine ⟨s, ?_, ?_, hus, fun k hk => hs_mem.2 k hk⟩
  · linarith
  · linarith

/-! ## 2. Sequences of probability measures on a compact configuration space -/

section Measures

variable {E : Type*} [MeasurableSpace E] [MetricSpace E] [CompactSpace E] [BorelSpace E]

/-- A sequence of probability measures on a compact metric space has a weakly convergent subsequence
(Prokhorov in the compact case; the limit is a probability measure). -/
theorem exists_subseq_tendsto_probabilityMeasure (ν : ℕ → ProbabilityMeasure E) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ProbabilityMeasure E,
      Tendsto (ν ∘ φ) atTop (𝓝 νl) := by
  obtain ⟨a, -, φ, hφ, h⟩ := isCompact_univ.tendsto_subseq (x := ν) (fun _ => mem_univ _)
  exact ⟨φ, hφ, a, h⟩

end Measures

/-! ## 3. A common subsequence at all coarse scales (projective system) -/

section Projective

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]

/-- From sequences of measures `ν n m` on the coarse configuration spaces `E m` at each scale `m` (the lattice-`n` measure pushed forward
to the block variables at scale `m`), one can extract a subsequence common to all `m`. -/
theorem exists_common_subseq (ν : ℕ → ∀ m, ProbabilityMeasure (E m)) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      ∀ m, Tendsto (fun k => ν (φ k) m) atTop (𝓝 (νl m)) := by
  obtain ⟨a, -, φ, hφ, h⟩ := isCompact_univ.tendsto_subseq (x := ν) (fun _ => mem_univ _)
  exact ⟨φ, hφ, a, fun m => ((continuous_apply m).tendsto a).comp h⟩

/-- If the coarsening maps `B m : E (m+1) → E m` are continuous and the push-forwards are consistent on fine enough lattices
(pushing forward by `B m` gives the measure at the next coarser scale), the subsequential limits are also consistent. -/
theorem limit_consistent (ν : ℕ → ∀ m, ProbabilityMeasure (E m))
    (B : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (B m))
    (hcons : ∀ m, ∀ᶠ n in atTop,
      (ν n (m + 1)).map (hB m).measurable.aemeasurable = ν n m)
    (φ : ℕ → ℕ) (hφ : StrictMono φ) (νl : ∀ m, ProbabilityMeasure (E m))
    (hlim : ∀ m, Tendsto (fun k => ν (φ k) m) atTop (𝓝 (νl m))) :
    ∀ m, (νl (m + 1)).map (hB m).measurable.aemeasurable = νl m := by
  intro m
  have h1 : Tendsto (fun k => (ν (φ k) (m + 1)).map (hB m).measurable.aemeasurable) atTop
      (𝓝 ((νl (m + 1)).map (hB m).measurable.aemeasurable)) :=
    ((ProbabilityMeasure.continuous_map (hB m)).tendsto _).comp (hlim (m + 1))
  have hev : ∀ᶠ k in atTop,
      ν (φ k) m = (ν (φ k) (m + 1)).map (hB m).measurable.aemeasurable :=
    (hφ.tendsto_atTop.eventually (hcons m)).mono (fun k hk => hk.symm)
  have h2 : Tendsto (fun k => (ν (φ k) (m + 1)).map (hB m).measurable.aemeasurable) atTop
      (𝓝 (νl m)) := (hlim m).congr' hev
  exact tendsto_nhds_unique h1 h2

end Projective

/-! ## 4. Closed conditions survive the limit (measure level) -/

section ClosedConditions

variable {E : Type*} [MeasurableSpace E] [MetricSpace E] [CompactSpace E] [BorelSpace E]

/-- Reflection positivity: if the reflection `Θ` is continuous and `∫ F(Θω) F(ω) ≥ 0` on each lattice for all `F` in the family `A`
of positive-time observables, the same holds for the weak limit. -/
theorem reflection_positivity_limit (Θ : E → E) (hΘ : Continuous Θ)
    (A : Set (BoundedContinuousFunction E ℝ))
    (ν : ℕ → ProbabilityMeasure E) (νl : ProbabilityMeasure E)
    (hlim : Tendsto ν atTop (𝓝 νl))
    (hRP : ∀ᶠ n in atTop, ∀ F ∈ A, 0 ≤ ∫ ω, F (Θ ω) * F ω ∂(ν n : Measure E)) :
    ∀ F ∈ A, 0 ≤ ∫ ω, F (Θ ω) * F ω ∂(νl : Measure E) := by
  intro F hF
  set G : BoundedContinuousFunction E ℝ := F.compContinuous ⟨Θ, hΘ⟩ * F
  have hG : ∀ ω, G ω = F (Θ ω) * F ω := fun ω => rfl
  have ht := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) G
  simp only [hG] at ht
  exact ge_of_tendsto ht (hRP.mono fun n hn => hn F hF)

/-- Approximate symmetry: for a continuous map `g`, if for each observable `f`
`|∫ f∘g dν_n − ∫ f dν_n| ≤ ε_n(f)` with `ε_n(f) → 0`, the limit is invariant under `g`
(`ε = 0` is the case of an exact lattice symmetry). -/
theorem approx_invariance_limit (g : E → E) (hg : Continuous g)
    (ν : ℕ → ProbabilityMeasure E) (νl : ProbabilityMeasure E)
    (hlim : Tendsto ν atTop (𝓝 νl))
    (ε : ℕ → BoundedContinuousFunction E ℝ → ℝ)
    (hε : ∀ f, Tendsto (fun n => ε n f) atTop (𝓝 0))
    (hsym : ∀ᶠ n in atTop, ∀ f,
      |∫ ω, f (g ω) ∂(ν n : Measure E) - ∫ ω, f ω ∂(ν n : Measure E)| ≤ ε n f) :
    ∀ f : BoundedContinuousFunction E ℝ,
      ∫ ω, f (g ω) ∂(νl : Measure E) = ∫ ω, f ω ∂(νl : Measure E) := by
  intro f
  set fg : BoundedContinuousFunction E ℝ := f.compContinuous ⟨g, hg⟩
  have hfg : ∀ ω, fg ω = f (g ω) := fun ω => rfl
  have t1 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) fg
  have t2 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) f
  simp only [hfg] at t1
  have td := (t1.sub t2).abs
  have hle : |∫ ω, f (g ω) ∂(νl : Measure E) - ∫ ω, f ω ∂(νl : Measure E)| ≤ 0 :=
    le_of_tendsto_of_tendsto td (hε f) (hsym.mono fun n hn => hn f)
  have := abs_nonpos_iff.mp hle
  linarith

/-- Lower bounds on probabilities of closed sets survive the limit (the small-field event does not collapse in the limit). -/
theorem closed_mass_lower_limit (C : Set E) (hC : IsClosed C) (c : ℝ≥0∞)
    (ν : ℕ → ProbabilityMeasure E) (νl : ProbabilityMeasure E)
    (hlim : Tendsto ν atTop (𝓝 νl))
    (hlow : ∀ᶠ n in atTop, c ≤ (ν n : Measure E) C) :
    c ≤ (νl : Measure E) C := by
  have h := MeasureTheory.ProbabilityMeasure.limsup_measure_closed_le_of_tendsto hlim hC
  have h1 : c ≤ limsup (fun n => (ν n : Measure E) C) atTop :=
    le_limsup_of_frequently_le hlow.frequently (by isBoundedDefault)
  exact h1.trans (by simpa using h)

end ClosedConditions

/-! ## 5. Observable level: subsequence on a dense set and continuous extension -/

section Observables

variable {X : Type*} [MetricSpace X]

/-- A uniformly bounded real-valued sequence on a countable set `D` has a subsequence converging at every point of `D`
(compactness of a countable product). -/
theorem exists_subseq_tendsto_on_countable (D : Set X) (hDc : D.Countable)
    (s : ℕ → X → ℝ) (Bd : ℝ) (hbd : ∀ n, ∀ d ∈ D, |s n d| ≤ Bd) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ T : D → ℝ,
      ∀ d : D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (T d)) := by
  have : Countable D := hDc.to_subtype
  let x : ℕ → (D → ℝ) := fun n d => s n d
  have hK : IsCompact (Set.univ.pi fun _ : D => Icc (-Bd) Bd) :=
    isCompact_univ_pi (fun _ => isCompact_Icc)
  have hx : ∀ n, x n ∈ Set.univ.pi fun _ : D => Icc (-Bd) Bd := by
    intro n d _
    exact abs_le.mp (hbd n d d.2)
  obtain ⟨T, -, φ, hφ, h⟩ := hK.tendsto_subseq hx
  exact ⟨φ, hφ, T, fun d => ((continuous_apply d).tendsto T).comp h⟩

/-- If along a given subsequence `φ` the sequence converges at each point of `D` (limit `T`), and is uniformly bounded and
equicontinuous "on fine enough lattices", then `T` extends to a continuous `S` on all of `X`, with the same bound and the same modulus of continuity. -/
theorem continuous_extension_of_tendsto (D : Set X) (hDd : Dense D)
    (s : ℕ → X → ℝ) (Bd : ℝ) (hbd : ∀ n, ∀ d ∈ D, |s n d| ≤ Bd)
    (heq : ∀ ε > 0, ∃ δ > 0, ∀ d ∈ D, ∀ d' ∈ D, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ ε)
    (φ : ℕ → ℕ) (hφ : StrictMono φ) (T : D → ℝ)
    (hT : ∀ d : D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (T d))) :
    ∃ S : X → ℝ, Continuous S ∧
      (∀ d ∈ D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (S d))) ∧
      (∀ x, |S x| ≤ Bd) ∧
      (∀ ε > 0, ∃ δ > 0, ∀ x y, dist x y < δ → |S x - S y| ≤ ε) := by
  -- T is uniformly continuous on D
  have hTeq : ∀ ε > 0, ∃ δ > 0, ∀ d d' : D, dist d d' < δ → |T d - T d'| ≤ ε := by
    intro ε hε
    obtain ⟨δ, hδ, h⟩ := heq ε hε
    refine ⟨δ, hδ, fun d d' hdd => ?_⟩
    have hev := hφ.tendsto_atTop.eventually (h d d.2 d' d'.2 hdd)
    have hlim : Tendsto (fun k => |s (φ k) d - s (φ k) d'|) atTop (𝓝 |T d - T d'|) :=
      ((hT d).sub (hT d')).abs
    exact le_of_tendsto hlim hev
  have hTuc : UniformContinuous T := by
    rw [Metric.uniformContinuous_iff]
    intro ε hε
    obtain ⟨δ, hδ, h⟩ := hTeq (ε / 2) (by positivity)
    refine ⟨δ, hδ, fun {a b} hab => ?_⟩
    rw [Real.dist_eq]
    have := h a b hab
    linarith
  have hui : IsUniformInducing (Subtype.val : D → X) :=
    isUniformEmbedding_subtype_val.isUniformInducing
  have hdr : DenseRange (Subtype.val : D → X) := hDd.denseRange_val
  set S : X → ℝ := (hui.isDenseInducing hdr).extend T with hS
  have hSuc : UniformContinuous S := uniformContinuous_uniformly_extend hui hdr hTuc
  have hSD : ∀ d : D, S d = T d := fun d => uniformly_extend_of_ind hui hdr hTuc d
  clear_value S
  refine ⟨S, hSuc.continuous, ?_, ?_, ?_⟩
  · intro d hd
    have := hT ⟨d, hd⟩
    rw [hSD ⟨d, hd⟩]
    exact this
  · -- boundedness: the closed set {x | |S x| ≤ Bd} contains D
    have hcl : IsClosed {x | |S x| ≤ Bd} :=
      isClosed_le (continuous_abs.comp hSuc.continuous) continuous_const
    have hsub : D ⊆ {x | |S x| ≤ Bd} := by
      intro d hd
      show |S d| ≤ Bd
      have hconv := hT ⟨d, hd⟩
      have : |T ⟨d, hd⟩| ≤ Bd :=
        le_of_tendsto (hconv.abs) (Eventually.of_forall (fun k => hbd (φ k) d hd))
      have e := hSD ⟨d, hd⟩
      simp only at e
      rw [e]; exact this
    intro x
    have := hcl.closure_subset_iff.mpr hsub
    rw [hDd.closure_eq] at this
    exact this (mem_univ x)
  · -- modulus of continuity: pass the estimate on D to the closure
    intro ε hε
    obtain ⟨δ, hδ, h⟩ := hTeq ε hε
    refine ⟨δ, hδ, fun x y hxy => ?_⟩
    -- view the set {p | dist p.1 p.2 < δ → |S p.1 - S p.2| ≤ ε} on the open set U = {dist < δ}
    have hU : IsOpen {p : X × X | dist p.1 p.2 < δ} :=
      isOpen_lt (continuous_fst.dist continuous_snd) continuous_const
    have hcl : IsClosed {p : X × X | |S p.1 - S p.2| ≤ ε} :=
      isClosed_le (continuous_abs.comp
        ((hSuc.continuous.comp continuous_fst).sub (hSuc.continuous.comp continuous_snd)))
        continuous_const
    have hDD : Dense (D ×ˢ D) := hDd.prod hDd
    -- U ∩ (D×D) is contained in U ∩ (a closed set), and U is open, so U ⊆ closure (U ∩ D×D)
    have hsub : {p : X × X | dist p.1 p.2 < δ} ∩ (D ×ˢ D) ⊆ {p | |S p.1 - S p.2| ≤ ε} := by
      rintro ⟨a, b⟩ ⟨hab, ha, hb⟩
      show |S a - S b| ≤ ε
      have e1 := hSD ⟨a, ha⟩
      have e2 := hSD ⟨b, hb⟩
      simp only at e1 e2
      rw [e1, e2]
      exact h ⟨a, ha⟩ ⟨b, hb⟩ hab
    have hmem : (x, y) ∈ closure ({p : X × X | dist p.1 p.2 < δ} ∩ (D ×ˢ D)) := by
      exact hDD.open_subset_closure_inter hU hxy
    have hfin : (x, y) ∈ {p : X × X | |S p.1 - S p.2| ≤ ε} :=
      (hcl.closure_subset_iff.mpr hsub) hmem
    exact hfin

/-- From a sequence on a countable dense `D` that is uniformly bounded and equicontinuous "on fine enough lattices", one gets
a subsequence and a continuous limit `S` on all of `X`. -/
theorem exists_subseq_continuous_limit (D : Set X) (hDc : D.Countable) (hDd : Dense D)
    (s : ℕ → X → ℝ) (Bd : ℝ) (hbd : ∀ n, ∀ d ∈ D, |s n d| ≤ Bd)
    (heq : ∀ ε > 0, ∃ δ > 0, ∀ d ∈ D, ∀ d' ∈ D, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ ε) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ S : X → ℝ, Continuous S ∧
      (∀ d ∈ D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (S d))) ∧
      (∀ x, |S x| ≤ Bd) ∧
      (∀ ε > 0, ∃ δ > 0, ∀ x y, dist x y < δ → |S x - S y| ≤ ε) := by
  obtain ⟨φ, hφ, T, hT⟩ := exists_subseq_tendsto_on_countable D hDc s Bd hbd
  exact ⟨φ, hφ, continuous_extension_of_tendsto D hDd s Bd hbd heq φ hφ T hT⟩

/-! ## 6. Invariance and positivity constraints survive the limit (observable level) -/

/-- If a continuous action `g : X → X` maps `D` to `D` and on `D`
`|s_n(g d) − s_n(d)| ≤ ε_n(d) → 0`, then the continuous extension `S` of the subsequential limit on `D` is
invariant under `g` on all of `X`. -/
theorem invariance_of_limit (D : Set X) (hDd : Dense D)
    (s : ℕ → X → ℝ) (φ : ℕ → ℕ) (S : X → ℝ) (hSc : Continuous S)
    (hlim : ∀ d ∈ D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (S d)))
    (g : X → X) (hg : Continuous g) (hgD : ∀ d ∈ D, g d ∈ D)
    (ε : ℕ → X → ℝ) (hε : ∀ d ∈ D, Tendsto (fun k => ε (φ k) d) atTop (𝓝 0))
    (hsym : ∀ n, ∀ d ∈ D, |s n (g d) - s n d| ≤ ε n d) :
    ∀ x, S (g x) = S x := by
  have hEq : EqOn (S ∘ g) S D := by
    intro d hd
    have t := ((hlim (g d) (hgD d hd)).sub (hlim d hd)).abs
    have hle : |S (g d) - S d| ≤ 0 :=
      le_of_tendsto_of_tendsto' t (hε d hd) (fun k => hsym (φ k) d hd)
    have := abs_nonpos_iff.mp hle
    simp only [Function.comp]
    linarith
  have := Continuous.ext_on hDd (hSc.comp hg) hSc hEq
  intro x
  exact congrFun this x

/-- Positivity of quadratic forms in finitely many observables (matrix form of reflection positivity): if on each lattice
`∑_{a,b} c_a c_b s_n(I a b) ≥ 0`, the same holds in the limit. -/
theorem quadratic_positivity_limit {m : ℕ} (s : ℕ → X → ℝ) (φ : ℕ → ℕ) (S : X → ℝ)
    (I : Fin m → Fin m → X)
    (hlim : ∀ a b, Tendsto (fun k => s (φ k) (I a b)) atTop (𝓝 (S (I a b))))
    (c : Fin m → ℝ)
    (hpos : ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, c a * c b * s n (I a b))
    (hφ : StrictMono φ) :
    0 ≤ ∑ a, ∑ b, c a * c b * S (I a b) := by
  have ht : Tendsto (fun k => ∑ a, ∑ b, c a * c b * s (φ k) (I a b)) atTop
      (𝓝 (∑ a, ∑ b, c a * c b * S (I a b))) := by
    apply tendsto_finsetSum
    intro a _
    apply tendsto_finsetSum
    intro b _
    exact (hlim a b).const_mul (c a * c b)
  exact ge_of_tendsto ht (hφ.tendsto_atTop.eventually hpos)

/-- Invariance under a dense subgroup extends to the whole group if the action is continuous in the group variable
(from invariance under dyadic translations to invariance under all translations of the torus). -/
theorem invariance_extends_by_density {Gc : Type*} [TopologicalSpace Gc]
    (actc : Gc → X → X) (S : X → ℝ) (hSc : Continuous S)
    (hcont : ∀ x, Continuous (fun g => actc g x))
    (Dg : Set Gc) (hDg : Dense Dg) (hinv : ∀ g ∈ Dg, ∀ x, S (actc g x) = S x) :
    ∀ g x, S (actc g x) = S x := by
  intro g x
  have hEq : EqOn (fun g => S (actc g x)) (fun _ => S x) Dg := fun g hg => hinv g hg x
  have := Continuous.ext_on hDg (hSc.comp (hcont x)) continuous_const hEq
  exact congrFun this g

/-! ## 7. No subsequence needed when increments are summable -/

/-- If `|s_{n+1}(x) − s_n(x)| ≤ δ_n` and `∑ δ_n < ∞`, then `s_n(x)` converges. -/
theorem tendsto_of_summable_increments (s : ℕ → ℝ) (δ : ℕ → ℝ)
    (hδ : Summable δ) (hinc : ∀ n, |s (n + 1) - s n| ≤ δ n) :
    ∃ L : ℝ, Tendsto s atTop (𝓝 L) := by
  have hd : Summable (fun n => dist (s n) (s n.succ)) := by
    refine Summable.of_nonneg_of_le (fun n => dist_nonneg) (fun n => ?_) hδ
    rw [Real.dist_eq, abs_sub_comm]
    exact hinc n
  exact cauchySeq_tendsto_of_complete (cauchySeq_of_summable_dist hd)

/-- If a sequence converges, every subsequential limit equals its limit (uniqueness of limits). -/
theorem subseq_limit_eq (s : ℕ → ℝ) (L L' : ℝ) (hs : Tendsto s atTop (𝓝 L))
    (φ : ℕ → ℕ) (hφ : StrictMono φ) (h' : Tendsto (s ∘ φ) atTop (𝓝 L')) : L' = L :=
  tendsto_nhds_unique h' (hs.comp hφ.tendsto_atTop)

end Observables

/-! ## 8. Assembly: from the premise structure to the conclusion structure -/

section AssemblyBlocks

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]

/-- Premises at the block-variable level (all lattice properties, for each lattice spacing).
`ν n m` is the lattice-`n` measure pushed forward to block variables at scale `m`, `B m` the coarsening map,
`Θ m` the time reflection at scale `m`, `A m` the positive-time observables, `act g m` the lattice symmetries
(hypercubic group and coarse-lattice translations), `C m` the small-field event (a closed set), `c m` the lower bound on its probability. -/
structure BlockHypotheses (ν : ℕ → ∀ m, ProbabilityMeasure (E m))
    (B : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (B m))
    (Θ : ∀ m, E m → E m) (A : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {G : Type*} (act : G → ∀ m, E m → E m)
    (C : ∀ m, Set (E m)) (c : ℕ → ℝ≥0∞) : Prop where
  consistent : ∀ m, ∀ᶠ n in atTop, (ν n (m + 1)).map (hB m).measurable.aemeasurable = ν n m
  reflection_continuous : ∀ m, Continuous (Θ m)
  reflection_positive : ∀ m, ∀ᶠ n in atTop,
    ∀ F ∈ A m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(ν n m : Measure (E m))
  symmetry_continuous : ∀ g m, Continuous (act g m)
  symmetric : ∀ g m, ∀ᶠ n in atTop, ∀ f : BoundedContinuousFunction (E m) ℝ,
    ∫ ω, f (act g m ω) ∂(ν n m : Measure (E m)) = ∫ ω, f ω ∂(ν n m : Measure (E m))
  small_field_closed : ∀ m, IsClosed (C m)
  small_field_mass : ∀ m, ∀ᶠ n in atTop, c m ≤ (ν n m : Measure (E m)) (C m)

/-- Conclusion at the block-variable level: the limiting projective system is consistent, reflection positive, invariant under
the lattice symmetries, and keeps the lower bound on the probability of the small-field event. -/
structure BlockConclusion (νl : ∀ m, ProbabilityMeasure (E m))
    (B : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (B m))
    (Θ : ∀ m, E m → E m) (A : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {G : Type*} (act : G → ∀ m, E m → E m)
    (C : ∀ m, Set (E m)) (c : ℕ → ℝ≥0∞) : Prop where
  consistent : ∀ m, (νl (m + 1)).map (hB m).measurable.aemeasurable = νl m
  reflection_positive : ∀ m, ∀ F ∈ A m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νl m : Measure (E m))
  symmetric : ∀ g m, ∀ f : BoundedContinuousFunction (E m) ℝ,
    ∫ ω, f (act g m ω) ∂(νl m : Measure (E m)) = ∫ ω, f ω ∂(νl m : Measure (E m))
  small_field_mass : ∀ m, c m ≤ (νl m : Measure (E m)) (C m)

/-- Skeleton of the implication (block-variable level): from the premise structure, a subsequence common to all scales and a
limiting projective system satisfying the conclusion structure. -/
theorem weak_uv_block_skeleton (ν : ℕ → ∀ m, ProbabilityMeasure (E m))
    (B : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (B m))
    (Θ : ∀ m, E m → E m) (A : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {G : Type*} (act : G → ∀ m, E m → E m)
    (C : ∀ m, Set (E m)) (c : ℕ → ℝ≥0∞)
    (H : BlockHypotheses ν B hB Θ A act C c) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => ν (φ k) m) atTop (𝓝 (νl m))) ∧
      BlockConclusion νl B hB Θ A act C c := by
  obtain ⟨φ, hφ, νl, hlim⟩ := exists_common_subseq ν
  have ev : ∀ {P : ℕ → Prop}, (∀ᶠ n in atTop, P n) → ∀ᶠ k in atTop, P (φ k) :=
    fun h => hφ.tendsto_atTop.eventually h
  refine ⟨φ, hφ, νl, hlim, ?_, ?_, ?_, ?_⟩
  · exact limit_consistent ν B hB H.consistent φ hφ νl hlim
  · intro m
    exact reflection_positivity_limit (Θ m) (H.reflection_continuous m) (A m)
      (fun k => ν (φ k) m) (νl m) (hlim m) (ev (H.reflection_positive m))
  · intro g m
    refine approx_invariance_limit (act g m) (H.symmetry_continuous g m)
      (fun k => ν (φ k) m) (νl m) (hlim m) (fun _ _ => 0) (fun _ => tendsto_const_nhds) ?_
    exact (ev (H.symmetric g m)).mono fun k hk f => by rw [hk f, sub_self, abs_zero]
  · intro m
    exact closed_mass_lower_limit (C m) (H.small_field_closed m) (c m)
      (fun k => ν (φ k) m) (νl m) (hlim m) (ev (H.small_field_mass m))

end AssemblyBlocks

section AssemblyObservables

variable {X : Type*} [MetricSpace X]

/-- Premises at the observable level. `X` is the space of observable configurations (positions and orientations of a tuple of
smeared observables), `D` the countable dense set of configurations representable on the lattice (dyadic positions), `s n x` the
expectation on lattice `n`. `act g` are the continuous symmetries (torus translations and the hypercubic group), `ε g n d` the size of
the breaking on lattice `n`. `P` is the family of matrix constraints of reflection positivity. -/
structure ObservableHypotheses (D : Set X) (s : ℕ → X → ℝ) (Bd : ℝ)
    {G : Type*} (act : G → X → X) (ε : G → ℕ → X → ℝ)
    (P : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ))) : Prop where
  countable : D.Countable
  dense : Dense D
  bounded : ∀ n, ∀ d ∈ D, |s n d| ≤ Bd
  equicontinuous : ∀ η > 0, ∃ δ > 0, ∀ d ∈ D, ∀ d' ∈ D, dist d d' < δ →
    ∀ᶠ n in atTop, |s n d - s n d'| ≤ η
  act_continuous : ∀ g, Continuous (act g)
  act_maps : ∀ g, ∀ d ∈ D, act g d ∈ D
  breaking : ∀ g n, ∀ d ∈ D, |s n (act g d) - s n d| ≤ ε g n d
  breaking_vanishes : ∀ g, ∀ d ∈ D, Tendsto (fun n => ε g n d) atTop (𝓝 0)
  positivity_on_lattice : ∀ p ∈ P, (∀ a b, p.2.1 a b ∈ D) ∧
    ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b)

/-- Conclusion at the observable level (for the limiting functional `S`). -/
structure ObservableConclusion (D : Set X) (S : X → ℝ) (Bd : ℝ)
    {G : Type*} (act : G → X → X)
    (P : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ))) : Prop where
  continuous : Continuous S
  bounded : ∀ x, |S x| ≤ Bd
  modulus : ∀ η > 0, ∃ δ > 0, ∀ x y, dist x y < δ → |S x - S y| ≤ η
  invariant : ∀ g x, S (act g x) = S x
  positive : ∀ p ∈ P, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * S (p.2.1 a b)

/-- Skeleton of the implication (observable level): there are a subsequence and a continuous functional `S` that is its limit on `D`,
and `S` is bounded, uniformly continuous, symmetry invariant, and satisfies the matrix constraints of reflection positivity. -/
theorem weak_uv_observable_skeleton (D : Set X) (s : ℕ → X → ℝ) (Bd : ℝ)
    {G : Type*} (act : G → X → X) (ε : G → ℕ → X → ℝ)
    (P : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (H : ObservableHypotheses D s Bd act ε P) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ S : X → ℝ,
      (∀ d ∈ D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (S d))) ∧
      ObservableConclusion D S Bd act P := by
  obtain ⟨φ, hφ, S, hSc, hlim, hbd, hmod⟩ :=
    exists_subseq_continuous_limit D H.countable H.dense s Bd H.bounded H.equicontinuous
  refine ⟨φ, hφ, S, hlim, hSc, hbd, hmod, ?_, ?_⟩
  · intro g
    exact invariance_of_limit D H.dense s φ S hSc hlim (act g) (H.act_continuous g)
      (H.act_maps g) (ε g) (fun d hd => (H.breaking_vanishes g d hd).comp hφ.tendsto_atTop)
      (H.breaking g)
  · intro p hp
    obtain ⟨hD, hpos⟩ := H.positivity_on_lattice p hp
    exact quadratic_positivity_limit s φ S p.2.1 (fun a b => hlim _ (hD a b)) p.2.2 hpos hφ

/-- Strong form (no subsequence): if moreover the increments are summable at each `d ∈ D`, the sequence itself converges on `D`
and the limit agrees with the `S` of the skeleton theorem. -/
theorem weak_uv_observable_full (D : Set X) (s : ℕ → X → ℝ) (Bd : ℝ)
    {G : Type*} (act : G → X → X) (ε : G → ℕ → X → ℝ)
    (P : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (H : ObservableHypotheses D s Bd act ε P)
    (δ : ℕ → X → ℝ) (hδ : ∀ d ∈ D, Summable (fun n => δ n d))
    (hinc : ∀ d ∈ D, ∀ n, |s (n + 1) d - s n d| ≤ δ n d) :
    ∃ S : X → ℝ, (∀ d ∈ D, Tendsto (fun n => s n d) atTop (𝓝 (S d))) ∧
      ObservableConclusion D S Bd act P := by
  obtain ⟨φ, hφ, S, hlim, hC⟩ := weak_uv_observable_skeleton D s Bd act ε P H
  refine ⟨S, fun d hd => ?_, hC⟩
  obtain ⟨L, hL⟩ := tendsto_of_summable_increments (fun n => s n d) (fun n => δ n d)
    (hδ d hd) (hinc d hd)
  have := subseq_limit_eq (fun n => s n d) L (S d) hL φ hφ (hlim d hd)
  rw [this]; exact hL

end AssemblyObservables

section AssemblyCombined

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Observables are represented by continuous functions of block variables: on fine enough lattices, the lattice-`n` expectation
at `d ∈ D` equals the integral of a bounded continuous function `F d` of the block variables at scale `lev d`. -/
structure Representation (ν : ℕ → ∀ m, ProbabilityMeasure (E m)) (D : Set X)
    (s : ℕ → X → ℝ) (lev : X → ℕ) (F : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ) :
    Prop where
  represent : ∀ d ∈ D, ∀ᶠ n in atTop,
    s n d = ∫ ω, F d ω ∂(ν n (lev d) : Measure (E (lev d)))

/-- Skeleton of the implication (combined form): taking one subsequence of the block-variable measures, along it all observables
converge on `D`, the limit is given by integrals against the limiting measures, extends continuously to all of `X`, and satisfies
all the observable-level conclusions. -/
theorem weak_uv_skeleton (ν : ℕ → ∀ m, ProbabilityMeasure (E m))
    (B : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (B m))
    (Θ : ∀ m, E m → E m) (A : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m)
    (C : ∀ m, Set (E m)) (c : ℕ → ℝ≥0∞)
    (D : Set X) (s : ℕ → X → ℝ) (Bd : ℝ)
    {G : Type*} (act : G → X → X) (ε : G → ℕ → X → ℝ)
    (P : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (lev : X → ℕ) (F : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HB : BlockHypotheses ν B hB Θ A actb C c)
    (HO : ObservableHypotheses D s Bd act ε P)
    (HR : Representation ν D s lev F) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => ν (φ k) m) atTop (𝓝 (νl m))) ∧
      BlockConclusion νl B hB Θ A actb C c ∧
      ∃ S : X → ℝ,
        (∀ d ∈ D, S d = ∫ ω, F d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (S d))) ∧
        ObservableConclusion D S Bd act P := by
  obtain ⟨φ, hφ, νl, hlim, HC⟩ := weak_uv_block_skeleton ν B hB Θ A actb C c HB
  set T : D → ℝ := fun d => ∫ ω, F d ω ∂(νl (lev d) : Measure (E (lev d))) with hTdef
  have hT : ∀ d : D, Tendsto (fun k => s (φ k) d) atTop (𝓝 (T d)) := by
    intro d
    have hint := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp (hlim (lev d))) (F d)
    have hev : ∀ᶠ k in atTop,
        ∫ ω, F d ω ∂(ν (φ k) (lev d) : Measure (E (lev d))) = s (φ k) d :=
      (hφ.tendsto_atTop.eventually (HR.represent d d.2)).mono (fun k hk => hk.symm)
    exact hint.congr' hev
  obtain ⟨S, hSc, hSlim, hSbd, hSmod⟩ :=
    continuous_extension_of_tendsto D HO.dense s Bd HO.bounded HO.equicontinuous φ hφ T hT
  refine ⟨φ, hφ, νl, hlim, HC, S, ?_, hSlim, hSc, hSbd, hSmod, ?_, ?_⟩
  · intro d hd
    exact tendsto_nhds_unique (hSlim d hd) (hT ⟨d, hd⟩)
  · intro g
    exact invariance_of_limit D HO.dense s φ S hSc hSlim (act g) (HO.act_continuous g)
      (HO.act_maps g) (ε g) (fun d hd => (HO.breaking_vanishes g d hd).comp hφ.tendsto_atTop)
      (HO.breaking g)
  · intro p hp
    obtain ⟨hD, hpos⟩ := HO.positivity_on_lattice p hp
    exact quadratic_positivity_limit s φ S p.2.1 (fun a b => hSlim _ (hD a b)) p.2.2 hpos hφ

end AssemblyCombined

/-! ## 9. Axiom check -/


end WeakUltravioletExistence

/-! Copy of SmallRemKernel (unchanged up to comments) -/
namespace SmallRemKernel

open MeasureTheory Filter Topology Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## 0. Copy of UltravioletChain (unchanged up to comments) -/

namespace UltravioletChain

open MeasureTheory Filter Topology Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## 1. (H-β): from the small-field step and the large-field step -/

/-- Per-step premises (for each bare inverse coupling `x`). `u k x` is the inverse coupling after `k` steps, `z k x` the large-field
activity, `w k x` the large-field supply generated at that step, `rs`, `rl` the small-field and large-field remainders of the coupling flow.
All fields are imposed only inside the domain (`u⋆ ≤ u` at all previous steps). -/
structure CouplingSteps (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ)
    (b C D ρ A B Z ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hC : 0 ≤ C
  hD : 0 ≤ D
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  /-- S_k: one coupling step (leading flow term `b` and two remainders) -/
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  /-- S_k: small-field remainder `|r^s| ≤ C g²` -/
  small_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ C / u k x
  /-- L_k: supply from the large-field gas to the coupling -/
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ D * z k x
  /-- L_k: activity recursion -/
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, z 0 x ≤ Z
  /-- L_k: rarity (the supply is larger for stronger coupling; `Φ` is decreasing on the domain) -/
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  supply_anti : ∀ s t, ustar ≤ s → s ≤ t → Φ t ≤ Φ s
  /-- Invariant interval: even with the supply at the worst coupling `u⋆`, the activity stays ≤ `Z` -/
  fix : ρ * Z + A * Φ ustar + B * Z ^ 2 ≤ Z
  /-- Margin: the sum of the remainders is at most half the flow -/
  margin : C / ustar + D * Z ≤ b / 2

/-- Inside the domain the activity stays ≤ `Z`. -/
theorem activity_le {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ Z := by
  intro k
  induction k with
  | zero => intro x _; exact H.act_init x
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hw : w k x ≤ Φ ustar :=
      le_trans (H.supply k x hdom') (H.supply_anti _ _ le_rfl (hdom' k le_rfl))
    have h1 : ρ * z k x ≤ ρ * Z := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ ustar := mul_le_mul_of_nonneg_left hw H.hA
    have h3 : z k x ^ 2 ≤ Z ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * Z ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    linarith [H.act_rec k x hdom', H.fix]

/-- The (H-β) form: inside the domain `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2`. -/
theorem hbeta_of_steps {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  intro k x hdom
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hz := activity_le H k x hdom
  have hdiv : C / u k x ≤ C / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hDz : D * z k x ≤ D * Z := mul_le_mul_of_nonneg_left hz H.hD
  have hs := abs_le.mp (le_trans (H.small_rem k x hdom) hdiv)
  have hl := abs_le.mp (le_trans (H.large_rem k x hdom) hDz)
  have hf := H.flow k x hdom
  have hm := H.margin
  constructor <;> nlinarith [hs.1, hs.2, hl.1, hl.2]

/-! ## 2. (H-sf): from the rarity of large-field events -/

section SmallField

variable {Ω : Type*} [MeasurableSpace Ω]

/-- Union bound: if finitely many large-field events `Bad b` (`b ∈ R`) each have probability `≤ ε`,
the small-field event (none occurs) has probability `≥ 1 − |R| ε`. -/
theorem small_field_mass_of_rarity (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type*} (R : Finset ι) (Bad : ι → Set Ω) (ε : ℝ≥0∞)
    (hbad : ∀ b ∈ R, μ (Bad b) ≤ ε) (Good : Set Ω) (hgood : (⋃ b ∈ R, Bad b)ᶜ ⊆ Good) :
    1 - R.card * ε ≤ μ Good := by
  have hU : μ (⋃ b ∈ R, Bad b) ≤ R.card * ε := by
    calc μ (⋃ b ∈ R, Bad b) ≤ ∑ b ∈ R, μ (Bad b) := measure_biUnion_finset_le R Bad
      _ ≤ ∑ _b ∈ R, ε := Finset.sum_le_sum hbad
      _ = R.card * ε := by rw [Finset.sum_const, nsmul_eq_mul]
  set U := ⋃ b ∈ R, Bad b with hUdef
  have h1 : (1 : ℝ≥0∞) ≤ μ U + μ Uᶜ := by
    rw [← measure_univ (μ := μ)]
    calc μ univ = μ (U ∪ Uᶜ) := by rw [union_compl_self]
      _ ≤ μ U + μ Uᶜ := measure_union_le _ _
  have h2 : 1 - μ U ≤ μ Uᶜ := tsub_le_iff_left.mpr h1
  calc 1 - R.card * ε ≤ 1 - μ U := tsub_le_tsub_left hU 1
    _ ≤ μ Uᶜ := h2
    _ ≤ μ Good := measure_mono hgood

/-- Invariant form: the large-field event is defined by an invariant `I b` of the field strength on each block (e.g. f₁ − f₂)
exceeding the threshold `θ_h`. The small-field event is `I b ≤ θ_h` for all `b ∈ R`. -/
theorem small_field_mass_invariant (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type*} (R : Finset ι) (I : ι → Ω → ℝ) (θh : ℝ) (ε : ℝ≥0∞)
    (hbad : ∀ b ∈ R, μ {ω | θh < I b ω} ≤ ε) :
    1 - R.card * ε ≤ μ {ω | ∀ b ∈ R, I b ω ≤ θh} := by
  apply small_field_mass_of_rarity μ R (fun b => {ω | θh < I b ω}) ε hbad
  intro ω hω
  simp only [mem_compl_iff, mem_iUnion, mem_ofPred_eq, not_exists, not_lt] at hω
  exact hω

end SmallField

/-! ## 3. (H-reg): measure-theoretic part of the one-step lemma, gauge fixing, equicontinuity -/

section Regularity

variable {Ω E : Type*} [MeasurableSpace Ω] [PseudoMetricSpace E]

/-- For a bounded (`|F| ≤ M`) `L`-Lipschitz observable, the difference of expectations of the images under two block maps is at most
the expectation of `min(2M, L·d)` of their distance. -/
theorem expectation_diff_le (μ : Measure Ω) [IsProbabilityMeasure μ]
    (F : E → ℝ) (M L : ℝ) (hM : ∀ e, |F e| ≤ M)
    (hLip : ∀ e e', |F e - F e'| ≤ L * dist e e')
    (V₁ V₂ : Ω → E)
    (hi₁ : Integrable (fun ω => F (V₁ ω)) μ) (hi₂ : Integrable (fun ω => F (V₂ ω)) μ)
    (him : Integrable (fun ω => min (2 * M) (L * dist (V₁ ω) (V₂ ω))) μ) :
    |∫ ω, F (V₁ ω) ∂μ - ∫ ω, F (V₂ ω) ∂μ| ≤
      ∫ ω, min (2 * M) (L * dist (V₁ ω) (V₂ ω)) ∂μ := by
  rw [← integral_sub hi₁ hi₂]
  refine le_trans (abs_integral_le_integral_abs) (integral_mono (hi₁.sub hi₂).abs him ?_)
  intro ω
  simp only
  refine le_min ?_ (hLip _ _)
  have h1 := hM (V₁ ω); have h2 := hM (V₂ ω)
  rw [abs_le] at h1 h2 ⊢
  constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]

/-- Splitting by the small-field event `G`: `∫ min(2M, L·D) ≤ ∫_G L·D + 2M μ(Gᶜ)`. -/
theorem split_small_field (μ : Measure Ω) [IsProbabilityMeasure μ]
    (D : Ω → ℝ) (M L : ℝ)
    (G : Set Ω) (hG : MeasurableSet G)
    (him : Integrable (fun ω => min (2 * M) (L * D ω)) μ)
    (hiD : Integrable (G.indicator fun ω => L * D ω) μ) :
    ∫ ω, min (2 * M) (L * D ω) ∂μ ≤
      ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + 2 * M * (μ Gᶜ).toReal := by
  have hic : Integrable (Gᶜ.indicator fun _ => 2 * M) μ :=
    (integrable_const (2 * M)).indicator hG.compl
  have hpt : ∀ ω, min (2 * M) (L * D ω) ≤
      G.indicator (fun ω => L * D ω) ω + Gᶜ.indicator (fun _ => 2 * M) ω := by
    intro ω
    by_cases h : ω ∈ G
    · rw [indicator_of_mem h, indicator_of_notMem (by simpa using h)]
      simp only [add_zero]; exact min_le_right _ _
    · rw [indicator_of_notMem h, indicator_of_mem (by simpa using h)]
      simp only [zero_add]; exact min_le_left _ _
  calc ∫ ω, min (2 * M) (L * D ω) ∂μ
      ≤ ∫ ω, (G.indicator (fun ω => L * D ω) ω + Gᶜ.indicator (fun _ => 2 * M) ω) ∂μ :=
        integral_mono him (hiD.add hic) hpt
    _ = ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + ∫ ω, Gᶜ.indicator (fun _ => 2 * M) ω ∂μ :=
        integral_add hiD hic
    _ = ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + 2 * M * (μ Gᶜ).toReal := by
        rw [integral_indicator_const _ hG.compl]
        simp [Measure.real, smul_eq_mul, mul_comm]

/-- Gauge fixing G_k: the difference of a gauge-invariant `L`-Lipschitz observable is bounded by the distance measured in any gauge `g`
(the background-field estimate may be used in the gauge where it holds). -/
theorem gauge_choice {G : Type*} (act : G → E → E) (F : E → ℝ) (L : ℝ)
    (hinv : ∀ g e, F (act g e) = F e) (hLip : ∀ e e', |F e - F e'| ≤ L * dist e e')
    (g : G) (e e' : E) : |F e - F e'| ≤ L * dist (act g e) (act g e') := by
  rw [← hinv g e, ← hinv g e']; exact hLip _ _

end Regularity

section Equicontinuity

variable {X : Type*} [PseudoMetricSpace X]

/-- If the estimate splits into a term τ_n going to 0 with the lattice and a term Ω(r) going to 0 with the shift,
the form of the `equicontinuous` field of Theorem W follows. -/
theorem equicontinuous_of_split (D : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ)
    (hτ : Tendsto τ atTop (𝓝 0))
    (hΩ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (hsplit : ∀ n, ∀ d ∈ D, ∀ d' ∈ D, |s n d - s n d'| ≤ τ n + Ωr (dist d d')) :
    ∀ η > 0, ∃ δ > 0, ∀ d ∈ D, ∀ d' ∈ D, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η := by
  intro η hη
  obtain ⟨δ, hδ, hΩδ⟩ := hΩ (η / 2) (by positivity)
  refine ⟨δ, hδ, fun d hd d' hd' hdd => ?_⟩
  have hev : ∀ᶠ n in atTop, τ n ≤ η / 2 :=
    (hτ.eventually (Iic_mem_nhds (by positivity : (0:ℝ) < η / 2))).mono fun n hn => hn
  refine hev.mono fun n hn => ?_
  have := hsplit n d hd d' hd'
  have := hΩδ (dist d d') dist_nonneg hdd
  linarith

/-- The sum of two estimates going to 0 also goes to 0 (assembling τ and Ω from parts). -/
theorem vanishing_add (Ω₁ Ω₂ : ℝ → ℝ)
    (h₁ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₁ r ≤ η)
    (h₂ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₂ r ≤ η) :
    ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₁ r + Ω₂ r ≤ η := by
  intro η hη
  obtain ⟨δ₁, hδ₁, k₁⟩ := h₁ (η / 2) (by positivity)
  obtain ⟨δ₂, hδ₂, k₂⟩ := h₂ (η / 2) (by positivity)
  refine ⟨min δ₁ δ₂, lt_min hδ₁ hδ₂, fun r hr hrδ => ?_⟩
  have := k₁ r hr (lt_of_lt_of_le hrδ (min_le_left _ _))
  have := k₂ r hr (lt_of_lt_of_le hrδ (min_le_right _ _))
  linarith

/-- The linear term `c·r` (smoothness of the background) goes to 0. -/
theorem vanishing_linear (c : ℝ) (hc : 0 ≤ c) :
    ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → c * r ≤ η := by
  intro η hη
  refine ⟨η / (c + 1), by positivity, fun r hr hrδ => ?_⟩
  have hc1 : 0 < c + 1 := by linarith
  have : r * (c + 1) < η := by rwa [lt_div_iff₀ hc1] at hrδ
  nlinarith

end Equicontinuity

/-! ## 4. The chain: from per-step premises to the three fields of Theorem W -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- The bundled chain premises.
* `steps`: the coupling part of S_k and L_k (§1).
* `rarity`: the rarity in L_k. For each block `b ∈ R m` at scale `m`, the probability of the large-field event (invariant form) is
  ≤ `ε m` on fine enough lattices.
* `split`: the one-step estimate through S_k, G_k, (H-reg-lf) splits into a term going to 0 with the lattice and one going to 0 with the shift. -/
structure ChainHypotheses (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ) (b C D ρ A B Z ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- Chain theorem: from the per-step premises follow (H-β) (the `hS` form of the bare-coupling lemma (W0)), (H-sf) (the `small_field_mass` form, with the event
defined by the invariant) and (H-reg) (the `equicontinuous` form) of Theorem W. -/
theorem chain_to_hypotheses {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypotheses u z w rs rl Φ b C D ρ A B Z ustar ν R I θh ε Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact small_field_mass_invariant (ν n m) (R m) (I m) (θh m) (ε m) hn
  · exact equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing H.shift_vanishing H.split

end Chain

/-! ## 5. Axiom check -/


end UltravioletChain

/-! ## 1. The ker φ form of the remainder -/

section Kernel

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- ker φ form of the remainder: if the source part `s` is in ker φ, the quadratic part `q` satisfies `‖q v‖ ≤ a‖v‖²`, the orbit lies in the
closed ball `‖v‖ ≤ (c₀/u)/(1−λ)`, and the coupling increment is `r = d + u·φ(Rf v)` (`|d| ≤ δ` the difference between λ* and the universal value),
then `|r| ≤ δ + ‖φ‖ a c₀²/((1−λ)² u)`. -/
theorem small_rem_kernel (φ : E →L[ℝ] ℝ) (Rf q : E → E) (s : E) (hs : φ s = 0)
    (hRf : ∀ v, Rf v = s + q v) (a c₀ lam u δ d : ℝ) (ha : 0 ≤ a) (hl : lam < 1) (hu : 0 < u)
    (hq : ∀ v, ‖q v‖ ≤ a * ‖v‖ ^ 2) (v : E) (hv : ‖v‖ ≤ (c₀ / u) / (1 - lam))
    (hd : |d| ≤ δ) :
    |d + u * φ (Rf v)| ≤ δ + ‖φ‖ * (a * c₀ ^ 2 / ((1 - lam) ^ 2 * u)) := by
  have hl0 : 0 < 1 - lam := by linarith
  have h1 : φ (Rf v) = φ (q v) := by rw [hRf, map_add, hs, zero_add]
  have h2 : |φ (q v)| ≤ ‖φ‖ * ‖q v‖ := by
    have := φ.le_opNorm (q v); rwa [Real.norm_eq_abs] at this
  have h3 : ‖v‖ ^ 2 ≤ ((c₀ / u) / (1 - lam)) ^ 2 := pow_le_pow_left₀ (norm_nonneg v) hv 2
  have h4 : ‖q v‖ ≤ a * ((c₀ / u) / (1 - lam)) ^ 2 :=
    le_trans (hq v) (mul_le_mul_of_nonneg_left h3 ha)
  have h5 : |φ (q v)| ≤ ‖φ‖ * (a * ((c₀ / u) / (1 - lam)) ^ 2) :=
    le_trans h2 (mul_le_mul_of_nonneg_left h4 (norm_nonneg φ))
  have e : u * (a * ((c₀ / u) / (1 - lam)) ^ 2) = a * c₀ ^ 2 / ((1 - lam) ^ 2 * u) := by
    field_simp
  have h6 : |u * φ (Rf v)| ≤ ‖φ‖ * (a * c₀ ^ 2 / ((1 - lam) ^ 2 * u)) := by
    rw [h1, abs_mul, abs_of_pos hu, ← e]
    calc u * |φ (q v)| ≤ u * (‖φ‖ * (a * ((c₀ / u) / (1 - lam)) ^ 2)) :=
          mul_le_mul_of_nonneg_left h5 hu.le
      _ = ‖φ‖ * (u * (a * ((c₀ / u) / (1 - lam)) ^ 2)) := by ring
  calc |d + u * φ (Rf v)| ≤ |d| + |u * φ (Rf v)| := abs_add_le _ _
    _ ≤ δ + ‖φ‖ * (a * c₀ ^ 2 / ((1 - lam) ^ 2 * u)) := add_le_add hd h6

/-- If `‖φ‖ ≤ 1` (`‖φ‖ = 1` for the direct-sum norm used here), then `|r| ≤ δ + C₂/u` with `C₂ = a c₀²/(1−λ)²`. -/
theorem small_rem_kernel_unit (φ : E →L[ℝ] ℝ) (hφ : ‖φ‖ ≤ 1) (Rf q : E → E) (s : E) (hs : φ s = 0)
    (hRf : ∀ v, Rf v = s + q v) (a c₀ lam u δ d : ℝ) (ha : 0 ≤ a) (hl : lam < 1) (hu : 0 < u)
    (hq : ∀ v, ‖q v‖ ≤ a * ‖v‖ ^ 2) (v : E) (hv : ‖v‖ ≤ (c₀ / u) / (1 - lam))
    (hd : |d| ≤ δ) :
    |d + u * φ (Rf v)| ≤ δ + (a * c₀ ^ 2 / (1 - lam) ^ 2) / u := by
  have h := small_rem_kernel φ Rf q s hs hRf a c₀ lam u δ d ha hl hu hq v hv hd
  have hl0 : 0 < 1 - lam := by linarith
  have hC : 0 ≤ a * c₀ ^ 2 / ((1 - lam) ^ 2 * u) := by positivity
  have e : a * c₀ ^ 2 / ((1 - lam) ^ 2 * u) = (a * c₀ ^ 2 / (1 - lam) ^ 2) / u := by
    field_simp
  rw [← e]
  nlinarith

/-! ## 2. Type caveat: the coupling increment vanishes for the projected remainder -/

/-- For a remainder with values in ker φ (the projected remainder), `u·φ(R v) = 0`. The chain's small_rem takes the unprojected remainder. -/
theorem projected_remainder_zero (φ : E →L[ℝ] ℝ) (R : E → E) (hR : ∀ v, φ (R v) = 0)
    (u : ℝ) (v : E) : u * φ (R v) = 0 := by rw [hR, mul_zero]

/-- The unprojected and projected remainders differ only by the component in the complement of ker φ:
`Rf = P Rf + (Rf − P Rf)`, and if `φ ∘ P = 0` then `φ(Rf v) = φ(Rf v − P(Rf v))`. -/
theorem coupling_from_unprojected (φ : E →L[ℝ] ℝ) (P : E → E) (hP : ∀ w, φ (P w) = 0)
    (Rf : E → E) (v : E) : φ (Rf v) = φ (Rf v - P (Rf v)) := by
  rw [map_sub, hP, sub_zero]

end Kernel

/-! ## 3. The ker φ version of the per-step premises and (H-β) -/

/-- Per-step premises (ker φ version): UltravioletChain.CouplingSteps with `small_rem` replaced by `|r^s| ≤ δ + C₂/u` and
`margin` replaced by `δ + C₂/u⋆ + DZ ≤ b/2`. -/
structure CouplingStepsKer (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ)
    (b δ C₂ D ρ A B Z ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hδ : 0 ≤ δ
  hC : 0 ≤ C₂
  hD : 0 ≤ D
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ δ + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ D * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, z 0 x ≤ Z
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  supply_anti : ∀ s t, ustar ≤ s → s ≤ t → Φ t ≤ Φ s
  fix : ρ * Z + A * Φ ustar + B * Z ^ 2 ≤ Z
  margin : δ + C₂ / ustar + D * Z ≤ b / 2

theorem activity_le_ker {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b δ C₂ D ρ A B Z ustar : ℝ}
    (H : CouplingStepsKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ Z := by
  intro k
  induction k with
  | zero => intro x _; exact H.act_init x
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hw : w k x ≤ Φ ustar :=
      le_trans (H.supply k x hdom') (H.supply_anti _ _ le_rfl (hdom' k le_rfl))
    have h1 : ρ * z k x ≤ ρ * Z := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ ustar := mul_le_mul_of_nonneg_left hw H.hA
    have h3 : z k x ^ 2 ≤ Z ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * Z ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    linarith [H.act_rec k x hdom', H.fix]

/-- The (H-β) form (ker φ version): inside the domain `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2`. -/
theorem hbeta_of_steps_ker {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b δ C₂ D ρ A B Z ustar : ℝ}
    (H : CouplingStepsKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  intro k x hdom
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hz := activity_le_ker H k x hdom
  have hdiv : C₂ / u k x ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hDz : D * z k x ≤ D * Z := mul_le_mul_of_nonneg_left hz H.hD
  have hs := abs_le.mp (le_trans (H.small_rem k x hdom) (add_le_add le_rfl hdiv))
  have hl := abs_le.mp (le_trans (H.large_rem k x hdom) hDz)
  have hf := H.flow k x hdom
  have hm := H.margin
  constructor <;> nlinarith [hs.1, hs.2, hl.1, hl.2]

/-! ## 4. Junction with UltravioletChain -/

/-- The original per-step premises are the case δ = 0. -/
theorem steps_ker_of_steps {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : UltravioletChain.CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    CouplingStepsKer u z w rs rl Φ b 0 C D ρ A B Z ustar where
  ustar_pos := H.ustar_pos
  hb := H.hb
  hδ := le_rfl
  hC := H.hC
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_rem k x h := by rw [zero_add]; exact H.small_rem k x h
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply
  supply_anti := H.supply_anti
  fix := H.fix
  margin := by rw [zero_add]; exact H.margin

/-- For δ = 0 the ker φ version of (H-β) and the original hbeta_of_steps give the same conclusion. -/
theorem hbeta_agrees {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : UltravioletChain.CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2) :=
  hbeta_of_steps_ker (steps_ker_of_steps H)

/-- Building the per-step premises from the ker φ form of the remainder: if each step's remainder has the form `r^s = d + u·φ(Rf v)`
and satisfies the hypotheses of `small_rem_kernel_unit`, then the `small_rem` field `|r^s| ≤ δ + C₂/u` holds. -/
theorem small_rem_field_of_kernel {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    (u rs : ℕ → ℝ → ℝ) (ustar : ℝ) (hus : 0 < ustar)
    (φ : E →L[ℝ] ℝ) (hφ : ‖φ‖ ≤ 1) (Rf q : ℕ → E → E) (s : ℕ → E) (hs : ∀ k, φ (s k) = 0)
    (hRf : ∀ k v, Rf k v = s k + q k v) (a c₀ lam δ : ℝ) (ha : 0 ≤ a) (hl : lam < 1)
    (hq : ∀ k v, ‖q k v‖ ≤ a * ‖v‖ ^ 2) (v : ℕ → ℝ → E) (d : ℕ → ℝ → ℝ)
    (hv : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → ‖v k x‖ ≤ (c₀ / u k x) / (1 - lam))
    (hd : ∀ k x, |d k x| ≤ δ)
    (hrs : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → rs k x = d k x + u k x * φ (Rf k (v k x))) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ δ + (a * c₀ ^ 2 / (1 - lam) ^ 2) / u k x := by
  intro k x hdom
  have hu : 0 < u k x := lt_of_lt_of_le hus (hdom k le_rfl)
  rw [hrs k x hdom]
  exact small_rem_kernel_unit φ hφ (Rf k) (q k) (s k) (hs k) (hRf k) a c₀ lam (u k x) δ (d k x)
    ha hl hu (hq k) (v k x) (hv k x hdom) (hd k x)

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- ker φ version of the chain structure (only the `steps` field replaced). -/
structure ChainHypothesesKer (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ) (b δ C₂ D ρ A B Z ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingStepsKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- Junction: from the ker φ chain, the three conclusions ((H-β), (H-sf), (H-reg)) of the same type as UltravioletChain.chain_to_hypotheses.
UltravioletGlue accepts this type, so they pass directly to the fields of Theorem W. -/
theorem chain_to_hypotheses_ker {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ}
    {b δ C₂ D ρ A B Z ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar ν R I θh ε Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps_ker H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact UltravioletChain.small_field_mass_invariant (ν n m) (R m) (I m) (θh m) (ε m) hn
  · exact UltravioletChain.equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing
      H.shift_vanishing H.split

/-- The original chain structure is the δ = 0 case of the ker φ version (agrees with the conclusion of chain_to_hypotheses). -/
theorem chain_ker_of_chain {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ}
    {b C D ρ A B Z ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : UltravioletChain.ChainHypotheses u z w rs rl Φ b C D ρ A B Z ustar ν R I θh ε Dset s τ Ωr) :
    ChainHypothesesKer u z w rs rl Φ b 0 C D ρ A B Z ustar ν R I θh ε Dset s τ Ωr where
  steps := steps_ker_of_steps H.steps
  prob := H.prob
  rarity := H.rarity
  lattice_vanishing := H.lattice_vanishing
  shift_vanishing := H.shift_vanishing
  split := H.split

end Chain


end SmallRemKernel

/-! Copy of TwoStageSmallField (unchanged up to comments) -/
namespace TwoStageSmallField

open MeasureTheory Filter Topology Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## 0. Copy of UltravioletChain (unchanged up to comments) -/

namespace UltravioletChain

open MeasureTheory Filter Topology Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## 1. (H-β): from the small-field step and the large-field step -/

/-- Per-step premises (for each bare inverse coupling `x`). `u k x` is the inverse coupling after `k` steps, `z k x` the large-field
activity, `w k x` the large-field supply generated at that step, `rs`, `rl` the small-field and large-field remainders of the coupling flow.
All fields are imposed only inside the domain (`u⋆ ≤ u` at all previous steps). -/
structure CouplingSteps (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ)
    (b C D ρ A B Z ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hC : 0 ≤ C
  hD : 0 ≤ D
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  /-- S_k: one coupling step (leading flow term `b` and two remainders) -/
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  /-- S_k: small-field remainder `|r^s| ≤ C g²` -/
  small_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ C / u k x
  /-- L_k: supply from the large-field gas to the coupling -/
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ D * z k x
  /-- L_k: activity recursion -/
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, z 0 x ≤ Z
  /-- L_k: rarity (the supply is larger for stronger coupling; `Φ` is decreasing on the domain) -/
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  supply_anti : ∀ s t, ustar ≤ s → s ≤ t → Φ t ≤ Φ s
  /-- Invariant interval: even with the supply at the worst coupling `u⋆`, the activity stays ≤ `Z` -/
  fix : ρ * Z + A * Φ ustar + B * Z ^ 2 ≤ Z
  /-- Margin: the sum of the remainders is at most half the flow -/
  margin : C / ustar + D * Z ≤ b / 2

/-- Inside the domain the activity stays ≤ `Z`. -/
theorem activity_le {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ Z := by
  intro k
  induction k with
  | zero => intro x _; exact H.act_init x
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hw : w k x ≤ Φ ustar :=
      le_trans (H.supply k x hdom') (H.supply_anti _ _ le_rfl (hdom' k le_rfl))
    have h1 : ρ * z k x ≤ ρ * Z := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ ustar := mul_le_mul_of_nonneg_left hw H.hA
    have h3 : z k x ^ 2 ≤ Z ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * Z ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    linarith [H.act_rec k x hdom', H.fix]

/-- The (H-β) form: inside the domain `u_k − 3b/2 ≤ u_{k+1} ≤ u_k − b/2`. -/
theorem hbeta_of_steps {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    (H : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  intro k x hdom
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hz := activity_le H k x hdom
  have hdiv : C / u k x ≤ C / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hDz : D * z k x ≤ D * Z := mul_le_mul_of_nonneg_left hz H.hD
  have hs := abs_le.mp (le_trans (H.small_rem k x hdom) hdiv)
  have hl := abs_le.mp (le_trans (H.large_rem k x hdom) hDz)
  have hf := H.flow k x hdom
  have hm := H.margin
  constructor <;> nlinarith [hs.1, hs.2, hl.1, hl.2]

/-! ## 2. (H-sf): from the rarity of large-field events -/

section SmallField

variable {Ω : Type*} [MeasurableSpace Ω]

/-- Union bound: if finitely many large-field events `Bad b` (`b ∈ R`) each have probability `≤ ε`,
the small-field event (none occurs) has probability `≥ 1 − |R| ε`. -/
theorem small_field_mass_of_rarity (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type*} (R : Finset ι) (Bad : ι → Set Ω) (ε : ℝ≥0∞)
    (hbad : ∀ b ∈ R, μ (Bad b) ≤ ε) (Good : Set Ω) (hgood : (⋃ b ∈ R, Bad b)ᶜ ⊆ Good) :
    1 - R.card * ε ≤ μ Good := by
  have hU : μ (⋃ b ∈ R, Bad b) ≤ R.card * ε := by
    calc μ (⋃ b ∈ R, Bad b) ≤ ∑ b ∈ R, μ (Bad b) := measure_biUnion_finset_le R Bad
      _ ≤ ∑ _b ∈ R, ε := Finset.sum_le_sum hbad
      _ = R.card * ε := by rw [Finset.sum_const, nsmul_eq_mul]
  set U := ⋃ b ∈ R, Bad b with hUdef
  have h1 : (1 : ℝ≥0∞) ≤ μ U + μ Uᶜ := by
    rw [← measure_univ (μ := μ)]
    calc μ univ = μ (U ∪ Uᶜ) := by rw [union_compl_self]
      _ ≤ μ U + μ Uᶜ := measure_union_le _ _
  have h2 : 1 - μ U ≤ μ Uᶜ := tsub_le_iff_left.mpr h1
  calc 1 - R.card * ε ≤ 1 - μ U := tsub_le_tsub_left hU 1
    _ ≤ μ Uᶜ := h2
    _ ≤ μ Good := measure_mono hgood

/-- Invariant form: the large-field event is defined by an invariant `I b` of the field strength on each block (e.g. f₁ − f₂)
exceeding the threshold `θ_h`. The small-field event is `I b ≤ θ_h` for all `b ∈ R`. -/
theorem small_field_mass_invariant (μ : Measure Ω) [IsProbabilityMeasure μ]
    {ι : Type*} (R : Finset ι) (I : ι → Ω → ℝ) (θh : ℝ) (ε : ℝ≥0∞)
    (hbad : ∀ b ∈ R, μ {ω | θh < I b ω} ≤ ε) :
    1 - R.card * ε ≤ μ {ω | ∀ b ∈ R, I b ω ≤ θh} := by
  apply small_field_mass_of_rarity μ R (fun b => {ω | θh < I b ω}) ε hbad
  intro ω hω
  simp only [mem_compl_iff, mem_iUnion, mem_ofPred_eq, not_exists, not_lt] at hω
  exact hω

end SmallField

/-! ## 3. (H-reg): measure-theoretic part of the one-step lemma, gauge fixing, equicontinuity -/

section Regularity

variable {Ω E : Type*} [MeasurableSpace Ω] [PseudoMetricSpace E]

/-- For a bounded (`|F| ≤ M`) `L`-Lipschitz observable, the difference of expectations of the images under two block maps is at most
the expectation of `min(2M, L·d)` of their distance. -/
theorem expectation_diff_le (μ : Measure Ω) [IsProbabilityMeasure μ]
    (F : E → ℝ) (M L : ℝ) (hM : ∀ e, |F e| ≤ M)
    (hLip : ∀ e e', |F e - F e'| ≤ L * dist e e')
    (V₁ V₂ : Ω → E)
    (hi₁ : Integrable (fun ω => F (V₁ ω)) μ) (hi₂ : Integrable (fun ω => F (V₂ ω)) μ)
    (him : Integrable (fun ω => min (2 * M) (L * dist (V₁ ω) (V₂ ω))) μ) :
    |∫ ω, F (V₁ ω) ∂μ - ∫ ω, F (V₂ ω) ∂μ| ≤
      ∫ ω, min (2 * M) (L * dist (V₁ ω) (V₂ ω)) ∂μ := by
  rw [← integral_sub hi₁ hi₂]
  refine le_trans (abs_integral_le_integral_abs) (integral_mono (hi₁.sub hi₂).abs him ?_)
  intro ω
  simp only
  refine le_min ?_ (hLip _ _)
  have h1 := hM (V₁ ω); have h2 := hM (V₂ ω)
  rw [abs_le] at h1 h2 ⊢
  constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]

/-- Splitting by the small-field event `G`: `∫ min(2M, L·D) ≤ ∫_G L·D + 2M μ(Gᶜ)`. -/
theorem split_small_field (μ : Measure Ω) [IsProbabilityMeasure μ]
    (D : Ω → ℝ) (M L : ℝ)
    (G : Set Ω) (hG : MeasurableSet G)
    (him : Integrable (fun ω => min (2 * M) (L * D ω)) μ)
    (hiD : Integrable (G.indicator fun ω => L * D ω) μ) :
    ∫ ω, min (2 * M) (L * D ω) ∂μ ≤
      ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + 2 * M * (μ Gᶜ).toReal := by
  have hic : Integrable (Gᶜ.indicator fun _ => 2 * M) μ :=
    (integrable_const (2 * M)).indicator hG.compl
  have hpt : ∀ ω, min (2 * M) (L * D ω) ≤
      G.indicator (fun ω => L * D ω) ω + Gᶜ.indicator (fun _ => 2 * M) ω := by
    intro ω
    by_cases h : ω ∈ G
    · rw [indicator_of_mem h, indicator_of_notMem (by simpa using h)]
      simp only [add_zero]; exact min_le_right _ _
    · rw [indicator_of_notMem h, indicator_of_mem (by simpa using h)]
      simp only [zero_add]; exact min_le_left _ _
  calc ∫ ω, min (2 * M) (L * D ω) ∂μ
      ≤ ∫ ω, (G.indicator (fun ω => L * D ω) ω + Gᶜ.indicator (fun _ => 2 * M) ω) ∂μ :=
        integral_mono him (hiD.add hic) hpt
    _ = ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + ∫ ω, Gᶜ.indicator (fun _ => 2 * M) ω ∂μ :=
        integral_add hiD hic
    _ = ∫ ω, G.indicator (fun ω => L * D ω) ω ∂μ + 2 * M * (μ Gᶜ).toReal := by
        rw [integral_indicator_const _ hG.compl]
        simp [Measure.real, smul_eq_mul, mul_comm]

/-- Gauge fixing G_k: the difference of a gauge-invariant `L`-Lipschitz observable is bounded by the distance measured in any gauge `g`
(the background-field estimate may be used in the gauge where it holds). -/
theorem gauge_choice {G : Type*} (act : G → E → E) (F : E → ℝ) (L : ℝ)
    (hinv : ∀ g e, F (act g e) = F e) (hLip : ∀ e e', |F e - F e'| ≤ L * dist e e')
    (g : G) (e e' : E) : |F e - F e'| ≤ L * dist (act g e) (act g e') := by
  rw [← hinv g e, ← hinv g e']; exact hLip _ _

end Regularity

section Equicontinuity

variable {X : Type*} [PseudoMetricSpace X]

/-- If the estimate splits into a term τ_n going to 0 with the lattice and a term Ω(r) going to 0 with the shift,
the form of the `equicontinuous` field of Theorem W follows. -/
theorem equicontinuous_of_split (D : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ)
    (hτ : Tendsto τ atTop (𝓝 0))
    (hΩ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (hsplit : ∀ n, ∀ d ∈ D, ∀ d' ∈ D, |s n d - s n d'| ≤ τ n + Ωr (dist d d')) :
    ∀ η > 0, ∃ δ > 0, ∀ d ∈ D, ∀ d' ∈ D, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η := by
  intro η hη
  obtain ⟨δ, hδ, hΩδ⟩ := hΩ (η / 2) (by positivity)
  refine ⟨δ, hδ, fun d hd d' hd' hdd => ?_⟩
  have hev : ∀ᶠ n in atTop, τ n ≤ η / 2 :=
    (hτ.eventually (Iic_mem_nhds (by positivity : (0:ℝ) < η / 2))).mono fun n hn => hn
  refine hev.mono fun n hn => ?_
  have := hsplit n d hd d' hd'
  have := hΩδ (dist d d') dist_nonneg hdd
  linarith

/-- The sum of two estimates going to 0 also goes to 0 (assembling τ and Ω from parts). -/
theorem vanishing_add (Ω₁ Ω₂ : ℝ → ℝ)
    (h₁ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₁ r ≤ η)
    (h₂ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₂ r ≤ η) :
    ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ω₁ r + Ω₂ r ≤ η := by
  intro η hη
  obtain ⟨δ₁, hδ₁, k₁⟩ := h₁ (η / 2) (by positivity)
  obtain ⟨δ₂, hδ₂, k₂⟩ := h₂ (η / 2) (by positivity)
  refine ⟨min δ₁ δ₂, lt_min hδ₁ hδ₂, fun r hr hrδ => ?_⟩
  have := k₁ r hr (lt_of_lt_of_le hrδ (min_le_left _ _))
  have := k₂ r hr (lt_of_lt_of_le hrδ (min_le_right _ _))
  linarith

/-- The linear term `c·r` (smoothness of the background) goes to 0. -/
theorem vanishing_linear (c : ℝ) (hc : 0 ≤ c) :
    ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → c * r ≤ η := by
  intro η hη
  refine ⟨η / (c + 1), by positivity, fun r hr hrδ => ?_⟩
  have hc1 : 0 < c + 1 := by linarith
  have : r * (c + 1) < η := by rwa [lt_div_iff₀ hc1] at hrδ
  nlinarith

end Equicontinuity

/-! ## 4. The chain: from per-step premises to the three fields of Theorem W -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- The bundled chain premises.
* `steps`: the coupling part of S_k and L_k (§1).
* `rarity`: the rarity in L_k. For each block `b ∈ R m` at scale `m`, the probability of the large-field event (invariant form) is
  ≤ `ε m` on fine enough lattices.
* `split`: the one-step estimate through S_k, G_k, (H-reg-lf) splits into a term going to 0 with the lattice and one going to 0 with the shift. -/
structure ChainHypotheses (u z w rs rl : ℕ → ℝ → ℝ) (Φ : ℝ → ℝ) (b C D ρ A B Z ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- Chain theorem: from the per-step premises follow (H-β) (the `hS` form of the bare-coupling lemma (W0)), (H-sf) (the `small_field_mass` form, with the event
defined by the invariant) and (H-reg) (the `equicontinuous` form) of Theorem W. -/
theorem chain_to_hypotheses {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b C D ρ A B Z ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypotheses u z w rs rl Φ b C D ρ A B Z ustar ν R I θh ε Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact small_field_mass_invariant (ν n m) (R m) (I m) (θh m) (ε m) hn
  · exact equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing H.shift_vanishing H.split

end Chain

/-! ## 5. Axiom check -/


end UltravioletChain

/-! ## 1. Two-term bound for one block -/

section Block

variable {Ω : Type*} [MeasurableSpace Ω] {Pl Pt : Type*}

/-- Bad event for one block: some plaquette angle exceeds `y_h`, or some point's background invariant exceeds `θ`. -/
def badSet (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) : Set Ω :=
  {ω | (∃ p ∈ plaq, yh < Y p ω) ∨ (∃ x ∈ pts, θ < f x ω)}

/-- Good event for one block (the two-stage small-field condition). -/
def goodSet (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) : Set Ω :=
  {ω | (∀ p ∈ plaq, Y p ω ≤ yh) ∧ (∀ x ∈ pts, f x ω ≤ θ)}

theorem badSet_eq (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) :
    badSet plaq pts Y f yh θ = (⋃ p ∈ plaq, {ω | yh < Y p ω}) ∪ (⋃ x ∈ pts, {ω | θ < f x ω}) := by
  ext ω; simp [badSet]

theorem goodSet_eq_compl (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ)
    (f : Pt → Ω → ℝ) (yh θ : ℝ) :
    goodSet plaq pts Y f yh θ = (badSet plaq pts Y f yh θ)ᶜ := by
  ext ω; simp only [goodSet, badSet, mem_ofPred_eq, mem_compl_iff, not_or, not_exists, not_and,
    not_lt]

/-- Two-term union bound: `μ(Bad) ≤ |plaq|·P₁ + |pts|·S_bg`. -/
theorem block_bad_le (μ : Measure Ω) (plaq : Finset Pl) (pts : Finset Pt)
    (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ) (yh θ : ℝ) (P₁ S : ℝ≥0∞)
    (hY : ∀ p ∈ plaq, μ {ω | yh < Y p ω} ≤ P₁) (hf : ∀ x ∈ pts, μ {ω | θ < f x ω} ≤ S) :
    μ (badSet plaq pts Y f yh θ) ≤ plaq.card * P₁ + pts.card * S := by
  rw [badSet_eq]
  refine le_trans (measure_union_le _ _) (add_le_add ?_ ?_)
  · calc μ (⋃ p ∈ plaq, {ω | yh < Y p ω}) ≤ ∑ p ∈ plaq, μ {ω | yh < Y p ω} :=
          measure_biUnion_finset_le _ _
      _ ≤ ∑ _p ∈ plaq, P₁ := Finset.sum_le_sum hY
      _ = plaq.card * P₁ := by rw [Finset.sum_const, nsmul_eq_mul]
  · calc μ (⋃ x ∈ pts, {ω | θ < f x ω}) ≤ ∑ x ∈ pts, μ {ω | θ < f x ω} :=
          measure_biUnion_finset_le _ _
      _ ≤ ∑ _x ∈ pts, S := Finset.sum_le_sum hf
      _ = pts.card * S := by rw [Finset.sum_const, nsmul_eq_mul]

/-- With counting bounds: if `|plaq| ≤ n_p` and `|pts| ≤ n_pt`, then `μ(Bad) ≤ n_p·P₁ + n_pt·S_bg`. -/
theorem block_bad_le_counts (μ : Measure Ω) (plaq : Finset Pl) (pts : Finset Pt)
    (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ) (yh θ : ℝ) (P₁ S : ℝ≥0∞) (np npt : ℕ)
    (hnp : plaq.card ≤ np) (hnpt : pts.card ≤ npt)
    (hY : ∀ p ∈ plaq, μ {ω | yh < Y p ω} ≤ P₁) (hf : ∀ x ∈ pts, μ {ω | θ < f x ω} ≤ S) :
    μ (badSet plaq pts Y f yh θ) ≤ np * P₁ + npt * S := by
  refine le_trans (block_bad_le μ plaq pts Y f yh θ P₁ S hY hf) (add_le_add ?_ ?_)
  · have : (plaq.card : ℝ≥0∞) ≤ np := by exact_mod_cast hnp
    gcongr
  · have : (pts.card : ℝ≥0∞) ≤ npt := by exact_mod_cast hnpt
    gcongr

/-! ## 2. Indicator invariant -/

open Classical in
/-- Two-stage indicator invariant of a block: 1 if bad, 0 if good. The form that goes into the chain's `I` field (threshold `θ_h = 1/2`). -/
noncomputable def twoStageIndex (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ)
    (f : Pt → Ω → ℝ) (yh θ : ℝ) (ω : Ω) : ℝ :=
  if (∃ p ∈ plaq, yh < Y p ω) ∨ (∃ x ∈ pts, θ < f x ω) then 1 else 0

theorem index_bad_eq (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) :
    {ω | (1 / 2 : ℝ) < twoStageIndex plaq pts Y f yh θ ω} = badSet plaq pts Y f yh θ := by
  ext ω
  simp only [mem_ofPred_eq, badSet, twoStageIndex]
  split_ifs with h
  · simp only [h, iff_true]; norm_num
  · simp only [h, iff_false, not_lt]; norm_num

theorem index_good_eq (plaq : Finset Pl) (pts : Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) (ω : Ω) :
    twoStageIndex plaq pts Y f yh θ ω ≤ 1 / 2 ↔
      (∀ p ∈ plaq, Y p ω ≤ yh) ∧ (∀ x ∈ pts, f x ω ≤ θ) := by
  have h := congrArg (fun s : Set Ω => ω ∈ s) (index_bad_eq plaq pts Y f yh θ)
  simp only [mem_ofPred_eq, eq_iff_iff] at h
  have h2 := congrArg (fun s : Set Ω => ω ∈ s) (goodSet_eq_compl plaq pts Y f yh θ)
  simp only [eq_iff_iff, mem_compl_iff] at h2
  rw [← not_lt, h]
  exact h2.symm.trans (by simp [goodSet])

end Block

/-! ## 3. Mass of the two-stage small-field event -/

section Mass

variable {Ω : Type*} [MeasurableSpace Ω] {ι Pl Pt : Type*}

/-- Two-stage form of (H-sf): for each block `i ∈ R`, plaquettes `plaq i` (≤ n_p of them) and points `pts i` (≤ n_pt of them); if each
plaquette has probability ≤ P₁ and each point ≤ S_bg, then the event that every block is good has probability ≥ 1 − |R|·(n_p·P₁ + n_pt·S_bg). -/
theorem small_field_two_stage (μ : Measure Ω) [IsProbabilityMeasure μ] (R : Finset ι)
    (plaq : ι → Finset Pl) (pts : ι → Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) (P₁ S : ℝ≥0∞) (np npt : ℕ)
    (hnp : ∀ i ∈ R, (plaq i).card ≤ np) (hnpt : ∀ i ∈ R, (pts i).card ≤ npt)
    (hY : ∀ i ∈ R, ∀ p ∈ plaq i, μ {ω | yh < Y p ω} ≤ P₁)
    (hf : ∀ i ∈ R, ∀ x ∈ pts i, μ {ω | θ < f x ω} ≤ S) :
    1 - R.card * (np * P₁ + npt * S) ≤
      μ {ω | ∀ i ∈ R, (∀ p ∈ plaq i, Y p ω ≤ yh) ∧ (∀ x ∈ pts i, f x ω ≤ θ)} := by
  apply UltravioletChain.small_field_mass_of_rarity μ R (fun i => badSet (plaq i) (pts i) Y f yh θ)
  · intro i hi
    exact block_bad_le_counts μ (plaq i) (pts i) Y f yh θ P₁ S np npt (hnp i hi) (hnpt i hi)
      (hY i hi) (hf i hi)
  · intro ω hω
    simp only [mem_compl_iff, mem_iUnion, not_exists] at hω
    intro i hi
    have := hω i hi
    have h2 := congrArg (fun s : Set Ω => ω ∈ s) (goodSet_eq_compl (plaq i) (pts i) Y f yh θ)
    simp only [eq_iff_iff, mem_compl_iff] at h2
    exact h2.mpr this

/-- The η form: if `|R| ≤ n_box` then `|R|·(n_p·P₁ + n_pt·S_bg) ≤ n_box·(n_p·P₁ + n_pt·S_bg)`. -/
theorem eta_le (R : Finset ι) (nbox np npt : ℕ) (P₁ S : ℝ≥0∞) (hR : R.card ≤ nbox) :
    (R.card : ℝ≥0∞) * (np * P₁ + npt * S) ≤ nbox * (np * P₁ + npt * S) := by
  have : (R.card : ℝ≥0∞) ≤ nbox := by exact_mod_cast hR
  gcongr

/-- Form `1 − n_box·[n_p·P₁ + n_pt·S_bg] ≤ μ(small field)`. -/
theorem small_field_two_stage_box (μ : Measure Ω) [IsProbabilityMeasure μ] (R : Finset ι)
    (plaq : ι → Finset Pl) (pts : ι → Finset Pt) (Y : Pl → Ω → ℝ) (f : Pt → Ω → ℝ)
    (yh θ : ℝ) (P₁ S : ℝ≥0∞) (nbox np npt : ℕ) (hR : R.card ≤ nbox)
    (hnp : ∀ i ∈ R, (plaq i).card ≤ np) (hnpt : ∀ i ∈ R, (pts i).card ≤ npt)
    (hY : ∀ i ∈ R, ∀ p ∈ plaq i, μ {ω | yh < Y p ω} ≤ P₁)
    (hf : ∀ i ∈ R, ∀ x ∈ pts i, μ {ω | θ < f x ω} ≤ S) :
    1 - nbox * (np * P₁ + npt * S) ≤
      μ {ω | ∀ i ∈ R, (∀ p ∈ plaq i, Y p ω ≤ yh) ∧ (∀ x ∈ pts i, f x ω ≤ θ)} :=
  le_trans (tsub_le_tsub_left (eta_le R nbox np npt P₁ S hR) 1)
    (small_field_two_stage μ R plaq pts Y f yh θ P₁ S np npt hnp hnpt hY hf)

end Mass

/-! ## 4. Junction with the chain's rarity field -/

section ChainGlue

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]
variable {ι Pl Pt : ℕ → Type*}

/-- Junction: if the per-plaquette and per-point probability bounds hold on fine enough lattices, the two-stage indicator invariant
gives the `rarity` field of UltravioletChain.ChainHypotheses (`θ_h = 1/2`, `ε_m = n_p·P₁ + n_pt·S_bg`). -/
theorem rarity_two_stage (ν : ℕ → ∀ m, Measure (E m)) (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Y : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m)
    (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hprob : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (∀ p ∈ plaq m i, ν n m {ω | yh m < Y m p ω} ≤ P₁ m) ∧
      (∀ x ∈ pts m i, ν n m {ω | θ m < f m x ω} ≤ S m)) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      ν n m {ω | (fun _ => (1 / 2 : ℝ)) m <
        (fun m i => twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m)) m i ω} ≤
        (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) m := by
  intro m
  refine (hprob m).mono fun n hn i hi => ?_
  simp only
  rw [index_bad_eq]
  exact block_bad_le_counts (ν n m) (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m) (P₁ m) (S m)
    (np m) (npt m) (hnp m i hi) (hnpt m i hi) (hn i hi).1 (hn i hi).2

/-! ## 5. Building the chain with the two-stage event, and reading its (H-sf) field as the two-stage event -/

variable {X : Type*} [PseudoMetricSpace X]

/-- Building the chain structure with the two-stage indicator invariant (the rarity field is filled by `rarity_two_stage`). -/
theorem chain_hypotheses_two_stage {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ}
    {b C D ρ A B Z ustar : ℝ}
    (ν : ℕ → ∀ m, Measure (E m)) (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Y : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (hsteps : UltravioletChain.CouplingSteps u z w rs rl Φ b C D ρ A B Z ustar)
    (hP : ∀ n m, IsProbabilityMeasure (ν n m))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m)
    (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hprob : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (∀ p ∈ plaq m i, ν n m {ω | yh m < Y m p ω} ≤ P₁ m) ∧
      (∀ x ∈ pts m i, ν n m {ω | θ m < f m x ω} ≤ S m))
    (hτ : Tendsto τ atTop (𝓝 0))
    (hΩ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (hsplit : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')) :
    UltravioletChain.ChainHypotheses u z w rs rl Φ b C D ρ A B Z ustar ν R
      (fun m i => twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr where
  steps := hsteps
  prob := hP
  rarity := rarity_two_stage ν R plaq pts Y f yh θ P₁ S np npt hnp hnpt hprob
  lattice_vanishing := hτ
  shift_vanishing := hΩ
  split := hsplit

/-- Reading the chain's (H-sf) field as the two-stage event: the second conclusion of chain_to_hypotheses becomes
mass ≥ 1 − |R_m|·(n_p·P₁ + n_pt·S_bg) of the event "angle ≤ y_h at all plaquettes and background invariant ≤ θ at all points"
(and 1 − n_box·[…] if moreover |R_m| ≤ n_box). -/
theorem hsf_two_stage {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ}
    {b C D ρ A B Z ustar : ℝ}
    (ν : ℕ → ∀ m, Measure (E m)) (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Y : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt nbox : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : UltravioletChain.ChainHypotheses u z w rs rl Φ b C D ρ A B Z ustar ν R
      (fun m i => twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (hR : ∀ m, (R m).card ≤ nbox m) :
    ∀ m, ∀ᶠ n in atTop,
      1 - nbox m * (np m * P₁ m + npt m * S m) ≤
        ν n m {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Y m p ω ≤ yh m) ∧ (∀ x ∈ pts m i, f m x ω ≤ θ m)} := by
  intro m
  refine ((UltravioletChain.chain_to_hypotheses H).2.1 m).mono fun n hn => ?_
  have hset : {ω | ∀ i ∈ R m, twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m) ω ≤ 1 / 2} =
      {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Y m p ω ≤ yh m) ∧ (∀ x ∈ pts m i, f m x ω ≤ θ m)} := by
    ext ω
    simp only [mem_ofPred_eq]
    exact forall₂_congr fun i _ => index_good_eq _ _ _ _ _ _ ω
  rw [hset] at hn
  exact le_trans (tsub_le_tsub_left (eta_le (R m) (nbox m) (np m) (npt m) (P₁ m) (S m) (hR m)) 1) hn

end ChainGlue


end TwoStageSmallField

namespace ChainEndToEnd

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- The chain end to end. -/
theorem chain_end_to_end
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b δ C₂ D ρ A B Z ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Y : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : SmallRemKernel.ChainHypothesesKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    -- remaining fields of the bare-coupling lemma (W0)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    -- remaining fields at the block-variable level
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Y m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    -- remaining fields at the observable level
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + b / 2 * n ≤ x ∧ x ≤ t + 3 * b / 2 * n ∧
      u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  obtain ⟨hβ, hsf, hreg⟩ := SmallRemKernel.chain_to_hypotheses_ker H
  refine ⟨fun t ht n => WeakUltravioletExistence.exists_bare_inverse_coupling u b ustar t n
    H.steps.hb h0 hβ hCu ht, ?_⟩
  have HB : WeakUltravioletExistence.BlockHypotheses νP Bm hB Θ Aset actb Cset
      (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) :=
    { consistent := hcons, reflection_continuous := hΘc, reflection_positive := hΘp,
      symmetry_continuous := hsc, symmetric := hsym, small_field_closed := hCc,
      small_field_mass := fun m => (hsf m).mono fun n hn => by
        refine le_trans hn (measure_mono ?_)
        intro ω hω
        apply hgood m
        intro i hi
        exact (TwoStageSmallField.index_good_eq (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m)
          ω).mp (hω i hi) }
  have HO : WeakUltravioletExistence.ObservableHypotheses Dset s Bd act εb Pset :=
    { countable := hcount, dense := hdense, bounded := hbd, equicontinuous := hreg,
      act_continuous := hac, act_maps := ham, breaking := hbr, breaking_vanishes := hbv,
      positivity_on_lattice := hpos }
  exact WeakUltravioletExistence.weak_uv_skeleton νP Bm hB Θ Aset actb Cset _ Dset s Bd act εb Pset
    lev Fo HB HO HR

/-- Entry point: build the end-to-end theorem's structure from the per-step premises (ker φ version) and the per-plaquette and
per-point probability bounds (the rarity field is filled by TwoStageSmallField.rarity_two_stage). -/
theorem chain_ker_two_stage
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ : ℝ → ℝ} {b δ C₂ D ρ A B Z ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Y : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (hsteps : SmallRemKernel.CouplingStepsKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar)
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m)
    (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hprob : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (∀ p ∈ plaq m i, (νP n m : Measure (E m)) {ω | yh m < Y m p ω} ≤ P₁ m) ∧
      (∀ x ∈ pts m i, (νP n m : Measure (E m)) {ω | θ m < f m x ω} ≤ S m))
    (hτ : Tendsto τ atTop (𝓝 0))
    (hΩ : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (hsplit : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')) :
    SmallRemKernel.ChainHypothesesKer u z w rs rl Φ b δ C₂ D ρ A B Z ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Y m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr where
  steps := hsteps
  prob := fun _ _ => inferInstance
  rarity := TwoStageSmallField.rarity_two_stage (fun n m => (νP n m : Measure (E m))) R plaq pts
    Y f yh θ P₁ S np npt hnp hnpt hprob
  lattice_vanishing := hτ
  shift_vanishing := hΩ
  split := hsplit


end ChainEndToEnd

namespace ChainMoving

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## M1. Per-step hypotheses (moving invariant interval) -/

structure CouplingStepsMoving (u z w rs rl : ℕ → ℝ → ℝ) (Φ W : ℝ → ℝ)
    (b δ C₂ D₁ ρ A B Y ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ δ + C₂ / u k x
  /-- The large-field contribution may grow proportionally to u -/
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ D₁ * u k x * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, z 0 x ≤ W (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  W_anti : ∀ s t, ustar ≤ s → s ≤ t → W t ≤ W s
  fix_moving : ∀ s, ustar ≤ s → ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s
  uW : ∀ s, ustar ≤ s → s * W s ≤ Y
  margin : δ + C₂ / ustar + D₁ * Y ≤ b / 2

/-- One step: if z_k ≤ W(u_k), the two-sided bound for that step. -/
theorem step_moving {u z w rs rl : ℕ → ℝ → ℝ} {Φ W : ℝ → ℝ} {b δ C₂ D₁ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMoving u z w rs rl Φ W b δ C₂ D₁ ρ A B Y ustar) (k : ℕ) (x : ℝ)
    (hdom : ∀ j ≤ k, ustar ≤ u j x) (hz : z k x ≤ W (u k x)) :
    u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hu0 : 0 ≤ u k x := le_trans H.ustar_pos.le hu
  have hdiv : C₂ / u k x ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have h1 : D₁ * u k x * z k x ≤ D₁ * u k x * W (u k x) :=
    mul_le_mul_of_nonneg_left hz (mul_nonneg H.hD hu0)
  have h2 : D₁ * (u k x * W (u k x)) ≤ D₁ * Y := mul_le_mul_of_nonneg_left (H.uW _ hu) H.hD
  have hl : |rl k x| ≤ D₁ * Y := by
    calc |rl k x| ≤ D₁ * u k x * z k x := H.large_rem k x hdom
      _ ≤ D₁ * u k x * W (u k x) := h1
      _ = D₁ * (u k x * W (u k x)) := by ring
      _ ≤ D₁ * Y := h2
  have hs := abs_le.mp (le_trans (H.small_rem k x hdom) (add_le_add le_rfl hdiv))
  have hl' := abs_le.mp hl
  have hf := H.flow k x hdom
  have hm := H.margin
  constructor <;> linarith [hs.1, hs.2, hl'.1, hl'.2]

/-- Within the domain the activity stays below the moving bound W(u_k) (joint induction with the coupling steps). -/
theorem activity_le_moving {u z w rs rl : ℕ → ℝ → ℝ} {Φ W : ℝ → ℝ}
    {b δ C₂ D₁ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMoving u z w rs rl Φ W b δ C₂ D₁ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ W (u k x) := by
  intro k
  induction k with
  | zero => intro x _; exact H.act_init x
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hst := step_moving H k x hdom' hz
    have hb := H.hb
    have hdown : u (k + 1) x ≤ u k x := by linarith [hst.2]
    have huk := hdom' k le_rfl
    have h1 : ρ * z k x ≤ ρ * W (u k x) := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ (u k x) := mul_le_mul_of_nonneg_left (H.supply k x hdom') H.hA
    have h3 : z k x ^ 2 ≤ W (u k x) ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * W (u k x) ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    have h5 := H.fix_moving (u k x) huk
    have h6 := H.W_anti (u (k + 1) x) (u k x) (hdom (k + 1) le_rfl) hdown
    linarith [H.act_rec k x hdom']

/-- The (H-β) form (moving version): same conclusion as `hbeta_of_steps_ker`. -/
theorem hbeta_of_steps_moving {u z w rs rl : ℕ → ℝ → ℝ} {Φ W : ℝ → ℝ}
    {b δ C₂ D₁ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMoving u z w rs rl Φ W b δ C₂ D₁ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 :=
  fun k x hdom => step_moving H k x hdom (activity_le_moving H k x hdom)


/-- General form: per-step hypotheses with the large-field coefficient a function `Dfun` of u. -/
structure CouplingStepsMovingD (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ)
    (b δ C₂ ρ A B Y ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hb : 0 < b
  hC : 0 ≤ C₂
  hD : ∀ s, ustar ≤ s → 0 ≤ Dfun s
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rs k x| ≤ δ + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ Dfun (u k x) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, z 0 x ≤ W (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  W_anti : ∀ s t, ustar ≤ s → s ≤ t → W t ≤ W s
  fix_moving : ∀ s, ustar ≤ s → ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s
  DW : ∀ s, ustar ≤ s → Dfun s * W s ≤ Y
  margin : δ + C₂ / ustar + Y ≤ b / 2

/-- The `D₁ u` form is a special case of the general form (`Dfun s = D₁ s`, `Y ↦ D₁ Y`). -/
theorem movingD_of_moving {u z w rs rl : ℕ → ℝ → ℝ} {Φ W : ℝ → ℝ} {b δ C₂ D₁ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMoving u z w rs rl Φ W b δ C₂ D₁ ρ A B Y ustar) :
    CouplingStepsMovingD u z w rs rl Φ W (fun s => D₁ * s) b δ C₂ ρ A B (D₁ * Y) ustar where
  ustar_pos := H.ustar_pos
  hb := H.hb
  hC := H.hC
  hD := fun s hs => mul_nonneg H.hD (le_trans H.ustar_pos.le hs)
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_rem := H.small_rem
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply
  W_anti := H.W_anti
  fix_moving := H.fix_moving
  DW := fun s hs => by
    have := mul_le_mul_of_nonneg_left (H.uW s hs) H.hD
    calc D₁ * s * W s = D₁ * (s * W s) := by ring
      _ ≤ D₁ * Y := this
  margin := H.margin

/-- One step (general form). -/
theorem step_movingD {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {b δ C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) (k : ℕ) (x : ℝ)
    (hdom : ∀ j ≤ k, ustar ≤ u j x) (hz : z k x ≤ W (u k x)) :
    u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hdiv : C₂ / u k x ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hl : |rl k x| ≤ Y :=
    le_trans (H.large_rem k x hdom)
      (le_trans (mul_le_mul_of_nonneg_left hz (H.hD _ hu)) (H.DW _ hu))
  have hs := abs_le.mp (le_trans (H.small_rem k x hdom) (add_le_add le_rfl hdiv))
  have hl' := abs_le.mp hl
  have hf := H.flow k x hdom
  have hm := H.margin
  constructor <;> linarith [hs.1, hs.2, hl'.1, hl'.2]

theorem activity_le_movingD {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ W (u k x) := by
  intro k
  induction k with
  | zero => intro x _; exact H.act_init x
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hst := step_movingD H k x hdom' hz
    have hb := H.hb
    have hdown : u (k + 1) x ≤ u k x := by linarith [hst.2]
    have huk := hdom' k le_rfl
    have h1 : ρ * z k x ≤ ρ * W (u k x) := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ (u k x) := mul_le_mul_of_nonneg_left (H.supply k x hdom') H.hA
    have h3 : z k x ^ 2 ≤ W (u k x) ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * W (u k x) ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    have h5 := H.fix_moving (u k x) huk
    have h6 := H.W_anti (u (k + 1) x) (u k x) (hdom (k + 1) le_rfl) hdown
    linarith [H.act_rec k x hdom']

theorem hbeta_of_steps_movingD {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 :=
  fun k x hdom => step_movingD H k x hdom (activity_le_movingD H k x hdom)

/-! ## M2. The chain structure and end-to-end -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

structure ChainHypothesesMoving (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ)
    (b δ C₂ ρ A B Y ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- The three conclusions of the moving chain (same type as `chain_to_hypotheses_ker`). -/
theorem chain_to_hypotheses_moving {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesMoving u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar ν R I θh ε Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps_movingD H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact SmallRemKernel.UltravioletChain.small_field_mass_invariant (ν n m) (R m) (I m) (θh m) (ε m) hn
  · exact SmallRemKernel.UltravioletChain.equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing
      H.shift_vanishing H.split

end Chain

section EndToEnd

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Chain end to end (moving version): the conclusion is the same as `ChainEndToEnd.chain_end_to_end`. -/
theorem chain_end_to_end_moving
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {b δ C₂ ρ A B Y ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesMoving u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + b / 2 * n ≤ x ∧ x ≤ t + 3 * b / 2 * n ∧
      u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  obtain ⟨hβ, hsf, hreg⟩ := chain_to_hypotheses_moving H
  refine ⟨fun t ht n => WeakUltravioletExistence.exists_bare_inverse_coupling u b ustar t n
    H.steps.hb h0 hβ hCu ht, ?_⟩
  have HB : WeakUltravioletExistence.BlockHypotheses νP Bm hB Θ Aset actb Cset
      (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) :=
    { consistent := hcons, reflection_continuous := hΘc, reflection_positive := hΘp,
      symmetry_continuous := hsc, symmetric := hsym, small_field_closed := hCc,
      small_field_mass := fun m => (hsf m).mono fun n hn => by
        refine le_trans hn (measure_mono ?_)
        intro ω hω
        apply hgood m
        intro i hi
        exact (TwoStageSmallField.index_good_eq (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m)
          ω).mp (hω i hi) }
  have HO : WeakUltravioletExistence.ObservableHypotheses Dset s Bd act εb Pset :=
    { countable := hcount, dense := hdense, bounded := hbd, equicontinuous := hreg,
      act_continuous := hac, act_maps := ham, breaking := hbr, breaking_vanishes := hbv,
      positivity_on_lattice := hpos }
  exact WeakUltravioletExistence.weak_uv_skeleton νP Bm hB Θ Aset actb Cset _ Dset s Bd act εb Pset
    lev Fo HB HO HR

end EndToEnd

/-! ## M3. With a logarithmic threshold the margin fields hold uniformly in u -/

/-- Invariant-interval arithmetic (copy of `ActivityFixedInterval.fixed_interval`). -/
theorem fixed_interval (ρ A Φ B : ℝ) (hρ1 : ρ < 1) (hA : 0 ≤ A) (hΦ : 0 ≤ Φ)
    (hsmall : 4 * B * (A * Φ) ≤ (1 - ρ) ^ 2 / 2) :
    ρ * (2 * (A * Φ) / (1 - ρ)) + A * Φ + B * (2 * (A * Φ) / (1 - ρ)) ^ 2 ≤
      2 * (A * Φ) / (1 - ρ) := by
  have h1 : 0 < 1 - ρ := by linarith
  set w := A * Φ with hw
  have hw0 : 0 ≤ w := mul_nonneg hA hΦ
  have key : (ρ * (2 * w / (1 - ρ)) + w + B * (2 * w / (1 - ρ)) ^ 2) * (1 - ρ) ^ 2 ≤
      (2 * w / (1 - ρ)) * (1 - ρ) ^ 2 := by
    have e1 : (ρ * (2 * w / (1 - ρ)) + w + B * (2 * w / (1 - ρ)) ^ 2) * (1 - ρ) ^ 2 =
        2 * ρ * w * (1 - ρ) + w * (1 - ρ) ^ 2 + 4 * B * w ^ 2 := by
      field_simp; ring
    have e2 : (2 * w / (1 - ρ)) * (1 - ρ) ^ 2 = 2 * w * (1 - ρ) := by
      field_simp
    rw [e1, e2]
    have h4 : 4 * B * w ^ 2 ≤ w * ((1 - ρ) ^ 2 / 2) := by
      have := mul_le_mul_of_nonneg_left hsmall hw0
      nlinarith
    nlinarith [sq_nonneg (1 - ρ)]
  have hpos : 0 < (1 - ρ) ^ 2 := by positivity
  exact le_of_mul_le_mul_right key hpos

/-- Supply under the logarithmic threshold: `Φ(s) = K e^{−t((log s)/t + c)} = K e^{−tc}/s` (s > 0). -/
theorem log_supply (K t c s : ℝ) (ht : t ≠ 0) (hs : 0 < s) :
    K * Real.exp (-(t * (Real.log s / t + c))) = K * Real.exp (-(t * c)) / s := by
  have e : -(t * (Real.log s / t + c)) = -Real.log s + -(t * c) := by field_simp; ring
  rw [e, Real.exp_add, Real.exp_neg, Real.exp_log hs]
  field_simp

/-- Under the logarithmic threshold the three fields of the moving version hold (monotonicity of W, the invariant interval at each s, s W(s) ≤ Y).
`W(s) = 2AΦ(s)/(1−ρ)`, `Φ(s) = K₀/s` (K₀ = K e^{−tc} ≥ 0), `Y = 2AK₀/(1−ρ)`.
Smallness of the invariant interval is imposed once, at the worst case `s = u⋆`. -/
theorem moving_of_log_threshold (ρ A B K₀ ustar : ℝ) (hρ1 : ρ < 1) (hA : 0 ≤ A) (hK : 0 ≤ K₀)
    (hus : 0 < ustar) (hsmall : 4 * B * (A * (K₀ / ustar)) ≤ (1 - ρ) ^ 2 / 2) (hB : 0 ≤ B) :
    let Φ : ℝ → ℝ := fun s => K₀ / s
    let W : ℝ → ℝ := fun s => 2 * (A * Φ s) / (1 - ρ)
    (∀ s t, ustar ≤ s → s ≤ t → W t ≤ W s) ∧
    (∀ s, ustar ≤ s → ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s) ∧
    (∀ s, ustar ≤ s → s * W s ≤ 2 * A * K₀ / (1 - ρ)) := by
  intro Φ W
  have h1 : 0 < 1 - ρ := by linarith
  have hΦa : ∀ s t, ustar ≤ s → s ≤ t → Φ t ≤ Φ s := by
    intro s t hs hst
    exact div_le_div_of_nonneg_left hK (lt_of_lt_of_le hus hs) hst
  refine ⟨?_, ?_, ?_⟩
  · intro s t hs hst
    have := hΦa s t hs hst
    have h2 : A * Φ t ≤ A * Φ s := mul_le_mul_of_nonneg_left this hA
    exact div_le_div_of_nonneg_right (by linarith) h1.le
  · intro s hs
    have hs0 : 0 < s := lt_of_lt_of_le hus hs
    have hΦ0 : 0 ≤ Φ s := div_nonneg hK hs0.le
    have hΦs : Φ s ≤ K₀ / ustar := hΦa ustar s le_rfl hs
    have hsm : 4 * B * (A * Φ s) ≤ (1 - ρ) ^ 2 / 2 := by
      have : A * Φ s ≤ A * (K₀ / ustar) := mul_le_mul_of_nonneg_left hΦs hA
      have : 4 * B * (A * Φ s) ≤ 4 * B * (A * (K₀ / ustar)) :=
        mul_le_mul_of_nonneg_left this (by linarith)
      linarith
    exact fixed_interval ρ A (Φ s) B hρ1 hA hΦ0 hsm
  · intro s hs
    have hs0 : 0 < s := lt_of_lt_of_le hus hs
    have e : s * W s = 2 * A * K₀ / (1 - ρ) := by
      show s * (2 * (A * (K₀ / s)) / (1 - ρ)) = 2 * A * K₀ / (1 - ρ)
      field_simp
    exact e.le

/-- When the coefficient grows with the threshold (D(s) = a·s·y_h(s), the Gaussian form κ(y) ≲ y/144): choosing
`y_h(s) = 2(log s)/t + c` (s ≥ 1, c ≥ 0, t > 0) gives `D(s)·K e^{−t y_h(s)} ≤ a K e^{−tc}(2/t + c)`. -/
theorem growing_coefficient_threshold (a K t c s : ℝ) (ha : 0 ≤ a) (hK : 0 ≤ K) (ht : 0 < t)
    (hc : 0 ≤ c) (hs : 1 ≤ s) :
    a * s * (2 * Real.log s / t + c) * (K * Real.exp (-(t * (2 * Real.log s / t + c)))) ≤
      a * K * Real.exp (-(t * c)) * (2 / t + c) := by
  have hs0 : 0 < s := by linarith
  have hlog0 : 0 ≤ Real.log s := Real.log_nonneg hs
  have hlog : Real.log s ≤ s := le_trans (Real.log_le_sub_one_of_pos hs0) (by linarith)
  have e : Real.exp (-(t * (2 * Real.log s / t + c))) = Real.exp (-(t * c)) / s ^ 2 := by
    have : -(t * (2 * Real.log s / t + c)) = -(2 * Real.log s) + -(t * c) := by
      field_simp; ring
    rw [this, Real.exp_add, Real.exp_neg, show 2 * Real.log s = Real.log (s ^ 2) by
      rw [Real.log_pow]; norm_num, Real.exp_log (by positivity)]
    field_simp
  rw [e]
  set E := Real.exp (-(t * c)) with hE
  have hE0 : 0 ≤ E := (Real.exp_pos _).le
  have key : s * (2 * Real.log s / t + c) / s ^ 2 ≤ 2 / t + c := by
    rw [div_le_iff₀ (by positivity)]
    have h1 : 2 * Real.log s / t ≤ 2 * s / t := by
      apply div_le_div_of_nonneg_right _ ht.le; linarith
    have h3 : c ≤ c * s := by nlinarith
    have hin : 2 * Real.log s / t + c ≤ (2 / t + c) * s := by
      have : 2 * s / t = 2 / t * s := by ring
      nlinarith
    calc s * (2 * Real.log s / t + c) ≤ s * ((2 / t + c) * s) :=
          mul_le_mul_of_nonneg_left hin hs0.le
      _ = (2 / t + c) * s ^ 2 := by ring
  calc a * s * (2 * Real.log s / t + c) * (K * (E / s ^ 2))
      = a * K * E * (s * (2 * Real.log s / t + c) / s ^ 2) := by ring
    _ ≤ a * K * E * (2 / t + c) := mul_le_mul_of_nonneg_left key (by positivity)

end ChainMoving



/-! # Copy of AsymptoticThreshold.lean (unchanged up to comments) -/

namespace AsymptoticPremises

open Set

/-! ## (a) The threshold 2(log u)/σ + y₀ and the point u⋆ -/

/-- Supply under the threshold `2(log s)/σ + y₀`: `K e^{−σ(2(log s)/σ + y₀)} = K e^{−σ y₀}/s²`. -/
theorem supply_sq_log_threshold (K σ y₀ s : ℝ) (hσ : 0 < σ) (hs : 0 < s) :
    K * Real.exp (-(σ * (2 * Real.log s / σ + y₀))) = K * Real.exp (-(σ * y₀)) / s ^ 2 := by
  have e : Real.exp (-(σ * (2 * Real.log s / σ + y₀))) = Real.exp (-(σ * y₀)) / s ^ 2 := by
    have : -(σ * (2 * Real.log s / σ + y₀)) = -(2 * Real.log s) + -(σ * y₀) := by
      field_simp; ring
    rw [this, Real.exp_add, Real.exp_neg, show 2 * Real.log s = Real.log (s ^ 2) by
      rw [Real.log_pow]; norm_num, Real.exp_log (by positivity)]
    field_simp
  rw [e]
  ring

noncomputable section

/-- Supply bound under the threshold `2(log u)/σ + y₀`: `Φ(u) = Φ₀/u²`. -/
def supplySq (Φ₀ : ℝ) (s : ℝ) : ℝ := Φ₀ / s ^ 2

/-- Moving bound `W(u) = 2AΦ(u)/(1−ρ)`. -/
def movingBound (ρ A Φ₀ : ℝ) (s : ℝ) : ℝ := 2 * (A * supplySq Φ₀ s) / (1 - ρ)

/-- `Υ(u) = 2AD₁Φ₀/((1−ρ)u)`, the bound on `D₁u·W(u)`. -/
def upsilon (ρ A D₁ Φ₀ : ℝ) (s : ℝ) : ℝ := 2 * A * D₁ * Φ₀ / ((1 - ρ) * s)

/-- The point u⋆: an explicit expression in the constants `u₀, ρ, A, B, D₁, Φ₀, C₂` and the margin `m`. -/
def ustarOf (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) : ℝ :=
  max u₀ (max 1 (max (4 * A * B * Φ₀ / (1 - ρ) ^ 2) ((C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ)) / m)))

end

theorem supplySq_nonneg {Φ₀ : ℝ} (hΦ : 0 ≤ Φ₀) (s : ℝ) : 0 ≤ supplySq Φ₀ s :=
  div_nonneg hΦ (sq_nonneg s)

theorem movingBound_nonneg {ρ A Φ₀ : ℝ} (hρ1 : ρ < 1) (hA : 0 ≤ A) (hΦ : 0 ≤ Φ₀) (s : ℝ) :
    0 ≤ movingBound ρ A Φ₀ s := by
  unfold movingBound
  have : 0 ≤ A * supplySq Φ₀ s := mul_nonneg hA (supplySq_nonneg hΦ s)
  exact div_nonneg (by linarith) (by linarith)

theorem supplySq_anti {Φ₀ : ℝ} (hΦ : 0 ≤ Φ₀) {s t : ℝ} (hs : 0 < s) (hst : s ≤ t) :
    supplySq Φ₀ t ≤ supplySq Φ₀ s := by
  unfold supplySq
  exact div_le_div_of_nonneg_left hΦ (by positivity) (pow_le_pow_left₀ hs.le hst 2)

theorem movingBound_anti {ρ A Φ₀ : ℝ} (hρ1 : ρ < 1) (hA : 0 ≤ A) (hΦ : 0 ≤ Φ₀) {s t : ℝ}
    (hs : 0 < s) (hst : s ≤ t) : movingBound ρ A Φ₀ t ≤ movingBound ρ A Φ₀ s := by
  unfold movingBound
  have h1 : 0 < 1 - ρ := by linarith
  have h2 : A * supplySq Φ₀ t ≤ A * supplySq Φ₀ s :=
    mul_le_mul_of_nonneg_left (supplySq_anti hΦ hs hst) hA
  exact div_le_div_of_nonneg_right (by linarith) h1.le

/-- Invariant-interval arithmetic, sharp form: with `W = 2AΦ/(1−ρ)`, `ρW + AΦ + BW² ≤ W` as soon as
`4B(AΦ) ≤ (1−ρ)²` (the copy in the chain files asks for `(1−ρ)²/2`). -/
theorem fixed_interval_sharp (ρ A Φ B : ℝ) (hρ1 : ρ < 1) (hA : 0 ≤ A) (hΦ : 0 ≤ Φ)
    (hsmall : 4 * B * (A * Φ) ≤ (1 - ρ) ^ 2) :
    ρ * (2 * (A * Φ) / (1 - ρ)) + A * Φ + B * (2 * (A * Φ) / (1 - ρ)) ^ 2 ≤
      2 * (A * Φ) / (1 - ρ) := by
  have h1 : 0 < 1 - ρ := by linarith
  set w := A * Φ with hw
  have hw0 : 0 ≤ w := mul_nonneg hA hΦ
  have key : (ρ * (2 * w / (1 - ρ)) + w + B * (2 * w / (1 - ρ)) ^ 2) * (1 - ρ) ^ 2 ≤
      (2 * w / (1 - ρ)) * (1 - ρ) ^ 2 := by
    have e1 : (ρ * (2 * w / (1 - ρ)) + w + B * (2 * w / (1 - ρ)) ^ 2) * (1 - ρ) ^ 2 =
        2 * ρ * w * (1 - ρ) + w * (1 - ρ) ^ 2 + 4 * B * w ^ 2 := by
      field_simp; ring
    have e2 : (2 * w / (1 - ρ)) * (1 - ρ) ^ 2 = 2 * w * (1 - ρ) := by
      field_simp
    rw [e1, e2]
    have h4 : 4 * B * w ^ 2 ≤ w * (1 - ρ) ^ 2 := by
      have := mul_le_mul_of_nonneg_left hsmall hw0
      nlinarith
    nlinarith [sq_nonneg (1 - ρ)]
  have hpos : 0 < (1 - ρ) ^ 2 := by positivity
  exact le_of_mul_le_mul_right key hpos

/-- The sharp condition is also necessary when `AΦ > 0`. -/
theorem fixed_interval_sharp_converse (ρ A Φ B : ℝ) (hρ1 : ρ < 1) (hw : 0 < A * Φ)
    (h : ρ * (2 * (A * Φ) / (1 - ρ)) + A * Φ + B * (2 * (A * Φ) / (1 - ρ)) ^ 2 ≤
      2 * (A * Φ) / (1 - ρ)) :
    4 * B * (A * Φ) ≤ (1 - ρ) ^ 2 := by
  have h1 : 0 < 1 - ρ := by linarith
  set w := A * Φ with hw'
  have hpos : 0 < (1 - ρ) ^ 2 := by positivity
  have key := mul_le_mul_of_nonneg_right h hpos.le
  have e1 : (ρ * (2 * w / (1 - ρ)) + w + B * (2 * w / (1 - ρ)) ^ 2) * (1 - ρ) ^ 2 =
      2 * ρ * w * (1 - ρ) + w * (1 - ρ) ^ 2 + 4 * B * w ^ 2 := by
    field_simp; ring
  have e2 : (2 * w / (1 - ρ)) * (1 - ρ) ^ 2 = 2 * w * (1 - ρ) := by
    field_simp
  rw [e1, e2] at key
  have h4 : w * (4 * B * w) ≤ w * (1 - ρ) ^ 2 := by nlinarith
  exact le_of_mul_le_mul_left h4 hw

/-- `D₁ s · W(s) = Υ(s)`. -/
theorem coefficient_times_bound (ρ A D₁ Φ₀ s : ℝ) (hρ1 : ρ < 1) (hs : 0 < s) :
    D₁ * s * movingBound ρ A Φ₀ s = upsilon ρ A D₁ Φ₀ s := by
  have h1 : 0 < 1 - ρ := by linarith
  unfold movingBound supplySq upsilon
  field_simp

/-- `Υ` is non-increasing on `(0, ∞)`. -/
theorem upsilon_anti (ρ A D₁ Φ₀ : ℝ) (hρ1 : ρ < 1) (hA : 0 ≤ A) (hD : 0 ≤ D₁) (hΦ : 0 ≤ Φ₀)
    {s t : ℝ} (hs : 0 < s) (hst : s ≤ t) : upsilon ρ A D₁ Φ₀ t ≤ upsilon ρ A D₁ Φ₀ s := by
  have h1 : 0 < 1 - ρ := by linarith
  unfold upsilon
  exact div_le_div_of_nonneg_left (by positivity) (by positivity)
    (mul_le_mul_of_nonneg_left hst h1.le)

theorem le_ustarOf (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) : u₀ ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m := by
  unfold ustarOf
  exact le_max_left _ _

theorem one_le_ustarOf (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) : 1 ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m := by
  unfold ustarOf
  exact le_trans (le_max_left _ _) (le_max_right _ _)

theorem ustarOf_pos (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) : 0 < ustarOf u₀ ρ A B D₁ Φ₀ C₂ m :=
  lt_of_lt_of_le one_pos (one_le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m)

theorem quad_le_ustarOf (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) :
    4 * A * B * Φ₀ / (1 - ρ) ^ 2 ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m := by
  unfold ustarOf
  exact le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) (le_max_right _ _)

theorem margin_le_ustarOf (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) :
    (C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ)) / m ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m := by
  unfold ustarOf
  exact le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) (le_max_right _ _)

/-- (a) The point u⋆ = `ustarOf …` (a function of the constants only) satisfies, for every u ≥ u⋆,
(i) the invariant interval `4ABΦ₀/((1−ρ)²u²) ≤ 1` and (ii) the margin `C₂/u + Υ(u) ≤ m`.
Only `ρ < 1` and `m > 0` are used; the signs of A, B, D₁, Φ₀, C₂ enter only through the chain fields. -/
theorem ustar_of_sq_log_threshold (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) (hρ1 : ρ < 1) (hm : 0 < m) :
    u₀ ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ∧ 1 ≤ ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ∧
    (∀ s, ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ s → 4 * A * B * Φ₀ / ((1 - ρ) ^ 2 * s ^ 2) ≤ 1) ∧
    (∀ s, ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ s → C₂ / s + upsilon ρ A D₁ Φ₀ s ≤ m) := by
  have h1 : 0 < 1 - ρ := by linarith
  have hu1 := one_le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m
  refine ⟨le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m, hu1, ?_, ?_⟩
  · intro s hs
    have hs1 : 1 ≤ s := le_trans hu1 hs
    have hs0 : 0 < s := by linarith
    have hq : 4 * A * B * Φ₀ / (1 - ρ) ^ 2 ≤ s := le_trans (quad_le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) hs
    have hq' : 4 * A * B * Φ₀ ≤ s * (1 - ρ) ^ 2 := by
      rwa [div_le_iff₀ (by positivity)] at hq
    have hss : s ≤ s ^ 2 := by nlinarith
    have hmul : (1 - ρ) ^ 2 * s ≤ (1 - ρ) ^ 2 * s ^ 2 :=
      mul_le_mul_of_nonneg_left hss (sq_nonneg (1 - ρ))
    have hpos : 0 < (1 - ρ) ^ 2 * s ^ 2 := by positivity
    rw [div_le_iff₀ hpos]
    nlinarith
  · intro s hs
    have hs1 : 1 ≤ s := le_trans hu1 hs
    have hs0 : 0 < s := by linarith
    have hq : (C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ)) / m ≤ s :=
      le_trans (margin_le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) hs
    have hq' : C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ) ≤ s * m := by
      rwa [div_le_iff₀ hm] at hq
    have e : C₂ / s + upsilon ρ A D₁ Φ₀ s = (C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ)) / s := by
      unfold upsilon
      rw [add_div, div_div]
    rw [e, div_le_iff₀ hs0]
    linarith

/-- (a), existence form: some u⋆ ≥ u₀ (positive) such that (i) and (ii) hold at every u ≥ u⋆. -/
theorem exists_ustar_sq_log_threshold (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) (hρ1 : ρ < 1) (hm : 0 < m) :
    ∃ us : ℝ, u₀ ≤ us ∧ 0 < us ∧ ∀ s, us ≤ s →
      4 * A * B * Φ₀ / ((1 - ρ) ^ 2 * s ^ 2) ≤ 1 ∧ C₂ / s + upsilon ρ A D₁ Φ₀ s ≤ m := by
  obtain ⟨h0, h1, hi, hii⟩ := ustar_of_sq_log_threshold u₀ ρ A B D₁ Φ₀ C₂ m hρ1 hm
  exact ⟨_, h0, lt_of_lt_of_le one_pos h1, fun s hs => ⟨hi s hs, hii s hs⟩⟩

/-- (a), the fields of the moving chain on `[u⋆, ∞)` with `Φ = Φ₀/s²`, `W = 2AΦ/(1−ρ)`, `D(s) = D₁s`,
`Y = Υ(u⋆)`: W non-increasing, the invariant interval at each s, `D(s)W(s) ≤ Υ(u⋆)`, and the margin
`C₂/u⋆ + Υ(u⋆) ≤ m`. -/
theorem moving_fields_sq_log (u₀ ρ A B D₁ Φ₀ C₂ m : ℝ) (hρ1 : ρ < 1)
    (hA : 0 ≤ A) (hD : 0 ≤ D₁) (hΦ : 0 ≤ Φ₀) (hm : 0 < m) :
    (∀ s t, ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ s → s ≤ t →
        movingBound ρ A Φ₀ t ≤ movingBound ρ A Φ₀ s) ∧
    (∀ s, ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ s →
        ρ * movingBound ρ A Φ₀ s + A * supplySq Φ₀ s + B * movingBound ρ A Φ₀ s ^ 2 ≤
          movingBound ρ A Φ₀ s) ∧
    (∀ s, ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ s →
        D₁ * s * movingBound ρ A Φ₀ s ≤ upsilon ρ A D₁ Φ₀ (ustarOf u₀ ρ A B D₁ Φ₀ C₂ m)) ∧
    C₂ / ustarOf u₀ ρ A B D₁ Φ₀ C₂ m + upsilon ρ A D₁ Φ₀ (ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) ≤ m := by
  obtain ⟨-, hu1, hi, hii⟩ := ustar_of_sq_log_threshold u₀ ρ A B D₁ Φ₀ C₂ m hρ1 hm
  have hus : 0 < ustarOf u₀ ρ A B D₁ Φ₀ C₂ m := lt_of_lt_of_le one_pos hu1
  have h1 : 0 < 1 - ρ := by linarith
  refine ⟨?_, ?_, ?_, hii _ le_rfl⟩
  · intro s t hs hst
    exact movingBound_anti hρ1 hA hΦ (lt_of_lt_of_le hus hs) hst
  · intro s hs
    have hs0 : 0 < s := lt_of_lt_of_le hus hs
    have h := hi s hs
    rw [div_le_iff₀ (by positivity), one_mul] at h
    have hsm : 4 * B * (A * supplySq Φ₀ s) ≤ (1 - ρ) ^ 2 := by
      have e : 4 * B * (A * supplySq Φ₀ s) = 4 * A * B * Φ₀ / s ^ 2 := by
        unfold supplySq; ring
      rw [e, div_le_iff₀ (by positivity)]
      linarith
    exact fixed_interval_sharp ρ A (supplySq Φ₀ s) B hρ1 hA (supplySq_nonneg hΦ s) hsm
  · intro s hs
    have hs0 : 0 < s := lt_of_lt_of_le hus hs
    rw [coefficient_times_bound ρ A D₁ Φ₀ s hρ1 hs0]
    exact upsilon_anti ρ A D₁ Φ₀ hρ1 hA hD hΦ hus hs

/-! ## (a′) The other numbers paid by u⋆: the floor, the window, a coefficient growing with the threshold -/

/-- `log s ≤ 2√s` for `s > 0`. -/
theorem log_le_two_sqrt {s : ℝ} (hs : 0 < s) : Real.log s ≤ 2 * Real.sqrt s := by
  have h1 : 0 < Real.sqrt s := Real.sqrt_pos.mpr hs
  have h2 := Real.log_le_sub_one_of_pos h1
  rw [Real.log_sqrt hs.le] at h2
  linarith

/-- The floor is paid by u: for `c > 0` (`c = 4(1 − cos θ_c)`, so that `c·u = β(1 − cos θ_c)` at `β = 4u`),
the threshold `2(log u)/σ + y₀` stays below `c·u` for every `u ≥ max 1 (max (8/(cσ))² (2y₀/c))`. -/
theorem floor_of_sq_log_threshold (c σ y₀ : ℝ) (hc : 0 < c) (hσ : 0 < σ) :
    ∀ u, max 1 (max ((8 / (c * σ)) ^ 2) (2 * y₀ / c)) ≤ u → 2 * Real.log u / σ + y₀ ≤ c * u := by
  intro u hu
  have hu1 : 1 ≤ u := le_trans (le_max_left _ _) hu
  have hu2 : (8 / (c * σ)) ^ 2 ≤ u := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hu
  have hu3 : 2 * y₀ / c ≤ u := le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hu
  have hu0 : 0 < u := by linarith
  have hcσ : 0 < c * σ := mul_pos hc hσ
  have hlog := log_le_two_sqrt hu0
  have hr : 0 < Real.sqrt u := Real.sqrt_pos.mpr hu0
  have hrr : Real.sqrt u * Real.sqrt u = u := Real.mul_self_sqrt hu0.le
  have hsq : 8 / (c * σ) ≤ Real.sqrt u := by
    have h := Real.sqrt_le_sqrt hu2
    rwa [Real.sqrt_sq (by positivity)] at h
  have hcs : 8 ≤ c * σ * Real.sqrt u := by
    have h := (div_le_iff₀ hcσ).mp hsq
    linarith
  have key : 8 * Real.sqrt u ≤ c * σ * u := by
    have h := mul_le_mul_of_nonneg_right hcs hr.le
    calc 8 * Real.sqrt u ≤ c * σ * Real.sqrt u * Real.sqrt u := h
      _ = c * σ * (Real.sqrt u * Real.sqrt u) := by ring
      _ = c * σ * u := by rw [hrr]
  have h1 : 2 * Real.log u / σ ≤ 4 * Real.sqrt u / σ :=
    div_le_div_of_nonneg_right (by linarith) hσ.le
  have h2 : 4 * Real.sqrt u / σ ≤ c * u / 2 := by
    rw [div_le_iff₀ hσ]
    linarith
  have h3 : y₀ ≤ c * u / 2 := by
    have h := (div_le_iff₀ hc).mp hu3
    linarith
  linarith

/-- The window of the class is paid by u: for `τ < 1`, `α > 0` and every
`u ≥ max 1 (max (2ℓ/(1−τ)) (32αc₀/(1−τ)²))`, `κ(u) = 1 − τ − ℓ/u ≥ (1−τ)/2` and the solvability
condition `c₀/u ≤ κ(u)²/(8α)` of the window holds. -/
theorem window_of_large_u (τ α c₀ ℓ : ℝ) (hτ : τ < 1) (hα : 0 < α) :
    ∀ u, max 1 (max (2 * ℓ / (1 - τ)) (32 * α * c₀ / (1 - τ) ^ 2)) ≤ u →
      (1 - τ) / 2 ≤ 1 - τ - ℓ / u ∧ c₀ / u ≤ (1 - τ - ℓ / u) ^ 2 / (8 * α) := by
  intro u hu
  have h1 : 0 < 1 - τ := by linarith
  have hu1 : 1 ≤ u := le_trans (le_max_left _ _) hu
  have hu0 : 0 < u := by linarith
  have hu2 : 2 * ℓ / (1 - τ) ≤ u := le_trans (le_trans (le_max_left _ _) (le_max_right _ _)) hu
  have hu3 : 32 * α * c₀ / (1 - τ) ^ 2 ≤ u :=
    le_trans (le_trans (le_max_right _ _) (le_max_right _ _)) hu
  have hk : (1 - τ) / 2 ≤ 1 - τ - ℓ / u := by
    have h2 : 2 * ℓ ≤ u * (1 - τ) := (div_le_iff₀ h1).mp hu2
    have h3 : ℓ / u ≤ (1 - τ) / 2 := by
      rw [div_le_iff₀ hu0]; linarith
    linarith
  refine ⟨hk, ?_⟩
  have hk0 : 0 ≤ (1 - τ) / 2 := by linarith
  have hsq : ((1 - τ) / 2) ^ 2 ≤ (1 - τ - ℓ / u) ^ 2 := pow_le_pow_left₀ hk0 hk 2
  have hc : c₀ / u ≤ ((1 - τ) / 2) ^ 2 / (8 * α) := by
    have h32 : 32 * α * c₀ ≤ u * (1 - τ) ^ 2 := (div_le_iff₀ (by positivity)).mp hu3
    rw [div_le_iff₀ hu0]
    have e : ((1 - τ) / 2) ^ 2 / (8 * α) * u = u * (1 - τ) ^ 2 / (32 * α) := by ring
    rw [e, le_div_iff₀ (by positivity)]
    linarith
  calc c₀ / u ≤ ((1 - τ) / 2) ^ 2 / (8 * α) := hc
    _ ≤ (1 - τ - ℓ / u) ^ 2 / (8 * α) := div_le_div_of_nonneg_right hsq (by positivity)

/-- Coefficient growing with the threshold, `D(u) = D₁u(2(log u)/σ + y₀)` (the form `D₁u·y_s(u)`):
for `u ≥ 1` and `y₀ ≥ 0`, `D(u)W(u) ≤ Υ₀(4/σ + y₀)/√u` with `Υ₀ = 2AD₁Φ₀/(1−ρ)`; the bound tends to 0. -/
theorem growing_coefficient_decay (ρ A D₁ Φ₀ σ y₀ u : ℝ) (hρ1 : ρ < 1) (hA : 0 ≤ A)
    (hD : 0 ≤ D₁) (hΦ : 0 ≤ Φ₀) (hσ : 0 < σ) (hy : 0 ≤ y₀) (hu : 1 ≤ u) :
    D₁ * u * (2 * Real.log u / σ + y₀) * movingBound ρ A Φ₀ u ≤
      2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) / Real.sqrt u := by
  have h1 : 0 < 1 - ρ := by linarith
  have hu0 : 0 < u := by linarith
  have hr : 0 < Real.sqrt u := Real.sqrt_pos.mpr hu0
  have hr1 : 1 ≤ Real.sqrt u := by
    have h := Real.sqrt_le_sqrt hu
    rwa [Real.sqrt_one] at h
  have hrr : Real.sqrt u * Real.sqrt u = u := Real.mul_self_sqrt hu0.le
  have hlog := log_le_two_sqrt hu0
  have e : D₁ * u * (2 * Real.log u / σ + y₀) * movingBound ρ A Φ₀ u =
      2 * A * D₁ * Φ₀ / (1 - ρ) * ((2 * Real.log u / σ + y₀) / u) := by
    have e1 : D₁ * u * (2 * Real.log u / σ + y₀) * movingBound ρ A Φ₀ u =
        (2 * Real.log u / σ + y₀) * (D₁ * u * movingBound ρ A Φ₀ u) := by ring
    have e2 : upsilon ρ A D₁ Φ₀ u = 2 * A * D₁ * Φ₀ / (1 - ρ) / u := by
      unfold upsilon; rw [div_div]
    rw [e1, coefficient_times_bound ρ A D₁ Φ₀ u hρ1 hu0, e2]
    ring
  rw [e]
  have hΥ : 0 ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) := by positivity
  have hN : 2 * Real.log u / σ + y₀ ≤ (4 / σ + y₀) * Real.sqrt u := by
    have ha : 2 * Real.log u / σ ≤ 4 * Real.sqrt u / σ :=
      div_le_div_of_nonneg_right (by linarith) hσ.le
    have hb : y₀ ≤ y₀ * Real.sqrt u := le_mul_of_one_le_right hy hr1
    have hc : 4 * Real.sqrt u / σ = 4 / σ * Real.sqrt u := by ring
    nlinarith
  have key : (2 * Real.log u / σ + y₀) / u ≤ (4 / σ + y₀) / Real.sqrt u := by
    calc (2 * Real.log u / σ + y₀) / u ≤ (4 / σ + y₀) * Real.sqrt u / u :=
          div_le_div_of_nonneg_right hN hu0.le
      _ = (4 / σ + y₀) / Real.sqrt u := by
          rw [div_eq_div_iff hu0.ne' hr.ne', mul_assoc, hrr]
  calc 2 * A * D₁ * Φ₀ / (1 - ρ) * ((2 * Real.log u / σ + y₀) / u)
      ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) * ((4 / σ + y₀) / Real.sqrt u) :=
        mul_le_mul_of_nonneg_left key hΥ
    _ = 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) / Real.sqrt u := by ring

/-- With the coefficient `D₁u·y_s(u)` the margin is still paid by u: for every
`u ≥ max 1 (((C₂ + Υ₀(4/σ + y₀))/m)²)`, `C₂/u + Υ₀(4/σ + y₀)/√u ≤ m` (`Υ₀ ≥ 0`, `C₂ ≥ 0`, `y₀ ≥ 0`). -/
theorem margin_growing_coefficient (C₂ Υ₀ σ y₀ m : ℝ) (hC : 0 ≤ C₂) (hΥ : 0 ≤ Υ₀) (hσ : 0 < σ)
    (hy : 0 ≤ y₀) (hm : 0 < m) :
    ∀ u, max 1 (((C₂ + Υ₀ * (4 / σ + y₀)) / m) ^ 2) ≤ u →
      C₂ / u + Υ₀ * (4 / σ + y₀) / Real.sqrt u ≤ m := by
  intro u hu
  have hu1 : 1 ≤ u := le_trans (le_max_left _ _) hu
  have hu2 : ((C₂ + Υ₀ * (4 / σ + y₀)) / m) ^ 2 ≤ u := le_trans (le_max_right _ _) hu
  have hu0 : 0 < u := by linarith
  have hr : 0 < Real.sqrt u := Real.sqrt_pos.mpr hu0
  have hr1 : 1 ≤ Real.sqrt u := by
    have h := Real.sqrt_le_sqrt hu1
    rwa [Real.sqrt_one] at h
  have hrr : Real.sqrt u * Real.sqrt u = u := Real.mul_self_sqrt hu0.le
  have hK : 0 ≤ C₂ + Υ₀ * (4 / σ + y₀) := by positivity
  have hsq : (C₂ + Υ₀ * (4 / σ + y₀)) / m ≤ Real.sqrt u := by
    have h := Real.sqrt_le_sqrt hu2
    rwa [Real.sqrt_sq (by positivity)] at h
  have h1 : C₂ / u ≤ C₂ / Real.sqrt u := by
    apply div_le_div_of_nonneg_left hC hr
    calc Real.sqrt u = Real.sqrt u * 1 := by ring
      _ ≤ Real.sqrt u * Real.sqrt u := mul_le_mul_of_nonneg_left hr1 hr.le
      _ = u := hrr
  have h2 : C₂ / Real.sqrt u + Υ₀ * (4 / σ + y₀) / Real.sqrt u =
      (C₂ + Υ₀ * (4 / σ + y₀)) / Real.sqrt u := by rw [add_div]
  have h3 : (C₂ + Υ₀ * (4 / σ + y₀)) / Real.sqrt u ≤ m := by
    rw [div_le_iff₀ hr]
    have h := (div_le_iff₀ hm).mp hsq
    linarith
  linarith

noncomputable section

/-- The point u⋆ for the coefficient `D₁u·y_s(u)`. -/
def ustarGrowingOf (u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m : ℝ) : ℝ :=
  max (ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) (((C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀)) / m) ^ 2)

/-- `Υ′(u) = Υ₀(4/σ + y₀)/√u`, the bound on `D₁u·y_s(u)·W(u)`. -/
def upsilonGrowing (ρ A D₁ Φ₀ σ y₀ : ℝ) (s : ℝ) : ℝ :=
  2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) / Real.sqrt s

end

/-- Fields of the moving chain with the coefficient `D(s) = D₁s(2(log s)/σ + y₀)` at
`u⋆ = ustarGrowingOf …` (constants only): `u⋆ ≥ u₀`, `u⋆ ≥ 1`, `D ≥ 0`, W non-increasing, the invariant
interval, `D(s)W(s) ≤ Υ′(u⋆)`, and the margin `C₂/u⋆ + Υ′(u⋆) ≤ m`. -/
theorem moving_fields_growing (u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m : ℝ) (hρ1 : ρ < 1)
    (hA : 0 ≤ A) (hD : 0 ≤ D₁) (hΦ : 0 ≤ Φ₀) (hC : 0 ≤ C₂) (hσ : 0 < σ) (hy : 0 ≤ y₀)
    (hm : 0 < m) :
    u₀ ≤ ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ∧ 1 ≤ ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ∧
    (∀ s, ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ≤ s →
        0 ≤ D₁ * s * (2 * Real.log s / σ + y₀)) ∧
    (∀ s t, ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ≤ s → s ≤ t →
        movingBound ρ A Φ₀ t ≤ movingBound ρ A Φ₀ s) ∧
    (∀ s, ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ≤ s →
        ρ * movingBound ρ A Φ₀ s + A * supplySq Φ₀ s + B * movingBound ρ A Φ₀ s ^ 2 ≤
          movingBound ρ A Φ₀ s) ∧
    (∀ s, ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m ≤ s →
        D₁ * s * (2 * Real.log s / σ + y₀) * movingBound ρ A Φ₀ s ≤
          upsilonGrowing ρ A D₁ Φ₀ σ y₀ (ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m)) ∧
    C₂ / ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m +
      upsilonGrowing ρ A D₁ Φ₀ σ y₀ (ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m) ≤ m := by
  have h1 : 0 < 1 - ρ := by linarith
  have hΥ : 0 ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) := by positivity
  have hle : ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤ ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m := by
    unfold ustarGrowingOf; exact le_max_left _ _
  have hsq : ((C₂ + 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀)) / m) ^ 2 ≤
      ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m := by
    unfold ustarGrowingOf; exact le_max_right _ _
  have hu1 : 1 ≤ ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m :=
    le_trans (one_le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) hle
  have hus : 0 < ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m := by linarith
  obtain ⟨hW, hfix, -, -⟩ := moving_fields_sq_log u₀ ρ A B D₁ Φ₀ C₂ m hρ1 hA hD hΦ hm
  refine ⟨le_trans (le_ustarOf u₀ ρ A B D₁ Φ₀ C₂ m) hle, hu1, ?_, ?_, ?_, ?_, ?_⟩
  · intro s hs
    have hs1 : 1 ≤ s := le_trans hu1 hs
    have hN : 0 ≤ 2 * Real.log s / σ + y₀ := by
      have : 0 ≤ 2 * Real.log s / σ := div_nonneg (by linarith [Real.log_nonneg hs1]) hσ.le
      linarith
    have hs0 : 0 ≤ s := by linarith
    exact mul_nonneg (mul_nonneg hD hs0) hN
  · intro s t hs hst
    exact hW s t (le_trans hle hs) hst
  · intro s hs
    exact hfix s (le_trans hle hs)
  · intro s hs
    have hs1 : 1 ≤ s := le_trans hu1 hs
    have hg := growing_coefficient_decay ρ A D₁ Φ₀ σ y₀ s hρ1 hA hD hΦ hσ hy hs1
    have hsq' : Real.sqrt (ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m) ≤ Real.sqrt s :=
      Real.sqrt_le_sqrt hs
    have hr : 0 < Real.sqrt (ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m) := Real.sqrt_pos.mpr hus
    have hK : 0 ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) := by positivity
    unfold upsilonGrowing
    calc D₁ * s * (2 * Real.log s / σ + y₀) * movingBound ρ A Φ₀ s
        ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) / Real.sqrt s := hg
      _ ≤ 2 * A * D₁ * Φ₀ / (1 - ρ) * (4 / σ + y₀) /
            Real.sqrt (ustarGrowingOf u₀ ρ A B D₁ Φ₀ C₂ σ y₀ m) :=
          div_le_div_of_nonneg_left hK hr hsq'
  · unfold upsilonGrowing
    exact margin_growing_coefficient C₂ (2 * A * D₁ * Φ₀ / (1 - ρ)) σ y₀ m hC hΥ hσ hy hm _
      (max_le hu1 hsq)

/-! ## (b) Bare-coupling lemma with a signed bracket -/

/-- (b) The bare-coupling lemma (W0) with a signed bracket. On the domain `{x | ∀ j ≤ k, u⋆ ≤ u j x}`
assume the net decrease of one step lies in `[bm, bp]` with `0 ≤ bm`, and continuity of `x ↦ u_{k+1} x`.
For a target `t ≥ u⋆` and `n` steps there is a bare value `x` with `u_n x = t`, `u_k x ≥ t` for `k ≤ n`,
and `t + bm·n ≤ x ≤ t + bp·n`. (`bm ≤ bp` follows from the hypothesis at `k = 0`, `x = t`.) -/
theorem exists_bare_inverse_coupling_signed (u : ℕ → ℝ → ℝ) (bm bp ustar t : ℝ) (n : ℕ)
    (hbm : 0 ≤ bm) (h0 : ∀ x, u 0 x = x)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      bm ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp)
    (hC : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (ht : ustar ≤ t) :
    ∃ x : ℝ, t + bm * n ≤ x ∧ x ≤ t + bp * n ∧ u n x = t ∧ ∀ k ≤ n, t ≤ u k x := by
  have hbp : 0 ≤ bp := by
    have hd0 : ∀ j ≤ 0, ustar ≤ u j t := by
      intro j hj
      obtain rfl : j = 0 := by omega
      rw [h0]; exact ht
    have := hS 0 t hd0
    linarith [this.1, this.2]
  -- sandwich for the sequence of steps (while inside the domain)
  have hdrop : ∀ x, ∀ k, (∀ j ≤ k, ustar ≤ u j x) →
      u k x ≤ x - bm * k ∧ x - bp * k ≤ u k x := by
    intro x k
    induction k with
    | zero => intro _; simp [h0]
    | succ k ih =>
      intro hd
      have hd' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hd j (by omega)
      obtain ⟨i1, i2⟩ := ih hd'
      obtain ⟨s1, s2⟩ := hS k x hd'
      push_cast
      constructor <;> linarith
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    refine ⟨t, by simp, by simp, h0 t, ?_⟩
    intro k hk
    have : k = 0 := by omega
    subst this; simp [h0]
  set a : ℝ := t + bp * n with ha
  -- K_k: starting points in [t, a] that stay ≥ t up to step k
  let K : ℕ → Set ℝ := fun k => {x | x ∈ Icc t a ∧ ∀ j ≤ k, t ≤ u j x}
  have hKdom : ∀ k x, x ∈ K k → ∀ j ≤ k, ustar ≤ u j x :=
    fun k x hx j hj => le_trans ht (hx.2 j hj)
  have hKclosed : ∀ k, IsClosed (K k) := by
    intro k
    induction k with
    | zero =>
      have : K 0 = Icc t a := by
        ext x
        simp only [K, mem_ofPred_eq, mem_Icc]
        constructor
        · intro h; exact h.1
        · intro h
          refine ⟨h, fun j hj => ?_⟩
          have : j = 0 := by omega
          subst this; rw [h0]; exact h.1
      rw [this]; exact isClosed_Icc
    | succ k ih =>
      have hco : ContinuousOn (u (k + 1)) (K k) :=
        (hC k).mono (fun x hx => hKdom k x hx)
      have hset : K (k + 1) = K k ∩ u (k + 1) ⁻¹' Ici t := by
        ext x
        simp only [K, mem_ofPred_eq, mem_inter_iff, mem_preimage, mem_Ici]
        constructor
        · rintro ⟨h1, h2⟩
          exact ⟨⟨h1, fun j hj => h2 j (by omega)⟩, h2 (k + 1) le_rfl⟩
        · rintro ⟨⟨h1, h2⟩, h3⟩
          refine ⟨h1, fun j hj => ?_⟩
          rcases Nat.lt_or_ge j (k + 1) with hlt | hge
          · exact h2 j (by omega)
          · have : j = k + 1 := by omega
            subst this; exact h3
      rw [hset]
      exact hco.preimage_isClosed_of_isClosed ih isClosed_Ici
  -- a lies in K n
  have hta : t ≤ a := by
    have : (0 : ℝ) ≤ bp * n := by positivity
    linarith
  have ha_mem : a ∈ K n := by
    have key : ∀ k ≤ n, (∀ j ≤ k, t + bp * ((n : ℝ) - j) ≤ u j a) := by
      intro k
      induction k with
      | zero => intro _ j hj; have : j = 0 := by omega
                subst this; simp [h0, ha]
      | succ k ih =>
        intro hk j hj
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact ih (by omega) j (by omega)
        · have : j = k + 1 := by omega
          subst this
          have ih' := ih (by omega)
          have hd : ∀ i ≤ k, ustar ≤ u i a := by
            intro i hi
            have h1 := ih' i hi
            have hin : (i : ℝ) ≤ n := by exact_mod_cast (show i ≤ n by omega)
            have : (0 : ℝ) ≤ bp * ((n : ℝ) - i) := mul_nonneg hbp (by linarith)
            linarith
          have s2 := (hS k a hd).2
          have hk' := ih' k le_rfl
          push_cast
          linarith
    refine ⟨⟨hta, le_rfl⟩, fun j hj => ?_⟩
    have h1 := key n le_rfl j hj
    have hin : (j : ℝ) ≤ n := by exact_mod_cast hj
    have : (0 : ℝ) ≤ bp * ((n : ℝ) - j) := mul_nonneg hbp (by linarith)
    linarith
  have hne : (K n).Nonempty := ⟨a, ha_mem⟩
  have hbdd : BddBelow (K n) := ⟨t, fun x hx => hx.1.1⟩
  set s := sInf (K n) with hs
  have hs_mem : s ∈ K n := (hKclosed n).csInf_mem hne hbdd
  have hsdom : ∀ j ≤ n, ustar ≤ u j s := hKdom n s hs_mem
  obtain ⟨d1, d2⟩ := hdrop s n hsdom
  -- u n s = t
  have hus : u n s = t := by
    by_contra hne'
    have hgt : t < u n s := lt_of_le_of_ne (hs_mem.2 n le_rfl) (Ne.symm hne')
    have hnn : (0 : ℝ) ≤ bm * n := by positivity
    have hst : t < s := by linarith
    -- strictly greater than t at every step
    have hall : ∀ k ≤ n, t < u k s := by
      intro k hk
      have mono : ∀ i, k + i ≤ n → u (k + i) s ≤ u k s := by
        intro i
        induction i with
        | zero => intro _; simp
        | succ i ih =>
          intro hi
          have h1 := ih (by omega)
          have h2 := (hS (k + i) s (fun j hj => hsdom j (by omega))).1
          rw [← Nat.add_assoc]
          linarith
      have := mono (n - k) (by omega)
      rw [Nat.add_sub_cancel' hk] at this
      linarith
    -- still greater than t near s (induction on the number of steps)
    have hopen : ∀ k ≤ n, ∃ ε > 0, ∀ y, dist y s < ε → ∀ j ≤ k, t < u j y := by
      intro k
      induction k with
      | zero =>
        intro _
        refine ⟨s - t, by linarith, fun y hy j hj => ?_⟩
        have : j = 0 := by omega
        subst this
        rw [h0]
        rw [Real.dist_eq, abs_lt] at hy
        linarith
      | succ k ih =>
        intro hk
        obtain ⟨ε, hε, hεy⟩ := ih (by omega)
        have hcw : ContinuousWithinAt (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x} s :=
          hC k s (fun j hj => hsdom j (by omega))
        rw [Metric.continuousWithinAt_iff] at hcw
        obtain ⟨ε', hε', hε'y⟩ := hcw (u (k + 1) s - t) (by linarith [hall (k + 1) hk])
        refine ⟨min ε ε', lt_min hε hε', fun y hy j hj => ?_⟩
        have hy1 : dist y s < ε := lt_of_lt_of_le hy (min_le_left _ _)
        have hy2 : dist y s < ε' := lt_of_lt_of_le hy (min_le_right _ _)
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact hεy y hy1 j (by omega)
        · have : j = k + 1 := by omega
          subst this
          have hydom : ∀ i ≤ k, ustar ≤ u i y := fun i hi => le_trans ht (hεy y hy1 i hi).le
          have := hε'y hydom hy2
          rw [Real.dist_eq, abs_lt] at this
          linarith
    obtain ⟨ε, hε, hεy⟩ := hopen n le_rfl
    set y := s - min (ε / 2) ((s - t) / 2) with hy
    have hm : 0 < min (ε / 2) ((s - t) / 2) := lt_min (by linarith) (by linarith)
    have hm1 : min (ε / 2) ((s - t) / 2) ≤ ε / 2 := min_le_left _ _
    have hm2 : min (ε / 2) ((s - t) / 2) ≤ (s - t) / 2 := min_le_right _ _
    have hyd : dist y s < ε := by
      rw [Real.dist_eq, hy]
      rw [abs_lt]; constructor <;> linarith
    have hyK : y ∈ K n := by
      refine ⟨⟨by linarith, by linarith [hs_mem.1.2]⟩, fun j hj => (hεy y hyd j hj).le⟩
    have := csInf_le hbdd hyK
    linarith
  refine ⟨s, ?_, ?_, hus, fun k hk => hs_mem.2 k hk⟩
  · linarith
  · linarith

/-- (b) The original bare-coupling lemma (bracket `[b/2, 3b/2]`, statement unchanged) is the special
case `bm = b/2`, `bp = 3b/2` of the signed lemma. -/
theorem exists_bare_inverse_coupling_of_signed (u : ℕ → ℝ → ℝ) (b ustar t : ℝ) (n : ℕ)
    (hb : 0 < b) (h0 : ∀ x, u 0 x = x)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2)
    (hC : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (ht : ustar ≤ t) :
    ∃ x : ℝ, t + b / 2 * n ≤ x ∧ x ≤ t + 3 * b / 2 * n ∧ u n x = t ∧
      ∀ k ≤ n, t ≤ u k x :=
  exists_bare_inverse_coupling_signed u (b / 2) (3 * b / 2) ustar t n (by linarith) h0
    (fun k x hd => by
      obtain ⟨h1, h2⟩ := hS k x hd
      constructor <;> linarith) hC ht

end AsymptoticPremises


/-! # (c) The chain under the asymptotic premises -/

namespace AsymptoticChain

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## C1. Per-step hypotheses with a signed net bracket -/

/-- Per-step hypotheses with a signed net bracket. Compared with `ChainMoving.CouplingStepsMovingD`:
the two-sided bound `|r^sf_k| ≤ δ + C₂/u_k` is replaced by the signed bracket of the net small-field
decrease, `bm − C₂/u_k ≤ b − r^sf_k ≤ bp + C₂/u_k`; the initial bound `z_0 ≤ W(u_0)` is required only
on the domain; the margin is `C₂/u⋆ + Y ≤ bm`. -/
structure CouplingStepsSigned (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ)
    (b bm bp C₂ ρ A B Y ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hC : 0 ≤ C₂
  hD : ∀ s, ustar ≤ s → 0 ≤ Dfun s
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    bm - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ Dfun (u k x) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, ustar ≤ u 0 x → z 0 x ≤ W (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  W_anti : ∀ s t, ustar ≤ s → s ≤ t → W t ≤ W s
  fix_moving : ∀ s, ustar ≤ s → ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s
  DW : ∀ s, ustar ≤ s → Dfun s * W s ≤ Y
  margin : C₂ / ustar + Y ≤ bm

/-- One step (signed form): if `z_k ≤ W(u_k)`, the net decrease lies in `[bm − e, bp + e]`,
`e = C₂/u⋆ + Y`. -/
theorem step_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar) (k : ℕ) (x : ℝ)
    (hdom : ∀ j ≤ k, ustar ≤ u j x) (hz : z k x ≤ W (u k x)) :
    bm - (C₂ / ustar + Y) ≤ u k x - u (k + 1) x ∧
      u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y) := by
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hdiv : C₂ / u k x ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hl : |rl k x| ≤ Y :=
    le_trans (H.large_rem k x hdom)
      (le_trans (mul_le_mul_of_nonneg_left hz (H.hD _ hu)) (H.DW _ hu))
  have hs := H.small_net k x hdom
  have hl' := abs_le.mp hl
  have hf := H.flow k x hdom
  constructor <;> linarith [hs.1, hs.2, hl'.1, hl'.2]

/-- Within the domain the activity stays below the moving bound (joint induction with the steps). -/
theorem activity_le_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ W (u k x) := by
  intro k
  induction k with
  | zero => intro x hdom; exact H.act_init x (hdom 0 le_rfl)
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hst := step_signed H k x hdom' hz
    have hm := H.margin
    have hdown : u (k + 1) x ≤ u k x := by linarith [hst.1]
    have huk := hdom' k le_rfl
    have h1 : ρ * z k x ≤ ρ * W (u k x) := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ (u k x) := mul_le_mul_of_nonneg_left (H.supply k x hdom') H.hA
    have h3 : z k x ^ 2 ≤ W (u k x) ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * W (u k x) ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    have h5 := H.fix_moving (u k x) huk
    have h6 := H.W_anti (u (k + 1) x) (u k x) (hdom (k + 1) le_rfl) hdown
    linarith [H.act_rec k x hdom']

/-- The signed form of (H-β): on the domain, `bm − e ≤ u_k − u_{k+1} ≤ bp + e`, `e = C₂/u⋆ + Y`. -/
theorem hbeta_of_steps_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      bm - (C₂ / ustar + Y) ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y) :=
  fun k x hdom => step_signed H k x hdom (activity_le_signed H k x hdom)

/-- The per-step hypotheses of the moving chain are the special case `bm = b − δ`, `bp = b + δ`. -/
theorem signed_of_movingD {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    (H : ChainMoving.CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) :
    CouplingStepsSigned u z w rs rl Φ W Dfun b (b - δ) (b + δ) C₂ ρ A B Y ustar where
  ustar_pos := H.ustar_pos
  hC := H.hC
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_net := fun k x hdom => by
    have h := abs_le.mp (H.small_rem k x hdom)
    constructor <;> linarith [h.1, h.2]
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := fun x _ => H.act_init x
  supply := H.supply
  W_anti := H.W_anti
  fix_moving := H.fix_moving
  DW := H.DW
  margin := by
    have h1 := H.margin
    have h2 := H.hb
    linarith

/-- Through the signed form, the bracket `[b/2, 3b/2]` of the moving chain is recovered
(same statement as `ChainMoving.hbeta_of_steps_movingD`). -/
theorem hbeta_movingD_via_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    (H : ChainMoving.CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      u k x - 3 * b / 2 ≤ u (k + 1) x ∧ u (k + 1) x ≤ u k x - b / 2 := by
  intro k x hdom
  have h := hbeta_of_steps_signed (signed_of_movingD H) k x hdom
  have hm := H.margin
  constructor <;> linarith [h.1, h.2]

/-- Under the correspondence of `signed_of_movingD`, the margin `δ + e ≤ b/2` of the moving chain is the
ratio condition `bp + 4e ≤ 3bm` (`bm = b − δ`, `bp = b + δ`, `e = C₂/u⋆ + Y`). -/
theorem ratio_of_movingD {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b δ C₂ ρ A B Y ustar : ℝ}
    (H : ChainMoving.CouplingStepsMovingD u z w rs rl Φ W Dfun b δ C₂ ρ A B Y ustar) :
    (b + δ) + 4 * (C₂ / ustar + Y) ≤ 3 * (b - δ) := by
  have h := H.margin
  linarith

/-- Conversely, signed hypotheses with `bp + 4e ≤ 3bm` (`e = C₂/u⋆ + Y`), `0 < bm ≤ bp`, and the initial
bound for every x give the hypotheses of the moving chain, recentred at `b′ = (bm + bp)/2`,
`δ′ = (bp − bm)/2`, `r^sf′ = r^sf + b′ − b`. So the moving chain is the signed chain under the ratio
condition `bp + 4e ≤ 3bm`; a bracket with `bp ≥ 3bm` is outside it whatever b is. -/
theorem movingD_of_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar)
    (hbm : 0 < bm) (hbmp : bm ≤ bp) (hratio : bp + 4 * (C₂ / ustar + Y) ≤ 3 * bm)
    (hinit : ∀ x, z 0 x ≤ W (u 0 x)) :
    ChainMoving.CouplingStepsMovingD u z w (fun k x => rs k x + ((bm + bp) / 2 - b)) rl Φ W Dfun
      ((bm + bp) / 2) ((bp - bm) / 2) C₂ ρ A B Y ustar where
  ustar_pos := H.ustar_pos
  hb := by linarith
  hC := H.hC
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := fun k x hd => by
    have h := H.flow k x hd
    show u (k + 1) x = u k x - (bm + bp) / 2 + (rs k x + ((bm + bp) / 2 - b)) + rl k x
    linarith
  small_rem := fun k x hd => by
    have h := H.small_net k x hd
    show |rs k x + ((bm + bp) / 2 - b)| ≤ (bp - bm) / 2 + C₂ / u k x
    rw [abs_le]
    constructor <;> linarith [h.1, h.2]
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := hinit
  supply := H.supply
  W_anti := H.W_anti
  fix_moving := H.fix_moving
  DW := H.DW
  margin := by linarith

-- The two statements have the same type (the signed route reproduces the moving chain's bracket).
example : @ChainMoving.hbeta_of_steps_movingD = @hbeta_movingD_via_signed := rfl

-- The statement of the original bare-coupling lemma is obtained from the signed one.
example : @WeakUltravioletExistence.exists_bare_inverse_coupling =
    @AsymptoticPremises.exists_bare_inverse_coupling_of_signed := rfl

/-! ## C2. The signed chain end to end -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

structure ChainHypothesesSigned (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ)
    (b bm bp C₂ ρ A B Y ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- The three conclusions of the signed chain. -/
theorem chain_to_hypotheses_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar ν R I θh ε
      Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      bm - (C₂ / ustar + Y) ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y)) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps_signed H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact SmallRemKernel.UltravioletChain.small_field_mass_invariant (ν n m) (R m) (I m) (θh m)
      (ε m) hn
  · exact SmallRemKernel.UltravioletChain.equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing
      H.shift_vanishing H.split

end Chain

section EndToEnd

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Chain end to end with the signed bracket: the conclusion is that of
`ChainMoving.chain_end_to_end_moving`, with the bracket of (W0) replaced by
`t + (bm − e)n ≤ x ≤ t + (bp + e)n`, `e = C₂/u⋆ + Y`. -/
theorem chain_end_to_end_signed
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {b bm bp C₂ ρ A B Y ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (bm - (C₂ / ustar + Y)) * n ≤ x ∧
      x ≤ t + (bp + (C₂ / ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  obtain ⟨hβ, hsf, hreg⟩ := chain_to_hypotheses_signed H
  have hm : 0 ≤ bm - (C₂ / ustar + Y) := by linarith [H.steps.margin]
  refine ⟨fun t ht n => AsymptoticPremises.exists_bare_inverse_coupling_signed u
    (bm - (C₂ / ustar + Y)) (bp + (C₂ / ustar + Y)) ustar t n hm h0 hβ hCu ht, ?_⟩
  have HB : WeakUltravioletExistence.BlockHypotheses νP Bm hB Θ Aset actb Cset
      (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) :=
    { consistent := hcons, reflection_continuous := hΘc, reflection_positive := hΘp,
      symmetry_continuous := hsc, symmetric := hsym, small_field_closed := hCc,
      small_field_mass := fun m => (hsf m).mono fun n hn => by
        refine le_trans hn (measure_mono ?_)
        intro ω hω
        apply hgood m
        intro i hi
        exact (TwoStageSmallField.index_good_eq (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m)
          ω).mp (hω i hi) }
  have HO : WeakUltravioletExistence.ObservableHypotheses Dset s Bd act εb Pset :=
    { countable := hcount, dense := hdense, bounded := hbd, equicontinuous := hreg,
      act_continuous := hac, act_maps := ham, breaking := hbr, breaking_vanishes := hbv,
      positivity_on_lattice := hpos }
  exact WeakUltravioletExistence.weak_uv_skeleton νP Bm hB Θ Aset actb Cset _ Dset s Bd act εb Pset
    lev Fo HB HO HR

end EndToEnd

/-! ## C3. The asymptotic premises (A∞″) and the point u⋆ -/

noncomputable section

/-- `Φ₀ = K e^{−σ y₀}`. -/
def phi0 (K σ y₀ : ℝ) : ℝ := K * Real.exp (-(σ * y₀))

/-- u⋆ for the centred form (margin `b/2 − δ`). -/
def ustarCentred (b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) : ℝ :=
  AsymptoticPremises.ustarOf u₀ ρ A B D₁ (phi0 K σ y₀) C₂ (b / 2 - δ)

/-- u⋆ for the signed form (margin `bm/2`). -/
def ustarSigned (bm C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) : ℝ :=
  AsymptoticPremises.ustarOf u₀ ρ A B D₁ (phi0 K σ y₀) C₂ (bm / 2)

/-- The activity set to 0 at bare values below u₀ (only the domain enters the chain; this is used
to meet the field `act_init : ∀ x, …` of the moving chain, which is stated for every x). -/
def truncAct (u : ℕ → ℝ → ℝ) (u₀ : ℝ) (z : ℕ → ℝ → ℝ) (k : ℕ) (x : ℝ) : ℝ :=
  if u₀ ≤ u 0 x then z k x else 0

end

theorem phi0_nonneg {K : ℝ} (hK : 0 ≤ K) (σ y₀ : ℝ) : 0 ≤ phi0 K σ y₀ :=
  mul_nonneg hK (Real.exp_pos _).le

/-- (A∞″), centred form. Constants independent of u (and of the volume), and a base point u₀; the
per-step fields hold on the domain `{x | ∀ j ≤ k, u₀ ≤ u j x}`. The supply bound is that of the
threshold `y_s(u) = 2(log u)/σ + y₀`, the large-field coefficient is `D₁u`, the initial bound
`z_0 ≤ W(u_0)` is asked for `u_0 ≥ u₀`. `δ < b/2` is the one condition not paid by u⋆. -/
structure AsymptoticStepsCentred (u z w rs rl : ℕ → ℝ → ℝ) (b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) :
    Prop where
  hb : 0 < b
  hδ : δ < b / 2
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hρ1 : ρ < 1
  hA : 0 ≤ A
  hB : 0 ≤ B
  hK : 0 ≤ K
  hσ : 0 < σ
  flow : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → |rs k x| ≤ δ + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → |rl k x| ≤ D₁ * u k x * z k x
  act_rec : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, u₀ ≤ u 0 x → z 0 x ≤ AsymptoticPremises.movingBound ρ A (phi0 K σ y₀) (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    w k x ≤ K * Real.exp (-(σ * (2 * Real.log (u k x) / σ + y₀)))

/-- (A∞″), signed form: as the centred form, with the signed net bracket
`bm − C₂/u_k ≤ b − r^sf_k ≤ bp + C₂/u_k` in place of `|r^sf_k| ≤ δ + C₂/u_k`. `bm > 0` is the one
condition on the bracket not paid by u⋆ (no condition on `bp/bm`). -/
structure AsymptoticStepsSigned (u z w rs rl : ℕ → ℝ → ℝ) (b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) :
    Prop where
  hbm : 0 < bm
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hρ1 : ρ < 1
  hA : 0 ≤ A
  hB : 0 ≤ B
  hK : 0 ≤ K
  hσ : 0 < σ
  flow : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    bm - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → |rl k x| ≤ D₁ * u k x * z k x
  act_rec : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, u₀ ≤ u 0 x → z 0 x ≤ AsymptoticPremises.movingBound ρ A (phi0 K σ y₀) (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    w k x ≤ K * Real.exp (-(σ * (2 * Real.log (u k x) / σ + y₀)))

/-- (c), centred form: the asymptotic premises give the per-step hypotheses of the moving chain at
the explicit point `u⋆ = ustarCentred …`, with `Φ = Φ₀/s²`, `W = 2AΦ/(1−ρ)`, `D(s) = D₁s`,
`Y = Υ(u⋆)` (activity truncated below u₀). -/
theorem movingD_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ} {b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsCentred u z w rs rl b δ C₂ D₁ ρ A B K σ y₀ u₀) :
    ChainMoving.CouplingStepsMovingD u (truncAct u u₀ z) w rs rl
      (AsymptoticPremises.supplySq (phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (phi0 K σ y₀)) (fun s => D₁ * s) b δ C₂ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀))
      (ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀) := by
  have hΦ : 0 ≤ phi0 K σ y₀ := phi0_nonneg H.hK σ y₀
  have hm : 0 < b / 2 - δ := by linarith [H.hδ]
  obtain ⟨hW, hfix, hDW, hmar⟩ := AsymptoticPremises.moving_fields_sq_log u₀ ρ A B D₁
    (phi0 K σ y₀) C₂ (b / 2 - δ) H.hρ1 H.hA H.hD hΦ hm
  have hu0 : u₀ ≤ ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _
  have hus : 0 < ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.ustarOf_pos _ _ _ _ _ _ _ _
  have hdom : ∀ k x, (∀ j ≤ k, ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ j ≤ k, u₀ ≤ u j x :=
    fun k x hd j hj => le_trans hu0 (hd j hj)
  have htr : ∀ k x, (∀ j ≤ k, ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ i, truncAct u u₀ z i x = z i x := by
    intro k x hd i
    have h0x : u₀ ≤ u 0 x := hdom k x hd 0 (Nat.zero_le k)
    unfold truncAct
    exact if_pos h0x
  exact
    { ustar_pos := hus
      hb := H.hb
      hC := H.hC
      hD := fun s hs => mul_nonneg H.hD (le_trans hus.le hs)
      hρ := H.hρ
      hA := H.hA
      hB := H.hB
      flow := fun k x hd => H.flow k x (hdom k x hd)
      small_rem := fun k x hd => H.small_rem k x (hdom k x hd)
      large_rem := fun k x hd => by
        rw [htr k x hd k]
        exact H.large_rem k x (hdom k x hd)
      act_rec := fun k x hd => by
        rw [htr k x hd (k + 1), htr k x hd k]
        exact H.act_rec k x (hdom k x hd)
      act_nonneg := fun k x => by
        unfold truncAct
        split_ifs
        · exact H.act_nonneg k x
        · exact le_rfl
      act_init := fun x => by
        unfold truncAct
        split_ifs with h
        · exact H.act_init x h
        · exact AsymptoticPremises.movingBound_nonneg H.hρ1 H.hA hΦ _
      supply := fun k x hd => by
        have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
        have h := H.supply k x (hdom k x hd)
        rw [AsymptoticPremises.supply_sq_log_threshold K σ y₀ (u k x) H.hσ hpos] at h
        exact h
      W_anti := hW
      fix_moving := hfix
      DW := hDW
      margin := by
        unfold ustarCentred
        linarith [hmar] }

/-- (c), signed form: the asymptotic premises give the signed per-step hypotheses at the explicit
point `u⋆ = ustarSigned …`. -/
theorem signed_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ} {b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsSigned u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀) :
    CouplingStepsSigned u z w rs rl
      (AsymptoticPremises.supplySq (phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (phi0 K σ y₀)) (fun s => D₁ * s) b bm bp C₂ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀))
      (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀) := by
  have hΦ : 0 ≤ phi0 K σ y₀ := phi0_nonneg H.hK σ y₀
  have hm : 0 < bm / 2 := by linarith [H.hbm]
  obtain ⟨hW, hfix, hDW, hmar⟩ := AsymptoticPremises.moving_fields_sq_log u₀ ρ A B D₁
    (phi0 K σ y₀) C₂ (bm / 2) H.hρ1 H.hA H.hD hΦ hm
  have hu0 : u₀ ≤ ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _
  have hus : 0 < ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.ustarOf_pos _ _ _ _ _ _ _ _
  have hdom : ∀ k x, (∀ j ≤ k, ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ j ≤ k, u₀ ≤ u j x :=
    fun k x hd j hj => le_trans hu0 (hd j hj)
  exact
    { ustar_pos := hus
      hC := H.hC
      hD := fun s hs => mul_nonneg H.hD (le_trans hus.le hs)
      hρ := H.hρ
      hA := H.hA
      hB := H.hB
      flow := fun k x hd => H.flow k x (hdom k x hd)
      small_net := fun k x hd => H.small_net k x (hdom k x hd)
      large_rem := fun k x hd => H.large_rem k x (hdom k x hd)
      act_rec := fun k x hd => H.act_rec k x (hdom k x hd)
      act_nonneg := H.act_nonneg
      act_init := fun x hx => H.act_init x (le_trans hu0 hx)
      supply := fun k x hd => by
        have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
        have h := H.supply k x (hdom k x hd)
        rw [AsymptoticPremises.supply_sq_log_threshold K σ y₀ (u k x) H.hσ hpos] at h
        exact h
      W_anti := hW
      fix_moving := hfix
      DW := hDW
      margin := by
        have hbm := H.hbm
        unfold ustarSigned
        linarith [hmar] }

/-- (A∞″), signed form with the coefficient `D₁u·y_s(u)`, `y_s(u) = 2(log u)/σ + y₀`, `y₀ ≥ 0`
(the other form of (S3)). -/
structure AsymptoticStepsSignedGrowing (u z w rs rl : ℕ → ℝ → ℝ)
    (b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) : Prop where
  hbm : 0 < bm
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hρ1 : ρ < 1
  hA : 0 ≤ A
  hB : 0 ≤ B
  hK : 0 ≤ K
  hσ : 0 < σ
  hy : 0 ≤ y₀
  flow : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    bm - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  large_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    |rl k x| ≤ D₁ * u k x * (2 * Real.log (u k x) / σ + y₀) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, u₀ ≤ u 0 x → z 0 x ≤ AsymptoticPremises.movingBound ρ A (phi0 K σ y₀) (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    w k x ≤ K * Real.exp (-(σ * (2 * Real.log (u k x) / σ + y₀)))

noncomputable section

/-- u⋆ for the signed form with the coefficient `D₁u·y_s(u)` (margin `bm/2`). -/
def ustarSignedGrowing (bm C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) : ℝ :=
  AsymptoticPremises.ustarGrowingOf u₀ ρ A B D₁ (phi0 K σ y₀) C₂ σ y₀ (bm / 2)

end

/-- (c), signed form with the coefficient `D₁u·y_s(u)`: the signed per-step hypotheses hold at the
explicit point `u⋆ = ustarSignedGrowing …`, with `Y = Υ′(u⋆) = Υ₀(4/σ + y₀)/√u⋆`; this feeds
`chain_end_to_end_signed` (through `ChainHypothesesSigned`) in the same way as `signed_of_asymptotic`. -/
theorem signed_of_asymptotic_growing {u z w rs rl : ℕ → ℝ → ℝ}
    {b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsSignedGrowing u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀) :
    CouplingStepsSigned u z w rs rl
      (AsymptoticPremises.supplySq (phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (phi0 K σ y₀))
      (fun s => D₁ * s * (2 * Real.log s / σ + y₀)) b bm bp C₂ ρ A B
      (AsymptoticPremises.upsilonGrowing ρ A D₁ (phi0 K σ y₀) σ y₀
        (ustarSignedGrowing bm C₂ D₁ ρ A B K σ y₀ u₀))
      (ustarSignedGrowing bm C₂ D₁ ρ A B K σ y₀ u₀) := by
  have hΦ : 0 ≤ phi0 K σ y₀ := phi0_nonneg H.hK σ y₀
  have hm : 0 < bm / 2 := by linarith [H.hbm]
  obtain ⟨hu0, hu1, hDn, hW, hfix, hDW, hmar⟩ := AsymptoticPremises.moving_fields_growing u₀ ρ A B D₁
    (phi0 K σ y₀) C₂ σ y₀ (bm / 2) H.hρ1 H.hA H.hD hΦ H.hC H.hσ H.hy hm
  have hus : 0 < ustarSignedGrowing bm C₂ D₁ ρ A B K σ y₀ u₀ :=
    lt_of_lt_of_le one_pos hu1
  have hdom : ∀ k x, (∀ j ≤ k, ustarSignedGrowing bm C₂ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ j ≤ k, u₀ ≤ u j x :=
    fun k x hd j hj => le_trans hu0 (hd j hj)
  exact
    { ustar_pos := hus
      hC := H.hC
      hD := hDn
      hρ := H.hρ
      hA := H.hA
      hB := H.hB
      flow := fun k x hd => H.flow k x (hdom k x hd)
      small_net := fun k x hd => H.small_net k x (hdom k x hd)
      large_rem := fun k x hd => H.large_rem k x (hdom k x hd)
      act_rec := fun k x hd => H.act_rec k x (hdom k x hd)
      act_nonneg := H.act_nonneg
      act_init := fun x hx => H.act_init x (le_trans hu0 hx)
      supply := fun k x hd => by
        have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
        have h := H.supply k x (hdom k x hd)
        rw [AsymptoticPremises.supply_sq_log_threshold K σ y₀ (u k x) H.hσ hpos] at h
        exact h
      W_anti := hW
      fix_moving := hfix
      DW := hDW
      margin := by
        have hbm := H.hbm
        unfold ustarSignedGrowing
        linarith [hmar] }

/-- The margin at the signed u⋆: `C₂/u⋆ + Υ(u⋆) ≤ bm/2`, so the bracket of (W0) below lies in
`[bm/2, bp + bm/2]`. -/
theorem margin_ustarSigned {bm C₂ D₁ ρ A B K σ y₀ u₀ : ℝ} (hbm : 0 < bm) (hρ1 : ρ < 1) :
    C₂ / ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ +
      AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀) ≤
      bm / 2 := by
  obtain ⟨-, -, -, hii⟩ := AsymptoticPremises.ustar_of_sq_log_threshold u₀ ρ A B D₁
    (phi0 K σ y₀) C₂ (bm / 2) hρ1 (by linarith)
  exact hii _ le_rfl

section ChainAsymptotic

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- The chain hypotheses with the per-step fields in the asymptotic form (A∞″), centred. -/
structure ChainHypothesesAsymptotic (u z w rs rl : ℕ → ℝ → ℝ) (b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : AsymptoticStepsCentred u z w rs rl b δ C₂ D₁ ρ A B K σ y₀ u₀
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- The chain hypotheses with the per-step fields in the asymptotic form (A∞″), signed. -/
structure ChainHypothesesAsymptoticSigned (u z w rs rl : ℕ → ℝ → ℝ)
    (b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : AsymptoticStepsSigned u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- (c), centred: the hypotheses of `ChainMoving.chain_end_to_end_moving` hold at u⋆. -/
theorem chainHypothesesMoving_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ}
    {b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptotic u z w rs rl b δ C₂ D₁ ρ A B K σ y₀ u₀ ν R I θh ε
      Dset s τ Ωr) :
    ChainMoving.ChainHypothesesMoving u (truncAct u u₀ z) w rs rl
      (AsymptoticPremises.supplySq (phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (phi0 K σ y₀)) (fun s => D₁ * s) b δ C₂ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀))
      (ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀) ν R I θh ε Dset s τ Ωr where
  steps := movingD_of_asymptotic H.steps
  prob := H.prob
  rarity := H.rarity
  lattice_vanishing := H.lattice_vanishing
  shift_vanishing := H.shift_vanishing
  split := H.split

/-- (c), signed: the hypotheses of `chain_end_to_end_signed` hold at u⋆. -/
theorem chainHypothesesSigned_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ}
    {b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptoticSigned u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀ ν R I θh ε
      Dset s τ Ωr) :
    ChainHypothesesSigned u z w rs rl
      (AsymptoticPremises.supplySq (phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (phi0 K σ y₀)) (fun s => D₁ * s) b bm bp C₂ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀))
      (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀) ν R I θh ε Dset s τ Ωr where
  steps := signed_of_asymptotic H.steps
  prob := H.prob
  rarity := H.rarity
  lattice_vanishing := H.lattice_vanishing
  shift_vanishing := H.shift_vanishing
  split := H.split

end ChainAsymptotic

section EndToEndAsymptotic

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- (c) Chain end to end under (A∞″), centred form, through `ChainMoving.chain_end_to_end_moving`
unchanged: with the explicit `u⋆ = ustarCentred …` (constants only), (W0) holds for every target
`t ≥ u⋆` with the bracket `[t + bn/2, t + 3bn/2]`, and the rest of the conclusions as in the moving
chain. Continuity is asked on the domain at u₀. -/
theorem chain_end_to_end_asymptotic
    {u z w rs rl : ℕ → ℝ → ℝ} {b δ C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptotic u z w rs rl b δ C₂ D₁ ρ A B K σ y₀ u₀
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, u₀ ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ,
      t + b / 2 * n ≤ x ∧ x ≤ t + 3 * b / 2 * n ∧ u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  have hu0 : u₀ ≤ ustarCentred b δ C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _
  exact ChainMoving.chain_end_to_end_moving νP R plaq pts Yf f yh θ P₁ S np npt
    (chainHypothesesMoving_of_asymptotic H) h0
    (fun k => (hCu k).mono (fun x hx j hj => le_trans hu0 (hx j hj)))
    Bm hB Θ Aset actb Cset hcons hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd
    hac ham hbr hbv hpos lev Fo HR

/-- (c) Chain end to end under (A∞″), signed form: with the explicit `u⋆ = ustarSigned …`
(constants only), (W0) holds for every target `t ≥ u⋆` with the bracket
`[t + (bm − e)n, t + (bp + e)n]`, `e = C₂/u⋆ + Υ(u⋆) ≤ bm/2` (`margin_ustarSigned`), and the rest of
the conclusions as in the moving chain. No condition on the ratio `bp/bm`. -/
theorem chain_end_to_end_asymptotic_signed
    {u z w rs rl : ℕ → ℝ → ℝ} {b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptoticSigned u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, u₀ ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ,
      t + (bm - (C₂ / ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ +
        AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀))) * n
        ≤ x ∧
      x ≤ t + (bp + (C₂ / ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ +
        AsymptoticPremises.upsilon ρ A D₁ (phi0 K σ y₀) (ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀))) * n ∧
      u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  have hu0 : u₀ ≤ ustarSigned bm C₂ D₁ ρ A B K σ y₀ u₀ :=
    AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _
  exact chain_end_to_end_signed νP R plaq pts Yf f yh θ P₁ S np npt
    (chainHypothesesSigned_of_asymptotic H) h0
    (fun k => (hCu k).mono (fun x hx j hj => le_trans hu0 (hx j hj)))
    Bm hB Θ Aset actb Cset hcons hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd
    hac ham hbr hbv hpos lev Fo HR

end EndToEndAsymptotic

/-! ## Non-vacuity: a toy model (u_k(x) = x − k, no large-field activity) satisfies the premises -/

example : AsymptoticStepsSigned (fun k x => x - k) (fun _ _ => 0) (fun _ _ => 0) (fun _ _ => 0)
    (fun _ _ => 0) 1 1 2 0 0 0 0 0 1 1 0 1 where
  hbm := one_pos
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hρ1 := zero_lt_one
  hA := le_rfl
  hB := le_rfl
  hK := zero_le_one
  hσ := one_pos
  flow := fun k x _ => by
    show x - ((k + 1 : ℕ) : ℝ) = x - (k : ℝ) - 1 + 0 + 0
    push_cast; ring
  small_net := fun k x _ => by norm_num
  large_rem := fun k x _ => by simp
  act_rec := fun k x _ => by simp
  act_nonneg := fun _ _ => le_rfl
  act_init := fun x _ => by simp [AsymptoticPremises.movingBound]
  supply := fun k x _ => by
    simp only [one_mul]
    exact (Real.exp_pos _).le

example : AsymptoticStepsCentred (fun k x => x - k) (fun _ _ => 0) (fun _ _ => 0) (fun _ _ => 0)
    (fun _ _ => 0) 1 0 0 0 0 0 0 1 1 0 1 where
  hb := one_pos
  hδ := by norm_num
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hρ1 := zero_lt_one
  hA := le_rfl
  hB := le_rfl
  hK := zero_le_one
  hσ := one_pos
  flow := fun k x _ => by
    show x - ((k + 1 : ℕ) : ℝ) = x - (k : ℝ) - 1 + 0 + 0
    push_cast; ring
  small_rem := fun k x _ => by simp
  large_rem := fun k x _ => by simp
  act_rec := fun k x _ => by simp
  act_nonneg := fun _ _ => le_rfl
  act_init := fun x _ => by simp [AsymptoticPremises.movingBound]
  supply := fun k x _ => by
    simp only [one_mul]
    exact (Real.exp_pos _).le

end AsymptoticChain


/-! # Transient bracket: elementary lemmas (namespace TransientPremises) -/

namespace TransientPremises

open Set

/-! ## T1. Sums of the transient -/

/-- If the negative parts of `δ` have partial sums at most `D₀`, every interval sum of `δ` is at
least `−D₀`. -/
theorem interval_sum_ge (δ : ℕ → ℝ) (D₀ : ℝ)
    (hδ : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀) :
    ∀ j k, j ≤ k → -D₀ ≤ ∑ i ∈ Finset.Ico j k, δ i := by
  intro j k _
  have h1 : ∑ i ∈ Finset.Ico j k, -max (-δ i) 0 ≤ ∑ i ∈ Finset.Ico j k, δ i :=
    Finset.sum_le_sum fun i _ => by linarith [le_max_left (-δ i) 0]
  have h2 : ∑ i ∈ Finset.Ico j k, max (-δ i) 0 ≤ ∑ i ∈ Finset.range k, max (-δ i) 0 := by
    apply Finset.sum_le_sum_of_subset_of_nonneg
    · intro i hi
      rw [Finset.mem_Ico] at hi
      exact Finset.mem_range.mpr hi.2
    · intro i _ _
      exact le_max_right _ _
  rw [Finset.sum_neg_distrib] at h1
  linarith [hδ k]

/-- Each negative part is at most `D₀`. -/
theorem neg_le_of_negPart_sum (δ : ℕ → ℝ) (D₀ : ℝ)
    (hδ : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀) (k : ℕ) : -δ k ≤ D₀ := by
  have hs : max (-δ k) 0 ≤ ∑ i ∈ Finset.range (k + 1), max (-δ i) 0 :=
    Finset.single_le_sum (f := fun i => max (-δ i) 0) (fun i _ => le_max_right _ _)
      (Finset.self_mem_range_succ k)
  linarith [le_max_left (-δ k) 0, hδ (k + 1)]

theorem nonneg_of_negPart_sum (δ : ℕ → ℝ) (D₀ : ℝ)
    (hδ : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀) : 0 ≤ D₀ := by
  have h := hδ 0
  rwa [Finset.range_zero, Finset.sum_empty] at h

/-- The absolute form `Σ_{k<n} |δ_k| ≤ D₀` implies the negative-part form. -/
theorem negPart_sum_of_abs_sum (δ : ℕ → ℝ) (D₀ : ℝ)
    (hδ : ∀ n, ∑ k ∈ Finset.range n, |δ k| ≤ D₀) :
    ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀ := fun n =>
  le_trans (Finset.sum_le_sum fun k _ => max_le (neg_le_abs (δ k)) (abs_nonneg _)) (hδ n)

/-! ## T2. The drop along a path and the cumulative deficit -/

/-- On the domain, the drop from step `j` to step `k` (`j ≤ k`) is at least
`a(k − j) + Σ_{j ≤ i < k} δ_i` and at most `bp(k − j)`. -/
theorem path_drop (u : ℕ → ℝ → ℝ) (δ : ℕ → ℝ) (a bp ustar : ℝ)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      a + δ k ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp) :
    ∀ x k, (∀ i ≤ k, ustar ≤ u i x) → ∀ j ≤ k,
      a * ((k : ℝ) - j) + ∑ i ∈ Finset.Ico j k, δ i ≤ u j x - u k x ∧
        u j x - u k x ≤ bp * ((k : ℝ) - j) := by
  intro x k
  induction k with
  | zero =>
    intro _ j hj
    obtain rfl : j = 0 := by omega
    simp
  | succ k ih =>
    intro hd j hj
    rcases Nat.lt_or_ge j (k + 1) with hlt | hge
    · have hd' : ∀ i ≤ k, ustar ≤ u i x := fun i hi => hd i (by omega)
      obtain ⟨i1, i2⟩ := ih hd' j (by omega)
      obtain ⟨s1, s2⟩ := hS k x hd'
      have e1 : a * (((k + 1 : ℕ) : ℝ) - j) = a * ((k : ℝ) - j) + a := by push_cast; ring
      have e2 : bp * (((k + 1 : ℕ) : ℝ) - j) = bp * ((k : ℝ) - j) + bp := by push_cast; ring
      rw [e1, e2, Finset.sum_Ico_succ_top (by omega : j ≤ k)]
      constructor <;> linarith
    · obtain rfl : j = k + 1 := by omega
      simp

/-- The cumulative deficit: with `a ≥ 0` and interval sums of `δ` at least `−D₀`, on the domain
`u_k − D₀ ≤ u_j` for `j ≤ k` (a path never rises more than `D₀` above an earlier value). -/
theorem cumulative_deficit (u : ℕ → ℝ → ℝ) (δ : ℕ → ℝ) (a bp D₀ ustar : ℝ) (ha : 0 ≤ a)
    (hδ : ∀ j k, j ≤ k → -D₀ ≤ ∑ i ∈ Finset.Ico j k, δ i)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      a + δ k ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp) :
    ∀ x k, (∀ i ≤ k, ustar ≤ u i x) → ∀ j ≤ k, u k x - D₀ ≤ u j x := by
  intro x k hd j hj
  obtain ⟨h1, -⟩ := path_drop u δ a bp ustar hS x k hd j hj
  have hjk : (j : ℝ) ≤ k := by exact_mod_cast hj
  have h2 : 0 ≤ a * ((k : ℝ) - j) := mul_nonneg ha (by linarith)
  linarith [hδ j k hj]

/-! ## T3. The bare-coupling lemma with a transient bracket -/

/-- The bare-coupling lemma (W0) with a transient bracket. On the domain
`{x | ∀ j ≤ k, u⋆ ≤ u j x}` assume `a + δ_k ≤ u_k − u_{k+1} ≤ bp` with `a ≥ 0` and every interval sum
of `δ` at least `−D₀`; no step needs to lower u. For a target `t ≥ u⋆ + D₀` and `n` steps there is a
bare value `x` with `u_n x = t`, `u_k x ≥ t − D₀` for `k ≤ n`, and `t + a·n − D₀ ≤ x ≤ t + bp·n`.
The cumulative deficit (`cumulative_deficit`) takes the place of the monotonicity of the steps. -/
theorem exists_bare_inverse_coupling_transient (u : ℕ → ℝ → ℝ) (δ : ℕ → ℝ)
    (a bp D₀ ustar t : ℝ) (n : ℕ) (ha : 0 ≤ a)
    (hδ : ∀ j k, j ≤ k → -D₀ ≤ ∑ i ∈ Finset.Ico j k, δ i)
    (h0 : ∀ x, u 0 x = x)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      a + δ k ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp)
    (hC : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (ht : ustar + D₀ ≤ t) :
    ∃ x : ℝ, t + a * n - D₀ ≤ x ∧ x ≤ t + bp * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x := by
  have hD0 : 0 ≤ D₀ := by
    have h := hδ 0 0 le_rfl
    rw [Finset.Ico_self, Finset.sum_empty] at h
    linarith
  have hLs : ustar ≤ t - D₀ := by linarith
  have hdrop := path_drop u δ a bp ustar hS
  have hdef := cumulative_deficit u δ a bp D₀ ustar ha hδ hS
  rcases Nat.eq_zero_or_pos n with hn | hn
  · subst hn
    refine ⟨t, by simp; linarith, by simp, h0 t, ?_⟩
    intro k hk
    obtain rfl : k = 0 := by omega
    rw [h0]; linarith
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  have hmax0 : 0 ≤ max bp 0 := le_max_right _ _
  have hmaxb : bp ≤ max bp 0 := le_max_left _ _
  -- the upper starting point
  set xh : ℝ := t + max bp 0 * ((m + 1 : ℕ) : ℝ) with hxh
  -- K' k: starting points in [t − D₀, xh] that stay ≥ t − D₀ up to step k
  let K' : ℕ → Set ℝ := fun k => {x | x ∈ Icc (t - D₀) xh ∧ ∀ j ≤ k, t - D₀ ≤ u j x}
  have hKdom : ∀ k x, x ∈ K' k → ∀ j ≤ k, ustar ≤ u j x :=
    fun k x hx j hj => le_trans hLs (hx.2 j hj)
  have hKclosed : ∀ k, IsClosed (K' k) := by
    intro k
    induction k with
    | zero =>
      have : K' 0 = Icc (t - D₀) xh := by
        ext x
        simp only [K', mem_ofPred_eq, mem_Icc]
        constructor
        · intro h; exact h.1
        · intro h
          refine ⟨h, fun j hj => ?_⟩
          obtain rfl : j = 0 := by omega
          rw [h0]; exact h.1
      rw [this]; exact isClosed_Icc
    | succ k ih =>
      have hco : ContinuousOn (u (k + 1)) (K' k) :=
        (hC k).mono (fun x hx => hKdom k x hx)
      have hset : K' (k + 1) = K' k ∩ u (k + 1) ⁻¹' Ici (t - D₀) := by
        ext x
        simp only [K', mem_ofPred_eq, mem_inter_iff, mem_preimage, mem_Ici]
        constructor
        · rintro ⟨h1, h2⟩
          exact ⟨⟨h1, fun j hj => h2 j (by omega)⟩, h2 (k + 1) le_rfl⟩
        · rintro ⟨⟨h1, h2⟩, h3⟩
          refine ⟨h1, fun j hj => ?_⟩
          rcases Nat.lt_or_ge j (k + 1) with hlt | hge
          · exact h2 j (by omega)
          · obtain rfl : j = k + 1 := by omega
            exact h3
      rw [hset]
      exact hco.preimage_isClosed_of_isClosed ih isClosed_Ici
  -- K: points of K' (m+1) reaching at least t at step m+1
  let K : Set ℝ := {x | x ∈ K' (m + 1) ∧ t ≤ u (m + 1) x}
  have hKc : IsClosed K := by
    have hco : ContinuousOn (u (m + 1)) (K' (m + 1)) :=
      (hC m).mono (fun x hx j hj => hKdom (m + 1) x hx j (by omega))
    have hK_eq : K = K' (m + 1) ∩ u (m + 1) ⁻¹' Ici t := by
      ext x
      simp only [K, mem_ofPred_eq, mem_inter_iff, mem_preimage, mem_Ici]
    rw [hK_eq]
    exact hco.preimage_isClosed_of_isClosed (hKclosed (m + 1)) isClosed_Ici
  -- xh lies in K
  have hxh_mem : xh ∈ K := by
    have key : ∀ k ≤ m + 1, ∀ j ≤ k, t + max bp 0 * (((m + 1 : ℕ) : ℝ) - j) ≤ u j xh := by
      intro k
      induction k with
      | zero =>
        intro _ j hj
        obtain rfl : j = 0 := by omega
        rw [h0, hxh]; simp
      | succ k ih =>
        intro hk j hj
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact ih (by omega) j (by omega)
        · obtain rfl : j = k + 1 := by omega
          have ih' := ih (by omega)
          have hd : ∀ i ≤ k, ustar ≤ u i xh := by
            intro i hi
            have h1 := ih' i hi
            have hin : (i : ℝ) ≤ ((m + 1 : ℕ) : ℝ) := by
              exact_mod_cast (show i ≤ m + 1 by omega)
            have : (0 : ℝ) ≤ max bp 0 * (((m + 1 : ℕ) : ℝ) - i) :=
              mul_nonneg hmax0 (by linarith)
            linarith
          have s2 := (hS k xh hd).2
          have hk' := ih' k le_rfl
          have e : max bp 0 * (((m + 1 : ℕ) : ℝ) - ((k + 1 : ℕ) : ℝ)) =
              max bp 0 * (((m + 1 : ℕ) : ℝ) - k) - max bp 0 := by push_cast; ring
          rw [e]
          linarith
    refine ⟨⟨⟨?_, le_rfl⟩, fun j hj => ?_⟩, ?_⟩
    · have : (0 : ℝ) ≤ max bp 0 * ((m + 1 : ℕ) : ℝ) := mul_nonneg hmax0 (by positivity)
      linarith
    · have h1 := key (m + 1) le_rfl j hj
      have hin : (j : ℝ) ≤ ((m + 1 : ℕ) : ℝ) := by exact_mod_cast hj
      have : (0 : ℝ) ≤ max bp 0 * (((m + 1 : ℕ) : ℝ) - j) := mul_nonneg hmax0 (by linarith)
      linarith
    · have h1 := key (m + 1) le_rfl (m + 1) le_rfl
      rw [sub_self, mul_zero, add_zero] at h1
      exact h1
  have hne : K.Nonempty := ⟨xh, hxh_mem⟩
  have hbdd : BddBelow K := ⟨t - D₀, fun x hx => hx.1.1.1⟩
  set s := sInf K with hs
  have hs_mem : s ∈ K := hKc.csInf_mem hne hbdd
  have hsdom : ∀ j ≤ m + 1, ustar ≤ u j s := hKdom (m + 1) s hs_mem.1
  -- u_{m+1}(s) = t
  have hus : u (m + 1) s = t := by
    by_contra hne'
    have hgt : t < u (m + 1) s := lt_of_le_of_ne hs_mem.2 (Ne.symm hne')
    -- every step stays strictly above t − D₀ (the cumulative deficit replaces monotonicity)
    have hall : ∀ k ≤ m + 1, t - D₀ < u k s := by
      intro k hk
      have := hdef s (m + 1) hsdom k hk
      linarith
    have hsL : t - D₀ < s := by
      have := hall 0 (Nat.zero_le _)
      rwa [h0] at this
    -- still above t − D₀ near s (induction on the number of steps)
    have hopen : ∀ k ≤ m + 1, ∃ ε > 0, ∀ y, dist y s < ε → ∀ j ≤ k, t - D₀ < u j y := by
      intro k
      induction k with
      | zero =>
        intro _
        refine ⟨s - (t - D₀), by linarith, fun y hy j hj => ?_⟩
        obtain rfl : j = 0 := by omega
        rw [h0]
        rw [Real.dist_eq, abs_lt] at hy
        linarith
      | succ k ih =>
        intro hk
        obtain ⟨ε, hε, hεy⟩ := ih (by omega)
        have hcw : ContinuousWithinAt (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x} s :=
          hC k s (fun j hj => hsdom j (by omega))
        rw [Metric.continuousWithinAt_iff] at hcw
        obtain ⟨ε', hε', hε'y⟩ := hcw (u (k + 1) s - (t - D₀)) (by linarith [hall (k + 1) hk])
        refine ⟨min ε ε', lt_min hε hε', fun y hy j hj => ?_⟩
        have hy1 : dist y s < ε := lt_of_lt_of_le hy (min_le_left _ _)
        have hy2 : dist y s < ε' := lt_of_lt_of_le hy (min_le_right _ _)
        rcases Nat.lt_or_ge j (k + 1) with hlt | hge
        · exact hεy y hy1 j (by omega)
        · obtain rfl : j = k + 1 := by omega
          have hydom : ∀ i ≤ k, ustar ≤ u i y := fun i hi => le_trans hLs (hεy y hy1 i hi).le
          have := hε'y hydom hy2
          rw [Real.dist_eq, abs_lt] at this
          linarith
    obtain ⟨ε, hε, hεy⟩ := hopen (m + 1) le_rfl
    -- and still above t at step m+1 near s
    have hcw : ContinuousWithinAt (u (m + 1)) {x | ∀ j ≤ m, ustar ≤ u j x} s :=
      hC m s (fun j hj => hsdom j (by omega))
    rw [Metric.continuousWithinAt_iff] at hcw
    obtain ⟨ε', hε', hε'y⟩ := hcw (u (m + 1) s - t) (by linarith)
    have hη : 0 < min ε ε' := lt_min hε hε'
    set r := min (min ε ε' / 2) ((s - (t - D₀)) / 2) with hr
    have hr0 : 0 < r := lt_min (by linarith) (by linarith)
    have hr1 : r ≤ min ε ε' / 2 := min_le_left _ _
    have hr2 : r ≤ (s - (t - D₀)) / 2 := min_le_right _ _
    have hyd : dist (s - r) s < min ε ε' := by
      rw [Real.dist_eq, abs_lt]; constructor <;> linarith
    have hyd1 : dist (s - r) s < ε := lt_of_lt_of_le hyd (min_le_left _ _)
    have hyd2 : dist (s - r) s < ε' := lt_of_lt_of_le hyd (min_le_right _ _)
    have hyL := hεy (s - r) hyd1
    have hydom : ∀ i ≤ m, ustar ≤ u i (s - r) :=
      fun i hi => le_trans hLs (hyL i (by omega)).le
    have hyt : t < u (m + 1) (s - r) := by
      have := hε'y hydom hyd2
      rw [Real.dist_eq, abs_lt] at this
      linarith [this.1]
    have hyK : s - r ∈ K :=
      ⟨⟨⟨by linarith, by linarith [hs_mem.1.1.2]⟩, fun j hj => (hyL j hj).le⟩, hyt.le⟩
    have := csInf_le hbdd hyK
    linarith
  obtain ⟨d1, d2⟩ := hdrop s (m + 1) hsdom 0 (Nat.zero_le _)
  simp only [h0, hus, Nat.cast_zero, sub_zero] at d1 d2
  have hsum := hδ 0 (m + 1) (Nat.zero_le _)
  refine ⟨s, by linarith, by linarith, hus, fun k hk => hs_mem.1.2 k hk⟩

/-- The signed bare-coupling lemma is the special case `δ ≡ 0`, `D₀ = 0` (statement unchanged). -/
theorem exists_bare_inverse_coupling_signed_of_transient (u : ℕ → ℝ → ℝ) (bm bp ustar t : ℝ)
    (n : ℕ) (hbm : 0 ≤ bm) (h0 : ∀ x, u 0 x = x)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      bm ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp)
    (hC : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (ht : ustar ≤ t) :
    ∃ x : ℝ, t + bm * n ≤ x ∧ x ≤ t + bp * n ∧ u n x = t ∧ ∀ k ≤ n, t ≤ u k x := by
  obtain ⟨x, h1, h2, h3, h4⟩ := exists_bare_inverse_coupling_transient u (fun _ => 0) bm bp 0
    ustar t n hbm (fun j k _ => by simp) h0
    (fun k x hd => by simp only [add_zero]; exact hS k x hd) hC (by linarith)
  exact ⟨x, by linarith, h2, h3, fun k hk => by linarith [h4 k hk]⟩

/-! ## T4. The invariant interval with a bounded one-step increase -/

/-- With `W(s) = 2AΦ₀/((1−ρ)s²)` and `Φ(s) = Φ₀/s²`: if `8ABΦ₀/(1−ρ)² ≤ s`, `12D₀/(1−ρ) ≤ s` and
`s ≥ 1`, then `ρW(s) + AΦ(s) + BW(s)² ≤ W(s')` for every `s' ∈ (0, s + D₀]` (no sign of B is used). The left side is
`W(s)((1+ρ)/2 + BW(s)) ≤ W(s)(3+ρ)/4`, and `W(s)/W(s') = (s'/s)² ≤ (1 + D₀/s)² ≤ 4/(3+ρ)`. -/
theorem fix_shift_sq (ρ A B Φ₀ D₀ s s' : ℝ) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1) (hA : 0 ≤ A)
    (hΦ : 0 ≤ Φ₀) (hD : 0 ≤ D₀) (hs1 : 1 ≤ s)
    (hq : 8 * A * B * Φ₀ / (1 - ρ) ^ 2 ≤ s) (hd : 12 * D₀ / (1 - ρ) ≤ s)
    (hs' : 0 < s') (hss : s' ≤ s + D₀) :
    ρ * AsymptoticPremises.movingBound ρ A Φ₀ s + A * AsymptoticPremises.supplySq Φ₀ s +
        B * AsymptoticPremises.movingBound ρ A Φ₀ s ^ 2 ≤
      AsymptoticPremises.movingBound ρ A Φ₀ s' := by
  have hc : 0 < 1 - ρ := by linarith
  have hs0 : 0 < s := by linarith
  have hV0 : 0 ≤ AsymptoticPremises.movingBound ρ A Φ₀ s :=
    AsymptoticPremises.movingBound_nonneg hρ1 hA hΦ s
  have hAS : A * AsymptoticPremises.supplySq Φ₀ s =
      (1 - ρ) * AsymptoticPremises.movingBound ρ A Φ₀ s / 2 := by
    unfold AsymptoticPremises.movingBound AsymptoticPremises.supplySq
    field_simp
  have hBV : B * AsymptoticPremises.movingBound ρ A Φ₀ s ≤ (1 - ρ) / 4 := by
    have h8 : 8 * A * B * Φ₀ ≤ (1 - ρ) ^ 2 * s ^ 2 := by
      have h := (div_le_iff₀ (pow_pos hc 2)).mp hq
      have hss2 : s ≤ s ^ 2 := by nlinarith
      nlinarith [sq_nonneg (1 - ρ)]
    have e : B * AsymptoticPremises.movingBound ρ A Φ₀ s =
        2 * (A * B * Φ₀) / ((1 - ρ) * s ^ 2) := by
      unfold AsymptoticPremises.movingBound AsymptoticPremises.supplySq
      field_simp
    rw [e, div_le_iff₀ (mul_pos hc (pow_pos hs0 2))]
    nlinarith
  have hLHS : ρ * AsymptoticPremises.movingBound ρ A Φ₀ s + A * AsymptoticPremises.supplySq Φ₀ s +
      B * AsymptoticPremises.movingBound ρ A Φ₀ s ^ 2 ≤
      AsymptoticPremises.movingBound ρ A Φ₀ s * ((3 + ρ) / 4) := by
    rw [hAS]
    have h : B * AsymptoticPremises.movingBound ρ A Φ₀ s ^ 2 ≤
        (1 - ρ) / 4 * AsymptoticPremises.movingBound ρ A Φ₀ s := by
      have := mul_le_mul_of_nonneg_right hBV hV0
      calc B * AsymptoticPremises.movingBound ρ A Φ₀ s ^ 2
          = B * AsymptoticPremises.movingBound ρ A Φ₀ s *
              AsymptoticPremises.movingBound ρ A Φ₀ s := by ring
        _ ≤ (1 - ρ) / 4 * AsymptoticPremises.movingBound ρ A Φ₀ s := this
    nlinarith
  have hW' : AsymptoticPremises.movingBound ρ A Φ₀ s' * s' ^ 2 =
      AsymptoticPremises.movingBound ρ A Φ₀ s * s ^ 2 := by
    unfold AsymptoticPremises.movingBound AsymptoticPremises.supplySq
    field_simp
  have hsq : (3 + ρ) * s' ^ 2 ≤ 4 * s ^ 2 := by
    have h1 : s' ^ 2 ≤ (s + D₀) ^ 2 := pow_le_pow_left₀ hs'.le hss 2
    have h2 : 12 * D₀ ≤ s * (1 - ρ) := (div_le_iff₀ hc).mp hd
    have hDs : D₀ ≤ s := by nlinarith [mul_nonneg hs0.le hρ0]
    have h3 : (s + D₀) ^ 2 ≤ s ^ 2 * ((5 - ρ) / 4) := by
      have hD2 : D₀ ^ 2 ≤ D₀ * s := by nlinarith [mul_le_mul_of_nonneg_left hDs hD]
      have hsD : 12 * (s * D₀) ≤ (1 - ρ) * s ^ 2 := by
        nlinarith [mul_le_mul_of_nonneg_left h2 hs0.le]
      nlinarith
    have h4 : (3 + ρ) * s' ^ 2 ≤ (3 + ρ) * (s + D₀) ^ 2 :=
      mul_le_mul_of_nonneg_left h1 (by linarith)
    have h5 : (3 + ρ) * (s + D₀) ^ 2 ≤ (3 + ρ) * (s ^ 2 * ((5 - ρ) / 4)) :=
      mul_le_mul_of_nonneg_left h3 (by linarith)
    have h6 : (3 + ρ) * (s ^ 2 * ((5 - ρ) / 4)) ≤ 4 * s ^ 2 := by
      nlinarith [mul_nonneg (sq_nonneg s) (sq_nonneg (1 - ρ))]
    linarith
  have hfin : AsymptoticPremises.movingBound ρ A Φ₀ s * ((3 + ρ) / 4) ≤
      AsymptoticPremises.movingBound ρ A Φ₀ s' := by
    have hs'2 : 0 < s' ^ 2 := pow_pos hs' 2
    have key : AsymptoticPremises.movingBound ρ A Φ₀ s * ((3 + ρ) / 4) * s' ^ 2 ≤
        AsymptoticPremises.movingBound ρ A Φ₀ s' * s' ^ 2 := by
      rw [hW']
      have := mul_le_mul_of_nonneg_left hsq hV0
      nlinarith
    exact le_of_mul_le_mul_right key hs'2
  linarith

noncomputable section

/-- The point u⋆ of the transient chain: `ustarOf` at the margin `m`, the term `8ABΦ₀/(1−ρ)²` (room in
the invariant interval for an increase), and `12D₀/(1−ρ)` (a step raises u by at most `D₀`). -/
def ustarTransientOf (u₀ ρ A B D₁ Φ₀ C₂ m D₀ : ℝ) : ℝ :=
  max (AsymptoticPremises.ustarOf u₀ ρ A B D₁ Φ₀ C₂ m)
    (max (8 * A * B * Φ₀ / (1 - ρ) ^ 2) (12 * D₀ / (1 - ρ)))

end

theorem ustarOf_le_ustarTransientOf (u₀ ρ A B D₁ Φ₀ C₂ m D₀ : ℝ) :
    AsymptoticPremises.ustarOf u₀ ρ A B D₁ Φ₀ C₂ m ≤
      ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ :=
  le_max_left _ _

theorem quad8_le_ustarTransientOf (u₀ ρ A B D₁ Φ₀ C₂ m D₀ : ℝ) :
    8 * A * B * Φ₀ / (1 - ρ) ^ 2 ≤ ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ :=
  le_trans (le_max_left _ _) (le_max_right _ _)

theorem incr_le_ustarTransientOf (u₀ ρ A B D₁ Φ₀ C₂ m D₀ : ℝ) :
    12 * D₀ / (1 - ρ) ≤ ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ :=
  le_trans (le_max_right _ _) (le_max_right _ _)

/-- The fields of the transient chain at `u⋆ = ustarTransientOf …` (constants only): `u⋆ ≥ u₀`,
`u⋆ ≥ 1`, the invariant interval from any `s ≥ u⋆` to any `s' ∈ [u⋆, s + D₀]`,
`D₁s·W(s) ≤ Υ(u⋆)`, and the margin `C₂/u⋆ + Υ(u⋆) ≤ m`. -/
theorem transient_fields_sq_log (u₀ ρ A B D₁ Φ₀ C₂ m D₀ : ℝ) (hρ0 : 0 ≤ ρ) (hρ1 : ρ < 1)
    (hA : 0 ≤ A) (hD : 0 ≤ D₁) (hΦ : 0 ≤ Φ₀) (hm : 0 < m) (hD0 : 0 ≤ D₀) :
    u₀ ≤ ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ ∧
    1 ≤ ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ ∧
    (∀ s s', ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ ≤ s →
      ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ ≤ s' → s' ≤ s + D₀ →
      ρ * AsymptoticPremises.movingBound ρ A Φ₀ s + A * AsymptoticPremises.supplySq Φ₀ s +
          B * AsymptoticPremises.movingBound ρ A Φ₀ s ^ 2 ≤
        AsymptoticPremises.movingBound ρ A Φ₀ s') ∧
    (∀ s, ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ ≤ s →
      D₁ * s * AsymptoticPremises.movingBound ρ A Φ₀ s ≤
        AsymptoticPremises.upsilon ρ A D₁ Φ₀ (ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀)) ∧
    C₂ / ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ +
        AsymptoticPremises.upsilon ρ A D₁ Φ₀ (ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀) ≤ m := by
  have hle := ustarOf_le_ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀
  obtain ⟨h0, h1, -, hii⟩ :=
    AsymptoticPremises.ustar_of_sq_log_threshold u₀ ρ A B D₁ Φ₀ C₂ m hρ1 hm
  have hu1 : 1 ≤ ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ := le_trans h1 hle
  have hus : 0 < ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀ := lt_of_lt_of_le one_pos hu1
  refine ⟨le_trans h0 hle, hu1, ?_, ?_, hii _ hle⟩
  · intro s s' hs hs' hss
    exact fix_shift_sq ρ A B Φ₀ D₀ s s' hρ0 hρ1 hA hΦ hD0 (le_trans hu1 hs)
      (le_trans (quad8_le_ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀) hs)
      (le_trans (incr_le_ustarTransientOf u₀ ρ A B D₁ Φ₀ C₂ m D₀) hs)
      (lt_of_lt_of_le hus hs') hss
  · intro s hs
    have hs0 : 0 < s := lt_of_lt_of_le hus hs
    rw [AsymptoticPremises.coefficient_times_bound ρ A D₁ Φ₀ s hρ1 hs0]
    exact AsymptoticPremises.upsilon_anti ρ A D₁ Φ₀ hρ1 hA hD hΦ hus hs

end TransientPremises

-- The signed bare-coupling lemma has the same statement as its special case of the transient one.
example : @AsymptoticPremises.exists_bare_inverse_coupling_signed =
    @TransientPremises.exists_bare_inverse_coupling_signed_of_transient := rfl


/-! # The error sum along a path grows logarithmically (namespace TransientPremises, continued) -/

namespace TransientPremises

/-! ## T5. A refined lower end of the (W0) bracket -/

/-- Along a path in the domain, with the per-step lower bounds `binf + δ_k − E/u_k ≤ u_k − u_{k+1}`,
the total drop is at least `binf·k + Σ_{i<k} δ_i − E·Σ_{i<k} 1/u_i`. -/
theorem path_drop_refined (u : ℕ → ℝ → ℝ) (δ : ℕ → ℝ) (binf E ustar : ℝ)
    (hR : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → binf + δ k - E / u k x ≤ u k x - u (k + 1) x) :
    ∀ x k, (∀ i ≤ k, ustar ≤ u i x) →
      binf * k + ∑ i ∈ Finset.range k, δ i - E * ∑ i ∈ Finset.range k, 1 / u i x ≤
        u 0 x - u k x := by
  intro x k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hd
    have hd' : ∀ i ≤ k, ustar ≤ u i x := fun i hi => hd i (by omega)
    have h1 := ih hd'
    have h2 := hR k x hd'
    have e : E / u k x = E * (1 / u k x) := by ring
    rw [e] at h2
    rw [Finset.sum_range_succ, Finset.sum_range_succ]
    push_cast
    simp only [mul_add, mul_one]
    linarith

/-- `Σ_{k<n} 1/(T + a(n − k)) ≤ log((T + an)/T)/a` for `T, a > 0` (a step-by-step comparison with
`∫ dy/(T + ay)`, from `log w ≤ w − 1`). -/
theorem sum_inv_reflect_le_log (T a : ℝ) (hT : 0 < T) (ha : 0 < a) :
    ∀ n : ℕ, ∑ k ∈ Finset.range n, 1 / (T + a * ((n : ℝ) - k)) ≤
      Real.log ((T + a * n) / T) / a := by
  intro n
  induction n with
  | zero => simp [hT.ne']
  | succ n ih =>
    rw [Finset.sum_range_succ']
    have hshift : ∑ k ∈ Finset.range n, 1 / (T + a * (((n + 1 : ℕ) : ℝ) - ((k + 1 : ℕ) : ℝ))) =
        ∑ k ∈ Finset.range n, 1 / (T + a * ((n : ℝ) - k)) := by
      apply Finset.sum_congr rfl
      intro k _
      rw [show (((n + 1 : ℕ) : ℝ) - ((k + 1 : ℕ) : ℝ)) = (n : ℝ) - k by push_cast; ring]
    rw [hshift, show (((n + 1 : ℕ) : ℝ) - ((0 : ℕ) : ℝ)) = (n : ℝ) + 1 by push_cast; ring,
      show ((n + 1 : ℕ) : ℝ) = (n : ℝ) + 1 by push_cast; ring]
    have hy0 : 0 < T + a * n := add_pos_of_pos_of_nonneg hT (mul_nonneg ha.le (Nat.cast_nonneg n))
    have hy : 0 < T + a * ((n : ℝ) + 1) :=
      add_pos_of_pos_of_nonneg hT (mul_nonneg ha.le (by positivity))
    have key : 1 / (T + a * ((n : ℝ) + 1)) ≤
        (Real.log (T + a * ((n : ℝ) + 1)) - Real.log (T + a * n)) / a := by
      have h := Real.log_le_sub_one_of_pos (div_pos hy0 hy)
      rw [Real.log_div hy0.ne' hy.ne'] at h
      have e : (T + a * n) / (T + a * ((n : ℝ) + 1)) - 1 = -(a / (T + a * ((n : ℝ) + 1))) := by
        field_simp
        ring
      rw [e] at h
      rw [le_div_iff₀ ha]
      have e2 : 1 / (T + a * ((n : ℝ) + 1)) * a = a / (T + a * ((n : ℝ) + 1)) := by ring
      rw [e2]
      linarith
    have hfinal : Real.log ((T + a * ((n : ℝ) + 1)) / T) / a =
        Real.log ((T + a * n) / T) / a +
          (Real.log (T + a * ((n : ℝ) + 1)) - Real.log (T + a * n)) / a := by
      rw [Real.log_div hy.ne' hT.ne', Real.log_div hy0.ne' hT.ne']
      ring
    rw [hfinal]
    linarith

/-- The refined lower end of the (W0) bracket. Along a path in the domain ending at `u_n x = t`,
with the coarse bracket `a + δ_k ≤ u_k − u_{k+1} ≤ bp` (`a > 0`, interval sums of `δ` at least
`−D₀`) and the refined lower bound `binf + δ_k − E/u_k ≤ u_k − u_{k+1}` (`E ≥ 0`), and with
`t − D₀ > 0`: `x ≥ t + binf·n − D₀ − (E/a)·log(1 + a·n/(t − D₀))`. The error sum `E·Σ 1/u_k` is only
logarithmic because `u_k ≥ t − D₀ + a(n − k)` grows linearly in `n − k`. -/
theorem bare_value_log_lower (u : ℕ → ℝ → ℝ) (δ : ℕ → ℝ) (a bp binf E D₀ ustar t x : ℝ)
    (n : ℕ) (ha : 0 < a) (hE : 0 ≤ E)
    (hδ : ∀ j k, j ≤ k → -D₀ ≤ ∑ i ∈ Finset.Ico j k, δ i)
    (hS : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      a + δ k ≤ u k x - u (k + 1) x ∧ u k x - u (k + 1) x ≤ bp)
    (hR : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → binf + δ k - E / u k x ≤ u k x - u (k + 1) x)
    (h0 : ∀ x, u 0 x = x) (hT : 0 < t - D₀)
    (hpath : ∀ k ≤ n, ustar ≤ u k x) (hend : u n x = t) :
    t + binf * n - D₀ - E / a * Real.log (1 + a * n / (t - D₀)) ≤ x := by
  have hTne : t - D₀ ≠ 0 := hT.ne'
  have hdrop := path_drop u δ a bp ustar hS x n hpath
  have href := path_drop_refined u δ binf E ustar hR x n hpath
  rw [h0, hend] at href
  -- the path grows linearly away from the end: u_k ≥ (t − D₀) + a(n − k)
  have hlow : ∀ k < n, (t - D₀) + a * ((n : ℝ) - k) ≤ u k x := by
    intro k hk
    obtain ⟨h1, -⟩ := hdrop k hk.le
    rw [hend] at h1
    have := hδ k n hk.le
    linarith
  have hsum : ∑ i ∈ Finset.range n, 1 / u i x ≤
      ∑ i ∈ Finset.range n, 1 / ((t - D₀) + a * ((n : ℝ) - i)) := by
    apply Finset.sum_le_sum
    intro i hi
    have hi' := Finset.mem_range.mp hi
    have hin : (i : ℝ) < n := by exact_mod_cast hi'
    have hpos : 0 < (t - D₀) + a * ((n : ℝ) - i) := by nlinarith
    exact one_div_le_one_div_of_le hpos (hlow i hi')
  have hlog := sum_inv_reflect_le_log (t - D₀) a hT ha n
  have hδsum : -D₀ ≤ ∑ i ∈ Finset.range n, δ i := by
    rw [Finset.range_eq_Ico]
    exact hδ 0 n (Nat.zero_le n)
  have hE' : E * ∑ i ∈ Finset.range n, 1 / u i x ≤ E / a * Real.log (1 + a * n / (t - D₀)) := by
    have h1 : ∑ i ∈ Finset.range n, 1 / u i x ≤ Real.log ((t - D₀ + a * n) / (t - D₀)) / a :=
      le_trans hsum hlog
    have e : (t - D₀ + a * n) / (t - D₀) = 1 + a * n / (t - D₀) := by
      field_simp
    rw [e] at h1
    calc E * ∑ i ∈ Finset.range n, 1 / u i x ≤ E * (Real.log (1 + a * n / (t - D₀)) / a) :=
          mul_le_mul_of_nonneg_left h1 hE
      _ = E / a * Real.log (1 + a * n / (t - D₀)) := by ring
  linarith

end TransientPremises


/-! # The chain with a transient bracket (namespace TransientChain) -/

namespace TransientChain

open Filter Topology MeasureTheory Set
open scoped ENNReal

set_option linter.unusedSectionVars false

/-! ## D1. Per-step hypotheses with a transient bracket -/

/-- Per-step hypotheses with a transient bracket. Compared with
`AsymptoticChain.CouplingStepsSigned`: the lower end of the net bracket is `binf + δ_k − C₂/u_k`,
with a step-dependent transient `δ_k` whose negative parts have partial sums at most `D₀`
(`transient`); the pair `W_anti`, `fix_moving` is replaced by `fix_shift` (the invariant interval
holds from `s` to every `s' ≤ s + D₀`); the margin is `C₂/u⋆ + Y ≤ binf`. No step is required to
lower u. -/
structure CouplingStepsTransient (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ) (δ : ℕ → ℝ)
    (b binf bp C₂ D₀ ρ A B Y ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  hC : 0 ≤ C₂
  hD : ∀ s, ustar ≤ s → 0 ≤ Dfun s
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    binf + δ k - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  transient : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ Dfun (u k x) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, ustar ≤ u 0 x → z 0 x ≤ W (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  fix_shift : ∀ s s', ustar ≤ s → ustar ≤ s' → s' ≤ s + D₀ →
    ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s'
  DW : ∀ s, ustar ≤ s → Dfun s * W s ≤ Y
  margin : C₂ / ustar + Y ≤ binf

/-- One step: if `z_k ≤ W(u_k)`, then `binf − e + δ_k ≤ u_k − u_{k+1} ≤ bp + e`, `e = C₂/u⋆ + Y`. -/
theorem step_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    (H : CouplingStepsTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar)
    (k : ℕ) (x : ℝ) (hdom : ∀ j ≤ k, ustar ≤ u j x) (hz : z k x ≤ W (u k x)) :
    binf - (C₂ / ustar + Y) + δ k ≤ u k x - u (k + 1) x ∧
      u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y) := by
  have hu : ustar ≤ u k x := hdom k le_rfl
  have hdiv : C₂ / u k x ≤ C₂ / ustar := div_le_div_of_nonneg_left H.hC H.ustar_pos hu
  have hl : |rl k x| ≤ Y :=
    le_trans (H.large_rem k x hdom)
      (le_trans (mul_le_mul_of_nonneg_left hz (H.hD _ hu)) (H.DW _ hu))
  have hs := H.small_net k x hdom
  have hl' := abs_le.mp hl
  have hf := H.flow k x hdom
  constructor <;> linarith [hs.1, hs.2, hl'.1, hl'.2]

/-- Within the domain the activity stays below the moving bound. A step may raise u, but by at
most `D₀` (the margin gives `u_k − u_{k+1} ≥ δ_k ≥ −D₀`), and `fix_shift` absorbs the rise. -/
theorem activity_le_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    (H : CouplingStepsTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → z k x ≤ W (u k x) := by
  intro k
  induction k with
  | zero => intro x hdom; exact H.act_init x (hdom 0 le_rfl)
  | succ k ih =>
    intro x hdom
    have hdom' : ∀ j ≤ k, ustar ≤ u j x := fun j hj => hdom j (by omega)
    have hz := ih x hdom'
    have hst := step_transient H k x hdom' hz
    have hm := H.margin
    have hneg := TransientPremises.neg_le_of_negPart_sum δ D₀ H.transient k
    have hup : u (k + 1) x ≤ u k x + D₀ := by linarith [hst.1]
    have huk := hdom' k le_rfl
    have h1 : ρ * z k x ≤ ρ * W (u k x) := mul_le_mul_of_nonneg_left hz H.hρ
    have h2 : A * w k x ≤ A * Φ (u k x) := mul_le_mul_of_nonneg_left (H.supply k x hdom') H.hA
    have h3 : z k x ^ 2 ≤ W (u k x) ^ 2 := pow_le_pow_left₀ (H.act_nonneg k x) hz 2
    have h4 : B * z k x ^ 2 ≤ B * W (u k x) ^ 2 := mul_le_mul_of_nonneg_left h3 H.hB
    have h5 := H.fix_shift (u k x) (u (k + 1) x) huk (hdom (k + 1) le_rfl) hup
    linarith [H.act_rec k x hdom']

/-- The transient form of (H-β): on the domain, `binf − e + δ_k ≤ u_k − u_{k+1} ≤ bp + e`. -/
theorem hbeta_of_steps_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    (H : CouplingStepsTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      binf - (C₂ / ustar + Y) + δ k ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y) :=
  fun k x hdom => step_transient H k x hdom (activity_le_transient H k x hdom)

/-- The signed per-step hypotheses are the special case `δ ≡ 0`, `D₀ = 0`, `binf = bm`
(`fix_shift` at `D₀ = 0` is `fix_moving` followed by `W_anti`). -/
theorem transient_of_signed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : AsymptoticChain.CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar) :
    CouplingStepsTransient u z w rs rl Φ W Dfun (fun _ => 0) b bm bp C₂ 0 ρ A B Y ustar where
  ustar_pos := H.ustar_pos
  hC := H.hC
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_net := fun k x hd => by
    simp only [add_zero]
    exact H.small_net k x hd
  transient := fun n => by simp
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply
  fix_shift := fun s s' hs hs' hss => by
    have h1 := H.fix_moving s hs
    have h2 := H.W_anti s' s hs' (by linarith)
    linarith
  DW := H.DW
  margin := H.margin

/-- Through the transient form, the signed (H-β) is recovered (same statement as
`AsymptoticChain.hbeta_of_steps_signed`). -/
theorem hbeta_signed_via_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ}
    {b bm bp C₂ ρ A B Y ustar : ℝ}
    (H : AsymptoticChain.CouplingStepsSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      bm - (C₂ / ustar + Y) ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y) := by
  intro k x hdom
  have h := hbeta_of_steps_transient (transient_of_signed H) k x hdom
  simp only [add_zero] at h
  exact h

example : @AsymptoticChain.hbeta_of_steps_signed = @hbeta_signed_via_transient := rfl

/-! ## D2. The transient chain end to end -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

structure ChainHypothesesTransient (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ) (δ : ℕ → ℝ)
    (b binf bp C₂ D₀ ρ A B Y ustar : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : CouplingStepsTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- The three conclusions of the transient chain. -/
theorem chain_to_hypotheses_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar ν R I θh ε
      Dset s τ Ωr) :
    (∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      binf - (C₂ / ustar + Y) + δ k ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustar + Y)) ∧
    (∀ m, ∀ᶠ n in atTop,
      1 - (R m).card * ε m ≤ ν n m {ω | ∀ i ∈ R m, I m i ω ≤ θh m}) ∧
    (∀ η > 0, ∃ δ > 0, ∀ d ∈ Dset, ∀ d' ∈ Dset, dist d d' < δ →
      ∀ᶠ n in atTop, |s n d - s n d'| ≤ η) := by
  refine ⟨hbeta_of_steps_transient H.steps, ?_, ?_⟩
  · intro m
    refine (H.rarity m).mono fun n hn => ?_
    have := H.prob n m
    exact SmallRemKernel.UltravioletChain.small_field_mass_invariant (ν n m) (R m) (I m) (θh m)
      (ε m) hn
  · exact SmallRemKernel.UltravioletChain.equicontinuous_of_split Dset s τ Ωr H.lattice_vanishing
      H.shift_vanishing H.split

end Chain

section EndToEnd

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Chain end to end with a transient bracket: the conclusion is that of
`AsymptoticChain.chain_end_to_end_signed`, with (W0) for every target `t ≥ u⋆ + D₀`, the bracket
`t + (binf − e)n − D₀ ≤ x ≤ t + (bp + e)n` (`e = C₂/u⋆ + Y`), and the path staying `≥ t − D₀`. -/
theorem chain_end_to_end_transient
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (C₂ / ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (C₂ / ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  obtain ⟨hβ, hsf, hreg⟩ := chain_to_hypotheses_transient H
  have ha : 0 ≤ binf - (C₂ / ustar + Y) := by linarith [H.steps.margin]
  refine ⟨fun t ht n => TransientPremises.exists_bare_inverse_coupling_transient u δ
    (binf - (C₂ / ustar + Y)) (bp + (C₂ / ustar + Y)) D₀ ustar t n ha
    (TransientPremises.interval_sum_ge δ D₀ H.steps.transient) h0 hβ hCu ht, ?_⟩
  have HB : WeakUltravioletExistence.BlockHypotheses νP Bm hB Θ Aset actb Cset
      (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) :=
    { consistent := hcons, reflection_continuous := hΘc, reflection_positive := hΘp,
      symmetry_continuous := hsc, symmetric := hsym, small_field_closed := hCc,
      small_field_mass := fun m => (hsf m).mono fun n hn => by
        refine le_trans hn (measure_mono ?_)
        intro ω hω
        apply hgood m
        intro i hi
        exact (TwoStageSmallField.index_good_eq (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m)
          ω).mp (hω i hi) }
  have HO : WeakUltravioletExistence.ObservableHypotheses Dset s Bd act εb Pset :=
    { countable := hcount, dense := hdense, bounded := hbd, equicontinuous := hreg,
      act_continuous := hac, act_maps := ham, breaking := hbr, breaking_vanishes := hbv,
      positivity_on_lattice := hpos }
  exact WeakUltravioletExistence.weak_uv_skeleton νP Bm hB Θ Aset actb Cset _ Dset s Bd act εb Pset
    lev Fo HB HO HR

/-- The signed chain end to end, obtained as the special case `δ ≡ 0`, `D₀ = 0` of the transient
chain (same statement as `AsymptoticChain.chain_end_to_end_signed`). -/
theorem chain_end_to_end_signed_of_transient
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {b bm bp C₂ ρ A B Y ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : AsymptoticChain.ChainHypothesesSigned u z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (bm - (C₂ / ustar + Y)) * n ≤ x ∧
      x ≤ t + (bp + (C₂ / ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  have H' : ChainHypothesesTransient u z w rs rl Φ W Dfun (fun _ => 0) b bm bp C₂ 0 ρ A B Y ustar
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr :=
    { steps := transient_of_signed H.steps, prob := H.prob, rarity := H.rarity,
      lattice_vanishing := H.lattice_vanishing, shift_vanishing := H.shift_vanishing,
      split := H.split }
  obtain ⟨hW0, hrest⟩ := chain_end_to_end_transient νP R plaq pts Yf f yh θ P₁ S np npt H' h0 hCu
    Bm hB Θ Aset actb Cset hcons hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd
    hac ham hbr hbv hpos lev Fo HR
  refine ⟨fun t ht n => ?_, hrest⟩
  obtain ⟨x, h1, h2, h3, h4⟩ := hW0 t (by linarith) n
  exact ⟨x, by linarith, h2, h3, fun k hk => by linarith [h4 k hk]⟩

end EndToEnd

-- The signed chain end to end has the same statement as its special case of the transient chain.
example : @AsymptoticChain.chain_end_to_end_signed = @chain_end_to_end_signed_of_transient := rfl

/-! ## D3. The asymptotic premises with a transient bracket and the point u⋆ -/

noncomputable section

/-- u⋆ for the transient form (margin `binf/2`). -/
def ustarTransient (binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ) : ℝ :=
  TransientPremises.ustarTransientOf u₀ ρ A B D₁ (AsymptoticChain.phi0 K σ y₀) C₂ (binf / 2) D₀

end

/-- The asymptotic premises with a transient bracket. As `AsymptoticChain.AsymptoticStepsSigned`
(constants independent of u, base point u₀, threshold `2(log u)/σ + y₀`, coefficient `D₁u`), with
the net bracket `binf + δ_k − C₂/u_k ≤ b − r^sf_k ≤ bp + C₂/u_k` and `Σ_{k<n} max(−δ_k, 0) ≤ D₀`.
The condition not paid by u⋆ is `binf > 0`; no step needs to lower u. -/
structure AsymptoticStepsTransient (u z w rs rl : ℕ → ℝ → ℝ) (δ : ℕ → ℝ)
    (b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ) : Prop where
  hbinf : 0 < binf
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hρ1 : ρ < 1
  hA : 0 ≤ A
  hB : 0 ≤ B
  hK : 0 ≤ K
  hσ : 0 < σ
  flow : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    binf + δ k - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  transient : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀
  large_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → |rl k x| ≤ D₁ * u k x * z k x
  act_rec : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, u₀ ≤ u 0 x →
    z 0 x ≤ AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    w k x ≤ K * Real.exp (-(σ * (2 * Real.log (u k x) / σ + y₀)))

/-- The asymptotic premises with a transient bracket give the per-step hypotheses of the transient
chain at the explicit point `u⋆ = ustarTransient …`, with `Φ = Φ₀/s²`, `W = 2AΦ/(1−ρ)`, `D(s) = D₁s`,
`Y = Υ(u⋆)`. -/
theorem transient_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀) :
    CouplingStepsTransient u z w rs rl
      (AsymptoticPremises.supplySq (AsymptoticChain.phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀)) (fun s => D₁ * s) δ
      b binf bp C₂ D₀ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
        (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀))
      (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) := by
  have hΦ : 0 ≤ AsymptoticChain.phi0 K σ y₀ := AsymptoticChain.phi0_nonneg H.hK σ y₀
  have hm : 0 < binf / 2 := by linarith [H.hbinf]
  have hD0 : 0 ≤ D₀ := TransientPremises.nonneg_of_negPart_sum δ D₀ H.transient
  obtain ⟨hu0, hu1, hfix, hDW, hmar⟩ := TransientPremises.transient_fields_sq_log u₀ ρ A B D₁
    (AsymptoticChain.phi0 K σ y₀) C₂ (binf / 2) D₀ H.hρ H.hρ1 H.hA H.hD hΦ hm hD0
  have hus : 0 < ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := lt_of_lt_of_le one_pos hu1
  have hdom : ∀ k x, (∀ j ≤ k, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ j ≤ k, u₀ ≤ u j x :=
    fun k x hd j hj => le_trans hu0 (hd j hj)
  exact
    { ustar_pos := hus
      hC := H.hC
      hD := fun s hs => mul_nonneg H.hD (le_trans hus.le hs)
      hρ := H.hρ
      hA := H.hA
      hB := H.hB
      flow := fun k x hd => H.flow k x (hdom k x hd)
      small_net := fun k x hd => H.small_net k x (hdom k x hd)
      transient := H.transient
      large_rem := fun k x hd => H.large_rem k x (hdom k x hd)
      act_rec := fun k x hd => H.act_rec k x (hdom k x hd)
      act_nonneg := H.act_nonneg
      act_init := fun x hx => H.act_init x (le_trans hu0 hx)
      supply := fun k x hd => by
        have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
        have h := H.supply k x (hdom k x hd)
        rw [AsymptoticPremises.supply_sq_log_threshold K σ y₀ (u k x) H.hσ hpos] at h
        exact h
      fix_shift := hfix
      DW := hDW
      margin := by
        have hb := H.hbinf
        unfold ustarTransient
        linarith [hmar] }

/-- The margin at the transient u⋆: `C₂/u⋆ + Υ(u⋆) ≤ binf/2`. -/
theorem margin_ustarTransient {binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ} (hbinf : 0 < binf)
    (hρ1 : ρ < 1) :
    C₂ / ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ +
      AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
        (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) ≤ binf / 2 := by
  obtain ⟨-, -, -, hii⟩ := AsymptoticPremises.ustar_of_sq_log_threshold u₀ ρ A B D₁
    (AsymptoticChain.phi0 K σ y₀) C₂ (binf / 2) hρ1 (by linarith)
  exact hii _ (TransientPremises.ustarOf_le_ustarTransientOf _ _ _ _ _ _ _ _ _)

/-- The signed asymptotic premises are the special case `δ ≡ 0`, `D₀ = 0`, `binf = bm`. -/
theorem asymptoticTransient_of_signed {u z w rs rl : ℕ → ℝ → ℝ}
    {b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticChain.AsymptoticStepsSigned u z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀) :
    AsymptoticStepsTransient u z w rs rl (fun _ => 0) b bm bp C₂ 0 D₁ ρ A B K σ y₀ u₀ where
  hbinf := H.hbm
  hC := H.hC
  hD := H.hD
  hρ := H.hρ
  hρ1 := H.hρ1
  hA := H.hA
  hB := H.hB
  hK := H.hK
  hσ := H.hσ
  flow := H.flow
  small_net := fun k x hd => by
    simp only [add_zero]
    exact H.small_net k x hd
  transient := fun n => by simp
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply

/-- (W0) alone under the transient asymptotic premises: for every target `t ≥ u⋆ + D₀` and every n
there is a bare value x with `u_n x = t`, the path staying `≥ t − D₀`, and
`t + (binf/2)n − D₀ ≤ x ≤ t + (bp + binf/2)n`. -/
theorem bare_value_of_asymptotic_transient {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, u₀ ≤ u j x}) :
    ∀ t, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ,
      t + binf / 2 * n - D₀ ≤ x ∧ x ≤ t + (bp + binf / 2) * n ∧ u n x = t ∧
        ∀ k ≤ n, t - D₀ ≤ u k x := by
  intro t ht n
  have HS := transient_of_asymptotic H
  have hu0 : u₀ ≤ ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ :=
    le_trans (AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _)
      (TransientPremises.ustarOf_le_ustarTransientOf _ _ _ _ _ _ _ _ _)
  have hmar := margin_ustarTransient (D₀ := D₀) (D₁ := D₁) (A := A) (B := B) (K := K) (σ := σ)
    (y₀ := y₀) (u₀ := u₀) (C₂ := C₂) H.hbinf H.hρ1
  have ha : 0 ≤ binf - (C₂ / ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ +
      AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
        (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀)) := by linarith [H.hbinf]
  obtain ⟨x, h1, h2, h3, h4⟩ := TransientPremises.exists_bare_inverse_coupling_transient u δ _ _
    D₀ _ t n ha (TransientPremises.interval_sum_ge δ D₀ H.transient) h0
    (hbeta_of_steps_transient HS)
    (fun k => (hCu k).mono (fun x hx j hj => le_trans hu0 (hx j hj))) ht
  have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  have hmn := mul_le_mul_of_nonneg_right hmar hn
  refine ⟨x, ?_, ?_, h3, h4⟩
  · nlinarith
  · nlinarith

section ChainAsymptotic

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- The chain hypotheses with the per-step fields in the transient asymptotic form. -/
structure ChainHypothesesAsymptoticTransient (u z w rs rl : ℕ → ℝ → ℝ) (δ : ℕ → ℝ)
    (b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ)
    (ν : ℕ → ∀ m, Measure (E m)) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (I : ∀ m, ι m → E m → ℝ) (θh : ℕ → ℝ) (ε : ℕ → ℝ≥0∞)
    (Dset : Set X) (s : ℕ → X → ℝ) (τ : ℕ → ℝ) (Ωr : ℝ → ℝ) : Prop where
  steps : AsymptoticStepsTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀
  prob : ∀ n m, IsProbabilityMeasure (ν n m)
  rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m
  lattice_vanishing : Tendsto τ atTop (𝓝 0)
  shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η
  split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')

/-- The hypotheses of `chain_end_to_end_transient` hold at u⋆. -/
theorem chainHypothesesTransient_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptoticTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀
      ν R I θh ε Dset s τ Ωr) :
    ChainHypothesesTransient u z w rs rl
      (AsymptoticPremises.supplySq (AsymptoticChain.phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀)) (fun s => D₁ * s) δ
      b binf bp C₂ D₀ ρ A B
      (AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
        (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀))
      (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) ν R I θh ε Dset s τ Ωr where
  steps := transient_of_asymptotic H.steps
  prob := H.prob
  rarity := H.rarity
  lattice_vanishing := H.lattice_vanishing
  shift_vanishing := H.shift_vanishing
  split := H.split

end ChainAsymptotic

section EndToEndAsymptotic

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Chain end to end under the transient asymptotic premises: with the explicit
`u⋆ = ustarTransient …` (constants only), (W0) holds for every target `t ≥ u⋆ + D₀` with the bracket
`[t + (binf − e⋆)n − D₀, t + (bp + e⋆)n]`, `e⋆ = C₂/u⋆ + Υ(u⋆) ≤ binf/2` (`margin_ustarTransient`), the
path staying `≥ t − D₀`, and the rest of the conclusions as in the moving chain. Continuity is asked
on the domain at u₀. -/
theorem chain_end_to_end_asymptotic_transient
    {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ} {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (H : ChainHypothesesAsymptoticTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀
      (fun n m => (νP n m : Measure (E m))) R
      (fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m))
      (fun _ => (1 / 2 : ℝ)) (fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m) Dset s τ Ωr)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, u₀ ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ,
      t + (binf - (C₂ / ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ +
        AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
          (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀))) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (C₂ / ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ +
        AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
          (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀))) * n ∧
      u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  have hu0 : u₀ ≤ ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ :=
    le_trans (AsymptoticPremises.le_ustarOf _ _ _ _ _ _ _ _)
      (TransientPremises.ustarOf_le_ustarTransientOf _ _ _ _ _ _ _ _ _)
  exact chain_end_to_end_transient νP R plaq pts Yf f yh θ P₁ S np npt
    (chainHypothesesTransient_of_asymptotic H) h0
    (fun k => (hCu k).mono (fun x hx j hj => le_trans hu0 (hx j hj)))
    Bm hB Θ Aset actb Cset hcons hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd
    hac ham hbr hbv hpos lev Fo HR

end EndToEndAsymptotic

/-! ## D4. Non-vacuity and a model outside the signed premises -/

-- the toy model of the original file (u_k(x) = x − k, no transient) satisfies the transient premises
example : AsymptoticStepsTransient (fun k x => x - k) (fun _ _ => 0) (fun _ _ => 0)
    (fun _ _ => 0) (fun _ _ => 0) (fun _ => 0) 1 1 2 0 0 0 0 0 0 1 1 0 1 where
  hbinf := one_pos
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hρ1 := zero_lt_one
  hA := le_rfl
  hB := le_rfl
  hK := zero_le_one
  hσ := one_pos
  flow := fun k x _ => by
    show x - ((k + 1 : ℕ) : ℝ) = x - (k : ℝ) - 1 + 0 + 0
    push_cast; ring
  small_net := fun k x _ => by norm_num
  transient := fun n => by simp
  large_rem := fun k x _ => by simp
  act_rec := fun k x _ => by simp
  act_nonneg := fun _ _ => le_rfl
  act_init := fun x _ => by simp [AsymptoticPremises.movingBound]
  supply := fun k x _ => by
    simp only [one_mul]
    exact (Real.exp_pos _).le

/-- A path family whose first step raises u by 1: `u_0 = x`, `u_{k+1} = x + 1 − k`. -/
def toyU : ℕ → ℝ → ℝ
  | 0, x => x
  | k + 1, x => x + 1 - k

/-- Its small-field remainder for `b = 1`. -/
def toyRs : ℕ → ℝ → ℝ
  | 0, _ => 2
  | _ + 1, _ => 0

/-- Its transient: `δ_0 = −2`, `δ_k = 0` for `k ≥ 1`. -/
def toyDelta : ℕ → ℝ
  | 0 => -2
  | _ + 1 => 0

/-- The model with a rising first step satisfies the transient premises (`binf = bp = 1`, `D₀ = 2`). -/
theorem toy_transient : AsymptoticStepsTransient toyU (fun _ _ => 0) (fun _ _ => 0) toyRs
    (fun _ _ => 0) toyDelta 1 1 1 0 2 0 0 0 0 0 1 0 1 where
  hbinf := one_pos
  hC := le_rfl
  hD := le_rfl
  hρ := le_rfl
  hρ1 := zero_lt_one
  hA := le_rfl
  hB := le_rfl
  hK := le_rfl
  hσ := one_pos
  flow := fun k x _ => by
    cases k with
    | zero => simp only [toyU, toyRs]; push_cast; ring
    | succ k => simp only [toyU, toyRs]; push_cast; ring
  small_net := fun k x _ => by
    cases k with
    | zero => simp only [toyRs, toyDelta]; norm_num
    | succ k => simp only [toyRs, toyDelta]; norm_num
  transient := fun n => by
    cases n with
    | zero => simp
    | succ n =>
      rw [Finset.sum_range_succ']
      simp only [toyDelta, neg_zero, max_self, Finset.sum_const_zero, zero_add]
      norm_num
  large_rem := fun k x _ => by simp
  act_rec := fun k x _ => by simp
  act_nonneg := fun _ _ => le_rfl
  act_init := fun x _ => by simp [AsymptoticPremises.movingBound]
  supply := fun k x _ => by simp

/-- The same path family is outside the signed premises, whatever the other data and constants:
the first step forces `bm ≤ (C₂ + Υ₀)/x − 1` for every large x. -/
theorem toy_not_signed (z w rs rl : ℕ → ℝ → ℝ) (b bm bp C₂ D₁ ρ A B K σ y₀ u₀ : ℝ) :
    ¬ AsymptoticChain.AsymptoticStepsSigned toyU z w rs rl b bm bp C₂ D₁ ρ A B K σ y₀ u₀ := by
  intro H
  have hΦ : 0 ≤ AsymptoticChain.phi0 K σ y₀ := AsymptoticChain.phi0_nonneg H.hK σ y₀
  have h1ρ : 0 < 1 - ρ := by linarith [H.hρ1]
  have hΥ0 : 0 ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) := by
    have := H.hA; have := H.hD
    positivity
  obtain ⟨x, hxu, hx1⟩ : ∃ x, u₀ ≤ x ∧
      C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) + 1 ≤ x :=
    ⟨max u₀ (C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) + 1),
      le_max_left _ _, le_max_right _ _⟩
  have hx0 : 0 < x := by linarith [H.hC]
  have hdom : ∀ j ≤ 0, u₀ ≤ toyU j x := by
    intro j hj
    obtain rfl : j = 0 := by omega
    exact hxu
  have hf := H.flow 0 x hdom
  have hsn := (H.small_net 0 x hdom).1
  have hl := H.large_rem 0 x hdom
  have hz := H.act_init x hxu
  simp only [toyU, Nat.cast_zero, sub_zero] at hf hsn hl hz
  have hW : D₁ * x * AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) x =
      2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) / x := by
    rw [AsymptoticPremises.coefficient_times_bound ρ A D₁ _ x H.hρ1 hx0]
    unfold AsymptoticPremises.upsilon
    rw [div_div]
  have hrl : rl 0 x ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) / x := by
    have h2 : D₁ * x * z 0 x ≤
        D₁ * x * AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) x :=
      mul_le_mul_of_nonneg_left hz (mul_nonneg H.hD hx0.le)
    linarith [le_abs_self (rl 0 x)]
  have hkey : bm + 1 ≤ (C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ)) / x := by
    rw [add_div]
    linarith
  have hlt : (C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ)) / x < 1 := by
    rw [div_lt_one hx0]
    linarith
  linarith [H.hbm]

/-- In this model the lower end `t + (binf − e⋆)n − D₀ = t + n − 2` of the (W0) bracket is attained
(`e⋆ = 0` since `C₂ = 0` and there is no large-field activity): the shift by `D₀` is sharp. -/
theorem toy_bare_value (t : ℝ) (n : ℕ) :
    toyU (n + 1) (t + 1 * ((n + 1 : ℕ) : ℝ) - 2) = t ∧
      ∀ k ≤ n + 1, t - 2 ≤ toyU k (t + 1 * ((n + 1 : ℕ) : ℝ) - 2) := by
  refine ⟨by simp only [toyU]; push_cast; ring, fun k hk => ?_⟩
  cases k with
  | zero =>
    simp only [toyU]; push_cast
    have : (0 : ℝ) ≤ n := Nat.cast_nonneg n
    linarith
  | succ k =>
    simp only [toyU]; push_cast
    have : (k : ℝ) ≤ n := by exact_mod_cast (show k ≤ n by omega)
    linarith

end TransientChain


/-! # (W0) with the one-loop slope binf and a logarithmic correction (namespace TransientChain) -/

namespace TransientChain

/-- On the domain at u⋆, the refined per-step lower bound of the transient asymptotic premises:
`binf + δ_k − (C₂ + Υ₀)/u_k ≤ u_k − u_{k+1}` with `Υ₀ = 2AD₁Φ₀/(1−ρ)` (the large-field part is at
most `D₁u_k·W(u_k) = Υ₀/u_k`). -/
theorem refined_step_of_asymptotic {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀) :
    ∀ k x, (∀ j ≤ k, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      binf + δ k - (C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ)) / u k x ≤
        u k x - u (k + 1) x := by
  intro k x hd
  have HS := transient_of_asymptotic H
  have hz := activity_le_transient HS k x hd
  have hus : 0 < ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := HS.ustar_pos
  have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
  have hsn := (HS.small_net k x hd).1
  have hf := HS.flow k x hd
  have hl := HS.large_rem k x hd
  have hW : D₁ * u k x * z k x ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) / u k x := by
    have h1 : D₁ * u k x * z k x ≤
        D₁ * u k x * AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) (u k x) :=
      mul_le_mul_of_nonneg_left hz (mul_nonneg H.hD hpos.le)
    have h2 : D₁ * u k x * AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) (u k x) =
        2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) / u k x := by
      rw [AsymptoticPremises.coefficient_times_bound ρ A D₁ _ (u k x) H.hρ1 hpos]
      unfold AsymptoticPremises.upsilon
      rw [div_div]
    linarith
  have hrl : rl k x ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) / u k x := by
    have h := le_trans (le_abs_self (rl k x)) hl
    linarith
  rw [add_div]
  linarith

/-- (W0) with the exact one-loop slope: under the transient asymptotic premises, for every target
`t ≥ u⋆ + D₀` and every n there is a bare value x with `u_n x = t`, the path staying `≥ t − D₀`,
`x ≤ t + (bp + binf/2)n`, and
`x ≥ t + binf·n − D₀ − (2(C₂ + Υ₀)/binf)·log(1 + binf·n/(2(t − D₀)))`, `Υ₀ = 2AD₁Φ₀/(1−ρ)`.
The slope of the lower end is `binf` itself; the errors `C₂/u_k + Υ₀/u_k` add up to a logarithm
because `u_k` grows linearly along the path. -/
theorem bare_value_log_of_asymptotic_transient {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsTransient u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀)
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, u₀ ≤ u j x}) :
    ∀ t, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ,
      t + binf * n - D₀ -
          (C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ)) / (binf / 2) *
            Real.log (1 + binf / 2 * n / (t - D₀)) ≤ x ∧
      x ≤ t + (bp + binf / 2) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x := by
  intro t ht n
  obtain ⟨x, -, h2, h3, h4⟩ := bare_value_of_asymptotic_transient H h0 hCu t ht n
  refine ⟨x, ?_, h2, h3, h4⟩
  have HS := transient_of_asymptotic H
  have hus : 0 < ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := HS.ustar_pos
  have hmar := margin_ustarTransient (D₀ := D₀) (D₁ := D₁) (A := A) (B := B) (K := K) (σ := σ)
    (y₀ := y₀) (u₀ := u₀) (C₂ := C₂) H.hbinf H.hρ1
  have hb := H.hbinf
  have hΦ : 0 ≤ AsymptoticChain.phi0 K σ y₀ := AsymptoticChain.phi0_nonneg H.hK σ y₀
  have h1ρ : 0 < 1 - ρ := by linarith [H.hρ1]
  have hE : 0 ≤ C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) := by
    have := H.hA; have := H.hD; have := H.hC
    positivity
  -- the coarse bracket with a = binf/2
  have hS : ∀ k x, (∀ j ≤ k, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      binf / 2 + δ k ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (C₂ / ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ +
          AsymptoticPremises.upsilon ρ A D₁ (AsymptoticChain.phi0 K σ y₀)
            (ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀)) := by
    intro k x hd
    have h := hbeta_of_steps_transient HS k x hd
    constructor <;> linarith [h.1, h.2]
  have hpath : ∀ k ≤ n, ustarTransient binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ ≤ u k x := by
    intro k hk
    have := h4 k hk
    linarith
  have hT : 0 < t - D₀ := by linarith
  exact TransientPremises.bare_value_log_lower u δ (binf / 2) _ binf _ D₀ _ t x n
    (by linarith) hE (TransientPremises.interval_sum_ge δ D₀ H.transient) hS
    (refined_step_of_asymptotic H) h0 hT hpath h3

end TransientChain


/-! # The coefficient D₁u·y_s(u), and the toy model against the abstract signed hypotheses
(namespace TransientChain) -/

namespace TransientChain

noncomputable section

/-- u⋆ for the transient form with the coefficient `D₁u·y_s(u)` (margin `binf/2`). -/
def ustarTransientGrowing (binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ) : ℝ :=
  max (AsymptoticPremises.ustarGrowingOf u₀ ρ A B D₁ (AsymptoticChain.phi0 K σ y₀) C₂ σ y₀ (binf / 2))
    (max (8 * A * B * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) ^ 2) (12 * D₀ / (1 - ρ)))

end

/-- The transient asymptotic premises with the coefficient `D₁u·y_s(u)`, `y_s(u) = 2(log u)/σ + y₀`,
`y₀ ≥ 0` (the other form of (S3)). -/
structure AsymptoticStepsTransientGrowing (u z w rs rl : ℕ → ℝ → ℝ) (δ : ℕ → ℝ)
    (b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ) : Prop where
  hbinf : 0 < binf
  hC : 0 ≤ C₂
  hD : 0 ≤ D₁
  hρ : 0 ≤ ρ
  hρ1 : ρ < 1
  hA : 0 ≤ A
  hB : 0 ≤ B
  hK : 0 ≤ K
  hσ : 0 < σ
  hy : 0 ≤ y₀
  flow : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    binf + δ k - C₂ / u k x ≤ b - rs k x ∧ b - rs k x ≤ bp + C₂ / u k x
  transient : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀
  large_rem : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    |rl k x| ≤ D₁ * u k x * (2 * Real.log (u k x) / σ + y₀) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, u₀ ≤ u 0 x →
    z 0 x ≤ AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀) (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, u₀ ≤ u j x) →
    w k x ≤ K * Real.exp (-(σ * (2 * Real.log (u k x) / σ + y₀)))

/-- With the coefficient `D₁u·y_s(u)` the transient per-step hypotheses hold at the explicit point
`u⋆ = ustarTransientGrowing …`, with `Y = Υ′(u⋆) = Υ₀(4/σ + y₀)/√u⋆`; this feeds
`chain_end_to_end_transient` in the same way as `transient_of_asymptotic`. -/
theorem transient_of_asymptotic_growing {u z w rs rl : ℕ → ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀ : ℝ}
    (H : AsymptoticStepsTransientGrowing u z w rs rl δ b binf bp C₂ D₀ D₁ ρ A B K σ y₀ u₀) :
    CouplingStepsTransient u z w rs rl
      (AsymptoticPremises.supplySq (AsymptoticChain.phi0 K σ y₀))
      (AsymptoticPremises.movingBound ρ A (AsymptoticChain.phi0 K σ y₀))
      (fun s => D₁ * s * (2 * Real.log s / σ + y₀)) δ b binf bp C₂ D₀ ρ A B
      (AsymptoticPremises.upsilonGrowing ρ A D₁ (AsymptoticChain.phi0 K σ y₀) σ y₀
        (ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀))
      (ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) := by
  have hΦ : 0 ≤ AsymptoticChain.phi0 K σ y₀ := AsymptoticChain.phi0_nonneg H.hK σ y₀
  have hm : 0 < binf / 2 := by linarith [H.hbinf]
  have hD0 : 0 ≤ D₀ := TransientPremises.nonneg_of_negPart_sum δ D₀ H.transient
  have h1ρ : 0 < 1 - ρ := by linarith [H.hρ1]
  obtain ⟨hu0, hu1, hDn, -, -, -, -⟩ := AsymptoticPremises.moving_fields_growing u₀ ρ A B D₁
    (AsymptoticChain.phi0 K σ y₀) C₂ σ y₀ (binf / 2) H.hρ1 H.hA H.hD hΦ H.hC H.hσ H.hy hm
  have hle : AsymptoticPremises.ustarGrowingOf u₀ ρ A B D₁ (AsymptoticChain.phi0 K σ y₀) C₂ σ y₀
      (binf / 2) ≤ ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := le_max_left _ _
  have hq8 : 8 * A * B * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) ^ 2 ≤
      ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ :=
    le_trans (le_max_left _ _) (le_max_right _ _)
  have hd12 : 12 * D₀ / (1 - ρ) ≤ ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ :=
    le_trans (le_max_right _ _) (le_max_right _ _)
  have hus1 : 1 ≤ ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := le_trans hu1 hle
  have hus : 0 < ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := by linarith
  have hu0' : u₀ ≤ ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := le_trans hu0 hle
  have hdom : ∀ k x, (∀ j ≤ k, ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ ≤ u j x) →
      ∀ j ≤ k, u₀ ≤ u j x :=
    fun k x hd j hj => le_trans hu0' (hd j hj)
  have hΥ : 0 ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) := by
    have := H.hA; have := H.hD
    positivity
  -- the squared margin term of `ustarGrowingOf` is below the new u⋆
  have hsq : ((C₂ + 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) * (4 / σ + y₀)) /
      (binf / 2)) ^ 2 ≤ ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀ := by
    refine le_trans ?_ hle
    unfold AsymptoticPremises.ustarGrowingOf
    exact le_max_right _ _
  exact
    { ustar_pos := hus
      hC := H.hC
      hD := fun s hs => hDn s (le_trans hle hs)
      hρ := H.hρ
      hA := H.hA
      hB := H.hB
      flow := fun k x hd => H.flow k x (hdom k x hd)
      small_net := fun k x hd => H.small_net k x (hdom k x hd)
      transient := H.transient
      large_rem := fun k x hd => H.large_rem k x (hdom k x hd)
      act_rec := fun k x hd => H.act_rec k x (hdom k x hd)
      act_nonneg := H.act_nonneg
      act_init := fun x hx => H.act_init x (le_trans hu0' hx)
      supply := fun k x hd => by
        have hpos : 0 < u k x := lt_of_lt_of_le hus (hd k le_rfl)
        have h := H.supply k x (hdom k x hd)
        rw [AsymptoticPremises.supply_sq_log_threshold K σ y₀ (u k x) H.hσ hpos] at h
        exact h
      fix_shift := fun s s' hs hs' hss =>
        TransientPremises.fix_shift_sq ρ A B (AsymptoticChain.phi0 K σ y₀) D₀ s s' H.hρ H.hρ1
          H.hA hΦ hD0 (le_trans hus1 hs) (le_trans hq8 hs) (le_trans hd12 hs)
          (lt_of_lt_of_le hus hs') hss
      DW := fun s hs => by
        have hs1 : 1 ≤ s := le_trans hus1 hs
        have hg := AsymptoticPremises.growing_coefficient_decay ρ A D₁
          (AsymptoticChain.phi0 K σ y₀) σ y₀ s H.hρ1 H.hA H.hD hΦ H.hσ H.hy hs1
        have hsq' : Real.sqrt (ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) ≤
            Real.sqrt s := Real.sqrt_le_sqrt hs
        have hr : 0 < Real.sqrt (ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) :=
          Real.sqrt_pos.mpr hus
        have hK' : 0 ≤ 2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ) * (4 / σ + y₀) :=
          mul_nonneg hΥ (add_nonneg (div_nonneg (by norm_num) H.hσ.le) H.hy)
        unfold AsymptoticPremises.upsilonGrowing
        exact le_trans hg (div_le_div_of_nonneg_left hK' hr hsq')
      margin := by
        have h := AsymptoticPremises.margin_growing_coefficient C₂
          (2 * A * D₁ * AsymptoticChain.phi0 K σ y₀ / (1 - ρ)) σ y₀ (binf / 2) H.hC hΥ H.hσ H.hy
          hm (ustarTransientGrowing binf C₂ D₀ D₁ ρ A B K σ y₀ u₀) (max_le hus1 hsq)
        unfold AsymptoticPremises.upsilonGrowing
        linarith [H.hbinf] }

/-- The toy path family is outside the abstract signed per-step hypotheses as well, for every u⋆,
W, Φ, Dfun, Y and every bracket: at `x = u⋆` the first step forces `bm ≤ C₂/u⋆ + Y − 1 ≤ bm − 1`. -/
theorem toy_not_signed_steps (z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ)
    (b bm bp C₂ ρ A B Y ustar : ℝ) :
    ¬ AsymptoticChain.CouplingStepsSigned toyU z w rs rl Φ W Dfun b bm bp C₂ ρ A B Y ustar := by
  intro H
  have hdom : ∀ j ≤ 0, ustar ≤ toyU j ustar := by
    intro j hj
    obtain rfl : j = 0 := by omega
    exact le_of_eq rfl
  have hf := H.flow 0 ustar hdom
  have hsn := (H.small_net 0 ustar hdom).1
  have hl := H.large_rem 0 ustar hdom
  have hz := H.act_init ustar le_rfl
  have hD := H.hD ustar le_rfl
  have hDW := H.DW ustar le_rfl
  have hm := H.margin
  simp only [toyU, Nat.cast_zero, sub_zero] at hf hsn hl hz
  have h1 : Dfun ustar * z 0 ustar ≤ Dfun ustar * W ustar := mul_le_mul_of_nonneg_left hz hD
  linarith [le_abs_self (rl 0 ustar)]

end TransientChain


/-! # The transient chain with an antitone error function (namespace TransientChainError)

The small-field bracket of `TransientChain.CouplingStepsTransient` uses its error `C₂/u_k` only
through two facts: the error decreases in `u` on the domain `[u⋆, ∞)`, and its value at `u⋆`
fits the margin. Here `C₂/u` is replaced by any function `e` that decreases on `[u⋆, ∞)`, for
example `e(s) = C₁/√s` (a remainder of order `g`) or `e(s) = C₂/s + C₁/√s`.

The per-step hypotheses with `e` imply the original ones with `C₂ = 0`, `binf ↦ binf − e(u⋆)`,
`bp ↦ bp + e(u⋆)` (`transient_of_error`), so the end-to-end theorem
`TransientChain.chain_end_to_end_transient` applies unchanged (`chain_end_to_end_error`), with the
bracket `binf − (e(u⋆) + Y)`, `bp + (e(u⋆) + Y)`. The original hypotheses are the case
`e(s) = C₂/s` (`error_of_transient`). -/

namespace TransientChainError

open Filter Topology MeasureTheory Set
open scoped ENNReal

/-- Per-step hypotheses with a transient bracket and an error function `e` that decreases on
`[u⋆, ∞)`. Same fields as `TransientChain.CouplingStepsTransient`, with `C₂ / u` replaced by
`e u` in `small_net` and `margin`, and `0 ≤ C₂` replaced by the monotonicity `he`. -/
structure CouplingStepsTransientE (u z w rs rl : ℕ → ℝ → ℝ) (Φ W Dfun : ℝ → ℝ) (δ : ℕ → ℝ)
    (e : ℝ → ℝ) (b binf bp D₀ ρ A B Y ustar : ℝ) : Prop where
  ustar_pos : 0 < ustar
  he : ∀ s t, ustar ≤ s → s ≤ t → e t ≤ e s
  hD : ∀ s, ustar ≤ s → 0 ≤ Dfun s
  hρ : 0 ≤ ρ
  hA : 0 ≤ A
  hB : 0 ≤ B
  flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x
  small_net : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    binf + δ k - e (u k x) ≤ b - rs k x ∧ b - rs k x ≤ bp + e (u k x)
  transient : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀
  large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ Dfun (u k x) * z k x
  act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
    z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2
  act_nonneg : ∀ k x, 0 ≤ z k x
  act_init : ∀ x, ustar ≤ u 0 x → z 0 x ≤ W (u 0 x)
  supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x)
  fix_shift : ∀ s s', ustar ≤ s → ustar ≤ s' → s' ≤ s + D₀ →
    ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s'
  DW : ∀ s, ustar ≤ s → Dfun s * W s ≤ Y
  margin : e ustar + Y ≤ binf

/-- The hypotheses with an antitone error give the original ones with `C₂ = 0` and the bracket
widened by `e(u⋆)` on both sides. -/
theorem transient_of_error {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    (H : CouplingStepsTransientE u z w rs rl Φ W Dfun δ e b binf bp D₀ ρ A B Y ustar) :
    TransientChain.CouplingStepsTransient u z w rs rl Φ W Dfun δ b (binf - e ustar)
      (bp + e ustar) 0 D₀ ρ A B Y ustar where
  ustar_pos := H.ustar_pos
  hC := le_rfl
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_net := by
    intro k x hdom
    have hk : e (u k x) ≤ e ustar := H.he ustar (u k x) le_rfl (hdom k le_rfl)
    have hs := H.small_net k x hdom
    simp only [zero_div, sub_zero, add_zero]
    constructor <;> linarith [hs.1, hs.2]
  transient := H.transient
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply
  fix_shift := H.fix_shift
  DW := H.DW
  margin := by
    have hm := H.margin
    simp only [zero_div, zero_add]
    linarith

/-- The original hypotheses are the case `e(s) = C₂/s`. -/
theorem error_of_transient {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {b binf bp C₂ D₀ ρ A B Y ustar : ℝ}
    (H : TransientChain.CouplingStepsTransient u z w rs rl Φ W Dfun δ b binf bp C₂ D₀ ρ A B Y
      ustar) :
    CouplingStepsTransientE u z w rs rl Φ W Dfun δ (fun s => C₂ / s) b binf bp D₀ ρ A B Y
      ustar where
  ustar_pos := H.ustar_pos
  he := fun _ _ hs hst => div_le_div_of_nonneg_left H.hC (lt_of_lt_of_le H.ustar_pos hs) hst
  hD := H.hD
  hρ := H.hρ
  hA := H.hA
  hB := H.hB
  flow := H.flow
  small_net := H.small_net
  transient := H.transient
  large_rem := H.large_rem
  act_rec := H.act_rec
  act_nonneg := H.act_nonneg
  act_init := H.act_init
  supply := H.supply
  fix_shift := H.fix_shift
  DW := H.DW
  margin := H.margin

/-- The (H-β) form with an antitone error: on the domain,
`binf − (e(u⋆) + Y) + δ_k ≤ u_k − u_{k+1} ≤ bp + (e(u⋆) + Y)`. -/
theorem hbeta_of_error {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    (H : CouplingStepsTransientE u z w rs rl Φ W Dfun δ e b binf bp D₀ ρ A B Y ustar) :
    ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      binf - (e ustar + Y) + δ k ≤ u k x - u (k + 1) x ∧
        u k x - u (k + 1) x ≤ bp + (e ustar + Y) := by
  intro k x hdom
  have h := TransientChain.hbeta_of_steps_transient (transient_of_error H) k x hdom
  simp only [zero_div, zero_add] at h
  constructor <;> linarith [h.1, h.2]

/-! ## Error functions of order `g` -/

/-- `e(s) = C₂/s + C₁/√s` decreases on `[u⋆, ∞)` when `u⋆ > 0`, `C₁, C₂ ≥ 0`. -/
theorem error_mixed_antitone {C₁ C₂ ustar : ℝ} (h1 : 0 ≤ C₁) (h2 : 0 ≤ C₂) (hu : 0 < ustar) :
    ∀ s t, ustar ≤ s → s ≤ t → C₂ / t + C₁ / Real.sqrt t ≤ C₂ / s + C₁ / Real.sqrt s := by
  intro s t hs hst
  have hs0 : 0 < s := lt_of_lt_of_le hu hs
  have a1 : C₂ / t ≤ C₂ / s := div_le_div_of_nonneg_left h2 hs0 hst
  have a2 : C₁ / Real.sqrt t ≤ C₁ / Real.sqrt s :=
    div_le_div_of_nonneg_left h1 (Real.sqrt_pos.mpr hs0) (Real.sqrt_le_sqrt hst)
  linarith

/-- An error `C₁/√u` (order `g`) fits a room `m > 0` once `u ≥ (C₁/m)²`. -/
theorem margin_sqrt {C₁ m u : ℝ} (hC : 0 ≤ C₁) (hm : 0 < m) (hu : (C₁ / m) ^ 2 ≤ u) :
    C₁ / Real.sqrt u ≤ m := by
  have hsq : C₁ / m ≤ Real.sqrt u := by
    calc C₁ / m = Real.sqrt ((C₁ / m) ^ 2) := (Real.sqrt_sq (div_nonneg hC hm.le)).symm
      _ ≤ Real.sqrt u := Real.sqrt_le_sqrt hu
  rcases eq_or_lt_of_le (Real.sqrt_nonneg u) with h0 | hpos
  · rw [← h0, div_zero]; exact hm.le
  · rw [div_le_iff₀ hpos]
    have h := (div_le_iff₀ hm).mp hsq
    linarith [mul_comm (Real.sqrt u) m]

/-- The mixed error `C₂/u + C₁/√u` fits a room `m > 0` once `u ≥ 2C₂/m` and `u ≥ (2C₁/m)²`
(no sign condition on `C₂` is needed here). -/
theorem margin_mixed {C₁ C₂ m u : ℝ} (h1 : 0 ≤ C₁) (hm : 0 < m) (hu : 0 < u)
    (hu2 : 2 * C₂ / m ≤ u) (hu1 : (2 * C₁ / m) ^ 2 ≤ u) :
    C₂ / u + C₁ / Real.sqrt u ≤ m := by
  have a1 : C₁ / Real.sqrt u ≤ m / 2 := by
    have hrw : C₁ / (m / 2) = 2 * C₁ / m := by rw [div_div_eq_mul_div]; ring
    exact margin_sqrt h1 (by linarith) (by rw [hrw]; exact hu1)
  have a2 : C₂ / u ≤ m / 2 := by
    rw [div_le_iff₀ hu]
    have h := (div_le_iff₀ hm).mp hu2
    nlinarith [h]
  linarith

/-- The per-step hypotheses with the mixed error `C₂/u + C₁/√u`: the monotonicity field is
automatic, and the margin holds for `u⋆` past the explicit thresholds of `margin_mixed`. -/
theorem stepsE_of_mixed {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {C₁ C₂ b binf bp D₀ ρ A B Y ustar : ℝ}
    (h1 : 0 ≤ C₁) (h2 : 0 ≤ C₂) (hY : Y < binf) (hu : 0 < ustar)
    (hu2 : 2 * C₂ / (binf - Y) ≤ ustar) (hu1 : (2 * C₁ / (binf - Y)) ^ 2 ≤ ustar)
    (hD : ∀ s, ustar ≤ s → 0 ≤ Dfun s) (hρ : 0 ≤ ρ) (hA : 0 ≤ A) (hB : 0 ≤ B)
    (flow : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → u (k + 1) x = u k x - b + rs k x + rl k x)
    (small_net : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      binf + δ k - (C₂ / u k x + C₁ / Real.sqrt (u k x)) ≤ b - rs k x ∧
        b - rs k x ≤ bp + (C₂ / u k x + C₁ / Real.sqrt (u k x)))
    (transient : ∀ n, ∑ k ∈ Finset.range n, max (-δ k) 0 ≤ D₀)
    (large_rem : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → |rl k x| ≤ Dfun (u k x) * z k x)
    (act_rec : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) →
      z (k + 1) x ≤ ρ * z k x + A * w k x + B * z k x ^ 2)
    (act_nonneg : ∀ k x, 0 ≤ z k x)
    (act_init : ∀ x, ustar ≤ u 0 x → z 0 x ≤ W (u 0 x))
    (supply : ∀ k x, (∀ j ≤ k, ustar ≤ u j x) → w k x ≤ Φ (u k x))
    (fix_shift : ∀ s s', ustar ≤ s → ustar ≤ s' → s' ≤ s + D₀ →
      ρ * W s + A * Φ s + B * W s ^ 2 ≤ W s')
    (DW : ∀ s, ustar ≤ s → Dfun s * W s ≤ Y) :
    CouplingStepsTransientE u z w rs rl Φ W Dfun δ (fun s => C₂ / s + C₁ / Real.sqrt s)
      b binf bp D₀ ρ A B Y ustar where
  ustar_pos := hu
  he := error_mixed_antitone h1 h2 hu
  hD := hD
  hρ := hρ
  hA := hA
  hB := hB
  flow := flow
  small_net := small_net
  transient := transient
  large_rem := large_rem
  act_rec := act_rec
  act_nonneg := act_nonneg
  act_init := act_init
  supply := supply
  fix_shift := fix_shift
  DW := DW
  margin := by
    have hm : 0 < binf - Y := by linarith
    have := margin_mixed h1 hm hu hu2 hu1
    show C₂ / ustar + C₁ / Real.sqrt ustar + Y ≤ binf
    linarith

/-! ## The chain end to end with an antitone error -/

section Chain

variable {X : Type*} [PseudoMetricSpace X]
variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)]

/-- The chain structure of `TransientChain` at the widened bracket, built from the per-step
hypotheses with an antitone error and the remaining (error-free) fields. -/
theorem chainHypotheses_of_error {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    {ν : ℕ → ∀ m, Measure (E m)} {ι : ℕ → Type*} {R : ∀ m, Finset (ι m)}
    {I : ∀ m, ι m → E m → ℝ} {θh : ℕ → ℝ} {ε : ℕ → ℝ≥0∞}
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : CouplingStepsTransientE u z w rs rl Φ W Dfun δ e b binf bp D₀ ρ A B Y ustar)
    (prob : ∀ n m, IsProbabilityMeasure (ν n m))
    (rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ν n m {ω | θh m < I m i ω} ≤ ε m)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d')) :
    TransientChain.ChainHypothesesTransient u z w rs rl Φ W Dfun δ b (binf - e ustar)
      (bp + e ustar) 0 D₀ ρ A B Y ustar ν R I θh ε Dset s τ Ωr :=
  ⟨transient_of_error HE, prob, rarity, lattice_vanishing, shift_vanishing, split⟩

end Chain

section EndToEnd

variable {E : ℕ → Type*} [∀ m, MeasurableSpace (E m)] [∀ m, MetricSpace (E m)]
  [∀ m, CompactSpace (E m)] [∀ m, BorelSpace (E m)]
variable {X : Type*} [MetricSpace X]

/-- Chain end to end with an antitone error function `e` in place of `C₂/u`: the conclusion of
`TransientChain.chain_end_to_end_transient`, with (W0) for every target `t ≥ u⋆ + D₀` and the
bracket `t + (binf − (e(u⋆) + Y))n − D₀ ≤ x ≤ t + (bp + (e(u⋆) + Y))n`. With
`e(s) = C₂/s + C₁/√s` (`stepsE_of_mixed`) a small-field remainder of order `g` is allowed. -/
theorem chain_end_to_end_error
    {u z w rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    (νP : ℕ → ∀ m, ProbabilityMeasure (E m))
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → E m → ℝ) (f : ∀ m, Pt m → E m → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : CouplingStepsTransientE u z w rs rl Φ W Dfun δ e b binf bp D₀ ρ A B Y ustar)
    (rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (νP n m : Measure (E m)) {ω | (1 / 2 : ℝ) <
        TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m) ω} ≤
        (np m : ℝ≥0∞) * P₁ m + npt m * S m)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d'))
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Bm : ∀ m, E (m + 1) → E m) (hB : ∀ m, Continuous (Bm m))
    (Θ : ∀ m, E m → E m) (Aset : ∀ m, Set (BoundedContinuousFunction (E m) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, E m → E m) (Cset : ∀ m, Set (E m))
    (hcons : ∀ m, ∀ᶠ n in atTop, (νP n (m + 1)).map (hB m).measurable.aemeasurable = νP n m)
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP n m : Measure (E m)))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (E m) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP n m : Measure (E m)) = ∫ ω, F ω ∂(νP n m : Measure (E m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (E (lev x)) ℝ)
    (HR : WeakUltravioletExistence.Representation νP Dset s lev Fo) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (e ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (e ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (E m),
      (∀ m, Tendsto (fun k => νP (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl Bm hB Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (E (lev d)))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset := by
  have H := chainHypotheses_of_error (ν := fun n m => (νP n m : Measure (E m)))
    (I := fun m i => TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m)
      (θ m))
    (θh := fun _ => (1 / 2 : ℝ)) (ε := fun m => (np m : ℝ≥0∞) * P₁ m + npt m * S m)
    HE (fun n m => inferInstance) rarity lattice_vanishing shift_vanishing split
  have key := TransientChain.chain_end_to_end_transient νP R plaq pts Yf f yh θ P₁ S np npt H h0
    hCu Bm hB Θ Aset actb Cset hcons hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd
    hac ham hbr hbv hpos lev Fo HR
  have e1 : binf - e ustar - (0 / ustar + Y) = binf - (e ustar + Y) := by rw [zero_div]; ring
  have e2 : bp + e ustar + (0 / ustar + Y) = bp + (e ustar + Y) := by rw [zero_div]; ring
  rw [e1, e2] at key
  exact key

end EndToEnd

end TransientChainError



/-!
# L1: the concrete block map `Bm := retract ∘ avg` and the seam (R0) of the chain

Correspondence with the paper (for checking):
* `blockMap` = the coarse field of the fix (F-b).md` §10.5 and
  WALL1 §8.37: on each coarse link `b`, the weighted average of oriented path products of the fine
  links (paper A, definition 2.1; the weights and the path family are left as data here, the
  family `(1/8, 3/4, 1/8)` is one instance), followed by the radial retraction
  `ra(q) = q / max(|q|, r₀)` (`retract`, same definition as `LatticeBlockReflection.retract`).
* `continuous_blockMap` = the field `hB : ∀ m, Continuous (Bm m)` of
  `TransientChainError.chain_end_to_end_error` (stage 1), for this concrete map.
* `down n m` = the coarse field at level `m` of the induction started at the finest level `n`,
  defined by composing the block maps (this is (F-b): the induction's coarse field is *defined*
  as the chain's map). `down_succ` is (R0): `down n m = Bm m ∘ down n (m+1)` for `m < n`.
* `hcons_blockMap` = the field `hcons` of `chain_end_to_end_error` for the push-forwards
  `νP n m := (μ n).map (down n m)` of an arbitrary family of fine measures `μ n`.
* `blockMap_of_small_field` = on the small-field event `r₀ ≤ |q|` the value is the projection
  `q/|q|` used by the induction (unit quaternion = SU(2)); `blockMap_of_lt` = for `|q| < r₀` the
  value lies strictly inside the ball (the extra configurations that (F-b) moves into the
  large-field polymers, `chain-gaps.md` §10.5 (N3-1)).
-/

namespace ChainBlockMap

open MeasureTheory Filter Topology

local notation "ℍr" => Quaternion ℝ

noncomputable instance instMeasurableSpaceQuaternion : MeasurableSpace ℍr := borel ℍr
instance instBorelSpaceQuaternion : BorelSpace ℍr := ⟨rfl⟩

/-- Values of a link variable: the closed unit ball of the quaternions (SU(2) is its boundary). -/
abbrev Ball := Metric.closedBall (0 : ℍr) 1

/-- Configurations on a finite set of links. -/
abbrev Cfg (L : Type*) := L → Ball

theorem mem_ball_iff (q : ℍr) : q ∈ Metric.closedBall (0 : ℍr) 1 ↔ ‖q‖ ≤ 1 :=
  mem_closedBall_zero_iff

/-! ## 1. Radial retraction -/

/-- Radial retraction `ra(q) = q / max(‖q‖, r₀)`. -/
noncomputable def retract (r₀ : ℝ) (q : ℍr) : ℍr := (max ‖q‖ r₀)⁻¹ • q

theorem continuous_retract {r₀ : ℝ} (hr : 0 < r₀) : Continuous (retract r₀) := by
  unfold retract
  have hmax : Continuous fun q : ℍr => max ‖q‖ r₀ := continuous_norm.max continuous_const
  exact (hmax.inv₀ (fun q => ne_of_gt (lt_of_lt_of_le hr (le_max_right _ _)))).smul continuous_id

theorem norm_retract {r₀ : ℝ} (hr : 0 < r₀) (q : ℍr) : ‖retract r₀ q‖ = ‖q‖ / max ‖q‖ r₀ := by
  have hpos : 0 < max ‖q‖ r₀ := lt_of_lt_of_le hr (le_max_right _ _)
  rw [retract, norm_smul, Real.norm_eq_abs, abs_inv, abs_of_pos hpos, inv_mul_eq_div]

theorem norm_retract_le {r₀ : ℝ} (hr : 0 < r₀) (q : ℍr) : ‖retract r₀ q‖ ≤ 1 := by
  have hpos : 0 < max ‖q‖ r₀ := lt_of_lt_of_le hr (le_max_right _ _)
  rw [norm_retract hr, div_le_one hpos]
  exact le_max_left _ _

/-- Small field `r₀ ≤ ‖q‖`: the retraction is the projection `q/‖q‖`, a unit quaternion. -/
theorem retract_of_le {r₀ : ℝ} (hr : 0 < r₀) {q : ℍr} (hq : r₀ ≤ ‖q‖) :
    retract r₀ q = ‖q‖⁻¹ • q ∧ ‖retract r₀ q‖ = 1 := by
  have hmax : max ‖q‖ r₀ = ‖q‖ := max_eq_left hq
  have hpos : 0 < ‖q‖ := lt_of_lt_of_le hr hq
  refine ⟨by simp [retract, hmax], ?_⟩
  rw [norm_retract hr, hmax, div_self hpos.ne']

/-- Inside `‖q‖ < r₀`: the retraction is `q/r₀`, of norm `‖q‖/r₀ < 1`. -/
theorem retract_of_lt {r₀ : ℝ} (hr : 0 < r₀) {q : ℍr} (hq : ‖q‖ < r₀) :
    retract r₀ q = r₀⁻¹ • q ∧ ‖retract r₀ q‖ = ‖q‖ / r₀ ∧ ‖retract r₀ q‖ < 1 := by
  have hmax : max ‖q‖ r₀ = r₀ := max_eq_right hq.le
  refine ⟨by simp [retract, hmax], by rw [norm_retract hr, hmax], ?_⟩
  rw [norm_retract hr, hmax, div_lt_one hr]
  exact hq

/-! ## 2. Oriented path products and the weighted average -/

section Average

variable {L : Type*}

/-- Value of an oriented step: `U ℓ` forward (`false`), `U ℓ*` backward (`true`). -/
noncomputable def stepVal (U : L → ℍr) (s : L × Bool) : ℍr := if s.2 then star (U s.1) else U s.1

/-- Ordered product along a path. -/
noncomputable def pathProd (U : L → ℍr) (γ : List (L × Bool)) : ℍr := (γ.map (stepVal U)).prod

/-- Weighted average over a finite family of paths. -/
noncomputable def avg (U : L → ℍr) (P : Finset (List (L × Bool))) (w : List (L × Bool) → ℝ) : ℍr :=
  ∑ γ ∈ P, w γ • pathProd U γ

theorem continuous_stepVal (s : L × Bool) : Continuous fun U : L → ℍr => stepVal U s := by
  unfold stepVal
  split_ifs
  · exact continuous_star.comp (continuous_apply s.1)
  · exact continuous_apply s.1

theorem continuous_pathProd (γ : List (L × Bool)) : Continuous fun U : L → ℍr => pathProd U γ := by
  induction γ with
  | nil => simpa [pathProd] using continuous_const
  | cons s rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    exact (continuous_stepVal s).mul ih

theorem continuous_avg (P : Finset (List (L × Bool))) (w : List (L × Bool) → ℝ) :
    Continuous fun U : L → ℍr => avg U P w :=
  continuous_finsetSum _ (fun γ _ => (continuous_pathProd γ).const_smul (w γ))

theorem norm_stepVal_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (s : L × Bool) : ‖stepVal U s‖ ≤ 1 := by
  unfold stepVal
  split_ifs
  · rw [norm_star]; exact hU s.1
  · exact hU s.1

theorem norm_pathProd_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (γ : List (L × Bool)) :
    ‖pathProd U γ‖ ≤ 1 := by
  induction γ with
  | nil => simp [pathProd]
  | cons s rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [norm_mul]
    exact mul_le_one₀ (norm_stepVal_le hU s) (norm_nonneg _) ih

/-- With ball-valued links, `‖avg‖ ≤ Σ |w γ|` (so `≤ 1` for a convex family). -/
theorem norm_avg_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (P : Finset (List (L × Bool)))
    (w : List (L × Bool) → ℝ) : ‖avg U P w‖ ≤ ∑ γ ∈ P, |w γ| := by
  unfold avg
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun γ _ => ?_)
  rw [norm_smul, Real.norm_eq_abs]
  exact mul_le_of_le_one_right (abs_nonneg _) (norm_pathProd_le hU γ)

/-! ### The family of the induction: six orders, weights `(1/8, 3/4, 1/8)` per transverse slot

`sixAvg P U = Σ_o Σ_A (1/6) Π_t wt (A t) · pathProd U (P o A)`, as in `LatticePath.walk`
(the order `o : Fin 6`, the displacement indices `A : Fin 3 → Fin 3`). It is a weighted average
of path products, with nonnegative weights of total mass one. -/

/-- Weights `(α, 1 − 2α, α)`, `α = 1/8` (= `LatticePath.wt`). -/
noncomputable def wt : Fin 3 → ℝ := ![1 / 8, 3 / 4, 1 / 8]

/-- Weight of the path with order `o` and displacements `A`. -/
noncomputable def sixWeight (A : Fin 3 → Fin 3) : ℝ := (1 / 6) * ∏ t, wt (A t)

noncomputable def sixAvg (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) : ℍr :=
  ∑ o, ∑ A, sixWeight A • pathProd U (P o A)

theorem wt_nonneg (a : Fin 3) : 0 ≤ wt a := by
  fin_cases a <;> norm_num [wt]

theorem wt_sum : ∑ a, wt a = 1 := by
  simp [wt, Fin.sum_univ_three]; norm_num

theorem sixWeight_nonneg (A : Fin 3 → Fin 3) : 0 ≤ sixWeight A :=
  mul_nonneg (by norm_num) (Finset.prod_nonneg fun t _ => wt_nonneg _)

/-- Total mass one. -/
theorem sixWeight_total : ∑ _o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A = 1 := by
  have h : ∑ A : Fin 3 → Fin 3, ∏ t, wt (A t) = 1 := by
    rw [← Fintype.prod_sum (fun _ : Fin 3 => wt)]
    simp [wt_sum]
  simp only [sixWeight, ← Finset.mul_sum, h, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
  norm_num

theorem continuous_sixAvg (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) :
    Continuous fun U : L → ℍr => sixAvg P U :=
  continuous_finsetSum _ fun o _ => continuous_finsetSum _ fun A _ =>
    (continuous_pathProd (P o A)).const_smul (sixWeight A)

/-- With ball-valued links the six-order average stays in the unit ball. -/
theorem norm_sixAvg_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1)
    (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) : ‖sixAvg P U‖ ≤ 1 := by
  unfold sixAvg
  calc ‖∑ o, ∑ A, sixWeight A • pathProd U (P o A)‖
      ≤ ∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A := by
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun o _ => ?_)
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun A _ => ?_)
        rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (sixWeight_nonneg A)]
        exact mul_le_of_le_one_right (sixWeight_nonneg A) (norm_pathProd_le hU _)
    _ = 1 := sixWeight_total

/-! ### Reversed paths: the reversed coarse link carries the conjugate  -/

/-- Walk a path backwards: reverse the order and flip each orientation. -/
def revPath (γ : List (L × Bool)) : List (L × Bool) := (γ.map fun s => (s.1, !s.2)).reverse

theorem revPath_revPath (γ : List (L × Bool)) : revPath (revPath γ) = γ := by
  simp [revPath, List.map_reverse, Function.comp_def]

theorem revPath_injective : Function.Injective (revPath (L := L)) :=
  Function.LeftInverse.injective revPath_revPath

theorem stepVal_flip (U : L → ℍr) (s : L × Bool) : stepVal U (s.1, !s.2) = star (stepVal U s) := by
  unfold stepVal
  cases s.2 <;> simp

theorem revPath_cons (s : L × Bool) (γ : List (L × Bool)) :
    revPath (s :: γ) = revPath γ ++ [(s.1, !s.2)] := by
  simp [revPath]

theorem pathProd_append (U : L → ℍr) (γ δ : List (L × Bool)) :
    pathProd U (γ ++ δ) = pathProd U γ * pathProd U δ := by
  simp [pathProd, List.map_append, List.prod_append]

/-- The product along the reversed path is the conjugate (the conjugate reverses products). -/
theorem pathProd_rev (U : L → ℍr) (γ : List (L × Bool)) :
    pathProd U (revPath γ) = star (pathProd U γ) := by
  induction γ with
  | nil => simp [revPath, pathProd]
  | cons s γ ih =>
    rw [revPath_cons, pathProd_append, ih]
    have h1 : pathProd U [(s.1, !s.2)] = star (stepVal U s) := by
      simp only [pathProd, List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, mul_one]
      exact stepVal_flip U s
    have h2 : pathProd U (s :: γ) = stepVal U s * pathProd U γ := by
      simp [pathProd]
    rw [h1, h2, star_mul]

/-- The reversal as an embedding (so no decidable equality on paths is needed). -/
def revEmb : List (L × Bool) ↪ List (L × Bool) := ⟨revPath, revPath_injective⟩

/-- Averages over the reversed family (same weights) give the conjugate. -/
theorem avg_rev (U : L → ℍr) (P : Finset (List (L × Bool))) (w w' : List (L × Bool) → ℝ)
    (hw : ∀ γ, w' (revPath γ) = w γ) :
    avg U (P.map revEmb) w' = star (avg U P w) := by
  unfold avg
  rw [Finset.sum_map, star_sum]
  refine Finset.sum_congr rfl fun γ _ => ?_
  simp only [revEmb, Function.Embedding.coeFn_mk]
  rw [hw, pathProd_rev, Quaternion.star_smul]

theorem sixAvg_rev (P P' : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool))
    (hP : ∀ o A, P' o A = revPath (P o A)) (U : L → ℍr) :
    sixAvg P' U = star (sixAvg P U) := by
  unfold sixAvg
  simp only [star_sum, Quaternion.star_smul, hP, pathProd_rev]

end Average

/-! ## 3. The block map between ball-valued configurations -/

section Block

variable {Lk : ℕ → Type*}
  (r₀ : ℝ) (hr : 0 < r₀)
  (paths : ∀ m, Lk m → Finset (List (Lk (m + 1) × Bool)))
  (w : ∀ m, Lk m → List (Lk (m + 1) × Bool) → ℝ)

/-- The coarse value `q_b(U)` before the retraction. -/
noncomputable def coarseAvg (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m) : ℍr :=
  avg (fun ℓ => (U ℓ : ℍr)) (paths m b) (w m b)

include hr in
/-- The block map `Bm m := retract ∘ avg`, as a map of ball-valued configurations. -/
noncomputable def blockMap (m : ℕ) (U : Cfg (Lk (m + 1))) : Cfg (Lk m) :=
  fun b => ⟨retract r₀ (coarseAvg paths w m U b),
    (mem_ball_iff _).2 (norm_retract_le hr _)⟩

theorem continuous_coarseAvg (m : ℕ) (b : Lk m) :
    Continuous fun U : Cfg (Lk (m + 1)) => coarseAvg paths w m U b :=
  (continuous_avg (paths m b) (w m b)).comp
    (continuous_pi fun ℓ => continuous_subtype_val.comp (continuous_apply ℓ))

/-- The field `hB` of the chain for the concrete block map. -/
theorem continuous_blockMap (m : ℕ) : Continuous (blockMap r₀ hr paths w m) := by
  refine continuous_pi fun b => ?_
  exact ((continuous_retract hr).comp (continuous_coarseAvg paths w m b)).subtype_mk _

/-- On the small-field event the block map is the projection `q/‖q‖` of the induction. -/
theorem blockMap_of_small_field (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m)
    (hq : r₀ ≤ ‖coarseAvg paths w m U b‖) :
    (blockMap r₀ hr paths w m U b : ℍr) =
        ‖coarseAvg paths w m U b‖⁻¹ • coarseAvg paths w m U b ∧
      ‖(blockMap r₀ hr paths w m U b : ℍr)‖ = 1 :=
  retract_of_le hr hq

/-- Off the small-field event the value lies strictly inside the ball. -/
theorem blockMap_of_lt (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m)
    (hq : ‖coarseAvg paths w m U b‖ < r₀) :
    (blockMap r₀ hr paths w m U b : ℍr) = r₀⁻¹ • coarseAvg paths w m U b ∧
      ‖(blockMap r₀ hr paths w m U b : ℍr)‖ < 1 :=
  ⟨(retract_of_lt hr hq).1, (retract_of_lt hr hq).2.2⟩

/-- The retraction commutes with the conjugation. -/
theorem retract_star (r₀ : ℝ) (q : ℍr) : retract r₀ (star q) = star (retract r₀ q) := by
  simp only [retract, norm_star, Quaternion.star_smul]

/-- (B5) for reversed coarse links: if the family of the reversed link `rev b` consists of the
reversed paths with the same weights, its coarse value is the conjugate. -/
theorem blockMap_rev (rev : ∀ m, Lk m → Lk m) (m : ℕ) (b : Lk m)
    (hP : paths m (rev m b) = (paths m b).map revEmb)
    (hw : ∀ γ, w m (rev m b) (revPath γ) = w m b γ) (U : Cfg (Lk (m + 1))) :
    (blockMap r₀ hr paths w m U (rev m b) : ℍr) = star (blockMap r₀ hr paths w m U b : ℍr) := by
  simp only [blockMap, coarseAvg, hP, avg_rev _ _ _ _ hw, retract_star]

/-! ## 4. The coarse fields of the induction: composition of block maps (fix (F-b)) -/

/-- Auxiliary: from the finest level `n` down `k` steps to level `m` (`m + k = n`). -/
noncomputable def downAux (n : ℕ) : ∀ (k m : ℕ), m + k = n → Cfg (Lk n) → Cfg (Lk m)
  | 0, m, h, U => cast (congrArg (fun j => Cfg (Lk j)) (show n = m by omega)) U
  | k + 1, m, h, U => blockMap r₀ hr paths w m (downAux n k (m + 1) (by omega) U)

/-- A fixed configuration, used for `m > n` (never used by the chain, which only needs large `n`). -/
noncomputable def oneCfg (L : Type*) : Cfg L := fun _ => ⟨1, (mem_ball_iff _).2 (by simp)⟩

/-- The coarse field at level `m` of the induction started at the finest level `n`. -/
noncomputable def down (n m : ℕ) (U : Cfg (Lk n)) : Cfg (Lk m) :=
  if h : m ≤ n then downAux r₀ hr paths w n (n - m) m (by omega) U else oneCfg (Lk m)

theorem downAux_congr (n : ℕ) {k k' m : ℕ} (hk : k = k') (h : m + k = n) (h' : m + k' = n)
    (U : Cfg (Lk n)) : downAux r₀ hr paths w n k m h U = downAux r₀ hr paths w n k' m h' U := by
  subst hk; rfl

/-- (R0) holds by definition: `down n m = Bm m ∘ down n (m+1)` for `m < n`. -/
theorem down_succ {n m : ℕ} (hmn : m < n) (U : Cfg (Lk n)) :
    down r₀ hr paths w n m U = blockMap r₀ hr paths w m (down r₀ hr paths w n (m + 1) U) := by
  have h1 : m ≤ n := hmn.le
  have h2 : m + 1 ≤ n := hmn
  simp only [down, dif_pos h1, dif_pos h2]
  rw [downAux_congr r₀ hr paths w n (show n - m = (n - (m + 1)) + 1 by omega) _ (by omega)]
  rfl

theorem down_self (n : ℕ) (U : Cfg (Lk n)) : down r₀ hr paths w n n U = U := by
  simp only [down, dif_pos le_rfl]
  rw [downAux_congr r₀ hr paths w n (show n - n = 0 by omega) _ (by omega)]
  exact cast_eq _ _

theorem continuous_downAux (n : ℕ) :
    ∀ (k m : ℕ) (h : m + k = n), Continuous (downAux r₀ hr paths w n k m h) := by
  intro k
  induction k with
  | zero =>
    intro m h
    subst h
    exact continuous_id.congr (fun U => (cast_eq _ U).symm)
  | succ k ih =>
    intro m h
    exact (continuous_blockMap r₀ hr paths w m).comp (ih (m + 1) (by omega))

theorem continuous_down (n m : ℕ) : Continuous (down r₀ hr paths w n m) := by
  by_cases h : m ≤ n
  · have : down r₀ hr paths w n m = downAux r₀ hr paths w n (n - m) m (by omega) := by
      funext U; simp only [down, dif_pos h]
    rw [this]
    exact continuous_downAux r₀ hr paths w n _ _ _
  · have : down r₀ hr paths w n m = fun _ : Cfg (Lk n) => oneCfg (Lk m) := by
      funext U; simp only [down, dif_neg h]
    rw [this]
    exact continuous_const

/-! ## 5. The field `hcons` of the chain for the push-forwards -/

variable [∀ m, Fintype (Lk m)]

/-- `νP n m := (μ n).map (down n m)`: the law of the coarse field at level `m`. -/
noncomputable def νP (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) (n m : ℕ) :
    ProbabilityMeasure (Cfg (Lk m)) :=
  (μ n).map (continuous_down r₀ hr paths w n m).measurable.aemeasurable

/-- The field `hcons` of `chain_end_to_end_error` with `Bm := blockMap`, for every family of fine
measures `μ n`. -/
theorem hcons_blockMap (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) :
    ∀ m, ∀ᶠ n in atTop,
      (νP r₀ hr paths w μ n (m + 1)).map
          (continuous_blockMap r₀ hr paths w m).measurable.aemeasurable =
        νP r₀ hr paths w μ n m := by
  intro m
  filter_upwards [eventually_gt_atTop m] with n hmn
  apply ProbabilityMeasure.toMeasure_injective
  simp only [νP, ProbabilityMeasure.toMeasure_map]
  rw [Measure.map_map (continuous_blockMap r₀ hr paths w m).measurable
    (continuous_down r₀ hr paths w n (m + 1)).measurable]
  congr 1
  funext U
  exact (down_succ r₀ hr paths w hmn U).symm

/-- At the finest level the coarse field is the configuration itself. -/
theorem νP_self (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) (n : ℕ) :
    νP r₀ hr paths w μ n n = μ n := by
  apply ProbabilityMeasure.toMeasure_injective
  simp only [νP, ProbabilityMeasure.toMeasure_map]
  have : down r₀ hr paths w n n = id := funext (down_self r₀ hr paths w n)
  rw [this, Measure.map_id]

end Block

/-! ## 6. Axioms -/


end ChainBlockMap

/-! # L1 (continued): the chain of stage 1 on the concrete block map

`chain_end_to_end_blockMap` is `TransientChainError.chain_end_to_end_error` with
`E m := Cfg (Lk m)` (ball-valued link configurations), `Bm := blockMap` (retraction after the
average of path products), `hB := continuous_blockMap` and `νP n m := (μ n).map (down n m)`; the
field `hcons` is discharged by `hcons_blockMap`. Paper: stage 1 of the proof ladder with the fix
(F-b) (`chain-gaps.md` §10.5); the remaining fields are the stage-2 inputs unchanged. -/

namespace ChainBlockMap

open Filter Topology MeasureTheory Set
open scoped ENNReal

variable {Lk : ℕ → Type*} [∀ m, Fintype (Lk m)]
variable {X : Type*} [MetricSpace X]

theorem chain_end_to_end_blockMap
    (r₀ : ℝ) (hr : 0 < r₀)
    (paths : ∀ m, Lk m → Finset (List (Lk (m + 1) × Bool)))
    (w : ∀ m, Lk m → List (Lk (m + 1) × Bool) → ℝ)
    (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n)))
    {u z w' rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    {ι Pl Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Pl m)) (pts : ∀ m, ι m → Finset (Pt m))
    (Yf : ∀ m, Pl m → Cfg (Lk m) → ℝ) (f : ∀ m, Pt m → Cfg (Lk m) → ℝ) (yh θ : ℕ → ℝ)
    (P₁ S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : TransientChainError.CouplingStepsTransientE u z w' rs rl Φ W Dfun δ e b binf bp D₀ ρ A
      B Y ustar)
    (rarity : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (νP r₀ hr paths w μ n m : Measure (Cfg (Lk m))) {ω | (1 / 2 : ℝ) <
        TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (Yf m) (f m) (yh m) (θ m) ω} ≤
        (np m : ℝ≥0∞) * P₁ m + npt m * S m)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d'))
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Θ : ∀ m, Cfg (Lk m) → Cfg (Lk m)) (Aset : ∀ m, Set (BoundedContinuousFunction (Cfg (Lk m)) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, Cfg (Lk m) → Cfg (Lk m)) (Cset : ∀ m, Set (Cfg (Lk m)))
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP r₀ hr paths w μ n m : Measure (Cfg (Lk m))))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (Lk m)) ℝ,
      ∫ ω, F (actb g m ω) ∂(νP r₀ hr paths w μ n m : Measure (Cfg (Lk m))) =
        ∫ ω, F ω ∂(νP r₀ hr paths w μ n m : Measure (Cfg (Lk m))))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, Yf m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (Cfg (Lk (lev x))) ℝ)
    (HR : WeakUltravioletExistence.Representation (νP r₀ hr paths w μ) Dset s lev Fo) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (e ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (e ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk m)),
      (∀ m, Tendsto (fun k => νP r₀ hr paths w μ (φ k) m) atTop (𝓝 (νl m))) ∧
      WeakUltravioletExistence.BlockConclusion νl (blockMap r₀ hr paths w)
        (continuous_blockMap r₀ hr paths w) Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * P₁ m + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (Cfg (Lk (lev d))))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset :=
  TransientChainError.chain_end_to_end_error (νP r₀ hr paths w μ) R plaq pts Yf f yh θ P₁ S np npt
    HE rarity lattice_vanishing shift_vanishing split h0 hCu (blockMap r₀ hr paths w)
    (continuous_blockMap r₀ hr paths w) Θ Aset actb Cset (hcons_blockMap r₀ hr paths w μ) hΘc hΘp
    hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd hac ham hbr hbv hpos lev Fo HR


end ChainBlockMap

/-! # L1 : the paths of the induction (`LatticePath.walk`, ℤ⁴) on the finite box

Paper: plan-01 §1 / : the induction's family is `LatticePath.walk μ o A` (six
orders, weights `(1/8, 3/4, 1/8)`, spine of two steps, reversed return) on `ℤ⁴`. Here it is carried
to the fine links of a finite box by an additive map `φ : ℤ⁴ →+ G` (e.g. the reduction to
`(ZMod N)⁴`) and a base point (the fine image of the coarse site): a signed link `(s, z, n)` goes to
the fine link `(x + φ z, n)` with orientation `s = −1` (backward, `star`). The definitions `tr`,
`ord`, `dv`, `ev`, `Link`, `fwd`, `back`, `walk` are copied from an earlier file (text-matched). Lean:
`walk_sign` (every step has sign `±1`, so the orientation flag is faithful), `walk_end` (copied),
**`walkCast_end`** (the cast path closes on `x + 2 φ(e_μ)`), and **`blockMap_walk`** (the block map
with these paths is continuous and is the projection on the small-field event). -/

namespace WalkCast

open Finset

def tr : Fin 4 → Fin 3 → Fin 4 := ![![1, 2, 3], ![0, 2, 3], ![0, 1, 3], ![0, 1, 2]]

/-- The six orders of the three transverse slots. -/
def ord : Fin 6 → Fin 3 → Fin 3 :=
  ![![0, 1, 2], ![0, 2, 1], ![1, 0, 2], ![1, 2, 0], ![2, 0, 1], ![2, 1, 0]]

/-- Displacement values and weights `(α, 1 − 2α, α)`, `α = 1/8`. -/
def dv : Fin 3 → ℤ := ![-1, 0, 1]
def ev (n : Fin 4) : Fin 4 → ℤ := Pi.single n 1

/-- A signed link: (sign, base point, direction). -/
abbrev Link := ℤ × (Fin 4 → ℤ) × Fin 4

/-- A forward transverse step of displacement `d` from `z` in direction `n`. -/
def fwd (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(1, z, n)] else if d = -1 then [(-1, z - ev n, n)] else []

/-- The step undoing it, from the point `w` reached after it. -/
def back (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(-1, w - ev n, n)] else if d = -1 then [(1, w, n)] else []

/-- The path of the coarse link in direction `μ` for the order `o` and the displacement
indices `A` (slot `t` is displaced by `dv (A t)` in direction `tr μ t`). -/
def walk (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : List Link :=
  let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  let z1 := d 0 • ev (n 0)
  let z2 := z1 + d 1 • ev (n 1)
  let z3 := z2 + d 2 • ev (n 2)
  let w3 := z3 + 2 • ev μ
  let w2 := w3 - d 2 • ev (n 2)
  let w1 := w2 - d 1 • ev (n 1)
  fwd (d 0) 0 (n 0) ++ fwd (d 1) z1 (n 1) ++ fwd (d 2) z2 (n 2) ++
    [(1, z3, μ), (1, z3 + ev μ, μ)] ++
    back (d 2) w3 (n 2) ++ back (d 1) w2 (n 1) ++ back (d 0) w1 (n 0)


theorem walk_end (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
    let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
    d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ
      - d 2 • ev (n 2) - d 1 • ev (n 1) - d 0 • ev (n 0) = 2 • ev μ := by
  intro n d
  abel

theorem fwd_sign (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : ∀ l ∈ fwd d z n, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  unfold fwd at hl
  split_ifs at hl <;> simp_all

theorem back_sign (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : ∀ l ∈ back d w n, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  unfold back at hl
  split_ifs at hl <;> simp_all

/-- Every step of the walk has sign `±1`. -/
theorem walk_sign (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    ∀ l ∈ walk μ o A, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  simp only [walk, List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with ((((((h | h) | h) | h | h) | h) | h) | h)
  · exact fwd_sign _ _ _ l h
  · exact fwd_sign _ _ _ l h
  · exact fwd_sign _ _ _ l h
  · left; rw [h]
  · left; rw [h]
  · exact back_sign _ _ _ l h
  · exact back_sign _ _ _ l h
  · exact back_sign _ _ _ l h

variable {G : Type*} [AddCommGroup G]

/-- A signed link of `ℤ⁴` to an oriented fine link of the box. -/
def linkCast (φ : (Fin 4 → ℤ) →+ G) (x : G) (l : Link) : (G × Fin 4) × Bool :=
  ((x + φ l.2.1, l.2.2), decide (l.1 = -1))

/-- The cast path closes on `x + 2 φ(e_μ)`. -/
theorem walkCast_end (φ : (Fin 4 → ℤ) →+ G) (x : G) (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
    let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
    x + φ (d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ
      - d 2 • ev (n 2) - d 1 • ev (n 1) - d 0 • ev (n 0)) = x + 2 • φ (ev μ) := by
  intro n d
  rw [walk_end μ o A, map_nsmul]

/-- The orientation flag is faithful: `true` exactly for the backward steps. -/
theorem linkCast_flag (φ : (Fin 4 → ℤ) →+ G) (x : G) {μ : Fin 4} {o : Fin 6} {A : Fin 3 → Fin 3}
    {l : Link} (hl : l ∈ walk μ o A) :
    ((linkCast φ x l).2 = true ↔ l.1 = -1) ∧ ((linkCast φ x l).2 = false ↔ l.1 = 1) := by
  rcases walk_sign μ o A l hl with h | h <;> simp [linkCast, h]

/-- The paths of the coarse link `b` (direction `dir b`, fine base point `base b`). -/
def pathsCast {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4) (b : Lc)
    (o : Fin 6) (A : Fin 3 → Fin 3) : List ((G × Fin 4) × Bool) :=
  (walk (dir b) o A).map (linkCast φ (base b))

open ChainBlockMap in
/-- **The block map on the box with the induction's paths**: continuous, and on the small-field
event it is the projection `q/|q|` of the induction. -/
theorem blockMap_walk {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    {r₀ : ℝ} (hr : 0 < r₀) (b : Lc) :
    Continuous (fun U : G × Fin 4 → Quaternion ℝ => retract r₀ (sixAvg (pathsCast φ base dir b) U)) ∧
    ∀ U : G × Fin 4 → Quaternion ℝ, r₀ ≤ ‖sixAvg (pathsCast φ base dir b) U‖ →
      retract r₀ (sixAvg (pathsCast φ base dir b) U) =
        ‖sixAvg (pathsCast φ base dir b) U‖⁻¹ • sixAvg (pathsCast φ base dir b) U := by
  refine ⟨(continuous_retract hr).comp (continuous_sixAvg _), fun U hU => ?_⟩
  exact (retract_of_le hr hU).1

end WalkCast


/-! # L1 (round two): the concrete box and the reversed coarse link

Paper (for checking): plan-01 §1, (3), work-06 "紙のまま" of L1, 
* `BoxLk L m` = the oriented-positive links of the periodic box of side `2^m L` at level `m`
  (level `m + 1` is the finer one, side `2^(m+1) L`): a site `y ∈ (ZMod (2^m L))⁴` and a
  direction `μ`. The coarse site `y` sits at the fine site `2y` (`double`, well defined
  `ZMod (2^m L) → ZMod (2^(m+1) L)`), the walk is carried by the reduction `ℤ⁴ → (ZMod (2^(m+1) L))⁴`.
* `boxPaths`/`boxW` turn the indexed family `(o, A) ↦ walk` (with weights `sixWeight A`) into the
  `Finset` family with merged weights used by `ChainBlockMap.blockMap`; `coarseAvg_box` says the
  coarse value is exactly the six-order average of the walk (`sixAvg`).
* `walkRev` = the same recipe for the reversed coarse link `−b` (from `y + e_μ` to `y`): the same
  transverse steps in the same order, the spine two steps in `−μ`, the same return.
  `walk_flip_rev` (on `ℤ⁴`): the reversal of `walk` is `walkRev` shifted by `2 e_μ`.
  **`boxMap_rev`**: the coarse value of `−b` by this recipe is the conjugate of the value of `b`
  (this discharges the hypotheses `hP`, `hw` of `ChainBlockMap.blockMap_rev` on the walk).
* `boxWalk_end`: the cast walk of `b = (y, μ)` ends at the fine image `2(y + e_μ)` of the next
  coarse site, which is also the base point of the reversed recipe.
-/

namespace BoxWalk

open WalkCast ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

/-! ## 1. The reversed recipe on `ℤ⁴` -/

/-- Flip the orientation of a signed link. -/
def flipL (l : Link) : Link := (-l.1, l.2)

/-- Translate a signed link. -/
def shiftL (v : Fin 4 → ℤ) (l : Link) : Link := (l.1, l.2.1 + v, l.2.2)

/-- The recipe of `walk` for the reversed coarse link (direction `−μ`), started at the origin
(= the coarse end point): same transverse steps, spine `−μ` twice, same return. -/
def walkRev (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : List Link :=
  let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  let z1 := d 0 • ev (n 0)
  let z2 := z1 + d 1 • ev (n 1)
  let z3 := z2 + d 2 • ev (n 2)
  let w3 := z3 - 2 • ev μ
  let w2 := w3 - d 2 • ev (n 2)
  let w1 := w2 - d 1 • ev (n 1)
  fwd (d 0) 0 (n 0) ++ fwd (d 1) z1 (n 1) ++ fwd (d 2) z2 (n 2) ++
    [(-1, z3 - ev μ, μ), (-1, z3 - 2 • ev μ, μ)] ++
    back (d 2) w3 (n 2) ++ back (d 1) w2 (n 1) ++ back (d 0) w1 (n 0)

theorem fwd_flip_rev (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) :
    ((fwd d z n).map flipL).reverse = back d (z + d • ev n) n := by
  unfold fwd back flipL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp [sub_eq_add_neg]
    · simp [h1, h2]

theorem back_flip_rev (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) :
    ((back d w n).map flipL).reverse = fwd d (w - d • ev n) n := by
  unfold fwd back flipL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp
    · simp [h1, h2]

theorem fwd_shift (d : ℤ) (z v : Fin 4 → ℤ) (n : Fin 4) :
    (fwd d z n).map (shiftL v) = fwd d (z + v) n := by
  unfold fwd shiftL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp only [if_neg (by decide : (-1 : ℤ) ≠ 1), if_true, List.map_cons,
        List.map_nil]
      congr 2; abel
    · simp [h1, h2]

theorem back_shift (d : ℤ) (w v : Fin 4 → ℤ) (n : Fin 4) :
    (back d w n).map (shiftL v) = back d (w + v) n := by
  unfold back shiftL
  by_cases h1 : d = 1
  · subst h1; simp only [if_true, List.map_cons, List.map_nil]
    congr 2; abel
  · by_cases h2 : d = -1
    · subst h2; simp
    · simp [h1, h2]

/-- The core identity with free displacements. -/
theorem flip_rev_core (d0 d1 d2 : ℤ) (n0 n1 n2 μ : Fin 4) :
    (((fwd d0 0 n0 ++ fwd d1 (d0 • ev n0) n1 ++ fwd d2 (d0 • ev n0 + d1 • ev n1) n2 ++
        [(1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2, μ),
          (1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + ev μ, μ)] ++
        back d2 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ) n2 ++
        back d1 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ - d2 • ev n2) n1 ++
        back d0 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ - d2 • ev n2 - d1 • ev n1) n0
        ).map flipL).reverse) =
      (fwd d0 0 n0 ++ fwd d1 (d0 • ev n0) n1 ++ fwd d2 (d0 • ev n0 + d1 • ev n1) n2 ++
        [(-1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - ev μ, μ),
          (-1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ, μ)] ++
        back d2 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ) n2 ++
        back d1 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ - d2 • ev n2) n1 ++
        back d0 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ - d2 • ev n2 - d1 • ev n1) n0
        ).map (shiftL (2 • ev μ)) := by
  simp only [List.map_append, List.reverse_append, fwd_flip_rev, back_flip_rev, fwd_shift,
    back_shift, List.map_cons, List.map_nil, List.reverse_cons, List.reverse_nil, List.nil_append,
    flipL, shiftL, List.append_assoc, List.cons_append, List.singleton_append]
  abel_nf

/-- **The reversal of the walk is the reversed recipe, shifted to the end point `2 e_μ`.** -/
theorem walk_flip_rev (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    ((walk μ o A).map flipL).reverse = (walkRev μ o A).map (shiftL (2 • ev μ)) :=
  flip_rev_core _ _ _ _ _ _ μ

/-! ## 2. Casting to the fine links -/

variable {G : Type*} [AddCommGroup G]

theorem linkCast_shift (φ : (Fin 4 → ℤ) →+ G) (x : G) (v : Fin 4 → ℤ) (l : Link) :
    linkCast φ x (shiftL v l) = linkCast φ (x + φ v) l := by
  simp only [linkCast, shiftL, map_add]
  congr 2
  abel

theorem linkCast_flip (φ : (Fin 4 → ℤ) →+ G) (x : G) {l : Link} (h : l.1 = 1 ∨ l.1 = -1) :
    linkCast φ x (flipL l) = ((linkCast φ x l).1, !(linkCast φ x l).2) := by
  rcases h with h | h <;> simp [linkCast, flipL, h]

/-- The cast of the reversed walk (walked backwards) is the cast of the reversed recipe from
`x + 2 φ(e_μ)`. -/
theorem revPath_walkCast (φ : (Fin 4 → ℤ) →+ G) (x : G) (μ : Fin 4) (o : Fin 6)
    (A : Fin 3 → Fin 3) :
    revPath ((walk μ o A).map (linkCast φ x)) =
      (walkRev μ o A).map (linkCast φ (x + 2 • φ (ev μ))) := by
  have h1 : revPath ((walk μ o A).map (linkCast φ x)) =
      (((walk μ o A).map flipL).reverse).map (linkCast φ x) := by
    rw [revPath, List.map_reverse, List.map_map, List.map_map]
    congr 1
    refine List.map_congr_left fun l hl => ?_
    simp only [Function.comp_apply]
    rw [linkCast_flip φ x (walk_sign μ o A l hl)]
  rw [h1, walk_flip_rev, List.map_map]
  congr 1
  funext l
  simp only [Function.comp_apply, linkCast_shift, map_nsmul]

/-- The family of the reversed coarse link by the same recipe. -/
def pathsCastRev {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    (b : Lc) (o : Fin 6) (A : Fin 3 → Fin 3) : List ((G × Fin 4) × Bool) :=
  (walkRev (dir b) o A).map (linkCast φ (base b + 2 • φ (ev (dir b))))

/-- **The reversed coarse link carries the conjugate** ((3) on the walk). -/
theorem retract_sixAvg_rev {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G)
    (dir : Lc → Fin 4) (r₀ : ℝ) (b : Lc) (U : G × Fin 4 → ℍr) :
    retract r₀ (sixAvg (pathsCastRev φ base dir b) U) =
      star (retract r₀ (sixAvg (pathsCast φ base dir b) U)) := by
  rw [← retract_star]
  congr 1
  exact sixAvg_rev _ _ (fun o A => (revPath_walkCast φ (base b) (dir b) o A).symm) U

/-! ## 3. Indexed families as `Finset` families with merged weights -/

section Merge

variable {L : Type*} [DecidableEq L]

/-- The `Finset` of the paths of an indexed family. -/
def famSet (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) : Finset (List (L × Bool)) :=
  univ.image fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2

/-- Merged weight of a path: the total weight of the indices giving it. -/
noncomputable def famW (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (γ : List (L × Bool)) :
    ℝ :=
  ∑ p ∈ univ.filter (fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2 = γ), sixWeight p.2

theorem avg_famSet (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) :
    avg U (famSet P) (famW P) = sixAvg P U := by
  unfold avg famSet famW sixAvg
  simp only [Finset.sum_smul]
  rw [← Fintype.sum_prod_type' (fun o A => sixWeight A • pathProd U (P o A))]
  rw [← Finset.sum_fiberwise_of_maps_to (s := univ)
    (t := univ.image fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2)
    (g := fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2)
    (fun p _ => Finset.mem_image_of_mem _ (Finset.mem_univ p))]
  refine Finset.sum_congr rfl fun γ _ => Finset.sum_congr rfl fun p hp => ?_
  rw [(Finset.mem_filter.1 hp).2]

end Merge

/-! ## 4. The periodic boxes `(ZMod (2^m L))⁴` -/

section Box

variable (L : ℕ) [NeZero L]

/-- Sites of the box at level `m` (side `2^m L`). -/
abbrev Site (m : ℕ) := Fin 4 → ZMod (2 ^ m * L)

/-- Positively oriented links of the box at level `m`. -/
abbrev BoxLk (m : ℕ) := Site L m × Fin 4

instance (m : ℕ) : NeZero (2 ^ m * L) := ⟨Nat.mul_ne_zero (pow_ne_zero _ two_ne_zero) (NeZero.ne L)⟩

instance (m : ℕ) : Fintype (BoxLk L m) := inferInstance

/-- `ZMod (2^m L) → ZMod (2^(m+1) L)`, `y ↦ 2y` (well defined). -/
def double (m : ℕ) : ZMod (2 ^ m * L) →+ ZMod (2 ^ (m + 1) * L) :=
  ZMod.lift (2 ^ m * L) ⟨(Int.castAddHom (ZMod (2 ^ (m + 1) * L))).comp
      (AddMonoidHom.mulLeft (2 : ℤ)), by
    simp only [AddMonoidHom.coe_comp, Function.comp_apply, AddMonoidHom.coe_mulLeft,
      Int.coe_castAddHom]
    have : ((2 * ((2 ^ m * L : ℕ) : ℤ) : ℤ) : ZMod (2 ^ (m + 1) * L)) =
        ((2 ^ (m + 1) * L : ℕ) : ZMod (2 ^ (m + 1) * L)) := by
      push_cast; ring
    rw [this, ZMod.natCast_self]⟩

theorem double_intCast (m : ℕ) (k : ℤ) :
    double L m (k : ZMod (2 ^ m * L)) = ((2 * k : ℤ) : ZMod (2 ^ (m + 1) * L)) := by
  simp [double, ZMod.lift_coe]

/-- The reduction `ℤ⁴ → (ZMod (2^(m+1) L))⁴` carrying the walk to the fine box. -/
def red (m : ℕ) : (Fin 4 → ℤ) →+ Site L (m + 1) :=
  AddMonoidHom.compLeft (Int.castAddHom (ZMod (2 ^ (m + 1) * L))) (Fin 4)

/-- Fine base point `2y` of the coarse link `(y, μ)`. -/
def base (m : ℕ) (b : BoxLk L m) : Site L (m + 1) := fun i => double L m (b.1 i)

/-- Direction of a link. -/
def dirB (m : ℕ) (b : BoxLk L m) : Fin 4 := b.2

/-- The indexed paths of the coarse link `b` on the fine box. -/
def boxPathsIdx (m : ℕ) (b : BoxLk L m) (o : Fin 6) (A : Fin 3 → Fin 3) :
    List (BoxLk L (m + 1) × Bool) :=
  pathsCast (red L m) (base L m) (dirB L m) b o A

/-- The paths and merged weights of the block map on the box. -/
def boxPaths (m : ℕ) (b : BoxLk L m) : Finset (List (BoxLk L (m + 1) × Bool)) :=
  famSet (boxPathsIdx L m b)

noncomputable def boxW (m : ℕ) (b : BoxLk L m) : List (BoxLk L (m + 1) × Bool) → ℝ :=
  famW (boxPathsIdx L m b)

/-- **The coarse value on the box is the six-order average of the induction's walk.** -/
theorem coarseAvg_box (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    coarseAvg (boxPaths L) (boxW L) m U b = sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr)) :=
  avg_famSet _ _

theorem boxMap_eq {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
      retract r₀ (sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))) := by
  simp only [blockMap, coarseAvg_box]

/-- On the small-field event the box map is the projection `q/|q|` of the induction. -/
theorem boxMap_small {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1)))
    (b : BoxLk L m) (hq : r₀ ≤ ‖sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))‖) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
        ‖sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))‖⁻¹ •
          sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr)) ∧
      ‖(blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr)‖ = 1 := by
  have h := blockMap_of_small_field r₀ hr (boxPaths L) (boxW L) m U b
    (by rwa [coarseAvg_box])
  rwa [coarseAvg_box] at h

/-- **The reversed coarse link on the box**: the recipe from `2(y + e_μ)` in direction `−μ`
gives the conjugate of the box map's value on `b = (y, μ)`. -/
theorem boxMap_rev {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    retract r₀ (sixAvg (pathsCastRev (red L m) (base L m) (dirB L m) b) (fun ℓ => (U ℓ : ℍr))) =
      star (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) := by
  rw [boxMap_eq L hr, retract_sixAvg_rev]
  rfl

/-- **End point**: the cast walk of `(y, μ)` ends at `2(y + e_μ)`, the fine image of the next
coarse site (and the base point of the reversed recipe). -/
theorem boxWalk_end (m : ℕ) (b : BoxLk L m) :
    base L m b + 2 • red L m (ev (dirB L m b)) =
      base L m (b.1 + Pi.single b.2 (1 : ZMod (2 ^ m * L)), b.2) := by
  funext i
  simp only [base, dirB, red, Pi.add_apply, Pi.smul_apply, AddMonoidHom.compLeft_apply,
    Function.comp_apply, Int.coe_castAddHom, map_add, ev]
  by_cases h : i = b.2
  · subst h
    have : double L m (1 : ZMod (2 ^ m * L)) = 2 := by
      have := double_intCast L m 1
      simpa using this
    simp [this]
  · simp [h]

/-- The ball-valued configurations of the box carry the instances the chain needs. -/
example (m : ℕ) : CompactSpace (Cfg (BoxLk L m)) := inferInstance
example (m : ℕ) : BorelSpace (Cfg (BoxLk L m)) := inferInstance

end Box

end BoxWalk


/-! # L1-1 (round two): the chain of stage 1 on the concrete box

Paper: plan-09 §1 L1-1. `E m := Cfg (BoxLk L m)` (ball-valued links of the box of side `2^m L`),
`Bm := blockMap` with the induction's walk (`boxPaths`, `boxW`), `νP n m := (μ n).map (down n m)`.
`chain_end_to_end_box` is `ChainBlockMap.chain_end_to_end_blockMap` at these data (the field `hcons`
is already discharged there; the other fields are the stage-2 inputs, unchanged). `hcons_box` is
the consistency of the push-forwards for the box. -/

namespace BoxWalk

open ChainBlockMap Filter

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) {X : Type*} [MetricSpace X]

theorem hcons_box (μ : ∀ n, MeasureTheory.ProbabilityMeasure (Cfg (BoxLk L n))) :
    ∀ m, ∀ᶠ n in atTop, (νP r₀ hr (boxPaths L) (boxW L) μ n (m + 1)).map
      (continuous_blockMap r₀ hr (boxPaths L) (boxW L) m).measurable.aemeasurable =
        νP r₀ hr (boxPaths L) (boxW L) μ n m :=
  hcons_blockMap r₀ hr (boxPaths L) (boxW L) μ

theorem chain_end_to_end_box :
    type_of% (@chain_end_to_end_blockMap (BoxLk L) _ X _ r₀ hr (boxPaths L) (boxW L)) :=
  @chain_end_to_end_blockMap (BoxLk L) _ X _ r₀ hr (boxPaths L) (boxW L)

end BoxWalk

/-! # L1-5 (round two, part): the reflection `x₀ ↦ −x₀` on the walk family

Paper (for checking): `reflL` reflects a signed link of `ℤ⁴` in the hyperplane
`x₀ = 0`: a link in direction `ν ≠ 0` keeps its sign and moves to `Θz`; a link in direction `0`
moves to `Θz − e₀` and flips its sign. Lean (finite checks by `decide`):
* **`refl_walk_ne`**: for `μ ≠ 0`, the reflected walk `(o, A)` is the walk `(o, flipA μ A)`, where
  `flipA` reverses the displacement index of the transverse slot in direction `0`
  (`A ↦ 2 − A` there; `wt` is symmetric, `wt_flip`), so the family and its weights are preserved.
* **`refl_walk_zero`**: for `μ = 0`, the reflected walk is exactly `walkRev 0 o A`, the recipe of
  the reversed coarse link (§1.3), so with `boxMap_rev` the reflected coarse link carries the
  conjugate. -/

namespace BoxWalk

open WalkCast

def reflZ (z : Fin 4 → ℤ) : Fin 4 → ℤ := fun i => if i = 0 then -z i else z i

def reflL (l : Link) : Link :=
  if l.2.2 = 0 then (-l.1, reflZ l.2.1 - ev 0, 0) else (l.1, reflZ l.2.1, l.2.2)

def flipA (μ : Fin 4) (A : Fin 3 → Fin 3) : Fin 3 → Fin 3 :=
  fun t => if tr μ t = 0 then (2 - A t : Fin 3) else A t

theorem wt_flip (a : Fin 3) : ChainBlockMap.wt (2 - a) = ChainBlockMap.wt a := by
  fin_cases a <;> simp [ChainBlockMap.wt] <;> rfl

theorem refl_walk_ne : ∀ μ : Fin 4, μ ≠ 0 → ∀ o : Fin 6, ∀ A : Fin 3 → Fin 3,
    (walk μ o A).map reflL = walk μ o (flipA μ A) := by
  decide

theorem refl_walk_zero : ∀ o : Fin 6, ∀ A : Fin 3 → Fin 3,
    (walk 0 o A).map reflL = walkRev 0 o A := by
  decide

end BoxWalk



-- ===== new part : BoxReflMap.part.lean =====
/-! # L1-5: the reflection `x₀ ↦ −x₀` commutes with the box map (plan-10 §3a)

On the box, `thS` negates the
coordinate `0` of a site; `reflV` reflects a link field: a link in direction `ν ≠ 0` takes the value
at the reflected site, a link in direction `0` takes the conjugate of the value at
`Θy − e₀` (it is walked backwards). Lean:
* `red_refl`, `base_refl`, `red_ev0`: `red ∘ reflZ = thS ∘ red`, `2Θy = Θ(2y)`, `red e₀ = e₀`.
* `step_refl`, `pathProd_refl`: the path product of `reflV U` along a cast walk is the path product
  of `U` along the reflected walk (`reflL`) from the reflected base point.
* `flipA_invol`, `sixWeight_flip`: `flipA` is an involution keeping `sixWeight` (`wt_flip`).
* **`boxMap_refl`**: `B(Θ_{m+1} U) = Θ_m (B U)` on every coarse link: for `ν ≠ 0` by
  `refl_walk_ne` and the reindexing by `flipA`; for `ν = 0` by `refl_walk_zero` and `boxMap_rev`
  (`walkRev` is the recipe of the reversed coarse link from `Θ(2y)`, `boxWalk_end`).
* `reflCfg`: the reflection on ball-valued configurations, with `boxMap_refl_cfg`
  `blockMap ∘ reflCfg = reflCfg ∘ blockMap`, the `hcomm` of `map_invariant_of_commute`. -/

namespace BoxWalk

open WalkCast ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

section ReflBox

variable (L : ℕ) [NeZero L]

/-- Reflection `Θ` of a site (negate the coordinate `0`). -/
def thS (m : ℕ) (y : Site L m) : Site L m := fun i => if i = 0 then -y i else y i

theorem thS_add (m : ℕ) (x y : Site L m) : thS L m (x + y) = thS L m x + thS L m y := by
  funext i; simp only [thS, Pi.add_apply]; split_ifs <;> abel

theorem thS_sub (m : ℕ) (x y : Site L m) : thS L m (x - y) = thS L m x - thS L m y := by
  funext i; simp only [thS, Pi.sub_apply]; split_ifs <;> abel

theorem thS_thS (m : ℕ) (x : Site L m) : thS L m (thS L m x) = x := by
  funext i; simp only [thS]; split_ifs <;> simp

theorem red_refl (m : ℕ) (z : Fin 4 → ℤ) : red L m (reflZ z) = thS L (m + 1) (red L m z) := by
  funext i
  simp only [red, reflZ, thS, AddMonoidHom.compLeft_apply, Function.comp_apply,
    Int.coe_castAddHom]
  split_ifs <;> simp

theorem red_ev0 (m : ℕ) : red L m (ev 0) = Pi.single 0 1 := by
  funext i
  simp only [red, ev, AddMonoidHom.compLeft_apply, Function.comp_apply, Int.coe_castAddHom]
  by_cases h : i = 0
  · subst h; simp
  · simp [h]

theorem base_refl (m : ℕ) (y : Site L m) (ν : Fin 4) :
    base L m (thS L m y, ν) = thS L (m + 1) (base L m (y, ν)) := by
  funext i
  simp only [base, thS]
  split_ifs <;> simp [map_neg]

/-- The reflection of a link field. -/
noncomputable def reflV (m : ℕ) (U : BoxLk L m → ℍr) : BoxLk L m → ℍr := fun ℓ =>
  if ℓ.2 = 0 then star (U (thS L m ℓ.1 - Pi.single 0 1, 0)) else U (thS L m ℓ.1, ℓ.2)

theorem step_refl (m : ℕ) (U : BoxLk L (m + 1) → ℍr) (x : Site L (m + 1)) (l : Link)
    (hs : l.1 = 1 ∨ l.1 = -1) :
    stepVal (reflV L (m + 1) U) (linkCast (red L m) x l) =
      stepVal U (linkCast (red L m) (thS L (m + 1) x) (reflL l)) := by
  obtain ⟨s, z, ν⟩ := l
  have hpos : thS L (m + 1) (x + red L m z) = thS L (m + 1) x + red L m (reflZ z) := by
    rw [thS_add, red_refl]
  by_cases hν : ν = 0
  · subst hν
    have hpos0 : thS L (m + 1) (x + red L m z) - Pi.single 0 1 =
        thS L (m + 1) x + red L m (reflZ z - ev 0) := by
      rw [map_sub, red_ev0, hpos]; abel
    simp only [linkCast, reflL, reflV, stepVal, if_true]
    rw [hpos0]
    rcases hs with h | h <;> simp only at h <;> subst h <;> simp
  · simp only [linkCast, reflL, reflV, stepVal, hν, if_false]
    rw [hpos]

theorem pathProd_refl (m : ℕ) (U : BoxLk L (m + 1) → ℍr) (x : Site L (m + 1)) (γ : List Link)
    (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) :
    pathProd (reflV L (m + 1) U) (γ.map (linkCast (red L m) x)) =
      pathProd U ((γ.map reflL).map (linkCast (red L m) (thS L (m + 1) x))) := by
  induction γ with
  | nil => rfl
  | cons l rest ih =>
    have h1 := ih fun l' hl' => hs l' (List.mem_cons_of_mem _ hl')
    simp only [pathProd, List.map_cons, List.prod_cons] at h1 ⊢
    rw [h1, step_refl L m U x l (hs l List.mem_cons_self)]

theorem flipA_invol (μ : Fin 4) : Function.Involutive (flipA μ) := by
  intro A
  funext t
  simp only [flipA]
  split_ifs with h
  · generalize A t = a; revert a; decide
  · rfl

theorem sixWeight_flip (μ : Fin 4) (A : Fin 3 → Fin 3) : sixWeight (flipA μ A) = sixWeight A := by
  unfold sixWeight
  congr 1
  refine Finset.prod_congr rfl fun t _ => ?_
  simp only [flipA]
  split_ifs
  · exact wt_flip _
  · rfl

/-- **The reflection commutes with the box map** (values). -/
theorem boxMap_refl {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : BoxLk L (m + 1) → ℍr)
    (hU : ∀ ℓ, U ℓ ∈ Metric.closedBall (0 : ℍr) 1) (b : BoxLk L m) :
    retract r₀ (sixAvg (boxPathsIdx L m b) (reflV L (m + 1) U)) =
      reflV L m (fun ℓ => (blockMap r₀ hr (boxPaths L) (boxW L) m
        (fun ℓ' => ⟨U ℓ', hU ℓ'⟩) ℓ : ℍr)) b := by
  obtain ⟨y, ν⟩ := b
  set F : BoxLk L m → ℍr := fun ℓ => (blockMap r₀ hr (boxPaths L) (boxW L) m
    (fun ℓ' => ⟨U ℓ', hU ℓ'⟩) ℓ : ℍr) with hF
  have hpp : ∀ (b : BoxLk L m) o A, boxPathsIdx L m b o A =
      (walk b.2 o A).map (linkCast (red L m) (base L m b)) := fun _ _ _ => rfl
  by_cases hν : ν = 0
  · subst hν
    have hR : reflV L m F (y, 0) = star (F (thS L m y - Pi.single 0 1, 0)) := by
      simp only [reflV, if_true]
    rw [hR, hF]
    simp only
    rw [← boxMap_rev L hr]
    refine congrArg (retract r₀) ?_
    unfold sixAvg
    refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
    refine congrArg (sixWeight A • ·) ?_
    rw [hpp, pathProd_refl L m U _ _ (walk_sign 0 o A), refl_walk_zero]
    have hb : base L m (thS L m y - Pi.single 0 1, 0) + 2 • red L m (ev 0) =
        thS L (m + 1) (base L m (y, 0)) := by
      have := boxWalk_end L m (thS L m y - Pi.single 0 1, 0)
      simp only [dirB, sub_add_cancel] at this
      rw [this, base_refl]
    show _ = pathProd U ((walkRev 0 o A).map
      (linkCast (red L m) (base L m (thS L m y - Pi.single 0 1, 0) + 2 • red L m (ev 0))))
    rw [hb]
  · have hR : reflV L m F (y, ν) = F (thS L m y, ν) := by
      simp only [reflV, hν, if_false]
    rw [hR, hF]
    simp only
    rw [boxMap_eq L hr]
    refine congrArg (retract r₀) ?_
    show ∑ o, ∑ A, sixWeight A • pathProd (reflV L (m + 1) U) (boxPathsIdx L m (y, ν) o A) =
      ∑ o, ∑ A, sixWeight A • pathProd U (boxPathsIdx L m (thS L m y, ν) o A)
    refine Finset.sum_congr rfl fun o _ => ?_
    have hterm : ∀ A, sixWeight A • pathProd (reflV L (m + 1) U) (boxPathsIdx L m (y, ν) o A) =
        sixWeight (flipA ν A) • pathProd U (boxPathsIdx L m (thS L m y, ν) o (flipA ν A)) := by
      intro A
      rw [hpp, hpp, pathProd_refl L m U _ _ (walk_sign ν o A), refl_walk_ne ν hν, base_refl,
        sixWeight_flip]
    rw [Finset.sum_congr rfl fun A _ => hterm A]
    exact Equiv.sum_comp (Function.Involutive.toPerm _ (flipA_invol ν))
      (fun A' => sixWeight A' • pathProd U (boxPathsIdx L m (thS L m y, ν) o A'))

/-- The reflection on ball-valued configurations. -/
noncomputable def reflCfg (m : ℕ) (U : Cfg (BoxLk L m)) : Cfg (BoxLk L m) := fun ℓ =>
  ⟨reflV L m (fun ℓ' => (U ℓ' : ℍr)) ℓ, by
    rw [mem_ball_iff]
    unfold reflV
    split_ifs
    · rw [norm_star]; exact (mem_ball_iff _).1 (U _).2
    · exact (mem_ball_iff _).1 (U _).2⟩

/-- **`blockMap ∘ Θ = Θ ∘ blockMap`** on configurations (the `hcomm` of
`map_invariant_of_commute`). -/
theorem boxMap_refl_cfg {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) :
    blockMap r₀ hr (boxPaths L) (boxW L) m (reflCfg L (m + 1) U) =
      reflCfg L m (blockMap r₀ hr (boxPaths L) (boxW L) m U) := by
  funext b
  apply Subtype.ext
  show (blockMap r₀ hr (boxPaths L) (boxW L) m (reflCfg L (m + 1) U) b : ℍr) =
    reflV L m (fun ℓ => (blockMap r₀ hr (boxPaths L) (boxW L) m U ℓ : ℍr)) b
  rw [boxMap_eq L hr]
  exact boxMap_refl L hr m (fun ℓ => (U ℓ : ℍr)) (fun ℓ => (U ℓ).2) b

end ReflBox

end BoxWalk



-- ===== verbatim copy of LatticeBlockReflection.lean, theorem pushforward_reflection_positive (lines 311-324) =====
namespace LatticeBlockReflection

open MeasureTheory Filter Topology

section Pushforward

variable {Ω E : Type*} [MeasurableSpace Ω] [MeasurableSpace E]

/-- If reflection positivity holds on the fine side for a collection `A` of positive-side functions, the block map `V`
commutes with the reflection (`V ∘ Θ = Θ' ∘ V`), and the pull-back `F ∘ V` of each coarse positive-side function `F`
lies in `A`, then coarse reflection positivity holds for the push-forward measure. -/
theorem pushforward_reflection_positive (μ : Measure Ω) (Θ : Ω → Ω) (Θ' : E → E)
    (V : Ω → E) (hV : Measurable V) (hΘ' : Measurable Θ')
    (hcomm : ∀ ω, V (Θ ω) = Θ' (V ω))
    (A : Set (Ω → ℝ)) (hRP : ∀ f ∈ A, 0 ≤ ∫ ω, f (Θ ω) * f ω ∂μ)
    (F : E → ℝ) (hF : Measurable F) (hFA : (fun ω => F (V ω)) ∈ A) :
    0 ≤ ∫ e, F (Θ' e) * F e ∂(μ.map V) := by
  rw [integral_map (f := fun e => F (Θ' e) * F e) hV.aemeasurable
    ((hF.comp hΘ').mul hF).aestronglyMeasurable]
  have := hRP _ hFA
  simp only [hcomm] at this
  exact this

end Pushforward

end LatticeBlockReflection

-- ===== new part : BoxReflPush.part.lean =====
/-! # L1-5 (hΘp): reflection positivity passes down the chain of box maps (plan-10 §3b)

Paper (for checking): `reflCfg` is continuous (`continuous_reflCfg`),
`down n m` commutes with the reflection for `m ≤ n` (`down_refl`, induction with `down_succ`,
`down_self` and `boxMap_refl_cfg`), and `pushforward_reflection_positive`
(companion file, verbatim) gives **`reflection_positive_down`**: if the fine measure at level `n` is
reflection positive on a class `A` that contains the pull-backs `F ∘ down n m`, the push-forward to
level `m` is reflection positive for `F`. -/

namespace BoxWalk

open WalkCast ChainBlockMap Finset MeasureTheory

local notation "ℍr" => Quaternion ℝ

section ReflPush

variable (L : ℕ) [NeZero L]

theorem continuous_reflCfg (m : ℕ) : Continuous (reflCfg L m) := by
  refine continuous_pi fun ℓ => ?_
  refine Continuous.subtype_mk ?_ _
  unfold reflV
  by_cases h : ℓ.2 = 0
  · simp only [h, if_true]
    exact continuous_star.comp (continuous_subtype_val.comp (continuous_apply _))
  · simp only [h, if_false]
    exact continuous_subtype_val.comp (continuous_apply _)

theorem down_refl {r₀ : ℝ} (hr : 0 < r₀) (n : ℕ) :
    ∀ k m, m + k = n → ∀ U : Cfg (BoxLk L n),
      down r₀ hr (boxPaths L) (boxW L) n m (reflCfg L n U) =
        reflCfg L m (down r₀ hr (boxPaths L) (boxW L) n m U) := by
  intro k
  induction k with
  | zero =>
    intro m hm U
    have : m = n := by omega
    subst this
    rw [down_self, down_self]
  | succ k ih =>
    intro m hm U
    have hlt : m < n := by omega
    rw [down_succ r₀ hr (boxPaths L) (boxW L) hlt, down_succ r₀ hr (boxPaths L) (boxW L) hlt,
      ih (m + 1) (by omega) U, boxMap_refl_cfg L hr m]

/-- **hΘp**: coarse reflection positivity from fine reflection positivity, down the chain. -/
theorem reflection_positive_down {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n)
    (μ : Measure (Cfg (BoxLk L n))) (A : Set (Cfg (BoxLk L n) → ℝ))
    (hRP : ∀ f ∈ A, 0 ≤ ∫ ω, f (reflCfg L n ω) * f ω ∂μ)
    (F : Cfg (BoxLk L m) → ℝ) (hF : Measurable F)
    (hFA : (fun ω => F (down r₀ hr (boxPaths L) (boxW L) n m ω)) ∈ A) :
    0 ≤ ∫ e, F (reflCfg L m e) * F e ∂(μ.map (down r₀ hr (boxPaths L) (boxW L) n m)) :=
  LatticeBlockReflection.pushforward_reflection_positive μ (reflCfg L n) (reflCfg L m)
    (down r₀ hr (boxPaths L) (boxW L) n m)
    (continuous_down r₀ hr (boxPaths L) (boxW L) n m).measurable
    (continuous_reflCfg L m).measurable
    (fun U => down_refl L hr n (n - m) m (by omega) U) A hRP F hF hFA

end ReflPush

end BoxWalk


-- ===== verbatim copy of an earlier file, theorem pathProd_congr =====
namespace BoxWalk

open WalkCast ChainBlockMap

local notation "ℍr" => Quaternion ℝ

theorem pathProd_congr {Lt : Type*} (U U' : Lt → ℍr) :
    ∀ γ : List (Lt × Bool), (∀ s ∈ γ, U s.1 = U' s.1) → pathProd U γ = pathProd U' γ := by
  intro γ
  induction γ with
  | nil => intro _; rfl
  | cons s rest ih =>
    intro h
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih fun s' hs' => h s' (List.mem_cons_of_mem _ hs')]
    congr 1
    unfold stepVal
    rw [h s List.mem_cons_self]

end BoxWalk

-- ===== verbatim copy of LatticeBlockReflection.lean, theorem pullback_mem_positive (lines 326-331) =====
namespace LatticeBlockReflection

section Pullback

variable {Ω E : Type*}

/-- Locality puts the pull-back on the positive side (abstract form): if `F ∘ V` factors through the positive-side
coordinates `πp`, it lies in `A = {f | f factors through πp}`. -/
theorem pullback_mem_positive {P : Type*} (πp : Ω → P) (V : Ω → E) (F : E → ℝ)
    (Vp : P → E) (hloc : ∀ ω, V ω = Vp (πp ω)) :
    (fun ω => F (V ω)) ∈ {f : Ω → ℝ | ∃ φ : P → ℝ, ∀ ω, f ω = φ (πp ω)} :=
  ⟨fun p => F (Vp p), fun ω => by simp [hloc ω]⟩

end Pullback

end LatticeBlockReflection

-- ===== new part : BoxReflLocal.part.lean =====
/-! # L1-5 (B4): locality puts the pull-back on the positive side (plan-20 §3a)

Paper (for checking): Positive sides are given by the time coordinate:
a set `Ps j ⊆ ZMod (2^j L)` at each level, the links `(x, ν)` with `x₀ ∈ Ps j`.
* `walk_reach0`: every link of the 648 walks has base time coordinate in `{−1, 0, 1, 2}`
  (`decide`; `2` for the transverse steps back at the far end of a time-like link); so the coarse
  link at `y` uses fine links with base time in `[2y₀ − 1, 2y₀ + 2]` only.
* **`boxMap_pos_local`**: if `2y₀ + d ∈ Ps (m+1)` for `y₀ ∈ Ps m`, `|d| ≤ 1` (`hcube`), the box
  map on the positive coarse links depends only on the positive fine links.
* **`down_pos_local`**: the same down the chain (`down_succ`, `down_self`).
* `hcube_interval`: the intervals `{s + i : i ≤ c}` with `s′ = 2s − 1` satisfy
  `hcube` with `c′ = 2c + 3` (a face at `x₀ = k = 2s − 1`, `k` odd, coarse `y₀ ≥ (k+1)/2`).

* **`reflection_positive_down_local`**: `reflection_positive_down` with `hFA` replaced by "`F`
  factors through the coarse positive side": `A` is the class of functions of the fine positive
  side (companion file `pullback_mem_positive`). `hRP` (reflection positivity of the finest Wilson action
  on that class, lattice-point face) stays a named hypothesis ((B3), paper side). -/

namespace BoxWalk

open WalkCast ChainBlockMap Finset MeasureTheory

local notation "ℍr" => Quaternion ℝ

theorem walk_reach0 : ∀ μ : Fin 4, ∀ o : Fin 6, ∀ A : Fin 3 → Fin 3,
    ∀ l ∈ walk μ o A, -1 ≤ l.2.1 0 ∧ l.2.1 0 ≤ 2 := by
  decide

section PosLocal

variable (L : ℕ) [NeZero L]

theorem boxMap_pos_local {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (Pc : Set (ZMod (2 ^ m * L)))
    (Pf : Set (ZMod (2 ^ (m + 1) * L)))
    (hcube : ∀ y ∈ Pc, ∀ d : ℤ, -1 ≤ d → d ≤ 2 → double L m y + (d : ZMod (2 ^ (m + 1) * L)) ∈ Pf)
    (U U' : Cfg (BoxLk L (m + 1)))
    (hU : ∀ x : Site L (m + 1), x 0 ∈ Pf → ∀ ν, U (x, ν) = U' (x, ν))
    (b : BoxLk L m) (hb : b.1 0 ∈ Pc) :
    blockMap r₀ hr (boxPaths L) (boxW L) m U b = blockMap r₀ hr (boxPaths L) (boxW L) m U' b := by
  apply Subtype.ext
  rw [boxMap_eq L hr, boxMap_eq L hr]
  refine congrArg (retract r₀) ?_
  unfold sixAvg
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  refine congrArg (sixWeight A • ·) ?_
  refine pathProd_congr _ _ _ fun s hs => ?_
  simp only [boxPathsIdx, pathsCast, List.mem_map] at hs
  obtain ⟨l, hl, rfl⟩ := hs
  simp only [linkCast, dirB]
  have hr0 := walk_reach0 _ o A l hl
  have hmem : (base L m b + red L m l.2.1) 0 ∈ Pf := hcube _ hb (l.2.1 0) hr0.1 hr0.2
  rw [hU _ hmem l.2.2]

theorem down_pos_local {r₀ : ℝ} (hr : 0 < r₀) (n : ℕ) (Ps : ∀ j, Set (ZMod (2 ^ j * L)))
    (hcube : ∀ j, ∀ y ∈ Ps j, ∀ d : ℤ, -1 ≤ d → d ≤ 2 →
      double L j y + (d : ZMod (2 ^ (j + 1) * L)) ∈ Ps (j + 1)) :
    ∀ k m, m + k = n → ∀ U U' : Cfg (BoxLk L n),
      (∀ x : Site L n, x 0 ∈ Ps n → ∀ ν, U (x, ν) = U' (x, ν)) →
      ∀ b : BoxLk L m, b.1 0 ∈ Ps m →
        down r₀ hr (boxPaths L) (boxW L) n m U b = down r₀ hr (boxPaths L) (boxW L) n m U' b := by
  intro k
  induction k with
  | zero =>
    intro m hm U U' hU b hb
    have : m = n := by omega
    subst this
    rw [down_self, down_self]
    exact hU b.1 hb b.2
  | succ k ih =>
    intro m hm U U' hU b hb
    have hlt : m < n := by omega
    rw [down_succ r₀ hr (boxPaths L) (boxW L) hlt, down_succ r₀ hr (boxPaths L) (boxW L) hlt]
    exact boxMap_pos_local L hr m (Ps m) (Ps (m + 1)) (hcube m) _ _
      (fun x hx ν => ih (m + 1) (by omega) U U' hU (x, ν) hx) b hb

/-- The intervals `{s + i : i ≤ c}` with `s′ = 2s − 1`, `c′ = 2c + 3` satisfy `hcube`. -/
theorem hcube_interval (j : ℕ) (s : ZMod (2 ^ j * L)) (c : ℕ) (y : ZMod (2 ^ j * L))
    (hy : ∃ i : ℕ, i ≤ c ∧ y = s + i) (d : ℤ) (hd0 : -1 ≤ d) (hd1 : d ≤ 2) :
    ∃ i : ℕ, i ≤ 2 * c + 3 ∧
      double L j y + (d : ZMod (2 ^ (j + 1) * L)) = (double L j s - 1) + i := by
  obtain ⟨i, hi, rfl⟩ := hy
  obtain ⟨t, ht⟩ : ∃ t : ℕ, (t : ℤ) = d + 1 := ⟨(d + 1).toNat, Int.toNat_of_nonneg (by omega)⟩
  refine ⟨2 * i + t, by omega, ?_⟩
  have e1 : double L j (i : ZMod (2 ^ j * L)) = ((2 * (i : ℤ) : ℤ) : ZMod (2 ^ (j + 1) * L)) := by
    rw [← double_intCast]; norm_cast
  have hd : d = (t : ℤ) - 1 := by omega
  subst hd
  rw [map_add, e1]
  push_cast
  ring

open Classical in
/-- Extension of a positive-side configuration by `1` (the abstract `Vp` of the pull-back). -/
noncomputable def extPos (n : ℕ) (Pn : Set (ZMod (2 ^ n * L)))
    (p : {ℓ : BoxLk L n // ℓ.1 0 ∈ Pn} → Ball) : Cfg (BoxLk L n) :=
  fun ℓ => if h : ℓ.1 0 ∈ Pn then p ⟨ℓ, h⟩ else oneCfg _ ℓ

/-- **(B4) with locality**: reflection positivity passes down the chain for every `F` that
factors through the coarse positive side. -/
theorem reflection_positive_down_local {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n)
    (Ps : ∀ j, Set (ZMod (2 ^ j * L)))
    (hcube : ∀ j, ∀ y ∈ Ps j, ∀ d : ℤ, -1 ≤ d → d ≤ 2 →
      double L j y + (d : ZMod (2 ^ (j + 1) * L)) ∈ Ps (j + 1))
    (μ : Measure (Cfg (BoxLk L n)))
    (hRP : ∀ f ∈ {f : Cfg (BoxLk L n) → ℝ | ∃ φ : ({ℓ : BoxLk L n // ℓ.1 0 ∈ Ps n} → Ball) → ℝ,
        ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (reflCfg L n ω) * f ω ∂μ)
    (F : Cfg (BoxLk L m) → ℝ) (hF : Measurable F)
    (hFpos : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ Ps m} → Ball) → ℝ, ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    0 ≤ ∫ e, F (reflCfg L m e) * F e ∂(μ.map (down r₀ hr (boxPaths L) (boxW L) n m)) := by
  obtain ⟨φ, hφ⟩ := hFpos
  refine reflection_positive_down L hr n m hmn μ _ hRP F hF ?_
  have hloc : ∀ ω : Cfg (BoxLk L n),
      (fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ Ps m} => down r₀ hr (boxPaths L) (boxW L) n m ω ℓ.1) =
        fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ Ps m} =>
          down r₀ hr (boxPaths L) (boxW L) n m (extPos L n (Ps n) (fun ℓ' => ω ℓ'.1)) ℓ.1 := by
    intro ω
    funext ℓ
    refine down_pos_local L hr n Ps hcube (n - m) m (by omega) ω _ ?_ ℓ.1 ℓ.2
    intro x hx ν
    simp only [extPos, dif_pos hx]
  have h := LatticeBlockReflection.pullback_mem_positive (fun ω : Cfg (BoxLk L n) => fun ℓ :
      {ℓ : BoxLk L n // ℓ.1 0 ∈ Ps n} => ω ℓ.1)
    (fun ω => fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ Ps m} =>
      down r₀ hr (boxPaths L) (boxW L) n m ω ℓ.1) φ
    (fun p => fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ Ps m} =>
      down r₀ hr (boxPaths L) (boxW L) n m (extPos L n (Ps n) p) ℓ.1) hloc
  obtain ⟨ψ, hψ⟩ := h
  exact ⟨ψ, fun ω => (hφ _).trans (hψ ω)⟩

end PosLocal

end BoxWalk


-- ===== new part : BoxReflSlab — locality of reflection positivity, rebuilt =====
/-! # Locality of reflection positivity with a hypothesis that the torus Wilson measure can satisfy

Correction of `reflection_positive_down_local` (copied verbatim above, unchanged). Audit:
in that statement the fine positive side `Ps n` is whatever `hcube`
forces, and starting from the coarse half `|Ps m| = N_m/2` the fine side grows to
`|Ps n| ≥ N_n/2 + 2(2^{n-m} - 1)`, past the closed half and the partner plane, where the site
reflection positivity of the Wilson measure (`hRP`) is not available.

Here the reflection is the same `reflCfg` (site reflection `x₀ ↦ -x₀` at every level, planes
`x₀ = 0` and `x₀ = N_j/2`, `N_j = 2^j L`).  The hypothesis `hRP` is stated **only for the fixed
class of functions of the fine links with base time `0, 1, …, N_n/2 - 1`** (`halfSlab`): every such
link (space-like at `x₀ ≤ N_n/2 - 1`, time-like from `x₀` to `x₀ + 1 ≤ N_n/2`) lies in the closed
slab between the two planes, so `hRP` is the site reflection positivity of the Wilson measure for
functions of the closed positive half (Osterwalder–Seiler; paper A, Appendix "Reflection
positivity at finite n", (RP1), premise 10), for `N_n` even.

The coarse class is the strip of base times `1, …, 1 + c` with `2c + 6 ≤ N_m`, i.e. coarse base
times in `[1, N_m/2 - 2]` (`strip`).  The strips `{1 + i : i ≤ c_j}` with `c_{j+1} = 2c_j + 3`
satisfy `hcube` (`hcube_interval` with `s = 1`, since `2·1 - 1 = 1`), `c_n + 3 = 2^{n-m}(c + 3)`,
and the fine strip stays inside `halfSlab` for every `n ≥ m` (`strip_sub_half`).  The coarse plane
links (base time `0`) and the last two coarse time slices are not in the class: the walks of a
coarse link at base time `y₀` use fine links with base time in `[2y₀ - 1, 2y₀ + 2]`
(`walk_reach0`), so base time `0` reaches the fine time `-1` (negative side), and the upper end
`2^{n-m}(e + 2) - 2 ≤ N_n/2 - 1` forces `e ≤ N_m/2 - 2`. -/

namespace BoxWalk

open WalkCast ChainBlockMap Finset MeasureTheory

section Slab

variable (L : ℕ) [NeZero L]

/-- Fine closed positive half (by base time): `{0, 1, …, N/2 - 1}`, `N = 2^n L`. -/
def halfSlab (n : ℕ) : Set (ZMod (2 ^ n * L)) :=
  {t | ∃ i : ℕ, 2 * i + 2 ≤ 2 ^ n * L ∧ t = (i : ZMod (2 ^ n * L))}

/-- The strip of base times `{1 + i : i ≤ c}` at level `j`. -/
def strip (j c : ℕ) : Set (ZMod (2 ^ j * L)) :=
  {t | ∃ i : ℕ, i ≤ c ∧ t = 1 + (i : ZMod (2 ^ j * L))}

/-- Width at level `j` of the strip started at level `m` with width `c`: `2^{j-m}(c+3) - 3`. -/
def stripW (m c j : ℕ) : ℕ := 2 ^ (j - m) * (c + 3) - 3

/-- The family of strips (empty below level `m`). -/
def stripFam (m c : ℕ) : ∀ j, Set (ZMod (2 ^ j * L)) := fun j =>
  if m ≤ j then strip L j (stripW m c j) else ∅

theorem stripW_self (m c : ℕ) : stripW m c m = c := by
  simp [stripW]

theorem stripW_succ (m c j : ℕ) (hj : m ≤ j) : stripW m c (j + 1) = 2 * stripW m c j + 3 := by
  unfold stripW
  have e : j + 1 - m = (j - m) + 1 := by omega
  have h3 : 3 ≤ 2 ^ (j - m) * (c + 3) :=
    le_trans (by omega : 3 ≤ c + 3) (Nat.le_mul_of_pos_left (c + 3) (by positivity))
  have e2 : 2 ^ (j + 1 - m) * (c + 3) = 2 * (2 ^ (j - m) * (c + 3)) := by
    rw [e, pow_succ]; ring
  rw [e2]
  generalize 2 ^ (j - m) * (c + 3) = X at h3 ⊢
  omega

theorem double_one_sub (j : ℕ) : double L j (1 : ZMod (2 ^ j * L)) - 1 = 1 := by
  have h := double_intCast L j 1
  rw [Int.cast_one] at h
  rw [h]
  simp only [Int.cast_mul, Int.cast_ofNat, Int.cast_one]
  ring

/-- The strips satisfy `hcube` at every level. -/
theorem stripFam_hcube (m c : ℕ) : ∀ j, ∀ y ∈ stripFam L m c j, ∀ d : ℤ, -1 ≤ d → d ≤ 2 →
    double L j y + (d : ZMod (2 ^ (j + 1) * L)) ∈ stripFam L m c (j + 1) := by
  intro j y hy d hd0 hd1
  by_cases hj : m ≤ j
  · simp only [stripFam, if_pos hj, strip, Set.mem_setOf_eq] at hy
    simp only [stripFam, if_pos (by omega : m ≤ j + 1), strip, Set.mem_setOf_eq]
    obtain ⟨i', hi', he⟩ := hcube_interval L j 1 (stripW m c j) y hy d hd0 hd1
    refine ⟨i', ?_, ?_⟩
    · rw [stripW_succ m c j hj]; exact hi'
    · rw [he, double_one_sub]
  · simp [stripFam, hj] at hy

/-- The fine strip lies in the closed positive half, for every `n ≥ m`, if `2c + 6 ≤ N_m`. -/
theorem strip_sub_half (m c n : ℕ) (hmn : m ≤ n) (hc : 2 * c + 6 ≤ 2 ^ m * L) :
    strip L n (stripW m c n) ⊆ halfSlab L n := by
  rintro t ⟨i, hi, rfl⟩
  simp only [halfSlab, Set.mem_setOf_eq]
  refine ⟨1 + i, ?_, by simp [Nat.cast_add]⟩
  have e : 2 ^ n * L = 2 ^ (n - m) * (2 ^ m * L) := by
    rw [← mul_assoc, ← pow_add, Nat.sub_add_cancel hmn]
  have h1 : 2 ^ (n - m) * (2 * c + 6) ≤ 2 ^ (n - m) * (2 ^ m * L) := Nat.mul_le_mul_left _ hc
  have h3 : 3 ≤ 2 ^ (n - m) * (c + 3) :=
    le_trans (by omega : 3 ≤ c + 3) (Nat.le_mul_of_pos_left (c + 3) (by positivity))
  have e2 : 2 ^ (n - m) * (2 * c + 6) = 2 * (2 ^ (n - m) * (c + 3)) := by ring
  unfold stripW at hi
  rw [e]
  rw [e2] at h1
  generalize 2 ^ (n - m) * (c + 3) = A at hi h3 h1
  generalize 2 ^ (n - m) * (2 ^ m * L) = B at h1 ⊢
  omega

theorem stripFam_of_le (m c n : ℕ) (hmn : m ≤ n) :
    stripFam L m c n = strip L n (stripW m c n) := by
  simp only [stripFam, if_pos hmn]

theorem stripFam_self (m c : ℕ) : stripFam L m c m = strip L m c := by
  rw [stripFam_of_le L m c m le_rfl, stripW_self]

/-- **Locality of reflection positivity, rebuilt (corrects `reflection_positive_down_local`).**
Paper: paper A, Definition "positive-time observables" and Appendix "Reflection positivity at
finite n" ((RP1), (RP2)); `hRP` is required only for functions of the fine
closed positive half (`halfSlab n`: base times `0 … N_n/2 - 1`, links inside the slab between the
planes `x₀ = 0` and `x₀ = N_n/2`), which is site reflection positivity of the Wilson measure
(premise 10 of paper A; not proved in Lean here).  Conclusion: reflection positivity of the
push-forward to level `m` for every measurable `F` of the coarse links with base time in
`{1, …, 1 + c}`, `2c + 6 ≤ N_m` (coarse base times `1 … N_m/2 - 2`).  Uniform in `n ≥ m`. -/
theorem reflection_positive_down_slab {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n)
    (c : ℕ) (hc : 2 * c + 6 ≤ 2 ^ m * L)
    (μ : Measure (Cfg (BoxLk L n)))
    (hRP : ∀ f ∈ {f : Cfg (BoxLk L n) → ℝ |
        ∃ φ : ({ℓ : BoxLk L n // ℓ.1 0 ∈ halfSlab L n} → Ball) → ℝ, ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (reflCfg L n ω) * f ω ∂μ)
    (F : Cfg (BoxLk L m) → ℝ) (hF : Measurable F)
    (hFpos : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ strip L m c} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    0 ≤ ∫ e, F (reflCfg L m e) * F e ∂(μ.map (down r₀ hr (boxPaths L) (boxW L) n m)) := by
  have hsub : stripFam L m c n ⊆ halfSlab L n := by
    rw [stripFam_of_le L m c n hmn]
    exact strip_sub_half L m c n hmn hc
  refine reflection_positive_down_local L hr n m hmn (stripFam L m c) (stripFam_hcube L m c) μ
    ?_ F hF ?_
  · rintro f ⟨φ, hφ⟩
    exact hRP f ⟨fun p => φ (fun ℓ => p ⟨ℓ.1, hsub ℓ.2⟩), fun ω => hφ ω⟩
  · rw [stripFam_self]
    exact hFpos

/-- The coarse class is not empty of content: for `N_m ≥ 8` (`c = 0`), every measurable function
of the coarse links at base time `1` is admitted, e.g. any coordinate of the link `(y, ν)` with
`y₀ = 1`.  (Witness of the side condition `hc`.) -/
theorem strip_hc_example (m : ℕ) (h : 8 ≤ 2 ^ m * L) : 2 * 0 + 6 ≤ 2 ^ m * L := by omega

end Slab

end BoxWalk


/-!
# Premise 10 for the Wilson measure of SU(2) on the periodic lattice (table 2, row 10)

Paper A, premise 10 / (RP1) / Appendix RP: site reflection positivity of the lattice measure
(Osterwalder–Seiler), here proved in Lean for the plain Wilson measure of `SU(2)` on `(ℤ/N)⁴`,
`N = 2M`, every real `β`, with the reflection `x₀ ↦ -x₀` of `BoxReflSlab.lean`.

Assembled from: `ReflectionProduct.lean` (two statements, copied), `parts/linkrp.part`
(abstract link form, checked alone as `LinkRP.v1.lean`), `CompactHaarInv.lean` (section
`Group`, copied), the `SU2` / `haarProb` definitions of `GapSU2.lean` (namespace `OSGap`,
copied verbatim so that the two agree), `parts/torusrp.part` (the torus).
-/

namespace ReflectionProduct

open MeasureTheory

variable {A P : Type*} [MeasurableSpace A] [MeasurableSpace P]
  (μ : Measure A) [SFinite μ] (ν : Measure P) [SFinite ν]

theorem refl_pairing_eq (h g : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * g z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    ∫ z : P × (A × A), h z.2.1 z.1 * g z.2.2 z.1 ∂(ν.prod (μ.prod μ))
      = ∫ p, (∫ a, h a p ∂μ) * (∫ b, g b p ∂μ) ∂ν := by
  rw [integral_prod _ hint]
  refine integral_congr_ae (Filter.Eventually.of_forall (fun p => ?_))
  exact integral_prod_mul (fun a => h a p) (fun b => g b p)

/-- **Reflection positivity (integral form) for a product measure with a factorised weight.** -/
theorem refl_pos_integral (h : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * h z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    0 ≤ ∫ z : P × (A × A), h z.2.1 z.1 * h z.2.2 z.1 ∂(ν.prod (μ.prod μ)) := by
  rw [refl_pairing_eq μ ν h h hint]
  exact integral_nonneg (fun p => mul_self_nonneg _)

end ReflectionProduct

/-! ## Reflection positivity for a product measure on link variables (abstract index form)

Paper A, premise 10 / Appendix RP (site reflection positivity of the lattice measure);
Osterwalder–Seiler.  This is the bridge from a *link-indexed* configuration space `Λ → X`
with the product measure `ν^Λ` to the plane/positive/negative product form
`P × (A × A)` of `ReflectionProduct.refl_pos_integral` (the same form as the configuration
space of the fermion lane, plane configuration × positive configuration).

Data: a reflection of the links `θ : Λ → Λ` (an involution), a map on the values `σ ℓ : X → X`
(the identity on spatial links, `star` = inverse on temporal links), measure preserving for `ν`,
and two decidable predicates: `fix ℓ` (links in the reflection planes, fixed by `θ` and with
`σ ℓ = id`) and `pos ℓ` (links strictly on the positive side).  Every link that is neither is
sent by `θ` to a positive link, and positive links are sent to non-positive links.  The closed
positive half is `fix ∨ pos`.  The reflected configuration is `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`.

Statement (`rp_core`): for every bounded measurable `g` that depends only on the links of the
closed positive half, `0 ≤ ∫ g(Θω) g(ω) d ν^Λ`.  With a weight that factorises as
`W(ω) = a(ω) a(Θω)`, `a` bounded measurable on the closed positive half (`rp_weighted`).
Nothing here is specific to a lattice; the concrete torus is in the next section.
-/

namespace LinkReflection

open MeasureTheory

variable {Λ X : Type*} [Fintype Λ] [MeasurableSpace X]

/-- The reflected configuration `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`. -/
def linkRefl (θ : Λ → Λ) (σ : Λ → X → X) (ω : Λ → X) : Λ → X := fun ℓ => σ ℓ (ω (θ ℓ))

section Split

variable (θ : Λ → Λ) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]

/-- links off the planes -/
abbrev Off := {ℓ : Λ // ¬ fix ℓ}
/-- links strictly on the positive side (as a subtype of `Off`) -/
abbrev PosI := {q : Off fix // pos q.1}
/-- links strictly on the negative side -/
abbrev NegI := {q : Off fix // ¬ pos q.1}

/-- The reflection identifies the negative links with the positive links. -/
def negPosEquiv (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ)) : NegI fix pos ≃ PosI fix pos where
  toFun b := ⟨⟨θ b.1.1, hposfix _ (hB _ b.1.2 b.2)⟩, hB _ b.1.2 b.2⟩
  invFun a := ⟨⟨θ a.1.1, fun h => a.1.2 (by
      have h2 := hfix _ h
      rw [hθ] at h2
      rw [h2]; exact h)⟩, hA _ a.2⟩
  left_inv b := Subtype.ext (Subtype.ext (hθ _))
  right_inv a := Subtype.ext (Subtype.ext (hθ _))

/-- Gluing a plane configuration and a positive configuration into a configuration (the other
links get an arbitrary value; only the closed positive half matters). -/
noncomputable def glue [Nonempty X] (p : {ℓ // fix ℓ} → X) (a : PosI fix pos → X) : Λ → X :=
  fun ℓ => if h : fix ℓ then p ⟨ℓ, h⟩ else if h' : pos ℓ then a ⟨⟨ℓ, h⟩, h'⟩
    else Classical.arbitrary X

theorem measurable_glue [Nonempty X] :
    Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => glue fix pos z.1 z.2) := by
  refine measurable_pi_lambda _ (fun ℓ => ?_)
  unfold glue
  by_cases h : fix ℓ
  · simp only [dif_pos h]
    exact (measurable_pi_apply _).comp measurable_fst
  · by_cases h' : pos ℓ
    · simp only [dif_neg h, dif_pos h']
      exact (measurable_pi_apply _).comp measurable_snd
    · simp only [dif_neg h, dif_neg h']
      exact measurable_const

end Split

theorem piCongrLeft_const {α β Y : Type*} [MeasurableSpace Y] (e : α ≃ β) (c : α → Y) (b : β) :
    MeasurableEquiv.piCongrLeft (fun _ : β => Y) e c b = c (e.symm b) := by
  obtain ⟨a, rfl⟩ := e.surjective b
  rw [MeasurableEquiv.piCongrLeft_apply_apply, Equiv.symm_apply_apply]

/-- **Reflection positivity of the product measure on link variables** (premise 10, the
reference measure; Osterwalder–Seiler).  `g` bounded, measurable, depending only on the closed
positive half `fix ∨ pos`. -/
theorem rp_core [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (g : (Λ → X) → ℝ) (hg : Measurable g) (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → g ω = g ω') :
    0 ≤ ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
  classical
  let e := negPosEquiv θ fix pos hθ (fun ℓ h => (hfix ℓ h).1) hposfix hA hB
  let Ψ : (Λ → X) → ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) :=
    fun ω => (fun i => ω i.1, (fun a => ω a.1.1, fun a => σ a.1.1 (ω (θ a.1.1))))
  have hs1 := measurePreserving_piEquivPiSubtypeProd (fun _ : Λ => ν) fix
  have hs2 := measurePreserving_piEquivPiSubtypeProd (fun _ : Off fix => ν)
    (fun q : Off fix => pos q.1)
  have hre := measurePreserving_piCongrLeft (fun _ : PosI fix pos => ν) e
  have hσp := measurePreserving_pi (fun _ : PosI fix pos => ν) (fun _ : PosI fix pos => ν)
    (f := fun a => σ a.1.1) (fun a => hσ a.1.1)
  have hτ := hσp.comp hre
  have hcomp := ((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod
    ((MeasurePreserving.id (Measure.pi fun _ : PosI fix pos => ν)).prod hτ)).comp
    (((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod hs2).comp hs1)
  have hΨ : MeasurePreserving Ψ (Measure.pi fun _ : Λ => ν)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    convert hcomp using 1
    funext ω
    refine Prod.ext rfl (Prod.ext rfl ?_)
    funext a
    show σ a.1.1 (ω (θ a.1.1)) = σ a.1.1 (MeasurableEquiv.piCongrLeft (fun _ : PosI fix pos => X) e
      (fun b => ω b.1.1) a)
    rw [piCongrLeft_const]
    rfl
  let G : ({ℓ // fix ℓ} → X) → (PosI fix pos → X) → ℝ := fun p a => g (glue fix pos p a)
  have hG : Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => G z.1 z.2) :=
    hg.comp (measurable_glue fix pos)
  have hH : Measurable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2) := by
    refine Measurable.mul ?_ ?_
    · exact hG.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    · exact hG.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have h1 : ∀ ω, g ω = G (Ψ ω).1 (Ψ ω).2.1 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show ω ℓ = glue fix pos (fun i => ω i.1) (fun a => ω a.1.1) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have h2 : ∀ ω, g (linkRefl θ σ ω) = G (Ψ ω).1 (Ψ ω).2.2 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show σ ℓ (ω (θ ℓ)) =
      glue fix pos (fun i => ω i.1) (fun a => σ a.1.1 (ω (θ a.1.1))) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h, (hfix ℓ h).1, (hfix ℓ h).2]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have hC : 0 ≤ C := le_trans (abs_nonneg _) (hgC (fun _ => Classical.arbitrary X))
  have hint : Integrable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    refine Integrable.of_bound hH.aestronglyMeasurable (C * C) (ae_of_all _ fun z => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    exact mul_le_mul (hgC _) (hgC _) (abs_nonneg _) hC
  calc (0 : ℝ) ≤ ∫ z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)),
        G z.1 z.2.1 * G z.1 z.2.2
        ∂((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
          ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) :=
        ReflectionProduct.refl_pos_integral (Measure.pi fun _ : PosI fix pos => ν)
          (Measure.pi fun _ : {ℓ // fix ℓ} => ν) (fun a p => G p a) hint
    _ = ∫ ω, G (Ψ ω).1 (Ψ ω).2.1 * G (Ψ ω).1 (Ψ ω).2.2 ∂(Measure.pi fun _ : Λ => ν) := by
        rw [← hΨ.map_eq, integral_map hΨ.measurable.aemeasurable hH.aestronglyMeasurable]
    _ = ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
        congr 1
        funext ω
        rw [h1 ω, h2 ω, mul_comm]

/-- **With a factorised weight** `W(ω) = a(ω) a(Θω)` (Wilson's action: plaquettes of the
positive side, half of the plaquettes in the planes).  `f`, `a` bounded measurable on the
closed positive half. -/
theorem rp_weighted [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (f a : (Λ → X) → ℝ) (hf : Measurable f) (ha : Measurable a) (Cf Ca : ℝ)
    (hfC : ∀ ω, |f ω| ≤ Cf) (haC : ∀ ω, |a ω| ≤ Ca)
    (hfdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → f ω = f ω')
    (hadep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → a ω = a ω') :
    0 ≤ ∫ ω, f (linkRefl θ σ ω) * f ω * (a ω * a (linkRefl θ σ ω)) ∂(Measure.pi fun _ : Λ => ν) := by
  have hCa : 0 ≤ Ca := le_trans (abs_nonneg _) (haC (fun _ => Classical.arbitrary X))
  have h := rp_core ν θ σ fix pos hθ hfix hposfix hA hB hσ (fun ω => a ω * f ω) (ha.mul hf)
    (Ca * Cf) (fun ω => by rw [abs_mul]; exact mul_le_mul (haC ω) (hfC ω) (abs_nonneg _) hCa)
    (fun ω ω' h => by rw [hadep ω ω' h, hfdep ω ω' h])
  calc (0 : ℝ) ≤ _ := h
    _ = _ := by
      congr 1
      funext ω
      ring

end LinkReflection

namespace CompactHaar

open MeasureTheory Measure

section Group

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [MeasurableSpace G] [BorelSpace G]

/-- **Right invariance.** -/
theorem map_mul_right_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ]
    (g : G) : map (· * g) μ = μ := by
  have hreg : (map (· * g) μ).Regular := by
    have h := Regular.map (μ := μ) (Homeomorph.mulRight g)
    exact h
  have hc := isMulLeftInvariant_eq_smul_of_regular (map (· * g) μ) μ
  have h1 : (map (· * g) μ) Set.univ = 1 := by
    rw [map_apply (continuous_mul_right g).measurable MeasurableSet.univ, Set.preimage_univ,
      measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isMulRightInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ]
    [IsProbabilityMeasure μ] : IsMulRightInvariant μ :=
  ⟨fun g => map_mul_right_eq μ g⟩

/-- **Inversion invariance.** -/
theorem inv_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    μ.inv = μ := by
  haveI : IsMulRightInvariant μ := isMulRightInvariant μ
  have hc := isMulLeftInvariant_eq_smul_of_regular μ.inv μ
  have h1 : μ.inv Set.univ = 1 := by
    rw [inv_apply, Set.inv_univ, measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isInvInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    IsInvInvariant μ :=
  ⟨inv_eq μ⟩

/-- the normalised Haar measure `haarMeasure ⊤` of a compact group is inversion invariant -/
theorem haarTop_inv_eq : (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)).inv
    = haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G) := by
  haveI : IsProbabilityMeasure (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)) := by
    refine ⟨?_⟩
    have h : haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)
        ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 := haarMeasure_self
    rwa [TopologicalSpace.PositiveCompacts.coe_top] at h
  exact inv_eq _

end Group

end CompactHaar

namespace OSGap

section SU2

open MeasureTheory

/-- `SU(2)` realised as the group of unit quaternions -/
abbrev SU2 : Type := Metric.sphere (0 : Quaternion ℝ) 1

noncomputable instance : MeasurableSpace SU2 := borel SU2

instance : BorelSpace SU2 := ⟨rfl⟩

/-- the normalised Haar measure of a compact group -/
noncomputable def haarProb (G : Type*) [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
    [CompactSpace G] [MeasurableSpace G] [BorelSpace G] : Measure G :=
  Measure.haarMeasure ⊤

instance haarProb_isProbabilityMeasure (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    IsProbabilityMeasure (haarProb G) := by
  refine ⟨?_⟩
  have h : haarProb G ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 :=
    Measure.haarMeasure_self
  rwa [TopologicalSpace.PositiveCompacts.coe_top] at h

instance haarProb_isMulLeftInvariant (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    (haarProb G).IsMulLeftInvariant := by
  unfold haarProb
  infer_instance

/-- the normalised Haar measure of `SU(2)` -/
noncomputable abbrev haarSU2 : Measure SU2 := haarProb SU2

end SU2

end OSGap


/-! ## The concrete four-dimensional periodic lattice: Wilson measure and site reflection

Paper A, premise 10 (site reflection positivity of `μ_n`, Appendix RP) for the plain Wilson
measure of `SU(2)` on the periodic lattice `(ℤ/N)⁴`, `N = 2M` even, with the reflection
`x₀ ↦ -x₀` (planes `x₀ = 0` and `x₀ = M`).  The reflection of the links is the one of
`BoxReflSlab.lean` (`reflV` / `reflCfg`): a temporal link `(x, 0)` goes to the star of the link
`(Θx - e₀, 0)`, a spatial link `(x, ν)` to `(Θx, ν)`.  Link values are in the closed unit ball
of the quaternions (as in `BoxReflSlab.lean`); the reference measure is the image of the
normalised Haar measure of `SU2` (the unit sphere), so the configurations are `SU(2)`-valued
almost surely.  Wilson's weight is `exp(β Σ_p Re U_p)` over the unoriented plaquettes
`(x, μ, ν)`, `μ < ν` (`Re U = ½ tr U`); the constant `1` of `1 - ½tr` and the normalisation
`Z` are positive factors and are omitted (they do not change the sign of the pairing).

Everything is in finite volume (the statement is for each `N`); nothing here is uniform in the
volume or the lattice spacing, and nothing is needed to be: reflection positivity is an exact
property of each finite-volume measure.
-/

namespace TorusRP

open MeasureTheory LinkReflection

local notation "ℍr" => Quaternion ℝ

/-- Values of a link variable (as in `BoxReflSlab.lean`). -/
abbrev QBall := Metric.closedBall (0 : ℍr) 1

section Geometry

variable (N : ℕ) [NeZero N]

abbrev Site := Fin 4 → ZMod N
abbrev Lk := Site N × Fin 4

/-- `Θ x = (-x₀, x₁, x₂, x₃)` -/
def thS (y : Site N) : Site N := fun i => if i = 0 then -y i else y i

/-- unit vector -/
def ev (μ : Fin 4) : Site N := Pi.single μ 1

/-- the reflection of the links (the index map of `reflV`) -/
def thL (ℓ : Lk N) : Lk N := if ℓ.2 = 0 then (thS N ℓ.1 - ev N 0, 0) else (thS N ℓ.1, ℓ.2)

noncomputable def starB (q : QBall) : QBall :=
  ⟨star (q : ℍr), by rw [mem_closedBall_zero_iff, norm_star]; exact mem_closedBall_zero_iff.1 q.2⟩

/-- the map on the values: `star` (= inverse on `SU(2)`) on temporal links -/
noncomputable def sig (ℓ : Lk N) : QBall → QBall := if ℓ.2 = 0 then starB else id

theorem thS_add (x y : Site N) : thS N (x + y) = thS N x + thS N y := by
  funext i; simp only [thS, Pi.add_apply]; split_ifs <;> abel

theorem thS_sub (x y : Site N) : thS N (x - y) = thS N x - thS N y := by
  funext i; simp only [thS, Pi.sub_apply]; split_ifs <;> abel

theorem thS_thS (x : Site N) : thS N (thS N x) = x := by
  funext i; simp only [thS]; split_ifs <;> simp

theorem thS_ev0 : thS N (ev N 0) = -ev N 0 := by
  funext i; simp only [thS, ev, Pi.neg_apply]; split_ifs with h
  · subst h; simp
  · simp [Pi.single_apply, h]

theorem thS_ev {ν : Fin 4} (hν : ν ≠ 0) : thS N (ev N ν) = ev N ν := by
  funext i; simp only [thS, ev]; split_ifs with h
  · subst h; simp [Pi.single_apply, Ne.symm hν]
  · rfl

theorem ev_zero {ν : Fin 4} (hν : ν ≠ 0) : ev N ν 0 = 0 := by
  simp [ev, Pi.single_apply, Ne.symm hν]

theorem thL_snd (ℓ : Lk N) : (thL N ℓ).2 = ℓ.2 := by
  unfold thL; split_ifs with h
  · exact h.symm
  · rfl

theorem thL_invol : Function.Involutive (thL N) := by
  intro ℓ
  obtain ⟨x, μ⟩ := ℓ
  by_cases h : μ = 0
  · subst h
    simp only [thL, if_true, thS_sub, thS_thS, thS_ev0, sub_neg_eq_add, add_sub_cancel_right]
  · simp only [thL, h, if_false, thS_thS]

theorem thL_time (ℓ : Lk N) :
    (thL N ℓ).1 0 = if ℓ.2 = 0 then -(ℓ.1 0) - 1 else -(ℓ.1 0) := by
  unfold thL; split_ifs <;> simp [thS, ev]

/-- the reflected configuration is the map of `reflCfg` -/
theorem refl_apply (ω : Lk N → QBall) (ℓ : Lk N) :
    ((linkRefl (thL N) (sig N) ω ℓ : QBall) : ℍr) =
      if ℓ.2 = 0 then star (ω (thL N ℓ) : ℍr) else (ω (thL N ℓ) : ℍr) := by
  unfold linkRefl sig; split_ifs <;> rfl

/-! ### time coordinate -/

theorem val_neg_sub_one (t : ZMod N) : (-t - 1).val = N - 1 - t.val := by
  have hv := ZMod.val_lt t
  have h : (N - 1 - t.val) + t.val + 1 = N := by omega
  have h2 := congrArg (Nat.cast : ℕ → ZMod N) h
  rw [Nat.cast_add, Nat.cast_add, Nat.cast_one, ZMod.natCast_self, ZMod.natCast_zmod_val] at h2
  have h3 : ((N - 1 - t.val : ℕ) : ZMod N) = -t - 1 := by linear_combination h2
  rw [← h3, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem val_neg' (t : ZMod N) (ht : t.val ≠ 0) : (-t).val = N - t.val := by
  have hv := ZMod.val_lt t
  have h : (N - t.val) + t.val = N := by omega
  have h2 := congrArg (Nat.cast : ℕ → ZMod N) h
  rw [Nat.cast_add, ZMod.natCast_self, ZMod.natCast_zmod_val] at h2
  have h3 : ((N - t.val : ℕ) : ZMod N) = -t := by linear_combination h2
  rw [← h3, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem val_add_one (t : ZMod N) (ht : t.val + 1 < N) : (t + 1).val = t.val + 1 := by
  have h2 : ((t.val + 1 : ℕ) : ZMod N) = t + 1 := by
    rw [Nat.cast_add, Nat.cast_one, ZMod.natCast_zmod_val]
  rw [← h2, ZMod.val_natCast, Nat.mod_eq_of_lt ht]

/-- time of the base point of a link -/
def tm (ℓ : Lk N) : ℕ := (ℓ.1 0).val

variable (M : ℕ)

/-- links in the reflection planes `x₀ = 0`, `x₀ = M` (spatial) -/
def fixP (ℓ : Lk N) : Prop := ℓ.2 ≠ 0 ∧ (tm N ℓ = 0 ∨ tm N ℓ = M)

/-- links strictly on the positive side -/
def posP (ℓ : Lk N) : Prop := if ℓ.2 = 0 then tm N ℓ < M else (0 < tm N ℓ ∧ tm N ℓ < M)

instance : DecidablePred (fixP N M) := fun ℓ => by unfold fixP; infer_instance
instance : DecidablePred (posP N M) := fun ℓ => by unfold posP; infer_instance

theorem tm_thL_temporal (ℓ : Lk N) (h : ℓ.2 = 0) : tm N (thL N ℓ) = N - 1 - tm N ℓ := by
  unfold tm; rw [thL_time, if_pos h, val_neg_sub_one]

theorem tm_thL_spatial (ℓ : Lk N) (h : ℓ.2 ≠ 0) (h0 : tm N ℓ ≠ 0) :
    tm N (thL N ℓ) = N - tm N ℓ := by
  unfold tm; rw [thL_time, if_neg h, val_neg' N _ h0]

theorem tm_thL_spatial0 (ℓ : Lk N) (h : ℓ.2 ≠ 0) (h0 : tm N ℓ = 0) : tm N (thL N ℓ) = 0 := by
  unfold tm at h0 ⊢
  rw [ZMod.val_eq_zero] at h0
  rw [thL_time, if_neg h, ZMod.val_eq_zero, h0, neg_zero]

theorem tm_lt (ℓ : Lk N) : tm N ℓ < N := ZMod.val_lt _

variable {N M}

theorem hfix_torus (hN : N = 2 * M) (ℓ : Lk N) (h : fixP N M ℓ) :
    thL N ℓ = ℓ ∧ ∀ x, sig N ℓ x = x := by
  obtain ⟨h2, h0⟩ := h
  refine ⟨?_, fun x => by simp [sig, h2]⟩
  obtain ⟨x, μ⟩ := ℓ
  simp only at h2
  simp only [tm] at h0
  have hx : x 0 = -x 0 := by
    rcases h0 with h0 | h0
    · rw [ZMod.val_eq_zero] at h0; rw [h0, neg_zero]
    · have hc : ((x 0).val : ZMod N) = (M : ZMod N) := by rw [h0]
      rw [ZMod.natCast_zmod_val] at hc
      have hNM : ((2 * M : ℕ) : ZMod N) = 0 := by rw [← hN, ZMod.natCast_self]
      rw [Nat.cast_mul, Nat.cast_ofNat] at hNM
      rw [hc]; linear_combination hNM
  have hth : thS N x = x := by
    funext i
    simp only [thS]
    split_ifs with hi
    · subst hi; exact hx.symm
    · rfl
  simp only [thL, h2, if_false, ↓reduceIte, hth]

theorem hposfix_torus (ℓ : Lk N) (h : posP N M ℓ) : ¬ fixP N M ℓ := by
  rintro ⟨h2, h0⟩
  unfold posP at h
  rw [if_neg h2] at h
  omega

theorem hA_torus (hN : N = 2 * M) (ℓ : Lk N) (h : posP N M ℓ) : ¬ posP N M (thL N ℓ) := by
  have hlt := tm_lt N ℓ
  unfold posP at h ⊢
  rw [thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at h ⊢
    rw [tm_thL_temporal N ℓ h2]
    omega
  · rw [if_neg h2] at h ⊢
    rw [tm_thL_spatial N ℓ h2 (by omega)]
    omega

theorem hB_torus (hN : N = 2 * M) (ℓ : Lk N) (hf : ¬ fixP N M ℓ) (hp : ¬ posP N M ℓ) :
    posP N M (thL N ℓ) := by
  have hlt := tm_lt N ℓ
  unfold posP at hp ⊢
  rw [thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at hp ⊢
    rw [tm_thL_temporal N ℓ h2]
    omega
  · rw [if_neg h2] at hp ⊢
    have h0 : tm N ℓ ≠ 0 := fun h0 => hf ⟨h2, Or.inl h0⟩
    have hM : tm N ℓ ≠ M := fun h0 => hf ⟨h2, Or.inr h0⟩
    rw [tm_thL_spatial N ℓ h2 h0]
    omega

/-- spatial links with time in `[0, M]` are in the closed positive half -/
theorem closed_spatial (z : Site N) (κ : Fin 4) (hκ : κ ≠ 0) (hv : (z 0).val ≤ M) :
    fixP N M (z, κ) ∨ posP N M (z, κ) := by
  by_cases h0 : (z 0).val = 0 ∨ (z 0).val = M
  · exact Or.inl ⟨hκ, h0⟩
  · right
    show if κ = 0 then (z 0).val < M else (0 < (z 0).val ∧ (z 0).val < M)
    rw [if_neg hκ]
    omega

/-- temporal links with time in `[0, M)` are strictly positive -/
theorem closed_temporal (z : Site N) (hv : (z 0).val < M) :
    fixP N M (z, 0) ∨ posP N M (z, 0) := by
  right
  show if (0 : Fin 4) = 0 then (z 0).val < M else (0 < (z 0).val ∧ (z 0).val < M)
  rw [if_pos rfl]
  exact hv

end Geometry

/-! ### the reference measure: image of the Haar measure of `SU2` -/

section Measure

open OSGap

noncomputable def incl (q : SU2) : QBall :=
  ⟨(q : ℍr), by rw [mem_closedBall_zero_iff]; exact le_of_eq (mem_sphere_zero_iff_norm.1 q.2)⟩

theorem continuous_incl : Continuous incl :=
  (continuous_subtype_val).subtype_mk _

/-- the reference measure on a link: `SU(2)` Haar measure in the ball -/
noncomputable def haarBall : Measure QBall := (haarProb SU2).map incl

instance : IsProbabilityMeasure haarBall :=
  Measure.isProbabilityMeasure_map continuous_incl.measurable.aemeasurable

theorem continuous_starB : Continuous starB :=
  (continuous_star.comp continuous_subtype_val).subtype_mk _

theorem starB_incl (q : SU2) : starB (incl q) = incl q⁻¹ := by
  apply Subtype.ext
  show star (q : ℍr) = ((q⁻¹ : SU2) : ℍr)
  have hn : ‖(q : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h1 : (q : ℍr) * star (q : ℍr) = 1 := by
    rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hn]
    simp
  have h2 : (q : ℍr)⁻¹ = star (q : ℍr) := inv_eq_of_mul_eq_one_right h1
  rw [Metric.unitSphere.coe_inv, h2]

theorem starB_preserving : MeasurePreserving starB haarBall haarBall := by
  refine ⟨continuous_starB.measurable, ?_⟩
  unfold haarBall
  rw [Measure.map_map continuous_starB.measurable continuous_incl.measurable]
  have hc : starB ∘ incl = incl ∘ (fun q : SU2 => q⁻¹) := funext starB_incl
  rw [hc, ← Measure.map_map continuous_incl.measurable continuous_inv.measurable]
  congr 1
  have h := CompactHaar.haarTop_inv_eq (G := SU2)
  rw [Measure.inv_def] at h
  exact h

theorem sig_preserving (N : ℕ) [NeZero N] (ℓ : Lk N) :
    MeasurePreserving (sig N ℓ) haarBall haarBall := by
  unfold sig; split_ifs
  · exact starB_preserving
  · exact MeasurePreserving.id _

end Measure

/-! ### Wilson's weight and its factorisation -/

section Wilson

variable (N : ℕ) [NeZero N] (M : ℕ)

instance : Nonempty QBall := ⟨⟨0, by rw [mem_closedBall_zero_iff, norm_zero]; exact zero_le_one⟩⟩

/-- link variable as a quaternion -/
noncomputable def Uq (ω : Lk N → QBall) (ℓ : Lk N) : ℍr := (ω ℓ : ℍr)

/-- plaquette holonomy `U(x,μ) U(x+μ,ν) U(x+ν,μ)* U(x,ν)*` of a quaternion field -/
noncomputable def holQ (U : Lk N → ℍr) (p : Lk N × Fin 4) : ℍr :=
  U p.1 * U (p.1.1 + ev N p.1.2, p.2) * star (U (p.1.1 + ev N p.2, p.1.2)) * star (U (p.1.1, p.2))

noncomputable def hol (ω : Lk N → QBall) (p : Lk N × Fin 4) : ℍr := holQ N (Uq N ω) p

/-- the unoriented plaquettes `(x, μ, ν)`, `μ < ν` -/
def plaqs : Finset (Lk N × Fin 4) := Finset.univ.filter (fun p => p.1.2 < p.2)

/-- Wilson's action without the constant: `Σ_p Re U_p` (`Re U = ½ tr U`) -/
noncomputable def action (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, (hol N ω p).re

/-- share of a plaquette in the positive half: `1` strictly positive, `½` in a plane -/
noncomputable def wt (p : Lk N × Fin 4) : ℝ :=
  if p.1.2 = 0 then (if tm N p.1 < M then 1 else 0)
  else (if 0 < tm N p.1 ∧ tm N p.1 < M then 1 else if tm N p.1 = 0 ∨ tm N p.1 = M then 1 / 2 else 0)

noncomputable def halfAction (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, wt N M p * (hol N ω p).re

/-- Wilson's weight `exp(β Σ_p ½ tr U_p)` -/
noncomputable def wilsonWeight (β : ℝ) (ω : Lk N → QBall) : ℝ := Real.exp (β * action N ω)

/-- the weight of the closed positive half -/
noncomputable def halfWeight (β : ℝ) (ω : Lk N → QBall) : ℝ := Real.exp (β * halfAction N M ω)

/-- the reflected quaternion field (the field of `reflCfg`) -/
noncomputable def reflQ (U : Lk N → ℍr) (ℓ : Lk N) : ℍr :=
  if ℓ.2 = 0 then star (U (thL N ℓ)) else U (thL N ℓ)

theorem Uq_refl (ω : Lk N → QBall) : Uq N (linkRefl (thL N) (sig N) ω) = reflQ N (Uq N ω) := by
  funext ℓ; exact refl_apply N ω ℓ

theorem re_cyc (p q : ℍr) : (p * q).re = (q * p).re := by
  simp only [Quaternion.re_mul]; ring

theorem quat4 (a b c d : ℍr) :
    (star a * b * star (star c) * star d).re = (a * d * star c * star b).re := by
  rw [star_star, mul_assoc (star a * b), mul_assoc (star a), re_cyc,
    show b * (c * star d) * star a = star (a * d * star c * star b) by
      simp only [star_mul, star_star, mul_assoc],
    Quaternion.re_star]

/-- **Reflection of a plaquette.**  `Re U_p(Θω) = Re U_{θp}(ω)`; for a temporal plaquette the
reflected holonomy is a cyclic rotation of the star of the holonomy of the reflected plaquette. -/
theorem holQ_refl (U : Lk N → ℍr) (x : Site N) (μ ν : Fin 4) (hlt : μ < ν) :
    (holQ N (reflQ N U) ((x, μ), ν)).re = (holQ N U (thL N (x, μ), ν)).re := by
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  by_cases hμ : μ = 0
  · subst hμ
    have e1 : thS N (x + ev N 0) = thS N x - ev N 0 := by
      rw [thS_add, thS_ev0, sub_eq_add_neg]
    have e2 : thS N (x + ev N ν) - ev N 0 = thS N x - ev N 0 + ev N ν := by
      rw [thS_add, thS_ev N hν]; abel
    simp only [holQ, reflQ, thL, hν, if_true, if_false, eq_self_iff_true, ↓reduceIte]
    rw [e1, e2, sub_add_cancel]
    exact quat4 _ _ _ _
  · simp only [holQ, reflQ, thL, hμ, hν, if_false, ↓reduceIte, thS_add, thS_ev N hμ, thS_ev N hν]

theorem sum_refl (g : Lk N × Fin 4 → ℝ) :
    ∑ p ∈ plaqs N, g (thL N p.1, p.2) = ∑ p ∈ plaqs N, g p := by
  refine Finset.sum_nbij' (fun p => (thL N p.1, p.2)) (fun p => (thL N p.1, p.2)) ?_ ?_ ?_ ?_ ?_
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thL_snd]; exact hp
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thL_snd]; exact hp
  · intro p _; exact Prod.ext (thL_invol N p.1) rfl
  · intro p _; exact Prod.ext (thL_invol N p.1) rfl
  · intro p _; rfl

theorem wt_add (hN : N = 2 * M) (ℓ : Lk N) (ν : Fin 4) :
    wt N M (thL N ℓ, ν) + wt N M (ℓ, ν) = 1 := by
  have hlt := tm_lt N ℓ
  simp only [wt, thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [tm_thL_temporal N ℓ h2]
    simp only [h2, ↓reduceIte]
    split_ifs <;> first | omega | (norm_num; done) | simp_all
  · by_cases h0 : tm N ℓ = 0
    · rw [tm_thL_spatial0 N ℓ h2 h0]
      simp only [h2, ↓reduceIte]
      split_ifs <;> first | omega | (norm_num; done) | simp_all
    · rw [tm_thL_spatial N ℓ h2 h0]
      simp only [h2, ↓reduceIte]
      split_ifs <;> first | omega | (norm_num; done) | simp_all

/-- **The action splits**: `S(ω) = S₊(ω) + S₊(Θω)`. -/
theorem action_split (hN : N = 2 * M) (ω : Lk N → QBall) :
    action N ω = halfAction N M ω + halfAction N M (linkRefl (thL N) (sig N) ω) := by
  have h1 : ∀ p ∈ plaqs N,
      (hol N (linkRefl (thL N) (sig N) ω) p).re = (hol N ω (thL N p.1, p.2)).re := by
    rintro ⟨⟨x, μ⟩, ν⟩ hp
    have hlt : μ < ν := by simpa [plaqs] using hp
    show (holQ N (Uq N (linkRefl (thL N) (sig N) ω)) _).re = (holQ N (Uq N ω) _).re
    rw [Uq_refl]
    exact holQ_refl N _ x μ ν hlt
  have h2 : ∑ p ∈ plaqs N, wt N M p * (hol N (linkRefl (thL N) (sig N) ω) p).re
      = ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re := by
    calc ∑ p ∈ plaqs N, wt N M p * (hol N (linkRefl (thL N) (sig N) ω) p).re
        = ∑ p ∈ plaqs N, wt N M p * (hol N ω (thL N p.1, p.2)).re :=
          Finset.sum_congr rfl (fun p hp => by rw [h1 p hp])
      _ = ∑ p ∈ plaqs N, (fun q => wt N M (thL N q.1, q.2) * (hol N ω q).re) (thL N p.1, p.2) :=
          Finset.sum_congr rfl (fun p _ => by simp only [thL_invol N p.1, Prod.mk.eta])
      _ = ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re :=
          sum_refl N (fun q => wt N M (thL N q.1, q.2) * (hol N ω q).re)
  have h3 : action N ω = ∑ p ∈ plaqs N, wt N M p * (hol N ω p).re
      + ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re := by
    unfold action
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun p _ => ?_)
    have h := wt_add N M hN p.1 p.2
    rw [Prod.mk.eta] at h
    linear_combination (-(hol N ω p).re) * h
  rw [h3]
  unfold halfAction
  rw [h2]

/-- **Wilson's weight factorises**: `W(ω) = a(ω) a(Θω)`. -/
theorem weight_factor (hN : N = 2 * M) (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β ω = halfWeight N M β ω * halfWeight N M β (linkRefl (thL N) (sig N) ω) := by
  unfold wilsonWeight halfWeight
  rw [← Real.exp_add, action_split N M hN, mul_add]

theorem add_ev_zero (x : Site N) {κ : Fin 4} (hκ : κ ≠ 0) : (x + ev N κ) 0 = x 0 := by
  simp [ev_zero N hκ]

theorem add_ev0_val (x : Site N) (h : (x 0).val + 1 < N) : ((x + ev N 0) 0).val = (x 0).val + 1 := by
  simp only [Pi.add_apply, ev, Pi.single_eq_same]
  exact val_add_one N _ h

/-- **The half weight depends only on the closed positive half.** -/
theorem halfAction_dep (hN : N = 2 * M) (ω ω' : Lk N → QBall)
    (h : ∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) : halfAction N M ω = halfAction N M ω' := by
  unfold halfAction
  refine Finset.sum_congr rfl (fun p hp => ?_)
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  have hlt : μ < ν := by simpa [plaqs] using hp
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  have hv := ZMod.val_lt (x 0)
  have hall : ∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → (ω ℓ : ℍr) = (ω' ℓ : ℍr) :=
    fun ℓ h' => by rw [h ℓ h']
  by_cases hw : wt N M ((x, μ), ν) = 0
  · rw [hw, zero_mul, zero_mul]
  · congr 1
    simp only [hol, holQ, Uq]
    by_cases hμ : μ = 0
    · subst hμ
      have hvM : (x 0).val < M := by
        by_contra hc
        apply hw
        simp only [wt]
        rw [if_neg (show ¬ tm N (x, 0) < M from hc)]
        simp
      rw [hall (x, 0) (closed_temporal x hvM),
        hall (x + ev N 0, ν) (closed_spatial (x + ev N 0) ν hν
          (by rw [add_ev0_val N x (by omega)]; omega)),
        hall (x + ev N ν, 0) (closed_temporal (x + ev N ν) (by rw [add_ev_zero N x hν]; exact hvM)),
        hall (x, ν) (closed_spatial x ν hν (by omega))]
    · have hvM : (x 0).val ≤ M := by
        by_contra hc
        apply hw
        have ht : tm N (x, μ) = (x 0).val := rfl
        simp only [wt]
        rw [if_neg hμ, if_neg (show ¬ (0 < tm N (x, μ) ∧ tm N (x, μ) < M) by omega),
          if_neg (show ¬ (tm N (x, μ) = 0 ∨ tm N (x, μ) = M) by omega)]
      rw [hall (x, μ) (closed_spatial x μ hμ hvM),
        hall (x + ev N μ, ν) (closed_spatial (x + ev N μ) ν hν (by rw [add_ev_zero N x hμ]; exact hvM)),
        hall (x + ev N ν, μ) (closed_spatial (x + ev N ν) μ hμ (by rw [add_ev_zero N x hν]; exact hvM)),
        hall (x, ν) (closed_spatial x ν hν hvM)]

theorem abs_re_le (q : ℍr) : |q.re| ≤ ‖q‖ := by
  have h := abs_real_inner_le_norm q 1
  rw [Quaternion.inner_def, star_one, mul_one, norm_one, mul_one] at h
  exact h

theorem abs_hol_re (ω : Lk N → QBall) (p : Lk N × Fin 4) : |(hol N ω p).re| ≤ 1 := by
  refine (abs_re_le _).trans ?_
  have hb : ∀ ℓ, ‖Uq N ω ℓ‖ ≤ 1 := fun ℓ => mem_closedBall_zero_iff.1 (ω ℓ).2
  simp only [hol, holQ]
  rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
  exact mul_le_one₀ (mul_le_one₀ (mul_le_one₀ (hb _) (norm_nonneg _) (hb _)) (norm_nonneg _)
    (hb _)) (norm_nonneg _) (hb _)

theorem abs_wt (p : Lk N × Fin 4) : |wt N M p| ≤ 1 := by
  unfold wt; split_ifs <;> norm_num

theorem abs_halfAction (ω : Lk N → QBall) : |halfAction N M ω| ≤ (plaqs N).card := by
  unfold halfAction
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ p ∈ plaqs N, |wt N M p * (hol N ω p).re| ≤ ∑ _p ∈ plaqs N, (1 : ℝ) :=
        Finset.sum_le_sum (fun p _ => by
          rw [abs_mul]; exact mul_le_one₀ (abs_wt N M p) (abs_nonneg _) (abs_hol_re N ω p))
    _ = (plaqs N).card := by simp

theorem abs_halfWeight (β : ℝ) (ω : Lk N → QBall) :
    |halfWeight N M β ω| ≤ Real.exp (|β| * (plaqs N).card) := by
  unfold halfWeight
  rw [abs_of_pos (Real.exp_pos _), Real.exp_le_exp]
  calc β * halfAction N M ω ≤ |β * halfAction N M ω| := le_abs_self _
    _ = |β| * |halfAction N M ω| := abs_mul _ _
    _ ≤ |β| * (plaqs N).card := mul_le_mul_of_nonneg_left (abs_halfAction N M ω) (abs_nonneg _)

theorem continuous_Uq (ℓ : Lk N) : Continuous (fun ω : Lk N → QBall => Uq N ω ℓ) :=
  continuous_subtype_val.comp (continuous_apply ℓ)

theorem continuous_hol (p : Lk N × Fin 4) : Continuous (fun ω : Lk N → QBall => hol N ω p) := by
  simp only [hol, holQ]
  exact (((continuous_Uq N _).mul (continuous_Uq N _)).mul (continuous_Uq N _).star).mul
    (continuous_Uq N _).star

theorem continuous_halfWeight (β : ℝ) : Continuous (halfWeight N M β) := by
  unfold halfWeight halfAction
  exact Real.continuous_exp.comp (continuous_const.mul (continuous_finsetSum _ (fun p _ =>
    continuous_const.mul (Quaternion.continuous_re.comp (continuous_hol N p)))))

theorem continuous_wilsonWeight (β : ℝ) : Continuous (wilsonWeight N β) := by
  unfold wilsonWeight action
  exact Real.continuous_exp.comp (continuous_const.mul (continuous_finsetSum _ (fun p _ =>
    Quaternion.continuous_re.comp (continuous_hol N p))))

/-- The Wilson measure of `SU(2)` on the periodic lattice `(ℤ/N)⁴` (unnormalised: the positive
constant `Z⁻¹ e^{-β·#plaquettes}` is omitted; it does not change the sign of the pairing). -/
noncomputable def wilsonMeasure (β : ℝ) : Measure (Lk N → QBall) :=
  (Measure.pi fun _ : Lk N => haarBall).withDensity
    (fun ω => ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal))

/-- **Premise 10 for the Wilson measure (Lean).**  Site reflection positivity of the Wilson
measure of `SU(2)` on `(ℤ/N)⁴`, `N = 2M`, for every real `β`, every bounded measurable `f` of
the links of the closed positive half (`fixP ∨ posP`: spatial links at times `0 … M`, temporal
links from times `0 … M - 1`).  Paper A, (RP1) / Appendix RP; Osterwalder–Seiler. -/
theorem wilson_rp (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f)
    (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  have key : ∀ ω, (Real.toNNReal (wilsonWeight N β ω)) • (f (linkRefl (thL N) (sig N) ω) * f ω)
      = f (linkRefl (thL N) (sig N) ω) * f ω *
        (halfWeight N M β ω * halfWeight N M β (linkRefl (thL N) (sig N) ω)) := by
    intro ω
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal (wilsonWeight N β ω) (Real.exp_pos _).le,
      weight_factor N M hN β ω]
    ring
  simp_rw [key]
  exact rp_weighted haarBall (thL N) (sig N) (fixP N M) (posP N M) (thL_invol N)
    (hfix_torus hN) (fun ℓ h => hposfix_torus ℓ h) (hA_torus hN) (hB_torus hN)
    (sig_preserving N) f (halfWeight N M β) hf (continuous_halfWeight N M β).measurable Cf
    (Real.exp (|β| * (plaqs N).card)) hfC (abs_halfWeight N M β) hfdep
    (fun ω ω' h => by unfold halfWeight; rw [halfAction_dep N M hN ω ω' h])

/-- the half-slab of `BoxReflSlab.lean` (`halfSlab L n` with `N = 2ⁿ L`) -/
def halfSlabT : Set (ZMod N) := {t | ∃ i : ℕ, 2 * i + 2 ≤ N ∧ t = (i : ZMod N)}

theorem halfSlab_closed (hN : N = 2 * M) (ℓ : Lk N) (h : ℓ.1 0 ∈ halfSlabT N) :
    fixP N M ℓ ∨ posP N M ℓ := by
  obtain ⟨i, hi, he⟩ := h
  obtain ⟨x, κ⟩ := ℓ
  simp only at he
  have hv : (x 0).val = i := by rw [he, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]
  by_cases h2 : κ = 0
  · subst h2; exact closed_temporal x (by omega)
  · exact closed_spatial x κ h2 (by omega)

/-- **The hypothesis `hRP` of `reflection_positive_down_slab`, for the Wilson measure**, on
the class narrowed to bounded measurable functions of the half-slab links (the class of
`FineRP` and of paper A's (RP1)). -/
theorem wilson_rp_halfSlab (hN : N = 2 * M) (β : ℝ) :
    ∀ f ∈ {f : (Lk N → QBall) → ℝ | Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
        ∃ φ : ({ℓ : Lk N // ℓ.1 0 ∈ halfSlabT N} → QBall) → ℝ, ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := by
  rintro f ⟨hf, ⟨C, hC⟩, φ, hφ⟩
  refine wilson_rp N M hN β f hf C hC (fun ω ω' h => ?_)
  rw [hφ ω, hφ ω']
  congr 1
  funext ℓ
  exact h ℓ.1 (halfSlab_closed N M hN ℓ.1 ℓ.2)

/-- the side condition `N = 2M` is met by `N = 2ⁿ L` for `n ≥ 1` -/
theorem even_box (L n : ℕ) (hn : 1 ≤ n) : 2 ^ n * L = 2 * (2 ^ (n - 1) * L) := by
  obtain ⟨k, rfl⟩ : ∃ k, n = k + 1 := ⟨n - 1, by omega⟩
  rw [pow_succ]; simp; ring

end Wilson

end TorusRP


-- ===== new part : the slab locality with the narrowed class, and premise 10 paid =====
/-! # `reflection_positive_down_slab` with the bounded measurable class, and its hypothesis paid for
the Wilson measure

s 1 and 2.
* `reflection_positive_down_slab_bdd` : the same conclusion as `reflection_positive_down_slab`,
  with `hRP` required only for *bounded measurable* functions of the half-slab links (the class of
  `FineRP` and of paper A's (RP1); a weaker hypothesis, so a stronger theorem), and `F` bounded.
* `wilson_down_slab` : `hRP` paid by `TorusRP.wilson_rp_halfSlab` for the plain Wilson measure of
  `SU(2)` on the fine torus `(ℤ/2ⁿL)⁴`, `n ≥ 1` (so that `N_n` is even and the partner plane is a
  plane of sites).  No hypothesis on the measure is left: reflection positivity of the
  push-forward to the coarse level `m` for the coarse strip `1 … 1 + c`.  Finite volume; the
  statement holds for every `n ≥ m ≥ 0`, `β ∈ ℝ` (it is an exact property, no uniformity needed).
-/

namespace BoxWalk

open WalkCast ChainBlockMap Finset MeasureTheory

section SlabBdd

variable (L : ℕ) [NeZero L]

/-- locality of the block map on the strip, as an explicit factorisation through the half slab -/
theorem down_strip_local {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n) (c : ℕ)
    (hc : 2 * c + 6 ≤ 2 ^ m * L) (F : Cfg (BoxLk L m) → ℝ)
    (hFpos : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ strip L m c} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    ∃ ψ : ({ℓ : BoxLk L n // ℓ.1 0 ∈ halfSlab L n} → Ball) → ℝ,
      ∀ ω, F (down r₀ hr (boxPaths L) (boxW L) n m ω) = ψ (fun ℓ => ω ℓ.1) := by
  have hsub : stripFam L m c n ⊆ halfSlab L n := by
    rw [stripFam_of_le L m c n hmn]
    exact strip_sub_half L m c n hmn hc
  have hFpos' : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ stripFam L m c m} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1) := by
    rw [stripFam_self]; exact hFpos
  obtain ⟨φ, hφ⟩ := hFpos'
  have hloc : ∀ ω : Cfg (BoxLk L n),
      (fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ stripFam L m c m} =>
        down r₀ hr (boxPaths L) (boxW L) n m ω ℓ.1) =
        fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ stripFam L m c m} =>
          down r₀ hr (boxPaths L) (boxW L) n m
            (extPos L n (stripFam L m c n) (fun ℓ' => ω ℓ'.1)) ℓ.1 := by
    intro ω
    funext ℓ
    refine down_pos_local L hr n (stripFam L m c) (stripFam_hcube L m c) (n - m) m (by omega)
      ω _ ?_ ℓ.1 ℓ.2
    intro x hx ν
    simp only [extPos, dif_pos hx]
  obtain ⟨ψ, hψ⟩ := LatticeBlockReflection.pullback_mem_positive
    (fun ω : Cfg (BoxLk L n) => fun ℓ : {ℓ : BoxLk L n // ℓ.1 0 ∈ stripFam L m c n} => ω ℓ.1)
    (fun ω => fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ stripFam L m c m} =>
      down r₀ hr (boxPaths L) (boxW L) n m ω ℓ.1) φ
    (fun p => fun ℓ : {ℓ : BoxLk L m // ℓ.1 0 ∈ stripFam L m c m} =>
      down r₀ hr (boxPaths L) (boxW L) n m (extPos L n (stripFam L m c n) p) ℓ.1) hloc
  exact ⟨fun p => ψ (fun ℓ => p ⟨ℓ.1, hsub ℓ.2⟩), fun ω => (hφ _).trans (hψ ω)⟩

/-- **`reflection_positive_down_slab` with the bounded measurable class** (1). -/
theorem reflection_positive_down_slab_bdd {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hmn : m ≤ n)
    (c : ℕ) (hc : 2 * c + 6 ≤ 2 ^ m * L)
    (μ : Measure (Cfg (BoxLk L n)))
    (hRP : ∀ f ∈ {f : Cfg (BoxLk L n) → ℝ | Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
        ∃ φ : ({ℓ : BoxLk L n // ℓ.1 0 ∈ halfSlab L n} → Ball) → ℝ, ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (reflCfg L n ω) * f ω ∂μ)
    (F : Cfg (BoxLk L m) → ℝ) (hF : Measurable F) (hFb : ∃ C, ∀ e, |F e| ≤ C)
    (hFpos : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ strip L m c} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    0 ≤ ∫ e, F (reflCfg L m e) * F e ∂(μ.map (down r₀ hr (boxPaths L) (boxW L) n m)) := by
  obtain ⟨C, hC⟩ := hFb
  exact reflection_positive_down L hr n m hmn μ _ hRP F hF
    ⟨hF.comp (continuous_down r₀ hr (boxPaths L) (boxW L) n m).measurable,
      ⟨C, fun ω => hC _⟩, down_strip_local L hr n m hmn c hc F hFpos⟩

/-- `reflCfg` is the link reflection of `TorusRP` -/
theorem reflCfg_eq_linkRefl (n : ℕ) (ω : Cfg (BoxLk L n)) :
    reflCfg L n ω = LinkReflection.linkRefl (TorusRP.thL (2 ^ n * L)) (TorusRP.sig (2 ^ n * L)) ω := by
  funext ℓ
  apply Subtype.ext
  rw [TorusRP.refl_apply]
  simp only [reflCfg, reflV, TorusRP.thL]
  split_ifs <;> rfl

/-- **Premise 10 paid in the locality step (Lean).**  For the plain Wilson measure of `SU(2)` on
the fine torus `(ℤ/2ⁿL)⁴` (`n ≥ 1`, every `β`), the push-forward by the block map `down` to the
coarse level `m ≤ n` is reflection positive for every bounded measurable `F` of the coarse links
with base time in `{1, …, 1 + c}`, `2c + 6 ≤ N_m`.  No hypothesis on the measure.  Paper A,
premise 10 / (RP1) and the locality of Definition positive-time.  Finite volume. -/
theorem wilson_down_slab {r₀ : ℝ} (hr : 0 < r₀) (n m : ℕ) (hn : 1 ≤ n) (hmn : m ≤ n)
    (c : ℕ) (hc : 2 * c + 6 ≤ 2 ^ m * L) (β : ℝ)
    (F : Cfg (BoxLk L m) → ℝ) (hF : Measurable F) (hFb : ∃ C, ∀ e, |F e| ≤ C)
    (hFpos : ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ strip L m c} → Ball) → ℝ,
      ∀ e, F e = φ (fun ℓ => e ℓ.1)) :
    0 ≤ ∫ e, F (reflCfg L m e) * F e
      ∂((TorusRP.wilsonMeasure (2 ^ n * L) β).map (down r₀ hr (boxPaths L) (boxW L) n m)) := by
  refine reflection_positive_down_slab_bdd L hr n m hmn c hc _ (fun f hf => ?_) F hF hFb hFpos
  have h := TorusRP.wilson_rp_halfSlab (2 ^ n * L) (2 ^ (n - 1) * L) (TorusRP.even_box L n hn) β
    f hf
  simp only [← reflCfg_eq_linkRefl L n] at h
  exact h

end SlabBdd

end BoxWalk

#print axioms BoxWalk.reflection_positive_down_slab
#print axioms BoxWalk.down_strip_local
#print axioms BoxWalk.reflection_positive_down_slab_bdd
#print axioms BoxWalk.reflCfg_eq_linkRefl
#print axioms BoxWalk.wilson_down_slab
#print axioms TorusRP.wilson_rp_halfSlab

/-! # The normalised Wilson measure (a `ProbabilityMeasure`) — 

the chain fields (`hΘp` of `chain_end_to_end_blockMap`)
take a family of `ProbabilityMeasure`s.  `wilsonMeasure N β` is the Wilson measure up to the
positive constant `Z e^{-β #plaquettes}`; here its total mass is shown to be finite and positive,
and `wilsonProb N β := (μ univ)⁻¹ • μ` is the normalised Wilson measure of paper A, line 73. -/

namespace TorusRP

open MeasureTheory

variable (N : ℕ) [NeZero N]

theorem abs_action_le (ω : Lk N → QBall) : |action N ω| ≤ (plaqs N).card := by
  unfold action
  calc |∑ p ∈ plaqs N, (hol N ω p).re| ≤ ∑ p ∈ plaqs N, |(hol N ω p).re| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _p ∈ plaqs N, (1 : ℝ) := Finset.sum_le_sum (fun p _ => abs_hol_re N ω p)
    _ = (plaqs N).card := by simp

theorem abs_beta_action_le (β : ℝ) (ω : Lk N → QBall) :
    |β * action N ω| ≤ |β| * (plaqs N).card := by
  rw [abs_mul]; exact mul_le_mul_of_nonneg_left (abs_action_le N ω) (abs_nonneg _)

theorem wilsonWeight_le (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β ω ≤ Real.exp (|β| * (plaqs N).card) := by
  unfold wilsonWeight
  exact Real.exp_le_exp.2 ((le_abs_self _).trans (abs_beta_action_le N β ω))

theorem wilsonWeight_ge (β : ℝ) (ω : Lk N → QBall) :
    Real.exp (-(|β| * (plaqs N).card)) ≤ wilsonWeight N β ω := by
  unfold wilsonWeight
  apply Real.exp_le_exp.2
  have h1 := abs_beta_action_le N β ω
  have h2 := neg_abs_le (β * action N ω)
  linarith

theorem wilsonMeasure_univ (β : ℝ) : wilsonMeasure N β Set.univ =
    ∫⁻ ω, ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal)
      ∂(Measure.pi fun _ : Lk N => haarBall) := by
  rw [wilsonMeasure, withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ]

theorem wilsonMeasure_univ_lt_top (β : ℝ) : wilsonMeasure N β Set.univ < ⊤ := by
  rw [wilsonMeasure_univ]
  calc ∫⁻ ω, ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall)
      ≤ ∫⁻ _ω, ((Real.toNNReal (Real.exp (|β| * (plaqs N).card)) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall) :=
        lintegral_mono (fun ω => ENNReal.coe_le_coe.mpr
          (Real.toNNReal_le_toNNReal (wilsonWeight_le N β ω)))
    _ < ⊤ := by
        rw [lintegral_const, measure_univ, mul_one]; exact ENNReal.coe_lt_top

theorem wilsonMeasure_univ_pos (β : ℝ) : 0 < wilsonMeasure N β Set.univ := by
  rw [wilsonMeasure_univ]
  calc (0 : ENNReal) < ((Real.toNNReal (Real.exp (-(|β| * (plaqs N).card))) : NNReal) : ENNReal) := by
        rw [ENNReal.coe_pos, Real.toNNReal_pos]; exact Real.exp_pos _
    _ = ∫⁻ _ω, ((Real.toNNReal (Real.exp (-(|β| * (plaqs N).card))) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall) := by
        rw [lintegral_const, measure_univ, mul_one]
    _ ≤ _ := lintegral_mono (fun ω => ENNReal.coe_le_coe.mpr
          (Real.toNNReal_le_toNNReal (wilsonWeight_ge N β ω)))

instance wilsonMeasure_finite (β : ℝ) : IsFiniteMeasure (wilsonMeasure N β) :=
  ⟨wilsonMeasure_univ_lt_top N β⟩

instance wilsonMeasure_neZero (β : ℝ) : NeZero (wilsonMeasure N β) :=
  ⟨fun h => by
    have := wilsonMeasure_univ_pos N β
    rw [h] at this
    simp at this⟩

/-- **The normalised Wilson measure** `μ_N = Z⁻¹ e^{β Σ_p Re U_p} ∏ dU` (paper A, line 73; the
constant `e^{-β #plaquettes}` of `1 - ½ tr U_p` cancels in the normalisation). -/
noncomputable def wilsonProb (β : ℝ) : ProbabilityMeasure (Lk N → QBall) :=
  ⟨(wilsonMeasure N β Set.univ)⁻¹ • wilsonMeasure N β, inferInstance⟩

theorem wilsonProb_toMeasure (β : ℝ) :
    (wilsonProb N β : Measure (Lk N → QBall)) =
      (wilsonMeasure N β Set.univ)⁻¹ • wilsonMeasure N β := rfl

/-- (RP1) for the normalised measure (a positive multiple). -/
theorem wilsonProb_rp (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (LinkReflection.linkRefl (thL N) (sig N) ω) * f ω
      ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  rw [wilsonProb_toMeasure, integral_smul_measure]
  exact smul_nonneg ENNReal.toReal_nonneg (wilson_rp N M hN β f hf Cf hfC hfdep)

end TorusRP

#print axioms TorusRP.wilsonMeasure_univ_pos
#print axioms TorusRP.wilsonProb
#print axioms TorusRP.wilsonProb_rp

/-! # Paying the chain field `hΘp` for the Wilson measure — 

  The field of `chain_end_to_end_blockMap` /
`chain_end_to_end_box` is
`hΘp : ∀ m, ∀ᶠ n in atTop, ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(νP r₀ hr paths w μ n m)`.
Here it is proved, with no hypothesis, for
* `μ n := TorusRP.wilsonProb (2ⁿL) (β n)` (the normalised `SU(2)` Wilson measure on `(ℤ/2ⁿL)⁴`,
  any sequence of couplings),
* `Θ m := reflCfg L m` (the site reflection `x₀ ↦ -x₀`; continuous: `continuous_reflCfg`),
* `Aset m := stripSet L c m` (bounded continuous functions of the coarse links with base time in
  `{1, …, 1 + c}`, when `2c + 6 ≤ 2^m L`; empty otherwise).
The values are the closed quaternion ball of `ChainBlockMap.Ball`, the same type as the chain's
`Cfg`; the measure is carried by `SU(2)`.  Only the site-reflection family is covered (no
link-midpoint planes, no (RP3)). -/

namespace BoxWalk

open WalkCast ChainBlockMap Finset MeasureTheory Filter

section ChainPlug

variable (L : ℕ) [NeZero L]

/-- the class `Aset m`: bounded continuous functions of the coarse strip `1 … 1 + c` -/
def stripSet (c m : ℕ) : Set (BoundedContinuousFunction (Cfg (BoxLk L m)) ℝ) :=
  {F | 2 * c + 6 ≤ 2 ^ m * L ∧
    ∃ φ : ({ℓ : BoxLk L m // ℓ.1 0 ∈ strip L m c} → Ball) → ℝ, ∀ e, F e = φ (fun ℓ => e ℓ.1)}

/-- **The chain field `hΘp`, paid for the normalised Wilson measure (no hypothesis).** -/
theorem wilson_hΘp {r₀ : ℝ} (hr : 0 < r₀) (β : ℕ → ℝ) (c : ℕ) :
    ∀ m, ∀ᶠ n in atTop, ∀ F ∈ stripSet L c m,
      0 ≤ ∫ ω, F (reflCfg L m ω) * F ω
        ∂(νP r₀ hr (boxPaths L) (boxW L)
            (fun n => TorusRP.wilsonProb (2 ^ n * L) (β n)) n m : Measure (Cfg (BoxLk L m))) := by
  intro m
  filter_upwards [eventually_ge_atTop (max m 1)] with n hn
  rintro F ⟨hc, hFpos⟩
  rw [νP, ProbabilityMeasure.toMeasure_map, TorusRP.wilsonProb_toMeasure, Measure.map_smul,
    integral_smul_measure]
  apply smul_nonneg ENNReal.toReal_nonneg
  exact wilson_down_slab L hr n m (le_trans (le_max_right _ _) hn)
    (le_trans (le_max_left _ _) hn) c hc (β n) F F.continuous.measurable
    ⟨‖F‖, fun e => by simpa [Real.norm_eq_abs] using F.norm_coe_le_norm e⟩ hFpos

/-- `Aset m` is not trivial: `cos (Re U_ℓ₀)` of one coarse link at time `1` belongs to it. -/
theorem stripSet_witness (c m : ℕ) (hc : 2 * c + 6 ≤ 2 ^ m * L) :
    ∃ F ∈ stripSet L c m, ∀ e, F e = Real.cos ((e ((fun _ => 1), 0) : Quaternion ℝ).re) := by
  have hcont : Continuous (fun e : Cfg (BoxLk L m) =>
      Real.cos ((e ((fun _ => 1), 0) : Quaternion ℝ).re)) :=
    Real.continuous_cos.comp (Quaternion.continuous_re.comp
      (continuous_subtype_val.comp (continuous_apply _)))
  refine ⟨BoundedContinuousFunction.mkOfBound ⟨_, hcont⟩ 2 (fun x y => ?_), ⟨hc, ?_⟩, fun e => rfl⟩
  · simp only [ContinuousMap.coe_mk, Real.dist_eq]
    have h1 := Real.abs_cos_le_one ((x ((fun _ => 1), 0) : Quaternion ℝ).re)
    have h2 := Real.abs_cos_le_one ((y ((fun _ => 1), 0) : Quaternion ℝ).re)
    calc _ ≤ |Real.cos ((x ((fun _ => 1), 0) : Quaternion ℝ).re)|
          + |Real.cos ((y ((fun _ => 1), 0) : Quaternion ℝ).re)| := abs_sub _ _
      _ ≤ 2 := by linarith
  · have hmem : (((fun _ => 1), 0) : BoxLk L m).1 0 ∈ strip L m c :=
      ⟨0, Nat.zero_le _, by simp⟩
    exact ⟨fun g => Real.cos ((g ⟨((fun _ => 1), 0), hmem⟩ : Quaternion ℝ).re), fun e => rfl⟩

end ChainPlug

end BoxWalk

#print axioms BoxWalk.wilson_hΘp
#print axioms BoxWalk.stripSet_witness
#print axioms TorusRP.wilsonProb_rp

/-! # The chain theorem with its field `hΘp` discharged for the Wilson measure — 
`chain_end_to_end_box` applied with `μ n := wilsonProb (2ⁿL) (β n)`, `Θ := reflCfg L`,
`Aset := stripSet L c` and `hΘp := wilson_hΘp`: the resulting statement no longer has the field
`hΘp`; all its other fields are those of `chain_end_to_end_box`, unchanged. -/

namespace BoxWalk

open ChainBlockMap Filter

theorem chain_end_to_end_box_wilson (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) {X : Type*}
    [MetricSpace X] (β : ℕ → ℝ) (c : ℕ) :
    type_of% (@chain_end_to_end_box L _ r₀ hr X _
      (fun n => TorusRP.wilsonProb (2 ^ n * L) (β n))
      (Θ := reflCfg L) (Aset := stripSet L c) (hΘp := wilson_hΘp L hr β c)) :=
  @chain_end_to_end_box L _ r₀ hr X _
    (fun n => TorusRP.wilsonProb (2 ^ n * L) (β n))
    (Θ := reflCfg L) (Aset := stripSet L c) (hΘp := wilson_hΘp L hr β c)

end BoxWalk


/-! # The chain theorem with its field `hΘp` discharged for the Wilson measure — 
`chain_end_to_end_box` applied with `μ n := wilsonProb (2ⁿL) (β n)`, `Θ := reflCfg L`,
`Aset := stripSet L c` and `hΘp := wilson_hΘp`: the resulting statement no longer has the field
`hΘp`; all its other fields are those of `chain_end_to_end_box`, unchanged. -/

namespace BoxWalk

open ChainBlockMap Filter

theorem chain_end_to_end_box_wilson2 (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) {X : Type*}
    [MetricSpace X] (β : ℕ → ℝ) (c : ℕ) :
    type_of% (@chain_end_to_end_box L _ r₀ hr X _
      (fun n => TorusRP.wilsonProb (2 ^ n * L) (β n))
      (Θ := reflCfg L) (Aset := stripSet L c) (hΘc := continuous_reflCfg L) (hΘp := wilson_hΘp L hr β c)) :=
  @chain_end_to_end_box L _ r₀ hr X _
    (fun n => TorusRP.wilsonProb (2 ^ n * L) (β n))
    (Θ := reflCfg L) (Aset := stripSet L c) (hΘc := continuous_reflCfg L) (hΘp := wilson_hΘp L hr β c)

end BoxWalk

#print axioms BoxWalk.chain_end_to_end_box_wilson2
