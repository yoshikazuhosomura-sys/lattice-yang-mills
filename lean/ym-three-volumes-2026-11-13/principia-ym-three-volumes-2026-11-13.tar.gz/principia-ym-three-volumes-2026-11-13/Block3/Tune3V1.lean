import Block3.FlatV1
/-!
# Centred blocks of side 3: the tuned coupling sequence exists (no hypothesis on the lower end)

Paper: (tuning by the coarse plaquette average for the centred block map of side 3).
* `Y3 L hr m k β := ∫ Ȳ(down (m+k) m ω) d(wilsonProb (3^(m+k) L) β)`: the coarse plaquette average of the
  pushed-forward normalised Wilson measure (fine torus side `3^(m+k) L`, coarse torus side `3^m L`);
* `continuous_Y3`; **`Y3_zero`**: `Y3 m k 0 = 0` for every `k` when `1 < 3^m L` (β = 0 is the product Haar
  measure, and the sign flips of `down_flipSet` give mean zero); **`tendsto_Y3_one`**: `Y3 m k β → 1` as
  `β → ∞` for `r₀ ≤ 1` (flat ⇒ flat and the concentration bound `FlatPush.tendsto_integral_of_flat`);
* **`tuned3_exists`**: for `r₀ ≤ 1`, `1 < 3^m₀ L` and every `κ₀ ∈ [0, 1)`, a sequence `β ≥ 0` with
  `Y3 m₀ k (β (m₀+k)) = κ₀` for all `k` exists, taken as the largest solution at each `k`;
* `tuned3_example`: the case `L = 1`, `r₀ = 1`, `m₀ = 1`, `κ₀ = 1/2`.
-/

set_option maxRecDepth 4000

namespace Block3

open MeasureTheory Filter Topology Set TorusRP ChainBlockMap TunedCoupling

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- The coarse plaquette average of the pushed-forward normalised Wilson measure:
fine torus `(ℤ/3^(m+k) L)⁴`, coarse torus `(ℤ/3^m L)⁴`, `k` steps of the centred block map of side 3. -/
noncomputable def Y3 (m k : ℕ) (β : ℝ) : ℝ :=
  ∫ ω, plaqAvg (3 ^ m * L) (down r₀ hr (paths L) (wts L) (m + k) m ω)
    ∂(wilsonProb (3 ^ (m + k) * L) β : Measure _)

theorem continuous_Y3 (m k : ℕ) : Continuous (Y3 L hr m k) :=
  continuous_integral_wilsonProb (3 ^ (m + k) * L) _
    ((continuous_plaqAvg (3 ^ m * L)).comp (continuous_down r₀ hr (paths L) (wts L) (m + k) m))

/-- **β = 0: the coarse plaquette average vanishes at every k** (`1 < 3^m L`). -/
theorem Y3_zero (m k : ℕ) (hN : 1 < 3 ^ m * L) : Y3 L hr m k 0 = 0 := by
  unfold Y3
  rw [integral_wilsonProb_div, TunedCoupling.integral_wilson]
  simp only [zero_mul, Real.exp_zero, one_mul]
  unfold plaqAvg
  have hi : ∀ p ∈ plaqs (3 ^ m * L), Integrable
      (fun ω : TorusRP.Lk (3 ^ (m + k) * L) → QBall =>
        (hol (3 ^ m * L) (down r₀ hr (paths L) (wts L) (m + k) m ω) p).re)
      (Measure.pi fun _ : TorusRP.Lk (3 ^ (m + k) * L) => haarBall) := fun p _ =>
    integrable_cont _ _ (Quaternion.continuous_re.comp ((continuous_hol (3 ^ m * L) p).comp
      (continuous_down r₀ hr (paths L) (wts L) (m + k) m)))
  rw [integral_div, integral_finsetSum _ hi,
    Finset.sum_eq_zero (fun p hp => integral_re_hol_down_haar L hr (Nat.le_add_right m k) hN p hp),
    zero_div, zero_div]

/-- **The upper end**: `Y3 m k β → 1` as `β → ∞` (`r₀ ≤ 1`). -/
theorem tendsto_Y3_one (hr1 : r₀ ≤ 1) (m k : ℕ) : Tendsto (Y3 L hr m k) atTop (𝓝 1) :=
  FlatPush.tendsto_integral_of_flat (3 ^ (m + k) * L) _
    ((continuous_plaqAvg _).comp (continuous_down r₀ hr (paths L) (wts L) (m + k) m))
    (fun _ => plaqAvg_le_one _ _) (fun _ => neg_one_le_plaqAvg _ _)
    (fun ω h => plaqAvg_down_of_flat L hr hr1 (Nat.le_add_right m k) ω h)

theorem exists_tuning3 (m k : ℕ) {β₁ β₂ κ₀ : ℝ} (h12 : β₁ ≤ β₂)
    (hκ : κ₀ ∈ uIcc (Y3 L hr m k β₁) (Y3 L hr m k β₂)) :
    ∃ β ∈ Icc β₁ β₂, Y3 L hr m k β = κ₀ := by
  obtain ⟨β, hβ, e⟩ := intermediate_value_uIcc (continuous_Y3 L hr m k).continuousOn hκ
  rw [uIcc_of_le h12] at hβ
  exact ⟨β, hβ, e⟩

theorem tuning3_at_level (hr1 : r₀ ≤ 1) (m k : ℕ) (κ₀ β₁ : ℝ) (hκ : κ₀ < 1)
    (hlow : Y3 L hr m k β₁ ≤ κ₀) : ∃ β, β₁ ≤ β ∧ Y3 L hr m k β = κ₀ := by
  have hev := (tendsto_Y3_one L hr hr1 m k).eventually (eventually_gt_nhds hκ)
  obtain ⟨β₂, h2, h12⟩ := (hev.and (eventually_ge_atTop β₁)).exists
  obtain ⟨β, hβ, e⟩ := exists_tuning3 L hr m k h12 (Set.mem_uIcc.2 (Or.inl ⟨hlow, h2.le⟩))
  exact ⟨β, hβ.1, e⟩

/-- The largest nonnegative solution at one level (`r₀ ≤ 1`, `1 < 3^m L`, `0 ≤ κ₀ < 1`). -/
theorem tuning3_max_at_level (hr1 : r₀ ≤ 1) (m k : ℕ) (hN : 1 < 3 ^ m * L) (κ₀ : ℝ) (h0 : 0 ≤ κ₀)
    (hκ : κ₀ < 1) :
    ∃ β, 0 ≤ β ∧ Y3 L hr m k β = κ₀ ∧ ∀ β', β < β' → κ₀ < Y3 L hr m k β' := by
  have hlow : Y3 L hr m k 0 ≤ κ₀ := by rw [Y3_zero L hr m k hN]; exact h0
  have hc := continuous_Y3 L hr m k
  obtain ⟨B, hB⟩ := eventually_atTop.1 ((tendsto_Y3_one L hr hr1 m k).eventually (eventually_gt_nhds hκ))
  set S := {β : ℝ | 0 ≤ β ∧ Y3 L hr m k β = κ₀}
  obtain ⟨β0, h0', e0⟩ := tuning3_at_level L hr hr1 m k κ₀ 0 hκ hlow
  have hne : S.Nonempty := ⟨β0, h0', e0⟩
  have hbdd : BddAbove S := ⟨B, fun β hβ => by
    by_contra h; push Not at h
    have := hB β h.le
    rw [hβ.2] at this; exact lt_irrefl _ this⟩
  have hcl : IsClosed S := (isClosed_le continuous_const continuous_id).inter (isClosed_eq hc continuous_const)
  have hmem : sSup S ∈ S := hcl.csSup_mem hne hbdd
  refine ⟨sSup S, hmem.1, hmem.2, fun β' hβ' => ?_⟩
  by_contra hle; push Not at hle
  set B' := max β' B + 1
  have hB' : κ₀ < Y3 L hr m k B' := hB B' (by simp only [B']; linarith [le_max_right β' B])
  have h12 : β' ≤ B' := by simp only [B']; linarith [le_max_left β' B]
  obtain ⟨β, hβ, e⟩ := exists_tuning3 L hr m k h12 (Set.mem_uIcc.2 (Or.inl ⟨hle, hB'.le⟩))
  have hin : β ∈ S := ⟨by linarith [hβ.1, hmem.1], e⟩
  have := le_csSup hbdd hin
  linarith [hβ.1]

/-- The tuning equation at level `m₀` for a coupling sequence indexed by the fine level. -/
def Tuned3 (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) : Prop := ∀ k, Y3 L hr m₀ k (β (m₀ + k)) = κ₀

/-- **Existence of the tuned coupling sequence** (`r₀ ≤ 1`, `1 < 3^m₀ L`, `0 ≤ κ₀ < 1`; no other
hypothesis): a sequence `β ≥ 0` with `Y3 m₀ k (β (m₀+k)) = κ₀` for every `k`, the largest solution at each `k`. -/
theorem tuned3_exists (hr1 : r₀ ≤ 1) (m₀ : ℕ) (hN : 1 < 3 ^ m₀ * L) (κ₀ : ℝ) (h0 : 0 ≤ κ₀)
    (hκ : κ₀ < 1) :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned3 L hr m₀ κ₀ β ∧
      ∀ k, ∀ β', β (m₀ + k) < β' → κ₀ < Y3 L hr m₀ k β' := by
  choose b hb e hmax using fun k => tuning3_max_at_level L hr hr1 m₀ k hN κ₀ h0 hκ
  exact ⟨fun n => b (n - m₀), fun n => hb _, fun k => by simpa using e k,
    fun k β' h => hmax k β' (by simpa using h)⟩

/-- **Example**: side `L = 1`, `r₀ = 1`, level `m₀ = 1` (coarse torus side 3), `κ₀ = 1/2`. -/
theorem tuned3_example :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned3 1 (show (0 : ℝ) < 1 by norm_num) 1 (1 / 2) β :=
  let ⟨β, hβ, ht, _⟩ := tuned3_exists 1 (show (0 : ℝ) < 1 by norm_num) le_rfl 1 (by norm_num)
    (1 / 2) (by norm_num) (by norm_num)
  ⟨β, hβ, ht⟩

end Block3

#print axioms Block3.Y3_zero
#print axioms Block3.tendsto_Y3_one
#print axioms Block3.tuned3_exists
#print axioms Block3.tuned3_example
