import Block3.MatchV1
/-!
# Centred blocks of side 3: positivity of the push-forward of the Wilson measure

Paper: (the statement with the site plane `x₀ = 0`, every level).
`OpenPos L m Mc b`: the coarse link `b` has both ends at coarse times in `[1, Mc - 1]` (strictly
between the two site planes `0` and `Mc` of the coarse torus).
* **`down_dep_posP`**: the composed block map on such a coarse link depends only on the fine links
  of `TorusRP.posP N M` (`N = 3^n L`, `M = 3^(n-m) Mc`).
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap MeasureTheory

local notation "ℍr" => Quaternion ℝ

/-- The integer bounds behind the support (fine time `t = P Y + z`, `P = 3^k`). -/
theorem time_bounds (P Y z Q e f : ℤ) (hP : 1 ≤ P) (hY1 : 1 ≤ Y) (hY2 : Y + e + 1 ≤ Q)
    (he : e = 0 ∨ e = 1) (hz1 : -(P - 1) ≤ 2 * z) (hz2 : 2 * (z + f) ≤ P - 1 + 2 * P * e)
    (_hf : 0 ≤ f) : 1 ≤ P * Y + z ∧ P * Y + z + f < P * Q := by
  have hA1 : P * 1 ≤ P * Y := mul_le_mul_of_nonneg_left hY1 (by linarith)
  have hA2 : P * Y ≤ P * (Q - 1 - e) := mul_le_mul_of_nonneg_left (by linarith) (by linarith)
  rcases he with rfl | rfl
  · constructor <;> nlinarith
  · constructor <;> nlinarith

theorem val_cast_int {N : ℕ} [NeZero N] (t : ℤ) (h0 : 0 ≤ t) (h1 : t < N) :
    (((t : ZMod N)).val : ℤ) = t := by
  rw [ZMod.val_intCast]; exact Int.emod_eq_of_lt h0 h1

variable (L : ℕ) [NeZero L]

/-- Coarse links strictly between the coarse site planes `0` and `Mc`. -/
def OpenPos (m Mc : ℕ) (b : Lk3 L m) : Prop :=
  1 ≤ (b.1 0).val ∧ (b.1 0).val + (if b.2 = 0 then 1 else 0) + 1 ≤ Mc

theorem down_dep_posP {r₀ : ℝ} (hr : 0 < r₀) {n m Mc : ℕ} (hmn : m ≤ n) (hMc : Mc ≤ 3 ^ m * L)
    (ω ω' : Cfg (Lk3 L n))
    (hω : ∀ ℓ, TorusRP.posP (3 ^ n * L) (3 ^ (n - m) * Mc) ℓ → ω ℓ = ω' ℓ)
    (b : Lk3 L m) (hb : OpenPos L m Mc b) :
    down r₀ hr (paths L) (wts L) n m ω b = down r₀ hr (paths L) (wts L) n m ω' b := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hmn
  obtain ⟨y, μ⟩ := b
  have hy : (fun i => ((((y i).val : ℤ) : ℤ) : ZMod (3 ^ m * L))) = y := by
    funext i; simp
  have key := down_local L hr (m + k) k m rfl ω ω' (fun i => ((y i).val : ℤ)) μ (by
    intro z ν hz hz'
    apply hω
    rw [show m + k - m = k by omega]
    have hz0 := hz 0
    have hz0' := hz' 0
    simp only [Pi.add_apply, ev_apply] at hz0 hz0'
    obtain ⟨hb1, hb2⟩ := hb
    simp only at hb1 hb2
    have hP : (1 : ℤ) ≤ (3 : ℤ) ^ k := one_le_pow₀ (by norm_num)
    have hY1 : (1 : ℤ) ≤ ((y 0).val : ℤ) := by exact_mod_cast hb1
    have hY2 : ((y 0).val : ℤ) + (if (0 : Fin 4) = μ then 1 else 0) + 1 ≤ (Mc : ℤ) := by
      rcases eq_or_ne μ 0 with h | h
      · subst h; simp only [if_true] at hb2 ⊢; omega
      · have h' : ¬ (0 : Fin 4) = μ := fun e => h e.symm
        simp only [h, h', if_false] at hb2 ⊢; omega
    have hTB := time_bounds ((3 : ℤ) ^ k) ((y 0).val : ℤ) (z 0) (Mc : ℤ)
      (if (0 : Fin 4) = μ then 1 else 0) (if (0 : Fin 4) = ν then 1 else 0) hP hY1 hY2
      (by split_ifs <;> simp) hz0.1 hz0'.2
      (by split_ifs <;> norm_num)
    have hMcz : (Mc : ℤ) ≤ ((3 ^ m * L : ℕ) : ℤ) := by exact_mod_cast hMc
    have hB : (3 : ℤ) ^ k * (Mc : ℤ) ≤ (3 : ℤ) ^ k * ((3 ^ m * L : ℕ) : ℤ) :=
      mul_le_mul_of_nonneg_left hMcz (by linarith)
    have hNc : (((3 ^ (m + k) * L : ℕ) : ℤ)) = (3 : ℤ) ^ k * ((3 ^ m * L : ℕ) : ℤ) := by
      push_cast; ring
    have hf0 : (0 : ℤ) ≤ (if 0 = ν then 1 else 0) := by split_ifs <;> norm_num
    have h0 : 0 ≤ (3 : ℤ) ^ k * ((y 0).val : ℤ) + z 0 := by linarith [hTB.1]
    have h1 : (3 : ℤ) ^ k * ((y 0).val : ℤ) + z 0 < (((3 ^ (m + k) * L : ℕ) : ℤ)) := by
      rw [hNc]; linarith [hTB.2]
    have hv := val_cast_int (N := 3 ^ (m + k) * L) _ h0 h1
    have hMk : (((3 ^ k : ℕ) : ℤ)) * (Mc : ℤ) = (3 : ℤ) ^ k * (Mc : ℤ) := by push_cast; ring
    have hT1 := hTB.1
    have hT2 := hTB.2
    unfold TorusRP.posP TorusRP.tm
    beta_reduce
    by_cases hν : ν = 0
    · subst hν
      simp only [if_true] at hT2 ⊢
      omega
    · have hν' : ¬ (0 : Fin 4) = ν := fun h => hν h.symm
      simp only [hν, hν', if_false] at hT2 ⊢
      constructor <;> omega)
  rw [hy] at key
  exact key

end Block3

#print axioms Block3.down_dep_posP
