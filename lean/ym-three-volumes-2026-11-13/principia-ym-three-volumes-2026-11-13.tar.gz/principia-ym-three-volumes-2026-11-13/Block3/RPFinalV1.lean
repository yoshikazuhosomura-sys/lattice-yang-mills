import Block3.RPPushV1
/-!
# Centred blocks of side 3: reflection positivity of the push-forward of the Wilson measure

Paper: (the statement with the site plane `x₀ = 0`, every level).
**`rp_push`**: for the SU(2) Wilson measure of the fine torus of side `N = 3^n L = 2M`
(`M = 3^(n-m) Mc`, every `β`) and every bounded measurable `F` of the coarse links strictly
between the coarse site planes `0` and `Mc` (`OpenPos`; no gauge invariance),
`∫ F(Θ_m V) F(V) d(down_* wilsonMeasure)(V) ≥ 0`, for every pair of levels `m ≤ n`.
Ingredients: `push_refl_integral` (the block maps commute with the reflection), `reflCfg3_eq`
(it is the reflection of `TorusRP`), `down_dep_posP` (support), `TorusRP.wilson_rp`.
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap MeasureTheory

variable (L : ℕ) [NeZero L]

theorem rp_push {r₀ : ℝ} (hr : 0 < r₀) {n m Mc : ℕ} (hmn : m ≤ n) (hMc : Mc ≤ 3 ^ m * L)
    (hN : 3 ^ n * L = 2 * (3 ^ (n - m) * Mc)) (β : ℝ)
    (F : Cfg (Lk3 L m) → ℝ) (hF : Measurable F) (CF : ℝ) (hFC : ∀ V, |F V| ≤ CF)
    (hFdep : ∀ V V' : Cfg (Lk3 L m), (∀ b, OpenPos L m Mc b → V b = V' b) → F V = F V') :
    0 ≤ ∫ V, F (reflCfg3 L m V) * F V
      ∂((TorusRP.wilsonMeasure (3 ^ n * L) β).map (down r₀ hr (paths L) (wts L) n m)) := by
  rw [push_refl_integral L hr hmn _ F hF]
  simp only [reflCfg3_eq]
  exact TorusRP.wilson_rp (3 ^ n * L) (3 ^ (n - m) * Mc) hN β
    (fun ω => F (down r₀ hr (paths L) (wts L) n m ω))
    (hF.comp (continuous_down r₀ hr (paths L) (wts L) n m).measurable) CF (fun ω => hFC _)
    (fun ω ω' h => hFdep _ _ (fun b hb =>
      down_dep_posP L hr hmn hMc ω ω' (fun ℓ hℓ => h ℓ (Or.inr hℓ)) b hb))

/-- The hypotheses can be met: `L = 2`, `Mc = 3^m` (so `3^m · 2 = 2 Mc`), every `m ≤ n`. -/
example (n m : ℕ) (hmn : m ≤ n) : 3 ^ n * 2 = 2 * (3 ^ (n - m) * 3 ^ m) ∧ 3 ^ m ≤ 3 ^ m * 2 := by
  refine ⟨?_, by omega⟩
  rw [← pow_add, Nat.sub_add_cancel hmn]; ring

/-- `OpenPos` is not empty when `Mc ≥ 3`: the spatial link at coarse time `1`. -/
example (m : ℕ) : OpenPos 2 m 3 (fun i => if i = 0 then 1 else 0, 1) := by
  have h1 : 1 ≤ 3 ^ m := Nat.one_le_pow _ _ (by norm_num)
  have hne : (3 ^ m * 2 : ℕ) ≠ 1 := by omega
  refine ⟨?_, ?_⟩
  · simp only [if_true]
    rw [ZMod.val_one'' hne]
  · simp only [if_true, show ¬ (1 : Fin 4) = 0 from by decide, if_false]
    rw [ZMod.val_one'' hne]
    norm_num

end Block3

#print axioms Block3.rp_push
