import Block3.DownReflV1
/-!
# Centred blocks of side 3: flipping the sign of the links crossing one face

Paper: (Haar push-forward: the coarse plaquette expectation vanishes).
`Cross L m b`: the fine links crossing the face between the block of `y` and the block of
`y + e_μ` (`b = (y, μ)`): direction `μ`, base `3y + z` with `z_μ = 1`, `z_i ∈ [-1,1]` (`i ≠ μ`).
`flipCfg` multiplies these links by `-1`.
* `pathProd_flip`: flipping the links of a set multiplies the product along a path by
  `(-1)^(number of steps on the set)`.
* `cross_iff`: a step of a path of the coarse link `b'` lies on `Cross L m b` iff `b' = b` and it
  is the crossing step of the straight line (base coordinate `μ` equal to `1`); the proof reads
  the coordinates modulo `3` (the coarse sites sit on `3ℤ`).
* **`blockMap_flip`**: after the flip, the block map changes the sign of the value on `b` and
  leaves every other coarse link unchanged (every level `m`, every side `L`, every `r₀ > 0`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

/-- Flipping the links of a set: the product along a path gets `(-1)^(count)`. -/
theorem pathProd_flip {Λ : Type*} (P : Λ → Prop) [DecidablePred P] (U : Λ → ℍr)
    (γ : List (Λ × Bool)) :
    pathProd (fun ℓ => if P ℓ then -U ℓ else U ℓ) γ =
      ((-1 : ℝ) ^ (γ.countP (fun s => decide (P s.1)))) • pathProd U γ := by
  induction γ with
  | nil => simp [pathProd]
  | cons s r ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih, List.countP_cons]
    by_cases h : P s.1
    · have hs : stepVal (fun ℓ => if P ℓ then -U ℓ else U ℓ) s = -stepVal U s := by
        unfold stepVal
        simp only [h, if_true]
        split_ifs <;> simp [star_neg]
      rw [hs, if_pos (decide_eq_true h), pow_succ, mul_neg_one, neg_smul, neg_mul, mul_smul_comm]
    · have hs : stepVal (fun ℓ => if P ℓ then -U ℓ else U ℓ) s = stepVal U s := by
        unfold stepVal
        simp only [h, if_false]
      rw [hs, if_neg (by simpa using h), add_zero, mul_smul_comm]

theorem retract_neg (r₀ : ℝ) (q : ℍr) : retract r₀ (-q) = -retract r₀ q := by
  simp only [retract, norm_neg, smul_neg]

theorem int_eq_of_mod3 {a c : ℤ} (h : (a : ZMod 3) = (c : ZMod 3)) (h1 : -1 ≤ a) (h2 : a ≤ 3)
    (h3 : -1 ≤ c) (h4 : c ≤ 1) (h5 : c = 1 ∨ a ≤ 1) : a = c := by
  have := (ZMod.intCast_eq_intCast_iff_dvd_sub a c 3).1 h
  push_cast at this
  omega

section Box

variable (L : ℕ) [NeZero L]

theorem three_dvd (m : ℕ) : 3 ∣ 3 ^ (m + 1) * L :=
  Dvd.dvd.mul_right (dvd_pow_self 3 (Nat.succ_ne_zero m)) L

/-- Residue modulo `3` on the fine box. -/
def r3 (m : ℕ) : ZMod (3 ^ (m + 1) * L) →+* ZMod 3 := ZMod.castHom (three_dvd L m) (ZMod 3)

theorem r3_triple (m : ℕ) (a : ZMod (3 ^ m * L)) : r3 L m (triple L m a) = 0 := by
  rw [← ZMod.intCast_zmod_cast a, triple_intCast, map_intCast]
  push_cast
  rw [show (3 : ZMod 3) = 0 by decide, zero_mul]

theorem r3_int (m : ℕ) (k : ℤ) : r3 L m (k : ZMod (3 ^ (m + 1) * L)) = (k : ZMod 3) :=
  map_intCast _ _

theorem triple_inj (m : ℕ) {a a' : ZMod (3 ^ m * L)} (h : triple L m a = triple L m a') : a = a' := by
  rw [← ZMod.intCast_zmod_cast a, ← ZMod.intCast_zmod_cast a', triple_intCast, triple_intCast] at h
  rw [← ZMod.intCast_zmod_cast a, ← ZMod.intCast_zmod_cast a']
  have h1 := (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).1 h
  apply (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).2
  have e : ((3 ^ (m + 1) * L : ℕ) : ℤ) = 3 * ((3 ^ m * L : ℕ) : ℤ) := by push_cast; ring
  rw [e, show 3 * (a'.cast : ℤ) - 3 * (a.cast : ℤ) = 3 * ((a'.cast : ℤ) - (a.cast : ℤ)) by ring] at h1
  exact (mul_dvd_mul_iff_left (by norm_num : (3 : ℤ) ≠ 0)).1 h1

/-- The fine links crossing the face between the block of `y` and the block of `y + e_μ`. -/
def Cross (m : ℕ) (b : Lk3 L m) (ℓ : Lk3 L (m + 1)) : Prop :=
  ℓ.2 = b.2 ∧ ∃ z : Fin 4 → ℤ, z b.2 = 1 ∧ (∀ i, i ≠ b.2 → -1 ≤ z i ∧ z i ≤ 1) ∧
    ℓ.1 = base3 L m b + red3 L m z

theorem coord_eq (m : ℕ) (b b' : Lk3 L m) (z z' : Fin 4 → ℤ)
    (h : base3 L m b' + red3 L m z' = base3 L m b + red3 L m z) (i : Fin 4) :
    triple L m (b'.1 i) + ((z' i : ℤ) : ZMod (3 ^ (m + 1) * L)) =
      triple L m (b.1 i) + ((z i : ℤ) : ZMod (3 ^ (m + 1) * L)) := by
  have := congrFun h i
  simpa [base3, red3] using this

theorem coord_mod3 (m : ℕ) (b b' : Lk3 L m) (z z' : Fin 4 → ℤ)
    (h : base3 L m b' + red3 L m z' = base3 L m b + red3 L m z) (i : Fin 4) :
    ((z' i : ℤ) : ZMod 3) = ((z i : ℤ) : ZMod 3) := by
  have := congrArg (r3 L m) (coord_eq L m b b' z z' h i)
  simpa [map_add, r3_triple, r3_int] using this

/-- The base of a step lies at one of its ends. -/
theorem base_inTwo {μ : Fin 4} {l : Link} (hs : l.1 = 1 ∨ l.1 = -1)
    (h : InTwo μ (src l) ∧ InTwo μ (tgt l)) : InTwo μ l.2.1 := by
  rcases hs with hs | hs
  · have := h.1; simpa [src, hs] using this
  · have := h.2; simp only [tgt, hs] at this; simpa using this

/-- **Which steps lie on the crossing set.** -/
theorem cross_iff (m : ℕ) (b b' : Lk3 L m) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4))
    (l : Link) (hl : l ∈ path b'.2 d o) :
    Cross L m b (linkCast (red3 L m) (base3 L m b') l).1 ↔
      (b' = b ∧ l.2.2 = b.2 ∧ l.2.1 b.2 = 1) := by
  have hsup := base_inTwo (path_sign _ _ _ l hl) (path_support _ _ _ l hl)
  constructor
  · rintro ⟨hdir, z, hz1, hzt, hzeq⟩
    have hdir' : l.2.2 = b.2 := hdir
    have hzeq' : base3 L m b' + red3 L m l.2.1 = base3 L m b + red3 L m z := hzeq
    have hm := coord_mod3 L m b b' z l.2.1 hzeq'
    by_cases hν : b'.2 = b.2
    · have hr := path_dir_range b'.2 d o l hl (by rw [hdir', hν])
      rw [hν] at hr
      have hμ : l.2.1 b.2 = 1 := by
        have := hm b.2
        rw [hz1] at this
        exact int_eq_of_mod3 (by simpa using this) hr.1 hr.2 (by norm_num) (by norm_num) (Or.inl rfl)
      have hall : l.2.1 = z := by
        funext i
        by_cases hi : i = b.2
        · subst hi; rw [hμ, hz1]
        · have h1 := hsup.1 i (by rw [hν]; exact hi)
          have h2 := hzt i hi
          exact int_eq_of_mod3 (hm i) h1.1 (by linarith [h1.2]) h2.1 h2.2 (Or.inr h1.2)
      refine ⟨?_, hdir', hμ⟩
      obtain ⟨y', ν'⟩ := b'
      obtain ⟨y, ν⟩ := b
      simp only at hν
      subst hν
      have hy : y' = y := by
        funext i
        have := coord_eq L m (y, ν') (y', ν') z l.2.1 hzeq' i
        rw [hall] at this
        exact triple_inj L m (add_right_cancel this)
      rw [hy]
    · exfalso
      have ho := path_cross_other hν d o l hl hdir'
      have := hm b.2
      rw [hz1] at this
      rcases ho with h | h <;> rw [h] at this <;> revert this <;> decide
  · rintro ⟨rfl, hdir, hμ⟩
    refine ⟨hdir, l.2.1, hμ, fun i hi => hsup.1 i hi, rfl⟩

open Classical in
/-- Flip the sign of the links crossing the face of `b`. -/
noncomputable def flipCfg (m : ℕ) (b : Lk3 L m) (U : Cfg (Lk3 L (m + 1))) : Cfg (Lk3 L (m + 1)) :=
  fun ℓ => if Cross L m b ℓ then
    ⟨-(U ℓ : ℍr), (mem_ball_iff _).2 (by rw [norm_neg]; exact (mem_ball_iff _).1 (U ℓ).2)⟩
  else U ℓ

open Classical in
theorem flipCfg_val (m : ℕ) (b : Lk3 L m) (U : Cfg (Lk3 L (m + 1))) :
    (fun ℓ => ((flipCfg L m b U ℓ : Ball) : ℍr)) =
      fun ℓ => if Cross L m b ℓ then -(U ℓ : ℍr) else (U ℓ : ℍr) := by
  funext ℓ
  unfold flipCfg
  split_ifs <;> rfl

open Classical in
theorem count_cross (m : ℕ) (b b' : Lk3 L m) (p : Idx) :
    (pathsIdx L m b' p).countP (fun s => decide (Cross L m b s.1)) =
      if b' = b then 1 else 0 := by
  obtain ⟨d, o⟩ := p
  rw [pathsIdx_eq, List.countP_map]
  by_cases hb : b' = b
  · rw [if_pos hb]
    refine (List.countP_congr fun l hl => ?_).trans (path_cross_count b'.2 d o)
    simp only [Function.comp_apply, decide_eq_true_eq]
    rw [cross_iff L m b b' d o l hl]
    subst hb
    simp
  · rw [if_neg hb]
    refine List.countP_eq_zero.2 fun l hl => ?_
    simp only [Function.comp_apply, decide_eq_true_eq]
    rw [cross_iff L m b b' d o l hl]
    exact fun h => hb h.1

/-- **The flip of the links crossing the face of `b` changes the sign of the coarse value on `b`
and leaves every other coarse link unchanged.** -/
theorem blockMap_flip {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (b : Lk3 L m) (U : Cfg (Lk3 L (m + 1)))
    (b' : Lk3 L m) :
    (blockMap r₀ hr (paths L) (wts L) m (flipCfg L m b U) b' : ℍr) =
      if b' = b then -(blockMap r₀ hr (paths L) (wts L) m U b' : ℍr)
      else (blockMap r₀ hr (paths L) (wts L) m U b' : ℍr) := by
  classical
  rw [blockMap_eq L hr, blockMap_eq L hr, flipCfg_val]
  have hterm : ∀ p : Idx, pathProd (fun ℓ => if Cross L m b ℓ then -(U ℓ : ℍr) else (U ℓ : ℍr))
      (pathsIdx L m b' p) =
        ((-1 : ℝ) ^ (if b' = b then 1 else 0)) • pathProd (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b' p) := by
    intro p
    rw [← count_cross L m b b' p]
    convert pathProd_flip (Cross L m b) (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b' p)
  simp only [hterm]
  by_cases hb : b' = b
  · simp only [hb, if_true, pow_one, neg_smul, one_smul, smul_neg, Finset.sum_neg_distrib,
      retract_neg]
  · simp only [hb, if_false, pow_zero, one_smul]

end Box

end Block3

#print axioms Block3.cross_iff
#print axioms Block3.blockMap_flip
