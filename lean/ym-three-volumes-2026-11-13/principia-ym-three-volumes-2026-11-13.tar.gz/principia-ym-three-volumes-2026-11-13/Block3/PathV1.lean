import UVChain.BoxChainV1
/-!
# Centred blocks of side 3 with uniform weights: the paths on `ℤ⁴`

Paper: (the centred block map of side 3, written as a family of paths).
The coarse site `y` sits at the fine site `3y` (the centre of the block `3y + {-1,0,1}⁴`).
For a coarse link of direction `μ`, a displacement `d ∈ {-1,0,1}⁴` (indices `Fin 3`, values `dv`)
and an order `o` of the four axes, the path (started at the origin) is

  `contour o d` (from `0` to `d`, one axis at a time in the order `o`)
  `++ line μ d` (three steps in direction `μ`, from `d` to `d + 3 e_μ`)
  `++ revL (shifted contour)` (back from `d + 3 e_μ` to `3 e_μ` along the same order `o`).

Lean:
* `Walks x γ y`: `γ` is a chain of oriented unit steps from `x` to `y`.
* **`path_walks`**: every path runs from `0` to `3 e_μ` (the fine images of the two ends of the
  coarse link); **`path_sign`**: every step has sign `±1`.
* **`path_support`** (support): every point visited by a path lies in the union of the two
  blocks `{-1,0,1}⁴` and `3 e_μ + {-1,0,1}⁴` (transverse coordinates in `[-1,1]`, the coordinate
  `μ` in `[-1,4]`).
-/

namespace Block3

open WalkCast BoxWalk

/-! ## 1. Chains of oriented unit steps -/

/-- Start of an oriented step `(s, z, n)`: `z` if `s = 1`, else `z + e_n`. -/
def src (l : Link) : Fin 4 → ℤ := if l.1 = 1 then l.2.1 else l.2.1 + ev l.2.2

/-- End of an oriented step. -/
def tgt (l : Link) : Fin 4 → ℤ := if l.1 = 1 then l.2.1 + ev l.2.2 else l.2.1

/-- `Walks x γ y`: the steps of `γ` follow each other from `x` to `y`. -/
inductive Walks : (Fin 4 → ℤ) → List Link → (Fin 4 → ℤ) → Prop
  | nil (x : Fin 4 → ℤ) : Walks x [] x
  | cons {l : Link} {r : List Link} {y : Fin 4 → ℤ} : Walks (tgt l) r y → Walks (src l) (l :: r) y

theorem Walks.append {x y z : Fin 4 → ℤ} {a b : List Link} (h1 : Walks x a y) (h2 : Walks y b z) :
    Walks x (a ++ b) z := by
  revert h2
  induction h1 with
  | nil x => exact id
  | cons _ ih => exact fun h2 => Walks.cons (ih h2)

theorem walks_pos {x y : Fin 4 → ℤ} {n : Fin 4} {r : List Link} (h : Walks (x + ev n) r y) :
    Walks x ((1, x, n) :: r) y := by
  have hs : src (1, x, n) = x := by simp [src]
  have ht : tgt (1, x, n) = x + ev n := by simp [tgt]
  rw [← ht] at h
  have := Walks.cons h
  rwa [hs] at this

theorem walks_neg {x y : Fin 4 → ℤ} {n : Fin 4} {r : List Link} (h : Walks (x - ev n) r y) :
    Walks x ((-1, x - ev n, n) :: r) y := by
  have hs : src (-1, x - ev n, n) = x := by simp [src]
  have ht : tgt (-1, x - ev n, n) = x - ev n := by simp [tgt]
  rw [← ht] at h
  have := Walks.cons h
  rwa [hs] at this

theorem dv_cases (j : Fin 3) : dv j = 1 ∨ dv j = 0 ∨ dv j = -1 := by
  revert j; decide

theorem dv_abs (j : Fin 3) : -1 ≤ dv j ∧ dv j ≤ 1 := by
  rcases dv_cases j with h | h | h <;> rw [h] <;> norm_num

theorem fwd_walks (a : ℤ) (ha : a = 1 ∨ a = 0 ∨ a = -1) (z : Fin 4 → ℤ) (n : Fin 4) :
    Walks z (fwd a z n) (z + a • ev n) := by
  rcases ha with rfl | rfl | rfl
  · simp only [fwd, if_pos rfl]
    rw [one_smul]
    exact walks_pos (Walks.nil _)
  · simp only [fwd, if_neg (by decide : (0 : ℤ) ≠ 1), if_neg (by decide : (0 : ℤ) ≠ -1)]
    rw [zero_smul, add_zero]
    exact Walks.nil _
  · simp only [fwd, if_neg (by decide : (-1 : ℤ) ≠ 1), if_pos rfl]
    rw [neg_one_smul, ← sub_eq_add_neg]
    exact walks_neg (Walks.nil _)

/-- Translation of a chain. -/
theorem src_shift (v : Fin 4 → ℤ) (l : Link) : src (shiftL v l) = src l + v := by
  unfold src shiftL; dsimp only; split_ifs <;> abel

theorem tgt_shift (v : Fin 4 → ℤ) (l : Link) : tgt (shiftL v l) = tgt l + v := by
  unfold tgt shiftL; dsimp only; split_ifs <;> abel

theorem Walks.shift {x y : Fin 4 → ℤ} {γ : List Link} (h : Walks x γ y) (v : Fin 4 → ℤ) :
    Walks (x + v) (γ.map (shiftL v)) (y + v) := by
  induction h with
  | nil x => exact Walks.nil _
  | @cons l r y _ ih =>
    rw [← src_shift]
    rw [← tgt_shift] at ih
    exact Walks.cons ih

/-- Walk a chain backwards: reverse the order and flip each orientation. -/
def revL (γ : List Link) : List Link := (γ.map flipL).reverse

theorem src_flip {l : Link} (h : l.1 = 1 ∨ l.1 = -1) : src (flipL l) = tgt l := by
  rcases h with h | h <;> simp [src, tgt, flipL, h]

theorem tgt_flip {l : Link} (h : l.1 = 1 ∨ l.1 = -1) : tgt (flipL l) = src l := by
  rcases h with h | h <;> simp [src, tgt, flipL, h]

theorem Walks.rev {x y : Fin 4 → ℤ} {γ : List Link} (h : Walks x γ y)
    (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) : Walks y (revL γ) x := by
  induction h with
  | nil x => exact Walks.nil _
  | @cons l r y _ ih =>
    have hl := hs l List.mem_cons_self
    have h1 := ih fun l' hl' => hs l' (List.mem_cons_of_mem _ hl')
    have h2 : Walks (tgt l) [flipL l] (src l) := by
      have := Walks.cons (l := flipL l) (Walks.nil (tgt (flipL l)))
      rwa [src_flip hl, tgt_flip hl] at this
    have e : revL (l :: r) = revL r ++ [flipL l] := by simp [revL]
    rw [e]
    exact h1.append h2

/-! ## 2. The paths of the centred block of side 3 -/

/-- Displacement vector of the index `d`. -/
def dvec (d : Fin 4 → Fin 3) : Fin 4 → ℤ := fun i => dv (d i)

/-- Point of the contour after `k` steps in the order `o` (axes `o 0, …, o (k-1)` displaced). -/
def cpt (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : ℕ) : Fin 4 → ℤ :=
  fun i => if ((o.symm i : Fin 4) : ℕ) < k then dv (d i) else 0

/-- The `k`-th step of the contour: axis `o k`, displacement `dv (d (o k))`. -/
def cstep (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : Fin 4) : List Link :=
  fwd (dv (d (o k))) (cpt o d k) (o k)

/-- The contour from the centre `0` to `dvec d`, one axis at a time in the order `o`. -/
def contour (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) : List Link :=
  cstep o d 0 ++ cstep o d 1 ++ cstep o d 2 ++ cstep o d 3

/-- Three steps in direction `μ` from `x`. -/
def line (μ : Fin 4) (x : Fin 4 → ℤ) : List Link :=
  [(1, x, μ), (1, x + ev μ, μ), (1, x + ev μ + ev μ, μ)]

/-- **The path of the coarse link of direction `μ`** for the displacement index `d` and the
order `o` (started at the fine image `0` of the coarse site). -/
def path (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) : List Link :=
  contour o d ++ line μ (dvec d) ++ revL ((contour o d).map (shiftL (3 • ev μ)))

theorem cpt_zero (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) : cpt o d 0 = 0 := by
  funext i; simp [cpt]

theorem cpt_four (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) : cpt o d 4 = dvec d := by
  funext i; simp [cpt, dvec, Fin.is_lt]

theorem cpt_succ (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : Fin 4) :
    cpt o d ((k : ℕ) + 1) = cpt o d k + dv (d (o k)) • ev (o k) := by
  funext i
  simp only [cpt, Pi.add_apply, Pi.smul_apply, ev, smul_eq_mul]
  by_cases h : i = o k
  · subst h
    simp
  · have hk : ((o.symm i : Fin 4) : ℕ) ≠ k := by
      intro hh
      exact h ((Equiv.symm_apply_eq o).1 (Fin.ext hh))
    have e : (((o.symm i : Fin 4) : ℕ) < k + 1) ↔ (((o.symm i : Fin 4) : ℕ) < k) := by omega
    simp only [e, Pi.single_apply, h, if_false, mul_zero, add_zero]

theorem cstep_walks (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : Fin 4) (a b : ℕ)
    (ha : (k : ℕ) = a) (hb : a + 1 = b) : Walks (cpt o d a) (cstep o d k) (cpt o d b) := by
  have := fwd_walks (dv (d (o k))) (dv_cases _) (cpt o d k) (o k)
  rw [← cpt_succ] at this
  subst ha hb
  exact this

theorem contour_walks (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) :
    Walks 0 (contour o d) (dvec d) := by
  have h0 := cstep_walks o d 0 0 1 rfl rfl
  have h1 := cstep_walks o d 1 1 2 rfl rfl
  have h2 := cstep_walks o d 2 2 3 rfl rfl
  have h3 := cstep_walks o d 3 3 4 rfl rfl
  rw [cpt_zero] at h0
  rw [cpt_four] at h3
  exact ((h0.append h1).append h2).append h3

theorem line_walks (μ : Fin 4) (x : Fin 4 → ℤ) : Walks x (line μ x) (x + 3 • ev μ) := by
  unfold line
  apply walks_pos; apply walks_pos; apply walks_pos
  rw [show x + 3 • ev μ = x + ev μ + ev μ + ev μ by abel]
  exact Walks.nil _

theorem fwd_sign' (a : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : ∀ l ∈ fwd a z n, l.1 = 1 ∨ l.1 = -1 :=
  fwd_sign a z n

theorem contour_sign (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) :
    ∀ l ∈ contour o d, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  simp only [contour, cstep, List.mem_append] at hl
  rcases hl with ((h | h) | h) | h <;> exact fwd_sign _ _ _ l h

/-- Every step of a path has sign `±1`. -/
theorem path_sign (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    ∀ l ∈ path μ d o, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  simp only [path, revL, line, List.mem_append, List.mem_reverse, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hl
  rcases hl with (h | h | h | h) | ⟨l', ⟨l'', h'', rfl⟩, rfl⟩
  · exact contour_sign o d l h
  · left; rw [h]
  · left; rw [h]
  · left; rw [h]
  · have := contour_sign o d l'' h''
    simp only [flipL, shiftL]
    rcases this with h | h <;> rw [h] <;> norm_num

/-- **End points**: every path runs from `0` to `3 e_μ`. -/
theorem path_walks (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    Walks 0 (path μ d o) (3 • ev μ) := by
  have hc := contour_walks o d
  have hl := line_walks μ (dvec d)
  have hs := hc.shift (3 • ev μ)
  have hr := hs.rev (by
    intro l hl
    simp only [List.mem_map] at hl
    obtain ⟨l', hl', rfl⟩ := hl
    exact contour_sign o d l' hl')
  rw [zero_add] at hr
  exact (hc.append hl).append hr

/-! ## 3. Support: the two blocks -/

/-- The block `{-1,0,1}⁴` of the coarse site `0`. -/
def InBlock (x : Fin 4 → ℤ) : Prop := ∀ i, -1 ≤ x i ∧ x i ≤ 1

/-- The union of the block of `0` and the block of `3 e_μ`, `{-1,0,1}⁴ ∪ (3 e_μ + {-1,0,1}⁴)`
together with the points between them: transverse coordinates in `[-1,1]`, coordinate `μ` in
`[-1,4]` (these two descriptions agree: `[-1,1] ∪ [2,4] = [-1,4]` on `ℤ`). -/
def InTwo (μ : Fin 4) (x : Fin 4 → ℤ) : Prop :=
  (∀ i, i ≠ μ → -1 ≤ x i ∧ x i ≤ 1) ∧ -1 ≤ x μ ∧ x μ ≤ 4

theorem inTwo_iff (μ : Fin 4) (x : Fin 4 → ℤ) :
    InTwo μ x ↔ InBlock x ∨ InBlock (x - 3 • ev μ) := by
  constructor
  · rintro ⟨ht, h1, h2⟩
    by_cases hx : x μ ≤ 1
    · left; intro i
      by_cases hi : i = μ
      · subst hi; exact ⟨h1, hx⟩
      · exact ht i hi
    · right; intro i
      by_cases hi : i = μ
      · subst hi
        have e : (x - 3 • ev i) i = x i - 3 := by simp [ev]
        rw [e]
        constructor <;> omega
      · simp only [Pi.sub_apply, Pi.smul_apply, ev, Pi.single_apply, hi, if_false, smul_zero,
          sub_zero]
        exact ht i hi
  · rintro (h | h)
    · refine ⟨fun i _ => h i, (h μ).1, by linarith [(h μ).2]⟩
    · refine ⟨fun i hi => ?_, ?_, ?_⟩
      · have := h i
        simpa [ev, Pi.single_apply, hi] using this
      · have := (h μ).1; simp [ev] at this; linarith
      · have := (h μ).2; simp [ev] at this; linarith

theorem cpt_inBlock (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : ℕ) : InBlock (cpt o d k) := by
  intro i
  simp only [cpt]
  split_ifs
  · exact dv_abs _
  · norm_num

theorem fwd_ends (a : ℤ) (ha : a = 1 ∨ a = 0 ∨ a = -1) (z : Fin 4 → ℤ) (n : Fin 4) :
    ∀ l ∈ fwd a z n, (src l = z ∧ tgt l = z + a • ev n) := by
  intro l hl
  rcases ha with rfl | rfl | rfl
  · simp [fwd] at hl
    subst hl; simp [src, tgt]
  · simp [fwd] at hl
  · simp [fwd] at hl
    subst hl; simp [src, tgt, sub_eq_add_neg]

theorem contour_points (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) :
    ∀ l ∈ contour o d, InBlock (src l) ∧ InBlock (tgt l) := by
  have key : ∀ k : Fin 4, ∀ l ∈ cstep o d k, InBlock (src l) ∧ InBlock (tgt l) := by
    intro k l hl
    obtain ⟨hs, ht⟩ := fwd_ends _ (dv_cases _) _ _ l hl
    rw [← cpt_succ] at ht
    rw [hs, ht]
    exact ⟨cpt_inBlock _ _ _, cpt_inBlock _ _ _⟩
  intro l hl
  simp only [contour, List.mem_append] at hl
  rcases hl with ((h | h) | h) | h
  · exact key 0 l h
  · exact key 1 l h
  · exact key 2 l h
  · exact key 3 l h

theorem inTwo_of_inBlock (μ : Fin 4) {x : Fin 4 → ℤ} (h : InBlock x) : InTwo μ x :=
  (inTwo_iff μ x).2 (Or.inl h)

theorem inTwo_of_inBlock_shift (μ : Fin 4) {x : Fin 4 → ℤ} (h : InBlock x) :
    InTwo μ (x + 3 • ev μ) :=
  (inTwo_iff μ _).2 (Or.inr (by simpa using h))

theorem inTwo_line (μ : Fin 4) (d : Fin 4 → Fin 3) (t : ℤ) (h0 : 0 ≤ t) (h3 : t ≤ 3) :
    InTwo μ (dvec d + t • ev μ) := by
  refine ⟨fun i hi => ?_, ?_, ?_⟩
  · simp only [Pi.add_apply, Pi.smul_apply, ev, Pi.single_apply, hi, if_false, smul_zero,
      add_zero, dvec]
    exact dv_abs _
  · simp only [Pi.add_apply, Pi.smul_apply, ev, Pi.single_eq_same, smul_eq_mul, mul_one, dvec]
    linarith [(dv_abs (d μ)).1]
  · simp only [Pi.add_apply, Pi.smul_apply, ev, Pi.single_eq_same, smul_eq_mul, mul_one, dvec]
    linarith [(dv_abs (d μ)).2]

/-- **Support**: every step of a path starts and ends in the union of the block of the coarse
site (`{-1,0,1}⁴`) and the block of its neighbour in direction `μ` (`3 e_μ + {-1,0,1}⁴`). -/
theorem path_support (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    ∀ l ∈ path μ d o, InTwo μ (src l) ∧ InTwo μ (tgt l) := by
  intro l hl
  simp only [path, revL, line, List.mem_append, List.mem_reverse, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hl
  rcases hl with (h | h | h | h) | ⟨l', ⟨l'', h'', rfl⟩, rfl⟩
  · obtain ⟨a, b⟩ := contour_points o d l h
    exact ⟨inTwo_of_inBlock μ a, inTwo_of_inBlock μ b⟩
  · subst h
    have e0 := inTwo_line μ d 0 le_rfl (by norm_num)
    have e1 := inTwo_line μ d 1 (by norm_num) (by norm_num)
    simp only [zero_smul, add_zero, one_smul] at e0 e1
    simpa [src, tgt] using And.intro e0 e1
  · subst h
    have e1 := inTwo_line μ d 1 (by norm_num) (by norm_num)
    have e2 := inTwo_line μ d 2 (by norm_num) (by norm_num)
    simp only [one_smul] at e1
    rw [show dvec d + (2 : ℤ) • ev μ = dvec d + ev μ + ev μ by abel] at e2
    simpa [src, tgt] using And.intro e1 e2
  · subst h
    have e2 := inTwo_line μ d 2 (by norm_num) (by norm_num)
    have e3 := inTwo_line μ d 3 (by norm_num) (by norm_num)
    rw [show dvec d + (2 : ℤ) • ev μ = dvec d + ev μ + ev μ by abel] at e2
    rw [show dvec d + (3 : ℤ) • ev μ = dvec d + ev μ + ev μ + ev μ by abel] at e3
    simpa [src, tgt] using And.intro e2 e3
  · have hsg := contour_sign o d l'' h''
    have hsg' : (shiftL (3 • ev μ) l'').1 = 1 ∨ (shiftL (3 • ev μ) l'').1 = -1 := by
      simpa [shiftL] using hsg
    obtain ⟨a, b⟩ := contour_points o d l'' h''
    rw [src_flip hsg', tgt_flip hsg', src_shift, tgt_shift]
    exact ⟨inTwo_of_inBlock_shift μ b, inTwo_of_inBlock_shift μ a⟩

end Block3

#print axioms Block3.path_walks
#print axioms Block3.path_support
