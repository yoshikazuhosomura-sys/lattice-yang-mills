import Block3.RPProbV1
import Tuned.TunedMaxV1
/-!
# Centred blocks of side 3: sign flips at every level and the Haar mean of the coarse plaquette

Paper: (lemma C at every level; β = 0).
* `flipSet S`: multiply the links of the set `S` by `-1` (`negB` on each link of `S`).
* `blockMap_flipSet`: flipping the union of the crossing sets of the coarse links of `B` flips
  exactly the coarse links of `B` (one level, every set `B`).
* **`down_flipSet`**: for every `m ≤ n` and every set `B` of coarse links at level `m` there is a set
  `S` of fine links at level `n` whose flip flips exactly `B` after `down n m` (induction on the
  number of levels; `S` is the iterated union of crossing sets).
* `flipSet_preserving`: the flip preserves the product Haar measure.
* **`integral_re_hol_down_haar`**: for `1 < 3^m L`, every unoriented coarse plaquette `p` and
  every `m ≤ n`, `∫ Re U_p(down n m ω) d(∏ Haar) = 0`.
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset MeasureTheory TorusRP

local notation "ℍr" => Quaternion ℝ

section Flip

variable {Λ : Type*}

open Classical in
/-- Flip the sign of the links of the set `S`. -/
noncomputable def flipSet (S : Set Λ) (U : Cfg Λ) : Cfg Λ :=
  fun ℓ => (if ℓ ∈ S then TunedCoupling.negB else id) (U ℓ)

open Classical in
theorem flipSet_val (S : Set Λ) (U : Cfg Λ) :
    (fun ℓ => ((flipSet S U ℓ : Ball) : ℍr)) = fun ℓ => if ℓ ∈ S then -(U ℓ : ℍr) else (U ℓ : ℍr) := by
  funext ℓ
  unfold flipSet
  split_ifs <;> rfl

theorem flipSet_apply_val (S : Set Λ) (U : Cfg Λ) (ℓ : Λ) [Decidable (ℓ ∈ S)] :
    ((flipSet S U ℓ : Ball) : ℍr) = if ℓ ∈ S then -(U ℓ : ℍr) else (U ℓ : ℍr) := by
  unfold flipSet
  by_cases h : ℓ ∈ S
  · rw [if_pos h, if_pos h]; rfl
  · rw [if_neg h, if_neg h]; rfl

end Flip

section Box

variable (L : ℕ) [NeZero L]

/-- The union of the crossing sets of the coarse links of `B`. -/
def CrossU (m : ℕ) (B : Set (Lk3 L m)) : Set (Lk3 L (m + 1)) := {ℓ | ∃ b ∈ B, Cross L m b ℓ}

open Classical in
theorem count_crossU (m : ℕ) (B : Set (Lk3 L m)) (b' : Lk3 L m) (p : Idx) :
    (pathsIdx L m b' p).countP (fun s => decide (s.1 ∈ CrossU L m B)) =
      if b' ∈ B then 1 else 0 := by
  obtain ⟨d, o⟩ := p
  rw [pathsIdx_eq, List.countP_map]
  have key : ∀ l ∈ path b'.2 d o, ((linkCast (red3 L m) (base3 L m b') l).1 ∈ CrossU L m B ↔
      (b' ∈ B ∧ l.2.2 = b'.2 ∧ l.2.1 b'.2 = 1)) := by
    intro l hl
    constructor
    · rintro ⟨b, hb, hc⟩
      obtain ⟨rfl, h2, h3⟩ := (cross_iff L m b b' d o l hl).1 hc
      exact ⟨hb, h2, h3⟩
    · rintro ⟨hb, h2, h3⟩
      exact ⟨b', hb, (cross_iff L m b' b' d o l hl).2 ⟨rfl, h2, h3⟩⟩
  by_cases hb : b' ∈ B
  · rw [if_pos hb]
    refine (List.countP_congr fun l hl => ?_).trans (path_cross_count b'.2 d o)
    simp only [Function.comp_apply, decide_eq_true_eq]
    rw [key l hl]
    simp [hb]
  · rw [if_neg hb]
    refine List.countP_eq_zero.2 fun l hl => ?_
    simp only [Function.comp_apply, decide_eq_true_eq]
    rw [key l hl]
    exact fun h => hb h.1

/-- **One level**: flipping the union of the crossing sets of `B` flips exactly `B`. -/
theorem blockMap_flipSet {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (B : Set (Lk3 L m))
    (U : Cfg (Lk3 L (m + 1))) :
    blockMap r₀ hr (paths L) (wts L) m (flipSet (CrossU L m B) U) =
      flipSet B (blockMap r₀ hr (paths L) (wts L) m U) := by
  classical
  funext b'
  apply Subtype.ext
  rw [flipSet_apply_val, blockMap_eq L hr, blockMap_eq L hr, flipSet_val]
  have hterm : ∀ p : Idx, pathProd (fun ℓ => if ℓ ∈ CrossU L m B then -(U ℓ : ℍr) else (U ℓ : ℍr))
      (pathsIdx L m b' p) =
        ((-1 : ℝ) ^ (if b' ∈ B then 1 else 0)) • pathProd (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b' p) := by
    intro p
    rw [← count_crossU L m B b' p]
    convert pathProd_flip (fun ℓ => ℓ ∈ CrossU L m B) (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b' p)
  simp only [hterm]
  by_cases hb : b' ∈ B
  · simp only [hb, if_true, pow_one, neg_smul, one_smul, smul_neg, Finset.sum_neg_distrib,
      retract_neg]
  · simp only [hb, if_false, pow_zero, one_smul]

/-- **Lemma C at every level**: for `n = m + k` and every set `B` of coarse links at level `m`, some
set `S` of fine links at level `n` is such that `down n m (flip_S U) = flip_B (down n m U)`. -/
theorem down_flipSet {r₀ : ℝ} (hr : 0 < r₀) (n : ℕ) : ∀ (k m : ℕ), n = m + k →
    ∀ B : Set (Lk3 L m), ∃ S : Set (Lk3 L n), ∀ U : Cfg (Lk3 L n),
      down r₀ hr (paths L) (wts L) n m (flipSet S U) =
        flipSet B (down r₀ hr (paths L) (wts L) n m U) := by
  intro k
  induction k with
  | zero =>
    intro m h B
    obtain rfl : n = m := by omega
    exact ⟨B, fun U => by rw [down_self, down_self]⟩
  | succ k ih =>
    intro m h B
    obtain ⟨S, hS⟩ := ih (m + 1) (by omega) (CrossU L m B)
    have hmn : m < n := by omega
    refine ⟨S, fun U => ?_⟩
    rw [down_succ r₀ hr (paths L) (wts L) hmn, down_succ r₀ hr (paths L) (wts L) hmn, hS,
      blockMap_flipSet L hr]

open Classical in
/-- The flip preserves the product Haar measure. -/
theorem flipSet_preserving (N : ℕ) [NeZero N] (S : Set (TorusRP.Lk N)) :
    MeasurePreserving (flipSet S) (Measure.pi fun _ : TorusRP.Lk N => haarBall)
      (Measure.pi fun _ : TorusRP.Lk N => haarBall) :=
  measurePreserving_pi _ _ (fun ℓ => by
    by_cases h : ℓ ∈ S
    · simp only [h, if_true]; exact TunedCoupling.negB_preserving
    · simp only [h, if_false]; exact MeasurePreserving.id _)

theorem flipSet_singleton (N : ℕ) [NeZero N] (ℓ₀ : TorusRP.Lk N) (ω : TorusRP.Lk N → QBall) :
    flipSet ({ℓ₀} : Set (TorusRP.Lk N)) ω = TunedCoupling.flipAt N ℓ₀ ω := by
  classical
  funext ℓ
  unfold flipSet TunedCoupling.flipAt
  simp only [Set.mem_singleton_iff]

/-- **β = 0: the Haar mean of every coarse plaquette vanishes** (every `m ≤ n`, `1 < 3^m L`). -/
theorem integral_re_hol_down_haar {r₀ : ℝ} (hr : 0 < r₀) {n m : ℕ} (hmn : m ≤ n)
    (hN : 1 < 3 ^ m * L) (p : TorusRP.Lk (3 ^ m * L) × Fin 4) (hp : p ∈ plaqs (3 ^ m * L)) :
    ∫ ω, (hol (3 ^ m * L) (down r₀ hr (paths L) (wts L) n m ω) p).re
      ∂(Measure.pi fun _ : TorusRP.Lk (3 ^ n * L) => haarBall) = 0 := by
  obtain ⟨S, hS⟩ := down_flipSet L hr n (n - m) m (by omega) {p.1}
  have hF := flipSet_preserving (3 ^ n * L) S
  have hm : Measurable (fun ω : TorusRP.Lk (3 ^ n * L) → QBall =>
      (hol (3 ^ m * L) (down r₀ hr (paths L) (wts L) n m ω) p).re) :=
    (Quaternion.continuous_re.comp ((continuous_hol (3 ^ m * L) p).comp
      (continuous_down r₀ hr (paths L) (wts L) n m))).measurable
  have h : ∫ ω, (hol (3 ^ m * L) (down r₀ hr (paths L) (wts L) n m ω) p).re
      ∂(Measure.pi fun _ : TorusRP.Lk (3 ^ n * L) => haarBall) =
      ∫ ω, (hol (3 ^ m * L) (down r₀ hr (paths L) (wts L) n m (flipSet S ω)) p).re
      ∂(Measure.pi fun _ : TorusRP.Lk (3 ^ n * L) => haarBall) := by
    conv_lhs => rw [← hF.map_eq]
    rw [integral_map hF.measurable.aemeasurable hm.aestronglyMeasurable]
  simp_rw [hS, flipSet_singleton, TunedCoupling.hol_flipAt (3 ^ m * L) hN p hp, Quaternion.re_neg,
    integral_neg] at h
  linarith

end Box

end Block3

#print axioms Block3.blockMap_flipSet
#print axioms Block3.down_flipSet
#print axioms Block3.integral_re_hol_down_haar
