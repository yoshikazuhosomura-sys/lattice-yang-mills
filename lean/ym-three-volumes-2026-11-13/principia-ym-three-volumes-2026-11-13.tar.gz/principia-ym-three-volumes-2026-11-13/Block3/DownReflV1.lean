import Block3.CrossV1
/-!
# Centred blocks of side 3: the composed block maps commute with the site reflection

Paper: (condition (b) at every level). `ChainBlockMap.down n m` is the
composition of the block maps from level `n` down to level `m`. Because the coarse site `y`
sits at the fine site `3y`, the site reflection `x₀ ↦ -x₀` of level `n` and that of level `m`
are the same plane, and
**`down_refl`**: `down n m ∘ Θ_n = Θ_m ∘ down n m` for every `m ≤ n`, every side `L`, every `r₀ > 0`.
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap

variable (L : ℕ) [NeZero L]

theorem down_refl_add {r₀ : ℝ} (hr : 0 < r₀) (k : ℕ) :
    ∀ (m : ℕ) (U : Cfg (Lk3 L (m + k))),
      down r₀ hr (paths L) (wts L) (m + k) m (reflCfg3 L (m + k) U) =
        reflCfg3 L m (down r₀ hr (paths L) (wts L) (m + k) m U) := by
  induction k with
  | zero =>
    intro m U
    show down r₀ hr (paths L) (wts L) m m (reflCfg3 L m U) =
      reflCfg3 L m (down r₀ hr (paths L) (wts L) m m U)
    rw [down_self, down_self]
  | succ k ih =>
    intro m U
    have hmn : m < m + (k + 1) := by omega
    have e : m + (k + 1) = (m + 1) + k := by omega
    rw [down_succ r₀ hr (paths L) (wts L) hmn, down_succ r₀ hr (paths L) (wts L) hmn]
    have key : ∀ (n : ℕ) (hn : n = (m + 1) + k) (V : Cfg (Lk3 L n)),
        down r₀ hr (paths L) (wts L) n (m + 1) (reflCfg3 L n V) =
          reflCfg3 L (m + 1) (down r₀ hr (paths L) (wts L) n (m + 1) V) := by
      intro n hn V
      subst hn
      exact ih (m + 1) V
    rw [key (m + (k + 1)) e U, blockMap_refl_cfg L hr]

/-- **The composed block maps commute with the site reflection, at every pair of levels.** -/
theorem down_refl {r₀ : ℝ} (hr : 0 < r₀) {n m : ℕ} (hmn : m ≤ n) (U : Cfg (Lk3 L n)) :
    down r₀ hr (paths L) (wts L) n m (reflCfg3 L n U) =
      reflCfg3 L m (down r₀ hr (paths L) (wts L) n m U) := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hmn
  exact down_refl_add L hr k m U

end Block3

#print axioms Block3.down_refl
