import Block3.Sanity15bV1
/-!
# Centred blocks of side 3: the reflection through a block boundary at every level

`down_reflB`: for every `m ≤ n` there is a fine translation `w` (the image `3^(n-m) e₀` of the coarse unit time
vector) with `down n m ∘ T_w ∘ Θ_n = T_{e₀} ∘ Θ_m ∘ down n m`; the coarse map `T_{e₀} ∘ Θ_m` is the reflection
`y₀ ↦ -1 - y₀` (the plane between the coarse times `-1` and `0`).
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem down_reflB {n m : ℕ} (hmn : m ≤ n) : ∃ w : Site3 L n, ∀ U : Cfg (Lk3 L n),
    down r₀ hr (paths L) (wts L) n m (transCfg L n w (reflCfg3 L n U)) =
      transCfg L m (Pi.single 0 1) (reflCfg3 L m (down r₀ hr (paths L) (wts L) n m U)) := by
  obtain ⟨w, hw⟩ := down_trans L hr n (n - m) m (by omega) (Pi.single 0 1)
  exact ⟨w, fun U => by rw [hw, down_refl L hr hmn]⟩

end Block3

#print axioms Block3.down_reflB
