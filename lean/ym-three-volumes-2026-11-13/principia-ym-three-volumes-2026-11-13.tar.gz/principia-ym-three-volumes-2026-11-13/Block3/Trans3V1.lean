import Block3.Tune3V1
/-!
# Centred blocks of side 3: translation invariance, Markov bounds and the limits of the tuned chain

Paper: §9 (consequences of the tuning).
* `down_trans`: for every coarse translation `v` at level `m` there is a fine translation `w` at level `n`
  (`w = 3^(n-m) v`) with `down n m ∘ T_w = T_v ∘ down n m` (every `m ≤ n`);
* `ν3 m k β`: the pushed-forward normalised Wilson measure; `ν3_shV_invariant` (coarse translations);
* `tuned3_markov_plaq6`: under the tuning equation, `ν(1 − Re U_p ≥ y) ≤ 6(1 − κ₀)/y` for one coarse plaquette;
* `attach_tuned3`: for the chain of the tuned family, along any common subsequence with limits `νl`, the limit at
  level `m₀` has coarse plaquette average `κ₀`, obeys the six-orientation Markov bound and the non-flatness bound;
* `zero3_limit_avg`: every level-`m₀` limit of the chain with `β ≡ 0` has coarse plaquette average `0`;
* **`tuned3_chain_limits`**: for `r₀ ≤ 1`, `1 < 3^m₀ L`, `0 < κ₀ < 1` (no other hypothesis): a tuned sequence
  `β ≥ 0` exists, a subsequence common to all levels has limits `νl m`, the limit at level `m₀` has coarse plaquette
  average `κ₀`, obeys the Markov and non-flatness bounds, and differs from every level-`m₀` limit of the `β ≡ 0`
  chain.
-/

set_option maxRecDepth 4000

namespace Block3

open MeasureTheory Filter Topology Set TorusRP ChainBlockMap TunedCoupling FoldAffine

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **Coarse translations at every level.** -/
theorem down_trans (n : ℕ) : ∀ (k m : ℕ), n = m + k → ∀ v : Site3 L m, ∃ w : Site3 L n,
    ∀ U : Cfg (Lk3 L n), down r₀ hr (paths L) (wts L) n m (transCfg L n w U) =
      transCfg L m v (down r₀ hr (paths L) (wts L) n m U) := by
  intro k
  induction k with
  | zero =>
    intro m h v
    obtain rfl : n = m := by omega
    exact ⟨v, fun U => by rw [down_self, down_self]⟩
  | succ k ih =>
    intro m h v
    obtain ⟨w, hw⟩ := ih (m + 1) (by omega) (tripleV L m v)
    have hmn : m < n := by omega
    exact ⟨w, fun U => by
      rw [down_succ r₀ hr (paths L) (wts L) hmn, down_succ r₀ hr (paths L) (wts L) hmn, hw,
        blockMap_trans L hr]⟩

/-- The pushed-forward normalised Wilson measure (`k` steps, coarse level `m`). -/
noncomputable def ν3 (m k : ℕ) (β : ℝ) : ProbabilityMeasure (Cfg (Lk3 L m)) :=
  (wilsonProb (3 ^ (m + k) * L) β).map
    (continuous_down r₀ hr (paths L) (wts L) (m + k) m).measurable.aemeasurable

theorem integral_ν3 (m k : ℕ) (β : ℝ) :
    ∫ V, plaqAvg (3 ^ m * L) V ∂(ν3 L hr m k β : Measure _) = Y3 L hr m k β := by
  unfold ν3 Y3
  rw [ProbabilityMeasure.toMeasure_map, integral_map
    (continuous_down r₀ hr (paths L) (wts L) (m + k) m).measurable.aemeasurable
    (continuous_plaqAvg _).aestronglyMeasurable]

theorem ν3_shV_invariant (m k : ℕ) (β : ℝ) (v : Site (3 ^ m * L))
    (f : (TorusRP.Lk (3 ^ m * L) → QBall) → ℝ) (hf : Continuous f) :
    ∫ V, f (shV _ v V) ∂(ν3 L hr m k β : Measure _) = ∫ V, f V ∂(ν3 L hr m k β : Measure _) := by
  have hD := continuous_down r₀ hr (paths L) (wts L) (m + k) m
  obtain ⟨w, hw⟩ := down_trans L hr (m + k) k m rfl v
  unfold ν3
  rw [ProbabilityMeasure.toMeasure_map]
  have hm1 : AEStronglyMeasurable (fun V : TorusRP.Lk (3 ^ m * L) → QBall => f (shV _ v V))
      ((wilsonProb (3 ^ (m + k) * L) β : Measure (TorusRP.Lk (3 ^ (m + k) * L) → QBall)).map
        (down r₀ hr (paths L) (wts L) (m + k) m)) :=
    (hf.comp (continuous_shV _ v)).aestronglyMeasurable
  have hm2 : AEStronglyMeasurable (fun V : TorusRP.Lk (3 ^ m * L) → QBall => f V)
      ((wilsonProb (3 ^ (m + k) * L) β : Measure (TorusRP.Lk (3 ^ (m + k) * L) → QBall)).map
        (down r₀ hr (paths L) (wts L) (m + k) m)) :=
    hf.aestronglyMeasurable
  rw [integral_map hD.measurable.aemeasurable hm1, integral_map hD.measurable.aemeasurable hm2]
  have e : ∀ ω : TorusRP.Lk (3 ^ (m + k) * L) → QBall,
      f (shV _ v (down r₀ hr (paths L) (wts L) (m + k) m ω)) =
        f (down r₀ hr (paths L) (wts L) (m + k) m (shV _ w ω)) := by
    intro ω
    congr 1
    exact (hw ω).symm
  simp_rw [e]
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_shV_invariant _ w β (fun ω => f (down r₀ hr (paths L) (wts L) (m + k) m ω))
      (hf.comp hD).measurable]

/-- **Markov under the tuning equation** (one coarse plaquette, constant 6). -/
theorem tuned3_markov_plaq6 (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned3 L hr m₀ κ₀ β) (k : ℕ)
    (y : ℝ) (hy : 0 < y) (p : TorusRP.Lk (3 ^ m₀ * L) × Fin 4) (hp : p ∈ plaqs (3 ^ m₀ * L)) :
    (ν3 L hr m₀ k (β (m₀ + k)) : Measure _).real {V | y ≤ 1 - (hol (3 ^ m₀ * L) V p).re} ≤
      6 * (1 - κ₀) / y :=
  markov_plaq_six _ _ (fun v f hf => ν3_shV_invariant L hr m₀ k _ v f hf) κ₀
    ((integral_ν3 L hr m₀ k _).trans (ht k)) y hy p hp

/-- The chain's family of fine measures: the normalised Wilson measures with couplings `β n`. -/
noncomputable def wFam3 (β : ℕ → ℝ) : ∀ n, ProbabilityMeasure (Cfg (Lk3 L n)) :=
  fun n => wilsonProb (3 ^ n * L) (β n)

theorem νP_wFam3 (β : ℕ → ℝ) (m k : ℕ) :
    νP r₀ hr (paths L) (wts L) (wFam3 L β) (m + k) m = ν3 L hr m k (β (m + k)) := rfl

/-- The coarse plaquette average as a bounded continuous function on the configurations of level `m`. -/
noncomputable def avgBC3 (m : ℕ) : BoundedContinuousFunction (Cfg (Lk3 L m)) ℝ :=
  BoundedContinuousFunction.mkOfCompact ⟨plaqAvg (3 ^ m * L), continuous_plaqAvg _⟩

theorem limit3_avg (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (hY : ∀ k, Y3 L hr m₀ k (β (m₀ + k)) = κ₀)
    (φ : ℕ → ℕ) (hφ : StrictMono φ) (νl : ProbabilityMeasure (Cfg (Lk3 L m₀)))
    (hlim : Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m₀) atTop (𝓝 νl)) :
    ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(νl : Measure _) = κ₀ := by
  refine limit_integral_eq (avgBC3 L m₀)
    (fun n => νP r₀ hr (paths L) (wts L) (wFam3 L β) n m₀) κ₀ ?_ φ hφ νl hlim
  refine Filter.eventually_atTop.2 ⟨m₀, fun n hn => ?_⟩
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
  show ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(_ : Measure _) = κ₀
  rw [νP_wFam3 L hr β m₀ k, integral_ν3]
  exact hY k

/-- Every level-`m₀` limit of the chain with `β ≡ 0` has coarse plaquette average `0` (`1 < 3^m₀ L`). -/
theorem zero3_limit_avg (m₀ : ℕ) (hN : 1 < 3 ^ m₀ * L) (ψ : ℕ → ℕ) (hψ : StrictMono ψ)
    (νz : ProbabilityMeasure (Cfg (Lk3 L m₀)))
    (hlim : Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L (fun _ => 0)) (ψ k) m₀) atTop (𝓝 νz)) :
    ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(νz : Measure _) = 0 :=
  limit3_avg L hr m₀ 0 (fun _ => 0) (fun k => Y3_zero L hr m₀ k hN) ψ hψ νz hlim

theorem limit3_shV_invariant (m₀ : ℕ) (β : ℕ → ℝ) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (νl : ProbabilityMeasure (Cfg (Lk3 L m₀)))
    (hlim : Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m₀) atTop (𝓝 νl))
    (v : Site (3 ^ m₀ * L)) (f : (TorusRP.Lk (3 ^ m₀ * L) → QBall) → ℝ) (hf : Continuous f) :
    ∫ V, f (shV _ v V) ∂(νl : Measure (TorusRP.Lk (3 ^ m₀ * L) → QBall)) =
      ∫ V, f V ∂(νl : Measure (TorusRP.Lk (3 ^ m₀ * L) → QBall)) := by
  let F : BoundedContinuousFunction (Cfg (Lk3 L m₀)) ℝ := BoundedContinuousFunction.mkOfCompact ⟨f, hf⟩
  let G : BoundedContinuousFunction (Cfg (Lk3 L m₀)) ℝ :=
    BoundedContinuousFunction.mkOfCompact ⟨fun V => f (shV _ v V), hf.comp (continuous_shV _ v)⟩
  have h1 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) F
  have h2 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) G
  have hn : ∀ᶠ n in atTop,
      ∫ V, G V ∂(νP r₀ hr (paths L) (wts L) (wFam3 L β) n m₀ : Measure _) =
      ∫ V, F V ∂(νP r₀ hr (paths L) (wts L) (wFam3 L β) n m₀ : Measure _) := by
    refine Filter.eventually_atTop.2 ⟨m₀, fun n hn => ?_⟩
    obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
    show ∫ V, f (shV _ v V) ∂(_ : Measure _) = ∫ V, f V ∂(_ : Measure _)
    rw [νP_wFam3 L hr β m₀ k]
    exact ν3_shV_invariant L hr m₀ k _ v f hf
  have hev := hφ.tendsto_atTop.eventually hn
  exact tendsto_nhds_unique (h2.congr' hev) h1

/-- **The tuning attached to any conclusion about the common subsequence and the limits.** -/
theorem attach_tuned3 (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned3 L hr m₀ κ₀ β)
    (P : (ℕ → ℕ) → (∀ m, ProbabilityMeasure (Cfg (Lk3 L m))) → Prop)
    (h : ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk3 L m)),
      (∀ m, Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m) atTop (𝓝 (νl m))) ∧
        P φ νl) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk3 L m)),
      (∀ m, Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m) atTop (𝓝 (νl m))) ∧
      P φ νl ∧
      ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (3 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (3 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤
        (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (3 ^ m₀ * L) V}) := by
  obtain ⟨φ, hφ, νl, hlim, hP⟩ := h
  have hκ := limit3_avg L hr m₀ κ₀ β ht φ hφ (νl m₀) (hlim m₀)
  refine ⟨φ, hφ, νl, hlim, hP, hκ, fun y hy p hp => ?_, fun y hy => ?_⟩
  · exact markov_plaq_six (3 ^ m₀ * L) (νl m₀ : Measure (TorusRP.Lk (3 ^ m₀ * L) → QBall))
      (fun v f hf => limit3_shV_invariant L hr m₀ β φ hφ (νl m₀) (hlim m₀) v f hf) κ₀ hκ y hy p hp
  · exact nonflat_avg (3 ^ m₀ * L) (νl m₀ : Measure (TorusRP.Lk (3 ^ m₀ * L) → QBall)) κ₀ hκ y hy

/-- **The tuned chain of the centred block map of side 3, without hypotheses on the couplings**
(`r₀ ≤ 1`, `1 < 3^m₀ L`, `0 < κ₀ < 1`): a tuned sequence `β ≥ 0` (largest solution at each level) exists; a
subsequence common to all levels has limits `νl m`; the limit at level `m₀` has coarse plaquette average `κ₀`,
obeys the Markov bound `6(1 − κ₀)/y` for each coarse plaquette and the non-flatness bound, and differs from every
level-`m₀` limit of the chain with `β ≡ 0` (whose coarse plaquette average is `0`). -/
theorem tuned3_chain_limits (hr1 : r₀ ≤ 1) (m₀ : ℕ) (hN : 1 < 3 ^ m₀ * L) (κ₀ : ℝ) (h0 : 0 < κ₀)
    (hκ : κ₀ < 1) :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned3 L hr m₀ κ₀ β ∧
      (∀ k, ∀ β', β (m₀ + k) < β' → κ₀ < Y3 L hr m₀ k β') ∧
      ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk3 L m)),
        (∀ m, Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m) atTop (𝓝 (νl m))) ∧
        ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
        (∀ y, 0 < y → ∀ p ∈ plaqs (3 ^ m₀ * L),
          (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (3 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
        (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤
          (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (3 ^ m₀ * L) V}) ∧
        (∀ (ψ : ℕ → ℕ), StrictMono ψ → ∀ νz : ProbabilityMeasure (Cfg (Lk3 L m₀)),
          Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L (fun _ => 0)) (ψ k) m₀) atTop (𝓝 νz) →
          νl m₀ ≠ νz) := by
  obtain ⟨β, hβ, ht, hmax⟩ := tuned3_exists L hr hr1 m₀ hN κ₀ h0.le hκ
  obtain ⟨φ, hφ, νl, hlim⟩ := WeakUltravioletExistence.exists_common_subseq
    (fun n m => νP r₀ hr (paths L) (wts L) (wFam3 L β) n m)
  obtain ⟨φ', hφ', νl', hlim', -, hκ', hM, hF⟩ :=
    attach_tuned3 L hr m₀ κ₀ β ht (fun _ _ => True) ⟨φ, hφ, νl, hlim, trivial⟩
  refine ⟨β, hβ, ht, hmax, φ', hφ', νl', hlim', hκ', hM, hF, fun ψ hψ νz hz heq => ?_⟩
  have h1 := zero3_limit_avg L hr m₀ hN ψ hψ νz hz
  rw [← heq, hκ'] at h1
  exact h0.ne' h1

/-- **Example**: `L = 1`, `r₀ = 1`, `m₀ = 1`, `κ₀ = 1/2`. -/
theorem tuned3_chain_limits_example :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned3 1 (show (0 : ℝ) < 1 by norm_num) 1 (1 / 2) β ∧
      ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk3 1 m)),
        (∀ m, Tendsto (fun k => νP 1 (show (0 : ℝ) < 1 by norm_num) (paths 1) (wts 1)
          (wFam3 1 β) (φ k) m) atTop (𝓝 (νl m))) ∧
        ∫ V, plaqAvg (3 ^ 1 * 1) V ∂(νl 1 : Measure _) = 1 / 2 :=
  let ⟨β, hβ, ht, _, φ, hφ, νl, hlim, hκ, _⟩ :=
    tuned3_chain_limits 1 (show (0 : ℝ) < 1 by norm_num) le_rfl 1 (by norm_num) (1 / 2) (by norm_num)
      (by norm_num)
  ⟨β, hβ, ht, φ, hφ, νl, hlim, hκ⟩

end Block3

#print axioms Block3.down_trans
#print axioms Block3.tuned3_markov_plaq6
#print axioms Block3.attach_tuned3
#print axioms Block3.tuned3_chain_limits
#print axioms Block3.tuned3_chain_limits_example
