import Block3.PushV1
import Lattice.TorusDecV2
/-!
# Centred blocks of side 3: the fine reflection is the link reflection of the Wilson library

Paper: (Lean, the remaining step (i)). The configurations of the box of side
`3^n L` are the configurations of `TorusRP` with `N = 3^n L` (`Lk3 L n = TorusRP.Lk N`, the same
closed unit ball), and **`reflCfg3_eq`**: `reflCfg3 L n = linkRefl (thL N) (sig N)`, the
reflection appearing in `TorusRP.wilson_rp`. The coarse reflection of every level is the same map
for its own side (`reflCfg3_eq` at level `m`).
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

theorem reflCfg3_eq (n : ℕ) (U : Cfg (Lk3 L n)) :
    reflCfg3 L n U = LinkReflection.linkRefl (TorusRP.thL (3 ^ n * L)) (TorusRP.sig (3 ^ n * L)) U := by
  funext ℓ
  apply Subtype.ext
  obtain ⟨x, μ⟩ := ℓ
  by_cases h : μ = 0
  · subst h
    show reflV3 L n (fun ℓ' => (U ℓ' : ℍr)) (x, 0) =
      ((TorusRP.sig (3 ^ n * L) (x, 0) (U (TorusRP.thL (3 ^ n * L) (x, 0))) : TorusRP.QBall) : ℍr)
    rw [reflV3_zero]
    simp only [TorusRP.sig, TorusRP.thL, if_pos rfl, TorusRP.starB]
    rfl
  · show reflV3 L n (fun ℓ' => (U ℓ' : ℍr)) (x, μ) =
      ((TorusRP.sig (3 ^ n * L) (x, μ) (U (TorusRP.thL (3 ^ n * L) (x, μ))) : TorusRP.QBall) : ℍr)
    rw [reflV3_ne L n _ x h]
    simp only [TorusRP.sig, TorusRP.thL, h, if_false, id]
    rfl

end Block3

#print axioms Block3.reflCfg3_eq
