import Block3.BoxV1
/-!
# Centred blocks of side 3: the block map commutes with the site reflection `x₀ ↦ -x₀`

On the box, `thS3` negates the coordinate `0` of a site;
`reflV3` reflects a link field (a link in direction `ν ≠ 0` takes the value at the reflected
site, a link in direction `0` takes the conjugate of the value at `Θy - e₀`), as `reflV` of the
box library. The coarse site `y` sits at `3y`, so the coarse reflection `y₀ ↦ -y₀` and the fine
reflection `x₀ ↦ -x₀` are the same plane at every level.
* `pathProd_refl3`: the product of `reflV3 U` along a cast path is the product of `U` along the
  reflected path from the reflected base point.
* **`blockMap_refl`** (values) and **`blockMap_refl_cfg`**:
  `blockMap ∘ Θ_{m+1} = Θ_m ∘ blockMap` on ball-valued configurations, every level `m`, every
  side `L`, all coarse links (direction `ν ≠ 0` by `path_refl_ne` and the reindexing
  `d ↦ flipD d`; direction `0` by `path_refl_zero`, the reversal `pathProd_rev` and `retract_star`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

section ReflBox

variable (L : ℕ) [NeZero L]

/-- Reflection `Θ` of a site (negate the coordinate `0`). -/
def thS3 (m : ℕ) (y : Site3 L m) : Site3 L m := fun i => if i = 0 then -y i else y i

theorem thS3_add (m : ℕ) (x y : Site3 L m) : thS3 L m (x + y) = thS3 L m x + thS3 L m y := by
  funext i; simp only [thS3, Pi.add_apply]; split_ifs <;> abel

theorem red3_refl (m : ℕ) (z : Fin 4 → ℤ) : red3 L m (reflZ z) = thS3 L (m + 1) (red3 L m z) := by
  funext i
  simp only [red3, reflZ, thS3, AddMonoidHom.compLeft_apply, Function.comp_apply,
    Int.coe_castAddHom]
  split_ifs <;> simp

theorem red3_ev0 (m : ℕ) : red3 L m (ev 0) = Pi.single 0 1 := by
  funext i
  simp only [red3, ev, AddMonoidHom.compLeft_apply, Function.comp_apply, Int.coe_castAddHom]
  by_cases h : i = 0
  · subst h; simp
  · simp [h]

theorem base3_refl (m : ℕ) (y : Site3 L m) (ν : Fin 4) :
    base3 L m (thS3 L m y, ν) = thS3 L (m + 1) (base3 L m (y, ν)) := by
  funext i
  simp only [base3, thS3]
  split_ifs <;> simp [map_neg]

/-- The reflection of a link field. -/
noncomputable def reflV3 (m : ℕ) (U : Lk3 L m → ℍr) : Lk3 L m → ℍr := fun ℓ =>
  if ℓ.2 = 0 then star (U (thS3 L m ℓ.1 - Pi.single 0 1, 0)) else U (thS3 L m ℓ.1, ℓ.2)

theorem step_refl3 (m : ℕ) (U : Lk3 L (m + 1) → ℍr) (x : Site3 L (m + 1)) (l : Link)
    (hs : l.1 = 1 ∨ l.1 = -1) :
    stepVal (reflV3 L (m + 1) U) (linkCast (red3 L m) x l) =
      stepVal U (linkCast (red3 L m) (thS3 L (m + 1) x) (reflL l)) := by
  obtain ⟨s, z, ν⟩ := l
  have hpos : thS3 L (m + 1) (x + red3 L m z) = thS3 L (m + 1) x + red3 L m (reflZ z) := by
    rw [thS3_add, red3_refl]
  by_cases hν : ν = 0
  · subst hν
    have hpos0 : thS3 L (m + 1) (x + red3 L m z) - Pi.single 0 1 =
        thS3 L (m + 1) x + red3 L m (reflZ z - ev 0) := by
      rw [map_sub, red3_ev0, hpos]; abel
    rw [reflL_zero]
    simp only [linkCast, reflV3, stepVal, if_true]
    rw [hpos0]
    rcases hs with h | h <;> simp only at h <;> subst h <;> simp
  · rw [reflL_ne _ _ hν]
    simp only [linkCast, reflV3, stepVal, hν, if_false]
    simp [hpos]

theorem pathProd_refl3 (m : ℕ) (U : Lk3 L (m + 1) → ℍr) (x : Site3 L (m + 1)) (γ : List Link)
    (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) :
    pathProd (reflV3 L (m + 1) U) (γ.map (linkCast (red3 L m) x)) =
      pathProd U ((γ.map reflL).map (linkCast (red3 L m) (thS3 L (m + 1) x))) := by
  induction γ with
  | nil => rfl
  | cons l rest ih =>
    have h1 := ih fun l' hl' => hs l' (List.mem_cons_of_mem _ hl')
    simp only [pathProd, List.map_cons, List.prod_cons] at h1 ⊢
    rw [h1, step_refl3 L m U x l (hs l List.mem_cons_self)]

/-- Casting a chain walked backwards is walking the cast chain backwards. -/
theorem revL_cast {G : Type*} [AddCommGroup G] (φ : (Fin 4 → ℤ) →+ G) (x : G) (γ : List Link)
    (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) :
    (revL γ).map (linkCast φ x) = revPath (γ.map (linkCast φ x)) := by
  simp only [revL, revPath, List.map_reverse, List.map_map]
  congr 1
  refine List.map_congr_left fun l hl => ?_
  simp only [Function.comp_apply]
  exact linkCast_flip φ x (hs l hl)

theorem shift_cast {G : Type*} [AddCommGroup G] (φ : (Fin 4 → ℤ) →+ G) (x : G)
    (v : Fin 4 → ℤ) (γ : List Link) :
    (γ.map (shiftL v)).map (linkCast φ x) = γ.map (linkCast φ (x + φ v)) := by
  simp only [List.map_map]
  congr 1
  funext l
  exact linkCast_shift φ x v l

/-- The fine image of the reflected coarse link of direction `0`: `Θ(3y) - 3 e₀ = 3(Θy - e₀)`. -/
theorem base3_refl0 (m : ℕ) (y : Site3 L m) :
    thS3 L (m + 1) (base3 L m (y, 0)) + red3 L m (-(3 • ev 0)) =
      base3 L m (thS3 L m y - Pi.single 0 1, 0) := by
  funext i
  by_cases hi : i = 0
  · subst hi
    simp [thS3, base3, red3, ev, map_sub, triple_one]
    try (push_cast; ring)
  · simp [thS3, base3, red3, ev, hi, Pi.single_apply]

theorem flipD_invol : Function.Involutive (fun p : Idx => (flipD p.1, p.2)) := by
  intro p
  obtain ⟨d, o⟩ := p
  simp only [Prod.mk.injEq, and_true]
  funext i
  simp only [flipD]
  split_ifs <;> simp

theorem shift_sign (v : Fin 4 → ℤ) (γ : List Link) (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) :
    ∀ l ∈ γ.map (shiftL v), l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  obtain ⟨l', hl', rfl⟩ := List.mem_map.1 hl
  exact hs l' hl'

/-- The reindexing `(d, o) ↦ (flipD d, o)` of the paths. -/
def flipE : Idx ≃ Idx := Function.Involutive.toPerm _ flipD_invol

theorem flipE_apply (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) : flipE (d, o) = (flipD d, o) :=
  rfl

theorem reflV3_zero (m : ℕ) (G : Lk3 L m → ℍr) (y : Site3 L m) :
    reflV3 L m G (y, 0) = star (G (thS3 L m y - Pi.single 0 1, 0)) := by
  unfold reflV3; exact if_pos rfl

theorem reflV3_ne (m : ℕ) (G : Lk3 L m → ℍr) (y : Site3 L m) {ν : Fin 4} (hν : ν ≠ 0) :
    reflV3 L m G (y, ν) = G (thS3 L m y, ν) := by
  unfold reflV3; exact if_neg hν

theorem pathsIdx_eq (m : ℕ) (b : Lk3 L m) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    pathsIdx L m b (d, o) = (path b.2 d o).map (linkCast (red3 L m) (base3 L m b)) := rfl

/-- **The reflection commutes with the block map** (values, every coarse link). -/
theorem blockMap_refl {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Lk3 L (m + 1) → ℍr)
    (hU : ∀ ℓ, U ℓ ∈ Metric.closedBall (0 : ℍr) 1) (b : Lk3 L m) :
    retract r₀ (∑ p : Idx, (1 / 1944 : ℝ) • pathProd (reflV3 L (m + 1) U) (pathsIdx L m b p)) =
      reflV3 L m (fun ℓ => (blockMap r₀ hr (paths L) (wts L) m
        (fun ℓ' => ⟨U ℓ', hU ℓ'⟩) ℓ : ℍr)) b := by
  obtain ⟨y, ν⟩ := b
  by_cases hν : ν = 0
  · subst hν
    rw [reflV3_zero]
    beta_reduce
    rw [blockMap_eq L hr, ← retract_star, star_sum]
    refine congrArg (retract r₀) ?_
    refine Fintype.sum_equiv flipE _ _ (fun p => ?_)
    obtain ⟨d, o⟩ := p
    rw [flipE_apply, Quaternion.star_smul, ← pathProd_rev]
    congr 1
    rw [pathsIdx_eq, pathsIdx_eq, pathProd_refl3 L m U _ _ (path_sign 0 d o), path_refl_zero,
      revL_cast _ _ _ (shift_sign _ _ (path_sign 0 (flipD d) o)), shift_cast, base3_refl0]
  · rw [reflV3_ne L m _ y hν]
    beta_reduce
    rw [blockMap_eq L hr]
    refine congrArg (retract r₀) ?_
    refine Fintype.sum_equiv flipE _ _ (fun p => ?_)
    obtain ⟨d, o⟩ := p
    rw [flipE_apply]
    congr 1
    rw [pathsIdx_eq, pathsIdx_eq, pathProd_refl3 L m U _ _ (path_sign ν d o), path_refl_ne hν,
      base3_refl]

/-- The reflection on ball-valued configurations. -/
noncomputable def reflCfg3 (m : ℕ) (U : Cfg (Lk3 L m)) : Cfg (Lk3 L m) := fun ℓ =>
  ⟨reflV3 L m (fun ℓ' => (U ℓ' : ℍr)) ℓ, by
    rw [mem_ball_iff]
    unfold reflV3
    split_ifs
    · rw [norm_star]; exact (mem_ball_iff _).1 (U _).2
    · exact (mem_ball_iff _).1 (U _).2⟩

/-- **`blockMap ∘ Θ = Θ ∘ blockMap`** on configurations, every level and every side. -/
theorem blockMap_refl_cfg {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (Lk3 L (m + 1))) :
    blockMap r₀ hr (paths L) (wts L) m (reflCfg3 L (m + 1) U) =
      reflCfg3 L m (blockMap r₀ hr (paths L) (wts L) m U) := by
  funext b
  apply Subtype.ext
  show (blockMap r₀ hr (paths L) (wts L) m (reflCfg3 L (m + 1) U) b : ℍr) =
    reflV3 L m (fun ℓ => (blockMap r₀ hr (paths L) (wts L) m U ℓ : ℍr)) b
  rw [blockMap_eq L hr]
  exact blockMap_refl L hr m (fun ℓ => (U ℓ : ℍr)) (fun ℓ => (U ℓ).2) b

end ReflBox

end Block3

#print axioms Block3.blockMap_refl
#print axioms Block3.blockMap_refl_cfg
