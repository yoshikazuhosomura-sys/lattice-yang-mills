import Block3.Trans3V1
/-!
# Centred blocks of side 3: the chain theorem for the tuned Wilson family

Paper: §9 (the tuned family inserted into the chain theorem `ChainBlockMap.chain_end_to_end_blockMap`,
which is general in the family of paths and weights).
With `Lk := Lk3 L`, `paths := paths L`, `w := wts L`, `μ := wFam3 L β` (normalised Wilson measures on
`(ℤ/3^n L)⁴`) and `L = 2c`:
* the reflection field: `Θ m := reflCfg3 L m` (site reflection `x₀ ↦ -x₀`), `Aset m` := bounded continuous `F`
  depending only on the coarse links `b` with `OpenPos L m (3^m c) b` (both ends at coarse times in
  `[1, 3^m c − 1]`); `hΘc`, `hΘp` are paid by `continuous_reflCfg3` and `rp_push_prob` (`hΘp_tuned3`);
* the symmetry field: `actb v m := shV (3^m L) (v m)` (coarse translations); `hsc`, `hsym` are paid by
  `ν3_shV_invariant` (`hsym_tuned3`);
* the rarity field: its plaquette part from the Markov bound `6(1 − κ m)/yh m` whenever `κ m ≤ Y3 m k (β (m+k))`
  for large `k` (`rarity_of_Y3`); at level `m₀` this is paid by the tuning equation.
**`chain_end_to_end_tuned3`** keeps as hypotheses: the lower bounds `hY` at the levels `m ≠ m₀`, the background part
`hS` of the two-stage index, the plaquette bookkeeping (`hplaq`, `hnp`, `hnpt`, `hyh`), and all fields of the chain
theorem that do not involve the measures through the reflection, the translations or the plaquettes (`HE`,
`lattice_vanishing`, `shift_vanishing`, `split`, `h0`, `hCu`, `Cset`, `hCc`, `hgood`, the observable fields and
`HR`).  Remark: `hY` with `κ m = -1` holds for every `β` (`plaqAvg ≥ -1`), so it carries no information unless
`κ m > -1`; the bound it gives is then `12/yh m`.
-/

set_option maxRecDepth 4000

namespace Block3

open MeasureTheory Filter Topology Set TorusRP ChainBlockMap TunedCoupling FoldAffine
open scoped ENNReal

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- The plaquette variable of the two-stage index on the coarse torus of level `m`. -/
noncomputable def plaqDev3 (m : ℕ) (p : TorusRP.Lk (3 ^ m * L) × Fin 4) (ω : Cfg (Lk3 L m)) : ℝ :=
  1 - (hol (3 ^ m * L) ω p).re

theorem plaq_measure_le3 (m k : ℕ) (b κ y : ℝ) (hy : 0 < y) (hY : κ ≤ Y3 L hr m k b)
    (p : TorusRP.Lk (3 ^ m * L) × Fin 4) (hp : p ∈ plaqs (3 ^ m * L)) :
    (ν3 L hr m k b : Measure (TorusRP.Lk (3 ^ m * L) → QBall))
        {V | y < 1 - (hol (3 ^ m * L) V p).re} ≤ ENNReal.ofReal (6 * (1 - κ) / y) := by
  have h1 := markov_plaq_six (3 ^ m * L) (ν3 L hr m k b : Measure (TorusRP.Lk (3 ^ m * L) → QBall))
    (fun v f hf => ν3_shV_invariant L hr m k b v f hf) _ rfl y hy p hp
  rw [integral_ν3] at h1
  have h2 : 6 * (1 - Y3 L hr m k b) / y ≤ 6 * (1 - κ) / y := by
    apply div_le_div_of_nonneg_right _ hy.le
    linarith
  calc (ν3 L hr m k b : Measure (TorusRP.Lk (3 ^ m * L) → QBall))
        {V | y < 1 - (hol (3 ^ m * L) V p).re}
      ≤ (ν3 L hr m k b : Measure (TorusRP.Lk (3 ^ m * L) → QBall))
          {V | y ≤ 1 - (hol (3 ^ m * L) V p).re} :=
        measure_mono (fun V (hV : y < 1 - (hol (3 ^ m * L) V p).re) =>
          (le_of_lt hV : y ≤ 1 - (hol (3 ^ m * L) V p).re))
    _ = ENNReal.ofReal ((ν3 L hr m k b : Measure (TorusRP.Lk (3 ^ m * L) → QBall)).real
          {V | y ≤ 1 - (hol (3 ^ m * L) V p).re}) := (ofReal_measureReal (measure_ne_top _ _)).symm
    _ ≤ ENNReal.ofReal (6 * (1 - κ) / y) := ENNReal.ofReal_le_ofReal (h1.trans h2)

/-- **The rarity field from lower bounds on `Y3`** (plaquette part); the background part is a hypothesis. -/
theorem rarity_of_Y3 (β : ℕ → ℝ) {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (TorusRP.Lk (3 ^ m * L) × Fin 4)) (pts : ∀ m, ι m → Finset (Pt m))
    (f : ∀ m, Pt m → Cfg (Lk3 L m) → ℝ) (yh θ : ℕ → ℝ) (S : ℕ → ℝ≥0∞)
    (np npt : ℕ → ℕ) (κ : ℕ → ℝ)
    (hplaq : ∀ m, ∀ i ∈ R m, plaq m i ⊆ plaqs (3 ^ m * L))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m) (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hyh : ∀ m, 0 < yh m)
    (hY : ∀ m, ∀ᶠ k in atTop, κ m ≤ Y3 L hr m k (β (m + k)))
    (hS : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) {ω | θ m < f m x ω} ≤ S m) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) {ω | (1 / 2 : ℝ) <
        TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (plaqDev3 L m) (f m) (yh m) (θ m) ω} ≤
        (np m : ℝ≥0∞) * ENNReal.ofReal (6 * (1 - κ m) / yh m) + npt m * S m := by
  intro m
  obtain ⟨K, hK⟩ := Filter.eventually_atTop.1 (hY m)
  filter_upwards [hS m, Filter.eventually_ge_atTop (m + K)] with n hSn hn
  intro i hi
  obtain ⟨k, rfl⟩ : ∃ k, n = m + k := ⟨n - m, by omega⟩
  rw [TwoStageSmallField.index_bad_eq]
  refine TwoStageSmallField.block_bad_le_counts _ _ _ _ _ _ _ _ _ _ _ (hnp m i hi) (hnpt m i hi) ?_ (hSn i hi)
  intro p hp
  rw [νP_wFam3 L hr β m k]
  exact plaq_measure_le3 L hr m k _ (κ m) (yh m) (hyh m) (hK k (by omega)) p (hplaq m i hi hp)

/-- The class of the reflection field: bounded continuous functions of the coarse links strictly between the two
site planes `0` and `3^m c` of the coarse torus of side `3^m L = 2 · 3^m c`. -/
def AsetRP (c m : ℕ) : Set (BoundedContinuousFunction (Cfg (Lk3 L m)) ℝ) :=
  {F | ∀ V V' : Cfg (Lk3 L m), (∀ b, OpenPos L m (3 ^ m * c) b → V b = V' b) → F V = F V'}

/-- **The reflection field `hΘp` for the Wilson family with any couplings** (`L = 2c`). -/
theorem hΘp_tuned3 (c : ℕ) (hc : L = 2 * c) (β : ℕ → ℝ) :
    ∀ m, ∀ᶠ n in atTop, ∀ F ∈ AsetRP L c m,
      0 ≤ ∫ ω, F (reflCfg3 L m ω) * F ω ∂(νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) := by
  intro m
  filter_upwards [Filter.eventually_ge_atTop m] with n hmn
  intro F hF
  have hN : 3 ^ n * L = 2 * (3 ^ (n - m) * (3 ^ m * c)) := by
    rw [hc, ← mul_assoc (3 ^ (n - m)), ← pow_add, Nat.sub_add_cancel hmn]; ring
  have hMc : 3 ^ m * c ≤ 3 ^ m * L := by rw [hc]; exact Nat.mul_le_mul_left _ (by omega)
  have h := rp_push_prob L hr hmn hMc hN (β n) F F.continuous.measurable ‖F‖
    (fun V => by rw [← Real.norm_eq_abs]; exact F.norm_coe_le_norm V) hF
  simpa only [νP, ProbabilityMeasure.toMeasure_map, wFam3] using h

/-- **The symmetry field `hsym` for coarse translations, for the Wilson family with any couplings.** -/
theorem hsym_tuned3 (β : ℕ → ℝ) :
    ∀ (v : ∀ m, Site3 L m) (m : ℕ), ∀ᶠ n in atTop,
      ∀ F : BoundedContinuousFunction (Cfg (Lk3 L m)) ℝ,
      ∫ ω, F (shV (3 ^ m * L) (v m) ω) ∂(νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) =
        ∫ ω, F ω ∂(νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) := by
  intro v m
  refine Filter.eventually_atTop.2 ⟨m, fun n hn => ?_⟩
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
  intro F
  rw [νP_wFam3 L hr β m k]
  exact ν3_shV_invariant L hr m k _ (v m) F F.continuous

/-- **The chain theorem for the tuned Wilson family of the centred block map of side 3.**
Fields paid here: `Θ`, `Aset`, `hΘc`, `hΘp` (site reflection, `rp_push_prob`, `L = 2c`), `actb`, `hsc`, `hsym`
(coarse translations), the plaquette part of `rarity` at level `m₀` (tuning equation).  Remaining hypotheses: see the
module docstring. -/
theorem chain_end_to_end_tuned3 {X : Type*} [MetricSpace X] (c : ℕ) (hc : L = 2 * c)
    (β : ℕ → ℝ) (m₀ : ℕ) (κ₀ : ℝ) (ht : Tuned3 L hr m₀ κ₀ β) (κ : ℕ → ℝ) (hκ0 : κ m₀ = κ₀)
    (hY : ∀ m, m ≠ m₀ → ∀ᶠ k in atTop, κ m ≤ Y3 L hr m k (β (m + k)))
    {u z w' rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (TorusRP.Lk (3 ^ m * L) × Fin 4)) (pts : ∀ m, ι m → Finset (Pt m))
    (f : ∀ m, Pt m → Cfg (Lk3 L m) → ℝ) (yh θ : ℕ → ℝ)
    (S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : TransientChainError.CouplingStepsTransientE u z w' rs rl Φ W Dfun δ e b binf bp D₀ ρ A
      B Y ustar)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d'))
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Cset : ∀ m, Set (Cfg (Lk3 L m)))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, plaqDev3 L m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (Cfg (Lk3 L (lev x))) ℝ)
    (HR : WeakUltravioletExistence.Representation (νP r₀ hr (paths L) (wts L) (wFam3 L β)) Dset s lev Fo)
    (hplaq : ∀ m, ∀ i ∈ R m, plaq m i ⊆ plaqs (3 ^ m * L))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m) (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hyh : ∀ m, 0 < yh m)
    (hS : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) {ω | θ m < f m x ω} ≤ S m) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (e ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (e ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (Cfg (Lk3 L m)),
      (∀ m, Tendsto (fun k => νP r₀ hr (paths L) (wts L) (wFam3 L β) (φ k) m) atTop (𝓝 (νl m))) ∧
      (WeakUltravioletExistence.BlockConclusion νl (blockMap r₀ hr (paths L) (wts L))
        (continuous_blockMap r₀ hr (paths L) (wts L)) (reflCfg3 L) (AsetRP L c)
        (fun (v : ∀ m, Site3 L m) m => shV (3 ^ m * L) (v m)) Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * ENNReal.ofReal (6 * (1 - κ m) / yh m) + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (Cfg (Lk3 L (lev d))))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset) ∧
      ∫ V, plaqAvg (3 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (3 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (3 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤
        (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (3 ^ m₀ * L) V}) := by
  have hYall : ∀ m, ∀ᶠ k in atTop, κ m ≤ Y3 L hr m k (β (m + k)) := by
    intro m
    by_cases h : m = m₀
    · subst h
      exact Filter.Eventually.of_forall (fun k => by rw [hκ0, ht k])
    · exact hY m h
  have hrar := rarity_of_Y3 L hr β R plaq pts f yh θ S np npt κ hplaq hnp hnpt hyh hYall hS
  obtain ⟨h1, h2⟩ := chain_end_to_end_blockMap (Lk := Lk3 L)
    (Pl := fun m => TorusRP.Lk (3 ^ m * L) × Fin 4) r₀ hr (paths L) (wts L) (wFam3 L β) R plaq pts
    (plaqDev3 L) f yh θ (fun m => ENNReal.ofReal (6 * (1 - κ m) / yh m)) S np npt HE hrar lattice_vanishing
    shift_vanishing split h0 hCu (reflCfg3 L) (AsetRP L c)
    (fun (v : ∀ m, Site3 L m) m => shV (3 ^ m * L) (v m)) Cset
    (continuous_reflCfg3 L) (hΘp_tuned3 L hr c hc β) (fun v m => continuous_shV _ (v m))
    (hsym_tuned3 L hr β) hCc hgood Bd act εb Pset hcount hdense hbd hac ham hbr hbv hpos lev Fo HR
  exact ⟨h1, attach_tuned3 L hr m₀ κ₀ β ht _ h2⟩

/-! ### Sanity -/

/-- One witness meeting the arithmetic of `rp_push` and the class at once: `L = 2`, `m = 1`, `n = 2`, `Mc = 3`
(`= 3^m L / 2`; the hypothesis `hN` forces `Mc = 3^m L/2`, so `L` must be even), and both a spatial and a time
link at coarse time `1` lie in `OpenPos`. -/
theorem rp_witness :
    3 ^ 2 * 2 = 2 * (3 ^ (2 - 1) * 3) ∧ 3 ≤ 3 ^ 1 * 2 ∧
      OpenPos 2 1 3 (fun i => if i = 0 then 1 else 0, 1) ∧
      OpenPos 2 1 3 (fun i => if i = 0 then 1 else 0, 0) := by
  have hne : (3 ^ 1 * 2 : ℕ) ≠ 1 := by norm_num
  refine ⟨by norm_num, by norm_num, ⟨?_, ?_⟩, ⟨?_, ?_⟩⟩
  · simp only [if_true]; rw [ZMod.val_one'' hne]
  · simp only [if_true, show ¬ (1 : Fin 4) = 0 from by decide, if_false]
    rw [ZMod.val_one'' hne]
    norm_num
  · simp only [if_true]; rw [ZMod.val_one'' hne]
  · simp only [if_true]
    rw [ZMod.val_one'' hne]

/-- The class `AsetRP` contains the real part of the value on any single coarse link of `OpenPos`. -/
theorem re_mem_AsetRP (c m : ℕ) (b₀ : Lk3 L m) (hb₀ : OpenPos L m (3 ^ m * c) b₀) :
    ∃ F ∈ AsetRP L c m, ∀ V, F V = ((V b₀ : Ball) : Quaternion ℝ).re := by
  let F : BoundedContinuousFunction (Cfg (Lk3 L m)) ℝ := BoundedContinuousFunction.mkOfCompact
    ⟨fun V => ((V b₀ : Ball) : Quaternion ℝ).re,
      Quaternion.continuous_re.comp (continuous_subtype_val.comp (continuous_apply b₀))⟩
  refine ⟨F, fun V V' h => ?_, fun V => rfl⟩
  show ((V b₀ : Ball) : Quaternion ℝ).re = ((V' b₀ : Ball) : Quaternion ℝ).re
  rw [h b₀ hb₀]

end Block3

#print axioms Block3.hΘp_tuned3
#print axioms Block3.hsym_tuned3
#print axioms Block3.chain_end_to_end_tuned3
#print axioms Block3.rp_witness
#print axioms Block3.re_mem_AsetRP
