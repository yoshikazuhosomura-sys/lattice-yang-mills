import Block3.Chain3V1
/-!
# Centred blocks of side 3: further sanity checks

* `reflCfg3_spatial` and `thS3_moves`: the site reflection reads the value of a spatial coarse link `(y, 1)` at the
  link `(Θy, 1)`, and `Θy ≠ y` for `y = e₀` on the box of side `3 · 2` (so the reflection is not the identity on the
  coarse values; this is the check announced in the docstring of `Block3.SanityV1`, which had no statement).
* Scope of `Block3.blockMap_flip`: it is the one-level sign flip (the coarse plaquette expectation is not part of it);
  the vanishing of the Haar mean of every coarse plaquette, at every level, is `Block3.integral_re_hol_down_haar`, and
  `Y3 m k 0 = 0` is `Block3.Y3_zero`.
* `Y3_ne_flat_and_zero`: under the tuning with `0 < κ₀ < 1`, `Y3 m₀ k (β (m₀+k))` differs from the value `0` at
  `β = 0` and from the flat value `1`, at every `k`.
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap

local notation "ℍr" => Quaternion ℝ

theorem reflCfg3_spatial (L : ℕ) [NeZero L] (m : ℕ) (U : Cfg (Lk3 L m)) (y : Site3 L m) :
    ((reflCfg3 L m U (y, 1) : Ball) : ℍr) = (U (thS3 L m y, 1) : ℍr) :=
  reflV3_ne L m (fun ℓ' => (U ℓ' : ℍr)) y (ν := 1) (by decide)

theorem thS3_moves :
    thS3 2 1 (fun i => if i = 0 then 1 else 0) ≠ (fun i => if i = 0 then 1 else 0) := by
  intro h
  have h0 := congrFun h 0
  simp only [thS3, if_true] at h0
  revert h0
  decide

theorem Y3_ne_flat_and_zero (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (m₀ : ℕ) (κ₀ : ℝ)
    (h0 : 0 < κ₀) (h1 : κ₀ < 1) (β : ℕ → ℝ) (ht : Tuned3 L hr m₀ κ₀ β) (k : ℕ) :
    Y3 L hr m₀ k (β (m₀ + k)) ≠ 0 ∧ Y3 L hr m₀ k (β (m₀ + k)) ≠ 1 := by
  rw [ht k]; exact ⟨h0.ne', h1.ne⟩

end Block3

#print axioms Block3.reflCfg3_spatial
#print axioms Block3.thS3_moves
#print axioms Block3.Y3_ne_flat_and_zero
