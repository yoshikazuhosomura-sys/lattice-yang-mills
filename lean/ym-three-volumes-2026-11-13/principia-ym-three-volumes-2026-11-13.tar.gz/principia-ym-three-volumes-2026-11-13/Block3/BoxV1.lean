import Block3.ReflV1
/-!
# Centred blocks of side 3 with uniform weights on the periodic boxes `(ZMod (3^m L))⁴`

Paper: (the centred block map of side 3 as a family of paths and weights).
* `Lk3 L m`: positively oriented links of the periodic box of side `3^m L` (level `m + 1` is the
  finer one). The coarse site `y` sits at the fine site `3y` (`triple`, well defined
  `ZMod (3^m L) → ZMod (3^(m+1) L)`), the centre of its block `3y + {-1,0,1}⁴`.
* `pathsIdx L m b (d, o)`: the path of `ℤ⁴` (`Block3.path`) carried to the fine box from `3y`.
  `paths`/`wts`: the `Finset` of the distinct paths and the merged weights (index weight
  `1/1944`, `1944 = 81 · 24`), the arguments `paths`, `w` of `ChainBlockMap.blockMap`.
* `wts_sum` (total mass one), `wts_pos` (every path of the family has positive weight),
  `paths_nonempty`, `coarseAvg_eq` (the coarse value is the uniform average over the 1944
  indices), `pathsIdx_ends` (end points: the fine images `3y`, `3(y + e_μ)` of the two ends of
  the coarse link), **`paths_support`** (every fine link used by a path of the coarse link
  `(y, μ)` is the image of a step inside the block of `y` and the block of `y + e_μ`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

section Box

variable (L : ℕ) [NeZero L]

/-- Sites of the box at level `m` (side `3^m L`). -/
abbrev Site3 (m : ℕ) := Fin 4 → ZMod (3 ^ m * L)

/-- Positively oriented links of the box at level `m`. -/
abbrev Lk3 (m : ℕ) := Site3 L m × Fin 4

instance (m : ℕ) : NeZero (3 ^ m * L) :=
  ⟨Nat.mul_ne_zero (pow_ne_zero _ (by norm_num)) (NeZero.ne L)⟩

instance (m : ℕ) : Fintype (Lk3 L m) := inferInstance

/-- `ZMod (3^m L) → ZMod (3^(m+1) L)`, `y ↦ 3y` (well defined). -/
def triple (m : ℕ) : ZMod (3 ^ m * L) →+ ZMod (3 ^ (m + 1) * L) :=
  ZMod.lift (3 ^ m * L) ⟨(Int.castAddHom (ZMod (3 ^ (m + 1) * L))).comp
      (AddMonoidHom.mulLeft (3 : ℤ)), by
    simp only [AddMonoidHom.coe_comp, Function.comp_apply, AddMonoidHom.coe_mulLeft,
      Int.coe_castAddHom]
    have : ((3 * ((3 ^ m * L : ℕ) : ℤ) : ℤ) : ZMod (3 ^ (m + 1) * L)) =
        ((3 ^ (m + 1) * L : ℕ) : ZMod (3 ^ (m + 1) * L)) := by
      push_cast; ring
    rw [this, ZMod.natCast_self]⟩

theorem triple_intCast (m : ℕ) (k : ℤ) :
    triple L m (k : ZMod (3 ^ m * L)) = ((3 * k : ℤ) : ZMod (3 ^ (m + 1) * L)) := by
  simp [triple, ZMod.lift_coe]

theorem triple_one (m : ℕ) : triple L m 1 = 3 := by
  have := triple_intCast L m 1
  simpa using this

/-- The reduction `ℤ⁴ → (ZMod (3^(m+1) L))⁴` carrying the paths to the fine box. -/
def red3 (m : ℕ) : (Fin 4 → ℤ) →+ Site3 L (m + 1) :=
  AddMonoidHom.compLeft (Int.castAddHom (ZMod (3 ^ (m + 1) * L))) (Fin 4)

/-- Fine base point `3y` (the centre of the block) of the coarse link `(y, μ)`. -/
def base3 (m : ℕ) (b : Lk3 L m) : Site3 L (m + 1) := fun i => triple L m (b.1 i)

/-- Index of a path: the displacement `d ∈ {-1,0,1}⁴` and the order `o` of the four axes. -/
abbrev Idx := (Fin 4 → Fin 3) × Equiv.Perm (Fin 4)

theorem card_idx : Fintype.card Idx = 1944 := by
  simp only [Fintype.card_prod, Fintype.card_fun, Fintype.card_perm, Fintype.card_fin]
  rfl

/-- The indexed paths of the coarse link `b` on the fine box. -/
def pathsIdx (m : ℕ) (b : Lk3 L m) (p : Idx) : List (Lk3 L (m + 1) × Bool) :=
  (path b.2 p.1 p.2).map (linkCast (red3 L m) (base3 L m b))

/-- The distinct paths of the coarse link `b`. -/
def paths (m : ℕ) (b : Lk3 L m) : Finset (List (Lk3 L (m + 1) × Bool)) :=
  univ.image (pathsIdx L m b)

/-- Merged weight of a path: `1/1944` times the number of indices giving it. -/
noncomputable def wts (m : ℕ) (b : Lk3 L m) (γ : List (Lk3 L (m + 1) × Bool)) : ℝ :=
  ∑ p ∈ univ.filter (fun p : Idx => pathsIdx L m b p = γ), (1 / 1944 : ℝ)

/-- **Total mass one.** -/
theorem wts_sum (m : ℕ) (b : Lk3 L m) : ∑ γ ∈ paths L m b, wts L m b γ = 1 := by
  unfold paths wts
  rw [Finset.sum_fiberwise_of_maps_to (s := univ) (t := univ.image (pathsIdx L m b))
    (g := pathsIdx L m b) (fun p _ => mem_image_of_mem _ (mem_univ p)) (fun _ => (1 / 1944 : ℝ))]
  rw [Finset.sum_const, Finset.card_univ, card_idx]
  norm_num

theorem wts_nonneg (m : ℕ) (b : Lk3 L m) (γ : List (Lk3 L (m + 1) × Bool)) : 0 ≤ wts L m b γ :=
  Finset.sum_nonneg fun _ _ => by norm_num

/-- Every path of the family has positive weight. -/
theorem wts_pos (m : ℕ) (b : Lk3 L m) {γ : List (Lk3 L (m + 1) × Bool)} (hγ : γ ∈ paths L m b) :
    0 < wts L m b γ := by
  obtain ⟨p, -, hp⟩ := mem_image.1 hγ
  exact Finset.sum_pos (fun _ _ => by norm_num) ⟨p, mem_filter.2 ⟨mem_univ p, hp⟩⟩

theorem paths_nonempty (m : ℕ) (b : Lk3 L m) : (paths L m b).Nonempty :=
  univ_nonempty.image _

/-- **The coarse value is the uniform average over the 1944 indices.** -/
theorem coarseAvg_eq (m : ℕ) (U : Cfg (Lk3 L (m + 1))) (b : Lk3 L m) :
    coarseAvg (paths L) (wts L) m U b =
      ∑ p : Idx, (1 / 1944 : ℝ) • pathProd (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b p) := by
  unfold coarseAvg avg paths wts
  simp only [Finset.sum_smul]
  rw [← Finset.sum_fiberwise_of_maps_to (s := univ) (t := univ.image (pathsIdx L m b))
    (g := pathsIdx L m b) (fun p _ => mem_image_of_mem _ (mem_univ p))]
  refine Finset.sum_congr rfl fun γ _ => Finset.sum_congr rfl fun p hp => ?_
  rw [(Finset.mem_filter.1 hp).2]

theorem blockMap_eq {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (Lk3 L (m + 1))) (b : Lk3 L m) :
    (blockMap r₀ hr (paths L) (wts L) m U b : ℍr) =
      retract r₀ (∑ p : Idx, (1 / 1944 : ℝ) • pathProd (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b p)) := by
  simp only [blockMap, coarseAvg_eq]

/-- `3 (y + e_μ) = 3y + 3 e_μ` on the fine box. -/
theorem base3_end (m : ℕ) (b : Lk3 L m) :
    base3 L m b + red3 L m (3 • ev b.2) =
      base3 L m (b.1 + Pi.single b.2 (1 : ZMod (3 ^ m * L)), b.2) := by
  funext i
  simp only [base3, red3, Pi.add_apply, AddMonoidHom.compLeft_apply, Function.comp_apply,
    Int.coe_castAddHom, map_add, ev, Pi.smul_apply]
  by_cases h : i = b.2
  · subst h
    simp [triple_one]
  · simp [h]

/-- **End points**: the path of index `p` of the coarse link `b = (y, μ)` is a chain of unit steps
of `ℤ⁴` from `0` to `3 e_μ`, carried from `3y`; and `3y + 3 e_μ = 3 (y + e_μ)`. -/
theorem pathsIdx_ends (m : ℕ) (b : Lk3 L m) (p : Idx) :
    pathsIdx L m b p = (path b.2 p.1 p.2).map (linkCast (red3 L m) (base3 L m b)) ∧
      Walks 0 (path b.2 p.1 p.2) (3 • ev b.2) ∧
      base3 L m b + red3 L m (3 • ev b.2) =
        base3 L m (b.1 + Pi.single b.2 (1 : ZMod (3 ^ m * L)), b.2) :=
  ⟨rfl, path_walks _ _ _, base3_end L m b⟩

/-- **Support**: every fine link used by a path of the coarse link `b = (y, μ)` is the image,
from `3y`, of a step of `ℤ⁴` whose two ends lie in `{-1,0,1}⁴ ∪ (3 e_μ + {-1,0,1}⁴)` (the block
of `y` and the block of `y + e_μ`). -/
theorem paths_support (m : ℕ) (b : Lk3 L m) :
    ∀ γ ∈ paths L m b, ∀ s ∈ γ, ∃ l : Link,
      InTwo b.2 (src l) ∧ InTwo b.2 (tgt l) ∧ s = linkCast (red3 L m) (base3 L m b) l := by
  intro γ hγ s hs
  obtain ⟨p, -, rfl⟩ := mem_image.1 hγ
  obtain ⟨l, hl, rfl⟩ := List.mem_map.1 hs
  exact ⟨l, (path_support _ _ _ l hl).1, (path_support _ _ _ l hl).2, rfl⟩

/-- The ball-valued configurations of the box carry the instances the chain needs. -/
example (m : ℕ) : CompactSpace (Cfg (Lk3 L m)) := inferInstance
example (m : ℕ) : BorelSpace (Cfg (Lk3 L m)) := inferInstance

end Box

end Block3

#print axioms Block3.wts_sum
#print axioms Block3.wts_pos
#print axioms Block3.coarseAvg_eq
#print axioms Block3.blockMap_eq
#print axioms Block3.pathsIdx_ends
#print axioms Block3.paths_support
