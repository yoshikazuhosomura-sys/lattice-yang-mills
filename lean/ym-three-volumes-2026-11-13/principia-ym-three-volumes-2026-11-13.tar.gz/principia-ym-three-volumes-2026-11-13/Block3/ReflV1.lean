import Block3.PathV1
/-!
# Centred blocks of side 3: the site reflection `x₀ ↦ -x₀` on the paths (on `ℤ⁴`)

Paper: (lemma B, commutation with the reflection through the lattice plane
`x₀ = 0`). The reflection of a signed step `reflL` is the one of the box library (a step in
direction `0` is reflected and walked the other way). `flipD` reflects the displacement index
in the coordinate `0` (`dv (2 - j) = - dv j`), the order `o` is kept.
* **`path_refl_ne`**: for a coarse link of direction `μ ≠ 0`, the reflected path is the path of the
  same direction with the reflected displacement and the same order.
* **`path_refl_zero`**: for `μ = 0`, the reflected path is the path of the reflected index walked
  backwards and translated by `-3 e₀` (the path of the reflected coarse link, read from its end).
-/

namespace Block3

open WalkCast BoxWalk

def reflZ (z : Fin 4 → ℤ) : Fin 4 → ℤ := fun i => if i = 0 then -z i else z i

def reflL (l : Link) : Link :=
  if l.2.2 = 0 then (-l.1, reflZ l.2.1 - ev 0, 0) else (l.1, reflZ l.2.1, l.2.2)

def flipD (d : Fin 4 → Fin 3) : Fin 4 → Fin 3 := fun i => if i = 0 then 2 - d i else d i

theorem dv_neg (j : Fin 3) : dv (2 - j) = - dv j := by revert j; decide

theorem reflZ_add (x y : Fin 4 → ℤ) : reflZ (x + y) = reflZ x + reflZ y := by
  funext i; simp only [reflZ, Pi.add_apply]; split_ifs <;> abel

theorem reflZ_sub (x y : Fin 4 → ℤ) : reflZ (x - y) = reflZ x - reflZ y := by
  funext i; simp only [reflZ, Pi.sub_apply]; split_ifs <;> abel

theorem reflZ_nsmul (k : ℕ) (x : Fin 4 → ℤ) : reflZ (k • x) = k • reflZ x := by
  funext i; simp only [reflZ, Pi.smul_apply]; split_ifs <;> simp [smul_neg]

theorem reflZ_ev_ne {n : Fin 4} (hn : n ≠ 0) : reflZ (ev n) = ev n := by
  funext i
  by_cases hi : i = 0
  · subst hi; simp [reflZ, ev, Pi.single_apply, Ne.symm hn]
  · simp [reflZ, hi]

theorem reflZ_ev0 : reflZ (ev 0) = - ev 0 := by
  funext i
  by_cases hi : i = 0
  · subst hi; simp [reflZ]
  · simp [reflZ, hi, ev, Pi.single_apply]

theorem reflL_zero (s : ℤ) (z : Fin 4 → ℤ) : reflL (s, z, 0) = (-s, reflZ z - ev 0, 0) := by
  unfold reflL; exact if_pos rfl

theorem reflL_ne (s : ℤ) (z : Fin 4 → ℤ) {n : Fin 4} (hn : n ≠ 0) :
    reflL (s, z, n) = (s, reflZ z, n) := by
  unfold reflL; exact if_neg hn

theorem fwd_one (z : Fin 4 → ℤ) (n : Fin 4) : fwd 1 z n = [(1, z, n)] := by
  unfold fwd; exact if_pos rfl

theorem fwd_negone (z : Fin 4 → ℤ) (n : Fin 4) : fwd (-1) z n = [(-1, z - ev n, n)] := by
  unfold fwd; rw [if_neg (by decide), if_pos rfl]

theorem fwd_zero (z : Fin 4 → ℤ) (n : Fin 4) : fwd 0 z n = [] := by
  unfold fwd; rw [if_neg (by decide), if_neg (by decide)]

theorem fwd_refl_zero (a : ℤ) (ha : a = 1 ∨ a = 0 ∨ a = -1) (z : Fin 4 → ℤ) :
    (fwd a z 0).map reflL = fwd (-a) (reflZ z) 0 := by
  rcases ha with rfl | rfl | rfl
  · rw [fwd_one, fwd_negone, List.map_cons, List.map_nil, reflL_zero]
  · rw [neg_zero, fwd_zero, fwd_zero, List.map_nil]
  · rw [neg_neg, fwd_negone, fwd_one, List.map_cons, List.map_nil, reflL_zero, reflZ_sub,
      reflZ_ev0]
    congr 3
    abel

theorem fwd_refl_ne (a : ℤ) (ha : a = 1 ∨ a = 0 ∨ a = -1) (z : Fin 4 → ℤ) {n : Fin 4}
    (hn : n ≠ 0) : (fwd a z n).map reflL = fwd a (reflZ z) n := by
  rcases ha with rfl | rfl | rfl
  · rw [fwd_one, fwd_one, List.map_cons, List.map_nil, reflL_ne _ _ hn]
  · rw [fwd_zero, fwd_zero, List.map_nil]
  · rw [fwd_negone, fwd_negone, List.map_cons, List.map_nil, reflL_ne _ _ hn, reflZ_sub,
      reflZ_ev_ne hn]

theorem cpt_refl (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : ℕ) :
    reflZ (cpt o d k) = cpt o (flipD d) k := by
  funext i
  by_cases hi : i = 0
  · subst hi
    simp only [reflZ, cpt, flipD, if_pos rfl]
    split_ifs <;> simp [dv_neg]
  · simp only [reflZ, cpt, flipD, hi, if_false]

theorem dvec_refl (d : Fin 4 → Fin 3) : reflZ (dvec d) = dvec (flipD d) := by
  funext i
  by_cases hi : i = 0
  · subst hi; simp only [reflZ, dvec, flipD, ↓reduceIte, dv_neg]
  · simp only [reflZ, dvec, flipD, hi, if_false]

theorem cstep_refl (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : Fin 4) :
    (cstep o d k).map reflL = cstep o (flipD d) k := by
  unfold cstep
  rw [← cpt_refl]
  by_cases h : o k = 0
  · rw [h, fwd_refl_zero _ (dv_cases _)]
    congr 1
    simp only [flipD, ↓reduceIte, dv_neg]
  · rw [fwd_refl_ne _ (dv_cases _) _ h]
    congr 1
    simp only [flipD, h, if_false]

theorem contour_refl (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) :
    (contour o d).map reflL = contour o (flipD d) := by
  unfold contour
  simp only [List.map_append, cstep_refl]

theorem line_refl_ne {μ : Fin 4} (hμ : μ ≠ 0) (x : Fin 4 → ℤ) :
    (line μ x).map reflL = line μ (reflZ x) := by
  unfold line
  simp only [List.map_cons, List.map_nil, reflL_ne _ _ hμ, reflZ_add, reflZ_ev_ne hμ]

theorem flipL_flipL (l : Link) : flipL (flipL l) = l := by
  obtain ⟨s, z, n⟩ := l; simp [flipL]

theorem reflL_flipL (l : Link) : reflL (flipL l) = flipL (reflL l) := by
  obtain ⟨s, z, n⟩ := l
  by_cases hn : n = 0
  · subst hn
    show reflL (-s, z, 0) = flipL (reflL (s, z, 0))
    rw [reflL_zero, reflL_zero]; rfl
  · show reflL (-s, z, n) = flipL (reflL (s, z, n))
    rw [reflL_ne _ _ hn, reflL_ne _ _ hn]; rfl

theorem reflL_shiftL (v : Fin 4 → ℤ) (l : Link) : reflL (shiftL v l) = shiftL (reflZ v) (reflL l) := by
  obtain ⟨s, z, n⟩ := l
  by_cases hn : n = 0
  · subst hn
    show reflL (s, z + v, 0) = shiftL (reflZ v) (reflL (s, z, 0))
    rw [reflL_zero, reflL_zero, reflZ_add]
    show _ = (-s, reflZ z - ev 0 + reflZ v, 0)
    congr 2
    abel
  · show reflL (s, z + v, n) = shiftL (reflZ v) (reflL (s, z, n))
    rw [reflL_ne _ _ hn, reflL_ne _ _ hn, reflZ_add]; rfl

theorem shiftL_flipL (v : Fin 4 → ℤ) (l : Link) : shiftL v (flipL l) = flipL (shiftL v l) := by
  obtain ⟨s, z, n⟩ := l; rfl

theorem shiftL_shiftL (v w : Fin 4 → ℤ) (l : Link) : shiftL w (shiftL v l) = shiftL (v + w) l := by
  obtain ⟨s, z, n⟩ := l
  show (s, z + v + w, n) = (s, z + (v + w), n)
  rw [add_assoc]

theorem revL_append (a b : List Link) : revL (a ++ b) = revL b ++ revL a := by
  simp [revL]

theorem revL_revL (γ : List Link) : revL (revL γ) = γ := by
  simp only [revL, List.map_reverse, List.reverse_reverse, List.map_map]
  conv_rhs => rw [← List.map_id γ]
  congr 1
  funext l
  exact flipL_flipL l

theorem revL_map_refl (γ : List Link) : (revL γ).map reflL = revL (γ.map reflL) := by
  simp only [revL, List.map_reverse, List.map_map]
  congr 2
  funext l
  exact reflL_flipL l

theorem revL_map_shift (v : Fin 4 → ℤ) (γ : List Link) :
    (revL γ).map (shiftL v) = revL (γ.map (shiftL v)) := by
  simp only [revL, List.map_reverse, List.map_map]
  congr 2

theorem map_shift_refl (v : Fin 4 → ℤ) (γ : List Link) :
    (γ.map (shiftL v)).map reflL = (γ.map reflL).map (shiftL (reflZ v)) := by
  simp only [List.map_map]
  congr 1
  funext l
  exact reflL_shiftL v l

theorem map_shift_shift (v w : Fin 4 → ℤ) (γ : List Link) :
    (γ.map (shiftL v)).map (shiftL w) = γ.map (shiftL (v + w)) := by
  simp only [List.map_map]
  congr 1
  funext l
  exact shiftL_shiftL v w l

theorem map_shift_zero (γ : List Link) : γ.map (shiftL 0) = γ := by
  conv_rhs => rw [← List.map_id γ]
  congr 1
  funext l
  obtain ⟨s, z, n⟩ := l
  show (s, z + 0, n) = (s, z, n)
  rw [add_zero]

theorem line_shift (μ : Fin 4) (x v : Fin 4 → ℤ) : (line μ x).map (shiftL v) = line μ (x + v) := by
  unfold line
  simp only [List.map_cons, List.map_nil]
  show [(1, x + v, μ), (1, x + ev μ + v, μ), (1, x + ev μ + ev μ + v, μ)] = _
  congr 3 <;> abel

theorem line_refl_zero (x : Fin 4 → ℤ) :
    (line 0 x).map reflL = revL (line 0 (reflZ x - 3 • ev 0)) := by
  unfold line revL
  simp only [List.map_cons, List.map_nil, reflL_zero, reflZ_add, reflZ_ev0, List.reverse_cons,
    List.reverse_nil, List.nil_append, List.cons_append]
  show [(-1, reflZ x - ev 0, 0), (-1, reflZ x + -ev 0 - ev 0, 0),
      (-1, reflZ x + -ev 0 + -ev 0 - ev 0, 0)] =
    [(-1, reflZ x - 3 • ev 0 + ev 0 + ev 0, 0), (-1, reflZ x - 3 • ev 0 + ev 0, 0),
      (-1, reflZ x - 3 • ev 0, 0)]
  congr 3 <;> abel

/-- **The reflection of the paths of a coarse link of direction `μ ≠ 0`**. -/
theorem path_refl_ne {μ : Fin 4} (hμ : μ ≠ 0) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    (path μ d o).map reflL = path μ (flipD d) o := by
  unfold path
  rw [List.map_append, List.map_append, contour_refl, line_refl_ne hμ, dvec_refl, revL_map_refl,
    map_shift_refl, contour_refl, reflZ_nsmul, reflZ_ev_ne hμ]

/-- **The reflection of the paths of a coarse link of direction `0`**: the path of the reflected
index, walked backwards from its end and translated by `-3 e₀`. -/
theorem path_refl_zero (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    (path 0 d o).map reflL = revL ((path 0 (flipD d) o).map (shiftL (-(3 • ev 0)))) := by
  unfold path
  rw [List.map_append, List.map_append, contour_refl, line_refl_zero, dvec_refl, revL_map_refl,
    map_shift_refl, contour_refl, reflZ_nsmul, reflZ_ev0, smul_neg]
  rw [List.map_append, List.map_append, revL_append, revL_append, revL_map_shift,
    map_shift_shift, add_neg_cancel, map_shift_zero, revL_revL, line_shift, ← sub_eq_add_neg,
    List.append_assoc]

end Block3

#print axioms Block3.path_refl_ne
#print axioms Block3.path_refl_zero
