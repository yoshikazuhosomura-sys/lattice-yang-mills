import Block3.FlipAllV1
/-!
# Centred blocks of side 3: a flat field is carried to a flat field

Paper: (upper end of the tuning bracket). `FlatPush.FlatQ e U` (unit link values
and `U(y,a) U(y+e_a,b) = U(y,b) U(y+e_b,a)`) is abstract in the group of sites.
* `spine3`: the straight three-step product `U(y,μ) U(y+e_μ,μ) U(y+2e_μ,μ)`;
* `comm_spine3`: under `FlatQ`, one transverse step is moved across the three-step spine;
* `pv_walk_spine3`: for any chain of unit steps `γ` from `a` to `c`, the product along
  `γ`, the spine from `c`, and the return of `γ` shifted by `3 e_μ` is the spine from `a`;
* `pathProd_path_flat`: the product along every path of the family is the spine from `0`;
* `blockMap_flat_val`, `blockMap_flatQ` (`r₀ ≤ 1`): the block map sends a flat field to the
  three-step spines, and the image is flat (the coarse plaquette is the 3 × 3 fine square);
* **`down_flatQ`**, **`plaqAvg_down_of_flat`**: the same for `down n m`, every `m ≤ n`.
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset FlatPush

local notation "ℍr" => Quaternion ℝ

section Abstract

variable {G : Type*} [AddCommGroup G] {e : Fin 4 → G} {U : G × Fin 4 → ℍr}

/-- The straight three-step product in direction `μ` from `y`. -/
noncomputable def spine3 (e : Fin 4 → G) (U : G × Fin 4 → ℍr) (μ : Fin 4) (y : G) : ℍr :=
  U (y, μ) * U (y + e μ, μ) * U (y + e μ + e μ, μ)

/-- **One transverse step across the three-step spine.** -/
theorem comm_spine3 (hf : FlatQ e U) (μ n : Fin 4) (y : G) :
    U (y, n) * spine3 e U μ (y + e n) = spine3 e U μ y * U (y + e μ + e μ + e μ, n) := by
  unfold spine3
  have p1 : y + e n + e μ = y + e μ + e n := by abel
  have p2 : y + e n + e μ + e μ = y + e μ + e μ + e n := by abel
  rw [p2, p1]
  calc U (y, n) * (U (y + e n, μ) * U (y + e μ + e n, μ) * U (y + e μ + e μ + e n, μ))
      = (U (y, n) * U (y + e n, μ)) * U (y + e μ + e n, μ) * U (y + e μ + e μ + e n, μ) := by
        simp only [mul_assoc]
    _ = U (y, μ) * (U (y + e μ, n) * U (y + e μ + e n, μ)) * U (y + e μ + e μ + e n, μ) := by
        rw [hf.2 y n μ]; simp only [mul_assoc]
    _ = U (y, μ) * (U (y + e μ, μ) * U (y + e μ + e μ, n)) * U (y + e μ + e μ + e n, μ) := by
        rw [hf.2 (y + e μ) n μ]
    _ = U (y, μ) * U (y + e μ, μ) * (U (y + e μ + e μ, n) * U (y + e μ + e μ + e n, μ)) := by
        simp only [mul_assoc]
    _ = U (y, μ) * U (y + e μ, μ) * (U (y + e μ + e μ, μ) * U (y + e μ + e μ + e μ, n)) := by
        rw [hf.2 (y + e μ + e μ) n μ]
    _ = U (y, μ) * U (y + e μ, μ) * U (y + e μ + e μ, μ) * U (y + e μ + e μ + e μ, n) := by
        simp only [mul_assoc]

theorem spine3_unit (hf : FlatQ e U) (μ : Fin 4) (y : G) :
    spine3 e U μ y * star (spine3 e U μ y) = 1 := by
  unfold spine3
  rw [star_mul, star_mul]
  have h1 := hf.1 (y, μ)
  have h2 := hf.1 (y + e μ, μ)
  have h3 := hf.1 (y + e μ + e μ, μ)
  calc U (y, μ) * U (y + e μ, μ) * U (y + e μ + e μ, μ) *
        (star (U (y + e μ + e μ, μ)) * (star (U (y + e μ, μ)) * star (U (y, μ))))
      = U (y, μ) * (U (y + e μ, μ) * (U (y + e μ + e μ, μ) * star (U (y + e μ + e μ, μ))) *
          star (U (y + e μ, μ))) * star (U (y, μ)) := by simp only [mul_assoc]
    _ = 1 := by rw [h3, mul_one, h2, mul_one, h1]

/-- **The 3 × 3 square**: two spines in directions `a`, `c` commute around the square. -/
theorem spine3_square (hf : FlatQ e U) (a c : Fin 4) (Y : G) :
    spine3 e U a Y * spine3 e U c (Y + e a + e a + e a) =
      spine3 e U c Y * spine3 e U a (Y + e c + e c + e c) := by
  have h0 := comm_spine3 hf a c Y
  have h1 := comm_spine3 hf a c (Y + e c)
  have h2 := comm_spine3 hf a c (Y + e c + e c)
  have q1 : Y + e a + e a + e a + e c = Y + e c + e a + e a + e a := by abel
  have q2 : Y + e a + e a + e a + e c + e c = Y + e c + e c + e a + e a + e a := by abel
  have hs : spine3 e U c (Y + e a + e a + e a) = U (Y + e a + e a + e a, c) *
      U (Y + e c + e a + e a + e a, c) * U (Y + e c + e c + e a + e a + e a, c) := by
    unfold spine3; rw [q2, q1]
  have hs' : spine3 e U c Y = U (Y, c) * U (Y + e c, c) * U (Y + e c + e c, c) := rfl
  rw [hs, hs']
  calc spine3 e U a Y * (U (Y + e a + e a + e a, c) * U (Y + e c + e a + e a + e a, c) *
        U (Y + e c + e c + e a + e a + e a, c))
      = (spine3 e U a Y * U (Y + e a + e a + e a, c)) * U (Y + e c + e a + e a + e a, c) *
        U (Y + e c + e c + e a + e a + e a, c) := by simp only [mul_assoc]
    _ = U (Y, c) * (spine3 e U a (Y + e c) * U (Y + e c + e a + e a + e a, c)) *
        U (Y + e c + e c + e a + e a + e a, c) := by rw [← h0]; simp only [mul_assoc]
    _ = U (Y, c) * U (Y + e c, c) * (spine3 e U a (Y + e c + e c) *
        U (Y + e c + e c + e a + e a + e a, c)) := by rw [← h1]; simp only [mul_assoc]
    _ = U (Y, c) * U (Y + e c, c) * U (Y + e c + e c, c) * spine3 e U a (Y + e c + e c + e c) := by
        rw [← h2]; simp only [mul_assoc]

variable (φ : (Fin 4 → ℤ) →+ G) (x : G)

/-- One step and its shifted return around the spine. -/
theorem pv_step3 (hf : FlatQ (fun a => φ (ev a)) U) (μ : Fin 4) (l : Link) (hs : l.1 = 1 ∨ l.1 = -1) :
    pv φ x U [l] * spine3 (fun a => φ (ev a)) U μ (x + φ (tgt l)) *
        pv φ x U [flipL (shiftL (3 • ev μ) l)] =
      spine3 (fun a => φ (ev a)) U μ (x + φ (src l)) := by
  obtain ⟨s, z, n⟩ := l
  have hc := comm_spine3 hf μ n (x + φ z)
  have p3 : x + φ z + φ (ev μ) + φ (ev μ) + φ (ev μ) = x + φ (z + 3 • ev μ) := by
    simp only [map_add, map_nsmul]; abel
  rw [p3] at hc
  have pn : x + φ z + φ (ev n) = x + φ (z + ev n) := by rw [map_add, add_assoc]
  rw [pn] at hc
  have v1 : ∀ w : Fin 4 → ℤ, pv φ x U [((1 : ℤ), w, n)] = U (x + φ w, n) := fun w => by
    simp [pv, pathProd, stepVal, linkCast]
  have v2 : ∀ w : Fin 4 → ℤ, pv φ x U [((-1 : ℤ), w, n)] = star (U (x + φ w, n)) := fun w => by
    simp [pv, pathProd, stepVal, linkCast]
  rcases hs with h | h <;> simp only at h <;> subst h
  · rw [show tgt ((1 : ℤ), z, n) = z + ev n by simp [tgt], show src ((1 : ℤ), z, n) = z by simp [src],
      show flipL (shiftL (3 • ev μ) ((1 : ℤ), z, n)) = ((-1 : ℤ), z + 3 • ev μ, n) from rfl, v1, v2,
      hc, mul_assoc, hf.1, mul_one]
  · rw [show tgt ((-1 : ℤ), z, n) = z by simp [tgt], show src ((-1 : ℤ), z, n) = z + ev n by simp [src],
      show flipL (shiftL (3 • ev μ) ((-1 : ℤ), z, n)) = ((1 : ℤ), z + 3 • ev μ, n) by simp [flipL, shiftL],
      v1, v2, mul_assoc, ← hc, ← mul_assoc, star_mul_of_mul_star (hf.1 _), one_mul]

/-- **A chain and its shifted return around the spine.** -/
theorem pv_walk_spine3 (hf : FlatQ (fun a => φ (ev a)) U) (μ : Fin 4) {a c : Fin 4 → ℤ}
    {γ : List Link} (h : Walks a γ c) (hs : ∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) :
    pv φ x U γ * spine3 (fun a => φ (ev a)) U μ (x + φ c) *
        pv φ x U (revL (γ.map (shiftL (3 • ev μ)))) =
      spine3 (fun a => φ (ev a)) U μ (x + φ a) := by
  induction h with
  | nil y => simp [pv, pathProd, revL]
  | @cons l r y hw ih =>
    have ih' := ih fun l' hl' => hs l' (List.mem_cons_of_mem _ hl')
    have e1 : revL ((l :: r).map (shiftL (3 • ev μ))) =
        revL (r.map (shiftL (3 • ev μ))) ++ [flipL (shiftL (3 • ev μ) l)] := by
      simp [revL]
    have e2 : l :: r = [l] ++ r := rfl
    rw [e1, e2, pv_append, pv_append]
    calc pv φ x U [l] * pv φ x U r * spine3 (fun a => φ (ev a)) U μ (x + φ y) *
          (pv φ x U (revL (List.map (shiftL (3 • ev μ)) r)) * pv φ x U [flipL (shiftL (3 • ev μ) l)])
        = pv φ x U [l] * (pv φ x U r * spine3 (fun a => φ (ev a)) U μ (x + φ y) *
          pv φ x U (revL (List.map (shiftL (3 • ev μ)) r))) * pv φ x U [flipL (shiftL (3 • ev μ) l)] := by
          simp only [mul_assoc]
      _ = _ := by rw [ih']; exact pv_step3 φ x hf μ l (hs l List.mem_cons_self)

/-- **The product along every path of the family is the three-step spine** (flat field). -/
theorem pathProd_path_flat (hf : FlatQ (fun a => φ (ev a)) U) (μ : Fin 4) (d : Fin 4 → Fin 3)
    (o : Equiv.Perm (Fin 4)) :
    pathProd U ((path μ d o).map (linkCast φ x)) = spine3 (fun a => φ (ev a)) U μ x := by
  show pv φ x U (path μ d o) = _
  unfold path
  rw [pv_append, pv_append]
  have hline : pv φ x U (line μ (dvec d)) = spine3 (fun a => φ (ev a)) U μ (x + φ (dvec d)) := by
    simp [pv, line, pathProd, stepVal, linkCast, spine3, map_add, add_assoc, mul_assoc]
  rw [hline]
  have := pv_walk_spine3 φ x hf μ (contour_walks o d) (contour_sign o d)
  rw [map_zero, add_zero] at this
  exact this

end Abstract

section Box

variable (L : ℕ) [NeZero L]

theorem red3_ev (m : ℕ) (a : Fin 4) :
    red3 L m (ev a) = TorusRP.ev (3 ^ (m + 1) * L) a := by
  funext i
  by_cases h : i = a
  · subst h; simp [red3, ev, TorusRP.ev]
  · simp [red3, ev, TorusRP.ev, h]

theorem base3_add_ev (m : ℕ) (y : Site3 L m) (a c : Fin 4) :
    base3 L m (y + TorusRP.ev (3 ^ m * L) a, c) =
      base3 L m (y, c) + TorusRP.ev (3 ^ (m + 1) * L) a + TorusRP.ev (3 ^ (m + 1) * L) a +
        TorusRP.ev (3 ^ (m + 1) * L) a := by
  funext i
  simp only [base3, Pi.add_apply, map_add]
  by_cases h : i = a
  · subst h
    simp only [TorusRP.ev, Pi.single_eq_same, triple_one]
    ring
  · simp [TorusRP.ev, h]

variable {r₀ : ℝ} (hr : 0 < r₀)

/-- **For `r₀ ≤ 1` the block map sends a flat field to the three-step spines.** -/
theorem blockMap_flat_val (hr1 : r₀ ≤ 1) (m : ℕ) (U : Cfg (Lk3 L (m + 1)))
    (hf : FlatQ (TorusRP.ev (3 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr))) (b : Lk3 L m) :
    (blockMap r₀ hr (paths L) (wts L) m U b : ℍr) =
      spine3 (TorusRP.ev (3 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base3 L m b) := by
  have he : (fun a => red3 L m (ev a)) = TorusRP.ev (3 ^ (m + 1) * L) := funext (red3_ev L m)
  have hf' : FlatQ (fun a => red3 L m (ev a)) (fun ℓ => (U ℓ : ℍr)) := by rw [he]; exact hf
  have hpath : ∀ p : Idx, pathProd (fun ℓ => (U ℓ : ℍr)) (pathsIdx L m b p) =
      spine3 (TorusRP.ev (3 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base3 L m b) := by
    intro p
    obtain ⟨d, o⟩ := p
    rw [pathsIdx_eq]
    have := pathProd_path_flat (red3 L m) (base3 L m b) hf' b.2 d o
    rw [he] at this
    exact this
  rw [blockMap_eq L hr]
  simp only [hpath, Finset.sum_const, Finset.card_univ, card_idx]
  rw [show ((1944 : ℕ) • ((1 / 1944 : ℝ) • spine3 (TorusRP.ev (3 ^ (m + 1) * L))
      (fun ℓ => (U ℓ : ℍr)) b.2 (base3 L m b))) =
      spine3 (TorusRP.ev (3 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base3 L m b) by
    rw [← Nat.cast_smul_eq_nsmul ℝ, smul_smul]; norm_num]
  have hn := norm_eq_one_of_unit (spine3_unit hf b.2 (base3 L m b))
  rw [(retract_of_le hr (by rw [hn]; exact hr1)).1, hn, inv_one, one_smul]

/-- **Flat ⇒ flat under one step of the block map** (`r₀ ≤ 1`). -/
theorem blockMap_flatQ (hr1 : r₀ ≤ 1) (m : ℕ) (U : Cfg (Lk3 L (m + 1)))
    (hf : FlatQ (TorusRP.ev (3 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr))) :
    FlatQ (TorusRP.ev (3 ^ m * L)) (fun b => (blockMap r₀ hr (paths L) (wts L) m U b : ℍr)) := by
  refine ⟨fun b => ?_, fun y a c => ?_⟩
  · dsimp only
    rw [blockMap_flat_val L hr hr1 m U hf b]; exact spine3_unit hf _ _
  · dsimp only
    rw [blockMap_flat_val L hr hr1 m U hf, blockMap_flat_val L hr hr1 m U hf,
      blockMap_flat_val L hr hr1 m U hf, blockMap_flat_val L hr hr1 m U hf]
    rw [base3_add_ev, base3_add_ev]
    have hy : ∀ d : Fin 4, base3 L m (y, d) = base3 L m (y, a) := fun d => rfl
    rw [hy c]
    exact spine3_square hf a c _

/-- **Flat ⇒ flat under `down n m`** (`r₀ ≤ 1`, every `m ≤ n`). -/
theorem down_flatQ (hr1 : r₀ ≤ 1) (n : ℕ) : ∀ (k m : ℕ), n = m + k → ∀ U : Cfg (Lk3 L n),
    FlatQ (TorusRP.ev (3 ^ n * L)) (fun ℓ => (U ℓ : ℍr)) →
      FlatQ (TorusRP.ev (3 ^ m * L)) (fun b => (down r₀ hr (paths L) (wts L) n m U b : ℍr)) := by
  intro k
  induction k with
  | zero =>
    intro m h U hf
    obtain rfl : n = m := by omega
    rw [show down r₀ hr (paths L) (wts L) n n U = U from down_self _ _ _ _ _ U]
    exact hf
  | succ k ih =>
    intro m h U hf
    have hmn : m < n := by omega
    have := blockMap_flatQ L hr hr1 m _ (ih (m + 1) (by omega) U hf)
    simpa only [down_succ r₀ hr (paths L) (wts L) hmn U] using this

/-- **If every fine plaquette has `Re U_p = 1`, every coarse plaquette average is `1`** (`r₀ ≤ 1`). -/
theorem plaqAvg_down_of_flat (hr1 : r₀ ≤ 1) {n m : ℕ} (hmn : m ≤ n) (ω : Cfg (Lk3 L n))
    (h : ∀ p ∈ TorusRP.plaqs (3 ^ n * L), (TorusRP.hol (3 ^ n * L) ω p).re = 1) :
    TunedCoupling.plaqAvg (3 ^ m * L) (down r₀ hr (paths L) (wts L) n m ω) = 1 :=
  plaqAvg_eq_one_of_flatQ _ _ (down_flatQ L hr hr1 n (n - m) m (by omega) ω (flatQ_of_re _ ω h))

end Box

end Block3

#print axioms Block3.comm_spine3
#print axioms Block3.pathProd_path_flat
#print axioms Block3.blockMap_flatQ
#print axioms Block3.down_flatQ
#print axioms Block3.plaqAvg_down_of_flat
