import Block3.BoxReflV1
/-!
# Centred blocks of side 3: the cross-section between two blocks (on `ℤ⁴`)

Paper: (the sign flip of the links crossing the face between the block of `y`
and the block of `y + e_μ`). With the coarse site at `0` and the neighbour at `3 e_μ`, the links
crossing the face are the links of direction `μ` whose base has coordinate `μ` equal to `1`
(their transverse coordinates lie in `[-1,1]` by `path_support`).
* **`path_cross_count`**: every path of the coarse link of direction `μ` uses exactly one such
  link, exactly once (the step of the straight line through the face).
* `path_cross_other`: a path of a coarse link of direction `ν ≠ μ` uses links of direction `μ` only
  with base coordinate `μ` in `{0, -1}` (never `≡ 1 mod 3`).
* `path_dir_range`: a path of direction `μ` uses links of direction `μ` only with base coordinate
  `μ` in `[-1, 3]` (so the only base coordinate `≡ 1 mod 3` is `1`).
-/

namespace Block3

open WalkCast BoxWalk

theorem fwd_mem (a : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) :
    ∀ l ∈ fwd a z n, l.2.2 = n ∧ (l.2.1 = z ∨ l.2.1 = z - ev n) := by
  intro l hl
  unfold fwd at hl
  split_ifs at hl <;> simp at hl <;> subst hl <;> simp

theorem cpt_self (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) (k : Fin 4) :
    cpt o d k (o k) = 0 := by
  simp [cpt]

/-- Steps of the contour: in each direction `μ`, base coordinate `μ` is `0` or `-1`. -/
theorem contour_dir (o : Equiv.Perm (Fin 4)) (d : Fin 4 → Fin 3) :
    ∀ l ∈ contour o d, ∀ μ : Fin 4, l.2.2 = μ → (l.2.1 μ = 0 ∨ l.2.1 μ = -1) := by
  have key : ∀ k : Fin 4, ∀ l ∈ cstep o d k, ∀ μ : Fin 4, l.2.2 = μ →
      (l.2.1 μ = 0 ∨ l.2.1 μ = -1) := by
    intro k l hl μ hμ
    obtain ⟨hn, hz⟩ := fwd_mem _ _ _ l hl
    rw [hn] at hμ
    subst hμ
    rcases hz with h | h
    · left; rw [h, cpt_self]
    · right; rw [h, Pi.sub_apply, cpt_self]; simp [ev]
  intro l hl
  simp only [contour, List.mem_append] at hl
  rcases hl with ((h | h) | h) | h
  · exact key 0 l h
  · exact key 1 l h
  · exact key 2 l h
  · exact key 3 l h

/-- **Exactly one crossing**: every path of the coarse link of direction `μ` uses exactly once a
link of direction `μ` with base coordinate `μ` equal to `1`. -/
theorem path_cross_count (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    (path μ d o).countP (fun l => decide (l.2.2 = μ ∧ l.2.1 μ = 1)) = 1 := by
  unfold path
  rw [List.countP_append, List.countP_append]
  have h1 : (contour o d).countP (fun l => decide (l.2.2 = μ ∧ l.2.1 μ = 1)) = 0 := by
    refine List.countP_eq_zero.2 fun l hl => ?_
    simp only [decide_eq_true_eq, not_and]
    intro hd hc
    rcases contour_dir o d l hl μ hd with h | h <;> omega
  have h3 : (revL ((contour o d).map (shiftL (3 • ev μ)))).countP
      (fun l => decide (l.2.2 = μ ∧ l.2.1 μ = 1)) = 0 := by
    refine List.countP_eq_zero.2 fun l hl => ?_
    simp only [revL, List.mem_reverse, List.mem_map] at hl
    obtain ⟨l', ⟨l'', h'', rfl⟩, rfl⟩ := hl
    intro hdc
    obtain ⟨hd0, hc⟩ := of_decide_eq_true hdc
    have hd : l''.2.2 = μ := hd0
    have hc' : l''.2.1 μ + 3 = 1 := by simpa [ev, flipL, shiftL] using hc
    rcases contour_dir o d l'' h'' μ hd with h | h <;> omega
  have h2 : (line μ (dvec d)).countP (fun l => decide (l.2.2 = μ ∧ l.2.1 μ = 1)) = 1 := by
    rcases dv_cases (d μ) with h | h | h <;> simp [line, dvec, h, ev, List.countP_cons]
  rw [h1, h2, h3]

/-- A path of a coarse link of direction `ν ≠ μ` uses links of direction `μ` only with base
coordinate `μ` in `{0, -1}`. -/
theorem path_cross_other {ν μ : Fin 4} (hνμ : ν ≠ μ) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    ∀ l ∈ path ν d o, l.2.2 = μ → (l.2.1 μ = 0 ∨ l.2.1 μ = -1) := by
  intro l hl hd
  simp only [path, revL, line, List.mem_append, List.mem_reverse, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hl
  rcases hl with (h | h | h | h) | ⟨l', ⟨l'', h'', rfl⟩, rfl⟩
  · exact contour_dir o d l h μ hd
  · subst h; exact absurd hd hνμ
  · subst h; exact absurd hd hνμ
  · subst h; exact absurd hd hνμ
  · simp only [flipL, shiftL] at hd ⊢
    have e : (l''.2.1 + 3 • ev ν) μ = l''.2.1 μ := by
      simp [ev, Pi.single_apply, Ne.symm hνμ]
    rw [e]
    exact contour_dir o d l'' h'' μ hd

/-- A path of a coarse link of direction `μ` uses links of direction `μ` only with base
coordinate `μ` in `[-1, 3]`. -/
theorem path_dir_range (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    ∀ l ∈ path μ d o, l.2.2 = μ → (-1 ≤ l.2.1 μ ∧ l.2.1 μ ≤ 3) := by
  intro l hl hd
  have hb := dv_abs (d μ)
  simp only [path, revL, line, List.mem_append, List.mem_reverse, List.mem_map, List.mem_cons,
    List.not_mem_nil, or_false] at hl
  rcases hl with (h | h | h | h) | ⟨l', ⟨l'', h'', rfl⟩, rfl⟩
  · rcases contour_dir o d l h μ hd with h | h <;> omega
  · subst h; simp only [dvec]; omega
  · subst h; simp only [dvec, Pi.add_apply, ev, Pi.single_eq_same]; omega
  · subst h; simp only [dvec, Pi.add_apply, ev, Pi.single_eq_same]; omega
  · simp only [flipL, shiftL] at hd ⊢
    have e : (l''.2.1 + 3 • ev μ) μ = l''.2.1 μ + 3 := by simp [ev]
    rw [e]
    rcases contour_dir o d l'' h'' μ hd with h | h <;> omega

end Block3

#print axioms Block3.path_cross_count
#print axioms Block3.path_cross_other
#print axioms Block3.path_dir_range
