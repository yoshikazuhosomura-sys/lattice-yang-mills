import Block3.Sanity15V1
/-!
# Centred blocks of side 3: the remaining hypotheses of `chain_end_to_end_tuned3` can be met (trivially)

* `Y3_ge_neg_one`: `-1 ≤ Y3 m k β` for every `β`, so the field `hY` holds with `κ m = -1` (it then gives the bound
  `12 / yh m`, which carries no information when `yh m ≤ 12`);
* `hS_top`: the field `hS` holds with `S m = ⊤` (no information).
These show that the two fields are not empty statements; informative choices (`κ m > -1` at the levels `m ≠ m₀`,
finite `S m`) are not supplied here.
-/

set_option maxRecDepth 4000

namespace Block3

open MeasureTheory Filter TorusRP ChainBlockMap TunedCoupling
open scoped ENNReal

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem Y3_ge_neg_one (m k : ℕ) (β : ℝ) : -1 ≤ Y3 L hr m k β := by
  rw [← integral_ν3]
  have h := integral_mono (integrable_const (-1 : ℝ))
    (integrable_cont (3 ^ m * L) (μ := (ν3 L hr m k β : Measure _)) _ (continuous_plaqAvg _))
    (fun V => neg_one_le_plaqAvg (3 ^ m * L) V)
  simpa using h

theorem hY_neg_one (β : ℕ → ℝ) (m₀ : ℕ) :
    ∀ m, m ≠ m₀ → ∀ᶠ k in atTop, (fun _ : ℕ => (-1 : ℝ)) m ≤ Y3 L hr m k (β (m + k)) :=
  fun m _ => Eventually.of_forall fun k => Y3_ge_neg_one L hr m k _

theorem hS_top (β : ℕ → ℝ) {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m)) (pts : ∀ m, ι m → Finset (Pt m))
    (f : ∀ m, Pt m → Cfg (Lk3 L m) → ℝ) (θ : ℕ → ℝ) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (νP r₀ hr (paths L) (wts L) (wFam3 L β) n m : Measure (Cfg (Lk3 L m))) {ω | θ m < f m x ω} ≤
        (fun _ : ℕ => (⊤ : ℝ≥0∞)) m :=
  fun _ => Eventually.of_forall fun _ _ _ _ _ => le_top

end Block3

#print axioms Block3.Y3_ge_neg_one
#print axioms Block3.hY_neg_one
#print axioms Block3.hS_top
