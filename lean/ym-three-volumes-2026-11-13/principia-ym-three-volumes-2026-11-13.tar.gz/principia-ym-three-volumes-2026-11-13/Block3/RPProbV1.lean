import Block3.RPFinalV1
import Lattice.WilsonGapV2
/-!
# Centred blocks of side 3: reflection positivity of the push-forward of the normalised Wilson measure

Paper: **`rp_push_prob`**: `rp_push` for the probability measure
`TorusRP.wilsonProb N β` (paper A, the normalised Wilson measure): the normalisation is a
nonnegative multiple.
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap MeasureTheory

variable (L : ℕ) [NeZero L]

theorem rp_push_prob {r₀ : ℝ} (hr : 0 < r₀) {n m Mc : ℕ} (hmn : m ≤ n) (hMc : Mc ≤ 3 ^ m * L)
    (hN : 3 ^ n * L = 2 * (3 ^ (n - m) * Mc)) (β : ℝ)
    (F : Cfg (Lk3 L m) → ℝ) (hF : Measurable F) (CF : ℝ) (hFC : ∀ V, |F V| ≤ CF)
    (hFdep : ∀ V V' : Cfg (Lk3 L m), (∀ b, OpenPos L m Mc b → V b = V' b) → F V = F V') :
    0 ≤ ∫ V, F (reflCfg3 L m V) * F V
      ∂(((TorusRP.wilsonProb (3 ^ n * L) β : Measure _)).map (down r₀ hr (paths L) (wts L) n m)) := by
  rw [TorusRP.wilsonProb_toMeasure, Measure.map_smul, integral_smul_measure]
  exact mul_nonneg ENNReal.toReal_nonneg (rp_push L hr hmn hMc hN β F hF CF hFC hFdep)

end Block3

#print axioms Block3.rp_push_prob
