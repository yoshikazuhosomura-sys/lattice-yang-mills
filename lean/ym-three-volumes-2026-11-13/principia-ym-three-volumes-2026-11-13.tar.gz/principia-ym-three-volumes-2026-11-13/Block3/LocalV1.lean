import Block3.TransV1
/-!
# Centred blocks of side 3: locality of one block map

Paper: (condition (a), one level). **`blockMap_local`**: the coarse value on
`b = (y, μ)` depends only on the fine links `(3y + z, ν)` with `z` in the union of the block of `y`
and the block of `y + e_μ` (`InTwo μ z`: `z_i ∈ [-1,1]` for `i ≠ μ`, `z_μ ∈ [-1,4]`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

theorem pathProd_congr_steps {Λ : Type*} (U U' : Λ → ℍr) (γ : List (Λ × Bool))
    (h : ∀ s ∈ γ, U s.1 = U' s.1) : pathProd U γ = pathProd U' γ := by
  induction γ with
  | nil => rfl
  | cons s r ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih fun s' hs' => h s' (List.mem_cons_of_mem _ hs')]
    congr 1
    unfold stepVal
    rw [h s List.mem_cons_self]

/-- **Locality of the block map**: the value on `b = (y, μ)` depends only on the fine links based
at `3y + z`, `z` in the two blocks of the ends of `b`. -/
theorem blockMap_local {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U U' : Cfg (Lk3 L (m + 1))) (b : Lk3 L m)
    (h : ∀ z : Fin 4 → ℤ, InTwo b.2 z → ∀ ν : Fin 4,
      U (base3 L m b + red3 L m z, ν) = U' (base3 L m b + red3 L m z, ν)) :
    blockMap r₀ hr (paths L) (wts L) m U b = blockMap r₀ hr (paths L) (wts L) m U' b := by
  apply Subtype.ext
  rw [blockMap_eq L hr, blockMap_eq L hr]
  congr 1
  refine Finset.sum_congr rfl fun p _ => ?_
  obtain ⟨d, o⟩ := p
  congr 1
  rw [pathsIdx_eq]
  refine pathProd_congr_steps _ _ _ fun s hs => ?_
  obtain ⟨l, hl, rfl⟩ := List.mem_map.1 hs
  have hz := base_inTwo (path_sign _ _ _ l hl) (path_support _ _ _ l hl)
  show (U (base3 L m b + red3 L m l.2.1, l.2.2) : ℍr) = (U' (base3 L m b + red3 L m l.2.1, l.2.2) : ℍr)
  rw [h l.2.1 hz l.2.2]

end Block3

#print axioms Block3.blockMap_local
