import Block3.SignV1
/-!
# Sanity checks for the centred blocks of side 3

* the hypotheses of the theorems are only `L ≠ 0` (`NeZero L`) and `0 < r₀`: they hold for
  `L = 1`, `r₀ = 1/2` (instances below);
* the crossing set of every coarse link is not empty (the link from `3y + e_μ` to `3y + 2e_μ`),
  so `blockMap_flip` does flip something;
* the family is not trivial: it is non-empty, its weights are positive and sum to one, so each
  weight is at most one; the path of index `(d, o)` has length at least three (the straight line);
* the reflection is not the identity on the coarse values (it sends the link `(y, ν)`, `ν ≠ 0`,
  to the link at `Θy`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

variable (L : ℕ) [NeZero L]

theorem cross_nonempty (m : ℕ) (b : Lk3 L m) :
    Cross L m b (base3 L m b + red3 L m (ev b.2), b.2) :=
  ⟨rfl, ev b.2, by simp [ev], fun i hi => by simp [ev, Pi.single_apply, hi], rfl⟩

theorem wts_le_one (m : ℕ) (b : Lk3 L m) {γ : List (Lk3 L (m + 1) × Bool)}
    (hγ : γ ∈ paths L m b) : wts L m b γ ≤ 1 := by
  rw [← wts_sum L m b]
  exact Finset.single_le_sum (fun γ' _ => wts_nonneg L m b γ') hγ

theorem path_length (μ : Fin 4) (d : Fin 4 → Fin 3) (o : Equiv.Perm (Fin 4)) :
    3 ≤ (path μ d o).length := by
  simp [path, line]
  omega

/-- The level-`m` block map with `L = 1`, `r₀ = 1/2` satisfies the flip theorem (no hidden
hypothesis). -/
example (m : ℕ) (b b' : Lk3 1 m) (U : Cfg (Lk3 1 (m + 1))) :
    (blockMap (1 / 2) (by norm_num) (paths 1) (wts 1) m (flipCfg 1 m b U) b' : Quaternion ℝ) =
      if b' = b then -(blockMap (1 / 2) (by norm_num) (paths 1) (wts 1) m U b' : Quaternion ℝ)
      else (blockMap (1 / 2) (by norm_num) (paths 1) (wts 1) m U b' : Quaternion ℝ) :=
  blockMap_flip 1 (by norm_num) m b U b'

example (n m : ℕ) (h : m ≤ n) (U : Cfg (Lk3 1 n)) :
    down (1 / 2) (by norm_num) (paths 1) (wts 1) n m (reflCfg3 1 n U) =
      reflCfg3 1 m (down (1 / 2) (by norm_num) (paths 1) (wts 1) n m U) :=
  down_refl 1 (by norm_num) h U

end Block3

#print axioms Block3.cross_nonempty
#print axioms Block3.wts_le_one
#print axioms Block3.path_length
#print axioms Block3.down_refl
#print axioms Block3.blockMap_flip
#print axioms Block3.blockMap_refl_cfg
#print axioms Block3.paths_support
#print axioms Block3.wts_sum
