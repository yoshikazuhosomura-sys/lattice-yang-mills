import Block3.LocalKV1
/-!
# Centred blocks of side 3: the reflection integral of a push-forward

Paper: (the one-line proof of the positivity of the push-forward, step (b)).
For every measure `μ` on the fine configurations and every measurable `F` on the coarse ones,
**`push_refl_integral`**: `∫ F(Θ_m V) F(V) d(down_* μ)(V) = ∫ H(Θ_n ω) H(ω) dμ(ω)` with
`H = F ∘ down n m` (the site reflection `x₀ ↦ -x₀` at both levels). With `down_local` (the
support of `H`) this reduces the positivity of the push-forward to the positivity of `μ` on the
functions of the fine links in the image region; that last step (matching the classes of the
fine reflection-positivity theorem) is not done here.
-/

set_option maxRecDepth 4000

namespace Block3

open ChainBlockMap MeasureTheory

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

theorem continuous_reflCfg3 (m : ℕ) : Continuous (reflCfg3 L m) := by
  refine continuous_pi fun ℓ => ?_
  refine continuous_induced_rng.2 ?_
  show Continuous fun U : Cfg (Lk3 L m) => reflV3 L m (fun ℓ' => (U ℓ' : ℍr)) ℓ
  unfold reflV3
  split_ifs
  · exact continuous_star.comp (continuous_subtype_val.comp (continuous_apply _))
  · exact continuous_subtype_val.comp (continuous_apply _)

/-- **The reflection integral of the push-forward is the reflection integral of `F ∘ down`.** -/
theorem push_refl_integral {r₀ : ℝ} (hr : 0 < r₀) {n m : ℕ} (hmn : m ≤ n)
    (μ : Measure (Cfg (Lk3 L n))) (F : Cfg (Lk3 L m) → ℝ) (hF : Measurable F) :
    ∫ V, F (reflCfg3 L m V) * F V ∂(μ.map (down r₀ hr (paths L) (wts L) n m)) =
      ∫ ω, F (down r₀ hr (paths L) (wts L) n m (reflCfg3 L n ω)) *
        F (down r₀ hr (paths L) (wts L) n m ω) ∂μ := by
  have hd := continuous_down r₀ hr (paths L) (wts L) n m
  have hm : AEStronglyMeasurable (fun V => F (reflCfg3 L m V) * F V)
      (μ.map (down r₀ hr (paths L) (wts L) n m)) :=
    ((hF.comp (continuous_reflCfg3 L m).measurable).mul hF).aestronglyMeasurable
  rw [integral_map hd.measurable.aemeasurable hm]
  simp only [down_refl L hr hmn]

end Block3

#print axioms Block3.push_refl_integral
