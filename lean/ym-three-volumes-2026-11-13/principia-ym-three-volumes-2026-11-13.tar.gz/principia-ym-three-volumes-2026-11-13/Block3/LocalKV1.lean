import Block3.LocalV1
/-!
# Centred blocks of side 3: the support of the composed block maps (every number of levels)

Paper: (condition (a) at every level). Write the coarse site of level `m` as
the image of an integer vector `Y`, and the sites of level `n = m + k` as `3^k Y + z`.
`InReg k μ z`: `z_i ∈ [-h, h]` for `i ≠ μ` and `z_μ ∈ [-h, 3^k + h]`, `h = (3^k - 1)/2` (written
`-(3^k - 1) ≤ 2 z_i ≤ (3^k - 1) + 2·3^k·[i = μ]`): the union of the level-`n` blocks of the two ends
of the coarse link (and nothing else).
* `blockMap_local2`: one level, with both ends of every fine link in the two blocks.
* `reg_step`: the regions compose (`3^k w + z`).
* **`down_local`**: the value of `down n m U` on the coarse link `(Y, μ)` depends only on the fine
  links of level `n` whose two ends lie in `3^k Y + InReg k μ` (every `k`, every side `L`).
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

/-- The level-`n` region of a coarse link of direction `μ`, `k = n - m` levels below. -/
def InReg (k : ℕ) (μ : Fin 4) (z : Fin 4 → ℤ) : Prop :=
  ∀ i, -((3 : ℤ) ^ k - 1) ≤ 2 * z i ∧ 2 * z i ≤ ((3 : ℤ) ^ k - 1) + 2 * (3 : ℤ) ^ k * ev μ i

theorem ev_apply (μ i : Fin 4) : ev μ i = if i = μ then 1 else 0 := by
  simp [ev, Pi.single_apply]

/-- Both ends of every step of a path lie in the two blocks. -/
theorem step_ends_inTwo {μ : Fin 4} {l : Link} (hs : l.1 = 1 ∨ l.1 = -1)
    (h : InTwo μ (src l) ∧ InTwo μ (tgt l)) : InTwo μ l.2.1 ∧ InTwo μ (l.2.1 + ev l.2.2) := by
  rcases hs with hs | hs
  · have h1 := h.1; have h2 := h.2
    simp only [src, tgt, hs, if_true] at h1 h2
    exact ⟨h1, h2⟩
  · have h1 := h.1; have h2 := h.2
    simp only [src, tgt, hs, if_neg (by decide : (-1 : ℤ) ≠ 1)] at h1 h2
    exact ⟨h2, h1⟩

/-- The regions compose: a step `w` of the two blocks of `μ` (both ends), then a region of
direction `ν` (the direction of the step) `k` levels below, lie in the region of `μ`, `k + 1`
levels below. -/
theorem reg_step (k : ℕ) {μ ν : Fin 4} {w z : Fin 4 → ℤ} (hw : InTwo μ w) (hw' : InTwo μ (w + ev ν))
    (hz : InReg k ν z) : InReg (k + 1) μ ((3 : ℤ) ^ k • w + z) := by
  intro i
  have hP : (1 : ℤ) ≤ 3 ^ k := one_le_pow₀ (by norm_num)
  rw [pow_succ]
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  have hzi := hz i
  generalize hPd : (3 : ℤ) ^ k = P at hP hzi ⊢
  rw [ev_apply] at hzi ⊢
  have hwi : (i ≠ μ → -1 ≤ w i ∧ w i ≤ 1) ∧ (i = μ → -1 ≤ w i ∧ w i ≤ 4) := by
    refine ⟨fun hi => hw.1 i hi, fun hi => ?_⟩
    subst hi; exact hw.2
  have hwi' : (i ≠ μ → -1 ≤ w i + ev ν i ∧ w i + ev ν i ≤ 1) ∧
      (i = μ → -1 ≤ w i + ev ν i ∧ w i + ev ν i ≤ 4) := by
    refine ⟨fun hi => hw'.1 i hi, fun hi => ?_⟩
    subst hi; exact hw'.2
  rw [ev_apply ν] at hwi'
  by_cases hiμ : i = μ
  · subst hiμ
    obtain ⟨a1, a2⟩ := hwi.2 rfl
    obtain ⟨b1, b2⟩ := hwi'.2 rfl
    simp only [eq_self_iff_true, if_true, ↓reduceIte] at hzi b1 b2 ⊢
    by_cases hνμ : i = ν
    · subst hνμ
      simp only [eq_self_iff_true, if_true, ↓reduceIte] at hzi b1 b2
      generalize w i = a at a1 a2 b1 b2 ⊢
      interval_cases a <;> omega
    · simp only [hνμ, if_false, ↓reduceIte] at hzi b1 b2
      generalize w i = a at a1 a2 b1 b2 ⊢
      interval_cases a <;> omega
  · obtain ⟨a1, a2⟩ := hwi.1 hiμ
    obtain ⟨b1, b2⟩ := hwi'.1 hiμ
    simp only [hiμ, if_false, ↓reduceIte] at ⊢
    by_cases hiν : i = ν
    · subst hiν
      simp only [eq_self_iff_true, if_true, ↓reduceIte] at hzi b1 b2
      generalize w i = a at a1 a2 b1 b2 ⊢
      interval_cases a <;> omega
    · simp only [hiν, if_false, ↓reduceIte] at hzi b1 b2
      generalize w i = a at a1 a2 b1 b2 ⊢
      interval_cases a <;> omega

variable (L : ℕ) [NeZero L]

/-- One level, both ends of every fine link in the two blocks. -/
theorem blockMap_local2 {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U U' : Cfg (Lk3 L (m + 1))) (b : Lk3 L m)
    (h : ∀ w : Fin 4 → ℤ, ∀ ν : Fin 4, InTwo b.2 w → InTwo b.2 (w + ev ν) →
      U (base3 L m b + red3 L m w, ν) = U' (base3 L m b + red3 L m w, ν)) :
    blockMap r₀ hr (paths L) (wts L) m U b = blockMap r₀ hr (paths L) (wts L) m U' b := by
  apply Subtype.ext
  rw [blockMap_eq L hr, blockMap_eq L hr]
  congr 1
  refine Finset.sum_congr rfl fun p _ => ?_
  obtain ⟨d, o⟩ := p
  congr 1
  rw [pathsIdx_eq]
  refine pathProd_congr_steps _ _ _ fun s hs => ?_
  obtain ⟨l, hl, rfl⟩ := List.mem_map.1 hs
  have hz := step_ends_inTwo (path_sign _ _ _ l hl) (path_support _ _ _ l hl)
  show (U (base3 L m b + red3 L m l.2.1, l.2.2) : ℍr) = (U' (base3 L m b + red3 L m l.2.1, l.2.2) : ℍr)
  rw [h l.2.1 l.2.2 hz.1 hz.2]

theorem base3_cast (m : ℕ) (Y w : Fin 4 → ℤ) (μ : Fin 4) :
    base3 L m ((fun i => ((Y i : ℤ) : ZMod (3 ^ m * L))), μ) + red3 L m w =
      fun i => ((3 * Y i + w i : ℤ) : ZMod (3 ^ (m + 1) * L)) := by
  funext i
  simp [base3, red3, triple_intCast]

/-- **Support of the composed block maps.** -/
theorem down_local {r₀ : ℝ} (hr : 0 < r₀) (n : ℕ) : ∀ (k m : ℕ), n = m + k →
    ∀ (U U' : Cfg (Lk3 L n)) (Y : Fin 4 → ℤ) (μ : Fin 4),
    (∀ z : Fin 4 → ℤ, ∀ ν : Fin 4, InReg k μ z → InReg k μ (z + ev ν) →
      U ((fun i => (((3 : ℤ) ^ k * Y i + z i : ℤ) : ZMod (3 ^ n * L))), ν) =
        U' ((fun i => (((3 : ℤ) ^ k * Y i + z i : ℤ) : ZMod (3 ^ n * L))), ν)) →
    down r₀ hr (paths L) (wts L) n m U ((fun i => ((Y i : ℤ) : ZMod (3 ^ m * L))), μ) =
      down r₀ hr (paths L) (wts L) n m U' ((fun i => ((Y i : ℤ) : ZMod (3 ^ m * L))), μ) := by
  intro k
  induction k with
  | zero =>
    intro m hn U U' Y μ h
    simp only [add_zero] at hn
    subst hn
    rw [down_self, down_self]
    have h0 := h 0 μ (by intro i; rw [ev_apply]; split_ifs <;> simp)
      (by intro i; simp only [zero_add]; rw [ev_apply]; split_ifs <;> simp)
    simpa using h0
  | succ k ih =>
    intro m hn U U' Y μ h
    have hmn : m < n := by omega
    rw [down_succ r₀ hr (paths L) (wts L) hmn, down_succ r₀ hr (paths L) (wts L) hmn]
    apply blockMap_local2 L hr
    intro w ν hw hw'
    rw [base3_cast]
    exact ih (m + 1) (by omega) U U' (fun i => 3 * Y i + w i) ν (fun z ν' hz hz' => by
      have e : (fun i => (((3 : ℤ) ^ k * (3 * Y i + w i) + z i : ℤ) : ZMod (3 ^ n * L))) =
          (fun i => (((3 : ℤ) ^ (k + 1) * Y i + ((3 : ℤ) ^ k • w + z) i : ℤ) : ZMod (3 ^ n * L))) := by
        funext i
        congr 1
        simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
        ring
      rw [e]
      refine h _ ν' (reg_step k hw hw' hz) ?_
      have := reg_step k hw hw' hz'
      rwa [← add_assoc] at this)

end Block3

#print axioms Block3.reg_step
#print axioms Block3.down_local
