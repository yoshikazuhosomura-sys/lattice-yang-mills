import Block3.SanityV1
/-!
# Centred blocks of side 3: coarse translations and the reflection through a block boundary

Paper: (lemma B for the boundary reflection, one level). The coarse
translation by `v` is the fine translation by `3v` (`tripleV`).
* **`blockMap_trans`**: `blockMap ∘ T_{3v} = T_v ∘ blockMap` (every coarse `v`, every level).
* **`blockMap_reflB`**: with `ΘB := T_{e₀} ∘ Θ` on the coarse box (`y₀ ↦ -1 - y₀`, the plane
  between the coarse times `-1` and `0`) and `T_{3e₀} ∘ Θ` on the fine box (`x₀ ↦ -3 - x₀`, the
  common face of the blocks centred at `-3` and `0`), the block map commutes with the boundary
  reflection.
-/

set_option maxRecDepth 4000

namespace Block3

open WalkCast BoxWalk ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

/-- Fine image `3v` of a coarse translation vector. -/
def tripleV (m : ℕ) (v : Site3 L m) : Site3 L (m + 1) := fun i => triple L m (v i)

/-- Translation of a configuration by `v` (the value on `(x, ν)` is the old value on `(x + v, ν)`). -/
def transCfg (m : ℕ) (v : Site3 L m) (U : Cfg (Lk3 L m)) : Cfg (Lk3 L m) :=
  fun ℓ => U (ℓ.1 + v, ℓ.2)

theorem base3_add (m : ℕ) (y v : Site3 L m) (ν : Fin 4) :
    base3 L m (y + v, ν) = base3 L m (y, ν) + tripleV L m v := by
  funext i; simp [base3, tripleV, map_add]

theorem pathProd_trans (m : ℕ) (U : Lk3 L (m + 1) → ℍr) (w x : Site3 L (m + 1)) (γ : List Link) :
    pathProd (fun ℓ => U (ℓ.1 + w, ℓ.2)) (γ.map (linkCast (red3 L m) x)) =
      pathProd U (γ.map (linkCast (red3 L m) (x + w))) := by
  induction γ with
  | nil => rfl
  | cons l rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih]
    congr 1
    unfold stepVal linkCast
    simp only
    rw [show x + (red3 L m) l.2.1 + w = x + w + (red3 L m) l.2.1 by abel]

theorem blockMap_trans {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (v : Site3 L m) (U : Cfg (Lk3 L (m + 1))) :
    blockMap r₀ hr (paths L) (wts L) m (transCfg L (m + 1) (tripleV L m v) U) =
      transCfg L m v (blockMap r₀ hr (paths L) (wts L) m U) := by
  funext b
  apply Subtype.ext
  obtain ⟨y, ν⟩ := b
  show (blockMap r₀ hr (paths L) (wts L) m (transCfg L (m + 1) (tripleV L m v) U) (y, ν) : ℍr) =
    (blockMap r₀ hr (paths L) (wts L) m U (y + v, ν) : ℍr)
  rw [blockMap_eq L hr, blockMap_eq L hr]
  congr 1
  refine Finset.sum_congr rfl fun p _ => ?_
  obtain ⟨d, o⟩ := p
  congr 1
  rw [pathsIdx_eq, pathsIdx_eq, base3_add]
  exact pathProd_trans L m (fun ℓ => (U ℓ : ℍr)) _ _ _

/-- **The block map commutes with the reflection through the block boundary** (one level):
`ΘB_m := T_{e₀} ∘ Θ_m`, fine `T_{3e₀} ∘ Θ_{m+1}`. -/
theorem blockMap_reflB {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (Lk3 L (m + 1))) :
    blockMap r₀ hr (paths L) (wts L) m
        (transCfg L (m + 1) (tripleV L m (Pi.single 0 1)) (reflCfg3 L (m + 1) U)) =
      transCfg L m (Pi.single 0 1) (reflCfg3 L m (blockMap r₀ hr (paths L) (wts L) m U)) := by
  rw [blockMap_trans L hr, blockMap_refl_cfg L hr]

end Block3

#print axioms Block3.blockMap_trans
#print axioms Block3.blockMap_reflB
