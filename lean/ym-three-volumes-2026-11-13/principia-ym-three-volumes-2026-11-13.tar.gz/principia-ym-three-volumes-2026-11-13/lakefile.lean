import Lake
open Lake DSL

/-- `ympremisefirst` — the Lean declarations cited by the Yang–Mills textbook (three volumes, 2026-11-13 edition).
    The package and library names are the same as in the earlier bundle `principia-ym-premise-first-2026-11-13`.
    Builds with Lean 4 v4.33.1 and the Mathlib tag below. -/
package ympremisefirst where
  leanOptions := #[
    ⟨`relaxedAutoImplicit, false⟩
  ]

-- Mathlib tag `v4.33.1`; `lake-manifest.json` pins the commit of that tag
-- (0df444a360eaa60ab8c11dca51a86af692955474).
require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @ "v4.33.1"

@[default_target]
lean_lib YMPremiseFirst where
  roots := #[`Area, `Band, `Block3, `Blocks, `Box, `BoxWalk, `Bridge, `Chain, `Covering, `Factor, `Fermion, `FermionLane, `Five, `FoldChess, `FreeOS, `Gauge, `Infvol, `Kernel, `Lam, `Lattice, `Lift, `Linz, `Peierls, `Plane, `PolyT, `Push, `PushRare, `RealSpace, `SkewOrbit, `Spec, `Sweep, `T1, `T10, `Tilt, `Tuned, `Tuning, `UVChain, `Uniform, `VortexCert, `Wilson]
  globs := #[.submodules `Area, .submodules `Band, .submodules `Block3, .submodules `Blocks, .submodules `Box, .submodules `BoxWalk, .submodules `Bridge, .submodules `Chain, .submodules `Covering, .submodules `Factor, .submodules `Fermion, .submodules `FermionLane, .submodules `Five, .submodules `FoldChess, .submodules `FreeOS, .submodules `Gauge, .submodules `Infvol, .submodules `Kernel, .submodules `Lam, .submodules `Lattice, .submodules `Lift, .submodules `Linz, .submodules `Peierls, .submodules `Plane, .submodules `PolyT, .submodules `Push, .submodules `PushRare, .submodules `RealSpace, .submodules `SkewOrbit, .submodules `Spec, .submodules `Sweep, .submodules `T1, .submodules `T10, .submodules `Tilt, .submodules `Tuned, .submodules `Tuning, .submodules `UVChain, .submodules `Uniform, .submodules `VortexCert, .submodules `Wilson]
