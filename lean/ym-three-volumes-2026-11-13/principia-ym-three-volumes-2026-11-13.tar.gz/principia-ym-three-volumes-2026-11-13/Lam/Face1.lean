-- ===== Lam/Face1 = an earlier file verbatim, except lines 604..624 (FaceTorus.torus_lambda_le, word for word the same theorem as in T1.T1hArith1) and line 641 (its #print axioms) dropped, so that both can be imported =====
import Mathlib

/-! # A6-L1: `Λ ≤ 2C₊/c` from the bracket of the stage covariance (finite-dimensional part)

At a Bloch momentum `q`, with
`q̂_μ = 1 − e^{iq_μ}` (any complex numbers here), the face map `d̂ : ℂ⁴ → ℂ⁶`,
`(d̂ x)_{μν} = q̂_μ x_ν − q̂_ν x_μ` (`μ < ν`), and `ω = Σ|q̂_μ|²`:
* `dmat_q`: `d̂ q̂ = 0` (`dd = 0`).
* `dmat_norm_sq`: `‖d̂ x‖² + |Σ q̂_μ x̄_μ|² = ω‖x‖²` (complex Lagrange), so `‖d̂ x‖² ≤ ω‖x‖²`.
* `dmat_adj_hs`: `Σ_p ‖d̂† e_p‖² = 3ω` (the trace of `d̂d̂†`; each row has `|q̂_μ|² + |q̂_ν|²`).
* abstract: from `G ≤ (C₊/ω)` and `G ≥ (c/ω)` on `q̂^⊥` (the bracket `cP/ω ≼ G ≼ C₊P/ω`),
  `λ_max(d̂Gd̂†) ≤ C₊` (`face_upper`) and `(1/6) tr(d̂Gd̂†) ≥ c/2` (`face_diag_avg`).
Hence, if `Cov F` is the direct sum over the Bloch momenta of `d̂Ĝd̂†` (paper, the hypothesis of
translation invariance), `λ_max(Cov F) ≤ C₊` and the diagonal (one value by the hypercubic
symmetry, paper) is `≥ c/2`, so `Λ ≤ 2C₊/c`. -/

noncomputable section

namespace FaceBracket

open Finset
open scoped InnerProductSpace ComplexConjugate Matrix
open Matrix

section Abstract

variable {𝕜 E F : Type*} [RCLike 𝕜] [NormedAddCommGroup E] [InnerProductSpace 𝕜 E]
  [FiniteDimensional 𝕜 E] [NormedAddCommGroup F] [InnerProductSpace 𝕜 F] [FiniteDimensional 𝕜 F]

/-- `‖D†y‖² ≤ ω‖y‖²` from `‖Dx‖² ≤ ω‖x‖²`. -/
theorem adj_norm_sq_le (D : E →ₗ[𝕜] F) {ω : ℝ} (hω : 0 ≤ ω)
    (hD : ∀ x, ‖D x‖ ^ 2 ≤ ω * ‖x‖ ^ 2) (y : F) :
    ‖LinearMap.adjoint D y‖ ^ 2 ≤ ω * ‖y‖ ^ 2 := by
  set z := LinearMap.adjoint D y
  have h1 : ‖z‖ ^ 2 = RCLike.re ⟪y, D z⟫_𝕜 := by
    rw [← inner_self_eq_norm_sq (𝕜 := 𝕜)]
    exact congrArg RCLike.re (LinearMap.adjoint_inner_left D z y)
  have h2 : RCLike.re ⟪y, D z⟫_𝕜 ≤ ‖y‖ * ‖D z‖ := re_inner_le_norm _ _
  have h3 := hD z
  have hy := norm_nonneg y
  have hz := norm_nonneg z
  have hDz := norm_nonneg (D z)
  have h4 : (‖z‖ ^ 2) ^ 2 ≤ ‖y‖ ^ 2 * (ω * ‖z‖ ^ 2) := by
    have : (‖z‖ ^ 2) ^ 2 ≤ (‖y‖ * ‖D z‖) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (h1 ▸ h2) 2
    calc (‖z‖ ^ 2) ^ 2 ≤ (‖y‖ * ‖D z‖) ^ 2 := this
      _ = ‖y‖ ^ 2 * ‖D z‖ ^ 2 := by ring
      _ ≤ ‖y‖ ^ 2 * (ω * ‖z‖ ^ 2) := mul_le_mul_of_nonneg_left h3 (by positivity)
  rcases eq_or_lt_of_le (sq_nonneg ‖z‖) with h0 | hpos
  · rw [← h0]; positivity
  · nlinarith

/-- **`λ_max(D G D†) ≤ C₊`** from `re⟨z, Gz⟩ ≤ (C₊/ω)‖z‖²` and `‖D‖² ≤ ω`. -/
theorem face_upper (D : E →ₗ[𝕜] F) (G : E →ₗ[𝕜] E) {ω Cp : ℝ} (hω : 0 < ω) (hC : 0 ≤ Cp)
    (hD : ∀ x, ‖D x‖ ^ 2 ≤ ω * ‖x‖ ^ 2)
    (hG : ∀ z, RCLike.re ⟪z, G z⟫_𝕜 ≤ Cp / ω * ‖z‖ ^ 2) (y : F) :
    RCLike.re ⟪y, D (G (LinearMap.adjoint D y))⟫_𝕜 ≤ Cp * ‖y‖ ^ 2 := by
  rw [← LinearMap.adjoint_inner_left D (G (LinearMap.adjoint D y)) y]
  have h1 := hG (LinearMap.adjoint D y)
  have h2 := adj_norm_sq_le D hω.le hD y
  have h3 : Cp / ω * ‖LinearMap.adjoint D y‖ ^ 2 ≤ Cp / ω * (ω * ‖y‖ ^ 2) :=
    mul_le_mul_of_nonneg_left h2 (div_nonneg hC hω.le)
  have e : Cp / ω * (ω * ‖y‖ ^ 2) = Cp * ‖y‖ ^ 2 := by field_simp
  linarith

/-- **`(1/6) Σ_p re⟨b_p, D G D† b_p⟩ ≥ c/2`** from the lower side on `q^⊥`, `D q = 0` and
`Σ_p ‖D† b_p‖² = 3ω`. -/
theorem face_diag_avg (D : E →ₗ[𝕜] F) (G : E →ₗ[𝕜] E) (qv : E) {ω c : ℝ} (hω : 0 < ω)
    (hDq : D qv = 0)
    (hG : ∀ z, ⟪z, qv⟫_𝕜 = 0 → c / ω * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, G z⟫_𝕜)
    (b : Fin 6 → F) (hHS : ∑ p, ‖LinearMap.adjoint D (b p)‖ ^ 2 = 3 * ω) :
    c / 2 ≤ (1 / 6) * ∑ p, RCLike.re ⟪b p, D (G (LinearMap.adjoint D (b p)))⟫_𝕜 := by
  have hp : ∀ p, c / ω * ‖LinearMap.adjoint D (b p)‖ ^ 2 ≤
      RCLike.re ⟪b p, D (G (LinearMap.adjoint D (b p)))⟫_𝕜 := by
    intro p
    rw [← LinearMap.adjoint_inner_left]
    apply hG
    rw [LinearMap.adjoint_inner_left, hDq, inner_zero_right]
  have hs := Finset.sum_le_sum fun p (_ : p ∈ univ) => hp p
  rw [← Finset.mul_sum, hHS] at hs
  have e : c / ω * (3 * ω) = 3 * c := by field_simp
  linarith

end Abstract

section Concrete

/-- The face map `d̂`: rows `01, 02, 03, 12, 13, 23`. -/
def dmat (qh : Fin 4 → ℂ) : Matrix (Fin 6) (Fin 4) ℂ :=
  Matrix.of ![![-qh 1, qh 0, 0, 0], ![-qh 2, 0, qh 0, 0], ![-qh 3, 0, 0, qh 0],
    ![0, -qh 2, qh 1, 0], ![0, -qh 3, 0, qh 1], ![0, 0, -qh 3, qh 2]]

/-- `ω = Σ |q̂_μ|²`. -/
def omg (qh : Fin 4 → ℂ) : ℝ := ∑ μ, ‖qh μ‖ ^ 2

theorem dmat_q (qh : Fin 4 → ℂ) : dmat qh *ᵥ qh = 0 := by
  funext p
  fin_cases p <;> simp [dmat, Matrix.mulVec, dotProduct, Fin.sum_univ_four] <;> ring

/-- The real Lagrange identity behind `‖d̂x‖² ≤ ω‖x‖²` (`q̂ = a + ib`, `x = u + iv`). -/
theorem lag4 (a b u v : Fin 4 → ℝ) :
    ((a 0 * u 1 - b 0 * v 1 - (a 1 * u 0 - b 1 * v 0)) ^ 2 +
        (a 0 * v 1 + b 0 * u 1 - (a 1 * v 0 + b 1 * u 0)) ^ 2) +
      ((a 0 * u 2 - b 0 * v 2 - (a 2 * u 0 - b 2 * v 0)) ^ 2 +
        (a 0 * v 2 + b 0 * u 2 - (a 2 * v 0 + b 2 * u 0)) ^ 2) +
      ((a 0 * u 3 - b 0 * v 3 - (a 3 * u 0 - b 3 * v 0)) ^ 2 +
        (a 0 * v 3 + b 0 * u 3 - (a 3 * v 0 + b 3 * u 0)) ^ 2) +
      ((a 1 * u 2 - b 1 * v 2 - (a 2 * u 1 - b 2 * v 1)) ^ 2 +
        (a 1 * v 2 + b 1 * u 2 - (a 2 * v 1 + b 2 * u 1)) ^ 2) +
      ((a 1 * u 3 - b 1 * v 3 - (a 3 * u 1 - b 3 * v 1)) ^ 2 +
        (a 1 * v 3 + b 1 * u 3 - (a 3 * v 1 + b 3 * u 1)) ^ 2) +
      ((a 2 * u 3 - b 2 * v 3 - (a 3 * u 2 - b 3 * v 2)) ^ 2 +
        (a 2 * v 3 + b 2 * u 3 - (a 3 * v 2 + b 3 * u 2)) ^ 2) +
      (a 0 * u 0 + b 0 * v 0 + a 1 * u 1 + b 1 * v 1 + a 2 * u 2 + b 2 * v 2 + a 3 * u 3 +
        b 3 * v 3) ^ 2 +
      (b 0 * u 0 - a 0 * v 0 + b 1 * u 1 - a 1 * v 1 + b 2 * u 2 - a 2 * v 2 + b 3 * u 3 -
        a 3 * v 3) ^ 2 =
    (a 0 ^ 2 + b 0 ^ 2 + (a 1 ^ 2 + b 1 ^ 2) + (a 2 ^ 2 + b 2 ^ 2) + (a 3 ^ 2 + b 3 ^ 2)) *
      (u 0 ^ 2 + v 0 ^ 2 + (u 1 ^ 2 + v 1 ^ 2) + (u 2 ^ 2 + v 2 ^ 2) + (u 3 ^ 2 + v 3 ^ 2)) := by
  ring

theorem dmat_mulVec (qh y : Fin 4 → ℂ) :
    dmat qh *ᵥ y = ![qh 0 * y 1 - qh 1 * y 0, qh 0 * y 2 - qh 2 * y 0, qh 0 * y 3 - qh 3 * y 0,
      qh 1 * y 2 - qh 2 * y 1, qh 1 * y 3 - qh 3 * y 1, qh 2 * y 3 - qh 3 * y 2] := by
  funext p
  fin_cases p <;> simp [dmat, Matrix.mulVec, dotProduct, Fin.sum_univ_four] <;> ring

theorem sqn (z : ℂ) : ‖z‖ ^ 2 = z.re ^ 2 + z.im ^ 2 := by
  rw [Complex.sq_norm, Complex.normSq_apply]; ring

set_option maxHeartbeats 1000000 in
theorem dmat_norm_sq (qh : Fin 4 → ℂ) (x : EuclideanSpace ℂ (Fin 4)) :
    ‖Matrix.toEuclideanLin (dmat qh) x‖ ^ 2 ≤ omg qh * ‖x‖ ^ 2 := by
  rw [EuclideanSpace.norm_sq_eq, EuclideanSpace.norm_sq_eq]
  show ∑ p, ‖(dmat qh *ᵥ WithLp.ofLp x) p‖ ^ 2 ≤ omg qh * ∑ i, ‖x i‖ ^ 2
  rw [dmat_mulVec]
  unfold omg
  simp only [Fin.sum_univ_succ, Fin.sum_univ_zero, Matrix.cons_val_zero, Matrix.cons_val_succ,
    Fin.succ_zero_eq_one, Fin.succ_one_eq_two, sqn, Complex.sub_re, Complex.sub_im,
    Complex.mul_re, Complex.mul_im, add_zero, Fin.reduceSucc]
  have key := lag4 (fun i => (qh i).re) (fun i => (qh i).im) (fun i => (x i).re)
    (fun i => (x i).im)
  simp only at key
  have h1 := sq_nonneg ((qh 0).re * (x 0).re + (qh 0).im * (x 0).im + (qh 1).re * (x 1).re +
    (qh 1).im * (x 1).im + (qh 2).re * (x 2).re + (qh 2).im * (x 2).im + (qh 3).re * (x 3).re +
    (qh 3).im * (x 3).im)
  have h2 := sq_nonneg ((qh 0).im * (x 0).re - (qh 0).re * (x 0).im + (qh 1).im * (x 1).re -
    (qh 1).re * (x 1).im + (qh 2).im * (x 2).re - (qh 2).re * (x 2).im + (qh 3).im * (x 3).re -
    (qh 3).re * (x 3).im)
  linarith

theorem dmat_adj_hs (qh : Fin 4 → ℂ) :
    ∑ p, ‖LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh)) (EuclideanSpace.single p 1)‖ ^ 2 =
      3 * omg qh := by
  simp only [← Matrix.toEuclideanLin_conjTranspose_eq_adjoint, EuclideanSpace.norm_sq_eq]
  have e : ∀ p ρ, (Matrix.toEuclideanLin (dmat qh).conjTranspose
      (EuclideanSpace.single p (1 : ℂ))) ρ = star (dmat qh p ρ) := by
    intro p ρ
    show ((dmat qh).conjTranspose *ᵥ WithLp.ofLp (EuclideanSpace.single p (1 : ℂ))) ρ = _
    simp [Matrix.mulVec, dotProduct, Matrix.conjTranspose_apply, EuclideanSpace.single,
      Pi.single_apply]
  simp only [e, norm_star]
  unfold omg
  simp [Fin.sum_univ_succ, dmat, Fin.sum_univ_four]
  ring

/-- **A6-L1 at one Bloch momentum**: from the bracket `c/ω ≤ G` on `q̂^⊥`, `G ≤ C₊/ω`,
the face covariance `d̂ G d̂†` has `λ_max ≤ C₊` and diagonal average `≥ c/2`. -/
theorem face_bracket (qh : Fin 4 → ℂ) (hω : 0 < omg qh)
    (G : EuclideanSpace ℂ (Fin 4) →ₗ[ℂ] EuclideanSpace ℂ (Fin 4)) {c Cp : ℝ} (hC : 0 ≤ Cp)
    (hup : ∀ z, RCLike.re ⟪z, G z⟫_ℂ ≤ Cp / omg qh * ‖z‖ ^ 2)
    (hlow : ∀ z, ⟪z, WithLp.toLp 2 qh⟫_ℂ = 0 → c / omg qh * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, G z⟫_ℂ) :
    (∀ y, RCLike.re ⟪y, Matrix.toEuclideanLin (dmat qh)
        (G (LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh)) y))⟫_ℂ ≤ Cp * ‖y‖ ^ 2) ∧
      c / 2 ≤ (1 / 6) * ∑ p, RCLike.re ⟪EuclideanSpace.single p (1 : ℂ),
        Matrix.toEuclideanLin (dmat qh) (G (LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh))
          (EuclideanSpace.single p 1)))⟫_ℂ := by
  refine ⟨face_upper _ G hω hC (dmat_norm_sq qh) hup, ?_⟩
  refine face_diag_avg _ G (WithLp.toLp 2 qh) hω ?_ hlow _ (dmat_adj_hs qh)
  show WithLp.toLp 2 (dmat qh *ᵥ WithLp.ofLp (WithLp.toLp 2 qh)) = 0
  rw [WithLp.ofLp_toLp, dmat_q]; rfl

/-- **`Λ ≤ 2C₊/c`** (the arithmetic of the ratio). -/
theorem lambda_le {lmax diag c Cp : ℝ} (hc : 0 < c) (hCp : 0 ≤ Cp) (hup : lmax ≤ Cp)
    (hd : c / 2 ≤ diag) : lmax / diag ≤ 2 * Cp / c := by
  have hd0 : 0 < diag := by linarith
  rw [div_le_div_iff₀ hd0 hc]
  have h1 := mul_le_mul_of_nonneg_right hup hc.le
  have h2 := mul_le_mul_of_nonneg_left hd hCp
  nlinarith

end Concrete

end FaceBracket

end

#print axioms FaceBracket.adj_norm_sq_le
#print axioms FaceBracket.face_upper
#print axioms FaceBracket.face_diag_avg
#print axioms FaceBracket.dmat_q
#print axioms FaceBracket.dmat_norm_sq
#print axioms FaceBracket.dmat_adj_hs
#print axioms FaceBracket.face_bracket
#print axioms FaceBracket.lambda_le

-- ===== new part : FaceReal.part.lean =====
/-! # T4a: the real bracket at one momentum gives the complex hypotheses of `face_bracket`

Real side: `s ∈ ℝ⁴` (`s_ν = sin(q_ν/2)`), a real matrix `G`
with the bracket `c·P/ω ≼ G ≼ C₊·P/ω`, `P` the projection on `s^⊥`, whose quadratic form is
`Pq s x = Σx² − (Σ x s)²/Σ s²` (the form of `projM s`). Phase: `u_ν` with `|u_ν| = 1`
(`u_ν = −i e^{iq_ν/2}`), `q̂_ν = 2 u_ν s_ν` (`= 1 − e^{iq_ν}`, `qhat_phase`), and
`G^ℂ = U G U*`, `U = diag(u)`. Then `re⟨z, G^ℂ z⟩ = aᵀGa + bᵀGb` for `U*z = a + ib`, and
`⟨z, q̂⟩ = 0 ⟺ a ⊥ s, b ⊥ s`; this gives `hup` (all `z`) and `hlow` (on `q̂^⊥`) of
`FaceBracket.face_bracket`. Note `ω = Σ|q̂_ν|² = 4Σ s_ν²` (`omg_qhat`), the `ω` of the real side. -/

noncomputable section

namespace FaceReal

open Finset FaceBracket
open scoped InnerProductSpace ComplexConjugate Matrix

/-- `q̂_ν = 2 u_ν s_ν`. -/
def qhat (u : Fin 4 → ℂ) (s : Fin 4 → ℝ) : Fin 4 → ℂ := fun ν => 2 * u ν * (s ν : ℂ)

/-- The quadratic form of the projection on `s^⊥`. -/
def Pq (s x : Fin 4 → ℝ) : ℝ := (∑ i, x i ^ 2) - (∑ i, x i * s i) ^ 2 / ∑ i, s i ^ 2

/-- The real quadratic form of `G`. -/
def Gq (G : Matrix (Fin 4) (Fin 4) ℝ) (x : Fin 4 → ℝ) : ℝ := ∑ i, ∑ j, G i j * x i * x j

/-- `G^ℂ = U G U*`. -/
def Gc (u : Fin 4 → ℂ) (G : Matrix (Fin 4) (Fin 4) ℝ) : Matrix (Fin 4) (Fin 4) ℂ :=
  Matrix.of fun i j => u i * (G i j : ℂ) * star (u j)

theorem Pq_le (s x : Fin 4 → ℝ) : Pq s x ≤ ∑ i, x i ^ 2 := by
  unfold Pq
  have : 0 ≤ (∑ i, x i * s i) ^ 2 / ∑ i, s i ^ 2 :=
    div_nonneg (sq_nonneg _) (Finset.sum_nonneg fun i _ => sq_nonneg _)
  linarith

theorem Pq_perp (s x : Fin 4 → ℝ) (h : ∑ i, x i * s i = 0) : Pq s x = ∑ i, x i ^ 2 := by
  unfold Pq; rw [h]; simp

theorem omg_qhat (u : Fin 4 → ℂ) (hu : ∀ ν, ‖u ν‖ = 1) (s : Fin 4 → ℝ) :
    omg (qhat u s) = 4 * ∑ ν, s ν ^ 2 := by
  unfold omg qhat
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [norm_mul, norm_mul, hu, Complex.norm_real, Real.norm_eq_abs]
  simp only [Complex.norm_ofNat]
  rw [mul_pow, mul_pow, sq_abs]; ring

/-- The phase identity: `2·(−i e^{ix})·sin x = 1 − e^{2ix}` (with `x = q/2`). -/
theorem qhat_phase (x : ℝ) :
    2 * (-Complex.I * Complex.exp (x * Complex.I)) * (Real.sin x : ℂ) =
      1 - Complex.exp (2 * x * Complex.I) := by
  rw [Complex.ofReal_sin, Complex.sin]
  have e1 : Complex.exp (x * Complex.I) * Complex.exp (-(x : ℂ) * Complex.I) = 1 := by
    rw [← Complex.exp_add]; simp
  have e2 : Complex.exp (x * Complex.I) * Complex.exp (x * Complex.I) =
      Complex.exp (2 * x * Complex.I) := by
    rw [← Complex.exp_add]; ring_nf
  have hI : Complex.I * Complex.I = -1 := Complex.I_mul_I
  linear_combination (-(Complex.I * Complex.I)) * e1 + (Complex.I * Complex.I) * e2 +
    (Complex.exp (2 * x * Complex.I) - 1) * hI

theorem phase_norm (x : ℝ) : ‖-Complex.I * Complex.exp (x * Complex.I)‖ = 1 := by
  rw [norm_mul, norm_neg, Complex.norm_I, Complex.norm_exp_ofReal_mul_I]; ring

/-- `w = U* z`, real and imaginary parts. -/
def wa (u : Fin 4 → ℂ) (z : EuclideanSpace ℂ (Fin 4)) (i : Fin 4) : ℝ := (star (u i) * z i).re
def wb (u : Fin 4 → ℂ) (z : EuclideanSpace ℂ (Fin 4)) (i : Fin 4) : ℝ := (star (u i) * z i).im

theorem re_term (w1 w2 : ℂ) (g : ℝ) :
    (star w1 * ((g : ℂ) * w2)).re = g * w1.re * w2.re + g * w1.im * w2.im := by
  simp [Complex.mul_re, Complex.mul_im]; ring

theorem inner_Gc (u : Fin 4 → ℂ) (G : Matrix (Fin 4) (Fin 4) ℝ) (z : EuclideanSpace ℂ (Fin 4)) :
    RCLike.re ⟪z, Matrix.toEuclideanLin (Gc u G) z⟫_ℂ = Gq G (wa u z) + Gq G (wb u z) := by
  have h : ⟪z, Matrix.toEuclideanLin (Gc u G) z⟫_ℂ =
      ∑ i, ∑ j, star (star (u i) * z i) * ((G i j : ℂ) * (star (u j) * z j)) := by
    rw [EuclideanSpace.inner_eq_star_dotProduct]
    simp only [Matrix.toEuclideanLin_apply, WithLp.ofLp_toLp, dotProduct, Matrix.mulVec, Gc,
      Matrix.of_apply, Pi.star_apply]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun j _ => ?_
    simp only [star_mul', star_star]
    ring
  rw [h]
  simp only [RCLike.re_to_complex, Complex.re_sum, re_term]
  unfold Gq wa wb
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [← Finset.sum_add_distrib]

theorem norm_sq_w (u : Fin 4 → ℂ) (hu : ∀ ν, ‖u ν‖ = 1) (z : EuclideanSpace ℂ (Fin 4)) :
    ‖z‖ ^ 2 = ∑ i, wa u z i ^ 2 + ∑ i, wb u z i ^ 2 := by
  rw [EuclideanSpace.norm_sq_eq, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun i _ => ?_
  have h1 : ‖star (u i) * z i‖ ^ 2 = ‖z i‖ ^ 2 := by
    rw [norm_mul, norm_star, hu, one_mul]
  rw [← h1, Complex.sq_norm, Complex.normSq_apply]
  unfold wa wb; ring

theorem inner_qhat (u : Fin 4 → ℂ) (s : Fin 4 → ℝ) (z : EuclideanSpace ℂ (Fin 4)) :
    ⟪z, WithLp.toLp 2 (qhat u s)⟫_ℂ = 2 * ∑ i, star (star (u i) * z i) * (s i : ℂ) := by
  rw [EuclideanSpace.inner_eq_star_dotProduct]
  simp only [WithLp.ofLp_toLp, dotProduct, qhat, Pi.star_apply, Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  simp only [star_mul', star_star]
  ring

theorem perp_of_sum (w : Fin 4 → ℂ) (s : Fin 4 → ℝ)
    (h : ∑ i, star (w i) * (s i : ℂ) = 0) :
    ∑ i, (w i).re * s i = 0 ∧ ∑ i, (w i).im * s i = 0 := by
  have hr : (∑ i, star (w i) * (s i : ℂ)).re = ∑ i, (w i).re * s i := by
    rw [Complex.re_sum]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [Complex.mul_re]
  have hi : (∑ i, star (w i) * (s i : ℂ)).im = -∑ i, (w i).im * s i := by
    rw [Complex.im_sum, ← Finset.sum_neg_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [Complex.mul_im]
  rw [h] at hr hi
  simp only [Complex.zero_re, Complex.zero_im] at hr hi
  exact ⟨hr.symm, by linarith⟩

theorem perp_of_inner (u : Fin 4 → ℂ) (s : Fin 4 → ℝ) (z : EuclideanSpace ℂ (Fin 4))
    (h : ⟪z, WithLp.toLp 2 (qhat u s)⟫_ℂ = 0) :
    ∑ i, wa u z i * s i = 0 ∧ ∑ i, wb u z i * s i = 0 := by
  rw [inner_qhat] at h
  have h2 : ∑ i, star (star (u i) * z i) * (s i : ℂ) = 0 := by
    rcases mul_eq_zero.mp h with h0 | h0
    · norm_num at h0
    · exact h0
  exact perp_of_sum (fun i => star (u i) * z i) s h2

/-- **T4a**: the real bracket at one momentum gives `face_bracket` for `G^ℂ = U G U*`. -/
theorem face_bracket_of_real (u : Fin 4 → ℂ) (hu : ∀ ν, ‖u ν‖ = 1) (s : Fin 4 → ℝ)
    (hs : 0 < ∑ ν, s ν ^ 2) (G : Matrix (Fin 4) (Fin 4) ℝ) {c Cp : ℝ} (hC : 0 ≤ Cp)
    (hupR : ∀ x, Gq G x ≤ Cp / omg (qhat u s) * Pq s x)
    (hlowR : ∀ x, c / omg (qhat u s) * Pq s x ≤ Gq G x) :
    (∀ y, RCLike.re ⟪y, Matrix.toEuclideanLin (dmat (qhat u s))
        (Matrix.toEuclideanLin (Gc u G)
          (LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qhat u s))) y))⟫_ℂ ≤ Cp * ‖y‖ ^ 2) ∧
      c / 2 ≤ (1 / 6) * ∑ p, RCLike.re ⟪EuclideanSpace.single p (1 : ℂ),
        Matrix.toEuclideanLin (dmat (qhat u s)) (Matrix.toEuclideanLin (Gc u G)
          (LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qhat u s)))
            (EuclideanSpace.single p 1)))⟫_ℂ := by
  have hω : 0 < omg (qhat u s) := by rw [omg_qhat u hu]; linarith
  have hk : 0 ≤ Cp / omg (qhat u s) := div_nonneg hC hω.le
  refine face_bracket (qhat u s) hω _ hC ?_ ?_
  · intro z
    rw [inner_Gc, norm_sq_w u hu z]
    have h1 := hupR (wa u z)
    have h2 := hupR (wb u z)
    have h3 := mul_le_mul_of_nonneg_left (Pq_le s (wa u z)) hk
    have h4 := mul_le_mul_of_nonneg_left (Pq_le s (wb u z)) hk
    nlinarith
  · intro z hz
    obtain ⟨ha, hb⟩ := perp_of_inner u s z hz
    rw [inner_Gc, norm_sq_w u hu z]
    have h1 := hlowR (wa u z)
    have h2 := hlowR (wb u z)
    rw [Pq_perp s _ ha] at h1
    rw [Pq_perp s _ hb] at h2
    rw [mul_add]
    linarith

/-- **T4a at the lattice momentum** `q`: `u_ν = −i e^{iq_ν/2}`, `s_ν = sin(q_ν/2)`,
`q̂_ν = 1 − e^{iq_ν}`. -/
theorem face_bracket_of_real_q (q : Fin 4 → ℝ) (hs : 0 < ∑ ν, Real.sin (q ν / 2) ^ 2)
    (G : Matrix (Fin 4) (Fin 4) ℝ) {c Cp : ℝ} (hC : 0 ≤ Cp)
    (hupR : ∀ x, Gq G x ≤ Cp / (4 * ∑ ν, Real.sin (q ν / 2) ^ 2) *
      Pq (fun ν => Real.sin (q ν / 2)) x)
    (hlowR : ∀ x, c / (4 * ∑ ν, Real.sin (q ν / 2) ^ 2) * Pq (fun ν => Real.sin (q ν / 2)) x ≤
      Gq G x) :
    let qh : Fin 4 → ℂ := fun ν => 1 - Complex.exp (q ν * Complex.I)
    let u : Fin 4 → ℂ := fun ν => -Complex.I * Complex.exp ((q ν / 2 : ℝ) * Complex.I)
    (∀ y, RCLike.re ⟪y, Matrix.toEuclideanLin (dmat qh)
        (Matrix.toEuclideanLin (Gc u G)
          (LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh)) y))⟫_ℂ ≤ Cp * ‖y‖ ^ 2) ∧
      c / 2 ≤ (1 / 6) * ∑ p, RCLike.re ⟪EuclideanSpace.single p (1 : ℂ),
        Matrix.toEuclideanLin (dmat qh) (Matrix.toEuclideanLin (Gc u G)
          (LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh))
            (EuclideanSpace.single p 1)))⟫_ℂ := by
  intro qh u
  have hu : ∀ ν, ‖u ν‖ = 1 := fun ν => phase_norm (q ν / 2)
  have hq : qh = qhat u (fun ν => Real.sin (q ν / 2)) := by
    funext ν
    simp only [qh, u, qhat]
    rw [qhat_phase]
    congr 2
    push_cast; ring
  have homg : omg (qhat u fun ν => Real.sin (q ν / 2)) = 4 * ∑ ν, Real.sin (q ν / 2) ^ 2 :=
    omg_qhat u hu _
  rw [hq]
  exact face_bracket_of_real u hu _ hs G hC (by rw [homg]; exact hupR) (by rw [homg]; exact hlowR)

end FaceReal

end

#print axioms FaceReal.qhat_phase
#print axioms FaceReal.inner_Gc
#print axioms FaceReal.face_bracket_of_real
#print axioms FaceReal.face_bracket_of_real_q

-- ===== new part : FaceTorus.part.lean =====
/-! # T4b(ii): the diagonal of the face covariance on the torus, `≥ (c/2)(1 − N^{−4})`

On the torus `(ℤ/N)⁴` the Bloch momenta are `k ∈ (Fin N)⁴`,
`q̂_μ(k) = 1 − e^{2πi k_μ/N}`, `ω_μ = |q̂_μ|²`, `ω = Σ ω_μ` (`omg`). If the covariance of the field is
translation invariant with Bloch symbol `Ĝ(k)`, the covariance of the face field `F = dA` has the
position diagonal `N^{−4} Σ_k re⟨e_p, d̂(k) Ĝ(k) d̂(k)† e_p⟩` at every point and face `p` (this is the
modelling hypothesis; the identification of the Lean family with the lattice symbol is not paid
here). With the lower side `c/ω ≤ Ĝ(k)` on `q̂(k)^⊥` at every `k ≠ 0`:
* `adj_single_sq`: `‖d̂† e_p‖² = ω_μ + ω_ν` for `p = (μ, ν)`;
* `omg_ne_zero`: `ω(k) ≠ 0` for `k ≠ 0`;
* `sum_ratio_eq`: `Σ_k ω_μ/ω` (the `k = 0` term read as `0`) is the same for every `μ` (the
  coordinates of `k` are permuted, no hypercubic symmetry of `Ĝ`), hence `= (N⁴ − 1)/4`;
* **`torus_face_diag`**: the position diagonal is `≥ (c/2)(1 − N^{−4})`, for every face;
* `torus_lambda_le`: with `λ_max ≤ C₊`, `Λ ≤ 2C₊/(c(1 − N^{−4})) ≤ (32/15)·C₊/c` for `N ≥ 2`. -/

noncomputable section

namespace FaceTorus

open Finset FaceBracket
open scoped InnerProductSpace ComplexConjugate Matrix

/-- The Bloch momentum `q̂_μ(k) = 1 − e^{2πi k_μ/N}`. -/
def qk (N : ℕ) (k : Fin 4 → Fin N) : Fin 4 → ℂ :=
  fun μ => 1 - Complex.exp (2 * Real.pi * Complex.I * ((k μ : ℕ) : ℂ) / N)

/-- The two directions of the face `p` (rows of `dmat`: `01, 02, 03, 12, 13, 23`). -/
def fa : Fin 6 → Fin 4 := ![0, 0, 0, 1, 1, 2]
def fb : Fin 6 → Fin 4 := ![1, 2, 3, 2, 3, 3]

theorem adj_single_sq (qh : Fin 4 → ℂ) (p : Fin 6) :
    ‖LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh)) (EuclideanSpace.single p 1)‖ ^ 2 =
      ‖qh (fa p)‖ ^ 2 + ‖qh (fb p)‖ ^ 2 := by
  simp only [← Matrix.toEuclideanLin_conjTranspose_eq_adjoint, EuclideanSpace.norm_sq_eq]
  have e : ∀ ρ, (Matrix.toEuclideanLin (dmat qh).conjTranspose
      (EuclideanSpace.single p (1 : ℂ))) ρ = star (dmat qh p ρ) := by
    intro ρ
    show ((dmat qh).conjTranspose *ᵥ WithLp.ofLp (EuclideanSpace.single p (1 : ℂ))) ρ = _
    simp [Matrix.mulVec, dotProduct, Matrix.conjTranspose_apply, EuclideanSpace.single,
      Pi.single_apply]
  simp only [e, norm_star]
  fin_cases p <;> simp [Fin.sum_univ_four, dmat, fa, fb] <;> ring

/-- The per-momentum diagonal from the lower side (`d̂ q̂ = 0`). -/
theorem diag_ge (qh : Fin 4 → ℂ) (hω : 0 < omg qh)
    (G : EuclideanSpace ℂ (Fin 4) →ₗ[ℂ] EuclideanSpace ℂ (Fin 4)) {c : ℝ}
    (hlow : ∀ z, ⟪z, WithLp.toLp 2 qh⟫_ℂ = 0 → c / omg qh * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, G z⟫_ℂ)
    (p : Fin 6) :
    c / omg qh * (‖qh (fa p)‖ ^ 2 + ‖qh (fb p)‖ ^ 2) ≤
      RCLike.re ⟪EuclideanSpace.single p (1 : ℂ), Matrix.toEuclideanLin (dmat qh)
        (G (LinearMap.adjoint (Matrix.toEuclideanLin (dmat qh)) (EuclideanSpace.single p 1)))⟫_ℂ := by
  rw [← adj_single_sq qh p, ← LinearMap.adjoint_inner_left]
  apply hlow
  rw [LinearMap.adjoint_inner_left]
  have : Matrix.toEuclideanLin (dmat qh) (WithLp.toLp 2 qh) = 0 := by
    show WithLp.toLp 2 (dmat qh *ᵥ WithLp.ofLp (WithLp.toLp 2 qh)) = 0
    rw [WithLp.ofLp_toLp, dmat_q]; rfl
  rw [this, inner_zero_right]

theorem dmat_zero : dmat (0 : Fin 4 → ℂ) = 0 := by
  ext p ρ; fin_cases p <;> fin_cases ρ <;> simp [dmat]

theorem exp_ne_one {N : ℕ} {m : ℕ} (hm0 : 0 < m) (hmN : m < N) :
    Complex.exp (2 * Real.pi * Complex.I * (m : ℂ) / N) ≠ 1 := by
  intro h
  rw [Complex.exp_eq_one_iff] at h
  obtain ⟨n, hn⟩ := h
  have hN : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hI : (2 * Real.pi * Complex.I : ℂ) ≠ 0 := by
    simp [Real.pi_ne_zero, Complex.I_ne_zero]
  have e : ((m : ℂ) / N) = (n : ℂ) := by
    have : 2 * Real.pi * Complex.I * ((m : ℂ) / N) = 2 * Real.pi * Complex.I * (n : ℂ) := by
      rw [← mul_div_assoc, hn]; ring
    exact mul_left_cancel₀ hI this
  have e' : (m : ℝ) / N = n := by
    have h' : (((m : ℝ) / N : ℝ) : ℂ) = ((n : ℝ) : ℂ) := by push_cast; exact e
    exact_mod_cast h'
  have h1 : (0 : ℝ) < n := by rw [← e']; positivity
  have h2 : (n : ℝ) < 1 := by rw [← e', div_lt_one hN]; exact_mod_cast hmN
  have h3 : (0 : ℤ) < n := by exact_mod_cast h1
  have h4 : n < (1 : ℤ) := by exact_mod_cast h2
  omega

theorem omg_ne_zero {N : ℕ} [NeZero N] (k : Fin 4 → Fin N) (hk : k ≠ 0) : omg (qk N k) ≠ 0 := by
  obtain ⟨μ, hμ⟩ := Function.ne_iff.mp hk
  have hm0 : 0 < ((k μ : ℕ)) := by
    rcases Nat.eq_zero_or_pos (k μ : ℕ) with h | h
    · exfalso; apply hμ; apply Fin.ext; rw [h]; simp
    · exact h
  have hq : qk N k μ ≠ 0 := by
    unfold qk; intro h
    exact exp_ne_one hm0 (k μ).isLt (by rw [sub_eq_zero] at h; exact h.symm)
  intro h0
  unfold omg at h0
  have := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => sq_nonneg ‖qk N k i‖)).mp h0 μ
    (Finset.mem_univ μ)
  exact hq (norm_eq_zero.mp (pow_eq_zero_iff two_ne_zero |>.mp this))

theorem omg_zero {N : ℕ} [NeZero N] : qk N (0 : Fin 4 → Fin N) = 0 := by
  funext μ; simp [qk]

/-- The ratio `ω_μ/ω` with the `k = 0` term `0`. -/
def rt (N : ℕ) (μ : Fin 4) (k : Fin 4 → Fin N) : ℝ := ‖qk N k μ‖ ^ 2 / omg (qk N k)

theorem qk_comp {N : ℕ} (k : Fin 4 → Fin N) (σ : Equiv.Perm (Fin 4)) (μ : Fin 4) :
    qk N (k ∘ σ) μ = qk N k (σ μ) := rfl

theorem omg_comp {N : ℕ} (k : Fin 4 → Fin N) (σ : Equiv.Perm (Fin 4)) :
    omg (qk N (k ∘ σ)) = omg (qk N k) := by
  unfold omg
  exact Equiv.sum_comp σ (fun μ => ‖qk N k μ‖ ^ 2)

theorem sum_rt_perm {N : ℕ} (μ : Fin 4) (σ : Equiv.Perm (Fin 4)) :
    ∑ k : Fin 4 → Fin N, rt N μ k = ∑ k : Fin 4 → Fin N, rt N (σ μ) k := by
  refine Fintype.sum_equiv (Equiv.arrowCongr σ (Equiv.refl (Fin N))) _ _ ?_
  intro k
  unfold rt
  have hk : (Equiv.arrowCongr σ (Equiv.refl (Fin N))) k = k ∘ σ.symm := by
    funext i; simp [Equiv.arrowCongr_apply]
  rw [hk, qk_comp, omg_comp, Equiv.symm_apply_apply]

theorem sum_rt_eq {N : ℕ} (μ ν : Fin 4) :
    ∑ k : Fin 4 → Fin N, rt N μ k = ∑ k : Fin 4 → Fin N, rt N ν k := by
  have := sum_rt_perm (N := N) μ (Equiv.swap μ ν)
  rwa [Equiv.swap_apply_left] at this

theorem sum_rt_all {N : ℕ} [NeZero N] :
    ∑ μ, ∑ k : Fin 4 → Fin N, rt N μ k = (N : ℝ) ^ 4 - 1 := by
  rw [Finset.sum_comm]
  have h : ∀ k : Fin 4 → Fin N, ∑ μ, rt N μ k = if k = 0 then 0 else 1 := by
    intro k
    unfold rt
    split_ifs with hk
    · subst hk; rw [omg_zero]; simp [omg]
    · rw [← Finset.sum_div]
      exact div_self (omg_ne_zero k hk)
  simp only [h]
  rw [Finset.sum_ite, Finset.sum_const_zero, zero_add, Finset.sum_const, nsmul_eq_mul, mul_one]
  have hc : (univ.filter fun k : Fin 4 → Fin N => ¬k = 0).card = N ^ 4 - 1 := by
    rw [Finset.filter_ne' univ (0 : Fin 4 → Fin N), Finset.card_erase_of_mem (Finset.mem_univ _),
      Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin]
  rw [hc]
  have h1 : 1 ≤ N ^ 4 := Nat.one_le_pow _ _ (Nat.pos_of_ne_zero (NeZero.ne N))
  push_cast [h1]
  ring

theorem sum_rt_quarter {N : ℕ} [NeZero N] (μ : Fin 4) :
    ∑ k : Fin 4 → Fin N, rt N μ k = ((N : ℝ) ^ 4 - 1) / 4 := by
  have h := sum_rt_all (N := N)
  rw [Fin.sum_univ_four, ← sum_rt_eq μ 0, ← sum_rt_eq μ 1, ← sum_rt_eq μ 2, ← sum_rt_eq μ 3] at h
  linarith

/-- **T4b(ii)**: the position diagonal of the face covariance on the torus. -/
theorem torus_face_diag {N : ℕ} [NeZero N]
    (G : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 4) →ₗ[ℂ] EuclideanSpace ℂ (Fin 4)) {c : ℝ}
    (hlow : ∀ k, k ≠ 0 → ∀ z, ⟪z, WithLp.toLp 2 (qk N k)⟫_ℂ = 0 →
      c / omg (qk N k) * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, G k z⟫_ℂ) (p : Fin 6) :
    c / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤
      (1 / (N : ℝ) ^ 4) * ∑ k : Fin 4 → Fin N,
        RCLike.re ⟪EuclideanSpace.single p (1 : ℂ), Matrix.toEuclideanLin (dmat (qk N k))
          (G k (LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qk N k)))
            (EuclideanSpace.single p 1)))⟫_ℂ := by
  have hterm : ∀ k : Fin 4 → Fin N, c * (rt N (fa p) k + rt N (fb p) k) ≤
      RCLike.re ⟪EuclideanSpace.single p (1 : ℂ), Matrix.toEuclideanLin (dmat (qk N k))
          (G k (LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qk N k)))
            (EuclideanSpace.single p 1)))⟫_ℂ := by
    intro k
    by_cases hk : k = 0
    · subst hk
      rw [omg_zero, dmat_zero]
      simp [rt, omg_zero, omg]
    · have hω : 0 < omg (qk N k) :=
        lt_of_le_of_ne (Finset.sum_nonneg fun i _ => sq_nonneg _) (omg_ne_zero k hk).symm
      have h := diag_ge (qk N k) hω (G k) (hlow k hk) p
      have e : c * (rt N (fa p) k + rt N (fb p) k) =
          c / omg (qk N k) * (‖qk N k (fa p)‖ ^ 2 + ‖qk N k (fb p)‖ ^ 2) := by
        unfold rt; field_simp
      rw [e]; exact h
  have hs := Finset.sum_le_sum fun k (_ : k ∈ (univ : Finset (Fin 4 → Fin N))) => hterm k
  rw [← Finset.mul_sum, Finset.sum_add_distrib, sum_rt_quarter, sum_rt_quarter] at hs
  have hN : (0 : ℝ) < (N : ℝ) ^ 4 := by
    have : (0 : ℝ) < N := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne N)
    positivity
  have hN0 : (N : ℝ) ≠ 0 := by exact_mod_cast NeZero.ne N
  have e : c / 2 * (1 - 1 / (N : ℝ) ^ 4) =
      (1 / (N : ℝ) ^ 4) * (c * (((N : ℝ) ^ 4 - 1) / 4 + ((N : ℝ) ^ 4 - 1) / 4)) := by
    field_simp; ring
  rw [e]
  exact mul_le_mul_of_nonneg_left hs (by positivity)

/-- The hypotheses are satisfiable: `Ĝ(k) = (c/ω(k))·1` (any `c ≥ 0`). -/
theorem hlow_example {N : ℕ} {c : ℝ} (k : Fin 4 → Fin N) (z : EuclideanSpace ℂ (Fin 4)) :
    c / omg (qk N k) * ‖z‖ ^ 2 ≤
      RCLike.re ⟪z, ((c / omg (qk N k) : ℝ) : ℂ) • z⟫_ℂ := by
  rw [inner_smul_right, inner_self_eq_norm_sq_to_K]
  simp [Complex.mul_re]
  norm_cast

end FaceTorus

end

#print axioms FaceTorus.adj_single_sq
#print axioms FaceTorus.omg_ne_zero
#print axioms FaceTorus.sum_rt_quarter
#print axioms FaceTorus.torus_face_diag
#print axioms FaceTorus.hlow_example

-- ===== new part : FaceTorusUp.part.lean =====
/-! # T4b(i) in Fourier form: `Σ_k re⟨ŷ_k, d̂Ĝd̂†ŷ_k⟩ ≤ C₊ Σ_k ‖ŷ_k‖²`

Paper: With the upper side `re⟨z, Ĝ(k)z⟩ ≤ (C₊/ω(k))‖z‖²` at every `k ≠ 0`, the
quadratic form of the face covariance, written in the Bloch momenta, is at most `C₊` times the
`ℓ²` norm of the Fourier coefficients (`k = 0` contributes `0`: `d̂(0) = 0`). With the unitary
(normalised) discrete Fourier transform on the torus, `Σ_k ‖ŷ_k‖² = ‖y‖²` (Plancherel, not formalised
here), this is `⟨y, C_F y⟩ ≤ C₊‖y‖²`. -/

noncomputable section

namespace FaceTorus

open Finset FaceBracket
open scoped InnerProductSpace ComplexConjugate Matrix

theorem torus_face_upper {N : ℕ} [NeZero N]
    (G : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 4) →ₗ[ℂ] EuclideanSpace ℂ (Fin 4)) {Cp : ℝ}
    (hC : 0 ≤ Cp)
    (hup : ∀ k, k ≠ 0 → ∀ z, RCLike.re ⟪z, G k z⟫_ℂ ≤ Cp / omg (qk N k) * ‖z‖ ^ 2)
    (yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) :
    ∑ k, RCLike.re ⟪yh k, Matrix.toEuclideanLin (dmat (qk N k))
        (G k (LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qk N k))) (yh k)))⟫_ℂ ≤
      Cp * ∑ k, ‖yh k‖ ^ 2 := by
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun k _ => ?_
  by_cases hk : k = 0
  · subst hk
    rw [omg_zero, dmat_zero]
    simp only [map_zero, LinearMap.zero_apply, inner_zero_right, RCLike.zero_re]
    positivity
  · have hω : 0 < omg (qk N k) :=
      lt_of_le_of_ne (Finset.sum_nonneg fun i _ => sq_nonneg _) (omg_ne_zero k hk).symm
    exact face_upper _ (G k) hω hC (dmat_norm_sq (qk N k)) (hup k hk) (yh k)

end FaceTorus

end

#print axioms FaceTorus.torus_face_upper
