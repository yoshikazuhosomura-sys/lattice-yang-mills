import Lam.Torus1
import Lam.Planch1

/-! # T1h, `Λ` in position space on the torus 

Paper: The face field `y : (Fin N)⁴ → ℂ⁶` (six faces at each site) with the
translation-invariant covariance `C` whose Bloch symbol at the momentum `k` is `faceM N m k = d̂(k) Ĝ_m(k) d̂(k)†`
(`Lam.Torus1`): `(C y)(x) = N⁻⁴ Σ_k e_k(x) faceM_k ŷ(k)`, `e_k(x) = Π_μ e^{2πik_μx_μ/N}`,
`ŷ(k) = Σ_x conj(e_k(x)) y(x)` (`PlanchK.opC`, `TorusChar.ch`). Then
* `posQ_le`: `re Σ_x ⟨y(x), (Cy)(x)⟩ ≤ Σ_x ‖y(x)‖²` (Plancherel + `TorusLam.faceQ_le`);
* `posDiag_eq`: the diagonal entry `⟨e_p δ_{x₀}, C e_p δ_{x₀}⟩` is `TorusLam.faceDiag N m p` at every site `x₀`;
* **`torus_position_face_lambda`**: `λ_max(C) ≤ 1`, every diagonal entry `≥ (c₀/2)(1 − N⁻⁴)`, `diag ≤ λ_max`, and
  `Λ = λ_max/diag ≤ 640/9` (`c₀ = 3/100`), for every stage `m`, `N ≥ 2`, site `x₀` and face `p`. -/

noncomputable section

namespace TorusPos

open Finset ComplexConjugate TorusLam PlanchK
open scoped InnerProductSpace

/-- The covariance of the face field in position space (stage `m`). -/
def posC (N m : ℕ) (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) :
    (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6) :=
  PlanchK.opC (TorusChar.ch N) (faceM N m) y

def posQ (N m : ℕ) (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : ℝ :=
  (∑ x, ⟪y x, posC N m y x⟫_ℂ).re

def posNorm (N : ℕ) (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : ℝ := ∑ x, ‖y x‖ ^ 2

def posSet (N m : ℕ) : Set ℝ :=
  {r | ∃ y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6), 0 < posNorm N y ∧ r = posQ N m y / posNorm N y}

/-- `λ_max` of the position-space covariance. -/
def posLamMax (N m : ℕ) : ℝ := sSup (posSet N m)

/-- The diagonal entry at the site `x₀` and the face `p`. -/
def posDiag (N m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) : ℝ :=
  (⟪EuclideanSpace.single p (1 : ℂ),
    posC N m (PlanchK.delta x0 (EuclideanSpace.single p 1)) x0⟫_ℂ).re

theorem card_sites (N : ℕ) : (Fintype.card (Fin 4 → Fin N) : ℝ) = (N : ℝ) ^ 4 := by
  simp [Fintype.card_fun]

theorem posQ_le {N : ℕ} [NeZero N] (m : ℕ) (y : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) :
    posQ N m y ≤ posNorm N y := by
  have h1 := PlanchK.form_eq (ch := TorusChar.ch N) (faceM N m) y
  have h2 := PlanchK.plancherel_norm (ch := TorusChar.ch N) (fun x x' => TorusChar.ortho x x') y
  have h3 := faceQ_le (N := N) m (fun k => PlanchK.ft (TorusChar.ch N) y k)
  have hc : (0 : ℝ) < Fintype.card (Fin 4 → Fin N) := by
    rw [card_sites]; have : (0 : ℝ) < N := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne N)
    positivity
  have h4 : (Fintype.card (Fin 4 → Fin N) : ℝ) * posQ N m y ≤
      (Fintype.card (Fin 4 → Fin N) : ℝ) * posNorm N y := by
    have e1 : (Fintype.card (Fin 4 → Fin N) : ℝ) * posQ N m y =
        faceQ N m (fun k => PlanchK.ft (TorusChar.ch N) y k) := h1
    have e2 : faceNorm N (fun k => PlanchK.ft (TorusChar.ch N) y k) =
        (Fintype.card (Fin 4 → Fin N) : ℝ) * posNorm N y := h2
    rw [e1, ← e2]; exact h3
  exact le_of_mul_le_mul_left h4 hc

theorem posDiag_eq {N : ℕ} (m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) :
    posDiag N m x0 p = faceDiag N m p := by
  unfold posDiag posC faceDiag
  rw [PlanchK.diag_eq (fun k x => TorusChar.ch_norm N k x)]
  have e : ((Fintype.card (Fin 4 → Fin N) : ℂ))⁻¹ = (((1 / (N : ℝ) ^ 4 : ℝ)) : ℂ) := by
    simp [Fintype.card_fun]
  rw [e, Complex.re_ofReal_mul, Complex.re_sum]
  rfl

theorem posNorm_delta {N : ℕ} (x0 : Fin 4 → Fin N) (p : Fin 6) :
    posNorm N (PlanchK.delta x0 (EuclideanSpace.single p (1 : ℂ))) = 1 := by
  unfold posNorm PlanchK.delta
  rw [Finset.sum_eq_single x0]
  · simp
  · intro x _ hx; simp [hx]
  · simp

theorem posQ_delta {N : ℕ} (m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) :
    posQ N m (PlanchK.delta x0 (EuclideanSpace.single p (1 : ℂ))) = posDiag N m x0 p := by
  unfold posQ posDiag
  rw [Finset.sum_eq_single x0]
  · simp [PlanchK.delta]
  · intro x _ hx; simp [PlanchK.delta, hx]
  · simp

theorem diag_mem {N : ℕ} (m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) : posDiag N m x0 p ∈ posSet N m :=
  ⟨PlanchK.delta x0 (EuclideanSpace.single p (1 : ℂ)), by rw [posNorm_delta]; exact one_pos,
    by rw [posNorm_delta, posQ_delta, div_one]⟩

theorem posSet_le {N : ℕ} [NeZero N] (m : ℕ) : ∀ r ∈ posSet N m, r ≤ 1 := by
  rintro r ⟨y, hpos, rfl⟩
  rw [div_le_one hpos]
  exact posQ_le m y

/-- **T1h, `Λ` of the face covariance in position space on the torus, joined to the chain.**
For `N ≥ 2`, every stage `m`, every site `x₀` and face `p`: `λ_max ≤ 1` (from (OS↑)), the diagonal entry
`≥ (c₀/2)(1 − N⁻⁴)`, `c₀ = 3/100` (from `lower_side_c`), `diag ≤ λ_max`, and `λ_max/diag ≤ 640/9`.
No hypothesis. -/
theorem torus_position_face_lambda {N : ℕ} (hN : 2 ≤ N) (m : ℕ) (x0 : Fin 4 → Fin N) (p : Fin 6) :
    (∀ y, posQ N m y ≤ posNorm N y) ∧ posLamMax N m ≤ 1 ∧
    (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ posDiag N m x0 p ∧
    posDiag N m x0 p ≤ posLamMax N m ∧
    posLamMax N m / posDiag N m x0 p ≤ 640 / 9 := by
  haveI : NeZero N := ⟨by omega⟩
  have hbdd : BddAbove (posSet N m) := ⟨1, posSet_le m⟩
  have hmax : posLamMax N m ≤ 1 := csSup_le ⟨_, diag_mem m x0 p⟩ (posSet_le m)
  have hd : (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ posDiag N m x0 p := by
    rw [posDiag_eq]; exact faceDiag_ge m p
  exact ⟨posQ_le m, hmax, hd, le_csSup hbdd (diag_mem m x0 p), T1h.torus_lambda_c3 hN hmax hd⟩

end TorusPos

end

#print axioms TorusPos.torus_position_face_lambda
#print axioms TorusPos.posDiag_eq
