import T1.Split1

-- ===== Lam/Up1 = import T1.Split1 (= an earlier file) + an earlier file lines 3728..6492 verbatim =====
-- (lines 1..3727 of TauSplitCombined are, namespace block by namespace block, identical to Split1 lines 1..3726: checked by a generating script)

-- ===== new part : CouplingLimit.part.lean =====
/-!
# (R3) The coupling coefficient `b_k → b_∞` from Theorem 1 

`b_k := Ξ(G_k)` with `G_k = 𝓜^k(P/ω)` (the physical stage covariance, `LatticeRec.rec_iterate`)
and `Ξ` Lipschitz relative to `P` on a set containing every `G_k`:
`−cP ≼ A − B ≼ cP  ⟹  |Ξ A − Ξ B| ≤ L c`  (`RelLip`).

* `coupling_limit` (abstract): if `M` preserves the order, `M P ≼ λ P` (`0 ≤ λ < 1`) and
  `−dP ≼ M G₀ − G₀ ≼ dP`, then `b_k = Ξ(M^k G₀)` converges to some `b_∞` with
  `|b_k − b_∞| ≤ L d λ^k/(1−λ)`, the bracket `b_∞ − Ld/(1−λ) ≤ b_k ≤ b_∞ + Ld/(1−λ)`,
  `Σ|b_k − b_∞|` summable with every partial sum `≤ L d/(1−λ)²`, hence the transient field
  `Σ_{k<n} max(−δ_k, 0) ≤ L d/(1−λ)²` of `CouplingStepsTransientE` (`δ_k = b_k − b_∞`).
* `D_lower` (the lower half of (R4)): `M(P/ω) − P/ω ≽ −2P` on `Qpos`; with `Mfam_B_le`
  (`≼ (15/8) P`) this gives `d = 2`.
* `coupling_converges`: the concrete statement for the family of Theorem 1 (`λ = 429/512`, `d = 2`).
* `quadLip`: every finite combination `Ξ(A) = Σ_i w_i ⟪v_i, A(q_i) v_i⟫` (on a finite torus,
  `(1/|Λ|) Σ_q tr(V(q) G(q))` is of this form) is `RelLip` with `L = Σ |w_i| ⟪v_i, P(q_i) v_i⟫`.
-/

noncomputable section

namespace CouplingLimit

open Finset Filter Topology UniformBracket
open scoped Real RealInnerProductSpace

section Abstract

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- `Ξ` is Lipschitz relative to `P` on `S` with constant `L`. -/
def RelLip (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (P : Q → E →ₗ[ℝ] E) (L : ℝ) (S : Set (Q → E →ₗ[ℝ] E)) :
    Prop :=
  ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c → Lw (-(c • P)) (A - B) → Lw (A - B) (c • P) →
    |Ξ A - Ξ B| ≤ L * c

theorem geom_partial_le {lam : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (n : ℕ) :
    ∑ k ∈ range n, lam ^ k ≤ 1 / (1 - lam) := by
  have h1 : 0 < 1 - lam := by linarith
  have e := geom_sum_mul lam n
  rw [le_div_iff₀ h1]
  have : (∑ k ∈ range n, lam ^ k) * (1 - lam) = 1 - lam ^ n := by linarith
  rw [this]
  have := pow_nonneg hlam0 n
  linarith

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The coupling coefficient converges geometrically** (abstract form). -/
theorem coupling_limit (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam d L : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hd : 0 ≤ d) (hL : 0 ≤ L)
    (hP : Lw (M P) (lam • P)) (hlo : Lw (-(d • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (d • P))
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (S : Set (Q → E →ₗ[ℝ] E)) (hS : ∀ k, (⇑M)^[k] G0 ∈ S)
    (hΞ : RelLip Ξ P L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d * lam ^ k / (1 - lam)) ∧
      (∀ k, binf - L * d / (1 - lam) ≤ Ξ ((⇑M)^[k] G0) ∧
        Ξ ((⇑M)^[k] G0) ≤ binf + L * d / (1 - lam)) ∧
      Summable (fun k => |Ξ ((⇑M)^[k] G0) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d / (1 - lam) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 ≤ L * d / (1 - lam) ^ 2) := by
  set b : ℕ → ℝ := fun k => Ξ ((⇑M)^[k] G0) with hb
  have h1 : 0 < 1 - lam := by linarith
  -- one step
  have hstep : ∀ k, dist (b k) (b (k + 1)) ≤ (L * d) * lam ^ k := by
    intro k
    obtain ⟨lo, hi⟩ := iterate_two_sided M hM hlam0 hd hP hlo hhi k
    have e : (⇑M)^[k] (M G0 - G0) = (⇑M)^[k + 1] G0 - (⇑M)^[k] G0 := by
      rw [iter_sub, Function.iterate_succ_apply]
    rw [e] at lo hi
    have hc : 0 ≤ d * lam ^ k := mul_nonneg hd (pow_nonneg hlam0 k)
    have := hΞ _ (hS (k + 1)) _ (hS k) _ hc lo hi
    rw [Real.dist_eq, abs_sub_comm]
    calc |b (k + 1) - b k| ≤ L * (d * lam ^ k) := this
      _ = L * d * lam ^ k := by ring
  have hcs : CauchySeq b := cauchySeq_of_le_geometric lam (L * d) hlam1 hstep
  obtain ⟨binf, hlim⟩ := cauchySeq_tendsto_of_complete hcs
  have hdist : ∀ k, |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := by
    intro k
    have := dist_le_of_le_geometric_of_tendsto lam (L * d) hlam1 hstep hlim k
    rwa [Real.dist_eq] at this
  have hLd : 0 ≤ L * d := mul_nonneg hL hd
  have hbr : ∀ k, |b k - binf| ≤ L * d / (1 - lam) := by
    intro k
    refine (hdist k).trans ?_
    rw [div_le_div_iff_of_pos_right h1]
    calc L * d * lam ^ k ≤ L * d * 1 := mul_le_mul_of_nonneg_left (pow_le_one₀ hlam0 hlam1.le) hLd
      _ = L * d := by ring
  have hsum : Summable (fun k => |b k - binf|) := by
    refine Summable.of_nonneg_of_le (fun k => abs_nonneg _) hdist ?_
    have := (summable_geometric_of_lt_one hlam0 hlam1).mul_left (L * d / (1 - lam))
    refine this.congr fun k => ?_
    ring
  have hpart : ∀ n, ∑ k ∈ range n, |b k - binf| ≤ L * d / (1 - lam) ^ 2 := by
    intro n
    calc ∑ k ∈ range n, |b k - binf| ≤ ∑ k ∈ range n, L * d / (1 - lam) * lam ^ k :=
          Finset.sum_le_sum fun k _ => by
            have := hdist k
            calc |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := this
              _ = L * d / (1 - lam) * lam ^ k := by ring
      _ = L * d / (1 - lam) * ∑ k ∈ range n, lam ^ k := by rw [Finset.mul_sum]
      _ ≤ L * d / (1 - lam) * (1 / (1 - lam)) :=
          mul_le_mul_of_nonneg_left (geom_partial_le hlam0 hlam1 n) (div_nonneg hLd h1.le)
      _ = L * d / (1 - lam) ^ 2 := by field_simp
  refine ⟨binf, hlim, hdist, fun k => ?_, hsum, hpart, fun n => ?_⟩
  · have := abs_le.mp (hbr k)
    constructor <;> linarith [this.1, this.2]
  · refine le_trans (Finset.sum_le_sum fun k _ => ?_) (hpart n)
    exact max_le (neg_le_abs _) (abs_nonneg _)

/-- A finite combination of quadratic-form evaluations is Lipschitz relative to `P` on all
families, with `L = Σ_i |w_i| ⟪v_i, P(q_i) v_i⟫`. -/
theorem quadLip {ι : Type*} (s : Finset ι) (w : ι → ℝ) (qs : ι → Q) (vs : ι → E)
    (P : Q → E →ₗ[ℝ] E) :
    RelLip (fun A => ∑ i ∈ s, w i * ⟪vs i, A (qs i) (vs i)⟫) P
      (∑ i ∈ s, |w i| * ⟪vs i, P (qs i) (vs i)⟫) Set.univ := by
  intro A _ B _ c hc lo hi
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
  have l := lo (qs i) (vs i)
  have h := hi (qs i) (vs i)
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.neg_apply,
    LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply, inner_neg_right,
    real_inner_smul_right] at l h
  rw [← mul_sub, abs_mul]
  have hab : |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫| ≤ c * ⟪vs i, P (qs i) (vs i)⟫ :=
    abs_le.mpr ⟨by linarith, by linarith⟩
  calc |w i| * |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫|
      ≤ |w i| * (c * ⟪vs i, P (qs i) (vs i)⟫) := mul_le_mul_of_nonneg_left hab (abs_nonneg _)
    _ = |w i| * ⟪vs i, P (qs i) (vs i)⟫ * c := by ring


/-- **With the sharp form (OS↑) the transient vanishes**: if `M G₀ ≼ G₀` and `Ξ` is monotone for
the Loewner order, then `b_k` decreases to its limit, so `δ_k = b_k − b_∞ ≥ 0` and every term
`max(−δ_k, 0)` of the transient field is `0` (`D₀ = 0`). -/
theorem transient_zero (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0)
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (hmono : ∀ A B, Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑M)^[k] G0) ∧ max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 = 0 := by
  have hanti : Antitone fun k => Ξ ((⇑M)^[k] G0) :=
    antitone_nat_of_succ_le fun n => hmono _ _ (iterate_antitone M hM h1 n)
  have hle : binf ≤ Ξ ((⇑M)^[k] G0) := hanti.le_of_tendsto hlim k
  exact ⟨hle, max_eq_right (by linarith)⟩

end Abstract

/-! ## The family of Theorem 1: `d = 2` -/

section Concrete

open OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower

/-- The alias nearest to the origin is at most half as far: `sin²(r*/2) ≤ ½ sin²(q/2)`. -/
theorem sR_zstar_le (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ sQ θ ν ^ 2 / 2 := by
  have hs := Real.sin_sq_add_cos_sq (θ ν)
  have hQ : sQ θ ν ^ 2 = 4 * Real.sin (θ ν) ^ 2 * Real.cos (θ ν) ^ 2 := by
    unfold sQ; rw [Real.sin_two_mul]; ring
  rw [hQ]
  unfold sR phi zstar
  by_cases h : 1 / 2 < Real.sin (θ ν) ^ 2
  · simp only [h, decide_true, if_true, Real.sin_add_pi_div_two]
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]
  · simp only [h, decide_false, Bool.false_eq_true, if_false, add_zero]
    replace h := le_of_not_gt h
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]

theorem nlow_ge {ξ : ℝ} (h0 : 0 ≤ ξ) (h1 : ξ ≤ 1 / 32) : 1 - 5 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0]

/-- The scalar inequality behind `D_lower`: `1 − n(b/2)²(1−b)² ≤ 16 b` for `0 ≤ b ≤ 1/16`. -/
theorem deficit_le {b : ℝ} (h0 : 0 ≤ b) (h1 : b ≤ 1 / 16) :
    1 - nlow (b / 2) ^ 2 * (1 - b) ^ 2 ≤ 16 * b := by
  have hn := nlow_ge (ξ := b / 2) (by linarith) (by linarith)
  have hn0 : 0 ≤ 1 - 5 * (b / 2) := by linarith
  have hsq : (1 - 5 * (b / 2)) ^ 2 ≤ nlow (b / 2) ^ 2 := pow_le_pow_left₀ hn0 hn 2
  have hb1 : 0 ≤ (1 - b) ^ 2 := sq_nonneg _
  have : (1 - 5 * (b / 2)) ^ 2 * (1 - b) ^ 2 ≤ nlow (b / 2) ^ 2 * (1 - b) ^ 2 :=
    mul_le_mul_of_nonneg_right hsq hb1
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0,
    mul_nonneg (mul_nonneg (mul_nonneg h0 h0) h0) h0]

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem inner_P_dot (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) :=
  inner_P th q x

/-- **(R4), lower half**: `𝓜(P/ω) − P/ω ≽ −2P`. -/
theorem D_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (-((2 : ℝ) • Pfam th))
      (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply,
    inner_neg_right, real_inner_smul_right, Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hP := inner_P_nonneg th q x
  have hωq := hω q
  set G0 : Q → V →ₗ[ℝ] V := fun q => (omF th q)⁻¹ • Pfam th q with hG0
  -- the terms of `𝓜 G0` are nonnegative
  have hterm : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
      G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
    intro ζ
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω _).le) (inner_P_nonneg th _ _)
  have hM := Mfam_inner th rq G0 q x
  have hG : ⟪x, G0 q x⟫ = (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
  by_cases hbig : 1 / 2 ≤ omF th q
  · -- far from the origin: `𝓜 G0 ≽ 0` and `G0 ≼ 2P`
    have h0 : 0 ≤ ⟪x, Mfam th rq G0 q x⟫ := by
      rw [hM]; exact mul_nonneg (by norm_num) (Finset.sum_nonneg fun ζ _ => hterm ζ)
    have h2 : (omF th q)⁻¹ ≤ 2 := by
      rw [inv_le_comm₀ hωq (by norm_num)]; linarith
    nlinarith [mul_le_mul_of_nonneg_right h2 hP]
  · -- near the origin: keep the alias `ζ*` only
    replace hbig := lt_of_not_ge hbig
    set ζ := zstar fun ν => Real.sin (th q ν) ^ 2
    set bb := omF th q / 8 with hbb
    have hb0 : 0 ≤ bb := by rw [hbb]; linarith
    have hb1 : bb ≤ 1 / 16 := by rw [hbb]; linarith
    have hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ bb := by
      intro ν
      refine (sR_zstar_le (th q) ν).trans ?_
      have hle : 4 * sQ (th q) ν ^ 2 ≤ omF th q := by
        unfold omF
        exact Finset.single_le_sum (f := fun ν => 4 * sQ (th q) ν ^ 2)
          (fun i _ => by positivity) (Finset.mem_univ ν)
      rw [hbb]; linarith
    have hn : 0 ≤ nlow (bb / 2) := by
      have := nlow_ge (ξ := bb / 2) (by linarith) (by linarith); linarith
    have h1 := one_alias_lower (th q) (WithLp.ofLp x) ζ hsR le_rfl (by linarith) hn
    rw [← alias_inner th rq hrq q ζ x] at h1
    have hrat := omega_ratio th rq hrq q ζ hsR
    have hωr := hω (rq q ζ)
    have hPx : ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x))
        (proj (sQ (th q)) (WithLp.ofLp x)) := inner_P th q x
    rw [← hPx] at h1
    -- one term of `𝓜 G0`
    set y := Matrix.toEuclideanLin (AtM (th q) ζ) x
    have hone : ⟪y, G0 (rq q ζ) y⟫ ≤ ⟪x, Mfam th rq G0 q x⟫ * 16 := by
      rw [hM]
      have := Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hterm ζ)
        (Finset.mem_univ ζ)
      linarith
    have hyG : ⟪y, G0 (rq q ζ) y⟫ = (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
      simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    -- `⟨y, P_r y⟩ / ω(r) ≥ 4 n² (1−b) |Px|² · 4(1−b)/ω(q)`
    have hb1' : 0 < 1 - bb := by linarith
    have hinv : 4 * (1 - bb) / omF th q ≤ (omF th (rq q ζ))⁻¹ := by
      rw [div_le_iff₀ hωq]
      calc 4 * (1 - bb) = (omF th (rq q ζ))⁻¹ * (4 * (1 - bb) * omF th (rq q ζ)) := by
            field_simp
        _ ≤ (omF th (rq q ζ))⁻¹ * omF th q :=
            mul_le_mul_of_nonneg_left hrat (inv_nonneg.mpr hωr.le)
    have hyP : 0 ≤ ⟪y, Pfam th (rq q ζ) y⟫ := inner_P_nonneg th _ _
    have hkey : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ ≤
        ⟪y, G0 (rq q ζ) y⟫ := by
      rw [hyG]
      calc nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫
          = (4 * (1 - bb) / omF th q) * (4 * nlow (bb / 2) ^ 2 * (1 - bb) * ⟪x, Pfam th q x⟫) := by
            ring
        _ ≤ (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
            apply mul_le_mul hinv h1
            · exact mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _)) hb1'.le) hP
            · exact inv_nonneg.mpr hωr.le
    have hdef := deficit_le hb0 hb1
    -- assemble: `⟨x,𝓜G0 x⟩ − ω⁻¹⟨x,Px⟩ ≥ −2⟨x,Px⟩`
    have hA : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, Mfam th rq G0 q x⟫ := by
      have : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ =
          16 * (nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫) := by
        field_simp
      linarith
    have hB : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
        nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        2 * ⟪x, Pfam th q x⟫ := by
      have e : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
          nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ =
          (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
      rw [e]
      have h16 : (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ ≤ 2 := by
        rw [← div_eq_mul_inv, div_le_iff₀ hωq]
        have e16 : 16 * bb = 2 * omF th q := by rw [hbb]; ring
        linarith
      exact mul_le_mul_of_nonneg_right h16 hP
    linarith

/-- **(R4), upper half** from `Mfam_B_le`: `𝓜(P/ω) − P/ω ≼ 2P`. -/
theorem D_upper (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q)
      ((2 : ℝ) • Pfam th) := by
  intro q x
  have h := Mfam_B_le th rq hrq hω q x
  have hP := inner_P_nonneg th q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right] at h
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right]
  nlinarith

/-- **b_k → b_∞ for the family of Theorem 1** (`λ = 429/512`, `d = 2`): for any `Ξ` Lipschitz
relative to `P` (constant `L`) on a set containing all `G_k = 𝓜^k(P/ω)`. -/
theorem coupling_converges (Ξ : (Qpos → V →ₗ[ℝ] V) → ℝ) (S : Set (Qpos → V →ₗ[ℝ] V)) {L : ℝ}
    (hL : 0 ≤ L)
    (hS : ∀ k, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) ∈ S)
    (hΞ : RelLip Ξ (Pfam Subtype.val) L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (429 / 512 : ℝ) ^ k / (1 - 429 / 512)) ∧
      (∀ k, binf - L * 2 / (1 - 429 / 512) ≤ Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ∧
        Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
          (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ≤ binf + L * 2 / (1 - 429 / 512)) ∧
      Summable (fun k => |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 / (1 - 429 / 512) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 429 / 512) ^ 2) := by
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  exact coupling_limit (Mfam (Subtype.val : Qpos → _) rqPos) (Mfam_orderPreserving _ _)
    (by norm_num) (by norm_num) (by norm_num) hL (Mfam_P_le _ _ hrq)
    (D_lower _ _ hrq hω) (D_upper _ _ hrq hω) Ξ S hS hΞ

/-- The numerical constants: `2/(1 − 429/512) = 1024/83 < 12.4` and
`2/(1 − 429/512)² = 524288/6889 < 76.2`. -/
theorem consts : (2 : ℝ) / (1 - 429 / 512) = 1024 / 83 ∧
    (2 : ℝ) / (1 - 429 / 512) ^ 2 = 524288 / 6889 := by
  constructor <;> norm_num

end Concrete

end CouplingLimit

end



-- ===== new part : RowSplit.part.lean =====
/-! # L3(ii) (round two): `𝓜 P ≼ (3/5) P` by the row-wise Cauchy split

work-08. All1135 `OneStepNorm.comp_sq_le` splits every row `μ`
of `N u` with one common `t = 3/10`, giving `λ̄ = 429/512` (`OneStepBridge.Mfam_P_le`). Here row
`μ` is split with `t_μ = 3 x_μ` (`row_split`, no division by `x_μ`), the cross terms keep the exact
`E`, `ρ′` (no `η̄`), and the coefficient of `u_c²` is `coefK`. The alias sum is the polynomial `Gk`
of `y_ν = σ_ν(1 − σ_ν)` and `Gk ≤ 3/5` on `[0, 1/4]⁴` (affine in each transverse `y`, a concave
quadratic in `y_c` at each vertex; largest `0.5902`).
Main: **`MP_coord_le_row`** `Qf θ x ≤ (3/5) ⟨x, P x⟩` and **`Mfam_P_le_row`** `𝓜 P ≼ (3/5) P`
(the `hPstep` of the bracket with `λ̄′ = 3/5` in place of `429/512`).
The hypothesis `hrq` of `Mfam_P_le_row` is the defining equation of the alias maps of the family
(the same convention as All1135 `rqPos`, `thR`), not an assumption on the measure.
-/

noncomputable section

namespace RowSplit

open Finset OneStepNorm OneStepHrep
open scoped Real

/-! ## 1. The row split -/

/-- `(a − sS)² ≤ (1 + k s²) a² + (s² + 1/k) S²` (`k > 0`): the split with `t = k s²`. -/
theorem row_split (a s S : ℝ) {k : ℝ} (hk : 0 < k) :
    (a - s * S) ^ 2 ≤ (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 := by
  have h : 0 ≤ (k * s * a + S) ^ 2 / k := div_nonneg (sq_nonneg _) hk.le
  have e : (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 - (a - s * S) ^ 2 =
      (k * s * a + S) ^ 2 / k := by
    field_simp; ring
  linarith

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Row `μ` with `t_μ = k s̃_μ²`. -/
theorem comp_sq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
  rw [comp_identity pi st E u hu μ]
  have h := row_split ((pi μ - st μ ^ 2) * u μ) (st μ)
    (∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) hk
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ st μ ^ 2 + 1 / k := by positivity
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hcs hc
  linarith

theorem normSq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le_row pi st E u hu hE hk μ

end MatrixLevel

/-! ## 2. The coefficient and the polynomial bound -/

/-- The row-split coefficient of `u_c²` with `t_μ = 3 x_μ` (direction `c` first). -/
def coefK (xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + 3 * xc) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 +
    ((x1 + 1 / 3) * Ef x2 x3 * rhoP xc x2 x3 + (x2 + 1 / 3) * Ef x1 x3 * rhoP xc x1 x3 +
      (x3 + 1 / 3) * Ef x1 x2 * rhoP xc x1 x2)

/-- The alias sum as a polynomial in `y_c, y_1, y_2, y_3`. -/
def Gk (y0 y1 y2 y3 : ℝ) : ℝ :=
  (-3/2) * y0^2 + (-3/32) * y0 * y1 * y2 * y3 + (149/576) * y0 * y1 * y2 +
    (149/576) * y0 * y1 * y3 + (-899/1152) * y0 * y1 + (149/576) * y0 * y2 * y3 +
    (-899/1152) * y0 * y2 + (-899/1152) * y0 * y3 + (65/256) * y0 + (-1/32) * y1 * y2 * y3 +
    (31/576) * y1 * y2 + (31/576) * y1 * y3 + (-281/1152) * y1 + (31/576) * y2 * y3 +
    (-281/1152) * y2 + (-281/1152) * y3 + (445/768)

theorem aliasK_eq (σc σ1 σ2 σ3 : ℝ) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) =
      Gk (yv σc) (yv σ1) (yv σ2) (yv σ3) := by
  simp only [Fintype.sum_bool, xa, wa, coefK, Ef, rhoP, yv, Gk]
  ring

theorem yv_mem' {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ ∧ yv σ ≤ 1 / 4 := by
  unfold yv
  constructor
  · exact mul_nonneg h0 (by linarith)
  · nlinarith [sq_nonneg (σ - 1 / 2)]

theorem affine_le {f : ℝ → ℝ} {L y : ℝ} (hf : f y = (1 - 4 * y) * f 0 + 4 * y * f (1 / 4))
    (hy0 : 0 ≤ y) (hy1 : y ≤ 1 / 4) (h0 : f 0 ≤ L) (h1 : f (1 / 4) ≤ L) : f y ≤ L := by
  rw [hf]
  have ha : 0 ≤ 1 - 4 * y := by linarith
  have hb : 0 ≤ 4 * y := by linarith
  nlinarith [mul_le_mul_of_nonneg_left h0 ha, mul_le_mul_of_nonneg_left h1 hb]

theorem Gk_vertex {y0 : ℝ} (h0 : 0 ≤ y0) (h1 : y0 ≤ 1 / 4) (v1 v2 v3 : ℝ)
    (hv1 : v1 = 0 ∨ v1 = 1 / 4) (hv2 : v2 = 0 ∨ v2 = 1 / 4) (hv3 : v3 = 0 ∨ v3 = 1 / 4) :
    Gk y0 v1 v2 v3 ≤ 3 / 5 := by
  unfold Gk
  rcases hv1 with rfl | rfl <;> rcases hv2 with rfl | rfl <;> rcases hv3 with rfl | rfl <;>
    nlinarith [sq_nonneg (y0 - 65 / 768), sq_nonneg (y0 - 271 / 13824)]

theorem Gk_le {y0 y1 y2 y3 : ℝ} (h0 : 0 ≤ y0 ∧ y0 ≤ 1 / 4) (h1 : 0 ≤ y1 ∧ y1 ≤ 1 / 4)
    (h2 : 0 ≤ y2 ∧ y2 ≤ 1 / 4) (h3 : 0 ≤ y3 ∧ y3 ≤ 1 / 4) : Gk y0 y1 y2 y3 ≤ 3 / 5 := by
  have V := fun v1 v2 v3 hv1 hv2 hv3 => Gk_vertex h0.1 h0.2 v1 v2 v3 hv1 hv2 hv3
  have s3 : ∀ v1 v2, (v1 = 0 ∨ v1 = 1 / 4) → (v2 = 0 ∨ v2 = 1 / 4) → Gk y0 v1 v2 y3 ≤ 3 / 5 :=
    fun v1 v2 hv1 hv2 => affine_le (f := fun z => Gk y0 v1 v2 z) (by simp only [Gk]; ring)
      h3.1 h3.2 (V v1 v2 0 hv1 hv2 (Or.inl rfl)) (V v1 v2 (1 / 4) hv1 hv2 (Or.inr rfl))
  have s2 : ∀ v1, (v1 = 0 ∨ v1 = 1 / 4) → Gk y0 v1 y2 y3 ≤ 3 / 5 :=
    fun v1 hv1 => affine_le (f := fun z => Gk y0 v1 z y3) (by simp only [Gk]; ring)
      h2.1 h2.2 (s3 v1 0 hv1 (Or.inl rfl)) (s3 v1 (1 / 4) hv1 (Or.inr rfl))
  exact affine_le (f := fun z => Gk y0 z y2 y3) (by simp only [Gk]; ring)
    h1.1 h1.2 (s2 0 (Or.inl rfl)) (s2 (1 / 4) (Or.inr rfl))

theorem aliasK_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) ≤ 3 / 5 := by
  rw [aliasK_eq]
  exact Gk_le (yv_mem' hc.1 hc.2) (yv_mem' h1.1 h1.2) (yv_mem' h2.1 h2.2) (yv_mem' h3.1 h3.2)

/-! ## 3. One alias with the row split -/

set_option maxRecDepth 8000 in
theorem normSq_alias_row (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefK (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefK (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefK (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefK (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le_row _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefK, rhoP, Ef, Matrix.cons_val]
  ring

/-- The alias coefficients with the row split. -/
def DalK (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefK (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefK (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefK (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefK (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

theorem DalK_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    DalK σ c ≤ 3 / 5 := by
  fin_cases c
  · exact aliasK_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact aliasK_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

theorem alias_term_le_row (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefK (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefK (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefK (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefK (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias_row (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

theorem hrep_coord_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le_row θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, DalK, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound with the row split**: `⟨x, (𝓜P)(q) x⟩ ≤ (3/5) ⟨x, P(q) x⟩`. -/
theorem MP_coord_le_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (3 / 5) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord_row θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (3 / 5) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (DalK_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end RowSplit

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hPstep` with `λ̄′ = 3/5`**: `𝓜 P ≼ (3/5) P` (row-wise split). -/
theorem Mfam_P_le_row (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((3 / 5 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact RowSplit.MP_coord_le_row (th q) (WithLp.ofLp x)

end OneStepBridge

end

namespace NmBracket

noncomputable section

open Finset

/-! ## Copied definitions  -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- Linearity of `N` in `u` (one combination). -/
theorem Nm_lin (s u v : Fin 4 → ℝ) (t : ℝ) :
    Nm s (fun i => u i + t * v i) = fun i => Nm s u i + t * Nm s v i := by
  funext μ
  unfold Nm
  simp only [sum_erase4]
  ring

/-! ## The `M`-form : `N u = u − ½ M u`, `M = Σ_{μ<ν} B_{μν} ρ ρᵀ` -/

/-- `B_{μν}` of the complementary pair `{ρ, ρ'}`, in `b = s²`. -/
def Bw (b b' : ℝ) : ℝ := 1 - (b + b') / 4 + b * b' / 12

theorem one_sub_Ef (b b' : ℝ) : 1 - Ef (b / 2) (b' / 2) = Bw b b' := by
  unfold Ef Bw; ring

/-- `D_{μν} = s_ν u_μ − s_μ u_ν`. -/
def Dp (s u : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := s ν * u μ - s μ * u ν

/-- The quadratic form `⟨u, M u⟩ = Σ_{μ<ν} B_{μν} D_{μν}²` written out over the six faces. -/
def Mq (s u : Fin 4 → ℝ) : ℝ :=
  Bw (s 2 ^ 2) (s 3 ^ 2) * Dp s u 0 1 ^ 2 + Bw (s 1 ^ 2) (s 3 ^ 2) * Dp s u 0 2 ^ 2 +
  Bw (s 1 ^ 2) (s 2 ^ 2) * Dp s u 0 3 ^ 2 + Bw (s 0 ^ 2) (s 3 ^ 2) * Dp s u 1 2 ^ 2 +
  Bw (s 0 ^ 2) (s 2 ^ 2) * Dp s u 1 3 ^ 2 + Bw (s 0 ^ 2) (s 1 ^ 2) * Dp s u 2 3 ^ 2

set_option maxRecDepth 8000 in
/-- `⟨u, N u⟩ = |u|² − ½ ⟨u, M u⟩` (unordered faces `μ < ν`). -/
theorem Nm_form (s u : Fin 4 → ℝ) : dot u (Nm s u) = dot u u - (1 / 2) * Mq s u := by
  unfold dot Nm Mq Dp Bw
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  simp
  ring

/-! ## Per-face bounds on `B` (P3, P3′) -/

theorem Bw_le_refined {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') (hb1 : b ≤ 1) (hb1' : b' ≤ 1) :
    Bw b b' ≤ 1 - 5 * (b + b') / 24 := by
  unfold Bw; nlinarith [mul_nonneg hb hb', mul_nonneg (sub_nonneg.2 hb1) hb',
    mul_nonneg hb (sub_nonneg.2 hb1'), sq_nonneg (b - b')]

theorem Bw_ge_lin {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') : 1 - (b + b') / 4 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg hb hb']

theorem Bw_lower {b b' : ℝ} (hb1 : b ≤ 1) (hb1' : b' ≤ 1) : 7 / 12 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg (sub_nonneg.2 hb1) (sub_nonneg.2 hb1')]

/-! ## The bracket on `s^⊥` -/

def llo (X bm sb : ℝ) : ℝ := 1 - 1/2*((1 - 5/24*X)*X + 5/24*(X*bm + sb))
def lup (X sb : ℝ) : ℝ := min (1 - 7/24*X) (1 - (X - X^2/4 + sb/4)/2)

def Xs (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 2
def Sb (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 4

section Bracket

variable {s u : Fin 4 → ℝ}

/-- Upper side of `⟨u, M u⟩` (gives `λ_lo`): with `u ⊥ s`,
`⟨u,Mu⟩ ≤ (1 − 5X/24) X |u|² + 5/24 (X Σ s²u² + Σ s⁴ |u|²)`. -/
theorem Mq_le (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    Mq s u ≤ (1 - 5/24 * Xs s) * Xs s * dot u u +
      5/24 * (Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 + Sb s * dot u u) := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have f01 := mul_le_mul_of_nonneg_right (Bw_le_refined p2 p3 h2 h3) (sq_nonneg (Dp s u 0 1))
  have f02 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p3 h1 h3) (sq_nonneg (Dp s u 0 2))
  have f03 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p2 h1 h2) (sq_nonneg (Dp s u 0 3))
  have f12 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p3 h0 h3) (sq_nonneg (Dp s u 1 2))
  have f13 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p2 h0 h2) (sq_nonneg (Dp s u 1 3))
  have f23 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p1 h0 h1) (sq_nonneg (Dp s u 2 3))
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  unfold Mq
  simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at f01 f02 f03 f12 f13 f23 ⊢
  linarith

/-- Lower sides of `⟨u, M u⟩` (give `λ_up`). -/
theorem Mq_ge (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    7/12 * (Xs s * dot u u) ≤ Mq s u ∧
      (Xs s - Xs s ^ 2 / 4 + Sb s / 4) * dot u u ≤ Mq s u := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  constructor
  · have g01 := mul_le_mul_of_nonneg_right (Bw_lower h2 h3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_lower h1 h3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_lower h1 h2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_lower h0 h3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_lower h0 h2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_lower h0 h1) (sq_nonneg (Dp s u 2 3))
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith
  · have g01 := mul_le_mul_of_nonneg_right (Bw_ge_lin p2 p3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p1) (sq_nonneg (Dp s u 2 3))
    have hX : 0 ≤ (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
        (s 0 ^ 2 * u 0 ^ 2 + s 1 ^ 2 * u 1 ^ 2 + s 2 ^ 2 * u 2 ^ 2 + s 3 ^ 2 * u 3 ^ 2) := by
      positivity
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith

theorem dot_self_nonneg (u : Fin 4 → ℝ) : 0 ≤ dot u u :=
  Finset.sum_nonneg fun i _ => mul_self_nonneg (u i)

theorem Xs_nonneg (s : Fin 4 → ℝ) : 0 ≤ Xs s := Finset.sum_nonneg fun i _ => sq_nonneg _

/-- **Lower end of the bracket**: `λ_lo |u|² ≤ ⟨u, N u⟩` on `s^⊥`. -/
theorem Nm_bracket_lo {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1) (hbm : ∀ ν, s ν ^ 2 ≤ bm)
    (hu : dot s u = 0) : llo (Xs s) bm (Sb s) * dot u u ≤ dot u (Nm s u) := by
  rw [Nm_form]
  have h := Mq_le hb hu
  have hw : ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ bm * dot u u := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun ν _ => by
      have := mul_le_mul_of_nonneg_right (hbm ν) (sq_nonneg (u ν)); nlinarith
  have hX := Xs_nonneg s
  have : Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ Xs s * (bm * dot u u) :=
    mul_le_mul_of_nonneg_left hw hX
  unfold llo
  nlinarith

/-- **Upper end of the bracket**: `⟨u, N u⟩ ≤ λ_up |u|²` on `s^⊥`. -/
theorem Nm_bracket_up (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    dot u (Nm s u) ≤ lup (Xs s) (Sb s) * dot u u := by
  rw [Nm_form]
  obtain ⟨h1, h2⟩ := Mq_ge hb hu
  unfold lup
  rw [min_mul_of_nonneg _ _ (dot_self_nonneg u)]
  refine le_min ?_ ?_ <;> nlinarith

end Bracket

/-! ## From the bracket to the norm bounds `κ⁻`, `κ⁺` -/

section Norm

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (fun i => b i + c i) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_smul_right (a b : Fin 4 → ℝ) (t : ℝ) : dot a (fun i => t * b i) = t * dot a b := by
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (fun i => a i + b i) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_smul_left (a b : Fin 4 → ℝ) (t : ℝ) : dot (fun i => t * a i) b = t * dot a b := by
  rw [dot_comm, dot_smul_right, dot_comm]

/-- `N` maps `s^⊥` into itself. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-- Cauchy–Schwarz for `dot`. -/
theorem dot_sq_le (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa [sq] using h

variable {s u : Fin 4 → ℝ}

/-- The frame inequality on `s^⊥`: `|N u − lo u|² ≤ (up − lo)(⟨u,Nu⟩ − lo|u|²)`. -/
theorem frame_ineq {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) ≤
      (up - lo) * (dot u (Nm s u) - lo * dot u u) := by
  set y : Fin 4 → ℝ := fun i => Nm s u i + (-lo) * u i with hy
  -- the positive form p(v) = ⟨v, N v⟩ - lo |v|² on s^⊥
  have hys : dot s y = 0 := by
    rw [hy, dot_add_right, dot_smul_right, dot_Nm_of_dot hu, hu]; ring
  have hNy : Nm s y = fun i => Nm s (Nm s u) i + (-lo) * Nm s u i := by
    rw [hy, Nm_lin]
  -- c = ⟨u, P y⟩ = |y|²
  have hc : dot u (Nm s y) + (-lo) * dot u y = dot y y := by
    rw [hNy, dot_add_right, dot_smul_right, Nm_symm s (Nm s u) u]
    conv_rhs => rw [hy, dot_add_left, dot_smul_left]
    rw [hy, dot_add_right, dot_smul_right]
    rw [dot_comm (Nm s u) (Nm s u)]
    have : dot (Nm s u) u = dot u (Nm s u) := dot_comm _ _
    rw [dot_add_right, dot_smul_right, this]
  set p := dot u (Nm s u) - lo * dot u u
  set c := dot y y
  set d := dot y (Nm s y) - lo * dot y y
  have hp : 0 ≤ p := by have := hlo u hu; simp only [p]; linarith
  have hyy : 0 ≤ c := dot_self_nonneg y
  have hd : d ≤ (up - lo) * c := by
    have := hup y hys; simp only [d, c]; linarith
  -- positivity of the form along u + t y
  have hf : ∀ t : ℝ, 0 ≤ p + 2 * t * c + t ^ 2 * d := by
    intro t
    set v : Fin 4 → ℝ := fun i => u i + t * y i with hv
    have hvs : dot s v = 0 := by rw [hv, dot_add_right, dot_smul_right, hu, hys]; ring
    have h0 := hlo v hvs
    have hNv : Nm s v = fun i => Nm s u i + t * Nm s y i := by rw [hv, Nm_lin]
    have hyu : dot y (Nm s u) = dot u (Nm s y) := by rw [Nm_symm, dot_comm]
    have e1 : dot v (Nm s v) = dot u (Nm s u) + 2 * t * dot u (Nm s y) +
        t ^ 2 * dot y (Nm s y) := by
      rw [hNv, hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, hyu]
      ring
    have e2 : dot v v = dot u u + 2 * t * dot u y + t ^ 2 * dot y y := by
      rw [hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, dot_comm y u]
      ring
    have hc' : dot u (Nm s y) - lo * dot u y = c := by simp only [c]; linarith [hc]
    rw [e1, e2] at h0
    have h2c : 2 * t * (dot u (Nm s y) - lo * dot u y) = 2 * t * c := by rw [hc']
    simp only [p, d]
    nlinarith [h2c]
  by_cases hD : 0 < up - lo
  · have h1 := hf (-(1 / (up - lo)))
    have hdiv : d * (1 / (up - lo)) ^ 2 ≤ c * (1 / (up - lo)) := by
      have hpos : 0 < 1 / (up - lo) := by positivity
      have := mul_le_mul_of_nonneg_right hd (sq_nonneg (1 / (up - lo)))
      have e : (up - lo) * c * (1 / (up - lo)) ^ 2 = c * (1 / (up - lo)) := by
        field_simp
      linarith
    have h2 : 0 ≤ p - c * (1 / (up - lo)) := by nlinarith
    have h3 : c * (1 / (up - lo)) ≤ p := by linarith
    have := mul_le_mul_of_nonneg_left h3 hD.le
    have e : (up - lo) * (c * (1 / (up - lo))) = c := by field_simp
    linarith
  · -- `up ≤ lo`: then `p = 0`, `d ≤ 0`, and positivity along `u + t y` forces `c = 0`
    have hd0 : d ≤ 0 := by nlinarith
    have hpa : p ≤ 0 := by
      have h1 := hup u hu
      have ha := dot_self_nonneg u
      have : (up - lo) * dot u u ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) ha
      simp only [p]; nlinarith
    have hp0 : p = 0 := le_antisymm hpa hp
    rw [hp0, mul_zero]
    by_contra hcon
    have hcpos : 0 < c := lt_of_not_ge hcon
    have h1 := hf (-1 / (2 * c))
    rw [hp0] at h1
    have e : 2 * (-1 / (2 * c)) * c = -1 := by field_simp
    have hn : (-1 / (2 * c)) ^ 2 * d ≤ 0 := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg _) hd0
    linarith

/-- **`κ⁺`**: on `s^⊥`, `|N u|² ≤ max (lo²) (up²) |u|²`. -/
theorem Nm_sq_le_of_bracket {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤ max (lo ^ 2) (up ^ 2) * dot u u := by
  have hF := frame_ineq hlo hup hu
  have e : dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) =
      dot (Nm s u) (Nm s u) - 2 * lo * dot u (Nm s u) + lo ^ 2 * dot u u := by
    rw [dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
      dot_smul_right, dot_smul_right, dot_comm (Nm s u) u]
    ring
  rw [e] at hF
  set t := dot u (Nm s u)
  set a := dot u u
  have ha : 0 ≤ a := dot_self_nonneg u
  have h1 := hlo u hu
  have h2 := hup u hu
  have hm1 := le_max_left (lo ^ 2) (up ^ 2)
  have hm2 := le_max_right (lo ^ 2) (up ^ 2)
  -- `N² ≤ (up + lo) t − up lo a`, linear in `t ∈ [lo a, up a]`
  rcases le_total 0 (up + lo) with hs | hs
  · have : (up + lo) * t ≤ (up + lo) * (up * a) := mul_le_mul_of_nonneg_left h2 hs
    nlinarith [mul_le_mul_of_nonneg_right hm2 ha]
  · have : (up + lo) * (lo * a) ≥ (up + lo) * t := mul_le_mul_of_nonpos_left h1 hs
    nlinarith [mul_le_mul_of_nonneg_right hm1 ha]

/-- **`κ⁻`**: on `s^⊥`, `(max lo 0)² |u|² ≤ |N u|²`. -/
theorem le_Nm_sq_of_bracket {lo : ℝ}
    (hlo : lo * dot u u ≤ dot u (Nm s u)) :
    (max lo 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) := by
  have ha := dot_self_nonneg u
  have hcs := dot_sq_le u (Nm s u)
  rcases le_total lo 0 with h | h
  · rw [max_eq_right h]; simp; exact dot_self_nonneg _
  · rw [max_eq_left h]
    have ht : lo * dot u u ≤ dot u (Nm s u) := hlo
    have h0 : 0 ≤ lo * dot u u := mul_nonneg h ha
    have hsq : (lo * dot u u) ^ 2 ≤ dot u (Nm s u) ^ 2 := pow_le_pow_left₀ h0 ht 2
    rcases lt_or_eq_of_le ha with hpos | hzero
    · have : lo ^ 2 * dot u u * dot u u ≤ dot (Nm s u) (Nm s u) * dot u u := by nlinarith
      exact le_of_mul_le_mul_right this hpos
    · rw [← hzero]; simp; exact dot_self_nonneg _

end Norm

/-! ## The concrete `κ⁻`, `κ⁺` of TauStageZero -/

theorem Nm_sq_le_kplus {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤
      max (llo (Xs s) bm (Sb s) ^ 2) (lup (Xs s) (Sb s) ^ 2) * dot u u :=
  Nm_sq_le_of_bracket (fun _ hv => Nm_bracket_lo hb hbm hv) (fun _ hv => Nm_bracket_up hb hv) hu

theorem kminus_le_Nm_sq {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    (max (llo (Xs s) bm (Sb s)) 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) :=
  le_Nm_sq_of_bracket (Nm_bracket_lo hb hbm hu)


end

end NmBracket

/-! # L2-3: (OS↑) `𝓜(P/ω) ≼ P/ω` from `E_ν ≤ 4`, and the transient `D₀ = 0`

Paper: theorem 3 (`E_ν < 4 ⇒ (OS↑)`), §8.57 ("紙のまま: E_ν < 4 ⇒ (OS↑)、Lean の EE と紙の
E_ν の同一"). Lean: `os_up` is `UniformBracket.Lw (Mfam th rq G₀) G₀`, `G₀ = P/ω`, i.e. the field
`h1` of `CouplingLimit.transient_zero`, under the hypothesis `hEE : EE σ(q) ν ≤ 4` where `EE` is
the definition of (`EE s ν = Σ_e HH s / XX s e * kplus s e * (1 − bb s e ν)`) copied
verbatim, and `σ(q)_ν = sin²(th q ν)`. The hypothesis is the conclusion of 
`FreeStageOS.E_lt_four_s` (`Adm σ`, i.e. `σ ≤ 1/2`, and `σ ≠ 0`).

Dictionary (proved here): `xa = bb/2`, `wa = 1 − bb`, `omR = 4·XX`, `omQ = 4·HH`,
`sR² = bb`, `Σ sR² = XX`, `Σ sR⁴ = SS`; the per-alias bound `alias_term_le_kplus` replaces
`alias_term_le_one` (κ⁺ in place of 1) via `NmBracket.Nm_sq_le_kplus`. -/

namespace OSUpBridge

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

/-! ## Copies of the definitions (ℝ) -/

def bb (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (μ : Fin 4) : ℝ := if e μ then 1 - s μ else s μ
def XX (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, bb s e μ
def SS (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, (bb s e μ)^2
def BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max (max (bb s e 0) (bb s e 1)) (max (bb s e 2) (bb s e 3))
def HH (s : Fin 4 → ℝ) : ℝ := 4 * ∑ μ, s μ * (1 - s μ)
noncomputable def lamLo (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.llo (XX s e) (BM s e) (SS s e)
noncomputable def lamUp (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.lup (XX s e) (SS s e)
noncomputable def kplus (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max ((lamLo s e)^2) ((lamUp s e)^2)
noncomputable def EE (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  ∑ e, HH s / XX s e * kplus s e * (1 - bb s e ν)

/-! ## The dictionary -/

theorem xa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    xa (s ν) (e ν) = bb s e ν / 2 := by
  unfold bb; cases e ν <;> simp [xa]

theorem wa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    wa (s ν) (e ν) = 1 - bb s e ν := by
  unfold bb; cases e ν <;> simp [wa]

theorem omR_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : omR s e = 4 * XX s e := by
  unfold omR XX; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by rw [xa_eq]; ring

theorem omQ_eq (s : Fin 4 → ℝ) : omQ s = 4 * HH s := by
  unfold omQ HH; rw [Finset.mul_sum, Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by ring

theorem sR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sR θ ζ ν ^ 2 = bb (fun ν => Real.sin (θ ν) ^ 2) ζ ν := by
  have h := xs_alias θ ζ ν
  unfold xs at h
  rw [xa_eq (fun ν => Real.sin (θ ν) ^ 2) ζ ν] at h
  linarith

theorem bb_le_BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) : bb s e ν ≤ BM s e := by
  unfold BM
  fin_cases ν
  · exact le_trans (le_max_left _ _) (le_max_left _ _)
  · exact le_trans (le_max_right _ _) (le_max_left _ _)
  · exact le_trans (le_max_left _ _) (le_max_right _ _)
  · exact le_trans (le_max_right _ _) (le_max_right _ _)

/-- `N` of All1135 is the `N` of `NmBracket` (same definition). -/
theorem Nm_eq (s u : Fin 4 → ℝ) : Nm s u = NmBracket.Nm s u := rfl

theorem dot_eq (a b : Fin 4 → ℝ) : dot a b = NmBracket.dot a b := rfl

/-! ## One alias with `κ⁺` -/

/-- **`alias_term_le_kplus`**: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 κ⁺_ζ Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_kplus (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * kplus (fun ν => Real.sin (θ ν) ^ 2) ζ *
        ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  set σ : Fin 4 → ℝ := fun ν => Real.sin (θ ν) ^ 2 with hσ
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb : ∀ ν, sR θ ζ ν ^ 2 ≤ 1 := fun ν => by
    unfold sR; exact Real.sin_sq_le_one _
  have hbm : ∀ ν, sR θ ζ ν ^ 2 ≤ BM σ ζ := fun ν => by
    rw [sR_sq]; exact bb_le_BM σ ζ ν
  have hK := NmBracket.Nm_sq_le_kplus hb hbm (by rw [← dot_eq]; exact hw)
  have hX : NmBracket.Xs (sR θ ζ) = XX σ ζ := by
    unfold NmBracket.Xs XX; exact Finset.sum_congr rfl fun ν _ => sR_sq θ ζ ν
  have hS : NmBracket.Sb (sR θ ζ) = SS σ ζ := by
    unfold NmBracket.Sb SS
    exact Finset.sum_congr rfl fun ν _ => by
      rw [← sR_sq]; ring
  rw [hX, hS] at hK
  have e : dot w w = ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * u μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  have hk : kplus σ ζ = max (NmBracket.llo (XX σ ζ) (BM σ ζ) (SS σ ζ) ^ 2)
      (NmBracket.lup (XX σ ζ) (SS σ ζ) ^ 2) := rfl
  rw [← dot_eq, ← dot_eq, ← Nm_eq, ← hk, e] at hK
  linarith

/-! ## The coefficient identity and (OS↑) -/

theorem coef_eq (σ : Fin 4 → ℝ) (hH : HH σ ≠ 0) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹ =
      EE σ μ / (4 * omQ σ) := by
  unfold EE
  rw [omQ_eq, Finset.mul_sum, Finset.sum_div]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [wa_eq, omR_eq]
  field_simp

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **(OS↑)**: `𝓜(P/ω) ≼ P/ω` when every `E_ν ≤ 4`. -/
theorem os_up (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_kplus (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hH : HH σ ≠ 0 := by rw [omQ_eq] at hω'; intro h; rw [h] at hω'; simp at hω'
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) *
        u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ *
      (omR σ ζ)⁻¹) * u μ ^ 2 ≤ ∑ μ, (omQ σ)⁻¹ * u μ ^ 2 := by
    refine Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)
    rw [coef_eq σ hH μ]
    have h4 : 0 < 4 * omQ σ := by linarith
    rw [div_le_iff₀ h4]
    have := hEE q μ
    have e : (omQ σ)⁻¹ * (4 * omQ σ) = 4 := by field_simp
    linarith
  have hRHS : ⟪x, (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ =
      (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-- `Adm` of (same text). -/
def Adm (s : Fin 4 → ℝ) : Prop := ∀ μ, 0 ≤ s μ ∧ s μ ≤ 1/2

theorem sin_sq_le_half {x : ℝ} (hx : |x| ≤ π / 4) : Real.sin x ^ 2 ≤ 1 / 2 := by
  have h := abs_le.mp hx
  have hc : 0 ≤ Real.cos (2 * x) :=
    Real.cos_nonneg_of_mem_Icc ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  have e : Real.sin x ^ 2 = 1 / 2 - Real.cos (2 * x) / 2 := by
    rw [Real.sin_sq, Real.cos_sq x]; ring
  rw [e]; linarith

/-- **(OS↑) with the free-stage input as a hypothesis in the exact form of 
`FreeStageOS.E_lt_four_s`** (`hE`), for momenta with `|θ_ν| ≤ π/4` (i.e. `|q_ν| ≤ π`). -/
theorem os_up_of_free (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hth : ∀ q ν, |th q ν| ≤ π / 4)
    (hE : ∀ {s : Fin 4 → ℝ}, Adm s → (∃ μ, 0 < s μ) → ∀ ν, EE s ν < 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  refine os_up th rq hrq hω fun q ν => le_of_lt (hE ?_ ?_ ν)
  · intro μ; exact ⟨sq_nonneg _, sin_sq_le_half (hth q μ)⟩
  · by_contra hne
    push_neg at hne
    have hz : ∀ μ, Real.sin (th q μ) = 0 := fun μ => by
      have := hne μ
      have h0 : Real.sin (th q μ) ^ 2 = 0 := le_antisymm this (sq_nonneg _)
      exact pow_eq_zero_iff (two_ne_zero) |>.mp h0
    have h0 : omF th q = 0 := by
      unfold omF sQ
      refine Finset.sum_eq_zero fun μ _ => ?_
      rw [Real.sin_two_mul, hz μ]; ring
    linarith [hω q]

open Filter Topology in
/-- **`transient_zero_concrete`**: with (OS↑) from `E_ν ≤ 4`, a Loewner-monotone `Ξ` along the
concrete stages decreases to its limit: `δ_k ≥ 0`, every transient term vanishes (`D₀ = 0`). -/
theorem transient_zero_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4)
    (Ξ : (Q → V →ₗ[ℝ] V) → ℝ) (hmono : ∀ A B, UniformBracket.Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
      atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) ∧
      max (-(Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) - binf)) 0 = 0 :=
  CouplingLimit.transient_zero (Mfam th rq) (Mfam_orderPreserving th rq)
    (os_up th rq hrq hω hEE) Ξ hmono hlim k

end OSUpBridge

-- ===== verbatim copy of an earlier file (without import and #print axioms) =====

/-!
# (OS↑) for the stage-0 free field: stages 2 and 3 

`G3(X) = U3(X)²/X = 1/X - 1 + 7X/16 - 3X²/32 + 9X³/1024` (for `X ≠ 0`).
With `c = (c_ν, c_1, c_2, c_3)`, `y_μ = c_μ/2`:
`E3_ν / H = Σ_{e=±} ((1 - e c_ν)/2) Σ_{ε ∈ {±}³} G3(2 + e c_ν/2 + ε·y)`.

* stage 3: at the smoothed point `c = (c_ν, t, t, t)`, `H·F < 4` unless `c = (1,1,1,1)`;
  the numerator `N(u,v)`, `u = 1 - c_ν`, `v = 1 - t`, has nonnegative Bernstein coefficients.
* stage 2: for fixed `c_ν` and `|c_o|`, the smoothed point is the maximum of `F`.
-/

noncomputable section
namespace FreeStageOS

/-- `G3(X) = U3(X)²/X` written out (equal for `X ≠ 0`) -/
def G3 (X : ℝ) : ℝ := X⁻¹ - 1 + 7/16*X - 3/32*X^2 + 9/1024*X^3

/-- `F` at the smoothed point `c = (c0, t, t, t)` -/
def Feq (c0 t : ℝ) : ℝ :=
  (1 - c0)/2 * (G3 (2 + c0/2 - 3*t/2) + 3*G3 (2 + c0/2 - t/2) + 3*G3 (2 + c0/2 + t/2)
      + G3 (2 + c0/2 + 3*t/2))
  + (1 + c0)/2 * (G3 (2 - c0/2 - 3*t/2) + 3*G3 (2 - c0/2 - t/2) + 3*G3 (2 - c0/2 + t/2)
      + G3 (2 - c0/2 + 3*t/2))

/-- the product of the eight denominators -/
def DD (c0 t : ℝ) : ℝ :=
  (2 + c0/2 - 3*t/2) * (2 + c0/2 - t/2) * (2 + c0/2 + t/2) * (2 + c0/2 + 3*t/2)
  * (2 - c0/2 - 3*t/2) * (2 - c0/2 - t/2) * (2 - c0/2 + t/2) * (2 - c0/2 + 3*t/2)
/-! ## (OS↑) stage 3: Bernstein form of the numerator at the smoothed point 

`N(u,v) = Σ_k C(14,k) u^k (1-u)^(14-k) p_k(v)`, and every `p_k` has nonnegative
Bernstein coefficients of degree 12 on `[0,1]`.
-/

/-- the coefficient of `u^0` in `N(u,v)` -/
def nr0 (v : ℝ) : ℝ :=
    (1053/32)*v^2 + (161325/256)*v^3 + (-28215/64)*v^4 + (-3235653/4096)*v^5 + (9880731/8192)*v^6
    + (-5767011/8192)*v^7 + (1681425/8192)*v^8 + (-781245/65536)*v^9 + (-1623969/131072)*v^10
    + (242757/65536)*v^11 + (-80919/262144)*v^12
/-- the coefficient of `u^1` in `N(u,v)` -/
def nr1 (v : ℝ) : ℝ :=
    (2655/16)*v + (325317/256)*v^2 + (-267453/256)*v^3 + (-5591859/4096)*v^4 + (1464309/512)*v^5
    + (-18506667/8192)*v^6 + (7873605/8192)*v^7 + (-14838471/65536)*v^8 + (727785/32768)*v^9
    + (287469/65536)*v^10 + (-59049/32768)*v^11 + (19683/131072)*v^12
/-- the coefficient of `u^2` in `N(u,v)` -/
def nr2 (v : ℝ) : ℝ :=
    (7797/32) + (253391/256)*v + (-597071/256)*v^2 + (3288575/2048)*v^3 + (6300967/8192)*v^4
    + (-16604091/8192)*v^5 + (12888969/8192)*v^6 + (-10711251/16384)*v^7 + (19775637/131072)*v^8
    + (-1077705/65536)*v^9 + (-217485/131072)*v^10 + (59049/65536)*v^11 + (-19683/262144)*v^12
/-- the coefficient of `u^3` in `N(u,v)` -/
def nr3 (v : ℝ) : ℝ :=
    (7871/256) + (-388059/256)*v + (4292405/2048)*v^2 + (-1309819/1024)*v^3 + (-80971/8192)*v^4
    + (4697469/8192)*v^5 + (-7114233/16384)*v^6 + (1398897/8192)*v^7 + (-2448657/65536)*v^8
    + (10935/2048)*v^9 + (-2187/4096)*v^10
/-- the coefficient of `u^4` in `N(u,v)` -/
def nr4 (v : ℝ) : ℝ :=
    (-91549/256) + (3870295/4096)*v + (-8553431/8192)*v^2 + (4775071/8192)*v^3 + (-834013/8192)*v^4
    + (-3661551/32768)*v^5 + (6303987/65536)*v^6 + (-1299267/32768)*v^7 + (2349027/262144)*v^8
    + (-10935/8192)*v^9 + (2187/16384)*v^10
/-- the coefficient of `u^5` in `N(u,v)` -/
def nr5 (v : ℝ) : ℝ :=
    (883129/4096) + (-360371/1024)*v + (2780247/8192)*v^2 + (-1501321/8192)*v^3
    + (2433667/32768)*v^4 + (-363393/16384)*v^5 + (260613/32768)*v^6 + (-29889/16384)*v^7
    + (29889/131072)*v^8
/-- the coefficient of `u^6` in `N(u,v)` -/
def nr6 (v : ℝ) : ℝ :=
    (-283595/8192) + (508671/8192)*v + (-616485/8192)*v^2 + (836949/16384)*v^3
    + (-1440051/65536)*v^4 + (208827/32768)*v^5 + (-116103/65536)*v^6 + (9963/32768)*v^7
    + (-9963/262144)*v^8
/-- the coefficient of `u^7` in `N(u,v)` -/
def nr7 (v : ℝ) : ℝ :=
    (-53473/8192) + (44615/8192)*v + (64287/16384)*v^2 + (-66979/8192)*v^3 + (129619/32768)*v^4
    + (-2349/2048)*v^5 + (783/4096)*v^6
/-- the coefficient of `u^8` in `N(u,v)` -/
def nr8 (v : ℝ) : ℝ :=
    (4573/1024) + (-332141/65536)*v + (274539/131072)*v^2 + (41329/65536)*v^3
    + (-103969/262144)*v^4 + (2349/16384)*v^5 + (-783/32768)*v^6
/-- the coefficient of `u^9` in `N(u,v)` -/
def nr9 (v : ℝ) : ℝ :=
    (-75223/65536) + (49505/32768)*v + (-58055/65536)*v^2 + (4275/32768)*v^3 + (-4275/131072)*v^4
/-- the coefficient of `u^10` in `N(u,v)` -/
def nr10 (v : ℝ) : ℝ :=
    (9505/131072) + (-11485/65536)*v + (13195/131072)*v^2 + (-855/65536)*v^3 + (855/262144)*v^4
/-- the coefficient of `u^11` in `N(u,v)` -/
def nr11 (v : ℝ) : ℝ :=
    (1083/65536) + (27/4096)*v + (-27/8192)*v^2
/-- the coefficient of `u^12` in `N(u,v)` -/
def nr12 (v : ℝ) : ℝ :=
    (-907/262144) + (-9/16384)*v + (9/32768)*v^2
/-- the coefficient of `u^13` in `N(u,v)` -/
def nr13 (v : ℝ) : ℝ :=
    (63/131072)
/-- the coefficient of `u^14` in `N(u,v)` -/
def nr14 (v : ℝ) : ℝ :=
    (-9/262144)
/-- the numerator `N(u,v)` in the power basis of `u` -/
def NN (u v : ℝ) : ℝ :=
    u^0*nr0 v + u^1*nr1 v + u^2*nr2 v + u^3*nr3 v + u^4*nr4 v + u^5*nr5 v + u^6*nr6 v + u^7*nr7 v + u^8*nr8 v + u^9*nr9 v + u^10*nr10 v + u^11*nr11 v + u^12*nr12 v + u^13*nr13 v + u^14*nr14 v
def pp0 (v : ℝ) : ℝ :=
    1*nr0 v
def pp1 (v : ℝ) : ℝ :=
    1*nr0 v + (1/14)*nr1 v
def pp2 (v : ℝ) : ℝ :=
    1*nr0 v + (1/7)*nr1 v + (1/91)*nr2 v
def pp3 (v : ℝ) : ℝ :=
    1*nr0 v + (3/14)*nr1 v + (3/91)*nr2 v + (1/364)*nr3 v
def pp4 (v : ℝ) : ℝ :=
    1*nr0 v + (2/7)*nr1 v + (6/91)*nr2 v + (1/91)*nr3 v + (1/1001)*nr4 v
def pp5 (v : ℝ) : ℝ :=
    1*nr0 v + (5/14)*nr1 v + (10/91)*nr2 v + (5/182)*nr3 v + (5/1001)*nr4 v + (1/2002)*nr5 v
def pp6 (v : ℝ) : ℝ :=
    1*nr0 v + (3/7)*nr1 v + (15/91)*nr2 v + (5/91)*nr3 v + (15/1001)*nr4 v + (3/1001)*nr5 v + (1/3003)*nr6 v
def pp7 (v : ℝ) : ℝ :=
    1*nr0 v + (1/2)*nr1 v + (3/13)*nr2 v + (5/52)*nr3 v + (5/143)*nr4 v + (3/286)*nr5 v + (1/429)*nr6 v + (1/3432)*nr7 v
def pp8 (v : ℝ) : ℝ :=
    1*nr0 v + (4/7)*nr1 v + (4/13)*nr2 v + (2/13)*nr3 v + (10/143)*nr4 v + (4/143)*nr5 v + (4/429)*nr6 v + (1/429)*nr7 v + (1/3003)*nr8 v
def pp9 (v : ℝ) : ℝ :=
    1*nr0 v + (9/14)*nr1 v + (36/91)*nr2 v + (3/13)*nr3 v + (18/143)*nr4 v + (9/143)*nr5 v + (4/143)*nr6 v + (3/286)*nr7 v + (3/1001)*nr8 v + (1/2002)*nr9 v
def pp10 (v : ℝ) : ℝ :=
    1*nr0 v + (5/7)*nr1 v + (45/91)*nr2 v + (30/91)*nr3 v + (30/143)*nr4 v + (18/143)*nr5 v + (10/143)*nr6 v + (5/143)*nr7 v + (15/1001)*nr8 v + (5/1001)*nr9 v + (1/1001)*nr10 v
def pp11 (v : ℝ) : ℝ :=
    1*nr0 v + (11/14)*nr1 v + (55/91)*nr2 v + (165/364)*nr3 v + (30/91)*nr4 v + (3/13)*nr5 v + (2/13)*nr6 v + (5/52)*nr7 v + (5/91)*nr8 v + (5/182)*nr9 v + (1/91)*nr10 v + (1/364)*nr11 v
def pp12 (v : ℝ) : ℝ :=
    1*nr0 v + (6/7)*nr1 v + (66/91)*nr2 v + (55/91)*nr3 v + (45/91)*nr4 v + (36/91)*nr5 v + (4/13)*nr6 v + (3/13)*nr7 v + (15/91)*nr8 v + (10/91)*nr9 v + (6/91)*nr10 v + (3/91)*nr11 v + (1/91)*nr12 v
def pp13 (v : ℝ) : ℝ :=
    1*nr0 v + (13/14)*nr1 v + (6/7)*nr2 v + (11/14)*nr3 v + (5/7)*nr4 v + (9/14)*nr5 v + (4/7)*nr6 v + (1/2)*nr7 v + (3/7)*nr8 v + (5/14)*nr9 v + (2/7)*nr10 v + (3/14)*nr11 v + (1/7)*nr12 v + (1/14)*nr13 v
def pp14 (v : ℝ) : ℝ :=
    1*nr0 v + 1*nr1 v + 1*nr2 v + 1*nr3 v + 1*nr4 v + 1*nr5 v + 1*nr6 v + 1*nr7 v + 1*nr8 v + 1*nr9 v + 1*nr10 v + 1*nr11 v + 1*nr12 v + 1*nr13 v + 1*nr14 v

theorem NN_bern (u v w : ℝ) (hw : w = 1 - u) :
    NN u v = 1*u^0*w^14*pp0 v
    + 14*u^1*w^13*pp1 v
    + 91*u^2*w^12*pp2 v
    + 364*u^3*w^11*pp3 v
    + 1001*u^4*w^10*pp4 v
    + 2002*u^5*w^9*pp5 v
    + 3003*u^6*w^8*pp6 v
    + 3432*u^7*w^7*pp7 v
    + 3003*u^8*w^6*pp8 v
    + 2002*u^9*w^5*pp9 v
    + 1001*u^10*w^4*pp10 v
    + 364*u^11*w^3*pp11 v
    + 91*u^12*w^2*pp12 v
    + 14*u^13*w^1*pp13 v
    + 1*u^14*w^0*pp14 v := by
  subst hw; unfold NN pp0 pp1 pp2 pp3 pp4 pp5 pp6 pp7 pp8 pp9 pp10 pp11 pp12 pp13 pp14; ring

theorem pp0_bern (v w : ℝ) (hw : w = 1 - v) :
    pp0 v = (1053/32)*v^2*w^10 + (245565/256)*v^3*w^9 + (1718145/256)*v^4*w^8 + (91415547/4096)*v^5*w^7
    + (353709909/8192)*v^6*w^6 + (433768365/8192)*v^7*w^5 + (348826905/8192)*v^8*w^4
    + (1470571875/65536)*v^9*w^3 + (979070625/131072)*v^10*w^2 + (93403125/65536)*v^11*w
    + (31134375/262144)*v^12 := by
  subst hw; unfold pp0 nr0; ring
theorem pp0_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp0 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp0_bern v w hwd]; positivity

theorem pp1_bern (v w : ℝ) (hw : w = 1 - v) :
    pp1 v = (2655/224)*v*w^11 + (910533/3584)*v^2*w^10 + (8760027/3584)*v^3*w^9 + (687134829/57344)*v^4*w^8
    + (970823685/28672)*v^5*w^7 + (6879531459/114688)*v^6*w^6 + (8008320441/114688)*v^7*w^5
    + (49895929641/917504)*v^8*w^4 + (1611594525/57344)*v^9*w^3 + (1061254905/114688)*v^10*w^2
    + (3148875/1792)*v^11*w + (1049625/7168)*v^12 := by
  subst hw; unfold pp1 nr0 nr1; ring
theorem pp1_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp1 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp1_bern v w hwd]; positivity

theorem pp2_bern (v w : ℝ) (hw : w = 1 - v) :
    pp2 v = (7797/2912)*w^12 + (1554143/23296)*v*w^11 + (17377391/23296)*v^2*w^10
    + (909068183/186368)*v^3*w^9 + (2064730723/106496)*v^4*w^8 + (36316474175/745472)*v^5*w^7
    + (288473581/3584)*v^6*w^6 + (1469913013/16384)*v^7*w^5 + (810789178903/11927552)*v^8*w^4
    + (919417355/26624)*v^9*w^3 + (4196922997/372736)*v^10*w^2 + (198391275/93184)*v^11*w
    + (66130425/372736)*v^12 := by
  subst hw; unfold pp2 nr0 nr1 nr2; ring
theorem pp2_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp2 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp2_bern v w hwd]; positivity

theorem pp3_bern (v w : ℝ) (hw : w = 1 - v) :
    pp3 v = (756383/93184)*w^12 + (15042669/93184)*v*w^11 + (156983819/106496)*v^2*w^10
    + (755132255/93184)*v^3*w^9 + (12144467207/425984)*v^4*w^8 + (197239974409/2981888)*v^5*w^7
    + (618850313065/5963776)*v^6*w^6 + (333358229287/2981888)*v^7*w^5
    + (1976029879567/23855104)*v^8*w^4 + (123714665135/2981888)*v^9*w^3
    + (80012946067/5963776)*v^10*w^2 + (942102495/372736)*v^11*w + (314034165/1490944)*v^12 := by
  subst hw; unfold pp3 nr0 nr1 nr2 nr3; ring
theorem pp3_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp3 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp3_bern v w hwd]; positivity

theorem pp4_bern (v w : ℝ) (hw : w = 1 - v) :
    pp4 v = (39537/2464)*w^12 + (13044133/45056)*v*w^11 + (19596568479/8200192)*v^2*w^10
    + (8892622793/745472)*v^3*w^9 + (1751143851/45056)*v^4*w^8 + (254448317703/2981888)*v^5*w^7
    + (1207358771859/9371648)*v^6*w^6 + (4434439444959/32800768)*v^7*w^5
    + (3689001238785/37486592)*v^8*w^4 + (1598184978855/32800768)*v^9*w^3
    + (146661655741/9371648)*v^10*w^2 + (12051044223/4100096)*v^11*w + (4017014741/16400384)*v^12 := by
  subst hw; unfold pp4 nr0 nr1 nr2 nr3 nr4; ring
theorem pp4_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp4 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp4_bern v w hwd]; positivity

theorem pp5_bern (v w : ℝ) (hw : w = 1 - v) :
    pp5 v = (30389327/1171456)*w^12 + (259027181/585728)*v*w^11 + (56341756893/16400384)*v^2*w^10
    + (264694512539/16400384)*v^3*w^9 + (3276505995951/65601536)*v^4*w^8
    + (1728958338543/16400384)*v^5*w^7 + (5073185233401/32800768)*v^6*w^6
    + (1302841881/8192)*v^7*w^5 + (7488373951257/65601536)*v^8*w^4 + (459173245625/8200192)*v^9*w^3
    + (293331676901/16400384)*v^10*w^2 + (858652107/256256)*v^11*w + (286217369/1025024)*v^12 := by
  subst hw; unfold pp5 nr0 nr1 nr2 nr3 nr4 nr5; ring
theorem pp5_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp5 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp5_bern v w hwd]; positivity

theorem pp6_bern (v w : ℝ) (hw : w = 1 - v) :
    pp6 v = (913376887/24600576)*w^12 + (714174733/1171456)*v*w^11 + (2331536267/512512)*v^2*w^10
    + (1009361223467/49201152)*v^3*w^9 + (4016894943053/65601536)*v^4*w^8
    + (2059485533551/16400384)*v^5*w^7 + (5913510576601/32800768)*v^6*w^6
    + (1496384654777/8200192)*v^7*w^5 + (653637280853/5046272)*v^8*w^4
    + (1551535199635/24600576)*v^9*w^3 + (328909913341/16400384)*v^10*w^2 + (73909823/19712)*v^11*w
    + (73909823/236544)*v^12 := by
  subst hw; unfold pp6 nr0 nr1 nr2 nr3 nr4 nr5 nr6; ring
theorem pp6_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp6 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp6_bern v w hwd]; positivity

theorem pp7_bern (v w : ℝ) (hw : w = 1 - v) :
    pp7 v = (124880909/2555904)*w^12 + (21970178147/28114944)*v*w^11 + (318799937549/56229888)*v^2*w^10
    + (698365192325/28114944)*v^3*w^9 + (738432379391/10223616)*v^4*w^8
    + (1019110914401/7028736)*v^5*w^7 + (2878356040811/14057472)*v^6*w^6
    + (89936865449/439296)*v^7*w^5 + (506261036393/3514368)*v^8*w^4 + (116027185/1664)*v^9*w^3
    + (5655761/256)*v^10*w^2 + (428859/104)*v^11*w + (142953/416)*v^12 := by
  subst hw; unfold pp7 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7; ring
theorem pp7_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp7 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp7_bern v w hwd]; positivity

theorem pp8_bern (v w : ℝ) (hw : w = 1 - v) :
    pp8 v = (1485576437/24600576)*w^12 + (26643026285/28114944)*v*w^11 + (378886566611/56229888)*v^2*w^10
    + (5690220823061/196804608)*v^3*w^9 + (64928477033989/787218432)*v^4*w^8
    + (728811943627/4472832)*v^5*w^7 + (1720024454975/7569408)*v^6*w^6
    + (692094053513/3075072)*v^7*w^5 + (3869296420169/24600576)*v^8*w^4
    + (9709192875/128128)*v^9*w^3 + (6135055119/256256)*v^10*w^2 + (35737641/8008)*v^11*w
    + (11912547/32032)*v^12 := by
  subst hw; unfold pp8 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8; ring
theorem pp8_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp8 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp8_bern v w hwd]; positivity

theorem pp9_bern (v w : ℝ) (hw : w = 1 - v) :
    pp9 v = (1331114775/18743296)*w^12 + (1638876289/1490944)*v*w^11 + (252661948503/32800768)*v^2*w^10
    + (20537032631/630784)*v^3*w^9 + (429136997349/4685824)*v^4*w^8
    + (733049588025/4100096)*v^5*w^7 + (2025317112723/8200192)*v^6*w^6
    + (15559297269/64064)*v^7*w^5 + (86531141205/512512)*v^8*w^4 + (185441535/2288)*v^9*w^3
    + (116916979/4576)*v^10*w^2 + (680358/143)*v^11*w + (113393/286)*v^12 := by
  subst hw; unfold pp9 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9; ring
theorem pp9_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp9 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp9_bern v w hwd]; positivity

theorem pp10_bern (v w : ℝ) (hw : w = 1 - v) :
    pp10 v = (10516351403/131203072)*w^12 + (1831616811/1490944)*v*w^11 + (279466446485/32800768)*v^2*w^10
    + (22472629763/630784)*v^3*w^9 + (3254054254271/32800768)*v^4*w^8
    + (787239665957/4100096)*v^5*w^7 + (2159955088439/8200192)*v^6*w^6
    + (16505166449/64064)*v^7*w^5 + (91431544913/512512)*v^8*w^4 + (195412275/2288)*v^9*w^3
    + (122997143/4576)*v^10*w^2 + (55014/11)*v^11*w + (9169/22)*v^12 := by
  subst hw; unfold pp10 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10; ring
theorem pp10_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp10 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp10_bern v w hwd]; positivity

theorem pp11_bern (v w : ℝ) (hw : w = 1 - v) :
    pp11 v = (160240443/1835008)*w^12 + (566346147/425984)*v*w^11 + (54603803941/5963776)*v^2*w^10
    + (1089674823/28672)*v^3*w^9 + (156694083355/1490944)*v^4*w^8 + (2355100381/11648)*v^5*w^7
    + (6430352095/23296)*v^6*w^6 + (97905233/364)*v^7*w^5 + (540847313/2912)*v^8*w^4
    + (1153700/13)*v^9*w^3 + (362650/13)*v^10*w^2 + (67440/13)*v^11*w + (5620/13)*v^12 := by
  subst hw; unfold pp11 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11; ring
theorem pp11_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp11 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp11_bern v w hwd]; positivity

theorem pp12_bern (v w : ℝ) (hw : w = 1 - v) :
    pp12 v = (169208321/1835008)*w^12 + (595606025/425984)*v*w^11 + (57177140431/5963776)*v^2*w^10
    + (1135871053/28672)*v^3*w^9 + (162634617961/1490944)*v^4*w^8 + (2435237167/11648)*v^5*w^7
    + (6628844581/23296)*v^6*w^6 + (100687547/364)*v^7*w^5 + (555236411/2912)*v^8*w^4
    + (1182940/13)*v^9*w^3 + (371558/13)*v^10*w^2 + (69072/13)*v^11*w + (5756/13)*v^12 := by
  subst hw; unfold pp12 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12; ring
theorem pp12_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp12 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp12_bern v w hwd]; positivity

theorem pp13_bern (v w : ℝ) (hw : w = 1 - v) :
    pp13 v = (6203295/65536)*w^12 + (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10
    + (10347939/256)*v^3*w^9 + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7
    + (9241883/32)*v^6*w^6 + 280436*v^7*w^5 + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2
    + 5376*v^11*w + 448*v^12 := by
  subst hw; unfold pp13 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13; ring
theorem pp13_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp13 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp13_bern v w hwd]; positivity

theorem pp14_bern (v w : ℝ) (hw : w = 1 - v) :
    pp14 v = (6203295/65536)*w^12 + (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10
    + (10347939/256)*v^3*w^9 + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7
    + (9241883/32)*v^6*w^6 + 280436*v^7*w^5 + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2
    + 5376*v^11*w + 448*v^12 := by
  subst hw; unfold pp14 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13 nr14; ring
theorem pp14_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp14 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp14_bern v w hwd]; positivity

theorem pp0_pos {v : ℝ} (hv0 : 0 < v) (hv1 : v ≤ 1) : 0 < pp0 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp0_bern v w hwd]
  have h1 : 0 < (31134375/262144)*v^12 := by positivity
  have h2 : 0 ≤ (1053/32)*v^2*w^10 + (245565/256)*v^3*w^9 + (1718145/256)*v^4*w^8 + (91415547/4096)*v^5*w^7
    + (353709909/8192)*v^6*w^6 + (433768365/8192)*v^7*w^5 + (348826905/8192)*v^8*w^4
    + (1470571875/65536)*v^9*w^3 + (979070625/131072)*v^10*w^2 + (93403125/65536)*v^11*w := by positivity
  linarith
theorem pp14_pos {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 < pp14 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp14_bern v w hwd]
  have h2 : 0 ≤ (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10 + (10347939/256)*v^3*w^9
    + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7 + (9241883/32)*v^6*w^6 + 280436*v^7*w^5
    + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2 + 5376*v^11*w := by positivity
  have h3 : 0 < (6203295/65536)*w^12 + 448*v^12 := by
    rcases eq_or_lt_of_le hv0 with h | h
    · have : w = 1 := by rw [hwd, ← h]; ring
      rw [this, ← h]; norm_num
    · have : 0 < v^12 := by positivity
      have : 0 ≤ w^12 := by positivity
      linarith
  linarith
/-- `(4 - H·F)·D = N(1 - c0, 1 - t)` at the smoothed point -/
theorem NN_eq (c0 t : ℝ) (h0 : (2 + c0/2 - 3*t/2) ≠ 0) (h1 : (2 + c0/2 - t/2) ≠ 0) (h2 : (2 + c0/2 + t/2) ≠ 0) (h3 : (2 + c0/2 + 3*t/2) ≠ 0) (h4 : (2 - c0/2 - 3*t/2) ≠ 0) (h5 : (2 - c0/2 - t/2) ≠ 0) (h6 : (2 - c0/2 + t/2) ≠ 0) (h7 : (2 - c0/2 + 3*t/2) ≠ 0) :
    (4 - (4 - c0^2 - 3*t^2) * Feq c0 t) * DD c0 t = NN (1 - c0) (1 - t) := by
  have e0 : (2 + c0/2 - 3*t/2) * (2 + c0/2 - 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h0
  have e1 : (2 + c0/2 - t/2) * (2 + c0/2 - t/2)⁻¹ = 1 := mul_inv_cancel₀ h1
  have e2 : (2 + c0/2 + t/2) * (2 + c0/2 + t/2)⁻¹ = 1 := mul_inv_cancel₀ h2
  have e3 : (2 + c0/2 + 3*t/2) * (2 + c0/2 + 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h3
  have e4 : (2 - c0/2 - 3*t/2) * (2 - c0/2 - 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h4
  have e5 : (2 - c0/2 - t/2) * (2 - c0/2 - t/2)⁻¹ = 1 := mul_inv_cancel₀ h5
  have e6 : (2 - c0/2 + t/2) * (2 - c0/2 + t/2)⁻¹ = 1 := mul_inv_cancel₀ h6
  have e7 : (2 - c0/2 + 3*t/2) * (2 - c0/2 + 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h7
  unfold Feq G3 DD NN nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13 nr14
  linear_combination (-(4 - c0^2 - 3*t^2)) * ((1 - c0)/2*((2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e0 + (1 - c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e1 + (1 - c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e2 + (1 - c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e3 + (1 + c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e4 + (1 + c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e5 + (1 + c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + 3*t/2))*e6 + (1 + c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2))*e7)

theorem NN_pos {u v : ℝ} (hu0 : 0 ≤ u) (hu1 : u ≤ 1) (hv0 : 0 ≤ v) (hv1 : v ≤ 1)
    (hne : 0 < u + v) : 0 < NN u v := by
  have hw : 0 ≤ 1 - u := by linarith
  rw [NN_bern u v (1 - u) rfl]
  have t0 : 0 ≤ 1*u^0*(1-u)^14*pp0 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp0_nonneg hv0 hv1)
  have t1 : 0 ≤ 14*u^1*(1-u)^13*pp1 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp1_nonneg hv0 hv1)
  have t2 : 0 ≤ 91*u^2*(1-u)^12*pp2 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp2_nonneg hv0 hv1)
  have t3 : 0 ≤ 364*u^3*(1-u)^11*pp3 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp3_nonneg hv0 hv1)
  have t4 : 0 ≤ 1001*u^4*(1-u)^10*pp4 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp4_nonneg hv0 hv1)
  have t5 : 0 ≤ 2002*u^5*(1-u)^9*pp5 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp5_nonneg hv0 hv1)
  have t6 : 0 ≤ 3003*u^6*(1-u)^8*pp6 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp6_nonneg hv0 hv1)
  have t7 : 0 ≤ 3432*u^7*(1-u)^7*pp7 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp7_nonneg hv0 hv1)
  have t8 : 0 ≤ 3003*u^8*(1-u)^6*pp8 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp8_nonneg hv0 hv1)
  have t9 : 0 ≤ 2002*u^9*(1-u)^5*pp9 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp9_nonneg hv0 hv1)
  have t10 : 0 ≤ 1001*u^10*(1-u)^4*pp10 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp10_nonneg hv0 hv1)
  have t11 : 0 ≤ 364*u^11*(1-u)^3*pp11 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp11_nonneg hv0 hv1)
  have t12 : 0 ≤ 91*u^12*(1-u)^2*pp12 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp12_nonneg hv0 hv1)
  have t13 : 0 ≤ 14*u^13*(1-u)^1*pp13 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp13_nonneg hv0 hv1)
  have t14 : 0 ≤ 1*u^14*(1-u)^0*pp14 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp14_nonneg hv0 hv1)
  rcases eq_or_lt_of_le hu0 with h | h
  · have hv : 0 < v := by linarith
    have hw1 : 0 < 1 - u := by linarith
    have s0 : 0 < 1*u^0*(1-u)^14*pp0 v :=
      mul_pos (mul_pos (by norm_num) (pow_pos hw1 _)) (pp0_pos hv hv1)
    linarith
  · have s14 : 0 < 1*u^14*(1-u)^0*pp14 v :=
      mul_pos (mul_pos (mul_pos (by norm_num) (pow_pos h _)) (by norm_num)) (pp14_pos hv0 hv1)
    linarith

theorem DD_pos {c0 t : ℝ} (hX0 : 0 < (2 + c0/2 - 3*t/2)) (hX1 : 0 < (2 + c0/2 - t/2)) (hX2 : 0 < (2 + c0/2 + t/2)) (hX3 : 0 < (2 + c0/2 + 3*t/2)) (hX4 : 0 < (2 - c0/2 - 3*t/2)) (hX5 : 0 < (2 - c0/2 - t/2)) (hX6 : 0 < (2 - c0/2 + t/2)) (hX7 : 0 < (2 - c0/2 + 3*t/2)) : 0 < DD c0 t := by
  unfold DD
  exact mul_pos (mul_pos (mul_pos (mul_pos (mul_pos (mul_pos (mul_pos hX0 hX1) hX2) hX3) hX4) hX5) hX6) hX7

/-- **stage 3**: at the smoothed point, `H·F < 4` unless `c0 = t = 1` -/
theorem eq_lt_four {c0 t : ℝ} (hc0 : 0 ≤ c0) (hc1 : c0 ≤ 1) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hne : c0 + 3*t < 4) : (4 - c0^2 - 3*t^2) * Feq c0 t < 4 := by

  have hX0 : 0 < (2 + c0/2 - 3*t/2) := by linarith
  have hX1 : 0 < (2 + c0/2 - t/2) := by linarith
  have hX2 : 0 < (2 + c0/2 + t/2) := by linarith
  have hX3 : 0 < (2 + c0/2 + 3*t/2) := by linarith
  have hX4 : 0 < (2 - c0/2 - 3*t/2) := by linarith
  have hX5 : 0 < (2 - c0/2 - t/2) := by linarith
  have hX6 : 0 < (2 - c0/2 + t/2) := by linarith
  have hX7 : 0 < (2 - c0/2 + 3*t/2) := by linarith
  have hD := DD_pos hX0 hX1 hX2 hX3 hX4 hX5 hX6 hX7
  have hN := NN_pos (u := 1 - c0) (v := 1 - t) (by linarith) (by linarith) (by linarith) (by linarith)
    (by linarith)
  have hE := NN_eq c0 t (ne_of_gt hX0) (ne_of_gt hX1) (ne_of_gt hX2) (ne_of_gt hX3)
    (ne_of_gt hX4) (ne_of_gt hX5) (ne_of_gt hX6) (ne_of_gt hX7)
  rw [← hE] at hN
  by_contra hc
  rw [not_lt] at hc
  nlinarith [hc, hD, hN]

/-! ## (OS↑) stage 2: smoothing `c_o` at fixed `c_ν` and `|c_o|` 

`Fo b y = Σ_{ε ∈ {±}³} G3(b + ε·y)` splits as `Inv b y + PP b |y|²`: the cubic part of `G3`
only sees `|y|²`.  The pair sum `PS B y1 y2 = Σ_{±,±} 1/(B ± y1 ± y2)` equals
`2B/(A - 2p) + 2B/(A + 2p)` with `A = B² - (y1² + y2²)`, `p = y1 y2`, so at fixed `y1² + y2²`
it increases with `p`.  Two such steps carry `(y1, y2, y3)` to `(m, m, m)`, `3m² = |y|²`.
-/

/-- the eight aliases with `e_ν` fixed -/
def Fo (b y1 y2 y3 : ℝ) : ℝ :=
  G3 (b + y1 + y2 + y3) + G3 (b + y1 + y2 - y3) + G3 (b + y1 - y2 + y3) + G3 (b + y1 - y2 - y3)
  + G3 (b - y1 + y2 + y3) + G3 (b - y1 + y2 - y3) + G3 (b - y1 - y2 + y3) + G3 (b - y1 - y2 - y3)

/-- the `1/X` part of `Fo` -/
def Inv (b y1 y2 y3 : ℝ) : ℝ :=
  (b + y1 + y2 + y3)⁻¹ + (b + y1 + y2 - y3)⁻¹ + (b + y1 - y2 + y3)⁻¹ + (b + y1 - y2 - y3)⁻¹
  + (b - y1 + y2 + y3)⁻¹ + (b - y1 + y2 - y3)⁻¹ + (b - y1 - y2 + y3)⁻¹ + (b - y1 - y2 - y3)⁻¹

/-- the cubic part of `Fo`, a function of `b` and `S = |y|²` only -/
def PP (b S : ℝ) : ℝ := 8*(-1 + 7/16*b - 3/32*b^2 + 9/1024*b^3) + 4*(-3/16 + 27/512*b)*S

/-- `F(c) = E3_ν/H` in the momentum form, `c = (c_ν, c_1, c_2, c_3)` -/
def FF (c0 c1 c2 c3 : ℝ) : ℝ :=
  (1 - c0)/2 * Fo (2 + c0/2) (c1/2) (c2/2) (c3/2) + (1 + c0)/2 * Fo (2 - c0/2) (c1/2) (c2/2) (c3/2)

/-- the pair sum -/
def PS (B y1 y2 : ℝ) : ℝ := (B + y1 + y2)⁻¹ + (B + y1 - y2)⁻¹ + (B - y1 + y2)⁻¹ + (B - y1 - y2)⁻¹

theorem Fo_split (b y1 y2 y3 : ℝ) : Fo b y1 y2 y3 = Inv b y1 y2 y3 + PP b (y1^2 + y2^2 + y3^2) := by
  unfold Fo Inv PP G3; ring

theorem FF_eq (c0 t : ℝ) : FF c0 t t t = Feq c0 t := by
  unfold FF Fo Feq G3; ring

theorem Inv_pair12 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = PS (b + y3) y1 y2 + PS (b - y3) y1 y2 := by
  unfold Inv PS; ring

theorem Inv_pair23 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = PS (b + y1) y2 y3 + PS (b - y1) y2 y3 := by
  unfold Inv PS; ring

theorem Inv_swap23 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = Inv b y1 y3 y2 := by
  unfold Inv; ring

theorem PS_closed {B y1 y2 : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hB : y1 + y2 < B) :
    PS B y1 y2 = 2*B/(B^2 - (y1^2 + y2^2) - 2*(y1*y2)) + 2*B/(B^2 - (y1^2 + y2^2) + 2*(y1*y2)) := by
  have h1 : 0 < B + y1 + y2 := by linarith
  have h2 : 0 < B + y1 - y2 := by linarith
  have h3 : 0 < B - y1 + y2 := by linarith
  have h4 : 0 < B - y1 - y2 := by linarith
  have d1 : B^2 - (y1^2 + y2^2) - 2*(y1*y2) = (B + y1 + y2) * (B - y1 - y2) := by ring
  have d2 : B^2 - (y1^2 + y2^2) + 2*(y1*y2) = (B + y1 - y2) * (B - y1 + y2) := by ring
  rw [d1, d2]
  unfold PS
  field_simp
  ring

theorem pair_mono {B A p p' : ℝ} (hB : 0 < B) (hp : 0 ≤ p) (hpp : p ≤ p') (hA : 2*p' < A) :
    2*B/(A - 2*p) + 2*B/(A + 2*p) ≤ 2*B/(A - 2*p') + 2*B/(A + 2*p') := by
  have a1 : 0 < A - 2*p := by linarith
  have a2 : 0 < A + 2*p := by linarith
  have a3 : 0 < A - 2*p' := by linarith
  have a4 : 0 < A + 2*p' := by linarith
  rw [div_add_div _ _ (ne_of_gt a1) (ne_of_gt a2), div_add_div _ _ (ne_of_gt a3) (ne_of_gt a4),
    div_le_div_iff₀ (mul_pos a1 a2) (mul_pos a3 a4)]
  have hBA : 0 ≤ B * A := by nlinarith
  have hq : 0 ≤ p'^2 - p^2 := by nlinarith
  nlinarith [mul_nonneg hBA hq]

theorem PS_le {B y1 y2 z1 z2 : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hz1 : 0 ≤ z1) (hz2 : 0 ≤ z2)
    (hS : y1^2 + y2^2 = z1^2 + z2^2) (hp : y1*y2 ≤ z1*z2) (hB : z1 + z2 < B) :
    PS B y1 y2 ≤ PS B z1 z2 := by
  have hsq : (y1 + y2)^2 ≤ (z1 + z2)^2 := by nlinarith
  have hyz : y1 + y2 ≤ z1 + z2 := (sq_le_sq₀ (by linarith) (by linarith)).mp hsq
  rw [PS_closed hy1 hy2 (by linarith), PS_closed hz1 hz2 hB, hS]
  exact pair_mono (by linarith) (mul_nonneg hy1 hy2) hp (by nlinarith)

/-- one smoothing: if `(y1² - m²)(y2² - m²) ≤ 0`, two pair steps reach `(m, m, m)` -/
theorem Inv_smooth_core {b y1 y2 y3 m : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hy3 : 0 ≤ y3)
    (hm0 : 0 ≤ m) (hm : 3*m^2 = y1^2 + y2^2 + y3^2) (hd : (y1^2 - m^2)*(y2^2 - m^2) ≤ 0)
    (hb : 3*m < b) : Inv b y1 y2 y3 ≤ Inv b m m m := by
  have hW : 0 ≤ y1^2 + y2^2 - m^2 := by
    by_contra hc
    rw [not_le] at hc
    have e1 : 0 < m^2 - y1^2 := by nlinarith
    have e2 : 0 < m^2 - y2^2 := by nlinarith
    nlinarith [mul_pos e1 e2]
  set w := Real.sqrt (y1^2 + y2^2 - m^2) with hwdef
  have hw0 : 0 ≤ w := Real.sqrt_nonneg _
  have hw2 : w^2 = y1^2 + y2^2 - m^2 := Real.sq_sqrt hW
  have hmw : y1*y2 ≤ m*w := by
    have : (y1*y2)^2 ≤ (m*w)^2 := by rw [mul_pow, mul_pow, hw2]; nlinarith
    exact (sq_le_sq₀ (mul_nonneg hy1 hy2) (mul_nonneg hm0 hw0)).mp this
  have hcs : y3 + m + w ≤ 3*m := by
    have : (y3 + m + w)^2 ≤ (3*m)^2 := by
      nlinarith [sq_nonneg (y3 - m), sq_nonneg (y3 - w), sq_nonneg (m - w)]
    exact (sq_le_sq₀ (by linarith) (by linarith)).mp this
  have step1 : Inv b y1 y2 y3 ≤ Inv b m w y3 := by
    rw [Inv_pair12, Inv_pair12 b m w y3]
    have hS : y1^2 + y2^2 = m^2 + w^2 := by rw [hw2]; ring
    exact add_le_add (PS_le hy1 hy2 hm0 hw0 hS hmw (by linarith))
      (PS_le hy1 hy2 hm0 hw0 hS hmw (by linarith))
  have step2 : Inv b m w y3 ≤ Inv b m m m := by
    rw [Inv_pair23, Inv_pair23 b m m m]
    have hS : w^2 + y3^2 = m^2 + m^2 := by rw [hw2]; linarith
    have hp : w*y3 ≤ m*m := by nlinarith [sq_nonneg (w - y3)]
    exact add_le_add (PS_le hw0 hy3 hm0 hm0 hS hp (by linarith))
      (PS_le hw0 hy3 hm0 hm0 hS hp (by linarith))
  exact le_trans step1 step2

theorem Inv_smooth {b y1 y2 y3 m : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hy3 : 0 ≤ y3)
    (hm0 : 0 ≤ m) (hm : 3*m^2 = y1^2 + y2^2 + y3^2) (hb : 3*m < b) :
    Inv b y1 y2 y3 ≤ Inv b m m m := by
  by_cases hd : (y1^2 - m^2)*(y2^2 - m^2) ≤ 0
  · exact Inv_smooth_core hy1 hy2 hy3 hm0 hm hd hb
  · rw [not_le] at hd
    have hd' : (y1^2 - m^2)*(y3^2 - m^2) ≤ 0 := by
      have : y3^2 - m^2 = -((y1^2 - m^2) + (y2^2 - m^2)) := by linarith
      rw [this]; nlinarith [sq_nonneg (y1^2 - m^2)]
    rw [Inv_swap23]
    exact Inv_smooth_core hy1 hy3 hy2 hm0 (by linarith) hd' hb

/-- **stage 2**: at fixed `c0` and `c1² + c2² + c3² = 3t²`, the smoothed point is the maximum -/
theorem FF_smooth {c0 c1 c2 c3 t : ℝ} (hc0 : 0 ≤ c0) (hc0' : c0 ≤ 1) (hc1 : 0 ≤ c1) (hc2 : 0 ≤ c2)
    (hc3 : 0 ≤ c3) (ht0 : 0 ≤ t) (ht : 3*t^2 = c1^2 + c2^2 + c3^2) (hne : c0 + 3*t < 4) :
    FF c0 c1 c2 c3 ≤ FF c0 t t t := by
  unfold FF
  simp only [Fo_split]
  have hS : (c1/2)^2 + (c2/2)^2 + (c3/2)^2 = (t/2)^2 + (t/2)^2 + (t/2)^2 := by nlinarith
  rw [hS]
  have hm : 3*(t/2)^2 = (c1/2)^2 + (c2/2)^2 + (c3/2)^2 := by nlinarith
  have i1 := Inv_smooth (b := 2 + c0/2) (by linarith) (by linarith) (by linarith) (by linarith) hm
    (by linarith)
  have i2 := Inv_smooth (b := 2 - c0/2) (by linarith) (by linarith) (by linarith) (by linarith) hm
    (by linarith)
  have w1 : 0 ≤ (1 - c0)/2 := by linarith
  have w2 : 0 ≤ (1 + c0)/2 := by linarith
  nlinarith [mul_le_mul_of_nonneg_left i1 w1, mul_le_mul_of_nonneg_left i2 w2]

end FreeStageOS

/-! ## Stage 1 (copied from an earlier file `TauStageZero`, only the parts used by `EE_le_E3`) -/

namespace TauStageZero

open Finset

def llo (X bm sb : ℝ) : ℝ := 1 - 1/2*((1 - 5/24*X)*X + 5/24*(X*bm + sb))
def lup (X sb : ℝ) : ℝ := min (1 - 7/24*X) (1 - (X - X^2/4 + sb/4)/2)

theorem sum_cons_bool {n : ℕ} (F : (Fin (n+1) → Bool) → ℝ) :
    ∑ e, F e = ∑ y, F (Fin.cons true y) + ∑ y, F (Fin.cons false y) := by
  rw [← (Fin.consEquiv (fun _ => Bool)).sum_comp]
  simp [Fintype.sum_prod_type]
  rfl

theorem sum0_bool (F : (Fin 0 → Bool) → ℝ) : ∑ e, F e = F ![] := by
  rw [Fintype.sum_unique]; congr 1

theorem sum16 (F : (Fin 4 → Bool) → ℝ) : ∑ e, F e =
    F ![true,true,true,true] + F ![true,true,true,false] + F ![true,true,false,true]
    + F ![true,true,false,false] + F ![true,false,true,true] + F ![true,false,true,false]
    + F ![true,false,false,true] + F ![true,false,false,false] + F ![false,true,true,true]
    + F ![false,true,true,false] + F ![false,true,false,true] + F ![false,true,false,false]
    + F ![false,false,true,true] + F ![false,false,true,false] + F ![false,false,false,true]
    + F ![false,false,false,false] := by
  simp only [sum_cons_bool, sum0_bool, add_assoc]
  rfl

def Adm (s : Fin 4 → ℝ) : Prop := ∀ μ, 0 ≤ s μ ∧ s μ ≤ 1/2
def bb (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (μ : Fin 4) : ℝ := if e μ then 1 - s μ else s μ
def XX (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, bb s e μ
def SS (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, (bb s e μ)^2
def BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max (max (bb s e 0) (bb s e 1)) (max (bb s e 2) (bb s e 3))
def HH (s : Fin 4 → ℝ) : ℝ := 4 * ∑ μ, s μ * (1 - s μ)
def lamLo (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := llo (XX s e) (BM s e) (SS s e)
def lamUp (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := lup (XX s e) (SS s e)
def kplus (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := max ((lamLo s e)^2) ((lamUp s e)^2)

theorem llo_le_lup {X bm S2 : ℝ} (hX0 : 0 ≤ X) (hX4 : X ≤ 4)
    (hS1 : X^2/4 ≤ S2) (hS2 : S2 ≤ X*bm) : llo X bm S2 ≤ lup X S2 := by
  unfold llo lup
  apply le_min
  · nlinarith
  · nlinarith

theorem llo_ge {X bm S2 : ℝ} (hX : 0 ≤ X) (hbm : bm ≤ 1) (hS : S2 ≤ X) : -(49/240) ≤ llo X bm S2 := by
  unfold llo
  have : X*bm ≤ X := by nlinarith
  nlinarith [sq_nonneg (X - 17/5)]

section
variable {s : Fin 4 → ℝ} (hs : Adm s) (e : Fin 4 → Bool)
include hs

theorem bb_nonneg (μ : Fin 4) : 0 ≤ bb s e μ := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_le_one (μ : Fin 4) : bb s e μ ≤ 1 := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_ge_s (μ : Fin 4) : s μ ≤ bb s e μ := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_le_BM (μ : Fin 4) : bb s e μ ≤ BM s e := by
  unfold BM; fin_cases μ <;> simp
theorem BM_le_one : BM s e ≤ 1 := by
  unfold BM
  exact max_le (max_le (bb_le_one hs e 0) (bb_le_one hs e 1))
    (max_le (bb_le_one hs e 2) (bb_le_one hs e 3))
theorem XX_nonneg : 0 ≤ XX s e := by
  unfold XX; exact Finset.sum_nonneg (fun μ _ => bb_nonneg hs e μ)
theorem XX_le_four : XX s e ≤ 4 := by
  unfold XX; simp only [Fin.sum_univ_four]
  linarith [bb_le_one hs e 0, bb_le_one hs e 1, bb_le_one hs e 2, bb_le_one hs e 3]
theorem SS_le_XX : SS s e ≤ XX s e := by
  unfold XX SS
  apply Finset.sum_le_sum; intro μ _
  nlinarith [bb_nonneg hs e μ, bb_le_one hs e μ]
theorem SS_cs : (XX s e)^2/4 ≤ SS s e := by
  unfold XX SS; simp only [Fin.sum_univ_four]
  nlinarith [sq_nonneg (bb s e 0 - bb s e 1), sq_nonneg (bb s e 0 - bb s e 2),
    sq_nonneg (bb s e 0 - bb s e 3), sq_nonneg (bb s e 1 - bb s e 2),
    sq_nonneg (bb s e 1 - bb s e 3), sq_nonneg (bb s e 2 - bb s e 3)]
theorem SS_le_XBM : SS s e ≤ XX s e * BM s e := by
  unfold XX SS; rw [Finset.sum_mul]
  apply Finset.sum_le_sum; intro μ _
  nlinarith [bb_nonneg hs e μ, bb_le_BM hs e μ]
end

/-- `U3(X) = 1 - X/2 + 3X²/32`: the upper end `λ_up` with `Σ b² ≥ X²/4` inserted -/
def U3 (X : ℝ) : ℝ := 1 - X/2 + 3*X^2/32

/-- `E_ν = Σ_e (H/X_e) κ⁺_e (1 - b_{e,ν})` (Theorem 3, refined brackets) -/
def EE (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := ∑ e, HH s / XX s e * kplus s e * (1 - bb s e ν)

/-- the majorant `E3_ν = Σ_e (H/X_e) U3(X_e)² (1 - b_{e,ν})` -/
def E3 (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  ∑ e, HH s / XX s e * (U3 (XX s e))^2 * (1 - bb s e ν)

theorem U3_ge (X : ℝ) : 1/3 ≤ U3 X := by
  unfold U3; nlinarith [sq_nonneg (X - 8/3)]

theorem kplus_le_U3 {s : Fin 4 → ℝ} (hs : Adm s) (e : Fin 4 → Bool) :
    kplus s e ≤ (U3 (XX s e))^2 := by
  have l1 : lamLo s e ≤ lamUp s e :=
    llo_le_lup (XX_nonneg hs e) (XX_le_four hs e) (SS_cs hs e) (SS_le_XBM hs e)
  have l4 : -(49/240) ≤ lamLo s e := llo_ge (XX_nonneg hs e) (BM_le_one hs e) (SS_le_XX hs e)
  have hup : lamUp s e ≤ U3 (XX s e) := by
    unfold lamUp lup U3
    apply le_trans (min_le_right _ _)
    nlinarith [SS_cs hs e]
  have hU := U3_ge (XX s e)
  unfold kplus
  apply max_le
  · nlinarith
  · nlinarith

theorem HH_nonneg {s : Fin 4 → ℝ} (hs : Adm s) : 0 ≤ HH s := by
  unfold HH
  apply mul_nonneg (by norm_num)
  exact Finset.sum_nonneg (fun μ _ => mul_nonneg (hs μ).1 (by linarith [(hs μ).2]))

/-- **step 1** : `E_ν ≤ E3_ν` for every admissible `s` -/
theorem EE_le_E3 {s : Fin 4 → ℝ} (hs : Adm s) (ν : Fin 4) : EE s ν ≤ E3 s ν := by
  unfold EE E3
  apply Finset.sum_le_sum; intro e _
  have h1 : 0 ≤ HH s / XX s e := div_nonneg (HH_nonneg hs) (XX_nonneg hs e)
  have h2 : 0 ≤ 1 - bb s e ν := by linarith [bb_le_one hs e ν]
  exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (kplus_le_U3 hs e) h1) h2

end TauStageZero

/-! ## Joining the three stages: `E_ν < 4` for every `q ≠ 0`  -/

namespace FreeStageOS

open TauStageZero

theorem XX_pos {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (e : Fin 4 → Bool) :
    0 < XX s e := by
  obtain ⟨μ, hμ⟩ := hne
  have h : s μ ≤ XX s e :=
    le_trans (bb_ge_s hs e μ)
      (Finset.single_le_sum (f := fun μ => bb s e μ) (fun μ _ => bb_nonneg hs e μ)
        (Finset.mem_univ μ))
  linarith

theorem E3_term (H X w : ℝ) (hX : X ≠ 0) : H / X * (U3 X)^2 * w = H * (G3 X * w) := by
  unfold U3 G3; field_simp; ring

theorem E3_G3 {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (ν : Fin 4) :
    E3 s ν = HH s * ∑ e, G3 (XX s e) * (1 - bb s e ν) := by
  unfold E3; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl (fun e _ => E3_term _ _ _ (ne_of_gt (XX_pos hs hne e)))

theorem sumG3_FF0 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 0)) = FF (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 2) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF1 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 1)) = FF (1 - 2*s 1) (1 - 2*s 0) (1 - 2*s 2) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF2 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 2)) = FF (1 - 2*s 2) (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF3 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 3)) = FF (1 - 2*s 3) (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 2) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sq0 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 2)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq1 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 1)^2 + (1 - 2*s 0)^2 + (1 - 2*s 2)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq2 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 2)^2 + (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq3 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 3)^2 + (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 2)^2 := by
  simp only [Fin.sum_univ_four] <;> ring

/-- the sixteen aliases regrouped by `e_ν`: `Σ_e G3(X_e)(1 - b_{e,ν}) = F(c)`, `c = 1 - 2s` -/
theorem sumG3_FF (s : Fin 4 → ℝ) (ν : Fin 4) : ∃ a b d : Fin 4,
    (∑ e, G3 (XX s e) * (1 - bb s e ν)) = FF (1 - 2*s ν) (1 - 2*s a) (1 - 2*s b) (1 - 2*s d) ∧
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s ν)^2 + (1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2 := by
  fin_cases ν
  · exact ⟨1, 2, 3, sumG3_FF0 s, sq0 s⟩
  · exact ⟨0, 2, 3, sumG3_FF1 s, sq1 s⟩
  · exact ⟨0, 1, 3, sumG3_FF2 s, sq2 s⟩
  · exact ⟨0, 1, 2, sumG3_FF3 s, sq3 s⟩

theorem HH_c (s : Fin 4 → ℝ) : HH s = 4 - ∑ μ, (1 - 2*s μ)^2 := by
  simp only [HH, Fin.sum_univ_four]; ring

theorem csq_lt {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) : ∑ μ, (1 - 2*s μ)^2 < 4 := by
  obtain ⟨μ, hμ⟩ := hne
  have h : ∑ μ, (1 - 2*s μ)^2 < ∑ _μ : Fin 4, (1:ℝ) := by
    apply Finset.sum_lt_sum
    · intro i _
      have := hs i
      nlinarith
    · refine ⟨μ, Finset.mem_univ μ, ?_⟩
      have := hs μ
      nlinarith
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin] at h
  norm_num at h
  exact h

/-- **(OS↑) at stage 0, scalar form**: `E_ν < 4` for every admissible `s ≠ 0` and every `ν` -/
theorem E_lt_four_s {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (ν : Fin 4) :
    EE s ν < 4 := by
  obtain ⟨a, b, d, hF, hsq⟩ := sumG3_FF s ν
  have hc : ∀ μ, 0 ≤ 1 - 2*s μ ∧ 1 - 2*s μ ≤ 1 := fun μ =>
    ⟨by linarith [(hs μ).2], by linarith [(hs μ).1]⟩
  have hlt := csq_lt hs hne
  rw [hsq] at hlt
  have hT : 0 ≤ ((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3 := by positivity
  obtain ⟨t, htd⟩ : ∃ t, t = Real.sqrt (((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3) :=
    ⟨_, rfl⟩
  have ht0 : 0 ≤ t := by rw [htd]; exact Real.sqrt_nonneg _
  have ht2 : t^2 = ((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3 := by
    rw [htd]; exact Real.sq_sqrt hT
  have ha := hc a
  have hb := hc b
  have hd := hc d
  have hn := hc ν
  have ht1 : t ≤ 1 := by nlinarith
  have hne' : (1 - 2*s ν) + 3*t < 4 := by nlinarith
  have hsm := FF_smooth hn.1 hn.2 ha.1 hb.1 hd.1 ht0 (by rw [ht2]; ring) hne'
  have hs3 := eq_lt_four hn.1 hn.2 ht0 ht1 hne'
  calc EE s ν ≤ E3 s ν := EE_le_E3 hs ν
    _ = HH s * FF (1 - 2*s ν) (1 - 2*s a) (1 - 2*s b) (1 - 2*s d) := by rw [E3_G3 hs hne, hF]
    _ ≤ HH s * FF (1 - 2*s ν) t t t := mul_le_mul_of_nonneg_left hsm (HH_nonneg hs)
    _ = (4 - (1 - 2*s ν)^2 - 3*t^2) * Feq (1 - 2*s ν) t := by rw [FF_eq, HH_c, hsq, ht2]; ring
    _ < 4 := hs3

/-- **(OS↑) at stage 0**: with `s_μ = (1 - cos(q_μ/2))/2`, `E_ν < 4` for every
`q ∈ [-π, π]⁴ ∖ {0}` and every `ν` -/
theorem E_lt_four (q : Fin 4 → ℝ) (hq : ∀ μ, |q μ| ≤ Real.pi) (hq0 : q ≠ 0) (ν : Fin 4) :
    EE (fun μ => (1 - Real.cos (q μ / 2))/2) ν < 4 := by
  apply E_lt_four_s
  · intro μ
    have h := abs_le.mp (hq μ)
    have hc0 : 0 ≤ Real.cos (q μ / 2) :=
      Real.cos_nonneg_of_mem_Icc ⟨by linarith, by linarith⟩
    have hc1 := Real.cos_le_one (q μ / 2)
    constructor <;> simp only <;> linarith
  · obtain ⟨μ, hμ⟩ := Function.ne_iff.mp hq0
    refine ⟨μ, ?_⟩
    have h := abs_le.mp (hq μ)
    have hpi := Real.pi_pos
    have hne1 : Real.cos (q μ / 2) ≠ 1 := by
      intro h1
      have := (Real.cos_eq_one_iff_of_lt_of_lt (x := q μ / 2) (by linarith) (by linarith)).mp h1
      apply hμ; simp only [Pi.zero_apply]; linarith
    have hc1 := Real.cos_le_one (q μ / 2)
    have : Real.cos (q μ / 2) < 1 := lt_of_le_of_ne hc1 hne1
    show 0 < (1 - Real.cos (q μ / 2))/2
    linarith

end FreeStageOS


-- ===== new part : OSUpFree.part.lean =====
/-! # L2 seam (b): (OS↑) from the free-stage bound, in one file (plan-20 §4c)

Paper (for checking): The definitions `EE`, `Adm` (and below them `bb`,
`XX`, `SS`, `BM`, `HH`, `lamLo`, `lamUp`, `kplus`, `llo`, `lup`) of `OSUpBridge` (All1135) and of
 `TauStageZero` are the same text; here they are identified by `rfl` (`EE_eq`), and
**`os_up_free`** is `OSUpBridge.os_up_of_free` with its input `hE` supplied by 
`FreeStageOS.E_lt_four_s`. **`hEE_free`**: the `hEE` of `coupling_converges_*` for momenta with
`|θ_ν| ≤ π/4`. -/

namespace OSUpFree

theorem EE_eq (s : Fin 4 → ℝ) (ν : Fin 4) : OSUpBridge.EE s ν = TauStageZero.EE s ν := rfl

theorem Adm_iff (s : Fin 4 → ℝ) : OSUpBridge.Adm s ↔ TauStageZero.Adm s := Iff.rfl

theorem os_up_free {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = OneStepBridge.thR (th q) ζ) (hω : ∀ q, 0 < OneStepET.omF th q)
    (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4) :
    UniformBracket.Lw (OneStepBridge.Mfam th rq
        (fun q => (OneStepET.omF th q)⁻¹ • OneStepBridge.Pfam th q))
      (fun q => (OneStepET.omF th q)⁻¹ • OneStepBridge.Pfam th q) :=
  OSUpBridge.os_up_of_free th rq hrq hω hth
    (fun hs hne ν => by rw [EE_eq]; exact FreeStageOS.E_lt_four_s hs hne ν)

theorem hEE_free {Q : Type*} (th : Q → (Fin 4 → ℝ)) (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4)
    (q : Q) (ν : Fin 4) : OSUpBridge.EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4 := by
  have hadm : TauStageZero.Adm (fun ν => Real.sin (th q ν) ^ 2) :=
    fun μ => ⟨sq_nonneg _, OSUpBridge.sin_sq_le_half (hth q μ)⟩
  by_cases hne : ∃ μ, 0 < Real.sin (th q μ) ^ 2
  · rw [EE_eq]; exact (FreeStageOS.E_lt_four_s hadm hne ν).le
  · push_neg at hne
    have h0 : ∀ μ, Real.sin (th q μ) ^ 2 = 0 := fun μ => le_antisymm (hne μ) (sq_nonneg _)
    simp only [OSUpBridge.EE, OSUpBridge.HH, h0, zero_mul, mul_zero, Finset.sum_const_zero,
      zero_div, sub_zero]
    norm_num

end OSUpFree

#print axioms OSUpFree.EE_eq
#print axioms OSUpFree.os_up_free
#print axioms OSUpFree.hEE_free

-- ===== new part : OSUpQpos.part.lean =====
/-! # T0: (OS↑) on the whole of `Qpos`, with no hypotheses

The statements `OSUpFree.os_up_free` and
`OSUpBridge.os_up_of_free` above take both `hrq` (the family is closed under the aliases
`thR θ ζ = θ/2 + ζπ/4`) and `hth : ∀ q ν, |th q ν| ≤ π/4`; for a nonempty `Q` these are
incompatible (two alias steps with `ζ ≡ true` leave the box), so those two statements are vacuous
on any nonempty family (`box_alias_closed_empty` below). `OSUpFree.hEE_free` takes no `hrq` and is a
true statement about points in the box only.

Here the input `hEE` of `OSUpBridge.os_up` is discharged at **every** point:
* `EE_bbflip`: `EE` is invariant under `s ↦ (bb s f ·)` (flip the coordinates in `f`, `s_μ ↦ 1 − s_μ`),
  because `bb (bb s f) e = bb s (e xor f)` and `e ↦ e xor f` is a bijection of `{0,1}⁴`;
* `EE_flip`: the one-coordinate form;
* `hEE_all`: `EE (sin² θ) ν ≤ 4` for every `θ` (fold to `min(s, 1 − s)`, which is `Adm`, and use
  `FreeStageOS.E_lt_four_s`; the case `s′ = 0` gives `EE = 0`);
* `os_up_Qpos`: `𝓜(P/ω) ≼ P/ω` on `Qpos` with the aliases `rqPos` (no hypotheses);
* `Gs_le_G0`: `𝓜^k(P/ω) ≼ P/ω` for every `k` (`C₊ = 1` at every stage). -/

namespace OSUpQpos

open Finset OneStepBridge OneStepET OneStepFinal

/-- `e xor f`, coordinatewise. -/
def bxor (e f : Fin 4 → Bool) : Fin 4 → Bool := fun j => xor (e j) (f j)

theorem bxor_invol (f : Fin 4 → Bool) : Function.Involutive (fun e => bxor e f) := by
  intro e; funext j; simp [bxor]

theorem bb_bb (s : Fin 4 → ℝ) (f e : Fin 4 → Bool) (j : Fin 4) :
    OSUpBridge.bb (fun i => OSUpBridge.bb s f i) e j = OSUpBridge.bb s (bxor e f) j := by
  unfold OSUpBridge.bb bxor
  cases h1 : e j <;> cases h2 : f j <;> simp [h1, h2]

theorem HH_bb (s : Fin 4 → ℝ) (f : Fin 4 → Bool) :
    OSUpBridge.HH (fun i => OSUpBridge.bb s f i) = OSUpBridge.HH s := by
  unfold OSUpBridge.HH
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  unfold OSUpBridge.bb
  cases h : f j <;> simp [h] <;> ring

/-- **`EE` is invariant under flipping any set of coordinates `s_μ ↦ 1 − s_μ`.** -/
theorem EE_bbflip (s : Fin 4 → ℝ) (f : Fin 4 → Bool) (ν : Fin 4) :
    OSUpBridge.EE (fun i => OSUpBridge.bb s f i) ν = OSUpBridge.EE s ν := by
  have hX : ∀ e, OSUpBridge.XX (fun i => OSUpBridge.bb s f i) e = OSUpBridge.XX s (bxor e f) :=
    fun e => by unfold OSUpBridge.XX; simp only [bb_bb]
  have hS : ∀ e, OSUpBridge.SS (fun i => OSUpBridge.bb s f i) e = OSUpBridge.SS s (bxor e f) :=
    fun e => by unfold OSUpBridge.SS; simp only [bb_bb]
  have hB : ∀ e, OSUpBridge.BM (fun i => OSUpBridge.bb s f i) e = OSUpBridge.BM s (bxor e f) :=
    fun e => by unfold OSUpBridge.BM; simp only [bb_bb]
  have hK : ∀ e, OSUpBridge.kplus (fun i => OSUpBridge.bb s f i) e =
      OSUpBridge.kplus s (bxor e f) := fun e => by
    unfold OSUpBridge.kplus OSUpBridge.lamLo OSUpBridge.lamUp
    rw [hX, hS, hB]
  unfold OSUpBridge.EE
  rw [HH_bb]
  simp only [hX, hK, bb_bb]
  exact Fintype.sum_equiv (bxor_invol f).toPerm _ _ (fun e => rfl)

/-- **`EE_flip`** : one coordinate. -/
theorem EE_flip (s : Fin 4 → ℝ) (μ ν : Fin 4) :
    OSUpBridge.EE (Function.update s μ (1 - s μ)) ν = OSUpBridge.EE s ν := by
  have h : Function.update s μ (1 - s μ) =
      fun i => OSUpBridge.bb s (fun j => decide (j = μ)) i := by
    funext i
    by_cases hi : i = μ
    · subst hi; simp [OSUpBridge.bb]
    · simp [OSUpBridge.bb, Function.update, hi]
  rw [h, EE_bbflip]

/-- `hEE` at every `θ`, from the free-stage bound on the admissible set (as a hypothesis `hE`,
in the exact form of `FreeStageOS.E_lt_four_s`). -/
theorem hEE_all_of
    (hE : ∀ {s : Fin 4 → ℝ}, OSUpBridge.Adm s → (∃ μ, 0 < s μ) → ∀ ν, OSUpBridge.EE s ν < 4)
    (θ : Fin 4 → ℝ) (ν : Fin 4) :
    OSUpBridge.EE (fun ν => Real.sin (θ ν) ^ 2) ν ≤ 4 := by
  set s : Fin 4 → ℝ := fun ν => Real.sin (θ ν) ^ 2 with hs_def
  have hs : ∀ j, 0 ≤ s j ∧ s j ≤ 1 := fun j =>
    ⟨sq_nonneg _, Real.sin_sq_le_one _⟩
  set f : Fin 4 → Bool := fun j => decide (1 / 2 < s j) with hf_def
  have hadm : OSUpBridge.Adm (fun i => OSUpBridge.bb s f i) := by
    intro j
    show 0 ≤ OSUpBridge.bb s f j ∧ OSUpBridge.bb s f j ≤ 1 / 2
    have hv : OSUpBridge.bb s f j = if 1 / 2 < s j then 1 - s j else s j := by
      simp [OSUpBridge.bb, hf_def]
    rw [hv]
    by_cases hj : 1 / 2 < s j
    · rw [if_pos hj]; constructor <;> linarith [(hs j).2]
    · rw [if_neg hj]; push_neg at hj; constructor <;> linarith [(hs j).1]
  rw [← EE_bbflip s f ν]
  by_cases hne : ∃ μ, 0 < OSUpBridge.bb s f μ
  · exact (hE hadm hne ν).le
  · push_neg at hne
    have h0 : ∀ μ, OSUpBridge.bb s f μ = 0 := fun μ => le_antisymm (hne μ) (hadm μ).1
    have hH : OSUpBridge.HH (fun i => OSUpBridge.bb s f i) = 0 := by
      unfold OSUpBridge.HH; simp [h0]
    unfold OSUpBridge.EE
    rw [hH]
    simp

/-- **`hEE_all`** : `E_ν ≤ 4` at every momentum (no box, no `ω > 0` needed). -/
theorem hEE_all (θ : Fin 4 → ℝ) (ν : Fin 4) :
    OSUpBridge.EE (fun ν => Real.sin (θ ν) ^ 2) ν ≤ 4 :=
  hEE_all_of (fun hs hne ν => by
    rw [OSUpFree.EE_eq]; exact FreeStageOS.E_lt_four_s hs hne ν) θ ν

/-- **(OS↑) for any alias-closed family with `ω > 0`**: no box hypothesis. -/
theorem os_up_family {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) :=
  OSUpBridge.os_up th rq hrq hω fun q ν => hEE_all (th q) ν

/-- **`os_up_Qpos`** : (OS↑) on `Qpos`, no hypotheses. -/
theorem os_up_Qpos :
    UniformBracket.Lw (Mfam (Subtype.val : Qpos → _) rqPos
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) :=
  os_up_family Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2)

/-- **`Gs_le_G0`** : every stage `G_k = 𝓜^k(P/ω) ≼ P/ω` on `Qpos` (`C₊ = 1`). -/
theorem Gs_le_G0 (k : ℕ) :
    UniformBracket.Lw ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) := by
  induction k with
  | zero => exact UniformBracket.Lw.refl _
  | succ k ih =>
    exact UniformBracket.Lw.trans
      (UniformBracket.iterate_antitone (Mfam Subtype.val rqPos)
        (Mfam_orderPreserving Subtype.val rqPos) os_up_Qpos k) ih

/-- The family version of `Gs_le_G0`. -/
theorem Gs_le_G0_family {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) (k : ℕ) :
    UniformBracket.Lw ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  induction k with
  | zero => exact UniformBracket.Lw.refl _
  | succ k ih =>
    exact UniformBracket.Lw.trans
      (UniformBracket.iterate_antitone (Mfam th rq) (Mfam_orderPreserving th rq)
        (os_up_family th rq hrq hω) k) ih

/-- **Why `os_up_free` / `os_up_of_free` are vacuous**: an alias-closed family whose every member
lies in the box `|θ_ν| ≤ π/4` is empty. -/
theorem box_alias_closed_empty {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4) :
    IsEmpty Q := by
  refine ⟨fun q => ?_⟩
  have h2 := hth (rq (rq q fun _ => true) fun _ => true) 0
  have h0 := hth q 0
  rw [hrq, hrq] at h2
  simp only [thR, if_true] at h2
  have := (abs_le.mp h0).1
  have := (abs_le.mp h2).2
  linarith [Real.pi_pos]

end OSUpQpos

#print axioms OSUpQpos.EE_flip
#print axioms OSUpQpos.hEE_all
#print axioms OSUpQpos.os_up_Qpos
#print axioms OSUpQpos.Gs_le_G0
#print axioms OSUpQpos.Gs_le_G0_family
#print axioms OSUpQpos.box_alias_closed_empty

-- ===== new part : TauSplit.part.lean =====
/-! # T2: (H-τ) on the concrete family, uniformly in the stage

Paper: `τ_k^{(m)}` is the least `τ` with
`𝓜^m(ω·G_k) ≼ τ·ω·G_{k+m}`, `G_k = 𝓜^k(P/ω)`.
* `iterate_split` (T2a, abstract): `M = M₀ + M₁`, both order preserving, `0 ≼ F ≼ P′` ⇒
  `M^m F ≼ M₀^m F + M^m P′`.
* `M0fam` / `M1fam`: the nearest-alias term `ζ = ζ*(q)` of `𝓜` and the other fifteen.
* `omF_chain_le`: along the nearest-alias chain, `ω(ch^m q) ≤ (π²/4)·4^{−m}·ω(q)` (exact constants;
  `4cos²(π/2^{j+2})` per step and the finite Viète product `Π cos(π/2^{j+2}) ≥ 2/π`).
* `tau_stage_uniform_of_low` (T2b): with the lower side `c·G₀ ≼ G_k` as the only input,
  `⟪x, 𝓜^m(ω G_k)(q) x⟫ ≤ ((π²/4)(1/4)^m + (1/c)(3/5)^m)·ω(q)⟪x, G_{k+m}(q) x⟫`; the upper side is
  `OSUpQpos.Gs_le_G0_family` (T0) and the contraction is `Mfam_P_le_row` (3/5).
* `tau_stage_uniform` (T2b on `Qpos`, no hypotheses): the input discharged by `lower_side`
  (`c = (4/π²)·0.04452²`), and `tau_stage_25`: `τ_k^{(25)} < 1/170` for every `k`. -/


/-! Copy of `CornerNear.cos_prod`, `cos_prod_ge` (same text): the finite Viète product. -/
namespace CornerNearCopy

open Finset Real

theorem cos_prod (J : ℕ) :
    2 ^ J * Real.sin (π / 2 ^ (J + 1)) * ∏ i ∈ range J, Real.cos (π / 2 ^ (i + 2)) = 1 := by
  induction J with
  | zero => simp [Real.sin_pi_div_two]
  | succ J ih =>
    rw [prod_range_succ, show J + 1 + 1 = J + 2 by ring]
    have e : π / 2 ^ (J + 1) = 2 * (π / 2 ^ (J + 2)) := by
      rw [show J + 2 = (J + 1) + 1 by ring, pow_succ]; field_simp; ring
    rw [e, Real.sin_two_mul] at ih
    rw [pow_succ]
    linear_combination ih

theorem cos_prod_ge (J : ℕ) : 2 / π ≤ ∏ i ∈ range J, Real.cos (π / 2 ^ (i + 2)) := by
  have h := cos_prod J
  set P := ∏ i ∈ range J, Real.cos (π / 2 ^ (i + 2))
  have hy0 : 0 < π / 2 ^ (J + 1) := by positivity
  have hylt : π / 2 ^ (J + 1) < π := by
    rw [div_lt_iff₀ (by positivity)]
    have : (1 : ℝ) < 2 ^ (J + 1) := one_lt_pow₀ (by norm_num) (by omega)
    nlinarith [pi_pos]
  have hs0 : 0 < Real.sin (π / 2 ^ (J + 1)) := Real.sin_pos_of_pos_of_lt_pi hy0 hylt
  have hs1 : Real.sin (π / 2 ^ (J + 1)) ≤ π / 2 ^ (J + 1) := Real.sin_le hy0.le
  have h2 : (0 : ℝ) < 2 ^ J := by positivity
  have ha : 2 ^ J * Real.sin (π / 2 ^ (J + 1)) ≤ π / 2 := by
    calc 2 ^ J * Real.sin (π / 2 ^ (J + 1)) ≤ 2 ^ J * (π / 2 ^ (J + 1)) :=
          mul_le_mul_of_nonneg_left hs1 h2.le
      _ = π / 2 := by rw [pow_succ]; field_simp
  have hapos : 0 < 2 ^ J * Real.sin (π / 2 ^ (J + 1)) := mul_pos h2 hs0
  have hP : 0 < P := by
    by_contra hn; push_neg at hn
    have : 2 ^ J * Real.sin (π / 2 ^ (J + 1)) * P ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hapos.le hn
    linarith
  rw [div_le_iff₀ pi_pos]
  nlinarith

end CornerNearCopy

namespace TauSplit

open Finset UniformBracket
open scoped Real RealInnerProductSpace

section Abstract

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- **`iterate_split`**. -/
theorem iterate_split {M M0 M1 : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E)} (hM : M = M0 + M1)
    (h0 : OrderPreserving M0) (h1 : OrderPreserving M1) {F P' : Q → E →ₗ[ℝ] E}
    (hF0 : Lw 0 F) (hFP : Lw F P') (m : ℕ) :
    Lw ((⇑M)^[m] F) ((⇑M0)^[m] F + (⇑M)^[m] P') := by
  have hMop : OrderPreserving M := by
    intro A B hAB q x
    have a := h0 A B hAB q x
    have b := h1 A B hAB q x
    subst hM
    simp only [LinearMap.add_apply, Pi.add_apply, inner_add_right]
    linarith
  have hit : ∀ j, Lw ((⇑M)^[j] F) ((⇑M)^[j] P') := by
    intro j
    induction j with
    | zero => exact hFP
    | succ j ih =>
      rw [Function.iterate_succ_apply', Function.iterate_succ_apply']
      exact hMop _ _ ih
  have hP0 : Lw 0 P' := hF0.trans hFP
  have hneg : ∀ j, Lw 0 ((⇑M0)^[j] P') := nonneg_iterate M0 h0 hP0
  -- claim: M^j F + M0^j P' ≼ M0^j F + M^j P'
  have claim : ∀ j, Lw ((⇑M)^[j] F + (⇑M0)^[j] P') ((⇑M0)^[j] F + (⇑M)^[j] P') := by
    intro j
    induction j with
    | zero =>
      intro q x
      simp only [Function.iterate_zero, id, Pi.add_apply, LinearMap.add_apply, inner_add_right]
      linarith
    | succ j ih =>
      intro q x
      have a := h0 _ _ ih q x
      have b := h1 _ _ (hit j) q x
      simp only [map_add, Pi.add_apply, LinearMap.add_apply, inner_add_right] at a
      simp only [Function.iterate_succ_apply', Pi.add_apply, LinearMap.add_apply, inner_add_right]
      subst hM
      simp only [LinearMap.add_apply, Pi.add_apply, inner_add_right]
      linarith
  intro q x
  have c := claim m q x
  have d := hneg m q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right, Pi.zero_apply,
    LinearMap.zero_apply, inner_zero_right] at c d ⊢
  linarith

end Abstract

section Concrete

open OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower Matrix

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The stage covariances `G_k = 𝓜^k(P/ω)` (same text as `Gs` of the Glue/XCoord files). -/
def Gs (k : ℕ) : Q → V →ₗ[ℝ] V :=
  (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)

/-- The nearest alias `ζ*(q)` (`zstar` of `sin²`, = `zs` of the Glue/XCoord files). -/
def zq (q : Q) : Fin 4 → Bool := zstar fun ν => Real.sin (th q ν) ^ 2

/-- One step down the nearest-alias chain. -/
def ch (q : Q) : Q := rq q (zq th q)

/-- **`M₀`**: the nearest-alias term of `𝓜`. -/
def M0fam : (Q → V →ₗ[ℝ] V) →ₗ[ℝ] (Q → V →ₗ[ℝ] V) where
  toFun G q := (1 / 16 : ℝ) •
    (Matrix.toEuclideanLin (AM (th q) (zq th q)) ∘ₗ G (rq q (zq th q)) ∘ₗ
      Matrix.toEuclideanLin (AtM (th q) (zq th q)))
  map_add' G H := by
    funext q
    simp only [Pi.add_apply, LinearMap.add_comp, LinearMap.comp_add, smul_add]
  map_smul' c G := by
    funext q
    simp only [Pi.smul_apply, RingHom.id_apply, LinearMap.smul_comp, LinearMap.comp_smul,
      smul_comm c (1 / 16 : ℝ)]

/-- **`M₁ = 𝓜 − M₀`**: the other fifteen aliases. -/
def M1fam : (Q → V →ₗ[ℝ] V) →ₗ[ℝ] (Q → V →ₗ[ℝ] V) := Mfam th rq - M0fam th rq

theorem Mfam_split : Mfam th rq = M0fam th rq + M1fam th rq := by
  unfold M1fam; abel

theorem M0_inner (G : Q → V →ₗ[ℝ] V) (q : Q) (x : V) :
    ⟪x, M0fam th rq G q x⟫ = (1 / 16) *
      ⟪Matrix.toEuclideanLin (AtM (th q) (zq th q)) x,
        G (rq q (zq th q)) (Matrix.toEuclideanLin (AtM (th q) (zq th q)) x)⟫ := by
  show ⟪x, ((1 / 16 : ℝ) • (Matrix.toEuclideanLin (AM (th q) (zq th q)) ∘ₗ
      G (rq q (zq th q)) ∘ₗ Matrix.toEuclideanLin (AtM (th q) (zq th q)))) x⟫ = _
  rw [LinearMap.smul_apply, real_inner_smul_right]
  congr 1
  simp only [LinearMap.comp_apply]
  exact inner_toE _ _ (AM_transpose (th q) (zq th q)) _ _

theorem M1_inner (G : Q → V →ₗ[ℝ] V) (q : Q) (x : V) :
    ⟪x, M1fam th rq G q x⟫ = (1 / 16) * ∑ ζ ∈ (univ : Finset (Fin 4 → Bool)).erase (zq th q),
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
  have h : ⟪x, M1fam th rq G q x⟫ = ⟪x, Mfam th rq G q x⟫ - ⟪x, M0fam th rq G q x⟫ := by
    unfold M1fam
    simp only [LinearMap.sub_apply, Pi.sub_apply, inner_sub_right]
  rw [h, Mfam_inner, M0_inner, ← Finset.add_sum_erase _ _ (Finset.mem_univ (zq th q))]
  ring

theorem M0_op : OrderPreserving (M0fam th rq) := by
  intro A B hAB q x
  rw [M0_inner, M0_inner]
  exact mul_le_mul_of_nonneg_left (hAB _ _) (by norm_num)

theorem M1_op : OrderPreserving (M1fam th rq) := by
  intro A B hAB q x
  rw [M1_inner, M1_inner]
  gcongr with ζ
  exact hAB _ _

/-- `M₀` moves a scalar weight one step down the chain. -/
theorem M0_smul (c : Q → ℝ) (G : Q → V →ₗ[ℝ] V) :
    M0fam th rq (fun q => c q • G q) = fun q => c (ch th rq q) • M0fam th rq G q := by
  funext q
  show (1 / 16 : ℝ) • (Matrix.toEuclideanLin (AM (th q) (zq th q)) ∘ₗ
      (c (rq q (zq th q)) • G (rq q (zq th q))) ∘ₗ Matrix.toEuclideanLin (AtM (th q) (zq th q))) =
    c (rq q (zq th q)) • ((1 / 16 : ℝ) • (Matrix.toEuclideanLin (AM (th q) (zq th q)) ∘ₗ
      G (rq q (zq th q)) ∘ₗ Matrix.toEuclideanLin (AtM (th q) (zq th q))))
  rw [LinearMap.smul_comp, LinearMap.comp_smul, smul_comm]

theorem M0_iter_smul (c : Q → ℝ) (G : Q → V →ₗ[ℝ] V) (m : ℕ) :
    (⇑(M0fam th rq))^[m] (fun q => c q • G q) =
      fun q => c ((ch th rq)^[m] q) • (⇑(M0fam th rq))^[m] G q := by
  induction m with
  | zero => rfl
  | succ m ih =>
    rw [Function.iterate_succ_apply', ih, M0_smul, Function.iterate_succ_apply']
    funext q
    rw [Function.iterate_succ_apply]

/-! ### The weight along the nearest-alias chain -/

theorem sQ_sq_sigma (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * Real.sin (θ ν) ^ 2 * (1 - Real.sin (θ ν) ^ 2) := by
  unfold sQ
  rw [Real.sin_two_mul]
  have := Real.sin_sq_add_cos_sq (θ ν)
  have hc : Real.cos (θ ν) ^ 2 = 1 - Real.sin (θ ν) ^ 2 := by linarith
  calc (2 * Real.sin (θ ν) * Real.cos (θ ν)) ^ 2
      = 4 * Real.sin (θ ν) ^ 2 * Real.cos (θ ν) ^ 2 := by ring
    _ = _ := by rw [hc]

/-- One alias step, per coordinate: `sQ(θ)² = 4u(1 − u)` with `u = sQ(r_ζ)²` (any `ζ`). -/
theorem sQ_alias_rel (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * sQ (thR θ ζ) ν ^ 2 * (1 - sQ (thR θ ζ) ν ^ 2) := by
  rw [sQ_thR, sQ_sq_sigma]
  have hx := xs_alias θ ζ ν
  unfold xs at hx
  cases hz : ζ ν
  · rw [hz] at hx; simp only [xa] at hx
    have : sR θ ζ ν ^ 2 = Real.sin (θ ν) ^ 2 := by linarith
    rw [this]
  · rw [hz] at hx; simp only [xa] at hx
    have : sR θ ζ ν ^ 2 = 1 - Real.sin (θ ν) ^ 2 := by linarith
    rw [this]; ring

theorem chain_scale (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) :
    ∀ j ν, sQ (th ((ch th rq)^[j] q)) ν ^ 2 ≤ bS j := by
  intro j
  induction j with
  | zero => exact fun ν => scale_zero th ((ch th rq)^[0] q) ν
  | succ j ih =>
    intro ν
    rw [Function.iterate_succ_apply']
    unfold ch zq
    rw [hrq, sQ_thR]
    exact alias_scale _ j ih ν

theorem one_sub_bS (j : ℕ) : 1 - bS (j + 1) = Real.cos (π / 2 ^ (j + 2)) ^ 2 := by
  unfold bS
  rw [show j + 1 + 1 = j + 2 by ring]
  have := Real.sin_sq_add_cos_sq (π / 2 ^ (j + 2))
  linarith

/-- One step of the chain: `4cos²(π/2^{j+2})·ω(ch^{j+1} q) ≤ ω(ch^j q)`. -/
theorem omF_step (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (j : ℕ) :
    4 * Real.cos (π / 2 ^ (j + 2)) ^ 2 * omF th ((ch th rq)^[j + 1] q) ≤
      omF th ((ch th rq)^[j] q) := by
  have hs := chain_scale th rq hrq q (j + 1)
  rw [← one_sub_bS]
  unfold omF
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  have hrel := sQ_alias_rel (th ((ch th rq)^[j] q)) (zq th ((ch th rq)^[j] q)) ν
  have e : th ((ch th rq)^[j + 1] q) =
      thR (th ((ch th rq)^[j] q)) (zq th ((ch th rq)^[j] q)) := by
    rw [Function.iterate_succ_apply']; unfold ch; rw [hrq]
  rw [e] at hs ⊢
  have hu := hs ν
  set u := sQ (thR (th ((ch th rq)^[j] q)) (zq th ((ch th rq)^[j] q))) ν ^ 2
  have hu0 : 0 ≤ u := sq_nonneg _
  rw [hrel]
  nlinarith

theorem omF_nonneg' (q : Q) : 0 ≤ omF th q := by
  unfold omF; positivity

/-- **`omF_chain_le`**: `ω(ch^m q) ≤ (π²/4)·(1/4)^m·ω(q)` (exact constants). -/
theorem omF_chain_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (m : ℕ) :
    omF th ((ch th rq)^[m] q) ≤ Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m * omF th q := by
  have key : ∀ m, omF th ((ch th rq)^[m] q) *
      (4 ^ m * (∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) ^ 2) ≤ omF th q := by
    intro m
    induction m with
    | zero => simp
    | succ m ih =>
      have hs := omF_step th rq hrq q m
      have hP : 0 ≤ 4 ^ m * (∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) ^ 2 := by positivity
      rw [Finset.prod_range_succ, pow_succ]
      calc omF th ((ch th rq)^[m + 1] q) * (4 ^ m * 4 *
            ((∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) * Real.cos (π / 2 ^ (m + 2))) ^ 2)
          = (4 * Real.cos (π / 2 ^ (m + 2)) ^ 2 * omF th ((ch th rq)^[m + 1] q)) *
            (4 ^ m * (∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) ^ 2) := by ring
        _ ≤ omF th ((ch th rq)^[m] q) *
            (4 ^ m * (∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) ^ 2) :=
          mul_le_mul_of_nonneg_right hs hP
        _ ≤ _ := ih
  have hk := key m
  have hc := CornerNearCopy.cos_prod_ge m
  have hpi := Real.pi_pos
  have h2pi : 0 < 2 / π := by positivity
  have hsq : (2 / π) ^ 2 ≤ (∏ i ∈ range m, Real.cos (π / 2 ^ (i + 2))) ^ 2 :=
    pow_le_pow_left₀ h2pi.le hc 2
  have hω := omF_nonneg' th ((ch th rq)^[m] q)
  have h4 : (0 : ℝ) < 4 ^ m := by positivity
  have hlow : omF th ((ch th rq)^[m] q) * (4 ^ m * (2 / π) ^ 2) ≤ omF th q :=
    le_trans (mul_le_mul_of_nonneg_left
      (mul_le_mul_of_nonneg_left hsq h4.le) hω) hk
  have e : Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m * (4 ^ m * (2 / π) ^ 2) = 1 := by
    rw [one_div, inv_pow]; field_simp <;> norm_num
  have hpos : 0 < 4 ^ m * (2 / π) ^ 2 := by positivity
  calc omF th ((ch th rq)^[m] q)
      = omF th ((ch th rq)^[m] q) * (4 ^ m * (2 / π) ^ 2) *
          (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m) := by
        rw [mul_assoc, mul_comm (4 ^ m * (2 / π) ^ 2), e, mul_one]
    _ ≤ omF th q * (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m) :=
        mul_le_mul_of_nonneg_right hlow (by positivity)
    _ = _ := by ring

/-! ### The stage-uniform τ -/

theorem G0_nonneg : UniformBracket.Lw 0 (fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
    real_inner_smul_right]
  exact mul_nonneg (inv_nonneg.mpr (omF_nonneg' th q)) (inner_P_nonneg th q x)

/-- **`tau_stage_uniform_of_low`** (any alias-closed family with `ω > 0`): the only
input is the lower side `c·G₀ ≼ G_k` (every `k`). Upper side: T0; contraction: `Mfam_P_le_row`. -/
theorem tau_stage_uniform_of_low (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (hω : ∀ q, 0 < omF th q) {c : ℝ} (hc : 0 < c)
    (hlow : ∀ k, UniformBracket.Lw (c • fun q => (omF th q)⁻¹ • Pfam th q) (Gs th rq k))
    (k m : ℕ) (q : Q) (x : V) :
    ⟪x, ((⇑(Mfam th rq))^[m] (fun q => omF th q • Gs th rq k q)) q x⟫ ≤
      (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m + (1 / c) * (3 / 5 : ℝ) ^ m) *
        (omF th q * ⟪x, Gs th rq (k + m) q x⟫) := by
  set G0 : Q → V →ₗ[ℝ] V := fun q => (omF th q)⁻¹ • Pfam th q with hG0
  have hGk0 : ∀ j, UniformBracket.Lw 0 (Gs th rq j) := fun j =>
    nonneg_iterate (Mfam th rq) (Mfam_orderPreserving th rq) (G0_nonneg th) j
  have hup : UniformBracket.Lw (Gs th rq k) G0 := OSUpQpos.Gs_le_G0_family th rq hrq hω k
  -- F = ω G_k, P' = P
  have hF0 : UniformBracket.Lw 0 (fun q => omF th q • Gs th rq k q) := by
    intro q x
    have := hGk0 k q x
    simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right, LinearMap.smul_apply,
      real_inner_smul_right] at this ⊢
    exact mul_nonneg (omF_nonneg' th q) this
  have hFP : UniformBracket.Lw (fun q => omF th q • Gs th rq k q) (Pfam th) := by
    intro q x
    have h := hup q x
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right] at h ⊢
    have hw := hω q
    calc omF th q * ⟪x, Gs th rq k q x⟫ ≤ omF th q * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
          mul_le_mul_of_nonneg_left h hw.le
      _ = ⟪x, Pfam th q x⟫ := by field_simp
  have hsplit := iterate_split (Mfam_split th rq) (M0_op th rq) (M1_op th rq) hF0 hFP m q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right] at hsplit
  -- first term
  have hA : ⟪x, (⇑(M0fam th rq))^[m] (fun q => omF th q • Gs th rq k q) q x⟫ ≤
      Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m * (omF th q * ⟪x, Gs th rq (k + m) q x⟫) := by
    rw [M0_iter_smul]
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    have hd := iterate_dominated (Mfam th rq) (M0fam th rq) (Mfam_orderPreserving th rq)
      (M0_op th rq) (fun A hA q x => by
        rw [Mfam_split th rq]
        simp only [LinearMap.add_apply, Pi.add_apply, inner_add_right]
        have := M1_op th rq 0 A hA q x
        simp only [map_zero, Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at this
        linarith) (hGk0 k) m q x
    have hn := nonneg_iterate (M0fam th rq) (M0_op th rq) (hGk0 k) m q x
    simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at hn
    have hkm : (⇑(Mfam th rq))^[m] (Gs th rq k) = Gs th rq (k + m) := by
      unfold Gs; rw [add_comm k m, Function.iterate_add_apply]
    rw [hkm] at hd
    have hr := omF_chain_le th rq hrq q m
    calc omF th ((ch th rq)^[m] q) * ⟪x, (⇑(M0fam th rq))^[m] (Gs th rq k) q x⟫
        ≤ (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m * omF th q) *
            ⟪x, (⇑(M0fam th rq))^[m] (Gs th rq k) q x⟫ := mul_le_mul_of_nonneg_right hr hn
      _ ≤ (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m * omF th q) * ⟪x, Gs th rq (k + m) q x⟫ :=
          mul_le_mul_of_nonneg_left hd (by have := hω q; positivity)
      _ = _ := by ring
  -- second term
  have hB : ⟪x, (⇑(Mfam th rq))^[m] (Pfam th) q x⟫ ≤
      (1 / c) * (3 / 5 : ℝ) ^ m * (omF th q * ⟪x, Gs th rq (k + m) q x⟫) := by
    have h1 := iterate_P_le (Mfam th rq) (Mfam_orderPreserving th rq) (by norm_num : (0:ℝ) ≤ 3/5)
      (Mfam_P_le_row th rq hrq) m q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h1
    have h2 := hlow (k + m) q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h2
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right] at h2
    have hw := hω q
    have hP : ⟪x, Pfam th q x⟫ ≤ (1 / c) * (omF th q * ⟪x, Gs th rq (k + m) q x⟫) := by
      have e : ⟪x, Pfam th q x⟫ = (1 / c) * (omF th q * (c * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫))) := by
        field_simp
      rw [e]
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact mul_le_mul_of_nonneg_left h2 hw.le
    calc ⟪x, (⇑(Mfam th rq))^[m] (Pfam th) q x⟫ ≤ (3 / 5 : ℝ) ^ m * ⟪x, Pfam th q x⟫ := h1
      _ ≤ (3 / 5 : ℝ) ^ m * ((1 / c) * (omF th q * ⟪x, Gs th rq (k + m) q x⟫)) :=
          mul_le_mul_of_nonneg_left hP (by positivity)
      _ = _ := by ring
  calc _ ≤ _ := hsplit
    _ ≤ _ := add_le_add hA hB
    _ = _ := by ring

/-- The lower-side constant of `lower_side`. -/
noncomputable def cLow : ℝ := 4 / Real.pi ^ 2 * (0.04452 : ℝ) ^ 2

theorem cLow_pos : 0 < cLow := by unfold cLow; have := Real.pi_pos; positivity

/-- **(H-τ) on any alias-closed family, no hypotheses beyond the family**
(`c = (4/π²)·0.04452²` from `lower_side`). -/
theorem tau_stage_uniform_family (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (hω : ∀ q, 0 < omF th q) (k m : ℕ) (q : Q) (x : V) :
    ⟪x, ((⇑(Mfam th rq))^[m] (fun q => omF th q • Gs th rq k q)) q x⟫ ≤
      (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m + (1 / cLow) * (3 / 5 : ℝ) ^ m) *
        (omF th q * ⟪x, Gs th rq (k + m) q x⟫) :=
  tau_stage_uniform_of_low th rq hrq hω cLow_pos (fun j => lower_side th rq hrq hω j) k m q x

end Concrete

open OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal

/-- **`tau_stage_uniform`** (on `Qpos`, no hypotheses). -/
theorem tau_stage_uniform (k m : ℕ) (q : Qpos) (x : V) :
    ⟪x, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[m]
        (fun q => omF Subtype.val q • Gs Subtype.val rqPos k q)) q x⟫ ≤
      (Real.pi ^ 2 / 4 * (1 / 4 : ℝ) ^ m + (1 / cLow) * (3 / 5 : ℝ) ^ m) *
        (omF Subtype.val q * ⟪x, Gs Subtype.val rqPos (k + m) q x⟫) :=
  tau_stage_uniform_family Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) k m q x

/-- `tauM` of `PaperStageCount16` (same text). -/
noncomputable def tauM (R lam : ℝ) (m : ℕ) : ℝ := (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ m + R * lam ^ m

/-- T2c for the `lower_side` constant: `tauM (1/c) (3/5) 25 < 1/170`. -/
theorem tauM_cLow_25 : tauM (1 / cLow) (3 / 5) 25 < 1 / 170 := by
  unfold tauM cLow
  have hp := Real.pi_lt_d4
  have hp0 := Real.pi_pos
  have hpi2 : Real.pi ^ 2 < 9.8697 := by nlinarith
  have hR : 1 / (4 / Real.pi ^ 2 * (0.04452 : ℝ) ^ 2) ≤ 1245 := by
    rw [div_le_iff₀ (by positivity)]
    field_simp
    nlinarith
  have h1 : (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ 25 ≤ (10 / 4) * (1 / 4 : ℝ) ^ 25 := by
    gcongr; linarith
  have h2 : 1 / (4 / Real.pi ^ 2 * (0.04452 : ℝ) ^ 2) * (3 / 5 : ℝ) ^ 25 ≤
      1245 * (3 / 5 : ℝ) ^ 25 := mul_le_mul_of_nonneg_right hR (by positivity)
  have h3 : (10 / 4) * (1 / 4 : ℝ) ^ 25 + 1245 * (3 / 5 : ℝ) ^ 25 < 1 / 170 := by norm_num
  linarith

/-- **`tau_stage_25`**: on `Qpos`, `τ_k^{(25)} < 1/170` for every stage `k`
(the hypothesis `∀ k, τ k ≤ tauM R lam m` of `F3Conditional.f3_conditional` with `R = 1/c`,
`lam = 3/5`, `m = 25`, in the quadratic-form reading). -/
theorem tau_stage_25 (k : ℕ) (q : Qpos) (x : V) :
    ⟪x, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[25]
        (fun q => omF Subtype.val q • Gs Subtype.val rqPos k q)) q x⟫ ≤
      tauM (1 / cLow) (3 / 5) 25 *
        (omF Subtype.val q * ⟪x, Gs Subtype.val rqPos (k + 25) q x⟫) := by
  have h := tau_stage_uniform k 25 q x
  unfold tauM
  exact h

end TauSplit


#print axioms TauSplit.iterate_split
#print axioms TauSplit.omF_chain_le
#print axioms TauSplit.tau_stage_uniform_of_low
#print axioms TauSplit.tau_stage_uniform
#print axioms TauSplit.tauM_cLow_25
#print axioms TauSplit.tau_stage_25
