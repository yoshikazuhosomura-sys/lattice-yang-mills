import Mathlib

/-! # Plancherel on the torus with the characters indexed by the momenta `k` 

Paper: an earlier file did Plancherel with `AddChar G ℂ`; the face
covariance of `Lam.Torus1` is indexed by the momenta `k ∈ (Fin N)⁴` (`q̂(k) = 1 − e^{2πik/N}`). Here:
* abstract (`PlanchK`): any family `ch : K → G → ℂ` with the orthogonality `Σ_k conj(ch k x) ch k x' = |G|[x' = x]`
  gives the Fourier transform `ŷ(k) = Σ_x conj(ch k x) y(x)`, the operator with symbol `M`
  `(C y)(x) = |G|⁻¹ Σ_k ch k x · M_k ŷ(k)`, Plancherel, `|G| Σ_x ⟨y, Cy⟩ = Σ_k ⟨ŷ, M ŷ⟩`, and (with `|ch| = 1`)
  the position diagonal `⟨v, (C δ_{x₀}v)(x₀)⟩ = |G|⁻¹ Σ_k ⟨v, M_k v⟩` (the same at every point `x₀`);
* torus (`TorusChar`): `ch k x = Π_μ e^{2πi k_μ x_μ/N}` on `(Fin N)⁴` satisfies the orthogonality and `|ch| = 1`. -/

noncomputable section

namespace PlanchK

open Finset ComplexConjugate
open scoped InnerProductSpace

variable {K G : Type*} [Fintype K] [Fintype G] [DecidableEq G]
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℂ E]
variable (ch : K → G → ℂ)

def ft (y : G → E) (k : K) : E := ∑ x, conj (ch k x) • y x

def opC (M : K → E →ₗ[ℂ] E) (y : G → E) (x : G) : E :=
  ((Fintype.card G : ℂ)⁻¹) • ∑ k, ch k x • M k (ft ch y k)

variable {ch}

theorem plancherel
    (hortho : ∀ x x' : G, ∑ k, conj (ch k x) * ch k x' = if x' = x then (Fintype.card G : ℂ) else 0)
    (y : G → E) :
    ∑ k, ⟪ft ch y k, ft ch y k⟫_ℂ = (Fintype.card G : ℂ) * ∑ x, ⟪y x, y x⟫_ℂ := by
  have key : ∀ x x' : G, ∑ k, ch k x * (conj (ch k x') * ⟪y x, y x'⟫_ℂ) =
      if x = x' then (Fintype.card G : ℂ) * ⟪y x, y x'⟫_ℂ else 0 := by
    intro x x'
    have hc := hortho x' x
    calc ∑ k, ch k x * (conj (ch k x') * ⟪y x, y x'⟫_ℂ)
        = (∑ k, conj (ch k x') * ch k x) * ⟪y x, y x'⟫_ℂ := by
          rw [Finset.sum_mul]
          exact Finset.sum_congr rfl fun k _ => by ring
      _ = _ := by rw [hc]; split_ifs <;> simp
  calc ∑ k, ⟪ft ch y k, ft ch y k⟫_ℂ
      = ∑ k, ∑ x, ∑ x', ch k x * (conj (ch k x') * ⟪y x, y x'⟫_ℂ) := by
        refine Finset.sum_congr rfl fun k _ => ?_
        simp only [ft, sum_inner, inner_sum, inner_smul_left, inner_smul_right, Complex.conj_conj,
          Finset.mul_sum]
        rw [Finset.sum_comm]
        exact Finset.sum_congr rfl fun x _ => Finset.sum_congr rfl fun x' _ => by ring
    _ = ∑ x, ∑ x', ∑ k, ch k x * (conj (ch k x') * ⟪y x, y x'⟫_ℂ) := by
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl fun x _ => ?_
        rw [Finset.sum_comm]
    _ = ∑ x, (Fintype.card G : ℂ) * ⟪y x, y x⟫_ℂ := by
        refine Finset.sum_congr rfl fun x _ => ?_
        simp_rw [key]
        simp
    _ = _ := by rw [Finset.mul_sum]

theorem card_mul_inner_opC (M : K → E →ₗ[ℂ] E) (y : G → E) :
    (Fintype.card G : ℂ) * ∑ x, ⟪y x, opC ch M y x⟫_ℂ = ∑ k, ⟪ft ch y k, M k (ft ch y k)⟫_ℂ := by
  by_cases hG : IsEmpty G
  · have h0 : ∀ k, ft ch y k = 0 := fun k => by simp [ft]
    simp [h0]
  have hG' : (Fintype.card G : ℂ) ≠ 0 := by
    rw [not_isEmpty_iff] at hG
    exact Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have e : ∑ x, ⟪y x, opC ch M y x⟫_ℂ =
      (Fintype.card G : ℂ)⁻¹ * ∑ k, ∑ x, ch k x * ⟪y x, M k (ft ch y k)⟫_ℂ := by
    simp only [opC, inner_smul_right, inner_sum]
    rw [← Finset.mul_sum, Finset.sum_comm]
  rw [e, mul_inv_cancel_left₀ hG']
  refine Finset.sum_congr rfl fun k _ => ?_
  generalize M k (ft ch y k) = w
  simp only [ft, sum_inner, inner_smul_left, Complex.conj_conj]

theorem re_inner_self (v : E) : (⟪v, v⟫_ℂ).re = ‖v‖ ^ 2 := by
  simpa using (inner_self_eq_norm_sq (𝕜 := ℂ) v)

/-- Plancherel in norms. -/
theorem plancherel_norm
    (hortho : ∀ x x' : G, ∑ k, conj (ch k x) * ch k x' = if x' = x then (Fintype.card G : ℂ) else 0)
    (y : G → E) :
    ∑ k, ‖ft ch y k‖ ^ 2 = (Fintype.card G : ℝ) * ∑ x, ‖y x‖ ^ 2 := by
  have h := congrArg Complex.re (plancherel hortho y)
  simp only [Complex.re_sum, re_inner_self, Complex.mul_re, Complex.natCast_re,
    Complex.natCast_im, zero_mul, sub_zero] at h
  exact h

/-- The quadratic form in position space equals `|G|⁻¹` times the form of the symbol. -/
theorem form_eq (M : K → E →ₗ[ℂ] E) (y : G → E) :
    (Fintype.card G : ℝ) * (∑ x, ⟪y x, opC ch M y x⟫_ℂ).re = ∑ k, (⟪ft ch y k, M k (ft ch y k)⟫_ℂ).re := by
  have h1 := congrArg Complex.re (card_mul_inner_opC (ch := ch) M y)
  simp only [Complex.re_sum, Complex.mul_re, Complex.natCast_re, Complex.natCast_im, zero_mul,
    sub_zero] at h1
  rw [Complex.re_sum]
  exact h1

/-- The point vector `δ_{x₀} v`. -/
def delta (x0 : G) (v : E) : G → E := fun x => if x = x0 then v else 0

theorem ft_delta (x0 : G) (v : E) (k : K) : ft ch (delta x0 v) k = conj (ch k x0) • v := by
  simp [ft, delta]

/-- **The position diagonal**: `⟨v, (C δ_{x₀}v)(x₀)⟩ = |G|⁻¹ Σ_k ⟨v, M_k v⟩` when `|ch| = 1`. -/
theorem diag_eq (hunit : ∀ k x, ‖ch k x‖ = 1) (M : K → E →ₗ[ℂ] E) (x0 : G) (v : E) :
    ⟪v, opC ch M (delta x0 v) x0⟫_ℂ = (Fintype.card G : ℂ)⁻¹ * ∑ k, ⟪v, M k v⟫_ℂ := by
  simp only [opC, ft_delta, map_smul, inner_smul_right, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun k _ => ?_
  have h : ch k x0 * conj (ch k x0) = 1 := by
    rw [Complex.mul_conj, Complex.normSq_eq_norm_sq, hunit]; simp
  rw [← mul_assoc, h, one_mul]

end PlanchK

namespace TorusChar

open Finset ComplexConjugate

/-- `e^{2πi j a/N}`. -/
def ch1 (N : ℕ) (j a : Fin N) : ℂ :=
  Complex.exp (2 * Real.pi * Complex.I * ((j : ℕ) : ℂ) * ((a : ℕ) : ℂ) / N)

/-- `Π_μ e^{2πi k_μ x_μ/N}`. -/
def ch (N : ℕ) (k x : Fin 4 → Fin N) : ℂ := ∏ μ, ch1 N (k μ) (x μ)

theorem ch1_norm (N : ℕ) (j a : Fin N) : ‖ch1 N j a‖ = 1 := by
  unfold ch1
  have e : 2 * Real.pi * Complex.I * ((j : ℕ) : ℂ) * ((a : ℕ) : ℂ) / N =
      ((2 * Real.pi * (j : ℕ) * (a : ℕ) / N : ℝ) : ℂ) * Complex.I := by push_cast; ring
  rw [e, Complex.norm_exp_ofReal_mul_I]

theorem ch_norm (N : ℕ) (k x : Fin 4 → Fin N) : ‖ch N k x‖ = 1 := by
  unfold ch; rw [norm_prod]; simp [ch1_norm]

theorem conj_mul_ch1 (N : ℕ) (j a b : Fin N) :
    conj (ch1 N j a) * ch1 N j b =
      Complex.exp (2 * Real.pi * Complex.I * (((b : ℕ) : ℂ) - ((a : ℕ) : ℂ)) / N) ^ (j : ℕ) := by
  unfold ch1
  rw [← Complex.exp_conj, ← Complex.exp_add, ← Complex.exp_nat_mul]
  congr 1
  simp only [map_div₀, map_mul, map_ofNat, Complex.conj_ofReal, Complex.conj_I, map_natCast]
  ring

theorem root_ne_one {N : ℕ} {d : ℤ} (hd0 : d ≠ 0) (hdN : |d| < N) :
    Complex.exp (2 * Real.pi * Complex.I * (d : ℂ) / N) ≠ 1 := by
  intro h
  rw [Complex.exp_eq_one_iff] at h
  obtain ⟨n, hn⟩ := h
  have hN : (0 : ℝ) < N := by
    have : (0 : ℤ) < N := lt_of_le_of_lt (abs_nonneg d) hdN
    exact_mod_cast this
  have hI : (2 * Real.pi * Complex.I : ℂ) ≠ 0 := by simp [Real.pi_ne_zero, Complex.I_ne_zero]
  have hN' : (N : ℂ) ≠ 0 := by exact_mod_cast hN.ne'
  have e : (d : ℂ) = (n : ℂ) * N := by
    have h2 : 2 * Real.pi * Complex.I * ((d : ℂ) / N) = 2 * Real.pi * Complex.I * (n : ℂ) := by
      rw [← mul_div_assoc, hn]; ring
    have h3 := mul_left_cancel₀ hI h2
    field_simp at h3
    rw [h3]; ring
  have e' : d = n * (N : ℤ) := by exact_mod_cast e
  have hb := abs_lt.mp hdN
  rcases lt_trichotomy n 0 with hn0 | hn0 | hn0
  · have : n * (N : ℤ) ≤ -(N : ℤ) := by nlinarith
    omega
  · subst hn0; simp at e'; exact hd0 e'
  · have : (N : ℤ) ≤ n * (N : ℤ) := by nlinarith
    omega

theorem root_pow_N {N : ℕ} (hN : N ≠ 0) (d : ℤ) :
    Complex.exp (2 * Real.pi * Complex.I * (d : ℂ) / N) ^ N = 1 := by
  rw [← Complex.exp_nat_mul, Complex.exp_eq_one_iff]
  refine ⟨d, ?_⟩
  have hN' : (N : ℂ) ≠ 0 := by exact_mod_cast hN
  field_simp

/-- One coordinate: `Σ_j conj(e^{2πi j a/N}) e^{2πi j b/N} = N [b = a]`. -/
theorem ortho1 {N : ℕ} (a b : Fin N) :
    ∑ j : Fin N, conj (ch1 N j a) * ch1 N j b = if b = a then (N : ℂ) else 0 := by
  have hN : N ≠ 0 := by rintro rfl; exact a.elim0
  simp_rw [conj_mul_ch1]
  rw [Fin.sum_univ_eq_sum_range (fun j => Complex.exp (2 * Real.pi * Complex.I *
    (((b : ℕ) : ℂ) - ((a : ℕ) : ℂ)) / N) ^ j) N]
  split_ifs with hab
  · subst hab; simp
  · set d : ℤ := (b : ℕ) - (a : ℕ) with hd
    have e : (((b : ℕ) : ℂ) - ((a : ℕ) : ℂ)) = (d : ℂ) := by rw [hd]; push_cast; ring
    rw [e]
    have hd0 : d ≠ 0 := by
      intro h0; apply hab; apply Fin.ext; rw [hd] at h0; omega
    have hdN : |d| < N := by
      rw [abs_lt]; constructor <;> (rw [hd]; have := a.isLt; have := b.isLt; omega)
    rw [geom_sum_eq (root_ne_one hd0 hdN), root_pow_N hN, sub_self, zero_div]

/-- **Orthogonality on the torus** `(Fin N)⁴`. -/
theorem ortho {N : ℕ} (x x' : Fin 4 → Fin N) :
    ∑ k : Fin 4 → Fin N, conj (ch N k x) * ch N k x' =
      if x' = x then (Fintype.card (Fin 4 → Fin N) : ℂ) else 0 := by
  have e1 : ∀ k : Fin 4 → Fin N, conj (ch N k x) * ch N k x' =
      ∏ μ, (conj (ch1 N (k μ) (x μ)) * ch1 N (k μ) (x' μ)) := by
    intro k; unfold ch; rw [map_prod, ← Finset.prod_mul_distrib]
  simp_rw [e1]
  have e2 := (Finset.prod_univ_sum (fun _ : Fin 4 => (Finset.univ : Finset (Fin N)))
    (fun μ j => conj (ch1 N j (x μ)) * ch1 N j (x' μ))).symm
  rw [Fintype.piFinset_univ] at e2
  rw [e2]
  simp_rw [ortho1]
  split_ifs with h
  · subst h; simp
  · obtain ⟨μ, hμ⟩ := Function.ne_iff.mp h
    exact Finset.prod_eq_zero (Finset.mem_univ μ) (if_neg hμ)

end TorusChar

end

#print axioms PlanchK.plancherel_norm
#print axioms PlanchK.form_eq
#print axioms PlanchK.diag_eq
#print axioms TorusChar.ortho
#print axioms TorusChar.ch_norm
