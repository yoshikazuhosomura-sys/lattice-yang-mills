import T1.Final2
import Lam.Up1
import Lam.Face1

/-! # T1h joined to the chain : `Λ` of the actual stage covariances on the torus, and `m = 17`

Imports (records `.olean.src.sha256`):
* `T1.Final2` — `HsSplit.lower_side_c` (`c₀ = 3/100`, from `hS_split` with no hypothesis), `T1h.torus_lambda_c3`,
  `StageArith.tau_3_17` (via `T1.T1hArith1`);
* `Lam.Up1` — `import T1.Split1` + the part of an earlier file after the common prefix:
  `OSUpQpos.Gs_le_G0` (T0, (OS↑), `C₊ = 1` at every stage), `TauSplit.tau_stage_uniform_of_low` (T2b);
* `Lam.Face1` — an earlier file (T4a/T4b: `FaceReal.*`, `FaceTorus.torus_face_diag`,
  `FaceTorus.torus_face_upper`).

The stage covariance is `G_m = 𝓜^m(P/ω)` on `Qpos` (the concrete one-step map `Mfam` with the aliases `rqPos`).
At the torus momentum `k ∈ (Fin N)⁴`, `k ≠ 0`, with `q_ν = 2πk_ν/N`, the point of `Qpos` is `θ = q/4`
(so `sin 2θ_ν = sin(q_ν/2)` and `ω = Σ 4 sin²(q_ν/2) = Σ|1 − e^{iq_ν}|²`; the coordinate convention `q = 4θ`).
The Bloch symbol of the field at `k` is `Ĝ(k) = U G_m(θ) U*` (`U = diag(−i e^{iq_ν/2})`, T4a), and the face
covariance at `k` is `d̂(k) Ĝ(k) d̂(k)†`. `lamMax` is the top of its Rayleigh quotient over all Bloch vectors
`ŷ : (Fin N)⁴ → ℂ⁶`, and `faceDiag p` is the position diagonal `N⁻⁴ Σ_k ⟨e_p, d̂Ĝd̂† e_p⟩` (translation
invariant). What is not done here: the identification of the position-space covariance of the face field with
the operator of this Bloch symbol (Plancherel on `(ℤ/N)⁴` with the characters indexed by `k`; the abstract
Plancherel is an earlier file), i.e. the modelling hypothesis of T4b stays as it was. -/

noncomputable section

namespace TorusLam

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower
  FaceBracket FaceReal FaceTorus
open scoped Real InnerProductSpace RealInnerProductSpace ComplexConjugate Matrix

/-! ### real side: matrices and quadratic forms -/

/-- The real matrix of an operator on `V`. -/
def torG (A : V →ₗ[ℝ] V) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun i j => ⟪EuclideanSpace.single i (1 : ℝ), A (EuclideanSpace.single j 1)⟫

theorem toLp_sum (x : Fin 4 → ℝ) :
    WithLp.toLp 2 x = ∑ j, x j • EuclideanSpace.single j (1 : ℝ) := by
  ext i
  simp [Pi.single_apply]

theorem Gq_torG (A : V →ₗ[ℝ] V) (x : Fin 4 → ℝ) :
    Gq (torG A) x = ⟪WithLp.toLp 2 x, A (WithLp.toLp 2 x)⟫ := by
  rw [toLp_sum x]
  simp only [map_sum, map_smul, inner_sum, sum_inner, real_inner_smul_left, real_inner_smul_right]
  unfold Gq torG
  simp only [Matrix.of_apply, Fin.sum_univ_four]
  ring

theorem Pq_projM (s x : Fin 4 → ℝ) :
    ⟪WithLp.toLp 2 x, Matrix.toEuclideanLin (projM s) (WithLp.toLp 2 x)⟫ = Pq s x := by
  rw [inner_coord, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, projM_mulVec]
  unfold Pq proj dot
  have e : (∑ i, s i * s i) = ∑ i, s i ^ 2 := Finset.sum_congr rfl fun i _ => by ring
  rw [e]
  simp only [Fin.sum_univ_four]
  ring

/-! ### the torus momenta as points of `Qpos` -/

/-- The torus momentum `q_ν = 2πk_ν/N`. -/
def torQv (N : ℕ) (k : Fin 4 → Fin N) (ν : Fin 4) : ℝ := 2 * π * ((k ν : ℕ) : ℝ) / N

/-- The phase `u_ν = −i e^{iq_ν/2}`. -/
def torU (N : ℕ) (k : Fin 4 → Fin N) : Fin 4 → ℂ :=
  fun ν => -Complex.I * Complex.exp ((torQv N k ν / 2 : ℝ) * Complex.I)

/-- `s_ν = sin(q_ν/2)`. -/
def torS (N : ℕ) (k : Fin 4 → Fin N) : Fin 4 → ℝ := fun ν => Real.sin (torQv N k ν / 2)

theorem torU_norm (N : ℕ) (k : Fin 4 → Fin N) (ν : Fin 4) : ‖torU N k ν‖ = 1 := phase_norm _

/-- `q̂(k) = 2 u s` (`q̂_ν = 1 − e^{2πik_ν/N}`). -/
theorem qk_eq (N : ℕ) (k : Fin 4 → Fin N) : qk N k = qhat (torU N k) (torS N k) := by
  funext ν
  simp only [qk, qhat, torU, torS]
  rw [qhat_phase]
  congr 2
  unfold torQv
  push_cast
  ring

theorem omg_qk (N : ℕ) (k : Fin 4 → Fin N) : omg (qk N k) = 4 * ∑ ν, torS N k ν ^ 2 := by
  rw [qk_eq]; exact omg_qhat _ (torU_norm N k) _

/-- The angle coordinates `θ_ν = q_ν/4`. -/
def torTh (N : ℕ) (k : Fin 4 → Fin N) : Fin 4 → ℝ := fun ν => torQv N k ν / 4

theorem sQ_torTh (N : ℕ) (k : Fin 4 → Fin N) : sQ (torTh N k) = torS N k := by
  funext ν; simp only [sQ, torTh, torS]; congr 1; ring

theorem omg_pos_of_ne {N : ℕ} [NeZero N] {k : Fin 4 → Fin N} (hk : k ≠ 0) : 0 < omg (qk N k) :=
  lt_of_le_of_ne (Finset.sum_nonneg fun i _ => sq_nonneg _) (omg_ne_zero k hk).symm

theorem pos_torTh {N : ℕ} {k : Fin 4 → Fin N} (h : 0 < omg (qk N k)) :
    0 < ∑ ν, 4 * sQ (torTh N k) ν ^ 2 := by
  rw [sQ_torTh, ← Finset.mul_sum, ← omg_qk]
  exact h

/-- The point `θ = q/4` of `Qpos` for the torus momentum `k` with `ω(k) > 0` (i.e. `k ≠ 0`). -/
def torPt {N : ℕ} (k : Fin 4 → Fin N) (h : 0 < omg (qk N k)) : Qpos := ⟨torTh N k, pos_torTh h⟩

theorem omF_torPt {N : ℕ} (k : Fin 4 → Fin N) (h : 0 < omg (qk N k)) :
    omF Subtype.val (torPt k h) = omg (qhat (torU N k) (torS N k)) := by
  rw [omg_qhat _ (torU_norm N k), Finset.mul_sum]
  show ∑ ν, 4 * sQ (torTh N k) ν ^ 2 = _
  rw [sQ_torTh]

theorem Pfam_torPt {N : ℕ} (k : Fin 4 → Fin N) (h : 0 < omg (qk N k)) (x : Fin 4 → ℝ) :
    ⟪WithLp.toLp 2 x, Pfam Subtype.val (torPt k h) (WithLp.toLp 2 x)⟫ = Pq (torS N k) x := by
  show ⟪WithLp.toLp 2 x, Matrix.toEuclideanLin (projM (sQ (torTh N k))) (WithLp.toLp 2 x)⟫ = _
  rw [sQ_torTh, Pq_projM]

/-! ### the stage covariance and its two sides at a torus momentum -/

/-- The stage covariance `G_m = 𝓜^m(P/ω)` on `Qpos`. -/
def Gst (m : ℕ) : Qpos → V →ₗ[ℝ] V :=
  (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[m] (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)

/-- Upper side at `θ = q/4`, from (OS↑) (`OSUpQpos.Gs_le_G0`, `C₊ = 1`). -/
theorem real_up {N : ℕ} (m : ℕ) (k : Fin 4 → Fin N) (hk : 0 < omg (qk N k)) (x : Fin 4 → ℝ) :
    Gq (torG (Gst m (torPt k hk))) x ≤ 1 / omg (qhat (torU N k) (torS N k)) * Pq (torS N k) x := by
  have h := OSUpQpos.Gs_le_G0 m (torPt k hk) (WithLp.toLp 2 x)
  simp only [LinearMap.smul_apply, real_inner_smul_right] at h
  rw [Pfam_torPt, omF_torPt] at h
  rw [Gq_torG, one_div]
  exact h

/-- Lower side at `θ = q/4`, from `HsSplit.lower_side_c` (`c₀ = 3/100`). -/
theorem real_low {N : ℕ} (m : ℕ) (k : Fin 4 → Fin N) (hk : 0 < omg (qk N k)) (x : Fin 4 → ℝ) :
    (3 / 100 : ℝ) / omg (qhat (torU N k) (torS N k)) * Pq (torS N k) x ≤
      Gq (torG (Gst m (torPt k hk))) x := by
  have h := HsSplit.lower_side_c Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) m
    (torPt k hk) (WithLp.toLp 2 x)
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h
  rw [Pfam_torPt, omF_torPt] at h
  rw [Gq_torG]
  have e : (3 / 100 : ℝ) / omg (qhat (torU N k) (torS N k)) * Pq (torS N k) x =
      3 / 100 * ((omg (qhat (torU N k) (torS N k)))⁻¹ * Pq (torS N k) x) := by ring
  rw [e]
  exact h

/-- The complex sides from the real ones (the two bullets of `FaceReal.face_bracket_of_real`). -/
theorem complex_sides (u : Fin 4 → ℂ) (hu : ∀ ν, ‖u ν‖ = 1) (s : Fin 4 → ℝ)
    (G : Matrix (Fin 4) (Fin 4) ℝ) {c Cp : ℝ} (hk : 0 ≤ Cp / omg (qhat u s))
    (hupR : ∀ x, Gq G x ≤ Cp / omg (qhat u s) * Pq s x)
    (hlowR : ∀ x, c / omg (qhat u s) * Pq s x ≤ Gq G x) :
    (∀ z, RCLike.re ⟪z, Matrix.toEuclideanLin (Gc u G) z⟫_ℂ ≤ Cp / omg (qhat u s) * ‖z‖ ^ 2) ∧
    (∀ z, ⟪z, WithLp.toLp 2 (qhat u s)⟫_ℂ = 0 →
      c / omg (qhat u s) * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, Matrix.toEuclideanLin (Gc u G) z⟫_ℂ) := by
  constructor
  · intro z
    rw [inner_Gc, norm_sq_w u hu z]
    have h1 := hupR (wa u z)
    have h2 := hupR (wb u z)
    have h3 := mul_le_mul_of_nonneg_left (Pq_le s (wa u z)) hk
    have h4 := mul_le_mul_of_nonneg_left (Pq_le s (wb u z)) hk
    nlinarith
  · intro z hz
    obtain ⟨ha, hb⟩ := perp_of_inner u s z hz
    rw [inner_Gc, norm_sq_w u hu z]
    have h1 := hlowR (wa u z)
    have h2 := hlowR (wb u z)
    rw [Pq_perp s _ ha] at h1
    rw [Pq_perp s _ hb] at h2
    rw [mul_add]
    linarith

/-- **The Bloch symbol of the stage-`m` field at the torus momentum `k`**: `U G_m(q/4) U*` when `ω(k) > 0`
(`k ≠ 0`); `0` at `k = 0`, where `d̂(0) = 0`. -/
def symb (N m : ℕ) (k : Fin 4 → Fin N) : EuclideanSpace ℂ (Fin 4) →ₗ[ℂ] EuclideanSpace ℂ (Fin 4) :=
  if hk : 0 < omg (qk N k) then Matrix.toEuclideanLin (Gc (torU N k) (torG (Gst m (torPt k hk)))) else 0

theorem omg_nonneg (qh : Fin 4 → ℂ) : 0 ≤ omg qh := Finset.sum_nonneg fun i _ => sq_nonneg _

theorem symb_up {N : ℕ} [NeZero N] (m : ℕ) (k : Fin 4 → Fin N) (hk : k ≠ 0)
    (z : EuclideanSpace ℂ (Fin 4)) :
    RCLike.re ⟪z, symb N m k z⟫_ℂ ≤ 1 / omg (qk N k) * ‖z‖ ^ 2 := by
  have h := omg_pos_of_ne hk
  have e : omg (qk N k) = omg (qhat (torU N k) (torS N k)) := by rw [qk_eq]
  unfold symb
  rw [dif_pos h, e]
  exact (complex_sides (torU N k) (torU_norm N k) (torS N k) _ (c := 3 / 100)
    (div_nonneg zero_le_one (omg_nonneg _)) (real_up m k h) (real_low m k h)).1 z

theorem symb_low {N : ℕ} [NeZero N] (m : ℕ) (k : Fin 4 → Fin N) (hk : k ≠ 0)
    (z : EuclideanSpace ℂ (Fin 4)) (hz : ⟪z, WithLp.toLp 2 (qk N k)⟫_ℂ = 0) :
    (3 / 100 : ℝ) / omg (qk N k) * ‖z‖ ^ 2 ≤ RCLike.re ⟪z, symb N m k z⟫_ℂ := by
  have h := omg_pos_of_ne hk
  have e : omg (qk N k) = omg (qhat (torU N k) (torS N k)) := by rw [qk_eq]
  rw [qk_eq] at hz
  unfold symb
  rw [dif_pos h, e]
  exact (complex_sides (torU N k) (torU_norm N k) (torS N k) _ (c := 3 / 100) (Cp := 1)
    (div_nonneg zero_le_one (omg_nonneg _)) (real_up m k h) (real_low m k h)).2 z hz

/-! ### the face covariance on the torus, its top and its diagonal -/

/-- The face covariance at the Bloch momentum `k`: `d̂(k) Ĝ(k) d̂(k)†`. -/
def faceM (N m : ℕ) (k : Fin 4 → Fin N) : EuclideanSpace ℂ (Fin 6) →ₗ[ℂ] EuclideanSpace ℂ (Fin 6) :=
  Matrix.toEuclideanLin (dmat (qk N k)) ∘ₗ symb N m k ∘ₗ
    LinearMap.adjoint (Matrix.toEuclideanLin (dmat (qk N k)))

/-- Its quadratic form on the Bloch vectors `ŷ : (Fin N)⁴ → ℂ⁶`. -/
def faceQ (N m : ℕ) (yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : ℝ :=
  ∑ k, RCLike.re ⟪yh k, faceM N m k (yh k)⟫_ℂ

def faceNorm (N : ℕ) (yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) : ℝ := ∑ k, ‖yh k‖ ^ 2

/-- `λ_max`: the top of the Rayleigh quotient. -/
def lamMax (N m : ℕ) : ℝ :=
  sSup {r : ℝ | ∃ yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6),
    0 < faceNorm N yh ∧ r = faceQ N m yh / faceNorm N yh}

/-- The position diagonal at the face `p` (the same at every point). -/
def faceDiag (N m : ℕ) (p : Fin 6) : ℝ :=
  (1 / (N : ℝ) ^ 4) * ∑ k : Fin 4 → Fin N,
    RCLike.re ⟪EuclideanSpace.single p (1 : ℂ), faceM N m k (EuclideanSpace.single p 1)⟫_ℂ

theorem faceQ_le {N : ℕ} [NeZero N] (m : ℕ) (yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6)) :
    faceQ N m yh ≤ faceNorm N yh := by
  have h := torus_face_upper (symb N m) zero_le_one (fun k hk z => symb_up m k hk z) yh
  rw [one_mul] at h
  exact h

theorem faceDiag_ge {N : ℕ} [NeZero N] (m : ℕ) (p : Fin 6) :
    (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ faceDiag N m p :=
  torus_face_diag (symb N m) (c := 3 / 100) (fun k hk z hz => symb_low m k hk z hz) p

theorem diag_mem {N : ℕ} [NeZero N] (m : ℕ) (p : Fin 6) :
    faceDiag N m p ∈ {r : ℝ | ∃ yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6),
      0 < faceNorm N yh ∧ r = faceQ N m yh / faceNorm N yh} := by
  refine ⟨fun _ => EuclideanSpace.single p 1, ?_, ?_⟩
  · have hN : (0 : ℝ) < (N : ℝ) ^ 4 := by
      have : (0 : ℝ) < N := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne N)
      positivity
    have e : faceNorm N (fun _ => EuclideanSpace.single p (1 : ℂ)) = (N : ℝ) ^ 4 := by
      simp [faceNorm, EuclideanSpace.norm_single, Fintype.card_fun]
    rw [e]; exact hN
  · have e : faceNorm N (fun _ => EuclideanSpace.single p (1 : ℂ)) = (N : ℝ) ^ 4 := by
      simp [faceNorm, EuclideanSpace.norm_single, Fintype.card_fun]
    rw [e]
    unfold faceDiag faceQ
    ring

theorem rayleigh_le {N : ℕ} [NeZero N] (m : ℕ) :
    ∀ r ∈ {r : ℝ | ∃ yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6),
      0 < faceNorm N yh ∧ r = faceQ N m yh / faceNorm N yh}, r ≤ 1 := by
  rintro r ⟨yh, hpos, rfl⟩
  rw [div_le_one hpos]
  exact faceQ_le m yh

/-- **T1h, `Λ` at every stage on the finite torus (Bloch form), joined to the chain.**
For `N ≥ 2`, every stage `m` and every face `p`, the face covariance of the stage covariance
`G_m = 𝓜^m(P/ω)` (Bloch symbol `U G_m(q/4) U*` at `k ≠ 0`) has: quadratic form `≤ ‖ŷ‖²` (from (OS↑), T0),
`λ_max ≤ 1`, diagonal `≥ (c₀/2)(1 − N⁻⁴)` with `c₀ = 3/100` (from `lower_side_c`, T1, through T4b),
`diagonal ≤ λ_max` (so `λ_max` is attained-or-exceeded by a true Rayleigh quotient), and
`Λ = λ_max/diagonal ≤ 640/9 = 32/(15c₀)`. No hypothesis. -/
theorem torus_bloch_face_lambda {N : ℕ} (hN : 2 ≤ N) (m : ℕ) (p : Fin 6) :
    (∀ yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6), faceQ N m yh ≤ faceNorm N yh) ∧
    lamMax N m ≤ 1 ∧
    (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ faceDiag N m p ∧
    faceDiag N m p ≤ lamMax N m ∧
    lamMax N m / faceDiag N m p ≤ 640 / 9 := by
  haveI : NeZero N := ⟨by omega⟩
  have hbdd : BddAbove {r : ℝ | ∃ yh : (Fin 4 → Fin N) → EuclideanSpace ℂ (Fin 6),
      0 < faceNorm N yh ∧ r = faceQ N m yh / faceNorm N yh} := ⟨1, rayleigh_le m⟩
  have hmax : lamMax N m ≤ 1 := csSup_le ⟨_, diag_mem m p⟩ (rayleigh_le m)
  have hd := faceDiag_ge (N := N) m p
  exact ⟨faceQ_le m, hmax, hd, le_csSup hbdd (diag_mem m p), T1h.torus_lambda_c3 hN hmax hd⟩

/-! ### `m = 17`: the stage `τ` of the concrete family at `c₀ = 3/100` -/

/-- **T1h, `m = 17` joined to the chain**: on `Qpos`, at every stage `k`, every `q` and `x`,
`⟨x, 𝓜^17(ω G_k)(q) x⟩ ≤ τ · ω(q)⟨x, G_{k+17}(q) x⟩` with `τ = τ̄₁₇(1/c₀) < 1/170`, `c₀ = 3/100`
(the quadratic-form reading of `τ_k^{(17)}`). The lower side is `HsSplit.lower_side_c`
(T1, no hypothesis on `Qpos`), passed into `TauSplit.tau_stage_uniform_of_low` (T2b). No hypothesis. -/
theorem stage_tau_17 : ∃ τ : ℝ, τ = StageArith.tauM (1 / (3 / 100)) (3 / 5) 17 ∧ τ < 1 / 170 ∧
    ∀ (k : ℕ) (q : Qpos) (x : V),
      ⟪x, ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[17]
          (fun q => omF Subtype.val q • TauSplit.Gs Subtype.val rqPos k q)) q x⟫ ≤
        τ * (omF Subtype.val q * ⟪x, TauSplit.Gs Subtype.val rqPos (k + 17) q x⟫) := by
  refine ⟨_, rfl, StageArith.tau_3_17, fun k q x => ?_⟩
  have h := TauSplit.tau_stage_uniform_of_low Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2)
    (c := 3 / 100) (by norm_num)
    (fun j => HsSplit.lower_side_c Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) j) k 17 q x
  unfold StageArith.tauM
  exact h

/-- `TauSplit.Gs` is the stage covariance `Gst` (same iterate). -/
theorem Gs_eq_Gst (k : ℕ) : TauSplit.Gs Subtype.val rqPos k = Gst k := rfl

end TorusLam

namespace T1h

open scoped RealInnerProductSpace

/-- **T1 with T1h, joined**: `c₀ = 3/100`; `hS` (no hypothesis); `m = 17` for the concrete stage `τ`
(`TorusLam.stage_tau_17`); `Λ ≤ 640/9` for the face covariance of every stage on every torus `N ≥ 2`
(`TorusLam.torus_bloch_face_lambda`, Bloch form). -/
theorem t1h_joined : ∃ c₀ : ℝ, c₀ = 3 / 100 ∧
    (∀ θ : Fin 4 → ℝ, 0 < NearAliasB.omT θ →
      c₀ ≤ NearAliasB.gpt 0 2 θ ∨ ∀ ν, c₀ ≤ NearAliasB.omT θ * NearAliasB.Dn 5 θ ν) ∧
    (∃ τ : ℝ, τ < 1 / 170 ∧ ∀ (k : ℕ) (q : OneStepFinal.Qpos) (x : OneStepBridge.V),
      ⟪x, ((⇑(OneStepBridge.Mfam (Subtype.val : OneStepFinal.Qpos → _) OneStepFinal.rqPos))^[17]
          (fun q => OneStepET.omF Subtype.val q • TauSplit.Gs Subtype.val OneStepFinal.rqPos k q)) q x⟫ ≤
        τ * (OneStepET.omF Subtype.val q * ⟪x, TauSplit.Gs Subtype.val OneStepFinal.rqPos (k + 17) q x⟫)) ∧
    (∀ {N : ℕ}, 2 ≤ N → ∀ (m : ℕ) (p : Fin 6),
      c₀ / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ TorusLam.faceDiag N m p ∧
      TorusLam.lamMax N m ≤ 1 ∧
      TorusLam.lamMax N m / TorusLam.faceDiag N m p ≤ 640 / 9) := by
  obtain ⟨τ, -, hτ, h17⟩ := TorusLam.stage_tau_17
  refine ⟨3 / 100, rfl, HsSplit.hS_split, ⟨τ, hτ, h17⟩, fun {N} hN m p => ?_⟩
  obtain ⟨-, h1, h2, -, h3⟩ := TorusLam.torus_bloch_face_lambda hN m p
  exact ⟨h2, h1, h3⟩

end T1h

end

#print axioms TorusLam.torus_bloch_face_lambda
#print axioms TorusLam.stage_tau_17
#print axioms T1h.t1h_joined
