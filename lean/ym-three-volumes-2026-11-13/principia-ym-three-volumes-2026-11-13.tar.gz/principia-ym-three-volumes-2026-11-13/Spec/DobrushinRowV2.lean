import Spec.LinkCoeffV1

/-!
# The Dobrushin constant of the single-link Wilson specification: `α ≤ 18 tanh |β|` 

Paper correspondence: `spec_coeff` (Spec.LinkCoeffV1) bounds `C_{xy}` by
`tanh(|β| n_{xy})`; here `tanh(t n) ≤ n tanh t` (`tanhForm_le`, from the subadditivity
`(XY-1)/(XY+1) ≤ (X-1)/(X+1) + (Y-1)/(Y+1)` for `X, Y ≥ 1`, whose gap is
`(XY-1)(X-1)(Y-1)/…`) and `Σ_{y ≠ x} n_{xy} ≤ 18` (`sum_n_le`: at most 6 plaquettes contain `x`,
each has at most 3 further links).  Hence `Σ_{y ≠ x} sup C_{xy} ≤ 18 tanh |β|`, which is `< 1`
for `|β| < artanh(1/18) ≈ 0.0556`.  Dobrushin's uniqueness/comparison theorem itself and the DLR
property of the Wilson measure are not in Lean.
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset

theorem tanh_sub_add (X Y : ℝ) (hX : 1 ≤ X) (hY : 1 ≤ Y) :
    (X * Y - 1) / (X * Y + 1) ≤ (X - 1) / (X + 1) + (Y - 1) / (Y + 1) := by
  have hXY : 1 ≤ X * Y := by nlinarith
  rw [div_add_div _ _ (by linarith) (by linarith), div_le_div_iff₀ (by linarith) (by positivity)]
  nlinarith [mul_nonneg (mul_nonneg (sub_nonneg.2 hXY) (sub_nonneg.2 hX)) (sub_nonneg.2 hY)]

/-- `tanh(t n) ≤ n tanh t` in the form `(e^{2tn} - 1)/(e^{2tn} + 1)` -/
theorem tanhForm_le (t : ℝ) (ht : 0 ≤ t) (n : ℕ) :
    (Real.exp (2 * t * n) - 1) / (Real.exp (2 * t * n) + 1)
      ≤ n * ((Real.exp (2 * t) - 1) / (Real.exp (2 * t) + 1)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have e : Real.exp (2 * t * ((n + 1 : ℕ) : ℝ)) = Real.exp (2 * t * n) * Real.exp (2 * t) := by
      rw [← Real.exp_add]; congr 1; push_cast; ring
    rw [e]
    have h1 : 1 ≤ Real.exp (2 * t * n) := Real.one_le_exp (by positivity)
    have h2 : 1 ≤ Real.exp (2 * t) := Real.one_le_exp (by positivity)
    refine (tanh_sub_add _ _ h1 h2).trans ?_
    push_cast
    linarith

variable (N : ℕ) [NeZero N]

theorem plaqsAt_card_le (x : Lk N) : (plaqsAt N x).card ≤ 6 := by
  have hmap : (univ.filter (fun q : plaqs N => x ∈ plaqLinks N q.1)).map
      (Function.Embedding.subtype _) = plaqsAt N x := by
    ext p
    simp [plaqsAt, and_comm]
  rw [← hmap, Finset.card_map]
  exact card_link_plaqs N x

theorem sum_n_le (x : Lk N) :
    ∑ y ∈ univ.erase x, ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≤ 18 := by
  have htot : ∑ y, ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card
      = ∑ p ∈ plaqsAt N x, (plaqLinks N p).card := by
    simp only [Finset.card_filter]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun p _ => ?_
    simp
  have hxx : ((plaqsAt N x).filter (fun p => x ∈ plaqLinks N p)).card = (plaqsAt N x).card := by
    rw [Finset.filter_true_of_mem]
    intro p hp
    exact (Finset.mem_filter.1 hp).2
  have hsplit := Finset.sum_erase_add (univ : Finset (Lk N))
    (fun y => ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) (Finset.mem_univ x)
  have h4 : ∑ p ∈ plaqsAt N x, (plaqLinks N p).card ≤ (plaqsAt N x).card * 4 := by
    have := Finset.sum_le_card_nsmul (plaqsAt N x) (fun p => (plaqLinks N p).card) 4
      (fun p _ => card_plaqLinks_le N p)
    simpa using this
  have h6 := plaqsAt_card_le N x
  omega

/-- **The Dobrushin constant of the single-link specification.**  For every link `x`,
`Σ_{y ≠ x} sup_{ω, ω' differing at y} |spec ω' x S - spec ω x S| ≤ 18 tanh |β|`, in the form:
each term is bounded by `tanhForm(|β| n_{xy})` (`spec_coeff`) and these sum to at most
`18 (e^{2|β|} - 1)/(e^{2|β|} + 1)`. -/
theorem dobrushin_row (β : ℝ) (x : Lk N) :
    ∑ y ∈ univ.erase x,
        (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) - 1) /
          (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) + 1)
      ≤ 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) := by
  have hg0 : 0 ≤ (Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1) := by
    have : 1 ≤ Real.exp (2 * |β|) := Real.one_le_exp (by positivity)
    exact div_nonneg (by linarith) (by linarith)
  calc _ ≤ ∑ y ∈ univ.erase x,
        (((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card : ℝ) *
          ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) :=
        Finset.sum_le_sum fun y _ => tanhForm_le |β| (abs_nonneg β) _
    _ = (∑ y ∈ univ.erase x, (((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card : ℝ)) *
          ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) := (Finset.sum_mul _ _ _).symm
    _ ≤ 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) := by
        refine mul_le_mul_of_nonneg_right ?_ hg0
        exact_mod_cast sum_n_le N x

end LinkSpec

#print axioms LinkSpec.tanhForm_le
#print axioms LinkSpec.sum_n_le
#print axioms LinkSpec.dobrushin_row
