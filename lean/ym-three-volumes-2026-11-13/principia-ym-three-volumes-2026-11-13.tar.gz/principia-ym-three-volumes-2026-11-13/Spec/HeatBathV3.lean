import Spec.LinkCoeffV1

/-!
# From sets to functions: the tilted expectation bound 

Paper correspondence: step (iii) of the Dobrushin route (first half).
`tilt_fun_rel`: for two Gibbs weights `e^a`, `e^{a'}` whose difference has oscillation `≤ 2c`, and
`g` with values in `[0, D]`, the two normalised expectations of `g` differ by at most
`D (e^c - 1)/(e^c + 1)`.  The sets `{ρ < ρ'}` and `{ρ' < ρ}` of the two normalised densities are
extremal, so `Tilt.tilt_tv_rel` applies directly (no layer-cake decomposition).
-/

namespace LinkSpec

open MeasureTheory Filter

theorem tilt_fun_rel {Ω : Type*} [MeasurableSpace Ω] (p : Measure Ω) [IsProbabilityMeasure p]
    (a a' : Ω → ℝ) (ha : Measurable a) (ha' : Measurable a') (K : ℝ)
    (hK : ∀ x, |a x| ≤ K) (hK' : ∀ x, |a' x| ≤ K) (m c : ℝ) (hc : 0 ≤ c)
    (hlo : ∀ x, m ≤ a' x - a x) (hhi : ∀ x, a' x - a x ≤ m + 2 * c)
    (g : Ω → ℝ) (hg : Measurable g) (D : ℝ) (hD : 0 ≤ D) (hg0 : ∀ x, 0 ≤ g x)
    (hgD : ∀ x, g x ≤ D) :
    |(∫ x, g x * Real.exp (a' x) ∂p) / (∫ x, Real.exp (a' x) ∂p)
      - (∫ x, g x * Real.exp (a x) ∂p) / (∫ x, Real.exp (a x) ∂p)|
      ≤ D * ((Real.exp c - 1) / (Real.exp c + 1)) := by
  have hbd : ∀ b : Ω → ℝ, (∀ x, |b x| ≤ K) → ∀ x, ‖Real.exp (b x)‖ ≤ Real.exp K :=
    fun b hb x => by
      rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.2 ((le_abs_self _).trans (hb x))
  have ie : Integrable (fun x => Real.exp (a x)) p :=
    Integrable.of_bound (Real.measurable_exp.comp ha).aestronglyMeasurable _
      (Eventually.of_forall (hbd a hK))
  have ie' : Integrable (fun x => Real.exp (a' x)) p :=
    Integrable.of_bound (Real.measurable_exp.comp ha').aestronglyMeasurable _
      (Eventually.of_forall (hbd a' hK'))
  have hgb : ∀ x, |g x| ≤ D := fun x => by rw [abs_of_nonneg (hg0 x)]; exact hgD x
  have igb : ∀ b : Ω → ℝ, Measurable b → (∀ x, |b x| ≤ K) →
      Integrable (fun x => g x * Real.exp (b x)) p := fun b hb hbK =>
    Integrable.of_bound (hg.mul (Real.measurable_exp.comp hb)).aestronglyMeasurable
      (D * Real.exp K) (Eventually.of_forall fun x => by
        rw [norm_mul, Real.norm_eq_abs]
        exact mul_le_mul (hgb x) (hbd b hbK x) (norm_nonneg _) hD)
  set Z := ∫ x, Real.exp (a x) ∂p with hZdef
  set Z' := ∫ x, Real.exp (a' x) ∂p with hZ'def
  have hZ : 0 < Z := integral_exp_pos ie
  have hZ' : 0 < Z' := integral_exp_pos ie'
  set ρ : Ω → ℝ := fun x => Real.exp (a x) / Z with hρ
  set ρ' : Ω → ℝ := fun x => Real.exp (a' x) / Z' with hρ'
  have iρ : Integrable ρ p := ie.div_const Z
  have iρ' : Integrable ρ' p := ie'.div_const Z'
  have mρ : Measurable ρ := (Real.measurable_exp.comp ha).div_const Z
  have mρ' : Measurable ρ' := (Real.measurable_exp.comp ha').div_const Z'
  have idiff : Integrable (fun x => ρ' x - ρ x) p := iρ'.sub iρ
  -- the difference of expectations as one integral
  have e : (∫ x, g x * Real.exp (a' x) ∂p) / Z' - (∫ x, g x * Real.exp (a x) ∂p) / Z
      = ∫ x, g x * (ρ' x - ρ x) ∂p := by
    rw [← integral_div, ← integral_div, ← integral_sub ((igb a' ha' hK').div_const Z')
      ((igb a ha hK).div_const Z)]
    congr 1
    funext x
    simp only [hρ, hρ']
    ring
  -- the indicator integrals
  have hind : ∀ T : Set Ω, MeasurableSet T →
      ∫ x, T.indicator (fun x => D * (ρ' x - ρ x)) x ∂p
        = D * ((∫ x in T, Real.exp (a' x) ∂p) / Z' - (∫ x in T, Real.exp (a x) ∂p) / Z) := by
    intro T hT
    rw [integral_indicator hT, integral_const_mul,
      integral_sub iρ'.integrableOn iρ.integrableOn]
    simp only [hρ, hρ']
    rw [integral_div, integral_div]
  have htv := fun T hT => Tilt.tilt_tv_rel p a a' ha ha' K hK hK' m c hc hlo hhi T hT
  set T₀ := (Real.exp c - 1) / (Real.exp c + 1) with hT₀
  have igd : Integrable (fun x => g x * (ρ' x - ρ x)) p :=
    (((igb a' ha' hK').div_const Z').sub ((igb a ha hK).div_const Z)).congr
      (Eventually.of_forall fun x => by simp only [hρ, hρ', Pi.sub_apply]; ring)
  -- upper bound
  have hS : MeasurableSet {x | ρ x < ρ' x} := measurableSet_lt mρ mρ'
  have up : ∫ x, g x * (ρ' x - ρ x) ∂p ≤ D * T₀ := by
    have hle : ∫ x, g x * (ρ' x - ρ x) ∂p
        ≤ ∫ x, {x | ρ x < ρ' x}.indicator (fun x => D * (ρ' x - ρ x)) x ∂p := by
      refine integral_mono igd ((idiff.const_mul D).indicator hS) (fun x => ?_)
      · by_cases hx : x ∈ {x | ρ x < ρ' x}
        · rw [Set.indicator_of_mem hx]
          exact mul_le_mul_of_nonneg_right (hgD x) (le_of_lt (sub_pos.2 hx))
        · rw [Set.indicator_of_notMem hx]
          exact mul_nonpos_of_nonneg_of_nonpos (hg0 x) (by simp at hx; linarith)
    rw [hind _ hS] at hle
    have := (abs_le.1 (htv _ hS)).2
    exact hle.trans (mul_le_mul_of_nonneg_left this hD)
  -- lower bound
  have hS2 : MeasurableSet {x | ρ' x < ρ x} := measurableSet_lt mρ' mρ
  have low : -(D * T₀) ≤ ∫ x, g x * (ρ' x - ρ x) ∂p := by
    have hge : ∫ x, {x | ρ' x < ρ x}.indicator (fun x => D * (ρ' x - ρ x)) x ∂p
        ≤ ∫ x, g x * (ρ' x - ρ x) ∂p := by
      refine integral_mono ((idiff.const_mul D).indicator hS2) igd (fun x => ?_)
      by_cases hx : x ∈ {x | ρ' x < ρ x}
      · rw [Set.indicator_of_mem hx]
        have h := mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.2 (hgD x))
          (sub_nonpos.2 (le_of_lt (show ρ' x < ρ x from hx)))
        nlinarith [h]
      · rw [Set.indicator_of_notMem hx]
        exact mul_nonneg (hg0 x) (by simp at hx; linarith)
    rw [hind _ hS2] at hge
    have h1 := mul_le_mul_of_nonneg_left (abs_le.1 (htv _ hS2)).1 hD
    linarith
  rw [e]
  exact abs_le.2 ⟨low, up⟩


open TorusRP

variable (N : ℕ) [NeZero N]

/-- the normalised single-link average of a function of the link variable -/
noncomputable def avg (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (h : QBall → ℝ) : ℝ :=
  (∫ U, h U * Real.exp (locAct N β ω x U) ∂haarBall) /
    (∫ U, Real.exp (locAct N β ω x U) ∂haarBall)

/-- the heat-bath operator `P_x f (ω) = ∫ f(ω[x ↦ U]) γ_x(dU | ω)` -/
noncomputable def heatBath (β : ℝ) (x : Lk N) (f : (Lk N → QBall) → ℝ) (ω : Lk N → QBall) : ℝ :=
  avg N β ω x (fun U => f (Function.update ω x U))

theorem integrable_expLoc (β : ℝ) (ω : Lk N → QBall) (x : Lk N) :
    Integrable (fun U => Real.exp (locAct N β ω x U)) haarBall :=
  Integrable.of_bound (Real.continuous_exp.comp (continuous_locAct N β ω x)).aestronglyMeasurable
    (Real.exp (|β| * (plaqsAt N x).card)) (Eventually.of_forall fun U => by
      rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.2 ((le_abs_self _).trans (abs_locAct_le N β ω x U)))

theorem integrable_mulLoc (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (h : QBall → ℝ)
    (hh : Measurable h) (C : ℝ) (hC : ∀ U, |h U| ≤ C) :
    Integrable (fun U => h U * Real.exp (locAct N β ω x U)) haarBall :=
  Integrable.of_bound (hh.mul (Real.continuous_exp.comp (continuous_locAct N β ω x)).measurable
      ).aestronglyMeasurable (C * Real.exp (|β| * (plaqsAt N x).card))
    (Eventually.of_forall fun U => by
      rw [norm_mul, Real.norm_eq_abs, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
      exact mul_le_mul (hC U) (Real.exp_le_exp.2 ((le_abs_self _).trans
        (abs_locAct_le N β ω x U))) (Real.exp_pos _).le ((abs_nonneg _).trans (hC U)))

theorem avg_add_const (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (h : QBall → ℝ)
    (hh : Integrable (fun U => h U * Real.exp (locAct N β ω x U)) haarBall) (k : ℝ) :
    avg N β ω x (fun U => h U + k) = avg N β ω x h + k := by
  have hZ : 0 < ∫ U, Real.exp (locAct N β ω x U) ∂haarBall :=
    integral_exp_pos (integrable_expLoc N β ω x)
  unfold avg
  rw [show (fun U => (h U + k) * Real.exp (locAct N β ω x U))
      = fun U => h U * Real.exp (locAct N β ω x U) + k * Real.exp (locAct N β ω x U) by
    funext U; ring, integral_add hh ((integrable_expLoc N β ω x).const_mul k),
    integral_const_mul, add_div, mul_div_assoc, div_self hZ.ne', mul_one]

theorem avg_sub (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (h₁ h₂ : QBall → ℝ)
    (h₁i : Integrable (fun U => h₁ U * Real.exp (locAct N β ω x U)) haarBall)
    (h₂i : Integrable (fun U => h₂ U * Real.exp (locAct N β ω x U)) haarBall) :
    avg N β ω x (fun U => h₁ U - h₂ U) = avg N β ω x h₁ - avg N β ω x h₂ := by
  unfold avg
  rw [show (fun U => (h₁ U - h₂ U) * Real.exp (locAct N β ω x U))
      = fun U => h₁ U * Real.exp (locAct N β ω x U) - h₂ U * Real.exp (locAct N β ω x U) by
    funext U; ring, integral_sub h₁i h₂i, sub_div]

theorem abs_avg_le (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (h : QBall → ℝ) (hh : Measurable h)
    (C : ℝ) (hC : ∀ U, |h U| ≤ C) : |avg N β ω x h| ≤ C := by
  have hZ : 0 < ∫ U, Real.exp (locAct N β ω x U) ∂haarBall :=
    integral_exp_pos (integrable_expLoc N β ω x)
  unfold avg
  rw [abs_div, abs_of_pos hZ, div_le_iff₀ hZ]
  have key : ‖∫ U, h U * Real.exp (locAct N β ω x U) ∂haarBall‖
      ≤ ∫ U, C * Real.exp (locAct N β ω x U) ∂haarBall := by
    refine norm_integral_le_of_norm_le ((integrable_expLoc N β ω x).const_mul C)
      (Eventually.of_forall fun U => ?_)
    rw [Real.norm_eq_abs, abs_mul, abs_of_pos (Real.exp_pos _)]
    exact mul_le_mul_of_nonneg_right (hC U) (Real.exp_pos _).le
  rw [integral_const_mul, Real.norm_eq_abs] at key
  exact key

/-- **Heat-bath oscillation bound** (Dobrushin's inequality for one site):
`δ_y(P_x f) ≤ δ_y(f) + C_{xy} δ_x(f)`, `C_{xy} = tanh(|β| n_{xy})`. -/
theorem heatBath_osc (β : ℝ) (x y : Lk N) (hxy : x ≠ y) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (Cf : ℝ) (hfb : ∀ ω, |f ω| ≤ Cf) (Dx Dy : ℝ) (hDx : 0 ≤ Dx)
    (hfx : ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ x → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ Dx)
    (hfy : ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ Dy)
    (ω ω' : Lk N → QBall) (hω : ∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) :
    |heatBath N β x f ω' - heatBath N β x f ω|
      ≤ Dy + Dx * ((Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card)
          - 1) / (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card)
          + 1)) := by
  set F' : QBall → ℝ := fun U => f (Function.update ω' x U) with hF'
  set F : QBall → ℝ := fun U => f (Function.update ω x U) with hF
  have hupd : Continuous (fun U : QBall => Function.update ω' x U) :=
    continuous_const.update x continuous_id
  have hupd' : Continuous (fun U : QBall => Function.update ω x U) :=
    continuous_const.update x continuous_id
  have mF' : Measurable F' := hf.comp hupd.measurable
  have mF : Measurable F := hf.comp hupd'.measurable
  have bF' : ∀ U, |F' U| ≤ Cf := fun U => hfb _
  have bF : ∀ U, |F U| ≤ Cf := fun U => hfb _
  -- the range of F' has width ≤ Dx
  have hwid : ∀ U V, |F' U - F' V| ≤ Dx := fun U V => hfx _ _ (fun ℓ hℓ => by
    rw [Function.update_of_ne hℓ, Function.update_of_ne hℓ])
  set U₀ : QBall := Classical.arbitrary QBall
  have hbdd : BddBelow (Set.range F') := ⟨F' U₀ - Dx, by
    rintro _ ⟨U, rfl⟩
    linarith [(abs_le.1 (hwid U₀ U)).2]⟩
  set lo := sInf (Set.range F') with hlo
  have hg0 : ∀ U, 0 ≤ F' U - lo := fun U => sub_nonneg.2 (csInf_le hbdd ⟨U, rfl⟩)
  have hgD : ∀ U, F' U - lo ≤ Dx := fun U => by
    have : F' U - Dx ≤ lo := le_csInf ⟨F' U₀, U₀, rfl⟩ (by
      rintro _ ⟨V, rfl⟩
      linarith [(abs_le.1 (hwid U V)).2])
    linarith
  -- the two averages of F' and the shift by lo
  have iF'ω' := integrable_mulLoc N β ω' x F' mF' Cf bF'
  have iF'ω := integrable_mulLoc N β ω x F' mF' Cf bF'
  have iFω := integrable_mulLoc N β ω x F mF Cf bF
  have mg : Measurable (fun U => F' U - lo) := mF'.sub measurable_const
  have bg : ∀ U, |F' U - lo| ≤ Dx := fun U => by
    rw [abs_of_nonneg (hg0 U)]; exact hgD U
  have s1 : avg N β ω' x F' = avg N β ω' x (fun U => F' U - lo) + lo := by
    rw [← avg_add_const N β ω' x _ (integrable_mulLoc N β ω' x _ mg Dx bg)]
    congr 1; funext U; ring
  have s2 : avg N β ω x F' = avg N β ω x (fun U => F' U - lo) + lo := by
    rw [← avg_add_const N β ω x _ (integrable_mulLoc N β ω x _ mg Dx bg)]
    congr 1; funext U; ring
  have hd := locAct_diff N β ω ω' x y hω
  set n : ℝ := (((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card : ℝ) with hn
  have t1 : |avg N β ω' x (fun U => F' U - lo) - avg N β ω x (fun U => F' U - lo)|
      ≤ Dx * ((Real.exp (2 * |β| * n) - 1) / (Real.exp (2 * |β| * n) + 1)) :=
    tilt_fun_rel haarBall (locAct N β ω x) (locAct N β ω' x)
      (continuous_locAct N β ω x).measurable (continuous_locAct N β ω' x).measurable
      (|β| * (plaqsAt N x).card) (abs_locAct_le N β ω x) (abs_locAct_le N β ω' x)
      (-(2 * |β| * n)) (2 * |β| * n) (by positivity)
      (fun U => by linarith [(abs_le.1 (hd U)).1])
      (fun U => by linarith [(abs_le.1 (hd U)).2]) _ mg Dx hDx hg0 hgD
  have s3 : avg N β ω x F' - avg N β ω x F = avg N β ω x (fun U => F' U - F U) :=
    (avg_sub N β ω x F' F iF'ω iFω).symm
  have t2 : |avg N β ω x (fun U => F' U - F U)| ≤ Dy :=
    abs_avg_le N β ω x _ (mF'.sub mF) Dy (fun U => hfy _ _ (fun ℓ hℓ => by
      by_cases hℓx : ℓ = x
      · rw [hℓx, Function.update_self, Function.update_self]
      · rw [Function.update_of_ne hℓx, Function.update_of_ne hℓx]; exact (hω ℓ hℓ).symm))
  show |avg N β ω' x F' - avg N β ω x F| ≤ _
  have : avg N β ω' x F' - avg N β ω x F
      = (avg N β ω' x (fun U => F' U - lo) - avg N β ω x (fun U => F' U - lo))
        + avg N β ω x (fun U => F' U - F U) := by
    rw [← s3, s1, s2]; ring
  rw [this]
  calc _ ≤ |avg N β ω' x (fun U => F' U - lo) - avg N β ω x (fun U => F' U - lo)|
        + |avg N β ω x (fun U => F' U - F U)| := abs_add_le _ _
    _ ≤ Dx * ((Real.exp (2 * |β| * n) - 1) / (Real.exp (2 * |β| * n) + 1)) + Dy :=
        add_le_add t1 t2
    _ = _ := by ring

end LinkSpec

#print axioms LinkSpec.tilt_fun_rel
#print axioms LinkSpec.heatBath_osc
