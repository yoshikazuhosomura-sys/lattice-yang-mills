import Lattice.TorusDecV2
import Tilt.TiltRelV1

/-!
# The Dobrushin coefficient of the single-link Wilson specification on `(ℤ/N)⁴` 

Paper correspondence: (the Dobrushin route, step (ii)). `spec N β ω x S` is the
heat-bath kernel of the link `x` (Haar measure on the link variable tilted by the local action
`β Σ_{p ∋ x} Re U_p`, other links frozen at `ω`), written as a ratio of integrals.  If `ω`, `ω'`
differ only at a link `y ≠ x`, then `|spec ω' x S - spec ω x S| ≤ tanh(|β| n_{xy})`, written as
`(e^{2|β| n} - 1)/(e^{2|β| n} + 1)`, where `n_{xy}` is the number of plaquettes containing both
`x` and `y`.  Only `|Re U_p| ≤ 1` is used.  That the Wilson measure is Gibbs for this
specification (DLR) and Dobrushin's comparison theorem are not in Lean.
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset

variable (N : ℕ) [NeZero N]

/-- plaquettes containing the link `x` -/
noncomputable def plaqsAt (x : Lk N) : Finset (Lk N × Fin 4) :=
  (plaqs N).filter (fun p => x ∈ plaqLinks N p)

/-- the local action of the link `x` (other links frozen at `ω`, `x` set to `U`) -/
noncomputable def locAct (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (U : QBall) : ℝ :=
  β * ∑ p ∈ plaqsAt N x, (hol N (Function.update ω x U) p).re

/-- the single-link specification (heat-bath kernel) -/
noncomputable def spec (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (S : Set QBall) : ℝ :=
  (∫ U in S, Real.exp (locAct N β ω x U) ∂haarBall) / (∫ U, Real.exp (locAct N β ω x U) ∂haarBall)

theorem hol_dep (ω ω' : Lk N → QBall) (p : Lk N × Fin 4)
    (h : ∀ ℓ ∈ plaqLinks N p, ω ℓ = ω' ℓ) : hol N ω p = hol N ω' p := by
  unfold hol holQ Uq
  rw [h p.1 (by simp [plaqLinks]), h (p.1.1 + ev N p.1.2, p.2) (by simp [plaqLinks]),
    h (p.1.1 + ev N p.2, p.1.2) (by simp [plaqLinks]), h (p.1.1, p.2) (by simp [plaqLinks])]

theorem continuous_locAct (β : ℝ) (ω : Lk N → QBall) (x : Lk N) :
    Continuous (locAct N β ω x) :=
  continuous_const.mul (continuous_finset_sum _ fun p _ =>
    Quaternion.continuous_re.comp ((continuous_hol N p).comp
      (continuous_const.update x continuous_id)))

theorem abs_locAct_le (β : ℝ) (ω : Lk N → QBall) (x : Lk N) (U : QBall) :
    |locAct N β ω x U| ≤ |β| * (plaqsAt N x).card := by
  unfold locAct
  rw [abs_mul]
  refine mul_le_mul_of_nonneg_left ?_ (abs_nonneg _)
  calc |∑ p ∈ plaqsAt N x, (hol N (Function.update ω x U) p).re|
      ≤ ∑ p ∈ plaqsAt N x, |(hol N (Function.update ω x U) p).re| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _p ∈ plaqsAt N x, (1 : ℝ) := Finset.sum_le_sum fun p _ => abs_hol_re N _ p
    _ = (plaqsAt N x).card := by simp

/-- changing one link `y ≠ x` changes the local action of `x` by at most `2|β| n_{xy}` -/
theorem locAct_diff (β : ℝ) (ω ω' : Lk N → QBall) (x y : Lk N)
    (hω : ∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) (U : QBall) :
    |locAct N β ω' x U - locAct N β ω x U|
      ≤ 2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card := by
  unfold locAct
  rw [← mul_sub, ← Finset.sum_sub_distrib, abs_mul,
    ← Finset.sum_filter_add_sum_filter_not (plaqsAt N x) (fun p => y ∈ plaqLinks N p)]
  have h0 : ∑ p ∈ (plaqsAt N x).filter (fun p => ¬ y ∈ plaqLinks N p),
      ((hol N (Function.update ω' x U) p).re - (hol N (Function.update ω x U) p).re) = 0 := by
    refine Finset.sum_eq_zero fun p hp => ?_
    have hy : ¬ y ∈ plaqLinks N p := (Finset.mem_filter.1 hp).2
    rw [hol_dep N (Function.update ω' x U) (Function.update ω x U) p (fun ℓ hℓ => ?_), sub_self]
    by_cases hℓx : ℓ = x
    · simp [hℓx]
    · rw [Function.update_of_ne hℓx, Function.update_of_ne hℓx]
      exact (hω ℓ (fun h => hy (h ▸ hℓ))).symm
  rw [h0, add_zero]
  have h1 : |∑ p ∈ (plaqsAt N x).filter (fun p => y ∈ plaqLinks N p),
      ((hol N (Function.update ω' x U) p).re - (hol N (Function.update ω x U) p).re)|
      ≤ ∑ _p ∈ (plaqsAt N x).filter (fun p => y ∈ plaqLinks N p), (2 : ℝ) := by
    refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun p _ => ?_)
    have a1 := abs_le.1 (abs_hol_re N (Function.update ω' x U) p)
    have a2 := abs_le.1 (abs_hol_re N (Function.update ω x U) p)
    exact abs_le.2 ⟨by linarith [a1.1, a2.2], by linarith [a1.2, a2.1]⟩
  rw [Finset.sum_const, nsmul_eq_mul] at h1
  calc |β| * |∑ p ∈ (plaqsAt N x).filter (fun p => y ∈ plaqLinks N p),
        ((hol N (Function.update ω' x U) p).re - (hol N (Function.update ω x U) p).re)|
      ≤ |β| * (((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card * 2) :=
        mul_le_mul_of_nonneg_left h1 (abs_nonneg _)
    _ = 2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card := by ring

/-- **The Dobrushin coefficient of one pair of links.**  `C_{xy} ≤ tanh(|β| n_{xy})`. -/
theorem spec_coeff (β : ℝ) (ω ω' : Lk N → QBall) (x y : Lk N)
    (hω : ∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) (S : Set QBall) (hS : MeasurableSet S) :
    |spec N β ω' x S - spec N β ω x S|
      ≤ (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) - 1) /
        (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) + 1) := by
  have hd := locAct_diff N β ω ω' x y hω
  set n : ℝ := (((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card : ℝ) with hn
  have hn0 : 0 ≤ n := Nat.cast_nonneg _
  unfold spec
  exact Tilt.tilt_tv_rel haarBall (locAct N β ω x) (locAct N β ω' x)
    (continuous_locAct N β ω x).measurable (continuous_locAct N β ω' x).measurable
    (|β| * (plaqsAt N x).card) (abs_locAct_le N β ω x) (abs_locAct_le N β ω' x)
    (-(2 * |β| * n)) (2 * |β| * n) (by positivity)
    (fun U => by linarith [(abs_le.1 (hd U)).1])
    (fun U => by linarith [(abs_le.1 (hd U)).2]) S hS

end LinkSpec

#print axioms LinkSpec.locAct_diff
#print axioms LinkSpec.spec_coeff
