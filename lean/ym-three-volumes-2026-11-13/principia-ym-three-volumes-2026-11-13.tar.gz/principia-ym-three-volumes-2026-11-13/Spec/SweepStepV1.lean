import Spec.HeatBathV3
import Spec.DobrushinRowV2

/-!
# One heat-bath step on the oscillation vector 

The single-site input of Dobrushin's sweep argument, as one statement.  If `δ y` bounds the change
of `f` under changes of the link `y`, then after the heat-bath step at `x` the vector
`δ' x = 0`, `δ' y = δ y + δ x · tanh(|β| n_{xy})` bounds the changes of `P_x f`, and
`Σ_y δ' y ≤ Σ_y δ y - (1 - 18 tanh|β|) δ x` (`dobrushin_row`).  The sweep over all links and the
comparison theorem are not in Lean.
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset

variable (N : ℕ) [NeZero N]

theorem heatBath_update (β : ℝ) (x : Lk N) (f : (Lk N → QBall) → ℝ) (ω : Lk N → QBall)
    (V : QBall) : heatBath N β x f (Function.update ω x V) = heatBath N β x f ω := by
  unfold heatBath avg locAct
  simp only [Function.update_idem]

/-- the coefficient `tanh(|β| n_{xy})` in the form `(e^{2|β| n} - 1)/(e^{2|β| n} + 1)` -/
noncomputable def coef (β : ℝ) (x y : Lk N) : ℝ :=
  (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) - 1) /
    (Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) + 1)

theorem sweep_step (β : ℝ) (x : Lk N) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) (Cf : ℝ)
    (hfb : ∀ ω, |f ω| ≤ Cf) (δ : Lk N → ℝ) (hδ0 : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ δ y) :
    (∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
        |heatBath N β x f ω - heatBath N β x f ω'|
          ≤ (if y = x then 0 else δ y + δ x * coef N β x y)) ∧
      ∑ y, (if y = x then 0 else δ y + δ x * coef N β x y)
        ≤ ∑ y, δ y - δ x + 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) * δ x := by
  constructor
  · intro y ω ω' h
    by_cases hy : y = x
    · rw [if_pos hy]
      subst hy
      have e : ω' = Function.update ω y (ω' y) := by
        funext ℓ
        by_cases hℓ : ℓ = y
        · rw [hℓ, Function.update_self]
        · rw [Function.update_of_ne hℓ]; exact (h ℓ hℓ).symm
      rw [e, heatBath_update, sub_self, abs_zero]
    · rw [if_neg hy, abs_sub_comm]
      exact heatBath_osc N β x y (Ne.symm hy) f hf Cf hfb (δ x) (δ y) (hδ0 x) (hosc x)
        (hosc y) ω ω' h
  · rw [← Finset.sum_erase_add _ _ (Finset.mem_univ x), if_pos rfl, add_zero,
      ← Finset.sum_erase_add _ δ (Finset.mem_univ x)]
    have e : ∑ y ∈ univ.erase x, (if y = x then 0 else δ y + δ x * coef N β x y)
        = ∑ y ∈ univ.erase x, δ y + δ x * ∑ y ∈ univ.erase x, coef N β x y := by
      rw [Finset.mul_sum, ← Finset.sum_add_distrib]
      refine Finset.sum_congr rfl fun y hy => ?_
      rw [if_neg (Finset.ne_of_mem_erase hy)]
    rw [e]
    have hrow : ∑ y ∈ univ.erase x, coef N β x y
        ≤ 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) := dobrushin_row N β x
    have := mul_le_mul_of_nonneg_left hrow (hδ0 x)
    linarith

end LinkSpec

#print axioms LinkSpec.sweep_step
