import Spec.LinkCoeffV1
import Lattice.WilsonGapV2

/-!
# The Wilson measure is Gibbs for the single-link specification (DLR, one link) — 

Paper correspondence: step (i) of the Dobrushin route. For every link `x` and every
bounded measurable `H`,
`∫ H dμ_W = ∫ (∫ H(ω[x ↦ U]) e^{locAct ω x U} dU / ∫ e^{locAct ω x U} dU) dμ_W(ω)`
(`dlr`), where `μ_W = wilsonMeasure N β` (unnormalised; the identity is linear in the measure).
Ingredients: resampling one coordinate preserves the product Haar measure (`update_preserving`),
the Wilson weight factorises as (plaquettes not containing `x`) × `e^{locAct}` (`weight_split`).
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset Filter

variable (N : ℕ) [NeZero N]

/-- resampling the coordinate `x` preserves the product Haar measure -/
theorem update_preserving (x : Lk N) :
    MeasurePreserving (fun z : (Lk N → QBall) × QBall => Function.update z.1 x z.2)
      ((Measure.pi fun _ : Lk N => haarBall).prod haarBall) (Measure.pi fun _ : Lk N => haarBall) := by
  have hmeas : Measurable (fun z : (Lk N → QBall) × QBall => Function.update z.1 x z.2) :=
    (continuous_fst.update x continuous_snd).measurable
  refine ⟨hmeas, (Measure.pi_eq fun s hs => ?_).symm⟩
  rw [Measure.map_apply hmeas (MeasurableSet.univ_pi hs)]
  have hpre : (fun z : (Lk N → QBall) × QBall => Function.update z.1 x z.2) ⁻¹' Set.univ.pi s
      = (Set.univ.pi (Function.update s x Set.univ)) ×ˢ s x := by
    ext ⟨ω, U⟩
    simp only [Set.mem_preimage, Set.mem_pi, Set.mem_univ, true_implies, Set.mem_prod]
    constructor
    · intro h
      refine ⟨fun i => ?_, ?_⟩
      · by_cases hi : i = x
        · rw [hi, Function.update_self]; exact Set.mem_univ _
        · have := h i
          simpa [Function.update_of_ne hi] using this
      · have := h x
        rwa [Function.update_self] at this
    · rintro ⟨h1, h2⟩ i
      by_cases hi : i = x
      · rw [hi, Function.update_self]; exact h2
      · have := h1 i
        simpa [Function.update_of_ne hi] using this
  rw [hpre, Measure.prod_prod, Measure.pi_pi]
  have e : ∀ i, haarBall (Function.update s x Set.univ i)
      = Function.update (fun i => haarBall (s i)) x 1 i := by
    intro i
    by_cases hi : i = x
    · rw [hi, Function.update_self, Function.update_self, measure_univ]
    · rw [Function.update_of_ne hi, Function.update_of_ne hi]
  simp_rw [e]
  rw [Finset.prod_update_of_mem (Finset.mem_univ x), one_mul, Finset.sdiff_singleton_eq_erase,
    mul_comm, Finset.mul_prod_erase _ (fun i => haarBall (s i)) (Finset.mem_univ x)]

/-- the Wilson weight of the plaquettes not containing `x` -/
noncomputable def restW (β : ℝ) (x : Lk N) (ω : Lk N → QBall) : ℝ :=
  Real.exp (β * ∑ p ∈ (plaqs N).filter (fun p => ¬ x ∈ plaqLinks N p), (hol N ω p).re)

theorem weight_split (β : ℝ) (x : Lk N) (ω : Lk N → QBall) :
    wilsonWeight N β ω = restW N β x ω * Real.exp (locAct N β ω x (ω x)) := by
  unfold wilsonWeight action restW locAct plaqsAt
  rw [Function.update_eq_self,
    ← Finset.sum_filter_add_sum_filter_not (plaqs N) (fun p => x ∈ plaqLinks N p), mul_add,
    Real.exp_add]
  ring

theorem restW_update (β : ℝ) (x : Lk N) (ω : Lk N → QBall) (U : QBall) :
    restW N β x (Function.update ω x U) = restW N β x ω := by
  unfold restW
  congr 2
  refine Finset.sum_congr rfl fun p hp => ?_
  rw [hol_dep N (Function.update ω x U) ω p (fun ℓ hℓ => ?_)]
  have hne : ℓ ≠ x := fun h => (Finset.mem_filter.1 hp).2 (h ▸ hℓ)
  rw [Function.update_of_ne hne]

theorem locAct_update (β : ℝ) (x : Lk N) (ω : Lk N → QBall) (V U : QBall) :
    locAct N β (Function.update ω x V) x U = locAct N β ω x U := by
  unfold locAct
  rw [Function.update_idem]

/-- numerator and denominator of the specification average of `H` -/
noncomputable def specNum (β : ℝ) (x : Lk N) (H : (Lk N → QBall) → ℝ) (ω : Lk N → QBall) : ℝ :=
  ∫ U, H (Function.update ω x U) * Real.exp (locAct N β ω x U) ∂haarBall

noncomputable def specDen (β : ℝ) (x : Lk N) (ω : Lk N → QBall) : ℝ :=
  ∫ U, Real.exp (locAct N β ω x U) ∂haarBall

theorem specNum_update (β : ℝ) (x : Lk N) (H : (Lk N → QBall) → ℝ) (ω : Lk N → QBall)
    (V : QBall) : specNum N β x H (Function.update ω x V) = specNum N β x H ω := by
  unfold specNum
  simp only [Function.update_idem, locAct_update]

theorem specDen_update (β : ℝ) (x : Lk N) (ω : Lk N → QBall) (V : QBall) :
    specDen N β x (Function.update ω x V) = specDen N β x ω := by
  unfold specDen
  simp only [locAct_update]

theorem continuous_locAct₂ (β : ℝ) (x : Lk N) :
    Continuous (fun z : (Lk N → QBall) × QBall => locAct N β z.1 x z.2) :=
  continuous_const.mul (continuous_finset_sum _ fun p _ =>
    Quaternion.continuous_re.comp ((continuous_hol N p).comp
      (continuous_fst.update x continuous_snd)))

theorem integrable_exp_locAct (β : ℝ) (x : Lk N) (ω : Lk N → QBall) :
    Integrable (fun U => Real.exp (locAct N β ω x U)) haarBall :=
  Integrable.of_bound (Real.continuous_exp.comp (continuous_locAct N β ω x)).aestronglyMeasurable
    (Real.exp (|β| * (plaqsAt N x).card)) (Eventually.of_forall fun U => by
      rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.2 ((le_abs_self _).trans (abs_locAct_le N β ω x U)))

theorem specDen_pos (β : ℝ) (x : Lk N) (ω : Lk N → QBall) : 0 < specDen N β x ω :=
  integral_exp_pos (integrable_exp_locAct N β x ω)

theorem abs_spec_le (β : ℝ) (x : Lk N) (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (CH : ℝ)
    (hHb : ∀ ω, |H ω| ≤ CH) (ω : Lk N → QBall) :
    |specNum N β x H ω / specDen N β x ω| ≤ CH := by
  have hd := specDen_pos N β x ω
  rw [abs_div, abs_of_pos hd, div_le_iff₀ hd]
  have hint := (integrable_exp_locAct N β x ω).const_mul CH
  have key : ‖specNum N β x H ω‖ ≤ ∫ U, CH * Real.exp (locAct N β ω x U) ∂haarBall := by
    refine norm_integral_le_of_norm_le hint (Eventually.of_forall fun U => ?_)
    rw [Real.norm_eq_abs, abs_mul, abs_of_pos (Real.exp_pos _)]
    exact mul_le_mul_of_nonneg_right (hHb _) (Real.exp_pos _).le
  rw [integral_const_mul, Real.norm_eq_abs] at key
  exact key

/-- **DLR for one link.** -/
theorem dlr (β : ℝ) (x : Lk N) (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (CH : ℝ)
    (hHb : ∀ ω, |H ω| ≤ CH) :
    ∫ ω, H ω ∂(wilsonMeasure N β)
      = ∫ ω, specNum N β x H ω / specDen N β x ω ∂(wilsonMeasure N β) := by
  have hmp := update_preserving N x
  have hf := hmp.measurable
  have hCH : 0 ≤ CH := (abs_nonneg _).trans (hHb (fun _ => ⟨0, by simp⟩))
  have transfer : ∀ g : (Lk N → QBall) → ℝ, Measurable g → (∀ ω, |g ω| ≤ CH * Real.exp (|β| * (plaqs N).card)) →
      ∫ ω, g ω ∂(Measure.pi fun _ : Lk N => haarBall)
        = ∫ ω, ∫ U, g (Function.update ω x U) ∂haarBall ∂(Measure.pi fun _ : Lk N => haarBall) := by
    intro g hg hC
    conv_lhs => rw [← hmp.map_eq]
    rw [integral_map hf.aemeasurable hg.aestronglyMeasurable]
    exact integral_prod _ (Integrable.of_bound (hg.comp hf).aestronglyMeasurable _
      (Eventually.of_forall fun z => by rw [Real.norm_eq_abs]; exact hC _))
  have hWpos : ∀ ω, 0 < wilsonWeight N β ω := fun ω => Real.exp_pos _
  have hWm := (continuous_wilsonWeight N β).measurable
  have hNum : Measurable (fun ω => specNum N β x H ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        H (Function.update z.1 x z.2) * Real.exp (locAct N β z.1 x z.2)) :=
      ((hH.comp hf).mul (Real.continuous_exp.comp (continuous_locAct₂ N β x)).measurable).stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hDen : Measurable (fun ω => specDen N β x ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        Real.exp (locAct N β z.1 x z.2)) :=
      (Real.continuous_exp.comp (continuous_locAct₂ N β x)).measurable.stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hbound : ∀ (h : (Lk N → QBall) → ℝ), (∀ ω, |h ω| ≤ CH) →
      ∀ ω, |h ω * wilsonWeight N β ω| ≤ CH * Real.exp (|β| * (plaqs N).card) := by
    intro h hb ω
    rw [abs_mul, abs_of_pos (hWpos ω)]
    exact mul_le_mul (hb ω) (wilsonWeight_le N β ω) (hWpos ω).le hCH
  rw [integral_wilson, integral_wilson,
    transfer (fun ω => H ω * wilsonWeight N β ω) (hH.mul hWm) (hbound H hHb),
    transfer (fun ω => specNum N β x H ω / specDen N β x ω * wilsonWeight N β ω)
      ((hNum.div hDen).mul hWm) (hbound _ (abs_spec_le N β x H hH CH hHb))]
  refine integral_congr_ae (Eventually.of_forall fun ω => ?_)
  have hW : ∀ U, wilsonWeight N β (Function.update ω x U)
      = restW N β x ω * Real.exp (locAct N β ω x U) := fun U => by
    rw [weight_split N β x, restW_update, Function.update_self, locAct_update]
  simp only [hW, specNum_update, specDen_update]
  have hd := (specDen_pos N β x ω).ne'
  have e1 : ∫ U, H (Function.update ω x U) * (restW N β x ω * Real.exp (locAct N β ω x U)) ∂haarBall
      = restW N β x ω * specNum N β x H ω := by
    rw [specNum, ← integral_const_mul]
    congr 1
    funext U
    ring
  have e2 : ∫ U, specNum N β x H ω / specDen N β x ω *
      (restW N β x ω * Real.exp (locAct N β ω x U)) ∂haarBall
      = restW N β x ω * specNum N β x H ω := by
    rw [integral_const_mul, integral_const_mul]
    show specNum N β x H ω / specDen N β x ω * (restW N β x ω * specDen N β x ω) = _
    rw [div_mul_eq_mul_div, div_eq_iff hd]
    ring
  rw [e1, e2]

end LinkSpec

#print axioms LinkSpec.update_preserving
#print axioms LinkSpec.weight_split
#print axioms LinkSpec.dlr
