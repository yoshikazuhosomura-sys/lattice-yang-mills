import Fermion.SliceWilsonV6d

/-! # the concrete Wilson gauge weight on the physical links, its split, reflection positivity and `Z > 0`

Paper side: (the split of the Wilson action at the site planes `t = 0`, `t = h`), 

The physical links of the torus `(time circle 2h) × (Fin N)³` are `PhysLink N h = Fin (2h) × site × Fin 4`
(`μ < 3` spatial `x → x + e_μ` on slice `t`, `μ = 3` the time link `t → t + 1`).  The Wilson action is defined
directly on a configuration `ω : PhysLink → SU2`:

  `S_W(ω) = Σ_{t < 2h} Σ_x [ Σ_{i < j} (1 − ½ Re tr U_{ij}(t, x)) + Σ_i (1 − ½ Re tr U_{i4}(t, x)) ]`,

`U_{μν}(x) = U_μ(x) U_ν(x + μ̂) U_μ(x + ν̂)† U_ν(x)†`, each unoriented plaquette once (spatial `i < j` on slice `t`,
temporal `(i, 4)` between slices `t` and `t + 1 mod 2h`).  Concrete: the action, the weight `exp(−β S_W)`, every
`β ∈ ℝ`.  Proved: `S_W(ω) = K(c) + H(c, a₊) + H(c, a₋)` where `(c, a₊, a₋) = configSplit (linkEquiv) (sigInv) ω`
(planes, positive side, reflected negative side with inverted time links) and `H` is one function used for both
sides (the reflected temporal plaquettes have the same `Re tr`: `plaqE_reflect`).  Then the abstract `k`, `hw` of
`site_reflection_positive_phys` and `w` of `partition_pos_wilson_SU2` are instantiated with `exp(−βK)`,
`exp(−βH)`. -/

namespace WilsonGauge

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection

/-! ## 1. Plaquettes -/

/-- the plaquette energy `1 − ½ Re tr (A B C† D†)` -/
noncomputable def plaqE (A B C D : Matrix (Fin 2) (Fin 2) ℂ) : ℝ :=
  1 - (1 / 2 : ℝ) * (Matrix.trace (A * B * Cᴴ * Dᴴ)).re

/-- **reflection of a temporal plaquette**: with the time links reversed (`†`) and the two slices exchanged, the
plaquette energy is unchanged (trace is cyclic and `tr M† = conj tr M`) -/
theorem plaqE_reflect (B0 B1 A A' : Matrix (Fin 2) (Fin 2) ℂ) :
    plaqE B1 A'ᴴ B0 Aᴴ = plaqE B0 A' B1 A := by
  unfold plaqE
  have h1 : (B1 * A'ᴴ * B0ᴴ * Aᴴᴴ).trace = ((B0 * A' * B1ᴴ * Aᴴ)ᴴ).trace := by
    simp only [conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]
    rw [Matrix.trace_mul_comm A]
    simp only [Matrix.mul_assoc]
  rw [h1, Matrix.trace_conjTranspose, Complex.star_def, Complex.conj_re]

/-- the unit vector `e_i` on the spatial torus -/
def ev (N : ℕ) [NeZero N] (i : Fin 3) : Fin 3 → Fin N := Pi.single i 1

/-- spatial plaquettes of one slice with spatial links `B x i` -/
noncomputable def spS (N : ℕ) [NeZero N] (B : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) : ℝ :=
  ∑ x, ∑ i : Fin 3, ∑ j ∈ Finset.Ioi i, plaqE (B x i) (B (x + ev N i) j) (B (x + ev N j) i) (B x j)

/-- temporal plaquettes between two slices (spatial links `B0`, `B1`) with time links `T x` (from `B0` to `B1`) -/
noncomputable def tmS (N : ℕ) [NeZero N] (B0 B1 : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (T : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ) : ℝ :=
  ∑ x, ∑ i : Fin 3, plaqE (B0 x i) (T (x + ev N i)) (B1 x i) (T x)

theorem tmS_reflect (N : ℕ) [NeZero N] (B0 B1 : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (T : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ) :
    tmS N B1 B0 (fun x => (T x)ᴴ) = tmS N B0 B1 T := by
  unfold tmS
  refine Finset.sum_congr rfl fun x _ => Finset.sum_congr rfl fun i _ => ?_
  exact plaqE_reflect _ _ _ _

/-! ## 2. The Wilson action on the physical links -/

/-- spatial link `(t, x, i)` of a physical configuration as a matrix (`1` for `t ≥ 2h`, never used) -/
noncomputable def physSp {N hT : ℕ} (ω : PhysLink N hT → SU2) (t : ℕ) :
    (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun x i => if ht : t < 2 * hT then quatMat (ω (⟨t, ht⟩, x, i.castSucc) : Quaternion ℝ) else 1

/-- time link `t → t + 1` at `x` of a physical configuration as a matrix -/
noncomputable def physT {N hT : ℕ} (ω : PhysLink N hT → SU2) (t : ℕ) :
    (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ :=
  fun x => if ht : t < 2 * hT then quatMat (ω (⟨t, ht⟩, x, (3 : Fin 4)) : Quaternion ℝ) else 1

/-- **the Wilson action** `Σ_p (1 − ½ Re tr U_p)` of a physical configuration (each unoriented plaquette once;
the time circle has length `2h`, `sc h t = t + 1 mod 2h`) -/
noncomputable def wilsonAction (N : ℕ) [NeZero N] (hT : ℕ) (ω : PhysLink N hT → SU2) : ℝ :=
  ∑ t ∈ Finset.range (2 * hT),
    (spS N (physSp ω t) + tmS N (physSp ω t) (physSp ω (sc hT t)) (physT ω t))

/-! ## 3. The half configuration and the split -/

/-- spatial links of slice `s ∈ [0, h]` of a half configuration `(c, a)` -/
noncomputable def halfSp (N : ℕ) (hT : ℕ) (c : PlaneConf N) (a : PosConf N hT) (s : ℕ) :
    (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  if s = 0 then U0of N c else if s = hT then Uhof N c else Upof N hT a s

/-- the action of the plaquettes inside the two planes -/
noncomputable def planeAction (N : ℕ) [NeZero N] (c : PlaneConf N) : ℝ :=
  spS N (U0of N c) + spS N (Uhof N c)

/-- the action of the plaquettes of one side (spatial plaquettes of the slices `0 < s < h`, temporal plaquettes
between `s` and `s + 1`, `s < h`) -/
noncomputable def halfAction (N : ℕ) [NeZero N] (hT : ℕ) (c : PlaneConf N) (a : PosConf N hT) : ℝ :=
  ∑ s ∈ Finset.range (hT - 1), spS N (halfSp N hT c a (s + 1))
    + ∑ s ∈ Finset.range hT, tmS N (halfSp N hT c a s) (halfSp N hT c a (s + 1)) (U4of N hT a s)

theorem halfSp_zero (N hT : ℕ) (c : PlaneConf N) (a : PosConf N hT) : halfSp N hT c a 0 = U0of N c := by
  unfold halfSp
  rw [if_pos rfl]

theorem omega_link {N hT : ℕ} (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (l : PhysLink N hT)
    (y : (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT)) (h : linkClass l = y) :
    ω l = ω ((linkEquiv N hT hpos).symm y) := by
  rw [← h]
  exact congrArg ω ((linkEquiv N hT hpos).symm_apply_apply l).symm

theorem linkClass_sp_zero {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (i : Fin 3) (h0 : t.val = 0) :
    linkClass (t, x, i.castSucc) = Sum.inl (Sum.inl (x, i)) := by
  simp [linkClass, h0]

theorem linkClass_sp_half {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (i : Fin 3) (hh : t.val = hT)
    (hpos : 0 < hT) : linkClass (t, x, i.castSucc) = Sum.inl (Sum.inr (x, i)) := by
  simp [linkClass, hh, hpos.ne']

theorem linkClass_sp_pos {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (i : Fin 3) (h0 : 0 < t.val)
    (hlt : t.val < hT) :
    linkClass (t, x, i.castSucc) = Sum.inr (Sum.inl (Sum.inl (⟨t.val - 1, by omega⟩, (x, i)))) := by
  have a1 : t.val ≠ 0 := by omega
  have a2 : t.val ≠ hT := by omega
  simp [linkClass, a1, a2, hlt]

theorem linkClass_sp_neg {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (i : Fin 3) (hgt : hT < t.val) :
    linkClass (t, x, i.castSucc)
      = Sum.inr (Sum.inr (Sum.inl (⟨2 * hT - t.val - 1, by have := t.isLt; omega⟩, (x, i)))) := by
  have a1 : t.val ≠ 0 := by omega
  have a2 : t.val ≠ hT := by omega
  have a3 : ¬ t.val < hT := by omega
  simp [linkClass, a1, a2, a3]

theorem linkClass_tm_pos {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (hlt : t.val < hT) :
    linkClass ((t, x, (3 : Fin 4)) : PhysLink N hT) = Sum.inr (Sum.inl (Sum.inr (⟨t.val, hlt⟩, x))) := by
  simp [linkClass, hlt]

theorem linkClass_tm_neg {N hT : ℕ} (t : Fin (2 * hT)) (x : Fin 3 → Fin N) (hge : hT ≤ t.val) :
    linkClass ((t, x, (3 : Fin 4)) : PhysLink N hT)
      = Sum.inr (Sum.inr (Sum.inr (⟨2 * hT - 1 - t.val, by have := t.isLt; omega⟩, x))) := by
  have a3 : ¬ t.val < hT := by omega
  simp [linkClass, a3]

/-- slices `t ≤ h`: the physical spatial links are those of `(c, a₊)` -/
theorem physSp_pos (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (t : ℕ) (ht : t ≤ hT) :
    physSp ω t = halfSp N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
      (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1 t := by
  have ht2 : t < 2 * hT := by omega
  funext x i
  simp only [physSp, dif_pos ht2]
  by_cases h0 : t = 0
  · rw [omega_link hpos ω _ _ (linkClass_sp_zero ⟨t, ht2⟩ x i h0)]
    simp only [halfSp, if_pos h0]
    rfl
  · by_cases hh : t = hT
    · rw [omega_link hpos ω _ _ (linkClass_sp_half ⟨t, ht2⟩ x i hh hpos)]
      simp only [halfSp, if_neg h0, if_pos hh]
      rfl
    · have hlt : 0 < t ∧ t < hT := ⟨by omega, by omega⟩
      rw [omega_link hpos ω _ _ (linkClass_sp_pos ⟨t, ht2⟩ x i hlt.1 hlt.2)]
      simp only [halfSp, if_neg h0, if_neg hh, Upof, dif_pos hlt]
      rfl

/-- slices `h ≤ t < 2h`: the physical spatial links are those of `(c, a₋)` at the reflected slice `2h − t` -/
theorem physSp_neg (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (t : ℕ) (ht : hT ≤ t)
    (ht2 : t < 2 * hT) :
    physSp ω t = halfSp N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
      (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2 (2 * hT - t) := by
  funext x i
  simp only [physSp, dif_pos ht2]
  have h0 : ¬ 2 * hT - t = 0 := by omega
  by_cases hh : t = hT
  · have hh' : 2 * hT - t = hT := by omega
    rw [omega_link hpos ω _ _ (linkClass_sp_half ⟨t, ht2⟩ x i hh hpos)]
    simp only [halfSp, if_neg h0, if_pos hh']
    rfl
  · have hh' : ¬ 2 * hT - t = hT := by omega
    have hlt : 0 < 2 * hT - t ∧ 2 * hT - t < hT := ⟨by omega, by omega⟩
    rw [omega_link hpos ω _ _ (linkClass_sp_neg ⟨t, ht2⟩ x i (by show hT < t; omega))]
    simp only [halfSp, if_neg h0, if_neg hh', Upof, dif_pos hlt]
    rfl

/-- time links `t → t + 1`, `t < h`: those of `a₊` -/
theorem physT_pos (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (t : ℕ) (ht : t < hT) :
    physT ω t = U4of N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1 t := by
  have ht2 : t < 2 * hT := by omega
  funext x
  simp only [physT, dif_pos ht2, U4of, dif_pos ht]
  rw [omega_link hpos ω _ _ (linkClass_tm_pos ⟨t, ht2⟩ x ht)]
  rfl

/-- time links `t → t + 1`, `h ≤ t < 2h`: the adjoints of those of `a₋` at `2h − 1 − t` (the reflected link,
traversed backwards) -/
theorem physT_neg (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) (t : ℕ) (ht : hT ≤ t)
    (ht2 : t < 2 * hT) :
    physT ω t = fun x => (U4of N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2
      (2 * hT - 1 - t) x)ᴴ := by
  have h3 : 2 * hT - 1 - t < hT := by omega
  funext x
  simp only [physT, dif_pos ht2, U4of, dif_pos h3]
  rw [omega_link hpos ω _ _ (linkClass_tm_neg ⟨t, ht2⟩ x ht)]
  have e0 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2.2 (⟨2 * hT - 1 - t, h3⟩, x)
      = (ω ((linkEquiv N hT hpos).symm (Sum.inr (Sum.inr (Sum.inr (⟨2 * hT - 1 - t, h3⟩, x))))))⁻¹ := rfl
  rw [e0, quatMat_inv, conjTranspose_conjTranspose]

set_option maxHeartbeats 1600000 in
/-- **the split of the Wilson action at the site planes `t = 0`, `t = h`**: `S_W(ω) = K(c) + H(c, a₊) + H(c, a₋)`
with `(c, a₊, a₋) = configSplit (linkEquiv) (sigInv) ω`, the same `H` on both sides -/
theorem wilsonAction_split (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) :
    wilsonAction N hT ω = planeAction N (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
      + halfAction N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
          (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1
      + halfAction N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
          (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2 := by
  obtain ⟨k, rfl⟩ : ∃ k, hT = k + 1 := ⟨hT - 1, by omega⟩
  have L1 := physSp_pos N (k + 1) hpos ω
  have L2 := physSp_neg N (k + 1) hpos ω
  have L3 := physT_pos N (k + 1) hpos ω
  have L4 := physT_neg N (k + 1) hpos ω
  set p := configSplit (linkEquiv N (k + 1) hpos) (sigInv N (k + 1)) ω with hp
  unfold wilsonAction halfAction planeAction
  simp only [Nat.add_sub_cancel]
  rw [Finset.sum_add_distrib]
  have hA : ∑ t ∈ Finset.range (2 * (k + 1)), spS N (physSp ω t)
      = spS N (U0of N p.1) + spS N (Uhof N p.1) + ∑ s ∈ Finset.range k, spS N (halfSp N (k + 1) p.1 p.2.1 (s + 1))
        + ∑ s ∈ Finset.range k, spS N (halfSp N (k + 1) p.1 p.2.2 (s + 1)) := by
    rw [show 2 * (k + 1) = (k + 1) + (k + 1) by ring, Finset.sum_range_add, Finset.sum_range_succ',
      Finset.sum_range_succ']
    have e1 : ∑ i ∈ Finset.range k, spS N (physSp ω (i + 1))
        = ∑ i ∈ Finset.range k, spS N (halfSp N (k + 1) p.1 p.2.1 (i + 1)) :=
      Finset.sum_congr rfl fun i hi => by rw [L1 (i + 1) (by have := Finset.mem_range.mp hi; omega)]
    have e2 : ∑ i ∈ Finset.range k, spS N (physSp ω (k + 1 + (i + 1)))
        = ∑ i ∈ Finset.range k, spS N (halfSp N (k + 1) p.1 p.2.2 (i + 1)) := by
      refine Eq.trans ?_ (Finset.sum_range_reflect (fun i => spS N (halfSp N (k + 1) p.1 p.2.2 (i + 1))) k)
      refine Finset.sum_congr rfl fun i hi => ?_
      have hi' := Finset.mem_range.mp hi
      beta_reduce
      rw [L2 (k + 1 + (i + 1)) (by omega) (by omega),
        show 2 * (k + 1) - (k + 1 + (i + 1)) = k - 1 - i + 1 by omega]
    have e0 : physSp ω 0 = U0of N p.1 := by
      rw [L1 0 (by omega), halfSp_zero]
    have eh : physSp ω (k + 1 + 0) = Uhof N p.1 := by
      rw [L1 (k + 1 + 0) (by omega)]
      have a1 : ¬ (k + 1 + 0 = 0) := by omega
      have a2 : k + 1 + 0 = k + 1 := by omega
      unfold halfSp
      rw [if_neg a1, if_pos a2]
    rw [e1, e2, e0, eh]
    ring
  have hB : ∑ t ∈ Finset.range (2 * (k + 1)), tmS N (physSp ω t) (physSp ω (sc (k + 1) t)) (physT ω t)
      = ∑ s ∈ Finset.range (k + 1), tmS N (halfSp N (k + 1) p.1 p.2.1 s) (halfSp N (k + 1) p.1 p.2.1 (s + 1))
          (U4of N (k + 1) p.2.1 s)
        + ∑ s ∈ Finset.range (k + 1), tmS N (halfSp N (k + 1) p.1 p.2.2 s) (halfSp N (k + 1) p.1 p.2.2 (s + 1))
          (U4of N (k + 1) p.2.2 s) := by
    rw [show 2 * (k + 1) = (k + 1) + (k + 1) by ring, Finset.sum_range_add]
    refine congrArg₂ (· + ·) ?_ ?_
    · refine Finset.sum_congr rfl fun t ht => ?_
      have ht' := Finset.mem_range.mp ht
      have hsc : sc (k + 1) t = t + 1 := by
        have a1 : ¬ (t + 1 = 2 * (k + 1)) := by omega
        unfold sc
        rw [if_neg a1]
      rw [hsc, L1 t (by omega), L1 (t + 1) (by omega), L3 t ht']
    · refine Eq.trans ?_ (Finset.sum_range_reflect (fun s => tmS N (halfSp N (k + 1) p.1 p.2.2 s)
        (halfSp N (k + 1) p.1 p.2.2 (s + 1)) (U4of N (k + 1) p.2.2 s)) (k + 1))
      refine Finset.sum_congr rfl fun u hu => ?_
      have hu' := Finset.mem_range.mp hu
      have hs1 : physSp ω (k + 1 + u) = halfSp N (k + 1) p.1 p.2.2 (k + 1 - 1 - u + 1) := by
        rw [L2 (k + 1 + u) (by omega) (by omega), show 2 * (k + 1) - (k + 1 + u) = k + 1 - 1 - u + 1 by omega]
      have hs2 : physSp ω (sc (k + 1) (k + 1 + u)) = halfSp N (k + 1) p.1 p.2.2 (k + 1 - 1 - u) := by
        unfold sc
        by_cases hw : k + 1 + u + 1 = 2 * (k + 1)
        · rw [if_pos hw, L1 0 (by omega), show k + 1 - 1 - u = 0 by omega, halfSp_zero, halfSp_zero]
        · rw [if_neg hw, L2 (k + 1 + u + 1) (by omega) (by omega),
            show 2 * (k + 1) - (k + 1 + u + 1) = k + 1 - 1 - u by omega]
      have ht1 : physT ω (k + 1 + u) = fun x => (U4of N (k + 1) p.2.2 (k + 1 - 1 - u) x)ᴴ := by
        rw [L4 (k + 1 + u) (by omega) (by omega), show 2 * (k + 1) - 1 - (k + 1 + u) = k + 1 - 1 - u by omega]
      rw [hs1, hs2, ht1]
      exact tmS_reflect N _ _ _
  rw [hA, hB]
  ring

/-! ## 4. The weights -/

/-- the weight of the plane plaquettes `exp(−β K(c))` -/
noncomputable def planeWeight (N : ℕ) [NeZero N] (β : ℝ) (c : PlaneConf N) : ℝ :=
  Real.exp (-β * planeAction N c)

/-- the weight of one side `exp(−β H(c, a))` -/
noncomputable def halfWeight (N : ℕ) [NeZero N] (hT : ℕ) (β : ℝ) (q : PlaneConf N × PosConf N hT) : ℝ :=
  Real.exp (-β * halfAction N hT q.1 q.2)

/-- **the Wilson weight factorises**: `exp(−β S_W(ω)) = k(c)·hw(c, a₊)·hw(c, a₋)` (every `β ∈ ℝ`) -/
theorem wilsonWeight_split (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (β : ℝ) (ω : PhysLink N hT → SU2) :
    Real.exp (-β * wilsonAction N hT ω)
      = planeWeight N β (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1
        * halfWeight N hT β ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1)
        * halfWeight N hT β ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2) := by
  simp only [planeWeight, halfWeight]
  rw [wilsonAction_split N hT hpos ω, ← Real.exp_add, ← Real.exp_add]
  congr 1
  ring

/-! ## 5. Continuity and bounds -/

theorem continuous_plaqE {X : Type*} [TopologicalSpace X] {A B C D : X → Matrix (Fin 2) (Fin 2) ℂ}
    (hA : Continuous A) (hB : Continuous B) (hC : Continuous C) (hD : Continuous D) :
    Continuous fun p => plaqE (A p) (B p) (C p) (D p) := by
  unfold plaqE
  exact continuous_const.sub (continuous_const.mul (Complex.continuous_re.comp
    (((hA.matrix_mul hB).matrix_mul hC.matrix_conjTranspose).matrix_mul hD.matrix_conjTranspose).matrix_trace))

theorem continuous_spS (N : ℕ) [NeZero N] {X : Type*} [TopologicalSpace X]
    (B : X → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hB : ∀ x i, Continuous fun p => B p x i) :
    Continuous fun p => spS N (B p) := by
  unfold spS
  exact continuous_finsetSum _ fun x _ => continuous_finsetSum _ fun i _ => continuous_finsetSum _ fun j _ =>
    continuous_plaqE (hB x i) (hB _ j) (hB _ i) (hB x j)

theorem continuous_tmS (N : ℕ) [NeZero N] {X : Type*} [TopologicalSpace X]
    (B0 B1 : X → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (T : X → (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (h0 : ∀ x i, Continuous fun p => B0 p x i) (h1 : ∀ x i, Continuous fun p => B1 p x i)
    (hT : ∀ x, Continuous fun p => T p x) :
    Continuous fun p => tmS N (B0 p) (B1 p) (T p) := by
  unfold tmS
  exact continuous_finsetSum _ fun x _ => continuous_finsetSum _ fun i _ =>
    continuous_plaqE (h0 x i) (hT _) (h1 x i) (hT x)

theorem continuous_halfSp (N hT : ℕ) (s : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) :
    Continuous fun q : PlaneConf N × PosConf N hT => halfSp N hT q.1 q.2 s x i := by
  apply continuous_matrix
  intro a b
  by_cases h0 : s = 0
  · simp only [halfSp, if_pos h0]
    exact (continuous_U0of N x i a b).comp continuous_fst
  · by_cases hh : s = hT
    · simp only [halfSp, if_neg h0, if_pos hh]
      exact (continuous_Uhof N x i a b).comp continuous_fst
    · simp only [halfSp, if_neg h0, if_neg hh]
      exact (continuous_Upof N hT s x i a b).comp continuous_snd

theorem continuous_halfAction (N : ℕ) [NeZero N] (hT : ℕ) :
    Continuous fun q : PlaneConf N × PosConf N hT => halfAction N hT q.1 q.2 := by
  unfold halfAction
  refine Continuous.add (continuous_finsetSum _ fun s _ =>
    continuous_spS N _ fun x i => continuous_halfSp N hT (s + 1) x i) (continuous_finsetSum _ fun s _ =>
    continuous_tmS N _ _ _ (fun x i => continuous_halfSp N hT s x i) (fun x i => continuous_halfSp N hT (s + 1) x i)
      (fun x => continuous_matrix fun a b => (continuous_U4of N hT s x a b).comp continuous_snd))

theorem continuous_planeAction (N : ℕ) [NeZero N] : Continuous fun c : PlaneConf N => planeAction N c := by
  unfold planeAction
  exact (continuous_spS N _ fun x i => continuous_matrix fun a b => continuous_U0of N x i a b).add
    (continuous_spS N _ fun x i => continuous_matrix fun a b => continuous_Uhof N x i a b)

theorem continuous_planeWeight (N : ℕ) [NeZero N] (β : ℝ) : Continuous (planeWeight N β) :=
  Real.continuous_exp.comp (continuous_const.mul (continuous_planeAction N))

theorem continuous_halfWeight (N : ℕ) [NeZero N] (hT : ℕ) (β : ℝ) : Continuous (halfWeight N hT β) :=
  Real.continuous_exp.comp (continuous_const.mul (continuous_halfAction N hT))

theorem bound_of_continuous {X : Type*} [TopologicalSpace X] [CompactSpace X] (f : X → ℝ) (hf : Continuous f) :
    ∃ C, ∀ x, |f x| ≤ C := by
  obtain ⟨C, hC⟩ := isCompact_univ.exists_bound_of_continuousOn hf.continuousOn
  exact ⟨C, fun x => by simpa [Real.norm_eq_abs] using hC x (Set.mem_univ x)⟩

/-! ## 6. Reflection positivity and `Z > 0` with the concrete Wilson weight -/

/-- the fermion weight `Re det D^{2j}` of the split configuration -/
noncomputable def fermWeight (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ)
    (p : PlaneConf N × (PosConf N hT × PosConf N hT)) : ℝ :=
  ((std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
      (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
    (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det
      ^ (2 * j)).re

set_option maxHeartbeats 1600000 in
/-- **Site reflection positivity with the concrete Wilson gauge weight** `exp(−β S_W)` (every `β ∈ ℝ`) times
`det D^{2j}` (`m > −1`), on `Π_{physical links} Haar`.  Abstract: only the observable `φ` (bounded measurable,
evaluated on `(c, a₊)` and on the reflected `(c, a₋)`). -/
theorem site_reflection_positive_wilson_full (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (j : ℕ) (m : ℝ) (hm : -1 < m) (β : ℝ)
    (φ : PlaneConf N × PosConf N hT → ℝ) (hφ : Measurable φ) (Cφ : ℝ) (bφ : ∀ p, |φ p| ≤ Cφ) :
    0 ≤ ∫ ω : PhysLink N hT → SU2,
        φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1)
          * φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2)
          * Real.exp (-β * wilsonAction N hT ω)
          * fermWeight N hT j m (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω)
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  haveI i0 : OpensMeasurableSpace (PlaneConf N × PosConf N hT) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  obtain ⟨Ck, bk⟩ := bound_of_continuous _ (continuous_planeWeight N β)
  obtain ⟨Ch, bh⟩ := bound_of_continuous _ (continuous_halfWeight N hT β)
  have h := site_reflection_positive_phys N hT hpos j m hm (planeWeight N β) (halfWeight N hT β) φ
    (continuous_planeWeight N β).measurable (continuous_halfWeight N hT β).measurable hφ Ck Ch Cφ bk bh bφ
    (fun c => (Real.exp_pos _).le)
  refine h.trans_eq ?_
  congr 1
  funext ω
  rw [wilsonWeight_split N hT hpos β ω]
  unfold wilsonIntegrand fermWeight
  ring

/-- the split Wilson weight on the split configuration space -/
noncomputable def splitWeight (N : ℕ) [NeZero N] (hT : ℕ) (β : ℝ)
    (p : PlaneConf N × (PosConf N hT × PosConf N hT)) : ℝ :=
  planeWeight N β p.1 * halfWeight N hT β (p.1, p.2.1) * halfWeight N hT β (p.1, p.2.2)

theorem continuous_splitWeight (N : ℕ) [NeZero N] (hT : ℕ) (β : ℝ) : Continuous (splitWeight N hT β) := by
  unfold splitWeight
  exact (((continuous_planeWeight N β).comp continuous_fst).mul ((continuous_halfWeight N hT β).comp
    (continuous_fst.prodMk (continuous_fst.comp continuous_snd)))).mul ((continuous_halfWeight N hT β).comp
    (continuous_fst.prodMk (continuous_snd.comp continuous_snd)))

set_option maxHeartbeats 1600000 in
/-- **`Z > 0` with the concrete Wilson gauge weight, on `Π_{physical links} Haar`**: for every `β ∈ ℝ`, every bare
mass `m ∈ ℝ` and every `j`. -/
theorem partition_pos_wilson_full (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (β : ℝ) :
    0 < ∫ ω : PhysLink N hT → SU2, Real.exp (-β * wilsonAction N hT ω)
          * fermWeight N hT j m (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω)
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  haveI i1 : OpensMeasurableSpace (PosConf N hT × PosConf N hT) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  haveI i2 : OpensMeasurableSpace (PlaneConf N × (PosConf N hT × PosConf N hT)) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  have h := partition_pos_wilson_SU2 N hT hpos j m (splitWeight N hT β) (continuous_splitWeight N hT β)
    (fun p => by unfold splitWeight planeWeight halfWeight; positivity)
  have c0 : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1 x i a b :=
    fun x i a b => (continuous_U0of N x i a b).comp continuous_fst
  have ch : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => Uhof N p.1 x i a b :=
    fun x i a b => (continuous_Uhof N x i a b).comp continuous_fst
  have cp : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.1 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_fst.comp continuous_snd)
  have cm : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.2 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_snd.comp continuous_snd)
  have c4p : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.1 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_fst.comp continuous_snd)
  have c4m : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.2 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_snd.comp continuous_snd)
  have hcont := continuous_det_torus_generic N hT j m
    (fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1) (fun p => Uhof N p.1)
    (fun p => Upof N hT p.2.1) (fun p => Upof N hT p.2.2)
    (fun p => U4of N hT p.2.1) (fun p => U4of N hT p.2.2) c0 ch cp cm c4p c4m
  have hF : Continuous (fermWeight N hT j m) := hcont
  have hG : Measurable fun p => splitWeight N hT β p * fermWeight N hT j m p :=
    ((continuous_splitWeight N hT β).mul hF).measurable
  have hmp := phys_split_preserving N hT hpos
  have h2 := integral_map hmp.aemeasurable hG.aestronglyMeasurable
  rw [hmp.map_eq] at h2
  have e : (fun ω : PhysLink N hT → SU2 => Real.exp (-β * wilsonAction N hT ω)
        * fermWeight N hT j m (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω))
      = fun ω => splitWeight N hT β (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω)
        * fermWeight N hT j m (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω) := by
    funext ω
    rw [splitWeight, wilsonWeight_split N hT hpos β ω]
  rw [e, ← h2]
  exact h

end WilsonGauge

/-! ## 7. The Wilson–Dirac operator written with the physical links 

Paper side: (numerical check of the same identity, difference ≤ 3.6e-15).
`physDirac` is `std4` (the textbook `r = 1` Wilson operator on (time circle `2h`) × (colour ⊗ spatial torus),
`sliceOp_wilson_eq_std4`, `Dop_wilson_eq_std4`) with the physical links slice by slice: spatial hops `torusX` of the
physical spatial links (antiperiodic spatial sign inside `torusLink`), time hop with the physical time links and the
antiperiodic sign `eps (sc h t)` (`−1` exactly on `2h − 1 → 0`).  It equals `std4` of the split configuration
`configSplit (linkEquiv) (sigInv) ω`, i.e. the operator of `fermWeight`. -/
namespace WilsonGauge

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection

/-- **the Wilson–Dirac operator of a physical configuration** -/
noncomputable def physDirac (N : ℕ) [NeZero N] (hT : ℕ) (m : ℝ) (ω : PhysLink N hT → SU2) :=
  std4 hT m (fun t => torusX N (physSp ω t)) (fun t => eps (sc hT t) • blockDiagonal (physT ω t))

theorem physDirac_eq_split (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (m : ℝ) (ω : PhysLink N hT → SU2) :
    physDirac N hT m ω
      = std4 hT m (Bfull hT (torusX N (U0of N (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1))
          (torusX N (Uhof N (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1))
          (fun t => torusX N (Upof N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1 t))
          (fun t => torusX N (Upof N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2 t)))
        (Vfull hT (fun t => blockDiagonal (U4of N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1 t))
          (fun t => blockDiagonal (U4of N hT (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2 t))) := by
  have L1 := physSp_pos N hT hpos ω
  have L2 := physSp_neg N hT hpos ω
  have L3 := physT_pos N hT hpos ω
  have L4 := physT_neg N hT hpos ω
  set p := configSplit (linkEquiv N hT hpos) (sigInv N hT) ω with hp
  unfold physDirac
  apply std4_congr
  · intro t ht
    unfold Bfull
    by_cases h0 : t = 0
    · rw [if_pos h0, L1 t (by omega)]
      unfold halfSp
      rw [if_pos h0]
    · rw [if_neg h0]
      by_cases hh : t = hT
      · rw [if_pos hh, L1 t (by omega)]
        unfold halfSp
        rw [if_neg h0, if_pos hh]
      · rw [if_neg hh]
        by_cases hl : t < hT
        · rw [if_pos hl, L1 t (by omega)]
          unfold halfSp
          rw [if_neg h0, if_neg hh]
        · rw [if_neg hl, L2 t (by omega) ht]
          have a0 : ¬ (2 * hT - t = 0) := by omega
          have a1 : ¬ (2 * hT - t = hT) := by omega
          have e : th hT t = 2 * hT - t := by
            unfold th
            rw [if_neg h0]
          unfold halfSp
          rw [if_neg a0, if_neg a1, e]
  · intro t ht
    unfold Vfull
    by_cases hl : t < hT
    · have a1 : ¬ (t + 1 = 2 * hT) := by omega
      have e : sc hT t = t + 1 := by
        unfold sc
        rw [if_neg a1]
      have a2 : t + 1 ≠ 0 := by omega
      rw [if_pos hl, L3 t hl, e, eps_of_ne a2, one_smul]
    · rw [if_neg hl, L4 t (by omega) ht, blockDiagonal_conjTranspose]
      have e : th hT (sc hT t) = 2 * hT - 1 - t := by
        unfold sc
        by_cases hw : t + 1 = 2 * hT
        · have a3 : 2 * hT - 1 - t = 0 := by omega
          rw [if_pos hw, a3]
          unfold th
          rw [if_pos rfl]
        · have a4 : ¬ (t + 1 = 0) := by omega
          rw [if_neg hw]
          unfold th
          rw [if_neg a4]
          omega
      rw [e]

/-- **reflection positivity with the concrete Wilson weight and the operator written with the physical links** -/
theorem site_reflection_positive_wilson_phys_op (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (j : ℕ) (m : ℝ) (hm : -1 < m) (β : ℝ)
    (φ : PlaneConf N × PosConf N hT → ℝ) (hφ : Measurable φ) (Cφ : ℝ) (bφ : ∀ p, |φ p| ≤ Cφ) :
    0 ≤ ∫ ω : PhysLink N hT → SU2,
        φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1)
          * φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2)
          * Real.exp (-β * wilsonAction N hT ω) * ((physDirac N hT m ω).det ^ (2 * j)).re
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have h := site_reflection_positive_wilson_full N hT hpos j m hm β φ hφ Cφ bφ
  refine h.trans_eq ?_
  congr 1
  funext ω
  rw [physDirac_eq_split N hT hpos m ω]
  rfl

/-- **`Z > 0` with the concrete Wilson weight and the operator written with the physical links** (every `β`, `m`, `j`) -/
theorem partition_pos_wilson_phys_op (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (β : ℝ) :
    0 < ∫ ω : PhysLink N hT → SU2, Real.exp (-β * wilsonAction N hT ω) * ((physDirac N hT m ω).det ^ (2 * j)).re
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have h := partition_pos_wilson_full N hT hpos j m β
  refine h.trans_eq ?_
  congr 1
  funext ω
  rw [physDirac_eq_split N hT hpos m ω]
  rfl

end WilsonGauge

/-! ## 8. The time reflection on the physical configurations 

`thetaPhys` is the site reflection `t ↦ −t mod 2h` acting on configurations: spatial links `(t, x, i) ↦ ω(θt, x, i)`
(`θt = th h t`), time links `(t → t+1) ↦ ω(2h−1−t → 2h−t)⁻¹` (the reflected link traversed backwards).  Then the
positive half of `Θω` is the (reflected) negative half of `ω`, so the observable `φ(c, a₋)` of the
reflection-positivity statements is `F(Θω)` with `F(ω) = φ(c, a₊)`: the textbook form `∫ F · ΘF · weight ≥ 0`. -/
namespace WilsonGauge

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config FermionSliceReflection

/-- **the time reflection of a physical configuration** -/
noncomputable def thetaPhys {N hT : ℕ} (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 :=
  fun l => if l.2.2.val < 3 then ω (⟨th hT l.1.val, th_lt hT l.1.val l.1.isLt⟩, l.2.1, l.2.2)
    else (ω (⟨2 * hT - 1 - l.1.val, by have := l.1.isLt; omega⟩, l.2.1, l.2.2))⁻¹

theorem symm_of_class {N hT : ℕ} (hpos : 0 < hT) (l : PhysLink N hT)
    (y : (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT)) (h : linkClass l = y) :
    (linkEquiv N hT hpos).symm y = l := by
  rw [Equiv.symm_apply_eq]
  exact h.symm

theorem theta_split_pos (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) :
    (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).2.1
      = (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2 := by
  refine Prod.ext (funext fun q => ?_) (funext fun q => ?_)
  · obtain ⟨s, x, i⟩ := q
    have hs := s.isLt
    have ht1 : s.val + 1 < 2 * hT := by omega
    have hy1 : linkClass ((⟨s.val + 1, ht1⟩, x, i.castSucc) : PhysLink N hT)
        = Sum.inr (Sum.inl (Sum.inl (s, (x, i)))) := by
      rw [linkClass_sp_pos ⟨s.val + 1, ht1⟩ x i (by show 0 < s.val + 1; omega) (by show s.val + 1 < hT; omega)] <;>
        simp [Fin.ext_iff]
    have ht2 : 2 * hT - (s.val + 1) < 2 * hT := by omega
    have hy2 : linkClass ((⟨2 * hT - (s.val + 1), ht2⟩, x, i.castSucc) : PhysLink N hT)
        = Sum.inr (Sum.inr (Sum.inl (s, (x, i)))) := by
      rw [linkClass_sp_neg ⟨2 * hT - (s.val + 1), ht2⟩ x i (by show hT < 2 * hT - (s.val + 1); omega)] <;>
        (simp only [Sum.inr.injEq, Sum.inl.injEq, Prod.mk.injEq, and_true, Fin.ext_iff]; omega)
    have e1 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).2.1.1 (s, (x, i))
        = thetaPhys ω ((linkEquiv N hT hpos).symm (Sum.inr (Sum.inl (Sum.inl (s, (x, i)))))) := rfl
    have e2 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2.1 (s, (x, i))
        = ω ((linkEquiv N hT hpos).symm (Sum.inr (Sum.inr (Sum.inl (s, (x, i)))))) := rfl
    rw [e1, e2, symm_of_class hpos _ _ hy1, symm_of_class hpos _ _ hy2]
    have hμ : (i.castSucc : Fin 4).val < 3 := by simp
    have hth : th hT (s.val + 1) = 2 * hT - (s.val + 1) := by
      have a : ¬ (s.val + 1 = 0) := by omega
      unfold th
      rw [if_neg a]
    simp only [thetaPhys, if_pos hμ]
    exact congrArg ω (Prod.ext (Fin.ext hth) rfl)
  · obtain ⟨s, x⟩ := q
    have hs := s.isLt
    have ht1 : s.val < 2 * hT := by omega
    have hy1 : linkClass ((⟨s.val, ht1⟩, x, (3 : Fin 4)) : PhysLink N hT)
        = Sum.inr (Sum.inl (Sum.inr (s, x))) := by
      rw [linkClass_tm_pos ⟨s.val, ht1⟩ x hs] <;> simp [Fin.ext_iff]
    have ht2 : 2 * hT - 1 - s.val < 2 * hT := by omega
    have hy2 : linkClass ((⟨2 * hT - 1 - s.val, ht2⟩, x, (3 : Fin 4)) : PhysLink N hT)
        = Sum.inr (Sum.inr (Sum.inr (s, x))) := by
      rw [linkClass_tm_neg ⟨2 * hT - 1 - s.val, ht2⟩ x (by show hT ≤ 2 * hT - 1 - s.val; omega)] <;>
        (simp only [Sum.inr.injEq, Sum.inl.injEq, Prod.mk.injEq, and_true, Fin.ext_iff]; omega)
    have e1 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).2.1.2 (s, x)
        = thetaPhys ω ((linkEquiv N hT hpos).symm (Sum.inr (Sum.inl (Sum.inr (s, x))))) := rfl
    have e2 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.2.2 (s, x)
        = (ω ((linkEquiv N hT hpos).symm (Sum.inr (Sum.inr (Sum.inr (s, x))))))⁻¹ := rfl
    rw [e1, e2, symm_of_class hpos _ _ hy1, symm_of_class hpos _ _ hy2]
    have hμ : ¬ ((3 : Fin 4).val < 3) := by decide
    simp only [thetaPhys, if_neg hμ]

theorem theta_split_plane (N : ℕ) (hT : ℕ) (hpos : 0 < hT) (ω : PhysLink N hT → SU2) :
    (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).1
      = (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1 := by
  have hμ : ∀ i : Fin 3, (i.castSucc : Fin 4).val < 3 := fun i => by simp
  refine Prod.ext (funext fun q => ?_) (funext fun q => ?_)
  · obtain ⟨x, i⟩ := q
    have ht : 0 < 2 * hT := by omega
    have hy : linkClass ((⟨0, ht⟩, x, i.castSucc) : PhysLink N hT) = Sum.inl (Sum.inl (x, i)) :=
      linkClass_sp_zero ⟨0, ht⟩ x i rfl
    have e1 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).1.1 (x, i)
        = thetaPhys ω ((linkEquiv N hT hpos).symm (Sum.inl (Sum.inl (x, i)))) := rfl
    have e2 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1.1 (x, i)
        = ω ((linkEquiv N hT hpos).symm (Sum.inl (Sum.inl (x, i)))) := rfl
    rw [e1, e2, symm_of_class hpos _ _ hy]
    simp only [thetaPhys, if_pos (hμ i)]
    exact congrArg ω (Prod.ext (Fin.ext (show th hT 0 = 0 by simp [th])) rfl)
  · obtain ⟨x, i⟩ := q
    have ht : hT < 2 * hT := by omega
    have hy : linkClass ((⟨hT, ht⟩, x, i.castSucc) : PhysLink N hT) = Sum.inl (Sum.inr (x, i)) :=
      linkClass_sp_half ⟨hT, ht⟩ x i rfl hpos
    have e1 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).1.2 (x, i)
        = thetaPhys ω ((linkEquiv N hT hpos).symm (Sum.inl (Sum.inr (x, i)))) := rfl
    have e2 : (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1.2 (x, i)
        = ω ((linkEquiv N hT hpos).symm (Sum.inl (Sum.inr (x, i)))) := rfl
    rw [e1, e2, symm_of_class hpos _ _ hy]
    have hth : th hT hT = hT := by
      unfold th
      rw [if_neg (by omega : hT ≠ 0)]
      omega
    simp only [thetaPhys, if_pos (hμ i)]
    exact congrArg ω (Prod.ext (Fin.ext hth) rfl)

/-- **site reflection positivity in the textbook form** `∫ F(ω) F(Θω) e^{−βS_W(ω)} Re det D(ω)^{2j} dΠHaar ≥ 0`
for every observable `F(ω) = φ(c, a₊)` of the links of the planes and of the positive side (bounded measurable
`φ`), every `β ∈ ℝ`, `m > −1`, `j`; `Θ = thetaPhys`, `D = physDirac` -/
theorem site_reflection_positive_wilson_theta (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (j : ℕ) (m : ℝ) (hm : -1 < m) (β : ℝ)
    (φ : PlaneConf N × PosConf N hT → ℝ) (hφ : Measurable φ) (Cφ : ℝ) (bφ : ∀ p, |φ p| ≤ Cφ) :
    0 ≤ ∫ ω : PhysLink N hT → SU2,
        φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω).2.1)
          * φ ((configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).1,
            (configSplit (linkEquiv N hT hpos) (sigInv N hT) (thetaPhys ω)).2.1)
          * Real.exp (-β * wilsonAction N hT ω) * ((physDirac N hT m ω).det ^ (2 * j)).re
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have h := site_reflection_positive_wilson_phys_op N hT hpos j m hm β φ hφ Cφ bφ
  refine h.trans_eq ?_
  congr 1
  funext ω
  rw [theta_split_plane N hT hpos ω, theta_split_pos N hT hpos ω]

end WilsonGauge

#print axioms WilsonGauge.plaqE_reflect
#print axioms WilsonGauge.physSp_pos
#print axioms WilsonGauge.physSp_neg
#print axioms WilsonGauge.physT_pos
#print axioms WilsonGauge.physT_neg
#print axioms WilsonGauge.wilsonAction_split
#print axioms WilsonGauge.wilsonWeight_split
#print axioms WilsonGauge.continuous_halfAction
#print axioms WilsonGauge.site_reflection_positive_wilson_full
#print axioms WilsonGauge.partition_pos_wilson_full
#print axioms WilsonGauge.physDirac_eq_split
#print axioms WilsonGauge.site_reflection_positive_wilson_phys_op
#print axioms WilsonGauge.partition_pos_wilson_phys_op
#print axioms WilsonGauge.theta_split_pos
#print axioms WilsonGauge.theta_split_plane
#print axioms WilsonGauge.site_reflection_positive_wilson_theta
