import Gauge.WilsonFullV7c

/-! # the entries of `physDirac` in the physical indices (the textbook formula)

`torusX_apply'`: the spatial hop of the torus is `X_i (c, x) (c', y) = [y = x + e_i] · s_i(x) · U_i(x)_{c c'}` with the
antiperiodic spatial sign `s_i(x) = −1` iff `x_i = N − 1`.  `physDirac_apply`: the entries of the operator of a
physical configuration, `(t, s, r, c, x) × (t', s', r', c', x')` (time, the two spinor indices, colour, site):

  `[t' = t] ((m + 4) δ − ½ Σ_i [(1 − γ_i) [x' = x + e_i] s_i(x) U_i(t, x) + (1 + γ_i) [x = x' + e_i] s_i(x') U_i(t, x')†])`
  `− ½ [(1 − γ₄) [t' = t + 1] ε U₄(t, x) δ_{x x'} + (1 + γ₄) [t = t' + 1] ε U₄(t', x)† δ_{x x'}]`

(`t + 1` mod `2h`, `ε = −1` exactly on `2h − 1 → 0`), i.e. `(Dψ)(x) = (m + 4)ψ(x) − ½ Σ_μ [(1 − γ_μ)U_μ(x)ψ(x + μ̂) +
(1 + γ_μ)U_μ(x − μ̂)†ψ(x − μ̂)]`. -/
namespace WilsonGauge

open Matrix FermionSliceBlock FermionSU2Config

theorem torusX_apply' {C : Type*} [Fintype C] [DecidableEq C] (N : ℕ) [NeZero N]
    (U : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (i : Fin 3) (c c' : C) (x y : Fin 3 → Fin N) :
    torusX N U i (c, x) (c', y)
      = if y = x + Pi.single i 1 then (if (x i).val + 1 = N then (-1 : ℂ) else 1) * U x i c c' else 0 := by
  have e : (x = torusShift N i y) ↔ (y = x + Pi.single i 1) := by
    show x = y + -Pi.single i 1 ↔ _
    rw [eq_add_neg_iff_add_eq, eq_comm]
  unfold torusX
  rw [shiftMat_apply]
  by_cases h : y = x + Pi.single i 1
  · rw [if_pos (e.mpr h), if_pos h]
    simp only [torusLink, Matrix.smul_apply, smul_eq_mul]
  · rw [if_neg (fun h' => h (e.mp h')), if_neg h]

/-- **the entries of the Wilson–Dirac operator of a physical configuration** -/
theorem physDirac_apply (N : ℕ) [NeZero N] (hT : ℕ) (m : ℝ) (ω : PhysLink N hT → SU2)
    (t t' : Fin (2 * hT)) (s s' r r' : Fin 2) (c c' : Fin 2) (x x' : Fin 3 → Fin N) :
    physDirac N hT m ω (t, s, (r, (c, x))) (t', s', (r', (c', x')))
      = (if t'.val = t.val then
          ((m : ℂ) + 4) * (1 : Matrix (Fin 2 × (Fin 2 × (Fin 2 × (Fin 3 → Fin N))))
              (Fin 2 × (Fin 2 × (Fin 2 × (Fin 3 → Fin N)))) ℂ) (s, (r, (c, x))) (s', (r', (c', x')))
          - (1 / 2 : ℂ) * ∑ i, ((((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) - gammaSp i) (s, r) (s', r'))
              * (if x' = x + Pi.single i 1 then
                  (if (x i).val + 1 = N then (-1 : ℂ) else 1) * physSp ω t.val x i c c' else 0)
            + (((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) + gammaSp i) (s, r) (s', r'))
              * star (if x = x' + Pi.single i 1 then
                  (if (x' i).val + 1 = N then (-1 : ℂ) else 1) * physSp ω t.val x' i c' c else 0))
          else 0)
        - (1 / 2 : ℂ) * ((((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) - gammaT) (s, r) (s', r'))
            * (if t'.val = sc hT t.val then
                eps (sc hT t.val) * (if x = x' then physT ω t.val x c c' else 0) else 0)
          + (((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) + gammaT) (s, r) (s', r'))
            * (if t.val = sc hT t'.val then
                star (eps (sc hT t'.val) * (if x' = x then physT ω t'.val x' c' c else 0)) else 0)) := by
  simp only [physDirac, std4, stdSlice, torusX_apply', Matrix.smul_apply, smul_eq_mul, blockDiagonal_apply]

end WilsonGauge

#print axioms WilsonGauge.physDirac_apply
