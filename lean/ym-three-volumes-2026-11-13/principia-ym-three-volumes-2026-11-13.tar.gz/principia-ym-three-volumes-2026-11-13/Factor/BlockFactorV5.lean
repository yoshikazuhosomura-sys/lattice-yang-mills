import Mathlib

/-!
# 枠を止めた塊の条件つき独立（段 2 の芯）と、tanh・log の算術（段 3 の算術）

紙： の補題 2.1（塊の積の上界）・補題 2.2（比から tanh）・補題 3.3（−log tanh の下界）・
命題 3.4（率の下界の組み立て）。

抽象の形：枠の配位 `f : F`（有限）、塊 `b : ι`（有限）、塊ごとの内部の配位 `x : Ω b`（有限）。
全体の重みは `w0 f * ∏ b, W b f (ω b)`（枠を止めると塊ごとに積に割れる、の形そのもの）。
塊の符号 `σ b (ω b)`（格子では η_B = Π_{P∈B} η(P)）の積の期待値の分子が
`∑ f, ∑ ω, w0 f * ∏ b, (W b f (ω b) * σ b (ω b))`。
-/

open Finset BigOperators

namespace BlockFactor

variable {F : Type*} [Fintype F] {ι : Type*} [Fintype ι] [DecidableEq ι]
  {Ω : ι → Type*} [∀ b, Fintype (Ω b)]

/-- 枠を止めると和は塊ごとの和の積に割れる（有限和の分配）。 -/
theorem sum_factor (w0 : F → ℝ) (g : (b : ι) → F → Ω b → ℝ) :
    (∑ f, ∑ ω : (∀ b, Ω b), w0 f * ∏ b, g b f (ω b))
      = ∑ f, w0 f * ∏ b, ∑ x, g b f x := by
  refine Finset.sum_congr rfl (fun f _ => ?_)
  rw [← Finset.mul_sum, Fintype.prod_sum]

/-- 段 2 の芯（紙の補題 2.1）：塊ごとに |Σ_x W σ| ≤ t_b Σ_x W が枠に一様に立てば、
符号の積の分子は (∏ t_b) × 分母 以下。格子では |θ| ≤ ∏_B sup_F |E[η_B | F]|。 -/
theorem block_bound (w0 : F → ℝ) (W : (b : ι) → F → Ω b → ℝ) (σ : (b : ι) → Ω b → ℝ)
    (t : ι → ℝ) (hw0 : ∀ f, 0 ≤ w0 f)
    (ht : ∀ b f, |∑ x, W b f x * σ b x| ≤ t b * ∑ x, W b f x) :
    |∑ f, ∑ ω : (∀ b, Ω b), w0 f * ∏ b, (W b f (ω b) * σ b (ω b))|
      ≤ (∏ b, t b) * ∑ f, ∑ ω : (∀ b, Ω b), w0 f * ∏ b, W b f (ω b) := by
  rw [sum_factor w0 (fun b f x => W b f x * σ b x), sum_factor w0 W, Finset.mul_sum]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum (fun f _ => ?_))
  rw [abs_mul, abs_of_nonneg (hw0 f), Finset.abs_prod]
  have hprod : ∏ b, |∑ x, W b f x * σ b x| ≤ ∏ b, (t b * ∑ x, W b f x) :=
    Finset.prod_le_prod (fun b _ => abs_nonneg _) (fun b _ => ht b f)
  rw [Finset.prod_mul_distrib] at hprod
  calc w0 f * ∏ b, |∑ x, W b f x * σ b x|
      ≤ w0 f * ((∏ b, t b) * ∏ b, ∑ x, W b f x) := mul_le_mul_of_nonneg_left hprod (hw0 f)
    _ = (∏ b, t b) * (w0 f * ∏ b, ∑ x, W b f x) := by ring

/-- 紙の補題 2.2：二つの正の分配関数の比が e^{±2K} の内なら |Z₊ − Z₋| ≤ tanh K · (Z₊ + Z₋)。 -/
theorem ratio_tanh {Zp Zm K : ℝ} (hp : 0 < Zp) (hm : 0 < Zm)
    (h1 : Zp ≤ Real.exp (2 * K) * Zm) (h2 : Zm ≤ Real.exp (2 * K) * Zp) :
    |Zp - Zm| ≤ Real.tanh K * (Zp + Zm) := by
  have hc : 0 < Real.cosh K := Real.cosh_pos K
  have ha : 0 < Real.exp K := Real.exp_pos K
  have hb : 0 < Real.exp (-K) := Real.exp_pos (-K)
  have hab : Real.exp K * Real.exp (-K) = 1 := by rw [← Real.exp_add]; simp
  have h2K : Real.exp (2 * K) = Real.exp K * Real.exp K := by rw [← Real.exp_add]; ring_nf
  rw [Real.tanh_eq_sinh_div_cosh, div_mul_eq_mul_div, le_div_iff₀ hc, Real.sinh_eq, Real.cosh_eq]
  rw [h2K] at h1 h2
  rcases abs_cases (Zp - Zm) with ⟨h, _⟩ | ⟨h, _⟩ <;> rw [h]
  · -- Zp ≥ Zm：(Zp − Zm)(a + b) ≤ (a − b)(Zp + Zm) ⟺ Zp b ≤ Zm a
    have : Zp * Real.exp (-K) ≤ Zm * Real.exp K := by
      have := mul_le_mul_of_nonneg_right h1 hb.le
      nlinarith [hab]
    nlinarith
  · have : Zm * Real.exp (-K) ≤ Zp * Real.exp K := by
      have := mul_le_mul_of_nonneg_right h2 hb.le
      nlinarith [hab]
    nlinarith


/-- 紙の命題 2.4 の形：塊ごとに枠 f を止めた分配関数 Z₊(b, f)・Z₋(b, f) の比が e^{±2K_b} の内なら、
|Σ_f w₀(f) Π_b (Z₊ − Z₋)| ≤ (Π_b tanh K_b) · Σ_f w₀(f) Π_b (Z₊ + Z₋)。
左辺の分子・右辺の分母は、格子では 2^{(定数)}(Z₀ − Z₁)・2^{(定数)}(Z₀ + Z₁)（系 2.0）。よって |θ| ≤ Π_b tanh K_b。 -/
theorem block_tanh (w0 : F → ℝ) (Zp Zm : ι → F → ℝ) (K : ι → ℝ) (hw0 : ∀ f, 0 ≤ w0 f)
    (hp : ∀ b f, 0 < Zp b f) (hm : ∀ b f, 0 < Zm b f)
    (h1 : ∀ b f, Zp b f ≤ Real.exp (2 * K b) * Zm b f)
    (h2 : ∀ b f, Zm b f ≤ Real.exp (2 * K b) * Zp b f) :
    |∑ f, w0 f * ∏ b, (Zp b f - Zm b f)|
      ≤ (∏ b, Real.tanh (K b)) * ∑ f, w0 f * ∏ b, (Zp b f + Zm b f) := by
  rw [Finset.mul_sum]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum (fun f _ => ?_))
  rw [abs_mul, abs_of_nonneg (hw0 f), Finset.abs_prod]
  have hprod : ∏ b, |Zp b f - Zm b f| ≤ ∏ b, (Real.tanh (K b) * (Zp b f + Zm b f)) :=
    Finset.prod_le_prod (fun b _ => abs_nonneg _)
      (fun b _ => ratio_tanh (hp b f) (hm b f) (h1 b f) (h2 b f))
  rw [Finset.prod_mul_distrib] at hprod
  calc w0 f * ∏ b, |Zp b f - Zm b f|
      ≤ w0 f * ((∏ b, Real.tanh (K b)) * ∏ b, (Zp b f + Zm b f)) :=
        mul_le_mul_of_nonneg_left hprod (hw0 f)
    _ = (∏ b, Real.tanh (K b)) * (w0 f * ∏ b, (Zp b f + Zm b f)) := by ring

/-- 紙の補題 3.3：K > 0 なら −log(tanh K) ≥ e^{−2K}。 -/
theorem neg_log_tanh_ge {K : ℝ} (hK : 0 < K) : Real.exp (-2 * K) ≤ -Real.log (Real.tanh K) := by
  have ha : 0 < Real.exp K := Real.exp_pos K
  have hb : 0 < Real.exp (-K) := Real.exp_pos (-K)
  have hab : Real.exp K * Real.exp (-K) = 1 := by rw [← Real.exp_add]; simp
  have hlt : Real.exp (-K) < Real.exp K := Real.exp_lt_exp.mpr (by linarith)
  have hy : Real.exp (-2 * K) = Real.exp (-K) * Real.exp (-K) := by rw [← Real.exp_add]; ring_nf
  have htanh : Real.tanh K = (Real.exp K - Real.exp (-K)) / (Real.exp K + Real.exp (-K)) := by
    rw [Real.tanh_eq_sinh_div_cosh, Real.sinh_eq, Real.cosh_eq]; field_simp
  have hpos : 0 < Real.tanh K := by
    rw [htanh]; exact div_pos (by linarith) (by linarith)
  have hlog := Real.log_le_sub_one_of_pos hpos
  -- 1 − tanh K = 2b/(a+b) ≥ b·b （a·b = 1、b ≤ 1）
  have hkey : Real.exp (-K) * Real.exp (-K) ≤ 1 - Real.tanh K := by
    rw [htanh, one_sub_div (by linarith : Real.exp K + Real.exp (-K) ≠ 0), le_div_iff₀ (by linarith)]
    have hb1 : Real.exp (-K) ≤ 1 := by rw [Real.exp_le_one_iff]; linarith
    nlinarith [mul_pos hb hb, mul_pos ha hb]
  rw [hy]; linarith

/-- 紙の命題 3.4 の算術：0 < θ ≤ (tanh K)^n、0 < K、2K ≤ A なら n·e^{−A} ≤ −log θ。
格子では n = 塊の数、A = β κ + D log(β L) + C、−log θ/M² が σ の近似。 -/
theorem rate_of_blocks {θ K A : ℝ} {n : ℕ} (hθ : 0 < θ) (hK : 0 < K)
    (hbound : θ ≤ Real.tanh K ^ n) (hA : 2 * K ≤ A) :
    (n : ℝ) * Real.exp (-A) ≤ -Real.log θ := by
  have htp : 0 < Real.tanh K := by
    rw [Real.tanh_eq_sinh_div_cosh]; exact div_pos (Real.sinh_pos_iff.mpr hK) (Real.cosh_pos K)
  have hlog : Real.log θ ≤ n * Real.log (Real.tanh K) := by
    rw [← Real.log_pow]; exact Real.log_le_log hθ hbound
  have h1 := neg_log_tanh_ge hK
  have h2 : Real.exp (-A) ≤ Real.exp (-2 * K) := Real.exp_le_exp.mpr (by linarith)
  have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  nlinarith [mul_le_mul_of_nonneg_left (h2.trans h1) hn]


/-- 紙の定理 E の最後の一歩（β → ∞）：σ(β) ≥ c·e^{−D log(βL)}·e^{−βκ} が十分大きい β で立てば、
全ての ε > 0 で十分大きい β について log(1/σ(β)) ≤ (κ + ε)β。すなわち limsup (1/β) log(1/σ) ≤ κ。 -/
theorem rate_limit (σ : ℝ → ℝ) {c D L κ : ℝ} (hc : 0 < c) (hD : 0 ≤ D) (hL : 0 < L)
    (h : ∀ᶠ β in Filter.atTop, 0 < σ β ∧
      c * Real.exp (-(D * Real.log (β * L))) * Real.exp (-(β * κ)) ≤ σ β) :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, Real.log (1 / σ β) ≤ (κ + ε) * β := by
  intro ε hε
  have hDp : 0 < D + 1 := by linarith
  have h1 := Real.isLittleO_log_id_atTop.bound (c := ε / (2 * (D + 1))) (by positivity)
  have h2 : ∀ᶠ β in Filter.atTop, (|Real.log c| + D * |Real.log L|) ≤ ε / 2 * β := by
    filter_upwards [Filter.eventually_ge_atTop ((|Real.log c| + D * |Real.log L|) / (ε / 2))] with β hβ
    have h' := (div_le_iff₀ (by positivity : (0 : ℝ) < ε / 2)).mp hβ
    linarith [mul_comm β (ε / 2)]
  filter_upwards [h, h1, h2, Filter.eventually_ge_atTop (1 : ℝ)] with β hσ hlog hc2 hβ1
  obtain ⟨hσp, hlow⟩ := hσ
  have hβp : 0 < β := by linarith
  have hlowpos : 0 < c * Real.exp (-(D * Real.log (β * L))) * Real.exp (-(β * κ)) := by positivity
  have hle := Real.log_le_log hlowpos hlow
  rw [Real.log_mul (by positivity) (by positivity), Real.log_mul (by positivity) (by positivity),
    Real.log_exp, Real.log_exp, Real.log_mul (by positivity) (by positivity)] at hle
  rw [one_div, Real.log_inv]
  have hlb : Real.log β ≤ ε / (2 * (D + 1)) * β := by
    have := hlog
    simp only [Real.norm_eq_abs, id] at this
    rw [abs_of_pos hβp] at this
    exact (le_abs_self _).trans this
  have hDlog : D * Real.log β ≤ ε / 2 * β := by
    have hmul := mul_le_mul_of_nonneg_left hlb hD
    have : D * (ε / (2 * (D + 1)) * β) ≤ ε / 2 * β := by
      rw [show D * (ε / (2 * (D + 1)) * β) = (D / (D + 1)) * (ε / 2 * β) by field_simp]
      have hfrac : D / (D + 1) ≤ 1 := by rw [div_le_one hDp]; linarith
      have : 0 ≤ ε / 2 * β := by positivity
      nlinarith
    linarith
  have hc' : -Real.log c ≤ |Real.log c| := neg_le_abs _
  have hL' : D * Real.log L ≤ D * |Real.log L| := mul_le_mul_of_nonneg_left (le_abs_self _) hD
  nlinarith


/-! ## 段 1 の数え上げ（紙の系 2.0）
Z[η] が符号の積 `sgn η` だけで決まる（`Z η = g (sgn η)`）なら、
Σ_η sgn η · Z[η] = 2^n (Z₀ − Z₁)、Σ_η Z[η] = 2^n (Z₀ + Z₁)（升の数 n + 1）。よって θ = ⟨Π η⟩。 -/

/-- η の符号の積（格子では Π_P η(P)、`true` が反転）。 -/
noncomputable def sgn {n : ℕ} (η : Fin n → Bool) : ℝ := ∏ i, (if η i then (-1 : ℝ) else 1)

theorem sgn_mul_self {n : ℕ} (η : Fin n → Bool) : sgn η * sgn η = 1 := by
  unfold sgn
  rw [← Finset.prod_mul_distrib]
  refine Finset.prod_eq_one (fun i _ => ?_)
  split_ifs <;> norm_num

theorem sum_sgn (n : ℕ) : ∑ η : Fin (n + 1) → Bool, sgn η = 0 := by
  unfold sgn
  rw [← Fintype.prod_sum (fun (_ : Fin (n + 1)) (b : Bool) => if b then (-1 : ℝ) else 1)]
  rw [Fin.prod_univ_succ]
  simp

theorem eta_sums (n : ℕ) (g : ℝ → ℝ) :
    (∑ η : Fin (n + 1) → Bool, sgn η * g (sgn η)) = 2 ^ n * (g 1 - g (-1)) ∧
    (∑ η : Fin (n + 1) → Bool, g (sgn η)) = 2 ^ n * (g 1 + g (-1)) := by
  have hcases : ∀ η : Fin (n + 1) → Bool, sgn η = 1 ∨ sgn η = -1 :=
    fun η => mul_self_eq_one_iff.mp (sgn_mul_self η)
  have hlin1 : ∀ η : Fin (n + 1) → Bool,
      sgn η * g (sgn η) = sgn η * ((g 1 + g (-1)) / 2) + (g 1 - g (-1)) / 2 := by
    intro η; rcases hcases η with h | h <;> rw [h] <;> ring
  have hlin2 : ∀ η : Fin (n + 1) → Bool,
      g (sgn η) = (g 1 + g (-1)) / 2 + sgn η * ((g 1 - g (-1)) / 2) := by
    intro η; rcases hcases η with h | h <;> rw [h] <;> ring
  have hcard : (Fintype.card (Fin (n + 1) → Bool) : ℝ) = 2 ^ (n + 1) := by
    simp
  constructor
  · rw [Finset.sum_congr rfl (fun η _ => hlin1 η), Finset.sum_add_distrib, ← Finset.sum_mul,
      sum_sgn, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, hcard]
    ring
  · rw [Finset.sum_congr rfl (fun η _ => hlin2 η), Finset.sum_add_distrib, ← Finset.sum_mul,
      sum_sgn, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, hcard]
    ring

/-! ## 仮定の欄が満たせる例 -/

/-- 実例（小さいが実際の系）：Ising 型の二点、塊 2 つ、枠なし（`F = Unit`）、内部 `Bool`、
重み e^{±β}、符号 ±1。塊ごとの比は tanh β で、仮定 `ht` は t = tanh β で満たされる。 -/
example (β : ℝ) (hβ : 0 ≤ β) :
    let W : Fin 2 → Unit → Bool → ℝ := fun _ _ x => Real.exp (if x then β else -β)
    let σ : Fin 2 → Bool → ℝ := fun _ x => if x then 1 else -1
    ∀ b f, |∑ x, W b f x * σ b x| ≤ Real.tanh β * ∑ x, W b f x := by
  intro W σ b f
  simp only [W, σ, Fintype.sum_bool, if_true, Bool.false_eq_true, if_false, mul_one, mul_neg]
  have hp : 0 < Real.exp β := Real.exp_pos β
  have hm : 0 < Real.exp (-β) := Real.exp_pos (-β)
  have h1 : Real.exp β ≤ Real.exp (2 * β) * Real.exp (-β) := by
    rw [← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith)
  have h2 : Real.exp (-β) ≤ Real.exp (2 * β) * Real.exp β := by
    rw [← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith)
  have := ratio_tanh hp hm h1 h2
  simpa [sub_eq_add_neg] using this

/-- `rate_limit` の仮定の欄が空でないことを示すだけの例：σ をちょうど下界の式に取る。 -/
example (κ : ℝ) : ∀ ε > 0, ∀ᶠ β in Filter.atTop,
    Real.log (1 / (2 * Real.exp (-(3 * Real.log (β * 5))) * Real.exp (-(β * κ)))) ≤ (κ + ε) * β :=
  rate_limit (fun β => 2 * Real.exp (-(3 * Real.log (β * 5))) * Real.exp (-(β * κ)))
    (by norm_num) (by norm_num) (by norm_num)
    (Filter.Eventually.of_forall (fun β => ⟨by positivity, le_refl _⟩))

/-- `block_tanh` の仮定の欄が満たせる例（実例：Ising 型の二点、塊二つ、枠なし。Z₊ = e^β、Z₋ = e^{−β}、K = β）。 -/
example (β : ℝ) (hβ : 0 ≤ β) :
    |∑ _f : Unit, (1 : ℝ) * ∏ _b : Fin 2, (Real.exp β - Real.exp (-β))|
      ≤ (∏ _b : Fin 2, Real.tanh β) * ∑ _f : Unit, (1 : ℝ) * ∏ _b : Fin 2, (Real.exp β + Real.exp (-β)) :=
  block_tanh (fun _ => 1) (fun _ _ => Real.exp β) (fun _ _ => Real.exp (-β)) (fun _ => β)
    (fun _ => zero_le_one) (fun _ _ => Real.exp_pos _) (fun _ _ => Real.exp_pos _)
    (fun _ _ => by rw [← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith))
    (fun _ _ => by rw [← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith))

end BlockFactor

#print axioms BlockFactor.sum_factor
#print axioms BlockFactor.block_bound
#print axioms BlockFactor.ratio_tanh
#print axioms BlockFactor.neg_log_tanh_ge
#print axioms BlockFactor.rate_of_blocks
#print axioms BlockFactor.rate_limit
#print axioms BlockFactor.eta_sums
#print axioms BlockFactor.block_tanh
