import PushRare.BlockChessV1
import FoldChess.RarityAllV1
import PushRare.ReachV1
/-!
**One step of the block map: the reference event is a block function, and the sublattice form of the reduction.**

Fine torus (ℤ/2L)⁴ (level 1 of the box family), coarse torus (ℤ/L)⁴ (level 0), B1 := the block map with the
paths of weights (1/8, 3/4, 1/8) and the radial retraction (radius r₀).  For a coarse plaquette p,
A_p := {1 − Re U_p(B1 ω) > y}.  With blocks of side 8 (fine units; L = 8m):
* `gRef_base` : the indicator of A_p for the reference plaquette p = ((1,1,1,1); μ, ν) is a bounded measurable function
  of the links of the fine cube [0, 8]⁴ (the locality of the block map, radius 2, gives the fine support
  [0, 6]⁴);
* `gRef_even` : on a block w with even coordinates, the transported reference event is A_p at the coarse plaquette
  ((1,1,1,1) + 4w; μ, ν) (translation covariance of the block map);
* `push_rarity_even` : if the uniform pattern weight of the reference event is at most Z·z^(n⁴), then for every set
  S of blocks with even coordinates, ∫ ∏_{w ∈ S} 1_{A_{p(w)}}(B1 ω) dμ_W ≤ Z·z^|S|.

Paper correspondence: the rarity of the pushed-forward measure (one step), reduced to the fine-lattice chessboard.
-/

namespace PushReduce

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy PushChess PushLocal Finset

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

/-- one step of the block map, from (ℤ/2L)⁴ to (ℤ/L)⁴ -/
noncomputable def B1 {r₀ : ℝ} (hr : 0 < r₀) (ω : FoldWilson.Cfg (2 ^ (0 + 1) * L)) :
    FoldWilson.Cfg (2 ^ 0 * L) :=
  ChainBlockMap.blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) 0 ω

theorem measurable_B1 {r₀ : ℝ} (hr : 0 < r₀) : Measurable (B1 L hr) :=
  (ChainBlockMap.continuous_blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) 0).measurable

/-- the reference coarse site (1, 1, 1, 1) -/
def yref : TorusRP.Site (2 ^ 0 * L) := fun _ => 1

/-- the reference event: the coarse plaquette ((1,1,1,1); μ, ν) of B1 ω is large -/
noncomputable def gRef {r₀ : ℝ} (hr : 0 < r₀) (y : ℝ) (μ ν : Fin 4) (ω : FoldWilson.Cfg (2 ^ (0 + 1) * L)) : ℝ :=
  bigP (2 ^ 0 * L) y (B1 L hr ω) ((yref L, μ), ν)

theorem val_small {K : ℕ} [NeZero K] (w : ℤ) (h0 : 0 ≤ w) (h6 : w ≤ 6) (hK : 6 < K) :
    ((w : ZMod K)).val ≤ 6 := by
  have h := ZMod.val_intCast (n := K) w
  rw [Int.emod_eq_of_lt h0 (by omega)] at h
  omega

theorem inCube_coarse (hL : 4 ≤ L) (c : TorusRP.Site (2 ^ 0 * L))
    (hc : ∀ i, ∃ k : ℤ, 1 ≤ k ∧ k ≤ 2 ∧ c i = (k : ZMod (2 ^ 0 * L))) (μ' : Fin 4) (z : Fin 4 → ℤ)
    (hz : ∀ i, -2 ≤ z i ∧ z i ≤ 2) (ν' : Fin 4) :
    InCubeB (2 ^ (0 + 1) * L) 8 (BoxWalk.base L 0 (c, μ') + BoxWalk.red L 0 z, ν') := by
  have hcoord : ∀ j, ((BoxWalk.base L 0 (c, μ') + BoxWalk.red L 0 z) j).val ≤ 6 := by
    intro j
    obtain ⟨k, hk1, hk2, hk⟩ := hc j
    have e : (BoxWalk.base L 0 (c, μ') + BoxWalk.red L 0 z) j =
        (((2 * k + z j : ℤ)) : ZMod (2 ^ (0 + 1) * L)) := by
      simp only [Pi.add_apply, BoxWalk.base, hk, BoxWalk.double_intCast, BoxWalk.red,
        AddMonoidHom.compLeft_apply, Function.comp_apply, Int.coe_castAddHom]
      push_cast; ring
    rw [e]
    have hzj := hz j
    exact val_small (2 * k + z j) (by omega) (by omega) (by norm_num; omega)
  exact ⟨lt_of_le_of_lt (hcoord _) (by norm_num), fun j => le_trans (hcoord j) (by norm_num)⟩

theorem yref_ok : ∀ i, ∃ k : ℤ, 1 ≤ k ∧ k ≤ 2 ∧ yref L i = (k : ZMod (2 ^ 0 * L)) :=
  fun _ => ⟨1, le_rfl, by norm_num, by simp [yref]⟩

theorem yref_ev_ok (d : Fin 4) :
    ∀ i, ∃ k : ℤ, 1 ≤ k ∧ k ≤ 2 ∧ (yref L + TorusRP.ev (2 ^ 0 * L) d : TorusRP.Site (2 ^ 0 * L)) i = (k : ZMod (2 ^ 0 * L)) := by
  intro i
  by_cases h : i = d
  · refine ⟨2, by norm_num, le_rfl, ?_⟩
    subst h; simp only [Pi.add_apply, yref, TorusRP.ev, Pi.single_eq_same]; push_cast; ring
  · refine ⟨1, le_rfl, by norm_num, ?_⟩
    simp only [Pi.add_apply, yref, TorusRP.ev, Pi.single_eq_of_ne h]; push_cast; ring

/-- **The reference event is a block function of the cube [0, 8]⁴** (L ≥ 4). -/
theorem gRef_base (hL : 4 ≤ L) {r₀ : ℝ} (hr : 0 < r₀) (y : ℝ) (μ ν : Fin 4) :
    BaseB (2 ^ (0 + 1) * L) 8 (gRef L hr y μ ν) := by
  refine ⟨(measurable_bigP (2 ^ 0 * L) y _).comp (measurable_B1 L hr), ⟨1, fun ω => ?_⟩, fun ω ω' hag => ?_⟩
  · simp only [gRef]; rw [abs_of_nonneg (bigP_nonneg _ _ _ _)]; exact bigP_le_one _ _ _ _
  · have hlink : ∀ c : TorusRP.Site (2 ^ 0 * L), (∀ i, ∃ k : ℤ, 1 ≤ k ∧ k ≤ 2 ∧ c i = (k : ZMod (2 ^ 0 * L))) →
        ∀ μ', Uq (2 ^ 0 * L) (B1 L hr ω) (c, μ') = Uq (2 ^ 0 * L) (B1 L hr ω') (c, μ') :=
      fun c hc μ' => boxMap_local L hr 0 ω ω' (c, μ') (fun z hz ν' => hag _ (inCube_coarse L hL c hc μ' z hz ν'))
    have hhol : hol (2 ^ 0 * L) (B1 L hr ω) ((yref L, μ), ν) = hol (2 ^ 0 * L) (B1 L hr ω') ((yref L, μ), ν) := by
      simp only [hol, holQ]
      rw [hlink _ (yref_ok L) μ, hlink _ (yref_ev_ok L μ) ν, hlink _ (yref_ev_ok L ν) μ,
        hlink _ (yref_ok L) ν]
    simp only [gRef, bigP, hhol]

/-- the coarse offset of the block w (even coordinates): 4 w -/
def cvec (n : ℕ) (q : Z4 n) : TorusRP.Site (2 ^ 0 * L) :=
  fun j => ((4 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ZMod (2 ^ 0 * L))

theorem double_cvec (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 1) * L = 8 * n) (q : Z4 n) (j : Fin 4) :
    BoxWalk.double L 0 (cvec L n q j) = ι (2 ^ (0 + 1) * L) n 8 hNb (![q.1, q.2.1, q.2.2.1, q.2.2.2] j) := by
  rw [ι_nat, cvec]
  have e : (((4 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ZMod (2 ^ 0 * L))) =
      ((((4 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ℤ)) : ZMod (2 ^ 0 * L)) := by
    rw [Int.cast_natCast]
  rw [e, BoxWalk.double_intCast]
  push_cast; ring

/-- on a block with even coordinates the transport is the translation by 8 w -/
theorem ΨB_even (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 1) * L = 8 * n) (q : Z4 n)
    (h0 : par n q.1 = false) (h1 : par n q.2.1 = false) (h2 : par n q.2.2.1 = false)
    (h3 : par n q.2.2.2 = false) (ω : FoldWilson.Cfg (2 ^ (0 + 1) * L)) :
    ΨB (2 ^ (0 + 1) * L) n 8 hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω =
      shV (2 ^ (0 + 1) * L) (fun j => BoxWalk.double L 0 (cvec L n q j)) ω := by
  simp only [ΨB, ΦB, cof, h0, h1, h2, h3, Bool.false_eq_true, if_false, affC_false_eq]
  funext ℓ
  simp only [shV]
  congr 2
  funext j
  simp only [Pi.add_apply]
  rw [double_cvec L n hNb q j]
  fin_cases j <;> simp [Pi.single_apply]

/-- **The transported reference event on an even block is the event at the coarse plaquette (1,1,1,1) + 4 w.** -/
theorem gRef_even (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 1) * L = 8 * n) {r₀ : ℝ} (hr : 0 < r₀) (y : ℝ)
    (μ ν : Fin 4) (q : Z4 n)
    (h0 : par n q.1 = false) (h1 : par n q.2.1 = false) (h2 : par n q.2.2.1 = false)
    (h3 : par n q.2.2.2 = false) (ω : FoldWilson.Cfg (2 ^ (0 + 1) * L)) :
    gRef L hr y μ ν (ΨB (2 ^ (0 + 1) * L) n 8 hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      bigP (2 ^ 0 * L) y (B1 L hr ω) ((yref L + cvec L n q, μ), ν) := by
  rw [ΨB_even L n hNb q h0 h1 h2 h3]
  have e : B1 L hr (shV (2 ^ (0 + 1) * L) (fun j => BoxWalk.double L 0 (cvec L n q j)) ω) =
      shV (2 ^ 0 * L) (cvec L n q) (B1 L hr ω) :=
    boxMap_trans L hr 0 (cvec L n q) ω
  simp only [gRef, e, bigP, hol_shV]

theorem four_le (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 1) * L = 8 * n) : 4 ≤ L := by
  have hn0 : n ≠ 0 := NeZero.ne n
  norm_num at hNb
  omega

/-- **Sublattice form of the reduction (one step of the block map).**  If the uniform pattern weight of the
reference event is at most Z·z^(n⁴), then for every set S of blocks with even coordinates
  ∫ ∏_{w ∈ S} 1[1 − Re U_{((1,1,1,1)+4w; μ,ν)}(B1 ω) > y] dμ_W(ω) ≤ Z·z^|S|,
μ_W the unnormalised SU(2) Wilson measure on the fine torus (ℤ/2L)⁴, 2L = 8n, n = 2m, Z its total mass. -/
theorem push_rarity_even (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 1) * L = 8 * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β y : ℝ) (μ ν : Fin 4) (z : ℝ) (hz : 0 ≤ z)
    (hpat : patternWeight (2 ^ (0 + 1) * L) n 8 hNb β (gRef L hr y μ ν) ≤
      Zw (2 ^ (0 + 1) * L) β * z ^ (n ^ 4))
    (S : Finset (Z4 n))
    (hS : ∀ q ∈ S, par n q.1 = false ∧ par n q.2.1 = false ∧ par n q.2.2.1 = false ∧ par n q.2.2.2 = false) :
    ∫ ω, ∏ q ∈ S, bigP (2 ^ 0 * L) y (B1 L hr ω) ((yref L + cvec L n q, μ), ν)
        ∂(wilsonMeasure (2 ^ (0 + 1) * L) β) ≤ Zw (2 ^ (0 + 1) * L) β * z ^ S.card := by
  have hL := four_le L n m hn hNb
  have h := chess_subset (2 ^ (0 + 1) * L) n 8 hNb m (8 * m) hn rfl β (gRef L hr y μ ν)
    (gRef_base L hL hr y μ ν) z hz hpat S
  refine le_trans (le_of_eq (integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_))) h
  refine prod_congr rfl fun q hq => ?_
  obtain ⟨h0, h1, h2, h3⟩ := hS q hq
  rw [gRef_even L n hNb hr y μ ν q h0 h1 h2 h3]

end PushReduce

#print axioms PushReduce.gRef_base
#print axioms PushReduce.push_rarity_even
