import PushRare.SanityKV1
import FoldChess.ExplicitV1
/-!
**At k = 0 the hypothesis of the reduction theorem holds with z < 1** (β ≥ 81, threshold y = 1).

For k = 0 the block map is the identity and the uniform pattern of the reference event (blocks of side 8) is the
event that n⁴ distinct plaquettes of the fine torus (one per block, at the transported positions) are all large.
The volume-uniform rarity on one scale (`FoldCap.rarity_explicit`, unit-cube chessboard) bounds it by
Z·q₁^⌊n⁴/6⌋ ≤ Z·(q₁^(1/12))^(n⁴), q₁ = e^{β(48/400 − 1)}/h(1/20)⁴ < 1.
* `pattern_zero` : patternWeight ≤ Z·(q₁^(1/12))^(n⁴), and q₁^(1/12) < 1;
* `push_rarity_zero` : the conclusion of the reduction theorem at k = 0 with z = q₁^(1/12) (weaker than the
  one-scale theorem itself; it shows that the hypothesis is discharged by a theorem at k = 0).

Paper correspondence: the k = 0 instance of the hypothesis of the reduction theorem (one-scale rarity).
-/

namespace PushReduceK

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy FoldQuarter FoldCap PushChess
  PushLocal Finset

variable (L : ℕ) [NeZero L]

/-- the transported reference site in direction d (k = 0) -/
def imgC (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n) (μ ν : Fin 4) (d : Fin 4) (t : ZMod n) :
    ZMod (2 ^ (0 + 0) * L) :=
  nb (2 ^ (0 + 0) * L) d (par n t) (ι (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb (cof n t)) μ ν (fun _ => 2)

/-- the transported reference plaquette of the block q -/
def imgP (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n) (μ ν : Fin 4) (q : Z4 n) :
    Lk (2 ^ (0 + 0) * L) × Fin 4 :=
  ((fun d => imgC L n hNb μ ν d (![q.1, q.2.1, q.2.2.1, q.2.2.2] d), μ), ν)

theorem gRef_zero_eq (n : ℕ) [NeZero n] (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n) {r₀ : ℝ} (hr : 0 < r₀)
    (μ ν : Fin 4) (hμν : μ < ν) (q : Z4 n) (ω : FoldWilson.Cfg (2 ^ (0 + 0) * L)) :
    gRefK L hr 0 1 μ ν (ΨB (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      bigP (2 ^ (0 + 0) * L) 1 ω (imgP L n hNb μ ν q) := by
  show bigP (2 ^ (0 + 0) * L) 1 (ΨB (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω)
      ((fun _ => 2, μ), ν) = _
  unfold bigP
  have hre : (hol (2 ^ (0 + 0) * L) (ΨB (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω)
      ((fun _ => 2, μ), ν)).re = (hol (2 ^ (0 + 0) * L) ω (imgP L n hNb μ ν q)).re := by
    simp only [ΨB, ΦB]
    rw [re_hol_affC _ _ _ _ _ _ μ ν hμν, re_hol_affC _ _ _ _ _ _ μ ν hμν, re_hol_affC _ _ _ _ _ _ μ ν hμν,
      re_hol_affC _ _ _ _ _ _ μ ν hμν]
    congr 4
    funext d
    fin_cases d <;> simp [imgC, nb, Function.update_apply]
  rw [hre]

theorem imgC_val (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n)
    (μ ν d : Fin 4) (t : ZMod n) :
    ∃ r : ℕ, r < 8 ∧ (imgC L n hNb μ ν d t).val = 8 * t.val + r := by
  have hn1 : 1 < n := by have := NeZero.ne n; omega
  have hNn : 2 ^ (0 + 0) * L = 8 * n := by rw [hNb]; norm_num
  have ht := ZMod.val_lt t
  have hlt : ∀ r : ℕ, r < 8 → 8 * t.val + r < 2 ^ (0 + 0) * L := by intro r hr; rw [hNn]; omega
  have hι : ι (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb t = ((8 * t.val : ℕ) : ZMod (2 ^ (0 + 0) * L)) := by
    rw [ι_nat]; norm_num
  have hι1 : ι (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb 1 = ((8 : ℕ) : ZMod (2 ^ (0 + 0) * L)) := by
    rw [ι_nat, ZMod.val_one_eq_one_mod, Nat.mod_eq_of_lt hn1]; norm_num
  unfold imgC nb cof
  cases hp : par n t
  · refine ⟨2, by norm_num, ?_⟩
    simp only [Bool.false_eq_true, if_false]
    rw [hι, show ((2 : ZMod (2 ^ (0 + 0) * L)) + ((8 * t.val : ℕ) : ZMod (2 ^ (0 + 0) * L))) =
      ((8 * t.val + 2 : ℕ) : ZMod (2 ^ (0 + 0) * L)) by push_cast; ring]
    exact ZMod.val_cast_of_lt (hlt 2 (by norm_num))
  · simp only [if_true, map_add, hι, hι1]
    by_cases hd : d = μ ∨ d = ν
    · refine ⟨5, by norm_num, ?_⟩
      rw [if_pos hd, show ((8 * t.val : ℕ) : ZMod (2 ^ (0 + 0) * L)) + ((8 : ℕ) : ZMod (2 ^ (0 + 0) * L)) - 2 - 1 =
        ((8 * t.val + 5 : ℕ) : ZMod (2 ^ (0 + 0) * L)) by push_cast; ring]
      exact ZMod.val_cast_of_lt (hlt 5 (by norm_num))
    · refine ⟨6, by norm_num, ?_⟩
      rw [if_neg hd, show ((8 * t.val : ℕ) : ZMod (2 ^ (0 + 0) * L)) + ((8 : ℕ) : ZMod (2 ^ (0 + 0) * L)) - 2 =
        ((8 * t.val + 6 : ℕ) : ZMod (2 ^ (0 + 0) * L)) by push_cast; ring]
      exact ZMod.val_cast_of_lt (hlt 6 (by norm_num))

theorem imgC_inj (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n)
    (μ ν d : Fin 4) (t t' : ZMod n) (h : imgC L n hNb μ ν d t = imgC L n hNb μ ν d t') : t = t' := by
  obtain ⟨r, hr, hv⟩ := imgC_val L n m hn hNb μ ν d t
  obtain ⟨r', hr', hv'⟩ := imgC_val L n m hn hNb μ ν d t'
  rw [h] at hv
  apply ZMod.val_injective
  omega

theorem imgP_inj (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n)
    (μ ν : Fin 4) : Function.Injective (imgP L n hNb μ ν) := by
  intro q q' h
  have h1 : ∀ d, imgC L n hNb μ ν d (![q.1, q.2.1, q.2.2.1, q.2.2.2] d) =
      imgC L n hNb μ ν d (![q'.1, q'.2.1, q'.2.2.1, q'.2.2.2] d) := fun d =>
    congrFun (congrArg (fun p : Lk (2 ^ (0 + 0) * L) × Fin 4 => p.1.1) h) d
  have e0 := imgC_inj L n m hn hNb μ ν 0 _ _ (h1 0)
  have e1 := imgC_inj L n m hn hNb μ ν 1 _ _ (h1 1)
  have e2 := imgC_inj L n m hn hNb μ ν 2 _ _ (h1 2)
  have e3 := imgC_inj L n m hn hNb μ ν 3 _ _ (h1 3)
  simp at e0 e1 e2 e3
  obtain ⟨a, b, c, d⟩ := q
  obtain ⟨a', b', c', d'⟩ := q'
  simp only at e0 e1 e2 e3
  rw [e0, e1, e2, e3]

/-- q₁ of the explicit one-scale rarity -/
noncomputable def q1 (β : ℝ) : ℝ := Real.exp (β * (48 * (1 / 20) ^ 2 - 1)) / haarBall.real (ballQ (1 / 20)) ^ 4

theorem q1_pos (β : ℝ) : 0 < q1 β :=
  div_pos (Real.exp_pos _) (pow_pos (ballQ_pos (1 / 20) (by norm_num)) _)

/-- **k = 0: the uniform pattern weight is at most Z·(q₁^(1/12))^(n⁴), with q₁^(1/12) < 1 for β ≥ 81.** -/
theorem pattern_zero (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β : ℝ) (hβ : 81 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) :
    q1 β ^ ((1 : ℝ) / 12) < 1 ∧
    patternWeight (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb β (gRefK L hr 0 1 μ ν) ≤
      Zw (2 ^ (0 + 0) * L) β * (q1 β ^ ((1 : ℝ) / 12)) ^ (n ^ 4) := by
  obtain ⟨hq, hrare⟩ := rarity_explicit β hβ
  have hq1 : q1 β < 1 := hq
  have hq0 := q1_pos β
  refine ⟨Real.rpow_lt_one hq0.le hq1 (by norm_num), ?_⟩
  have hNn : 2 ^ (0 + 0) * L = 8 * n := by rw [hNb]; norm_num
  set X := (Finset.univ : Finset (Z4 n)).image (imgP L n hNb μ ν) with hX
  have hXp : X ⊆ plaqs (2 ^ (0 + 0) * L) := by
    intro p hp
    obtain ⟨q, _, rfl⟩ := mem_image.mp hp
    simp [plaqs, imgP, hμν]
  have hcard : X.card = n ^ 4 := by
    rw [hX, card_image_of_injective _ (imgP_inj L n m hn hNb μ ν), card_univ]
    simp [Z4, Fintype.card_prod, ZMod.card]; ring
  have h := hrare (2 ^ (0 + 0) * L) (4 * n) (by rw [hNn]; ring) (by have := NeZero.ne n; omega) X hXp
  have e : patternWeight (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb β (gRefK L hr 0 1 μ ν) =
      ∫ ω, ∏ p ∈ X, bigP (2 ^ (0 + 0) * L) 1 ω p ∂(wilsonMeasure (2 ^ (0 + 0) * L) β) := by
    unfold patternWeight
    refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
    show ∏ q : Z4 n, gRefK L hr 0 1 μ ν (ΨB (2 ^ (0 + 0) * L) n (8 * 2 ^ 0) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      ∏ p ∈ X, bigP (2 ^ (0 + 0) * L) 1 ω p
    rw [hX, prod_image (fun a _ b _ hab => imgP_inj L n m hn hNb μ ν hab)]
    exact prod_congr rfl fun q _ => gRef_zero_eq L n hNb hr μ ν hμν q ω
  rw [e]
  refine le_trans h (mul_le_mul_of_nonneg_left ?_ (Zw_nonneg _ β))
  rw [hcard]
  -- q^⌊n⁴/6⌋ ≤ q^(n⁴/12)
  have hn4 : 16 ≤ n ^ 4 := by
    have : 2 ≤ n := by have := NeZero.ne n; omega
    calc 16 = 2 ^ 4 := by norm_num
      _ ≤ n ^ 4 := Nat.pow_le_pow_left this 4
  have hfl : ((n ^ 4 : ℕ) : ℝ) / 12 ≤ ((n ^ 4 / 6 : ℕ) : ℝ) := by
    have h6 : n ^ 4 ≤ 12 * (n ^ 4 / 6) := by omega
    rw [div_le_iff₀ (by norm_num)]
    exact_mod_cast (by linarith : n ^ 4 ≤ (n ^ 4 / 6) * 12)
  rw [← Real.rpow_natCast (q1 β ^ ((1 : ℝ) / 12)), ← Real.rpow_mul hq0.le, ← Real.rpow_natCast]
  have : (1 : ℝ) / 12 * ((n ^ 4 : ℕ) : ℝ) = ((n ^ 4 : ℕ) : ℝ) / 12 := by ring
  rw [this]
  exact Real.rpow_le_rpow_of_exponent_ge hq0 hq1.le hfl

/-- **The reduction theorem at k = 0 with its hypothesis discharged** (β ≥ 81, y = 1, z = q₁^(1/12) < 1). -/
theorem push_rarity_zero (n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + 0) * L = (8 * 2 ^ 0) * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β : ℝ) (hβ : 81 ≤ β)
    (X : Finset (Lk (2 ^ 0 * L) × Fin 4)) (hX : X ⊆ plaqs (2 ^ 0 * L)) :
    ∫ ω, ∏ p ∈ X, bigP (2 ^ 0 * L) 1 (BK L hr 0 ω) p ∂(wilsonMeasure (2 ^ (0 + 0) * L) β) ≤
      Zw (2 ^ (0 + 0) * L) β * (q1 β ^ ((1 : ℝ) / 12)) ^ (X.card / 393216) := by
  have hz0 : 0 ≤ q1 β ^ ((1 : ℝ) / 12) := Real.rpow_nonneg (q1_pos β).le _
  have hz1 : q1 β ^ ((1 : ℝ) / 12) ≤ 1 := (pattern_zero L n m hn hNb hr β hβ 0 1 (by decide)).1.le
  exact push_rarity_allK L 0 n m hn hNb hr β 1 _ hz0 hz1
    (fun μ ν hμν => (pattern_zero L n m hn hNb hr β hβ μ ν hμν).2) X hX

end PushReduceK

#print axioms PushReduceK.pattern_zero
#print axioms PushReduceK.push_rarity_zero
