import PushRare.ZeroV1
/-!
**The reduction theorem written in the pushed-forward measure.**  With ν_k := (BK)_* μ_W (the image of the
unnormalised SU(2) Wilson measure of (ℤ/2^k L)⁴ under k steps of the block map, a measure on the configurations of
(ℤ/L)⁴), the conclusion of `push_rarity_allK` reads: for every finite set X of plaquettes of (ℤ/L)⁴,
  ν_k(1 − Re U_p > y for all p ∈ X) ≤ ν_k(total) · z^⌊|X|/393216⌋,
under the hypothesis on the uniform pattern weight (one number per orientation).  At k = 0, β ≥ 81, y = 1 the
hypothesis holds with z = q₁^(1/12) < 1 (`push_rarity_zero`).

Paper correspondence: the raw form of the rarity of the pushed-forward measures ν_{n,n−k} (no effective action).
-/

namespace PushReduceK

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy PushChess PushLocal Finset

variable (L : ℕ) [NeZero L]

theorem map_total (k : ℕ) {r₀ : ℝ} (hr : 0 < r₀) (β : ℝ) :
    ∫ _V, (1 : ℝ) ∂((wilsonMeasure (2 ^ (0 + k) * L) β).map (BK L hr k)) = Zw (2 ^ (0 + k) * L) β := by
  rw [integral_map (measurable_BK L hr k).aemeasurable aestronglyMeasurable_const]
  rfl

/-- **The rarity in the pushed-forward measure (k steps), reduced to the uniform pattern weight.** -/
theorem push_rarity_map (k n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β y : ℝ) (z : ℝ) (hz0 : 0 ≤ z) (hz1 : z ≤ 1)
    (hpat : ∀ μ ν : Fin 4, μ < ν → patternWeight (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb β (gRefK L hr k y μ ν) ≤
      Zw (2 ^ (0 + k) * L) β * z ^ (n ^ 4))
    (X : Finset (Lk (2 ^ 0 * L) × Fin 4)) (hX : X ⊆ plaqs (2 ^ 0 * L)) :
    ∫ V, ∏ p ∈ X, bigP (2 ^ 0 * L) y V p ∂((wilsonMeasure (2 ^ (0 + k) * L) β).map (BK L hr k)) ≤
      (∫ _V, (1 : ℝ) ∂((wilsonMeasure (2 ^ (0 + k) * L) β).map (BK L hr k))) * z ^ (X.card / 393216) := by
  rw [map_total L k hr β]
  rw [integral_map (measurable_BK L hr k).aemeasurable
    (Finset.measurable_prod X (fun p _ => measurable_bigP _ y p)).aestronglyMeasurable]
  exact push_rarity_allK L k n m hn hNb hr β y z hz0 hz1 hpat X hX

end PushReduceK

#print axioms PushReduceK.push_rarity_map
