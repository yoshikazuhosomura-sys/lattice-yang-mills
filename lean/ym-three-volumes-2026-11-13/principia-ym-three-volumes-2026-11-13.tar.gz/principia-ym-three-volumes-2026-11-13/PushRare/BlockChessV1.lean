import FoldChess.WilsonChessV1
/-!
**The chessboard estimate with blocks of side b** for the concrete SU(2) Wilson measure on (ℤ/N)⁴, N = b·n, n = 2m.

Blocks w = (t0, t1, t2, t3) ∈ (ZMod n)⁴ are the cubes b·w + [0, b]⁴ of the fine torus.  The transport ΨB w is the
product over the directions d of ΦB d (t_d): the translation x_d ↦ x_d + b t (t even) or the reflection
x_d ↦ b (t + 1) − x_d (t odd).  The reflection between the blocks is the site reflection x_k ↦ 2ab − x_k.
The block functions are bounded measurable functions of the links of the cube [0, b]⁴ (links (x, μ) with
x_μ < b and 0 ≤ x_j ≤ b).  All fields of `FoldChess.Data4` are verified, so for every family F of block functions
  |∫ ∏_w Hf (F w) (ΨB w ω) dμ_W|^(n⁴) ≤ ∏_w ∫ ∏_{w'} Hf (F w) (ΨB w' ω) dμ_W.
The subset form: for a block function 0 ≤ g ≤ 1 whose uniform pattern weight is at most Z·z^(n⁴), every set S of
blocks has ∫ ∏_{w ∈ S} g (ΨB w ω) dμ_W ≤ Z·z^|S|.

Paper correspondence: the chessboard estimate (Fröhlich–Israel–Lieb–Simon) with blocks larger than one cell, used
for events whose fine support has a radius larger than one lattice spacing (events of the pushed-forward field).
-/

namespace PushChess

open MeasureTheory TorusRP LinkReflection PeierlsPerm PeierlsPermCS FoldAffine FoldChess FoldWilson Finset

variable (N n b : ℕ) [NeZero N] [NeZero n] (hNb : N = b * n)

/-- the block coordinate t ↦ the fine coordinate b·t (well defined when N = b n) -/
def ι : ZMod n →+ ZMod N :=
  ZMod.lift n ⟨(Int.castAddHom (ZMod N)).comp (AddMonoidHom.mulLeft (b : ℤ)), by
    simp only [AddMonoidHom.coe_comp, Function.comp_apply, AddMonoidHom.coe_mulLeft, Int.coe_castAddHom]
    have : (((b : ℤ) * (n : ℤ) : ℤ) : ZMod N) = ((N : ℕ) : ZMod N) := by rw [hNb]; push_cast; ring
    rw [this, ZMod.natCast_self]⟩

theorem ι_nat (s : ZMod n) : ι N n b hNb s = ((b * s.val : ℕ) : ZMod N) := by
  have hs : s = ((s.val : ℤ) : ZMod n) := by simp
  conv_lhs => rw [hs]
  rw [ι, ZMod.lift_coe]
  simp

theorem ι_val (s : ZMod n) : (ι N n b hNb s).val = b * s.val := by
  rw [ι_nat N n b hNb, ZMod.val_cast_of_lt]
  have hb : 0 < b := by
    rcases Nat.eq_zero_or_pos b with h | h
    · exact absurd (by rw [hNb, h, zero_mul]) (NeZero.ne N)
    · exact h
  rw [hNb]; exact Nat.mul_lt_mul_of_pos_left (ZMod.val_lt s) hb

/-- the transport of the blocks of one direction -/
noncomputable def ΦB (d : Fin 4) (t : ZMod n) : FoldWilson.Cfg N → FoldWilson.Cfg N :=
  affC N d (par n t) (ι N n b hNb (cof n t))

/-- the transport to the block (t0, t1, t2, t3) -/
noncomputable def ΨB (t0 t1 t2 t3 : ZMod n) (ω : FoldWilson.Cfg N) : FoldWilson.Cfg N :=
  ΦB N n b hNb 0 t0 (ΦB N n b hNb 1 t1 (ΦB N n b hNb 2 t2 (ΦB N n b hNb 3 t3 ω)))

/-- the reflection through the fine lattice plane x_k = b a -/
noncomputable def RB (k : Fin 4) (a : ZMod n) : FoldWilson.Cfg N → FoldWilson.Cfg N := R N k (ι N n b hNb a)

variable (m M : ℕ)

/-- the class of the reflection RB k a: measurable, bounded and depending on the closed plus half -/
def GoodB (k : Fin 4) (a : ZMod n) (f : FoldWilson.Cfg N → ℝ) : Prop := Good N M k (ι N n b hNb a) f

theorem ΦB_rho (hn : n = 2 * m) (d : Fin 4) (a t : ZMod n) (X : FoldWilson.Cfg N) :
    ΦB N n b hNb d (rho a t) X = ΦB N n b hNb d t (affC N d true (ι N n b hNb a + ι N n b hNb a) X) := by
  unfold ΦB cof
  rw [affC_comp, par_rho n m hn]
  cases hp : par n t
  · have e : rho a t + 1 = a + a - t := by unfold rho; ring
    simp [e, map_sub, map_add]
  · have e : rho a t = a + a - (t + 1) := by unfold rho; ring
    simp [e, map_sub, map_add]

theorem ΦB_R_comm (j k : Fin 4) (hjk : j ≠ k) (t a : ZMod n) (ω : FoldWilson.Cfg N) :
    ΦB N n b hNb j t (RB N n b hNb k a ω) = RB N n b hNb k a (ΦB N n b hNb j t ω) := by
  unfold ΦB RB R; exact affC_comm N j k hjk _ _ _ _ ω

theorem trB0 (hn : n = 2 * m) (a t0 t1 t2 t3 : ZMod n) (ω : FoldWilson.Cfg N) :
    ΨB N n b hNb (rho a t0) t1 t2 t3 ω = ΨB N n b hNb t0 t1 t2 t3 (RB N n b hNb 0 a ω) := by
  simp only [ΨB]
  rw [ΦB_R_comm N n b hNb 3 0 (by decide), ΦB_R_comm N n b hNb 2 0 (by decide),
    ΦB_R_comm N n b hNb 1 0 (by decide), RB, R, ← ΦB_rho N n b hNb m hn]

theorem trB1 (hn : n = 2 * m) (a t0 t1 t2 t3 : ZMod n) (ω : FoldWilson.Cfg N) :
    ΨB N n b hNb t0 (rho a t1) t2 t3 ω = ΨB N n b hNb t0 t1 t2 t3 (RB N n b hNb 1 a ω) := by
  simp only [ΨB]
  rw [ΦB_R_comm N n b hNb 3 1 (by decide), ΦB_R_comm N n b hNb 2 1 (by decide), RB, R,
    ← ΦB_rho N n b hNb m hn]

theorem trB2 (hn : n = 2 * m) (a t0 t1 t2 t3 : ZMod n) (ω : FoldWilson.Cfg N) :
    ΨB N n b hNb t0 t1 (rho a t2) t3 ω = ΨB N n b hNb t0 t1 t2 t3 (RB N n b hNb 2 a ω) := by
  simp only [ΨB]
  rw [ΦB_R_comm N n b hNb 3 2 (by decide), RB, R, ← ΦB_rho N n b hNb m hn]

theorem trB3 (hn : n = 2 * m) (a t0 t1 t2 t3 : ZMod n) (ω : FoldWilson.Cfg N) :
    ΨB N n b hNb t0 t1 t2 (rho a t3) ω = ΨB N n b hNb t0 t1 t2 t3 (RB N n b hNb 3 a ω) := by
  simp only [ΨB]
  rw [RB, R, ← ΦB_rho N n b hNb m hn]

/-! ### locality -/

/-- the links of the cube [0, b]⁴ -/
def InCubeB (ℓ : Lk N) : Prop := (ℓ.1 ℓ.2).val < b ∧ ∀ j, (ℓ.1 j).val ≤ b

/-- bounded measurable functions of the links of the cube [0, b]⁴ -/
def BaseB (h : FoldWilson.Cfg N → ℝ) : Prop :=
  Measurable h ∧ (∃ C, ∀ ω, |h ω| ≤ C) ∧ (∀ ω ω', (∀ ℓ, InCubeB N b ℓ → ω ℓ = ω' ℓ) → h ω = h ω')

theorem cast_sub_eq (A B : ℕ) (h : B ≤ A) : ((A : ZMod N) - (B : ZMod N)) = ((A - B : ℕ) : ZMod N) := by
  rw [Nat.cast_sub h]

/-- the k-th coordinate after the transport of one block coordinate and the shift -/
theorem coord_valueB (hn : n = 2 * m) (hM : M = b * m) (k : Fin 4) (a t : ZMod n) (ht : inH m a t)
    (x : Site N) (μ : Fin 4) (hx : (x k).val ≤ b) (hμ : μ = k → (x k).val < b) :
    let v := nv N k (par n t) (ι N n b hNb (cof n t)) (x, μ) + -(ι N n b hNb a)
    if μ = k then v.val < M else v.val ≤ M := by
  intro v
  unfold inH at ht
  have hm : 0 < m := by
    rcases Nat.eq_zero_or_pos m with h | h
    · exact absurd (show n = 0 by omega) (NeZero.ne n)
    · exact h
  have hNM : N = 2 * M := by rw [hNb, hn, hM]; ring
  have hb : 0 < b := by
    rcases Nat.eq_zero_or_pos b with h | h
    · exact absurd (by rw [hNb, h, zero_mul]) (NeZero.ne N)
    · exact h
  set s := t - a with hs_def
  have hsv : s.val < m := ht
  have hxk : x k = (((x k).val : ℕ) : ZMod N) := (ZMod.natCast_zmod_val (x k)).symm
  have hbm : b * s.val + b ≤ M := by
    rw [hM]; nlinarith
  have hMN : M < N := by
    rw [hNM]; have : 0 < M := by rw [hM]; exact Nat.mul_pos hb hm
    omega
  cases hp : par n t
  · -- translation: v = x_k + b s
    have hv : v = (((x k).val + b * s.val : ℕ) : ZMod N) := by
      simp only [v, nv, cof, hp, Bool.false_eq_true, if_false]
      rw [show t = s + a by rw [hs_def]; ring, map_add, ι_nat N n b hNb s]
      conv_lhs => rw [hxk]
      push_cast; ring
    have hlt : (x k).val + b * s.val < N := by omega
    rw [hv, ZMod.val_cast_of_lt hlt]
    split_ifs with h
    · have := hμ h; omega
    · omega
  · -- reflection: v = b (s + 1) − x_k − [μ = k]
    have hs1 : (s + 1).val = s.val + 1 := TorusRP.val_add_one n s (by omega)
    have hι1 : ι N n b hNb (s + 1) = ((b * (s.val + 1) : ℕ) : ZMod N) := by
      rw [ι_nat N n b hNb, hs1]
    by_cases h : μ = k
    · have hxb := hμ h
      have hv : v = ((b * (s.val + 1) - (x k).val - 1 : ℕ) : ZMod N) := by
        simp only [v, nv, cof, hp, if_true, h]
        rw [show t + 1 = (s + 1) + a by rw [hs_def]; ring, map_add, hι1]
        conv_lhs => rw [hxk]
        have h1 : (x k).val + 1 ≤ b * (s.val + 1) := by nlinarith
        rw [Nat.sub_sub, Nat.cast_sub h1]
        push_cast; ring
      have hlt : b * (s.val + 1) - (x k).val - 1 < N := by
        have : b * (s.val + 1) = b * s.val + b := by ring
        omega
      rw [hv, ZMod.val_cast_of_lt hlt, if_pos h]
      have : b * (s.val + 1) = b * s.val + b := by ring
      omega
    · have hv : v = ((b * (s.val + 1) - (x k).val : ℕ) : ZMod N) := by
        simp only [v, nv, cof, hp, if_true, h, if_false]
        rw [show t + 1 = (s + 1) + a by rw [hs_def]; ring, map_add, hι1]
        conv_lhs => rw [hxk]
        have h1 : (x k).val ≤ b * (s.val + 1) := by nlinarith
        rw [Nat.cast_sub h1]
        push_cast; ring
      have hlt : b * (s.val + 1) - (x k).val < N := by
        have : b * (s.val + 1) = b * s.val + b := by ring
        omega
      rw [hv, ZMod.val_cast_of_lt hlt, if_neg h]
      have : b * (s.val + 1) = b * s.val + b := by ring
      omega

/-- the link read by the transport -/
def LtB (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) : Lk N :=
  affL N 3 (par n t3) (ι N n b hNb (cof n t3)) (affL N 2 (par n t2) (ι N n b hNb (cof n t2))
    (affL N 1 (par n t1) (ι N n b hNb (cof n t1)) (affL N 0 (par n t0) (ι N n b hNb (cof n t0)) ℓ)))

theorem measurable_ΨB (t0 t1 t2 t3 : ZMod n) : Measurable (ΨB N n b hNb t0 t1 t2 t3) := by
  unfold ΨB ΦB
  exact (measurable_affC N 0 _ _).comp ((measurable_affC N 1 _ _).comp
    ((measurable_affC N 2 _ _).comp (measurable_affC N 3 _ _)))

theorem det_ΨB (t0 t1 t2 t3 : ZMod n) (ω ω' : FoldWilson.Cfg N) (ℓ : Lk N)
    (h : ω (LtB N n b hNb t0 t1 t2 t3 ℓ) = ω' (LtB N n b hNb t0 t1 t2 t3 ℓ)) :
    ΨB N n b hNb t0 t1 t2 t3 ω ℓ = ΨB N n b hNb t0 t1 t2 t3 ω' ℓ := by
  unfold ΨB ΦB
  apply det_affC; apply det_affC; apply det_affC; apply det_affC
  exact h

theorem LtB_snd (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) : (LtB N n b hNb t0 t1 t2 t3 ℓ).2 = ℓ.2 := rfl

theorem LtB_coord0 (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) :
    (LtB N n b hNb t0 t1 t2 t3 ℓ).1 0 = nv N 0 (par n t0) (ι N n b hNb (cof n t0)) ℓ := by
  simp only [LtB]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_neg (by decide),
    affL_coord, if_pos rfl]

theorem LtB_coord1 (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) :
    (LtB N n b hNb t0 t1 t2 t3 ℓ).1 1 = nv N 1 (par n t1) (ι N n b hNb (cof n t1)) ℓ := by
  simp only [LtB]
  rw [affL_coord, if_neg (by decide), affL_coord, if_neg (by decide), affL_coord, if_pos rfl,
    nv_affL N 0 1 (by decide)]

theorem LtB_coord2 (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) :
    (LtB N n b hNb t0 t1 t2 t3 ℓ).1 2 = nv N 2 (par n t2) (ι N n b hNb (cof n t2)) ℓ := by
  simp only [LtB]
  rw [affL_coord, if_neg (by decide), affL_coord, if_pos rfl, nv_affL N 1 2 (by decide),
    nv_affL N 0 2 (by decide)]

theorem LtB_coord3 (t0 t1 t2 t3 : ZMod n) (ℓ : Lk N) :
    (LtB N n b hNb t0 t1 t2 t3 ℓ).1 3 = nv N 3 (par n t3) (ι N n b hNb (cof n t3)) ℓ := by
  simp only [LtB]
  rw [affL_coord, if_pos rfl, nv_affL N 2 3 (by decide), nv_affL N 1 3 (by decide),
    nv_affL N 0 3 (by decide)]

/-- **Locality**: a transported block function with the k-th block coordinate in the plus half is in the class. -/
theorem loc_generalB (hn : n = 2 * m) (hM : M = b * m) (k : Fin 4) (a t : ZMod n) (Lf : Lk N → Lk N)
    (P : FoldWilson.Cfg N → FoldWilson.Cfg N)
    (hP : Measurable P) (hdet : ∀ ω ω' ℓ, ω (Lf ℓ) = ω' (Lf ℓ) → P ω ℓ = P ω' ℓ)
    (hsnd : ∀ ℓ, (Lf ℓ).2 = ℓ.2) (hcoord : ∀ ℓ, (Lf ℓ).1 k = nv N k (par n t) (ι N n b hNb (cof n t)) ℓ)
    (ht : inH m a t) (h : FoldWilson.Cfg N → ℝ) (hh : BaseB N b h) :
    GoodB N n b hNb M k a (fun ω => h (P ω)) := by
  obtain ⟨hm, ⟨C, hC⟩, hd⟩ := hh
  refine ⟨hm.comp hP, hm.comp (hP.comp (measurable_affC N k false _)), ⟨C, fun ω => hC _⟩,
    fun ω ω' hag => ?_⟩
  show h (P (S N k (ι N n b hNb a) ω)) = h (P (S N k (ι N n b hNb a) ω'))
  apply hd
  intro ℓ hℓ
  apply hdet
  apply det_affC
  apply hag
  apply half_of_val
  obtain ⟨x, μ⟩ := ℓ
  have e1 : (affL N k false (-(ι N n b hNb a)) (Lf (x, μ))).1 k =
      nv N k (par n t) (ι N n b hNb (cof n t)) (x, μ) + -(ι N n b hNb a) := by
    rw [affL_coord, if_pos rfl]
    show (Lf (x, μ)).1 k + -(ι N n b hNb a) = _
    rw [hcoord]
  rw [affL_snd, hsnd, e1]
  exact coord_valueB N n b hNb m M hn hM k a t ht x μ (hℓ.2 k) (fun h' => h' ▸ hℓ.1)

/-- **All the data of the chessboard estimate with blocks of side b.** -/
theorem dataB (hn : n = 2 * m) (hM : M = b * m) (β : ℝ) {I : Type*} (Hf : I → FoldWilson.Cfg N → ℝ)
    (hH : ∀ i, BaseB N b (Hf i)) :
    Data4 m (wilsonMeasure N β) Hf (ΨB N n b hNb) (RB N n b hNb) (GoodB N n b hNb M) := by
  have hNM : N = 2 * M := by rw [hNb, hn, hM]; ring
  exact {
  one := fun k a => good_one N M k _
  mul := fun k a => good_mul N M k _
  cs := fun k a f g hf hg => cs_R N M hNM k _ β f g hf hg
  rp := fun k a f hf => rp_R N M hNM k _ β f hf
  tr0 := trB0 N n b hNb m hn
  tr1 := trB1 N n b hNb m hn
  tr2 := trB2 N n b hNb m hn
  tr3 := trB3 N n b hNb m hn
  loc0 := fun a t0 t1 t2 t3 i ht => loc_generalB N n b hNb m M hn hM 0 a t0 (LtB N n b hNb t0 t1 t2 t3)
    (ΨB N n b hNb t0 t1 t2 t3) (measurable_ΨB N n b hNb t0 t1 t2 t3) (det_ΨB N n b hNb t0 t1 t2 t3)
    (LtB_snd N n b hNb t0 t1 t2 t3) (LtB_coord0 N n b hNb t0 t1 t2 t3) ht (Hf i) (hH i)
  loc1 := fun a t0 t1 t2 t3 i ht => loc_generalB N n b hNb m M hn hM 1 a t1 (LtB N n b hNb t0 t1 t2 t3)
    (ΨB N n b hNb t0 t1 t2 t3) (measurable_ΨB N n b hNb t0 t1 t2 t3) (det_ΨB N n b hNb t0 t1 t2 t3)
    (LtB_snd N n b hNb t0 t1 t2 t3) (LtB_coord1 N n b hNb t0 t1 t2 t3) ht (Hf i) (hH i)
  loc2 := fun a t0 t1 t2 t3 i ht => loc_generalB N n b hNb m M hn hM 2 a t2 (LtB N n b hNb t0 t1 t2 t3)
    (ΨB N n b hNb t0 t1 t2 t3) (measurable_ΨB N n b hNb t0 t1 t2 t3) (det_ΨB N n b hNb t0 t1 t2 t3)
    (LtB_snd N n b hNb t0 t1 t2 t3) (LtB_coord2 N n b hNb t0 t1 t2 t3) ht (Hf i) (hH i)
  loc3 := fun a t0 t1 t2 t3 i ht => loc_generalB N n b hNb m M hn hM 3 a t3 (LtB N n b hNb t0 t1 t2 t3)
    (ΨB N n b hNb t0 t1 t2 t3) (measurable_ΨB N n b hNb t0 t1 t2 t3) (det_ΨB N n b hNb t0 t1 t2 t3)
    (LtB_snd N n b hNb t0 t1 t2 t3) (LtB_coord3 N n b hNb t0 t1 t2 t3) ht (Hf i) (hH i) }

/-- **The chessboard estimate with blocks of side b** for the SU(2) Wilson measure, every β. -/
theorem wilson_chessboard_block (hn : n = 2 * m) (hM : M = b * m) (β : ℝ) {I : Type*}
    (Hf : I → FoldWilson.Cfg N → ℝ) (hH : ∀ i, BaseB N b (Hf i)) (F : ZMod n → ZMod n → ZMod n → ZMod n → I) :
    |V4 (wilsonMeasure N β) Hf (ΨB N n b hNb) F| ^ (n ^ 4) ≤
      ∏ t0, ∏ t1, ∏ t2, ∏ t3, V4 (wilsonMeasure N β) Hf (ΨB N n b hNb) (fun _ _ _ _ => F t0 t1 t2 t3) :=
  chess_data m _ hn Hf (ΨB N n b hNb) (RB N n b hNb) (GoodB N n b hNb M)
    (dataB N n b hNb m M hn hM β Hf hH) F

/-! ### the subset form -/

/-- the two block functions: g on the chosen blocks, 1 elsewhere -/
noncomputable def selF (g : FoldWilson.Cfg N → ℝ) : Bool → FoldWilson.Cfg N → ℝ :=
  fun i ω => if i then g ω else 1

/-- the weight of the uniform pattern: g transported to every block -/
noncomputable def patternWeight (β : ℝ) (g : FoldWilson.Cfg N → ℝ) : ℝ :=
  ∫ ω, ∏ q : Z4 n, g (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) ∂(wilsonMeasure N β)

theorem baseB_one : BaseB N b (fun _ => (1 : ℝ)) :=
  ⟨measurable_const, ⟨1, fun _ => by simp⟩, fun _ _ _ => rfl⟩

/-- **Subset form of the chessboard estimate with blocks of side b.**  If 0 ≤ g ≤ 1 is a block function and the
uniform pattern weight is at most Z·z^(n⁴), then for every set S of blocks
  ∫ ∏_{w ∈ S} g (ΨB w ω) dμ_W ≤ Z·z^|S|   (Z = total mass of the unnormalised Wilson measure). -/
theorem chess_subset (hn : n = 2 * m) (hM : M = b * m) (β : ℝ) (g : FoldWilson.Cfg N → ℝ)
    (hg : BaseB N b g) (z : ℝ) (hz : 0 ≤ z)
    (hpat : patternWeight N n b hNb β g ≤ (∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)) * z ^ (n ^ 4))
    (S : Finset (Z4 n)) :
    ∫ ω, ∏ q ∈ S, g (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) ∂(wilsonMeasure N β) ≤
      (∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)) * z ^ S.card := by
  set Z := ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) with hZ
  have hZ0 : 0 ≤ Z := integral_nonneg fun _ => zero_le_one
  have hH : ∀ i, BaseB N b (selF N g i) := by
    intro i; cases i
    · exact baseB_one N b
    · have e : selF N g true = g := by funext ω; simp [selF]
      rw [e]; exact hg
  set n4 := n ^ 4 with hn4
  have hn4pos : n4 ≠ 0 := pow_ne_zero _ (NeZero.ne n)
  set c0 := Z ^ ((1 : ℝ) / n4) with hc0
  have hc0n : c0 ^ n4 = Z := by
    rw [hc0, one_div, Real.rpow_inv_natCast_pow hZ0 hn4pos]
  have hc0pos : 0 ≤ c0 := Real.rpow_nonneg hZ0 _
  let c : Bool → ℝ := fun i => if i then c0 * z else c0
  have hc : ∀ i, 0 ≤ c i := by intro i; cases i <;> simp [c, hc0pos, mul_nonneg hc0pos hz]
  have hconst : ∀ i, V4 (wilsonMeasure N β) (selF N g) (ΨB N n b hNb) (fun _ _ _ _ => i) ≤ c i ^ n4 := by
    intro i; cases i
    · simp only [V4, selF, Bool.false_eq_true, if_false, prod_const_one, c, hc0n]; exact le_rfl
    · simp only [c, if_true, mul_pow, hc0n]
      refine le_trans (le_of_eq ?_) hpat
      simp only [V4, selF, if_true, patternWeight]
      congr 1; funext ω; rw [prod4]
  have hroot := chess_data_root m _ hn (selF N g) (ΨB N n b hNb) (RB N n b hNb) (GoodB N n b hNb M)
    (dataB N n b hNb m M hn hM β (selF N g) hH) c hc hconst
    (fun t0 t1 t2 t3 => decide ((t0, t1, t2, t3) ∈ S))
  have hL : V4 (wilsonMeasure N β) (selF N g) (ΨB N n b hNb) (fun t0 t1 t2 t3 => decide ((t0, t1, t2, t3) ∈ S)) =
      ∫ ω, ∏ q ∈ S, g (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) ∂(wilsonMeasure N β) := by
    simp only [V4]
    congr 1; funext ω
    rw [prod4]
    rw [← Finset.prod_filter_mul_prod_filter_not Finset.univ (fun q => q ∈ S)]
    have h1 : ∏ q ∈ Finset.univ.filter (fun q => q ∈ S),
        selF N g (decide ((q.1, q.2.1, q.2.2.1, q.2.2.2) ∈ S)) (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
        ∏ q ∈ S, g (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) := by
      rw [Finset.filter_mem_eq_inter, Finset.univ_inter]
      apply Finset.prod_congr rfl; intro q hq
      simp [selF, hq]
    have h2 : ∏ q ∈ Finset.univ.filter (fun q => q ∉ S),
        selF N g (decide ((q.1, q.2.1, q.2.2.1, q.2.2.2) ∈ S)) (ΨB N n b hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) = 1 := by
      apply Finset.prod_eq_one; intro q hq
      simp only [Finset.mem_filter] at hq
      simp [selF, hq.2]
    rw [h1, h2, mul_one]
  have hR : ∏ t0, ∏ t1, ∏ t2, ∏ t3, c (decide ((t0, t1, t2, t3) ∈ S)) = Z * z ^ S.card := by
    rw [prod4]
    have : ∀ q : Z4 n, c (decide ((q.1, q.2.1, q.2.2.1, q.2.2.2) ∈ S)) = c0 * (if q ∈ S then z else 1) := by
      intro q
      by_cases hq : q ∈ S
      · simp [c, hq]
      · simp [c, hq]
    simp only [this, Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ]
    rw [Finset.prod_ite_mem, Finset.univ_inter, Finset.prod_const]
    have hcard : Fintype.card (Z4 n) = n4 := by
      simp [Z4, Fintype.card_prod, ZMod.card, hn4]; ring
    rw [hcard, hc0n]
  rw [← hL, ← hR]
  exact le_trans (le_abs_self _) hroot

end PushChess

#print axioms PushChess.wilson_chessboard_block
#print axioms PushChess.chess_subset
