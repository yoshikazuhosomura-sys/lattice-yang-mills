import UVChain.BoxChainV1
/-!
Locality and translation covariance of the box block map (the family of paths with weights (1/8, 3/4, 1/8)).

* `walk_reach` : every link of every walk of the family has its base point within sup-distance 2 of the origin
  (a finite check over the 4·6·27 walks).
* `boxMap_local` : the coarse value on `b = (y, μ)` depends only on the fine links based in the cube of radius 2
  around the fine point `2y` (radius 2 in fine units, independent of the level and of the side).
* `boxMap_trans` : translating the fine field by `2t` and blocking equals blocking and translating the coarse
  field by `t`.

Paper correspondence: the locality (B3) and the translation part of the symmetry of the block map; used for the
reduction of the rarity of the pushed-forward measure to the fine-lattice chessboard estimate.
-/

namespace PushLocal

open WalkCast ChainBlockMap BoxWalk

local notation "ℍr" => Quaternion ℝ

theorem walk_reach : ∀ μ : Fin 4, ∀ o : Fin 6, ∀ A : Fin 3 → Fin 3,
    ∀ l ∈ walk μ o A, ∀ i, -2 ≤ l.2.1 i ∧ l.2.1 i ≤ 2 := by
  decide

theorem pathProd_congr {Lt : Type*} (U U' : Lt → ℍr) :
    ∀ γ : List (Lt × Bool), (∀ s ∈ γ, U s.1 = U' s.1) → pathProd U γ = pathProd U' γ := by
  intro γ
  induction γ with
  | nil => intro _; rfl
  | cons s rest ih =>
    intro h
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih fun s' hs' => h s' (List.mem_cons_of_mem _ hs')]
    congr 1
    unfold stepVal
    rw [h s List.mem_cons_self]

variable (L : ℕ) [NeZero L]

/-- The value of the block map on `b` depends only on the fine links in the cube of radius 2 around `2y`. -/
theorem boxMap_local {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U U' : Cfg (BoxLk L (m + 1)))
    (b : BoxLk L m)
    (h : ∀ z : Fin 4 → ℤ, (∀ i, -2 ≤ z i ∧ z i ≤ 2) → ∀ ν,
      U (base L m b + red L m z, ν) = U' (base L m b + red L m z, ν)) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
      (blockMap r₀ hr (boxPaths L) (boxW L) m U' b : ℍr) := by
  rw [boxMap_eq L hr, boxMap_eq L hr]
  refine congrArg (retract r₀) ?_
  unfold sixAvg
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  refine congrArg (sixWeight A • ·) ?_
  refine pathProd_congr _ _ _ fun s hs => ?_
  simp only [boxPathsIdx, pathsCast, List.mem_map] at hs
  obtain ⟨l, hl, rfl⟩ := hs
  simp only [linkCast, dirB]
  rw [h l.2.1 (walk_reach _ o A l hl) l.2.2]

theorem pathProd_shift {G : Type*} [AddCommGroup G] (φ : (Fin 4 → ℤ) →+ G) (U : G × Fin 4 → ℍr)
    (x₀ a : G) (γ : List Link) :
    pathProd (fun ℓ => U (ℓ.1 + a, ℓ.2)) (γ.map (linkCast φ x₀)) =
      pathProd U (γ.map (linkCast φ (x₀ + a))) := by
  induction γ with
  | nil => rfl
  | cons l rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih]
    congr 1
    simp only [stepVal, linkCast]
    rw [show x₀ + φ l.2.1 + a = x₀ + a + φ l.2.1 by abel]
    rfl

/-- Translation of configurations. -/
def transCfg {m : ℕ} (a : Site L m) (U : Cfg (BoxLk L m)) : Cfg (BoxLk L m) :=
  fun ℓ => U (ℓ.1 + a, ℓ.2)

/-- The box map commutes with translations (fine `2t` ↔ coarse `t`). -/
theorem boxMap_trans {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (t : Site L m) (U : Cfg (BoxLk L (m + 1))) :
    blockMap r₀ hr (boxPaths L) (boxW L) m (transCfg L (fun i => double L m (t i)) U) =
      transCfg L t (blockMap r₀ hr (boxPaths L) (boxW L) m U) := by
  funext b
  apply Subtype.ext
  show (blockMap r₀ hr (boxPaths L) (boxW L) m (transCfg L (fun i => double L m (t i)) U) b : ℍr)
    = (blockMap r₀ hr (boxPaths L) (boxW L) m U (b.1 + t, b.2) : ℍr)
  rw [boxMap_eq L hr, boxMap_eq L hr]
  refine congrArg (retract r₀) ?_
  unfold sixAvg
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  refine congrArg (sixWeight A • ·) ?_
  simp only [boxPathsIdx, pathsCast, dirB]
  have hb : base L m (b.1 + t, b.2) = base L m b + fun i => double L m (t i) := by
    funext i; simp [base, map_add]
  rw [hb]
  exact pathProd_shift (red L m) (fun ℓ => (U ℓ : ℍr)) (base L m b) _ _

end PushLocal

#print axioms PushLocal.boxMap_local
#print axioms PushLocal.boxMap_trans
