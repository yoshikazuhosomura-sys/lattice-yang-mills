import PushRare.ReduceAllKV1
/-!
Checks of the hypothesis of the k-step reduction theorem: the uniform pattern weight is at most Z (the hypothesis
holds with z = 1 for every k and β; with z = 1 the conclusion is the trivial bound ≤ Z), and it is nonnegative.
For k = 0 the k-fold block map is the identity (`downK_zero`).
-/

namespace PushReduceK

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy PushChess PushLocal Finset

variable (L : ℕ) [NeZero L]

theorem downK_zero {r₀ : ℝ} (hr : 0 < r₀) (ω : FoldWilson.Cfg (2 ^ (0 + 0) * L)) : BK L hr 0 ω = ω := rfl

theorem patternK_le_Z (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) {r₀ : ℝ} (hr : 0 < r₀)
    (β y : ℝ) (μ ν : Fin 4) :
    patternWeight (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb β (gRefK L hr k y μ ν) ≤
      Zw (2 ^ (0 + k) * L) β * 1 ^ (n ^ 4) := by
  rw [one_pow, mul_one]
  unfold patternWeight Zw
  have hg0 : ∀ ω, 0 ≤ gRefK L hr k y μ ν ω := fun ω => bigP_nonneg _ _ _ _
  have hg1 : ∀ ω, gRefK L hr k y μ ν ω ≤ 1 := fun ω => bigP_le_one _ _ _ _
  have hmeas : Measurable (fun ω : FoldWilson.Cfg (2 ^ (0 + k) * L) =>
      ∏ q : Z4 n, gRefK L hr k y μ ν (ΨB (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω)) :=
    Finset.measurable_prod _ (fun q _ => ((measurable_bigP _ y _).comp (measurable_BK L hr k)).comp
      (measurable_ΨB _ n _ hNb _ _ _ _))
  refine integral_mono (Integrable.of_bound hmeas.aestronglyMeasurable 1
    (Filter.Eventually.of_forall fun ω => ?_)) (integrable_const 1) (fun ω => ?_)
  · rw [Real.norm_eq_abs, abs_of_nonneg (prod_nonneg fun _ _ => hg0 _)]
    exact prod_le_one (fun _ _ => hg0 _) (fun _ _ => hg1 _)
  · exact prod_le_one (fun _ _ => hg0 _) (fun _ _ => hg1 _)

end PushReduceK

#print axioms PushReduceK.patternK_le_Z
