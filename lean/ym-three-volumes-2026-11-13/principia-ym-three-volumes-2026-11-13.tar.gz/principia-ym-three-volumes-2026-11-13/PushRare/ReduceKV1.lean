import PushRare.ReduceEvenV1
import PushRare.DownKV1
/-!
**k steps of the block map: the reference event is a block function, and the sublattice form of the reduction.**

Fine torus (ℤ/2^k L)⁴ with the SU(2) Wilson measure μ_W (unnormalised, total mass Z), coarse torus (ℤ/L)⁴,
BK := k steps of the block map (paths with weights (1/8, 3/4, 1/8), radial retraction of radius r₀), for every k.
Blocks of side 8·2^k (fine units) = 8 (coarse units), 2^k L = 8·2^k·n, n = 2m.  For a coarse plaquette p,
A_p := {1 − Re U_p(BK ω) > y}.
* `gRefK_base` : the indicator of A_p for p = ((2,2,2,2); μ, ν) is a bounded measurable function of the links of the
  fine cube [0, 8·2^k]⁴ (k-step locality, radius 2^(k+1) − 2: fine support in [2, 5·2^k − 2]⁴);
* `push_rarity_evenK` : if the uniform pattern weight of the reference event is at most Z·z^(n⁴), then for every set S
  of blocks with even coordinates, ∫ ∏_{w ∈ S} 1_{A_{p(w)}}(BK ω) dμ_W ≤ Z·z^|S|, p(w) = ((2,2,2,2) + 8w; μ, ν).

Paper correspondence: the rarity of the k-fold pushed-forward measure, reduced to the fine-lattice chessboard.
-/

namespace PushReduceK

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy PushChess PushLocal Finset

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

theorem continuous_downK {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) :
    ∀ k, Continuous (downK L hr m k)
  | 0 => continuous_id
  | k + 1 => (continuous_downK hr m k).comp
      (ChainBlockMap.continuous_blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (m + k))

/-- k steps of the block map, from (ℤ/2^k L)⁴ to (ℤ/L)⁴ -/
noncomputable def BK {r₀ : ℝ} (hr : 0 < r₀) (k : ℕ) (ω : FoldWilson.Cfg (2 ^ (0 + k) * L)) :
    FoldWilson.Cfg (2 ^ 0 * L) :=
  downK L hr 0 k ω

theorem measurable_BK {r₀ : ℝ} (hr : 0 < r₀) (k : ℕ) : Measurable (BK L hr k) :=
  (continuous_downK L hr 0 k).measurable

/-- the reference coarse site (2, 2, 2, 2) -/
def yref2 : TorusRP.Site (2 ^ 0 * L) := fun _ => 2

/-- the reference event: the coarse plaquette ((2,2,2,2); μ, ν) of BK ω is large -/
noncomputable def gRefK {r₀ : ℝ} (hr : 0 < r₀) (k : ℕ) (y : ℝ) (μ ν : Fin 4)
    (ω : FoldWilson.Cfg (2 ^ (0 + k) * L)) : ℝ :=
  bigP (2 ^ 0 * L) y (BK L hr k ω) ((yref2 L, μ), ν)

theorem scale_intCast (m : ℕ) : ∀ (k : ℕ) (w : ℤ),
    scale L m k ((w : ℤ) : ZMod (2 ^ m * L)) = (((2 ^ k * w : ℤ)) : ZMod (2 ^ (m + k) * L))
  | 0, w => by simp [scale]
  | k + 1, w => by
    show BoxWalk.double L (m + k) (scale L m k ((w : ℤ) : ZMod (2 ^ m * L))) = _
    rw [scale_intCast m k w, BoxWalk.double_intCast]
    push_cast; ring

theorem val_le {K : ℕ} [NeZero K] (w B : ℤ) (h0 : 0 ≤ w) (hB : w ≤ B) (hK : B < K) :
    (((w : ZMod K)).val : ℤ) ≤ B := by
  have h := ZMod.val_intCast (n := K) w
  rw [Int.emod_eq_of_lt h0 (by omega)] at h
  omega

theorem inCubeK (k : ℕ) (hL : 8 ≤ L) (c : TorusRP.Site (2 ^ 0 * L))
    (hc : ∀ i, ∃ j : ℤ, 2 ≤ j ∧ j ≤ 3 ∧ c i = (j : ZMod (2 ^ 0 * L))) (z : Fin 4 → ℤ)
    (hz : ∀ i, -((2 : ℤ) ^ (k + 1) - 2) ≤ z i ∧ z i ≤ (2 : ℤ) ^ (k + 1) - 2) (ν' : Fin 4) :
    InCubeB (2 ^ (0 + k) * L) (8 * 2 ^ k)
      ((fun i => scale L 0 k (c i) + ((z i : ℤ) : ZMod (2 ^ (0 + k) * L))), ν') := by
  have hpk : (1 : ℤ) ≤ 2 ^ k := one_le_pow₀ (by norm_num)
  have hK : (5 * 2 ^ k - 2 : ℤ) < ((2 ^ (0 + k) * L : ℕ) : ℤ) := by
    push_cast
    rw [zero_add]
    have : (8 : ℤ) ≤ L := by exact_mod_cast hL
    nlinarith
  have hcoord : ∀ j, (((scale L 0 k (c j) + ((z j : ℤ) : ZMod (2 ^ (0 + k) * L))).val : ℕ) : ℤ) ≤ 5 * 2 ^ k - 2 := by
    intro j
    obtain ⟨w, hw2, hw3, hw⟩ := hc j
    rw [hw, scale_intCast]
    have e : ((((2 ^ k * w : ℤ)) : ZMod (2 ^ (0 + k) * L)) + ((z j : ℤ) : ZMod (2 ^ (0 + k) * L))) =
        (((2 ^ k * w + z j : ℤ)) : ZMod (2 ^ (0 + k) * L)) := by push_cast; ring
    rw [e]
    have hzj := hz j
    have hp1 : (2 : ℤ) ^ (k + 1) = 2 * 2 ^ k := by ring
    rw [hp1] at hzj
    exact val_le _ _ (by nlinarith [hzj.1]) (by nlinarith [hzj.2]) hK
  refine ⟨?_, fun j => ?_⟩
  · have := hcoord ν'
    have h8 : (5 * 2 ^ k - 2 : ℤ) < ((8 * 2 ^ k : ℕ) : ℤ) := by push_cast; nlinarith
    exact_mod_cast lt_of_le_of_lt this h8
  · have := hcoord j
    have h8 : (5 * 2 ^ k - 2 : ℤ) ≤ ((8 * 2 ^ k : ℕ) : ℤ) := by push_cast; nlinarith
    exact_mod_cast le_trans this h8

theorem yref2_ok : ∀ i, ∃ j : ℤ, 2 ≤ j ∧ j ≤ 3 ∧ yref2 L i = (j : ZMod (2 ^ 0 * L)) :=
  fun _ => ⟨2, le_rfl, by norm_num, by simp [yref2]⟩

theorem yref2_ev_ok (d : Fin 4) :
    ∀ i, ∃ j : ℤ, 2 ≤ j ∧ j ≤ 3 ∧
      (yref2 L + TorusRP.ev (2 ^ 0 * L) d : TorusRP.Site (2 ^ 0 * L)) i = (j : ZMod (2 ^ 0 * L)) := by
  intro i
  by_cases h : i = d
  · refine ⟨3, by norm_num, le_rfl, ?_⟩
    subst h; simp only [Pi.add_apply, yref2, TorusRP.ev, Pi.single_eq_same]; push_cast; ring
  · refine ⟨2, le_rfl, by norm_num, ?_⟩
    simp only [Pi.add_apply, yref2, TorusRP.ev, Pi.single_eq_of_ne h]; push_cast; ring

/-- **The reference event of k steps is a block function of the cube [0, 8·2^k]⁴** (L ≥ 8). -/
theorem gRefK_base (k : ℕ) (hL : 8 ≤ L) {r₀ : ℝ} (hr : 0 < r₀) (y : ℝ) (μ ν : Fin 4) :
    BaseB (2 ^ (0 + k) * L) (8 * 2 ^ k) (gRefK L hr k y μ ν) := by
  refine ⟨(measurable_bigP (2 ^ 0 * L) y _).comp (measurable_BK L hr k), ⟨1, fun ω => ?_⟩,
    fun ω ω' hag => ?_⟩
  · simp only [gRefK]; rw [abs_of_nonneg (bigP_nonneg _ _ _ _)]; exact bigP_le_one _ _ _ _
  · have hlink : ∀ c : TorusRP.Site (2 ^ 0 * L), (∀ i, ∃ j : ℤ, 2 ≤ j ∧ j ≤ 3 ∧ c i = (j : ZMod (2 ^ 0 * L))) →
        ∀ μ', Uq (2 ^ 0 * L) (BK L hr k ω) (c, μ') = Uq (2 ^ 0 * L) (BK L hr k ω') (c, μ') := by
      intro c hc μ'
      have := downK_local L hr 0 k ω ω' (c, μ') (fun z hz ν' => hag _ (inCubeK L k hL c hc z hz ν'))
      simp only [Uq, BK]; rw [this]
    have hhol : hol (2 ^ 0 * L) (BK L hr k ω) ((yref2 L, μ), ν) =
        hol (2 ^ 0 * L) (BK L hr k ω') ((yref2 L, μ), ν) := by
      simp only [hol, holQ]
      rw [hlink _ (yref2_ok L) μ, hlink _ (yref2_ev_ok L μ) ν, hlink _ (yref2_ev_ok L ν) μ,
        hlink _ (yref2_ok L) ν]
    simp only [gRefK, bigP, hhol]

/-- the coarse offset of the block w (even coordinates): 8 w -/
def cvecK (n : ℕ) (q : Z4 n) : TorusRP.Site (2 ^ 0 * L) :=
  fun j => ((8 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ZMod (2 ^ 0 * L))

theorem scale_cvecK (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) (q : Z4 n) (j : Fin 4) :
    scale L 0 k (cvecK L n q j) = ι (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb (![q.1, q.2.1, q.2.2.1, q.2.2.2] j) := by
  rw [ι_nat, cvecK]
  have e : (((8 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ZMod (2 ^ 0 * L))) =
      ((((8 * (![q.1, q.2.1, q.2.2.1, q.2.2.2] j).val : ℕ) : ℤ)) : ZMod (2 ^ 0 * L)) := by
    rw [Int.cast_natCast]
  rw [e, scale_intCast]
  push_cast; ring

theorem ΨB_evenK (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) (q : Z4 n)
    (h0 : par n q.1 = false) (h1 : par n q.2.1 = false) (h2 : par n q.2.2.1 = false)
    (h3 : par n q.2.2.2 = false) (ω : FoldWilson.Cfg (2 ^ (0 + k) * L)) :
    ΨB (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω =
      shV (2 ^ (0 + k) * L) (fun j => scale L 0 k (cvecK L n q j)) ω := by
  simp only [ΨB, ΦB, cof, h0, h1, h2, h3, Bool.false_eq_true, if_false, affC_false_eq]
  funext ℓ
  simp only [shV]
  congr 2
  funext j
  simp only [Pi.add_apply]
  rw [scale_cvecK L k n hNb q j]
  fin_cases j <;> simp [Pi.single_apply]

theorem gRefK_even (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) {r₀ : ℝ} (hr : 0 < r₀)
    (y : ℝ) (μ ν : Fin 4) (q : Z4 n)
    (h0 : par n q.1 = false) (h1 : par n q.2.1 = false) (h2 : par n q.2.2.1 = false)
    (h3 : par n q.2.2.2 = false) (ω : FoldWilson.Cfg (2 ^ (0 + k) * L)) :
    gRefK L hr k y μ ν (ΨB (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb q.1 q.2.1 q.2.2.1 q.2.2.2 ω) =
      bigP (2 ^ 0 * L) y (BK L hr k ω) ((yref2 L + cvecK L n q, μ), ν) := by
  rw [ΨB_evenK L k n hNb q h0 h1 h2 h3]
  have e : BK L hr k (shV (2 ^ (0 + k) * L) (fun j => scale L 0 k (cvecK L n q j)) ω) =
      shV (2 ^ 0 * L) (cvecK L n q) (BK L hr k ω) :=
    downK_trans L hr 0 k (cvecK L n q) ω
  simp only [gRefK, e, bigP, hol_shV]

theorem eight_le (k n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) : 8 ≤ L := by
  have hn0 : n ≠ 0 := NeZero.ne n
  have hp : 0 < 2 ^ k := pow_pos (by norm_num) k
  rw [zero_add] at hNb
  have : L = 8 * n := by
    have h2 : 2 ^ k * L = 2 ^ k * (8 * n) := by rw [hNb]; ring
    exact Nat.eq_of_mul_eq_mul_left hp h2
  omega

/-- **Sublattice form of the reduction, k steps of the block map, every k.**  If the uniform pattern weight of the
reference event is at most Z·z^(n⁴), then for every set S of blocks with even coordinates
  ∫ ∏_{w ∈ S} 1[1 − Re U_{((2,2,2,2)+8w; μ,ν)}(BK ω) > y] dμ_W(ω) ≤ Z·z^|S|,
μ_W the unnormalised SU(2) Wilson measure on the fine torus (ℤ/2^k L)⁴, L = 8n, n = 2m, Z its total mass. -/
theorem push_rarity_evenK (k n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β y : ℝ) (μ ν : Fin 4) (z : ℝ) (hz : 0 ≤ z)
    (hpat : patternWeight (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb β (gRefK L hr k y μ ν) ≤
      Zw (2 ^ (0 + k) * L) β * z ^ (n ^ 4))
    (S : Finset (Z4 n))
    (hS : ∀ q ∈ S, par n q.1 = false ∧ par n q.2.1 = false ∧ par n q.2.2.1 = false ∧ par n q.2.2.2 = false) :
    ∫ ω, ∏ q ∈ S, bigP (2 ^ 0 * L) y (BK L hr k ω) ((yref2 L + cvecK L n q, μ), ν)
        ∂(wilsonMeasure (2 ^ (0 + k) * L) β) ≤ Zw (2 ^ (0 + k) * L) β * z ^ S.card := by
  have hL := eight_le L k n m hn hNb
  have h := chess_subset (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb m ((8 * 2 ^ k) * m) hn rfl β (gRefK L hr k y μ ν)
    (gRefK_base L k hL hr y μ ν) z hz hpat S
  refine le_trans (le_of_eq (integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_))) h
  refine prod_congr rfl fun q hq => ?_
  obtain ⟨h0, h1, h2, h3⟩ := hS q hq
  rw [gRefK_even L k n hNb hr y μ ν q h0 h1 h2 h3]

end PushReduceK

#print axioms PushReduceK.gRefK_base
#print axioms PushReduceK.push_rarity_evenK
