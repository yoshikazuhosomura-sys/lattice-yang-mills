import PushRare.ReachV1
/-!
**k steps of the block map: locality with radius 2^(k+1) − 2 and translation covariance.**

`downK m k` : Cfg (level m + k) → Cfg (level m), the composition of k block maps (finest step first).
`scale m k` : ZMod (2^m L) → ZMod (2^(m+k) L), y ↦ 2^k y (the composition of the doublings).
* `downK_local` : the value of `downK m k U` on the coarse link b = (y, μ) depends only on the fine links (x, ν) with
  x = 2^k y + z, |z_i| ≤ 2^(k+1) − 2 (the radius R_k satisfies R_0 = 0, R_(k+1) = 2 R_k + 2);
* `downK_trans` : translating the fine field by 2^k a and applying `downK` equals applying `downK` and translating by a.

Paper correspondence: the locality (B3) and translation covariance of the k-fold block map, the two inputs of the
reduction of the k-step rarity to the fine-lattice chessboard (blocks of side 2^(k+3)).
-/

namespace PushLocal

open WalkCast ChainBlockMap BoxWalk

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L]

/-- y ↦ 2^k y from level m to level m + k -/
def scale (m : ℕ) : ∀ k : ℕ, ZMod (2 ^ m * L) →+ ZMod (2 ^ (m + k) * L)
  | 0 => AddMonoidHom.id _
  | k + 1 => (double L (m + k)).comp (scale m k)

variable {r₀ : ℝ} (hr : 0 < r₀)

/-- k steps of the block map, from level m + k to level m -/
noncomputable def downK (m : ℕ) : ∀ k : ℕ, Cfg (BoxLk L (m + k)) → Cfg (BoxLk L m)
  | 0 => fun U => U
  | k + 1 => fun U => downK m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k) U)

/-- **Locality of k steps of the block map** (radius 2^(k+1) − 2 in fine units around 2^k y). -/
theorem downK_local (m : ℕ) : ∀ (k : ℕ) (U U' : Cfg (BoxLk L (m + k))) (b : BoxLk L m),
    (∀ z : Fin 4 → ℤ, (∀ i, -((2 : ℤ) ^ (k + 1) - 2) ≤ z i ∧ z i ≤ (2 : ℤ) ^ (k + 1) - 2) → ∀ ν,
      U ((fun i => scale L m k (b.1 i) + ((z i : ℤ) : ZMod (2 ^ (m + k) * L))), ν) =
        U' ((fun i => scale L m k (b.1 i) + ((z i : ℤ) : ZMod (2 ^ (m + k) * L))), ν)) →
    downK L hr m k U b = downK L hr m k U' b
  | 0, U, U', b, h => by
    have h0 := h 0 (fun i => by norm_num) b.2
    have e : (fun i => scale L m 0 (b.1 i) + (((0 : Fin 4 → ℤ) i : ℤ) : ZMod (2 ^ (m + 0) * L))) = b.1 := by
      funext i; simp [scale]
    rw [e] at h0
    exact h0
  | k + 1, U, U', b, h => by
    show downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k) U) b =
      downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k) U') b
    apply downK_local m k
    intro z hz ν
    apply Subtype.ext
    apply boxMap_local L hr (m + k) U U'
    intro z' hz' ν'
    have key : base L (m + k) ((fun i => scale L m k (b.1 i) + ((z i : ℤ) : ZMod (2 ^ (m + k) * L))), ν) +
        red L (m + k) z' =
        fun i => scale L m (k + 1) (b.1 i) + (((2 * z i + z' i : ℤ)) : ZMod (2 ^ (m + (k + 1)) * L)) := by
      funext i
      simp only [Pi.add_apply, base, red, map_add, double_intCast, scale, AddMonoidHom.comp_apply,
        AddMonoidHom.compLeft_apply, Function.comp_apply, Int.coe_castAddHom]
      push_cast; ring
    rw [key]
    apply h
    intro i
    have hp : (2 : ℤ) ^ (k + 1 + 1) = 2 * 2 ^ (k + 1) := by ring
    rw [hp]
    have h1 := hz i; have h2 := hz' i
    constructor <;> linarith [h1.1, h1.2, h2.1, h2.2]

/-- **Translation covariance of k steps of the block map.** -/
theorem downK_trans (m : ℕ) : ∀ (k : ℕ) (a : Site L m) (U : Cfg (BoxLk L (m + k))),
    downK L hr m k (transCfg L (fun i => scale L m k (a i)) U) = transCfg L a (downK L hr m k U)
  | 0, a, U => by
    show transCfg L (fun i => scale L m 0 (a i)) U = transCfg L a U
    rfl
  | k + 1, a, U => by
    show downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k)
        (transCfg L (fun i => scale L m (k + 1) (a i)) U)) = _
    have e : (fun i => scale L m (k + 1) (a i)) = fun i => double L (m + k) ((fun j => scale L m k (a j)) i) := rfl
    rw [e, boxMap_trans L hr (m + k) (fun j => scale L m k (a j)) U, downK_trans m k a]
    rfl

end PushLocal

#print axioms PushLocal.downK_local
#print axioms PushLocal.downK_trans
