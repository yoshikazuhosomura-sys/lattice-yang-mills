import PushRare.DownKV1
/-!
**The k-fold block map composed finest-first equals the coarse field of the chain.**

`ChainBlockMap.down n m` (the coarse field at level m of the induction started at level n, composed coarsest-first
through `downAux`) and `downK m k` (composed finest-first) agree: `down (m + k) m = downK m k`.  Hence the
pushed-forward measures of the chain, `ChainBlockMap.νP … μ (m + k) m = (μ (m + k)).map (down (m + k) m)`, are the
images under `downK`, and the reduction theorem of `PushRare.ReduceAllKV1` is a statement about them (m = 0).

Paper correspondence: the definition of ν_{n,m} (the raw form) and the k-fold block map of the reduction.
-/

namespace PushLocal

open ChainBlockMap BoxWalk

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- transport of a configuration along an equality of levels -/
def lc {j j' : ℕ} (h : j = j') (V : Cfg (BoxLk L j)) : Cfg (BoxLk L j') :=
  cast (congrArg (fun i => Cfg (BoxLk L i)) h) V

theorem blockMap_lc {j j' : ℕ} (h : j = j') (V : Cfg (BoxLk L (j + 1))) :
    blockMap r₀ hr (boxPaths L) (boxW L) j' (lc L (congrArg (· + 1) h) V) =
      lc L h (blockMap r₀ hr (boxPaths L) (boxW L) j V) := by
  subst h; rfl

theorem lc_lc {j j' j'' : ℕ} (h : j = j') (h' : j' = j'') (V : Cfg (BoxLk L j)) :
    lc L h' (lc L h V) = lc L (h.trans h') V := by
  subst h; subst h'; rfl

/-- one coarse step after k fine steps equals k steps after one fine step -/
theorem comm_step : ∀ (k m : ℕ) (V : Cfg (BoxLk L ((m + 1) + k))),
    blockMap r₀ hr (boxPaths L) (boxW L) m (downK L hr (m + 1) k V) =
      downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k) (lc L (by omega : (m + 1) + k = (m + k) + 1) V))
  | 0, m, V => rfl
  | k + 1, m, V => by
    show blockMap r₀ hr (boxPaths L) (boxW L) m
        (downK L hr (m + 1) k (blockMap r₀ hr (boxPaths L) (boxW L) ((m + 1) + k) V)) = _
    rw [comm_step k m]
    show downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k) (lc L _ (blockMap r₀ hr (boxPaths L) (boxW L)
        ((m + 1) + k) V))) =
      downK L hr m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + k)
        (blockMap r₀ hr (boxPaths L) (boxW L) (m + (k + 1)) (lc L _ V)))
    congr 2
    exact (blockMap_lc L hr (by omega : (m + 1) + k = m + (k + 1)) V).symm

theorem downAux_eq : ∀ (k m n : ℕ) (h : m + k = n) (U : Cfg (BoxLk L n)),
    downAux r₀ hr (boxPaths L) (boxW L) n k m h U = downK L hr m k (lc L h.symm U)
  | 0, m, n, h, U => rfl
  | k + 1, m, n, h, U => by
    show blockMap r₀ hr (boxPaths L) (boxW L) m (downAux r₀ hr (boxPaths L) (boxW L) n k (m + 1) (by omega) U) = _
    rw [downAux_eq k (m + 1) n (by omega) U, comm_step L hr k m, lc_lc]
    rfl

/-- **`down (m + k) m = downK m k`** -/
theorem down_eq_downK (k m : ℕ) (U : Cfg (BoxLk L (m + k))) :
    down r₀ hr (boxPaths L) (boxW L) (m + k) m U = downK L hr m k U := by
  have hle : m ≤ m + k := Nat.le_add_right m k
  simp only [down, dif_pos hle]
  rw [downAux_congr r₀ hr (boxPaths L) (boxW L) (m + k) (show m + k - m = k by omega) _ rfl U,
    downAux_eq L hr k m (m + k) rfl U]
  rfl

/-- the pushed-forward measures of the chain are the images under `downK` -/
theorem νP_eq_map (μ : ∀ n, MeasureTheory.ProbabilityMeasure (Cfg (BoxLk L n))) (k m : ℕ) :
    ((νP r₀ hr (boxPaths L) (boxW L) μ (m + k) m : MeasureTheory.ProbabilityMeasure (Cfg (BoxLk L m))) :
      MeasureTheory.Measure (Cfg (BoxLk L m))) = (μ (m + k) : MeasureTheory.Measure _).map (downK L hr m k) := by
  simp only [νP, MeasureTheory.ProbabilityMeasure.toMeasure_map]
  congr 1
  funext U
  exact down_eq_downK L hr k m U

end PushLocal

#print axioms PushLocal.down_eq_downK
#print axioms PushLocal.νP_eq_map
