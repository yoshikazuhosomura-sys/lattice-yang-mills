import PushRare.ReduceKV1
/-!
**The reduction theorem for k steps of the block map, every k: every set X of coarse plaquettes.**

Fine torus (ℤ/2^k L)⁴ with the SU(2) Wilson measure μ_W (unnormalised, total mass Z), coarse torus (ℤ/L)⁴,
BK = k steps of the block map (paths with weights (1/8, 3/4, 1/8), radial retraction of radius r₀),
A_p = {1 − Re U_p(BK ω) > y}.  If, for each of the six orientations μ < ν, the uniform pattern weight of the
reference event (the chessboard pattern with blocks of side 8·2^k, `patternWeight`) is at most Z·z^(n⁴) with
0 ≤ z ≤ 1, then for every finite set X of coarse plaquettes
  ∫ ∏_{p ∈ X} 1_{A_p}(BK ω) dμ_W(ω) ≤ Z·z^⌊|X| / 393216⌋,     393216 = 6·16⁴,
for all k and all L with L = 8n, n = 2m.  The number c = 6·16⁴ does not depend on k, L, β.  Proof as for one step:
classes (orientation × base point mod 16), a class with at least ⌊|X|/c⌋ plaquettes, dropping the other factors,
a translation of the fine field by 2^k a (invariance of μ_W, translation covariance of the k-fold block map),
the sublattice form `push_rarity_evenK`.

Paper correspondence: the rarity of the k-fold pushed-forward measure in the raw form (no effective action, no
reflection positivity of the pushed-forward measure; only the fine-lattice chessboard).
-/

namespace PushReduceK

open MeasureTheory TorusRP FoldAffine FoldChess FoldWilson FoldPeierls FoldEntropy PushChess PushLocal PushReduce Finset

variable (L : ℕ) [NeZero L]

theorem val_mod16 {K : ℕ} [NeZero K] (h8 : 16 ∣ K) (x : ZMod K) : ((ZMod.castHom h8 (ZMod 16)) x).val = x.val % 16 := by
  rw [ZMod.castHom_apply, ZMod.cast_eq_val, ZMod.val_natCast]

theorem castHom_eq16 {K : ℕ} [NeZero K] (h8 : 16 ∣ K) (x : ZMod K) :
    (ZMod.castHom h8 (ZMod 16)) x = (((x.val % 16 : ℕ)) : ZMod 16) := by
  apply ZMod.val_injective
  rw [val_mod16 h8, ZMod.val_natCast, Nat.mod_mod_of_dvd _ (dvd_refl 16)]

/-- the class of a coarse plaquette: base point mod 8 and orientation -/
def clsK (p : Lk (2 ^ 0 * L) × Fin 4) : (Fin 4 → Fin 16) × (Fin 4 × Fin 4) :=
  (fun j => ⟨(p.1.1 j).val % 16, Nat.mod_lt _ (by norm_num)⟩, (p.1.2, p.2))

/-- the coarse shift of a class -/
def shiftOfK (r : Fin 4 → Fin 16) : TorusRP.Site (2 ^ 0 * L) := fun j => (((r j : ℕ) + 14 : ℕ) : ZMod (2 ^ 0 * L))

theorem sub_mod16 (h8 : 16 ∣ 2 ^ 0 * L) (r : Fin 4 → Fin 16) (x : TorusRP.Site (2 ^ 0 * L))
    (hx : ∀ j, (x j).val % 16 = r j) (j : Fin 4) : (x j - shiftOfK L r j).val % 16 = 2 := by
  rw [← val_mod16 h8, map_sub, castHom_eq16 h8 (x j), hx j, shiftOfK, map_natCast]
  push_cast
  generalize ((r j : ℕ) : ZMod 16) = w
  revert w; decide

/-- the block coordinate of a coarse coordinate -/
def tcK (n : ℕ) (u : ZMod (2 ^ 0 * L)) : ZMod n := ((u.val / 8 : ℕ) : ZMod n)

/-- the block of a plaquette of the class r -/
def tmapK (n : ℕ) (r : Fin 4 → Fin 16) (p : Lk (2 ^ 0 * L) × Fin 4) : Z4 n :=
  (tcK L n (p.1.1 0 - shiftOfK L r 0), tcK L n (p.1.1 1 - shiftOfK L r 1), tcK L n (p.1.1 2 - shiftOfK L r 2),
    tcK L n (p.1.1 3 - shiftOfK L r 3))

theorem vec_tmapK (n : ℕ) (r : Fin 4 → Fin 16) (p : Lk (2 ^ 0 * L) × Fin 4) (j : Fin 4) :
    (![(tmapK L n r p).1, (tmapK L n r p).2.1, (tmapK L n r p).2.2.1, (tmapK L n r p).2.2.2] j) =
      tcK L n (p.1.1 j - shiftOfK L r j) := by
  fin_cases j <;> rfl

theorem L_eqK (k n : ℕ) (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) : 2 ^ 0 * L = 8 * n := by
  have hp : 0 < 2 ^ k := pow_pos (by norm_num) k
  rw [zero_add] at hNb
  have h2 : 2 ^ k * L = 2 ^ k * (8 * n) := by rw [hNb]; ring
  rw [pow_zero, one_mul]
  exact Nat.eq_of_mul_eq_mul_left hp h2

theorem tcK_val (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) (u : ZMod (2 ^ 0 * L)) :
    (tcK L n u).val = u.val / 8 := by
  unfold tcK
  apply ZMod.val_cast_of_lt
  have h1 : u.val < 8 * n := lt_of_lt_of_eq (ZMod.val_lt u) (L_eqK L k n hNb)
  omega

theorem tcK_par (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) (u : ZMod (2 ^ 0 * L))
    (hu : u.val % 16 = 2) : par n (tcK L n u) = false := by
  unfold par
  rw [tcK_val L k n hNb]
  have e : u.val / 8 = 2 * (u.val / 16) := by omega
  rw [e]
  have h2 : (((2 * (u.val / 16) : ℕ)) : ZMod 2) = 0 := by
    push_cast
    rw [show (2 : ZMod 2) = 0 from rfl, zero_mul]
  rw [h2]; decide

theorem reconK (k n : ℕ) [NeZero n] (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n) (h8 : 16 ∣ 2 ^ 0 * L)
    (r : Fin 4 → Fin 16) (p : Lk (2 ^ 0 * L) × Fin 4) (hx : ∀ j, (p.1.1 j).val % 16 = r j) :
    yref2 L + cvecK L n (tmapK L n r p) + shiftOfK L r = p.1.1 := by
  funext j
  simp only [Pi.add_apply, yref2, cvecK]
  rw [vec_tmapK L n r p j, tcK_val L k n hNb]
  have hu := sub_mod16 L h8 r p.1.1 hx j
  set u := (p.1.1 j - shiftOfK L r j).val with hudef
  have e1 : (2 : ZMod (2 ^ 0 * L)) + ((8 * (u / 8) : ℕ) : ZMod (2 ^ 0 * L)) = ((u : ℕ) : ZMod (2 ^ 0 * L)) := by
    have : 8 * (u / 8) + 2 = u := by omega
    have e2 : ((u : ℕ) : ZMod (2 ^ 0 * L)) = ((8 * (u / 8) + 2 : ℕ) : ZMod (2 ^ 0 * L)) := congrArg _ this.symm
    rw [e2]; push_cast; ring
  rw [e1, hudef, ZMod.natCast_zmod_val, sub_add_cancel]

/-- **The reduction theorem for k steps of the block map, every k** (every finite set X of coarse plaquettes;
the class count 393216 = 6·16⁴ does not depend on k, L, β). -/
theorem push_rarity_allK (k n m : ℕ) [NeZero n] (hn : n = 2 * m) (hNb : 2 ^ (0 + k) * L = (8 * 2 ^ k) * n)
    {r₀ : ℝ} (hr : 0 < r₀) (β y : ℝ) (z : ℝ) (hz0 : 0 ≤ z) (hz1 : z ≤ 1)
    (hpat : ∀ μ ν : Fin 4, μ < ν → patternWeight (2 ^ (0 + k) * L) n (8 * 2 ^ k) hNb β (gRefK L hr k y μ ν) ≤
      Zw (2 ^ (0 + k) * L) β * z ^ (n ^ 4))
    (X : Finset (Lk (2 ^ 0 * L) × Fin 4)) (hX : X ⊆ plaqs (2 ^ 0 * L)) :
    ∫ ω, ∏ p ∈ X, bigP (2 ^ 0 * L) y (BK L hr k ω) p ∂(wilsonMeasure (2 ^ (0 + k) * L) β) ≤
      Zw (2 ^ (0 + k) * L) β * z ^ (X.card / 393216) := by
  have h8 : 16 ∣ 2 ^ 0 * L := by
    rw [L_eqK L k n hNb, hn]; exact ⟨m, by ring⟩
  obtain ⟨T, hTdef⟩ : ∃ T : Finset ((Fin 4 → Fin 16) × (Fin 4 × Fin 4)),
      T = univ ×ˢ univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2) := ⟨_, rfl⟩
  have hT : T.card = 393216 := by
    have h6 : (univ.filter (fun o : Fin 4 × Fin 4 => o.1 < o.2)).card = 6 := by decide
    rw [hTdef]
    simp only [card_product, card_univ, h6, Fintype.card_fun, Fintype.card_fin]
    norm_num
  have hmaps : ∀ p ∈ X, clsK L p ∈ T := by
    intro p hp
    have := hX hp
    simp only [plaqs, mem_filter, mem_univ, true_and] at this
    rw [hTdef]
    simp only [clsK, mem_product, mem_univ, mem_filter, true_and]; exact this
  have hTne : T.Nonempty := ⟨(fun _ => 0, (0, 1)), by rw [hTdef]; simp⟩
  obtain ⟨c, hcT, hc⟩ := Finset.exists_le_card_fiber_of_mul_le_card_of_maps_to hmaps hTne
    (show T.card * (X.card / 393216) ≤ X.card by
      rw [hT]; have := Nat.div_mul_le_self X.card 393216; linarith)
  set Xc := X.filter (fun p => clsK L p = c) with hXc
  obtain ⟨r, μ, ν⟩ := c
  have hμν : μ < ν := by
    rw [hTdef] at hcT; simp only [mem_product, mem_univ, mem_filter, true_and] at hcT; exact hcT
  have hbd : ∀ (s : Finset (Lk (2 ^ 0 * L) × Fin 4)),
      Integrable (fun ω => ∏ p ∈ s, bigP (2 ^ 0 * L) y (BK L hr k ω) p) (wilsonMeasure (2 ^ (0 + k) * L) β) := by
    intro s
    refine Integrable.of_bound (Finset.measurable_prod s
      (fun p _ => (measurable_bigP _ y p).comp (measurable_BK L hr k))).aestronglyMeasurable 1
      (Filter.Eventually.of_forall fun ω => ?_)
    rw [Real.norm_eq_abs, abs_of_nonneg (prod_nonneg fun p _ => bigP_nonneg _ y _ p)]
    exact prod_le_one (fun p _ => bigP_nonneg _ y _ p) (fun p _ => bigP_le_one _ y _ p)
  -- monotonicity
  have hmono : ∫ ω, ∏ p ∈ X, bigP (2 ^ 0 * L) y (BK L hr k ω) p ∂(wilsonMeasure (2 ^ (0 + k) * L) β) ≤
      ∫ ω, ∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p ∂(wilsonMeasure (2 ^ (0 + k) * L) β) := by
    refine integral_mono (hbd X) (hbd Xc) (fun ω => ?_)
    show ∏ p ∈ X, bigP (2 ^ 0 * L) y (BK L hr k ω) p ≤ ∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p
    rw [← prod_filter_mul_prod_filter_not X (fun p => clsK L p = (r, μ, ν))]
    have h1 : ∏ p ∈ X.filter (fun p => ¬ clsK L p = (r, μ, ν)), bigP (2 ^ 0 * L) y (BK L hr k ω) p ≤ 1 :=
      prod_le_one (fun p _ => bigP_nonneg _ y _ p) (fun p _ => bigP_le_one _ y _ p)
    have h0 : 0 ≤ ∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p := prod_nonneg fun p _ => bigP_nonneg _ y _ p
    calc (∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p) *
          ∏ p ∈ X.filter (fun p => ¬ clsK L p = (r, μ, ν)), bigP (2 ^ 0 * L) y (BK L hr k ω) p
        ≤ (∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p) * 1 := mul_le_mul_of_nonneg_left h1 h0
      _ = _ := mul_one _
  -- the members of the class
  have hmem : ∀ p ∈ Xc, p = ((p.1.1, μ), ν) ∧ ∀ j, (p.1.1 j).val % 16 = r j := by
    intro p hp
    simp only [hXc, mem_filter, clsK, Prod.mk.injEq] at hp
    obtain ⟨_, hπ, hμ, hν⟩ := hp
    refine ⟨?_, fun j => ?_⟩
    · rw [← hμ, ← hν]
    · have := congrFun hπ j
      exact congrArg Fin.val this
  set S : Finset (Z4 n) := Xc.image (tmapK L n r) with hSdef
  have hinj : Set.InjOn (tmapK L n r) Xc := by
    intro p hp p' hp' h
    have e1 := reconK L k n hNb h8 r p (hmem p hp).2
    have e2 := reconK L k n hNb h8 r p' (hmem p' hp').2
    have h' : tmapK L n r p = tmapK L n r p' := h
    rw [h'] at e1
    rw [(hmem p hp).1, (hmem p' hp').1, ← e1, ← e2]
  have hS : ∀ q ∈ S, par n q.1 = false ∧ par n q.2.1 = false ∧ par n q.2.2.1 = false ∧ par n q.2.2.2 = false := by
    intro q hq
    obtain ⟨p, hp, rfl⟩ := mem_image.mp hq
    have hu := sub_mod16 L h8 r p.1.1 (hmem p hp).2
    exact ⟨tcK_par L k n hNb _ (hu 0), tcK_par L k n hNb _ (hu 1), tcK_par L k n hNb _ (hu 2), tcK_par L k n hNb _ (hu 3)⟩
  -- the translation
  set v : TorusRP.Site (2 ^ (0 + k) * L) := fun i => scale L 0 k (shiftOfK L r i) with hv
  have hshift : ∫ ω, ∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p ∂(wilsonMeasure (2 ^ (0 + k) * L) β) =
      ∫ ω, ∏ q ∈ S, bigP (2 ^ 0 * L) y (BK L hr k ω) ((yref2 L + cvecK L n q, μ), ν)
        ∂(wilsonMeasure (2 ^ (0 + k) * L) β) := by
    have hm : Measurable (fun ω : FoldWilson.Cfg (2 ^ (0 + k) * L) =>
        ∏ q ∈ S, bigP (2 ^ 0 * L) y (BK L hr k ω) ((yref2 L + cvecK L n q, μ), ν)) :=
      Finset.measurable_prod S (fun q _ => (measurable_bigP _ y _).comp (measurable_BK L hr k))
    rw [← wilson_shV_invariant (2 ^ (0 + k) * L) v β _ hm]
    refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
    have e : BK L hr k (shV (2 ^ (0 + k) * L) v ω) = shV (2 ^ 0 * L) (shiftOfK L r) (BK L hr k ω) :=
      downK_trans L hr 0 k (shiftOfK L r) ω
    show ∏ p ∈ Xc, bigP (2 ^ 0 * L) y (BK L hr k ω) p =
      ∏ q ∈ S, bigP (2 ^ 0 * L) y (BK L hr k (shV (2 ^ (0 + k) * L) v ω)) ((yref2 L + cvecK L n q, μ), ν)
    rw [e, hSdef, prod_image hinj]
    refine prod_congr rfl fun p hp => ?_
    rw [congrArg (bigP (2 ^ 0 * L) y (BK L hr k ω)) (hmem p hp).1]
    simp only [bigP, hol_shV, reconK L k n hNb h8 r p (hmem p hp).2]
  have hcard : X.card / 393216 ≤ S.card := by
    rw [hSdef, card_image_of_injOn hinj]; exact hc
  have hrs := push_rarity_evenK L k n m hn hNb hr β y μ ν z hz0 (hpat μ ν hμν) S hS
  calc ∫ ω, ∏ p ∈ X, bigP (2 ^ 0 * L) y (BK L hr k ω) p ∂(wilsonMeasure (2 ^ (0 + k) * L) β)
      ≤ _ := hmono
    _ = _ := hshift
    _ ≤ Zw (2 ^ (0 + k) * L) β * z ^ S.card := hrs
    _ ≤ Zw (2 ^ (0 + k) * L) β * z ^ (X.card / 393216) :=
        mul_le_mul_of_nonneg_left (pow_le_pow_of_le_one hz0 hz1 hcard) (Zw_nonneg _ β)

end PushReduceK

#print axioms PushReduceK.push_rarity_allK
