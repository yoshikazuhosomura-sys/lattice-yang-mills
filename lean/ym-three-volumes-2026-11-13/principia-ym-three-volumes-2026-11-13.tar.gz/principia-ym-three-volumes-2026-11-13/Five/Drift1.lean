import Mathlib

/-! # T5: the constraint drifts `hR3p`, `hR3m` of `thmR_form` from a lift and a block-constant comparison weight


`thmR_form` (an earlier file 536) needs
`hR3p : ∀ y, T (W⁻¹ y) = 0 → ∃ s, T s = 0 ∧ N(y − s) ≤ δ₊ N(y)` and
`hR3m : ∀ y, T (W⁻¹ y) = 0 → ∃ v, T (W v) = 0 ∧ N(v − y) ≤ δ₋ N(y)` (`N = lamNorm B r`).
Here, for any right inverse (lift) `E` of `T` (`T E = 1`) and any comparison weight `W_b` that is constant on the
blocks (`T W_b = D T` for some `D`, the property that gave `δ± = 0` for block-constant `W` earlier):
* `R3p_of_lift`: `s = y − E T y` works with `δ₊` any bound of `N(E T (W − W_b) z) ≤ δ₊ N(W z)` on `ker T`;
* `R3m_of_lift`: `v = y − W⁻¹ E T W y` works with `δ₋` any bound of `N(W⁻¹ E T (W² − W_b²) z) ≤ δ₋ N(W z)` on
  `ker T` (`N` even);
* `R3_block_const`: when `W = W_b` both bounds hold with `δ± = 0` (the earlier observation, now a corollary).
So the drifts only see the deviation `W − W_b` of the smooth weight from its block-constant comparison
(pointwise `|W − W_b| ≤ W_b (e^{η·osc ρ} − 1)` on a block), not `W − 1`; what is left for T5d is the norm of
`E T (W − W_b)` in `N` (a multiplication operator by a function of size `e^{ηs} − 1` and gradient `≲ η`,
composed with the lift), which is not done here. -/

namespace Drift

variable {R E Z : Type*} [CommRing R] [AddCommGroup E] [Module R E] [AddCommGroup Z] [Module R Z]

/-- **`hR3p` from a lift.** -/
theorem R3p_of_lift (T : E →ₗ[R] Z) (Ef : Z →ₗ[R] E) (hE : ∀ z, T (Ef z) = z)
    (W Winv Wb : E →ₗ[R] E) (D : Z →ₗ[R] Z) (hWW : ∀ y, W (Winv y) = y)
    (hcomm : ∀ y, T (Wb y) = D (T y)) (N : E → ℝ) {δ : ℝ}
    (hδ : ∀ z, T z = 0 → N (Ef (T ((W - Wb) z))) ≤ δ * N (W z)) :
    ∀ y, T (Winv y) = 0 → ∃ s, T s = 0 ∧ N (y - s) ≤ δ * N y := by
  intro y hy
  refine ⟨y - Ef (T y), by rw [map_sub, hE, sub_self], ?_⟩
  have e1 : y - (y - Ef (T y)) = Ef (T y) := by abel
  have e2 : T y = T ((W - Wb) (Winv y)) := by
    rw [LinearMap.sub_apply, map_sub, hcomm, hy, map_zero, sub_zero, hWW]
  rw [e1, e2]
  have h := hδ (Winv y) hy
  rwa [hWW] at h

/-- **`hR3m` from a lift** (`N` even). -/
theorem R3m_of_lift (T : E →ₗ[R] Z) (Ef : Z →ₗ[R] E) (hE : ∀ z, T (Ef z) = z)
    (W Winv Wb : E →ₗ[R] E) (D : Z →ₗ[R] Z) (hWW : ∀ y, W (Winv y) = y)
    (hcomm : ∀ y, T (Wb y) = D (T y)) (N : E → ℝ) (hN : ∀ a, N (-a) = N a) {δ : ℝ}
    (hδ : ∀ z, T z = 0 → N (Winv (Ef (T ((W ∘ₗ W - Wb ∘ₗ Wb) z)))) ≤ δ * N (W z)) :
    ∀ y, T (Winv y) = 0 → ∃ v, T (W v) = 0 ∧ N (v - y) ≤ δ * N y := by
  intro y hy
  refine ⟨y - Winv (Ef (T (W y))), ?_, ?_⟩
  · rw [map_sub, hWW, map_sub, hE, sub_self]
  · have e1 : y - Winv (Ef (T (W y))) - y = -Winv (Ef (T (W y))) := by abel
    have e2 : T (W y) = T ((W ∘ₗ W - Wb ∘ₗ Wb) (Winv y)) := by
      rw [LinearMap.sub_apply, map_sub, LinearMap.comp_apply, LinearMap.comp_apply, hcomm, hcomm, hy,
        map_zero, map_zero, sub_zero, hWW]
    rw [e1, hN, e2]
    have h := hδ (Winv y) hy
    rwa [hWW] at h

/-- **Block-constant weight**: `W = W_b` gives `δ₊ = δ₋ = 0` (needs only `N 0 = 0`). -/
theorem R3_block_const (T : E →ₗ[R] Z) (Ef : Z →ₗ[R] E) (hE : ∀ z, T (Ef z) = z)
    (W Winv : E →ₗ[R] E) (D : Z →ₗ[R] Z) (hWW : ∀ y, W (Winv y) = y)
    (hcomm : ∀ y, T (W y) = D (T y)) (N : E → ℝ) (hN : ∀ a, N (-a) = N a) (hN0 : N 0 = 0) :
    (∀ y, T (Winv y) = 0 → ∃ s, T s = 0 ∧ N (y - s) ≤ 0 * N y) ∧
    (∀ y, T (Winv y) = 0 → ∃ v, T (W v) = 0 ∧ N (v - y) ≤ 0 * N y) := by
  constructor
  · refine R3p_of_lift T Ef hE W Winv W D hWW hcomm N (fun z _ => ?_)
    simp [hN0]
  · refine R3m_of_lift T Ef hE W Winv W D hWW hcomm N hN (fun z _ => ?_)
    simp [hN0]

end Drift

#print axioms Drift.R3p_of_lift
#print axioms Drift.R3m_of_lift
#print axioms Drift.R3_block_const
