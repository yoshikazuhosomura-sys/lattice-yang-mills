import Mathlib

/-!
# Positive definiteness of `e^{β⟨V,W⟩}` for `β ≥ 0` — the middle-plane step of (RP1) 

Paper correspondence: (link-midpoint reflection plane, gauge
invariant functions, `β ≥ 0`).  For unit quaternions `Re(V W*) = ⟨V, W⟩_{ℝ⁴}` (`re_mul_star`), so the
weights of the plaquettes crossing the midpoint plane (after fixing the crossing links to `1` by a
gauge transformation, which needs gauge invariance of the observable) form the kernel
`exp(β Σ_j φ_j(V) φ_j(W))` with `φ` the `4|I|` real coordinates.  This file proves, for any finite
measure `ρ`, bounded measurable `f` and bounded measurable coordinates `φ`:
`0 ≤ ∫∫ f(x) f(y) exp(β Σ_j φ_j(x) φ_j(y)) dρ(x) dρ(y)` (`kernel_exp_nonneg`), by the power series
`Σ_k β^k/k! ⟨·,·⟩^k`, each power being a sum of squares (`kernel_pow_nonneg`) and dominated
convergence.  The factorisation of the rest of the Wilson weight and the gauge fixing are on paper.
-/

namespace KernelPD

open MeasureTheory Finset Filter Topology

theorem re_mul_star (V W : Quaternion ℝ) :
    (V * star W).re = V.re * W.re + V.imI * W.imI + V.imJ * W.imJ + V.imK * W.imK := by
  simp only [Quaternion.re_mul, Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star,
    Quaternion.imK_star]
  ring

variable {X : Type*} [MeasurableSpace X] (ρ : Measure X) [IsFiniteMeasure ρ]

theorem integrable_of_abs_le {Z : Type*} [MeasurableSpace Z] (ν : Measure Z) [IsFiniteMeasure ν]
    {g : Z → ℝ} (hg : Measurable g) (C : ℝ) (hC : ∀ x, |g x| ≤ C) : Integrable g ν :=
  Integrable.of_bound hg.aestronglyMeasurable C
    (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hC x)

variable {d : ℕ} (φ : X → Fin d → ℝ) (f : X → ℝ)

/-- the monomial functions `x ↦ f x * ∏ i, φ x (s i)` -/
noncomputable def mono {k : ℕ} (s : Fin k → Fin d) (x : X) : ℝ := f x * ∏ i, φ x (s i)

theorem measurable_mono (hφ : ∀ j, Measurable fun x => φ x j) (hf : Measurable f) {k : ℕ}
    (s : Fin k → Fin d) : Measurable (mono φ f s) :=
  hf.mul (Finset.measurable_prod _ fun i _ => hφ (s i))

theorem abs_mono_le (Cφ Cf : ℝ) (hφb : ∀ x j, |φ x j| ≤ Cφ) (hfb : ∀ x, |f x| ≤ Cf)
    {k : ℕ} (s : Fin k → Fin d) (x : X) : |mono φ f s x| ≤ Cf * Cφ ^ k := by
  unfold mono
  rw [abs_mul, Finset.abs_prod]
  have h1 : ∏ i, |φ x (s i)| ≤ ∏ _i : Fin k, Cφ :=
    Finset.prod_le_prod (fun i _ => abs_nonneg _) (fun i _ => hφb x (s i))
  rw [Fin.prod_const] at h1
  exact mul_le_mul (hfb x) h1 (Finset.prod_nonneg fun i _ => abs_nonneg _)
    ((abs_nonneg _).trans (hfb x))

theorem pow_expand (k : ℕ) (x y : X) :
    f x * f y * (∑ j, φ x j * φ y j) ^ k
      = ∑ s ∈ Fintype.piFinset (fun _ : Fin k => (univ : Finset (Fin d))),
          mono φ f s x * mono φ f s y := by
  rw [Finset.sum_pow', Finset.mul_sum]
  refine Finset.sum_congr rfl fun s _ => ?_
  unfold mono
  rw [Finset.prod_mul_distrib]
  ring

variable (hφ : ∀ j, Measurable fun x => φ x j) (hf : Measurable f) (Cφ Cf : ℝ)
  (hφb : ∀ x j, |φ x j| ≤ Cφ) (hfb : ∀ x, |f x| ≤ Cf)
include hφ hf hφb hfb

theorem integrable_term (k : ℕ) :
    Integrable (fun p : X × X => f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k) (ρ.prod ρ) := by
  have e : (fun p : X × X => f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k) =
      fun p => ∑ s ∈ Fintype.piFinset (fun _ : Fin k => (univ : Finset (Fin d))),
        mono φ f s p.1 * mono φ f s p.2 := funext fun p => pow_expand φ f k p.1 p.2
  rw [e]
  refine integrable_finset_sum _ (fun s _ => ?_)
  have hi : Integrable (mono φ f s) ρ :=
    integrable_of_abs_le ρ (measurable_mono φ f hφ hf s) _ (abs_mono_le φ f Cφ Cf hφb hfb s)
  exact hi.mul_prod hi

/-- each power `⟨·,·⟩^k` of the kernel is positive definite (a sum of squares) -/
theorem kernel_pow_nonneg (k : ℕ) :
    0 ≤ ∫ p : X × X, f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k ∂(ρ.prod ρ) := by
  have e : (fun p : X × X => f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k) =
      fun p => ∑ s ∈ Fintype.piFinset (fun _ : Fin k => (univ : Finset (Fin d))),
        mono φ f s p.1 * mono φ f s p.2 := funext fun p => pow_expand φ f k p.1 p.2
  rw [e]
  have hi : ∀ s : Fin k → Fin d, Integrable (mono φ f s) ρ := fun s =>
    integrable_of_abs_le ρ (measurable_mono φ f hφ hf s) _ (abs_mono_le φ f Cφ Cf hφb hfb s)
  rw [integral_finset_sum _ (fun s _ => (hi s).mul_prod (hi s))]
  refine Finset.sum_nonneg fun s _ => ?_
  rw [integral_prod_mul]
  exact mul_self_nonneg _

theorem abs_inner_le (x y : X) : |∑ j, φ x j * φ y j| ≤ (d : ℝ) * Cφ ^ 2 := by
  calc |∑ j, φ x j * φ y j| ≤ ∑ j, |φ x j * φ y j| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _j : Fin d, Cφ ^ 2 := Finset.sum_le_sum fun j _ => by
        rw [abs_mul, sq]
        exact mul_le_mul (hφb x j) (hφb y j) (abs_nonneg _) ((abs_nonneg _).trans (hφb x j))
    _ = (d : ℝ) * Cφ ^ 2 := by simp

/-- **The kernel `exp(β Σ_j φ_j(x) φ_j(y))` is positive definite for `β ≥ 0`.** -/
theorem kernel_exp_nonneg (β : ℝ) (hβ : 0 ≤ β) :
    0 ≤ ∫ p : X × X, f p.1 * f p.2 * Real.exp (β * ∑ j, φ p.1 j * φ p.2 j) ∂(ρ.prod ρ) := by
  have hCf : ∀ x : X, 0 ≤ Cf := fun x => (abs_nonneg _).trans (hfb x)
  have ht_meas : Measurable (fun p : X × X => ∑ j, φ p.1 j * φ p.2 j) :=
    Finset.measurable_sum _ fun j _ =>
      ((hφ j).comp measurable_fst).mul ((hφ j).comp measurable_snd)
  have hff : Measurable (fun p : X × X => f p.1 * f p.2) :=
    (hf.comp measurable_fst).mul (hf.comp measurable_snd)
  let P : ℕ → X × X → ℝ := fun n p => ∑ k ∈ range n,
    β ^ k / (Nat.factorial k : ℝ) * (f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k)
  have hPnn : ∀ n, 0 ≤ ∫ p, P n p ∂(ρ.prod ρ) := fun n => by
    show 0 ≤ ∫ p, ∑ k ∈ range n,
      β ^ k / (Nat.factorial k : ℝ) * (f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k) ∂(ρ.prod ρ)
    rw [integral_finset_sum _ (fun k _ =>
      (integrable_term ρ φ f hφ hf Cφ Cf hφb hfb k).const_mul _)]
    refine Finset.sum_nonneg fun k _ => ?_
    rw [integral_const_mul]
    exact mul_nonneg (div_nonneg (pow_nonneg hβ k) (Nat.cast_nonneg _))
      (kernel_pow_nonneg ρ φ f hφ hf Cφ Cf hφb hfb k)
  have hlim : Tendsto (fun n => ∫ p, P n p ∂(ρ.prod ρ)) atTop
      (𝓝 (∫ p : X × X, f p.1 * f p.2 * Real.exp (β * ∑ j, φ p.1 j * φ p.2 j) ∂(ρ.prod ρ))) := by
    refine tendsto_integral_of_dominated_convergence
      (fun _ => Cf * Cf * Real.exp (β * ((d : ℝ) * Cφ ^ 2))) (fun n => ?_)
      (integrable_const _) (fun n => Eventually.of_forall fun p => ?_)
      (Eventually.of_forall fun p => ?_)
    · exact (Finset.measurable_sum _ fun k _ =>
        measurable_const.mul (hff.mul (ht_meas.pow_const k))).aestronglyMeasurable
    · rw [Real.norm_eq_abs]
      have hT := abs_inner_le φ f hφ hf Cφ Cf hφb hfb p.1 p.2
      have h0T : 0 ≤ β * ((d : ℝ) * Cφ ^ 2) :=
        mul_nonneg hβ ((abs_nonneg _).trans hT)
      calc |P n p| ≤ ∑ k ∈ range n,
            |β ^ k / (Nat.factorial k : ℝ) * (f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k)| :=
            Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ k ∈ range n, Cf * Cf * ((β * ((d : ℝ) * Cφ ^ 2)) ^ k / (Nat.factorial k : ℝ)) :=
            Finset.sum_le_sum fun k _ => by
              rw [abs_mul, abs_mul, abs_mul, abs_pow, abs_div, abs_pow, abs_of_nonneg hβ,
                Nat.abs_cast]
              have hk : 0 < (Nat.factorial k : ℝ) := by exact_mod_cast Nat.factorial_pos k
              have h1 : |f p.1| * |f p.2| ≤ Cf * Cf :=
                mul_le_mul (hfb p.1) (hfb p.2) (abs_nonneg _) (hCf p.1)
              have h2 : |∑ j, φ p.1 j * φ p.2 j| ^ k ≤ ((d : ℝ) * Cφ ^ 2) ^ k :=
                pow_le_pow_left₀ (abs_nonneg _) hT k
              have h3 : 0 ≤ β ^ k / (Nat.factorial k : ℝ) := div_nonneg (pow_nonneg hβ k) hk.le
              calc β ^ k / (Nat.factorial k : ℝ) * (|f p.1| * |f p.2| * |∑ j, φ p.1 j * φ p.2 j| ^ k)
                  ≤ β ^ k / (Nat.factorial k : ℝ) * (Cf * Cf * ((d : ℝ) * Cφ ^ 2) ^ k) :=
                    mul_le_mul_of_nonneg_left
                      (mul_le_mul h1 h2 (pow_nonneg (abs_nonneg _) k)
                        (mul_nonneg (hCf p.1) (hCf p.1))) h3
                _ = Cf * Cf * ((β * ((d : ℝ) * Cφ ^ 2)) ^ k / (Nat.factorial k : ℝ)) := by
                    rw [mul_pow]; ring
        _ = Cf * Cf * ∑ k ∈ range n, (β * ((d : ℝ) * Cφ ^ 2)) ^ k / (Nat.factorial k : ℝ) :=
            (Finset.mul_sum _ _ _).symm
        _ ≤ Cf * Cf * Real.exp (β * ((d : ℝ) * Cφ ^ 2)) :=
            mul_le_mul_of_nonneg_left (Real.sum_le_exp_of_nonneg h0T n)
              (mul_nonneg (hCf p.1) (hCf p.1))
    · have hs := NormedSpace.expSeries_div_hasSum_exp (β * ∑ j, φ p.1 j * φ p.2 j)
      rw [← Real.exp_eq_exp_ℝ] at hs
      have ht := hs.tendsto_sum_nat.const_mul (f p.1 * f p.2)
      refine ht.congr (fun n => ?_)
      show f p.1 * f p.2 * ∑ k ∈ range n, (β * ∑ j, φ p.1 j * φ p.2 j) ^ k / (Nat.factorial k : ℝ) = P n p
      show _ = ∑ k ∈ range n,
        β ^ k / (Nat.factorial k : ℝ) * (f p.1 * f p.2 * (∑ j, φ p.1 j * φ p.2 j) ^ k)
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun k _ => ?_
      rw [mul_pow]
      ring
  exact ge_of_tendsto' hlim hPnn

end KernelPD

#print axioms KernelPD.re_mul_star
#print axioms KernelPD.kernel_pow_nonneg
#print axioms KernelPD.kernel_exp_nonneg
