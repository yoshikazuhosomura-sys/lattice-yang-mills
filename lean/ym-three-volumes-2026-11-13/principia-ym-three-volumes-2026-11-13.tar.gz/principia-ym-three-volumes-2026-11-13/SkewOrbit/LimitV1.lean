import Mathlib

/-!
# Limit of finite orbits for a skew product with a marginal direction

The pull-back form (all directions contract) is replaced by a skew product
`Φ k (u, v) = (u - b k + r k u v, T k u v)`: the coordinate `u` (marginal, e.g. inverse coupling)
need not contract; only the irrelevant coordinate `v` contracts, with cross couplings `c`, `c'`.

* `two_point_bound` (a): the finite two-point boundary problem
  `x 0 = 0`, `y n ≤ D`, `(1-ε) x k ≤ x (k-1) + c y k`, `y (k-1) ≤ c' x k + τ y k`
  gives `y k ≤ D θ^(n-k)` and `x k ≤ c D θ^(n-k) / (1-ε-θ)` provided `q < 1`.
* `midpoint_admissible` (b): with `θ = (1-ε+τ)/2`, the condition `4cc' < (1-ε-τ)^2`
  gives the hypotheses of (a).
* `orbit_compare`, `coarse_step`, `coarse_cauchy`, `coarse_tendsto`, `coarse_rate`,
  `limit_independent`, `observable_tendsto` (c): orbits from scale `n` to `0` with the
  marginal coordinate matched at the coarse end; the coarse irrelevant coordinate is Cauchy
  (`≤ D θ^n`), converges if `X` is complete, and the limit does not depend on the bare values.
-/

open Filter Topology

namespace SkewOrbit

/-! ## (a) the finite two-point boundary lemma -/

theorem two_point_bound (n : ℕ) (x y : ℕ → ℝ) (ε c c' τ D θ : ℝ)
    (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
    (hτθ : τ < θ) (hθ : θ < 1 - ε)
    (hy0 : ∀ k, 0 ≤ y k)
    (hx0 : x 0 = 0) (hyn : y n ≤ D)
    (hxs : ∀ k, 1 ≤ k → k ≤ n → (1 - ε) * x k ≤ x (k - 1) + c * y k)
    (hys : ∀ k, 1 ≤ k → k ≤ n → y (k - 1) ≤ c' * x k + τ * y k)
    (hq : (c * c' / (1 - ε - θ) + τ) / θ < 1) :
    ∀ k ≤ n, y k ≤ D * θ ^ (n - k) ∧ x k ≤ c * D * θ ^ (n - k) / (1 - ε - θ) := by
  have hθ0 : 0 < θ := lt_of_le_of_lt hτ hτθ
  have hd : 0 < 1 - ε - θ := by linarith
  have h1ε : 0 < 1 - ε := by linarith
  -- M = max_{k ≤ n} y k / θ^(n-k)
  obtain ⟨M, hM0, hyM, k₀, hk₀, hk₀M⟩ : ∃ M : ℝ, 0 ≤ M ∧ (∀ k ≤ n, y k ≤ M * θ ^ (n - k)) ∧
      ∃ k₀ ≤ n, y k₀ = M * θ ^ (n - k₀) := by
    let f : ℕ → ℝ := fun k => y k / θ ^ (n - k)
    have hne : (Finset.range (n + 1)).Nonempty := ⟨0, by simp⟩
    refine ⟨(Finset.range (n + 1)).sup' hne f, ?_, ?_, ?_⟩
    · have h : f 0 ≤ _ := Finset.le_sup' f (Finset.mem_range.mpr (Nat.succ_pos n))
      exact le_trans (div_nonneg (hy0 0) (pow_pos hθ0 _).le) h
    · intro k hk
      have h : f k ≤ _ := Finset.le_sup' f (Finset.mem_range.mpr (show k < n + 1 by omega))
      exact (div_le_iff₀ (pow_pos hθ0 _)).mp h
    · obtain ⟨k₀, hk₀, h⟩ := Finset.exists_mem_eq_sup' hne f
      refine ⟨k₀, by simpa [Nat.lt_succ_iff] using hk₀, ?_⟩
      rw [h]
      show y k₀ = y k₀ / θ ^ (n - k₀) * θ ^ (n - k₀)
      exact (div_mul_cancel₀ (y k₀) (pow_ne_zero _ hθ0.ne')).symm
  -- x k ≤ c M θ^(n-k) / (1-ε-θ), by induction from the coarse end
  have hxM : ∀ k ≤ n, x k ≤ c * M * θ ^ (n - k) / (1 - ε - θ) := by
    intro k
    induction k with
    | zero => intro _; rw [hx0]; positivity
    | succ k ih =>
      intro hk
      have h1 := hxs (k + 1) (by omega) hk
      simp only [Nat.add_sub_cancel] at h1
      have h2 := ih (by omega)
      have h3 := hyM (k + 1) hk
      have hpow : θ ^ (n - k) = θ * θ ^ (n - (k + 1)) := by
        rw [← pow_succ']; congr 1; omega
      rw [hpow] at h2
      have key : (1 - ε) * x (k + 1) ≤ (1 - ε) * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) := by
        calc (1 - ε) * x (k + 1) ≤ x k + c * y (k + 1) := h1
          _ ≤ c * M * (θ * θ ^ (n - (k + 1))) / (1 - ε - θ) + c * (M * θ ^ (n - (k + 1))) :=
              add_le_add h2 (mul_le_mul_of_nonneg_left h3 hc)
          _ = (1 - ε) * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) := by
              field_simp
              ring
      exact le_of_mul_le_mul_left key h1ε
  -- for k < n, y k ≤ q M θ^(n-k)
  set q := (c * c' / (1 - ε - θ) + τ) / θ with hqdef
  have hyq : ∀ k < n, y k ≤ q * M * θ ^ (n - k) := by
    intro k hk
    have h1 := hys (k + 1) (by omega) hk
    simp only [Nat.add_sub_cancel] at h1
    have h2 := hxM (k + 1) hk
    have h3 := hyM (k + 1) hk
    have hpow : θ ^ (n - k) = θ * θ ^ (n - (k + 1)) := by
      rw [← pow_succ']; congr 1; omega
    rw [hpow]
    calc y k ≤ c' * x (k + 1) + τ * y (k + 1) := h1
      _ ≤ c' * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) + τ * (M * θ ^ (n - (k + 1))) :=
          add_le_add (mul_le_mul_of_nonneg_left h2 hc') (mul_le_mul_of_nonneg_left h3 hτ)
      _ = q * M * (θ * θ ^ (n - (k + 1))) := by
          rw [hqdef]
          field_simp
  -- M ≤ D
  have hMD : M ≤ D := by
    rcases Nat.lt_or_ge k₀ n with hlt | hge
    · have h := hyq k₀ hlt
      rw [hk₀M] at h
      have hp : 0 < θ ^ (n - k₀) := pow_pos hθ0 _
      have hMq : M ≤ q * M := le_of_mul_le_mul_right (by linarith) hp
      by_contra hcon
      have hMpos : 0 < M := by linarith
      have : q * M < 1 * M := mul_lt_mul_of_pos_right hq hMpos
      linarith
    · have hk : k₀ = n := le_antisymm hk₀ hge
      subst hk
      simp only [Nat.sub_self, pow_zero, mul_one] at hk₀M
      linarith
  intro k hk
  have hp : 0 ≤ θ ^ (n - k) := pow_nonneg hθ0.le _
  refine ⟨le_trans (hyM k hk) (mul_le_mul_of_nonneg_right hMD hp), le_trans (hxM k hk) ?_⟩
  gcongr

/-! ## (b) the midpoint choice of `θ` -/

theorem midpoint_admissible (ε c c' τ : ℝ) (hτ : 0 ≤ τ) (hετ : ε + τ < 1)
    (h4 : 4 * c * c' < (1 - ε - τ) ^ 2) :
    τ < (1 - ε + τ) / 2 ∧ (1 - ε + τ) / 2 < 1 - ε ∧
      (c * c' / (1 - ε - (1 - ε + τ) / 2) + τ) / ((1 - ε + τ) / 2) < 1 := by
  refine ⟨by linarith, by linarith, ?_⟩
  have hd : 1 - ε - (1 - ε + τ) / 2 = (1 - ε - τ) / 2 := by ring
  rw [hd]
  have hpos : 0 < (1 - ε - τ) / 2 := by linarith
  have hθ : 0 < (1 - ε + τ) / 2 := by linarith
  have h : c * c' / ((1 - ε - τ) / 2) < (1 - ε - τ) / 2 := by
    rw [div_lt_iff₀ hpos]
    nlinarith
  rw [div_lt_one hθ]
  linarith

/-- (a) with the midpoint `θ = (1-ε+τ)/2` under `4cc' < (1-ε-τ)^2`. -/
theorem two_point_bound_mid (n : ℕ) (x y : ℕ → ℝ) (ε c c' τ D : ℝ)
    (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
    (hετ : ε + τ < 1) (h4 : 4 * c * c' < (1 - ε - τ) ^ 2)
    (hy0 : ∀ k, 0 ≤ y k)
    (hx0 : x 0 = 0) (hyn : y n ≤ D)
    (hxs : ∀ k, 1 ≤ k → k ≤ n → (1 - ε) * x k ≤ x (k - 1) + c * y k)
    (hys : ∀ k, 1 ≤ k → k ≤ n → y (k - 1) ≤ c' * x k + τ * y k) :
    ∀ k ≤ n, y k ≤ D * ((1 - ε + τ) / 2) ^ (n - k) ∧
      x k ≤ c * D * ((1 - ε + τ) / 2) ^ (n - k) / (1 - ε - (1 - ε + τ) / 2) := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact two_point_bound n x y ε c c' τ D _ hc hc' hτ hD h1 h2 hy0 hx0 hyn hxs hys h3

/-! ## (c) orbits of the skew product -/

section Skew

variable {X : Type*} [MetricSpace X]

/-- One step of the skew product, from scale `k` to scale `k - 1`:
`(u, v) ↦ (u - b k + r k u v, T k u v)`. -/
def step (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (k : ℕ) (p : ℝ × X) : ℝ × X :=
  (p.1 - b k + r k p.1 p.2, T k p.1 p.2)

/-- `w` is an orbit from scale `n` down to scale `0`: `w k = step (k+1) (w (k+1))` for `k < n`. -/
def IsOrbit (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (n : ℕ) (w : ℕ → ℝ × X) :
    Prop :=
  ∀ k < n, w k = step b r T (k + 1) (w (k + 1))

omit [MetricSpace X] in
/-- The part of an orbit from scale `m ≥ n` that lies at scales `≤ n` is an orbit from `n`. -/
theorem IsOrbit.mono {b : ℕ → ℝ} {r : ℕ → ℝ → X → ℝ} {T : ℕ → ℝ → X → X} {m n : ℕ}
    {w : ℕ → ℝ × X} (h : IsOrbit b r T m w) (hnm : n ≤ m) : IsOrbit b r T n w :=
  fun k hk => h k (lt_of_lt_of_le hk hnm)

variable (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (B : Set X)
  (ε c c' τ D θ : ℝ)

section Hyp

variable (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
  (hτθ : τ < θ) (hθ : θ < 1 - ε) (hq : (c * c' / (1 - ε - θ) + τ) / θ < 1)
  (hr : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
  (hT : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v')
  (hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ D)

include hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- Two orbits from scale `n` with the same marginal coordinate at the coarse end and the
irrelevant coordinate in `B` stay close: at scale `k` the irrelevant coordinates differ by at
most `D θ^(n-k)` and the marginal ones by at most `c D θ^(n-k) / (1-ε-θ)`. -/
theorem orbit_compare (n : ℕ) (w w' : ℕ → ℝ × X)
    (hw : IsOrbit b r T n w) (hw' : IsOrbit b r T n w') (h0 : (w 0).1 = (w' 0).1)
    (hm : ∀ k ≤ n, (w k).2 ∈ B) (hm' : ∀ k ≤ n, (w' k).2 ∈ B) :
    ∀ k ≤ n, dist (w k).2 (w' k).2 ≤ D * θ ^ (n - k) ∧
      |(w k).1 - (w' k).1| ≤ c * D * θ ^ (n - k) / (1 - ε - θ) := by
  have := two_point_bound n (fun k => |(w k).1 - (w' k).1|) (fun k => dist (w k).2 (w' k).2)
    ε c c' τ D θ hc hc' hτ hD hτθ hθ (fun k => dist_nonneg) (by simp [h0])
    (hB _ (hm n le_rfl) _ (hm' n le_rfl)) ?_ ?_ hq
  · exact this
  · intro k hk1 hkn
    obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
    simp only [Nat.add_sub_cancel]
    have e := congrArg Prod.fst (hw j (by omega))
    have e' := congrArg Prod.fst (hw' j (by omega))
    simp only [step] at e e'
    rw [e, e']
    have hR := hr (j + 1) (w (j + 1)).1 (w' (j + 1)).1 _ (hm (j + 1) hkn) _ (hm' (j + 1) hkn)
    have t : |(w (j + 1)).1 - (w' (j + 1)).1| ≤
        |((w (j + 1)).1 - b (j + 1) + r (j + 1) (w (j + 1)).1 (w (j + 1)).2) -
          ((w' (j + 1)).1 - b (j + 1) + r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)| +
        |r (j + 1) (w (j + 1)).1 (w (j + 1)).2 - r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2| := by
      calc |(w (j + 1)).1 - (w' (j + 1)).1|
          = |(((w (j + 1)).1 - b (j + 1) + r (j + 1) (w (j + 1)).1 (w (j + 1)).2) -
              ((w' (j + 1)).1 - b (j + 1) + r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)) -
            (r (j + 1) (w (j + 1)).1 (w (j + 1)).2 -
              r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)| := by congr 1; ring
        _ ≤ _ := abs_sub _ _
    linarith
  · intro k hk1 hkn
    obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
    simp only [Nat.add_sub_cancel]
    have e := congrArg Prod.snd (hw j (by omega))
    have e' := congrArg Prod.snd (hw' j (by omega))
    simp only [step] at e e'
    rw [e, e']
    exact hT (j + 1) _ _ _ (hm (j + 1) hkn) _ (hm' (j + 1) hkn)

/-- Hypotheses on the family of orbits: lattice `n` gives an orbit `w n` from scale `n` to `0`,
matched at the coarse end (`(w n 0).1 = ub`), with the irrelevant coordinate in `B`. -/
def Admissible (ub : ℝ) (w : ℕ → ℕ → ℝ × X) : Prop :=
  (∀ n, IsOrbit b r T n (w n)) ∧ (∀ n, (w n 0).1 = ub) ∧ (∀ n, ∀ k ≤ n, (w n k).2 ∈ B)

include hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- Lattice `n+1` versus lattice `n`: the coarse irrelevant coordinates differ by `≤ D θ^n`. -/
theorem coarse_step (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (n : ℕ) :
    dist (w (n + 1) 0).2 (w n 0).2 ≤ D * θ ^ n := by
  obtain ⟨horb, hend, hmem⟩ := hw
  have h := orbit_compare b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB n (w (n + 1)) (w n)
    ((horb (n + 1)).mono (Nat.le_succ n)) (horb n) (by rw [hend, hend])
    (fun k hk => hmem (n + 1) k (by omega)) (hmem n) 0 (Nat.zero_le n)
  simpa using h.1

variable (hε : 0 ≤ ε)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- The coarse irrelevant coordinate is a Cauchy sequence in the lattice index. -/
theorem coarse_cauchy (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) :
    CauchySeq (fun n => (w n 0).2) := by
  have hθ1 : θ < 1 := by linarith
  exact cauchySeq_of_le_geometric θ D hθ1 (fun n => by
    rw [dist_comm]; exact coarse_step b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB ub w hw n)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- In a complete space the whole sequence converges (no subsequence). -/
theorem coarse_tendsto [CompleteSpace X] (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) :=
  cauchySeq_tendsto_of_complete
    (coarse_cauchy b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB hε ub w hw)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- Rate: `dist ((w n 0).2) v ≤ D θ^n / (1 - θ)`. -/
theorem coarse_rate (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (v : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v)) (n : ℕ) :
    dist (w n 0).2 v ≤ D * θ ^ n / (1 - θ) := by
  have hθ1 : θ < 1 := by linarith
  exact dist_le_of_le_geometric_of_tendsto θ D hθ1 (fun n => by
    rw [dist_comm]; exact coarse_step b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB ub w hw n)
    hv n

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- Two families of orbits with the same coarse marginal value `ub` (but arbitrary bare
irrelevant coordinates in `B`) have the same limit. -/
theorem limit_independent (ub : ℝ) (w w' : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hw' : Admissible b r T B ub w') (v v' : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v))
    (hv' : Tendsto (fun n => (w' n 0).2) atTop (𝓝 v')) : v = v' := by
  obtain ⟨horb, hend, hmem⟩ := hw
  obtain ⟨horb', hend', hmem'⟩ := hw'
  have hθ0 : 0 ≤ θ := by linarith
  have hθ1 : θ < 1 := by linarith
  have h1 : Tendsto (fun n => dist (w n 0).2 (w' n 0).2) atTop (𝓝 (dist v v')) := hv.dist hv'
  have hg : Tendsto (fun n => D * θ ^ n) atTop (𝓝 0) := by
    simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hθ0 hθ1).const_mul D
  have h0 : Tendsto (fun n => dist (w n 0).2 (w' n 0).2) atTop (𝓝 0) := by
    refine squeeze_zero (fun n => dist_nonneg) (fun n => ?_) hg
    have h := orbit_compare b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB n (w n) (w' n)
      (horb n) (horb' n) (by rw [hend, hend']) (hmem n) (hmem' n) 0 (Nat.zero_le n)
    simpa using h.1
  exact dist_eq_zero.mp (tendsto_nhds_unique h1 h0)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- A coarse observable that is a continuous function `Ψ` of the coarse coordinates `(u, v)`
converges along the whole sequence, to a value independent of the bare irrelevant coordinates. -/
theorem observable_tendsto [CompleteSpace X] {Y : Type*} [TopologicalSpace Y]
    (Ψ : ℝ × X → Y) (hΨ : Continuous Ψ) (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => Ψ (w n 0)) atTop (𝓝 (Ψ (ub, v))) := by
  obtain ⟨v, hv⟩ := coarse_tendsto b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB hε ub w hw
  refine ⟨v, ((hΨ.tendsto _).comp (tendsto_const_nhds.prodMk_nhds hv)).congr (fun n => ?_)⟩
  show Ψ (ub, (w n 0).2) = Ψ (w n 0)
  congr 1
  exact Prod.ext (hw.2.1 n).symm rfl

end Hyp

/-! ### The midpoint form: hypotheses stated with `4cc' < (1-ε-τ)^2` only -/

section Mid

variable (hε : 0 ≤ ε) (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
  (hετ : ε + τ < 1) (h4 : 4 * c * c' < (1 - ε - τ) ^ 2)
  (hr : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
  (hT : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v')
  (hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ D)

include hc hc' hτ hD hετ h4 hr hT hB in
theorem coarse_step_mid (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (n : ℕ) :
    dist (w (n + 1) 0).2 (w n 0).2 ≤ D * ((1 - ε + τ) / 2) ^ n := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact coarse_step b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB ub w hw n

include hε hc hc' hτ hD hετ h4 hr hT hB in
theorem coarse_tendsto_mid [CompleteSpace X] (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact coarse_tendsto b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB hε ub w hw

include hε hc hc' hτ hD hετ h4 hr hT hB in
theorem limit_independent_mid (ub : ℝ) (w w' : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hw' : Admissible b r T B ub w') (v v' : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v))
    (hv' : Tendsto (fun n => (w' n 0).2) atTop (𝓝 v')) : v = v' := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact limit_independent b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB hε ub w w' hw hw'
    v v' hv hv'

end Mid

end Skew

end SkewOrbit

#print axioms SkewOrbit.two_point_bound
#print axioms SkewOrbit.midpoint_admissible
#print axioms SkewOrbit.two_point_bound_mid
#print axioms SkewOrbit.orbit_compare
#print axioms SkewOrbit.coarse_step
#print axioms SkewOrbit.coarse_cauchy
#print axioms SkewOrbit.coarse_tendsto
#print axioms SkewOrbit.coarse_rate
#print axioms SkewOrbit.limit_independent
#print axioms SkewOrbit.observable_tendsto
#print axioms SkewOrbit.coarse_step_mid
#print axioms SkewOrbit.coarse_tendsto_mid
#print axioms SkewOrbit.limit_independent_mid
