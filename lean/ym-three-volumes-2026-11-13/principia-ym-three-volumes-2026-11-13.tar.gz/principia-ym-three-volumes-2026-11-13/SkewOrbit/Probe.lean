import Mathlib

/-!
# Limit of finite orbits for a skew product with a marginal direction

The pull-back form (all directions contract) is replaced by a skew product
`Φ k (u, v) = (u - b k + r k u v, T k u v)`: the coordinate `u` (marginal, e.g. inverse coupling)
need not contract; only the irrelevant coordinate `v` contracts, with cross couplings `c`, `c'`.

* `two_point_bound` (a): the finite two-point boundary problem
  `x 0 = 0`, `y n ≤ D`, `(1-ε) x k ≤ x (k-1) + c y k`, `y (k-1) ≤ c' x k + τ y k`
  gives `y k ≤ D θ^(n-k)` and `x k ≤ c D θ^(n-k) / (1-ε-θ)` provided `q < 1`.
* `midpoint_admissible` (b): with `θ = (1-ε+τ)/2`, the condition `4cc' < (1-ε-τ)^2`
  gives the hypotheses of (a).
* `orbit_compare`, `coarse_step`, `coarse_cauchy`, `coarse_tendsto`, `coarse_rate`,
  `limit_independent`, `observable_tendsto` (c): orbits from scale `n` to `0` with the
  marginal coordinate matched at the coarse end; the coarse irrelevant coordinate is Cauchy
  (`≤ D θ^n`), converges if `X` is complete, and the limit does not depend on the bare values.
-/

open Filter Topology

namespace SkewOrbit

/-! ## (a) the finite two-point boundary lemma -/

theorem two_point_bound (n : ℕ) (x y : ℕ → ℝ) (ε c c' τ D θ : ℝ)
    (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
    (hτθ : τ < θ) (hθ : θ < 1 - ε)
    (hy0 : ∀ k, 0 ≤ y k)
    (hx0 : x 0 = 0) (hyn : y n ≤ D)
    (hxs : ∀ k, 1 ≤ k → k ≤ n → (1 - ε) * x k ≤ x (k - 1) + c * y k)
    (hys : ∀ k, 1 ≤ k → k ≤ n → y (k - 1) ≤ c' * x k + τ * y k)
    (hq : (c * c' / (1 - ε - θ) + τ) / θ < 1) :
    ∀ k ≤ n, y k ≤ D * θ ^ (n - k) ∧ x k ≤ c * D * θ ^ (n - k) / (1 - ε - θ) := by
  have hθ0 : 0 < θ := lt_of_le_of_lt hτ hτθ
  have hd : 0 < 1 - ε - θ := by linarith
  have h1ε : 0 < 1 - ε := by linarith
  -- M = max_{k ≤ n} y k / θ^(n-k)
  obtain ⟨M, hM0, hyM, k₀, hk₀, hk₀M⟩ : ∃ M : ℝ, 0 ≤ M ∧ (∀ k ≤ n, y k ≤ M * θ ^ (n - k)) ∧
      ∃ k₀ ≤ n, y k₀ = M * θ ^ (n - k₀) := by
    let f : ℕ → ℝ := fun k => y k / θ ^ (n - k)
    have hne : (Finset.range (n + 1)).Nonempty := ⟨0, by simp⟩
    refine ⟨(Finset.range (n + 1)).sup' hne f, ?_, ?_, ?_⟩
    · have h : f 0 ≤ _ := Finset.le_sup' f (Finset.mem_range.mpr (Nat.succ_pos n))
      exact le_trans (div_nonneg (hy0 0) (pow_pos hθ0 _).le) h
    · intro k hk
      have h : f k ≤ _ := Finset.le_sup' f (Finset.mem_range.mpr (show k < n + 1 by omega))
      exact (div_le_iff₀ (pow_pos hθ0 _)).mp h
    · obtain ⟨k₀, hk₀, h⟩ := Finset.exists_mem_eq_sup' hne f
      refine ⟨k₀, by simpa [Nat.lt_succ_iff] using hk₀, ?_⟩
      rw [h]
      show y k₀ = y k₀ / θ ^ (n - k₀) * θ ^ (n - k₀)
      exact (div_mul_cancel₀ (y k₀) (pow_ne_zero _ hθ0.ne')).symm
  -- x k ≤ c M θ^(n-k) / (1-ε-θ), by induction from the coarse end
  have hxM : ∀ k ≤ n, x k ≤ c * M * θ ^ (n - k) / (1 - ε - θ) := by
    intro k
    induction k with
    | zero => intro _; rw [hx0]; positivity
    | succ k ih =>
      intro hk
      have h1 := hxs (k + 1) (by omega) hk
      simp only [Nat.add_sub_cancel] at h1
      have h2 := ih (by omega)
      have h3 := hyM (k + 1) hk
      have hpow : θ ^ (n - k) = θ * θ ^ (n - (k + 1)) := by
        rw [← pow_succ']; congr 1; omega
      rw [hpow] at h2
      have key : (1 - ε) * x (k + 1) ≤ (1 - ε) * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) := by
        calc (1 - ε) * x (k + 1) ≤ x k + c * y (k + 1) := h1
          _ ≤ c * M * (θ * θ ^ (n - (k + 1))) / (1 - ε - θ) + c * (M * θ ^ (n - (k + 1))) :=
              add_le_add h2 (mul_le_mul_of_nonneg_left h3 hc)
          _ = (1 - ε) * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) := by
              field_simp
              ring
      exact le_of_mul_le_mul_left key h1ε
  -- for k < n, y k ≤ q M θ^(n-k)
  set q := (c * c' / (1 - ε - θ) + τ) / θ with hqdef
  have hyq : ∀ k < n, y k ≤ q * M * θ ^ (n - k) := by
    intro k hk
    have h1 := hys (k + 1) (by omega) hk
    simp only [Nat.add_sub_cancel] at h1
    have h2 := hxM (k + 1) hk
    have h3 := hyM (k + 1) hk
    have hpow : θ ^ (n - k) = θ * θ ^ (n - (k + 1)) := by
      rw [← pow_succ']; congr 1; omega
    rw [hpow]
    calc y k ≤ c' * x (k + 1) + τ * y (k + 1) := h1
      _ ≤ c' * (c * M * θ ^ (n - (k + 1)) / (1 - ε - θ)) + τ * (M * θ ^ (n - (k + 1))) :=
          add_le_add (mul_le_mul_of_nonneg_left h2 hc') (mul_le_mul_of_nonneg_left h3 hτ)
      _ = q * M * (θ * θ ^ (n - (k + 1))) := by
          rw [hqdef]
          field_simp
  -- M ≤ D
  have hMD : M ≤ D := by
    rcases Nat.lt_or_ge k₀ n with hlt | hge
    · have h := hyq k₀ hlt
      rw [hk₀M] at h
      have hp : 0 < θ ^ (n - k₀) := pow_pos hθ0 _
      have hMq : M ≤ q * M := le_of_mul_le_mul_right (by linarith) hp
      by_contra hcon
      have hMpos : 0 < M := by linarith
      have : q * M < 1 * M := mul_lt_mul_of_pos_right hq hMpos
      linarith
    · have hk : k₀ = n := le_antisymm hk₀ hge
      subst hk
      simp only [Nat.sub_self, pow_zero, mul_one] at hk₀M
      linarith
  intro k hk
  have hp : 0 ≤ θ ^ (n - k) := pow_nonneg hθ0.le _
  refine ⟨le_trans (hyM k hk) (mul_le_mul_of_nonneg_right hMD hp), le_trans (hxM k hk) ?_⟩
  gcongr

/-! ## (b) the midpoint choice of `θ` -/

theorem midpoint_admissible (ε c c' τ : ℝ) (hτ : 0 ≤ τ) (hετ : ε + τ < 1)
    (h4 : 4 * c * c' < (1 - ε - τ) ^ 2) :
    τ < (1 - ε + τ) / 2 ∧ (1 - ε + τ) / 2 < 1 - ε ∧
      (c * c' / (1 - ε - (1 - ε + τ) / 2) + τ) / ((1 - ε + τ) / 2) < 1 := by
  refine ⟨by linarith, by linarith, ?_⟩
  have hd : 1 - ε - (1 - ε + τ) / 2 = (1 - ε - τ) / 2 := by ring
  rw [hd]
  have hpos : 0 < (1 - ε - τ) / 2 := by linarith
  have hθ : 0 < (1 - ε + τ) / 2 := by linarith
  have h : c * c' / ((1 - ε - τ) / 2) < (1 - ε - τ) / 2 := by
    rw [div_lt_iff₀ hpos]
    nlinarith
  rw [div_lt_one hθ]
  linarith

/-- (a) with the midpoint `θ = (1-ε+τ)/2` under `4cc' < (1-ε-τ)^2`. -/
theorem two_point_bound_mid (n : ℕ) (x y : ℕ → ℝ) (ε c c' τ D : ℝ)
    (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
    (hετ : ε + τ < 1) (h4 : 4 * c * c' < (1 - ε - τ) ^ 2)
    (hy0 : ∀ k, 0 ≤ y k)
    (hx0 : x 0 = 0) (hyn : y n ≤ D)
    (hxs : ∀ k, 1 ≤ k → k ≤ n → (1 - ε) * x k ≤ x (k - 1) + c * y k)
    (hys : ∀ k, 1 ≤ k → k ≤ n → y (k - 1) ≤ c' * x k + τ * y k) :
    ∀ k ≤ n, y k ≤ D * ((1 - ε + τ) / 2) ^ (n - k) ∧
      x k ≤ c * D * ((1 - ε + τ) / 2) ^ (n - k) / (1 - ε - (1 - ε + τ) / 2) := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact two_point_bound n x y ε c c' τ D _ hc hc' hτ hD h1 h2 hy0 hx0 hyn hxs hys h3

/-! ## (c) orbits of the skew product -/

section Skew

variable {X : Type*} [MetricSpace X]

/-- One step of the skew product, from scale `k` to scale `k - 1`:
`(u, v) ↦ (u - b k + r k u v, T k u v)`. -/
def step (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (k : ℕ) (p : ℝ × X) : ℝ × X :=
  (p.1 - b k + r k p.1 p.2, T k p.1 p.2)

/-- `w` is an orbit from scale `n` down to scale `0`: `w k = step (k+1) (w (k+1))` for `k < n`. -/
def IsOrbit (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (n : ℕ) (w : ℕ → ℝ × X) :
    Prop :=
  ∀ k < n, w k = step b r T (k + 1) (w (k + 1))

omit [MetricSpace X] in
/-- The part of an orbit from scale `m ≥ n` that lies at scales `≤ n` is an orbit from `n`. -/
theorem IsOrbit.mono {b : ℕ → ℝ} {r : ℕ → ℝ → X → ℝ} {T : ℕ → ℝ → X → X} {m n : ℕ}
    {w : ℕ → ℝ × X} (h : IsOrbit b r T m w) (hnm : n ≤ m) : IsOrbit b r T n w :=
  fun k hk => h k (lt_of_lt_of_le hk hnm)

variable (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (B : Set X)
  (ε c c' τ D θ : ℝ)

section Hyp

variable (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
  (hτθ : τ < θ) (hθ : θ < 1 - ε) (hq : (c * c' / (1 - ε - θ) + τ) / θ < 1)
  (hr : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
  (hT : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v')
  (hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ D)

include hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- Two orbits from scale `n` with the same marginal coordinate at the coarse end and the
irrelevant coordinate in `B` stay close: at scale `k` the irrelevant coordinates differ by at
most `D θ^(n-k)` and the marginal ones by at most `c D θ^(n-k) / (1-ε-θ)`. -/
theorem orbit_compare (n : ℕ) (w w' : ℕ → ℝ × X)
    (hw : IsOrbit b r T n w) (hw' : IsOrbit b r T n w') (h0 : (w 0).1 = (w' 0).1)
    (hm : ∀ k ≤ n, (w k).2 ∈ B) (hm' : ∀ k ≤ n, (w' k).2 ∈ B) :
    ∀ k ≤ n, dist (w k).2 (w' k).2 ≤ D * θ ^ (n - k) ∧
      |(w k).1 - (w' k).1| ≤ c * D * θ ^ (n - k) / (1 - ε - θ) := by
  have := two_point_bound n (fun k => |(w k).1 - (w' k).1|) (fun k => dist (w k).2 (w' k).2)
    ε c c' τ D θ hc hc' hτ hD hτθ hθ (fun k => dist_nonneg) (by simp [h0])
    (hB _ (hm n le_rfl) _ (hm' n le_rfl)) ?_ ?_ hq
  · exact this
  · intro k hk1 hkn
    obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
    simp only [Nat.add_sub_cancel]
    have e := congrArg Prod.fst (hw j (by omega))
    have e' := congrArg Prod.fst (hw' j (by omega))
    simp only [step] at e e'
    rw [e, e']
    have hR := hr (j + 1) (w (j + 1)).1 (w' (j + 1)).1 _ (hm (j + 1) hkn) _ (hm' (j + 1) hkn)
    have t : |(w (j + 1)).1 - (w' (j + 1)).1| ≤
        |((w (j + 1)).1 - b (j + 1) + r (j + 1) (w (j + 1)).1 (w (j + 1)).2) -
          ((w' (j + 1)).1 - b (j + 1) + r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)| +
        |r (j + 1) (w (j + 1)).1 (w (j + 1)).2 - r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2| := by
      calc |(w (j + 1)).1 - (w' (j + 1)).1|
          = |(((w (j + 1)).1 - b (j + 1) + r (j + 1) (w (j + 1)).1 (w (j + 1)).2) -
              ((w' (j + 1)).1 - b (j + 1) + r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)) -
            (r (j + 1) (w (j + 1)).1 (w (j + 1)).2 -
              r (j + 1) (w' (j + 1)).1 (w' (j + 1)).2)| := by congr 1; ring
        _ ≤ _ := abs_sub _ _
    linarith
  · intro k hk1 hkn
    obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
    simp only [Nat.add_sub_cancel]
    have e := congrArg Prod.snd (hw j (by omega))
    have e' := congrArg Prod.snd (hw' j (by omega))
    simp only [step] at e e'
    rw [e, e']
    exact hT (j + 1) _ _ _ (hm (j + 1) hkn) _ (hm' (j + 1) hkn)

/-- Hypotheses on the family of orbits: lattice `n` gives an orbit `w n` from scale `n` to `0`,
matched at the coarse end (`(w n 0).1 = ub`), with the irrelevant coordinate in `B`. -/
def Admissible (ub : ℝ) (w : ℕ → ℕ → ℝ × X) : Prop :=
  (∀ n, IsOrbit b r T n (w n)) ∧ (∀ n, (w n 0).1 = ub) ∧ (∀ n, ∀ k ≤ n, (w n k).2 ∈ B)

include hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- Lattice `n+1` versus lattice `n`: the coarse irrelevant coordinates differ by `≤ D θ^n`. -/
theorem coarse_step (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (n : ℕ) :
    dist (w (n + 1) 0).2 (w n 0).2 ≤ D * θ ^ n := by
  obtain ⟨horb, hend, hmem⟩ := hw
  have h := orbit_compare b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB n (w (n + 1)) (w n)
    ((horb (n + 1)).mono (Nat.le_succ n)) (horb n) (by rw [hend, hend])
    (fun k hk => hmem (n + 1) k (by omega)) (hmem n) 0 (Nat.zero_le n)
  simpa using h.1

variable (hε : 0 ≤ ε)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- The coarse irrelevant coordinate is a Cauchy sequence in the lattice index. -/
theorem coarse_cauchy (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) :
    CauchySeq (fun n => (w n 0).2) := by
  have hθ1 : θ < 1 := by linarith
  exact cauchySeq_of_le_geometric θ D hθ1 (fun n => by
    rw [dist_comm]; exact coarse_step b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB ub w hw n)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- In a complete space the whole sequence converges (no subsequence). -/
theorem coarse_tendsto [CompleteSpace X] (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) :=
  cauchySeq_tendsto_of_complete
    (coarse_cauchy b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB hε ub w hw)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- Rate: `dist ((w n 0).2) v ≤ D θ^n / (1 - θ)`. -/
theorem coarse_rate (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (v : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v)) (n : ℕ) :
    dist (w n 0).2 v ≤ D * θ ^ n / (1 - θ) := by
  have hθ1 : θ < 1 := by linarith
  exact dist_le_of_le_geometric_of_tendsto θ D hθ1 (fun n => by
    rw [dist_comm]; exact coarse_step b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB ub w hw n)
    hv n

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- Two families of orbits with the same coarse marginal value `ub` (but arbitrary bare
irrelevant coordinates in `B`) have the same limit. -/
theorem limit_independent (ub : ℝ) (w w' : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hw' : Admissible b r T B ub w') (v v' : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v))
    (hv' : Tendsto (fun n => (w' n 0).2) atTop (𝓝 v')) : v = v' := by
  obtain ⟨horb, hend, hmem⟩ := hw
  obtain ⟨horb', hend', hmem'⟩ := hw'
  have hθ0 : 0 ≤ θ := by linarith
  have hθ1 : θ < 1 := by linarith
  have h1 : Tendsto (fun n => dist (w n 0).2 (w' n 0).2) atTop (𝓝 (dist v v')) := hv.dist hv'
  have hg : Tendsto (fun n => D * θ ^ n) atTop (𝓝 0) := by
    simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hθ0 hθ1).const_mul D
  have h0 : Tendsto (fun n => dist (w n 0).2 (w' n 0).2) atTop (𝓝 0) := by
    refine squeeze_zero (fun n => dist_nonneg) (fun n => ?_) hg
    have h := orbit_compare b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB n (w n) (w' n)
      (horb n) (horb' n) (by rw [hend, hend']) (hmem n) (hmem' n) 0 (Nat.zero_le n)
    simpa using h.1
  exact dist_eq_zero.mp (tendsto_nhds_unique h1 h0)

include hc hc' hτ hD hτθ hθ hq hr hT hB hε in
/-- A coarse observable that is a continuous function `Ψ` of the coarse coordinates `(u, v)`
converges along the whole sequence, to a value independent of the bare irrelevant coordinates. -/
theorem observable_tendsto [CompleteSpace X] {Y : Type*} [TopologicalSpace Y]
    (Ψ : ℝ × X → Y) (hΨ : Continuous Ψ) (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => Ψ (w n 0)) atTop (𝓝 (Ψ (ub, v))) := by
  obtain ⟨v, hv⟩ := coarse_tendsto b r T B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr hT hB hε ub w hw
  refine ⟨v, ((hΨ.tendsto _).comp (tendsto_const_nhds.prodMk_nhds hv)).congr (fun n => ?_)⟩
  show Ψ (ub, (w n 0).2) = Ψ (w n 0)
  congr 1
  exact Prod.ext (hw.2.1 n).symm rfl

end Hyp

/-! ### The midpoint form: hypotheses stated with `4cc' < (1-ε-τ)^2` only -/

section Mid

variable (hε : 0 ≤ ε) (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
  (hετ : ε + τ < 1) (h4 : 4 * c * c' < (1 - ε - τ) ^ 2)
  (hr : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
  (hT : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B, dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v')
  (hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ D)

include hc hc' hτ hD hετ h4 hr hT hB in
theorem coarse_step_mid (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w) (n : ℕ) :
    dist (w (n + 1) 0).2 (w n 0).2 ≤ D * ((1 - ε + τ) / 2) ^ n := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact coarse_step b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB ub w hw n

include hε hc hc' hτ hD hετ h4 hr hT hB in
theorem coarse_tendsto_mid [CompleteSpace X] (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) :
    ∃ v : X, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact coarse_tendsto b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB hε ub w hw

include hε hc hc' hτ hD hετ h4 hr hT hB in
theorem limit_independent_mid (ub : ℝ) (w w' : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hw' : Admissible b r T B ub w') (v v' : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v))
    (hv' : Tendsto (fun n => (w' n 0).2) atTop (𝓝 v')) : v = v' := by
  obtain ⟨h1, h2, h3⟩ := midpoint_admissible ε c c' τ hτ hετ h4
  exact limit_independent b r T B ε c c' τ D _ hc hc' hτ hD h1 h2 h3 hr hT hB hε ub w w' hw hw'
    v v' hv hv'

end Mid

end Skew

end SkewOrbit

#print axioms SkewOrbit.two_point_bound
#print axioms SkewOrbit.midpoint_admissible
#print axioms SkewOrbit.two_point_bound_mid
#print axioms SkewOrbit.orbit_compare
#print axioms SkewOrbit.coarse_step
#print axioms SkewOrbit.coarse_cauchy
#print axioms SkewOrbit.coarse_tendsto
#print axioms SkewOrbit.coarse_rate
#print axioms SkewOrbit.limit_independent
#print axioms SkewOrbit.observable_tendsto
#print axioms SkewOrbit.coarse_step_mid
#print axioms SkewOrbit.coarse_tendsto_mid
#print axioms SkewOrbit.limit_independent_mid

/-! # Probes on `SkewOrbit` (checker's additions; everything above is a verbatim copy)

* `Ex.admissible`, `Ex.coarse_converges`, `Ex.bare_not_cauchy`: an explicit linear skew product
  on `ℝ` with `ε = 0`, `c = 7/20`, `c' = 1/20`, `τ = 7/10`, `B = [-1, 1]` (`D = 2`), matched at
  the coarse end (`ub = 0`). All hypotheses of the `_mid` theorems hold, the bare irrelevant
  coordinates oscillate, and the coarse ones converge.
* `Ex.matching_needed`: the same maps and orbits in `B`, but without the coarse-end matching:
  the coarse irrelevant coordinate is not Cauchy.
* `theta_exists_iff`: a `θ` with `τ < θ < 1 - ε` and `q < 1` exists iff `ε + τ < 1` and
  `4cc' < (1-ε-τ)^2`.
* `rate_window`: every `θ` strictly between the two roots of `(θ-τ)(1-ε-θ) = cc'` satisfies the
  hypotheses of `two_point_bound`.
* `coarse_step_window`, `coarse_tendsto_window`, `limit_independent_window`: (K-lip) on a
  window `u ≥ a` suffices when the orbits stay in the window (clamp `u ↦ max u a`).
* `one_step_after`: what `coarse_step` compares.
* `Sharp.sharp`: for `ε = 0`, `c = 1/6`, `c' = 1/3`, `τ = 1/2` (`θ₋ = 2/3`), sequences satisfying
  the inequalities of `two_point_bound` with `y 0 ≥ (2/3)^n/2`: no `θ < θ₋` works there.
-/

namespace SkewOrbitProbe

open SkewOrbit Filter Topology

namespace Ex

noncomputable section

def b : ℕ → ℝ := fun _ => 0
def r : ℕ → ℝ → ℝ → ℝ := fun _ _ v => 7 / 20 * v
def T : ℕ → ℝ → ℝ → ℝ := fun _ u v => 7 / 10 * v + 1 / 20 * u
def B : Set ℝ := Set.Icc (-1) 1

/-- Bare irrelevant amplitude `t n = (-1)^n / 2`. -/
def t (n : ℕ) : ℝ := (-1) ^ n / 2

/-- Orbit of lattice `n`, matched to `ub = 0` at the coarse end:
`w n k = S (20/21)^k (1, 1/7) + t n (13/20)^(n-k) (1, -1)` with `S = - t n (13/20)^n`. -/
def w (n k : ℕ) : ℝ × ℝ :=
  ((-(t n) * (13 / 20) ^ n) * (20 / 21) ^ k + t n * (13 / 20) ^ (n - k),
   (-(t n) * (13 / 20) ^ n) * (20 / 21) ^ k / 7 - t n * (13 / 20) ^ (n - k))

theorem orbit (n : ℕ) : IsOrbit b r T n (w n) := by
  intro k hk
  have h1 : n - k = (n - (k + 1)) + 1 := by omega
  have e1 : ((13 : ℝ) / 20) ^ (n - k) = (13 / 20) ^ (n - (k + 1)) * (13 / 20) := by
    rw [h1, pow_succ]
  have e2 : ((20 : ℝ) / 21) ^ (k + 1) = (20 / 21) ^ k * (20 / 21) := pow_succ _ _
  simp only [w, step, b, r, T, Prod.mk.injEq]
  rw [e1, e2]
  constructor <;> ring

theorem matched (n : ℕ) : (w n 0).1 = 0 := by
  simp only [w, pow_zero, Nat.sub_zero]
  ring

theorem t_cases (n : ℕ) : t n = 1 / 2 ∨ t n = -1 / 2 := by
  unfold t
  rcases neg_one_pow_eq_or ℝ n with h | h <;> rw [h] <;> simp

theorem t_succ (n : ℕ) : t (n + 1) = - t n := by
  unfold t
  rw [pow_succ]
  ring

theorem mem (n k : ℕ) : (w n k).2 ∈ B := by
  have hs0 : (0 : ℝ) ≤ (13 / 20) ^ n := by positivity
  have hs1 : ((13 : ℝ) / 20) ^ n ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hq0 : (0 : ℝ) ≤ (20 / 21) ^ k := by positivity
  have hq1 : ((20 : ℝ) / 21) ^ k ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hp0 : (0 : ℝ) ≤ (13 / 20) ^ (n - k) := by positivity
  have hp1 : ((13 : ℝ) / 20) ^ (n - k) ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  have hsq0 : (0 : ℝ) ≤ (13 / 20) ^ n * (20 / 21) ^ k := mul_nonneg hs0 hq0
  have hsq1 : ((13 : ℝ) / 20) ^ n * (20 / 21) ^ k ≤ 1 := by nlinarith
  simp only [w, B, Set.mem_Icc]
  rcases t_cases n with h | h <;> rw [h] <;> constructor <;> nlinarith

theorem admissible : Admissible b r T B 0 w :=
  ⟨orbit, matched, fun n k _ => mem n k⟩

theorem hr : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B,
    |r k u v - r k u' v'| ≤ 0 * |u - u'| + 7 / 20 * dist v v' := by
  intro k u u' v _ v' _
  have e : r k u v - r k u' v' = 7 / 20 * (v - v') := by simp only [r]; ring
  rw [e, abs_mul, Real.dist_eq, abs_of_pos (by norm_num : (0 : ℝ) < 7 / 20)]
  linarith

theorem hT : ∀ k u u', ∀ v ∈ B, ∀ v' ∈ B,
    dist (T k u v) (T k u' v') ≤ 1 / 20 * |u - u'| + 7 / 10 * dist v v' := by
  intro k u u' v _ v' _
  have e : T k u v - T k u' v' = 7 / 10 * (v - v') + 1 / 20 * (u - u') := by
    simp only [T]; ring
  rw [Real.dist_eq, Real.dist_eq, e]
  calc |7 / 10 * (v - v') + 1 / 20 * (u - u')|
      ≤ |7 / 10 * (v - v')| + |1 / 20 * (u - u')| := abs_add_le _ _
    _ = 1 / 20 * |u - u'| + 7 / 10 * |v - v'| := by
      rw [abs_mul, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 7 / 10),
        abs_of_pos (by norm_num : (0 : ℝ) < 1 / 20)]
      ring

theorem hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ 2 := by
  intro v hv v' hv'
  simp only [B, Set.mem_Icc] at hv hv'
  rw [Real.dist_eq, abs_le]
  constructor <;> linarith [hv.1, hv.2, hv'.1, hv'.2]

/-- The parameters: `ε = 0`, `c = 7/20`, `c' = 1/20`, `τ = 7/10` (so `4cc' = 0.07 < 0.09`). -/
theorem params : (0 : ℝ) + 7 / 10 < 1 ∧ 4 * (7 / 20 : ℝ) * (1 / 20) < (1 - 0 - 7 / 10) ^ 2 := by
  norm_num

/-- The theorem `coarse_tendsto_mid` applies to the example. -/
theorem coarse_converges : ∃ v : ℝ, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) :=
  coarse_tendsto_mid b r T B 0 (7 / 20) (1 / 20) (7 / 10) 2 le_rfl (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) params.1 params.2 hr hT hB 0 w admissible

/-- The bare irrelevant coordinates `(w n n).2` of the example do not converge. -/
theorem bare_not_cauchy : ¬ CauchySeq (fun n => (w n n).2) := by
  intro h
  rw [Metric.cauchySeq_iff'] at h
  obtain ⟨N, hN⟩ := h (1 / 2) (by norm_num)
  have h1 := hN (N + 1) (Nat.le_succ N)
  simp only [w, Nat.sub_self, pow_zero, mul_one, Real.dist_eq, t_succ] at h1
  have hs0 : (0 : ℝ) ≤ (13 / 20) ^ N * (20 / 21) ^ N := by positivity
  have hs0' : (0 : ℝ) ≤ (13 / 20) ^ (N + 1) * (20 / 21) ^ (N + 1) := by positivity
  rw [abs_lt] at h1
  rcases t_cases N with ht | ht <;> rw [ht] at h1 <;> obtain ⟨h1a, h1b⟩ := h1 <;> nlinarith

/-! ### Without the coarse-end matching -/

/-- `σ n = (1 + (-1)^n) / 4 ∈ {0, 1/2}`. -/
def σ (n : ℕ) : ℝ := (1 + (-1) ^ n) / 4

/-- Orbits along the expanding direction `(7, 1)` (eigenvalue `21/20` of the step); the coarse
marginal value `7 σ n` is not the same for all `n`. -/
def wu (n k : ℕ) : ℝ × ℝ := (7 * σ n * (20 / 21) ^ k, σ n * (20 / 21) ^ k)

theorem wu_orbit (n : ℕ) : IsOrbit b r T n (wu n) := by
  intro k _
  have e2 : ((20 : ℝ) / 21) ^ (k + 1) = (20 / 21) ^ k * (20 / 21) := pow_succ _ _
  simp only [wu, step, b, r, T, Prod.mk.injEq]
  rw [e2]
  constructor <;> ring

theorem σ_cases (n : ℕ) : σ n = 1 / 2 ∨ σ n = 0 := by
  unfold σ
  rcases neg_one_pow_eq_or ℝ n with h | h <;> rw [h] <;> norm_num

theorem σ_succ (n : ℕ) : σ (n + 1) = 1 / 2 - σ n := by
  unfold σ
  rw [pow_succ]
  ring

theorem wu_mem (n k : ℕ) : (wu n k).2 ∈ B := by
  have hq0 : (0 : ℝ) ≤ (20 / 21) ^ k := by positivity
  have hq1 : ((20 : ℝ) / 21) ^ k ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  simp only [wu, B, Set.mem_Icc]
  rcases σ_cases n with h | h <;> rw [h] <;> constructor <;> nlinarith

/-- Same maps (so `hr`, `hT`, `hB`, `params` hold), orbits with the irrelevant coordinate in `B`,
but no coarse-end matching: the coarse irrelevant coordinate is not Cauchy. -/
theorem matching_needed :
    (∀ n, IsOrbit b r T n (wu n)) ∧ (∀ n, ∀ k ≤ n, (wu n k).2 ∈ B) ∧
      ¬ CauchySeq (fun n => (wu n 0).2) := by
  refine ⟨wu_orbit, fun n k _ => wu_mem n k, ?_⟩
  intro h
  rw [Metric.cauchySeq_iff'] at h
  obtain ⟨N, hN⟩ := h (1 / 4) (by norm_num)
  have h1 := hN (N + 1) (Nat.le_succ N)
  simp only [wu, pow_zero, mul_one, Real.dist_eq, σ_succ] at h1
  rw [abs_lt] at h1
  rcases σ_cases N with h | h <;> rw [h] at h1 <;> obtain ⟨h1a, h1b⟩ := h1 <;> linarith

end

end Ex

/-! ## The choice of `θ` -/

/-- Some `θ` satisfies the hypotheses `τ < θ < 1 - ε`, `q < 1` of `two_point_bound` iff
`ε + τ < 1` and `4cc' < (1-ε-τ)^2`: the midpoint loses nothing in the condition. -/
theorem theta_exists_iff (ε c c' τ : ℝ) (hτ : 0 ≤ τ) :
    (∃ θ, τ < θ ∧ θ < 1 - ε ∧ (c * c' / (1 - ε - θ) + τ) / θ < 1) ↔
      (ε + τ < 1 ∧ 4 * c * c' < (1 - ε - τ) ^ 2) := by
  constructor
  · rintro ⟨θ, h1, h2, h3⟩
    have hθ0 : 0 < θ := lt_of_le_of_lt hτ h1
    have hd : 0 < 1 - ε - θ := by linarith
    refine ⟨by linarith, ?_⟩
    rw [div_lt_one hθ0] at h3
    have h5 : c * c' / (1 - ε - θ) < θ - τ := by linarith
    rw [div_lt_iff₀ hd] at h5
    nlinarith [sq_nonneg (θ - τ - (1 - ε - θ))]
  · rintro ⟨h1, h2⟩
    exact ⟨_, midpoint_admissible ε c c' τ hτ h1 h2⟩

/-- Every `θ` strictly between `θ₋ = ((1-ε+τ) - s)/2` and `θ₊ = ((1-ε+τ) + s)/2`,
`s = √((1-ε-τ)^2 - 4cc')`, satisfies the hypotheses of `two_point_bound`. -/
theorem rate_window (ε c c' τ θ : ℝ) (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ)
    (hετ : ε + τ < 1) (h4 : 4 * c * c' ≤ (1 - ε - τ) ^ 2)
    (hlo : ((1 - ε + τ) - Real.sqrt ((1 - ε - τ) ^ 2 - 4 * c * c')) / 2 < θ)
    (hhi : θ < ((1 - ε + τ) + Real.sqrt ((1 - ε - τ) ^ 2 - 4 * c * c')) / 2) :
    τ < θ ∧ θ < 1 - ε ∧ (c * c' / (1 - ε - θ) + τ) / θ < 1 := by
  set s := Real.sqrt ((1 - ε - τ) ^ 2 - 4 * c * c') with hs
  have hs0 : 0 ≤ s := Real.sqrt_nonneg _
  have hs2 : s ^ 2 = (1 - ε - τ) ^ 2 - 4 * c * c' := Real.sq_sqrt (by linarith)
  have hcc : 0 ≤ c * c' := mul_nonneg hc hc'
  have hsle : s ≤ 1 - ε - τ := by
    have h' : s ≤ Real.sqrt ((1 - ε - τ) ^ 2) := Real.sqrt_le_sqrt (by linarith)
    rwa [Real.sqrt_sq (by linarith)] at h'
  have h1 : τ < θ := by linarith
  have h2 : θ < 1 - ε := by linarith
  refine ⟨h1, h2, ?_⟩
  have hθ0 : 0 < θ := lt_of_le_of_lt hτ h1
  have hd : 0 < 1 - ε - θ := by linarith
  rw [div_lt_one hθ0]
  have key : c * c' < (θ - τ) * (1 - ε - θ) := by
    nlinarith [mul_pos (sub_pos.mpr hlo) (sub_pos.mpr hhi)]
  have h5 : c * c' / (1 - ε - θ) < θ - τ := by
    rw [div_lt_iff₀ hd]; linarith
  linarith

/-! ## `θ₋` cannot be lowered in `two_point_bound`

For `ε = 0`, `c = 1/6`, `c' = 1/3`, `τ = 1/2` one has `θ₋ = 2/3`, `θ₊ = 5/6`. The difference
sequences of the linear model `δu_{k-1} = δu_k - c δv_k`, `δv_{k-1} = c' δu_k + τ δv_k`
(cross couplings of opposite signs) with `δu_0 = 0`, `δv_n = 1` satisfy every hypothesis of
`two_point_bound` on `x = |δu|`, `y = |δv|` (with `D = 1`) except the choice of `θ`, and
`y 0 ≥ (2/3)^n / 2`. -/

namespace Sharp

noncomputable section

/-- `α n = 1 / (2 - (4/5)^n)`. -/
def α (n : ℕ) : ℝ := 1 / (2 - (4 / 5) ^ n)

/-- `δu` at scale `k` for lattice `n`. -/
def du (n k : ℕ) : ℝ := α n * ((2 / 3) ^ (n - k) - (4 / 5) ^ n * (5 / 6) ^ (n - k))

/-- `δv` at scale `k` for lattice `n`. -/
def dv (n k : ℕ) : ℝ := α n * (2 * (2 / 3) ^ (n - k) - (4 / 5) ^ n * (5 / 6) ^ (n - k))

theorem theta_minus : ((1 - 0 + 1 / 2) - Real.sqrt ((1 - 0 - 1 / 2) ^ 2 - 4 * (1 / 6) * (1 / 3))) / 2
    = (2 / 3 : ℝ) := by
  have e : (1 - 0 - 1 / 2 : ℝ) ^ 2 - 4 * (1 / 6) * (1 / 3) = (1 / 6) ^ 2 := by norm_num
  rw [e, Real.sqrt_sq (by norm_num)]
  norm_num

theorem den_pos (n : ℕ) : 0 < 2 - ((4 : ℝ) / 5) ^ n := by
  have : ((4 : ℝ) / 5) ^ n ≤ 1 := pow_le_one₀ (by norm_num) (by norm_num)
  linarith

theorem α_ge (n : ℕ) : 1 / 2 ≤ α n := by
  unfold α
  rw [le_div_iff₀ (den_pos n)]
  have : (0 : ℝ) ≤ (4 / 5) ^ n := by positivity
  linarith

theorem rec_u (n k : ℕ) (hk1 : 1 ≤ k) (hkn : k ≤ n) :
    du n (k - 1) = du n k - 1 / 6 * dv n k := by
  have h : n - (k - 1) = (n - k) + 1 := by omega
  simp only [du, dv]
  rw [h, pow_succ, pow_succ]
  ring

theorem rec_v (n k : ℕ) (hk1 : 1 ≤ k) (hkn : k ≤ n) :
    dv n (k - 1) = 1 / 3 * du n k + 1 / 2 * dv n k := by
  have h : n - (k - 1) = (n - k) + 1 := by omega
  simp only [du, dv]
  rw [h, pow_succ, pow_succ]
  ring

theorem pow_prod (n : ℕ) : ((4 : ℝ) / 5) ^ n * (5 / 6) ^ n = (2 / 3) ^ n := by
  rw [← mul_pow]; norm_num

theorem du_zero (n : ℕ) : du n 0 = 0 := by
  simp only [du, Nat.sub_zero, pow_prod, sub_self, mul_zero]

theorem dv_top (n : ℕ) : dv n n = 1 := by
  simp only [dv, α, Nat.sub_self, pow_zero, mul_one]
  exact one_div_mul_cancel (den_pos n).ne'

theorem dv_zero (n : ℕ) : dv n 0 = α n * (2 / 3) ^ n := by
  simp only [dv, Nat.sub_zero, pow_prod]
  ring

/-- All hypotheses of `two_point_bound` on `x = |du n ·|`, `y = |dv n ·|` with `ε = 0`,
`c = 1/6`, `c' = 1/3`, `τ = 1/2`, `D = 1`, except those on `θ`. -/
theorem hyps (n : ℕ) :
    (∀ k, 0 ≤ |dv n k|) ∧ |du n 0| = 0 ∧ |dv n n| ≤ 1 ∧
    (∀ k, 1 ≤ k → k ≤ n → (1 - 0) * |du n k| ≤ |du n (k - 1)| + 1 / 6 * |dv n k|) ∧
    (∀ k, 1 ≤ k → k ≤ n → |dv n (k - 1)| ≤ 1 / 3 * |du n k| + 1 / 2 * |dv n k|) := by
  refine ⟨fun k => abs_nonneg _, by rw [du_zero, abs_zero], by rw [dv_top, abs_one], ?_, ?_⟩
  · intro k hk1 hkn
    have e : du n k = du n (k - 1) + 1 / 6 * dv n k := by rw [rec_u n k hk1 hkn]; ring
    have h := abs_add_le (du n (k - 1)) (1 / 6 * dv n k)
    rw [← e, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 1 / 6)] at h
    linarith
  · intro k hk1 hkn
    have h := abs_add_le (1 / 3 * du n k) (1 / 2 * dv n k)
    rw [← rec_v n k hk1 hkn, abs_mul, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 1 / 3),
      abs_of_pos (by norm_num : (0 : ℝ) < 1 / 2)] at h
    exact h

theorem y0_ge (n : ℕ) : (2 / 3 : ℝ) ^ n / 2 ≤ |dv n 0| := by
  have ha := α_ge n
  have hp : (0 : ℝ) ≤ (2 / 3) ^ n := by positivity
  rw [dv_zero, abs_of_nonneg (mul_nonneg (by linarith) hp)]
  nlinarith

/-- No `θ < θ₋ = 2/3` can stand in the conclusion `y 0 ≤ D θ^n` of `two_point_bound`. -/
theorem sharp (θ : ℝ) (h0 : 0 ≤ θ) (h1 : θ < 2 / 3) : ∃ n, 1 * θ ^ n < |dv n 0| := by
  have hr0 : 0 ≤ θ * (3 / 2) := by positivity
  have hr1 : θ * (3 / 2) < 1 := by linarith
  have ht := tendsto_pow_atTop_nhds_zero_of_lt_one hr0 hr1
  obtain ⟨n, hn⟩ := (ht.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1 / 2))).exists
  refine ⟨n, lt_of_lt_of_le ?_ (y0_ge n)⟩
  have e : θ ^ n = (θ * (3 / 2)) ^ n * (2 / 3) ^ n := by
    rw [← mul_pow]; congr 1; ring
  rw [one_mul, e]
  have hp : (0 : ℝ) < (2 / 3) ^ n := by positivity
  nlinarith

/-- For comparison: every `θ` in `(2/3, 5/6)` is admissible for `two_point_bound`. -/
theorem window_ok (θ : ℝ) (hlo : 2 / 3 < θ) (hhi : θ < 5 / 6) :
    (1 / 2 : ℝ) < θ ∧ θ < 1 - 0 ∧ (1 / 6 * (1 / 3) / (1 - 0 - θ) + 1 / 2) / θ < 1 := by
  have e : (1 - 0 - 1 / 2 : ℝ) ^ 2 - 4 * (1 / 6) * (1 / 3) = (1 / 6) ^ 2 := by norm_num
  have h := rate_window 0 (1 / 6) (1 / 3) (1 / 2) θ (by norm_num) (by norm_num) (by norm_num)
    (by norm_num) (by norm_num) (by rw [e, Real.sqrt_sq (by norm_num)]; linarith)
    (by rw [e, Real.sqrt_sq (by norm_num)]; linarith)
  simpa [mul_assoc] using h

end

end Sharp

/-! ## What `coarse_step` compares -/

/-- The orbit of lattice `n+1`, cut at scale `n` (as in `coarse_step`), starts one step after
its bare value: `w (n+1) n = step (n+1) (w (n+1) (n+1))`; the orbit of lattice `n` starts at its
bare value `w n n`. -/
theorem one_step_after {X : Type*} [MetricSpace X] (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ)
    (T : ℕ → ℝ → X → X) (B : Set X) (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (n : ℕ) :
    w (n + 1) n = step b r T (n + 1) (w (n + 1) (n + 1)) :=
  hw.1 (n + 1) n (Nat.lt_succ_self n)

/-! ## (K-lip) only on a window of the marginal coordinate -/

section Window

variable {X : Type*} [MetricSpace X]

omit [MetricSpace X] in
/-- An orbit that stays in the window `u ≥ a` is an orbit of the maps with `u` clamped. -/
theorem clamp_orbit (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (a : ℝ) (n : ℕ)
    (w : ℕ → ℝ × X) (hw : IsOrbit b r T n w) (ha : ∀ k ≤ n, a ≤ (w k).1) :
    IsOrbit b (fun k u v => r k (max u a) v) (fun k u v => T k (max u a) v) n w := by
  intro k hk
  rw [hw k hk]
  simp only [step, max_eq_left (ha (k + 1) (Nat.succ_le_of_lt hk))]

/-- (K-lip) on the window `u, u' ≥ a` gives (K-lip) for all `u, u'` of the clamped maps. -/
theorem clamp_lip (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (B : Set X) (ε c c' τ a : ℝ)
    (hε : 0 ≤ ε) (hc' : 0 ≤ c')
    (hr : ∀ k u u', a ≤ u → a ≤ u' → ∀ v ∈ B, ∀ v' ∈ B,
      |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
    (hT : ∀ k u u', a ≤ u → a ≤ u' → ∀ v ∈ B, ∀ v' ∈ B,
      dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v') :
    (∀ k u u', ∀ v ∈ B, ∀ v' ∈ B,
      |r k (max u a) v - r k (max u' a) v'| ≤ ε * |u - u'| + c * dist v v') ∧
    (∀ k u u', ∀ v ∈ B, ∀ v' ∈ B,
      dist (T k (max u a) v) (T k (max u' a) v') ≤ c' * |u - u'| + τ * dist v v') := by
  refine ⟨fun k u u' v hv v' hv' => ?_, fun k u u' v hv v' hv' => ?_⟩
  · have h := hr k (max u a) (max u' a) (le_max_right _ _) (le_max_right _ _) v hv v' hv'
    have hm := abs_max_sub_max_le_abs u u' a
    nlinarith [mul_le_mul_of_nonneg_left hm hε]
  · have h := hT k (max u a) (max u' a) (le_max_right _ _) (le_max_right _ _) v hv v' hv'
    have hm := abs_max_sub_max_le_abs u u' a
    nlinarith [mul_le_mul_of_nonneg_left hm hc']

omit [MetricSpace X] in
/-- A family of orbits staying in the window is admissible for the clamped maps. -/
theorem clamp_admissible (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (B : Set X)
    (ub a : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w)
    (hwin : ∀ n, ∀ k ≤ n, a ≤ (w n k).1) :
    Admissible b (fun k u v => r k (max u a) v) (fun k u v => T k (max u a) v) B ub w :=
  ⟨fun n => clamp_orbit b r T a n (w n) (hw.1 n) (hwin n), hw.2.1, hw.2.2⟩

section WindowHyp

variable (b : ℕ → ℝ) (r : ℕ → ℝ → X → ℝ) (T : ℕ → ℝ → X → X) (B : Set X)
  (ε c c' τ D θ a : ℝ) (hε : 0 ≤ ε) (hc : 0 ≤ c) (hc' : 0 ≤ c') (hτ : 0 ≤ τ) (hD : 0 ≤ D)
  (hτθ : τ < θ) (hθ : θ < 1 - ε) (hq : (c * c' / (1 - ε - θ) + τ) / θ < 1)
  (hr : ∀ k u u', a ≤ u → a ≤ u' → ∀ v ∈ B, ∀ v' ∈ B,
    |r k u v - r k u' v'| ≤ ε * |u - u'| + c * dist v v')
  (hT : ∀ k u u', a ≤ u → a ≤ u' → ∀ v ∈ B, ∀ v' ∈ B,
    dist (T k u v) (T k u' v') ≤ c' * |u - u'| + τ * dist v v')
  (hB : ∀ v ∈ B, ∀ v' ∈ B, dist v v' ≤ D)

include hε hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- `coarse_step` with (K-lip) assumed only for `u, u' ≥ a`, for orbits staying in `u ≥ a`. -/
theorem coarse_step_window (ub : ℝ) (w : ℕ → ℕ → ℝ × X) (hw : Admissible b r T B ub w)
    (hwin : ∀ n, ∀ k ≤ n, a ≤ (w n k).1) (n : ℕ) :
    dist (w (n + 1) 0).2 (w n 0).2 ≤ D * θ ^ n := by
  obtain ⟨hr', hT'⟩ := clamp_lip r T B ε c c' τ a hε hc' hr hT
  exact coarse_step b _ _ B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr' hT' hB ub w
    (clamp_admissible b r T B ub a w hw hwin) n

include hε hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- `coarse_tendsto` with (K-lip) only on the window. -/
theorem coarse_tendsto_window [CompleteSpace X] (ub : ℝ) (w : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hwin : ∀ n, ∀ k ≤ n, a ≤ (w n k).1) :
    ∃ v : X, Tendsto (fun n => (w n 0).2) atTop (𝓝 v) := by
  obtain ⟨hr', hT'⟩ := clamp_lip r T B ε c c' τ a hε hc' hr hT
  exact coarse_tendsto b _ _ B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr' hT' hB hε ub w
    (clamp_admissible b r T B ub a w hw hwin)

include hε hc hc' hτ hD hτθ hθ hq hr hT hB in
/-- `limit_independent` with (K-lip) only on the window. -/
theorem limit_independent_window (ub : ℝ) (w w' : ℕ → ℕ → ℝ × X)
    (hw : Admissible b r T B ub w) (hw' : Admissible b r T B ub w')
    (hwin : ∀ n, ∀ k ≤ n, a ≤ (w n k).1) (hwin' : ∀ n, ∀ k ≤ n, a ≤ (w' n k).1) (v v' : X)
    (hv : Tendsto (fun n => (w n 0).2) atTop (𝓝 v))
    (hv' : Tendsto (fun n => (w' n 0).2) atTop (𝓝 v')) : v = v' := by
  obtain ⟨hr', hT'⟩ := clamp_lip r T B ε c c' τ a hε hc' hr hT
  exact limit_independent b _ _ B ε c c' τ D θ hc hc' hτ hD hτθ hθ hq hr' hT' hB hε ub w w'
    (clamp_admissible b r T B ub a w hw hwin) (clamp_admissible b r T B ub a w' hw' hwin')
    v v' hv hv'

end WindowHyp

end Window

end SkewOrbitProbe

#check @SkewOrbit.IsOrbit
#check @SkewOrbit.Admissible
#print axioms SkewOrbit.IsOrbit.mono
#print axioms SkewOrbitProbe.one_step_after
#print axioms SkewOrbitProbe.Ex.admissible
#print axioms SkewOrbitProbe.Ex.hr
#print axioms SkewOrbitProbe.Ex.hT
#print axioms SkewOrbitProbe.Ex.hB
#print axioms SkewOrbitProbe.Ex.params
#print axioms SkewOrbitProbe.Ex.coarse_converges
#print axioms SkewOrbitProbe.Ex.bare_not_cauchy
#print axioms SkewOrbitProbe.Ex.matching_needed
#print axioms SkewOrbitProbe.theta_exists_iff
#print axioms SkewOrbitProbe.rate_window
#print axioms SkewOrbitProbe.Sharp.theta_minus
#print axioms SkewOrbitProbe.Sharp.hyps
#print axioms SkewOrbitProbe.Sharp.sharp
#print axioms SkewOrbitProbe.Sharp.window_ok
#print axioms SkewOrbitProbe.clamp_orbit
#print axioms SkewOrbitProbe.clamp_lip
#print axioms SkewOrbitProbe.clamp_admissible
#print axioms SkewOrbitProbe.coarse_step_window
#print axioms SkewOrbitProbe.coarse_tendsto_window
#print axioms SkewOrbitProbe.limit_independent_window
