/-
The determinant kernel lemma: the algebraic core of reflection positivity for the determinant-weighted
(Wilson fermion) measure, without Grassmann variables.

Paper side: and 着想 1. For Wilson fermions (r = 1,
antiperiodic in the reflected direction) the Dirac matrix splits across the reflection planes as
  det D[U₊, U₀, θU₊'] = det [[N, A₁], [−A₂, N'ᴴ]],
`N = N(U₀, U₊)` the block of the positive side, `A₁, A₂ ⪰ 0` the hopping-free parts on the two planes
(`A = m + 4 − ½ Σ_{i≤3}(T_i + T_iᴴ)`, positive definite for m > −1).  That this block form holds for the lattice
operator is on paper (numerics in a generating script); the statements below are for arbitrary matrices.

Contents
* `det_mul_eq_sum_fun`                      : half Cauchy–Binet, det(A B) = Σ_p (Π_i A i (p i)) det(B[p,:]).
* `sum_det_submatrix_mul_det_submatrix`     : Cauchy–Binet indexed by functions,
                                              Σ_p det(Aᵀ[p,:]) det(B[p,:]) = n! det(A B).
* `factorial_mul_det_conjTranspose_mul`     : Hermitian form, n! det(C'ᴴ C) = Σ_p conj(det C'[p,:]) det C[p,:].
* `det_conjTranspose_mul_kernel`, `…_nonneg`: (C', C) ↦ det(C'ᴴ C) is a positive semidefinite kernel
                                              (an explicit sum of squares).
* `det_fromBlocks_swap`, `det_fromBlocks_posDef_eq` : the block form and its Schur complement on the `A₁` side.
* `block_det_kernel_posDef`                 : (N', N) ↦ det [[N, A₁], [−A₂, N'ᴴ]] is a positive semidefinite
                                              kernel for A₁ ≻ 0, A₂ ⪰ 0.
* `block_det_kernel_posSemidef`             : the same for A₁ ⪰ 0 (limit ε → 0 of A₁ + ε).
-/
import Mathlib

namespace FermionDetKernel

open Matrix Finset
open scoped ComplexOrder MatrixOrder

variable {n N : Type*} [Fintype n] [DecidableEq n] [Fintype N] [DecidableEq N]

set_option linter.unusedSectionVars false

section CauchyBinet

variable {R : Type*} [CommRing R]

/-- Half Cauchy–Binet: expanding the rows of `A * B` along `A`. -/
theorem det_mul_eq_sum_fun (A : Matrix n N R) (B : Matrix N n R) :
    (A * B).det = ∑ p : n → N, (∏ i, A i (p i)) * (B.submatrix p id).det := by
  have hL : (A * B).det = ((A * B)ᵀ).det := (det_transpose _).symm
  have hR : ∀ p : n → N, (B.submatrix p id).det = ((B.submatrix p id)ᵀ).det :=
    fun p => (det_transpose _).symm
  rw [hL]
  simp only [hR]
  simp only [det_apply', transpose_apply, mul_apply, submatrix_apply, id_eq]
  simp only [Finset.prod_univ_sum, Fintype.piFinset_univ, Finset.mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun p _ => Finset.sum_congr rfl fun σ _ => ?_
  rw [Finset.prod_mul_distrib]
  ring

/-- Cauchy–Binet indexed by functions `p : n → N` (non-injective `p` contribute zero; each `n`-subset is
counted `n!` times). -/
theorem sum_det_submatrix_mul_det_submatrix (A : Matrix n N R) (B : Matrix N n R) :
    ∑ p : n → N, (Aᵀ.submatrix p id).det * (B.submatrix p id).det
      = ((Fintype.card n).factorial : R) * (A * B).det := by
  have hA : ∀ p : n → N, (Aᵀ.submatrix p id).det
      = ∑ σ : Equiv.Perm n, ((Equiv.Perm.sign σ : ℤ) : R) * ∏ i, A i (p (σ i)) := by
    intro p
    rw [det_apply']
    simp only [submatrix_apply, transpose_apply, id_eq]
  have hσ : ∀ σ : Equiv.Perm n,
      ∑ p : n → N, ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (p (σ i))) * (B.submatrix p id).det
        = (A * B).det := by
    intro σ
    obtain ⟨e, he⟩ : ∃ e : (n → N) ≃ (n → N), ∀ q i, e q i = q (σ.symm i) :=
      ⟨Equiv.arrowCongr σ (Equiv.refl N), fun q i => rfl⟩
    have hterm : ∀ q : n → N,
        ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (e q (σ i))) * (B.submatrix (e q) id).det
          = (∏ i, A i (q i)) * (B.submatrix q id).det := by
      intro q
      have h1 : (B.submatrix (e q) id).det
          = ((Equiv.Perm.sign σ : ℤ) : R) * (B.submatrix q id).det := by
        have h2 : B.submatrix (e q) id = (B.submatrix q id).submatrix (σ.symm : n → n) id := by
          ext i j
          simp only [submatrix_apply, he, id_eq]
        rw [h2, det_permute, Equiv.Perm.sign_symm]
      have h3 : ∏ i, A i (e q (σ i)) = ∏ i, A i (q i) := by
        refine Finset.prod_congr rfl fun i _ => ?_
        rw [he, Equiv.symm_apply_apply]
      rw [h1, h3]
      rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with h | h <;> simp [h]
    calc ∑ p : n → N,
          ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (p (σ i))) * (B.submatrix p id).det
        = ∑ q : n → N,
          ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (e q (σ i))) * (B.submatrix (e q) id).det :=
          (Equiv.sum_comp e (fun p : n → N =>
            ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (p (σ i))) * (B.submatrix p id).det)).symm
      _ = ∑ q : n → N, (∏ i, A i (q i)) * (B.submatrix q id).det :=
          Finset.sum_congr rfl fun q _ => hterm q
      _ = (A * B).det := (det_mul_eq_sum_fun A B).symm
  calc ∑ p : n → N, (Aᵀ.submatrix p id).det * (B.submatrix p id).det
      = ∑ p : n → N, ∑ σ : Equiv.Perm n,
          ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (p (σ i))) * (B.submatrix p id).det := by
        refine Finset.sum_congr rfl fun p _ => ?_
        rw [hA p, Finset.sum_mul]
    _ = ∑ σ : Equiv.Perm n, ∑ p : n → N,
          ((Equiv.Perm.sign σ : ℤ) : R) * (∏ i, A i (p (σ i))) * (B.submatrix p id).det :=
        Finset.sum_comm
    _ = ∑ _σ : Equiv.Perm n, (A * B).det := Finset.sum_congr rfl fun σ _ => hσ σ
    _ = ((Fintype.card n).factorial : R) * (A * B).det := by
        rw [Finset.sum_const, Finset.card_univ, Fintype.card_perm, nsmul_eq_mul]

end CauchyBinet

section Kernel

/-- Cauchy–Binet in Hermitian form. -/
theorem factorial_mul_det_conjTranspose_mul (C' C : Matrix N n ℂ) :
    ((Fintype.card n).factorial : ℂ) * (C'ᴴ * C).det
      = ∑ p : n → N, star ((C'.submatrix p id).det) * (C.submatrix p id).det := by
  rw [← sum_det_submatrix_mul_det_submatrix C'ᴴ C]
  refine Finset.sum_congr rfl fun p _ => ?_
  have h : (C'ᴴ)ᵀ.submatrix p id = ((C'.submatrix p id)ᴴ)ᵀ := by
    ext i j
    simp only [submatrix_apply, transpose_apply, conjTranspose_apply, id_eq]
  rw [h, det_transpose, det_conjTranspose]

/-- **The determinant kernel is a sum of squares.**  For a finite family `C a : Matrix N n ℂ` and coefficients
`c a`, with `S p = Σ_b c_b det(C_b[p,:])`:
`n! Σ_{a,b} conj(c_a) c_b det(C_aᴴ C_b) = Σ_p conj(S p) S p`. -/
theorem det_conjTranspose_mul_kernel {ι : Type*} [Fintype ι] (c : ι → ℂ) (C : ι → Matrix N n ℂ) :
    ((Fintype.card n).factorial : ℂ) * ∑ a, ∑ b, star (c a) * c b * ((C a)ᴴ * C b).det
      = ∑ p : n → N, star (∑ b, c b * ((C b).submatrix p id).det)
          * ∑ b, c b * ((C b).submatrix p id).det := by
  have h1 : ∀ p : n → N, star (∑ b, c b * ((C b).submatrix p id).det)
        * ∑ b, c b * ((C b).submatrix p id).det
      = ∑ a, ∑ b, star (c a) * c b
          * (star (((C a).submatrix p id).det) * ((C b).submatrix p id).det) := by
    intro p
    rw [star_sum (R := ℂ), Finset.sum_mul_sum]
    refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => ?_
    rw [star_mul']
    ring
  have h2 : ∀ a b, ((Fintype.card n).factorial : ℂ) * (star (c a) * c b * ((C a)ᴴ * C b).det)
      = ∑ p : n → N, star (c a) * c b
          * (star (((C a).submatrix p id).det) * ((C b).submatrix p id).det) := by
    intro a b
    rw [← Finset.mul_sum, ← factorial_mul_det_conjTranspose_mul]
    ring
  calc ((Fintype.card n).factorial : ℂ) * ∑ a, ∑ b, star (c a) * c b * ((C a)ᴴ * C b).det
      = ∑ a, ∑ b, ∑ p : n → N, star (c a) * c b
          * (star (((C a).submatrix p id).det) * ((C b).submatrix p id).det) := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl fun a _ => ?_
        rw [Finset.mul_sum]
        exact Finset.sum_congr rfl fun b _ => h2 a b
    _ = ∑ a, ∑ p : n → N, ∑ b, star (c a) * c b
          * (star (((C a).submatrix p id).det) * ((C b).submatrix p id).det) :=
        Finset.sum_congr rfl fun a _ => Finset.sum_comm
    _ = ∑ p : n → N, ∑ a, ∑ b, star (c a) * c b
          * (star (((C a).submatrix p id).det) * ((C b).submatrix p id).det) := Finset.sum_comm
    _ = ∑ p : n → N, star (∑ b, c b * ((C b).submatrix p id).det)
          * ∑ b, c b * ((C b).submatrix p id).det :=
        Finset.sum_congr rfl fun p _ => (h1 p).symm

/-- **Positivity of the determinant kernel** `(C', C) ↦ det(C'ᴴ C)`: the Hermitian form is a nonnegative real. -/
theorem det_conjTranspose_mul_kernel_nonneg {ι : Type*} [Fintype ι] (c : ι → ℂ)
    (C : ι → Matrix N n ℂ) :
    ∃ r : ℝ, 0 ≤ r ∧ ∑ a, ∑ b, star (c a) * c b * ((C a)ᴴ * C b).det = (r : ℂ) := by
  have hk := det_conjTranspose_mul_kernel c C
  have hne : ((Fintype.card n).factorial : ℂ) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero _)
  refine ⟨(∑ p : n → N, Complex.normSq (∑ b, c b * ((C b).submatrix p id).det))
      / (Fintype.card n).factorial,
    div_nonneg (Finset.sum_nonneg fun p _ => Complex.normSq_nonneg _) (Nat.cast_nonneg _), ?_⟩
  rw [Complex.ofReal_div, Complex.ofReal_sum, Complex.ofReal_natCast, eq_div_iff hne, mul_comm, hk]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [Complex.normSq_eq_conj_mul_self]
  rfl

end Kernel

section Blocks

/-- Swapping the two block columns (and a sign): `det [[N, A₁], [−A₂, N']] = det [[A₁, −N], [N', A₂]]`. -/
theorem det_fromBlocks_swap {R : Type*} [CommRing R] (Nm A₁ A₂ N' : Matrix n n R) :
    (fromBlocks Nm A₁ (-A₂) N').det = (fromBlocks A₁ (-Nm) N' A₂).det := by
  have hJ : (fromBlocks (0 : Matrix n n R) (-1) 1 (0 : Matrix n n R)).det = 1 := by
    have h : fromBlocks (0 : Matrix n n R) (-1) 1 (0 : Matrix n n R)
        = fromBlocks (1 : Matrix n n R) (-1) 0 (1 : Matrix n n R)
          * fromBlocks (1 : Matrix n n R) 0 1 (1 : Matrix n n R)
          * fromBlocks (1 : Matrix n n R) (-1) 0 (1 : Matrix n n R) := by
      simp [fromBlocks_multiply]
    rw [h, det_mul, det_mul, det_fromBlocks_zero₂₁, det_fromBlocks_zero₁₂]
    simp
  have hmul : fromBlocks Nm A₁ (-A₂) N' * fromBlocks (0 : Matrix n n R) (-1) 1 (0 : Matrix n n R)
      = fromBlocks A₁ (-Nm) N' A₂ := by
    simp [fromBlocks_multiply]
  rw [← hmul, det_mul, hJ, mul_one]

/-- Schur complement on the `A₁` side (no invertibility of `N` or `N'` is needed). -/
theorem det_fromBlocks_posDef_eq (A₁ A₂ Nm N' : Matrix n n ℂ) (hA₁ : A₁.PosDef) :
    (fromBlocks Nm A₁ (-A₂) N').det = A₁.det * (A₂ + N' * A₁⁻¹ * Nm).det := by
  rw [det_fromBlocks_swap]
  have : Invertible A₁ := hA₁.isUnit.invertible
  rw [det_fromBlocks₁₁, invOf_eq_nonsing_inv]
  congr 2
  rw [mul_neg, sub_neg_eq_add]

/-- A positive semidefinite complex matrix is `Sᴴ S`. -/
theorem exists_eq_conjTranspose_mul_self {A : Matrix n n ℂ} (hA : A.PosSemidef) :
    ∃ S : Matrix n n ℂ, A = Sᴴ * S := by
  have h0 : (0 : Matrix n n ℂ) ≤ A := hA.nonneg
  refine ⟨CFC.sqrt A, ?_⟩
  have h2 : (CFC.sqrt A)ᴴ = CFC.sqrt A := (CFC.sqrt_nonneg A).posSemidef.1
  rw [h2]
  exact (CFC.sqrt_mul_sqrt_self A h0).symm

/-- **Block determinant kernel, `A₁ ≻ 0`.**  `(N', N) ↦ det [[N, A₁], [−A₂, N'ᴴ]]` is a positive semidefinite
kernel on all complex `n × n` matrices: for every finite family `Nf` and coefficients `c`, the Hermitian form is
a nonnegative real.  (`N`, `N'` arbitrary — not assumed invertible.) -/
theorem block_det_kernel_posDef {ι : Type*} [Fintype ι] (A₁ A₂ : Matrix n n ℂ)
    (hA₁ : A₁.PosDef) (hA₂ : A₂.PosSemidef) (c : ι → ℂ) (Nf : ι → Matrix n n ℂ) :
    ∃ r : ℝ, 0 ≤ r ∧
      ∑ a, ∑ b, star (c a) * c b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det = (r : ℂ) := by
  obtain ⟨S, hS⟩ := exists_eq_conjTranspose_mul_self hA₂
  obtain ⟨Rm, hR⟩ := exists_eq_conjTranspose_mul_self hA₁.inv.posSemidef
  have hmat : ∀ a b, A₂ + (Nf a)ᴴ * A₁⁻¹ * Nf b
      = (fromRows S (Rm * Nf a))ᴴ * fromRows S (Rm * Nf b) := by
    intro a b
    rw [conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromRows,
      conjTranspose_mul, hR, ← hS]
    simp only [Matrix.mul_assoc]
  have hker : ∀ a b, (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det
      = A₁.det * ((fromRows S (Rm * Nf a))ᴴ * fromRows S (Rm * Nf b)).det := by
    intro a b
    rw [det_fromBlocks_posDef_eq _ _ _ _ hA₁, hmat]
  obtain ⟨r', hr', hsum⟩ :=
    det_conjTranspose_mul_kernel_nonneg c (fun a => fromRows S (Rm * Nf a))
  have hdet := Complex.lt_def.mp hA₁.det_pos
  have hdre : (0 : ℝ) < A₁.det.re := by simpa using hdet.1
  have hdim : A₁.det.im = 0 := by simpa using hdet.2.symm
  have hdeq : A₁.det = ((A₁.det.re : ℝ) : ℂ) := by
    apply Complex.ext <;> simp [hdim]
  refine ⟨A₁.det.re * r', mul_nonneg hdre.le hr', ?_⟩
  simp only [hker]
  rw [Complex.ofReal_mul, ← hdeq, ← hsum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun b _ => ?_
  ring

/-- **Block determinant kernel, `A₁ ⪰ 0`.**  The same positivity when `A₁` is only positive semidefinite
(the limit `ε → 0` of `A₁ + ε`). -/
theorem block_det_kernel_posSemidef {ι : Type*} [Fintype ι] (A₁ A₂ : Matrix n n ℂ)
    (hA₁ : A₁.PosSemidef) (hA₂ : A₂.PosSemidef) (c : ι → ℂ) (Nf : ι → Matrix n n ℂ) :
    0 ≤ (∑ a, ∑ b, star (c a) * c b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det).re ∧
      (∑ a, ∑ b, star (c a) * c b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det).im = 0 := by
  obtain ⟨F, hF⟩ : ∃ F : ℝ → ℂ, ∀ ε : ℝ, F ε = ∑ a, ∑ b, star (c a) * c b *
      (fromBlocks (Nf b) (A₁ + (ε : ℂ) • (1 : Matrix n n ℂ)) (-A₂) (Nf a)ᴴ).det :=
    ⟨_, fun ε => rfl⟩
  have hcont : Continuous F := by
    have hF' : F = fun ε : ℝ => ∑ a, ∑ b, star (c a) * c b *
        (fromBlocks (Nf b) (A₁ + (ε : ℂ) • (1 : Matrix n n ℂ)) (-A₂) (Nf a)ᴴ).det :=
      funext hF
    rw [hF']
    refine continuous_finsetSum _ fun a _ => continuous_finsetSum _ fun b _ => ?_
    refine continuous_const.mul ?_
    refine Continuous.matrix_det ?_
    refine Continuous.matrix_fromBlocks continuous_const ?_ continuous_const continuous_const
    exact continuous_const.add (Complex.continuous_ofReal.smul continuous_const)
  have hpos : ∀ ε : ℝ, 0 < ε → 0 ≤ (F ε).re ∧ (F ε).im = 0 := by
    intro ε hε
    have hd : ((ε : ℂ) • (1 : Matrix n n ℂ)).PosDef := by
      rw [smul_one_eq_diagonal]
      exact PosDef.diagonal fun _ => Complex.zero_lt_real.mpr hε
    have hPD : (A₁ + (ε : ℂ) • (1 : Matrix n n ℂ)).PosDef := PosDef.posSemidef_add hA₁ hd
    obtain ⟨r, hr, hsum⟩ := block_det_kernel_posDef _ A₂ hPD hA₂ c Nf
    rw [hF ε, hsum]
    exact ⟨by simpa using hr, by simp⟩
  have hF0 : F 0 = ∑ a, ∑ b, star (c a) * c b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det := by
    rw [hF 0]
    simp
  rw [← hF0]
  have hlim : Filter.Tendsto F (nhdsWithin 0 (Set.Ioi 0)) (nhds (F 0)) :=
    (hcont.tendsto 0).mono_left nhdsWithin_le_nhds
  have hev : ∀ᶠ ε in nhdsWithin (0 : ℝ) (Set.Ioi 0), 0 < ε := self_mem_nhdsWithin
  constructor
  · have hre : Filter.Tendsto (fun ε => (F ε).re) (nhdsWithin 0 (Set.Ioi 0)) (nhds (F 0).re) :=
      (Complex.continuous_re.tendsto _).comp hlim
    exact ge_of_tendsto hre (hev.mono fun ε hε => (hpos ε hε).1)
  · have him : Filter.Tendsto (fun ε => (F ε).im) (nhdsWithin 0 (Set.Ioi 0)) (nhds (F 0).im) :=
      (Complex.continuous_im.tendsto _).comp hlim
    have him0 : Filter.Tendsto (fun ε => (F ε).im) (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) :=
      tendsto_const_nhds.congr' (hev.mono fun ε hε => ((hpos ε hε).2).symm)
    exact tendsto_nhds_unique him him0

end Blocks

section MatrixForm

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Matrix form: `K a b = det(C_aᴴ C_b)` is a positive semidefinite matrix. -/
theorem det_conjTranspose_mul_matrix_posSemidef (C : ι → Matrix N n ℂ) :
    (Matrix.of fun a b => ((C a)ᴴ * C b).det : Matrix ι ι ℂ).PosSemidef := by
  refine PosSemidef.of_dotProduct_mulVec_nonneg ?_ ?_
  · refine IsHermitian.ext fun a b => ?_
    rw [Matrix.of_apply, Matrix.of_apply, ← det_conjTranspose, conjTranspose_mul,
      conjTranspose_conjTranspose]
  · intro x
    obtain ⟨r, hr, hsum⟩ := det_conjTranspose_mul_kernel_nonneg x C
    have h : star x ⬝ᵥ ((Matrix.of fun a b => ((C a)ᴴ * C b).det : Matrix ι ι ℂ) *ᵥ x)
        = ∑ a, ∑ b, star (x a) * x b * ((C a)ᴴ * C b).det := by
      simp only [dotProduct, mulVec, Matrix.of_apply, Pi.star_apply, Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => ?_
      ring
    rw [h, hsum]
    exact Complex.zero_le_real.mpr hr

/-- Gram representation of the block determinant for `A₁ ≻ 0`, `A₂ ⪰ 0`:
`det [[N, A₁], [−A₂, N'ᴴ]] = d · det(C(N')ᴴ C(N))`, `d = det A₁ > 0`, `C(N) = [[S], [R N]]`. -/
theorem block_det_eq_gram (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosDef) (hA₂ : A₂.PosSemidef) :
    ∃ (S Rm : Matrix n n ℂ) (d : ℝ), 0 < d ∧ ∀ Nm N' : Matrix n n ℂ,
      (fromBlocks Nm A₁ (-A₂) N'ᴴ).det
        = (d : ℂ) * ((fromRows S (Rm * N'))ᴴ * fromRows S (Rm * Nm)).det := by
  obtain ⟨S, hS⟩ := exists_eq_conjTranspose_mul_self hA₂
  obtain ⟨Rm, hR⟩ := exists_eq_conjTranspose_mul_self hA₁.inv.posSemidef
  have hdet := Complex.lt_def.mp hA₁.det_pos
  have hdre : (0 : ℝ) < A₁.det.re := by simpa using hdet.1
  have hdim : A₁.det.im = 0 := by simpa using hdet.2.symm
  have hdeq : A₁.det = ((A₁.det.re : ℝ) : ℂ) := by
    apply Complex.ext <;> simp [hdim]
  refine ⟨S, Rm, A₁.det.re, hdre, fun Nm N' => ?_⟩
  have hmat : A₂ + N'ᴴ * A₁⁻¹ * Nm = (fromRows S (Rm * N'))ᴴ * fromRows S (Rm * Nm) := by
    rw [conjTranspose_fromRows_eq_fromCols_conjTranspose, fromCols_mul_fromRows,
      conjTranspose_mul, hR, ← hS]
    simp only [Matrix.mul_assoc]
  rw [det_fromBlocks_posDef_eq _ _ _ _ hA₁, hmat, ← hdeq]

/-- **Matrix form of the block determinant kernel** (`A₁ ≻ 0`, `A₂ ⪰ 0`):
`K a b = det [[N_b, A₁], [−A₂, N_aᴴ]]` is a positive semidefinite matrix. -/
theorem block_det_matrix_posSemidef (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosDef)
    (hA₂ : A₂.PosSemidef) (Nf : ι → Matrix n n ℂ) :
    (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det : Matrix ι ι ℂ).PosSemidef := by
  obtain ⟨S, Rm, d, hd, hrep⟩ := block_det_eq_gram A₁ A₂ hA₁ hA₂
  have hsd : star (d : ℂ) = (d : ℂ) := Complex.conj_ofReal d
  refine PosSemidef.of_dotProduct_mulVec_nonneg ?_ ?_
  · refine IsHermitian.ext fun a b => ?_
    rw [Matrix.of_apply, Matrix.of_apply, hrep, hrep, star_mul', hsd, ← det_conjTranspose,
      conjTranspose_mul, conjTranspose_conjTranspose]
  · intro x
    obtain ⟨r, hr, hsum⟩ := block_det_kernel_posDef A₁ A₂ hA₁ hA₂ x Nf
    have h : star x ⬝ᵥ ((Matrix.of fun a b =>
          (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det : Matrix ι ι ℂ) *ᵥ x)
        = ∑ a, ∑ b, star (x a) * x b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det := by
      simp only [dotProduct, mulVec, Matrix.of_apply, Pi.star_apply, Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => ?_
      ring
    rw [h, hsum]
    exact Complex.zero_le_real.mpr hr

/-- **`N_f` flavours.**  The entrywise power `K a b ^ k` of the block determinant kernel is again a positive
semidefinite matrix (Schur product).  `k = 2` is the weight `det(D + m)²` of two degenerate Wilson flavours. -/
theorem block_det_matrix_pow_posSemidef (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosDef)
    (hA₂ : A₂.PosSemidef) (Nf : ι → Matrix n n ℂ) (k : ℕ) :
    (Matrix.of fun a b =>
      (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ k : Matrix ι ι ℂ).PosSemidef := by
  induction k with
  | zero =>
    have h1 : (Matrix.of fun a b =>
        (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ 0 : Matrix ι ι ℂ)
        = vecMulVec (star fun _ : ι => (1 : ℂ)) (fun _ : ι => (1 : ℂ)) := by
      ext a b
      simp [vecMulVec_apply]
    rw [h1]
    exact posSemidef_vecMulVec_star_self _
  | succ k ih =>
    have h1 : (Matrix.of fun a b =>
        (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ (k + 1) : Matrix ι ι ℂ)
        = Matrix.hadamard
            (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ k)
            (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det) := by
      ext a b
      simp only [Matrix.of_apply, Matrix.hadamard_apply, pow_succ]
    rw [h1]
    exact ih.hadamard (block_det_matrix_posSemidef A₁ A₂ hA₁ hA₂ Nf)

end MatrixForm

end FermionDetKernel


-- ===== part : DetIntegral.part.lean =====

/-! # Integral form of the determinant kernel, and the plane matrix of the Wilson operator


* `wilson_plane_posDef` : for unitary `T_i` and `m > −1` the plane matrix
  `A = (m + 1) + Σ_i (1 − ½(T_i + T_iᴴ))  (= (m + 1 + d) − ½ Σ_i (T_i + T_iᴴ))` is positive definite; this is the
  hypothesis `A₁.PosDef` of the kernel lemma for the Wilson operator with `r = 1`.
* `det_kernel_integral_nonneg` : fibre form of the fermion version of Lemma 3 of paper A
  (`site_reflection_positive`): for fixed plane data `A₁ ≻ 0`, `A₂ ⪰ 0`, a continuous matrix-valued map `Nm` on a
  compact space and a bounded measurable real `g`,
  `∬ g(x) g(y) Re (det [[N(x), A₁], [−A₂, N(y)ᴴ]])^k dν(x) dν(y) ≥ 0`   (`k = N_f`). -/
namespace FermionDetIntegral

open Matrix Finset MeasureTheory
open scoped ComplexOrder MatrixOrder
open FermionDetKernel

variable {n : Type*} [Fintype n] [DecidableEq n]

set_option linter.unusedSectionVars false

/-! ## 1. The plane matrix -/

theorem one_sub_conjTranspose_mul_one_sub (T : Matrix n n ℂ) (hT : Tᴴ * T = 1) :
    (1 - T)ᴴ * (1 - T) = (2 : ℝ) • (1 : Matrix n n ℂ) - (T + Tᴴ) := by
  simp only [conjTranspose_sub, conjTranspose_one, Matrix.sub_mul, Matrix.mul_sub, Matrix.one_mul,
    Matrix.mul_one, hT, two_smul]
  abel

theorem wilson_plane_term (T : Matrix n n ℂ) (hT : Tᴴ * T = 1) :
    (1 : Matrix n n ℂ) - (1 / 2 : ℝ) • (T + Tᴴ) = (1 / 2 : ℝ) • ((1 - T)ᴴ * (1 - T)) := by
  rw [one_sub_conjTranspose_mul_one_sub T hT, smul_sub, smul_smul]
  norm_num

/-- **The plane matrix of the Wilson operator (r = 1) is positive definite for `m > −1`.**
`T i` are the unitary one-step shifts inside the plane (`d = 3` in four dimensions). -/
theorem wilson_plane_posDef {d : ℕ} (m : ℝ) (hm : -1 < m) (T : Fin d → Matrix n n ℂ)
    (hT : ∀ i, (T i)ᴴ * T i = 1) :
    ((m + 1 : ℝ) • (1 : Matrix n n ℂ)
      + ∑ i, ((1 : Matrix n n ℂ) - (1 / 2 : ℝ) • (T i + (T i)ᴴ))).PosDef := by
  have h1 : ((m + 1 : ℝ) • (1 : Matrix n n ℂ)).PosDef := PosDef.one.smul (by linarith)
  have h2 : (∑ i, ((1 : Matrix n n ℂ) - (1 / 2 : ℝ) • (T i + (T i)ᴴ))).PosSemidef := by
    refine posSemidef_sum _ fun i _ => ?_
    rw [wilson_plane_term (T i) (hT i)]
    exact (posSemidef_conjTranspose_mul_self _).smul (by norm_num)
  exact h1.add_posSemidef h2

/-- The same matrix in the usual form `(m + 1 + d) − ½ Σ_i (T_i + T_iᴴ)`. -/
theorem wilson_plane_eq {d : ℕ} (m : ℝ) (T : Fin d → Matrix n n ℂ) :
    (m + 1 : ℝ) • (1 : Matrix n n ℂ) + ∑ i, ((1 : Matrix n n ℂ) - (1 / 2 : ℝ) • (T i + (T i)ᴴ))
      = (m + 1 + d : ℝ) • (1 : Matrix n n ℂ) - (1 / 2 : ℝ) • ∑ i, (T i + (T i)ᴴ) := by
  rw [Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    ← Finset.smul_sum, add_smul (m + 1) (d : ℝ), Nat.cast_smul_eq_nsmul]
  abel

/-! ## 2. Integral form -/

/-- A kernel that is a finite sum of real squares has a nonnegative double integral. -/
theorem sos_kernel_integral_nonneg {X : Type*} [MeasurableSpace X] (ν : Measure X) [SFinite ν]
    {P : Type*} [Fintype P] (a b : P → X → ℝ) (ha : ∀ p, Integrable (a p) ν)
    (hb : ∀ p, Integrable (b p) ν) (c : ℝ) (hc : 0 ≤ c) :
    0 ≤ ∫ z : X × X, c * ∑ p, (a p z.1 * a p z.2 + b p z.1 * b p z.2) ∂(ν.prod ν) := by
  have hint : ∀ p, Integrable (fun z : X × X => a p z.1 * a p z.2 + b p z.1 * b p z.2)
      (ν.prod ν) := fun p => ((ha p).mul_prod (ha p)).add ((hb p).mul_prod (hb p))
  rw [integral_const_mul]
  refine mul_nonneg hc ?_
  rw [integral_finsetSum _ (fun p _ => hint p)]
  refine Finset.sum_nonneg fun p _ => ?_
  rw [integral_add ((ha p).mul_prod (ha p)) ((hb p).mul_prod (hb p)), integral_prod_mul,
    integral_prod_mul]
  exact add_nonneg (mul_self_nonneg _) (mul_self_nonneg _)

/-- **Sum-of-squares form of the block determinant kernel and its powers.**  For `A₁ ≻ 0`, `A₂ ⪰ 0` and a
continuous `Nm`, there are a constant `c ≥ 0` and finitely many continuous functions `Ψ p` with
`(det [[N(x), A₁], [−A₂, N(y)ᴴ]])^k = c · Σ_p Ψ_p(x) · conj Ψ_p(y)`. -/
theorem block_det_pow_sos {X : Type*} [TopologicalSpace X]
    (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosDef) (hA₂ : A₂.PosSemidef)
    (Nm : X → Matrix n n ℂ) (hN : Continuous Nm) (k : ℕ) :
    ∃ (c : ℝ) (Ψ : (Fin k → (n → n ⊕ n)) → X → ℂ), 0 ≤ c ∧ (∀ p, Continuous (Ψ p)) ∧
      ∀ x y, (fromBlocks (Nm x) A₁ (-A₂) (Nm y)ᴴ).det ^ k
        = (c : ℂ) * ∑ p, Ψ p x * star (Ψ p y) := by
  obtain ⟨S, Rm, d, hd, hrep⟩ := block_det_eq_gram A₁ A₂ hA₁ hA₂
  obtain ⟨φ, hφ⟩ : ∃ φ : (n → n ⊕ n) → X → ℂ,
      ∀ q x, φ q x = ((fromRows S (Rm * Nm x)).submatrix q id).det := ⟨_, fun q x => rfl⟩
  have hφc : ∀ q, Continuous (φ q) := by
    intro q
    have h0 : φ q = fun x => ((fromRows S (Rm * Nm x)).submatrix q id).det := funext (hφ q)
    rw [h0]
    refine Continuous.matrix_det ?_
    refine Continuous.matrix_submatrix ?_ q id
    refine continuous_matrix fun i j => ?_
    rcases i with i | i
    · show Continuous fun _ : X => S i j
      exact continuous_const
    · show Continuous fun x : X => (Rm * Nm x) i j
      exact (continuous_const.matrix_mul hN).matrix_elem i j
  have hne : ((Fintype.card n).factorial : ℂ) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.factorial_ne_zero _)
  have hK : ∀ x y, (fromBlocks (Nm x) A₁ (-A₂) (Nm y)ᴴ).det
      = ((d / (Fintype.card n).factorial : ℝ) : ℂ) * ∑ q, φ q x * star (φ q y) := by
    intro x y
    have h1 := factorial_mul_det_conjTranspose_mul (fromRows S (Rm * Nm y))
      (fromRows S (Rm * Nm x))
    simp only [← hφ] at h1
    have h2 : ((fromRows S (Rm * Nm y))ᴴ * fromRows S (Rm * Nm x)).det
        = ((Fintype.card n).factorial : ℂ)⁻¹ * ∑ q, φ q x * star (φ q y) := by
      rw [eq_inv_mul_iff_mul_eq₀ hne, h1]
      exact Finset.sum_congr rfl fun q _ => mul_comm _ _
    rw [hrep (Nm x) (Nm y), h2, Complex.ofReal_div, Complex.ofReal_natCast]
    ring
  refine ⟨(d / (Fintype.card n).factorial) ^ k, fun p x => ∏ j, φ (p j) x, by positivity,
    fun p => continuous_finsetProd _ fun j _ => hφc (p j), fun x y => ?_⟩
  rw [hK x y, mul_pow, Complex.ofReal_pow]
  congr 1
  rw [← Fin.prod_const, Finset.prod_univ_sum, Fintype.piFinset_univ]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [star_prod, Finset.prod_mul_distrib]

/-- **Fibre form of the fermion version of Lemma 3 (site reflection).**  For fixed plane data
`A₁ ≻ 0`, `A₂ ⪰ 0`, a continuous `Nm : X → Matrix n n ℂ` on a compact space with a finite measure, a bounded
measurable real `g` and `k` flavours, the double integral of
`g(x) g(y) Re (det [[N(x), A₁], [−A₂, N(y)ᴴ]])^k` is nonnegative. -/
theorem det_kernel_integral_nonneg {X : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] (ν : Measure X) [IsFiniteMeasure ν]
    (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosDef) (hA₂ : A₂.PosSemidef)
    (Nm : X → Matrix n n ℂ) (hN : Continuous Nm)
    (g : X → ℝ) (hg : Measurable g) (Cg : ℝ) (bg : ∀ x, |g x| ≤ Cg) (k : ℕ) :
    0 ≤ ∫ z : X × X, g z.1 * g z.2 *
      ((fromBlocks (Nm z.1) A₁ (-A₂) (Nm z.2)ᴴ).det ^ k).re ∂(ν.prod ν) := by
  obtain ⟨c, Ψ, hc, hΨc, hpow⟩ := block_det_pow_sos A₁ A₂ hA₁ hA₂ Nm hN k
  have hbound : ∀ F : X → ℝ, Continuous F → Integrable (fun x => g x * F x) ν := by
    intro F hF
    obtain ⟨C, hC⟩ := isCompact_univ.exists_bound_of_continuousOn hF.continuousOn
    refine Integrable.of_bound (hg.mul hF.measurable).aestronglyMeasurable (Cg * C) ?_
    refine Filter.Eventually.of_forall fun x => ?_
    rw [Real.norm_eq_abs, abs_mul]
    have h1 := bg x
    have h2 : |F x| ≤ C := by simpa using hC x (Set.mem_univ x)
    exact mul_le_mul h1 h2 (abs_nonneg _) (le_trans (abs_nonneg _) h1)
  obtain ⟨a, ha⟩ : ∃ a : (Fin k → (n → n ⊕ n)) → X → ℝ, ∀ p x, a p x = g x * (Ψ p x).re :=
    ⟨_, fun _ _ => rfl⟩
  obtain ⟨b, hb⟩ : ∃ b : (Fin k → (n → n ⊕ n)) → X → ℝ, ∀ p x, b p x = g x * (Ψ p x).im :=
    ⟨_, fun _ _ => rfl⟩
  have hai : ∀ p, Integrable (a p) ν := by
    intro p
    have h0 : a p = fun x => g x * (Ψ p x).re := funext (ha p)
    rw [h0]
    exact hbound _ (Complex.continuous_re.comp (hΨc p))
  have hbi : ∀ p, Integrable (b p) ν := by
    intro p
    have h0 : b p = fun x => g x * (Ψ p x).im := funext (hb p)
    rw [h0]
    exact hbound _ (Complex.continuous_im.comp (hΨc p))
  have hfun : (fun z : X × X => g z.1 * g z.2 *
        ((fromBlocks (Nm z.1) A₁ (-A₂) (Nm z.2)ᴴ).det ^ k).re)
      = fun z : X × X => c * ∑ p, (a p z.1 * a p z.2 + b p z.1 * b p z.2) := by
    funext z
    rw [hpow z.1 z.2, Complex.re_ofReal_mul, Complex.re_sum]
    simp only [ha, hb, Complex.mul_re, Complex.star_def, Complex.conj_re, Complex.conj_im,
      Finset.mul_sum]
    refine Finset.sum_congr rfl fun p _ => ?_
    ring
  rw [hfun]
  exact sos_kernel_integral_nonneg ν a b hai hbi c hc

/-- **Fermion version of Lemma 3 of paper A (site reflection, factorised form with the determinant kernel).**
`Y` carries the links inside the reflection planes (`U₀`), `X` the links of the open positive side (`U₊`; the
negative side is identified with it by the reflection).  Weight: `k(U₀) h(U₀,U₊) h(U₀,U₋)` (the Wilson gauge
weight, as in `site_reflection_positive`) times the real part of the `kf`-th power of the determinant kernel
`det [[N(U₀,U₊), A₁(U₀)], [−A₂(U₀), N(U₀,U₋)ᴴ]]` (`kf = N_f`).  For each `U₀` the plane matrices are assumed
`A₁(U₀) ≻ 0`, `A₂(U₀) ⪰ 0` and `U₊ ↦ N(U₀,U₊)` continuous; the kernel is assumed measurable and bounded as a
function of `(U₀, U₊, U₋)`.  No measurability in `U₀` of square roots is needed. -/
theorem site_reflection_positive_det {X Y : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (kf : ℕ) (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosDef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
    (bρ : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re| ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re
        ∂(μ₀.prod (ν.prod ν)) := by
  obtain ⟨ρ, hρ⟩ : ∃ ρ : Y × (X × X) → ℝ, ∀ p, ρ p =
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re :=
    ⟨_, fun _ => rfl⟩
  have hρm' : Measurable ρ := by
    have h0 : ρ = fun p : Y × (X × X) =>
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re :=
      funext hρ
    rw [h0]
    exact hρm
  obtain ⟨g, hgdef⟩ : ∃ g : Y × X → ℝ, ∀ q, g q = φ q * h q := ⟨_, fun _ => rfl⟩
  have hgm : Measurable g := by
    have h0 : g = fun q => φ q * h q := funext hgdef
    rw [h0]
    exact hφ.mul hh
  have bg : ∀ q, |g q| ≤ Cφ * Ch := by
    intro q
    rw [hgdef, abs_mul]
    exact mul_le_mul (bφ q) (bh q) (abs_nonneg _) (le_trans (abs_nonneg _) (bφ q))
  have hrw : (fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
      = fun p : Y × (X × X) => k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p) := by
    funext p
    rw [hgdef, hgdef, hρ]
    ring
  rw [hrw]
  have hm1 : Measurable fun p : Y × (X × X) => (p.1, p.2.1) :=
    measurable_fst.prodMk measurable_snd.fst
  have hm2 : Measurable fun p : Y × (X × X) => (p.1, p.2.2) :=
    measurable_fst.prodMk measurable_snd.snd
  have hmeas : Measurable fun p : Y × (X × X) =>
      k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p) :=
    (hk.comp measurable_fst).mul (((hgm.comp hm1).mul (hgm.comp hm2)).mul hρm')
  have hint : Integrable (fun p : Y × (X × X) =>
      k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p)) (μ₀.prod (ν.prod ν)) := by
    refine Integrable.of_bound hmeas.aestronglyMeasurable
      (Ck * ((Cφ * Ch) * (Cφ * Ch) * Cρ)) ?_
    refine Filter.Eventually.of_forall (fun p => ?_)
    rw [Real.norm_eq_abs, abs_mul, abs_mul, abs_mul]
    have h1 := bk p.1
    have h2 := bg (p.1, p.2.1)
    have h3 := bg (p.1, p.2.2)
    have h4 : |ρ p| ≤ Cρ := by rw [hρ]; exact bρ p
    have h23 : |g (p.1, p.2.1)| * |g (p.1, p.2.2)| ≤ (Cφ * Ch) * (Cφ * Ch) :=
      mul_le_mul h2 h3 (abs_nonneg _) (le_trans (abs_nonneg _) h2)
    have h234 : |g (p.1, p.2.1)| * |g (p.1, p.2.2)| * |ρ p| ≤ (Cφ * Ch) * (Cφ * Ch) * Cρ :=
      mul_le_mul h23 h4 (abs_nonneg _)
        (le_trans (mul_nonneg (abs_nonneg _) (abs_nonneg _)) h23)
    exact mul_le_mul h1 h234 (by positivity) (le_trans (abs_nonneg _) h1)
  have key : ∀ c : Y, 0 ≤ ∫ y : X × X, k c * (g (c, y.1) * g (c, y.2) * ρ (c, y)) ∂(ν.prod ν) := by
    intro c
    rw [integral_const_mul]
    refine mul_nonneg (hk0 c) ?_
    have hfib : 0 ≤ ∫ z : X × X, g (c, z.1) * g (c, z.2) *
        ((fromBlocks (Nm (c, z.1)) (A₁ c) (-(A₂ c)) (Nm (c, z.2))ᴴ).det ^ kf).re ∂(ν.prod ν) :=
      det_kernel_integral_nonneg ν (A₁ c) (A₂ c) (hA₁ c) (hA₂ c) (fun x => Nm (c, x)) (hN c)
        (fun x => g (c, x)) (hgm.comp measurable_prodMk_left) (Cφ * Ch) (fun x => bg (c, x)) kf
    have e : (fun y : X × X => g (c, y.1) * g (c, y.2) * ρ (c, y))
        = fun z : X × X => g (c, z.1) * g (c, z.2) *
          ((fromBlocks (Nm (c, z.1)) (A₁ c) (-(A₂ c)) (Nm (c, z.2))ᴴ).det ^ kf).re := by
      funext y
      rw [hρ]
    rw [e]
    exact hfib
  rw [integral_prod _ hint]
  apply integral_nonneg
  intro c
  exact key c

/-- The same as an integral against the weighted measure (`withDensity`): when the weight
`k h h · Re K^{kf}` is pointwise nonnegative (for the lattice: `K = det D[U]` is real and `kf` is even),
`∫ f(Θp) f(p) dμ ≥ 0` for `μ = (μ₀ ⊗ ν ⊗ ν).withDensity w`, `f(c,(a,b)) = φ(c,b)`, `Θ(c,(a,b)) = (c,(b,a))`. -/
theorem site_reflection_positive_det_measure {X Y : Type*} [TopologicalSpace X] [CompactSpace X]
    [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (kf : ℕ) (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosDef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) (hh0 : ∀ p, 0 ≤ h p)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
    (bρ : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re| ≤ Cρ)
    (hρ0 : ∀ p : Y × (X × X),
      0 ≤ ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re) :
    let w : Y × (X × X) → NNReal := fun p =>
      ⟨k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2) *
          ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re,
        mul_nonneg (mul_nonneg (mul_nonneg (hk0 _) (hh0 _)) (hh0 _)) (hρ0 p)⟩
    0 ≤ ∫ p, φ (p.1, p.2.1) * φ (p.1, p.2.2)
        ∂((μ₀.prod (ν.prod ν)).withDensity fun p => (w p : ENNReal)) := by
  intro w
  have hwm : Measurable w := by
    apply Measurable.subtype_mk
    exact (((hk.comp measurable_fst).mul
      (hh.comp (measurable_fst.prodMk measurable_snd.fst))).mul
      (hh.comp (measurable_fst.prodMk measurable_snd.snd))).mul hρm
  rw [integral_withDensity_eq_integral_smul hwm]
  have hmain := site_reflection_positive_det ν μ₀ kf A₁ A₂ hA₁ hA₂ Nm hN k h φ hk hh hφ
    Ck Ch Cφ Cρ bk bh bφ hk0 hρm bρ
  have e : ∀ p : Y × (X × X), w p • (φ (p.1, p.2.1) * φ (p.1, p.2.2)) =
      φ (p.1, p.2.1) * φ (p.1, p.2.2) * (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re := by
    intro p
    rw [NNReal.smul_def, smul_eq_mul]
    change (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2) *
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
      * (φ (p.1, p.2.1) * φ (p.1, p.2.2)) = _
    ring
  rw [integral_congr_ae (Filter.Eventually.of_forall e)]
  exact hmain

/-! ## 3. The weight is real: γ5-hermiticity -/

/-- If `Γ D Γ = Dᴴ` with `Γ² = 1` (γ5-hermiticity of the Wilson operator), then `det D` is real, and so
`(det D)²` is a nonnegative real: the weight of two degenerate flavours is nonnegative. -/
theorem det_real_of_gamma_hermitian (D Γ : Matrix n n ℂ) (hΓ : Γ * Γ = 1) (hD : Γ * D * Γ = Dᴴ) :
    D.det.im = 0 ∧ 0 ≤ (D.det ^ 2).re ∧ (D.det ^ 2).im = 0 := by
  have h1 : star D.det = D.det := by
    rw [← det_conjTranspose, ← hD, det_mul, det_mul, mul_right_comm, ← det_mul, hΓ, det_one,
      one_mul]
  have him : D.det.im = 0 := Complex.conj_eq_iff_im.mp h1
  refine ⟨him, ?_, ?_⟩
  · rw [sq, Complex.mul_re, him]
    nlinarith [sq_nonneg D.det.re]
  · rw [sq, Complex.mul_im, him]
    ring

/-! ## 4. Gram bound (the quantitative form of "fermions have no large fields") -/

/-- **Gram bound.**  `|det(C₁ᴴ C₂)|² ≤ det(C₁ᴴ C₁) · det(C₂ᴴ C₂)` for rectangular complex matrices; it is the
2×2 case of the positivity of the determinant kernel. -/
theorem gram_det_bound {N : Type*} [Fintype N] [DecidableEq N] (C₁ C₂ : Matrix N n ℂ) :
    Complex.normSq ((C₁ᴴ * C₂).det) ≤ ((C₁ᴴ * C₁).det).re * ((C₂ᴴ * C₂).det).re := by
  obtain ⟨Cf, hC0, hC1⟩ : ∃ Cf : Fin 2 → Matrix N n ℂ, Cf 0 = C₁ ∧ Cf 1 = C₂ :=
    ⟨fun a => if a = 0 then C₁ else C₂, by simp, by simp⟩
  have hK := det_conjTranspose_mul_matrix_posSemidef Cf
  have hdet := hK.det_nonneg
  rw [det_fin_two] at hdet
  simp only [Matrix.of_apply, hC0, hC1] at hdet
  have h10 : (C₂ᴴ * C₁).det = star ((C₁ᴴ * C₂).det) := by
    rw [← det_conjTranspose, conjTranspose_mul, conjTranspose_conjTranspose]
  have ha := hK.diag_nonneg (i := 0)
  simp only [Matrix.of_apply, hC0] at ha
  have ha' := (Complex.le_def.mp ha).2
  rw [h10] at hdet
  have hre := (Complex.le_def.mp hdet).1
  have e : ((C₁ᴴ * C₂).det * star ((C₁ᴴ * C₂).det)).re
      = Complex.normSq ((C₁ᴴ * C₂).det) := by
    simp only [Complex.mul_re, Complex.star_def, Complex.conj_re, Complex.conj_im,
      Complex.normSq_apply]
    ring
  rw [Complex.sub_re, Complex.mul_re, e, ← ha'] at hre
  simp only [Complex.zero_re, Complex.zero_im, zero_mul, sub_zero] at hre
  linarith

/-! ## 5. Positive semidefinite (zero-padded) plane blocks

On the lattice the `n × n` blocks `A₁`, `A₂` of the block form are the plane matrices padded by zero on the
bulk components (a generating script, lines 123–128): positive semidefinite and singular. The statements
of this section are the versions for `A₁ ⪰ 0`. -/

section Padded

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Hermitian symmetry of the block kernel for Hermitian `A₁`, `A₂` (pure algebra, no positivity). -/
theorem block_det_star (A₁ A₂ : Matrix n n ℂ) (h₁ : A₁.IsHermitian) (h₂ : A₂.IsHermitian)
    (Nm N' : Matrix n n ℂ) :
    star ((fromBlocks N' A₁ (-A₂) Nmᴴ).det) = (fromBlocks Nm A₁ (-A₂) N'ᴴ).det := by
  rw [← det_conjTranspose, fromBlocks_conjTranspose, conjTranspose_conjTranspose,
    conjTranspose_neg, h₁.eq, h₂.eq,
    ← det_submatrix_equiv_self (Equiv.sumComm n n) (fromBlocks N'ᴴ (-A₂) A₁ Nm)]
  congr 1
  ext (i | i) (j | j) <;> rfl

/-- Matrix form of the block determinant kernel for `A₁ ⪰ 0`, `A₂ ⪰ 0`. -/
theorem block_det_matrix_posSemidef_of_posSemidef (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosSemidef)
    (hA₂ : A₂.PosSemidef) (Nf : ι → Matrix n n ℂ) :
    (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det : Matrix ι ι ℂ).PosSemidef := by
  refine PosSemidef.of_dotProduct_mulVec_nonneg ?_ ?_
  · refine IsHermitian.ext fun a b => ?_
    rw [Matrix.of_apply, Matrix.of_apply]
    exact block_det_star A₁ A₂ hA₁.1 hA₂.1 (Nf b) (Nf a)
  · intro x
    obtain ⟨hre, him⟩ := block_det_kernel_posSemidef A₁ A₂ hA₁ hA₂ x Nf
    have h : star x ⬝ᵥ ((Matrix.of fun a b =>
          (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det : Matrix ι ι ℂ) *ᵥ x)
        = ∑ a, ∑ b, star (x a) * x b * (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det := by
      simp only [dotProduct, mulVec, Matrix.of_apply, Pi.star_apply, Finset.mul_sum]
      refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun b _ => ?_
      ring
    rw [h]
    exact Complex.le_def.mpr ⟨by simpa using hre, by simpa using him.symm⟩

/-- `N_f` flavours with positive semidefinite plane blocks: the entrywise `k`-th power of the kernel matrix is
positive semidefinite. -/
theorem block_det_matrix_pow_posSemidef_of_posSemidef (A₁ A₂ : Matrix n n ℂ)
    (hA₁ : A₁.PosSemidef) (hA₂ : A₂.PosSemidef) (Nf : ι → Matrix n n ℂ) (k : ℕ) :
    (Matrix.of fun a b =>
      (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ k : Matrix ι ι ℂ).PosSemidef := by
  induction k with
  | zero =>
    have h1 : (Matrix.of fun a b =>
        (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ 0 : Matrix ι ι ℂ)
        = vecMulVec (star fun _ : ι => (1 : ℂ)) (fun _ : ι => (1 : ℂ)) := by
      ext a b
      simp [vecMulVec_apply]
    rw [h1]
    exact posSemidef_vecMulVec_star_self _
  | succ k ih =>
    have h1 : (Matrix.of fun a b =>
        (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ (k + 1) : Matrix ι ι ℂ)
        = Matrix.hadamard
            (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det ^ k)
            (Matrix.of fun a b => (fromBlocks (Nf b) A₁ (-A₂) (Nf a)ᴴ).det) := by
      ext a b
      simp only [Matrix.of_apply, Matrix.hadamard_apply, pow_succ]
    rw [h1]
    exact ih.hadamard (block_det_matrix_posSemidef_of_posSemidef A₁ A₂ hA₁ hA₂ Nf)

end Padded

/-- Fibre form for `A₁ ⪰ 0`: the limit `ε → 0` of `A₁ + ε` under the integral (dominated convergence). -/
theorem det_kernel_integral_nonneg_posSemidef {X : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X]
    (ν : Measure X) [IsFiniteMeasure ν]
    (A₁ A₂ : Matrix n n ℂ) (hA₁ : A₁.PosSemidef) (hA₂ : A₂.PosSemidef)
    (Nm : X → Matrix n n ℂ) (hN : Continuous Nm)
    (g : X → ℝ) (hg : Measurable g) (Cg : ℝ) (bg : ∀ x, |g x| ≤ Cg) (k : ℕ) :
    0 ≤ ∫ z : X × X, g z.1 * g z.2 *
      ((fromBlocks (Nm z.1) A₁ (-A₂) (Nm z.2)ᴴ).det ^ k).re ∂(ν.prod ν) := by
  obtain ⟨G, hG⟩ : ∃ G : ℝ → X × X → ℝ, ∀ ε z, G ε z =
      ((fromBlocks (Nm z.1) (A₁ + (ε : ℂ) • (1 : Matrix n n ℂ)) (-A₂) (Nm z.2)ᴴ).det ^ k).re :=
    ⟨_, fun _ _ => rfl⟩
  have hGc : Continuous (Function.uncurry G) := by
    have h0 : Function.uncurry G = fun p : ℝ × (X × X) =>
        ((fromBlocks (Nm p.2.1) (A₁ + ((p.1 : ℝ) : ℂ) • (1 : Matrix n n ℂ)) (-A₂)
          (Nm p.2.2)ᴴ).det ^ k).re := by
      funext p
      exact hG p.1 p.2
    rw [h0]
    refine Complex.continuous_re.comp (Continuous.pow (Continuous.matrix_det ?_) k)
    refine Continuous.matrix_fromBlocks (hN.comp (continuous_fst.comp continuous_snd)) ?_
      continuous_const (hN.comp (continuous_snd.comp continuous_snd)).matrix_conjTranspose
    exact continuous_const.add
      ((Complex.continuous_ofReal.comp continuous_fst).smul continuous_const)
  obtain ⟨C, hC⟩ := (isCompact_Icc.prod isCompact_univ :
    IsCompact (Set.Icc (0 : ℝ) 1 ×ˢ (Set.univ : Set (X × X)))).exists_bound_of_continuousOn
      hGc.continuousOn
  have hG0 : ∀ z, G 0 z = ((fromBlocks (Nm z.1) A₁ (-A₂) (Nm z.2)ᴴ).det ^ k).re := by
    intro z
    rw [hG]
    simp
  obtain ⟨εs, hεs⟩ : ∃ εs : ℕ → ℝ, ∀ j, εs j = 1 / ((j : ℝ) + 1) := ⟨_, fun _ => rfl⟩
  have hεpos : ∀ j, 0 < εs j := fun j => by rw [hεs]; positivity
  have hεle : ∀ j, εs j ≤ 1 := fun j => by
    rw [hεs, div_le_one (by positivity)]
    linarith [Nat.cast_nonneg (α := ℝ) j]
  have hεlim : Filter.Tendsto εs Filter.atTop (nhds 0) := by
    have h0 : εs = fun j : ℕ => 1 / ((j : ℝ) + 1) := funext hεs
    rw [h0]
    exact tendsto_one_div_add_atTop_nhds_zero_nat
  have hpos : ∀ j, 0 ≤ ∫ z : X × X, g z.1 * g z.2 * G (εs j) z ∂(ν.prod ν) := by
    intro j
    have hd : ((εs j : ℂ) • (1 : Matrix n n ℂ)).PosDef := by
      rw [smul_one_eq_diagonal]
      exact PosDef.diagonal fun _ => Complex.zero_lt_real.mpr (hεpos j)
    have hPD : (A₁ + (εs j : ℂ) • (1 : Matrix n n ℂ)).PosDef := PosDef.posSemidef_add hA₁ hd
    have h1 := det_kernel_integral_nonneg ν _ A₂ hPD hA₂ Nm hN g hg Cg bg k
    have e : (fun z : X × X => g z.1 * g z.2 * G (εs j) z) = fun z : X × X => g z.1 * g z.2 *
        ((fromBlocks (Nm z.1) (A₁ + (εs j : ℂ) • (1 : Matrix n n ℂ)) (-A₂)
          (Nm z.2)ᴴ).det ^ k).re := by
      funext z
      rw [hG]
    rw [e]
    exact h1
  have hlim : Filter.Tendsto (fun j => ∫ z : X × X, g z.1 * g z.2 * G (εs j) z ∂(ν.prod ν))
      Filter.atTop (nhds (∫ z : X × X, g z.1 * g z.2 * G 0 z ∂(ν.prod ν))) := by
    refine tendsto_integral_of_dominated_convergence (fun _ => Cg * Cg * C) (fun j => ?_)
      (integrable_const _) (fun j => ?_) ?_
    · have hm : Measurable fun z : X × X => G (εs j) z :=
        (hGc.comp (continuous_const.prodMk continuous_id)).measurable
      exact (((hg.comp measurable_fst).mul (hg.comp measurable_snd)).mul hm).aestronglyMeasurable
    · refine Filter.Eventually.of_forall fun z => ?_
      rw [Real.norm_eq_abs, abs_mul, abs_mul]
      have h1 := bg z.1
      have h2 := bg z.2
      have h3 : |G (εs j) z| ≤ C := by
        have h := hC (εs j, z) (Set.mem_prod.mpr ⟨⟨(hεpos j).le, hεle j⟩, Set.mem_univ _⟩)
        simpa using h
      have h12 : |g z.1| * |g z.2| ≤ Cg * Cg :=
        mul_le_mul h1 h2 (abs_nonneg _) (le_trans (abs_nonneg _) h1)
      exact mul_le_mul h12 h3 (abs_nonneg _)
        (le_trans (mul_nonneg (abs_nonneg _) (abs_nonneg _)) h12)
    · refine Filter.Eventually.of_forall fun z => ?_
      have hc : Continuous fun ε : ℝ => G ε z :=
        hGc.comp (continuous_id.prodMk continuous_const)
      exact ((hc.tendsto 0).comp hεlim).const_mul (g z.1 * g z.2)
  have hfin := ge_of_tendsto' hlim hpos
  have e0 : (fun z : X × X => g z.1 * g z.2 * G 0 z) = fun z : X × X => g z.1 * g z.2 *
      ((fromBlocks (Nm z.1) A₁ (-A₂) (Nm z.2)ᴴ).det ^ k).re := by
    funext z
    rw [hG0]
  rw [e0] at hfin
  exact hfin

/-- **Fermion version of Lemma 3 of paper A, positive semidefinite plane blocks.**  The same statement as
`site_reflection_positive_det` with `A₁(U₀)` only positive semidefinite — the case of the lattice, where the
`n × n` blocks are the plane matrices padded by zero on the bulk components.  (`X` second countable.)

`Y` carries the links inside the reflection planes (`U₀`), `X` the links of the open positive side (`U₊`; the
negative side is identified with it by the reflection).  Weight: `k(U₀) h(U₀,U₊) h(U₀,U₋)` times the real part
of the `kf`-th power of the determinant kernel `det [[N(U₀,U₊), A₁(U₀)], [−A₂(U₀), N(U₀,U₋)ᴴ]]` (`kf = N_f`).
For each `U₀`: `A₁(U₀) ⪰ 0`, `A₂(U₀) ⪰ 0`, `U₊ ↦ N(U₀,U₊)` continuous; the kernel is assumed measurable and
bounded as a function of `(U₀, U₊, U₋)`. -/
theorem site_reflection_positive_det_posSemidef {X Y : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (kf : ℕ) (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosSemidef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
    (bρ : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re| ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re
        ∂(μ₀.prod (ν.prod ν)) := by
  obtain ⟨ρ, hρ⟩ : ∃ ρ : Y × (X × X) → ℝ, ∀ p, ρ p =
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re :=
    ⟨_, fun _ => rfl⟩
  have hρm' : Measurable ρ := by
    have h0 : ρ = fun p : Y × (X × X) =>
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re :=
      funext hρ
    rw [h0]
    exact hρm
  obtain ⟨g, hgdef⟩ : ∃ g : Y × X → ℝ, ∀ q, g q = φ q * h q := ⟨_, fun _ => rfl⟩
  have hgm : Measurable g := by
    have h0 : g = fun q => φ q * h q := funext hgdef
    rw [h0]
    exact hφ.mul hh
  have bg : ∀ q, |g q| ≤ Cφ * Ch := by
    intro q
    rw [hgdef, abs_mul]
    exact mul_le_mul (bφ q) (bh q) (abs_nonneg _) (le_trans (abs_nonneg _) (bφ q))
  have hrw : (fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
      = fun p : Y × (X × X) => k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p) := by
    funext p
    rw [hgdef, hgdef, hρ]
    ring
  rw [hrw]
  have hm1 : Measurable fun p : Y × (X × X) => (p.1, p.2.1) :=
    measurable_fst.prodMk measurable_snd.fst
  have hm2 : Measurable fun p : Y × (X × X) => (p.1, p.2.2) :=
    measurable_fst.prodMk measurable_snd.snd
  have hmeas : Measurable fun p : Y × (X × X) =>
      k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p) :=
    (hk.comp measurable_fst).mul (((hgm.comp hm1).mul (hgm.comp hm2)).mul hρm')
  have hint : Integrable (fun p : Y × (X × X) =>
      k p.1 * (g (p.1, p.2.1) * g (p.1, p.2.2) * ρ p)) (μ₀.prod (ν.prod ν)) := by
    refine Integrable.of_bound hmeas.aestronglyMeasurable
      (Ck * ((Cφ * Ch) * (Cφ * Ch) * Cρ)) ?_
    refine Filter.Eventually.of_forall (fun p => ?_)
    rw [Real.norm_eq_abs, abs_mul, abs_mul, abs_mul]
    have h1 := bk p.1
    have h2 := bg (p.1, p.2.1)
    have h3 := bg (p.1, p.2.2)
    have h4 : |ρ p| ≤ Cρ := by rw [hρ]; exact bρ p
    have h23 : |g (p.1, p.2.1)| * |g (p.1, p.2.2)| ≤ (Cφ * Ch) * (Cφ * Ch) :=
      mul_le_mul h2 h3 (abs_nonneg _) (le_trans (abs_nonneg _) h2)
    have h234 : |g (p.1, p.2.1)| * |g (p.1, p.2.2)| * |ρ p| ≤ (Cφ * Ch) * (Cφ * Ch) * Cρ :=
      mul_le_mul h23 h4 (abs_nonneg _)
        (le_trans (mul_nonneg (abs_nonneg _) (abs_nonneg _)) h23)
    exact mul_le_mul h1 h234 (by positivity) (le_trans (abs_nonneg _) h1)
  have key : ∀ c : Y, 0 ≤ ∫ y : X × X, k c * (g (c, y.1) * g (c, y.2) * ρ (c, y)) ∂(ν.prod ν) := by
    intro c
    rw [integral_const_mul]
    refine mul_nonneg (hk0 c) ?_
    have hfib : 0 ≤ ∫ z : X × X, g (c, z.1) * g (c, z.2) *
        ((fromBlocks (Nm (c, z.1)) (A₁ c) (-(A₂ c)) (Nm (c, z.2))ᴴ).det ^ kf).re ∂(ν.prod ν) :=
      det_kernel_integral_nonneg_posSemidef ν (A₁ c) (A₂ c) (hA₁ c) (hA₂ c) (fun x => Nm (c, x)) (hN c)
        (fun x => g (c, x)) (hgm.comp measurable_prodMk_left) (Cφ * Ch) (fun x => bg (c, x)) kf
    have e : (fun y : X × X => g (c, y.1) * g (c, y.2) * ρ (c, y))
        = fun z : X × X => g (c, z.1) * g (c, z.2) *
          ((fromBlocks (Nm (c, z.1)) (A₁ c) (-(A₂ c)) (Nm (c, z.2))ᴴ).det ^ kf).re := by
      funext y
      rw [hρ]
    rw [e]
    exact hfib
  rw [integral_prod _ hint]
  apply integral_nonneg
  intro c
  exact key c

/-- Measure form with positive semidefinite plane blocks (the case of the lattice): when the weight
`k h h · Re K^{kf}` is pointwise nonnegative (for the lattice: `K = det D[U]` is real and `kf` is even),
`∫ f(Θp) f(p) dμ ≥ 0` for `μ = (μ₀ ⊗ ν ⊗ ν).withDensity w`, `f(c,(a,b)) = φ(c,b)`, `Θ(c,(a,b)) = (c,(b,a))`. -/
theorem site_reflection_positive_det_measure_posSemidef {X Y : Type*} [TopologicalSpace X]
    [CompactSpace X] [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (kf : ℕ) (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosSemidef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) (hh0 : ∀ p, 0 ≤ h p)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
    (bρ : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re| ≤ Cρ)
    (hρ0 : ∀ p : Y × (X × X),
      0 ≤ ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re) :
    let w : Y × (X × X) → NNReal := fun p =>
      ⟨k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2) *
          ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re,
        mul_nonneg (mul_nonneg (mul_nonneg (hk0 _) (hh0 _)) (hh0 _)) (hρ0 p)⟩
    0 ≤ ∫ p, φ (p.1, p.2.1) * φ (p.1, p.2.2)
        ∂((μ₀.prod (ν.prod ν)).withDensity fun p => (w p : ENNReal)) := by
  intro w
  have hwm : Measurable w := by
    apply Measurable.subtype_mk
    exact (((hk.comp measurable_fst).mul
      (hh.comp (measurable_fst.prodMk measurable_snd.fst))).mul
      (hh.comp (measurable_fst.prodMk measurable_snd.snd))).mul hρm
  rw [integral_withDensity_eq_integral_smul hwm]
  have hmain := site_reflection_positive_det_posSemidef ν μ₀ kf A₁ A₂ hA₁ hA₂ Nm hN k h φ hk hh hφ
    Ck Ch Cφ Cρ bk bh bφ hk0 hρm bρ
  have e : ∀ p : Y × (X × X), w p • (φ (p.1, p.2.1) * φ (p.1, p.2.2)) =
      φ (p.1, p.2.1) * φ (p.1, p.2.2) * (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re := by
    intro p
    rw [NNReal.smul_def, smul_eq_mul]
    change (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2) *
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ kf).re)
      * (φ (p.1, p.2.1) * φ (p.1, p.2.2)) = _
    ring
  rw [integral_congr_ae (Filter.Eventually.of_forall e)]
  exact hmain

/-- **The lattice plane block is positive semidefinite.**  A positive semidefinite matrix `a` on the plane
components, padded by zero on the bulk components. -/
theorem padded_posSemidef {nb q : Type*} [Fintype nb] [DecidableEq nb] [Fintype q] [DecidableEq q]
    (a : Matrix q q ℂ) (ha : a.PosSemidef) :
    (fromBlocks (0 : Matrix nb nb ℂ) (0 : Matrix nb q ℂ) (0 : Matrix q nb ℂ) a).PosSemidef := by
  obtain ⟨S, hS⟩ := exists_eq_conjTranspose_mul_self ha
  have h : fromBlocks (0 : Matrix nb nb ℂ) (0 : Matrix nb q ℂ) (0 : Matrix q nb ℂ) a
      = (fromBlocks (0 : Matrix nb nb ℂ) (0 : Matrix nb q ℂ) (0 : Matrix q nb ℂ) S)ᴴ
        * fromBlocks (0 : Matrix nb nb ℂ) (0 : Matrix nb q ℂ) (0 : Matrix q nb ℂ) S := by
    rw [fromBlocks_conjTranspose, fromBlocks_multiply, hS]
    simp
  rw [h]
  exact posSemidef_conjTranspose_mul_self _

/-- The zero-padded plane matrix of the Wilson operator (`r = 1`, `m > −1`) is positive semidefinite: the
hypothesis `A₁.PosSemidef` of the `…_posSemidef` statements holds for the lattice blocks. -/
theorem padded_wilson_plane_posSemidef {nb q : Type*} [Fintype nb] [DecidableEq nb] [Fintype q]
    [DecidableEq q] {d : ℕ} (m : ℝ) (hm : -1 < m) (T : Fin d → Matrix q q ℂ)
    (hT : ∀ i, (T i)ᴴ * T i = 1) :
    (fromBlocks (0 : Matrix nb nb ℂ) (0 : Matrix nb q ℂ) (0 : Matrix q nb ℂ)
      ((m + 1 : ℝ) • (1 : Matrix q q ℂ)
        + ∑ i, ((1 : Matrix q q ℂ) - (1 / 2 : ℝ) • (T i + (T i)ᴴ)))).PosSemidef :=
  padded_posSemidef _ (wilson_plane_posDef m hm T hT).posSemidef

/-! ## 6. From the Dirac matrix to the block form: the reindexing sign

The Dirac matrix `D` has one index set `I` (site × spin × colour) for rows and columns; the block form uses two
different splittings of `I`, one for the rows (`R₊ ⊔ R₋`) and one for the columns (`C₊ ⊔ C₋`).  If, after
reindexing rows by `er` and columns by `ec`, `D` has the four blocks `N, A₁, −A₂, N'ᴴ`, then `det D` is the
block determinant up to the sign of the permutation `er.trans ec.symm`; for an even number of flavours the sign
drops out. -/

/-- Reindexing rows and columns by different equivalences changes the determinant by a sign. -/
theorem det_submatrix_two_equivs {I J : Type*} [Fintype I] [DecidableEq I] [Fintype J]
    [DecidableEq J] (D : Matrix I I ℂ) (er ec : J ≃ I) :
    (D.submatrix er ec).det = ((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ) * D.det := by
  have h1 : D.submatrix er ec = (D.submatrix ec ec).submatrix (er.trans ec.symm) id := by
    ext i j
    simp
  rw [h1, det_permute, det_submatrix_equiv_self]

/-- If the reindexed Dirac matrix has the block form, `det D = ± det [[N, A₁], [−A₂, N'ᴴ]]`. -/
theorem det_eq_sign_mul_block_det {I : Type*} [Fintype I] [DecidableEq I] (D : Matrix I I ℂ)
    (er ec : n ⊕ n ≃ I) (Nm N' A₁ A₂ : Matrix n n ℂ)
    (hD : D.submatrix er ec = fromBlocks Nm A₁ (-A₂) N'ᴴ) :
    D.det = ((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ) * (fromBlocks Nm A₁ (-A₂) N'ᴴ).det := by
  rw [← hD, det_submatrix_two_equivs, ← mul_assoc]
  rcases Int.units_eq_one_or (Equiv.Perm.sign (er.trans ec.symm)) with h | h <;> simp [h]

/-- For an even number of flavours the reindexing sign drops out: `(det D)^(2j) = (block det)^(2j)`.
**Caution :** for the concrete Wilson operator the entrywise hypothesis `hD` with a *pure* reindexing
does not hold (the lower-left block is `+A₂`, the lower-right block is `S₁ N'ᴴ S₂` with constant sign matrices).
The form that the lattice operator satisfies is `det_pow_even_of_signed_block` below. -/
theorem det_pow_even_eq_block_det_pow {I : Type*} [Fintype I] [DecidableEq I] (D : Matrix I I ℂ)
    (er ec : n ⊕ n ≃ I) (Nm N' A₁ A₂ : Matrix n n ℂ)
    (hD : D.submatrix er ec = fromBlocks Nm A₁ (-A₂) N'ᴴ) (j : ℕ) :
    D.det ^ (2 * j) = (fromBlocks Nm A₁ (-A₂) N'ᴴ).det ^ (2 * j) := by
  rw [det_eq_sign_mul_block_det D er ec Nm N' A₁ A₂ hD, mul_pow, pow_mul]
  rcases Int.units_eq_one_or (Equiv.Perm.sign (er.trans ec.symm)) with h | h <;> simp [h]

/-- **Site reflection positivity of the weight `det D^{2j}` (N_f = 2j flavours), stated for the Dirac matrix,
pure-reindexing form.**
`Dm (U₀, (U₊, U₋))` is the Dirac matrix as a function of the plane links `U₀`, the positive-side links `U₊` and
the reflected negative-side links `U₋`.  Hypothesis `hblock`: after reindexing rows by `er` and columns by `ec`,
the four blocks are `N(U₀,U₊)`, `A₁(U₀)`, `−A₂(U₀)`, `N(U₀,U₋)ᴴ`, with `A₁(U₀), A₂(U₀) ⪰ 0` and `U₊ ↦ N(U₀,U₊)`
continuous.  Then `∫ φ(U₀,U₊) φ(U₀,U₋) k h h · Re det D^{2j} ≥ 0`.

**Caution :** the Wilson operator itself does NOT satisfy `hblock`
with a pure reindexing (entrywise the lower-left block is `+A₂` and the lower-right block is `S₁ N'ᴴ S₂`); this
statement applies to the sign-conjugated matrix only.  The statement whose hypothesis the lattice operator
satisfies is `site_reflection_positive_dirac_signed` below (the signs `γ₄`, `ε₀` of `J` enter the hypothesis). -/
theorem site_reflection_positive_dirac {X Y I : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype I] [DecidableEq I]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (j : ℕ) (Dm : Y × (X × X) → Matrix I I ℂ) (er ec : n ⊕ n ≃ I)
    (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosSemidef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (hblock : ∀ p : Y × (X × X), (Dm p).submatrix er ec
      = fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ)
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) => ((Dm p).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X), |((Dm p).det ^ (2 * j)).re| ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) * ((Dm p).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have e : ∀ p : Y × (X × X), ((Dm p).det ^ (2 * j)).re
      = ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re :=
    fun p => by
      rw [det_pow_even_eq_block_det_pow (Dm p) er ec _ _ _ _ (hblock p) j]
  have hfun : (fun p : Y × (X × X) => ((Dm p).det ^ (2 * j)).re)
      = fun p : Y × (X × X) =>
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re :=
    funext e
  have hρm' : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re := by
    rw [← hfun]
    exact hρm
  have bρ' : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re|
        ≤ Cρ := fun p => by
    rw [← e p]
    exact bρ p
  have hmain := site_reflection_positive_det_posSemidef ν μ₀ (2 * j) A₁ A₂ hA₁ hA₂ Nm hN k h φ
    hk hh hφ Ck Ch Cφ Cρ bk bh bφ hk0 hρm' bρ'
  have hint : (fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) * ((Dm p).det ^ (2 * j)).re)
      = fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re := by
    funext p
    rw [e p]
  rw [hint]
  exact hmain

/-! ## 7. The signed block form 

For the concrete Wilson operator the reindexed matrix has the block form only after multiplying by constant
diagonal sign matrices (the signs of `J = ε₀ γ₄ R`):
`S_r * D.submatrix er ec * S_c = fromBlocks N A₁ (−A₂) N'ᴴ`. -/

/-- Even powers of the determinant are unchanged by constant sign matrices: if
`S_r * D.submatrix er ec * S_c = M` with `(det S_r * det S_c)² = 1` (e.g. diagonal `±1` matrices), then
`det D ^ (2j) = det M ^ (2j)`. (First checked in a separate check, `L9r2_SignedBlock.lean`.) -/
theorem det_pow_even_of_signed_block {I : Type*} [Fintype I] [DecidableEq I] (D : Matrix I I ℂ)
    (er ec : n ⊕ n ≃ I) (Sr Sc M : Matrix (n ⊕ n) (n ⊕ n) ℂ)
    (hS : (Sr.det * Sc.det) ^ 2 = 1)
    (hD : Sr * D.submatrix er ec * Sc = M) (j : ℕ) :
    D.det ^ (2 * j) = M.det ^ (2 * j) := by
  have h1 : (D.submatrix er ec).det = ((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ) * D.det := by
    have h : D.submatrix er ec = (D.submatrix ec ec).submatrix (er.trans ec.symm) id := by
      ext i j
      simp
    rw [h, det_permute, det_submatrix_equiv_self]
  have h3 : (((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ)) ^ 2 = 1 := by
    rcases Int.units_eq_one_or (Equiv.Perm.sign (er.trans ec.symm)) with h | h <;> simp [h]
  have h2 : M.det ^ 2 = D.det ^ 2 := by
    rw [← hD, det_mul, det_mul, h1]
    calc (Sr.det * (((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ) * D.det) * Sc.det) ^ 2
        = (Sr.det * Sc.det) ^ 2 * (((Equiv.Perm.sign (er.trans ec.symm) : ℤ) : ℂ)) ^ 2 * D.det ^ 2 := by
          ring
      _ = D.det ^ 2 := by rw [hS, h3]; ring
  rw [pow_mul, pow_mul, h2]

/-- A diagonal matrix of signs has `det² = 1`. -/
theorem det_diagonal_sign_sq {J : Type*} [Fintype J] [DecidableEq J] (d : J → ℂ)
    (hd : ∀ i, d i ^ 2 = 1) : (Matrix.diagonal d).det ^ 2 = 1 := by
  rw [det_diagonal, ← Finset.prod_pow]
  exact Finset.prod_eq_one fun i _ => hd i

/-- **Site reflection positivity of the weight `det D^{2j}` (N_f = 2j flavours), stated for the Dirac matrix,
signed form.**.
`Dm (U₀, (U₊, U₋))` is the Dirac matrix as a function of the plane links `U₀`, the positive-side links `U₊` and
the reflected negative-side links `U₋`.  Lattice input `hblock`: after reindexing rows by `er` and columns by
`ec` and multiplying by constant matrices `S_r`, `S_c` with `(det S_r · det S_c)² = 1` (diagonal signs), the four
blocks are `N(U₀,U₊)`, `A₁(U₀)`, `−A₂(U₀)`, `N(U₀,U₋)ᴴ`, with `A₁(U₀), A₂(U₀) ⪰ 0` and `U₊ ↦ N(U₀,U₊)`
continuous.  Then `∫ φ(U₀,U₊) φ(U₀,U₋) k h h · Re det D^{2j} ≥ 0`. -/
theorem site_reflection_positive_dirac_signed {X Y I : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype I] [DecidableEq I]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (j : ℕ) (Dm : Y × (X × X) → Matrix I I ℂ) (er ec : n ⊕ n ≃ I)
    (Sr Sc : Matrix (n ⊕ n) (n ⊕ n) ℂ) (hS : (Sr.det * Sc.det) ^ 2 = 1)
    (A₁ A₂ : Y → Matrix n n ℂ) (hA₁ : ∀ c, (A₁ c).PosSemidef) (hA₂ : ∀ c, (A₂ c).PosSemidef)
    (Nm : Y × X → Matrix n n ℂ) (hN : ∀ c, Continuous fun x => Nm (c, x))
    (hblock : ∀ p : Y × (X × X), Sr * (Dm p).submatrix er ec * Sc
      = fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ)
    (k : Y → ℝ) (h φ : Y × X → ℝ)
    (hk : Measurable k) (hh : Measurable h) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bh : ∀ p, |h p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) => ((Dm p).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X), |((Dm p).det ^ (2 * j)).re| ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) * ((Dm p).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have e : ∀ p : Y × (X × X), ((Dm p).det ^ (2 * j)).re
      = ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re :=
    fun p => by
      rw [det_pow_even_of_signed_block (Dm p) er ec Sr Sc _ hS (hblock p) j]
  have hfun : (fun p : Y × (X × X) => ((Dm p).det ^ (2 * j)).re)
      = fun p : Y × (X × X) =>
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re :=
    funext e
  have hρm' : Measurable fun p : Y × (X × X) =>
      ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re := by
    rw [← hfun]
    exact hρm
  have bρ' : ∀ p : Y × (X × X),
      |((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re|
        ≤ Cρ := fun p => by
    rw [← e p]
    exact bρ p
  have hmain := site_reflection_positive_det_posSemidef ν μ₀ (2 * j) A₁ A₂ hA₁ hA₂ Nm hN k h φ
    hk hh hφ Ck Ch Cφ Cρ bk bh bφ hk0 hρm' bρ'
  have hint : (fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) * ((Dm p).det ^ (2 * j)).re)
      = fun p : Y × (X × X) => φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * h (p.1, p.2.1) * h (p.1, p.2.2)) *
        ((fromBlocks (Nm (p.1, p.2.1)) (A₁ p.1) (-(A₂ p.1)) (Nm (p.1, p.2.2))ᴴ).det ^ (2 * j)).re := by
    funext p
    rw [e p]
  rw [hint]
  exact hmain

end FermionDetIntegral


-- ===== part : SliceBlock.part.lean =====

/-! # The time-slice form of the Wilson–Dirac operator and its signed block structure 

Paper side: –(P6) and §1.5 (layer 1).

Index set `I = Fin (2h) × Fin 2 × W`:
* time on the circle of length `T = 2h` (reflection planes `t = 0` and `t = h`),
* the sign of `γ₄` (index `1 ↔ γ₄ = +1`, index `0 ↔ γ₄ = −1`; representation `γ₄ = diag(1,1,−1,−1)`),
* the rest `W` (space site × remaining spin index × colour).

`sliceOp h B V` is the operator
`D (t,s,w) (t',s',w') = [t' = t] B_t (s,w) (s',w') − [t' = t+1, s = s' = −] V_t w w' − [t = t'+1, s = s' = +] conj(V_{t'} w' w)`,
i.e. `D = (time-diagonal part) − P₋ ⊗ (forward hop) − P₊ ⊗ (backward hop)`; this is the Wilson operator with `r = 1`
when `B_t` is its restriction to the time slice `t` and `V_t` is the time-link matrix from `t` to `t+1` (the
antiperiodic sign is put on the link `2h−1 → 0`).

`Dop h b0 bh Bp Bm Vp Vm` is the operator of the configuration assembled from the plane data `b0, bh`, the
positive-side data `(Bp, Vp)` and the reflected negative-side data `(Bm, Vm)` (time links reversed and adjointed,
antiperiodic in time).

Main statement `slice_signed_block`: with `er`, `ec` the two reindexings `R₊ ⊕ R₊ ≃ I` and constant diagonal sign
matrices `S_r`, `S_c` (the signs `ε₀ γ₄` of `J`),
`S_r * D.submatrix er ec * S_c = fromBlocks N A₁ (−A₂) N'ᴴ`,
where `A₁, A₂` are the plane blocks padded by zero and `N = D[R₊, C₊]` depends on the positive side only.
The only hypothesis on the slice matrices is `B = Γ₄ Bᴴ Γ₄` (`GammaHerm`). -/
namespace FermionSliceBlock

open Matrix
open scoped ComplexOrder

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

/-! ## 0. Time arithmetic on the circle of length `2h` (natural numbers) -/

/-- successor of a time -/
def sc (h k : ℕ) : ℕ := if k + 1 = 2 * h then 0 else k + 1

/-- reflection `t ↦ −t` -/
def th (h k : ℕ) : ℕ := if k = 0 then 0 else 2 * h - k

/-- flip of the `γ₄` index on the two planes `t = 0, h` -/
def fl (h t s : ℕ) : ℕ := if t = 0 ∨ t = h then 1 - s else s

theorem sc_spec (h k : ℕ) : (k + 1 = 2 * h ∧ sc h k = 0) ∨ (k + 1 ≠ 2 * h ∧ sc h k = k + 1) := by
  unfold sc
  by_cases hc : k + 1 = 2 * h
  · exact Or.inl ⟨hc, if_pos hc⟩
  · exact Or.inr ⟨hc, if_neg hc⟩

theorem th_spec (h k : ℕ) : (k = 0 ∧ th h k = 0) ∨ (k ≠ 0 ∧ th h k = 2 * h - k) := by
  unfold th
  by_cases hc : k = 0
  · exact Or.inl ⟨hc, if_pos hc⟩
  · exact Or.inr ⟨hc, if_neg hc⟩

theorem fl_spec (h t s : ℕ) :
    ((t = 0 ∨ t = h) ∧ fl h t s = 1 - s) ∨ (¬ (t = 0 ∨ t = h) ∧ fl h t s = s) := by
  unfold fl
  by_cases hc : t = 0 ∨ t = h
  · exact Or.inl ⟨hc, if_pos hc⟩
  · exact Or.inr ⟨hc, if_neg hc⟩

theorem th_lt (h k : ℕ) (hk : k < 2 * h) : th h k < 2 * h := by
  have a := th_spec h k
  omega

theorem fl_lt (h t s : ℕ) (hs : s < 2) : fl h t s < 2 := by
  have a := fl_spec h t s
  omega

theorem th_th (h k : ℕ) (hk : k < 2 * h) : th h (th h k) = k := by
  have a := th_spec h k
  have b := th_spec h (th h k)
  omega

theorem th_inj (h k k' : ℕ) (hk : k < 2 * h) (hk' : k' < 2 * h) (e : th h k = th h k') : k = k' := by
  have a := th_spec h k
  have b := th_spec h k'
  omega

/-- the reflection reverses the direction of time -/
theorem sc_th (h k k' : ℕ) (hk : k < 2 * h) (hk' : k' < 2 * h) :
    k' = sc h k ↔ th h k = sc h (th h k') := by
  have a := sc_spec h k
  have b := th_spec h k
  have c := th_spec h k'
  have d := sc_spec h (th h k')
  constructor
  · intro e
    omega
  · intro e
    omega

theorem fl_fl (h t s : ℕ) (hs : s < 2) : fl h t (fl h t s) = s := by
  have a := fl_spec h t s
  have b := fl_spec h t (fl h t s)
  omega

theorem fl_th_fl (h t s : ℕ) (ht : t < 2 * h) (hs : s < 2) : fl h (th h t) (fl h t s) = s := by
  have a := fl_spec h t s
  have b := th_spec h t
  have c := fl_spec h (th h t) (fl h t s)
  omega

/-- `ι = θ ∘ (flip)` exchanges the rows `R₊` with their complement -/
theorem rp_iota_iff (h t s : ℕ) (ht : t < 2 * h) (hs : s < 2) :
    ((0 < th h t ∧ th h t < h) ∨ (th h t = 0 ∧ fl h t s = 0) ∨ (th h t = h ∧ fl h t s = 1))
      ↔ ¬ ((0 < t ∧ t < h) ∨ (t = 0 ∧ s = 0) ∨ (t = h ∧ s = 1)) := by
  have a := fl_spec h t s
  have b := th_spec h t
  constructor
  · intro e
    omega
  · intro e
    omega

/-! ## 1. Signs -/

/-- `ε₀(t)`: `−1` on the plane `t = 0`, `+1` elsewhere (moves the antiperiodic sign back under reflection) -/
def eps (t : ℕ) : ℂ := if t = 0 then -1 else 1

/-- the sign of `γ₄`: `+1` for the index `1`, `−1` for the index `0` -/
def gam (s : Fin 2) : ℂ := if s.val = 1 then 1 else -1

/-- the index of the `γ₄ = −1` components -/
def sM : Fin 2 := ⟨0, by omega⟩

/-- the index of the `γ₄ = +1` components -/
def sP : Fin 2 := ⟨1, by omega⟩

theorem eps_of_eq {t : ℕ} (ht : t = 0) : eps t = -1 := by
  unfold eps
  rw [if_pos ht]

theorem eps_zero : eps 0 = -1 := eps_of_eq rfl

theorem eps_of_ne {t : ℕ} (ht : t ≠ 0) : eps t = 1 := by
  unfold eps
  rw [if_neg ht]

theorem gam_of_one {s : Fin 2} (hs : s.val = 1) : gam s = 1 := by
  unfold gam
  rw [if_pos hs]

theorem gam_of_zero {s : Fin 2} (hs : s.val = 0) : gam s = -1 := by
  have h1 : ¬ (s.val = 1) := by omega
  unfold gam
  rw [if_neg h1]

theorem eps_mul_self (t : ℕ) : eps t * eps t = 1 := by
  by_cases ht : t = 0
  · rw [eps_of_eq ht]
    norm_num
  · rw [eps_of_ne ht]
    norm_num

theorem gam_mul_self (s : Fin 2) : gam s * gam s = 1 := by
  have hs2 := s.isLt
  by_cases hs : s.val = 1
  · rw [gam_of_one hs]
    norm_num
  · have h0 : s.val = 0 := by omega
    rw [gam_of_zero h0]
    norm_num

theorem star_eps (t : ℕ) : star (eps t) = eps t := by
  by_cases ht : t = 0
  · rw [eps_of_eq ht]
    simp
  · rw [eps_of_ne ht]
    simp

theorem sign_sandwich (a b c d X : ℂ) (ha : a * a = 1) (hb : b * b = 1) (hc : c * c = 1)
    (hd : d * d = 1) : (a * b) * ((a * b) * (c * d) * X) * (c * d) = X := by
  linear_combination (b * b * (c * c) * (d * d) * X) * ha + (c * c * (d * d) * X) * hb
    + (d * d * X) * hc + X * hd

/-! ## 2. The time-slice operator -/

variable {W : Type*}

/-- `M = Γ₄ Mᴴ Γ₄` entrywise (`Γ₄` = the diagonal sign of `γ₄`); holds for every time slice of the Wilson
operator. -/
def GammaHerm (M : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) : Prop :=
  ∀ (s s' : Fin 2) (w w' : W), M (s, w) (s', w') = gam s * gam s' * star (M (s', w') (s, w))

/-- entries of the time-slice operator, times as natural numbers -/
def entry (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ)
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W) : ℂ :=
  (if t' = t then B t (s, w) (s', w') else 0)
    - (if t' = sc h t ∧ s.val = 0 ∧ s'.val = 0 then V t w w' else 0)
    - (if t = sc h t' ∧ s.val = 1 ∧ s'.val = 1 then star (V t' w' w) else 0)

/-- **The time-slice operator** on `Fin (2h) × Fin 2 × W`. -/
def sliceOp (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ) :
    Matrix (Fin (2 * h) × Fin 2 × W) (Fin (2 * h) × Fin 2 × W) ℂ :=
  fun a b => entry h B V a.1.val a.2.1 a.2.2 b.1.val b.2.1 b.2.2

theorem entry_congr (h : ℕ) (B B' : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V V' : ℕ → Matrix W W ℂ)
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W)
    (hB : t' = t → B t = B' t)
    (hV : t' = sc h t ∧ s.val = 0 ∧ s'.val = 0 → V t = V' t)
    (hV' : t = sc h t' ∧ s.val = 1 ∧ s'.val = 1 → V t' = V' t') :
    entry h B V t s w t' s' w' = entry h B' V' t s w t' s' w' := by
  have e1 : (if t' = t then B t (s, w) (s', w') else 0)
      = (if t' = t then B' t (s, w) (s', w') else 0) := by
    by_cases hc : t' = t
    · rw [if_pos hc, if_pos hc, hB hc]
    · rw [if_neg hc, if_neg hc]
  have e2 : (if t' = sc h t ∧ s.val = 0 ∧ s'.val = 0 then V t w w' else 0)
      = (if t' = sc h t ∧ s.val = 0 ∧ s'.val = 0 then V' t w w' else 0) := by
    by_cases hc : t' = sc h t ∧ s.val = 0 ∧ s'.val = 0
    · rw [if_pos hc, if_pos hc, hV hc]
    · rw [if_neg hc, if_neg hc]
  have e3 : (if t = sc h t' ∧ s.val = 1 ∧ s'.val = 1 then star (V t' w' w) else 0)
      = (if t = sc h t' ∧ s.val = 1 ∧ s'.val = 1 then star (V' t' w' w) else 0) := by
    by_cases hc : t = sc h t' ∧ s.val = 1 ∧ s'.val = 1
    · rw [if_pos hc, if_pos hc, hV' hc]
    · rw [if_neg hc, if_neg hc]
  unfold entry
  rw [e1, e2, e3]

theorem entry_of_no_hop (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ)
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W)
    (h1 : ¬ (t' = sc h t ∧ s.val = 0 ∧ s'.val = 0))
    (h2 : ¬ (t = sc h t' ∧ s.val = 1 ∧ s'.val = 1)) :
    entry h B V t s w t' s' w' = if t' = t then B t (s, w) (s', w') else 0 := by
  unfold entry
  rw [if_neg h1, if_neg h2, sub_zero, sub_zero]

/-- **(P4) The reflection relation** `D[θU] = J D[U]ᴴ J`, entrywise, for two families related by the
reflection: `B_t = Γ₄ (B'_{θt})ᴴ Γ₄` and `V_k = ε₀(k) ε₀(k+1) (V'_{θ(k+1)})ᴴ`. -/
theorem entry_refl (h : ℕ) (B B' : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V V' : ℕ → Matrix W W ℂ)
    (t : ℕ) (ht : t < 2 * h) (s : Fin 2) (w : W) (t' : ℕ) (ht' : t' < 2 * h) (s' : Fin 2) (w' : W)
    (hB : ∀ (q q' : Fin 2) (v v' : W),
      B t (q, v) (q', v') = gam q * gam q' * star (B' (th h t) (q', v') (q, v)))
    (hV : ∀ k, k < 2 * h → ∀ v v' : W,
      V k v v' = eps k * eps (sc h k) * star (V' (th h (sc h k)) v' v)) :
    entry h B V t s w t' s' w'
      = (eps t * gam s) * (eps t' * gam s') * star (entry h B' V' (th h t') s' w' (th h t) s w) := by
  have e1 : (if t' = t then B t (s, w) (s', w') else 0)
      = (eps t * gam s) * (eps t' * gam s') *
        star (if th h t = th h t' then B' (th h t') (s', w') (s, w) else 0) := by
    by_cases hc : t' = t
    · have hc' : th h t = th h t' := by rw [hc]
      rw [if_pos hc, if_pos hc', hB s s' w w', hc]
      have e := eps_mul_self t
      linear_combination (-(gam s * gam s' * star (B' (th h t) (s', w') (s, w)))) * e
    · have hc' : ¬ (th h t = th h t') := fun e => hc (th_inj h t t' ht ht' e).symm
      rw [if_neg hc, if_neg hc', star_zero, mul_zero]
  have e2 : (if t' = sc h t ∧ s.val = 0 ∧ s'.val = 0 then V t w w' else 0)
      = (eps t * gam s) * (eps t' * gam s') *
        star (if th h t = sc h (th h t') ∧ s'.val = 0 ∧ s.val = 0 then V' (th h t') w' w else 0) := by
    by_cases hc : t' = sc h t ∧ s.val = 0 ∧ s'.val = 0
    · have h1 := hc.1
      have h2 := hc.2.1
      have h3 := hc.2.2
      have h4 : th h t = sc h (th h t') ∧ s'.val = 0 ∧ s.val = 0 :=
        ⟨(sc_th h t t' ht ht').mp h1, h3, h2⟩
      have hv := hV t ht w w'
      rw [← h1] at hv
      rw [if_pos hc, if_pos h4, hv, gam_of_zero h2, gam_of_zero h3]
      ring
    · have hc' : ¬ (th h t = sc h (th h t') ∧ s'.val = 0 ∧ s.val = 0) :=
        fun e => hc ⟨(sc_th h t t' ht ht').mpr e.1, e.2.2, e.2.1⟩
      rw [if_neg hc, if_neg hc', star_zero, mul_zero]
  have e3 : (if t = sc h t' ∧ s.val = 1 ∧ s'.val = 1 then star (V t' w' w) else 0)
      = (eps t * gam s) * (eps t' * gam s') *
        star (if th h t' = sc h (th h t) ∧ s'.val = 1 ∧ s.val = 1
          then star (V' (th h t) w w') else 0) := by
    by_cases hc : t = sc h t' ∧ s.val = 1 ∧ s'.val = 1
    · have h1 := hc.1
      have h2 := hc.2.1
      have h3 := hc.2.2
      have h4 : th h t' = sc h (th h t) ∧ s'.val = 1 ∧ s.val = 1 :=
        ⟨(sc_th h t' t ht' ht).mp h1, h3, h2⟩
      have hv := hV t' ht' w' w
      rw [← h1] at hv
      rw [if_pos hc, if_pos h4, hv, gam_of_one h2, gam_of_one h3]
      simp only [star_star, star_mul', star_eps]
      ring
    · have hc' : ¬ (th h t' = sc h (th h t) ∧ s'.val = 1 ∧ s.val = 1) :=
        fun e => hc ⟨(sc_th h t' t ht' ht).mpr e.1, e.2.2, e.2.1⟩
      rw [if_neg hc, if_neg hc', star_zero, mul_zero]
  unfold entry
  rw [e1, e2, e3]
  simp only [star_sub, mul_sub]

/-! ## 3. The assembled configuration -/

/-- slice data of the assembled configuration: planes `b0` (at `t = 0`) and `bh` (at `t = h`), positive side
`Bp t` (`0 < t < h`), negative side `Bm (θ t)` (`h < t < 2h`) -/
def Bfull {M : Type*} (h : ℕ) (b0 bh : M) (Bp Bm : ℕ → M) (t : ℕ) : M :=
  if t = 0 then b0 else if t = h then bh else if t < h then Bp t else Bm (th h t)

/-- time-link data of the assembled configuration: `Vp t` for `0 ≤ t < h`; for `h ≤ t < 2h` the reversed
adjoint link of the negative-side data, with the antiperiodic sign on the link `2h−1 → 0`
(`ε₀(t+1) = −1` exactly there) -/
def Vfull (h : ℕ) (Vp Vm : ℕ → Matrix W W ℂ) (t : ℕ) : Matrix W W ℂ :=
  if t < h then Vp t else eps (sc h t) • (Vm (th h (sc h t)))ᴴ

theorem Bfull_zero {M : Type*} (h : ℕ) (b0 bh : M) (Bp Bm : ℕ → M) : Bfull h b0 bh Bp Bm 0 = b0 := by
  unfold Bfull
  rw [if_pos rfl]

theorem Bfull_half {M : Type*} (h : ℕ) (hh : 0 < h) (b0 bh : M) (Bp Bm : ℕ → M) :
    Bfull h b0 bh Bp Bm h = bh := by
  have h0 : ¬ (h = 0) := by omega
  unfold Bfull
  rw [if_neg h0, if_pos rfl]

theorem Bfull_congr_of_le {M : Type*} (h : ℕ) (b0 bh : M) (Bp Bm Bm' : ℕ → M) (t : ℕ) (ht : t ≤ h) :
    Bfull h b0 bh Bp Bm t = Bfull h b0 bh Bp Bm' t := by
  unfold Bfull
  by_cases h0 : t = 0
  · rw [if_pos h0, if_pos h0]
  · by_cases h1 : t = h
    · rw [if_neg h0, if_neg h0, if_pos h1, if_pos h1]
    · have h2 : t < h := by omega
      rw [if_neg h0, if_neg h0, if_neg h1, if_neg h1, if_pos h2, if_pos h2]

theorem Vfull_congr_of_lt (h : ℕ) (Vp Vm Vm' : ℕ → Matrix W W ℂ) (t : ℕ) (ht : t < h) :
    Vfull h Vp Vm t = Vfull h Vp Vm' t := by
  unfold Vfull
  rw [if_pos ht, if_pos ht]

theorem Bfull_induction {M : Type*} (P : M → Prop) (h : ℕ) (b0 bh : M) (Bp Bm : ℕ → M) (t : ℕ)
    (h0 : P b0) (h1 : P bh) (h2 : ∀ k, P (Bp k)) (h3 : ∀ k, P (Bm k)) :
    P (Bfull h b0 bh Bp Bm t) := by
  unfold Bfull
  by_cases c0 : t = 0
  · rw [if_pos c0]
    exact h0
  · rw [if_neg c0]
    by_cases c1 : t = h
    · rw [if_pos c1]
      exact h1
    · rw [if_neg c1]
      by_cases c2 : t < h
      · rw [if_pos c2]
        exact h2 t
      · rw [if_neg c2]
        exact h3 _

/-- exchanging the two sides is the time reflection of the slices -/
theorem Bfull_refl {M : Type*} (h : ℕ) (hh : 0 < h) (b0 bh : M) (Bp Bm : ℕ → M) (t : ℕ)
    (ht : t < 2 * h) : Bfull h b0 bh Bm Bp (th h t) = Bfull h b0 bh Bp Bm t := by
  have b := th_spec h t
  unfold Bfull
  by_cases h0 : t = 0
  · have e0 : th h t = 0 := by omega
    rw [if_pos e0, if_pos h0]
  · by_cases h1 : t = h
    · have e0 : ¬ (th h t = 0) := by omega
      have e1 : th h t = h := by omega
      rw [if_neg e0, if_pos e1, if_neg h0, if_pos h1]
    · by_cases h2 : t < h
      · have e0 : ¬ (th h t = 0) := by omega
        have e1 : ¬ (th h t = h) := by omega
        have e2 : ¬ (th h t < h) := by omega
        have e3 : th h (th h t) = t := th_th h t ht
        rw [if_neg e0, if_neg e1, if_neg e2, e3, if_neg h0, if_neg h1, if_pos h2]
      · have e0 : ¬ (th h t = 0) := by omega
        have e1 : ¬ (th h t = h) := by omega
        have e2 : th h t < h := by omega
        rw [if_neg e0, if_neg e1, if_pos e2, if_neg h0, if_neg h1, if_neg h2]

/-- the time links of the two assembled configurations `(x₊, x₋)` and `(x₋, x₊)` are related by the reflection,
with the signs `ε₀` -/
theorem Vfull_refl (h : ℕ) (hh : 0 < h) (Vp Vm : ℕ → Matrix W W ℂ) (k : ℕ) (hk : k < 2 * h)
    (v v' : W) :
    Vfull h Vp Vm k v v' = eps k * eps (sc h k) * star (Vfull h Vm Vp (th h (sc h k)) v' v) := by
  have a := sc_spec h k
  have b := th_spec h (sc h k)
  have c := sc_spec h (th h (sc h k))
  have d := th_spec h (sc h (th h (sc h k)))
  unfold Vfull
  by_cases h1 : k < h
  · have e1 : ¬ (th h (sc h k) < h) := by omega
    have e2 : th h (sc h (th h (sc h k))) = k := by omega
    have e3 : eps k * eps (sc h k) * eps (sc h (th h (sc h k))) = 1 := by
      by_cases k0 : k = 0
      · have f1 : sc h k ≠ 0 := by omega
        have f2 : sc h (th h (sc h k)) = 0 := by omega
        rw [eps_of_eq k0, eps_of_ne f1, eps_of_eq f2]
        norm_num
      · have f1 : sc h k ≠ 0 := by omega
        have f2 : sc h (th h (sc h k)) ≠ 0 := by omega
        rw [eps_of_ne k0, eps_of_ne f1, eps_of_ne f2]
        norm_num
    rw [if_pos h1, if_neg e1, e2]
    simp only [Matrix.smul_apply, Matrix.conjTranspose_apply, smul_eq_mul, star_mul', star_star,
      star_eps]
    linear_combination (-(Vp k v v')) * e3
  · have e1 : th h (sc h k) < h := by omega
    have k0 : k ≠ 0 := by omega
    rw [if_neg h1, if_pos e1, eps_of_ne k0]
    simp only [Matrix.smul_apply, Matrix.conjTranspose_apply, smul_eq_mul]
    ring

/-! ## 4. Support and values of the four blocks (entry level) -/

/-- **(L1)** the entries with a row in `R₊` and a column in `C₊` depend on the positive-side data only -/
theorem entry_pos_indep (h : ℕ) (hh : 0 < h)
    (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Bp Bm Bm' : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Vp Vm Vm' : ℕ → Matrix W W ℂ)
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' r' : Fin 2) (w' : W)
    (hr : (0 < t ∧ t < h) ∨ (t = 0 ∧ s.val = 0) ∨ (t = h ∧ s.val = 1))
    (hr' : (0 < t' ∧ t' < h) ∨ (t' = 0 ∧ s'.val = 0) ∨ (t' = h ∧ s'.val = 1))
    (er' : r'.val = fl h t' s'.val) :
    entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) t s w t' r' w'
      = entry h (Bfull h b0 bh Bp Bm') (Vfull h Vp Vm') t s w t' r' w' := by
  have f2 := fl_spec h t' s'.val
  have hs2 := s.isLt
  have hs2' := s'.isLt
  apply entry_congr
  · intro hc
    exact Bfull_congr_of_le h b0 bh Bp Bm Bm' t (by omega)
  · intro hc
    exact Vfull_congr_of_lt h Vp Vm Vm' t (by omega)
  · intro hc
    exact Vfull_congr_of_lt h Vp Vm Vm' t' (by omega)

/-- **(P3), upper right block**: for rows in `R₊` and columns in `C₋ = θ R₊` only the plane blocks survive;
with the column sign `ε₀ γ₄` the value is the `(−,−)` block of the plane `0` and the `(+,+)` block of the
plane `h`. -/
theorem entry_cross₁ (h : ℕ) (hh : 0 < h) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (V : ℕ → Matrix W W ℂ) (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W)
    (hr : (0 < t ∧ t < h) ∨ (t = 0 ∧ s.val = 0) ∨ (t = h ∧ s.val = 1))
    (hr' : (0 < t' ∧ t' < h) ∨ (t' = 0 ∧ s'.val = 0) ∨ (t' = h ∧ s'.val = 1)) :
    entry h B V t s w (th h t') s' w' * (eps (th h t') * gam s')
      = (if t = 0 ∧ t' = 0 then B 0 (sM, w) (sM, w') else 0)
        + (if t = h ∧ t' = h then B h (sP, w) (sP, w') else 0) := by
  have a1 := sc_spec h t
  have a2 := th_spec h t'
  have a3 := sc_spec h (th h t')
  have hs2 := s.isLt
  have hs2' := s'.isLt
  have h1 : ¬ (th h t' = sc h t ∧ s.val = 0 ∧ s'.val = 0) := by omega
  have h2 : ¬ (t = sc h (th h t') ∧ s.val = 1 ∧ s'.val = 1) := by omega
  rw [entry_of_no_hop h B V t s w (th h t') s' w' h1 h2]
  by_cases cA : t = 0 ∧ t' = 0
  · have hs0 : s.val = 0 := by omega
    have hs0' : s'.val = 0 := by omega
    have hs : s = sM := Fin.ext hs0
    have hs' : s' = sM := Fin.ext hs0'
    have c1 : th h t' = t := by omega
    have cB : ¬ (t = h ∧ t' = h) := by omega
    have et' : th h t' = 0 := by omega
    have et : t = 0 := cA.1
    rw [if_pos c1, if_pos cA, if_neg cB, et', eps_zero, gam_of_zero hs0', hs, hs', et]
    ring
  · by_cases cB : t = h ∧ t' = h
    · have hs1 : s.val = 1 := by omega
      have hs1' : s'.val = 1 := by omega
      have hs : s = sP := Fin.ext hs1
      have hs' : s' = sP := Fin.ext hs1'
      have c1 : th h t' = t := by omega
      have ne0 : th h t' ≠ 0 := by omega
      have et : t = h := cB.1
      rw [if_pos c1, if_neg cA, if_pos cB, eps_of_ne ne0, gam_of_one hs1', hs, hs', et]
      ring
    · have c1 : ¬ (th h t' = t) := by omega
      rw [if_neg c1, if_neg cA, if_neg cB]
      ring

set_option maxHeartbeats 1600000 in
/-- **(P3), lower left block**: for rows in `R₋ = ι R₊` and columns in `C₊` only the plane blocks survive; with
the row sign `ε₀ γ₄` the value is minus the `(+,+)` block of the plane `0` and minus the `(−,−)` block of the
plane `h`. -/
theorem entry_cross₂ (h : ℕ) (hh : 0 < h) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (V : ℕ → Matrix W W ℂ) (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W) (r r' : Fin 2)
    (hr : (0 < t ∧ t < h) ∨ (t = 0 ∧ s.val = 0) ∨ (t = h ∧ s.val = 1))
    (hr' : (0 < t' ∧ t' < h) ∨ (t' = 0 ∧ s'.val = 0) ∨ (t' = h ∧ s'.val = 1))
    (er : r.val = fl h t s.val) (er' : r'.val = fl h t' s'.val) :
    (eps (th h t) * gam r) * entry h B V (th h t) r w t' r' w'
      = -((if t = 0 ∧ t' = 0 then B 0 (sP, w) (sP, w') else 0)
        + (if t = h ∧ t' = h then B h (sM, w) (sM, w') else 0)) := by
  have a1 := th_spec h t
  have a2 := sc_spec h (th h t)
  have a3 := sc_spec h t'
  have f1 := fl_spec h t s.val
  have f2 := fl_spec h t' s'.val
  have hs2 := s.isLt
  have hs2' := s'.isLt
  have h1 : ¬ (t' = sc h (th h t) ∧ r.val = 0 ∧ r'.val = 0) := by omega
  have h2 : ¬ (th h t = sc h t' ∧ r.val = 1 ∧ r'.val = 1) := by omega
  rw [entry_of_no_hop h B V (th h t) r w t' r' w' h1 h2]
  by_cases cA : t = 0 ∧ t' = 0
  · have hr1 : r.val = 1 := by omega
    have hr1' : r'.val = 1 := by omega
    have hrr : r = sP := Fin.ext hr1
    have hrr' : r' = sP := Fin.ext hr1'
    have c1 : t' = th h t := by omega
    have cB : ¬ (t = h ∧ t' = h) := by omega
    have et : th h t = 0 := by omega
    rw [if_pos c1, if_pos cA, if_neg cB, et, eps_zero, gam_of_one hr1, hrr, hrr']
    ring
  · by_cases cB : t = h ∧ t' = h
    · have hr0 : r.val = 0 := by omega
      have hr0' : r'.val = 0 := by omega
      have hrr : r = sM := Fin.ext hr0
      have hrr' : r' = sM := Fin.ext hr0'
      have c1 : t' = th h t := by omega
      have et : th h t = h := by omega
      have ne0 : h ≠ 0 := by omega
      rw [if_pos c1, if_neg cA, if_pos cB, et, eps_of_ne ne0, gam_of_zero hr0, hrr, hrr']
      ring
    · have c1 : ¬ (t' = th h t) := by
        clear a2 a3 f1 f2 er er' h1 h2
        omega
      rw [if_neg c1, if_neg cA, if_neg cB]
      ring

/-- **(P5), lower right block**: with both signs, the block `D[R₋, C₋]` of the configuration `(x₊, x₋)` is the
conjugate transpose of the block `D[R₊, C₊]` of the reflection-symmetric configuration `(x₋, x₋)`. -/
theorem entry_lower_right (h : ℕ) (hh : 0 < h)
    (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Bp Bm : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Vp Vm : ℕ → Matrix W W ℂ)
    (hb0 : GammaHerm b0) (hbh : GammaHerm bh) (hBp : ∀ k, GammaHerm (Bp k))
    (hBm : ∀ k, GammaHerm (Bm k))
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W) (r : Fin 2)
    (ht : t < 2 * h) (ht' : t' < 2 * h)
    (hr : (0 < t ∧ t < h) ∨ (t = 0 ∧ s.val = 0) ∨ (t = h ∧ s.val = 1))
    (hr' : (0 < t' ∧ t' < h) ∨ (t' = 0 ∧ s'.val = 0) ∨ (t' = h ∧ s'.val = 1))
    (er : r.val = fl h t s.val) :
    (eps (th h t) * gam r)
        * entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) (th h t) r w (th h t') s' w'
        * (eps (th h t') * gam s')
      = star (entry h (Bfull h b0 bh Bm Bm) (Vfull h Vm Vm) t' s' w' t r w) := by
  have htt : th h t < 2 * h := th_lt h t ht
  have htt' : th h t' < 2 * h := th_lt h t' ht'
  have hB : ∀ (q q' : Fin 2) (v v' : W),
      Bfull h b0 bh Bp Bm (th h t) (q, v) (q', v')
        = gam q * gam q' * star (Bfull h b0 bh Bm Bp (th h (th h t)) (q', v') (q, v)) := by
    intro q q' v v'
    rw [Bfull_refl h hh b0 bh Bp Bm (th h t) htt]
    exact Bfull_induction GammaHerm h b0 bh Bp Bm (th h t) hb0 hbh hBp hBm q q' v v'
  have R := entry_refl h (Bfull h b0 bh Bp Bm) (Bfull h b0 bh Bm Bp) (Vfull h Vp Vm)
    (Vfull h Vm Vp) (th h t) htt r w (th h t') htt' s' w' hB
    (fun k hk v v' => Vfull_refl h hh Vp Vm k hk v v')
  rw [th_th h t' ht', th_th h t ht] at R
  have L := entry_pos_indep h hh b0 bh Bm Bp Bm Vm Vp Vm t' s' w' t s r w hr' hr er
  rw [R, L]
  exact sign_sandwich _ _ _ _ _ (eps_mul_self _) (gam_mul_self _) (eps_mul_self _) (gam_mul_self _)

/-! ## 5. Continuity of the entries in the positive-side data -/

theorem continuous_entry {X : Type*} [TopologicalSpace X] (h : ℕ)
    (B : X → ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : X → ℕ → Matrix W W ℂ)
    (hB : ∀ k i j, Continuous fun x => B x k i j) (hV : ∀ k v v', Continuous fun x => V x k v v')
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W) :
    Continuous fun x => entry h (B x) (V x) t s w t' s' w' := by
  unfold entry
  refine Continuous.sub (Continuous.sub ?_ ?_) ?_
  · by_cases c : t' = t
    · simp only [if_pos c]
      exact hB t _ _
    · simp only [if_neg c]
      exact continuous_const
  · by_cases c : t' = sc h t ∧ s.val = 0 ∧ s'.val = 0
    · simp only [if_pos c]
      exact hV t w w'
    · simp only [if_neg c]
      exact continuous_const
  · by_cases c : t = sc h t' ∧ s.val = 1 ∧ s'.val = 1
    · simp only [if_pos c]
      exact (hV t' w' w).star
    · simp only [if_neg c]
      exact continuous_const

theorem continuous_Bfull {X : Type*} [TopologicalSpace X] (h : ℕ)
    (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Bp : X → ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (hBc : ∀ k i j, Continuous fun x => Bp x k i j) (k : ℕ) (i j : Fin 2 × W) :
    Continuous fun x => Bfull h b0 bh (Bp x) (Bp x) k i j := by
  unfold Bfull
  by_cases c0 : k = 0
  · simp only [if_pos c0]
    exact continuous_const
  · by_cases c1 : k = h
    · simp only [if_neg c0, if_pos c1]
      exact continuous_const
    · by_cases c2 : k < h
      · simp only [if_neg c0, if_neg c1, if_pos c2]
        exact hBc k i j
      · simp only [if_neg c0, if_neg c1, if_neg c2]
        exact hBc (th h k) i j

theorem continuous_Vfull {X : Type*} [TopologicalSpace X] (h : ℕ) (Vp : X → ℕ → Matrix W W ℂ)
    (hVc : ∀ k v v', Continuous fun x => Vp x k v v') (k : ℕ) (v v' : W) :
    Continuous fun x => Vfull h (Vp x) (Vp x) k v v' := by
  unfold Vfull
  by_cases c : k < h
  · simp only [if_pos c]
    exact hVc k v v'
  · simp only [if_neg c, Matrix.smul_apply, Matrix.conjTranspose_apply, smul_eq_mul]
    exact continuous_const.mul (hVc _ v' v).star

/-! ## 6. The index maps and the reindexings -/

/-- the rows of the positive side: `R₊ = bulk₊ ∪ (0, −) ∪ (h, +)` -/
def rp (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : Prop :=
  (0 < a.1.val ∧ a.1.val < h) ∨ (a.1.val = 0 ∧ a.2.1.val = 0) ∨ (a.1.val = h ∧ a.2.1.val = 1)

instance rpDecidable (h : ℕ) : DecidablePred (rp (W := W) h) := fun a => by
  unfold rp
  infer_instance

/-- the index type `n` of the blocks: the rows of the positive side -/
abbrev Rp (h : ℕ) (W : Type*) := {a : Fin (2 * h) × Fin 2 × W // rp h a}

def thF (h : ℕ) (t : Fin (2 * h)) : Fin (2 * h) := ⟨th h t.val, th_lt h t.val t.isLt⟩

def flF (h : ℕ) (t : Fin (2 * h)) (s : Fin 2) : Fin 2 := ⟨fl h t.val s.val, fl_lt h t.val s.val s.isLt⟩

/-- time reflection `θ` -/
def reflT (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : Fin (2 * h) × Fin 2 × W :=
  (thF h a.1, a.2.1, a.2.2)

/-- `f`: flip of the `γ₄` index on the two planes -/
def flipS (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : Fin (2 * h) × Fin 2 × W :=
  (a.1, flF h a.1 a.2.1, a.2.2)

/-- `ι = θ ∘ f` -/
def iotaR (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : Fin (2 * h) × Fin 2 × W :=
  (thF h a.1, flF h a.1 a.2.1, a.2.2)

theorem flipS_invol (h : ℕ) : Function.Involutive (flipS (W := W) h) := by
  intro a
  apply Prod.ext
  · rfl
  · apply Prod.ext
    · apply Fin.ext
      exact fl_fl h a.1.val a.2.1.val a.2.1.isLt
    · rfl

theorem iotaR_invol (h : ℕ) : Function.Involutive (iotaR (W := W) h) := by
  intro a
  apply Prod.ext
  · apply Fin.ext
    exact th_th h a.1.val a.1.isLt
  · apply Prod.ext
    · apply Fin.ext
      exact fl_th_fl h a.1.val a.2.1.val a.1.isLt a.2.1.isLt
    · rfl

theorem flipS_iotaR (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : flipS h (iotaR h a) = reflT h a := by
  apply Prod.ext
  · rfl
  · apply Prod.ext
    · apply Fin.ext
      exact fl_th_fl h a.1.val a.2.1.val a.1.isLt a.2.1.isLt
    · rfl

theorem rp_iotaR (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : rp h (iotaR h a) ↔ ¬ rp h a :=
  rp_iota_iff h a.1.val a.2.1.val a.1.isLt a.2.1.isLt

/-- Reindexing from an involution (from a separate check, `L9r2_SignedBlock.lean`): if `ι` is an
involution of `I` exchanging `p` with `¬ p`, then `inl a ↦ a`, `inr a ↦ ι a` is an equivalence. -/
def sumEquivOfInvolution {I : Type*} (p : I → Prop) [DecidablePred p] (ι : I → I)
    (hι : Function.Involutive ι) (hp : ∀ i, p (ι i) ↔ ¬ p i) : {i // p i} ⊕ {i // p i} ≃ I :=
  (Equiv.sumCongr (Equiv.refl {i // p i})
    ((Function.Involutive.toPerm ι hι).subtypeEquiv (p := p) (q := fun i => ¬ p i)
      (fun a => by
        rw [Function.Involutive.coe_toPerm, hp a]
        exact not_not.symm))).trans (Equiv.sumCompl p)

theorem sumEquivOfInvolution_inl {I : Type*} (p : I → Prop) [DecidablePred p] (ι : I → I)
    (hι : Function.Involutive ι) (hp : ∀ i, p (ι i) ↔ ¬ p i) (a : {i // p i}) :
    sumEquivOfInvolution p ι hι hp (Sum.inl a) = a.1 := by
  simp [sumEquivOfInvolution]

theorem sumEquivOfInvolution_inr {I : Type*} (p : I → Prop) [DecidablePred p] (ι : I → I)
    (hι : Function.Involutive ι) (hp : ∀ i, p (ι i) ↔ ¬ p i) (a : {i // p i}) :
    sumEquivOfInvolution p ι hι hp (Sum.inr a) = ι a.1 := by
  simp [sumEquivOfInvolution]

/-- the row reindexing `er`: `inl a ↦ a`, `inr a ↦ ι a` -/
def erE (h : ℕ) : Rp h W ⊕ Rp h W ≃ Fin (2 * h) × Fin 2 × W :=
  sumEquivOfInvolution (rp h) (iotaR h) (iotaR_invol h) (rp_iotaR h)

/-- the column reindexing `ec`: `inl a ↦ f a`, `inr a ↦ θ a` -/
def ecE (h : ℕ) : Rp h W ⊕ Rp h W ≃ Fin (2 * h) × Fin 2 × W :=
  (erE h).trans (Function.Involutive.toPerm (flipS h) (flipS_invol h))

theorem erE_inl (h : ℕ) (a : Rp h W) : erE h (Sum.inl a) = a.1 :=
  sumEquivOfInvolution_inl (rp h) (iotaR h) (iotaR_invol h) (rp_iotaR h) a

theorem erE_inr (h : ℕ) (a : Rp h W) : erE h (Sum.inr a) = iotaR h a.1 :=
  sumEquivOfInvolution_inr (rp h) (iotaR h) (iotaR_invol h) (rp_iotaR h) a

theorem ecE_inl (h : ℕ) (a : Rp h W) : ecE h (Sum.inl a) = flipS h a.1 := by
  have e : ecE h (Sum.inl a) = flipS h (erE h (Sum.inl a)) := rfl
  rw [e, erE_inl]

theorem ecE_inr (h : ℕ) (a : Rp h W) : ecE h (Sum.inr a) = reflT h a.1 := by
  have e : ecE h (Sum.inr a) = flipS h (erE h (Sum.inr a)) := rfl
  rw [e, erE_inr]
  exact flipS_iotaR h a.1

/-! ## 7. The blocks and the signed block identity -/

variable [Fintype W] [DecidableEq W]

/-- **The assembled Dirac matrix**: planes `b0, bh`, positive-side data `(Bp, Vp)`, reflected negative-side data
`(Bm, Vm)`. -/
def Dop (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Bp Bm : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Vp Vm : ℕ → Matrix W W ℂ) :
    Matrix (Fin (2 * h) × Fin 2 × W) (Fin (2 * h) × Fin 2 × W) ℂ :=
  sliceOp h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm)

/-- `N = D[R₊, C₊]` of the reflection-symmetric configuration with positive-side data `(Bp, Vp)` -/
def Nblk (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Bp : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Vp : ℕ → Matrix W W ℂ) :
    Matrix (Rp h W) (Rp h W) ℂ :=
  fun a b => Dop h b0 bh Bp Bp Vp Vp a.1 (flipS h b.1)

/-- selector of the components on the time slice `c` -/
def tsel (h c : ℕ) (a : Rp h W) : ℂ := if a.1.1.val = c then 1 else 0

/-- a `W × W` matrix placed on the components of the time slice `c`, zero elsewhere -/
def padOne (h c : ℕ) (P : Matrix W W ℂ) : Matrix (Rp h W) (Rp h W) ℂ :=
  fun a b => if a.1.1.val = c ∧ b.1.1.val = c then P a.1.2.2 b.1.2.2 else 0

/-- `A₁`: the `(−,−)` block of the plane `0` and the `(+,+)` block of the plane `h`, padded by zero -/
def A1blk (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) : Matrix (Rp h W) (Rp h W) ℂ :=
  padOne h 0 (b0.submatrix (Prod.mk sM) (Prod.mk sM)) + padOne h h (bh.submatrix (Prod.mk sP) (Prod.mk sP))

/-- `A₂`: the `(+,+)` block of the plane `0` and the `(−,−)` block of the plane `h`, padded by zero -/
def A2blk (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) : Matrix (Rp h W) (Rp h W) ℂ :=
  padOne h 0 (b0.submatrix (Prod.mk sP) (Prod.mk sP)) + padOne h h (bh.submatrix (Prod.mk sM) (Prod.mk sM))

theorem padOne_posSemidef (h c : ℕ) (P : Matrix W W ℂ) (hP : P.PosSemidef) :
    (padOne h c P).PosSemidef := by
  have e : padOne h c P
      = (Matrix.diagonal (tsel h c))ᴴ
        * P.submatrix (fun a : Rp h W => a.1.2.2) (fun a : Rp h W => a.1.2.2)
        * Matrix.diagonal (tsel h c) := by
    ext a b
    rw [Matrix.diagonal_conjTranspose, Matrix.mul_diagonal, Matrix.diagonal_mul, Pi.star_apply,
      Matrix.submatrix_apply]
    unfold padOne tsel
    by_cases h1 : a.1.1.val = c <;> by_cases h2 : b.1.1.val = c <;> simp [h1, h2]
  rw [e]
  exact (hP.submatrix _).conjTranspose_mul_mul_same _

theorem A1blk_posSemidef (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (h0 : (b0.submatrix (Prod.mk sM) (Prod.mk sM)).PosSemidef)
    (h1 : (bh.submatrix (Prod.mk sP) (Prod.mk sP)).PosSemidef) : (A1blk h b0 bh).PosSemidef :=
  (padOne_posSemidef h 0 _ h0).add (padOne_posSemidef h h _ h1)

theorem A2blk_posSemidef (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (h0 : (b0.submatrix (Prod.mk sP) (Prod.mk sP)).PosSemidef)
    (h1 : (bh.submatrix (Prod.mk sM) (Prod.mk sM)).PosSemidef) : (A2blk h b0 bh).PosSemidef :=
  (padOne_posSemidef h 0 _ h0).add (padOne_posSemidef h h _ h1)

/-- the row signs `S_r = diag(1, σ(ι a))`, `σ = ε₀ γ₄` -/
def sgnR (h : ℕ) : Rp h W ⊕ Rp h W → ℂ :=
  Sum.elim (fun _ => 1) (fun a => eps (th h a.1.1.val) * gam (flF h a.1.1 a.1.2.1))

/-- the column signs `S_c = diag(1, σ(θ b))` -/
def sgnC (h : ℕ) : Rp h W ⊕ Rp h W → ℂ :=
  Sum.elim (fun _ => 1) (fun b => eps (th h b.1.1.val) * gam b.1.2.1)

theorem sgnR_sq (h : ℕ) (i : Rp h W ⊕ Rp h W) : sgnR h i ^ 2 = 1 := by
  rcases i with a | a
  · show (1 : ℂ) ^ 2 = 1
    norm_num
  · show (eps (th h a.1.1.val) * gam (flF h a.1.1 a.1.2.1)) ^ 2 = 1
    have e1 := eps_mul_self (th h a.1.1.val)
    have e2 := gam_mul_self (flF h a.1.1 a.1.2.1)
    linear_combination (gam (flF h a.1.1 a.1.2.1) * gam (flF h a.1.1 a.1.2.1)) * e1 + e2

theorem sgnC_sq (h : ℕ) (i : Rp h W ⊕ Rp h W) : sgnC h i ^ 2 = 1 := by
  rcases i with a | a
  · show (1 : ℂ) ^ 2 = 1
    norm_num
  · show (eps (th h a.1.1.val) * gam a.1.2.1) ^ 2 = 1
    have e1 := eps_mul_self (th h a.1.1.val)
    have e2 := gam_mul_self a.1.2.1
    linear_combination (gam a.1.2.1 * gam a.1.2.1) * e1 + e2

/-- **(P5) The signed block form of the time-slice operator.**;
numerics earlier data files.
For every assembled configuration (planes `b0, bh`, positive-side data `(Bp, Vp)`, reflected negative-side data
`(Bm, Vm)`), with slice matrices satisfying `B = Γ₄ Bᴴ Γ₄`:
`S_r * D.submatrix er ec * S_c = [[N(Bp,Vp), A₁], [−A₂, N(Bm,Vm)ᴴ]]`. -/
theorem slice_signed_block (h : ℕ) (hh : 0 < h)
    (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Bp Bm : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Vp Vm : ℕ → Matrix W W ℂ)
    (hb0 : GammaHerm b0) (hbh : GammaHerm bh) (hBp : ∀ k, GammaHerm (Bp k))
    (hBm : ∀ k, GammaHerm (Bm k)) :
    Matrix.diagonal (sgnR h) * (Dop h b0 bh Bp Bm Vp Vm).submatrix (erE h) (ecE h)
        * Matrix.diagonal (sgnC h)
      = Matrix.fromBlocks (Nblk h b0 bh Bp Vp) (A1blk h b0 bh) (-(A2blk h b0 bh))
          (Nblk h b0 bh Bm Vm)ᴴ := by
  ext i j
  rw [Matrix.mul_diagonal, Matrix.diagonal_mul, Matrix.submatrix_apply]
  rcases i with a | a <;> rcases j with b | b
  · rw [Matrix.fromBlocks_apply₁₁, erE_inl, ecE_inl]
    show (1 : ℂ) * entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) a.1.1.val a.1.2.1 a.1.2.2
        b.1.1.val (flF h b.1.1 b.1.2.1) b.1.2.2 * (1 : ℂ)
      = entry h (Bfull h b0 bh Bp Bp) (Vfull h Vp Vp) a.1.1.val a.1.2.1 a.1.2.2
        b.1.1.val (flF h b.1.1 b.1.2.1) b.1.2.2
    rw [one_mul, mul_one]
    exact entry_pos_indep h hh b0 bh Bp Bm Bp Vp Vm Vp a.1.1.val a.1.2.1 a.1.2.2 b.1.1.val b.1.2.1
      (flF h b.1.1 b.1.2.1) b.1.2.2 a.2 b.2 rfl
  · rw [Matrix.fromBlocks_apply₁₂, erE_inl, ecE_inr]
    show (1 : ℂ) * entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) a.1.1.val a.1.2.1 a.1.2.2
        (th h b.1.1.val) b.1.2.1 b.1.2.2 * (eps (th h b.1.1.val) * gam b.1.2.1)
      = (if a.1.1.val = 0 ∧ b.1.1.val = 0 then b0 (sM, a.1.2.2) (sM, b.1.2.2) else 0)
        + (if a.1.1.val = h ∧ b.1.1.val = h then bh (sP, a.1.2.2) (sP, b.1.2.2) else 0)
    rw [one_mul, entry_cross₁ h hh _ _ a.1.1.val a.1.2.1 a.1.2.2 b.1.1.val b.1.2.1 b.1.2.2 a.2 b.2,
      Bfull_zero, Bfull_half h hh]
  · rw [Matrix.fromBlocks_apply₂₁, erE_inr, ecE_inl]
    show (eps (th h a.1.1.val) * gam (flF h a.1.1 a.1.2.1))
        * entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) (th h a.1.1.val) (flF h a.1.1 a.1.2.1)
          a.1.2.2 b.1.1.val (flF h b.1.1 b.1.2.1) b.1.2.2 * (1 : ℂ)
      = -((if a.1.1.val = 0 ∧ b.1.1.val = 0 then b0 (sP, a.1.2.2) (sP, b.1.2.2) else 0)
        + (if a.1.1.val = h ∧ b.1.1.val = h then bh (sM, a.1.2.2) (sM, b.1.2.2) else 0))
    rw [mul_one, entry_cross₂ h hh _ _ a.1.1.val a.1.2.1 a.1.2.2 b.1.1.val b.1.2.1 b.1.2.2
      (flF h a.1.1 a.1.2.1) (flF h b.1.1 b.1.2.1) a.2 b.2 rfl rfl, Bfull_zero, Bfull_half h hh]
  · rw [Matrix.fromBlocks_apply₂₂, erE_inr, ecE_inr, Matrix.conjTranspose_apply]
    show (eps (th h a.1.1.val) * gam (flF h a.1.1 a.1.2.1))
        * entry h (Bfull h b0 bh Bp Bm) (Vfull h Vp Vm) (th h a.1.1.val) (flF h a.1.1 a.1.2.1)
          a.1.2.2 (th h b.1.1.val) b.1.2.1 b.1.2.2 * (eps (th h b.1.1.val) * gam b.1.2.1)
      = star (entry h (Bfull h b0 bh Bm Bm) (Vfull h Vm Vm) b.1.1.val b.1.2.1 b.1.2.2
          a.1.1.val (flF h a.1.1 a.1.2.1) a.1.2.2)
    exact entry_lower_right h hh b0 bh Bp Bm Vp Vm hb0 hbh hBp hBm a.1.1.val a.1.2.1 a.1.2.2
      b.1.1.val b.1.2.1 b.1.2.2 (flF h a.1.1 a.1.2.1) a.1.1.isLt b.1.1.isLt a.2 b.2 rfl

/-- `U₊ ↦ N(U₀, U₊)` is continuous when the positive-side data are (entrywise) continuous -/
theorem continuous_Nblk {X : Type*} [TopologicalSpace X] (h : ℕ)
    (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Bp : X → ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Vp : X → ℕ → Matrix W W ℂ)
    (hBc : ∀ k i j, Continuous fun x => Bp x k i j) (hVc : ∀ k v v', Continuous fun x => Vp x k v v') :
    Continuous fun x => Nblk h b0 bh (Bp x) (Vp x) := by
  refine continuous_matrix fun a b => ?_
  show Continuous fun x => entry h (Bfull h b0 bh (Bp x) (Bp x)) (Vfull h (Vp x) (Vp x))
    a.1.1.val a.1.2.1 a.1.2.2 b.1.1.val (flF h b.1.1 b.1.2.1) b.1.2.2
  exact continuous_entry h (fun x => Bfull h b0 bh (Bp x) (Bp x)) (fun x => Vfull h (Vp x) (Vp x))
    (continuous_Bfull h b0 bh Bp hBc) (continuous_Vfull h Vp hVc) _ _ _ _ _ _

/-! ## 8. Slices of Wilson type (layer 2, slice level) -/

/-- A slice matrix of Wilson type `[[A, K], [−K, A]]` in the `γ₄ = ±1` splitting (`(+,+) = (−,−) = A`,
`(+,−) = K`, `(−,+) = −K`).  For the Wilson operator with `r = 1`:
`A = (m + 4) − ½ Σ_i (T_i + T_iᴴ)` and `K = ½ Σ_i (−i σ_i) ⊗ (T_i − T_iᴴ)` (both Hermitian), with
`γ_i = [[0, −iσ_i], [iσ_i, 0]]`. -/
def wilsonSlice (A K : Matrix W W ℂ) : Matrix (Fin 2 × W) (Fin 2 × W) ℂ :=
  fun a b => if a.1.val = b.1.val then A a.2 b.2 else if a.1.val = 1 then K a.2 b.2 else -K a.2 b.2

theorem wilsonSlice_gammaHerm (A K : Matrix W W ℂ) (hA : A.IsHermitian) (hK : K.IsHermitian) :
    GammaHerm (wilsonSlice A K) := by
  intro s s' w w'
  have hs2 := s.isLt
  have hs2' := s'.isLt
  have eA : A w w' = star (A w' w) := (hA.apply w w').symm
  have eK : K w w' = star (K w' w) := (hK.apply w w').symm
  show (if s.val = s'.val then A w w' else if s.val = 1 then K w w' else -K w w')
    = gam s * gam s' * star (if s'.val = s.val then A w' w else if s'.val = 1 then K w' w else -K w' w)
  by_cases c : s.val = s'.val
  · have c' : s'.val = s.val := c.symm
    have e : s' = s := Fin.ext c'
    rw [if_pos c, if_pos c', e, eA]
    have g := gam_mul_self s
    linear_combination (-(star (A w' w))) * g
  · have c' : ¬ (s'.val = s.val) := fun e => c e.symm
    by_cases c1 : s.val = 1
    · have c0' : s'.val = 0 := by omega
      have c1' : ¬ (s'.val = 1) := by omega
      rw [if_neg c, if_pos c1, if_neg c', if_neg c1', gam_of_one c1, gam_of_zero c0', star_neg, ← eK]
      ring
    · have c0 : s.val = 0 := by omega
      have c1' : s'.val = 1 := by omega
      rw [if_neg c, if_neg c1, if_neg c', if_pos c1', gam_of_zero c0, gam_of_one c1', ← eK]
      ring

theorem wilsonSlice_block (A K : Matrix W W ℂ) (s : Fin 2) :
    (wilsonSlice A K).submatrix (Prod.mk s) (Prod.mk s) = A := by
  ext w w'
  show (if s.val = s.val then A w w' else if s.val = 1 then K w w' else -K w w') = A w w'
  rw [if_pos rfl]

theorem continuous_wilsonSlice {X : Type*} [TopologicalSpace X] (A K : X → Matrix W W ℂ)
    (hA : ∀ v v', Continuous fun x => A x v v') (hK : ∀ v v', Continuous fun x => K x v v')
    (i j : Fin 2 × W) : Continuous fun x => wilsonSlice (A x) (K x) i j := by
  show Continuous fun x => if i.1.val = j.1.val then A x i.2 j.2
    else if i.1.val = 1 then K x i.2 j.2 else -K x i.2 j.2
  by_cases c : i.1.val = j.1.val
  · simp only [if_pos c]
    exact hA _ _
  · by_cases c1 : i.1.val = 1
    · simp only [if_neg c, if_pos c1]
      exact hK _ _
    · simp only [if_neg c, if_neg c1]
      exact (hK _ _).neg

end FermionSliceBlock

-- ===== part : SliceFinal.part.lean =====

/-! # Site reflection positivity for the time-slice (Wilson) operator 

One statement in which the lattice hypothesis `hblock` of `site_reflection_positive_dirac_signed` is paid by the
concrete time-slice operator `FermionSliceBlock.Dop`. The gauge weight stays abstract (`k h h`), as in Lemma 3 of paper A. -/
namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionDetIntegral
open scoped ComplexOrder

/-- **Site reflection positivity of the weight `det D^{2j}` for the time-slice operator** (`N_f = 2j`).
`Y` = plane data (`U₀`), `X` = positive-side data (`U₊`); the Dirac matrix of `(U₀, U₊, U₋)` is
`Dop hT (b0 U₀) (bh U₀) (Bp U₊) (Bp U₋) (Vp U₊) (Vp U₋)` on the circle of `2·hT` time slices, antiperiodic in
time, with the negative side filled by the reflection of `U₋`.
Hypotheses on the operator: every slice matrix satisfies `B = Γ₄ Bᴴ Γ₄`; the two diagonal `γ₄`-blocks of the two
plane matrices are positive semidefinite; the positive-side data are entrywise continuous.
Then `∫ φ(U₀,U₊) φ(U₀,U₋) k h h · Re det D^{2j} ≥ 0`. -/
theorem site_reflection_positive_slices {X Y W : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype W] [DecidableEq W]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ)
    (b0 bh : Y → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Bp : X → ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Vp : X → ℕ → Matrix W W ℂ)
    (hb0 : ∀ c, GammaHerm (b0 c)) (hbh : ∀ c, GammaHerm (bh c)) (hBp : ∀ x t, GammaHerm (Bp x t))
    (hA0m : ∀ c, ((b0 c).submatrix (Prod.mk sM) (Prod.mk sM)).PosSemidef)
    (hA0p : ∀ c, ((b0 c).submatrix (Prod.mk sP) (Prod.mk sP)).PosSemidef)
    (hAhm : ∀ c, ((bh c).submatrix (Prod.mk sM) (Prod.mk sM)).PosSemidef)
    (hAhp : ∀ c, ((bh c).submatrix (Prod.mk sP) (Prod.mk sP)).PosSemidef)
    (hBc : ∀ t i i', Continuous fun x => Bp x t i i')
    (hVc : ∀ t v v', Continuous fun x => Vp x t v v')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((Dop hT (b0 p.1) (bh p.1) (Bp p.2.1) (Bp p.2.2) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X),
      |((Dop hT (b0 p.1) (bh p.1) (Bp p.2.1) (Bp p.2.2) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re|
        ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((Dop hT (b0 p.1) (bh p.1) (Bp p.2.1) (Bp p.2.2) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have hS : ((Matrix.diagonal (sgnR (W := W) hT)).det * (Matrix.diagonal (sgnC (W := W) hT)).det) ^ 2
      = 1 := by
    rw [mul_pow, det_diagonal_sign_sq _ (sgnR_sq hT), det_diagonal_sign_sq _ (sgnC_sq hT), one_mul]
  exact site_reflection_positive_dirac_signed (n := Rp hT W) ν μ₀ j
    (fun p => Dop hT (b0 p.1) (bh p.1) (Bp p.2.1) (Bp p.2.2) (Vp p.2.1) (Vp p.2.2))
    (erE hT) (ecE hT) (Matrix.diagonal (sgnR hT)) (Matrix.diagonal (sgnC hT)) hS
    (fun c => A1blk hT (b0 c) (bh c)) (fun c => A2blk hT (b0 c) (bh c))
    (fun c => A1blk_posSemidef hT _ _ (hA0m c) (hAhp c))
    (fun c => A2blk_posSemidef hT _ _ (hA0p c) (hAhm c))
    (fun q => Nblk hT (b0 q.1) (bh q.1) (Bp q.2) (Vp q.2))
    (fun c => continuous_Nblk hT (b0 c) (bh c) Bp Vp hBc hVc)
    (fun p => slice_signed_block hT hpos (b0 p.1) (bh p.1) (Bp p.2.1) (Bp p.2.2) (Vp p.2.1)
      (Vp p.2.2) (hb0 p.1) (hbh p.1) (hBp p.2.1) (hBp p.2.2))
    k hw φ hk hhw hφ Ck Ch Cφ Cρ bk bhw bφ hk0 hρm bρ

/-- **The same for slices of Wilson type** `B_t = [[A_t, K_t], [−K_t, A_t]]` (`r = 1`):
the plane matrices `A₀(U₀)`, `A_h(U₀)` positive semidefinite (for the Wilson operator with unitary links and
`m > −1` they are positive definite: `FermionDetIntegral.wilson_plane_posDef`), all other `A_t`, `K_t`
Hermitian and entrywise continuous in the positive-side data, the time-link matrices `V_t` arbitrary
(entrywise continuous). -/
theorem site_reflection_positive_wilson_slices {X Y W : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype W] [DecidableEq W]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ)
    (A0 Ah K0 Kh : Y → Matrix W W ℂ) (Ap Kp Vp : X → ℕ → Matrix W W ℂ)
    (hA0 : ∀ c, (A0 c).PosSemidef) (hAh : ∀ c, (Ah c).PosSemidef)
    (hK0 : ∀ c, (K0 c).IsHermitian) (hKh : ∀ c, (Kh c).IsHermitian)
    (hAp : ∀ x t, (Ap x t).IsHermitian) (hKp : ∀ x t, (Kp x t).IsHermitian)
    (hAc : ∀ t v v', Continuous fun x => Ap x t v v')
    (hKc : ∀ t v v', Continuous fun x => Kp x t v v')
    (hVc : ∀ t v v', Continuous fun x => Vp x t v v')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((Dop hT (wilsonSlice (A0 p.1) (K0 p.1)) (wilsonSlice (Ah p.1) (Kh p.1))
        (fun t => wilsonSlice (Ap p.2.1 t) (Kp p.2.1 t))
        (fun t => wilsonSlice (Ap p.2.2 t) (Kp p.2.2 t)) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X),
      |((Dop hT (wilsonSlice (A0 p.1) (K0 p.1)) (wilsonSlice (Ah p.1) (Kh p.1))
        (fun t => wilsonSlice (Ap p.2.1 t) (Kp p.2.1 t))
        (fun t => wilsonSlice (Ap p.2.2 t) (Kp p.2.2 t)) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re|
        ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((Dop hT (wilsonSlice (A0 p.1) (K0 p.1)) (wilsonSlice (Ah p.1) (Kh p.1))
          (fun t => wilsonSlice (Ap p.2.1 t) (Kp p.2.1 t))
          (fun t => wilsonSlice (Ap p.2.2 t) (Kp p.2.2 t)) (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have hblk0 : ∀ (c : Y) (s : Fin 2),
      ((wilsonSlice (A0 c) (K0 c)).submatrix (Prod.mk s) (Prod.mk s)).PosSemidef := by
    intro c s
    rw [wilsonSlice_block]
    exact hA0 c
  have hblkh : ∀ (c : Y) (s : Fin 2),
      ((wilsonSlice (Ah c) (Kh c)).submatrix (Prod.mk s) (Prod.mk s)).PosSemidef := by
    intro c s
    rw [wilsonSlice_block]
    exact hAh c
  exact site_reflection_positive_slices ν μ₀ hT hpos j
    (fun c => wilsonSlice (A0 c) (K0 c)) (fun c => wilsonSlice (Ah c) (Kh c))
    (fun x t => wilsonSlice (Ap x t) (Kp x t)) Vp
    (fun c => wilsonSlice_gammaHerm _ _ (hA0 c).isHermitian (hK0 c))
    (fun c => wilsonSlice_gammaHerm _ _ (hAh c).isHermitian (hKh c))
    (fun x t => wilsonSlice_gammaHerm _ _ (hAp x t) (hKp x t))
    (fun c => hblk0 c sM) (fun c => hblk0 c sP) (fun c => hblkh c sM) (fun c => hblkh c sP)
    (fun t i i' => continuous_wilsonSlice (fun x => Ap x t) (fun x => Kp x t) (hAc t) (hKc t) i i')
    hVc k hw φ hk hhw hφ Ck Ch Cφ Cρ bk bhw bφ hk0 hρm bρ

end FermionSliceReflection


-- ===== part : SliceExtra.part.lean =====

/-! # `γ₅`-Hermiticity of the time-slice operator (the weight `det D^{2j}` is real and ≥ 0), and the
statement with the Wilson plane matrix 

-/
namespace FermionSliceBlock

open Matrix
open scoped ComplexOrder

section Gamma5

variable {W : Type*} [Fintype W] [DecidableEq W]

/-- exchange of the two `γ₄` components (the action of `γ₅` on the index, up to a sign) -/
def swF (s : Fin 2) : Fin 2 := ⟨1 - s.val, by have := s.isLt; omega⟩

def swI (h : ℕ) (a : Fin (2 * h) × Fin 2 × W) : Fin (2 * h) × Fin 2 × W := (a.1, swF a.2.1, a.2.2)

theorem swI_invol (h : ℕ) : Function.Involutive (swI (W := W) h) := by
  intro a
  apply Prod.ext
  · rfl
  · apply Prod.ext
    · apply Fin.ext
      show 1 - (1 - a.2.1.val) = a.2.1.val
      have := a.2.1.isLt
      omega
    · rfl

/-- `Γ₅ M Γ₅ = Mᴴ` entrywise, `Γ₅` = the exchange of the two `γ₄` components -/
def Gamma5Herm (M : Matrix (Fin 2 × W) (Fin 2 × W) ℂ) : Prop :=
  ∀ (s s' : Fin 2) (w w' : W), M (swF s, w) (swF s', w') = star (M (s', w') (s, w))

theorem entry_gamma5 (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ)
    (hB : ∀ t, Gamma5Herm (B t))
    (t : ℕ) (s : Fin 2) (w : W) (t' : ℕ) (s' : Fin 2) (w' : W) :
    entry h B V t (swF s) w t' (swF s') w' = star (entry h B V t' s' w' t s w) := by
  have hs2 := s.isLt
  have hs2' := s'.isLt
  have v1 : (swF s).val = 1 - s.val := rfl
  have v2 : (swF s').val = 1 - s'.val := rfl
  have e1 : (if t' = t then B t (swF s, w) (swF s', w') else 0)
      = star (if t = t' then B t' (s', w') (s, w) else 0) := by
    by_cases hc : t' = t
    · have hc' : t = t' := hc.symm
      rw [if_pos hc, if_pos hc', hB t s s' w w', hc]
    · have hc' : ¬ (t = t') := fun e => hc e.symm
      rw [if_neg hc, if_neg hc', star_zero]
  have e2 : (if t' = sc h t ∧ (swF s).val = 0 ∧ (swF s').val = 0 then V t w w' else 0)
      = star (if t' = sc h t ∧ s'.val = 1 ∧ s.val = 1 then star (V t w w') else 0) := by
    by_cases hc : t' = sc h t ∧ (swF s).val = 0 ∧ (swF s').val = 0
    · have g1 : s'.val = 1 := by omega
      have g2 : s.val = 1 := by omega
      have hc' : t' = sc h t ∧ s'.val = 1 ∧ s.val = 1 := ⟨hc.1, g1, g2⟩
      rw [if_pos hc, if_pos hc', star_star]
    · have hc' : ¬ (t' = sc h t ∧ s'.val = 1 ∧ s.val = 1) := by
        intro e
        have g1 : (swF s).val = 0 := by omega
        have g2 : (swF s').val = 0 := by omega
        exact hc ⟨e.1, g1, g2⟩
      rw [if_neg hc, if_neg hc', star_zero]
  have e3 : (if t = sc h t' ∧ (swF s).val = 1 ∧ (swF s').val = 1 then star (V t' w' w) else 0)
      = star (if t = sc h t' ∧ s'.val = 0 ∧ s.val = 0 then V t' w' w else 0) := by
    by_cases hc : t = sc h t' ∧ (swF s).val = 1 ∧ (swF s').val = 1
    · have g1 : s'.val = 0 := by omega
      have g2 : s.val = 0 := by omega
      have hc' : t = sc h t' ∧ s'.val = 0 ∧ s.val = 0 := ⟨hc.1, g1, g2⟩
      rw [if_pos hc, if_pos hc']
    · have hc' : ¬ (t = sc h t' ∧ s'.val = 0 ∧ s.val = 0) := by
        intro e
        have g1 : (swF s).val = 1 := by omega
        have g2 : (swF s').val = 1 := by omega
        exact hc ⟨e.1, g1, g2⟩
      rw [if_neg hc, if_neg hc', star_zero]
  unfold entry
  rw [e1, e2, e3, star_sub, star_sub]
  ring

/-- **`γ₅`-Hermiticity of the time-slice operator**: `D.submatrix σ σ = Dᴴ` for the exchange `σ` of the two
`γ₄` components (any time-link matrices `V`). -/
theorem sliceOp_gamma5 (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ)
    (hB : ∀ t, Gamma5Herm (B t)) :
    (sliceOp h B V).submatrix (swI h) (swI h) = (sliceOp h B V)ᴴ := by
  ext a b
  rw [Matrix.submatrix_apply, Matrix.conjTranspose_apply]
  exact entry_gamma5 h B V hB a.1.val a.2.1 a.2.2 b.1.val b.2.1 b.2.2

/-- the determinant of the time-slice operator is real -/
theorem sliceOp_det_real (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (V : ℕ → Matrix W W ℂ)
    (hB : ∀ t, Gamma5Herm (B t)) : star (sliceOp h B V).det = (sliceOp h B V).det := by
  have e := sliceOp_gamma5 h B V hB
  have h1 : ((sliceOp h B V).submatrix (swI h) (swI h)).det = (sliceOp h B V).det :=
    Matrix.det_submatrix_equiv_self (Function.Involutive.toPerm (swI h) (swI_invol h)) (sliceOp h B V)
  rw [e, Matrix.det_conjTranspose] at h1
  exact h1

/-- **The weight `det D^{2j}` is real and nonnegative** (`N_f = 2j`). -/
theorem sliceOp_det_pow_even_nonneg (h : ℕ) (B : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (V : ℕ → Matrix W W ℂ) (hB : ∀ t, Gamma5Herm (B t)) (j : ℕ) :
    0 ≤ ((sliceOp h B V).det ^ (2 * j)).re ∧ ((sliceOp h B V).det ^ (2 * j)).im = 0 := by
  have hreal := sliceOp_det_real h B V hB
  obtain ⟨r, hr⟩ := Complex.conj_eq_iff_real.mp hreal
  rw [hr, ← Complex.ofReal_pow, Complex.ofReal_re, Complex.ofReal_im]
  exact ⟨Even.pow_nonneg (even_two_mul j) r, rfl⟩

/-- the same for the assembled operator `Dop` -/
theorem Dop_det_pow_even_nonneg (h : ℕ) (b0 bh : Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Bp Bm : ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Vp Vm : ℕ → Matrix W W ℂ)
    (h0 : Gamma5Herm b0) (h1 : Gamma5Herm bh) (h2 : ∀ k, Gamma5Herm (Bp k))
    (h3 : ∀ k, Gamma5Herm (Bm k)) (j : ℕ) :
    0 ≤ ((Dop h b0 bh Bp Bm Vp Vm).det ^ (2 * j)).re
      ∧ ((Dop h b0 bh Bp Bm Vp Vm).det ^ (2 * j)).im = 0 :=
  sliceOp_det_pow_even_nonneg h _ _
    (fun t => Bfull_induction Gamma5Herm h b0 bh Bp Bm t h0 h1 h2 h3) j

/-- slices of Wilson type are `γ₅`-Hermitian -/
theorem wilsonSlice_gamma5Herm (A K : Matrix W W ℂ) (hA : A.IsHermitian) (hK : K.IsHermitian) :
    Gamma5Herm (wilsonSlice A K) := by
  intro s s' w w'
  have hs2 := s.isLt
  have hs2' := s'.isLt
  have eA : A w w' = star (A w' w) := (hA.apply w w').symm
  have eK : K w w' = star (K w' w) := (hK.apply w w').symm
  show (if 1 - s.val = 1 - s'.val then A w w' else if 1 - s.val = 1 then K w w' else -K w w')
    = star (if s'.val = s.val then A w' w else if s'.val = 1 then K w' w else -K w' w)
  by_cases c : s.val = s'.val
  · have c1 : 1 - s.val = 1 - s'.val := by omega
    have c' : s'.val = s.val := c.symm
    rw [if_pos c1, if_pos c', eA]
  · have c1 : ¬ (1 - s.val = 1 - s'.val) := by omega
    have c' : ¬ (s'.val = s.val) := fun e => c e.symm
    by_cases d : s.val = 1
    · have d1 : ¬ (1 - s.val = 1) := by omega
      have d2 : ¬ (s'.val = 1) := by omega
      rw [if_neg c1, if_neg d1, if_neg c', if_neg d2, star_neg, ← eK]
    · have d1 : 1 - s.val = 1 := by omega
      have d2 : s'.val = 1 := by omega
      rw [if_neg c1, if_pos d1, if_neg c', if_pos d2, ← eK]

/-- the plane matrix of the Wilson operator (`r = 1`): `(m + 1) + Σ_i (1 − ½ (T_i + T_iᴴ))`
`= (m + 1 + d) − ½ Σ_i (T_i + T_iᴴ)`, `T_i` the unitary one-step shifts inside the time slice -/
noncomputable def wilsonPlane {d : ℕ} (m : ℝ) (T : Fin d → Matrix W W ℂ) : Matrix W W ℂ :=
  (m + 1 : ℝ) • (1 : Matrix W W ℂ) + ∑ i, ((1 : Matrix W W ℂ) - (1 / 2 : ℝ) • (T i + (T i)ᴴ))

theorem wilsonPlane_posDef {d : ℕ} (m : ℝ) (hm : -1 < m) (T : Fin d → Matrix W W ℂ)
    (hT : ∀ i, (T i)ᴴ * T i = 1) : (wilsonPlane m T).PosDef :=
  FermionDetIntegral.wilson_plane_posDef m hm T hT

theorem continuous_wilsonPlane {X : Type*} [TopologicalSpace X] {d : ℕ} (m : ℝ)
    (T : X → Fin d → Matrix W W ℂ) (hT : ∀ i, Continuous fun x => T x i) :
    Continuous fun x => wilsonPlane m (T x) := by
  unfold wilsonPlane
  refine continuous_const.add (continuous_finsetSum _ fun i _ => ?_)
  exact continuous_const.sub (((hT i).add (hT i).matrix_conjTranspose).const_smul (1 / 2 : ℝ))

end Gamma5

end FermionSliceBlock

namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionDetIntegral
open scoped ComplexOrder

/-- **Site reflection positivity of the weight `det D^{2j}` for the Wilson operator in time-slice form, with the
Wilson plane matrix.**  Slices `B_t = [[A_t, K_t], [−K_t, A_t]]` with
`A_t = (m + 1 + d) − ½ Σ_i (T_{t,i} + T_{t,i}ᴴ)`, unitary shifts `T_{t,i}`, `m > −1`, Hermitian `K_t`, arbitrary
time-link matrices `V_t`; everything entrywise continuous in the positive-side data.  The hypotheses on the
operator of `site_reflection_positive_slices` are paid; the gauge weight `k h h` stays abstract. -/
theorem site_reflection_positive_wilson {X Y W : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype W] [DecidableEq W]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ) {d : ℕ} (m : ℝ) (hm : -1 < m)
    (T0 Th : Y → Fin d → Matrix W W ℂ) (K0 Kh : Y → Matrix W W ℂ)
    (Tp : X → ℕ → Fin d → Matrix W W ℂ) (Kp Vp : X → ℕ → Matrix W W ℂ)
    (hT0 : ∀ c i, (T0 c i)ᴴ * T0 c i = 1) (hTh : ∀ c i, (Th c i)ᴴ * Th c i = 1)
    (hTp : ∀ x t i, (Tp x t i)ᴴ * Tp x t i = 1)
    (hK0 : ∀ c, (K0 c).IsHermitian) (hKh : ∀ c, (Kh c).IsHermitian)
    (hKp : ∀ x t, (Kp x t).IsHermitian)
    (hTc : ∀ t i, Continuous fun x => Tp x t i)
    (hKc : ∀ t v v', Continuous fun x => Kp x t v v')
    (hVc : ∀ t v v', Continuous fun x => Vp x t v v')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
        (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
        (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
        (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
        (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X),
      |((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
        (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
        (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
        (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
        (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re| ≤ Cρ) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) :=
  site_reflection_positive_wilson_slices ν μ₀ hT hpos j
    (fun c => wilsonPlane m (T0 c)) (fun c => wilsonPlane m (Th c)) K0 Kh
    (fun x t => wilsonPlane m (Tp x t)) Kp Vp
    (fun c => (wilsonPlane_posDef m hm _ (hT0 c)).posSemidef)
    (fun c => (wilsonPlane_posDef m hm _ (hTh c)).posSemidef)
    hK0 hKh
    (fun x t => (wilsonPlane_posDef m hm _ (hTp x t)).isHermitian) hKp
    (fun t v v' => (continuous_wilsonPlane m (fun x => Tp x t) (hTc t)).matrix_elem v v')
    hKc hVc k hw φ hk hhw hφ Ck Ch Cφ Cρ bk bhw bφ hk0 hρm bρ

/-- For the same operator the weight is real and nonnegative: `det D^{2j} ≥ 0` (so `Re` can be dropped and the
weighted measure is a positive measure). -/
theorem wilson_weight_nonneg {W : Type*} [Fintype W] [DecidableEq W]
    (hT : ℕ) (j : ℕ) (A0 Ah K0 Kh : Matrix W W ℂ) (Ap Am Kp Km Vp Vm : ℕ → Matrix W W ℂ)
    (hA0 : A0.IsHermitian) (hAh : Ah.IsHermitian) (hK0 : K0.IsHermitian) (hKh : Kh.IsHermitian)
    (hAp : ∀ t, (Ap t).IsHermitian) (hAm : ∀ t, (Am t).IsHermitian)
    (hKp : ∀ t, (Kp t).IsHermitian) (hKm : ∀ t, (Km t).IsHermitian) :
    0 ≤ ((Dop hT (wilsonSlice A0 K0) (wilsonSlice Ah Kh) (fun t => wilsonSlice (Ap t) (Kp t))
        (fun t => wilsonSlice (Am t) (Km t)) Vp Vm).det ^ (2 * j)).re
      ∧ ((Dop hT (wilsonSlice A0 K0) (wilsonSlice Ah Kh) (fun t => wilsonSlice (Ap t) (Kp t))
        (fun t => wilsonSlice (Am t) (Km t)) Vp Vm).det ^ (2 * j)).im = 0 :=
  Dop_det_pow_even_nonneg hT _ _ _ _ Vp Vm (wilsonSlice_gamma5Herm _ _ hA0 hK0)
    (wilsonSlice_gamma5Herm _ _ hAh hKh) (fun t => wilsonSlice_gamma5Herm _ _ (hAp t) (hKp t))
    (fun t => wilsonSlice_gamma5Herm _ _ (hAm t) (hKm t)) j

end FermionSliceReflection


-- ===== part : SliceMeasure.part.lean =====

/-! # Measure form: reflection positivity of the measure weighted by `k h h · det D^{2j}`  -/
namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionDetIntegral
open scoped ComplexOrder

/-- **Site reflection positivity of the determinant-weighted measure, Wilson operator in time-slice form.**
`μ = (μ₀ ⊗ ν ⊗ ν).withDensity w`, `w(U₀,U₊,U₋) = k(U₀) h(U₀,U₊) h(U₀,U₋) · det D[U₀,U₊,θU₋]^{2j}` (a nonnegative
weight: the determinant is real by `γ₅`-Hermiticity, `wilson_weight_nonneg`), `f(c,(a,b)) = φ(c,b)`,
`Θ(c,(a,b)) = (c,(b,a))`:  `∫ f(Θp) f(p) dμ ≥ 0`.  Same hypotheses as `site_reflection_positive_wilson`, plus
`h ≥ 0`. -/
theorem site_reflection_positive_wilson_measure {X Y W : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X] [MeasurableSpace Y]
    [Fintype W] [DecidableEq W]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ) {d : ℕ} (m : ℝ) (hm : -1 < m)
    (T0 Th : Y → Fin d → Matrix W W ℂ) (K0 Kh : Y → Matrix W W ℂ)
    (Tp : X → ℕ → Fin d → Matrix W W ℂ) (Kp Vp : X → ℕ → Matrix W W ℂ)
    (hT0 : ∀ c i, (T0 c i)ᴴ * T0 c i = 1) (hTh : ∀ c i, (Th c i)ᴴ * Th c i = 1)
    (hTp : ∀ x t i, (Tp x t i)ᴴ * Tp x t i = 1)
    (hK0 : ∀ c, (K0 c).IsHermitian) (hKh : ∀ c, (Kh c).IsHermitian)
    (hKp : ∀ x t, (Kp x t).IsHermitian)
    (hTc : ∀ t i, Continuous fun x => Tp x t i)
    (hKc : ∀ t v v', Continuous fun x => Kp x t v v')
    (hVc : ∀ t v v', Continuous fun x => Vp x t v v')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ Cρ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) (hh0 : ∀ p, 0 ≤ hw p)
    (hρm : Measurable fun p : Y × (X × X) =>
      ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re)
    (bρ : ∀ p : Y × (X × X),
      |((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re| ≤ Cρ) :
    let w : Y × (X × X) → NNReal := fun p =>
      ⟨k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2) *
          ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re,
        mul_nonneg (mul_nonneg (mul_nonneg (hk0 _) (hh0 _)) (hh0 _))
          (wilson_weight_nonneg hT j _ _ _ _ _ _ _ _ (Vp p.2.1) (Vp p.2.2)
            (wilsonPlane_posDef m hm _ (hT0 p.1)).isHermitian
            (wilsonPlane_posDef m hm _ (hTh p.1)).isHermitian (hK0 p.1) (hKh p.1)
            (fun t => (wilsonPlane_posDef m hm _ (hTp p.2.1 t)).isHermitian)
            (fun t => (wilsonPlane_posDef m hm _ (hTp p.2.2 t)).isHermitian)
            (fun t => hKp p.2.1 t) (fun t => hKp p.2.2 t)).1⟩
    0 ≤ ∫ p, φ (p.1, p.2.1) * φ (p.1, p.2.2)
        ∂((μ₀.prod (ν.prod ν)).withDensity fun p => (w p : ENNReal)) := by
  intro w
  have hwm : Measurable w := by
    apply Measurable.subtype_mk
    exact (((hk.comp measurable_fst).mul
      (hhw.comp (measurable_fst.prodMk measurable_snd.fst))).mul
      (hhw.comp (measurable_fst.prodMk measurable_snd.snd))).mul hρm
  rw [integral_withDensity_eq_integral_smul hwm]
  have hmain := site_reflection_positive_wilson ν μ₀ hT hpos j m hm T0 Th K0 Kh Tp Kp Vp hT0 hTh hTp
    hK0 hKh hKp hTc hKc hVc k hw φ hk hhw hφ Ck Ch Cφ Cρ bk bhw bφ hk0 hρm bρ
  have e : ∀ p : Y × (X × X), w p • (φ (p.1, p.2.1) * φ (p.1, p.2.2)) =
      φ (p.1, p.2.1) * φ (p.1, p.2.2) * (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re := by
    intro p
    rw [NNReal.smul_def, smul_eq_mul]
    change (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2) *
      ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re)
      * (φ (p.1, p.2.1) * φ (p.1, p.2.2)) = _
    ring
  rw [integral_congr_ae (Filter.Eventually.of_forall e)]
  exact hmain

end FermionSliceReflection


-- ===== part : SliceRegular.part.lean =====

/-! # The statement with continuity only: measurability and boundedness of the weight paid 

Paper side: /§4.3. `site_reflection_positive_wilson` and its measure form assume that
`Re det D^{2j}` is measurable and bounded.  Here both are derived from the joint continuity of the assembled Dirac
matrix (`continuous_Dop`) on the compact configuration space, so that the remaining hypotheses on the operator
are: unitary shifts, Hermitian `K`, `m > −1`, continuity. -/
namespace FermionDetWeight

open Matrix MeasureTheory

theorem det_pow_re_continuous {I P : Type*} [Fintype I] [DecidableEq I] [TopologicalSpace P]
    (Dm : P → Matrix I I ℂ) (hD : Continuous Dm) (k : ℕ) :
    Continuous fun p => ((Dm p).det ^ k).re :=
  Complex.continuous_re.comp (hD.matrix_det.pow k)

theorem det_pow_re_measurable_bounded {I P : Type*} [Fintype I] [DecidableEq I] [TopologicalSpace P]
    [CompactSpace P] [MeasurableSpace P] [OpensMeasurableSpace P] (Dm : P → Matrix I I ℂ)
    (hD : Continuous Dm) (k : ℕ) :
    (Measurable fun p => ((Dm p).det ^ k).re) ∧ ∃ C : ℝ, ∀ p, |((Dm p).det ^ k).re| ≤ C := by
  have hc := det_pow_re_continuous Dm hD k
  refine ⟨hc.measurable, ?_⟩
  obtain ⟨C, hC⟩ := isCompact_univ.exists_bound_of_continuousOn hc.continuousOn
  refine ⟨C, fun p => ?_⟩
  have h := hC p (Set.mem_univ p)
  rwa [Real.norm_eq_abs] at h

end FermionDetWeight

namespace FermionSliceBlock

open Matrix
open scoped ComplexOrder

section Regular

variable {W : Type*} [Fintype W] [DecidableEq W]

/-- joint continuity of the assembled Dirac matrix in all its data -/
theorem continuous_Dop {P : Type*} [TopologicalSpace P] (h : ℕ)
    (b0 bh : P → Matrix (Fin 2 × W) (Fin 2 × W) ℂ)
    (Bp Bm : P → ℕ → Matrix (Fin 2 × W) (Fin 2 × W) ℂ) (Vp Vm : P → ℕ → Matrix W W ℂ)
    (hb0 : ∀ i j, Continuous fun p => b0 p i j) (hbh : ∀ i j, Continuous fun p => bh p i j)
    (hBp : ∀ k i j, Continuous fun p => Bp p k i j)
    (hBm : ∀ k i j, Continuous fun p => Bm p k i j)
    (hVp : ∀ k v v', Continuous fun p => Vp p k v v')
    (hVm : ∀ k v v', Continuous fun p => Vm p k v v') :
    Continuous fun p => Dop h (b0 p) (bh p) (Bp p) (Bm p) (Vp p) (Vm p) := by
  have hB : ∀ k i j, Continuous fun p => Bfull h (b0 p) (bh p) (Bp p) (Bm p) k i j := by
    intro k i j
    unfold Bfull
    by_cases c0 : k = 0
    · simp only [if_pos c0]
      exact hb0 i j
    · by_cases c1 : k = h
      · simp only [if_neg c0, if_pos c1]
        exact hbh i j
      · by_cases c2 : k < h
        · simp only [if_neg c0, if_neg c1, if_pos c2]
          exact hBp k i j
        · simp only [if_neg c0, if_neg c1, if_neg c2]
          exact hBm (th h k) i j
  have hV : ∀ k v v', Continuous fun p => Vfull h (Vp p) (Vm p) k v v' := by
    intro k v v'
    unfold Vfull
    by_cases c : k < h
    · simp only [if_pos c]
      exact hVp k v v'
    · simp only [if_neg c, Matrix.smul_apply, Matrix.conjTranspose_apply, smul_eq_mul]
      exact continuous_const.mul (hVm _ v' v).star
  refine continuous_matrix fun a b => ?_
  show Continuous fun p => entry h (Bfull h (b0 p) (bh p) (Bp p) (Bm p)) (Vfull h (Vp p) (Vm p))
    a.1.val a.2.1 a.2.2 b.1.val b.2.1 b.2.2
  exact continuous_entry h (fun p => Bfull h (b0 p) (bh p) (Bp p) (Bm p))
    (fun p => Vfull h (Vp p) (Vm p)) hB hV _ _ _ _ _ _

end Regular

end FermionSliceBlock

namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionDetIntegral
open scoped ComplexOrder

/-- **Site reflection positivity of the weight `det D^{2j}`, Wilson operator in time-slice form, with continuity
hypotheses only.**  `Y` (plane data) and `X` (positive-side data) compact; unitary shifts `T`, Hermitian `K`,
`m > −1`; `T`, `K`, `V` continuous in the data.  Measurability and boundedness of the weight are derived
(`continuous_Dop`, `det_pow_re_measurable_bounded`).  The gauge weight `k h h` stays abstract. -/
theorem site_reflection_positive_wilson_regular {X Y W : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X]
    [TopologicalSpace Y] [CompactSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y]
    [OpensMeasurableSpace Y] [Fintype W] [DecidableEq W]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ) {d : ℕ} (m : ℝ) (hm : -1 < m)
    (T0 Th : Y → Fin d → Matrix W W ℂ) (K0 Kh : Y → Matrix W W ℂ)
    (Tp : X → ℕ → Fin d → Matrix W W ℂ) (Kp Vp : X → ℕ → Matrix W W ℂ)
    (hT0 : ∀ c i, (T0 c i)ᴴ * T0 c i = 1) (hTh : ∀ c i, (Th c i)ᴴ * Th c i = 1)
    (hTp : ∀ x t i, (Tp x t i)ᴴ * Tp x t i = 1)
    (hK0 : ∀ c, (K0 c).IsHermitian) (hKh : ∀ c, (Kh c).IsHermitian)
    (hKp : ∀ x t, (Kp x t).IsHermitian)
    (hT0c : ∀ i, Continuous fun c => T0 c i) (hThc : ∀ i, Continuous fun c => Th c i)
    (hK0c : ∀ v v', Continuous fun c => K0 c v v') (hKhc : ∀ v v', Continuous fun c => Kh c v v')
    (hTc : ∀ t i, Continuous fun x => Tp x t i)
    (hKc : ∀ t v v', Continuous fun x => Kp x t v v')
    (hVc : ∀ t v v', Continuous fun x => Vp x t v v')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have hD : Continuous fun p : Y × (X × X) =>
      (Dop hT (wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
          (wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
          (fun t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
          (Vp p.2.1) (Vp p.2.2)) := by
    refine continuous_Dop hT
      (fun p : Y × (X × X) => wilsonSlice (wilsonPlane m (T0 p.1)) (K0 p.1))
      (fun p : Y × (X × X) => wilsonSlice (wilsonPlane m (Th p.1)) (Kh p.1))
      (fun (p : Y × (X × X)) t => wilsonSlice (wilsonPlane m (Tp p.2.1 t)) (Kp p.2.1 t))
      (fun (p : Y × (X × X)) t => wilsonSlice (wilsonPlane m (Tp p.2.2 t)) (Kp p.2.2 t))
      (fun p : Y × (X × X) => Vp p.2.1) (fun p : Y × (X × X) => Vp p.2.2) ?_ ?_ ?_ ?_ ?_ ?_
    · intro i i'
      exact continuous_wilsonSlice (fun p : Y × (X × X) => wilsonPlane m (T0 p.1))
        (fun p : Y × (X × X) => K0 p.1)
        (fun v v' => (continuous_wilsonPlane m (fun p : Y × (X × X) => T0 p.1)
          (fun i => (hT0c i).comp continuous_fst)).matrix_elem v v')
        (fun v v' => (hK0c v v').comp continuous_fst) i i'
    · intro i i'
      exact continuous_wilsonSlice (fun p : Y × (X × X) => wilsonPlane m (Th p.1))
        (fun p : Y × (X × X) => Kh p.1)
        (fun v v' => (continuous_wilsonPlane m (fun p : Y × (X × X) => Th p.1)
          (fun i => (hThc i).comp continuous_fst)).matrix_elem v v')
        (fun v v' => (hKhc v v').comp continuous_fst) i i'
    · intro t i i'
      exact continuous_wilsonSlice (fun p : Y × (X × X) => wilsonPlane m (Tp p.2.1 t))
        (fun p : Y × (X × X) => Kp p.2.1 t)
        (fun v v' => (continuous_wilsonPlane m (fun p : Y × (X × X) => Tp p.2.1 t)
          (fun i => (hTc t i).comp (continuous_fst.comp continuous_snd))).matrix_elem v v')
        (fun v v' => (hKc t v v').comp (continuous_fst.comp continuous_snd)) i i'
    · intro t i i'
      exact continuous_wilsonSlice (fun p : Y × (X × X) => wilsonPlane m (Tp p.2.2 t))
        (fun p : Y × (X × X) => Kp p.2.2 t)
        (fun v v' => (continuous_wilsonPlane m (fun p : Y × (X × X) => Tp p.2.2 t)
          (fun i => (hTc t i).comp (continuous_snd.comp continuous_snd))).matrix_elem v v')
        (fun v v' => (hKc t v v').comp (continuous_snd.comp continuous_snd)) i i'
    · intro t v v'
      exact (hVc t v v').comp (continuous_fst.comp continuous_snd)
    · intro t v v'
      exact (hVc t v v').comp (continuous_snd.comp continuous_snd)
  obtain ⟨hρm, Cρ, bρ⟩ := FermionDetWeight.det_pow_re_measurable_bounded _ hD (2 * j)
  exact site_reflection_positive_wilson ν μ₀ hT hpos j m hm T0 Th K0 Kh Tp Kp Vp hT0 hTh hTp
    hK0 hKh hKp hTc hKc hVc k hw φ hk hhw hφ Ck Ch Cφ Cρ bk bhw bφ hk0 hρm bρ

end FermionSliceReflection


-- ===== part : LayerThree.part.lean =====

/-! # Layer 3: the Wilson–Dirac operator of a four-dimensional lattice in the time-slice form 



Representation of the Dirac matrices on the spinor index `(s, r) ∈ Fin 2 × Fin 2` (`s` = sign of `γ₄`,
`s = 1 ↔ γ₄ = +1`, `r` = remaining index): `γ₄ = diag(1, 1, −1, −1)` (`gammaT`),
`γ_i = [[0, −iσ_i], [iσ_i, 0]]` (`gammaSp`), `σ_i` the Pauli matrices (`pauli`).

The rest of the index is `L` (colour × space site).  The spatial hops are matrices `X_i` on `L`
(`X_i (c, x) (c', y) = [y = x + e_i] U_i(x) c c'`, with the antiperiodic sign on the boundary links;
`torusShift`, `torusLink`, `torusX` below), the time hop of the slice `t` is `v_t` on `L`.

* `stdSlice m X`: the textbook terms of the Wilson operator (`r = 1`) that stay on one time slice,
  `(m + 4) − ½ Σ_i [(1 − γ_i) ⊗ X_i + (1 + γ_i) ⊗ X_iᴴ]`, written with the matrices `gammaSp`.
* `std4 h m X v`: the textbook Wilson operator on the lattice `(time circle of length 2h) × L`,
  `[t = t'] stdSlice_t − ½ [(1 − γ₄) ⊗ H₄ + (1 + γ₄) ⊗ H₄ᴴ]`, `H₄ (t, l) (t', l') = [t' = t + 1] v_t l l'`.
* `sliceOp_wilson_eq_std4`: `sliceOp` with the Wilson slices `[[A, K], [−K, A]]`,
  `A = wilsonPlane m (1 ⊗ X_i)`, `K = kMat X = ½ Σ_i (−iσ_i) ⊗ (X_i − X_iᴴ)` and the time links `1 ⊗ v_t`
  is entrywise equal to `std4`.
* `liftShift_unitary`, `kMat_isHermitian`: the hypotheses "`T_i` unitary" and "`K_t` Hermitian" of
  `site_reflection_positive_wilson_regular`, paid for unitary `X_i`.
* `torusX_unitary`: the spatial hops of the torus `(Fin N)³` with unitary links and antiperiodic signs are
  unitary. -/
namespace FermionSliceBlock

open Matrix
open scoped Kronecker ComplexOrder

section LayerThree

/-- the Pauli matrices `σ₁, σ₂, σ₃` -/
def pauli (i : Fin 3) : Matrix (Fin 2) (Fin 2) ℂ :=
  if i.val = 0 then !![0, 1; 1, 0] else if i.val = 1 then !![0, -Complex.I; Complex.I, 0]
  else !![1, 0; 0, -1]

theorem pauli_star (i : Fin 3) (a b : Fin 2) : star (pauli i b a) = pauli i a b := by
  fin_cases i <;> fin_cases a <;> fin_cases b <;> simp [pauli, Complex.conj_I]

/-- `γ_i = [[0, −iσ_i], [iσ_i, 0]]` on `(s, r)`, `s = 1 ↔ γ₄ = +1` -/
noncomputable def gammaSp (i : Fin 3) : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  fun a b => if a.1.val = 1 ∧ b.1.val = 0 then -Complex.I * pauli i a.2 b.2
    else if a.1.val = 0 ∧ b.1.val = 1 then Complex.I * pauli i a.2 b.2 else 0

/-- `γ₄ = diag(1, 1, −1, −1)` on `(s, r)` -/
def gammaT : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  fun a b => if a = b then gam a.1 else 0

theorem oneSub_gammaT_apply (s s' r r' : Fin 2) :
    ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) - gammaT) (s, r) (s', r')
      = if s.val = 0 ∧ s'.val = 0 ∧ r = r' then 2 else 0 := by
  simp only [Matrix.sub_apply, Matrix.one_apply, gammaT, gam]
  fin_cases s <;> fin_cases s' <;> by_cases hr : r = r' <;> simp [hr] <;> norm_num

theorem onePlus_gammaT_apply (s s' r r' : Fin 2) :
    ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) + gammaT) (s, r) (s', r')
      = if s.val = 1 ∧ s'.val = 1 ∧ r = r' then 2 else 0 := by
  simp only [Matrix.add_apply, Matrix.one_apply, gammaT, gam]
  fin_cases s <;> fin_cases s' <;> by_cases hr : r = r' <;> simp [hr] <;> norm_num

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- a matrix on `L` lifted to `W = Fin 2 × L` (identity on the remaining spin index) -/
def liftShift (X : Matrix L L ℂ) : Matrix (Fin 2 × L) (Fin 2 × L) ℂ :=
  (1 : Matrix (Fin 2) (Fin 2) ℂ) ⊗ₖ X

theorem liftShift_apply (X : Matrix L L ℂ) (r r' : Fin 2) (l l' : L) :
    liftShift X (r, l) (r', l') = (1 : Matrix (Fin 2) (Fin 2) ℂ) r r' * X l l' := rfl

theorem liftShift_unitary (X : Matrix L L ℂ) (hX : Xᴴ * X = 1) : (liftShift X)ᴴ * liftShift X = 1 := by
  unfold liftShift
  rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, Matrix.one_mul, hX, one_kronecker_one]

theorem liftShift_smul_conjTranspose (e : ℂ) (he : star e = e) (X : Matrix L L ℂ) :
    liftShift (e • Xᴴ) = e • (liftShift X)ᴴ := by
  ext ⟨r, l⟩ ⟨r', l'⟩
  simp only [liftShift_apply, Matrix.smul_apply, Matrix.conjTranspose_apply, smul_eq_mul, star_mul',
    Matrix.one_apply]
  by_cases hr : r = r'
  · subst hr
    simp
  · have hr' : ¬ r' = r := fun e => hr e.symm
    simp [hr, hr']

/-- `K = ½ Σ_i (−iσ_i) ⊗ (X_i − X_iᴴ)`: the `(+, −)` block of a Wilson slice -/
noncomputable def kMat (X : Fin 3 → Matrix L L ℂ) : Matrix (Fin 2 × L) (Fin 2 × L) ℂ :=
  ∑ i, (1 / 2 : ℂ) • ((-Complex.I • pauli i) ⊗ₖ (X i - (X i)ᴴ))

theorem kMat_apply (X : Fin 3 → Matrix L L ℂ) (a b : Fin 2 × L) :
    kMat X a b = ∑ i, (1 / 2 : ℂ) * ((-Complex.I * pauli i a.1 b.1) * (X i a.2 b.2 - star (X i b.2 a.2))) := by
  simp only [kMat, Matrix.sum_apply, Matrix.smul_apply, Matrix.kroneckerMap_apply, Matrix.sub_apply,
    Matrix.conjTranspose_apply, smul_eq_mul]

theorem kMat_isHermitian (X : Fin 3 → Matrix L L ℂ) : (kMat X).IsHermitian := by
  have h2 : star (1 / 2 : ℂ) = 1 / 2 := by
    rw [Complex.star_def, map_div₀, map_one, map_ofNat]
  have hI : star (-Complex.I) = Complex.I := by
    rw [star_neg, Complex.star_def, Complex.conj_I, neg_neg]
  ext a b
  rw [Matrix.conjTranspose_apply, kMat_apply, kMat_apply, star_sum]
  refine Finset.sum_congr rfl fun i _ => ?_
  simp only [star_mul', star_sub, star_star, h2, hI, pauli_star]
  ring

/-- the textbook terms of the Wilson operator (`r = 1`) on one time slice:
`(m + 4) − ½ Σ_i [(1 − γ_i) ⊗ X_i + (1 + γ_i) ⊗ X_iᴴ]`, index `(s, (r, l))` -/
noncomputable def stdSlice (m : ℝ) (X : Fin 3 → Matrix L L ℂ) :
    Matrix (Fin 2 × (Fin 2 × L)) (Fin 2 × (Fin 2 × L)) ℂ :=
  fun a b => ((m : ℂ) + 4) * (1 : Matrix (Fin 2 × (Fin 2 × L)) (Fin 2 × (Fin 2 × L)) ℂ) a b
    - (1 / 2 : ℂ) * ∑ i, ((((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) - gammaSp i)
          (a.1, a.2.1) (b.1, b.2.1)) * X i a.2.2 b.2.2
        + (((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) + gammaSp i)
          (a.1, a.2.1) (b.1, b.2.1)) * star (X i b.2.2 a.2.2))

theorem wilsonPlane_lift_apply (m : ℝ) (X : Fin 3 → Matrix L L ℂ) (r r' : Fin 2) (l l' : L) :
    wilsonPlane m (fun i => liftShift (X i)) (r, l) (r', l')
      = (if r = r' then 1 else 0) * (((m : ℂ) + 4) * (if l = l' then 1 else 0)
          - (1 / 2 : ℂ) * ∑ i, (X i l l' + star (X i l' l))) := by
  simp only [wilsonPlane, Matrix.add_apply, Matrix.smul_apply, Matrix.sum_apply, Matrix.sub_apply,
    liftShift_apply, Matrix.conjTranspose_apply, Matrix.one_apply, Prod.mk.injEq, Fin.sum_univ_three,
    star_mul']
  by_cases hr : r = r'
  · subst hr
    by_cases hl : l = l'
    · subst hl
      simp only [and_self, if_true, star_one, one_mul, Complex.real_smul]
      push_cast
      ring
    · simp only [hl, and_false, if_false, if_true, star_one, one_mul, Complex.real_smul, mul_zero]
      push_cast
      ring
  · have hr' : ¬ r' = r := fun e => hr e.symm
    simp only [hr, hr', false_and, if_false, star_zero, zero_mul, mul_zero, Complex.real_smul]
    ring

theorem wilsonSlice_eq_stdSlice (m : ℝ) (X : Fin 3 → Matrix L L ℂ) :
    wilsonSlice (wilsonPlane m (fun i => liftShift (X i))) (kMat X) = stdSlice m X := by
  ext ⟨s, r, l⟩ ⟨s', r', l'⟩
  simp only [wilsonSlice, stdSlice, wilsonPlane_lift_apply, kMat_apply, gammaSp, Matrix.one_apply,
    Matrix.sub_apply, Matrix.add_apply, Prod.mk.injEq, Fin.sum_univ_three]
  fin_cases s <;> fin_cases s' <;> by_cases hr : r = r' <;> by_cases hl : l = l' <;>
    simp [hr, hl] <;> ring

/-- the textbook Wilson operator (`r = 1`) on `(time circle of length 2h) × L`, index `(t, s, (r, l))`:
`[t = t'] stdSlice_t − ½ [(1 − γ₄) ⊗ H₄ + (1 + γ₄) ⊗ H₄ᴴ]`, `H₄ (t, l) (t', l') = [t' = t + 1] v_t l l'`
(the antiperiodic sign in time is carried by `v` on the link `2h − 1 → 0`) -/
noncomputable def std4 (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    Matrix (Fin (2 * h) × Fin 2 × (Fin 2 × L)) (Fin (2 * h) × Fin 2 × (Fin 2 × L)) ℂ :=
  fun a b => (if b.1.val = a.1.val then stdSlice m (X a.1.val) a.2 b.2 else 0)
    - (1 / 2 : ℂ) * ((((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) - gammaT) (a.2.1, a.2.2.1) (b.2.1, b.2.2.1))
          * (if b.1.val = sc h a.1.val then v a.1.val a.2.2.2 b.2.2.2 else 0)
        + (((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) + gammaT) (a.2.1, a.2.2.1) (b.2.1, b.2.2.1))
          * (if a.1.val = sc h b.1.val then star (v b.1.val b.2.2.2 a.2.2.2) else 0))

theorem hop_fwd (c : Prop) [Decidable c] (s s' r r' : Fin 2) (x : ℂ) :
    (if c ∧ s.val = 0 ∧ s'.val = 0 then (1 : Matrix (Fin 2) (Fin 2) ℂ) r r' * x else 0)
      = (1 / 2 : ℂ) * ((if s.val = 0 ∧ s'.val = 0 ∧ r = r' then 2 else 0) * (if c then x else 0)) := by
  by_cases hc : c <;> by_cases hs : s.val = 0 <;> by_cases hs' : s'.val = 0 <;> by_cases hr : r = r' <;>
    simp [hc, hs, hs', hr, Matrix.one_apply]

theorem hop_bwd (c : Prop) [Decidable c] (s s' r r' : Fin 2) (x : ℂ) :
    (if c ∧ s.val = 1 ∧ s'.val = 1 then star ((1 : Matrix (Fin 2) (Fin 2) ℂ) r' r * x) else 0)
      = (1 / 2 : ℂ) * ((if s.val = 1 ∧ s'.val = 1 ∧ r = r' then 2 else 0) * (if c then star x else 0)) := by
  by_cases hc : c <;> by_cases hs : s.val = 1 <;> by_cases hs' : s'.val = 1 <;> by_cases hr : r = r' <;>
    simp [hc, hs, hs', hr, Matrix.one_apply] <;> exact fun e => absurd e.symm hr

/-- **Layer 3 (entrywise).**  The time-slice operator with Wilson slices built from spatial hops `X_t,i` and
time links `1 ⊗ v_t` is the textbook Wilson operator `std4`. -/
theorem sliceOp_wilson_eq_std4 (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    sliceOp h (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (X t i))) (kMat (X t)))
      (fun t => liftShift (v t)) = std4 h m X v := by
  ext ⟨t, s, r, l⟩ ⟨t', s', r', l'⟩
  have e1 := congrFun (congrFun (wilsonSlice_eq_stdSlice m (X t.val)) (s, r, l)) (s', r', l')
  show entry h (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (X t i))) (kMat (X t)))
      (fun t => liftShift (v t)) t.val s (r, l) t'.val s' (r', l') = std4 h m X v (t, s, r, l) (t', s', r', l')
  unfold entry std4
  simp only [liftShift_apply, oneSub_gammaT_apply, onePlus_gammaT_apply]
  rw [e1, hop_fwd, hop_bwd]
  ring

/-- the assembled configuration of Wilson slices is the Wilson operator of the assembled lattice data -/
theorem Dop_wilson_eq_std4 (h : ℕ) (m : ℝ) (X0 Xh : Fin 3 → Matrix L L ℂ) (Xp Xm : ℕ → Fin 3 → Matrix L L ℂ)
    (vp vm : ℕ → Matrix L L ℂ) :
    Dop h (wilsonSlice (wilsonPlane m (fun i => liftShift (X0 i))) (kMat X0))
        (wilsonSlice (wilsonPlane m (fun i => liftShift (Xh i))) (kMat Xh))
        (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xp t i))) (kMat (Xp t)))
        (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xm t i))) (kMat (Xm t)))
        (fun t => liftShift (vp t)) (fun t => liftShift (vm t))
      = std4 h m (Bfull h X0 Xh Xp Xm) (Vfull h vp vm) := by
  have hB : Bfull h (wilsonSlice (wilsonPlane m (fun i => liftShift (X0 i))) (kMat X0))
        (wilsonSlice (wilsonPlane m (fun i => liftShift (Xh i))) (kMat Xh))
        (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xp t i))) (kMat (Xp t)))
        (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xm t i))) (kMat (Xm t)))
      = fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Bfull h X0 Xh Xp Xm t i)))
          (kMat (Bfull h X0 Xh Xp Xm t)) := by
    funext t
    unfold Bfull
    split_ifs <;> rfl
  have hV : Vfull h (fun t => liftShift (vp t)) (fun t => liftShift (vm t))
      = fun t => liftShift (Vfull h vp vm t) := by
    funext t
    unfold Vfull
    split_ifs
    · rfl
    · have he : star (eps (sc h t)) = eps (sc h t) := by
        unfold eps
        split_ifs <;> simp
      exact (liftShift_smul_conjTranspose _ he _).symm
  unfold Dop
  rw [hB, hV]
  exact sliceOp_wilson_eq_std4 h m _ _

theorem continuous_liftShift {P : Type*} [TopologicalSpace P] (X : P → Matrix L L ℂ)
    (hX : ∀ l l', Continuous fun p => X p l l') : Continuous fun p => liftShift (X p) := by
  refine continuous_matrix fun a b => ?_
  simp only [liftShift, Matrix.kroneckerMap_apply]
  exact continuous_const.mul (hX a.2 b.2)

theorem continuous_kMat {P : Type*} [TopologicalSpace P] (X : P → Fin 3 → Matrix L L ℂ)
    (hX : ∀ i l l', Continuous fun p => X p i l l') (a b : Fin 2 × L) :
    Continuous fun p => kMat (X p) a b := by
  simp only [kMat_apply]
  exact continuous_finsetSum _ fun i _ =>
    continuous_const.mul (continuous_const.mul ((hX i _ _).sub (hX i _ _).star))

/-! ### The spatial torus `(Fin N)³` -/

/-- the hop of a lattice with links: `X (c, x) (c', y) = [x = σ y] u_x c c'` -/
def shiftMat {C S : Type*} [Fintype C] [DecidableEq C] [Fintype S] [DecidableEq S] (σ : S ≃ S)
    (u : S → Matrix C C ℂ) : Matrix (C × S) (C × S) ℂ :=
  (blockDiagonal u).submatrix id (Equiv.prodCongr (Equiv.refl C) σ)

theorem shiftMat_apply {C S : Type*} [Fintype C] [DecidableEq C] [Fintype S] [DecidableEq S] (σ : S ≃ S)
    (u : S → Matrix C C ℂ) (c c' : C) (x y : S) :
    shiftMat σ u (c, x) (c', y) = if x = σ y then u x c c' else 0 := by
  simp [shiftMat, blockDiagonal_apply]

theorem shiftMat_unitary {C S : Type*} [Fintype C] [DecidableEq C] [Fintype S] [DecidableEq S] (σ : S ≃ S)
    (u : S → Matrix C C ℂ) (hu : ∀ x, (u x)ᴴ * u x = 1) : (shiftMat σ u)ᴴ * shiftMat σ u = 1 := by
  have h1 : (blockDiagonal u)ᴴ * blockDiagonal u = 1 := by
    rw [blockDiagonal_conjTranspose, ← blockDiagonal_mul]
    have e : (fun k => (u k)ᴴ * u k) = (1 : S → Matrix C C ℂ) := funext hu
    rw [e, blockDiagonal_one]
  have h2 := Matrix.submatrix_mul_equiv (blockDiagonal u)ᴴ (blockDiagonal u)
    (Equiv.prodCongr (Equiv.refl C) σ) (Equiv.refl (C × S)) (Equiv.prodCongr (Equiv.refl C) σ)
  rw [h1, submatrix_one_equiv] at h2
  unfold shiftMat
  rw [conjTranspose_submatrix]
  exact h2

/-- the shift `x ↦ x − e_i` of the torus `(Fin N)³`; `x = σ_i y ↔ y = x + e_i` -/
def torusShift (N : ℕ) [NeZero N] (i : Fin 3) : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N) :=
  Equiv.addRight (-Pi.single i 1)

/-- the link from `x` to `x + e_i`, with the antiperiodic sign on the boundary links `x_i = N − 1` -/
def torusLink {C : Type*} (N : ℕ) (U : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (x : Fin 3 → Fin N)
    (i : Fin 3) : Matrix C C ℂ :=
  (if (x i).val + 1 = N then (-1 : ℂ) else 1) • U x i

/-- the spatial hop `X_i` of the torus -/
def torusX {C : Type*} [Fintype C] [DecidableEq C] (N : ℕ) [NeZero N]
    (U : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (i : Fin 3) :
    Matrix (C × (Fin 3 → Fin N)) (C × (Fin 3 → Fin N)) ℂ :=
  shiftMat (torusShift N i) (fun x => torusLink N U x i)

theorem torusX_unitary {C : Type*} [Fintype C] [DecidableEq C] (N : ℕ) [NeZero N]
    (U : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (hU : ∀ x i, (U x i)ᴴ * U x i = 1) (i : Fin 3) :
    (torusX N U i)ᴴ * torusX N U i = 1 := by
  refine shiftMat_unitary _ _ fun x => ?_
  unfold torusLink
  have he : star (if (x i).val + 1 = N then (-1 : ℂ) else 1) * (if (x i).val + 1 = N then (-1 : ℂ) else 1)
      = 1 := by
    split_ifs <;> simp
  rw [conjTranspose_smul, Matrix.smul_mul, Matrix.mul_smul, hU, smul_smul, he, one_smul]

theorem continuous_torusX {C P : Type*} [Fintype C] [DecidableEq C] [TopologicalSpace P] (N : ℕ) [NeZero N]
    (U : P → (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (hU : ∀ x i c c', Continuous fun p => U p x i c c')
    (i : Fin 3) (a b : C × (Fin 3 → Fin N)) : Continuous fun p => torusX N (U p) i a b := by
  obtain ⟨c, x⟩ := a
  obtain ⟨c', y⟩ := b
  simp only [torusX, shiftMat_apply, torusLink, Matrix.smul_apply, smul_eq_mul]
  by_cases hxy : x = torusShift N i y
  · simp only [hxy, if_true]
    exact continuous_const.mul (hU _ _ _ _)
  · simp only [hxy, if_false]
    exact continuous_const

end LayerThree

end FermionSliceBlock

-- ===== part : TorusFinal.part.lean =====

/-! # Site reflection positivity for the textbook Wilson operator of the lattice 

Paper side: Lemma 3 of paper A (site reflection, factorised form), fermion version.
The operator in the integrand is `std4` (the textbook Wilson operator, `r = 1`, written with Dirac matrices)
of the configuration assembled from the plane data and the positive-side data and its reflected copy.  The
hypotheses on the operator are: unitary spatial hops, continuity in the configuration, `m > −1`. -/
namespace FermionSliceBlock

open Matrix

theorem continuous_blockDiagonal_elem {C S P : Type*} [Fintype C] [DecidableEq C] [Fintype S] [DecidableEq S]
    [TopologicalSpace P] (U : P → S → Matrix C C ℂ) (hU : ∀ x c c', Continuous fun p => U p x c c')
    (a b : C × S) : Continuous fun p => blockDiagonal (U p) a b := by
  obtain ⟨c, x⟩ := a
  obtain ⟨c', y⟩ := b
  simp only [blockDiagonal_apply]
  by_cases hxy : x = y
  · simp only [hxy, if_true]
    exact hU _ _ _
  · simp only [hxy, if_false]
    exact continuous_const

end FermionSliceBlock

namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock
open scoped ComplexOrder

/-- **Site reflection positivity of the weight `det D^{2j}` for the textbook Wilson operator `std4`.**
`X0 c, Xh c`: spatial hops on the planes `t = 0, h`; `Xp x t, vp x t`: spatial hops and time links of the positive
side `0 < t < h` (time links `0 ≤ t < h`); the negative side is the reflected copy (`Bfull`, `Vfull`, antiperiodic in
time).  Hypotheses: unitary `X`, entrywise continuity, `m > −1`, compact configuration spaces.  The gauge weight
`k h h` stays abstract. -/
theorem site_reflection_positive_wilson_std4 {X Y L : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X]
    [TopologicalSpace Y] [CompactSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y]
    [OpensMeasurableSpace Y] [Fintype L] [DecidableEq L]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (hm : -1 < m)
    (X0 Xh : Y → Fin 3 → Matrix L L ℂ) (Xp : X → ℕ → Fin 3 → Matrix L L ℂ) (vp : X → ℕ → Matrix L L ℂ)
    (hX0 : ∀ c i, (X0 c i)ᴴ * X0 c i = 1) (hXh : ∀ c i, (Xh c i)ᴴ * Xh c i = 1)
    (hXp : ∀ x t i, (Xp x t i)ᴴ * Xp x t i = 1)
    (hX0c : ∀ i l l', Continuous fun c => X0 c i l l') (hXhc : ∀ i l l', Continuous fun c => Xh c i l l')
    (hXpc : ∀ t i l l', Continuous fun x => Xp x t i l l')
    (hvc : ∀ t l l', Continuous fun x => vp x t l l')
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((std4 hT m (Bfull hT (X0 p.1) (Xh p.1) (Xp p.2.1) (Xp p.2.2))
          (Vfull hT (vp p.2.1) (vp p.2.2))).det ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) := by
  have key := fun p : Y × (X × X) =>
    (Dop_wilson_eq_std4 hT m (X0 p.1) (Xh p.1) (Xp p.2.1) (Xp p.2.2) (vp p.2.1) (vp p.2.2)).symm
  simp only [key]
  exact site_reflection_positive_wilson_regular ν μ₀ hT hpos j m hm
    (fun c i => liftShift (X0 c i)) (fun c i => liftShift (Xh c i)) (fun c => kMat (X0 c))
    (fun c => kMat (Xh c))
    (fun x t i => liftShift (Xp x t i)) (fun x t => kMat (Xp x t)) (fun x t => liftShift (vp x t))
    (fun c i => liftShift_unitary _ (hX0 c i)) (fun c i => liftShift_unitary _ (hXh c i))
    (fun x t i => liftShift_unitary _ (hXp x t i))
    (fun c => kMat_isHermitian _) (fun c => kMat_isHermitian _) (fun x t => kMat_isHermitian _)
    (fun i => continuous_liftShift (fun c => X0 c i) (hX0c i))
    (fun i => continuous_liftShift (fun c => Xh c i) (hXhc i))
    (fun v v' => continuous_kMat X0 hX0c v v') (fun v v' => continuous_kMat Xh hXhc v v')
    (fun t i => continuous_liftShift (fun x => Xp x t i) (hXpc t i))
    (fun t v v' => continuous_kMat (fun x => Xp x t) (hXpc t) v v')
    (fun t v v' => (continuous_liftShift (fun x => vp x t) (hvc t)).matrix_elem v v')
    k hw φ hk hhw hφ Ck Ch Cφ bk bhw bφ hk0

/-- **The same on the spatial torus `(Fin N)³`** with link variables: spatial links `U0 c x i`, `Uh c x i`,
`Up x' t x i` unitary (antiperiodic signs on the boundary links added by `torusLink`), time links `U4 x' t x`
arbitrary (the antiperiodic sign in time is added by `Vfull`).  The hypotheses "unitary hop" and continuity of
`site_reflection_positive_wilson_std4` are paid by `torusX_unitary`, `continuous_torusX`,
`continuous_blockDiagonal_elem`. -/
theorem site_reflection_positive_wilson_torus {X Y C : Type*} [TopologicalSpace X] [CompactSpace X]
    [SecondCountableTopology X] [MeasurableSpace X] [OpensMeasurableSpace X]
    [TopologicalSpace Y] [CompactSpace Y] [SecondCountableTopology Y] [MeasurableSpace Y]
    [OpensMeasurableSpace Y] [Fintype C] [DecidableEq C] (N : ℕ) [NeZero N]
    (ν : Measure X) (μ₀ : Measure Y) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ) (hm : -1 < m)
    (U0 Uh : Y → (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ)
    (Up : X → ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (U4 : X → ℕ → (Fin 3 → Fin N) → Matrix C C ℂ)
    (hU0 : ∀ c x i, (U0 c x i)ᴴ * U0 c x i = 1) (hUh : ∀ c x i, (Uh c x i)ᴴ * Uh c x i = 1)
    (hUp : ∀ x' t x i, (Up x' t x i)ᴴ * Up x' t x i = 1)
    (hU0c : ∀ x i a b, Continuous fun c => U0 c x i a b) (hUhc : ∀ x i a b, Continuous fun c => Uh c x i a b)
    (hUpc : ∀ t x i a b, Continuous fun x' => Up x' t x i a b)
    (hU4c : ∀ t x a b, Continuous fun x' => U4 x' t x a b)
    (k : Y → ℝ) (hw φ : Y × X → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ p : Y × (X × X), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((std4 hT m (Bfull hT (torusX N (U0 p.1)) (torusX N (Uh p.1)) (fun t => torusX N (Up p.2.1 t))
            (fun t => torusX N (Up p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4 p.2.1 t)) (fun t => blockDiagonal (U4 p.2.2 t)))).det
            ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) :=
  site_reflection_positive_wilson_std4 ν μ₀ hT hpos j m hm
    (fun c => torusX N (U0 c)) (fun c => torusX N (Uh c)) (fun x t => torusX N (Up x t))
    (fun x t => blockDiagonal (U4 x t))
    (fun c i => torusX_unitary N _ (hU0 c) i) (fun c i => torusX_unitary N _ (hUh c) i)
    (fun x t i => torusX_unitary N _ (hUp x t) i)
    (fun i l l' => continuous_torusX N U0 hU0c i l l') (fun i l l' => continuous_torusX N Uh hUhc i l l')
    (fun t i l l' => continuous_torusX N (fun x => Up x t) (hUpc t) i l l')
    (fun t l l' => continuous_blockDiagonal_elem (fun x => U4 x t) (hU4c t) l l')
    k hw φ hk hhw hφ Ck Ch Cφ bk bhw bφ hk0

end FermionSliceReflection


-- ===== copy : FreeInvertible.lean =====
/-
  (Table 2, row 9: fermions). The algebraic core of "`det D ≠ 0` for the free Wilson operator"
(the point `U = 1` that gives `Z > 0` at negative bare mass).

`free_dirac_isUnit_det`: let `γ_μ` (μ = 0..3) be Hermitian matrices with the Clifford relations
`γ_μ γ_ν + γ_ν γ_μ = 2 δ_μν`, `M` Hermitian, `A_μ` anti-Hermitian, all of `M, A_μ` commuting with each other.
Then `D = 1 ⊗ M + Σ_μ γ_μ ⊗ A_μ` satisfies `Dᴴ D = 1 ⊗ (Mᴴ M + Σ_μ A_μᴴ A_μ)`, and `D` is invertible as soon as
one `A_ν` is invertible.  For the free Wilson operator `M = m + Σ_μ (1 − ½ (T_μ + T_μᴴ))` and
`A_μ = ½ (T_μ − T_μᴴ)`, with commuting unitary shifts `T_μ`; `A_ν` is invertible when `±1` are not eigenvalues of
`T_ν` (antiperiodic direction of even length).  No sign condition on `m` is used.


-/

open Matrix
open scoped Kronecker ComplexOrder

namespace FermionFreeInvertible

variable {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]

theorem kronecker_neg' (A : Matrix ι ι ℂ) (B : Matrix κ κ ℂ) : A ⊗ₖ (-B) = -(A ⊗ₖ B) := by
  ext a b
  simp

theorem kronecker_sub' (A : Matrix ι ι ℂ) (B C : Matrix κ κ ℂ) : A ⊗ₖ (B - C) = A ⊗ₖ B - A ⊗ₖ C := by
  ext a b
  simp [mul_sub]

theorem kronecker_sum' (A : Matrix ι ι ℂ) (B : Fin 4 → Matrix κ κ ℂ) :
    A ⊗ₖ (∑ μ, B μ) = ∑ μ, A ⊗ₖ B μ := by
  ext a b
  simp [Matrix.sum_apply, Finset.mul_sum]

/-- `(Σ γ_μ ⊗ A_μ)² = 1 ⊗ Σ A_μ²` under the Clifford relations and commuting `A_μ` -/
theorem sq_sum_kronecker (γ : Fin 4 → Matrix ι ι ℂ)
    (hcl : ∀ μ ν, γ μ * γ ν + γ ν * γ μ = if μ = ν then (2 : ℂ) • (1 : Matrix ι ι ℂ) else 0)
    (A : Fin 4 → Matrix κ κ ℂ) (hAA : ∀ μ ν, A μ * A ν = A ν * A μ) :
    (∑ μ, γ μ ⊗ₖ A μ) * (∑ μ, γ μ ⊗ₖ A μ) = (1 : Matrix ι ι ℂ) ⊗ₖ ∑ μ, A μ * A μ := by
  have e1 : (∑ μ, γ μ ⊗ₖ A μ) * (∑ μ, γ μ ⊗ₖ A μ)
      = ∑ μ, ∑ ν, (γ μ * γ ν) ⊗ₖ (A μ * A ν) := by
    rw [Finset.sum_mul]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [mul_kronecker_mul]
  have e2 : (∑ μ, γ μ ⊗ₖ A μ) * (∑ μ, γ μ ⊗ₖ A μ)
      = ∑ μ, ∑ ν, (γ ν * γ μ) ⊗ₖ (A μ * A ν) := by
    rw [e1, Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => Finset.sum_congr rfl fun ν _ => ?_
    rw [hAA]
  have e3 : ∀ μ, ∑ ν, (γ μ * γ ν + γ ν * γ μ) ⊗ₖ (A μ * A ν)
      = (2 : ℂ) • ((1 : Matrix ι ι ℂ) ⊗ₖ (A μ * A μ)) := by
    intro μ
    have : ∀ ν, (γ μ * γ ν + γ ν * γ μ) ⊗ₖ (A μ * A ν)
        = if μ = ν then (2 : ℂ) • ((1 : Matrix ι ι ℂ) ⊗ₖ (A μ * A ν)) else 0 := by
      intro ν
      rw [hcl]
      split_ifs
      · rw [smul_kronecker]
      · rw [zero_kronecker]
    rw [Finset.sum_congr rfl fun ν _ => this ν, Finset.sum_ite_eq, if_pos (Finset.mem_univ _)]
  have e4 : (2 : ℂ) • ((∑ μ, γ μ ⊗ₖ A μ) * (∑ μ, γ μ ⊗ₖ A μ))
      = (2 : ℂ) • ((1 : Matrix ι ι ℂ) ⊗ₖ ∑ μ, A μ * A μ) := by
    rw [two_smul]
    nth_rewrite 1 [e1]
    rw [e2, ← Finset.sum_add_distrib, kronecker_sum', Finset.smul_sum]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← Finset.sum_add_distrib, ← e3 μ]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [add_kronecker]
  exact smul_right_injective _ (two_ne_zero : (2 : ℂ) ≠ 0) e4

/-- **`Dᴴ D = 1 ⊗ (Mᴴ M + Σ A_μᴴ A_μ)`** -/
theorem conjTranspose_mul_self_eq (γ : Fin 4 → Matrix ι ι ℂ) (hγ : ∀ μ, (γ μ)ᴴ = γ μ)
    (hcl : ∀ μ ν, γ μ * γ ν + γ ν * γ μ = if μ = ν then (2 : ℂ) • (1 : Matrix ι ι ℂ) else 0)
    (M : Matrix κ κ ℂ) (hM : Mᴴ = M) (A : Fin 4 → Matrix κ κ ℂ) (hA : ∀ μ, (A μ)ᴴ = -A μ)
    (hMA : ∀ μ, M * A μ = A μ * M) (hAA : ∀ μ ν, A μ * A ν = A ν * A μ) :
    ((1 : Matrix ι ι ℂ) ⊗ₖ M + ∑ μ, γ μ ⊗ₖ A μ)ᴴ * ((1 : Matrix ι ι ℂ) ⊗ₖ M + ∑ μ, γ μ ⊗ₖ A μ)
      = (1 : Matrix ι ι ℂ) ⊗ₖ (Mᴴ * M + ∑ μ, (A μ)ᴴ * A μ) := by
  have hSH : (∑ μ, γ μ ⊗ₖ A μ)ᴴ = -(∑ μ, γ μ ⊗ₖ A μ) := by
    rw [conjTranspose_sum, ← Finset.sum_neg_distrib]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [conjTranspose_kronecker, hγ, hA, kronecker_neg']
  have hMS : ((1 : Matrix ι ι ℂ) ⊗ₖ M) * (∑ μ, γ μ ⊗ₖ A μ)
      = (∑ μ, γ μ ⊗ₖ A μ) * ((1 : Matrix ι ι ℂ) ⊗ₖ M) := by
    rw [Finset.mul_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← mul_kronecker_mul, ← mul_kronecker_mul, Matrix.one_mul, Matrix.mul_one, hMA]
  have hsum : ∑ μ, (A μ)ᴴ * A μ = -∑ μ, A μ * A μ := by
    rw [← Finset.sum_neg_distrib]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [hA, Matrix.neg_mul]
  rw [conjTranspose_add, conjTranspose_kronecker, conjTranspose_one, hM, hSH, add_mul, mul_add, mul_add,
    hMS, Matrix.neg_mul, Matrix.neg_mul, sq_sum_kronecker γ hcl A hAA, ← mul_kronecker_mul, Matrix.one_mul,
    hsum, kronecker_add, kronecker_neg']
  abel

/-- **The free Wilson operator is invertible** (algebraic form): one invertible `A_ν` suffices, for every `M`. -/
theorem free_dirac_isUnit_det (γ : Fin 4 → Matrix ι ι ℂ) (hγ : ∀ μ, (γ μ)ᴴ = γ μ)
    (hcl : ∀ μ ν, γ μ * γ ν + γ ν * γ μ = if μ = ν then (2 : ℂ) • (1 : Matrix ι ι ℂ) else 0)
    (M : Matrix κ κ ℂ) (hM : Mᴴ = M) (A : Fin 4 → Matrix κ κ ℂ) (hA : ∀ μ, (A μ)ᴴ = -A μ)
    (hMA : ∀ μ, M * A μ = A μ * M) (hAA : ∀ μ ν, A μ * A ν = A ν * A μ)
    (ν₀ : Fin 4) (hν : IsUnit (A ν₀).det) :
    IsUnit ((1 : Matrix ι ι ℂ) ⊗ₖ M + ∑ μ, γ μ ⊗ₖ A μ).det := by
  have hP : (Mᴴ * M + ∑ μ, (A μ)ᴴ * A μ).PosDef := by
    have h1 : ((A ν₀)ᴴ * A ν₀).PosDef :=
      Matrix.PosDef.conjTranspose_mul_self _
        (Matrix.mulVec_injective_iff_isUnit.mpr ((Matrix.isUnit_iff_isUnit_det _).mpr hν))
    have h2 : (Mᴴ * M + ∑ μ ∈ Finset.univ.erase ν₀, (A μ)ᴴ * A μ).PosSemidef :=
      (Matrix.posSemidef_conjTranspose_mul_self M).add
        (Matrix.posSemidef_sum _ fun μ _ => Matrix.posSemidef_conjTranspose_mul_self (A μ))
    have e : Mᴴ * M + ∑ μ, (A μ)ᴴ * A μ
        = (A ν₀)ᴴ * A ν₀ + (Mᴴ * M + ∑ μ ∈ Finset.univ.erase ν₀, (A μ)ᴴ * A μ) := by
      rw [← Finset.add_sum_erase _ _ (Finset.mem_univ ν₀)]
      abel
    rw [e]
    exact h1.add_posSemidef h2
  have hdet : IsUnit (((1 : Matrix ι ι ℂ) ⊗ₖ M + ∑ μ, γ μ ⊗ₖ A μ)ᴴ
      * ((1 : Matrix ι ι ℂ) ⊗ₖ M + ∑ μ, γ μ ⊗ₖ A μ)).det := by
    rw [conjTranspose_mul_self_eq γ hγ hcl M hM A hA hMA hAA, det_kronecker, det_one, one_pow, one_mul]
    exact ((Matrix.isUnit_iff_isUnit_det _).mp hP.isUnit).pow _
  rw [det_mul] at hdet
  exact isUnit_of_mul_isUnit_right hdet

end FermionFreeInvertible


-- ===== copy : HopInvertible.lean =====
/-
  (Table 2, row 9: fermions). The second input of `free_dirac_isUnit_det`
(`FreeInvertible.lean`): for a unitary hop `T` with `T^(2h) = −1` (antiperiodic direction of even length `2h`),
`A = ½ (T − Tᴴ)` is invertible, i.e. `±1` are not eigenvalues of `T`.
Proof: `(Σ_{k<h} (T²)^k)(T² − 1) = (T²)^h − 1 = −2` and `T − Tᴴ = Tᴴ (T² − 1)`.


-/

open Matrix

namespace FermionFreeInvertible

variable {κ : Type*} [Fintype κ] [DecidableEq κ]

theorem sq_sub_one_isUnit_det (T : Matrix κ κ ℂ) (h : ℕ) (hT : T ^ (2 * h) = -1) :
    IsUnit (T * T - 1).det := by
  have hg : (∑ i ∈ Finset.range h, (T * T) ^ i) * (T * T - 1) = (T * T) ^ h - 1 := geom_sum_mul _ _
  have hp : (T * T) ^ h = T ^ (2 * h) := by
    rw [← pow_two, ← pow_mul]
  rw [hp, hT] at hg
  have hdet : IsUnit ((∑ i ∈ Finset.range h, (T * T) ^ i) * (T * T - 1)).det := by
    rw [hg, show (-1 : Matrix κ κ ℂ) - 1 = (-2 : ℂ) • (1 : Matrix κ κ ℂ) by
      rw [neg_smul, two_smul]; abel]
    rw [det_smul, det_one, mul_one]
    exact (IsUnit.mk0 _ (by norm_num)).pow _
  rw [det_mul] at hdet
  exact isUnit_of_mul_isUnit_right hdet

/-- **`T − Tᴴ` is invertible** for a unitary `T` with `T^(2h) = −1`. -/
theorem sub_conjTranspose_isUnit_det (T : Matrix κ κ ℂ) (hU : Tᴴ * T = 1) (h : ℕ)
    (hT : T ^ (2 * h) = -1) : IsUnit (T - Tᴴ).det := by
  have e : T - Tᴴ = Tᴴ * (T * T - 1) := by
    rw [Matrix.mul_sub, ← Matrix.mul_assoc, hU, Matrix.one_mul, Matrix.mul_one]
  have hTH : IsUnit Tᴴ.det := by
    have := congrArg Matrix.det hU
    rw [det_mul, det_one] at this
    exact isUnit_of_mul_isUnit_left (by rw [this]; exact isUnit_one)
  rw [e, det_mul]
  exact hTH.mul (sq_sub_one_isUnit_det T h hT)

/-- the same for `A = ½ (T − Tᴴ)` -/
theorem half_sub_conjTranspose_isUnit_det (T : Matrix κ κ ℂ) (hU : Tᴴ * T = 1) (h : ℕ)
    (hT : T ^ (2 * h) = -1) : IsUnit ((1 / 2 : ℂ) • (T - Tᴴ)).det := by
  rw [det_smul]
  exact ((IsUnit.mk0 _ (by norm_num)).pow _).mul (sub_conjTranspose_isUnit_det T hU h hT)

end FermionFreeInvertible


-- ===== copy : HermitePart.lean =====
/-
  (Table 2, row 9: fermions). Invertibility from the Hermitian part.


For a non-Hermitian operator the role of the order structure is played by the coercivity of the Hermitian part:
* `isUnit_det_of_add_conjTranspose_posDef` : `A + Aᴴ ≻ 0  ⟹  det A` is a unit.
* `isUnit_det_of_hermitePart`              : `D + Dᴴ = c·1 + P`, `c > 0`, `P ⪰ 0  ⟹  det D` is a unit
  (the Wilson operator with `m > 0`: `D + Dᴴ = 2m + Σ_μ (1 − T_μ)ᴴ (1 − T_μ)`).
* `isUnit_det_fluctuation`                 : if moreover `G ⪰ 0` (e.g. `G = b·QᴴQ`, `b ≥ 0`) then `det (D + G)` is a
  unit: the hypothesis `hF` of `FermionBlockTower.det_block_step` for every gauge field, when `m > 0`.
-/

open Matrix
open scoped ComplexOrder

namespace FermionHermitePart

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- If the Hermitian part `A + Aᴴ` is positive definite, then `A` is invertible. -/
theorem isUnit_det_of_add_conjTranspose_posDef (A : Matrix n n ℂ) (hA : (A + Aᴴ).PosDef) :
    IsUnit A.det := by
  rw [isUnit_iff_ne_zero]
  intro h0
  obtain ⟨v, hv, hAv⟩ := (Matrix.exists_mulVec_eq_zero_iff (M := A)).mpr h0
  have hpos := hA.dotProduct_mulVec_pos hv
  have e1 : star v ⬝ᵥ (A *ᵥ v) = 0 := by
    rw [hAv, dotProduct_zero]
  have e2 : star v ⬝ᵥ (Aᴴ *ᵥ v) = 0 := by
    rw [Matrix.dotProduct_mulVec, ← Matrix.star_mulVec, hAv, star_zero, zero_dotProduct]
  rw [Matrix.add_mulVec, dotProduct_add, e1, e2, add_zero] at hpos
  exact lt_irrefl _ hpos

/-- `D + Dᴴ = c·1 + P` with `c > 0` and `P ⪰ 0` implies that `D` is invertible. -/
theorem isUnit_det_of_hermitePart (D P : Matrix n n ℂ) (c : ℝ) (hc : 0 < c) (hP : P.PosSemidef)
    (h : D + Dᴴ = (c : ℝ) • (1 : Matrix n n ℂ) + P) : IsUnit D.det := by
  apply isUnit_det_of_add_conjTranspose_posDef
  rw [h]
  exact (PosDef.one.smul hc).add_posSemidef hP

/-- If `D + Dᴴ ≻ 0` and `G ⪰ 0` (Hermitian positive semidefinite, e.g. `G = b·QᴴQ` with `b ≥ 0`), then `D + G`
is invertible. -/
theorem isUnit_det_fluctuation (D G : Matrix n n ℂ) (hD : (D + Dᴴ).PosDef) (hG : G.PosSemidef) :
    IsUnit (D + G).det := by
  apply isUnit_det_of_add_conjTranspose_posDef
  have e : D + G + (D + G)ᴴ = (D + Dᴴ) + (G + G) := by
    rw [conjTranspose_add, hG.isHermitian.eq]
    abel
  rw [e]
  exact hD.add_posSemidef (hG.add hG)

end FermionHermitePart


-- ===== part : CliffordZ.part.lean =====

/-! # The Clifford form of the textbook Wilson operator, its Hermitian part, and `det D ≠ 0` at a free configuration


Paper side: ("U = 1", "Hermitian part"); 
§1.5.  All statements are about the concrete operator `std4` (the textbook Wilson operator, `r = 1`, of
`LayerThree.part.lean`).

* `std4_eq_kron4`, `kron4_eq_clifford`, `std4_eq_clifford`: after the relabelling `(t, s, (r, l)) ↦ ((s, r), (t, l))`,
  `std4 = (m + 4) − ½ Σ_μ [(1 − γ_μ) ⊗ H_μ + (1 + γ_μ) ⊗ H_μᴴ] = 1 ⊗ M + Σ_μ γ_μ ⊗ A_μ`,
  `M = (m + 4) − ½ Σ_μ (H_μ + H_μᴴ)`, `A_μ = ½ (H_μ − H_μᴴ)`.
* `std4_add_conjTranspose`: `D + Dᴴ = 2 (1 ⊗ M)` (relabelled); `massPart_eq_sos`: for unitary hops
  `M = m + ½ Σ_μ (1 − H_μ)ᴴ (1 − H_μ)`; `std4_isUnit_det_of_pos`: `m > 0` and unitary hops ⟹ `det D ≠ 0`
  (every gauge field).
* `std4_free_isUnit_det`: for spatial hops `Y_i` (the same on every time slice) that are unitary and commute, and the
  time links `1` with the antiperiodic sign on the link `2h − 1 → 0`, `det D ≠ 0` for **every** `m` (no sign
  condition).  `torusX_sign_commute`: the spatial hops of the torus at the configuration `U_x,i = ±1` (the sign that
  cancels the antiperiodic boundary sign; `±1 ∈ SU(2)`) are commuting permutation matrices.
-/
namespace FermionSliceBlock

open Matrix
open scoped Kronecker ComplexOrder

/-- the four Dirac matrices: `γ₁, γ₂, γ₃` spatial, `γ₄` (index 3) time -/
noncomputable def gammaAll (μ : Fin 4) : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ :=
  if h : μ.val < 3 then gammaSp ⟨μ.val, h⟩ else gammaT

theorem gammaAll_isHermitian (μ : Fin 4) : (gammaAll μ)ᴴ = gammaAll μ := by
  ext ⟨s, r⟩ ⟨s', r'⟩
  fin_cases μ <;> fin_cases s <;> fin_cases r <;> fin_cases s' <;> fin_cases r' <;>
    simp [gammaAll, gammaSp, gammaT, gam, pauli, Complex.conj_I]

set_option maxHeartbeats 3200000 in
theorem gammaAll_clifford (μ ν : Fin 4) :
    gammaAll μ * gammaAll ν + gammaAll ν * gammaAll μ
      = if μ = ν then (2 : ℂ) • (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) else 0 := by
  ext ⟨s, r⟩ ⟨s', r'⟩
  fin_cases μ <;> fin_cases ν <;> fin_cases s <;> fin_cases r <;> fin_cases s' <;> fin_cases r' <;>
    simp [gammaAll, gammaSp, gammaT, gam, pauli, Matrix.mul_apply, Fintype.sum_prod_type, Fin.sum_univ_two,
      Matrix.one_apply] <;> ring_nf <;> simp [Complex.I_sq] <;> norm_num

theorem gammaAll_zero : gammaAll 0 = gammaSp 0 := by
  unfold gammaAll
  rw [dif_pos (by decide)]
  rfl

theorem gammaAll_one : gammaAll 1 = gammaSp 1 := by
  unfold gammaAll
  rw [dif_pos (by decide)]
  rfl

theorem gammaAll_two : gammaAll 2 = gammaSp 2 := by
  unfold gammaAll
  rw [dif_pos (by decide)]
  rfl

theorem gammaAll_three : gammaAll 3 = gammaT := by
  unfold gammaAll
  rw [dif_neg (by decide)]

theorem star_ite_zero (c : Prop) [Decidable c] (x : ℂ) : star (if c then x else 0) = if c then star x else 0 := by
  split_ifs <;> simp

theorem one_prod_apply {A B : Type*} [DecidableEq A] [DecidableEq B] (a b : A) (c d : B) :
    (1 : Matrix (A × B) (A × B) ℂ) (a, c) (b, d) = (1 : Matrix A A ℂ) a b * (1 : Matrix B B ℂ) c d := by
  by_cases hab : a = b <;> by_cases hcd : c = d <;> simp [Matrix.one_apply, hab, hcd]

section CliffordForm

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- the spatial hop `i` on `(time circle of length 2h) × L` (diagonal in time) -/
def hopSp (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (i : Fin 3) :
    Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  fun a b => if b.1.val = a.1.val then X a.1.val i a.2 b.2 else 0

/-- the time hop `t → t + 1` with the link matrices `v_t` -/
def hopT (h : ℕ) (v : ℕ → Matrix L L ℂ) : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  fun a b => if b.1.val = sc h a.1.val then v a.1.val a.2 b.2 else 0

/-- the four hops, index 3 = time -/
def hop4 (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) (μ : Fin 4) :
    Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  if hμ : μ.val < 3 then hopSp h X ⟨μ.val, hμ⟩ else hopT h v

theorem hop4_zero (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hop4 h X v 0 = hopSp h X 0 := by
  unfold hop4
  rw [dif_pos (by decide)]
  rfl

theorem hop4_one (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hop4 h X v 1 = hopSp h X 1 := by
  unfold hop4
  rw [dif_pos (by decide)]
  rfl

theorem hop4_two (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hop4 h X v 2 = hopSp h X 2 := by
  unfold hop4
  rw [dif_pos (by decide)]
  rfl

theorem hop4_three (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hop4 h X v 3 = hopT h v := by
  unfold hop4
  rw [dif_neg (by decide)]

/-- `M = (m + 4) − ½ Σ_μ (H_μ + H_μᴴ)` -/
noncomputable def massPart (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  ((m : ℂ) + 4) • (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ)
    - (1 / 2 : ℂ) • ∑ μ, (hop4 h X v μ + (hop4 h X v μ)ᴴ)

/-- `A_μ = ½ (H_μ − H_μᴴ)` -/
noncomputable def antiPart (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) (μ : Fin 4) :
    Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  (1 / 2 : ℂ) • (hop4 h X v μ - (hop4 h X v μ)ᴴ)

/-- the relabelling `(t, s, (r, l)) ↦ ((s, r), (t, l))` -/
def relabel (h : ℕ) (L : Type*) : Fin (2 * h) × Fin 2 × (Fin 2 × L) ≃ (Fin 2 × Fin 2) × (Fin (2 * h) × L) where
  toFun a := ((a.2.1, a.2.2.1), (a.1, a.2.2.2))
  invFun b := (b.2.1, b.1.1, b.1.2, b.2.2)
  left_inv _ := rfl
  right_inv _ := rfl

/-- the textbook Wilson operator in Kronecker notation on `(spin) × (time × L)` -/
noncomputable def kron4 (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    Matrix ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ℂ :=
  ((m : ℂ) + 4) • (1 : Matrix ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ℂ)
    - (1 / 2 : ℂ) • ∑ μ, ((1 - gammaAll μ) ⊗ₖ hop4 h X v μ + (1 + gammaAll μ) ⊗ₖ (hop4 h X v μ)ᴴ)

theorem kron4_eq_clifford (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    kron4 h m X v = (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v
      + ∑ μ, gammaAll μ ⊗ₖ antiPart h X v μ := by
  have h1 : (1 : Matrix ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ((Fin 2 × Fin 2) × (Fin (2 * h) × L)) ℂ)
      = (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) :=
    one_kronecker_one.symm
  unfold kron4
  rw [h1]
  ext a b
  simp only [massPart, antiPart, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply, Matrix.sum_apply,
    Matrix.kroneckerMap_apply, Matrix.conjTranspose_apply, smul_eq_mul, Fin.sum_univ_four]
  ring

/-- **The textbook operator is the Kronecker form** (entrywise, after the relabelling). -/
theorem std4_eq_kron4 (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    std4 h m X v = (kron4 h m X v).submatrix (relabel h L) (relabel h L) := by
  ext ⟨t, s, r, l⟩ ⟨t', s', r', l'⟩
  simp only [Matrix.submatrix_apply, relabel, Equiv.coe_fn_mk]
  unfold kron4 std4 stdSlice
  dsimp only
  simp only [Matrix.sub_apply, Matrix.add_apply, Matrix.smul_apply, Matrix.sum_apply, Matrix.kroneckerMap_apply,
    Matrix.conjTranspose_apply, smul_eq_mul, Fin.sum_univ_four, Fin.sum_univ_three, gammaAll_zero, gammaAll_one,
    gammaAll_two, gammaAll_three, hop4_zero, hop4_one, hop4_two, hop4_three, hopSp, hopT, star_ite_zero,
    one_prod_apply]
  by_cases ht : t' = t
  · subst ht
    have e : ∀ (a b : Fin 2 × (Fin 2 × L)),
        (1 : Matrix (Fin 2 × (Fin 2 × L)) (Fin 2 × (Fin 2 × L)) ℂ) a b
          = (1 : Matrix (Fin 2) (Fin 2) ℂ) a.1 b.1
            * ((1 : Matrix (Fin 2) (Fin 2) ℂ) a.2.1 b.2.1 * (1 : Matrix L L ℂ) a.2.2 b.2.2) := by
      intro a b
      obtain ⟨a1, a2, a3⟩ := a
      obtain ⟨b1, b2, b3⟩ := b
      rw [one_prod_apply, one_prod_apply]
    simp only [if_true, Matrix.one_apply_eq, e]
    ring
  · have htv : ¬ t'.val = t.val := fun e => ht (Fin.ext e)
    have htv' : ¬ t.val = t'.val := fun e => ht (Fin.ext e.symm)
    have hne : t ≠ t' := fun e => ht e.symm
    simp only [htv, htv', if_false, star_zero, Matrix.one_apply_ne hne]
    ring

/-- **Clifford form of the Wilson operator.** -/
theorem std4_eq_clifford (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    std4 h m X v = ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v
      + ∑ μ, gammaAll μ ⊗ₖ antiPart h X v μ).submatrix (relabel h L) (relabel h L) := by
  rw [std4_eq_kron4, kron4_eq_clifford]

theorem det_std4_eq_clifford (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    (std4 h m X v).det = ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v
      + ∑ μ, gammaAll μ ⊗ₖ antiPart h X v μ).det := by
  rw [std4_eq_clifford, det_submatrix_equiv_self]

theorem massPart_conjTranspose (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    (massPart h m X v)ᴴ = massPart h m X v := by
  have hs : star ((m : ℂ) + 4) = (m : ℂ) + 4 := by
    apply Complex.ext <;> simp
  have h2 : star (1 / 2 : ℂ) = 1 / 2 := by
    rw [Complex.star_def, map_div₀, map_one, map_ofNat]
  have hsum : (∑ μ, (hop4 h X v μ + (hop4 h X v μ)ᴴ))ᴴ = ∑ μ, (hop4 h X v μ + (hop4 h X v μ)ᴴ) := by
    rw [conjTranspose_sum]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [conjTranspose_add, conjTranspose_conjTranspose, add_comm]
  unfold massPart
  rw [conjTranspose_sub, conjTranspose_smul, conjTranspose_one, conjTranspose_smul, hsum, hs, h2]

theorem antiPart_conjTranspose (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) (μ : Fin 4) :
    (antiPart h X v μ)ᴴ = -antiPart h X v μ := by
  have h2 : star (1 / 2 : ℂ) = 1 / 2 := by
    rw [Complex.star_def, map_div₀, map_one, map_ofNat]
  unfold antiPart
  rw [conjTranspose_smul, conjTranspose_sub, conjTranspose_conjTranspose, h2, ← neg_sub, smul_neg]

/-- **Hermitian part of the Wilson operator**: `D + Dᴴ = 2 (1 ⊗ M)` (relabelled). -/
theorem std4_add_conjTranspose (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    std4 h m X v + (std4 h m X v)ᴴ
      = ((2 : ℂ) • ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v)).submatrix
          (relabel h L) (relabel h L) := by
  have hneg : ∀ μ, (gammaAll μ ⊗ₖ antiPart h X v μ)ᴴ = -(gammaAll μ ⊗ₖ antiPart h X v μ) := fun μ => by
    rw [conjTranspose_kronecker, gammaAll_isHermitian, antiPart_conjTranspose]
    ext a b
    simp [Matrix.kroneckerMap_apply]
  have key : ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v
      + ∑ μ, gammaAll μ ⊗ₖ antiPart h X v μ)
      + ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v
      + ∑ μ, gammaAll μ ⊗ₖ antiPart h X v μ)ᴴ
      = (2 : ℂ) • ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v) := by
    rw [conjTranspose_add, conjTranspose_kronecker, conjTranspose_one, massPart_conjTranspose, conjTranspose_sum,
      Finset.sum_congr rfl fun μ _ => hneg μ, Finset.sum_neg_distrib, two_smul]
    abel
  rw [std4_eq_clifford, conjTranspose_submatrix]
  ext a b
  have := congrFun (congrFun key (relabel h L a)) (relabel h L b)
  simpa only [Matrix.submatrix_apply, Matrix.add_apply, Matrix.smul_apply] using this

/-- for unitary hops, `M = m + ½ Σ_μ (1 − H_μ)ᴴ (1 − H_μ)` -/
theorem massPart_eq_sos (h : ℕ) (m : ℝ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ)
    (hU : ∀ μ, (hop4 h X v μ)ᴴ * hop4 h X v μ = 1) :
    massPart h m X v = (m : ℂ) • (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ)
      + (1 / 2 : ℂ) • ∑ μ, (1 - hop4 h X v μ)ᴴ * (1 - hop4 h X v μ) := by
  have e : ∀ μ, (1 - hop4 h X v μ)ᴴ * (1 - hop4 h X v μ)
      = (2 : ℂ) • (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) - (hop4 h X v μ + (hop4 h X v μ)ᴴ) := by
    intro μ
    rw [conjTranspose_sub, conjTranspose_one, Matrix.sub_mul, Matrix.mul_sub, Matrix.mul_sub, Matrix.one_mul,
      Matrix.mul_one, Matrix.one_mul, hU μ, two_smul]
    abel
  ext a b
  have e' : ∀ μ, (((1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) - hop4 h X v μ)ᴴ
      * ((1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) - hop4 h X v μ)) a b
      = 2 * (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) a b
        - (hop4 h X v μ a b + star (hop4 h X v μ b a)) := by
    intro μ
    rw [e μ]
    simp only [Matrix.sub_apply, Matrix.smul_apply, Matrix.add_apply, Matrix.conjTranspose_apply, smul_eq_mul]
  simp only [massPart, Matrix.add_apply, Matrix.sub_apply, Matrix.smul_apply, Matrix.sum_apply, smul_eq_mul,
    Matrix.conjTranspose_apply, e', Fin.sum_univ_four]
  ring

/-- **`m > 0`: the Wilson operator is invertible for every configuration with unitary hops** (from the Hermitian
part; no smallness of the field). -/
theorem std4_isUnit_det_of_pos (h : ℕ) (m : ℝ) (hm : 0 < m) (X : ℕ → Fin 3 → Matrix L L ℂ)
    (v : ℕ → Matrix L L ℂ) (hU : ∀ μ, (hop4 h X v μ)ᴴ * hop4 h X v μ = 1) :
    IsUnit (std4 h m X v).det := by
  have hM : (massPart h m X v).PosDef := by
    rw [massPart_eq_sos h m X v hU]
    have e1 : (m : ℂ) • (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ)
        = (m : ℝ) • (1 : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) := by
      ext a b
      simp [Matrix.smul_apply]
    have e2 : (1 / 2 : ℂ) • ∑ μ, (1 - hop4 h X v μ)ᴴ * (1 - hop4 h X v μ)
        = (1 / 2 : ℝ) • ∑ μ, (1 - hop4 h X v μ)ᴴ * (1 - hop4 h X v μ) := by
      ext a b
      simp [Matrix.smul_apply]
    rw [e1, e2]
    exact (PosDef.one.smul hm).add_posSemidef
      ((Matrix.posSemidef_sum _ fun μ _ => Matrix.posSemidef_conjTranspose_mul_self _).smul (by norm_num))
  have e3 : (2 : ℂ) • ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v)
      = (2 : ℝ) • ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v) := by
    ext a b
    simp [Matrix.smul_apply]
  have hK : ((2 : ℂ) • ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ massPart h m X v)).PosDef := by
    rw [e3]
    exact (PosDef.one.kronecker hM).smul (by norm_num)
  apply FermionHermitePart.isUnit_det_of_add_conjTranspose_posDef
  rw [std4_add_conjTranspose]
  exact hK.submatrix (relabel h L).injective

end CliffordForm

/-! ### The free configuration -/

section Free

/-- the antiperiodic time shift with unit links: `S t t' = [t' = t + 1] · (−1 on the link 2h − 1 → 0)` -/
def tshift (h : ℕ) : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ :=
  fun t t' => if t'.val = sc h t.val then (if t.val + 1 = 2 * h then -1 else 1) else 0

theorem tshift_pow (h : ℕ) (k : ℕ) (hk : k ≤ 2 * h) (t t' : Fin (2 * h)) :
    (tshift h ^ k) t t' = if t'.val = (if t.val + k < 2 * h then t.val + k else t.val + k - 2 * h)
      then (if 2 * h ≤ t.val + k then (-1 : ℂ) else 1) else 0 := by
  induction k generalizing t' with
  | zero =>
    simp only [pow_zero, Nat.add_zero]
    rw [Matrix.one_apply, if_neg (by omega : ¬ 2 * h ≤ t.val), if_pos t.isLt]
    by_cases e : t = t'
    · subst e
      simp
    · have e' : ¬ t'.val = t.val := fun e' => e (Fin.ext e'.symm)
      rw [if_neg e, if_neg e']
  | succ k ih =>
    have hk' : k ≤ 2 * h := by omega
    obtain ⟨n, hn⟩ : ∃ n, n = (if t.val + k < 2 * h then t.val + k else t.val + k - 2 * h) := ⟨_, rfl⟩
    have hnlt : n < 2 * h := by
      have := t.isLt
      split_ifs at hn <;> omega
    rw [pow_succ, Matrix.mul_apply, Finset.sum_eq_single (⟨n, hnlt⟩ : Fin (2 * h))]
    · rw [ih hk' ⟨n, hnlt⟩]
      have hnn : (⟨n, hnlt⟩ : Fin (2 * h)).val = (if t.val + k < 2 * h then t.val + k else t.val + k - 2 * h) := hn
      rw [if_pos hnn]
      have hsc : sc h n = (if t.val + (k + 1) < 2 * h then t.val + (k + 1) else t.val + (k + 1) - 2 * h) := by
        have := t.isLt
        unfold sc
        split_ifs at hn ⊢ <;> omega
      have hsg : (if 2 * h ≤ t.val + k then (-1 : ℂ) else 1) * (if n + 1 = 2 * h then -1 else 1)
          = (if 2 * h ≤ t.val + (k + 1) then (-1 : ℂ) else 1) := by
        have := t.isLt
        split_ifs at hn ⊢ <;> first | omega | norm_num
      show (if 2 * h ≤ t.val + k then (-1 : ℂ) else 1)
          * (if t'.val = sc h n then (if n + 1 = 2 * h then -1 else 1) else 0) = _
      rw [hsc]
      by_cases e : t'.val = (if t.val + (k + 1) < 2 * h then t.val + (k + 1) else t.val + (k + 1) - 2 * h)
      · rw [if_pos e, if_pos e, hsg]
      · rw [if_neg e, if_neg e, mul_zero]
    · intro b _ hb
      rw [ih hk' b]
      have hb' : ¬ b.val = (if t.val + k < 2 * h then t.val + k else t.val + k - 2 * h) := by
        intro e
        exact hb (Fin.ext (e.trans hn.symm))
      rw [if_neg hb', zero_mul]
    · intro hn'
      exact absurd (Finset.mem_univ _) hn'

/-- **`S^(2h) = −1`**: one antiperiodic sign around the time circle -/
theorem tshift_pow_two_h (h : ℕ) : tshift h ^ (2 * h) = -1 := by
  ext t t'
  have := t.isLt
  have h1 : ¬ (t.val + 2 * h < 2 * h) := by omega
  have h2 : 2 * h ≤ t.val + 2 * h := by omega
  rw [tshift_pow h (2 * h) le_rfl, if_neg h1, if_pos h2, Nat.add_sub_cancel]
  show _ = -((1 : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ) t t')
  rw [Matrix.one_apply]
  by_cases e : t'.val = t.val
  · have : t = t' := Fin.ext e.symm
    subst this
    simp
  · have : ¬ t = t' := fun h' => e (h' ▸ rfl)
    rw [if_neg e, if_neg this, neg_zero]

theorem tshift_unitary (h : ℕ) : (tshift h)ᴴ * tshift h = 1 := by
  ext t t'
  have ht := t.isLt
  obtain ⟨p, hp⟩ : ∃ p, p = (if t.val = 0 then 2 * h - 1 else t.val - 1) := ⟨_, rfl⟩
  have hplt : p < 2 * h := by split_ifs at hp <;> omega
  have hscp : sc h p = t.val := by unfold sc; split_ifs at hp ⊢ <;> omega
  rw [Matrix.mul_apply, Finset.sum_eq_single (⟨p, hplt⟩ : Fin (2 * h))]
  · have e1 : tshift h ⟨p, hplt⟩ t = if p + 1 = 2 * h then (-1 : ℂ) else 1 := by
      show (if t.val = sc h p then (if p + 1 = 2 * h then (-1 : ℂ) else 1) else 0) = _
      rw [if_pos hscp.symm]
    have e2 : tshift h ⟨p, hplt⟩ t' = if t'.val = t.val then (if p + 1 = 2 * h then (-1 : ℂ) else 1) else 0 := by
      show (if t'.val = sc h p then (if p + 1 = 2 * h then (-1 : ℂ) else 1) else 0) = _
      rw [hscp]
    rw [Matrix.conjTranspose_apply, e1, e2, Matrix.one_apply]
    by_cases e : t'.val = t.val
    · have : t = t' := Fin.ext e.symm
      subst this
      rw [if_pos rfl, if_pos rfl]
      split_ifs <;> simp
    · have : ¬ t = t' := fun h' => e (h' ▸ rfl)
      rw [if_neg e, if_neg this, mul_zero]
  · intro b _ hb
    have hb' : ¬ t.val = sc h b.val := by
      intro e
      apply hb
      apply Fin.ext
      show b.val = p
      have := b.isLt
      unfold sc at e
      split_ifs at hp e <;> omega
    have e0 : tshift h b t = 0 := by
      show (if t.val = sc h b.val then (if b.val + 1 = 2 * h then (-1 : ℂ) else 1) else 0) = 0
      rw [if_neg hb']
    rw [Matrix.conjTranspose_apply, e0, star_zero, zero_mul]
  · intro hn'
    exact absurd (Finset.mem_univ _) hn'

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- the free time links: `1`, with the antiperiodic sign `−1` on the link `2h − 1 → 0` -/
noncomputable def vfree (h : ℕ) : ℕ → Matrix L L ℂ :=
  fun t => (if t + 1 = 2 * h then (-1 : ℂ) else 1) • (1 : Matrix L L ℂ)

theorem hopT_vfree (h : ℕ) : hopT h (vfree (L := L) h) = tshift h ⊗ₖ (1 : Matrix L L ℂ) := by
  ext ⟨t, l⟩ ⟨t', l'⟩
  simp only [hopT, vfree, tshift, Matrix.kroneckerMap_apply, Matrix.smul_apply, smul_eq_mul]
  by_cases e : t'.val = sc h t.val
  · rw [if_pos e, if_pos e]
  · rw [if_neg e, if_neg e, zero_mul]

theorem hopSp_const (h : ℕ) (Y : Fin 3 → Matrix L L ℂ) (i : Fin 3) :
    hopSp h (fun _ => Y) i = (1 : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ) ⊗ₖ Y i := by
  ext ⟨t, l⟩ ⟨t', l'⟩
  simp only [hopSp, Matrix.kroneckerMap_apply, Matrix.one_apply]
  by_cases e : t = t'
  · subst e
    simp
  · have e' : ¬ t'.val = t.val := fun e' => e (Fin.ext e'.symm)
    rw [if_neg e', if_neg e, zero_mul]

/-- the first factors of the free hops: `1` (spatial) and `S` (time) -/
def freeA (h : ℕ) (μ : Fin 4) : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ :=
  if μ.val < 3 then 1 else tshift h

/-- the second factors of the free hops: `Y_i` (spatial) and `1` (time) -/
def freeB (Y : Fin 3 → Matrix L L ℂ) (μ : Fin 4) : Matrix L L ℂ :=
  if hμ : μ.val < 3 then Y ⟨μ.val, hμ⟩ else 1

theorem hop4_free (h : ℕ) (Y : Fin 3 → Matrix L L ℂ) (μ : Fin 4) :
    hop4 h (fun _ => Y) (vfree h) μ = freeA h μ ⊗ₖ freeB Y μ := by
  unfold hop4 freeA freeB
  by_cases hμ : μ.val < 3
  · rw [dif_pos hμ, if_pos hμ, dif_pos hμ, hopSp_const]
  · rw [dif_neg hμ, if_neg hμ, dif_neg hμ, hopT_vfree]

theorem commute_kronecker {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]
    {A A' : Matrix ι ι ℂ} {B B' : Matrix κ κ ℂ} (hA : Commute A A') (hB : Commute B B') :
    Commute (A ⊗ₖ B) (A' ⊗ₖ B') := by
  show (A ⊗ₖ B) * (A' ⊗ₖ B') = (A' ⊗ₖ B') * (A ⊗ₖ B)
  rw [← mul_kronecker_mul, ← mul_kronecker_mul, hA.eq, hB.eq]

/-- commuting unitaries: the adjoint of one commutes with the other -/
theorem commute_conjTranspose_of_unitary {κ : Type*} [Fintype κ] [DecidableEq κ] {P Q : Matrix κ κ ℂ}
    (hP : Pᴴ * P = 1) (hPQ : Commute P Q) : Commute Pᴴ Q := by
  have hP' : P * Pᴴ = 1 := mul_eq_one_comm.mp hP
  show Pᴴ * Q = Q * Pᴴ
  calc Pᴴ * Q = Pᴴ * Q * (P * Pᴴ) := by rw [hP', Matrix.mul_one]
    _ = Pᴴ * (Q * P) * Pᴴ := by simp only [Matrix.mul_assoc]
    _ = Pᴴ * (P * Q) * Pᴴ := by rw [hPQ.eq]
    _ = Q * Pᴴ := by rw [← Matrix.mul_assoc, hP, Matrix.one_mul]

/-- if every hop and its adjoint commute with every hop, then `M` and the `A_μ` commute -/
theorem parts_commute {κ : Type*} [Fintype κ] [DecidableEq κ] (H : Fin 4 → Matrix κ κ ℂ) (c : ℂ)
    (h1 : ∀ μ ν, Commute (H μ) (H ν)) (h2 : ∀ μ ν, Commute (H μ)ᴴ (H ν)) :
    (∀ μ, (c • (1 : Matrix κ κ ℂ) - (1 / 2 : ℂ) • ∑ ν, (H ν + (H ν)ᴴ)) * ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ))
        = ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ)) * (c • (1 : Matrix κ κ ℂ) - (1 / 2 : ℂ) • ∑ ν, (H ν + (H ν)ᴴ)))
    ∧ ∀ μ ν, ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ)) * ((1 / 2 : ℂ) • (H ν - (H ν)ᴴ))
        = ((1 / 2 : ℂ) • (H ν - (H ν)ᴴ)) * ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ)) := by
  have h3 : ∀ μ ν, Commute (H μ)ᴴ (H ν)ᴴ := by
    intro μ ν
    show (H μ)ᴴ * (H ν)ᴴ = (H ν)ᴴ * (H μ)ᴴ
    rw [← conjTranspose_mul, ← conjTranspose_mul, (h1 ν μ).eq]
  have h4 : ∀ μ ν, Commute (H μ) (H ν)ᴴ := fun μ ν => (h2 ν μ).symm
  -- anything commuting with all `H ν`, `H νᴴ` commutes with `M` and with every `A μ`
  have cM : ∀ P : Matrix κ κ ℂ, (∀ ν, Commute P (H ν)) → (∀ ν, Commute P (H ν)ᴴ) →
      Commute P (c • (1 : Matrix κ κ ℂ) - (1 / 2 : ℂ) • ∑ ν, (H ν + (H ν)ᴴ)) := by
    intro P hP hP'
    exact ((Commute.one_right P).smul_right c).sub_right
      ((Commute.sum_right _ _ _ fun ν _ => (hP ν).add_right (hP' ν)).smul_right _)
  have cA : ∀ P : Matrix κ κ ℂ, (∀ ν, Commute P (H ν)) → (∀ ν, Commute P (H ν)ᴴ) →
      ∀ μ, Commute P ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ)) := by
    intro P hP hP' μ
    exact ((hP μ).sub_right (hP' μ)).smul_right _
  refine ⟨fun μ => ?_, fun μ ν => ?_⟩
  · have hHM := cM (H μ) (h1 μ) (h4 μ)
    have hHsM := cM (H μ)ᴴ (h2 μ) (h3 μ)
    exact (((hHM.sub_left hHsM).smul_left (1 / 2 : ℂ)).symm).eq
  · have hHA := cA (H μ) (h1 μ) (h4 μ) ν
    have hHsA := cA (H μ)ᴴ (h2 μ) (h3 μ) ν
    exact ((hHA.sub_left hHsA).smul_left (1 / 2 : ℂ)).eq

theorem kron_pow_one {ι κ : Type*} [Fintype ι] [DecidableEq ι] [Fintype κ] [DecidableEq κ]
    (A : Matrix ι ι ℂ) (k : ℕ) : (A ⊗ₖ (1 : Matrix κ κ ℂ)) ^ k = (A ^ k) ⊗ₖ (1 : Matrix κ κ ℂ) := by
  induction k with
  | zero => rw [pow_zero, pow_zero, one_kronecker_one]
  | succ k ih => rw [pow_succ, ih, ← mul_kronecker_mul, Matrix.one_mul, ← pow_succ]

/-- **`det D ≠ 0` at the free configuration, for every bare mass `m`.**  Spatial hops `Y_i` (the same on every time
slice), unitary and commuting; time links `1` with the antiperiodic sign.  This gives `Z > 0` together with
continuity (`FermionGibbsParameter.partition_pos`). -/
theorem std4_free_isUnit_det (h : ℕ) (m : ℝ) (Y : Fin 3 → Matrix L L ℂ)
    (hYu : ∀ i, (Y i)ᴴ * Y i = 1) (hYY : ∀ i j, Commute (Y i) (Y j)) :
    IsUnit (std4 h m (fun _ => Y) (vfree h)).det := by
  -- the factors commute, with adjoints
  have hS : (tshift h)ᴴ * tshift h = 1 := tshift_unitary h
  have hAc : ∀ μ ν, Commute (freeA h μ) (freeA h ν) := by
    intro μ ν
    unfold freeA
    split_ifs
    · exact Commute.one_left _
    · exact Commute.one_left _
    · exact Commute.one_right _
    · exact Commute.refl _
  have hAs : ∀ μ ν, Commute (freeA h μ)ᴴ (freeA h ν) := by
    intro μ ν
    unfold freeA
    split_ifs
    · rw [conjTranspose_one]; try exact Commute.one_left _
    · rw [conjTranspose_one]; try exact Commute.one_left _
    · exact Commute.one_right _
    · exact commute_conjTranspose_of_unitary hS (Commute.refl _)
  have hBc : ∀ μ ν, Commute (freeB Y μ) (freeB Y ν) := by
    intro μ ν
    unfold freeB
    split_ifs
    · exact hYY _ _
    · exact Commute.one_right _
    · exact Commute.one_left _
    · exact Commute.refl _
  have hBs : ∀ μ ν, Commute (freeB Y μ)ᴴ (freeB Y ν) := by
    intro μ ν
    unfold freeB
    split_ifs
    · exact commute_conjTranspose_of_unitary (hYu _) (hYY _ _)
    · exact Commute.one_right _
    · rw [conjTranspose_one]; try exact Commute.one_left _
    · rw [conjTranspose_one]; try exact Commute.one_left _
  have h1 : ∀ μ ν, Commute (hop4 h (fun _ => Y) (vfree h) μ) (hop4 h (fun _ => Y) (vfree h) ν) := by
    intro μ ν
    rw [hop4_free, hop4_free]
    exact commute_kronecker (hAc μ ν) (hBc μ ν)
  have h2 : ∀ μ ν, Commute (hop4 h (fun _ => Y) (vfree h) μ)ᴴ (hop4 h (fun _ => Y) (vfree h) ν) := by
    intro μ ν
    rw [hop4_free, hop4_free, conjTranspose_kronecker]
    exact commute_kronecker (hAs μ ν) (hBs μ ν)
  obtain ⟨hMA, hAA⟩ := parts_commute (hop4 h (fun _ => Y) (vfree h)) ((m : ℂ) + 4) h1 h2
  -- the time part is invertible
  have hT3 : hop4 h (fun _ => Y) (vfree h) 3 = tshift h ⊗ₖ (1 : Matrix L L ℂ) := by
    rw [hop4_three, hopT_vfree]
  have hTu : (tshift h ⊗ₖ (1 : Matrix L L ℂ))ᴴ * (tshift h ⊗ₖ (1 : Matrix L L ℂ)) = 1 := by
    rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, hS, Matrix.one_mul, one_kronecker_one]
  have hTp : (tshift h ⊗ₖ (1 : Matrix L L ℂ)) ^ (2 * h) = -1 := by
    rw [kron_pow_one, tshift_pow_two_h,
      show (-1 : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ) ⊗ₖ (1 : Matrix L L ℂ)
        = -((1 : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ) ⊗ₖ (1 : Matrix L L ℂ)) from by
          ext ⟨a1, a2⟩ ⟨b1, b2⟩
          simp [Matrix.kroneckerMap_apply, one_prod_apply],
      one_kronecker_one]
  have hA3 : IsUnit (antiPart h (fun _ => Y) (vfree h) 3).det := by
    unfold antiPart
    rw [hT3]
    exact FermionFreeInvertible.half_sub_conjTranspose_isUnit_det _ hTu h hTp
  rw [det_std4_eq_clifford]
  exact FermionFreeInvertible.free_dirac_isUnit_det gammaAll gammaAll_isHermitian gammaAll_clifford
    (massPart h m (fun _ => Y) (vfree h)) (massPart_conjTranspose h m _ _)
    (antiPart h (fun _ => Y) (vfree h)) (antiPart_conjTranspose h _ _) hMA hAA 3 hA3

end Free

end FermionSliceBlock

-- ===== part : TorusFree.part.lean =====

/-! # The free configuration on the spatial torus 

Paper side: With the links `U_x,i = −1` on the boundary links `x_i = N − 1` and `1` elsewhere
(`usign`; `±1 ∈ SU(2)`), the antiperiodic sign of `torusLink` cancels and the spatial hops are permutation matrices of
the commuting shifts `x ↦ x − e_i`; with the free time links `vfree` the textbook operator is invertible for every
`m` (`std4_free_torus_isUnit_det`). -/
namespace FermionSliceBlock

open Matrix
open scoped Kronecker

section TorusFree

variable {C : Type*} [Fintype C] [DecidableEq C]

/-- the sign links: `−1` on the boundary links `x_i = N − 1`, `1` elsewhere -/
def usign (N : ℕ) : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ :=
  fun x i => (if (x i).val + 1 = N then (-1 : ℂ) else 1) • (1 : Matrix C C ℂ)

theorem usign_unitary (N : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) :
    (usign (C := C) N x i)ᴴ * usign N x i = 1 := by
  unfold usign
  split_ifs <;> simp

theorem shiftMat_one_eq {S : Type*} [Fintype S] [DecidableEq S] (σ : S ≃ S) :
    shiftMat σ (fun _ => (1 : Matrix C C ℂ))
      = (1 : Matrix (C × S) (C × S) ℂ).submatrix id (Equiv.prodCongr (Equiv.refl C) σ) := by
  ext ⟨c, x⟩ ⟨c', y⟩
  rw [shiftMat_apply]
  simp only [Matrix.submatrix_apply, id, Equiv.prodCongr_apply, Equiv.coe_refl, Prod.map_apply,
    Matrix.one_apply, Prod.mk.injEq]
  by_cases hx : x = σ y
  · by_cases hc : c = c' <;> simp [hx, hc]
  · simp [hx]

theorem perm_mul_perm {β : Type*} [Fintype β] [DecidableEq β] (e f : β ≃ β) :
    (1 : Matrix β β ℂ).submatrix id e * (1 : Matrix β β ℂ).submatrix id f
      = (1 : Matrix β β ℂ).submatrix id (f.trans e) := by
  ext a b
  rw [Matrix.mul_apply, Finset.sum_eq_single (f b)]
  · simp [Matrix.one_apply]
  · intro c _ hc
    simp [Matrix.one_apply, hc]
  · intro hn
    exact absurd (Finset.mem_univ _) hn

theorem torusX_usign (N : ℕ) [NeZero N] (i : Fin 3) :
    torusX N (usign (C := C) N) i = shiftMat (torusShift N i) (fun _ => (1 : Matrix C C ℂ)) := by
  unfold torusX
  congr 1
  funext x
  unfold torusLink usign
  rw [smul_smul]
  split_ifs <;> norm_num

theorem torusX_usign_commute (N : ℕ) [NeZero N] (i j : Fin 3) :
    Commute (torusX N (usign (C := C) N) i) (torusX N (usign (C := C) N) j) := by
  rw [torusX_usign, torusX_usign, shiftMat_one_eq, shiftMat_one_eq]
  show _ * _ = _ * _
  rw [perm_mul_perm, perm_mul_perm]
  congr 1
  funext ⟨c, x⟩
  simp only [Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map_apply, Equiv.refl_apply, torusShift,
    Equiv.coe_addRight]
  congr 1
  abel

/-- **`det D ≠ 0` at the free configuration of the torus `(Fin N)³ × (time circle 2h)`, for every bare mass.** -/
theorem std4_free_torus_isUnit_det (N : ℕ) [NeZero N] (h : ℕ) (m : ℝ) :
    IsUnit (std4 h m (fun _ => torusX N (usign (C := C) N)) (vfree h)).det :=
  std4_free_isUnit_det h m (torusX N (usign N)) (fun i => torusX_unitary N _ (usign_unitary N) i)
    (torusX_usign_commute N)

end TorusFree

end FermionSliceBlock

-- ===== part : SU2Config.part.lean =====

/-! # `SU(2)` link variables as unit quaternions; the plane matrix is Hermitian 

Paper side: (the configuration space `Π SU(2)` of the links); check.
`SU2 = Metric.sphere (0 : ℍ) 1` (the same realisation as the run on row 10).  `quatMat q` is the `2 × 2` matrix
`[[a + ib, c + id], [−c + id, a − ib]]` of `q = a + bi + cj + dk`; for `‖q‖ = 1` it is unitary with determinant `1`,
it is multiplicative, and `quatMat (star q) = (quatMat q)ᴴ` (the reflected time links carry `†`, and on `SU2`
`star q = q⁻¹`).  Products `Λ → SU2` are compact, second countable and Borel. -/
namespace FermionSU2Config

open Matrix

/-- `SU(2)` realised as the group of unit quaternions -/
abbrev SU2 : Type := Metric.sphere (0 : Quaternion ℝ) 1

noncomputable instance : MeasurableSpace SU2 := borel SU2

instance : BorelSpace SU2 := ⟨rfl⟩

/-- the fundamental `2 × 2` matrix of a quaternion -/
noncomputable def quatMat (q : Quaternion ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![(q.re : ℂ) + (q.imI : ℂ) * Complex.I, (q.imJ : ℂ) + (q.imK : ℂ) * Complex.I;
     -(q.imJ : ℂ) + (q.imK : ℂ) * Complex.I, (q.re : ℂ) - (q.imI : ℂ) * Complex.I]

theorem normSq_eq_one (q : SU2) :
    (q : Quaternion ℝ).re ^ 2 + (q : Quaternion ℝ).imI ^ 2 + (q : Quaternion ℝ).imJ ^ 2
      + (q : Quaternion ℝ).imK ^ 2 = 1 := by
  have hn : ‖(q : Quaternion ℝ)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h1 : Quaternion.normSq (q : Quaternion ℝ) = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, hn, mul_one]
  rwa [Quaternion.normSq_def'] at h1

/-- `quatMat q` is unitary for a unit quaternion -/
theorem quatMat_unitary (q : SU2) : (quatMat q)ᴴ * quatMat q = 1 := by
  have h1 := normSq_eq_one q
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [quatMat, Matrix.mul_apply, Fin.sum_univ_two, Matrix.conjTranspose_apply, Complex.ext_iff,
      Complex.conj_ofReal] <;>
    (try simp only [and_true, true_and]) <;>
    (try refine ⟨?_, ?_⟩) <;>
    first
    | trivial
    | ring1
    | linear_combination h1

/-- `det (quatMat q) = 1` for a unit quaternion: the matrices are in `SU(2)` -/
theorem quatMat_det (q : SU2) : (quatMat q).det = 1 := by
  have h1 := normSq_eq_one q
  rw [Matrix.det_fin_two]
  simp only [quatMat, Matrix.of_apply, Matrix.cons_val', Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.empty_val', Matrix.cons_val_fin_one, Matrix.head_cons, Matrix.head_fin_const]
  apply Complex.ext <;> simp <;> first | ring1 | linear_combination h1

/-- conjugation of the quaternion is the adjoint of the matrix -/
theorem quatMat_star (q : Quaternion ℝ) : quatMat (star q) = (quatMat q)ᴴ := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [quatMat, Matrix.conjTranspose_apply, Complex.ext_iff, Complex.conj_ofReal]

/-- `quatMat` is multiplicative -/
theorem quatMat_mul (p q : Quaternion ℝ) : quatMat (p * q) = quatMat p * quatMat q := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [quatMat, Matrix.mul_apply, Fin.sum_univ_two, Complex.ext_iff] <;>
    (try simp only [and_true, true_and]) <;>
    first | trivial | ring1 | (constructor <;> ring1)

/-- on `SU2`, the inverse is the conjugate, so the matrix of `q⁻¹` is the adjoint -/
theorem quatMat_inv (q : SU2) : quatMat ((q⁻¹ : SU2) : Quaternion ℝ) = (quatMat q)ᴴ := by
  have hn : ‖(q : Quaternion ℝ)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h1 : (q : Quaternion ℝ) * star (q : Quaternion ℝ) = 1 := by
    rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hn]
    simp
  have h2 : (q : Quaternion ℝ)⁻¹ = star (q : Quaternion ℝ) := inv_eq_of_mul_eq_one_right h1
  rw [Metric.unitSphere.coe_inv, h2, quatMat_star]

theorem continuous_quatMat_elem (a b : Fin 2) :
    Continuous fun q : SU2 => quatMat (q : Quaternion ℝ) a b := by
  have hr : Continuous fun q : SU2 => ((q : Quaternion ℝ).re : ℂ) :=
    Complex.continuous_ofReal.comp (Quaternion.continuous_re.comp continuous_subtype_val)
  have hi : Continuous fun q : SU2 => ((q : Quaternion ℝ).imI : ℂ) :=
    Complex.continuous_ofReal.comp (Quaternion.continuous_imI.comp continuous_subtype_val)
  have hj : Continuous fun q : SU2 => ((q : Quaternion ℝ).imJ : ℂ) :=
    Complex.continuous_ofReal.comp (Quaternion.continuous_imJ.comp continuous_subtype_val)
  have hk : Continuous fun q : SU2 => ((q : Quaternion ℝ).imK : ℂ) :=
    Complex.continuous_ofReal.comp (Quaternion.continuous_imK.comp continuous_subtype_val)
  fin_cases a <;> fin_cases b <;> simp only [quatMat, Matrix.of_apply, Matrix.cons_val', Matrix.cons_val_zero,
    Matrix.cons_val_one, Matrix.empty_val', Matrix.cons_val_fin_one, Matrix.head_cons, Matrix.head_fin_const,
    Fin.zero_eta, Fin.mk_one, Fin.isValue]
  · exact hr.add (hi.mul continuous_const)
  · exact hj.add (hk.mul continuous_const)
  · exact hj.neg.add (hk.mul continuous_const)
  · exact hr.sub (hi.mul continuous_const)

/-- the instances needed by the reflection-positivity theorems hold on products of `SU2` -/
example (Λ : Type) [Fintype Λ] : CompactSpace (Λ → SU2) := inferInstance
example (Λ : Type) [Fintype Λ] : SecondCountableTopology (Λ → SU2) := inferInstance
example (Λ : Type) [Fintype Λ] : OpensMeasurableSpace (Λ → SU2) := inferInstance
example (Λ Λ' : Type) [Fintype Λ] [Fintype Λ'] : OpensMeasurableSpace ((Λ → SU2) × (Λ' → SU2)) :=
  inferInstance
example (Λ Λ' : Type) [Fintype Λ] [Fintype Λ'] : CompactSpace ((Λ → SU2) × (Λ' → SU2)) := inferInstance
/-- the normalised Haar measure of `Λ → SU2` is a finite measure -/
example (Λ : Type) [Fintype Λ] :
    MeasureTheory.IsFiniteMeasure (MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure (Λ → SU2)) :=
  inferInstance

end FermionSU2Config

namespace FermionSliceBlock

open Matrix

variable {W : Type*} [Fintype W] [DecidableEq W]

/-- the plane matrix `(m + 1) + Σ_i (1 − ½ (T_i + T_iᴴ))` is Hermitian for every `m` and every `T` -/
theorem wilsonPlane_isHermitian {d : ℕ} (m : ℝ) (T : Fin d → Matrix W W ℂ) :
    (wilsonPlane m T).IsHermitian := by
  show (wilsonPlane m T)ᴴ = wilsonPlane m T
  unfold wilsonPlane
  rw [conjTranspose_add, conjTranspose_sum]
  congr 1
  · rw [conjTranspose_smul, conjTranspose_one, star_trivial]
  · refine Finset.sum_congr rfl fun i _ => ?_
    rw [conjTranspose_sub, conjTranspose_one, conjTranspose_smul, conjTranspose_add,
      conjTranspose_conjTranspose, star_trivial, add_comm (T i)ᴴ]

end FermionSliceBlock

-- ===== part : SU2Links.part.lean =====

/-! # The link configuration spaces of the torus with `SU(2)` links 

Paper side: (configuration space of the reflection).
`PlaneConf N`: the spatial links of the two reflection planes `t = 0` and `t = h` (each `(Fin N)³ × 3` links).
`PosConf N h`: the spatial links on the slices `0 < t < h` (coordinate `t − 1 : Fin (h − 1)`;: the slice
`t = 0` belongs to the plane, so it is no longer a coordinate here and the identification with `Π_links SU(2)` is a
bijection of coordinates) and the time links `t → t + 1`, `t < h`, of the positive side.  The negative side is a second copy of
`PosConf` (identified through the reflection; its time links enter with `†`, see `quatMat_inv`).  These are compact,
second countable, Borel spaces; their normalised Haar measures are finite. -/
namespace FermionSU2Config

open Matrix MeasureTheory

/-- spatial links of one time slice: site × direction -/
abbrev SpLinks (N : ℕ) : Type := (Fin 3 → Fin N) × Fin 3

/-- the links of the two planes `t = 0`, `t = h` -/
abbrev PlaneConf (N : ℕ) : Type := (SpLinks N → SU2) × (SpLinks N → SU2)

/-- the links of the positive side: spatial links on the slices `0 < t < h` (stored at `t − 1`), time links
`t → t + 1` for `t < h` -/
abbrev PosConf (N hT : ℕ) : Type := (Fin (hT - 1) × SpLinks N → SU2) × (Fin hT × (Fin 3 → Fin N) → SU2)

theorem posIdx_lt {hT t : ℕ} (ht : 0 < t ∧ t < hT) : t - 1 < hT - 1 := by
  have h1 := ht.1
  have h2 := ht.2
  omega

/-- spatial links of the plane `t = 0` as matrices -/
noncomputable def U0of (N : ℕ) (c : PlaneConf N) : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun x i => quatMat (c.1 (x, i))

/-- spatial links of the plane `t = h` as matrices -/
noncomputable def Uhof (N : ℕ) (c : PlaneConf N) : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun x i => quatMat (c.2 (x, i))

/-- spatial links of the positive side as matrices (`1` outside `0 < t < h`, never used) -/
noncomputable def Upof (N hT : ℕ) (a : PosConf N hT) : ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ :=
  fun t x i => if ht : 0 < t ∧ t < hT then quatMat (a.1 (⟨t - 1, posIdx_lt ht⟩, (x, i))) else 1

/-- time links of the positive side as matrices (`1` outside `t < h`, never used) -/
noncomputable def U4of (N hT : ℕ) (a : PosConf N hT) : ℕ → (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ :=
  fun t x => if ht : t < hT then quatMat (a.2 (⟨t, ht⟩, x)) else 1

theorem U0of_unitary (N : ℕ) (c : PlaneConf N) (x : Fin 3 → Fin N) (i : Fin 3) :
    (U0of N c x i)ᴴ * U0of N c x i = 1 := quatMat_unitary _

theorem Uhof_unitary (N : ℕ) (c : PlaneConf N) (x : Fin 3 → Fin N) (i : Fin 3) :
    (Uhof N c x i)ᴴ * Uhof N c x i = 1 := quatMat_unitary _

theorem Upof_unitary (N hT : ℕ) (a : PosConf N hT) (t : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) :
    (Upof N hT a t x i)ᴴ * Upof N hT a t x i = 1 := by
  unfold Upof
  by_cases ht : 0 < t ∧ t < hT
  · rw [dif_pos ht]
    exact quatMat_unitary _
  · rw [dif_neg ht, conjTranspose_one, Matrix.one_mul]

theorem U4of_unitary (N hT : ℕ) (a : PosConf N hT) (t : ℕ) (x : Fin 3 → Fin N) :
    (U4of N hT a t x)ᴴ * U4of N hT a t x = 1 := by
  unfold U4of
  by_cases ht : t < hT
  · rw [dif_pos ht]
    exact quatMat_unitary _
  · rw [dif_neg ht, conjTranspose_one, Matrix.one_mul]

theorem continuous_U0of (N : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) (a b : Fin 2) :
    Continuous fun c : PlaneConf N => U0of N c x i a b :=
  (continuous_quatMat_elem a b).comp ((continuous_apply (x, i)).comp continuous_fst)

theorem continuous_Uhof (N : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) (a b : Fin 2) :
    Continuous fun c : PlaneConf N => Uhof N c x i a b :=
  (continuous_quatMat_elem a b).comp ((continuous_apply (x, i)).comp continuous_snd)

theorem continuous_Upof (N hT : ℕ) (t : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) (a b : Fin 2) :
    Continuous fun p : PosConf N hT => Upof N hT p t x i a b := by
  by_cases ht : 0 < t ∧ t < hT
  · simp only [Upof, dif_pos ht]
    exact (continuous_quatMat_elem a b).comp
      ((continuous_apply (((⟨t - 1, posIdx_lt ht⟩ : Fin (hT - 1))), (x, i))).comp continuous_fst)
  · simp only [Upof, dif_neg ht]
    exact continuous_const

theorem continuous_U4of (N hT : ℕ) (t : ℕ) (x : Fin 3 → Fin N) (a b : Fin 2) :
    Continuous fun p : PosConf N hT => U4of N hT p t x a b := by
  by_cases ht : t < hT
  · simp only [U4of, dif_pos ht]
    exact (continuous_quatMat_elem a b).comp ((continuous_apply (((⟨t, ht⟩ : Fin hT)), x)).comp continuous_snd)
  · simp only [U4of, dif_neg ht]
    exact continuous_const

/-- the instances of the reflection-positivity theorems on the concrete configuration spaces -/
example (N hT : ℕ) : CompactSpace (PosConf N hT) := inferInstance
example (N hT : ℕ) : SecondCountableTopology (PosConf N hT) := inferInstance
example (N hT : ℕ) : OpensMeasurableSpace (PosConf N hT) := inferInstance
example (N : ℕ) : CompactSpace (PlaneConf N) := inferInstance
example (N : ℕ) : OpensMeasurableSpace (PlaneConf N) := inferInstance

/-- the normalised Haar measures of the link groups are finite (they are probability measures) -/
instance haar_posConf_finite (N hT : ℕ) :
    IsFiniteMeasure (Measure.haarMeasure ⊤ : Measure (PosConf N hT)) := inferInstance

instance haar_planeConf_finite (N : ℕ) :
    IsFiniteMeasure (Measure.haarMeasure ⊤ : Measure (PlaneConf N)) := inferInstance

end FermionSU2Config

-- ===== part : TorusSU2.part.lean =====

/-! # The weight `det D^{2j}` of the textbook operator is real and nonnegative; reflection positivity with `SU(2)`
links on the concrete configuration spaces 

Paper side: Lemma 3 of paper A (site reflection, factorised form), fermion version; 
items 2, 3.  What is concrete and what is abstract in `site_reflection_positive_wilson_SU2`:
* concrete: the operator (`std4`, textbook Wilson operator on the torus `(Fin N)³ × (time circle 2h)`, antiperiodic),
  the link variables (unit quaternions = `SU(2)` matrices via `quatMat`), the configuration spaces `PlaneConf`,
  `PosConf` (compact, second countable, Borel);
* abstract: the finite reference measures `ν`, `μ₀` (the Haar probability measures are instances:
  `site_reflection_positive_wilson_SU2_haar`), the gauge weight `k h h` (measurable, bounded, `k ≥ 0`; its
  identification with the Wilson plaquette action is paper), the observable `φ` (real valued);
* paper: the identification of `Π_{all links} SU(2)` with `PlaneConf × PosConf × PosConf` (the negative side's time
  links enter with `†`, i.e. `quatMat q⁻¹`, and Haar measure is inversion invariant) and the bridge to `FineRP`. -/
namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config
open scoped ComplexOrder

/-- **`det D^{2j}` of the textbook operator is real and `≥ 0`** for every configuration and every `m`
(the `std4` form of `wilson_weight_nonneg`; no unitarity is needed). -/
theorem wilson_weight_nonneg_std4 {L : Type*} [Fintype L] [DecidableEq L] (hT j : ℕ) (m : ℝ)
    (X0 Xh : Fin 3 → Matrix L L ℂ) (Xp Xm : ℕ → Fin 3 → Matrix L L ℂ) (vp vm : ℕ → Matrix L L ℂ) :
    0 ≤ ((std4 hT m (Bfull hT X0 Xh Xp Xm) (Vfull hT vp vm)).det ^ (2 * j)).re
      ∧ ((std4 hT m (Bfull hT X0 Xh Xp Xm) (Vfull hT vp vm)).det ^ (2 * j)).im = 0 := by
  rw [← Dop_wilson_eq_std4 hT m X0 Xh Xp Xm vp vm]
  exact wilson_weight_nonneg hT j (wilsonPlane m (fun i => liftShift (X0 i)))
    (wilsonPlane m (fun i => liftShift (Xh i))) (kMat X0) (kMat Xh)
    (fun t => wilsonPlane m (fun i => liftShift (Xp t i))) (fun t => wilsonPlane m (fun i => liftShift (Xm t i)))
    (fun t => kMat (Xp t)) (fun t => kMat (Xm t)) (fun t => liftShift (vp t)) (fun t => liftShift (vm t))
    (wilsonPlane_isHermitian _ _) (wilsonPlane_isHermitian _ _) (kMat_isHermitian _) (kMat_isHermitian _)
    (fun _ => wilsonPlane_isHermitian _ _) (fun _ => wilsonPlane_isHermitian _ _)
    (fun _ => kMat_isHermitian _) (fun _ => kMat_isHermitian _)

/-- the same on the spatial torus with link variables (any matrices) -/
theorem wilson_weight_nonneg_torus {C : Type*} [Fintype C] [DecidableEq C] (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ)
    (U0 Uh : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ) (Up Um : ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ)
    (U4p U4m : ℕ → (Fin 3 → Fin N) → Matrix C C ℂ) :
    0 ≤ ((std4 hT m (Bfull hT (torusX N U0) (torusX N Uh) (fun t => torusX N (Up t)) (fun t => torusX N (Um t)))
        (Vfull hT (fun t => blockDiagonal (U4p t)) (fun t => blockDiagonal (U4m t)))).det ^ (2 * j)).re
      ∧ ((std4 hT m (Bfull hT (torusX N U0) (torusX N Uh) (fun t => torusX N (Up t)) (fun t => torusX N (Um t)))
        (Vfull hT (fun t => blockDiagonal (U4p t)) (fun t => blockDiagonal (U4m t)))).det ^ (2 * j)).im = 0 :=
  wilson_weight_nonneg_std4 hT j m _ _ _ _ _ _

/-- **Site reflection positivity with `SU(2)` links on the concrete configuration spaces.**  The hypotheses on the
operator and on the configuration spaces of `site_reflection_positive_wilson_torus` are all discharged; what remains
are the finite reference measures and the gauge weight / observable (abstract, as in Lemma 3 of paper A). -/
theorem site_reflection_positive_wilson_SU2 (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (ν : Measure (PosConf N hT)) (μ₀ : Measure (PlaneConf N)) [IsFiniteMeasure ν] [IsFiniteMeasure μ₀]
    (j : ℕ) (m : ℝ) (hm : -1 < m)
    (k : PlaneConf N → ℝ) (hw φ : PlaneConf N × PosConf N hT → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ p : PlaneConf N × (PosConf N hT × PosConf N hT), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
            (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det
            ^ (2 * j)).re
        ∂(μ₀.prod (ν.prod ν)) :=
  site_reflection_positive_wilson_torus N ν μ₀ hT hpos j m hm (U0of N) (Uhof N) (Upof N hT) (U4of N hT)
    (U0of_unitary N) (Uhof_unitary N) (Upof_unitary N hT)
    (continuous_U0of N) (continuous_Uhof N) (continuous_Upof N hT) (continuous_U4of N hT)
    k hw φ hk hhw hφ Ck Ch Cφ bk bhw bφ hk0

/-- the same with the normalised Haar measures of the link groups as reference measures -/
theorem site_reflection_positive_wilson_SU2_haar (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (j : ℕ) (m : ℝ) (hm : -1 < m)
    (k : PlaneConf N → ℝ) (hw φ : PlaneConf N × PosConf N hT → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ p : PlaneConf N × (PosConf N hT × PosConf N hT), φ (p.1, p.2.1) * φ (p.1, p.2.2) *
        (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
        ((std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
            (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det
            ^ (2 * j)).re
        ∂((Measure.haarMeasure ⊤ : Measure (PlaneConf N)).prod
          ((Measure.haarMeasure ⊤ : Measure (PosConf N hT)).prod (Measure.haarMeasure ⊤))) :=
  site_reflection_positive_wilson_SU2 N hT hpos _ _ j m hm k hw φ hk hhw hφ Ck Ch Cφ bk bhw bφ hk0

end FermionSliceReflection

-- ===== part : ZPos.part.lean =====

/-! # `Z > 0` for the determinant-weighted measure with `SU(2)` links on the torus 

`Z = ∫ w · Re det D^{2j} d(Haar)` with any continuous positive
gauge weight `w` (e.g. `exp(−β S_W)`), every bare mass `m` and every `j`: the integrand is continuous and `≥ 0`
(`wilson_weight_nonneg_torus`), nonzero at the free configuration (`std4_free_torus_isUnit_det`; the links `±1`
that cancel the antiperiodic boundary sign, time links `1`), and Haar measure is positive on open sets. -/
namespace FermionSliceBlock

open Matrix

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- joint continuity of the textbook operator of the assembled lattice data -/
theorem continuous_std4_assembled {P : Type*} [TopologicalSpace P] (hT : ℕ) (m : ℝ)
    (X0 Xh : P → Fin 3 → Matrix L L ℂ) (Xp Xm : P → ℕ → Fin 3 → Matrix L L ℂ) (vp vm : P → ℕ → Matrix L L ℂ)
    (hX0 : ∀ i l l', Continuous fun p => X0 p i l l') (hXh : ∀ i l l', Continuous fun p => Xh p i l l')
    (hXp : ∀ t i l l', Continuous fun p => Xp p t i l l') (hXm : ∀ t i l l', Continuous fun p => Xm p t i l l')
    (hvp : ∀ t l l', Continuous fun p => vp p t l l') (hvm : ∀ t l l', Continuous fun p => vm p t l l') :
    Continuous fun p => std4 hT m (Bfull hT (X0 p) (Xh p) (Xp p) (Xm p)) (Vfull hT (vp p) (vm p)) := by
  have e : (fun p => std4 hT m (Bfull hT (X0 p) (Xh p) (Xp p) (Xm p)) (Vfull hT (vp p) (vm p)))
      = fun p => Dop hT (wilsonSlice (wilsonPlane m (fun i => liftShift (X0 p i))) (kMat (X0 p)))
          (wilsonSlice (wilsonPlane m (fun i => liftShift (Xh p i))) (kMat (Xh p)))
          (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xp p t i))) (kMat (Xp p t)))
          (fun t => wilsonSlice (wilsonPlane m (fun i => liftShift (Xm p t i))) (kMat (Xm p t)))
          (fun t => liftShift (vp p t)) (fun t => liftShift (vm p t)) :=
    funext fun p => (Dop_wilson_eq_std4 hT m (X0 p) (Xh p) (Xp p) (Xm p) (vp p) (vm p)).symm
  rw [e]
  refine continuous_Dop hT _ _ _ _ _ _ ?_ ?_ ?_ ?_ ?_ ?_
  · intro a b
    exact continuous_wilsonSlice (fun p => wilsonPlane m (fun i => liftShift (X0 p i))) (fun p => kMat (X0 p))
      (fun v v' => (continuous_wilsonPlane m (fun p i => liftShift (X0 p i))
        (fun i => continuous_liftShift (fun p => X0 p i) (hX0 i))).matrix_elem v v')
      (continuous_kMat X0 hX0) a b
  · intro a b
    exact continuous_wilsonSlice (fun p => wilsonPlane m (fun i => liftShift (Xh p i))) (fun p => kMat (Xh p))
      (fun v v' => (continuous_wilsonPlane m (fun p i => liftShift (Xh p i))
        (fun i => continuous_liftShift (fun p => Xh p i) (hXh i))).matrix_elem v v')
      (continuous_kMat Xh hXh) a b
  · intro t a b
    exact continuous_wilsonSlice (fun p => wilsonPlane m (fun i => liftShift (Xp p t i)))
      (fun p => kMat (Xp p t))
      (fun v v' => (continuous_wilsonPlane m (fun p i => liftShift (Xp p t i))
        (fun i => continuous_liftShift (fun p => Xp p t i) (hXp t i))).matrix_elem v v')
      (continuous_kMat (fun p => Xp p t) (hXp t)) a b
  · intro t a b
    exact continuous_wilsonSlice (fun p => wilsonPlane m (fun i => liftShift (Xm p t i)))
      (fun p => kMat (Xm p t))
      (fun v v' => (continuous_wilsonPlane m (fun p i => liftShift (Xm p t i))
        (fun i => continuous_liftShift (fun p => Xm p t i) (hXm t i))).matrix_elem v v')
      (continuous_kMat (fun p => Xm p t) (hXm t)) a b
  · intro t v v'
    exact (continuous_liftShift (fun p => vp p t) (hvp t)).matrix_elem v v'
  · intro t v v'
    exact (continuous_liftShift (fun p => vm p t) (hvm t)).matrix_elem v v'

/-- `std4` sees the slice data only at the times `t < 2h` -/
theorem std4_congr (h : ℕ) (m : ℝ) (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hX : ∀ t, t < 2 * h → X t = X' t) (hv : ∀ t, t < 2 * h → v t = v' t) :
    std4 h m X v = std4 h m X' v' := by
  ext a b
  dsimp only [std4]
  rw [hX a.1.val a.1.isLt, hv a.1.val a.1.isLt, hv b.1.val b.1.isLt]

/-- the assembled data of a configuration that is the same on every slice -/
theorem Bfull_const {M : Type*} (h : ℕ) (b : M) : Bfull h b b (fun _ => b) (fun _ => b) = fun _ => b := by
  funext t
  unfold Bfull
  split_ifs <;> rfl

/-- the free time links in the reflected form are `vfree` -/
theorem Vfull_one (h : ℕ) (hpos : 0 < h) :
    Vfull h (fun _ => (1 : Matrix L L ℂ)) (fun _ => (1 : Matrix L L ℂ)) = vfree h := by
  funext t
  unfold Vfull vfree eps sc
  by_cases ht : t < h
  · have : ¬ t + 1 = 2 * h := by omega
    rw [if_pos ht, if_neg this, one_smul]
  · rw [if_neg ht, conjTranspose_one]
    by_cases e : t + 1 = 2 * h
    · rw [if_pos e, if_pos e, if_pos rfl]
    · have : ¬ t + 1 = 0 := by omega
      rw [if_neg e, if_neg e, if_neg this]

end FermionSliceBlock

namespace FermionSU2Config

open Matrix MeasureTheory FermionSliceBlock

/-- the sign of the boundary links as an element of `SU(2)` -/
noncomputable def sgnSU2 (N : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) : SU2 :=
  if (x i).val + 1 = N then -1 else 1

theorem quatMat_one : quatMat 1 = 1 := by
  ext a b
  fin_cases a <;> fin_cases b <;>
    simp [quatMat, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one]

theorem quatMat_neg_one : quatMat (-1) = -1 := by
  ext a b
  fin_cases a <;> fin_cases b <;>
    simp [quatMat, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one]

theorem quatMat_sgnSU2 (N : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) :
    quatMat (sgnSU2 N x i) = usign (C := Fin 2) N x i := by
  unfold sgnSU2 usign
  by_cases e : (x i).val + 1 = N
  · rw [if_pos e, if_pos e, coe_neg_sphere, Metric.unitSphere.coe_one, quatMat_neg_one, neg_one_smul]
  · rw [if_neg e, if_neg e, Metric.unitSphere.coe_one, quatMat_one, one_smul]

/-- the free point of the configuration space -/
noncomputable def freePlane (N : ℕ) : PlaneConf N := (fun xi => sgnSU2 N xi.1 xi.2, fun xi => sgnSU2 N xi.1 xi.2)

noncomputable def freePos (N hT : ℕ) : PosConf N hT := (fun txi => sgnSU2 N txi.2.1 txi.2.2, fun _ => 1)

theorem U0of_free (N : ℕ) : U0of N (freePlane N) = usign N := by
  funext x i
  exact quatMat_sgnSU2 N x i

theorem Uhof_free (N : ℕ) : Uhof N (freePlane N) = usign N := by
  funext x i
  exact quatMat_sgnSU2 N x i

theorem Upof_free (N hT : ℕ) (t : ℕ) (h0 : 0 < t) (ht : t < hT) : Upof N hT (freePos N hT) t = usign N := by
  funext x i
  unfold Upof
  rw [dif_pos ⟨h0, ht⟩]
  exact quatMat_sgnSU2 N x i

theorem U4of_free (N hT : ℕ) (t : ℕ) : U4of N hT (freePos N hT) t = fun _ => 1 := by
  funext x
  unfold U4of
  split_ifs
  · exact (congrArg quatMat Metric.unitSphere.coe_one).trans quatMat_one
  · rfl

end FermionSU2Config

namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config

/-! ### `Z > 0` split into a lemma with the configuration space and the link maps as variables

The direct form (rounds 4–5) timed out in `isDefEq` while elaborating the continuity of the integrand with the
concrete configuration space.  Here the continuity and the free point are handled for an arbitrary compact space
`P`, an arbitrary finite measure that is positive on open sets, and arbitrary link maps; the concrete statement is
an instance. -/

set_option maxHeartbeats 1600000 in
/-- **`Z > 0`, generic form.**  For a compact space `P` of configurations with continuous link maps (spatial links
of the planes `U0`, `Uh`, of the two sides `Up`, `Um`, time links `U4p`, `U4m`), a finite measure positive on open
sets, a continuous positive gauge weight `w`, and a point `p0` where the links are the sign links `usign` (spatial)
and `1` (time): `∫ w · Re det D^{2j} > 0` for every bare mass `m` and every `j`.  At `p0` the operator is the free
operator with spatially periodic and temporally antiperiodic boundary conditions (`usign` cancels the
antiperiodic sign of `torusLink`), invertible for every `m` (`std4_free_torus_isUnit_det`). -/
theorem partition_pos_torus_generic (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ)
    {P : Type*} [TopologicalSpace P] [CompactSpace P] [MeasurableSpace P] [OpensMeasurableSpace P]
    (μ : Measure P) [IsFiniteMeasure μ] [μ.IsOpenPosMeasure]
    (U0 Uh : P → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (Up Um : P → ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (U4p U4m : P → ℕ → (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (c0 : ∀ x i a b, Continuous fun p => U0 p x i a b) (ch : ∀ x i a b, Continuous fun p => Uh p x i a b)
    (cp : ∀ t x i a b, Continuous fun p => Up p t x i a b) (cm : ∀ t x i a b, Continuous fun p => Um p t x i a b)
    (c4p : ∀ t x a b, Continuous fun p => U4p p t x a b) (c4m : ∀ t x a b, Continuous fun p => U4m p t x a b)
    (p0 : P) (f0 : U0 p0 = usign N) (fh : Uh p0 = usign N)
    (fp : ∀ t, 0 < t → t < hT → Up p0 t = usign N) (fm : ∀ t, 0 < t → t < hT → Um p0 t = usign N)
    (f4p : ∀ t, U4p p0 t = fun _ => 1) (f4m : ∀ t, U4m p0 t = fun _ => 1)
    (w : P → ℝ) (hwc : Continuous w) (hw0 : ∀ p, 0 < w p) :
    0 < ∫ p, w p * ((std4 hT m (Bfull hT (torusX N (U0 p)) (torusX N (Uh p))
            (fun t => torusX N (Up p t)) (fun t => torusX N (Um p t)))
          (Vfull hT (fun t => blockDiagonal (U4p p t)) (fun t => blockDiagonal (U4m p t)))).det ^ (2 * j)).re ∂μ := by
  have hD := continuous_std4_assembled (L := Fin 2 × (Fin 3 → Fin N)) (P := P) hT m
      (fun p => torusX N (U0 p)) (fun p => torusX N (Uh p))
      (fun p t => torusX N (Up p t)) (fun p t => torusX N (Um p t))
      (fun p t => blockDiagonal (U4p p t)) (fun p t => blockDiagonal (U4m p t))
      (fun i l l' => continuous_torusX N U0 c0 i l l') (fun i l l' => continuous_torusX N Uh ch i l l')
      (fun t i l l' => continuous_torusX N (fun p => Up p t) (cp t) i l l')
      (fun t i l l' => continuous_torusX N (fun p => Um p t) (cm t) i l l')
      (fun t l l' => continuous_blockDiagonal_elem (fun p => U4p p t) (c4p t) l l')
      (fun t l l' => continuous_blockDiagonal_elem (fun p => U4m p t) (c4m t) l l')
  have hv := hwc.mul (FermionDetWeight.det_pow_re_continuous _ hD (2 * j))
  -- the free point
  have hB : ∀ t, t < 2 * hT → Bfull hT (torusX N (U0 p0)) (torusX N (Uh p0))
      (fun t => torusX N (Up p0 t)) (fun t => torusX N (Um p0 t)) t = torusX N (usign N) := by
    intro t ht2
    unfold Bfull
    rw [f0, fh]
    split_ifs with h0 hh hlt
    · rfl
    · rfl
    · dsimp only
      rw [fp t (Nat.pos_of_ne_zero h0) hlt]
    · unfold th
      dsimp only
      have h1 : 0 < 2 * hT - t := by omega
      have h2 : 2 * hT - t < hT := by omega
      rw [if_neg h0, fm _ h1 h2]
  have hV : Vfull hT (fun t => blockDiagonal (U4p p0 t)) (fun t => blockDiagonal (U4m p0 t)) = vfree hT := by
    simp only [f4p, f4m]
    rw [show (blockDiagonal fun _ : Fin 3 → Fin N => (1 : Matrix (Fin 2) (Fin 2) ℂ))
        = (1 : Matrix (Fin 2 × (Fin 3 → Fin N)) (Fin 2 × (Fin 3 → Fin N)) ℂ) from blockDiagonal_one]
    exact Vfull_one hT hpos
  have hdet : IsUnit (std4 hT m (Bfull hT (torusX N (U0 p0)) (torusX N (Uh p0))
      (fun t => torusX N (Up p0 t)) (fun t => torusX N (Um p0 t)))
      (Vfull hT (fun t => blockDiagonal (U4p p0 t)) (fun t => blockDiagonal (U4m p0 t)))).det := by
    rw [std4_congr hT m _ (fun _ => torusX N (usign N)) _ (vfree hT) hB (fun t _ => congrFun hV t)]
    exact std4_free_torus_isUnit_det N hT m
  refine hv.integral_pos_of_hasCompactSupport_nonneg_nonzero (HasCompactSupport.of_compactSpace _)
    (fun p => mul_nonneg (hw0 p).le (wilson_weight_nonneg_torus N hT j m _ _ _ _ _ _).1) (x := p0) ?_
  refine mul_ne_zero (hw0 p0).ne' ?_
  have him := (wilson_weight_nonneg_torus N hT j m (U0 p0) (Uh p0) (Up p0) (Um p0) (U4p p0) (U4m p0)).2
  have hne : (std4 hT m (Bfull hT (torusX N (U0 p0)) (torusX N (Uh p0))
      (fun t => torusX N (Up p0 t)) (fun t => torusX N (Um p0 t)))
      (Vfull hT (fun t => blockDiagonal (U4p p0 t)) (fun t => blockDiagonal (U4m p0 t)))).det ^ (2 * j) ≠ 0 :=
    pow_ne_zero _ hdet.ne_zero
  intro hre
  exact hne (Complex.ext hre him)

set_option maxHeartbeats 1600000 in
/-- **`Z > 0`** for the measure `w · Re det D^{2j} · Haar` on the `SU(2)` link configurations of the torus
(`PlaneConf N × PosConf N h × PosConf N h`, product of the normalised Haar measures of the product groups), for
every bare mass `m`, every `j`, and every continuous positive gauge weight `w` (abstract here; the Wilson weight
`exp(−β S_W)` is one).  The point used is `(freePlane, freePos, freePos)`: spatial boundary links `−1 ∈ SU(2)`, all
other links `1` (spatially periodic, temporally antiperiodic free operator). -/
theorem partition_pos_wilson_SU2 (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m : ℝ)
    (w : PlaneConf N × (PosConf N hT × PosConf N hT) → ℝ) (hwc : Continuous w) (hw0 : ∀ p, 0 < w p) :
    0 < ∫ p : PlaneConf N × (PosConf N hT × PosConf N hT), w p *
        ((std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
            (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det
            ^ (2 * j)).re
        ∂((Measure.haarMeasure ⊤ : Measure (PlaneConf N)).prod
          ((Measure.haarMeasure ⊤ : Measure (PosConf N hT)).prod (Measure.haarMeasure ⊤))) := by
  have c0 : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1 x i a b :=
    fun x i a b => (continuous_U0of N x i a b).comp continuous_fst
  have ch : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => Uhof N p.1 x i a b :=
    fun x i a b => (continuous_Uhof N x i a b).comp continuous_fst
  have cp : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.1 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_fst.comp continuous_snd)
  have cm : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.2 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_snd.comp continuous_snd)
  have c4p : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.1 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_fst.comp continuous_snd)
  have c4m : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.2 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_snd.comp continuous_snd)
  -- the product instance is not found automatically for the triple product 
  haveI i1 : OpensMeasurableSpace (PosConf N hT × PosConf N hT) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  haveI i2 : OpensMeasurableSpace (PlaneConf N × (PosConf N hT × PosConf N hT)) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  exact partition_pos_torus_generic N hT hpos j m
    ((Measure.haarMeasure ⊤ : Measure (PlaneConf N)).prod
      ((Measure.haarMeasure ⊤ : Measure (PosConf N hT)).prod (Measure.haarMeasure ⊤)))
    (fun p => U0of N p.1) (fun p => Uhof N p.1) (fun p => Upof N hT p.2.1) (fun p => Upof N hT p.2.2)
    (fun p => U4of N hT p.2.1) (fun p => U4of N hT p.2.2) c0 ch cp cm c4p c4m
    (freePlane N, (freePos N hT, freePos N hT)) (U0of_free N) (Uhof_free N)
    (fun t h0 ht => Upof_free N hT t h0 ht) (fun t h0 ht => Upof_free N hT t h0 ht)
    (fun t => U4of_free N hT t) (fun t => U4of_free N hT t) w hwc hw0

end FermionSliceReflection


-- ===== part : HopUnitary.part.lean =====

/-! # The hops of the assembled `SU(2)` configuration are unitary 

L-10 (i). `hopSp` (block diagonal in time) and `hopT` (the time
shift `t ↦ sc t` with links) are unitary when every link matrix is unitary.  For the assembled data of a point of
`PlaneConf × PosConf × PosConf` (spatial hops `torusX` of `quatMat` links; time links `blockDiagonal` of `quatMat`
links, the reflected ones as `eps • ᴴ`) all four hops `hop4 μ` are unitary.  This discharges the hypothesis `hU` of
`massPart_eq_sos` and `std4_isUnit_det_of_pos` on the concrete configuration space. -/
namespace FermionSliceBlock

open Matrix

theorem submatrix_unitary {α β : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]
    (A : Matrix β β ℂ) (hA : Aᴴ * A = 1) (e f : α ≃ β) :
    (A.submatrix e f)ᴴ * A.submatrix e f = 1 := by
  rw [conjTranspose_submatrix, Matrix.submatrix_mul_equiv Aᴴ A f e f, hA, submatrix_one_equiv]

theorem blockDiagonal_unitary {T C : Type*} [Fintype T] [DecidableEq T] [Fintype C] [DecidableEq C]
    (V : T → Matrix C C ℂ) (hV : ∀ t, (V t)ᴴ * V t = 1) : (blockDiagonal V)ᴴ * blockDiagonal V = 1 := by
  rw [blockDiagonal_conjTranspose, ← blockDiagonal_mul]
  have e : (fun k => (V k)ᴴ * V k) = (1 : T → Matrix C C ℂ) := funext hV
  rw [e, blockDiagonal_one]

theorem sc_lt (h k : ℕ) (hk : k < 2 * h) : sc h k < 2 * h := by
  unfold sc
  split_ifs <;> omega

/-- the time shift `t ↦ sc t` on `Fin (2h)` -/
def scFin (h : ℕ) (t : Fin (2 * h)) : Fin (2 * h) := ⟨sc h t.val, sc_lt h t.val t.isLt⟩

theorem scFin_injective (h : ℕ) : Function.Injective (scFin h) := by
  intro a b hab
  have e : sc h a.val = sc h b.val := congrArg Fin.val hab
  have ha := a.isLt
  have hb := b.isLt
  apply Fin.ext
  unfold sc at e
  split_ifs at e <;> omega

/-- the time shift as a permutation of `Fin (2h)` -/
noncomputable def scEquiv (h : ℕ) : Fin (2 * h) ≃ Fin (2 * h) :=
  Equiv.ofBijective (scFin h) (Finite.injective_iff_bijective.mp (scFin_injective h))

section HopUnitary

variable {L : Type*} [Fintype L] [DecidableEq L]

theorem hopSp_eq_submatrix (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (i : Fin 3) :
    hopSp h X i = (blockDiagonal fun t : Fin (2 * h) => X t.val i).submatrix
      (Equiv.prodComm (Fin (2 * h)) L) (Equiv.prodComm (Fin (2 * h)) L) := by
  ext ⟨t, l⟩ ⟨t', l'⟩
  show (if t'.val = t.val then X t.val i l l' else 0)
    = blockDiagonal (fun t : Fin (2 * h) => X t.val i) (l, t) (l', t')
  rw [blockDiagonal_apply]
  by_cases e : t = t'
  · subst e
    rw [if_pos rfl, if_pos rfl]
  · have e' : ¬ t'.val = t.val := fun h' => e (Fin.ext h'.symm)
    rw [if_neg e', if_neg e]

theorem hopT_eq_submatrix (h : ℕ) (v : ℕ → Matrix L L ℂ) :
    hopT h v = (blockDiagonal fun t : Fin (2 * h) => v t.val).submatrix
      (Equiv.prodComm (Fin (2 * h)) L)
      ((Equiv.prodCongr (scEquiv h).symm (Equiv.refl L)).trans (Equiv.prodComm (Fin (2 * h)) L)) := by
  ext ⟨t, l⟩ ⟨t', l'⟩
  show (if t'.val = sc h t.val then v t.val l l' else 0)
    = blockDiagonal (fun t : Fin (2 * h) => v t.val) (l, t) (l', (scEquiv h).symm t')
  rw [blockDiagonal_apply]
  have key : (t'.val = sc h t.val) ↔ t = (scEquiv h).symm t' := by
    rw [Equiv.eq_symm_apply]
    constructor
    · intro e
      exact Fin.ext e.symm
    · intro e
      exact (congrArg Fin.val e).symm
  by_cases e : t'.val = sc h t.val
  · rw [if_pos e, if_pos (key.mp e)]
  · rw [if_neg e, if_neg (fun e2 => e (key.mpr e2))]

/-- the spatial hop is unitary when the link matrices are -/
theorem hopSp_unitary (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (hX : ∀ t i, (X t i)ᴴ * X t i = 1) (i : Fin 3) :
    (hopSp h X i)ᴴ * hopSp h X i = 1 := by
  rw [hopSp_eq_submatrix]
  exact submatrix_unitary _ (blockDiagonal_unitary _ fun t => hX t.val i) _ _

/-- the time hop is unitary when the link matrices are -/
theorem hopT_unitary (h : ℕ) (v : ℕ → Matrix L L ℂ) (hv : ∀ t, (v t)ᴴ * v t = 1) :
    (hopT h v)ᴴ * hopT h v = 1 := by
  rw [hopT_eq_submatrix]
  exact submatrix_unitary _ (blockDiagonal_unitary _ fun t => hv t.val) _ _

theorem hop4_unitary (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ)
    (hX : ∀ t i, (X t i)ᴴ * X t i = 1) (hv : ∀ t, (v t)ᴴ * v t = 1) (μ : Fin 4) :
    (hop4 h X v μ)ᴴ * hop4 h X v μ = 1 := by
  unfold hop4
  split_ifs with hμ
  · exact hopSp_unitary h X hX _
  · exact hopT_unitary h v hv

end HopUnitary

end FermionSliceBlock

namespace FermionSU2Config

open Matrix FermionSliceBlock

/-- the spatial hops of the assembled `SU(2)` configuration are unitary (all times) -/
theorem Bfull_SU2_unitary (N : ℕ) [NeZero N] (hT : ℕ) (p : PlaneConf N × (PosConf N hT × PosConf N hT))
    (t : ℕ) (i : Fin 3) :
    (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)) t i)ᴴ
      * Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)) t i = 1 := by
  unfold Bfull
  split_ifs
  · exact torusX_unitary N _ (U0of_unitary N p.1) i
  · exact torusX_unitary N _ (Uhof_unitary N p.1) i
  · exact torusX_unitary N _ (Upof_unitary N hT p.2.1 t) i
  · exact torusX_unitary N _ (Upof_unitary N hT p.2.2 _) i

/-- the time links of the assembled `SU(2)` configuration are unitary (all times; the reflected ones are
`eps • ᴴ` of unitary matrices) -/
theorem Vfull_SU2_unitary (N : ℕ) [NeZero N] (hT : ℕ) (p : PlaneConf N × (PosConf N hT × PosConf N hT)) (t : ℕ) :
    (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)) t)ᴴ
      * Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)) t
      = 1 := by
  unfold Vfull
  split_ifs
  · exact blockDiagonal_unitary _ (U4of_unitary N hT p.2.1 t)
  · dsimp only
    have hB := blockDiagonal_unitary _ (U4of_unitary N hT p.2.2 (th hT (sc hT t)))
    have hB' : blockDiagonal (U4of N hT p.2.2 (th hT (sc hT t)))
        * (blockDiagonal (U4of N hT p.2.2 (th hT (sc hT t))))ᴴ = 1 := by
      first
        | exact mul_eq_one_comm.mp hB
        | exact (Matrix.mul_eq_one_comm_of_equiv (Equiv.refl _)).mp hB
    have he : star (eps (sc hT t)) * eps (sc hT t) = 1 := by
      unfold eps
      split_ifs <;> simp
    rw [conjTranspose_smul, conjTranspose_conjTranspose, Matrix.smul_mul, Matrix.mul_smul, hB', smul_smul, he,
      one_smul]

/-- **all four hops of the assembled `SU(2)` configuration are unitary** (hypothesis `hU` of `massPart_eq_sos`
and `std4_isUnit_det_of_pos`, discharged on `PlaneConf × PosConf × PosConf`) -/
theorem hop4_unitary_SU2 (N : ℕ) [NeZero N] (hT : ℕ) (p : PlaneConf N × (PosConf N hT × PosConf N hT))
    (μ : Fin 4) :
    (hop4 hT (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
      (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t))) μ)ᴴ
    * hop4 hT (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
      (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t))) μ = 1 :=
  hop4_unitary hT _ _ (Bfull_SU2_unitary N hT p) (Vfull_SU2_unitary N hT p) μ

end FermionSU2Config

-- ===== part : HopUnitaryCor.part.lean =====

/-! # `massPart_eq_sos` and `std4_isUnit_det_of_pos` on the concrete `SU(2)` configuration space 

L-10 (i). The hypothesis `hU` (unitary hops) is discharged by
`hop4_unitary_SU2`.  Concrete: operator, links (`quatMat` of unit quaternions), configuration space. -/
namespace FermionSU2Config

open Matrix FermionSliceBlock

/-- **`M = m + ½ Σ_μ (1 − H_μ)ᴴ (1 − H_μ)` at every point of `PlaneConf × PosConf × PosConf`** -/
theorem massPart_eq_sos_SU2 (N : ℕ) [NeZero N] (hT : ℕ) (m : ℝ)
    (p : PlaneConf N × (PosConf N hT × PosConf N hT)) :
    massPart hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
      (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))
    = (m : ℂ) • (1 : Matrix (Fin (2 * hT) × (Fin 2 × (Fin 3 → Fin N))) (Fin (2 * hT) × (Fin 2 × (Fin 3 → Fin N))) ℂ)
      + (1 / 2 : ℂ) • ∑ μ, (1 - hop4 hT (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
            (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t))) μ)ᴴ
        * (1 - hop4 hT (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
            (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
          (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t))) μ) :=
  massPart_eq_sos hT m _ _ (hop4_unitary_SU2 N hT p)

/-- **`m > 0`: `det D ≠ 0` at every point of `PlaneConf × PosConf × PosConf`** (every `SU(2)` configuration of
the torus; from the Hermitian part) -/
theorem std4_isUnit_det_of_pos_SU2 (N : ℕ) [NeZero N] (hT : ℕ) (m : ℝ) (hm : 0 < m)
    (p : PlaneConf N × (PosConf N hT × PosConf N hT)) :
    IsUnit (std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
      (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det :=
  std4_isUnit_det_of_pos hT m hm _ _ (hop4_unitary_SU2 N hT p)

end FermionSU2Config


-- ===== part : HaarLinks.part.lean =====

/-! # The configuration measure as the product of the link Haar measures; the split map `ι` 


* `haarTop_prod_eq`, `haar_pi_eq`, `haar_planeConf_eq`, `haar_posConf_eq`: the normalised Haar measure of the
  product groups `PlaneConf N`, `PosConf N h` is the product of the normalised Haar measures of the links
  (uniqueness of the Haar probability measure; as `HaarPi.haarProb_pi_eq`).
* `haarTop_inv_preserving`: inversion preserves the normalised Haar measure of a compact group (as
  `CompactHaar.inv_eq`, copied).
* `link_split_preserving`: for **any** bijection `e : Λ ≃ F ⊕ (P ⊕ P)` of a finite link set onto
  "plane ⊕ (positive ⊕ negative)" and any measure-preserving value maps `σ` on the negative side (inversion on the
  reflected time links), the split map `ω ↦ (ω|F, (ω|P₊, σ(ω|P₋)))` carries `Π_Λ Haar` to `Π_F Haar ⊗ (Π_P Haar ⊗
  Π_P Haar)`. The concrete `e` of the torus `(Fin N)³ × (time circle 2h)` is paper (counted and
  checked numerically). -/
namespace FermionSU2Config

open MeasureTheory Measure

section Generic

variable (G : Type*) [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [MeasurableSpace G] [BorelSpace G]

theorem haarTop_isProb : IsProbabilityMeasure (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)) := by
  refine ⟨?_⟩
  have h : haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)
      ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 := haarMeasure_self
  rwa [TopologicalSpace.PositiveCompacts.coe_top] at h

/-- inversion preserves the normalised Haar measure of a compact group (copied from `CompactHaar.inv_eq`:
right invariance from the total mass, then uniqueness) -/
theorem haarTop_inv_preserving :
    MeasurePreserving (fun g : G => g⁻¹) (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G))
      (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)) := by
  haveI := haarTop_isProb G
  set μ := haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G) with hμ
  have hright : ∀ g : G, map (· * g) μ = μ := by
    intro g
    have hc := isMulLeftInvariant_eq_smul_of_regular (map (· * g) μ) μ
    have h1 : (map (· * g) μ) Set.univ = 1 := by
      rw [map_apply (continuous_mul_right g).measurable MeasurableSet.univ, Set.preimage_univ, measure_univ]
    rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
    rw [hc, h1, one_smul]
  haveI : IsMulRightInvariant μ := ⟨hright⟩
  have hinv : μ.inv = μ := by
    have hc := isMulLeftInvariant_eq_smul_of_regular μ.inv μ
    have h1 : μ.inv Set.univ = 1 := by
      rw [inv_apply, Set.inv_univ, measure_univ]
    rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
    rw [hc, h1, one_smul]
  haveI : IsInvInvariant μ := ⟨hinv⟩
  exact measurePreserving_inv μ

variable [SecondCountableTopology G]

/-- **the normalised Haar measure of `Λ → G` is the product of the link Haar measures** -/
theorem haar_pi_eq (Λ : Type*) [Fintype Λ] :
    (haarMeasure ⊤ : Measure (Λ → G)) = Measure.pi (fun _ : Λ => (haarMeasure ⊤ : Measure G)) := by
  haveI := haarTop_isProb G
  haveI := haarTop_isProb (Λ → G)
  haveI : MeasurableMul G := inferInstance
  haveI : (Measure.pi (fun _ : Λ => (haarMeasure ⊤ : Measure G))).IsHaarMeasure :=
    Measure.pi.isHaarMeasure _
  haveI : IsProbabilityMeasure (Measure.pi (fun _ : Λ => (haarMeasure ⊤ : Measure G))) := inferInstance
  exact isHaarMeasure_eq_of_isProbabilityMeasure _ _

/-- **the normalised Haar measure of a product of two compact groups is the product measure** -/
theorem haarTop_prod_eq (H : Type*) [Group H] [TopologicalSpace H] [IsTopologicalGroup H] [CompactSpace H]
    [MeasurableSpace H] [BorelSpace H] [SecondCountableTopology H] :
    (haarMeasure ⊤ : Measure (G × H)) = (haarMeasure ⊤ : Measure G).prod (haarMeasure ⊤ : Measure H) := by
  haveI := haarTop_isProb G
  haveI := haarTop_isProb H
  haveI := haarTop_isProb (G × H)
  haveI : MeasurableMul G := inferInstance
  haveI : MeasurableMul H := inferInstance
  haveI : ((haarMeasure ⊤ : Measure G).prod (haarMeasure ⊤ : Measure H)).IsHaarMeasure := inferInstance
  haveI : IsProbabilityMeasure ((haarMeasure ⊤ : Measure G).prod (haarMeasure ⊤ : Measure H)) := inferInstance
  exact isHaarMeasure_eq_of_isProbabilityMeasure _ _

/-- **the split map `ι`** (any bijection of the links onto plane ⊕ (positive ⊕ negative), any measure-preserving
value maps on the negative side) carries the product of the link Haar measures to the product form of the
reflection-positivity statements -/
theorem link_split_preserving {Λ F P : Type*} [Fintype Λ] [Fintype F] [Fintype P]
    (e : Λ ≃ F ⊕ (P ⊕ P)) (σ : P → G → G)
    (hσ : ∀ p, MeasurePreserving (σ p) (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G))
      (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G))) :
    MeasurePreserving
      (fun ω : Λ → G => ((fun f => ω (e.symm (Sum.inl f))),
        ((fun p => ω (e.symm (Sum.inr (Sum.inl p)))), (fun p => σ p (ω (e.symm (Sum.inr (Sum.inr p))))))))
      (Measure.pi fun _ : Λ => (haarMeasure ⊤ : Measure G))
      ((Measure.pi fun _ : F => (haarMeasure ⊤ : Measure G)).prod
        ((Measure.pi fun _ : P => (haarMeasure ⊤ : Measure G)).prod
          (Measure.pi fun _ : P => (haarMeasure ⊤ : Measure G)))) := by
  haveI := haarTop_isProb G
  have h1 := measurePreserving_arrowCongr' (fun _ : Λ => (haarMeasure ⊤ : Measure G))
    (fun _ : F ⊕ (P ⊕ P) => (haarMeasure ⊤ : Measure G)) e (MeasurableEquiv.refl G)
    (fun _ => MeasurePreserving.id _)
  have h2 := measurePreserving_sumPiEquivProdPi (X := fun _ : F ⊕ (P ⊕ P) => G)
    (fun _ => (haarMeasure ⊤ : Measure G))
  have h3 := measurePreserving_sumPiEquivProdPi (X := fun _ : P ⊕ P => G)
    (fun _ => (haarMeasure ⊤ : Measure G))
  have h4 := measurePreserving_pi (fun _ : P => (haarMeasure ⊤ : Measure G))
    (fun _ : P => (haarMeasure ⊤ : Measure G)) hσ
  have h34 := ((MeasurePreserving.id (Measure.pi fun _ : P => (haarMeasure ⊤ : Measure G))).prod h4).comp h3
  have hall := ((MeasurePreserving.id (Measure.pi fun _ : F => (haarMeasure ⊤ : Measure G))).prod h34).comp
    (h2.comp h1)
  exact hall

end Generic

/-- the configuration measures of the reflection-positivity statements are products of link Haar measures -/
theorem haar_planeConf_eq (N : ℕ) :
    (haarMeasure ⊤ : Measure (PlaneConf N))
      = (Measure.pi fun _ : SpLinks N => (haarMeasure ⊤ : Measure SU2)).prod
          (Measure.pi fun _ : SpLinks N => (haarMeasure ⊤ : Measure SU2)) := by
  rw [haarTop_prod_eq, haar_pi_eq]

theorem haar_posConf_eq (N hT : ℕ) :
    (haarMeasure ⊤ : Measure (PosConf N hT))
      = (Measure.pi fun _ : Fin (hT - 1) × SpLinks N => (haarMeasure ⊤ : Measure SU2)).prod
          (Measure.pi fun _ : Fin hT × (Fin 3 → Fin N) => (haarMeasure ⊤ : Measure SU2)) := by
  rw [haarTop_prod_eq, haar_pi_eq, haar_pi_eq]

/-- inversion of a link preserves the `SU(2)` Haar measure (the reflected time links) -/
theorem su2_inv_preserving :
    MeasurePreserving (fun g : SU2 => g⁻¹) (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2))
      (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2)) :=
  haarTop_inv_preserving SU2

end FermionSU2Config


-- ===== part : HaarLinks2.part.lean =====

/-! # The split map onto the concrete configuration spaces 

`configSplit e σ`: for a bijection `e : Λ ≃ (SpLinks ⊕ SpLinks) ⊕ (PosIdx ⊕ PosIdx)` of a finite link set (plane `t = 0`,
plane `t = h`; positive side, negative side identified with the positive side by the reflection) and value maps
`σ` on the negative side, the configuration `(c, (a₊, a₋)) ∈ PlaneConf × (PosConf × PosConf)`.  It carries
`Π_Λ Haar` to the measure of `site_reflection_positive_wilson_SU2_haar` / `partition_pos_wilson_SU2` when every `σ p`
preserves Haar (inversion on the reflected time links: `su2_inv_preserving`).  The concrete `e` of the torus
 is paper. -/
namespace FermionSU2Config

open MeasureTheory Measure

/-- index set of `PosConf`: spatial links of the slices `0 < t < h` and time links `t → t+1`, `t < h` -/
abbrev PosIdx (N hT : ℕ) : Type := (Fin (hT - 1) × SpLinks N) ⊕ (Fin hT × (Fin 3 → Fin N))

noncomputable def configSplit {N hT : ℕ} {Λ : Type*} (e : Λ ≃ (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT))
    (σ : PosIdx N hT → SU2 → SU2) (ω : Λ → SU2) : PlaneConf N × (PosConf N hT × PosConf N hT) :=
  (MeasurableEquiv.sumPiEquivProdPi (fun _ => SU2) (fun f => ω (e.symm (Sum.inl f))),
    (MeasurableEquiv.sumPiEquivProdPi (fun _ => SU2) (fun p => ω (e.symm (Sum.inr (Sum.inl p)))),
     MeasurableEquiv.sumPiEquivProdPi (fun _ => SU2) (fun p => σ p (ω (e.symm (Sum.inr (Sum.inr p)))))))

/-- **`configSplit` carries `Π_Λ Haar` to `Haar(PlaneConf) ⊗ (Haar(PosConf) ⊗ Haar(PosConf))`** -/
theorem configSplit_preserving {N hT : ℕ} {Λ : Type*} [Fintype Λ]
    (e : Λ ≃ (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT)) (σ : PosIdx N hT → SU2 → SU2)
    (hσ : ∀ p, MeasurePreserving (σ p) (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2))
      (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2))) :
    MeasurePreserving (configSplit e σ) (Measure.pi fun _ : Λ => (haarMeasure ⊤ : Measure SU2))
      ((haarMeasure ⊤ : Measure (PlaneConf N)).prod
        ((haarMeasure ⊤ : Measure (PosConf N hT)).prod (haarMeasure ⊤ : Measure (PosConf N hT)))) := by
  haveI := haarTop_isProb SU2
  rw [haar_planeConf_eq, haar_posConf_eq]
  have h := link_split_preserving SU2 e σ hσ
  have hF := measurePreserving_sumPiEquivProdPi (X := fun _ : SpLinks N ⊕ SpLinks N => SU2)
    (fun _ => (haarMeasure ⊤ : Measure SU2))
  have hP := measurePreserving_sumPiEquivProdPi (X := fun _ : PosIdx N hT => SU2)
    (fun _ => (haarMeasure ⊤ : Measure SU2))
  exact (hF.prod (hP.prod hP)).comp h

end FermionSU2Config


-- ===== part : LinkEquiv.part.lean =====

/-! # The concrete bijection `e` of the links of the torus 

Paper side: (the table of `ι`), (counted: 64/64, 128/128, 192/192, 432/432).
Physical links of `(time circle 2h) × (Fin N)³`: `(t, x, μ)`, `μ < 3` spatial `x → x + e_μ` on the slice `t`,
`μ = 3` the time link `t → t + 1` at `x`.  `linkClass` sends them to plane `t = 0` / plane `t = h` / positive side /
negative side (reflected index `2h − t − 1` for spatial, `2h − 1 − t` for time links); it is injective and the
cardinalities agree, so it is a bijection (`linkEquiv`). -/
namespace FermionSU2Config

/-- physical links of the torus -/
abbrev PhysLink (N hT : ℕ) : Type := Fin (2 * hT) × (Fin 3 → Fin N) × Fin 4

def linkClass {N hT : ℕ} (l : PhysLink N hT) :
    (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT) :=
  if hμ : l.2.2.val < 3 then
    if h0 : l.1.val = 0 then Sum.inl (Sum.inl (l.2.1, ⟨l.2.2.val, hμ⟩))
    else if hh : l.1.val = hT then Sum.inl (Sum.inr (l.2.1, ⟨l.2.2.val, hμ⟩))
    else if ht : l.1.val < hT then
      Sum.inr (Sum.inl (Sum.inl (⟨l.1.val - 1, by omega⟩, (l.2.1, ⟨l.2.2.val, hμ⟩))))
    else Sum.inr (Sum.inr (Sum.inl (⟨2 * hT - l.1.val - 1, by have := l.1.isLt; omega⟩,
      (l.2.1, ⟨l.2.2.val, hμ⟩))))
  else
    if ht : l.1.val < hT then Sum.inr (Sum.inl (Sum.inr (⟨l.1.val, ht⟩, l.2.1)))
    else Sum.inr (Sum.inr (Sum.inr (⟨2 * hT - 1 - l.1.val, by have := l.1.isLt; omega⟩, l.2.1)))

theorem linkClass_injective (N hT : ℕ) : Function.Injective (linkClass (N := N) (hT := hT)) := by
  rintro ⟨t, x, μ⟩ ⟨t', x', μ'⟩ h
  have ht := t.isLt
  have ht' := t'.isLt
  have hμ4 := μ.isLt
  have hμ4' := μ'.isLt
  unfold linkClass at h
  dsimp only at h
  split_ifs at h <;>
    simp only [Sum.inl.injEq, Sum.inr.injEq, Prod.mk.injEq, Fin.mk.injEq, reduceCtorEq] at h <;>
    (simp only [Prod.ext_iff, Fin.ext_iff]
     refine ⟨?_, ?_, ?_⟩ <;>
       first
         | omega
         | exact h.1
         | exact h.2.1
         | exact h.1.2
         | exact h.2
         | exact h
         | simp_all
         | (simp_all; omega))

theorem card_physLink (N hT : ℕ) (hpos : 0 < hT) :
    Fintype.card (PhysLink N hT) = Fintype.card ((SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT)) := by
  simp only [Fintype.card_sum, Fintype.card_prod, Fintype.card_fin, Fintype.card_fun]
  obtain ⟨k, rfl⟩ : ∃ k, hT = k + 1 := ⟨hT - 1, by omega⟩
  simp only [Nat.add_sub_cancel]
  ring

/-- **the concrete bijection of the links of the torus onto plane ⊕ (positive ⊕ negative)** -/
noncomputable def linkEquiv (N hT : ℕ) (hpos : 0 < hT) :
    PhysLink N hT ≃ (SpLinks N ⊕ SpLinks N) ⊕ (PosIdx N hT ⊕ PosIdx N hT) :=
  Equiv.ofBijective linkClass ((Fintype.bijective_iff_injective_and_card _).mpr
    ⟨linkClass_injective N hT, card_physLink N hT hpos⟩)

/-- the time links of the negative side are inverted -/
noncomputable def sigInv (N hT : ℕ) : PosIdx N hT → SU2 → SU2
  | Sum.inl _ => id
  | Sum.inr _ => fun g => g⁻¹

/-- **`Π_{physical links} Haar` is carried to the measure of the reflection-positivity and `Z > 0` statements** -/
theorem phys_split_preserving (N hT : ℕ) (hpos : 0 < hT) :
    MeasureTheory.MeasurePreserving (configSplit (linkEquiv N hT hpos) (sigInv N hT))
      (MeasureTheory.Measure.pi fun _ : PhysLink N hT => (MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure SU2))
      ((MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure (PlaneConf N)).prod
        ((MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure (PosConf N hT)).prod
          (MeasureTheory.Measure.haarMeasure ⊤ : MeasureTheory.Measure (PosConf N hT)))) := by
  refine configSplit_preserving _ _ fun p => ?_
  cases p with
  | inl _ => exact MeasureTheory.MeasurePreserving.id _
  | inr _ => exact su2_inv_preserving

end FermionSU2Config


-- ===== part : PhysRP.part.lean =====

/-! # Site reflection positivity on the physical link configurations 

Paper side: The reflection-positivity statement `site_reflection_positive_wilson_SU2_haar` transported
to `Π_{physical links} Haar` through `configSplit (linkEquiv) (sigInv)` (`phys_split_preserving`).  Concrete: the
measure (product of the link Haar measures of the torus), the split map, the operator.  Abstract: the gauge weight
`k h h` and the observable `φ`.  Not in Lean: that the operator written directly in the physical links equals `std4`
of the split configuration (checked numerically). -/
namespace FermionSliceReflection

open Matrix MeasureTheory FermionSliceBlock FermionSU2Config

/-- continuity of the fermion weight, generic configuration space -/
theorem continuous_det_torus_generic (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ) {P : Type*} [TopologicalSpace P]
    (U0 Uh : P → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (Up Um : P → ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (U4p U4m : P → ℕ → (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (c0 : ∀ x i a b, Continuous fun p => U0 p x i a b) (ch : ∀ x i a b, Continuous fun p => Uh p x i a b)
    (cp : ∀ t x i a b, Continuous fun p => Up p t x i a b) (cm : ∀ t x i a b, Continuous fun p => Um p t x i a b)
    (c4p : ∀ t x a b, Continuous fun p => U4p p t x a b) (c4m : ∀ t x a b, Continuous fun p => U4m p t x a b) :
    Continuous fun p => ((std4 hT m (Bfull hT (torusX N (U0 p)) (torusX N (Uh p))
            (fun t => torusX N (Up p t)) (fun t => torusX N (Um p t)))
          (Vfull hT (fun t => blockDiagonal (U4p p t)) (fun t => blockDiagonal (U4m p t)))).det ^ (2 * j)).re := by
  have hD := continuous_std4_assembled (L := Fin 2 × (Fin 3 → Fin N)) (P := P) hT m
      (fun p => torusX N (U0 p)) (fun p => torusX N (Uh p))
      (fun p t => torusX N (Up p t)) (fun p t => torusX N (Um p t))
      (fun p t => blockDiagonal (U4p p t)) (fun p t => blockDiagonal (U4m p t))
      (fun i l l' => continuous_torusX N U0 c0 i l l') (fun i l l' => continuous_torusX N Uh ch i l l')
      (fun t i l l' => continuous_torusX N (fun p => Up p t) (cp t) i l l')
      (fun t i l l' => continuous_torusX N (fun p => Um p t) (cm t) i l l')
      (fun t l l' => continuous_blockDiagonal_elem (fun p => U4p p t) (c4p t) l l')
      (fun t l l' => continuous_blockDiagonal_elem (fun p => U4m p t) (c4m t) l l')
  exact FermionDetWeight.det_pow_re_continuous _ hD (2 * j)

/-- the integrand of the reflection-positivity statement -/
noncomputable def wilsonIntegrand (N : ℕ) [NeZero N] (hT j : ℕ) (m : ℝ) (k : PlaneConf N → ℝ)
    (hw φ : PlaneConf N × PosConf N hT → ℝ) (p : PlaneConf N × (PosConf N hT × PosConf N hT)) : ℝ :=
  φ (p.1, p.2.1) * φ (p.1, p.2.2) * (k p.1 * hw (p.1, p.2.1) * hw (p.1, p.2.2)) *
    ((std4 hT m (Bfull hT (torusX N (U0of N p.1)) (torusX N (Uhof N p.1))
        (fun t => torusX N (Upof N hT p.2.1 t)) (fun t => torusX N (Upof N hT p.2.2 t)))
      (Vfull hT (fun t => blockDiagonal (U4of N hT p.2.1 t)) (fun t => blockDiagonal (U4of N hT p.2.2 t)))).det
        ^ (2 * j)).re

set_option maxHeartbeats 1600000 in
/-- **Site reflection positivity of `det D^{2j}` with `SU(2)` links, on `Π_{physical links of the torus} Haar`.** -/
theorem site_reflection_positive_phys (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT)
    (j : ℕ) (m : ℝ) (hm : -1 < m)
    (k : PlaneConf N → ℝ) (hw φ : PlaneConf N × PosConf N hT → ℝ)
    (hk : Measurable k) (hhw : Measurable hw) (hφ : Measurable φ)
    (Ck Ch Cφ : ℝ) (bk : ∀ c, |k c| ≤ Ck) (bhw : ∀ p, |hw p| ≤ Ch) (bφ : ∀ p, |φ p| ≤ Cφ)
    (hk0 : ∀ c, 0 ≤ k c) :
    0 ≤ ∫ ω : PhysLink N hT → SU2,
        wilsonIntegrand N hT j m k hw φ (configSplit (linkEquiv N hT hpos) (sigInv N hT) ω)
        ∂(Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have hmp := phys_split_preserving N hT hpos
  haveI i1 : OpensMeasurableSpace (PosConf N hT × PosConf N hT) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  haveI i2 : OpensMeasurableSpace (PlaneConf N × (PosConf N hT × PosConf N hT)) :=
    Prod.opensMeasurableSpace (h := secondCountableTopologyEither_of_left _ _)
  have c0 : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1 x i a b :=
    fun x i a b => (continuous_U0of N x i a b).comp continuous_fst
  have ch : ∀ x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => Uhof N p.1 x i a b :=
    fun x i a b => (continuous_Uhof N x i a b).comp continuous_fst
  have cp : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.1 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_fst.comp continuous_snd)
  have cm : ∀ t x i a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      Upof N hT p.2.2 t x i a b :=
    fun t x i a b => (continuous_Upof N hT t x i a b).comp (continuous_snd.comp continuous_snd)
  have c4p : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.1 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_fst.comp continuous_snd)
  have c4m : ∀ t x a b, Continuous fun p : PlaneConf N × (PosConf N hT × PosConf N hT) =>
      U4of N hT p.2.2 t x a b :=
    fun t x a b => (continuous_U4of N hT t x a b).comp (continuous_snd.comp continuous_snd)
  have hcont := continuous_det_torus_generic N hT j m
    (fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => U0of N p.1) (fun p => Uhof N p.1)
    (fun p => Upof N hT p.2.1) (fun p => Upof N hT p.2.2)
    (fun p => U4of N hT p.2.1) (fun p => U4of N hT p.2.2) c0 ch cp cm c4p c4m
  have m1 : Measurable fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => φ (p.1, p.2.1) :=
    hφ.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
  have m2 : Measurable fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => φ (p.1, p.2.2) :=
    hφ.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have mk : Measurable fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => k p.1 := hk.comp measurable_fst
  have mh1 : Measurable fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => hw (p.1, p.2.1) :=
    hhw.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
  have mh2 : Measurable fun p : PlaneConf N × (PosConf N hT × PosConf N hT) => hw (p.1, p.2.2) :=
    hhw.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have hGm : Measurable (wilsonIntegrand N hT j m k hw φ) :=
    ((m1.mul m2).mul ((mk.mul mh1).mul mh2)).mul hcont.measurable
  have h2 := integral_map hmp.aemeasurable hGm.aestronglyMeasurable
  rw [hmp.map_eq] at h2
  have h1 : 0 ≤ ∫ p, wilsonIntegrand N hT j m k hw φ p
      ∂((Measure.haarMeasure ⊤ : Measure (PlaneConf N)).prod
        ((Measure.haarMeasure ⊤ : Measure (PosConf N hT)).prod (Measure.haarMeasure ⊤))) :=
    site_reflection_positive_wilson_SU2_haar N hT hpos j m hm k hw φ hk hhw hφ Ck Ch Cφ bk bhw bφ hk0
  exact h1.trans_eq h2

end FermionSliceReflection

#print axioms FermionSliceBlock.std4_eq_clifford
#print axioms FermionSliceBlock.std4_add_conjTranspose
#print axioms FermionSliceBlock.massPart_eq_sos
#print axioms FermionSliceBlock.std4_isUnit_det_of_pos
#print axioms FermionSliceBlock.tshift_pow_two_h
#print axioms FermionSliceBlock.std4_free_isUnit_det
#print axioms FermionSU2Config.quatMat_unitary
#print axioms FermionSU2Config.quatMat_det
#print axioms FermionSU2Config.quatMat_inv
#print axioms FermionSliceBlock.wilsonPlane_isHermitian
#print axioms FermionSliceReflection.wilson_weight_nonneg_std4
#print axioms FermionSliceReflection.wilson_weight_nonneg_torus
#print axioms FermionSliceReflection.site_reflection_positive_wilson_SU2
#print axioms FermionSliceReflection.site_reflection_positive_wilson_SU2_haar
#print axioms FermionSliceBlock.std4_free_torus_isUnit_det
#print axioms FermionSliceBlock.continuous_std4_assembled
#print axioms FermionSliceReflection.partition_pos_torus_generic
#print axioms FermionSliceReflection.partition_pos_wilson_SU2
#print axioms FermionSliceBlock.hop4_unitary
#print axioms FermionSU2Config.hop4_unitary_SU2
#print axioms FermionSU2Config.massPart_eq_sos_SU2
#print axioms FermionSU2Config.std4_isUnit_det_of_pos_SU2
#print axioms FermionSU2Config.haar_planeConf_eq
#print axioms FermionSU2Config.phys_split_preserving
#print axioms FermionSliceReflection.continuous_det_torus_generic
#print axioms FermionSliceReflection.site_reflection_positive_phys
