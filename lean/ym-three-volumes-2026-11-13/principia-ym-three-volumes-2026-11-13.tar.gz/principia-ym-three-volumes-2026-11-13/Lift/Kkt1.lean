import Linz.LiftBound1

/-!
# The one-dimensional constrained minimiser is the explicit block-quadratic kernel

Problem (T8, d = 1, scalar, `U = 1`). On `ℤ`, blocks `B_b = {bL, …, bL + L − 1}`. Energy on the
window of the blocks `−R, …, R − 1` (the bonds `(x, x + 1)` with `x = −RL − 1, …, RL − 1`):
`energyW L R g = Σ_{i < 2RL + 1} (g(x₀ + i + 1) − g(x₀ + i))²`, `x₀ = −RL − 1`.
Constraint: the block sums `Σ_{r < L} g(bL + r) = L·δ_{b0}` (block averages `δ_{b0}`).

`liftF L x = q_{b}(u)` with `b = ⌊x / L⌋`, `u = (x mod L) − (L − 1)/2`,
`q_b(u) = δ_{b0} + β_b u − (μ_b/2)(u² − κ)`, `κ = (L² − 1)/12`, with the explicit coefficients
`BlockLift.zK`, `beK`, `muK`.

* `liftF_blocks`: `liftF` satisfies the constraint.
* `liftF_kkt`: `−Δ liftF (x) = μ_{⌊x/L⌋}` at every `x` (one multiplier per block: the KKT condition).
* `energy_split`: for every perturbation `h` vanishing outside the blocks `−R, …, R − 1` with zero
  block sums, `energyW (liftF + h) = energyW liftF + energyW h`.
* `window_min_unique`: among all `g` equal to `liftF` outside the blocks `−R, …, R − 1` and with
  block sums `L·δ_{b0}`, `liftF` has the least window energy, and it is the only one with that energy
  (for every `R`): `liftF` is the unique minimiser of each finite window problem with its own
  boundary values. (Not stated: uniqueness among all functions on `ℤ` of finite energy.)
* `kerE_eq_liftF`: `kerE L u b' = liftF (−b'L + r)` with `u = r − (L − 1)/2`.
* `row_sum_minimiser`: a minimiser `g` of a window problem (as above) has row sums
  `|g r| + Σ_{k<n} (|g(r − (k+1)L)| + |g(r + (k+1)L)|) ≤ 1 + 10/8 + 2(9/2 + 17/8)(0.27/0.73)`.
-/

namespace BlockLiftMin

open BlockLift Finset

variable (L : ℕ)

/-- `κ = (L² − 1)/12`. -/
noncomputable def kap : ℝ := ((L : ℝ) ^ 2 - 1) / 12

/-- The offset `u = r − (L − 1)/2` from the block centre. -/
noncomputable def off (r : ℤ) : ℝ := (r : ℝ) - ((L : ℝ) - 1) / 2

/-- The quadratic of block `b`: `q_b(u) = δ_{b0} + β_b u − (μ_b/2)(u² − κ)`. -/
noncomputable def qB (b : ℤ) (u : ℝ) : ℝ := zK b + beK L b * u - muK L b / 2 * (u ^ 2 - kap L)

/-- The global lift of `z = δ_0`. -/
noncomputable def liftF (x : ℤ) : ℝ := qB L (x / (L : ℤ)) (off L (x % (L : ℤ)))

/-- The window energy over the blocks `−R, …, R − 1`. -/
noncomputable def energyW (R : ℕ) (g : ℤ → ℝ) : ℝ :=
  ∑ i ∈ range (2 * R * L + 1),
    (g (-((R : ℤ) * L) - 1 + i + 1) - g (-((R : ℤ) * L) - 1 + i)) ^ 2

variable {L}

theorem liftF_block (hL : 0 < L) (b r : ℤ) (h0 : 0 ≤ r) (h1 : r < L) :
    liftF L (b * L + r) = qB L b (off L r) := by
  have hL' : (L : ℤ) ≠ 0 := by exact_mod_cast hL.ne'
  have hd : (b * L + r) / (L : ℤ) = b := by
    rw [show b * (L : ℤ) + r = r + b * L by ring, Int.add_mul_ediv_right _ _ hL',
      Int.ediv_eq_zero_of_lt h0 h1, zero_add]
  have hm : (b * L + r) % (L : ℤ) = r := by
    rw [show b * (L : ℤ) + r = r + b * L by ring, Int.add_mul_emod_self_right,
      Int.emod_eq_of_lt h0 h1]
  unfold liftF; rw [hd, hm]

/-- The two seam points: `q_{b−1}` and `q_b` agree at `bL − 1` and at `bL`. -/
theorem seam_left (hL : 2 ≤ L) (b : ℤ) :
    qB L (b - 1) (off L ((L : ℤ) - 1)) = qB L b (off L (-1)) := by
  have hA := seamA hL b
  have hB := seamB hL b
  unfold gam at hB
  simp only [qB, off, kap]
  push_cast
  linear_combination (1 / 2 : ℝ) * hA - (1 / 2 : ℝ) * hB

theorem seam_right (hL : 2 ≤ L) (b : ℤ) :
    qB L (b - 1) (off L (L : ℤ)) = qB L b (off L 0) := by
  have hA := seamA hL b
  have hB := seamB hL b
  unfold gam at hB
  simp only [qB, off, kap]
  push_cast
  linear_combination (-1 / 2 : ℝ) * hA - (1 / 2 : ℝ) * hB

theorem qB_second (b : ℤ) (u : ℝ) :
    qB L b (u + 1) + qB L b (u - 1) - 2 * qB L b u = -muK L b := by
  simp only [qB]; ring

theorem off_add (r : ℤ) (k : ℤ) : off L (r + k) = off L r + k := by
  simp only [off]; push_cast; ring

/-- **KKT**: `−Δ liftF = μ_{⌊x/L⌋}` at every site. -/
theorem liftF_kkt (hL : 2 ≤ L) (x : ℤ) :
    liftF L (x + 1) + liftF L (x - 1) - 2 * liftF L x = -muK L (x / (L : ℤ)) := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  have hx0 := Int.ediv_mul_add_emod x L
  set b := x / (L : ℤ)
  set r := x % (L : ℤ)
  have hr0 : 0 ≤ r := Int.emod_nonneg _ hLz.ne'
  have hrL : r < L := Int.emod_lt_of_pos _ hLz
  have hx : x = b * L + r := by linear_combination -hx0
  have hL2 : (2 : ℤ) ≤ L := by exact_mod_cast hL
  have hc : liftF L x = qB L b (off L r) := by rw [hx]; exact liftF_block hL0 b r hr0 hrL
  rw [hc]
  rcases (show r = 0 ∨ (0 < r ∧ r < (L : ℤ) - 1) ∨ r = (L : ℤ) - 1 by omega) with h | ⟨h1, h2⟩ | h
  · -- first site of the block: the left neighbour is the last site of block `b − 1`
    have e1 : liftF L (x + 1) = qB L b (off L r + 1) := by
      rw [show x + 1 = b * L + (r + 1) by rw [hx]; ring, liftF_block hL0 b (r + 1) (by omega)
        (by omega), off_add]; push_cast; ring_nf
    have e2 : liftF L (x - 1) = qB L b (off L r - 1) := by
      rw [show x - 1 = (b - 1) * L + ((L : ℤ) - 1) by rw [hx, h]; ring,
        liftF_block hL0 (b - 1) ((L : ℤ) - 1) (by omega) (by omega), seam_left hL b, h]
      congr 1; simp only [off]; push_cast; ring
    rw [e1, e2, qB_second]
  · have e1 : liftF L (x + 1) = qB L b (off L r + 1) := by
      rw [show x + 1 = b * L + (r + 1) by rw [hx]; ring, liftF_block hL0 b (r + 1) (by omega)
        (by omega), off_add]; push_cast; ring_nf
    have e2 : liftF L (x - 1) = qB L b (off L r - 1) := by
      rw [show x - 1 = b * L + (r - 1) by rw [hx]; ring, liftF_block hL0 b (r - 1) (by omega)
        (by omega)]
      congr 1; simp only [off]; push_cast; ring
    rw [e1, e2, qB_second]
  · -- last site of the block: the right neighbour is the first site of block `b + 1`
    have e1 : liftF L (x + 1) = qB L b (off L r + 1) := by
      rw [show x + 1 = (b + 1) * L + 0 by rw [hx, h]; ring,
        liftF_block hL0 (b + 1) 0 le_rfl hLz, ← seam_right hL (b + 1),
        show b + 1 - 1 = b by ring, h]
      congr 1; simp only [off]; push_cast; ring
    have e2 : liftF L (x - 1) = qB L b (off L r - 1) := by
      rw [show x - 1 = b * L + (r - 1) by rw [hx]; ring, liftF_block hL0 b (r - 1) (by omega)
        (by omega)]
      congr 1; simp only [off]; push_cast; ring
    rw [e1, e2, qB_second]

/-! ## The constraint -/

theorem sum_lin (n : ℕ) (c : ℝ) :
    ∑ r ∈ range n, ((r : ℝ) - c) = (n : ℝ) * (n - 1) / 2 - n * c := by
  induction n with
  | zero => simp
  | succ n ih => rw [sum_range_succ, ih]; push_cast; ring

theorem sum_sq (n : ℕ) (c : ℝ) :
    ∑ r ∈ range n, ((r : ℝ) - c) ^ 2 =
      (n : ℝ) * (n - 1) * (2 * n - 1) / 6 - c * n * (n - 1) + n * c ^ 2 := by
  induction n with
  | zero => simp
  | succ n ih => rw [sum_range_succ, ih]; push_cast; ring

theorem sum_quad (n : ℕ) (A B C c k : ℝ) :
    ∑ r ∈ range n, (A + B * ((r : ℝ) - c) - C * (((r : ℝ) - c) ^ 2 - k)) =
      n * A + B * ((n : ℝ) * (n - 1) / 2 - n * c) -
        C * ((n : ℝ) * (n - 1) * (2 * n - 1) / 6 - c * n * (n - 1) + n * c ^ 2 - n * k) := by
  induction n with
  | zero => simp
  | succ n ih => rw [sum_range_succ, ih]; push_cast; ring

/-- **The constraint**: the block sums of `liftF` are `L·δ_{b0}`. -/
theorem liftF_blocks (hL : 0 < L) (b : ℤ) :
    ∑ r ∈ range L, liftF L (b * L + r) = L * zK b := by
  have e : ∀ r ∈ range L, liftF L (b * L + r) =
      zK b + beK L b * ((r : ℝ) - ((L : ℝ) - 1) / 2) -
        muK L b / 2 * (((r : ℝ) - ((L : ℝ) - 1) / 2) ^ 2 - kap L) := by
    intro r hr
    rw [liftF_block hL b r (by positivity) (by exact_mod_cast mem_range.1 hr)]
    simp only [qB, off, Int.cast_natCast]
  rw [sum_congr rfl e, sum_quad]
  simp only [kap]
  ring

/-! ## Summation by parts and the energy identity -/

theorem sbp (f g : ℕ → ℝ) (N : ℕ) :
    ∑ i ∈ range (N + 1), (f (i + 1) - f i) * (g (i + 1) - g i) =
      g (N + 1) * (f (N + 1) - f N) - g 0 * (f 1 - f 0) -
        ∑ i ∈ range N, g (i + 1) * (f (i + 2) - 2 * f (i + 1) + f i) := by
  induction N with
  | zero => simp; ring
  | succ N ih => rw [sum_range_succ, ih, sum_range_succ]; ring

theorem sum_blocks (φ : ℕ → ℝ) (C : ℕ) :
    ∑ i ∈ range (C * L), φ i = ∑ c ∈ range C, ∑ r ∈ range L, φ (c * L + r) := by
  induction C with
  | zero => simp
  | succ C ih => rw [show (C + 1) * L = C * L + L by ring, sum_range_add, ih, sum_range_succ]

/-- **Energy identity**: perturbations supported in the blocks `−R, …, R − 1` with zero block sums
add their own energy. -/
theorem energy_split (hL : 2 ≤ L) (R : ℕ) (h : ℤ → ℝ)
    (hsupp : ∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → h x = 0)
    (hblk : ∀ b : ℤ, ∑ r ∈ range L, h (b * L + r) = 0) :
    energyW L R (fun x => liftF L x + h x) = energyW L R (liftF L) + energyW L R h := by
  have hL0 : 0 < L := by omega
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  set N := 2 * R * L
  set f : ℕ → ℝ := fun i => liftF L (x₀ + i)
  set g : ℕ → ℝ := fun i => h (x₀ + i)
  have hcross : ∑ i ∈ range (N + 1), (f (i + 1) - f i) * (g (i + 1) - g i) = 0 := by
    rw [sbp]
    have hg0 : g 0 = 0 := hsupp _ (Or.inl (by simp [x₀]))
    have hgN : g (N + 1) = 0 := hsupp _ (Or.inr (by simp only [x₀, N]; push_cast; linarith))
    rw [hg0, hgN, zero_mul, zero_mul, sub_zero, zero_sub, neg_eq_zero]
    have hlap : ∀ i, f (i + 2) - 2 * f (i + 1) + f i = -muK L ((x₀ + (i + 1 : ℕ)) / (L : ℤ)) := by
      intro i
      have := liftF_kkt hL (x₀ + (i + 1 : ℕ))
      simp only [f]
      rw [← this]
      have e1 : x₀ + ((i + 2 : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) + 1 := by push_cast; ring
      have e2 : x₀ + ((i : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) - 1 := by push_cast; ring
      rw [e1, e2]; ring
    simp only [hlap]
    rw [show N = (2 * R) * L by rfl, sum_blocks]
    refine sum_eq_zero fun c _ => ?_
    have hx : ∀ r : ℕ, r < L → x₀ + ((c * L + r : ℕ) + 1 : ℕ) = ((c : ℤ) - R) * L + r := by
      intro r _; simp only [x₀]; push_cast; ring
    have hdiv : ∀ r : ℕ, r < L → (((c : ℤ) - R) * L + r) / (L : ℤ) = (c : ℤ) - R := by
      intro r hr
      have hL' : (L : ℤ) ≠ 0 := by exact_mod_cast hL0.ne'
      rw [show ((c : ℤ) - R) * L + r = r + ((c : ℤ) - R) * L by ring,
        Int.add_mul_ediv_right _ _ hL', Int.ediv_eq_zero_of_lt (by positivity)
          (by exact_mod_cast hr), zero_add]
    have e : ∀ r ∈ range L, g (c * L + r + 1) * -muK L ((x₀ + ((c * L + r + 1 : ℕ) : ℤ)) / (L : ℤ)) =
        -muK L ((c : ℤ) - R) * h (((c : ℤ) - R) * L + r) := by
      intro r hr
      have hr' := mem_range.1 hr
      simp only [g]
      rw [hx r hr', hdiv r hr']; ring
    rw [sum_congr rfl e, ← mul_sum, hblk, mul_zero]
  unfold energyW
  simp only [f, g] at hcross
  rw [← sum_add_distrib]
  have : ∀ i ∈ range (2 * R * L + 1),
      (liftF L (x₀ + i + 1) + h (x₀ + i + 1) - (liftF L (x₀ + i) + h (x₀ + i))) ^ 2 =
        (liftF L (x₀ + i + 1) - liftF L (x₀ + i)) ^ 2 + (h (x₀ + i + 1) - h (x₀ + i)) ^ 2 +
          2 * ((liftF L (x₀ + ((i + 1 : ℕ) : ℤ)) - liftF L (x₀ + i)) *
            (h (x₀ + ((i + 1 : ℕ) : ℤ)) - h (x₀ + i))) := by
    intro i _
    have e : x₀ + ((i + 1 : ℕ) : ℤ) = x₀ + i + 1 := by push_cast; ring
    rw [e]; ring
  rw [sum_congr rfl this, sum_add_distrib, ← mul_sum, hcross, mul_zero, add_zero]

/-- The window energy vanishes only for functions constant along the window. -/
theorem energy_zero (R : ℕ) (h : ℤ → ℝ)
    (hsupp : ∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → h x = 0)
    (h0 : energyW L R h = 0) : ∀ x, h x = 0 := by
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  have hterm : ∀ i ∈ range (2 * R * L + 1), (h (x₀ + i + 1) - h (x₀ + i)) ^ 2 = 0 :=
    (sum_eq_zero_iff_of_nonneg fun i _ => sq_nonneg _).1 h0
  have hstep : ∀ i : ℕ, i ≤ 2 * R * L + 1 → h (x₀ + i) = 0 := by
    intro i
    induction i with
    | zero => intro _; simpa using hsupp x₀ (Or.inl (by simp [x₀]))
    | succ i ih =>
        intro hi
        have := hterm i (mem_range.2 (by omega))
        have e : h (x₀ + i + 1) = h (x₀ + i) := by nlinarith [sq_nonneg (h (x₀ + i + 1) - h (x₀ + i))]
        push_cast; rw [← add_assoc, e]; exact ih (by omega)
  intro x
  by_cases hx : x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x
  · exact hsupp x hx
  · simp only [not_or, not_lt] at hx
    obtain ⟨i, hi⟩ : ∃ i : ℕ, x = x₀ + i := ⟨(x - x₀).toNat, by simp only [x₀]; omega⟩
    rw [hi]
    refine hstep i ?_
    have : (i : ℤ) ≤ 2 * R * L + 1 := by simp only [x₀] at hi; nlinarith [hx.1, hx.2]
    exact_mod_cast this

/-- **`liftF` is the unique minimiser of every window problem with its own boundary values.**
Admissible: `g = liftF` outside the blocks `−R, …, R − 1`, block sums `L·δ_{b0}` for every block. -/
theorem window_min_unique (hL : 2 ≤ L) (R : ℕ) (g : ℤ → ℝ)
    (hout : ∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → g x = liftF L x)
    (hblk : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * zK b) :
    energyW L R (liftF L) ≤ energyW L R g ∧ (energyW L R g ≤ energyW L R (liftF L) → g = liftF L) := by
  have hL0 : 0 < L := by omega
  set h : ℤ → ℝ := fun x => g x - liftF L x
  have hsupp : ∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → h x = 0 := fun x hx => by
    simp only [h, hout x hx, sub_self]
  have hb : ∀ b : ℤ, ∑ r ∈ range L, h (b * L + r) = 0 := fun b => by
    simp only [h, sum_sub_distrib, hblk, liftF_blocks hL0, sub_self]
  have hg : (fun x => liftF L x + h x) = g := by funext x; simp only [h]; ring
  have hs := energy_split hL R h hsupp hb
  rw [hg] at hs
  have hnn : 0 ≤ energyW L R h := sum_nonneg fun _ _ => sq_nonneg _
  refine ⟨by linarith, fun hle => ?_⟩
  have h0 : energyW L R h = 0 := by linarith
  have := energy_zero R h hsupp h0
  funext x; have := this x; simp only [h] at this; linarith

/-- `kerE` (the row of the lift at a site of block `0`) is `liftF` read at block `−b'`. -/
theorem kerE_eq_liftF (hL : 0 < L) (r : ℕ) (hr : r < L) (b' : ℤ) :
    kerE L (off L r) b' = liftF L (-b' * L + r) := by
  rw [liftF_block hL (-b') r (by positivity) (by exact_mod_cast hr)]
  simp only [kerE, qB, kap, neg_neg]
  have : zK (-b') = zK b' := by simp only [zK, neg_eq_zero]
  rw [this]

theorem off_abs (hL : 0 < L) (r : ℕ) (hr : r < L) : |off L r| ≤ (L : ℝ) / 2 := by
  have h1 : (r : ℝ) + 1 ≤ L := by exact_mod_cast hr
  have h0 : (0 : ℝ) ≤ r := by positivity
  rw [abs_le]; simp only [off, Int.cast_natCast]; constructor <;> linarith

/-- **Row sums of the constrained minimiser** (T8, d = 1): a minimiser `g` of a window problem
(boundary values `liftF` outside the blocks `−R, …, R − 1`, block sums `L·δ_{b0}`) is `liftF`, and
its row sums at a site `r` of block `0` are bounded uniformly in `L ≥ 2`, `R`, `n`. -/
theorem row_sum_minimiser (hL : 2 ≤ L) (R : ℕ) (g : ℤ → ℝ)
    (hout : ∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → g x = liftF L x)
    (hblk : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * zK b)
    (hmin : ∀ g' : ℤ → ℝ, (∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → g' x = liftF L x) →
      (∀ b : ℤ, ∑ r ∈ range L, g' (b * L + r) = L * zK b) → energyW L R g ≤ energyW L R g')
    (r : ℕ) (hr : r < L) (n : ℕ) :
    |g r| + ∑ k ∈ range n, (|g (r - ((k : ℤ) + 1) * L)| + |g (r + ((k : ℤ) + 1) * L)|) ≤
      1 + 10 / 8 + 2 * (9 / 2 + 17 / 8) * ((27 / 100) / (1 - 27 / 100)) := by
  have hL0 : 0 < L := by omega
  have hgF : g = liftF L := (window_min_unique hL R g hout hblk).2
    (hmin _ (fun _ _ => rfl) (liftF_blocks hL0))
  subst hgF
  have hb := row_sum_bound hL (off_abs hL0 r hr) n
  have e0 : liftF L (r : ℤ) = kerE L (off L r) 0 := by
    rw [kerE_eq_liftF hL0 r hr]; simp
  have e1 : ∀ k : ℕ, liftF L ((r : ℤ) - ((k : ℤ) + 1) * L) = kerE L (off L r) ((k : ℤ) + 1) := by
    intro k; rw [kerE_eq_liftF hL0 r hr]; congr 1; ring
  have e2 : ∀ k : ℕ, liftF L ((r : ℤ) + ((k : ℤ) + 1) * L) = kerE L (off L r) (-((k : ℤ) + 1)) := by
    intro k; rw [kerE_eq_liftF hL0 r hr]; congr 1; ring
  simp only [e0, e1, e2]
  exact hb

/-- The window problem is not empty: `liftF` itself is admissible, so `row_sum_minimiser` applies
to `g = liftF` for every `R`. -/
theorem liftF_admissible (hL : 2 ≤ L) (R : ℕ) :
    (∀ g' : ℤ → ℝ, (∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → g' x = liftF L x) →
      (∀ b : ℤ, ∑ r ∈ range L, g' (b * L + r) = L * zK b) →
        energyW L R (liftF L) ≤ energyW L R g') :=
  fun g' hout hblk => (window_min_unique hL R g' hout hblk).1

end BlockLiftMin

#print axioms BlockLiftMin.liftF_kkt
#print axioms BlockLiftMin.liftF_blocks
#print axioms BlockLiftMin.energy_split
#print axioms BlockLiftMin.window_min_unique
#print axioms BlockLiftMin.row_sum_minimiser
#print axioms BlockLiftMin.liftF_admissible
