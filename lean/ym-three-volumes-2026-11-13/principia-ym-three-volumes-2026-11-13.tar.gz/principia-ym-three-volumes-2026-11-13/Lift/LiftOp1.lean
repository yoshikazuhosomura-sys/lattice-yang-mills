import Lift.KktUniq1

/-!
# The minimal lift as an operator on finitely supported block data

For block data `z : ℤ →₀ ℝ` (finitely many blocks), `liftOp L z x = Σ_b z_b · liftF L (x − bL)`.

* `liftOp_blocks`: the block sums of `liftOp z` are `L · z_b` (so `T ∘ liftOp = id` for the block
  average `T`).
* `liftOp_kkt`: one multiplier per block, `ν_b = Σ_{b'} z_{b'} μ_{b − b'}`.
* `liftOp_bounded`: `|liftOp z x| ≤ 7 Σ_b |z_b|`.
* `liftOp_unique`: a bounded `g` with block sums `L · z_b` and one multiplier per block is
  `liftOp z`; `bounded_local_min_eq_liftOp`: the same for bounded local minimisers.
* `liftOp_local_min`: `liftOp z` is a local minimiser.
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

/-- The minimal lift of finitely supported block data. -/
noncomputable def liftOp (L : ℕ) (z : ℤ →₀ ℝ) (x : ℤ) : ℝ :=
  z.sum fun b c => c * liftF L (x - b * L)

theorem liftOp_blocks (hL : 0 < L) (z : ℤ →₀ ℝ) (b : ℤ) :
    ∑ r ∈ range L, liftOp L z (b * L + r) = L * z b := by
  unfold liftOp Finsupp.sum
  rw [sum_comm]
  have e : ∀ b' ∈ z.support, ∑ r ∈ range L, z b' * liftF L (b * L + r - b' * L) =
      z b' * (L * zK (b - b')) := by
    intro b' _
    rw [← mul_sum, ← liftF_blocks hL (b - b')]
    congr 1
    refine sum_congr rfl fun r _ => ?_
    congr 1; ring
  rw [sum_congr rfl e]
  have e2 : ∀ b' ∈ z.support, z b' * ((L : ℝ) * zK (b - b')) =
      if b' = b then (L : ℝ) * z b' else 0 := by
    intro b' _
    unfold zK
    by_cases h : b' = b
    · subst h; simp; ring
    · rw [if_neg h, if_neg (sub_ne_zero.2 (Ne.symm h))]; ring
  rw [sum_congr rfl e2, sum_ite_eq']
  split_ifs with h
  · ring
  · rw [Finsupp.notMem_support_iff.1 h, mul_zero]

theorem liftOp_kkt (hL : 2 ≤ L) (z : ℤ →₀ ℝ) (x : ℤ) :
    liftOp L z (x + 1) + liftOp L z (x - 1) - 2 * liftOp L z x =
      -(z.sum fun b c => c * muK L (x / (L : ℤ) - b)) := by
  have hL0 : 0 < L := by omega
  have hL' : (L : ℤ) ≠ 0 := by exact_mod_cast hL0.ne'
  unfold liftOp Finsupp.sum
  rw [← sum_add_distrib, mul_sum, ← sum_sub_distrib, ← sum_neg_distrib]
  refine sum_congr rfl fun b _ => ?_
  have h := liftF_kkt hL (x - b * L)
  have e1 : x + 1 - b * L = x - b * L + 1 := by ring
  have e2 : x - 1 - b * L = x - b * L - 1 := by ring
  have e3 : (x - b * L) / (L : ℤ) = x / L - b := by
    rw [sub_eq_add_neg, show -(b * (L : ℤ)) = (-b) * L by ring, Int.add_mul_ediv_right _ _ hL']
    ring
  rw [e3] at h
  show z b * liftF L (x + 1 - b * L) + z b * liftF L (x - 1 - b * L) - 2 * (z b * liftF L (x - b * L)) =
    -(z b * muK L (x / (L : ℤ) - b))
  rw [e1, e2]
  linear_combination (z b) * h

theorem liftOp_bounded (hL : 2 ≤ L) (z : ℤ →₀ ℝ) (x : ℤ) :
    |liftOp L z x| ≤ 7 * z.sum fun _ c => |c| := by
  unfold liftOp Finsupp.sum
  rw [mul_sum]
  refine (abs_sum_le_sum_abs _ _).trans (sum_le_sum fun b _ => ?_)
  rw [abs_mul, mul_comm]
  exact mul_le_mul_of_nonneg_right (liftF_bounded hL _) (abs_nonneg _)

/-- **The minimal lift of finitely supported data is unique among bounded functions with one
multiplier per block.** -/
theorem liftOp_unique (hL : 2 ≤ L) (z : ℤ →₀ ℝ) (g : ℤ → ℝ) {K : ℝ} (hK : ∀ x, |g x| ≤ K)
    (ν : ℤ → ℝ) (hk : ∀ x, g (x + 1) + g (x - 1) - 2 * g x = -ν (x / (L : ℤ)))
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * z b) : g = liftOp L z := by
  have hL0 : 0 < L := by omega
  have hz := kkt_bounded_zero hL (fun x => g x - liftOp L z x)
    (fun b => ν b - z.sum fun b' c => c * muK L (b - b'))
    (fun x => by
      have h1 := hk x
      have h2 := liftOp_kkt hL z x
      linarith)
    (fun b => by simp only [sum_sub_distrib, hs, liftOp_blocks hL0, sub_self])
    (K := K + 7 * z.sum fun _ c => |c|) (fun x => by
      have h1 := hK x
      have h2 := liftOp_bounded hL z x
      calc |g x - liftOp L z x| ≤ |g x| + |liftOp L z x| := abs_sub _ _
        _ ≤ _ := by linarith)
  funext x; have := hz x; linarith

theorem bounded_local_min_eq_liftOp (hL : 2 ≤ L) (z : ℤ →₀ ℝ) (g : ℤ → ℝ) {K : ℝ}
    (hK : ∀ x, |g x| ≤ K) (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * z b)
    (hmin : LocalMin L g) : g = liftOp L z := by
  refine liftOp_unique hL z g hK
    (fun b => -(g (b * L + 1) + g (b * L - 1) - 2 * g (b * L))) (fun x => ?_) hs
  rw [local_min_kkt hL g hmin x]; ring

/-- `liftOp z` is a local minimiser: perturbations supported in a window with zero block sums add
their own energy. -/
theorem liftOp_local_min (hL : 2 ≤ L) (z : ℤ →₀ ℝ) : LocalMin L (liftOp L z) := by
  intro R h hsupp hblk
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  have h2RL : (2 : ℤ) * R * L = 2 * ((R : ℤ) * L) := by ring
  have he := energy_general (L := L) R (liftOp L z) h (hsupp _ (Or.inl (by omega)))
    (hsupp _ (Or.inr (by push_cast; linarith [h2RL])))
  rw [he]
  -- the cross term vanishes: the Laplacian of `liftOp z` is constant on blocks
  have hcross : ∑ i ∈ range (2 * R * L), h (x₀ + (i + 1 : ℕ)) *
      (liftOp L z (x₀ + (i + 2 : ℕ)) - 2 * liftOp L z (x₀ + (i + 1 : ℕ)) + liftOp L z (x₀ + i)) = 0 := by
    have hL0 : 0 < L := by omega
    have hlap : ∀ i : ℕ, liftOp L z (x₀ + (i + 2 : ℕ)) - 2 * liftOp L z (x₀ + (i + 1 : ℕ)) +
        liftOp L z (x₀ + i) = -(z.sum fun b c => c * muK L ((x₀ + (i + 1 : ℕ)) / (L : ℤ) - b)) := by
      intro i
      rw [← liftOp_kkt hL z (x₀ + (i + 1 : ℕ))]
      have e1 : x₀ + ((i + 2 : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) + 1 := by push_cast; ring
      have e2 : x₀ + ((i : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) - 1 := by push_cast; ring
      rw [e1, e2]; ring
    simp only [hlap]
    rw [show 2 * R * L = (2 * R) * L by ring, sum_blocks]
    refine sum_eq_zero fun c _ => ?_
    have hx : ∀ r : ℕ, x₀ + ((c * L + r : ℕ) + 1 : ℕ) = ((c : ℤ) - R) * L + r := by
      intro r; simp only [x₀]; push_cast; ring
    have e : ∀ r ∈ range L, h (x₀ + ((c * L + r + 1 : ℕ) : ℤ)) *
        -(z.sum fun b c' => c' * muK L ((x₀ + ((c * L + r + 1 : ℕ) : ℤ)) / (L : ℤ) - b)) =
        -(z.sum fun b c' => c' * muK L ((c : ℤ) - R - b)) * h (((c : ℤ) - R) * L + r) := by
      intro r hr
      rw [hx r, div_block hL0 _ r (by positivity) (by exact_mod_cast mem_range.1 hr)]; ring
    rw [sum_congr rfl e, ← mul_sum, hblk, mul_zero]
  rw [hcross, mul_zero, sub_zero]
  have : 0 ≤ energyW L R h := sum_nonneg fun _ _ => sq_nonneg _
  linarith

end BlockLiftMin

#print axioms BlockLiftMin.liftOp_blocks
#print axioms BlockLiftMin.liftOp_kkt
#print axioms BlockLiftMin.liftOp_unique
#print axioms BlockLiftMin.bounded_local_min_eq_liftOp
#print axioms BlockLiftMin.liftOp_local_min
