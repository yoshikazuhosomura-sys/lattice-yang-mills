import Lift.PerRow1

/-!
# The λ-norm of the periodic minimal lift, uniformly in `L` and the period

Periodic chain of `B ≥ 1` blocks of length `L ≥ 2`. For block data `a` on the `B` blocks,
`Eper a x = Σ_{b<B} a_b · liftPer B L (x − bL)` (block averages `a`, by `liftPer_blocks`).
* `per_row_any`: `Σ_{b<B} |liftPer B L (x − bL)| ≤ 2·7/(1 − q)` for every `x`;
* `per_col`: `Σ_{x<BL} |liftPer B L (x − bL)| ≤ L · 2·7/(1 − q)`;
* the same for the gradient with `35/(1 − q)/L` and `35/(1 − q)` (`per_grad_row`, `per_grad_col`);
* `per_lamNorm`: `Σ_{x<BL} (∇ Eper a)² + L⁻² Σ_{x<BL} (Eper a)² ≤ (35² + 14²)(1 − q)⁻²/L · Σ_{b<B} a_b²`,
  `q = 27/100`.
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

/-- Finite sums over distinct shifts: `Σ_{n∈T} Σ_{x<P} g(x − nP) ≤ sup over finite sets`. -/
theorem per_fold {P : ℕ} (hP : 0 < P) (g : ℤ → ℝ) (hg : ∀ y, 0 ≤ g y) {C : ℝ}
    (hC : ∀ U : Finset ℤ, ∑ y ∈ U, g y ≤ C) (T : Finset ℤ) (S : Finset ℕ) (hS : ∀ s ∈ S, s < P) :
    ∑ n ∈ T, ∑ s ∈ S, g ((s : ℤ) - n * P) ≤ C := by
  have e : ∑ n ∈ T, ∑ s ∈ S, g ((s : ℤ) - n * P) =
      ∑ y ∈ (T ×ˢ S).image (fun p : ℤ × ℕ => (p.2 : ℤ) - p.1 * P), g y := by
    rw [sum_image (fun p hp q hq hpq => by
      simp only [mem_coe, mem_product] at hp hq
      have hP' : (0 : ℤ) < P := by exact_mod_cast hP
      have h1 : ((p.2 : ℤ) - q.2) = (p.1 - q.1) * P := by linarith
      have hp2 := hS p.2 hp.2
      have hq2 := hS q.2 hq.2
      have h2 : |(p.2 : ℤ) - q.2| < P := by rw [abs_lt]; constructor <;> omega
      rw [h1, abs_mul, abs_of_pos hP'] at h2
      have h3 : |p.1 - q.1| < 1 := by
        by_contra hc
        have hc' := not_lt.1 hc
        nlinarith
      have h4 : p.1 = q.1 := by rw [abs_lt] at h3; omega
      have h5 : (p.2 : ℤ) = q.2 := by rw [h4, sub_self, zero_mul] at h1; linarith
      exact Prod.ext h4 (by exact_mod_cast h5))]
    rw [sum_product]
  rw [e]; exact hC _

/-- A periodised nonnegative kernel: `Σ_{s∈S} Σ'_n g(s − nP) ≤ C` when every finite sum of `g` is. -/
theorem per_tsum_fold {P : ℕ} (hP : 0 < P) (g : ℤ → ℝ) (hg : ∀ y, 0 ≤ g y)
    (hsum : ∀ s : ℕ, Summable (fun n : ℤ => g ((s : ℤ) - n * P))) {C : ℝ} (hC0 : 0 ≤ C)
    (hC : ∀ U : Finset ℤ, ∑ y ∈ U, g y ≤ C) (S : Finset ℕ) (hS : ∀ s ∈ S, s < P) :
    ∑ s ∈ S, ∑' n : ℤ, g ((s : ℤ) - n * P) ≤ C := by
  rw [← Summable.tsum_finsetSum (f := fun (s : ℕ) (n : ℤ) => g ((s : ℤ) - n * P)) (fun s _ => hsum s)]
  refine tsum_le_of_sum_le' hC0 (fun T => ?_)
  exact per_fold hP g hg hC T S hS


/-- The same fold with `s + nP` (used for the rows). -/
theorem per_fold_plus {P : ℕ} (hP : 0 < P) (g : ℤ → ℝ) {C : ℝ}
    (hC : ∀ U : Finset ℤ, ∑ y ∈ U, g y ≤ C) (T : Finset ℤ) (S : Finset ℕ) (hS : ∀ s ∈ S, s < P) :
    ∑ n ∈ T, ∑ s ∈ S, g ((s : ℤ) + n * P) ≤ C := by
  have e : ∑ n ∈ T, ∑ s ∈ S, g ((s : ℤ) + n * P) =
      ∑ y ∈ (T ×ˢ S).image (fun p : ℤ × ℕ => (p.2 : ℤ) + p.1 * P), g y := by
    rw [sum_image (fun p hp q hq hpq => by
      simp only [mem_coe, mem_product] at hp hq
      have hP' : (0 : ℤ) < P := by exact_mod_cast hP
      have h1 : ((p.2 : ℤ) - q.2) = (q.1 - p.1) * P := by linarith
      have hp2 := hS p.2 hp.2
      have hq2 := hS q.2 hq.2
      have h2 : |(p.2 : ℤ) - q.2| < P := by rw [abs_lt]; constructor <;> omega
      rw [h1, abs_mul, abs_of_pos hP'] at h2
      have h3 : |q.1 - p.1| < 1 := by
        by_contra hc
        have hc' := not_lt.1 hc
        nlinarith
      have h4 : q.1 = p.1 := by rw [abs_lt] at h3; omega
      have h5 : (p.2 : ℤ) = q.2 := by rw [h4, sub_self, zero_mul] at h1; linarith
      exact Prod.ext h4.symm (by exact_mod_cast h5))]
    rw [sum_product]
  rw [e]; exact hC _

theorem fin_row_geo (hL : 2 ≤ L) (x : ℤ) (U : Finset ℤ) :
    ∑ m ∈ U, |liftF L (x - m * L)| ≤ 7 * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by
  have hL0 : 0 < L := by omega
  calc ∑ m ∈ U, |liftF L (x - m * L)| ≤ ∑ m ∈ U, 7 * (27 / 100 : ℝ) ^ (m - x / L).natAbs := by
        refine sum_le_sum fun m _ => ?_
        have := liftF_decay hL (x - m * L)
        rwa [div_sub_block hL0, natAbs_swap] at this
    _ = 7 * ∑ m ∈ U, (27 / 100 : ℝ) ^ (m - x / L).natAbs := by rw [mul_sum]
    _ ≤ 7 * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by gcongr; exact geo_int (by norm_num) (by norm_num) _ _

theorem fin_col_geo (hL : 2 ≤ L) (b : ℤ) (U : Finset ℤ) :
    ∑ y ∈ U, |liftF L (y - b * L)| ≤ 7 * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by
  have hL0 : 0 < L := by omega
  calc ∑ y ∈ U, |liftF L (y - b * L)| ≤ ∑ y ∈ U, 7 * (27 / 100 : ℝ) ^ (y / L - b).natAbs := by
        refine sum_le_sum fun y _ => ?_
        have := liftF_decay hL (y - b * L)
        rwa [div_sub_block hL0] at this
    _ = 7 * ∑ y ∈ U, (27 / 100 : ℝ) ^ (y / L - b).natAbs := by rw [mul_sum]
    _ ≤ 7 * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by gcongr; exact col_geo hL0 (by norm_num) (by norm_num) U b

theorem abs_liftPer_le (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (y : ℤ) :
    |liftPer B L y| ≤ ∑' n : ℤ, |liftF L (y - n * (B * L))| := by
  unfold liftPer
  exact norm_tsum_le_tsum_norm (f := fun n : ℤ => liftF L (y - n * (B * L))) (summable_shift hL hB y).abs

/-- **Rows of the periodic kernel**, at any site. -/
theorem per_row_any (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (x : ℤ) :
    ∑ b ∈ range B, |liftPer B L (x - b * L)| ≤ 7 * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by
  refine (sum_le_sum fun (b : ℕ) _ => abs_liftPer_le hL hB (x - (b : ℤ) * L)).trans ?_
  rw [← Summable.tsum_finsetSum (f := fun (b : ℕ) (n : ℤ) => |liftF L (x - (b : ℤ) * L - n * (B * L))|)
    (fun b _ => (summable_shift hL hB _).abs)]
  refine tsum_le_of_sum_le' (by positivity) (fun T => ?_)
  have := per_fold_plus hB (fun m => |liftF L (x - m * L)|) (fin_row_geo hL x) T (range B)
    (fun s hs => mem_range.1 hs)
  refine le_of_eq_of_le ?_ this
  refine sum_congr rfl fun n _ => sum_congr rfl fun b _ => ?_
  congr 2; ring

/-- **Columns of the periodic kernel** over one period. -/
theorem per_col (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (b : ℤ) :
    ∑ s ∈ range (B * L), |liftPer B L (s - b * L)| ≤ 7 * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by
  have hP : 0 < B * L := Nat.mul_pos hB (by omega)
  refine (sum_le_sum fun (s : ℕ) _ => abs_liftPer_le hL hB ((s : ℤ) - b * L)).trans ?_
  have := per_tsum_fold hP (fun y => |liftF L (y - b * L)|) (fun _ => abs_nonneg _)
    (fun s => by
      have := (summable_shift hL hB ((s : ℤ) - b * L)).abs
      refine this.congr fun n => ?_
      show |liftF L ((s : ℤ) - b * L - n * (B * L))| = |liftF L ((s : ℤ) - n * ((B * L : ℕ) : ℤ) - b * L)|
      congr 2; push_cast; ring)
    (by positivity) (fin_col_geo hL b) (range (B * L)) (fun s hs => mem_range.1 hs)
  refine le_of_eq_of_le ?_ this
  refine sum_congr rfl fun s _ => tsum_congr fun n => ?_
  congr 2; push_cast; ring

theorem fin_grad_row (hL : 2 ≤ L) (x : ℤ) (U : Finset ℤ) :
    ∑ m ∈ U, |liftF L (x - m * L + 1) - liftF L (x - m * L)| ≤ 35 / 2 / L * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by
  have hL0 : 0 < L := by omega
  calc _ ≤ ∑ m ∈ U, 35 / 2 * (27 / 100 : ℝ) ^ (m - x / L).natAbs / L := by
        refine sum_le_sum fun m _ => ?_
        have := liftF_grad_decay hL (x - m * L)
        rwa [div_sub_block hL0, natAbs_swap] at this
    _ = 35 / 2 / L * ∑ m ∈ U, (27 / 100 : ℝ) ^ (m - x / L).natAbs := by
        rw [mul_sum]; refine sum_congr rfl fun m _ => by ring
    _ ≤ _ := by gcongr; exact geo_int (by norm_num) (by norm_num) _ _

theorem fin_grad_col (hL : 2 ≤ L) (b : ℤ) (U : Finset ℤ) :
    ∑ y ∈ U, |liftF L (y - b * L + 1) - liftF L (y - b * L)| ≤ 35 / 2 / L * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by
  have hL0 : 0 < L := by omega
  calc _ ≤ ∑ y ∈ U, 35 / 2 * (27 / 100 : ℝ) ^ (y / L - b).natAbs / L := by
        refine sum_le_sum fun y _ => ?_
        have := liftF_grad_decay hL (y - b * L)
        rwa [div_sub_block hL0] at this
    _ = 35 / 2 / L * ∑ y ∈ U, (27 / 100 : ℝ) ^ (y / L - b).natAbs := by
        rw [mul_sum]; refine sum_congr rfl fun y _ => by ring
    _ ≤ _ := by gcongr; exact col_geo hL0 (by norm_num) (by norm_num) U b

theorem abs_grad_liftPer_le (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (y : ℤ) :
    |liftPer B L (y + 1) - liftPer B L y| ≤
      ∑' n : ℤ, |liftF L (y - n * (B * L) + 1) - liftF L (y - n * (B * L))| := by
  have hs : Summable (fun n : ℤ => liftF L (y - n * (B * L) + 1) - liftF L (y - n * (B * L))) := by
    refine ((summable_shift hL hB (y + 1)).sub (summable_shift hL hB y)).congr fun n => ?_
    rw [show y + 1 - n * ((B : ℤ) * L) = y - n * (B * L) + 1 by ring]
  have e : liftPer B L (y + 1) - liftPer B L y =
      ∑' n : ℤ, (liftF L (y - n * (B * L) + 1) - liftF L (y - n * (B * L))) := by
    unfold liftPer
    rw [← (summable_shift hL hB (y + 1)).tsum_sub (summable_shift hL hB y)]
    refine tsum_congr fun n => ?_
    rw [show y + 1 - n * ((B : ℤ) * L) = y - n * (B * L) + 1 by ring]
  rw [e]
  exact norm_tsum_le_tsum_norm
    (f := fun n : ℤ => liftF L (y - n * (B * L) + 1) - liftF L (y - n * (B * L))) hs.abs

theorem per_grad_row (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (x : ℤ) :
    ∑ b ∈ range B, |liftPer B L (x - b * L + 1) - liftPer B L (x - b * L)| ≤
      35 / 2 / L * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by
  refine (sum_le_sum fun (b : ℕ) _ => abs_grad_liftPer_le hL hB (x - (b : ℤ) * L)).trans ?_
  have hsum : ∀ b : ℕ, Summable (fun n : ℤ =>
      |liftF L (x - (b : ℤ) * L - n * (B * L) + 1) - liftF L (x - (b : ℤ) * L - n * (B * L))|) := by
    intro b
    refine (((summable_shift hL hB (x - (b : ℤ) * L + 1)).sub
      (summable_shift hL hB (x - (b : ℤ) * L))).abs).congr fun n => ?_
    show |_ - _| = |_ - _|
    rw [show x - (b : ℤ) * L + 1 - n * (B * L) = x - (b : ℤ) * L - n * (B * L) + 1 by ring]
  rw [← Summable.tsum_finsetSum (f := fun (b : ℕ) (n : ℤ) =>
      |liftF L (x - (b : ℤ) * L - n * (B * L) + 1) - liftF L (x - (b : ℤ) * L - n * (B * L))|)
    (fun b _ => hsum b)]
  refine tsum_le_of_sum_le' (by positivity) (fun T => ?_)
  have := per_fold_plus hB (fun m => |liftF L (x - m * L + 1) - liftF L (x - m * L)|)
    (fin_grad_row hL x) T (range B) (fun s hs => mem_range.1 hs)
  refine le_of_eq_of_le ?_ this
  refine sum_congr rfl fun n _ => sum_congr rfl fun b _ => ?_
  congr 2 <;> ring_nf

theorem per_grad_col (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (b : ℤ) :
    ∑ s ∈ range (B * L), |liftPer B L (s - b * L + 1) - liftPer B L (s - b * L)| ≤
      35 / 2 / L * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by
  have hP : 0 < B * L := Nat.mul_pos hB (by omega)
  refine (sum_le_sum fun (s : ℕ) _ => abs_grad_liftPer_le hL hB ((s : ℤ) - b * L)).trans ?_
  have := per_tsum_fold hP (fun y => |liftF L (y - b * L + 1) - liftF L (y - b * L)|) (fun _ => abs_nonneg _)
    (fun s => by
      refine (((summable_shift hL hB ((s : ℤ) - b * L + 1)).sub
        (summable_shift hL hB ((s : ℤ) - b * L))).abs).congr fun n => ?_
      show _ = |liftF L ((s : ℤ) - n * ((B * L : ℕ) : ℤ) - b * L + 1) - liftF L ((s : ℤ) - n * ((B * L : ℕ) : ℤ) - b * L)|
      congr 2 <;> push_cast <;> ring_nf)
    (by positivity) (fin_grad_col hL b) (range (B * L)) (fun s hs => mem_range.1 hs)
  refine le_of_eq_of_le ?_ this
  refine sum_congr rfl fun s _ => tsum_congr fun n => ?_
  congr 2 <;> push_cast <;> ring_nf

/-- **The λ-norm of the periodic minimal lift over one period.** -/
theorem per_lamNorm (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (a : ℕ → ℝ) :
    ∑ s ∈ range (B * L), (∑ b ∈ range B, a b * liftPer B L ((s : ℤ) + 1 - b * L) -
        ∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L)) ^ 2 +
      (1 / (L : ℝ)) ^ 2 * ∑ s ∈ range (B * L), (∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L)) ^ 2 ≤
      (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ range B, a b ^ 2 := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  set Q := (1 - 27 / 100 : ℝ)⁻¹
  have hQ : 0 ≤ Q := by positivity
  set A := ∑ b ∈ range B, a b ^ 2
  have hA : 0 ≤ A := sum_nonneg fun _ _ => sq_nonneg _
  have h0 : ∑ s ∈ range (B * L), (∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L)) ^ 2 ≤
      (7 * (2 * Q)) * (7 * (L * (2 * Q))) * A := by
    have e : ∀ s : ℕ, ∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L) =
        ∑ b ∈ range B, liftPer B L ((s : ℤ) - (b : ℕ) * L) * a b := fun s =>
      sum_congr rfl fun b _ => mul_comm _ _
    simp only [e]
    exact SchurFin.schur_finset (range (B * L)) (range B) (fun s b => liftPer B L ((s : ℤ) - (b : ℕ) * L)) a
      (by positivity) (fun s _ => per_row_any hL hB s) (fun b _ => per_col hL hB b)
  have h1 : ∑ s ∈ range (B * L), (∑ b ∈ range B, a b * liftPer B L ((s : ℤ) + 1 - b * L) -
        ∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L)) ^ 2 ≤
      (35 / 2 / L * (2 * Q)) * (35 / 2 / L * (L * (2 * Q))) * A := by
    have e : ∀ s : ℕ, ∑ b ∈ range B, a b * liftPer B L ((s : ℤ) + 1 - b * L) -
        ∑ b ∈ range B, a b * liftPer B L ((s : ℤ) - b * L) =
        ∑ b ∈ range B, (liftPer B L ((s : ℤ) - (b : ℕ) * L + 1) - liftPer B L ((s : ℤ) - (b : ℕ) * L)) * a b := by
      intro s; rw [← sum_sub_distrib]; refine sum_congr rfl fun b _ => ?_
      rw [show (s : ℤ) + 1 - (b : ℕ) * L = (s : ℤ) - (b : ℕ) * L + 1 by ring]
      ring
    simp only [e]
    exact SchurFin.schur_finset (range (B * L)) (range B)
      (fun s b => liftPer B L ((s : ℤ) - (b : ℕ) * L + 1) - liftPer B L ((s : ℤ) - (b : ℕ) * L)) a
      (by positivity) (fun s _ => per_grad_row hL hB s) (fun b _ => per_grad_col hL hB b)
  have g1 : (35 / 2 / L * (2 * Q)) * (35 / 2 / L * (L * (2 * Q))) * A = 35 ^ 2 * Q ^ 2 / L * A := by
    field_simp
  have g0 : (1 / (L : ℝ)) ^ 2 * ((7 * (2 * Q)) * (7 * (L * (2 * Q))) * A) = 14 ^ 2 * Q ^ 2 / L * A := by
    field_simp; ring
  have h0' := mul_le_mul_of_nonneg_left h0 (by positivity : (0 : ℝ) ≤ (1 / (L : ℝ)) ^ 2)
  rw [g0] at h0'; rw [g1] at h1
  have e3 : (35 ^ 2 + 14 ^ 2) * Q ^ 2 / L * A = 35 ^ 2 * Q ^ 2 / L * A + 14 ^ 2 * Q ^ 2 / L * A := by ring
  rw [e3]; linarith

end BlockLiftMin

#print axioms BlockLiftMin.per_fold
#print axioms BlockLiftMin.per_tsum_fold
#print axioms BlockLiftMin.per_row_any
#print axioms BlockLiftMin.per_col
#print axioms BlockLiftMin.per_grad_row
#print axioms BlockLiftMin.per_grad_col
#print axioms BlockLiftMin.per_lamNorm
