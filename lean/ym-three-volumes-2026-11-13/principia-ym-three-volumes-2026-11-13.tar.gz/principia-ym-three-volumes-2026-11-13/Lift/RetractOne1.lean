import Linz.Levels1
import Linz.RetractGen1
import Linz.Witness1

/-!
# The linearisation for every retraction threshold `0 < r₀ ≤ 1`, and the stages of `pushOp`

* `retract_one_add_le_one`: for `0 < r₀ ≤ 1`, `‖v‖ ≤ s ≤ 1/2`, `|Re v| ≤ ρ`,
  `‖retract r₀ (1 + v) − (1 + v)‖ ≤ 2ρ + s²`. (If `‖1 + v‖ ≥ r₀` the retraction is the projection
  `q/‖q‖`; otherwise it is `q/r₀` and `‖q/r₀ − q‖ = ‖q‖(1/r₀ − 1) ≤ 1 − ‖q‖`.)
* `blockMap_exp_linear_le_one`: the box block map of the chain (`ChainBlockMap.blockMap`) at
  `U = exp(ε a)` is within `257 (ε M)²` of `exp(ε · sixSgn)`, and the linear part colour by colour is
  `Cop (y ↦ 2y) (pathKernel (2^(m+1) L))`, for **every** `0 < r₀ ≤ 1` and `ε M ≤ 1/32`.
  The case `r₀ = 1` (the retraction is the identity on the closed unit ball, so the block map is
  the plain weighted average of path products) is `blockMap_exp_linear_r1`.
* `level_linearised_le_one`: the same at every level `j` of the box chain with base `N`, with the
  operator of `LatticePush.stepOp (fine j N)`.
* `fine_add`, `pushOp_add`, `pushOp_stage`, `stageCov_stage`: for every `m`, the `j`-th step of
  `pushOp` (counted from the coarse side) is `stepOp (fine j N)`.
-/

namespace BlockLinear

open ChainBlockMap
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

/-- The retraction at `1 + v` for any threshold `0 < r₀ ≤ 1`. -/
theorem retract_one_add_le_one {r₀ : ℝ} (hr : 0 < r₀) (hr1 : r₀ ≤ 1) {v : ℍr} {s ρ : ℝ}
    (hv : ‖v‖ ≤ s) (hs : s ≤ 1 / 2) (hre : |v.re| ≤ ρ) :
    ‖retract r₀ (1 + v) - (1 + v)‖ ≤ 2 * ρ + s ^ 2 := by
  have hq : 1 - s ≤ ‖1 + v‖ := by
    have := norm_sub_norm_le (1 : ℍr) (-v)
    simp only [norm_one, norm_neg, sub_neg_eq_add] at this
    linarith
  set t := ‖1 + v‖ with htdef
  have hpos : 0 < t := by linarith
  have ht := norm_one_add_sq v
  rw [← htdef] at ht
  -- the deviation is at most `|1 − t|`
  have hdev : ‖retract r₀ (1 + v) - (1 + v)‖ ≤ |1 - t| := by
    have e : retract r₀ (1 + v) - (1 + v) = ((max t r₀)⁻¹ - 1) • (1 + v) := by
      simp only [retract, ← htdef, sub_smul, one_smul]
    rw [e, norm_smul, Real.norm_eq_abs, ← htdef]
    rcases le_total r₀ t with h | h
    · rw [max_eq_left h]
      rw [show t⁻¹ - 1 = (1 - t) / t by field_simp, abs_div, abs_of_pos hpos,
        div_mul_cancel₀ _ hpos.ne']
    · rw [max_eq_right h]
      have hr' : 1 ≤ r₀⁻¹ := one_le_inv_iff₀.2 ⟨hr, hr1⟩
      rw [abs_of_nonneg (by linarith), abs_of_nonneg (by linarith)]
      have : r₀⁻¹ * t ≤ 1 := by
        rw [inv_mul_le_iff₀ hr]; linarith
      nlinarith
  refine hdev.trans ?_
  have hv0 : 0 ≤ ‖v‖ := norm_nonneg _
  have hre' := abs_le.1 hre
  have hs0 : 0 ≤ s := hv0.trans hv
  have hvs : ‖v‖ ^ 2 ≤ s ^ 2 := pow_le_pow_left₀ hv0 hv 2
  rw [abs_le]
  constructor <;> nlinarith [hpos, hre'.1, hre'.2]

section Exp

variable {L : Type*}

/-- The expansion of `retract ∘ sixAvg` for any threshold `0 < r₀ ≤ 1`. -/
theorem retract_sixAvg_exp_le_one (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool))
    (hlen : ∀ o A, (P o A).length ≤ 8) {r₀ : ℝ} (hr : 0 < r₀) (hr1 : r₀ ≤ 1)
    (a : L → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M) (hM : ∀ ℓ, ‖a ℓ‖ ≤ M)
    (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) :
    ‖retract r₀ (sixAvg P fun ℓ => NormedSpace.exp (ε • a ℓ)) -
        NormedSpace.exp (ε • sixSgn P a)‖ ≤ 257 * (ε * M) ^ 2 := by
  set δ := ε * M with hδdef
  have hδ : 0 ≤ δ := mul_nonneg hε hM0
  set U : L → ℍr := fun ℓ => NormedSpace.exp (ε • a ℓ) with hUdef
  have hna : ∀ ℓ, ‖ε • a ℓ‖ ≤ δ := fun ℓ => by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    exact mul_le_mul_of_nonneg_left (hM _) hε
  have hrea : ∀ ℓ, (ε • a ℓ).re = 0 := fun ℓ => by rw [Quaternion.re_smul, ha, smul_zero]
  have hU1 : ∀ ℓ, ‖U ℓ‖ = 1 := fun ℓ => (exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).1
  have hU2 : ∀ ℓ, ‖U ℓ - 1‖ ≤ δ := fun ℓ =>
    ((exp_imag _ (hrea ℓ) ((hna ℓ).trans (by linarith))).2.1).trans (hna ℓ)
  obtain ⟨hA, hB, hC⟩ := sixAvg_near_one P hδ hU1 hU2 hlen
  push_cast at hA hB hC
  set lin := sixLin P U
  set e := sixAvg P U - 1 - lin
  set v := sixAvg P U - 1
  have hv : v = lin + e := by simp only [v, e]; abel
  have hvn : ‖v‖ ≤ 8 * δ + 32 * δ ^ 2 := by
    rw [hv]; refine (norm_add_le _ _).trans ?_; nlinarith [hA, hB]
  have hvre : |v.re| ≤ 36 * δ ^ 2 := by
    rw [hv, Quaternion.re_add]
    refine (abs_add_le _ _).trans ?_
    have := abs_re_le_norm e
    nlinarith [hA, hC]
  have hs : 8 * δ + 32 * δ ^ 2 ≤ 1 / 2 := by nlinarith
  have hR := retract_one_add_le_one hr hr1 hvn hs hvre
  have h1v : 1 + v = sixAvg P U := by simp only [v]; abel
  rw [h1v] at hR
  set S := sixSgn P a
  have hlinS : ‖lin - ε • S‖ ≤ 8 * δ ^ 2 := by
    have e2 : lin - ε • S = ∑ o, ∑ A, sixWeight A •
        (pathLin U (P o A) - ε • pathSgn a (P o A)) := by
      simp only [lin, S, sixLin, sixSgn, Finset.smul_sum, smul_sub, Finset.sum_sub_distrib]
      congr 1
      refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
      rw [smul_comm]
    rw [e2]
    refine norm_sixSum_le _ fun o A => (pathLin_exp a ha hε hM (by linarith) (P o A)).trans ?_
    have := hlen o A
    have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
    nlinarith [sq_nonneg δ]
  have hSn : ‖ε • S‖ ≤ 8 * δ := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hε]
    have : ‖S‖ ≤ 8 * M := norm_sixSum_le _ fun o A => (norm_pathSgn_le hM (P o A)).trans (by
      have := hlen o A
      have : ((P o A).length : ℝ) ≤ 8 := by exact_mod_cast this
      nlinarith)
    nlinarith
  have hSre : (ε • S).re = 0 := by rw [Quaternion.re_smul, re_sixSgn P ha, smul_zero]
  have hE := (exp_imag _ hSre (by linarith)).2.2
  have hS2 : ‖ε • S‖ ^ 2 ≤ 64 * δ ^ 2 := by nlinarith [norm_nonneg (ε • S)]
  have key : retract r₀ (sixAvg P U) - NormedSpace.exp (ε • S) =
      (retract r₀ (sixAvg P U) - sixAvg P U) + e + (lin - ε • S) -
        (NormedSpace.exp (ε • S) - 1 - ε • S) := by
    simp only [e]; abel
  rw [key]
  calc _ ≤ ‖retract r₀ (sixAvg P U) - sixAvg P U‖ + ‖e‖ + ‖lin - ε • S‖ +
        ‖NormedSpace.exp (ε • S) - 1 - ε • S‖ := by
        refine (norm_sub_le _ _).trans ?_
        gcongr
        refine (norm_add_le _ _).trans ?_
        gcongr
        exact norm_add_le _ _
    _ ≤ (2 * (36 * δ ^ 2) + (8 * δ + 32 * δ ^ 2) ^ 2) + 32 * δ ^ 2 + 8 * δ ^ 2 + 64 * δ ^ 2 := by
        gcongr
        · nlinarith [hA]
        · exact hE.trans hS2
    _ ≤ 257 * δ ^ 2 := by
        have h9 : 8 * δ + 32 * δ ^ 2 ≤ 9 * δ := by nlinarith
        have h81 : (8 * δ + 32 * δ ^ 2) ^ 2 ≤ (9 * δ) ^ 2 :=
          pow_le_pow_left₀ (by positivity) h9 2
        nlinarith

end Exp

end BlockLinear

namespace BlockLinearKernel

open ChainBlockMap WalkCast BlockLinear

local notation "ℍr" => Quaternion ℝ

/-- **The box block map of the chain, linearised at `U = 1`, for every threshold `0 < r₀ ≤ 1`.**
The block map is `ChainBlockMap.blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)` (retraction
of the weighted average of path products); the linear part of each real-linear component `f` is the
path-kernel operator `Cop (y ↦ 2y) (pathKernel (2^(m+1) L))` applied to `f ∘ a`. -/
theorem blockMap_exp_linear_le_one (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (hr1 : r₀ ≤ 1)
    (m : ℕ) (a : BoxWalk.BoxLk L (m + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk L m) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx L m b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ))
        b.1 b.2 := by
  rw [BoxWalk.boxMap_eq L hr]
  exact ⟨retract_sixAvg_exp_le_one _ (pathsCast_length _ _ _ b) hr hr1 a ha hM0 hM hε hεM,
    fun f => colour_kernel _ (((BoxWalk.double L m).compLeft (Fin 4)) b.1) b.2 a f⟩

/-- The threshold `r₀ = 1` (the retraction is the identity on the closed unit ball). -/
theorem blockMap_exp_linear_r1 (L : ℕ) [NeZero L] (m : ℕ)
    (a : BoxWalk.BoxLk L (m + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk L m) :
    ‖(blockMap 1 one_pos (BoxWalk.boxPaths L) (BoxWalk.boxW L) m (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx L m b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx L m b) a) : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((f (a (y, ν)) : ℝ) : ℂ))
        b.1 b.2 :=
  blockMap_exp_linear_le_one L one_pos le_rfl m a ha hM0 hM hε hεM b

/-- At `r₀ = 1` the retraction fixes every quaternion of norm `≤ 1`. -/
theorem retract_one_of_norm_le {q : ℍr} (hq : ‖q‖ ≤ 1) : retract 1 q = q := by
  simp [retract, max_eq_right hq]

/-- All hypotheses of `blockMap_exp_linear_r1` hold: `L = 1`, `m = 0`, `a ≡ i`, `ε = 1/32`. -/
theorem blockMap_exp_linear_r1_example (b : BoxWalk.BoxLk 1 0) :
    ‖(blockMap 1 one_pos (BoxWalk.boxPaths 1) (BoxWalk.boxW 1) 0
        (expCfg (fun _ => unitI) (fun _ => unitI_re) (1 / 32)) b : ℍr) -
        NormedSpace.exp ((1 / 32 : ℝ) • sixSgn (BoxWalk.boxPathsIdx 1 0 b) fun _ => unitI)‖ ≤
      257 * ((1 / 32 : ℝ) * 1) ^ 2 ∧ 257 * ((1 / 32 : ℝ) * 1) ^ 2 < 2 :=
  ⟨(blockMap_exp_linear_r1 1 0 (fun _ => unitI) (fun _ => unitI_re)
      (M := 1) (ε := 1 / 32) zero_le_one (fun _ => le_of_eq unitI_norm) (by norm_num)
      (by norm_num) b).1, by norm_num⟩

/-- **Degenerate field** for every `0 < r₀ ≤ 1`: the block value of `U ≡ 1` is `1`. -/
theorem blockMap_zero_field_le_one (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (hr1 : r₀ ≤ 1)
    (m : ℕ) (ε : ℝ) (hε : 0 ≤ ε) (b : BoxWalk.BoxLk L m) :
    (blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m
      (expCfg (fun _ => (0 : ℍr)) (fun _ => rfl) ε) b : ℍr) = 1 := by
  have h := (blockMap_exp_linear_le_one L hr hr1 m (fun _ => (0 : ℍr)) (fun _ => rfl) (M := 0)
    (ε := ε) le_rfl (fun _ => by simp) hε (by simp) b).1
  rw [sixSgn_zero, smul_zero, NormedSpace.exp_zero] at h
  have h0 : ‖(blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) m
      (expCfg (fun _ => (0 : ℍr)) (fun _ => rfl) ε) b : ℍr) - 1‖ = 0 :=
    le_antisymm (by simpa using h) (norm_nonneg _)
  exact sub_eq_zero.1 (norm_eq_zero.1 h0)

section Levels

variable (N : ℕ) [NeZero N] (j : ℕ)

/-- **Level `j` of the stage push is the linearised box block map at level `j`, for every
threshold `0 < r₀ ≤ 1`.** -/
theorem level_linearised_le_one {r₀ : ℝ} (hr : 0 < r₀) (hr1 : r₀ ≤ 1)
    (a : BoxWalk.BoxLk N (j + 1) → ℍr) (ha : ∀ ℓ, (a ℓ).re = 0) {M ε : ℝ} (hM0 : 0 ≤ M)
    (hM : ∀ ℓ, ‖a ℓ‖ ≤ M) (hε : 0 ≤ ε) (hεM : ε * M ≤ 1 / 32) (b : BoxWalk.BoxLk N j) :
    ‖(blockMap r₀ hr (BoxWalk.boxPaths N) (BoxWalk.boxW N) j (expCfg a ha ε) b : ℍr) -
        NormedSpace.exp (ε • sixSgn (BoxWalk.boxPathsIdx N j b) a)‖ ≤ 257 * (ε * M) ^ 2 ∧
    ∀ f : ℍr →ₗ[ℝ] ℝ, ((f (sixSgn (BoxWalk.boxPathsIdx N j b) a) : ℝ) : ℂ) =
      TorusFourier.Cop (TorusFourier.betaT 4 (LatticePush.fine j N))
        (LatticeTorus.pathKernel (2 * LatticePush.fine j N))
        (fun y ν => ((f (a ((siteMap (eF N j)).symm y, ν)) : ℝ) : ℂ))
        (siteMap (eC N j) b.1) b.2 := by
  obtain ⟨h1, h2⟩ := blockMap_exp_linear_le_one N hr hr1 j a ha hM0 hM hε hεM b
  refine ⟨h1, fun f => ?_⟩
  rw [h2 f]
  have := cop_transport (eC N j) (eF N j) (BoxWalk.double N j)
    (TorusFourier.dbl (LatticePush.fine j N)) (double_intertwine N j)
    (fun y ν => ((f (a ((siteMap (eF N j)).symm y, ν)) : ℝ) : ℂ)) b.1 b.2
  simp only [Equiv.symm_apply_apply] at this
  exact this

end Levels

end BlockLinearKernel

namespace LatticePush

/-- `fine (m + j) L = fine m (fine j L)` (both are `2^(m+j) L`). -/
theorem fine_add : ∀ (j m L : ℕ), fine (m + j) L = fine m (fine j L)
  | 0, _, _ => rfl
  | j + 1, m, L => fine_add j m (2 * L)

/-- Transport of a stage operator along an equality of torus sides. -/
def castOp {p q : ℕ} (h : p = q) (T : Fld p → Fld p) : Fld q → Fld q := h ▸ T

/-- **`pushOp` splits**: `m + j` steps from `L` are `j` steps from `L` after `m` steps from
`fine j L`. -/
theorem pushOp_add : ∀ (j m L : ℕ) [NeZero L] (T : Fld (fine (m + j) L) → Fld (fine (m + j) L)),
    pushOp (m + j) L T = pushOp j L (pushOp m (fine j L) (castOp (fine_add j m L) T))
  | 0, _, _, _, _ => rfl
  | j + 1, m, L, _, T => by
      show stepOp L (pushOp (m + j) (2 * L) T) =
        stepOp L (pushOp j (2 * L) (pushOp m (fine j (2 * L)) (castOp (fine_add j m (2 * L)) T)))
      rw [pushOp_add j m (2 * L) T]

/-- **The `j`-th step of `pushOp` is `stepOp (fine j L)`**, for every number of steps
`(k + 1) + j`: the steps `0, …, j − 1` come after it and the steps `j + 1, …` before it. -/
theorem pushOp_stage (j k L : ℕ) [NeZero L]
    (T : Fld (fine ((k + 1) + j) L) → Fld (fine ((k + 1) + j) L)) :
    pushOp ((k + 1) + j) L T =
      pushOp j L (stepOp (fine j L)
        (pushOp k (2 * fine j L) (castOp (fine_add j (k + 1) L) T))) :=
  pushOp_add j (k + 1) L T

/-- The stage covariance `stageCov ((k + 1) + j) N`: its `j`-th step is `stepOp (fine j N)`. -/
theorem stageCov_stage (j k N : ℕ) [NeZero N] :
    stageCov ((k + 1) + j) N =
      pushOp j N (stepOp (fine j N)
        (pushOp k (2 * fine j N) (castOp (fine_add j (k + 1) N) (freeCov (fine ((k + 1) + j) N))))) :=
  pushOp_stage j k N _

end LatticePush

#print axioms BlockLinear.retract_one_add_le_one
#print axioms BlockLinearKernel.blockMap_exp_linear_le_one
#print axioms BlockLinearKernel.blockMap_exp_linear_r1_example
#print axioms BlockLinearKernel.blockMap_zero_field_le_one
#print axioms BlockLinearKernel.level_linearised_le_one
#print axioms LatticePush.pushOp_stage
#print axioms LatticePush.stageCov_stage
