import Mathlib

/-!
# The Schur test on finite sums

`schur_finset`: if the rows of `K` have `Σ_b |K x b| ≤ R` and the columns `Σ_x |K x b| ≤ C`, then
`Σ_x (Σ_b K x b · a b)² ≤ R · C · Σ_b (a b)²`. (Used for the λ-norm of the minimal lift of block data:
rows and columns of the lift kernel and of its gradient are bounded by the decay `|ρ_L|^{|b|}`.)
-/

open Finset

namespace SchurFin

theorem weighted_cs {κ : Type*} (S : Finset κ) (w a : κ → ℝ) (hw : ∀ b ∈ S, 0 ≤ w b) :
    (∑ b ∈ S, w b * |a b|) ^ 2 ≤ (∑ b ∈ S, w b) * ∑ b ∈ S, w b * a b ^ 2 := by
  have h := sum_mul_sq_le_sq_mul_sq S (fun b => Real.sqrt (w b)) (fun b => Real.sqrt (w b) * |a b|)
  have e1 : ∀ b ∈ S, Real.sqrt (w b) * (Real.sqrt (w b) * |a b|) = w b * |a b| := by
    intro b hb; rw [← mul_assoc, Real.mul_self_sqrt (hw b hb)]
  have e2 : ∀ b ∈ S, Real.sqrt (w b) ^ 2 = w b := fun b hb => Real.sq_sqrt (hw b hb)
  have e3 : ∀ b ∈ S, (Real.sqrt (w b) * |a b|) ^ 2 = w b * a b ^ 2 := by
    intro b hb; rw [mul_pow, Real.sq_sqrt (hw b hb), sq_abs]
  rw [sum_congr rfl e1, sum_congr rfl e2, sum_congr rfl e3] at h
  exact h

/-- **Schur test.** -/
theorem schur_finset {ι κ : Type*} (X : Finset ι) (S : Finset κ) (K : ι → κ → ℝ) (a : κ → ℝ)
    {R C : ℝ} (hR0 : 0 ≤ R) (hR : ∀ x ∈ X, ∑ b ∈ S, |K x b| ≤ R)
    (hC : ∀ b ∈ S, ∑ x ∈ X, |K x b| ≤ C) :
    ∑ x ∈ X, (∑ b ∈ S, K x b * a b) ^ 2 ≤ R * C * ∑ b ∈ S, a b ^ 2 := by
  have hrow : ∀ x ∈ X, (∑ b ∈ S, K x b * a b) ^ 2 ≤ R * ∑ b ∈ S, |K x b| * a b ^ 2 := by
    intro x hx
    have h1 : |∑ b ∈ S, K x b * a b| ≤ ∑ b ∈ S, |K x b| * |a b| := by
      refine (abs_sum_le_sum_abs _ _).trans (le_of_eq ?_)
      refine sum_congr rfl fun b _ => abs_mul _ _
    have h2 := weighted_cs S (fun b => |K x b|) a (fun b _ => abs_nonneg _)
    have h3 : (∑ b ∈ S, K x b * a b) ^ 2 ≤ (∑ b ∈ S, |K x b| * |a b|) ^ 2 := by
      rw [← sq_abs]; exact pow_le_pow_left₀ (abs_nonneg _) h1 2
    have h4 : 0 ≤ ∑ b ∈ S, |K x b| * a b ^ 2 := sum_nonneg fun _ _ => by positivity
    calc _ ≤ _ := h3
      _ ≤ _ := h2
      _ ≤ R * ∑ b ∈ S, |K x b| * a b ^ 2 := mul_le_mul_of_nonneg_right (hR x hx) h4
  calc ∑ x ∈ X, (∑ b ∈ S, K x b * a b) ^ 2 ≤ ∑ x ∈ X, R * ∑ b ∈ S, |K x b| * a b ^ 2 :=
        sum_le_sum hrow
    _ = R * ∑ b ∈ S, a b ^ 2 * ∑ x ∈ X, |K x b| := by
        rw [← mul_sum, sum_comm]
        congr 1
        refine sum_congr rfl fun b _ => ?_
        rw [mul_sum]; refine sum_congr rfl fun x _ => by ring
    _ ≤ R * ∑ b ∈ S, a b ^ 2 * C := by
        gcongr with b hb
        exact hC b hb
    _ = R * C * ∑ b ∈ S, a b ^ 2 := by rw [← sum_mul]; ring

end SchurFin

#print axioms SchurFin.schur_finset
