import Mathlib

/-!
# The block average of the weight deviation (scalar, one dimension)

Weight `W x = exp(κ ρ(x)/L)` with `ρ` 1-Lipschitz on `ℤ`, block-constant comparison `W_b = W(bL)`.
For any field `z` and any block `b`, with `a_b = (1/L) Σ_{r<L} (W(bL+r) − W_b) z(bL+r)` (the block
average `T((W − W_b) z)` at `b`):
`a_b² ≤ 36 κ² / L · Σ_{r<L} (W(bL+r) z(bL+r))²` for `0 ≤ κ ≤ 1` (`drift_block`), uniformly in `L`.
Summed over blocks (`drift_blocks`): `Σ_{b∈S} a_b² ≤ 36 κ²/L · Σ_{b∈S} Σ_r (W z)²`.
This is the first half of the bound of the constraint drift `δ₊`; the second half (the λ-norm of the
minimal lift of `a`) is not here.
-/

open Finset Real

namespace DriftBlock

/-- The weight `W x = exp(κ ρ(x)/L)`. -/
noncomputable def wt (L : ℕ) (κ : ℝ) (ρ : ℤ → ℝ) (x : ℤ) : ℝ := Real.exp (κ * ρ x / L)

/-- `a_b = (1/L) Σ_{r<L} (W(bL+r) − W(bL)) z(bL+r)`. -/
noncomputable def aB (L : ℕ) (κ : ℝ) (ρ : ℤ → ℝ) (z : ℤ → ℝ) (b : ℤ) : ℝ :=
  (1 / L) * ∑ r ∈ range L, (wt L κ ρ (b * L + r) - wt L κ ρ (b * L)) * z (b * L + r)

theorem wt_dev {L : ℕ} (hL : 0 < L) {κ : ℝ} (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1) {ρ : ℤ → ℝ}
    (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) (b : ℤ) {r : ℕ} (hr : r < L) :
    |wt L κ ρ (b * L + r) - wt L κ ρ (b * L)| ≤ 2 * κ * wt L κ ρ (b * L) ∧
      wt L κ ρ (b * L) ≤ 3 * wt L κ ρ (b * L + r) := by
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL
  set u := κ * ρ (b * L + r) / L - κ * ρ (b * L) / L
  have hu : |u| ≤ κ := by
    have h1 := hρ (b * L + r) (b * L)
    have e0 : ((b * L + r : ℤ) : ℝ) - ((b * L : ℤ) : ℝ) = (r : ℝ) := by push_cast; ring
    rw [e0, abs_of_nonneg (by positivity : (0 : ℝ) ≤ r)] at h1
    have h3 : |ρ (b * L + r) - ρ (b * L)| ≤ L := h1.trans (by exact_mod_cast hr.le)
    have e : u = κ * (ρ (b * L + r) - ρ (b * L)) / L := by simp only [u]; ring
    rw [e, abs_div, abs_mul, abs_of_nonneg hκ0, abs_of_pos hLr, div_le_iff₀ hLr]
    nlinarith [abs_nonneg (ρ (b * L + r) - ρ (b * L))]
  have hW : wt L κ ρ (b * L + r) = wt L κ ρ (b * L) * Real.exp u := by
    simp only [wt, u, ← Real.exp_add]; ring_nf
  have hpos : 0 < wt L κ ρ (b * L) := Real.exp_pos _
  constructor
  · rw [hW, show wt L κ ρ (b * L) * Real.exp u - wt L κ ρ (b * L) =
        wt L κ ρ (b * L) * (Real.exp u - 1) by ring, abs_mul, abs_of_pos hpos]
    have := Real.abs_exp_sub_one_le (hu.trans hκ1)
    nlinarith
  · rw [hW]
    have h1 : Real.exp (-1) ≤ Real.exp u := Real.exp_le_exp.2 (by
      have := neg_abs_le u; linarith)
    have h2 : (1 : ℝ) / 3 ≤ Real.exp (-1) := by
      have := Real.exp_one_lt_d9
      rw [Real.exp_neg, one_div]
      exact inv_anti₀ (Real.exp_pos 1) (by linarith)
    nlinarith

/-- **One block**: `a_b² ≤ 36 κ²/L · Σ_{r<L} (W z)²`. -/
theorem drift_block {L : ℕ} (hL : 0 < L) {κ : ℝ} (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1) {ρ : ℤ → ℝ}
    (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) (z : ℤ → ℝ) (b : ℤ) :
    aB L κ ρ z b ^ 2 ≤
      36 * κ ^ 2 / L * ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2 := by
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL
  set Wb := wt L κ ρ (b * L)
  -- each term is at most `6 κ |W z|`
  have hterm : ∀ r ∈ range L, |(wt L κ ρ (b * L + r) - Wb) * z (b * L + r)| ≤
      6 * κ * |wt L κ ρ (b * L + r) * z (b * L + r)| := by
    intro r hr
    obtain ⟨h1, h2⟩ := wt_dev hL hκ0 hκ1 hρ b (mem_range.1 hr)
    have hWp : 0 < wt L κ ρ (b * L + r) := Real.exp_pos _
    rw [abs_mul, abs_mul, abs_of_pos hWp]
    have hz := abs_nonneg (z (b * L + r))
    calc |wt L κ ρ (b * L + r) - Wb| * |z (b * L + r)| ≤ (2 * κ * Wb) * |z (b * L + r)| :=
          mul_le_mul_of_nonneg_right h1 hz
      _ ≤ (2 * κ * (3 * wt L κ ρ (b * L + r))) * |z (b * L + r)| := by
          gcongr
      _ = _ := by ring
  have hsum : |∑ r ∈ range L, (wt L κ ρ (b * L + r) - Wb) * z (b * L + r)| ≤
      6 * κ * ∑ r ∈ range L, |wt L κ ρ (b * L + r) * z (b * L + r)| := by
    rw [mul_sum]
    exact (abs_sum_le_sum_abs _ _).trans (sum_le_sum hterm)
  -- Cauchy–Schwarz: (Σ |v|)² ≤ L Σ v²
  have hcs : (∑ r ∈ range L, |wt L κ ρ (b * L + r) * z (b * L + r)|) ^ 2 ≤
      L * ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2 := by
    have := sq_sum_le_card_mul_sum_sq (s := range L)
      (f := fun r => |wt L κ ρ (b * L + r) * z (b * L + r)|)
    simpa only [sq_abs, card_range] using this
  unfold aB
  rw [mul_pow, ← sq_abs (∑ r ∈ range L, _)]
  have hS0 : 0 ≤ ∑ r ∈ range L, |wt L κ ρ (b * L + r) * z (b * L + r)| :=
    sum_nonneg fun _ _ => abs_nonneg _
  have h1 : |∑ r ∈ range L, (wt L κ ρ (b * L + r) - Wb) * z (b * L + r)| ^ 2 ≤
      (6 * κ * ∑ r ∈ range L, |wt L κ ρ (b * L + r) * z (b * L + r)|) ^ 2 :=
    pow_le_pow_left₀ (abs_nonneg _) hsum 2
  have h2 : (6 * κ * ∑ r ∈ range L, |wt L κ ρ (b * L + r) * z (b * L + r)|) ^ 2 ≤
      36 * κ ^ 2 * (L * ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2) := by
    rw [mul_pow, mul_pow]; nlinarith [sq_nonneg κ]
  have e : (1 / (L : ℝ)) ^ 2 * (36 * κ ^ 2 * (L * ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2)) =
      36 * κ ^ 2 / L * ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2 := by
    field_simp
  rw [← e]
  exact mul_le_mul_of_nonneg_left (h1.trans h2) (by positivity)

/-- **Summed over any finite set of blocks.** -/
theorem drift_blocks {L : ℕ} (hL : 0 < L) {κ : ℝ} (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1) {ρ : ℤ → ℝ}
    (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) (z : ℤ → ℝ) (S : Finset ℤ) :
    ∑ b ∈ S, aB L κ ρ z b ^ 2 ≤
      36 * κ ^ 2 / L * ∑ b ∈ S, ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2 := by
  rw [mul_sum]
  exact sum_le_sum fun b _ => drift_block hL hκ0 hκ1 hρ z b

/-- The hypotheses are met: `ρ x = |x|` is 1-Lipschitz. -/
theorem abs_lipschitz : ∀ x y : ℤ, |((|x| : ℤ) : ℝ) - ((|y| : ℤ) : ℝ)| ≤ |(x : ℝ) - y| := by
  intro x y
  rw [Int.cast_abs, Int.cast_abs]
  exact abs_abs_sub_abs_le_abs_sub _ _

end DriftBlock

#print axioms DriftBlock.drift_block
#print axioms DriftBlock.drift_blocks
#print axioms DriftBlock.abs_lipschitz
