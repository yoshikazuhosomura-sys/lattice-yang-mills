import Lift.LiftNorm1
import Lift.Periodic1

/-!
# The minimiser on the periodic chain is the periodisation of `liftF`

Periodic chain of `B ≥ 1` blocks of length `L ≥ 2` (period `P = B·L`), constraint: block sums
`L·[B ∣ b]` (block averages `1` on the blocks `≡ 0 mod B`, `0` elsewhere).
* `liftPer B L x = Σ'_{n∈ℤ} liftF L (x − n·(B·L))` (absolutely summable: `summable_shift`);
* `liftPer_periodic`, `liftPer_kkt` (one multiplier per block), `liftPer_blocks`;
* `kkt_local_min`: any function with one multiplier per block is a local minimiser;
* `liftPer_unique`: a periodic local minimiser with block sums `L·[B ∣ b]` is `liftPer B L`.
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem summable_geo_int {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) :
    Summable (fun n : ℤ => q ^ n.natAbs) := by
  apply Summable.of_nat_of_neg
  · simpa using summable_geometric_of_lt_one hq0 hq1
  · simpa using summable_geometric_of_lt_one hq0 hq1

theorem pow_tsub_le {q : ℝ} (hq0 : 0 < q) (hq1 : q ≤ 1) (a b : ℕ) :
    q ^ (a - b) ≤ q ^ a / q ^ b := by
  rw [le_div_iff₀ (pow_pos hq0 b), ← pow_add]
  exact pow_le_pow_of_le_one hq0.le hq1 (by omega)

theorem summable_shift (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (x : ℤ) :
    Summable (fun n : ℤ => liftF L (x - n * (B * L))) := by
  have hL0 : 0 < L := by omega
  set c := x / (L : ℤ)
  have hq0 : (0 : ℝ) < 27 / 100 := by norm_num
  refine Summable.of_norm_bounded (g := fun n : ℤ => 7 * ((27 / 100 : ℝ) ^ n.natAbs / (27 / 100) ^ c.natAbs))
    ((summable_geo_int hq0.le (by norm_num)).div_const _ |>.mul_left 7) (fun n => ?_)
  have h := liftF_decay hL (x - n * (B * L))
  rw [show x - n * ((B : ℤ) * L) = x - (n * B) * L by ring, div_sub_block hL0] at h
  rw [Real.norm_eq_abs, show x - n * ((B : ℤ) * L) = x - (n * B) * L by ring]
  refine h.trans ?_
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  have hk : n.natAbs - c.natAbs ≤ (c - n * B).natAbs := by
    have : n.natAbs ≤ (n * B).natAbs := by
      rw [Int.natAbs_mul]; exact Nat.le_mul_of_pos_right _ (by simpa using hB)
    have := Int.natAbs_sub_le c (c - n * B)
    rw [show c - (c - n * B) = n * B by ring] at this
    omega
  calc (27 / 100 : ℝ) ^ (c - n * B).natAbs ≤ (27 / 100 : ℝ) ^ (n.natAbs - c.natAbs) :=
        pow_le_pow_of_le_one hq0.le (by norm_num) hk
    _ ≤ _ := pow_tsub_le hq0 (by norm_num) _ _

/-- The periodisation of `liftF` with period `B·L`. -/
noncomputable def liftPer (B L : ℕ) (x : ℤ) : ℝ := ∑' n : ℤ, liftF L (x - n * (B * L))

theorem liftPer_periodic (B : ℕ) : Function.Periodic (liftPer B L) ((B : ℤ) * L) := by
  intro x
  unfold liftPer
  conv_rhs => rw [← (Equiv.subRight (1 : ℤ)).tsum_eq]
  refine tsum_congr fun n => ?_
  simp only [Equiv.subRight_apply]
  congr 1; ring

/-- **KKT** for the periodisation. -/
theorem liftPer_kkt (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) :
    ∃ ν : ℤ → ℝ, ∀ x, liftPer B L (x + 1) + liftPer B L (x - 1) - 2 * liftPer B L x = -ν (x / (L : ℤ)) := by
  have hL0 : 0 < L := by omega
  refine ⟨fun c => -(liftPer B L (c * L + 1) + liftPer B L (c * L - 1) - 2 * liftPer B L (c * L)), fun x => ?_⟩
  -- term by term: the Laplacian of the n-th shift is `−μ(⌊x/L⌋ − nB)`, which depends on the block only
  have hterm : ∀ y : ℤ, liftPer B L (y + 1) + liftPer B L (y - 1) - 2 * liftPer B L y =
      ∑' n : ℤ, -muK L (y / (L : ℤ) - n * B) := by
    intro y
    unfold liftPer
    rw [← (summable_shift hL hB (y + 1)).tsum_add (summable_shift hL hB (y - 1)),
      ← tsum_mul_left, ← ((summable_shift hL hB (y + 1)).add (summable_shift hL hB (y - 1))).tsum_sub
        ((summable_shift hL hB y).mul_left 2)]
    refine tsum_congr fun n => ?_
    have h := liftF_kkt hL (y - n * (B * L))
    rw [show y - n * ((B : ℤ) * L) = y - (n * B) * L by ring, div_sub_block hL0] at h
    rw [show y + 1 - n * ((B : ℤ) * L) = y - n * B * L + 1 by ring,
      show y - 1 - n * ((B : ℤ) * L) = y - n * B * L - 1 by ring,
      show y - n * ((B : ℤ) * L) = y - n * B * L by ring]
    exact h
  have hc : (x / (L : ℤ)) * L / (L : ℤ) = x / L := by
    simpa using div_block hL0 (x / L) 0 le_rfl (by exact_mod_cast hL0)
  rw [hterm x, neg_neg, hterm, hc]

/-- **The constraint** for the periodisation: block sums `L·[B ∣ b]`. -/
theorem liftPer_blocks (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (b : ℤ) :
    ∑ r ∈ range L, liftPer B L (b * L + r) = L * (if (B : ℤ) ∣ b then 1 else 0) := by
  have hL0 : 0 < L := by omega
  unfold liftPer
  rw [← Summable.tsum_finsetSum (f := fun (r : ℕ) (n : ℤ) => liftF L (b * L + r - n * (B * L)))
    (fun r _ => summable_shift hL hB (b * L + r))]
  have e : ∀ n : ℤ, ∑ r ∈ range L, liftF L (b * L + r - n * (B * L)) = L * zK (b - n * B) := by
    intro n
    rw [← liftF_blocks hL0 (b - n * B)]
    refine sum_congr rfl fun r _ => ?_
    congr 1; ring
  rw [tsum_congr e, tsum_mul_left]
  congr 1
  unfold zK
  split_ifs with hd
  · obtain ⟨k, hk⟩ := hd
    rw [tsum_eq_single k (fun n hn => by
      rw [if_neg]; intro h; apply hn
      have : (n - k) * B = 0 := by linarith
      rcases mul_eq_zero.1 this with h1 | h1
      · linarith
      · exact absurd h1 (by exact_mod_cast hB.ne'))]
    rw [if_pos (by rw [hk]; ring)]
  · have h0 : ∀ n : ℤ, (if b - n * B = 0 then (1 : ℝ) else 0) = 0 :=
      fun n => if_neg fun h => hd ⟨n, by linarith⟩
    rw [tsum_congr h0, tsum_zero]

/-- Any function with one multiplier per block is a local minimiser. -/
theorem kkt_local_min (hL : 2 ≤ L) (g ν : ℤ → ℝ)
    (hk : ∀ x, g (x + 1) + g (x - 1) - 2 * g x = -ν (x / (L : ℤ))) : LocalMin L g := by
  have hL0 : 0 < L := by omega
  intro R h hsupp hblk
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  have h2RL : (2 : ℤ) * R * L = 2 * ((R : ℤ) * L) := by ring
  have he := energy_general (L := L) R g h (hsupp _ (Or.inl (by omega)))
    (hsupp _ (Or.inr (by push_cast; linarith [h2RL])))
  rw [he]
  have hcross : ∑ i ∈ range (2 * R * L), h (x₀ + (i + 1 : ℕ)) *
      (g (x₀ + (i + 2 : ℕ)) - 2 * g (x₀ + (i + 1 : ℕ)) + g (x₀ + i)) = 0 := by
    have hlap : ∀ i : ℕ, g (x₀ + (i + 2 : ℕ)) - 2 * g (x₀ + (i + 1 : ℕ)) + g (x₀ + i) =
        -ν ((x₀ + (i + 1 : ℕ)) / (L : ℤ)) := by
      intro i
      rw [← hk (x₀ + (i + 1 : ℕ))]
      have e1 : x₀ + ((i + 2 : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) + 1 := by push_cast; ring
      have e2 : x₀ + ((i : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) - 1 := by push_cast; ring
      rw [e1, e2]; ring
    simp only [hlap]
    rw [show 2 * R * L = (2 * R) * L by ring, sum_blocks]
    refine sum_eq_zero fun c _ => ?_
    have hx : ∀ r : ℕ, x₀ + ((c * L + r : ℕ) + 1 : ℕ) = ((c : ℤ) - R) * L + r := by
      intro r; simp only [x₀]; push_cast; ring
    have e : ∀ r ∈ range L, h (x₀ + ((c * L + r + 1 : ℕ) : ℤ)) *
        -ν ((x₀ + ((c * L + r + 1 : ℕ) : ℤ)) / (L : ℤ)) = -ν ((c : ℤ) - R) * h (((c : ℤ) - R) * L + r) := by
      intro r hr
      rw [hx r, div_block hL0 _ r (by positivity) (by exact_mod_cast mem_range.1 hr)]; ring
    rw [sum_congr rfl e, ← mul_sum, hblk, mul_zero]
  rw [hcross, mul_zero, sub_zero]
  have : 0 ≤ energyW L R h := sum_nonneg fun _ _ => sq_nonneg _
  linarith

/-- **The minimiser on the periodic chain is the periodisation of `liftF`.** -/
theorem liftPer_unique (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (g : ℤ → ℝ)
    (hg : Function.Periodic g ((B : ℤ) * L)) (hm : LocalMin L g)
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * (if (B : ℤ) ∣ b then 1 else 0)) :
    g = liftPer B L := by
  have hP : 0 < B * L := Nat.mul_pos hB (by omega)
  obtain ⟨ν, hν⟩ := liftPer_kkt hL hB
  refine periodic_local_min_unique hL hP g (liftPer B L) (by exact_mod_cast hg)
    (by exact_mod_cast liftPer_periodic (L := L) B) hm (kkt_local_min hL _ ν hν) (fun b => ?_)
  rw [hs, liftPer_blocks hL hB]

/-- The class is not empty: `liftPer` is periodic, a local minimiser, and meets the constraint. -/
theorem liftPer_in_class (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) :
    Function.Periodic (liftPer B L) ((B : ℤ) * L) ∧ LocalMin L (liftPer B L) ∧
      ∀ b : ℤ, ∑ r ∈ range L, liftPer B L (b * L + r) = L * (if (B : ℤ) ∣ b then 1 else 0) := by
  obtain ⟨ν, hν⟩ := liftPer_kkt hL hB
  exact ⟨liftPer_periodic B, kkt_local_min hL _ ν hν, liftPer_blocks hL hB⟩

end BlockLiftMin

#print axioms BlockLiftMin.summable_shift
#print axioms BlockLiftMin.liftPer_kkt
#print axioms BlockLiftMin.liftPer_blocks
#print axioms BlockLiftMin.kkt_local_min
#print axioms BlockLiftMin.liftPer_unique
#print axioms BlockLiftMin.liftPer_in_class
