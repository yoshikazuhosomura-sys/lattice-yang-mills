import Lift.PerNorm1
import Lift.DriftBlock1

/-!
# The constraint drift `δ₊` on the periodic chain

Periodic chain of `B ≥ 1` blocks of length `L ≥ 2`; any field `z`, weight `W = exp(κ ρ/L)` with `ρ`
1-Lipschitz (e.g. the distance on the circle of length `B·L`), `W_b = W(bL)`,
`a_b = T((W − W_b) z)_b` (`DriftBlock.aB`) for `b < B`, and the periodic minimal lift
`y = Σ_{b<B} a_b liftPer B L (· − bL)` (block averages `a`, `liftPer_blocks`; the unique periodic
local minimiser, `liftPer_unique`, by linearity).
`per_drift_plus`: over one period,
`Σ_{s<BL} (∇y)² + L⁻² Σ_{s<BL} y² ≤ 36 (35² + 14²)(1 − q)⁻² κ² · L⁻² Σ_{b<B} Σ_{r<L} (W z)(bL + r)²`,
`q = 27/100`, `0 ≤ κ ≤ 1`: `δ₊ ≤ C κ` with `C` independent of `L` and of the period.
-/

namespace BlockLiftMin

open BlockLift Finset DriftBlock

variable {L : ℕ}

theorem per_drift_plus (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) {κ : ℝ} (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1)
    {ρ : ℤ → ℝ} (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) (z : ℤ → ℝ) :
    ∑ s ∈ range (B * L), (∑ b ∈ range B, aB L κ ρ z b * liftPer B L ((s : ℤ) + 1 - b * L) -
        ∑ b ∈ range B, aB L κ ρ z b * liftPer B L ((s : ℤ) - b * L)) ^ 2 +
      (1 / (L : ℝ)) ^ 2 * ∑ s ∈ range (B * L), (∑ b ∈ range B, aB L κ ρ z b * liftPer B L ((s : ℤ) - b * L)) ^ 2 ≤
      36 * (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 * κ ^ 2 *
        ((1 / (L : ℝ)) ^ 2 * ∑ b ∈ range B, ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2) := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  have h1 := per_lamNorm hL hB (fun b => aB L κ ρ z b)
  have h3 := drift_blocks hL0 hκ0 hκ1 hρ z ((range B).image (fun b : ℕ => (b : ℤ)))
  rw [sum_image (fun x _ y _ h => by exact_mod_cast h), sum_image (fun x _ y _ h => by exact_mod_cast h)] at h3
  have hC : 0 ≤ (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L := by positivity
  calc _ ≤ (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ range B, aB L κ ρ z b ^ 2 := h1
    _ ≤ (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L *
        (36 * κ ^ 2 / L * ∑ b ∈ range B, ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2) :=
        mul_le_mul_of_nonneg_left h3 hC
    _ = _ := by field_simp

end BlockLiftMin

#print axioms BlockLiftMin.per_drift_plus
