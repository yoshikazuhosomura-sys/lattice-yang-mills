import Lift.PerLift1

/-!
# Row sums of the periodic minimiser

`per_row_sum`: on the periodic chain of `B ≥ 1` blocks, at a site `r` of block `0`, the row of the
periodic lift over the `B` blocks satisfies
`Σ_{b'<B} |liftPer B L (r − b' L)| ≤ 1 + 10/8 + 2(9/2 + 17/8)(0.27/0.73)` — the same bound as on `ℤ`
(`row_sum_bound`), uniformly in `L ≥ 2` and `B`.
(`liftPer B L (r − b'L)` is the periodic minimiser for the data `δ` at block `b'`, read at `r`, by
translation.)
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem sym_sum (a : ℤ → ℝ) (M : ℕ) :
    ∑ m ∈ Icc (-(M : ℤ)) M, a m = a 0 + ∑ k ∈ range M, (a ((k : ℤ) + 1) + a (-((k : ℤ) + 1))) := by
  induction M with
  | zero => simp
  | succ M ih =>
      have hs : Icc (-((M + 1 : ℕ) : ℤ)) ((M + 1 : ℕ) : ℤ) =
          insert (-((M : ℤ) + 1)) (insert ((M : ℤ) + 1) (Icc (-(M : ℤ)) M)) := by
        ext m; simp only [mem_Icc, mem_insert]; push_cast; omega
      rw [hs, sum_insert (by simp only [mem_insert, mem_Icc]; omega),
        sum_insert (by simp only [mem_Icc]; omega), ih, sum_range_succ]
      ring

/-- Finite sums of `|liftF L (r − m L)|` over any finite set of blocks are at most the row bound. -/
theorem finite_row (hL : 2 ≤ L) (r : ℕ) (hr : r < L) (T : Finset ℤ) :
    ∑ m ∈ T, |liftF L (r - m * L)| ≤ 1 + 10 / 8 + 2 * (9 / 2 + 17 / 8) * ((27 / 100) / (1 - 27 / 100)) := by
  have hL0 : 0 < L := by omega
  obtain ⟨M, hM⟩ : ∃ M : ℕ, T ⊆ Icc (-(M : ℤ)) M := by
    refine ⟨(T.sup fun m => m.natAbs), fun m hm => ?_⟩
    have := le_sup (f := fun m : ℤ => m.natAbs) hm
    rw [mem_Icc]; constructor <;> omega
  have h1 : ∑ m ∈ T, |liftF L (r - m * L)| ≤ ∑ m ∈ Icc (-(M : ℤ)) M, |liftF L (r - m * L)| :=
    sum_le_sum_of_subset_of_nonneg hM fun _ _ _ => abs_nonneg _
  refine h1.trans ?_
  rw [sym_sum (fun m => |liftF L (r - m * L)|)]
  have hb := row_sum_bound hL (off_abs hL0 r hr) M
  have e : ∀ m : ℤ, liftF L (r - m * L) = kerE L (off L r) m := by
    intro m; rw [kerE_eq_liftF hL0 r hr]; congr 1; ring
  simp only [e]
  exact hb

/-- **Row sums of the periodic minimiser.** -/
theorem per_row_sum (hL : 2 ≤ L) {B : ℕ} (hB : 0 < B) (r : ℕ) (hr : r < L) :
    ∑ b ∈ range B, |liftPer B L (r - b * L)| ≤
      1 + 10 / 8 + 2 * (9 / 2 + 17 / 8) * ((27 / 100) / (1 - 27 / 100)) := by
  -- each term: |Σ' n f| ≤ Σ' n |f|
  have hs : ∀ b : ℕ, Summable (fun n : ℤ => |liftF L ((r : ℤ) - b * L - n * (B * L))|) :=
    fun b => (summable_shift hL hB (r - b * L)).abs
  have h1 : ∀ b ∈ range B, |liftPer B L (r - b * L)| ≤
      ∑' n : ℤ, |liftF L ((r : ℤ) - b * L - n * (B * L))| := by
    intro b _
    unfold liftPer
    exact norm_tsum_le_tsum_norm (f := fun n : ℤ => liftF L ((r : ℤ) - b * L - n * (B * L))) (hs b)
  refine (sum_le_sum h1).trans ?_
  rw [← Summable.tsum_finsetSum (f := fun (b : ℕ) (n : ℤ) => |liftF L ((r : ℤ) - b * L - n * (B * L))|)
    (fun b _ => hs b)]
  -- every finite partial sum is a sum over distinct blocks `b + nB`
  refine tsum_le_of_sum_le' (by positivity) (fun T => ?_)
  have e : ∑ n ∈ T, ∑ b ∈ range B, |liftF L ((r : ℤ) - b * L - n * (B * L))| =
      ∑ m ∈ (T ×ˢ range B).image (fun p : ℤ × ℕ => (p.2 : ℤ) + p.1 * B), |liftF L (r - m * L)| := by
    rw [sum_image (fun p hp q hq hpq => by
      simp only [mem_coe, mem_product, mem_range] at hp hq
      have hB' : (0 : ℤ) < B := by exact_mod_cast hB
      have h1 : ((p.2 : ℤ) - q.2) = (q.1 - p.1) * B := by linarith
      have h2 : |(p.2 : ℤ) - q.2| < B := by rw [abs_lt]; constructor <;> omega
      rw [h1, abs_mul, abs_of_pos hB'] at h2
      have h3 : |q.1 - p.1| < 1 := by
        by_contra hc
        have hc' := not_lt.1 hc
        nlinarith
      have h4 : q.1 = p.1 := by rw [abs_lt] at h3; omega
      have h5 : (p.2 : ℤ) = q.2 := by rw [h4, sub_self, zero_mul] at h1; linarith
      exact Prod.ext h4.symm (by exact_mod_cast h5))]
    rw [sum_product]
    refine sum_congr rfl fun n _ => sum_congr rfl fun b _ => ?_
    congr 2; ring
  rw [e]
  exact finite_row hL r hr _

end BlockLiftMin

#print axioms BlockLiftMin.finite_row
#print axioms BlockLiftMin.per_row_sum
