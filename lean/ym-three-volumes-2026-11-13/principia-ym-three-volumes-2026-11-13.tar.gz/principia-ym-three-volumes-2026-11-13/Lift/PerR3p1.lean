import Lift.PerDrift1
import Five.Drift1

/-!
# `hR3p` of the one-step theorem on the periodic chain (scalar, one dimension)

On functions `ℤ → ℝ` (the periodic chain of `B` blocks of length `L` is read over one period
`P = B·L`): block average `T y b = (1/L) Σ_{r<L} y(bL + r)` (`b : Fin B`), the periodic minimal
lift `Ef z = Σ_b z_b liftPer B L (· − bL)` (a right inverse of `T`, `T_Ef`), the weight
`W = exp(κρ/L)` and its block-constant comparison `W_b(x) = W(⌊x/L⌋ L)`, and the λ-norm over one
period `N y = √(Σ_{s<P} (y(s+1) − y(s))² + L⁻² Σ_{s<P} y(s)²)`.
`per_hR3p`: for `0 ≤ κ ≤ 1`, every `y` with `T(W⁻¹ y) = 0` has an `s` with `T s = 0` and
`N(y − s) ≤ δ₊ N(y)`, `δ₊ = √(36 (35² + 14²)) (1 − 27/100)⁻¹ κ` — the hypothesis `hR3p` of
`thmR_form` in this setting (via `Drift.R3p_of_lift`).
-/

namespace PerR3

open BlockLift BlockLiftMin Finset DriftBlock

variable (B L : ℕ) (κ : ℝ) (ρ : ℤ → ℝ)

/-- Block averages on the `B` blocks. -/
noncomputable def T : (ℤ → ℝ) →ₗ[ℝ] (Fin B → ℝ) where
  toFun y b := (1 / L) * ∑ r ∈ range L, y ((b : ℕ) * L + r)
  map_add' y y' := by funext b; simp [sum_add_distrib, mul_add]
  map_smul' c y := by funext b; simp [mul_sum]; refine sum_congr rfl fun r _ => by ring

/-- The periodic minimal lift. -/
noncomputable def Ef : (Fin B → ℝ) →ₗ[ℝ] (ℤ → ℝ) where
  toFun z x := ∑ b : Fin B, z b * liftPer B L (x - (b : ℕ) * L)
  map_add' z z' := by funext x; simp [add_mul, sum_add_distrib]
  map_smul' c z := by funext x; simp [mul_sum, mul_assoc]

/-- Multiplication by a function. -/
noncomputable def mulOp (f : ℤ → ℝ) : (ℤ → ℝ) →ₗ[ℝ] (ℤ → ℝ) where
  toFun y x := f x * y x
  map_add' y y' := by funext x; simp [mul_add]
  map_smul' c y := by funext x; simp; ring

noncomputable def Wop : (ℤ → ℝ) →ₗ[ℝ] (ℤ → ℝ) := mulOp (wt L κ ρ)
noncomputable def Winv : (ℤ → ℝ) →ₗ[ℝ] (ℤ → ℝ) := mulOp (fun x => (wt L κ ρ x)⁻¹)
noncomputable def Wb : (ℤ → ℝ) →ₗ[ℝ] (ℤ → ℝ) := mulOp (fun x => wt L κ ρ ((x / (L : ℤ)) * L))
noncomputable def D : (Fin B → ℝ) →ₗ[ℝ] (Fin B → ℝ) where
  toFun z b := wt L κ ρ (((b : ℕ) : ℤ) * L) * z b
  map_add' z z' := by funext b; simp [mul_add]
  map_smul' c z := by funext b; simp; ring

/-- The λ-norm over one period. -/
noncomputable def N (y : ℤ → ℝ) : ℝ :=
  Real.sqrt (∑ s ∈ range (B * L), (y ((s : ℤ) + 1) - y s) ^ 2 + (1 / (L : ℝ)) ^ 2 * ∑ s ∈ range (B * L), y s ^ 2)

variable {B L κ ρ}

theorem T_Ef (hL : 2 ≤ L) (hB : 0 < B) (z : Fin B → ℝ) : T B L (Ef B L z) = z := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  funext b
  simp only [T, Ef, LinearMap.coe_mk, AddHom.coe_mk]
  rw [sum_comm]
  have e : ∀ b' : Fin B, ∑ r ∈ range L, z b' * liftPer B L ((b : ℕ) * L + r - (b' : ℕ) * L) =
      z b' * (L * (if (B : ℤ) ∣ ((b : ℕ) : ℤ) - (b' : ℕ) then 1 else 0)) := by
    intro b'
    rw [← mul_sum, ← liftPer_blocks hL hB]
    congr 1; refine sum_congr rfl fun r _ => ?_
    congr 1; ring
  rw [sum_congr rfl fun b' _ => e b']
  rw [sum_eq_single b (fun b' _ hb' => by
    have hnd : ¬ ((B : ℤ) ∣ ((b : ℕ) : ℤ) - (b' : ℕ)) := by
      rintro ⟨k, hk⟩
      apply hb'
      have h1 := b.isLt; have h2 := b'.isLt
      have hk' : ((b : ℕ) : ℤ) - (b' : ℕ) = B * k := hk
      have : k = 0 := by
        by_contra hk0
        have h3 : (B : ℤ) ≤ |(B : ℤ) * k| := by
          rw [abs_mul, abs_of_pos (by exact_mod_cast hB : (0 : ℤ) < B)]
          have : (1 : ℤ) ≤ |k| := Int.one_le_abs hk0
          nlinarith
        rw [← hk'] at h3
        have h4 : |((b : ℕ) : ℤ) - (b' : ℕ)| < B := by rw [abs_lt]; constructor <;> omega
        linarith
      subst this
      exact (Fin.ext (by omega)).symm
    simp [hnd]) (fun h => absurd (mem_univ b) h)]
  rw [if_pos ⟨0, by simp⟩]
  field_simp

theorem Wop_Winv (y : ℤ → ℝ) : Wop L κ ρ (Winv L κ ρ y) = y := by
  funext x
  simp only [Wop, Winv, mulOp, LinearMap.coe_mk, AddHom.coe_mk]
  rw [← mul_assoc, mul_inv_cancel₀ (show wt L κ ρ x ≠ 0 from (Real.exp_pos _).ne'), one_mul]

theorem T_Wb (hL : 2 ≤ L) (y : ℤ → ℝ) : T B L (Wb L κ ρ y) = D B L κ ρ (T B L y) := by
  have hL0 : 0 < L := by omega
  funext b
  simp only [T, Wb, D, mulOp, LinearMap.coe_mk, AddHom.coe_mk]
  rw [mul_sum, mul_sum, mul_sum]
  refine sum_congr rfl fun r hr => ?_
  rw [div_block hL0 _ r (by positivity) (by exact_mod_cast mem_range.1 hr)]
  ring

theorem T_dev (hL : 2 ≤ L) (z : ℤ → ℝ) (b : Fin B) :
    T B L ((Wop L κ ρ - Wb L κ ρ) z) b = aB L κ ρ z (b : ℕ) := by
  have hL0 : 0 < L := by omega
  simp only [T, Wop, Wb, mulOp, LinearMap.sub_apply, LinearMap.coe_mk, AddHom.coe_mk, aB, Pi.sub_apply]
  congr 1
  refine sum_congr rfl fun r hr => ?_
  rw [div_block hL0 _ r (by positivity) (by exact_mod_cast mem_range.1 hr)]
  ring

/-- **The drift bound in the form of `Drift.R3p_of_lift`.** -/
theorem per_hδ (hL : 2 ≤ L) (hB : 0 < B) (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1)
    (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) (z : ℤ → ℝ) :
    N B L (Ef B L (T B L ((Wop L κ ρ - Wb L κ ρ) z))) ≤
      (Real.sqrt (36 * (35 ^ 2 + 14 ^ 2)) * (1 - 27 / 100 : ℝ)⁻¹ * κ) * N B L (Wop L κ ρ z) := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  have hEf : ∀ x, Ef B L (T B L ((Wop L κ ρ - Wb L κ ρ) z)) x =
      ∑ b ∈ range B, aB L κ ρ z b * liftPer B L (x - b * L) := by
    intro x
    simp only [Ef, LinearMap.coe_mk, AddHom.coe_mk, T_dev hL]
    exact Fin.sum_univ_eq_sum_range (fun b => aB L κ ρ z b * liftPer B L (x - (b : ℕ) * L)) B
  have hP := per_drift_plus hL hB hκ0 hκ1 hρ z
  -- the weighted sum over the blocks is the sum over one period
  have hblk : ∑ b ∈ range B, ∑ r ∈ range L, (wt L κ ρ (b * L + r) * z (b * L + r)) ^ 2 =
      ∑ s ∈ range (B * L), (Wop L κ ρ z s) ^ 2 := by
    rw [sum_blocks (fun s : ℕ => (Wop L κ ρ z s) ^ 2) B]
    refine sum_congr rfl fun b _ => sum_congr rfl fun r _ => ?_
    simp only [Wop, mulOp, LinearMap.coe_mk, AddHom.coe_mk]; push_cast; ring_nf
  rw [hblk] at hP
  have hN2 : (1 / (L : ℝ)) ^ 2 * ∑ s ∈ range (B * L), (Wop L κ ρ z s) ^ 2 ≤ N B L (Wop L κ ρ z) ^ 2 := by
    unfold N
    rw [Real.sq_sqrt (by positivity)]
    have : 0 ≤ ∑ s ∈ range (B * L), (Wop L κ ρ z ((s : ℤ) + 1) - Wop L κ ρ z s) ^ 2 :=
      sum_nonneg fun _ _ => sq_nonneg _
    linarith
  have hlhs : N B L (Ef B L (T B L ((Wop L κ ρ - Wb L κ ρ) z))) ^ 2 ≤
      36 * (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 * κ ^ 2 * N B L (Wop L κ ρ z) ^ 2 := by
    unfold N
    rw [Real.sq_sqrt (by positivity)]
    simp only [hEf]
    refine hP.trans ?_
    have hc : 0 ≤ 36 * (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 * κ ^ 2 := by positivity
    have := mul_le_mul_of_nonneg_left hN2 hc
    unfold N at this
    exact this
  have hrhs : 0 ≤ Real.sqrt (36 * (35 ^ 2 + 14 ^ 2)) * (1 - 27 / 100 : ℝ)⁻¹ * κ * N B L (Wop L κ ρ z) := by
    unfold N; positivity
  rw [← Real.sqrt_sq (by unfold N; positivity : 0 ≤ N B L (Ef B L (T B L ((Wop L κ ρ - Wb L κ ρ) z)))),
    ← Real.sqrt_sq hrhs]
  apply Real.sqrt_le_sqrt
  have e : (Real.sqrt (36 * (35 ^ 2 + 14 ^ 2)) * (1 - 27 / 100 : ℝ)⁻¹ * κ * N B L (Wop L κ ρ z)) ^ 2 =
      36 * (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 * κ ^ 2 * N B L (Wop L κ ρ z) ^ 2 := by
    rw [mul_pow, mul_pow, mul_pow, Real.sq_sqrt (by norm_num)]
  rw [e]; exact hlhs

/-- **`hR3p` on the periodic chain** (the hypothesis of the one-step theorem `thmR_form`). -/
theorem per_hR3p (hL : 2 ≤ L) (hB : 0 < B) (hκ0 : 0 ≤ κ) (hκ1 : κ ≤ 1)
    (hρ : ∀ x y : ℤ, |ρ x - ρ y| ≤ |(x : ℝ) - y|) :
    ∀ y, T B L (Winv L κ ρ y) = 0 → ∃ s, T B L s = 0 ∧
      N B L (y - s) ≤ (Real.sqrt (36 * (35 ^ 2 + 14 ^ 2)) * (1 - 27 / 100 : ℝ)⁻¹ * κ) * N B L y :=
  Drift.R3p_of_lift (T B L) (Ef B L) (T_Ef hL hB) (Wop L κ ρ) (Winv L κ ρ) (Wb L κ ρ) (D B L κ ρ)
    Wop_Winv (T_Wb hL) (N B L) (fun z _ => per_hδ hL hB hκ0 hκ1 hρ z)

end PerR3

#print axioms PerR3.T_Ef
#print axioms PerR3.per_hδ
#print axioms PerR3.per_hR3p
