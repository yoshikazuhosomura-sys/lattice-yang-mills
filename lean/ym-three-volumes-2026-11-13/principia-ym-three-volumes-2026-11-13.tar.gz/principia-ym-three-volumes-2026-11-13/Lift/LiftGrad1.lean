import Lift.Kkt1

/-!
# The gradient of the one-dimensional minimal lift

`liftF_grad`: at a site `bL + r` (`r < L`) the forward difference of `liftF` is
`β_b − (μ_b/2)(2u + 1)`, `u = r − (L − 1)/2` (also across the block end, by the seam).
`liftF_grad_bound`: `|liftF(x + 1) − liftF(x)| ≤ (35/2) |ρ_L|^{|b|} / L` for `x` in block `b`,
uniformly in `L ≥ 2` (the gradient of the lift is of size `1/L`, decaying with the block distance).
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem liftF_grad (hL : 2 ≤ L) (b : ℤ) (r : ℕ) (hr : r < L) :
    liftF L (b * L + r + 1) - liftF L (b * L + r) =
      beK L b - muK L b / 2 * (2 * off L r + 1) := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  rw [liftF_block hL0 b r (by positivity) (by exact_mod_cast hr)]
  rcases Nat.lt_or_ge (r + 1) L with h | h
  · rw [show b * (L : ℤ) + r + 1 = b * L + ((r + 1 : ℕ) : ℤ) by push_cast; ring,
      liftF_block hL0 b _ (by positivity) (by exact_mod_cast h)]
    simp only [qB, off]; push_cast; ring
  · have hrL : r + 1 = L := by omega
    rw [show b * (L : ℤ) + r + 1 = (b + 1) * L + 0 by
        have : ((r : ℤ) + 1) = L := by exact_mod_cast hrL
        linear_combination this,
      liftF_block hL0 (b + 1) 0 le_rfl hLz, ← seam_right hL (b + 1), show b + 1 - 1 = b by ring]
    have : (L : ℝ) = r + 1 := by exact_mod_cast hrL.symm
    simp only [qB, off]; push_cast; rw [this]; ring

theorem liftF_grad_bound (hL : 2 ≤ L) (b : ℤ) (r : ℕ) (hr : r < L) :
    |liftF L (b * L + r + 1) - liftF L (b * L + r)| ≤ 35 / 2 * |rhoL L| ^ b.natAbs / L := by
  obtain ⟨⟨hA0, hAL⟩, ⟨hB0, hBL⟩, ⟨hm0, hmL⟩⟩ := coeff_bounds hL
  have hL0 : (0 : ℝ) < L := by
    have : (2 : ℝ) ≤ L := by exact_mod_cast hL
    linarith
  have hu : |2 * off L r + 1| ≤ L := by
    have h1 : (r : ℝ) + 1 ≤ L := by exact_mod_cast hr
    have h0 : (0 : ℝ) ≤ r := by positivity
    rw [abs_le]; simp only [off, Int.cast_natCast]; constructor <;> linarith
  rw [liftF_grad hL b r hr]
  set ρn := |rhoL L| ^ b.natAbs with hρn
  have hρn0 : 0 ≤ ρn := by positivity
  rw [le_div_iff₀ hL0]
  by_cases hb : b = 0
  · subst hb
    simp only [beK, muK, if_true, zero_sub, abs_neg, Int.natAbs_zero, pow_zero] at hρn ⊢
    rw [abs_mul, abs_div, abs_of_nonneg hm0, abs_two]
    have := mul_le_mul_of_nonneg_left hu (by positivity : 0 ≤ 2 * cA L * rhoL L / (rhoL L - 1) / 2)
    nlinarith
  · have hbe : |beK L b| = cB L * ρn := by
      unfold beK
      rw [if_neg hb, abs_mul, abs_mul, abs_of_nonneg hB0, abs_pow]
      split_ifs <;> simp [hρn]
    have hmu : |muK L b| = cA L * ρn := by
      unfold muK
      rw [if_neg hb, abs_mul, abs_of_pos hA0, abs_pow]
    calc |beK L b - muK L b / 2 * (2 * off L r + 1)| * L
        ≤ (|beK L b| + |muK L b / 2 * (2 * off L r + 1)|) * L := by
          gcongr; exact abs_sub _ _
      _ = (cB L * ρn + cA L * ρn / 2 * |2 * off L r + 1|) * L := by
          rw [abs_mul, abs_div, hbe, hmu, abs_two]
      _ ≤ (cB L * ρn + cA L * ρn / 2 * L) * L := by gcongr
      _ = ρn * (cB L * L + cA L * (L : ℝ) ^ 2 / 2) := by ring
      _ ≤ ρn * (9 + 17 / 2) := by
          apply mul_le_mul_of_nonneg_left _ hρn0; linarith
      _ = 35 / 2 * ρn := by ring

end BlockLiftMin

#print axioms BlockLiftMin.liftF_grad
#print axioms BlockLiftMin.liftF_grad_bound
