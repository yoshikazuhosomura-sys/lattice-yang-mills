import Lift.LiftOp1
import Lift.LiftGrad1
import Lift.Schur1

/-!
# The λ-norm of the minimal lift of block data (one dimension), uniformly in `L`

For finitely supported block data `a` and any finite window `X ⊆ ℤ`, with `q = 27/100`:
* `lift_l2`: `Σ_{x∈X} (liftOp a x)² ≤ (14/(1−q)) · (14 L/(1−q)) · Σ_b a_b²`;
* `lift_grad_l2`: `Σ_{x∈X} (liftOp a (x+1) − liftOp a x)² ≤ (35/((1−q)L)) · (35/(1−q)) · Σ_b a_b²`;
* `lift_lamNorm`: hence `Σ_X (∇ E a)² + L⁻² Σ_X (E a)² ≤ (35² + 14²)/((1−q)² L) · Σ_b a_b²`.
The constants do not depend on `L`, on the window, or on the support of `a`. Proof: the Schur test
(`SchurFin.schur_finset`) with the decay of the lift `|liftF y| ≤ 7 q^{|⌊y/L⌋|}` and of its gradient
`≤ (35/2) q^{|⌊y/L⌋|}/L`, and the geometric sums over finite sets of integers.
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem geo_nat {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (T : Finset ℕ) :
    ∑ n ∈ T, q ^ n ≤ (1 - q)⁻¹ := by
  rw [← tsum_geometric_of_lt_one hq0 hq1]
  exact (summable_geometric_of_lt_one hq0 hq1).sum_le_tsum T (fun _ _ => pow_nonneg hq0 _)

theorem geo_int {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (c : ℤ) (S : Finset ℤ) :
    ∑ b ∈ S, q ^ (b - c).natAbs ≤ 2 * (1 - q)⁻¹ := by
  rw [← sum_filter_add_sum_filter_not S (fun b => c ≤ b)]
  have h1 : ∑ b ∈ S.filter (fun b => c ≤ b), q ^ (b - c).natAbs ≤ (1 - q)⁻¹ := by
    rw [← sum_image (f := fun n => q ^ n) (g := fun b => (b - c).natAbs)
      (fun x hx y hy hxy => by
        simp only [mem_coe, mem_filter] at hx hy
        simp only at hxy
        omega)]
    exact geo_nat hq0 hq1 _
  have h2 : ∑ b ∈ S.filter (fun b => ¬ c ≤ b), q ^ (b - c).natAbs ≤ (1 - q)⁻¹ := by
    rw [← sum_image (f := fun n => q ^ n) (g := fun b => (b - c).natAbs)
      (fun x hx y hy hxy => by
        simp only [mem_coe, mem_filter] at hx hy
        simp only at hxy
        omega)]
    exact geo_nat hq0 hq1 _
  linarith

/-- Decay of the lift: `|liftF y| ≤ 7 q^{|⌊y/L⌋|}`, `q = 27/100`. -/
theorem liftF_decay (hL : 2 ≤ L) (y : ℤ) : |liftF L y| ≤ 7 * (27 / 100 : ℝ) ^ (y / (L : ℤ)).natAbs := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  have hx0 := Int.ediv_mul_add_emod y L
  have hr0 : 0 ≤ y % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
  have hrL : y % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
  obtain ⟨r, hr⟩ : ∃ r : ℕ, y % (L : ℤ) = r := ⟨(y % (L : ℤ)).toNat, by omega⟩
  have hrL' : r < L := by omega
  have e : liftF L y = kerE L (off L r) (-(y / L)) := by
    rw [kerE_eq_liftF hL0 r hrL', neg_neg, ← hr, hx0]
  rw [e]
  obtain ⟨h0, hb⟩ := kernel_bound hL (off_abs hL0 r hrL')
  obtain ⟨hlo, hhi⟩ := rho_range hL
  have hρ : |rhoL L| ≤ 27 / 100 := by rw [abs_le]; constructor <;> linarith
  by_cases hb0 : -(y / (L : ℤ)) = 0
  · have : y / (L : ℤ) = 0 := by omega
    rw [hb0, this]; simp only [Int.natAbs_zero, pow_zero]; linarith
  · have h := hb _ hb0
    rw [Int.natAbs_neg] at h
    have hp : |rhoL L| ^ (y / (L : ℤ)).natAbs ≤ (27 / 100 : ℝ) ^ (y / (L : ℤ)).natAbs :=
      pow_le_pow_left₀ (abs_nonneg _) hρ _
    have hq0 : 0 ≤ (27 / 100 : ℝ) ^ (y / (L : ℤ)).natAbs := by positivity
    nlinarith

/-- Decay of the gradient of the lift: `≤ (35/2) q^{|⌊y/L⌋|} / L`. -/
theorem liftF_grad_decay (hL : 2 ≤ L) (y : ℤ) :
    |liftF L (y + 1) - liftF L y| ≤ 35 / 2 * (27 / 100 : ℝ) ^ (y / (L : ℤ)).natAbs / L := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  have hx0 := Int.ediv_mul_add_emod y L
  have hr0 : 0 ≤ y % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
  have hrL : y % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
  obtain ⟨r, hr⟩ : ∃ r : ℕ, y % (L : ℤ) = r := ⟨(y % (L : ℤ)).toNat, by omega⟩
  have hrL' : r < L := by omega
  have h := liftF_grad_bound hL (y / L) r hrL'
  rw [← hr, hx0] at h
  obtain ⟨hlo, hhi⟩ := rho_range hL
  have hρ : |rhoL L| ≤ 27 / 100 := by rw [abs_le]; constructor <;> linarith
  have hp : |rhoL L| ^ (y / (L : ℤ)).natAbs ≤ (27 / 100 : ℝ) ^ (y / (L : ℤ)).natAbs :=
    pow_le_pow_left₀ (abs_nonneg _) hρ _
  refine h.trans ?_
  apply div_le_div_of_nonneg_right _ hLr.le
  linarith

theorem div_sub_block (hL : 0 < L) (x b : ℤ) : (x - b * L) / (L : ℤ) = x / L - b := by
  have hL' : (L : ℤ) ≠ 0 := by exact_mod_cast hL.ne'
  rw [sub_eq_add_neg, show -(b * (L : ℤ)) = (-b) * L by ring, Int.add_mul_ediv_right _ _ hL']
  ring

theorem natAbs_swap (c b : ℤ) : (c - b).natAbs = (b - c).natAbs := by
  rw [← Int.natAbs_neg, neg_sub]

/-- Column sums over a window: at most `L` sites per block. -/
theorem col_geo (hL : 0 < L) {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (X : Finset ℤ) (b : ℤ) :
    ∑ x ∈ X, q ^ (x / (L : ℤ) - b).natAbs ≤ L * (2 * (1 - q)⁻¹) := by
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL
  rw [← sum_fiberwise_of_maps_to (s := X) (t := X.image fun x => x / (L : ℤ))
    (g := fun x => x / (L : ℤ)) (fun x hx => mem_image_of_mem _ hx)]
  have hfib : ∀ c ∈ X.image (fun x => x / (L : ℤ)),
      ∑ x ∈ X.filter (fun x => x / (L : ℤ) = c), q ^ (x / (L : ℤ) - b).natAbs ≤
        L * q ^ (c - b).natAbs := by
    intro c _
    have e : ∀ x ∈ X.filter (fun x => x / (L : ℤ) = c), q ^ (x / (L : ℤ) - b).natAbs =
        q ^ (c - b).natAbs := by
      intro x hx; rw [(mem_filter.1 hx).2]
    rw [sum_congr rfl e, sum_const, nsmul_eq_mul]
    apply mul_le_mul_of_nonneg_right _ (pow_nonneg hq0 _)
    have hsub : X.filter (fun x => x / (L : ℤ) = c) ⊆ Icc (c * L) (c * L + L - 1) := by
      intro x hx
      have hc := (mem_filter.1 hx).2
      have hx0 := Int.ediv_mul_add_emod x L
      have hr0 : 0 ≤ x % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
      have hrL : x % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
      rw [hc] at hx0
      rw [mem_Icc]; constructor <;> linarith
    have := card_le_card hsub
    rw [Int.card_Icc] at this
    have h2 : (c * L + L - 1 + 1 - c * L).toNat = L := by
      rw [show c * (L : ℤ) + L - 1 + 1 - c * L = L by ring]; simp
    rw [h2] at this
    exact_mod_cast this
  calc _ ≤ ∑ c ∈ X.image (fun x => x / (L : ℤ)), (L : ℝ) * q ^ (c - b).natAbs := sum_le_sum hfib
    _ = L * ∑ c ∈ X.image (fun x => x / (L : ℤ)), q ^ (c - b).natAbs := by rw [mul_sum]
    _ ≤ L * (2 * (1 - q)⁻¹) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        exact geo_int hq0 hq1 b _

theorem liftOp_eq (z : ℤ →₀ ℝ) (x : ℤ) :
    liftOp L z x = ∑ b ∈ z.support, liftF L (x - b * L) * z b := by
  unfold liftOp Finsupp.sum; exact sum_congr rfl fun b _ => mul_comm _ _

/-- **`Σ_X (E a)² ≤ (14/(1−q))(14 L/(1−q)) Σ a²`.** -/
theorem lift_l2 (hL : 2 ≤ L) (a : ℤ →₀ ℝ) (X : Finset ℤ) :
    ∑ x ∈ X, liftOp L a x ^ 2 ≤
      (14 * (1 - 27 / 100 : ℝ)⁻¹) * (L * (14 * (1 - 27 / 100 : ℝ)⁻¹)) * ∑ b ∈ a.support, a b ^ 2 := by
  have hL0 : 0 < L := by omega
  have hq0 : (0 : ℝ) ≤ 27 / 100 := by norm_num
  have hq1 : (27 / 100 : ℝ) < 1 := by norm_num
  simp only [liftOp_eq]
  refine SchurFin.schur_finset X a.support (fun x b => liftF L (x - b * L)) a (by positivity)
    (fun x _ => ?_) (fun b _ => ?_)
  · calc ∑ b ∈ a.support, |liftF L (x - b * L)| ≤ ∑ b ∈ a.support, 7 * (27 / 100 : ℝ) ^ (b - x / L).natAbs := by
          refine sum_le_sum fun b _ => ?_
          have := liftF_decay hL (x - b * L)
          rwa [div_sub_block hL0, natAbs_swap] at this
      _ = 7 * ∑ b ∈ a.support, (27 / 100 : ℝ) ^ (b - x / L).natAbs := by rw [mul_sum]
      _ ≤ 7 * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by gcongr; exact geo_int hq0 hq1 _ _
      _ = 14 * (1 - 27 / 100 : ℝ)⁻¹ := by ring
  · calc ∑ x ∈ X, |liftF L (x - b * L)| ≤ ∑ x ∈ X, 7 * (27 / 100 : ℝ) ^ (x / L - b).natAbs := by
          refine sum_le_sum fun x _ => ?_
          have := liftF_decay hL (x - b * L)
          rwa [div_sub_block hL0] at this
      _ = 7 * ∑ x ∈ X, (27 / 100 : ℝ) ^ (x / L - b).natAbs := by rw [mul_sum]
      _ ≤ 7 * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by gcongr; exact col_geo hL0 hq0 hq1 X b
      _ = L * (14 * (1 - 27 / 100 : ℝ)⁻¹) := by ring

/-- **`Σ_X (∇ E a)² ≤ (35/((1−q)L))(35/(1−q)) Σ a²`.** -/
theorem lift_grad_l2 (hL : 2 ≤ L) (a : ℤ →₀ ℝ) (X : Finset ℤ) :
    ∑ x ∈ X, (liftOp L a (x + 1) - liftOp L a x) ^ 2 ≤
      (35 * (1 - 27 / 100 : ℝ)⁻¹ / L) * (35 * (1 - 27 / 100 : ℝ)⁻¹) * ∑ b ∈ a.support, a b ^ 2 := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  have hq0 : (0 : ℝ) ≤ 27 / 100 := by norm_num
  have hq1 : (27 / 100 : ℝ) < 1 := by norm_num
  have e : ∀ x, liftOp L a (x + 1) - liftOp L a x =
      ∑ b ∈ a.support, (liftF L (x - b * L + 1) - liftF L (x - b * L)) * a b := by
    intro x
    rw [liftOp_eq, liftOp_eq, ← sum_sub_distrib]
    refine sum_congr rfl fun b _ => ?_
    rw [show x + 1 - b * L = x - b * L + 1 by ring]; ring
  simp only [e]
  refine SchurFin.schur_finset X a.support (fun x b => liftF L (x - b * L + 1) - liftF L (x - b * L)) a
    (by positivity) (fun x _ => ?_) (fun b _ => ?_)
  · calc ∑ b ∈ a.support, |liftF L (x - b * L + 1) - liftF L (x - b * L)|
        ≤ ∑ b ∈ a.support, 35 / 2 * (27 / 100 : ℝ) ^ (b - x / L).natAbs / L := by
          refine sum_le_sum fun b _ => ?_
          have := liftF_grad_decay hL (x - b * L)
          rwa [div_sub_block hL0, natAbs_swap] at this
      _ = 35 / 2 / L * ∑ b ∈ a.support, (27 / 100 : ℝ) ^ (b - x / L).natAbs := by
          rw [mul_sum]; refine sum_congr rfl fun b _ => by ring
      _ ≤ 35 / 2 / L * (2 * (1 - 27 / 100 : ℝ)⁻¹) := by gcongr; exact geo_int hq0 hq1 _ _
      _ = 35 * (1 - 27 / 100 : ℝ)⁻¹ / L := by ring
  · calc ∑ x ∈ X, |liftF L (x - b * L + 1) - liftF L (x - b * L)|
        ≤ ∑ x ∈ X, 35 / 2 * (27 / 100 : ℝ) ^ (x / L - b).natAbs / L := by
          refine sum_le_sum fun x _ => ?_
          have := liftF_grad_decay hL (x - b * L)
          rwa [div_sub_block hL0] at this
      _ = 35 / 2 / L * ∑ x ∈ X, (27 / 100 : ℝ) ^ (x / L - b).natAbs := by
          rw [mul_sum]; refine sum_congr rfl fun x _ => by ring
      _ ≤ 35 / 2 / L * (L * (2 * (1 - 27 / 100 : ℝ)⁻¹)) := by
          gcongr; exact col_geo hL0 hq0 hq1 X b
      _ = 35 * (1 - 27 / 100 : ℝ)⁻¹ := by field_simp

/-- **The λ-norm (`r = 1/L`) of the lift of block data, on any window, is `≤ C/L · Σ a²`** with
`C = (35² + 14²)/(1 − q)²`, uniformly in `L ≥ 2`. -/
theorem lift_lamNorm (hL : 2 ≤ L) (a : ℤ →₀ ℝ) (X : Finset ℤ) :
    ∑ x ∈ X, (liftOp L a (x + 1) - liftOp L a x) ^ 2 + (1 / (L : ℝ)) ^ 2 * ∑ x ∈ X, liftOp L a x ^ 2 ≤
      (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  have h1 := lift_grad_l2 hL a X
  have h2 := lift_l2 hL a X
  have hS : 0 ≤ ∑ b ∈ a.support, a b ^ 2 := sum_nonneg fun _ _ => sq_nonneg _
  have h3 : (1 / (L : ℝ)) ^ 2 * ∑ x ∈ X, liftOp L a x ^ 2 ≤
      (1 / (L : ℝ)) ^ 2 * ((14 * (1 - 27 / 100 : ℝ)⁻¹) * (L * (14 * (1 - 27 / 100 : ℝ)⁻¹)) *
        ∑ b ∈ a.support, a b ^ 2) := mul_le_mul_of_nonneg_left h2 (by positivity)
  have e1 : (1 / (L : ℝ)) ^ 2 * ((14 * (1 - 27 / 100 : ℝ)⁻¹) * (L * (14 * (1 - 27 / 100 : ℝ)⁻¹)) *
        ∑ b ∈ a.support, a b ^ 2) = 14 ^ 2 * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 := by
    field_simp
  have e2 : (35 * (1 - 27 / 100 : ℝ)⁻¹ / L) * (35 * (1 - 27 / 100 : ℝ)⁻¹) * ∑ b ∈ a.support, a b ^ 2 =
      35 ^ 2 * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 := by ring
  rw [e1] at h3; rw [e2] at h1
  have e3 : (35 ^ 2 + 14 ^ 2) * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 =
      35 ^ 2 * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 +
        14 ^ 2 * (1 - 27 / 100 : ℝ)⁻¹ ^ 2 / L * ∑ b ∈ a.support, a b ^ 2 := by ring
  rw [e3]; linarith

end BlockLiftMin

#print axioms BlockLiftMin.lift_l2
#print axioms BlockLiftMin.lift_grad_l2
#print axioms BlockLiftMin.lift_lamNorm
