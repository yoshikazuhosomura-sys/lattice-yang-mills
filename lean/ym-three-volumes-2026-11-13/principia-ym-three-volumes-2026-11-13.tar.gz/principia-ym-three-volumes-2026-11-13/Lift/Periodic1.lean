import Lift.KktUniq1

/-!
# The periodic chain: uniqueness of the constrained minimiser

On the periodic chain of `B` blocks of length `L` (functions on `ℤ` with period `P = B·L`), a
periodic function is bounded, so `kkt_bounded_zero` applies:
* `periodic_bounded`: `|g x| ≤ Σ_{k<P} |g k|`;
* `periodic_kkt_unique`: two periodic functions with one multiplier per block and the same block
  sums are equal;
* `periodic_local_min_unique`: two periodic local minimisers (perturbations supported in windows)
  with the same block sums are equal.
Not stated here: the identification of the periodic minimiser with the periodisation of `liftF`.
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem periodic_bounded {P : ℕ} (hP : 0 < P) (g : ℤ → ℝ) (hg : Function.Periodic g (P : ℤ)) (x : ℤ) :
    |g x| ≤ ∑ k ∈ range P, |g k| := by
  have hPz : (0 : ℤ) < P := by exact_mod_cast hP
  have hx0 := Int.ediv_mul_add_emod x P
  have hr0 : 0 ≤ x % (P : ℤ) := Int.emod_nonneg _ hPz.ne'
  have hrP : x % (P : ℤ) < P := Int.emod_lt_of_pos _ hPz
  obtain ⟨k, hk⟩ : ∃ k : ℕ, x % (P : ℤ) = k := ⟨(x % (P : ℤ)).toNat, by omega⟩
  have e : g x = g k := by
    rw [← hx0, hk, add_comm]; exact hg.int_mul (x / (P : ℤ)) (k : ℤ)
  rw [e]
  exact single_le_sum (f := fun k : ℕ => |g k|) (fun _ _ => abs_nonneg _)
    (mem_range.2 (by omega))

/-- **Uniqueness on the periodic chain** (KKT form). -/
theorem periodic_kkt_unique (hL : 2 ≤ L) {P : ℕ} (hP : 0 < P) (g₁ g₂ : ℤ → ℝ)
    (h₁ : Function.Periodic g₁ (P : ℤ)) (h₂ : Function.Periodic g₂ (P : ℤ)) (ν₁ ν₂ : ℤ → ℝ)
    (hk₁ : ∀ x, g₁ (x + 1) + g₁ (x - 1) - 2 * g₁ x = -ν₁ (x / (L : ℤ)))
    (hk₂ : ∀ x, g₂ (x + 1) + g₂ (x - 1) - 2 * g₂ x = -ν₂ (x / (L : ℤ)))
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g₁ (b * L + r) = ∑ r ∈ range L, g₂ (b * L + r)) : g₁ = g₂ := by
  have hz := kkt_bounded_zero hL (fun x => g₁ x - g₂ x) (fun b => ν₁ b - ν₂ b)
    (fun x => by have := hk₁ x; have := hk₂ x; linarith)
    (fun b => by rw [sum_sub_distrib, hs, sub_self])
    (K := ∑ k ∈ range P, |g₁ k| + ∑ k ∈ range P, |g₂ k|) (fun x => by
      have a1 := periodic_bounded hP g₁ h₁ x
      have a2 := periodic_bounded hP g₂ h₂ x
      calc |g₁ x - g₂ x| ≤ |g₁ x| + |g₂ x| := abs_sub _ _
        _ ≤ _ := by linarith)
  funext x; have := hz x; linarith

/-- **Uniqueness on the periodic chain** (local minimisers). -/
theorem periodic_local_min_unique (hL : 2 ≤ L) {P : ℕ} (hP : 0 < P) (g₁ g₂ : ℤ → ℝ)
    (h₁ : Function.Periodic g₁ (P : ℤ)) (h₂ : Function.Periodic g₂ (P : ℤ))
    (hm₁ : LocalMin L g₁) (hm₂ : LocalMin L g₂)
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g₁ (b * L + r) = ∑ r ∈ range L, g₂ (b * L + r)) : g₁ = g₂ :=
  periodic_kkt_unique hL hP g₁ g₂ h₁ h₂
    (fun b => -(g₁ (b * L + 1) + g₁ (b * L - 1) - 2 * g₁ (b * L)))
    (fun b => -(g₂ (b * L + 1) + g₂ (b * L - 1) - 2 * g₂ (b * L)))
    (fun x => by rw [local_min_kkt hL g₁ hm₁ x]; ring)
    (fun x => by rw [local_min_kkt hL g₂ hm₂ x]; ring) hs

end BlockLiftMin

#print axioms BlockLiftMin.periodic_bounded
#print axioms BlockLiftMin.periodic_kkt_unique
#print axioms BlockLiftMin.periodic_local_min_unique
