import Linz.Kernel1
import Linz.Witness1

/-!
# The covariance of a pushed-forward measure is `C T C†`

* `covForm μ u v = ∫ ⟪u,x⟫⟪v,x⟫ dμ − (∫ ⟪u,x⟫ dμ)(∫ ⟪v,x⟫ dμ)` (the covariance form of a measure on a
  real inner product space). No Gaussian structure is used.
* `covForm_map`: for a continuous linear `C`, `covForm (μ.map C) u v = covForm μ (C† u) (C† v)`.
* `covOp_map`: if `covForm μ u v = ⟪u, T v⟫` for all `u v`, then `covForm (μ.map C) u v =
  ⟪u, (C T C†) v⟫`.
* `covForm_two_point`: for `μ = ½(δ_e + δ_{−e})`, `covForm μ u v = ⟪u,e⟫⟪v,e⟫` (a measure for which
  the hypothesis of `covOp_map` holds with the rank-one `T v = ⟪e,v⟫ e`).
* Lattice form (`lattice_pushCov`): on one colour of the gauge field on the fine box
  `(ℤ/2^(m+1)L)⁴ × Fin 4`, the linear part `blockLin` of the block map at `U = 1`
  (`φ ↦ imI (sixSgn (boxPathsIdx L m b) (φ · i))`) is the path-kernel operator
  `Cop (y ↦ 2y) (pathKernel (2^(m+1) L))`, and it pushes any field measure with covariance `T`
  to one with covariance `C T C†`.
-/

open MeasureTheory
open scoped InnerProductSpace RealInnerProductSpace

namespace PushCov

variable {E F : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E] [CompleteSpace E]
  [MeasurableSpace E] [BorelSpace E]
  [NormedAddCommGroup F] [InnerProductSpace ℝ F] [CompleteSpace F]
  [MeasurableSpace F] [BorelSpace F]

/-- The covariance form of a measure. -/
noncomputable def covForm (μ : Measure E) (u v : E) : ℝ :=
  (∫ x, ⟪u, x⟫ * ⟪v, x⟫ ∂μ) - (∫ x, ⟪u, x⟫ ∂μ) * (∫ x, ⟪v, x⟫ ∂μ)

/-- **Push-forward of the covariance form along a continuous linear map.** -/
theorem covForm_map (μ : Measure E) (C : E →L[ℝ] F) (u v : F) :
    covForm (μ.map C) u v = covForm μ (ContinuousLinearMap.adjoint C u)
      (ContinuousLinearMap.adjoint C v) := by
  have hC : AEMeasurable C μ := C.continuous.aemeasurable
  unfold covForm
  rw [integral_map hC ((continuous_const.inner continuous_id).mul
      (continuous_const.inner continuous_id)).aestronglyMeasurable,
    integral_map hC (continuous_const.inner continuous_id).aestronglyMeasurable,
    integral_map hC (continuous_const.inner continuous_id).aestronglyMeasurable]
  simp only [ContinuousLinearMap.adjoint_inner_left]

/-- **Covariance operator of the push-forward: `C T C†`.** -/
theorem covOp_map (μ : Measure E) (T : E →L[ℝ] E) (hT : ∀ u v, covForm μ u v = ⟪u, T v⟫)
    (C : E →L[ℝ] F) (u v : F) :
    covForm (μ.map C) u v = ⟪u, (C ∘L T ∘L ContinuousLinearMap.adjoint C) v⟫ := by
  rw [covForm_map, hT, ContinuousLinearMap.adjoint_inner_left]
  rfl

/-- A non-degenerate example: `μ = ½(δ_e + δ_{−e})` has covariance `⟪u,e⟫⟪v,e⟫`. -/
theorem covForm_two_point (e u v : E) :
    covForm ((2 : ENNReal)⁻¹ • (Measure.dirac e + Measure.dirac (-e))) u v = ⟪u, e⟫ * ⟪v, e⟫ := by
  unfold covForm
  have hi : ∀ f : E → ℝ, Integrable f (Measure.dirac e) ∧ Integrable f (Measure.dirac (-e)) :=
    fun f => ⟨integrable_dirac (by simp), integrable_dirac (by simp)⟩
  rw [integral_smul_measure, integral_smul_measure, integral_smul_measure,
    integral_add_measure (hi _).1 (hi _).2, integral_add_measure (hi _).1 (hi _).2,
    integral_add_measure (hi _).1 (hi _).2]
  simp only [integral_dirac, inner_neg_right]
  norm_num
  ring

/-- The rank-one operator `v ↦ ⟪e, v⟫ e` represents that covariance. -/
theorem two_point_rep (e : E) (u v : E) :
    covForm ((2 : ENNReal)⁻¹ • (Measure.dirac e + Measure.dirac (-e))) u v =
      ⟪u, ((innerSL ℝ e).smulRight e) v⟫ := by
  rw [covForm_two_point]
  simp only [ContinuousLinearMap.smulRight_apply, innerSL_apply_apply, inner_smul_right]
  rw [real_inner_comm e v]; ring

end PushCov

namespace BlockLinear

open ChainBlockMap
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

variable {L : Type*}

theorem pathSgn_add (a a' : L → ℍr) (γ : List (L × Bool)) :
    pathSgn (a + a') γ = pathSgn a γ + pathSgn a' γ := by
  unfold pathSgn
  rw [← List.sum_map_add]
  congr 1
  refine List.map_congr_left fun s _ => ?_
  split_ifs
  · simp only [Pi.add_apply, neg_add]
  · rfl

theorem pathSgn_smul (c : ℝ) (a : L → ℍr) (γ : List (L × Bool)) :
    pathSgn (c • a) γ = c • pathSgn a γ := by
  induction γ with
  | nil => simp [pathSgn]
  | cons s t ih =>
      simp only [pathSgn, List.map_cons, List.sum_cons] at ih ⊢
      rw [ih]; split_ifs <;> simp only [Pi.smul_apply, smul_neg, smul_add]

theorem sixSgn_add (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (a a' : L → ℍr) :
    sixSgn P (a + a') = sixSgn P a + sixSgn P a' := by
  simp only [sixSgn, pathSgn_add, smul_add, Finset.sum_add_distrib]

theorem sixSgn_smul (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (c : ℝ) (a : L → ℍr) :
    sixSgn P (c • a) = c • sixSgn P a := by
  simp only [sixSgn, pathSgn_smul, Finset.smul_sum]
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  rw [smul_comm]

end BlockLinear

namespace PushCov

open ChainBlockMap BlockLinear BlockLinearKernel
open scoped Quaternion

local notation "ℍr" => Quaternion ℝ

variable (L : ℕ) [NeZero L] (m : ℕ)

/-- The linear part of the box block map at `U = 1` on one colour (`i`) of the field. -/
noncomputable def blockLinFun : (BoxWalk.BoxLk L (m + 1) → ℝ) →ₗ[ℝ] (BoxWalk.BoxLk L m → ℝ) where
  toFun φ b := (sixSgn (BoxWalk.boxPathsIdx L m b) fun ℓ => φ ℓ • unitI).imI
  map_add' φ ψ := by
    funext b
    have : (fun ℓ => (φ + ψ) ℓ • unitI) = (fun ℓ => φ ℓ • unitI) + (fun ℓ => ψ ℓ • unitI) := by
      funext ℓ; simp only [Pi.add_apply, add_smul]
    show (sixSgn _ fun ℓ => (φ + ψ) ℓ • unitI).imI = _
    rw [this, sixSgn_add]; rfl
  map_smul' c φ := by
    funext b
    have : (fun ℓ => (c • φ) ℓ • unitI) = c • (fun ℓ => φ ℓ • unitI) := by
      funext ℓ; simp only [Pi.smul_apply, smul_eq_mul, mul_smul]
    show (sixSgn _ fun ℓ => (c • φ) ℓ • unitI).imI = _
    rw [this, sixSgn_smul]; rfl

/-- The same map between the Euclidean spaces of the fine and coarse fields. -/
noncomputable def blockLin :
    EuclideanSpace ℝ (BoxWalk.BoxLk L (m + 1)) →L[ℝ] EuclideanSpace ℝ (BoxWalk.BoxLk L m) :=
  (EuclideanSpace.equiv (BoxWalk.BoxLk L m) ℝ).symm.toContinuousLinearMap ∘L
    LinearMap.toContinuousLinearMap (blockLinFun L m) ∘L
      (EuclideanSpace.equiv (BoxWalk.BoxLk L (m + 1)) ℝ).toContinuousLinearMap

theorem blockLin_apply (φ : EuclideanSpace ℝ (BoxWalk.BoxLk L (m + 1))) (b : BoxWalk.BoxLk L m) :
    blockLin L m φ b = (sixSgn (BoxWalk.boxPathsIdx L m b) fun ℓ => φ ℓ • unitI).imI := rfl

/-- **The linear part of the block map is the path-kernel operator, and it pushes covariances to
`C T C†`** (one colour of the fine box field; any measure with covariance operator `T`). -/
theorem lattice_pushCov (μ : Measure (EuclideanSpace ℝ (BoxWalk.BoxLk L (m + 1))))
    (T : EuclideanSpace ℝ (BoxWalk.BoxLk L (m + 1)) →L[ℝ] EuclideanSpace ℝ (BoxWalk.BoxLk L (m + 1)))
    (hT : ∀ u v, covForm μ u v = ⟪u, T v⟫) :
    (∀ φ b, ((blockLin L m φ b : ℝ) : ℂ) =
      TorusFourier.Cop ((BoxWalk.double L m).compLeft (Fin 4))
        (LatticeTorus.pathKernel (2 ^ (m + 1) * L)) (fun y ν => ((φ (y, ν) : ℝ) : ℂ)) b.1 b.2) ∧
    ∀ u v, covForm (μ.map (blockLin L m)) u v =
      ⟪u, (blockLin L m ∘L T ∘L ContinuousLinearMap.adjoint (blockLin L m)) v⟫ := by
  refine ⟨fun φ b => ?_, covOp_map μ T hT (blockLin L m)⟩
  have h := (blockMap_linear_colours L m (fun ℓ => φ ℓ • unitI)
    (fun ℓ => by simp [unitI_re]) b).2 0
  rw [blockLin_apply]
  have hc : ∀ q : ℍr, colour 0 q = q.imI := fun _ => rfl
  rw [hc] at h
  rw [h]
  congr 1
  funext y ν
  rw [hc, Quaternion.imI_smul]
  simp [unitI]

end PushCov

#print axioms PushCov.covForm_map
#print axioms PushCov.covOp_map
#print axioms PushCov.covForm_two_point
#print axioms PushCov.two_point_rep
#print axioms PushCov.lattice_pushCov
