import Lift.Kkt1

/-!
# Uniqueness of the one-dimensional constrained minimiser among bounded functions

`d : ℤ → ℝ` with one multiplier per block (`d(x+1) + d(x−1) − 2 d(x) = −ν(⌊x/L⌋)`), zero block
sums, and `|d| ≤ K` is `0` (`kkt_bounded_zero`). The proof: inside a block the gradient drops by
`ν_b` per site; the block sums and the matching of neighbouring blocks give the three-term relation
`(L² − 1)(ν_{b+2} + ν_b) + (4L² + 2) ν_{b+1} = 0` (`nu_rec`); a bounded solution of it is `0`
(`bounded_rec_zero`, from `|ν_{b+2}| ≥ 4|ν_{b+1}| − |ν_b|`); then the gradient is constant and the
block sums force it to `0`.

Consequences:
* `liftF_unique`: a bounded `g` with block sums `L·δ_{b0}` and one multiplier per block is `liftF`.
* `local_min_kkt`: a function whose window energy cannot be lowered by perturbations supported in
  one block with zero block sum has one multiplier per block.
* `bounded_local_min_eq_liftF`, `row_sum_bounded_minimiser`: a bounded local minimiser of the
  constrained problem is `liftF`, and its row sums are bounded uniformly in `L ≥ 2`.
* `liftF_bounded`, `liftF_local_min`: `liftF` itself is bounded and a local minimiser (the class is
  not empty).
-/

namespace BlockLiftMin

open BlockLift Finset

variable {L : ℕ}

theorem div_block (hL : 0 < L) (b : ℤ) (r : ℤ) (h0 : 0 ≤ r) (h1 : r < L) :
    (b * L + r) / (L : ℤ) = b := by
  have hL' : (L : ℤ) ≠ 0 := by exact_mod_cast hL.ne'
  rw [show b * (L : ℤ) + r = r + b * L by ring, Int.add_mul_ediv_right _ _ hL',
    Int.ediv_eq_zero_of_lt h0 h1, zero_add]

section Rec

variable (d ν : ℤ → ℝ)

/-- The gradient entering block `b`. -/
def gIn (b : ℤ) : ℝ := d (b * L) - d (b * L - 1)

theorem grad_in_block (hL : 0 < L)
    (hk : ∀ x, d (x + 1) + d (x - 1) - 2 * d x = -ν (x / (L : ℤ))) (b : ℤ) :
    ∀ r : ℕ, r < L → d (b * L + r + 1) - d (b * L + r) = gIn (L := L) d b - (r + 1) * ν b := by
  intro r
  induction r with
  | zero =>
      intro _
      have h := hk (b * L)
      rw [show b * (L : ℤ) = b * L + 0 by ring, div_block hL b 0 le_rfl (by exact_mod_cast hL)] at h
      simp only [gIn]
      push_cast
      simp only [add_zero] at h ⊢
      linarith
  | succ r ih =>
      intro hr
      have h1 := ih (by omega)
      have h := hk (b * L + (r + 1 : ℕ))
      rw [div_block hL b _ (by positivity) (by exact_mod_cast hr)] at h
      have e1 : b * (L : ℤ) + ((r + 1 : ℕ) : ℤ) + 1 = b * L + ((r + 1 : ℕ) : ℤ) + 1 := rfl
      have e2 : b * (L : ℤ) + ((r + 1 : ℕ) : ℤ) - 1 = b * L + (r : ℤ) := by push_cast; ring
      have e3 : b * (L : ℤ) + ((r + 1 : ℕ) : ℤ) = b * L + (r : ℤ) + 1 := by push_cast; ring
      rw [e2, e3] at h
      rw [e3]
      push_cast at h1 ⊢
      linarith

theorem value_in_block (hL : 0 < L)
    (hk : ∀ x, d (x + 1) + d (x - 1) - 2 * d x = -ν (x / (L : ℤ))) (b : ℤ) :
    ∀ r : ℕ, r ≤ L → d (b * L + r) =
      d (b * L) + r * gIn (L := L) d b - ν b * (r * (r + 1) / 2) := by
  intro r
  induction r with
  | zero => intro _; simp
  | succ r ih =>
      intro hr
      have h1 := ih (by omega)
      have h2 := grad_in_block d ν hL hk b r (by omega)
      have e : b * (L : ℤ) + ((r + 1 : ℕ) : ℤ) = b * L + (r : ℤ) + 1 := by push_cast; ring
      rw [e]
      push_cast at h1 h2 ⊢
      linarith

theorem sum_value (n : ℕ) (a D v : ℝ) :
    ∑ r ∈ range n, (a + (r : ℝ) * D - v * ((r : ℝ) * (r + 1) / 2)) =
      n * a + D * ((n : ℝ) * (n - 1) / 2) - v * (((n : ℝ) - 1) * n * (n + 1) / 6) := by
  induction n with
  | zero => simp
  | succ n ih => rw [sum_range_succ, ih]; push_cast; ring

/-- **The three-term relation of the multipliers.** -/
theorem nu_rec (hL : 2 ≤ L)
    (hk : ∀ x, d (x + 1) + d (x - 1) - 2 * d x = -ν (x / (L : ℤ)))
    (hs : ∀ b : ℤ, ∑ r ∈ range L, d (b * L + r) = 0) (b : ℤ) :
    ((L : ℝ) ^ 2 - 1) * (ν (b + 2) + ν b) + (4 * (L : ℝ) ^ 2 + 2) * ν (b + 1) = 0 := by
  have hL0 : 0 < L := by omega
  have hLr : (0 : ℝ) < L := by exact_mod_cast hL0
  -- the relations R1, R2, R3 at the blocks `c`
  have R1 : ∀ c : ℤ, gIn (L := L) d (c + 1) = gIn (L := L) d c - L * ν c := by
    intro c
    have h := grad_in_block d ν hL0 hk c (L - 1) (by omega)
    have e1 : c * (L : ℤ) + ((L - 1 : ℕ) : ℤ) + 1 = (c + 1) * L := by
      rw [Nat.cast_sub (by omega)]; push_cast; ring
    have e2 : c * (L : ℤ) + ((L - 1 : ℕ) : ℤ) = (c + 1) * L - 1 := by
      rw [Nat.cast_sub (by omega)]; push_cast; ring
    rw [e1, e2] at h
    simp only [gIn] at h ⊢
    rw [h, Nat.cast_sub (by omega)]; push_cast; ring
  have R2 : ∀ c : ℤ, d ((c + 1) * L) =
      d (c * L) + L * gIn (L := L) d c - ν c * ((L : ℝ) * (L + 1) / 2) := by
    intro c
    have h := value_in_block d ν hL0 hk c L le_rfl
    rw [show (c + 1) * (L : ℤ) = c * L + (L : ℕ) by ring, h]
  have R3 : ∀ c : ℤ, (L : ℝ) * d (c * L) + gIn (L := L) d c * ((L : ℝ) * (L - 1) / 2) -
      ν c * (((L : ℝ) - 1) * L * (L + 1) / 6) = 0 := by
    intro c
    have h := hs c
    rw [sum_congr rfl fun r hr => value_in_block d ν hL0 hk c r (mem_range.1 hr).le] at h
    rw [← h, sum_value]
  have key : (L : ℝ) * (((L : ℝ) ^ 2 - 1) * (ν (b + 2) + ν b) + (4 * (L : ℝ) ^ 2 + 2) * ν (b + 1)) = 0 := by
    have r10 := R1 b
    have r11 := R1 (b + 1)
    have r20 := R2 b
    have r21 := R2 (b + 1)
    have r30 := R3 b
    have r31 := R3 (b + 1)
    have r32 := R3 (b + 2)
    rw [show b + 1 + 1 = b + 2 by ring] at r11 r21
    linear_combination (3 * (L : ℝ) ^ 2 + 3 * L) * r10 + (3 * (L : ℝ) ^ 2 - 3 * L) * r11 -
      6 * (L : ℝ) * r20 + 6 * (L : ℝ) * r21 - 6 * r30 + 12 * r31 - 6 * r32
  rcases mul_eq_zero.1 key with h | h
  · exact absurd h hLr.ne'
  · exact h

end Rec

/-! ## A bounded solution of the three-term relation is zero -/

theorem forward_growth (s : ℕ → ℝ) (hf : ∀ k, 4 * s (k + 1) - s k ≤ s (k + 2))
    (hs0 : ∀ k, 0 ≤ s k) (hc : s 0 < s 1) :
    ∀ k : ℕ, s k < s (k + 1) ∧ 2 ^ k * (s 1 - s 0) ≤ s (k + 1) - s k := by
  intro k
  induction k with
  | zero => simp only [pow_zero, one_mul, zero_add]; exact ⟨hc, le_rfl⟩
  | succ k ih =>
      obtain ⟨h1, h2⟩ := ih
      have h := hf k
      have hk0 := hs0 k
      have hδ : 0 < 2 ^ k * (s 1 - s 0) := mul_pos (pow_pos two_pos k) (by linarith)
      rw [pow_succ]
      constructor <;> nlinarith

theorem bounded_no_growth (f : ℤ → ℝ) (hf : ∀ b, 4 * |f (b + 1)| - |f b| ≤ |f (b + 2)|)
    {M : ℝ} (hM : ∀ b, |f b| ≤ M) (c : ℤ) : |f (c + 1)| ≤ |f c| := by
  by_contra hlt
  have hlt := not_le.1 hlt
  set s : ℕ → ℝ := fun k => |f (c + k)| with hsdef
  have hsf : ∀ k, 4 * s (k + 1) - s k ≤ s (k + 2) := by
    intro k
    have := hf (c + k)
    simp only [hsdef]; push_cast
    rw [show c + ((k : ℤ) + 1) = c + k + 1 by ring, show c + ((k : ℤ) + 2) = c + k + 2 by ring]
    exact this
  have hc : s 0 < s 1 := by simp only [hsdef]; push_cast; simpa using hlt
  set δ := s 1 - s 0 with hδ
  have hδ0 : 0 < δ := by linarith
  have hM0 : 0 ≤ M := (abs_nonneg _).trans (hM c)
  obtain ⟨k, hk⟩ := pow_unbounded_of_one_lt (2 * M / δ) (by norm_num : (1 : ℝ) < 2)
  have h := (forward_growth s hsf (fun k => abs_nonneg _) hc k).2
  have hb1 : s (k + 1) ≤ M := hM _
  have hb0 : 0 ≤ s k := abs_nonneg _
  have : 2 ^ k * δ ≤ M := by linarith
  have : 2 * M / δ * δ < 2 ^ k * δ := mul_lt_mul_of_pos_right hk hδ0
  rw [div_mul_cancel₀ _ hδ0.ne'] at this
  linarith

/-- **A bounded solution of `|f(b+2)| ≥ 4|f(b+1)| − |f(b)|` (both directions) is `0`.** -/
theorem bounded_rec_zero (f : ℤ → ℝ) (hf : ∀ b, 4 * |f (b + 1)| - |f b| ≤ |f (b + 2)|)
    (hf' : ∀ b, 4 * |f (b + 1)| - |f (b + 2)| ≤ |f b|) {M : ℝ} (hM : ∀ b, |f b| ≤ M) :
    ∀ b, f b = 0 := by
  have hfwd := bounded_no_growth f hf hM
  set g : ℤ → ℝ := fun b => f (-b)
  have hg : ∀ b, 4 * |g (b + 1)| - |g b| ≤ |g (b + 2)| := by
    intro b
    have := hf' (-b - 2)
    have e1 : -b - 2 + 1 = -(b + 1) := by ring
    have e2 : -b - 2 + 2 = -b := by ring
    rw [e1, e2] at this
    simp only [g]
    rw [show -(b + 2) = -b - 2 by ring]
    exact this
  have hbwd := bounded_no_growth g hg (M := M) (fun b => hM _)
  have heq : ∀ c, |f (c + 1)| = |f c| := by
    intro c
    have h2 := hbwd (-(c + 1))
    simp only [g, neg_neg, show -(-(c + 1) + 1) = c by ring] at h2
    exact le_antisymm (hfwd c) h2
  intro b
  have h := hf b
  rw [show b + 2 = b + 1 + 1 by ring, heq (b + 1), heq b] at h
  have : |f b| = 0 := by linarith [abs_nonneg (f b)]
  exact abs_eq_zero.1 this

theorem tri_lower {p q : ℝ} (hp : 0 < p) (hq : 0 < q) (u v w : ℝ)
    (h : p * (w + u) + q * v = 0) : q * |v| - p * |u| ≤ p * |w| := by
  have e : q * v = -(p * w) - p * u := by linarith
  have t := abs_sub (-(p * w)) (p * u)
  rw [← e, abs_neg, abs_mul, abs_mul, abs_mul, abs_of_pos hp, abs_of_pos hq] at t
  linarith

/-- **A bounded function with one multiplier per block and zero block sums is `0`.** -/
theorem kkt_bounded_zero (hL : 2 ≤ L) (d ν : ℤ → ℝ)
    (hk : ∀ x, d (x + 1) + d (x - 1) - 2 * d x = -ν (x / (L : ℤ)))
    (hs : ∀ b : ℤ, ∑ r ∈ range L, d (b * L + r) = 0) {K : ℝ} (hK : ∀ x, |d x| ≤ K) :
    ∀ x, d x = 0 := by
  have hL0 : 0 < L := by omega
  have hLr : (2 : ℝ) ≤ L := by exact_mod_cast hL
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  -- the multipliers are bounded
  have hνb : ∀ b, |ν b| ≤ 4 * K := by
    intro b
    have h := hk (b * L)
    rw [show b * (L : ℤ) = b * L + 0 by ring, div_block hL0 b 0 le_rfl hLz] at h
    have e : ν b = -(d (b * L + 0 + 1) + d (b * L + 0 - 1) - 2 * d (b * L + 0)) := by linarith
    rw [e, abs_neg]
    have := hK (b * L + 0 + 1); have := hK (b * L + 0 - 1); have := hK (b * L + 0)
    calc _ ≤ |d (b * L + 0 + 1)| + |d (b * L + 0 - 1)| + |2 * d (b * L + 0)| := by
          refine (abs_sub _ _).trans ?_; gcongr; exact abs_add_le _ _
      _ ≤ 4 * K := by rw [abs_mul, abs_two]; linarith
  -- the three-term relation gives the growth inequalities
  have hrec := nu_rec d ν hL hk hs
  have hc : (4 : ℝ) * ((L : ℝ) ^ 2 - 1) ≤ 4 * (L : ℝ) ^ 2 + 2 := by nlinarith
  have hpos : (0 : ℝ) < (L : ℝ) ^ 2 - 1 := by nlinarith
  have hq : (0 : ℝ) < 4 * (L : ℝ) ^ 2 + 2 := by positivity
  have hf : ∀ b, 4 * |ν (b + 1)| - |ν b| ≤ |ν (b + 2)| := by
    intro b
    have t := tri_lower hpos hq (ν b) (ν (b + 1)) (ν (b + 2)) (by linarith [hrec b])
    have : ((L : ℝ) ^ 2 - 1) * (4 * |ν (b + 1)| - |ν b|) ≤ ((L : ℝ) ^ 2 - 1) * |ν (b + 2)| := by
      nlinarith [abs_nonneg (ν (b + 1))]
    exact le_of_mul_le_mul_left this hpos
  have hf' : ∀ b, 4 * |ν (b + 1)| - |ν (b + 2)| ≤ |ν b| := by
    intro b
    have t := tri_lower hpos hq (ν (b + 2)) (ν (b + 1)) (ν b) (by linarith [hrec b])
    have : ((L : ℝ) ^ 2 - 1) * (4 * |ν (b + 1)| - |ν (b + 2)|) ≤ ((L : ℝ) ^ 2 - 1) * |ν b| := by
      nlinarith [abs_nonneg (ν (b + 1))]
    exact le_of_mul_le_mul_left this hpos
  have hν0 := bounded_rec_zero ν hf hf' hνb
  -- with `ν = 0` the entering gradient is constant, then zero
  have R1 : ∀ c : ℤ, gIn (L := L) d (c + 1) = gIn (L := L) d c := by
    intro c
    have h := grad_in_block d ν hL0 hk c (L - 1) (by omega)
    have e1 : c * (L : ℤ) + ((L - 1 : ℕ) : ℤ) + 1 = (c + 1) * L := by
      rw [Nat.cast_sub (by omega)]; push_cast; ring
    have e2 : c * (L : ℤ) + ((L - 1 : ℕ) : ℤ) = (c + 1) * L - 1 := by
      rw [Nat.cast_sub (by omega)]; push_cast; ring
    rw [e1, e2, hν0, mul_zero, sub_zero] at h
    simp only [gIn] at h ⊢
    exact h
  have R2 : ∀ c : ℤ, d ((c + 1) * L) = d (c * L) + L * gIn (L := L) d c := by
    intro c
    have h := value_in_block d ν hL0 hk c L le_rfl
    rw [show (c + 1) * (L : ℤ) = c * L + (L : ℕ) by ring, h, hν0, zero_mul, sub_zero]
  have R3 : ∀ c : ℤ, (L : ℝ) * d (c * L) + gIn (L := L) d c * ((L : ℝ) * (L - 1) / 2) = 0 := by
    intro c
    have h := hs c
    rw [sum_congr rfl fun r hr => value_in_block d ν hL0 hk c r (mem_range.1 hr).le] at h
    rw [sum_value, hν0, zero_mul, sub_zero] at h
    linarith
  have hD : ∀ c : ℤ, gIn (L := L) d c = 0 := by
    intro c
    have a1 := R3 c
    have a2 := R3 (c + 1)
    have a3 := R2 c
    have a4 := R1 c
    rw [a4, a3] at a2
    have : (L : ℝ) * ((L : ℝ) * gIn (L := L) d c) = 0 := by linarith
    rcases mul_eq_zero.1 this with h | h
    · linarith
    · rcases mul_eq_zero.1 h with h' | h'
      · linarith
      · exact h'
  have ha : ∀ c : ℤ, d (c * L) = 0 := by
    intro c
    have := R3 c
    rw [hD c, zero_mul, add_zero] at this
    rcases mul_eq_zero.1 this with h | h
    · linarith
    · exact h
  intro x
  have hx0 := Int.ediv_mul_add_emod x L
  have hr0 : 0 ≤ x % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
  have hrL : x % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
  obtain ⟨r, hr⟩ : ∃ r : ℕ, x % (L : ℤ) = r := ⟨(x % (L : ℤ)).toNat, by omega⟩
  have hv := value_in_block d ν hL0 hk (x / L) r (by omega)
  rw [← hr, hx0, ha, hD, hν0] at hv
  simpa using hv

/-! ## Consequences: uniqueness of the minimiser and its row sums -/

theorem liftF_bounded (hL : 2 ≤ L) (x : ℤ) : |liftF L x| ≤ 7 := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  have hx0 := Int.ediv_mul_add_emod x L
  have hr0 : 0 ≤ x % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
  have hrL : x % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
  obtain ⟨r, hr⟩ : ∃ r : ℕ, x % (L : ℤ) = r := ⟨(x % (L : ℤ)).toNat, by omega⟩
  have hrL' : r < L := by omega
  have e : liftF L x = kerE L (off L r) (-(x / L)) := by
    rw [kerE_eq_liftF hL0 r hrL', neg_neg, ← hr, hx0]
  rw [e]
  obtain ⟨h0, hb⟩ := kernel_bound hL (off_abs hL0 r hrL')
  obtain ⟨hlo, hhi⟩ := rho_range hL
  by_cases hb0 : -(x / (L : ℤ)) = 0
  · rw [hb0]; linarith
  · have h := hb _ hb0
    have hρ : |rhoL L| ≤ 1 := by rw [abs_le]; constructor <;> linarith
    have hp : |rhoL L| ^ (-(x / (L : ℤ))).natAbs ≤ 1 := pow_le_one₀ (abs_nonneg _) hρ
    nlinarith

/-- **Uniqueness**: a bounded `g` with block sums `L·δ_{b0}` and one multiplier per block is
`liftF`. -/
theorem liftF_unique (hL : 2 ≤ L) (g : ℤ → ℝ) {K : ℝ} (hK : ∀ x, |g x| ≤ K)
    (ν : ℤ → ℝ) (hk : ∀ x, g (x + 1) + g (x - 1) - 2 * g x = -ν (x / (L : ℤ)))
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * zK b) : g = liftF L := by
  have hL0 : 0 < L := by omega
  have hz := kkt_bounded_zero hL (fun x => g x - liftF L x) (fun b => ν b - muK L b)
    (fun x => by
      have h1 := hk x
      have h2 := liftF_kkt hL x
      linarith)
    (fun b => by simp only [sum_sub_distrib, hs, liftF_blocks hL0, sub_self])
    (K := K + 7) (fun x => by
      have h1 := hK x
      have h2 := liftF_bounded hL x
      calc |g x - liftF L x| ≤ |g x| + |liftF L x| := abs_sub _ _
        _ ≤ K + 7 := by linarith)
  funext x; have := hz x; linarith

/-- The general energy identity on a window: for `h` vanishing at the two ends of the window,
`energyW (g + h) = energyW g + energyW h − 2 Σ h·Δg`. -/
theorem energy_general (R : ℕ) (g h : ℤ → ℝ)
    (h0 : h (-((R : ℤ) * L) - 1) = 0) (hN : h (-((R : ℤ) * L) - 1 + (2 * R * L + 1 : ℕ)) = 0) :
    energyW L R (fun x => g x + h x) = energyW L R g + energyW L R h -
      2 * ∑ i ∈ range (2 * R * L), h (-((R : ℤ) * L) - 1 + (i + 1 : ℕ)) *
        (g (-((R : ℤ) * L) - 1 + (i + 2 : ℕ)) - 2 * g (-((R : ℤ) * L) - 1 + (i + 1 : ℕ)) +
          g (-((R : ℤ) * L) - 1 + i)) := by
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  set N := 2 * R * L
  have hc := sbp (fun i => g (x₀ + i)) (fun i => h (x₀ + i)) N
  rw [show x₀ + ((0 : ℕ) : ℤ) = x₀ by simp, h0, hN] at hc
  simp only [zero_mul, sub_zero, zero_sub] at hc
  unfold energyW
  have : ∀ i ∈ range (N + 1),
      (g (x₀ + i + 1) + h (x₀ + i + 1) - (g (x₀ + i) + h (x₀ + i))) ^ 2 =
        (g (x₀ + i + 1) - g (x₀ + i)) ^ 2 + (h (x₀ + i + 1) - h (x₀ + i)) ^ 2 +
          2 * ((g (x₀ + ((i + 1 : ℕ) : ℤ)) - g (x₀ + i)) * (h (x₀ + ((i + 1 : ℕ) : ℤ)) - h (x₀ + i))) := by
    intro i _
    have e : x₀ + ((i + 1 : ℕ) : ℤ) = x₀ + i + 1 := by push_cast; ring
    rw [e]; ring
  rw [sum_congr rfl this, sum_add_distrib, sum_add_distrib, ← mul_sum, hc]
  have e2 : ∀ i ∈ range N, h (x₀ + ((i + 1 : ℕ) : ℤ)) *
      (g (x₀ + ((i + 2 : ℕ) : ℤ)) - 2 * g (x₀ + ((i + 1 : ℕ) : ℤ)) + g (x₀ + ((i : ℕ) : ℤ))) =
      h (x₀ + ((i + 1 : ℕ) : ℤ)) *
      (g (x₀ + ((i + 2 : ℕ) : ℤ)) - 2 * g (x₀ + ((i + 1 : ℕ) : ℤ)) + g (x₀ + i)) := fun _ _ => rfl
  rw [sum_congr rfl e2]
  ring

theorem sum_delta (x₀ x : ℤ) (N : ℕ) (hx1 : x₀ + 1 ≤ x) (hx2 : x ≤ x₀ + N) (F : ℤ → ℝ) :
    ∑ i ∈ range N, (if x₀ + ((i + 1 : ℕ) : ℤ) = x then (1 : ℝ) else 0) * F (x₀ + ((i + 1 : ℕ) : ℤ)) =
      F x := by
  rw [sum_eq_single_of_mem ((x - x₀ - 1).toNat) (by rw [mem_range]; omega)
    (fun i _ hi => by rw [if_neg (by omega), zero_mul])]
  have e : x₀ + (((x - x₀ - 1).toNat + 1 : ℕ) : ℤ) = x := by push_cast; omega
  rw [e, if_pos rfl, one_mul]

theorem block_delta (hL : 0 < L) (b x : ℤ) :
    ∑ r ∈ range L, (if b * L + (r : ℤ) = x then (1 : ℝ) else 0) = if x / (L : ℤ) = b then 1 else 0 := by
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL
  split_ifs with hb
  · have hx0 := Int.ediv_mul_add_emod x L
    have hr0 : 0 ≤ x % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
    have hrL : x % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
    rw [sum_eq_single_of_mem (x % (L : ℤ)).toNat (by rw [mem_range]; omega)
      (fun r _ hr => by
        rw [if_neg]
        intro h
        apply hr
        have := div_block hL b r (by positivity) (by exact_mod_cast (mem_range.1 ‹_›))
        rw [h] at this
        have h2 : (r : ℤ) = x % L := by
          have := Int.ediv_mul_add_emod x L
          rw [← h] at this ⊢
          rw [show b * (L : ℤ) + r = r + b * L by ring, Int.add_mul_emod_self_right,
            Int.emod_eq_of_lt (by positivity) (by exact_mod_cast (mem_range.1 ‹_›))]
        omega)]
    rw [if_pos]
    rw [← hb]; omega
  · refine sum_eq_zero fun r hr => if_neg fun h => hb ?_
    rw [← h]; exact div_block hL b r (by positivity) (by exact_mod_cast mem_range.1 hr)

theorem quad_nonneg_zero {c q : ℝ} (hq : 0 ≤ q) (H : ∀ t : ℝ, 0 ≤ t ^ 2 * q - 2 * t * c) : c = 0 := by
  by_contra hc
  have h := H (c / (q + 1))
  have hq1 : 0 < q + 1 := by linarith
  have hc2 : 0 < c ^ 2 := by positivity
  have e : (c / (q + 1)) ^ 2 * q - 2 * (c / (q + 1)) * c = -(c ^ 2 * (q + 2)) / (q + 1) ^ 2 := by
    field_simp; ring
  rw [e, neg_div] at h
  have : 0 < c ^ 2 * (q + 2) / (q + 1) ^ 2 := by positivity
  linarith

/-- A function `g` is a **local minimiser** of the constrained problem if no perturbation supported
in a window of blocks, with zero block sums, lowers its window energy. -/
def LocalMin (L : ℕ) (g : ℤ → ℝ) : Prop :=
  ∀ (R : ℕ) (h : ℤ → ℝ), (∀ x, (x < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ x) → h x = 0) →
    (∀ b : ℤ, ∑ r ∈ range L, h (b * L + r) = 0) →
      energyW L R g ≤ energyW L R (fun x => g x + h x)

/-- **A local minimiser has one multiplier per block (KKT).** -/
theorem local_min_kkt (hL : 2 ≤ L) (g : ℤ → ℝ) (hg : LocalMin L g) :
    ∀ x, g (x + 1) + g (x - 1) - 2 * g x =
      g ((x / (L : ℤ)) * L + 1) + g ((x / (L : ℤ)) * L - 1) - 2 * g ((x / (L : ℤ)) * L) := by
  have hL0 : 0 < L := by omega
  have hLz : (0 : ℤ) < L := by exact_mod_cast hL0
  intro x
  set b := x / (L : ℤ)
  set y := b * (L : ℤ)
  have hx0 := Int.ediv_mul_add_emod x L
  have hr0 : 0 ≤ x % (L : ℤ) := Int.emod_nonneg _ hLz.ne'
  have hrL : x % (L : ℤ) < L := Int.emod_lt_of_pos _ hLz
  have hyb : y / (L : ℤ) = b := by
    simpa using div_block hL0 b 0 le_rfl hLz
  -- the window
  set R : ℕ := b.natAbs + 1
  have hRb1 : -((R : ℤ) * L) ≤ y := by
    simp only [R, y]; push_cast
    nlinarith [abs_nonneg b, neg_abs_le b, le_abs_self b, Int.natCast_natAbs b]
  have hRb2 : x < (R : ℤ) * L := by
    simp only [R]; push_cast
    have : b ≤ |b| := le_abs_self b
    have hbl : b * (L : ℤ) ≤ |b| * L := mul_le_mul_of_nonneg_right this hLz.le
    have : x = b * L + x % (L : ℤ) := by simp only [b]; linarith
    nlinarith
  have hyx : y ≤ x := by simp only [y]; linarith
  set φ : ℤ → ℝ := fun z => (if z = x then 1 else 0) - (if z = y then 1 else 0)
  have hsupp : ∀ (t : ℝ) z, (z < -((R : ℤ) * L) ∨ (R : ℤ) * L ≤ z) → t * φ z = 0 := by
    intro t z hz
    simp only [φ]
    rw [if_neg (by omega), if_neg (by omega)]; ring
  have hblk : ∀ (t : ℝ) (b' : ℤ), ∑ r ∈ range L, t * φ (b' * L + r) = 0 := by
    intro t b'
    simp only [φ, ← mul_sum, sum_sub_distrib, block_delta hL0, hyb]
    rw [sub_self, mul_zero]
  set Lap : ℤ → ℝ := fun z => g (z + 1) - 2 * g z + g (z - 1)
  set N := 2 * R * L
  set x₀ : ℤ := -((R : ℤ) * L) - 1
  have hNdef : (N : ℤ) = 2 * ((R : ℤ) * L) := by simp only [N]; push_cast; ring
  have hcross : ∀ t : ℝ, ∑ i ∈ range N, t * φ (x₀ + (i + 1 : ℕ)) *
      (g (x₀ + (i + 2 : ℕ)) - 2 * g (x₀ + (i + 1 : ℕ)) + g (x₀ + i)) = t * (Lap x - Lap y) := by
    intro t
    have e : ∀ i ∈ range N, t * φ (x₀ + (i + 1 : ℕ)) *
        (g (x₀ + (i + 2 : ℕ)) - 2 * g (x₀ + (i + 1 : ℕ)) + g (x₀ + i)) =
        t * ((if x₀ + ((i + 1 : ℕ) : ℤ) = x then (1 : ℝ) else 0) * Lap (x₀ + ((i + 1 : ℕ) : ℤ)) -
          (if x₀ + ((i + 1 : ℕ) : ℤ) = y then (1 : ℝ) else 0) * Lap (x₀ + ((i + 1 : ℕ) : ℤ))) := by
      intro i _
      simp only [φ, Lap]
      have e1 : x₀ + ((i + 2 : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) + 1 := by push_cast; ring
      have e2 : x₀ + ((i : ℕ) : ℤ) = x₀ + ((i + 1 : ℕ) : ℤ) - 1 := by push_cast; ring
      rw [e1, e2]; ring
    rw [sum_congr rfl e, ← mul_sum, sum_sub_distrib,
      sum_delta x₀ x N (by simp only [x₀]; omega) (by simp only [x₀]; omega),
      sum_delta x₀ y N (by simp only [x₀]; omega) (by simp only [x₀]; omega)]
  have hscale : ∀ t : ℝ, energyW L R (fun z => t * φ z) = t ^ 2 * energyW L R φ := by
    intro t; unfold energyW; rw [mul_sum]
    refine sum_congr rfl fun i _ => by ring
  have h2RL : (2 : ℤ) * R * L = 2 * ((R : ℤ) * L) := by ring
  have H : ∀ t : ℝ, 0 ≤ t ^ 2 * energyW L R φ - 2 * t * (Lap x - Lap y) := by
    intro t
    have hm := hg R (fun z => t * φ z) (hsupp t) (hblk t)
    have he := energy_general (L := L) R g (fun z => t * φ z)
      (hsupp t _ (Or.inl (by omega)))
      (hsupp t _ (Or.inr (by push_cast; linarith [h2RL])))
    rw [he, hscale, hcross] at hm
    linarith
  have hq : 0 ≤ energyW L R φ := sum_nonneg fun _ _ => sq_nonneg _
  have h0 := quad_nonneg_zero hq H
  simp only [Lap] at h0
  linarith

/-- **A bounded local minimiser with block sums `L·δ_{b0}` is `liftF`.** -/
theorem bounded_local_min_eq_liftF (hL : 2 ≤ L) (g : ℤ → ℝ) {K : ℝ} (hK : ∀ x, |g x| ≤ K)
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * zK b) (hmin : LocalMin L g) : g = liftF L := by
  refine liftF_unique hL g hK
    (fun b => -(g (b * L + 1) + g (b * L - 1) - 2 * g (b * L))) (fun x => ?_) hs
  rw [local_min_kkt hL g hmin x]; ring

/-- `liftF` is a local minimiser (and bounded, `liftF_bounded`; block sums, `liftF_blocks`). -/
theorem liftF_local_min (hL : 2 ≤ L) : LocalMin L (liftF L) := by
  intro R h hsupp hblk
  rw [energy_split hL R h hsupp hblk]
  have : 0 ≤ energyW L R h := sum_nonneg fun _ _ => sq_nonneg _
  linarith

/-- **T8 (d = 1): row sums of the constrained minimiser.** Any bounded local minimiser `g` of the
energy `Σ (g(x+1) − g(x))²` under the block sums `L·δ_{b0}` has, at a site `r` of block `0`,
`|g r| + Σ_{k<n} (|g(r − (k+1)L)| + |g(r + (k+1)L)|) ≤ 1 + 10/8 + 2(9/2 + 17/8)(0.27/0.73)`,
uniformly in `L ≥ 2` and `n`; such a `g` exists (`liftF`). -/
theorem row_sum_bounded_minimiser (hL : 2 ≤ L) (g : ℤ → ℝ) {K : ℝ} (hK : ∀ x, |g x| ≤ K)
    (hs : ∀ b : ℤ, ∑ r ∈ range L, g (b * L + r) = L * zK b) (hmin : LocalMin L g)
    (r : ℕ) (hr : r < L) (n : ℕ) :
    |g r| + ∑ k ∈ range n, (|g (r - ((k : ℤ) + 1) * L)| + |g (r + ((k : ℤ) + 1) * L)|) ≤
      1 + 10 / 8 + 2 * (9 / 2 + 17 / 8) * ((27 / 100) / (1 - 27 / 100)) := by
  have hgF := bounded_local_min_eq_liftF hL g hK hs hmin
  subst hgF
  exact row_sum_minimiser hL 0 (liftF L) (fun _ _ => rfl) (liftF_blocks (by omega))
    (fun g' hout hblk => (window_min_unique hL 0 g' hout hblk).1) r hr n

/-- The class of `row_sum_bounded_minimiser` is not empty: `liftF` is in it. -/
theorem liftF_in_class (hL : 2 ≤ L) :
    (∀ x, |liftF L x| ≤ 7) ∧ (∀ b : ℤ, ∑ r ∈ range L, liftF L (b * L + r) = L * zK b) ∧
      LocalMin L (liftF L) :=
  ⟨liftF_bounded hL, liftF_blocks (by omega), liftF_local_min hL⟩

end BlockLiftMin

#print axioms BlockLiftMin.nu_rec
#print axioms BlockLiftMin.bounded_rec_zero
#print axioms BlockLiftMin.kkt_bounded_zero
#print axioms BlockLiftMin.liftF_unique
#print axioms BlockLiftMin.local_min_kkt
#print axioms BlockLiftMin.bounded_local_min_eq_liftF
#print axioms BlockLiftMin.row_sum_bounded_minimiser
#print axioms BlockLiftMin.liftF_in_class
