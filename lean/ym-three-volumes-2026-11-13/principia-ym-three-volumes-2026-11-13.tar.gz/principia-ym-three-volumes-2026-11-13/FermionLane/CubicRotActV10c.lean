import FermionLane.CubicActV10b

/-! # The 90° rotations of the spatial planes: Wilson action and the normalised Wilson–fermion measure

The rotation in the plane `(a, b)` is the exchange of the coordinates `a ↔ b` followed by the reflection of the axis
`a` (`rot_eq`).  The exchange relabels sites and directions without reversing links:
* `swapSite`, `swapPhys`, `swapLink`; `pairs_swap` (a symmetric function summed over the pairs `i < j` of `Fin 3`
  is unchanged by a transposition), `spS_swap`, `tmS_swap`, `wilsonAction_swap`, `pi_swap_preserving`.
* **`wilsonAction_rot`**, `wfWeight_rot` (with `physDirac_det_rot`), `pi_rot_preserving`, **`wfProb_rot`**. -/

namespace CubicSym

open Matrix MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion

variable {N : ℕ} [NeZero N]

/-- the exchange of the coordinates `a ↔ b` of the spatial torus -/
def swapSite (a b : Fin 3) : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N) where
  toFun x := fun l => x (Equiv.swap a b l)
  invFun x := fun l => x (Equiv.swap a b l)
  left_inv x := by funext l; simp
  right_inv x := by funext l; simp

theorem swapSite_apply (a b : Fin 3) (x : Fin 3 → Fin N) (l : Fin 3) :
    swapSite a b x l = x (Equiv.swap a b l) := rfl

theorem swapSite_add (a b i : Fin 3) (x : Fin 3 → Fin N) :
    swapSite a b (x + Pi.single i 1) = swapSite a b x + Pi.single (Equiv.swap a b i) 1 := by
  funext l
  simp only [swapSite_apply, Pi.add_apply, Pi.single_apply]
  congr 1
  by_cases h : l = Equiv.swap a b i
  · rw [if_pos h, if_pos (by rw [h, Equiv.swap_apply_self])]
  · rw [if_neg h, if_neg (fun e => h (by rw [← e, Equiv.swap_apply_self]))]

theorem pairs_eq (g : Fin 3 → Fin 3 → ℝ) : ∑ i, ∑ j ∈ Finset.Ioi i, g i j = g 0 1 + g 0 2 + g 1 2 := by
  have h0 : Finset.Ioi (0 : Fin 3) = {1, 2} := by decide
  have h1 : Finset.Ioi (1 : Fin 3) = {2} := by decide
  have h2 : Finset.Ioi (2 : Fin 3) = ∅ := by decide
  rw [Fin.sum_univ_three, h0, h1, h2, Finset.sum_pair (by decide), Finset.sum_singleton, Finset.sum_empty]
  ring

/-- a symmetric function summed over the pairs `i < j` is unchanged by a transposition -/
theorem pairs_swap (a b : Fin 3) (g : Fin 3 → Fin 3 → ℝ) (hg : ∀ i j, g i j = g j i) :
    ∑ i, ∑ j ∈ Finset.Ioi i, g (Equiv.swap a b i) (Equiv.swap a b j) = ∑ i, ∑ j ∈ Finset.Ioi i, g i j := by
  rw [pairs_eq (fun i j => g (Equiv.swap a b i) (Equiv.swap a b j)), pairs_eq]
  have e01 := hg 0 1; have e02 := hg 0 2; have e12 := hg 1 2
  fin_cases a <;> fin_cases b <;> simp [Equiv.swap_apply_def] <;> linarith

theorem plaqE_symm (A B C D : Matrix (Fin 2) (Fin 2) ℂ) : plaqE D C B A = plaqE A B C D := by
  unfold plaqE
  have h1 : (D * C * Bᴴ * Aᴴ).trace = ((A * B * Cᴴ * Dᴴ)ᴴ).trace := by
    simp only [conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]
  rw [h1, Matrix.trace_conjTranspose, Complex.star_def, Complex.conj_re]

theorem spS_swap (a b : Fin 3) (B B' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hB : ∀ y i, B' y i = B (swapSite a b y) (Equiv.swap a b i)) :
    spS N B' = spS N B := by
  unfold spS
  simp only [ev]
  refine Fintype.sum_equiv (swapSite a b) _ _ fun y => ?_
  simp only [hB, swapSite_add]
  have h := pairs_swap a b (fun i j => plaqE (B (swapSite a b y) i) (B (swapSite a b y + Pi.single i 1) j)
    (B (swapSite a b y + Pi.single j 1) i) (B (swapSite a b y) j))
    (fun i j => (plaqE_symm _ _ _ _).symm)
  exact h

theorem tmS_swap (a b : Fin 3) (B0 B1 B0' B1' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (T T' : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (h0 : ∀ y i, B0' y i = B0 (swapSite a b y) (Equiv.swap a b i))
    (h1 : ∀ y i, B1' y i = B1 (swapSite a b y) (Equiv.swap a b i))
    (hT : ∀ y, T' y = T (swapSite a b y)) :
    tmS N B0' B1' T' = tmS N B0 B1 T := by
  unfold tmS
  simp only [ev]
  refine Fintype.sum_equiv (swapSite a b) _ _ fun y => ?_
  rw [← Equiv.sum_comp (Equiv.swap a b)]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [h0, h1, hT, hT, swapSite_add, Equiv.swap_apply_self]

/-- the configuration with the coordinates `a ↔ b` exchanged -/
def swapPhys {hT : ℕ} (a b : Fin 3) (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 :=
  fun l => ω (l.1, swapSite a b l.2.1, Equiv.swap a.castSucc b.castSucc l.2.2)

theorem swap_castSucc (a b i : Fin 3) :
    Equiv.swap a.castSucc b.castSucc i.castSucc = (Equiv.swap a b i).castSucc :=
  (Fin.castSucc_injective 3).swap_apply a b i

section Phys

variable {hT : ℕ} (a b : Fin 3) (ω : PhysLink N hT → SU2)

theorem physSp_swap (t : ℕ) (y : Fin 3 → Fin N) (i : Fin 3) :
    physSp (swapPhys a b ω) t y i = physSp ω t (swapSite a b y) (Equiv.swap a b i) := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [swapPhys, swap_castSucc]
  · rw [dif_neg ht, dif_neg ht]

theorem physT_swap (t : ℕ) (y : Fin 3 → Fin N) :
    physT (swapPhys a b ω) t y = physT ω t (swapSite a b y) := by
  unfold physT
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [swapPhys, Equiv.swap_apply_of_ne_of_ne (three_ne_castSucc a) (three_ne_castSucc b)]
  · rw [dif_neg ht, dif_neg ht]

theorem wilsonAction_swap : wilsonAction N hT (swapPhys a b ω) = wilsonAction N hT ω := by
  unfold wilsonAction
  refine Finset.sum_congr rfl fun t _ => ?_
  rw [spS_swap a b _ _ (fun y i => physSp_swap a b ω t y i),
    tmS_swap a b _ _ _ _ _ _ (fun y i => physSp_swap a b ω t y i) (fun y i => physSp_swap a b ω (sc hT t) y i)
      (fun y => physT_swap a b ω t y)]

/-- **the rotation is the exchange `a ↔ b` followed by the reflection of the axis `a`** -/
theorem rot_eq (hab : a ≠ b) : rotPhys a b hab ω = reflPhys a (swapPhys a b ω) := by
  have hs : ∀ z : Fin 3 → Fin N, (rotSite a b hab).symm z = swapSite a b ((reflSite a).symm z) := by
    intro z
    funext l
    show (if l = a then z b else if l = b then Fin.rev (z a) else z l)
      = (if Equiv.swap a b l = a then Fin.rev (z a) else z (Equiv.swap a b l))
    by_cases hla : l = a
    · rw [if_pos hla, hla, Equiv.swap_apply_left, if_neg (Ne.symm hab)]
    · by_cases hlb : l = b
      · rw [if_neg hla, if_pos hlb, hlb, Equiv.swap_apply_right, if_pos rfl]
      · rw [if_neg hla, if_neg hlb, Equiv.swap_apply_of_ne_of_ne hla hlb, if_neg hla]
  funext l
  obtain ⟨t, y, μ⟩ := l
  have hab' := castSucc_ne_castSucc hab
  by_cases hμa : μ = a.castSucc
  · simp only [rotPhys, reflPhys, swapPhys, hμa, if_neg hab', if_true, Equiv.swap_apply_left, hs]
  · by_cases hμb : μ = b.castSucc
    · simp only [rotPhys, reflPhys, swapPhys, hμb, if_true, if_neg (Ne.symm hab'), Equiv.swap_apply_right, hs]
    · simp only [rotPhys, reflPhys, swapPhys, if_neg hμa, if_neg hμb, Equiv.swap_apply_of_ne_of_ne hμa hμb, hs]

/-- **the Wilson action is invariant under the 90° rotations of the spatial planes** -/
theorem wilsonAction_rot (hab : a ≠ b) : wilsonAction N hT (rotPhys a b hab ω) = wilsonAction N hT ω := by
  rw [rot_eq, wilsonAction_refl, wilsonAction_swap]

theorem wfWeight_rot (hab : a ≠ b) (j : ℕ) (m β : ℝ) :
    wfWeight N hT j m β (rotPhys a b hab ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_rot, physDirac_det_rot]

end Phys

/-- the link relabelling of the exchange (an involution) -/
def swapLink {hT : ℕ} (a b : Fin 3) (l : PhysLink N hT) : PhysLink N hT :=
  (l.1, swapSite a b l.2.1, Equiv.swap a.castSucc b.castSucc l.2.2)

theorem swapLink_invol {hT : ℕ} (a b : Fin 3) : Function.Involutive (swapLink (N := N) (hT := hT) a b) := by
  intro l
  obtain ⟨t, y, μ⟩ := l
  simp only [swapLink, Equiv.swap_apply_self]
  congr 2
  exact (swapSite a b).symm_apply_apply y

theorem pi_swap_preserving (hT : ℕ) (a b : Fin 3) :
    MeasurePreserving (swapPhys (N := N) (hT := hT) a b)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h1 := measurePreserving_arrowCongr' (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (swapLink_invol (N := N) (hT := hT) a b).toPerm.symm (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e1 : ⇑(MeasurableEquiv.arrowCongr' (swapLink_invol (N := N) (hT := hT) a b).toPerm.symm
      (MeasurableEquiv.refl SU2)) = swapPhys a b := by
    funext ω l; rfl
  rw [e1] at h1
  exact h1

theorem pi_rot_preserving (hT : ℕ) (a b : Fin 3) (hab : a ≠ b) :
    MeasurePreserving (rotPhys (N := N) (hT := hT) a b hab)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have e : rotPhys (N := N) (hT := hT) a b hab = reflPhys a ∘ swapPhys a b := by
    funext ω; exact rot_eq a b ω hab
  rw [e]
  exact (pi_refl_preserving hT a).comp (pi_swap_preserving hT a b)

/-- **the normalised Wilson–fermion measure is invariant under the 90° rotations of the spatial planes** -/
theorem wfProb_rot (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) (a b : Fin 3) (hab : a ≠ b) :
    (wfProb N hT j m β).map (rotPhys a b hab) = wfProb N hT j m β := by
  have hT' := pi_rot_preserving (N := N) hT a b hab
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (rotPhys a b hab ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_rot]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end CubicSym

#print axioms CubicSym.pairs_swap
#print axioms CubicSym.spS_swap
#print axioms CubicSym.rot_eq
#print axioms CubicSym.wilsonAction_rot
#print axioms CubicSym.pi_rot_preserving
#print axioms CubicSym.wfProb_rot
