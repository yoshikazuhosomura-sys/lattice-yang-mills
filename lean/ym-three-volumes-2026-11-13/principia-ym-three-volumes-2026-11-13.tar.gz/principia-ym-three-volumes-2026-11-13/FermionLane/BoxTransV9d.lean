import FermionLane.TransV9d
import FermionLane.BlockShiftV9d

/-! # `hsym` of the box chain for the spatial lattice translations

The spatial translation of the physical configurations (`transPhys`, `TransV9d`) is the
translation of the box configurations by `e_{k+1}` (`pullBox_trans`; `zf` is additive).  The fine measures are
invariant under all multiples of `e_{k+1}` (`fermProbBox_shift_nat`), the block maps commute with translations
(`down_shift`, `BlockShiftV9d`), so the block measures at level `m` are invariant under the coarse translation by
`e_{k+1}` (**`hsym_box_fermion_trans`**). -/

namespace BlockShift

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config BoxFermion GaugeDet

section Fine

variable (h : ℕ) [NeZero (2 * h)]

theorem zf_add_one (a : ZMod (2 * h)) : zf h (a + 1) = zf h a + 1 := by
  apply Fin.ext
  simp only [zf, Fin.val_add, ZMod.val_add, ZMod.val_one_eq_one_mod, Fin.val_one']

/-- the translation of the torus links by a vector -/
def shiftT (c : TorusRP.Site (2 * h)) (U : TorusRP.Lk (2 * h) → TorusRP.QBall) : TorusRP.Lk (2 * h) → TorusRP.QBall :=
  fun ℓ => U (ℓ.1 + c, ℓ.2)

theorem toPhys_shift (k : Fin 3) (ℓ : TorusRP.Lk (2 * h)) :
    toPhys h (ℓ.1 + Pi.single k.succ 1, ℓ.2)
      = ((toPhys h ℓ).1, (toPhys h ℓ).2.1 + WilsonGauge.ev (2 * h) k, (toPhys h ℓ).2.2) := by
  unfold toPhys
  simp only [Prod.mk.injEq]
  refine ⟨?_, ?_, trivial⟩
  · have : (Pi.single k.succ (1 : ZMod (2 * h)) : Fin 4 → ZMod (2 * h)) 0 = 0 :=
      Pi.single_eq_of_ne (Fin.succ_ne_zero k).symm _
    simp only [Pi.add_apply, this, add_zero]
  · funext j
    simp only [Pi.add_apply, WilsonGauge.ev]
    by_cases hj : j = k
    · subst hj
      simp only [Pi.single_eq_same]
      exact zf_add_one h _
    · have h1 : (Pi.single k.succ (1 : ZMod (2 * h)) : Fin 4 → ZMod (2 * h)) j.succ = 0 :=
        Pi.single_eq_of_ne (fun e => hj (Fin.succ_inj.1 e)) _
      have h2 : (Pi.single k (1 : Fin (2 * h)) : Fin 3 → Fin (2 * h)) j = 0 := Pi.single_eq_of_ne hj _
      rw [h1, h2, add_zero, add_zero]

theorem pull_trans (k : Fin 3) (ω : PhysLink (2 * h) h → SU2) :
    pull h (transPhys k ω) = shiftT h (Pi.single k.succ 1) (pull h ω) := by
  funext ℓ
  show TorusRP.incl (transPhys k ω (toPhys h ℓ)) = TorusRP.incl (ω (toPhys h (ℓ.1 + Pi.single k.succ 1, ℓ.2)))
  rw [toPhys_shift]
  rfl

end Fine

theorem castCfg_shift {a b : ℕ} [NeZero a] [NeZero b] (e : a = b) (c : Fin 4)
    (U : TorusRP.Lk a → TorusRP.QBall) :
    castCfg e (fun ℓ => U (ℓ.1 + Pi.single c 1, ℓ.2)) = fun ℓ => castCfg e U (ℓ.1 + Pi.single c 1, ℓ.2) := by
  subst e; rfl

variable (L : ℕ) [NeZero L]

theorem pullBox_trans (n : ℕ) (k : Fin 3) (ω : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) :
    pullBox L n (transPhys k ω) = shiftCfg (2 * L) (Pi.single k.succ 1) (pullBox L n ω) := by
  unfold pullBox
  rw [pull_trans]
  exact castCfg_shift (size_eq L n) k.succ _

theorem measurable_shiftCfg {m : ℕ} (c : Site (2 * L) m) : Measurable (shiftCfg (2 * L) c) :=
  measurable_pi_lambda _ fun _ => measurable_pi_apply _

theorem measurable_transPhys {N hT : ℕ} [NeZero N] (k : Fin 3) : Measurable (transPhys (N := N) (hT := hT) k) :=
  measurable_pi_lambda _ fun _ => measurable_pi_apply _

theorem fermProbBox_shift (j : ℕ) (mseq βseq : ℕ → ℝ) (n : ℕ) (k : Fin 3) :
    (fermProbBox L j mseq βseq n : Measure (Cfg (BoxLk (2 * L) n))).map (shiftCfg (2 * L) (Pi.single k.succ 1))
      = fermProbBox L j mseq βseq n := by
  rw [fermProbBox_toMeasure, Measure.map_map (measurable_shiftCfg L _) (measurable_pullBox L n)]
  have e : shiftCfg (2 * L) (Pi.single k.succ 1) ∘ pullBox L n = pullBox L n ∘ transPhys k :=
    funext fun ω => (pullBox_trans L n k ω).symm
  rw [e, ← Measure.map_map (measurable_pullBox L n) (measurable_transPhys k),
    wfProb_trans (2 ^ n * L) (h_pos L n) j (mseq n) (βseq n) k]

theorem shiftCfg_add {L' m : ℕ} [NeZero L'] (c c' : Site L' m) (U : Cfg (BoxLk L' m)) :
    shiftCfg L' (c + c') U = shiftCfg L' c' (shiftCfg L' c U) := by
  funext ℓ
  simp only [shiftCfg, shiftLk, add_assoc]
  rw [add_comm c c']

/-- the fine measures are invariant under every multiple of `e_{k+1}` -/
theorem fermProbBox_shift_nat (j : ℕ) (mseq βseq : ℕ → ℝ) (n : ℕ) (k : Fin 3) (r : ℕ) :
    (fermProbBox L j mseq βseq n : Measure (Cfg (BoxLk (2 * L) n))).map
        (shiftCfg (2 * L) (Pi.single k.succ (r : ZMod (2 ^ n * (2 * L)))))
      = fermProbBox L j mseq βseq n := by
  induction r with
  | zero =>
    have : shiftCfg (2 * L) (Pi.single k.succ ((0 : ℕ) : ZMod (2 ^ n * (2 * L)))) = id := by
      funext U ℓ; simp [shiftCfg, shiftLk]
    rw [this, Measure.map_id]
  | succ r ih =>
    have : shiftCfg (2 * L) (Pi.single k.succ ((r + 1 : ℕ) : ZMod (2 ^ n * (2 * L))))
        = shiftCfg (2 * L) (Pi.single k.succ 1) ∘ shiftCfg (2 * L) (Pi.single k.succ (r : ZMod (2 ^ n * (2 * L)))) := by
      funext U
      rw [Function.comp_apply, ← shiftCfg_add, Nat.cast_succ, Pi.single_add]
    rw [this, ← Measure.map_map (measurable_shiftCfg L _) (measurable_shiftCfg L _), ih, fermProbBox_shift]

/-- the vectors `2^{j−m} e_d` at the levels `j` -/
def vfam (m : ℕ) (d : Fin 4) (j : ℕ) : Site (2 * L) j := Pi.single d ((2 ^ (j - m) : ℕ) : ZMod (2 ^ j * (2 * L)))

theorem vfam_succ (m : ℕ) (d : Fin 4) (j : ℕ) (hj : m ≤ j) :
    vfam L m d (j + 1) = dbl (2 * L) j (vfam L m d j) := by
  funext i
  unfold vfam dbl
  by_cases hi : i = d
  · subst hi
    simp only [Pi.single_eq_same]
    rw [show ((2 ^ (j - m) : ℕ) : ZMod (2 ^ j * (2 * L))) = (((2 ^ (j - m) : ℕ) : ℤ) : ZMod (2 ^ j * (2 * L))) by
      push_cast; rfl, double_intCast]
    have : j + 1 - m = (j - m) + 1 := by omega
    rw [this, pow_succ]
    push_cast
    ring
  · simp only [Pi.single_eq_of_ne hi, map_zero]

/-- **`hsym` of the box chain for the spatial lattice translation by `e_{k+1}` at level `m`** (all `j`, `m_n`, `β_n`) -/
theorem hsym_box_fermion_trans {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (k : Fin 3) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (shiftCfg (2 * L) (Pi.single k.succ 1) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) := by
  filter_upwards [eventually_ge_atTop m] with n hn
  intro F
  have hvm : vfam L m k.succ m = Pi.single k.succ 1 := by
    unfold vfam; simp
  have hD := (continuous_down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m).measurable
  have hS := measurable_shiftCfg L (vfam L m k.succ m)
  have hm1 : Measurable fun ω : Cfg (BoxLk (2 * L) m) => F (shiftCfg (2 * L) (vfam L m k.succ m) ω) :=
    F.continuous.measurable.comp hS
  have hm2 : Measurable fun ω : Cfg (BoxLk (2 * L) m) => F ω := F.continuous.measurable
  have hm3 : Measurable fun ω : Cfg (BoxLk (2 * L) n) => F (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m ω) :=
    F.continuous.measurable.comp hD
  rw [← hvm, νP, ProbabilityMeasure.toMeasure_map,
    integral_map hD.aemeasurable hm1.aestronglyMeasurable,
    integral_map hD.aemeasurable hm2.aestronglyMeasurable]
  have hfun : (fun ω => F (shiftCfg (2 * L) (vfam L m k.succ m) (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m ω)))
      = fun ω => F (down r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) n m (shiftCfg (2 * L) (vfam L m k.succ n) ω)) := by
    funext ω
    rw [down_shift (2 * L) hr n (vfam L m k.succ) (n - m) m (by omega)
      (fun i hi _ => vfam_succ L m k.succ i hi) ω]
  rw [hfun]
  have hinv := fermProbBox_shift_nat L j mseq βseq n k (2 ^ (n - m))
  conv_rhs => rw [← hinv]
  rw [integral_map (measurable_shiftCfg L _).aemeasurable hm3.aestronglyMeasurable]
  rfl

end BlockShift

#print axioms BlockShift.pullBox_trans
#print axioms BlockShift.fermProbBox_shift_nat
#print axioms BlockShift.vfam_succ
#print axioms BlockShift.hsym_box_fermion_trans
