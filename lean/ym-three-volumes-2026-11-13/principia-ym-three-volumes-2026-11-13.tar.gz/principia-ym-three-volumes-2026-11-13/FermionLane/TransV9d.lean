import FermionLane.GaugeDetV9c

/-! # (file Trans, version a): the fine Wilson–fermion measure is invariant under the spatial lattice
translations

Paper side: For a direction `k`, the translation `x ↦ x + e_k` of the spatial torus acts on the
physical links by `(τ_k ω)(t, x, μ) = ω(t, x + e_k, μ)`.  The fermions are antiperiodic in space, so the operator is
conjugated by a *signed* translation `(Qψ)(x) = s_k(x) ψ(x + e_k)`, `s_k(x) = −1` on the slice `x_k = N − 1` (the
same sign as the antiperiodic hop):
* `sign_identity`: `s_i(x) = s_k(x) s_i(x + e_k) s_k(x + e_i)` (no modular arithmetic: `s² = 1` and
  `(x + e_k)_i = x_i` for `i ≠ k`);
* `transQ_conj_apply`, `transQ_unitary`, `torusX_trans`, `blockDiagonal_trans`;
* **`physDirac_det_trans`**: `det D(τ_k ω) = det D(ω)` (with `det_std4_conj` of this round);
* `spS_trans`, `tmS_trans`, **`wilsonAction_trans`**; `pi_trans_preserving`; **`wfProb_trans`**: the normalised
  Wilson–fermion measure is invariant under `τ_k` (all `j`, `m`, `β`). -/

namespace GaugeDet

open Matrix MeasureTheory FermionSliceBlock WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

variable {N : ℕ} [NeZero N]

/-- the antiperiodic sign `s_k(x) = −1` on the slice `x_k = N − 1` -/
def wrapSign (k : Fin 3) (x : Fin 3 → Fin N) : ℂ := if (x k).val + 1 = N then -1 else 1

theorem wrapSign_mul_self (k : Fin 3) (x : Fin 3 → Fin N) : wrapSign k x * wrapSign k x = 1 := by
  unfold wrapSign; split_ifs <;> norm_num

theorem wrapSign_star (k : Fin 3) (x : Fin 3 → Fin N) : star (wrapSign k x) = wrapSign k x := by
  unfold wrapSign; split_ifs <;> simp

theorem add_ev_apply_ne {k i : Fin 3} (h : i ≠ k) (x : Fin 3 → Fin N) : (x + ev N k) i = x i := by
  simp [ev, Pi.single_apply, h]

theorem wrapSign_add_ne {k i : Fin 3} (h : i ≠ k) (x : Fin 3 → Fin N) : wrapSign i (x + ev N k) = wrapSign i x := by
  unfold wrapSign; rw [add_ev_apply_ne h]

/-- **the sign identity** of the signed translation -/
theorem sign_identity (k i : Fin 3) (x : Fin 3 → Fin N) :
    wrapSign i x = wrapSign k x * wrapSign i (x + ev N k) * wrapSign k (x + ev N i) := by
  by_cases hki : k = i
  · subst hki
    rw [mul_assoc, wrapSign_mul_self, mul_one]
  · rw [wrapSign_add_ne (Ne.symm hki), wrapSign_add_ne hki]
    rw [mul_comm (wrapSign k x) (wrapSign i x), mul_assoc, wrapSign_mul_self, mul_one]

/-- the signed translation `(Qψ)(x) = s_k(x) ψ(x + e_k)` -/
noncomputable def transQ (k : Fin 3) : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ :=
  Matrix.of fun x y => if y = x + ev N k then wrapSign k x else 0

theorem transQ_conj_apply (k : Fin 3) (K : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ) (x y : Fin 3 → Fin N) :
    (transQ k * K * (transQ k)ᴴ : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ) x y = wrapSign k x * K (x + ev N k) (y + ev N k) * wrapSign k y := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (y + ev N k)]
  · rw [Matrix.mul_apply, Finset.sum_eq_single (x + ev N k)]
    · simp only [transQ, Matrix.of_apply, conjTranspose_apply, if_true, wrapSign_star]
    · intro z _ hz
      simp only [transQ, Matrix.of_apply, if_neg hz, zero_mul]
    · intro h; exact absurd (Finset.mem_univ _) h
  · intro z _ hz
    simp only [conjTranspose_apply, transQ, Matrix.of_apply, if_neg hz, star_zero, mul_zero]
  · intro h; exact absurd (Finset.mem_univ _) h

theorem transQ_unitary (k : Fin 3) : transQ (N := N) k * (transQ k)ᴴ = 1 := by
  ext x y
  have h := transQ_conj_apply k 1 x y
  rw [Matrix.mul_one] at h
  rw [h]
  by_cases hxy : x = y
  · subst hxy
    rw [Matrix.one_apply_eq, Matrix.one_apply_eq, mul_one, wrapSign_mul_self]
  · rw [Matrix.one_apply_ne (fun e => hxy (add_right_cancel e)), Matrix.one_apply_ne hxy, mul_zero, zero_mul]

/-- the signed translation on `colour × space` -/
noncomputable def transP (k : Fin 3) : Matrix (Fin 2 × (Fin 3 → Fin N)) (Fin 2 × (Fin 3 → Fin N)) ℂ :=
  (1 : Matrix (Fin 2) (Fin 2) ℂ) ⊗ₖ transQ k

theorem transP_unitary (k : Fin 3) : transP (N := N) k * (transP k)ᴴ = 1 := by
  unfold transP
  rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, Matrix.one_mul, transQ_unitary,
    one_kronecker_one]

theorem transP_conj_apply (k : Fin 3) (M : Matrix (Fin 2 × (Fin 3 → Fin N)) (Fin 2 × (Fin 3 → Fin N)) ℂ)
    (a b : Fin 2 × (Fin 3 → Fin N)) :
    (transP k * M * (transP k)ᴴ : Matrix (Fin 2 × (Fin 3 → Fin N)) (Fin 2 × (Fin 3 → Fin N)) ℂ) a b
      = wrapSign k a.2 * M (a.1, a.2 + ev N k) (b.1, b.2 + ev N k) * wrapSign k b.2 := by
  unfold transP
  rw [conjTranspose_kronecker, conjTranspose_one, kron_conj_apply, transQ_conj_apply]
  rfl

theorem torusX_trans (k i : Fin 3) (U : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) :
    torusX N (fun x i => U (x + ev N k) i) i = transP k * torusX N U i * (transP k)ᴴ := by
  ext ⟨c, x⟩ ⟨c', y⟩
  rw [transP_conj_apply]
  simp only [torusX, shiftMat_apply, torusLink, torusShift, Equiv.coe_addRight]
  have hiff : (x + ev N k = y + ev N k + -Pi.single i 1) ↔ (x = y + -Pi.single i 1) := by
    rw [add_right_comm y (ev N k), add_left_inj]
  have h1 : (if (x i).val + 1 = N then (-1 : ℂ) else 1) = wrapSign i x := rfl
  have h2 : (if ((x + ev N k) i).val + 1 = N then (-1 : ℂ) else 1) = wrapSign i (x + ev N k) := rfl
  rw [h1, h2]
  by_cases hA : x = y + -Pi.single i 1
  · have hB := hiff.2 hA
    have hy : y = x + ev N i := by rw [hA]; simp [ev]
    simp only [eq_true hA, eq_true hB, if_true, Matrix.smul_apply, smul_eq_mul]
    rw [hy, sign_identity k i x]
    ring
  · have hB : ¬ (x + ev N k = y + ev N k + -Pi.single i 1) := fun h => hA (hiff.1 h)
    simp only [eq_false hA, eq_false hB, if_false, mul_zero, zero_mul]

theorem blockDiagonal_trans (k : Fin 3) (u : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ) :
    blockDiagonal (fun x => u (x + ev N k)) = transP k * blockDiagonal u * (transP k)ᴴ := by
  ext ⟨c, x⟩ ⟨c', y⟩
  rw [transP_conj_apply]
  simp only [blockDiagonal_apply']
  by_cases hxy : x = y
  · subst hxy
    rw [if_pos rfl, if_pos rfl, mul_comm (wrapSign k x), mul_assoc, wrapSign_mul_self, mul_one]
  · rw [if_neg hxy, if_neg (fun e => hxy (add_right_cancel e)), mul_zero, zero_mul]

/-- the spatial translation of a physical configuration -/
def transPhys {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 :=
  fun l => ω (l.1, l.2.1 + ev N k, l.2.2)

theorem physSp_trans {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2) (t : ℕ) :
    physSp (transPhys k ω) t = fun x i => physSp ω t (x + ev N k) i := by
  funext x i
  unfold physSp transPhys
  split_ifs <;> rfl

theorem physT_trans {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2) (t : ℕ) :
    physT (transPhys k ω) t = fun x => physT ω t (x + ev N k) := by
  funext x
  unfold physT transPhys
  split_ifs <;> rfl

/-- **the determinant of the Wilson–Dirac operator is invariant under the spatial translations** -/
theorem physDirac_det_trans (hT : ℕ) (m : ℝ) (k : Fin 3) (ω : PhysLink N hT → SU2) :
    (physDirac N hT m (transPhys k ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  have eX : (fun t => torusX N (physSp (transPhys k ω) t))
      = fun t i => transP k * torusX N (physSp ω t) i * (transP k)ᴴ := by
    funext t i
    rw [physSp_trans]
    exact torusX_trans k i _
  have eV : (fun t => eps (sc hT t) • blockDiagonal (physT (transPhys k ω) t))
      = fun t => transP k * (eps (sc hT t) • blockDiagonal (physT ω t)) * (transP k)ᴴ := by
    funext t
    rw [physT_trans, blockDiagonal_trans, Matrix.mul_smul, Matrix.smul_mul]
  rw [eX, eV]
  exact det_std4_conj hT m (transP k) (transP_unitary k) _ _

theorem spS_trans (B : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (a : Fin 3 → Fin N) :
    spS N (fun x i => B (x + a) i) = spS N B := by
  unfold spS
  refine Fintype.sum_equiv (Equiv.addRight a) _ _ fun x => ?_
  simp only [Equiv.coe_addRight]
  refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
  rw [add_right_comm x (ev N i) a, add_right_comm x (ev N j) a]

theorem tmS_trans (B0 B1 : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (T : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ) (a : Fin 3 → Fin N) :
    tmS N (fun x i => B0 (x + a) i) (fun x i => B1 (x + a) i) (fun x => T (x + a)) = tmS N B0 B1 T := by
  unfold tmS
  refine Fintype.sum_equiv (Equiv.addRight a) _ _ fun x => ?_
  simp only [Equiv.coe_addRight]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [add_right_comm x (ev N i) a]

/-- **the Wilson action is invariant under the spatial translations** -/
theorem wilsonAction_trans (hT : ℕ) (k : Fin 3) (ω : PhysLink N hT → SU2) :
    wilsonAction N hT (transPhys k ω) = wilsonAction N hT ω := by
  unfold wilsonAction
  refine Finset.sum_congr rfl fun t _ => ?_
  rw [physSp_trans, physSp_trans, physT_trans, spS_trans, tmS_trans]

theorem wfWeight_trans (hT j : ℕ) (m β : ℝ) (k : Fin 3) (ω : PhysLink N hT → SU2) :
    wfWeight N hT j m β (transPhys k ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_trans, physDirac_det_trans]

/-- the link map of the translation -/
def linkTrans (hT : ℕ) (k : Fin 3) : PhysLink N hT ≃ PhysLink N hT :=
  Equiv.prodCongr (Equiv.refl _) (Equiv.prodCongr (Equiv.addRight (ev N k)) (Equiv.refl _))

theorem pi_trans_preserving (hT : ℕ) (k : Fin 3) :
    MeasurePreserving (transPhys (N := N) (hT := hT) k)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h := measurePreserving_arrowCongr' (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (linkTrans hT k).symm
    (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e : ⇑(MeasurableEquiv.arrowCongr' (linkTrans (N := N) hT k).symm (MeasurableEquiv.refl SU2))
      = transPhys k := by
    funext ω l; rfl
  rw [e] at h
  exact h

/-- **the normalised Wilson–fermion measure is invariant under the spatial translations** -/
theorem wfProb_trans (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) (k : Fin 3) :
    (wfProb N hT j m β).map (transPhys k) = wfProb N hT j m β := by
  have hT' := pi_trans_preserving (N := N) hT k
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (transPhys k ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_trans]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end GaugeDet

#print axioms GaugeDet.sign_identity
#print axioms GaugeDet.transQ_unitary
#print axioms GaugeDet.torusX_trans
#print axioms GaugeDet.blockDiagonal_trans
#print axioms GaugeDet.physDirac_det_trans
#print axioms GaugeDet.wilsonAction_trans
#print axioms GaugeDet.pi_trans_preserving
#print axioms GaugeDet.wfProb_trans
