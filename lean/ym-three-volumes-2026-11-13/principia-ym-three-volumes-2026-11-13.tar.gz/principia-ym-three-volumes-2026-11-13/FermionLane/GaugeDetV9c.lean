import FermionLane.GaugeV9

/-! # (file GaugeDet, version a): the determinant of the Wilson–Dirac operator is invariant under
global gauge transformations, and `hsym` of the box chain without premise

Paper side: (the Kronecker route), For a unit quaternion `g`, `G = quatMat g`,
`P = G ⊗ 1_space` on `L = colour × space`, `W = 1_time ⊗ P`:
* `hopSp_conj`, `hopT_conj`, `hop4_conj`: the hops of the conjugated links are `W H Wᴴ`;
* `massPart_conj`, `antiPart_conj`: the Clifford parts are conjugated by `W`;
* `det_std4_conj`: `det std4 (P X Pᴴ) (P v Pᴴ) = det std4 X v` for every unitary `P`;
* `torusX_conj`, `blockDiagonal_conj`: the spatial hops and the time links of `gωg⁻¹` are `P (·) Pᴴ`;
* **`physDirac_det_conj`**: `det D(gωg⁻¹) = det D(ω)` (the premise `hdet`);
* **`hsym_box_fermion_gauge`**: the field `hsym` of the box chain for the Wilson–fermion family and the global
  gauge transformations, without premise (all `j`, all `m_n`, `β_n`). -/

namespace GaugeDet

open Matrix FermionSliceBlock
open scoped Kronecker

section Lift

variable {T L : Type*} [Fintype T] [DecidableEq T] [Fintype L] [DecidableEq L]

theorem conjT_conj {n : Type*} [Fintype n] (W A : Matrix n n ℂ) : (W * A * Wᴴ)ᴴ = W * Aᴴ * Wᴴ := by
  rw [conjTranspose_mul, conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]

theorem det_conj_unitary {n : Type*} [Fintype n] [DecidableEq n] (W B : Matrix n n ℂ) (hW : W * Wᴴ = 1) :
    (W * B * Wᴴ).det = B.det := by
  rw [det_mul, det_mul, mul_comm W.det, mul_assoc, ← det_mul, hW, det_one, mul_one]

/-- left multiplication by `1 ⊗ P` acts on the second index -/
theorem kron_mul_apply (P : Matrix L L ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    (((1 : Matrix T T ℂ) ⊗ₖ P) * M) a b = ∑ l, P a.2 l * M (a.1, l) b := by
  rw [Matrix.mul_apply, Fintype.sum_prod_type, Finset.sum_eq_single a.1]
  · refine Finset.sum_congr rfl fun l _ => ?_
    rw [kroneckerMap_apply, Matrix.one_apply_eq, one_mul]
  · intro y _ hy
    refine Finset.sum_eq_zero fun l _ => ?_
    rw [kroneckerMap_apply, Matrix.one_apply_ne (Ne.symm hy), zero_mul, zero_mul]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- right multiplication by `1 ⊗ Q` acts on the second index -/
theorem mul_kron_apply (Q : Matrix L L ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    (M * ((1 : Matrix T T ℂ) ⊗ₖ Q)) a b = ∑ l, M a (b.1, l) * Q l b.2 := by
  rw [Matrix.mul_apply, Fintype.sum_prod_type, Finset.sum_eq_single b.1]
  · refine Finset.sum_congr rfl fun l _ => ?_
    rw [kroneckerMap_apply, Matrix.one_apply_eq, one_mul]
  · intro y _ hy
    refine Finset.sum_eq_zero fun l _ => ?_
    rw [kroneckerMap_apply, Matrix.one_apply_ne hy, zero_mul, mul_zero]
  · intro h; exact absurd (Finset.mem_univ _) h

/-- the entries of `(1 ⊗ P) M (1 ⊗ Q)` -/
theorem kron_conj_apply (P Q : Matrix L L ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    (((1 : Matrix T T ℂ) ⊗ₖ P) * M * ((1 : Matrix T T ℂ) ⊗ₖ Q)) a b
      = (P * Matrix.of (fun l l' => M (a.1, l) (b.1, l')) * Q) a.2 b.2 := by
  rw [mul_kron_apply]
  simp only [kron_mul_apply]
  simp only [Matrix.mul_apply, Matrix.of_apply]

/-- left multiplication by `G ⊗ 1` acts on the first index -/
theorem kron1_mul_apply (G : Matrix T T ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    ((G ⊗ₖ (1 : Matrix L L ℂ)) * M) a b = ∑ c, G a.1 c * M (c, a.2) b := by
  rw [Matrix.mul_apply, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun c _ => ?_
  rw [Finset.sum_eq_single a.2]
  · rw [kroneckerMap_apply, Matrix.one_apply_eq, mul_one]
  · intro y _ hy
    rw [kroneckerMap_apply, Matrix.one_apply_ne (Ne.symm hy), mul_zero, zero_mul]
  · intro h; exact absurd (Finset.mem_univ _) h

theorem mul_kron1_apply (H : Matrix T T ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    (M * (H ⊗ₖ (1 : Matrix L L ℂ))) a b = ∑ c, M a (c, b.2) * H c b.1 := by
  rw [Matrix.mul_apply, Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun c _ => ?_
  rw [Finset.sum_eq_single b.2]
  · rw [kroneckerMap_apply, Matrix.one_apply_eq, mul_one]
  · intro y _ hy
    rw [kroneckerMap_apply, Matrix.one_apply_ne hy, mul_zero, mul_zero]
  · intro h; exact absurd (Finset.mem_univ _) h

theorem kron1_conj_apply (G H : Matrix T T ℂ) (M : Matrix (T × L) (T × L) ℂ) (a b : T × L) :
    ((G ⊗ₖ (1 : Matrix L L ℂ)) * M * (H ⊗ₖ (1 : Matrix L L ℂ))) a b
      = (G * Matrix.of (fun c c' => M (c, a.2) (c', b.2)) * H) a.1 b.1 := by
  rw [mul_kron1_apply]
  simp only [kron1_mul_apply]
  simp only [Matrix.mul_apply, Matrix.of_apply]

end Lift

/-! ## the hops and the Clifford parts -/
section Hops

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- the lift `1_time ⊗ P` -/
noncomputable def liftT (h : ℕ) (P : Matrix L L ℂ) : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  (1 : Matrix (Fin (2 * h)) (Fin (2 * h)) ℂ) ⊗ₖ P

theorem liftT_conjTranspose (h : ℕ) (P : Matrix L L ℂ) : (liftT h P)ᴴ = liftT h Pᴴ := by
  unfold liftT; rw [conjTranspose_kronecker, conjTranspose_one]

theorem liftT_mul_conjTranspose (h : ℕ) (P : Matrix L L ℂ) (hP : P * Pᴴ = 1) :
    liftT h P * (liftT h P)ᴴ = 1 := by
  rw [liftT_conjTranspose]; unfold liftT
  rw [← mul_kronecker_mul, Matrix.one_mul, hP, one_kronecker_one]

theorem hopSp_conj (h : ℕ) (P : Matrix L L ℂ) (X : ℕ → Fin 3 → Matrix L L ℂ) (i : Fin 3) :
    hopSp h (fun t i => P * X t i * Pᴴ) i = liftT h P * hopSp h X i * liftT h Pᴴ := by
  ext a b
  unfold liftT
  rw [kron_conj_apply]
  unfold hopSp
  by_cases hb : b.1.val = a.1.val
  · simp only [hb, if_true]; rfl
  · have e : (Matrix.of fun (l l' : L) => (if b.1.val = a.1.val then X a.1.val i l l' else 0)) = 0 := by
      ext l l'; simp [hb]
    simp only [hb, if_false]
    rw [show (Matrix.of fun (l l' : L) => (0 : ℂ)) = 0 from by ext; rfl]
    simp

theorem hopT_conj (h : ℕ) (P : Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hopT h (fun t => P * v t * Pᴴ) = liftT h P * hopT h v * liftT h Pᴴ := by
  ext a b
  unfold liftT
  rw [kron_conj_apply]
  unfold hopT
  by_cases hb : b.1.val = sc h a.1.val
  · simp only [hb, if_true]; rfl
  · simp only [hb, if_false]
    rw [show (Matrix.of fun (l l' : L) => (0 : ℂ)) = 0 from by ext; rfl]
    simp

theorem hop4_conj (h : ℕ) (P : Matrix L L ℂ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) (μ : Fin 4) :
    hop4 h (fun t i => P * X t i * Pᴴ) (fun t => P * v t * Pᴴ) μ
      = liftT h P * hop4 h X v μ * (liftT h P)ᴴ := by
  rw [liftT_conjTranspose]
  unfold hop4
  split_ifs
  · exact hopSp_conj h P X _
  · exact hopT_conj h P v

theorem hop4_conj_star (h : ℕ) (P : Matrix L L ℂ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ)
    (μ : Fin 4) :
    (hop4 h (fun t i => P * X t i * Pᴴ) (fun t => P * v t * Pᴴ) μ)ᴴ
      = liftT h P * (hop4 h X v μ)ᴴ * (liftT h P)ᴴ := by
  rw [hop4_conj, conjTranspose_mul, conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]

theorem massPart_conj (h : ℕ) (m : ℝ) (P : Matrix L L ℂ) (hP : P * Pᴴ = 1) (X : ℕ → Fin 3 → Matrix L L ℂ)
    (v : ℕ → Matrix L L ℂ) :
    massPart h m (fun t i => P * X t i * Pᴴ) (fun t => P * v t * Pᴴ)
      = liftT h P * massPart h m X v * (liftT h P)ᴴ := by
  unfold massPart
  simp only [hop4_conj, conjT_conj]
  rw [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one,
    liftT_mul_conjTranspose h P hP, Matrix.mul_smul, Matrix.smul_mul, Finset.mul_sum, Finset.sum_mul]
  congr 2
  refine Finset.sum_congr rfl fun μ _ => ?_
  rw [Matrix.mul_add, Matrix.add_mul]

theorem antiPart_conj (h : ℕ) (P : Matrix L L ℂ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ)
    (μ : Fin 4) :
    antiPart h (fun t i => P * X t i * Pᴴ) (fun t => P * v t * Pᴴ) μ
      = liftT h P * antiPart h X v μ * (liftT h P)ᴴ := by
  unfold antiPart
  rw [hop4_conj, conjT_conj, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_sub, Matrix.sub_mul]

/-- **the determinant of the textbook Wilson operator is invariant under conjugation of all links by one
unitary `P`** -/
theorem det_std4_conj (h : ℕ) (m : ℝ) (P : Matrix L L ℂ) (hP : P * Pᴴ = 1) (X : ℕ → Fin 3 → Matrix L L ℂ)
    (v : ℕ → Matrix L L ℂ) :
    (std4 h m (fun t i => P * X t i * Pᴴ) (fun t => P * v t * Pᴴ)).det = (std4 h m X v).det := by
  rw [det_std4_eq_clifford, det_std4_eq_clifford, massPart_conj h m P hP]
  simp only [antiPart_conj]
  have hk : ∀ (A : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) (B : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ),
      A ⊗ₖ (liftT h P * B * (liftT h P)ᴴ)
        = ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ liftT h P) * (A ⊗ₖ B)
          * ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ liftT h P)ᴴ := by
    intro A B
    rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, ← mul_kronecker_mul, Matrix.one_mul,
      Matrix.mul_one]
  have hVV : ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ liftT h P)
      * ((1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ liftT h P)ᴴ = 1 := by
    rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, Matrix.one_mul,
      liftT_mul_conjTranspose h P hP, one_kronecker_one]
  simp only [hk]
  rw [← Finset.sum_mul, ← Finset.mul_sum, ← Matrix.add_mul, ← Matrix.mul_add]
  exact det_conj_unitary _ _ hVV

end Hops

/-! ## the physical links -/
section Phys

variable {C S : Type*} [Fintype C] [DecidableEq C] [Fintype S] [DecidableEq S]

theorem shiftMat_conj (σ : S ≃ S) (G H : Matrix C C ℂ) (u : S → Matrix C C ℂ) :
    shiftMat σ (fun x => G * u x * H) = (G ⊗ₖ (1 : Matrix S S ℂ)) * shiftMat σ u * (H ⊗ₖ (1 : Matrix S S ℂ)) := by
  ext ⟨c, x⟩ ⟨c', y⟩
  rw [kron1_conj_apply]
  simp only [shiftMat_apply]
  by_cases hx : x = σ y
  · simp only [hx, if_true]; rfl
  · simp only [hx, if_false]
    rw [show (Matrix.of fun (l l' : C) => (0 : ℂ)) = 0 from by ext; rfl]
    simp

theorem blockDiagonal_conj (G H : Matrix C C ℂ) (u : S → Matrix C C ℂ) :
    blockDiagonal (fun x => G * u x * H)
      = (G ⊗ₖ (1 : Matrix S S ℂ)) * blockDiagonal u * (H ⊗ₖ (1 : Matrix S S ℂ)) := by
  ext ⟨c, x⟩ ⟨c', y⟩
  rw [kron1_conj_apply]
  simp only [blockDiagonal_apply']
  by_cases hx : x = y
  · simp only [hx, if_true]; rfl
  · simp only [hx, if_false]
    rw [show (Matrix.of fun (l l' : C) => (0 : ℂ)) = 0 from by ext; rfl]
    simp

theorem torusX_conj (N : ℕ) [NeZero N] (G : Matrix C C ℂ) (U : (Fin 3 → Fin N) → Fin 3 → Matrix C C ℂ)
    (i : Fin 3) :
    torusX N (fun x i => G * U x i * Gᴴ) i
      = (G ⊗ₖ (1 : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ)) * torusX N U i
        * (G ⊗ₖ (1 : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ))ᴴ := by
  rw [conjTranspose_kronecker, conjTranspose_one]
  unfold torusX
  rw [← shiftMat_conj]
  congr 1
  funext x
  unfold torusLink
  rw [Matrix.mul_smul, Matrix.smul_mul]

end Phys

section Dirac

open WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

/-- the colour lift `P = G ⊗ 1_space` of a unit quaternion -/
noncomputable def colourLift (N : ℕ) (g : SU2) :
    Matrix (Fin 2 × (Fin 3 → Fin N)) (Fin 2 × (Fin 3 → Fin N)) ℂ :=
  quatMat (g : Quaternion ℝ) ⊗ₖ (1 : Matrix (Fin 3 → Fin N) (Fin 3 → Fin N) ℂ)

theorem quatMat_mul_star (g : SU2) : quatMat (g : Quaternion ℝ) * (quatMat (g : Quaternion ℝ))ᴴ = 1 := by
  rw [← quatMat_star, ← quatMat_mul, mul_star_self_unit (mem_sphere_zero_iff_norm.mp g.2), quatMat_one']

theorem colourLift_unitary (N : ℕ) (g : SU2) : colourLift N g * (colourLift N g)ᴴ = 1 := by
  unfold colourLift
  rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, quatMat_mul_star, Matrix.one_mul,
    one_kronecker_one]

theorem physX_conj (N : ℕ) [NeZero N] {hT : ℕ} (g : SU2) (ω : PhysLink N hT → SU2) (t : ℕ) (i : Fin 3) :
    torusX N (physSp (conjPhys g ω) t) i = colourLift N g * torusX N (physSp ω t) i * (colourLift N g)ᴴ := by
  have e : physSp (conjPhys g ω) t
      = fun x i => quatMat (g : Quaternion ℝ) * physSp ω t x i * (quatMat (g : Quaternion ℝ))ᴴ := by
    funext x i; exact physSp_conj g ω t x i
  rw [e, torusX_conj]
  rfl

theorem physV_conj (N : ℕ) [NeZero N] {hT : ℕ} (g : SU2) (ω : PhysLink N hT → SU2) (t : ℕ) :
    eps (sc hT t) • blockDiagonal (physT (conjPhys g ω) t)
      = colourLift N g * (eps (sc hT t) • blockDiagonal (physT ω t)) * (colourLift N g)ᴴ := by
  have e : physT (conjPhys g ω) t
      = fun x => quatMat (g : Quaternion ℝ) * physT ω t x * (quatMat (g : Quaternion ℝ))ᴴ := by
    funext x; exact physT_conj g ω t x
  rw [e, blockDiagonal_conj, Matrix.mul_smul, Matrix.smul_mul]
  unfold colourLift
  rw [conjTranspose_kronecker, conjTranspose_one]

/-- **`hdet`: the determinant of the Wilson–Dirac operator is invariant under global gauge transformations**
(every `N`, `hT`, `m`, `ω`, `g ∈ SU(2)`) -/
theorem physDirac_det_conj (N : ℕ) [NeZero N] (hT : ℕ) (m : ℝ) (g : SU2) (ω : PhysLink N hT → SU2) :
    (physDirac N hT m (conjPhys g ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  have eX : (fun t => torusX N (physSp (conjPhys g ω) t))
      = fun t i => colourLift N g * torusX N (physSp ω t) i * (colourLift N g)ᴴ := by
    funext t i; exact physX_conj N g ω t i
  have eV : (fun t => eps (sc hT t) • blockDiagonal (physT (conjPhys g ω) t))
      = fun t => colourLift N g * (eps (sc hT t) • blockDiagonal (physT ω t)) * (colourLift N g)ᴴ := by
    funext t; exact physV_conj N g ω t
  rw [eX, eV]
  exact det_std4_conj hT m (colourLift N g) (colourLift_unitary N g) _ _

end Dirac

end GaugeDet

namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config

/-- **`hsym` of the box chain for the Wilson–fermion family and the global gauge transformations, without
premise** (all `j`, all `m_n`, `β_n`; the group is the constant gauge transformations `g ∈ SU(2)`) -/
theorem hsym_box_fermion_gauge (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (g : SU2)
    (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (conjCfg (g : Quaternion ℝ) (mem_sphere_zero_iff_norm.mp g.2) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) :=
  hsym_box_fermion_of_det L hr j mseq βseq g
    (fun n ω => GaugeDet.physDirac_det_conj _ _ _ g ω) m

/-- the density `exp(−β S_W) Re det D^{2j}` is gauge invariant (every level) -/
theorem wfWeight_conj (N : ℕ) [NeZero N] (hT j : ℕ) (m β : ℝ) (g : SU2) (ω : PhysLink N hT → SU2) :
    wfWeight N hT j m β (conjPhys g ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_conj, GaugeDet.physDirac_det_conj]

end BoxFermion

#print axioms GaugeDet.hopSp_conj
#print axioms GaugeDet.hopT_conj
#print axioms GaugeDet.massPart_conj
#print axioms GaugeDet.antiPart_conj
#print axioms GaugeDet.det_std4_conj
#print axioms GaugeDet.shiftMat_conj
#print axioms GaugeDet.blockDiagonal_conj
#print axioms GaugeDet.torusX_conj
#print axioms GaugeDet.physDirac_det_conj
#print axioms BoxFermion.hsym_box_fermion_gauge
#print axioms BoxFermion.wfWeight_conj
