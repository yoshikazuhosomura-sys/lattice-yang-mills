import FermionLane.CubicLatV10c

/-! # Cubic symmetry of the Wilson–Dirac determinant on the physical configurations

* `rotPhys a b hab ω` (`a ≠ b` spatial): the configuration rotated by 90° in the plane `(a, b)`
  (`e_a ↦ e_b ↦ − e_a`, sites relabelled by `rotSite`): the `b`-links are the old `a`-links, the `a`-links are the
  reversed (inverse) old `b`-links, the other links are carried along.
* `reflPhys k ω`: the configuration reflected in the spatial axis `k` (`reflSite`): the `k`-links are the reversed
  old `k`-links, the other links are carried along.
* **`physDirac_det_rot`**, **`physDirac_det_refl`**: the determinant of the Wilson–Dirac operator (antiperiodic in
  all four directions) is unchanged.  With the global gauge transformations and the four lattice translations, this
  gives every generator of the symmetry group of the spatial cubic lattice (rotations of the spatial planes, axis
  reflections); rotations involving time are not included (they need the isotropic box `2h = N` and an operator
  with the time direction on the same footing). -/

namespace CubicSym

open Matrix MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

variable {N : ℕ} [NeZero N]

/-- the configuration rotated by 90° in the spatial plane `(a, b)` -/
noncomputable def rotPhys {hT : ℕ} (a b : Fin 3) (hab : a ≠ b) (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 := fun l =>
  if l.2.2 = b.castSucc then ω (l.1, (rotSite a b hab).symm l.2.1, a.castSucc)
  else if l.2.2 = a.castSucc then (ω (l.1, (rotSite a b hab).symm (l.2.1 + Pi.single a 1), b.castSucc))⁻¹
  else ω (l.1, (rotSite a b hab).symm l.2.1, l.2.2)

/-- the configuration reflected in the spatial axis `k` -/
noncomputable def reflPhys {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 := fun l =>
  if l.2.2 = k.castSucc then (ω (l.1, (reflSite k).symm (l.2.1 + Pi.single k 1), k.castSucc))⁻¹
  else ω (l.1, (reflSite k).symm l.2.1, l.2.2)

theorem three_ne_castSucc (i : Fin 3) : (3 : Fin 4) ≠ i.castSucc := fun h => last_ne_castSucc i h

section Rot

variable {hT : ℕ} (a b : Fin 3) (hab : a ≠ b) (ω : PhysLink N hT → SU2)

theorem physSp_rot_b (t : ℕ) (y : Fin 3 → Fin N) :
    physSp (rotPhys a b hab ω) t y b = physSp ω t ((rotSite a b hab).symm y) a := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [rotPhys, if_true]
  · rw [dif_neg ht, dif_neg ht]

theorem physSp_rot_a (t : ℕ) (y : Fin 3 → Fin N) :
    physSp (rotPhys a b hab ω) t y a = (physSp ω t ((rotSite a b hab).symm (y + Pi.single a 1)) b)ᴴ := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [rotPhys, if_neg (castSucc_ne_castSucc hab), if_true]
    exact quatMat_inv _
  · rw [dif_neg ht, dif_neg ht, conjTranspose_one]

theorem physSp_rot_c (i : Fin 3) (hia : i ≠ a) (hib : i ≠ b) (t : ℕ) (y : Fin 3 → Fin N) :
    physSp (rotPhys a b hab ω) t y i = physSp ω t ((rotSite a b hab).symm y) i := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [rotPhys, if_neg (castSucc_ne_castSucc hib), if_neg (castSucc_ne_castSucc hia)]
  · rw [dif_neg ht, dif_neg ht]

theorem physT_rot (t : ℕ) (y : Fin 3 → Fin N) :
    physT (rotPhys a b hab ω) t y = physT ω t ((rotSite a b hab).symm y) := by
  unfold physT
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [rotPhys, if_neg (three_ne_castSucc b), if_neg (three_ne_castSucc a)]
  · rw [dif_neg ht, dif_neg ht]

/-- **the determinant of the Wilson–Dirac operator is invariant under the 90° rotations of the spatial planes** -/
theorem physDirac_det_rot (m : ℝ) :
    (physDirac N hT m (rotPhys a b hab ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  refine det_std4_rot hT m (permP (rotSite a b hab)) (permP_unitary _) a b hab _ _ _ _ ?_ ?_ ?_ ?_
  · intro t
    refine (torusX_fwd _ a b (rot_fwd_a a b hab) (fun x => ?_) _ _ fun y => physSp_rot_b a b hab ω t y).symm
    rw [rotSite_apply, if_pos rfl]
  · intro t
    refine (torusX_bwd _ b a (rot_bwd_b a b hab) (fun x => ?_) _ _ fun y => physSp_rot_a a b hab ω t y).symm
    rw [rotSite_apply, if_neg hab, if_pos rfl]
    simp only [Pi.add_apply, Pi.single_eq_same]
    exact rev_succ_cut _
  · intro t i hia hib
    refine (torusX_fwd _ i i (rot_fwd_c a b hab i hia hib) (fun x => ?_) _ _
      fun y => physSp_rot_c a b hab ω i hia hib t y).symm
    rw [rotSite_apply, if_neg hib, if_neg hia]
  · intro t
    rw [Matrix.mul_smul, Matrix.smul_mul, ← blockDiagonal_perm]
    congr 2
    funext y
    exact (physT_rot a b hab ω t y).symm

end Rot

section Refl

variable {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2)

theorem physSp_refl_k (t : ℕ) (y : Fin 3 → Fin N) :
    physSp (reflPhys k ω) t y k = (physSp ω t ((reflSite k).symm (y + Pi.single k 1)) k)ᴴ := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [reflPhys, if_true]
    exact quatMat_inv _
  · rw [dif_neg ht, dif_neg ht, conjTranspose_one]

theorem physSp_refl_o (i : Fin 3) (hik : i ≠ k) (t : ℕ) (y : Fin 3 → Fin N) :
    physSp (reflPhys k ω) t y i = physSp ω t ((reflSite k).symm y) i := by
  unfold physSp
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [reflPhys, if_neg (castSucc_ne_castSucc hik)]
  · rw [dif_neg ht, dif_neg ht]

theorem physT_refl (t : ℕ) (y : Fin 3 → Fin N) :
    physT (reflPhys k ω) t y = physT ω t ((reflSite k).symm y) := by
  unfold physT
  by_cases ht : t < 2 * hT
  · rw [dif_pos ht, dif_pos ht]
    simp only [reflPhys, if_neg (three_ne_castSucc k)]
  · rw [dif_neg ht, dif_neg ht]

/-- **the determinant of the Wilson–Dirac operator is invariant under the reflections of the spatial axes** -/
theorem physDirac_det_refl (m : ℝ) :
    (physDirac N hT m (reflPhys k ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  refine det_std4_refl hT m (permP (reflSite k)) (permP_unitary _) k _ _ _ _ ?_ ?_ ?_
  · intro t
    refine (torusX_bwd _ k k (refl_bwd k) (fun x => ?_) _ _ fun y => physSp_refl_k k ω t y).symm
    rw [reflSite_apply, if_pos rfl]
    simp only [Pi.add_apply, Pi.single_eq_same]
    exact rev_succ_cut _
  · intro t i hik
    refine (torusX_fwd _ i i (refl_fwd k i hik) (fun x => ?_) _ _ fun y => physSp_refl_o k ω i hik t y).symm
    rw [reflSite_apply, if_neg hik]
  · intro t
    rw [Matrix.mul_smul, Matrix.smul_mul, ← blockDiagonal_perm]
    congr 2
    funext y
    exact (physT_refl k ω t y).symm

end Refl

end CubicSym

#print axioms CubicSym.physDirac_det_rot
#print axioms CubicSym.physDirac_det_refl
