import FermionLane.CubicRotActV10c
import FermionLane.TimeReflActV10b

/-! # The generators of the lattice symmetries of the normalised Wilson–fermion measure, together

For the normalised Wilson–fermion measure `wfProb` (Wilson action, `Re det D^{2j}` with the Wilson–Dirac operator,
`r = 1`, antiperiodic in all four directions; spatial torus `(Fin N)³`, time circle `2h`), the push-forward under
each generator equals the measure: global gauge transformations, unit translations in the three spatial directions
and in time, the 90° rotations of the spatial planes, the reflections of the spatial axes, and the time reflection.
(Rotations mixing time and space, which need `2h = N`, are not included.) -/

namespace CubicSym

open MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion TimeShift

/-- **all generators at once** -/
theorem wfProb_lattice_generators (N : ℕ) [NeZero N] (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    (∀ g : SU2, (wfProb N hT j m β).map (conjPhys g) = wfProb N hT j m β) ∧
    (∀ k : Fin 3, (wfProb N hT j m β).map (transPhys k) = wfProb N hT j m β) ∧
    ((wfProb N hT j m β).map tshiftPhys = wfProb N hT j m β) ∧
    (∀ (a b : Fin 3) (hab : a ≠ b), (wfProb N hT j m β).map (rotPhys a b hab) = wfProb N hT j m β) ∧
    (∀ k : Fin 3, (wfProb N hT j m β).map (reflPhys k) = wfProb N hT j m β) ∧
    ((wfProb N hT j m β).map treflPhys = wfProb N hT j m β) :=
  ⟨fun g => wfProb_conj_of_weight j m β g (fun ω => wfWeight_conj N hT j m β g ω) hpos,
    fun k => wfProb_trans hT hpos j m β k, wfProb_tshift hT hpos j m β,
    fun a b hab => wfProb_rot hT hpos j m β a b hab, fun k => wfProb_refl hT hpos j m β k,
    wfProb_trefl hT hpos j m β⟩

end CubicSym

#print axioms CubicSym.wfProb_lattice_generators
