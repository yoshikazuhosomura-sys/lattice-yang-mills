import FermionLane.LatticeSymV10a
import FermionLane.TimeRotActV10c

/-! # The generators of the hypercubic symmetries on the isotropic lattice, together

On the isotropic lattice (spatial torus `(Fin (2h))³`, time circle `2h`, antiperiodic fermions in all four
directions) the normalised Wilson–fermion measure is invariant under each generator: global gauge transformations,
unit translations in all four directions, 90° rotations in the spatial planes and in the (space, time) planes,
reflections of the spatial axes and of time. -/

namespace CubicSym

open MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion TimeShift

/-- **all generators of the hypercubic lattice symmetries at once (isotropic lattice)** -/
theorem wfProb_hypercubic_generators (h : ℕ) [NeZero (2 * h)] (hpos : 0 < h) (j : ℕ) (m β : ℝ) :
    (∀ g : SU2, (wfProb (2 * h) h j m β).map (conjPhys g) = wfProb (2 * h) h j m β) ∧
    (∀ k : Fin 3, (wfProb (2 * h) h j m β).map (transPhys k) = wfProb (2 * h) h j m β) ∧
    ((wfProb (2 * h) h j m β).map tshiftPhys = wfProb (2 * h) h j m β) ∧
    (∀ (a b : Fin 3) (hab : a ≠ b), (wfProb (2 * h) h j m β).map (rotPhys a b hab) = wfProb (2 * h) h j m β) ∧
    (∀ a : Fin 3, (wfProb (2 * h) h j m β).map (trotPhys a) = wfProb (2 * h) h j m β) ∧
    (∀ k : Fin 3, (wfProb (2 * h) h j m β).map (reflPhys k) = wfProb (2 * h) h j m β) ∧
    ((wfProb (2 * h) h j m β).map treflPhys = wfProb (2 * h) h j m β) := by
  obtain ⟨h1, h2, h3, h4, h5, h6⟩ := wfProb_lattice_generators (2 * h) h hpos j m β
  exact ⟨h1, h2, h3, h4, fun a => wfProb_trot hpos j m β a, h5, h6⟩

end CubicSym

#print axioms CubicSym.wfProb_hypercubic_generators
