import FermionLane.CubicCliffV10b

/-! # Cubic symmetry of the Wilson–Dirac operator on the lattice: 90° rotations in the spatial planes and the
reflections of the spatial axes

The spatial torus `(Fin N)³` is isotropic, the fermions are antiperiodic.  The coordinate reversal is
`rev z = N − 1 − z`, which keeps the antiperiodic cut (the link `N − 1 → 0`) in place.
* `rotSite a b`: `(ρx)_b = x_a`, `(ρx)_a = rev(x_b)` (`e_a ↦ e_b ↦ − e_a`); `reflSite k`: `(rx)_k = rev(x_k)`.
* `permP ρ = 1_colour ⊗ (permutation matrix of ρ)`: conjugation relabels the sites (no signs are needed: the cut
  stays in place).
* `torusX_fwd`, `torusX_bwd`: a hop that is carried forward (`ρ(x + e_i) = ρx + e_j`) or backward
  (`ρ(x + e_i) + e_j = ρx`) by `ρ`, with the antiperiodic signs matching.
* `det_std4_rot`, `det_std4_refl`: the operator level, through `det_cliffOp_perm` and the spin factors
  `rot_spin` (`1 + γ_b γ_a`) and `refl_spin` (`γ_a γ_b γ_c`, the other three directions).
* **`physDirac_det_rot`**, **`physDirac_det_refl`**: `det D(Rω) = det D(ω)` for the rotated / reflected physical
  configuration (reversed links carry the inverse). -/

namespace CubicSym

open Matrix FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

section Hops

variable {L : Type*} [Fintype L] [DecidableEq L]

theorem hop4_castSucc (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) (i : Fin 3) :
    hop4 h X v i.castSucc = hopSp h X i := by
  unfold hop4
  rw [dif_pos (by simp)]
  rfl

theorem hop4_last (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    hop4 h X v (Fin.last 3) = hopT h v := by
  unfold hop4
  rw [dif_neg (by simp)]

theorem hopSp_star (h : ℕ) (X : ℕ → Fin 3 → Matrix L L ℂ) (i : Fin 3) :
    hopSp h (fun t i => (X t i)ᴴ) i = (hopSp h X i)ᴴ := by
  ext a b
  simp only [hopSp, conjTranspose_apply]
  by_cases hb : b.1.val = a.1.val
  · rw [if_pos hb, if_pos hb.symm, hb]
  · rw [if_neg hb, if_neg (fun e => hb e.symm), star_zero]

theorem hopSp_congr (h : ℕ) (Y Z : ℕ → Fin 3 → Matrix L L ℂ) (i j : Fin 3) (hYZ : ∀ t, Y t i = Z t j) :
    hopSp h Y i = hopSp h Z j := by
  ext a b
  simp only [hopSp, hYZ]

theorem castSucc_ne_castSucc {i j : Fin 3} (h : i ≠ j) : i.castSucc ≠ j.castSucc :=
  fun e => h (Fin.castSucc_injective _ e)

theorem last_ne_castSucc (i : Fin 3) : Fin.last 3 ≠ i.castSucc := (Fin.castSucc_lt_last i).ne'

/-- **the operator level of the rotation in the plane `(a, b)`** -/
theorem det_std4_rot (h : ℕ) (m : ℝ) (P : Matrix L L ℂ) (hP : P * Pᴴ = 1) (a b : Fin 3) (hab : a ≠ b)
    (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hXa : ∀ t, P * X t a * Pᴴ = X' t b) (hXb : ∀ t, P * X t b * Pᴴ = (X' t a)ᴴ)
    (hXc : ∀ t i, i ≠ a → i ≠ b → P * X t i * Pᴴ = X' t i) (hv : ∀ t, P * v t * Pᴴ = v' t) :
    (std4 h m X' v').det = (std4 h m X v).det := by
  rw [det_std4_eq_cliffOp, det_std4_eq_cliffOp]
  have hab' := castSucc_ne_castSucc hab
  refine det_cliffOp_perm m (liftT h P) (liftT_mul_conjTranspose h P hP) _ _
    (Equiv.swap a.castSucc b.castSucc) (fun μ => μ ≠ b.castSucc) ?_ ⟨_, _, rot_spin _ _ hab'⟩
  intro μ
  induction μ using Fin.lastCases with
  | last =>
    rw [if_pos (last_ne_castSucc b), Equiv.swap_apply_of_ne_of_ne (last_ne_castSucc a) (last_ne_castSucc b),
      hop4_last, hop4_last, liftT_conjTranspose, ← hopT_conj]
    congr 1
    funext t
    exact hv t
  | cast i =>
    rw [hop4_castSucc, liftT_conjTranspose, ← hopSp_conj]
    by_cases hia : i = a
    · rw [hia, if_pos hab', Equiv.swap_apply_left, hop4_castSucc]
      exact hopSp_congr h _ _ a b hXa
    · by_cases hib : i = b
      · rw [hib, if_neg (not_not.mpr rfl), Equiv.swap_apply_right, hop4_castSucc, ← hopSp_star]
        exact hopSp_congr h _ _ b a hXb
      · rw [if_pos (castSucc_ne_castSucc hib),
          Equiv.swap_apply_of_ne_of_ne (castSucc_ne_castSucc hia) (castSucc_ne_castSucc hib), hop4_castSucc]
        exact hopSp_congr h _ _ i i fun t => hXc t i hia hib

theorem exists_refl_spin (k : Fin 3) :
    ∃ S T : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ, S * T = 1 ∧
      ∀ μ, S * gammaAll μ * T = if μ ≠ k.castSucc then gammaAll ((Equiv.refl (Fin 4)) μ)
        else -gammaAll ((Equiv.refl (Fin 4)) μ) := by
  fin_cases k
  · exact ⟨_, _, refl_spin 1 2 3 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)⟩
  · exact ⟨_, _, refl_spin 0 2 3 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)⟩
  · exact ⟨_, _, refl_spin 0 1 3 2 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)⟩

/-- **the operator level of the reflection of the spatial axis `k`** -/
theorem det_std4_refl (h : ℕ) (m : ℝ) (P : Matrix L L ℂ) (hP : P * Pᴴ = 1) (k : Fin 3)
    (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hXk : ∀ t, P * X t k * Pᴴ = (X' t k)ᴴ)
    (hXo : ∀ t i, i ≠ k → P * X t i * Pᴴ = X' t i) (hv : ∀ t, P * v t * Pᴴ = v' t) :
    (std4 h m X' v').det = (std4 h m X v).det := by
  rw [det_std4_eq_cliffOp, det_std4_eq_cliffOp]
  refine det_cliffOp_perm m (liftT h P) (liftT_mul_conjTranspose h P hP) _ _
    (Equiv.refl (Fin 4)) (fun μ => μ ≠ k.castSucc) ?_ (exists_refl_spin k)
  intro μ
  induction μ using Fin.lastCases with
  | last =>
    rw [if_pos (last_ne_castSucc k), Equiv.refl_apply, hop4_last, hop4_last, liftT_conjTranspose, ← hopT_conj]
    congr 1
    funext t
    exact hv t
  | cast i =>
    rw [hop4_castSucc, liftT_conjTranspose, ← hopSp_conj, Equiv.refl_apply]
    by_cases hik : i = k
    · rw [hik, if_neg (not_not.mpr rfl), hop4_castSucc, ← hopSp_star]
      exact hopSp_congr h _ _ k k hXk
    · rw [if_pos (castSucc_ne_castSucc hik), hop4_castSucc]
      exact hopSp_congr h _ _ i i fun t => hXo t i hik

end Hops

section Sites

variable {N : ℕ} [NeZero N]

theorem succ_val_zero_iff (z : Fin N) : (z + 1).val = 0 ↔ z.val + 1 = N := by
  rw [Fin.val_add, show (1 : Fin N).val = 1 % N from rfl]
  have hz := z.isLt
  rcases Nat.lt_or_ge 1 N with hN | hN
  · rw [Nat.mod_eq_of_lt hN]
    by_cases h : z.val + 1 = N
    · rw [h, Nat.mod_self]
      simp
    · rw [Nat.mod_eq_of_lt (by omega)]
      omega
  · have h1 : N = 1 := by have := NeZero.ne N; omega
    have e : ∀ k : ℕ, k % N = 0 := fun k => by rw [h1]; exact Nat.mod_one k
    rw [e]
    omega

/-- the antiperiodic cut is kept by the reversal: `rev(z + 1)` sits on the cut iff `z` does -/
theorem rev_succ_cut (z : Fin N) : (Fin.rev (z + 1)).val + 1 = N ↔ z.val + 1 = N := by
  rw [← succ_val_zero_iff z, Fin.val_rev]
  have := (z + 1).isLt
  omega

/-- the 90° rotation of the spatial torus in the plane `(a, b)` -/
def rotSite (a b : Fin 3) (hab : a ≠ b) : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N) where
  toFun x := fun l => if l = b then x a else if l = a then Fin.rev (x b) else x l
  invFun y := fun l => if l = a then y b else if l = b then Fin.rev (y a) else y l
  left_inv x := by
    funext l
    by_cases hla : l = a
    · simp [hla, hab, Ne.symm hab]
    · by_cases hlb : l = b
      · simp [hlb, hab, Ne.symm hab]
      · simp [hla, hlb]
  right_inv y := by
    funext l
    by_cases hlb : l = b
    · simp [hlb, hab, Ne.symm hab]
    · by_cases hla : l = a
      · simp [hla, hab, Ne.symm hab]
      · simp [hla, hlb]

theorem rotSite_apply (a b : Fin 3) (hab : a ≠ b) (x : Fin 3 → Fin N) (l : Fin 3) :
    rotSite a b hab x l = if l = b then x a else if l = a then Fin.rev (x b) else x l := rfl

/-- the reflection of the spatial axis `k` -/
def reflSite (k : Fin 3) : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N) where
  toFun x := fun l => if l = k then Fin.rev (x k) else x l
  invFun x := fun l => if l = k then Fin.rev (x k) else x l
  left_inv x := by
    funext l
    by_cases hl : l = k <;> simp [hl]
  right_inv x := by
    funext l
    by_cases hl : l = k <;> simp [hl]

theorem reflSite_apply (k : Fin 3) (x : Fin 3 → Fin N) (l : Fin 3) :
    reflSite k x l = if l = k then Fin.rev (x k) else x l := rfl

theorem reflSite_symm (k : Fin 3) : (reflSite (N := N) k).symm = reflSite k := rfl

theorem rot_fwd_a (a b : Fin 3) (hab : a ≠ b) (x : Fin 3 → Fin N) :
    rotSite a b hab (x + Pi.single a 1) = rotSite a b hab x + Pi.single b 1 := by
  funext l
  simp only [rotSite_apply, Pi.add_apply, Pi.single_apply]
  by_cases hlb : l = b
  · simp [hlb, hab, Ne.symm hab]
  · by_cases hla : l = a
    · simp [hla, hab, Ne.symm hab]
    · simp [hla, hlb]

theorem rot_bwd_b (a b : Fin 3) (hab : a ≠ b) (x : Fin 3 → Fin N) :
    rotSite a b hab (x + Pi.single b 1) + Pi.single a 1 = rotSite a b hab x := by
  funext l
  simp only [rotSite_apply, Pi.add_apply, Pi.single_apply]
  by_cases hlb : l = b
  · simp [hlb, hab, Ne.symm hab]
  · by_cases hla : l = a
    · simp [hla, hab, Ne.symm hab, Fin.rev_add]
    · simp [hla, hlb]

theorem rot_fwd_c (a b : Fin 3) (hab : a ≠ b) (i : Fin 3) (hia : i ≠ a) (hib : i ≠ b) (x : Fin 3 → Fin N) :
    rotSite a b hab (x + Pi.single i 1) = rotSite a b hab x + Pi.single i 1 := by
  funext l
  simp only [rotSite_apply, Pi.add_apply, Pi.single_apply]
  by_cases hlb : l = b
  · simp [hlb, hib, Ne.symm hib, hab, Ne.symm hab, hia, Ne.symm hia]
  · by_cases hla : l = a
    · simp [hla, Ne.symm hia, hia, hab, Ne.symm hab, hib, Ne.symm hib]
    · simp [hla, hlb]

theorem refl_bwd (k : Fin 3) (x : Fin 3 → Fin N) :
    reflSite k (x + Pi.single k 1) + Pi.single k 1 = reflSite k x := by
  funext l
  simp only [reflSite_apply, Pi.add_apply, Pi.single_apply]
  by_cases hl : l = k
  · simp [hl, Fin.rev_add]
  · simp [hl]

theorem refl_fwd (k i : Fin 3) (hik : i ≠ k) (x : Fin 3 → Fin N) :
    reflSite k (x + Pi.single i 1) = reflSite k x + Pi.single i 1 := by
  funext l
  simp only [reflSite_apply, Pi.add_apply, Pi.single_apply]
  by_cases hl : l = k
  · simp [hl, hik, Ne.symm hik]
  · simp [hl]

end Sites

section Perm

variable {S : Type*} [Fintype S] [DecidableEq S]

/-- the permutation matrix `(Qψ)(y) = ψ(ρ⁻¹ y)` -/
def permQ (ρ : S ≃ S) : Matrix S S ℂ := Matrix.of fun y x => if x = ρ.symm y then 1 else 0

theorem permQ_conj_apply (ρ : S ≃ S) (K : Matrix S S ℂ) (y y' : S) :
    (permQ ρ * K * (permQ ρ)ᴴ : Matrix S S ℂ) y y' = K (ρ.symm y) (ρ.symm y') := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (ρ.symm y')]
  · rw [Matrix.mul_apply, Finset.sum_eq_single (ρ.symm y)]
    · simp [permQ, conjTranspose_apply]
    · intro z _ hz
      simp only [permQ, Matrix.of_apply, if_neg hz, zero_mul]
    · intro h; exact absurd (Finset.mem_univ _) h
  · intro z _ hz
    simp only [conjTranspose_apply, permQ, Matrix.of_apply, if_neg hz, star_zero, mul_zero]
  · intro h; exact absurd (Finset.mem_univ _) h

theorem permQ_unitary (ρ : S ≃ S) : permQ ρ * (permQ ρ)ᴴ = 1 := by
  ext y y'
  have h := permQ_conj_apply ρ 1 y y'
  rw [Matrix.mul_one] at h
  rw [h]
  by_cases hy : y = y'
  · subst hy; simp
  · rw [Matrix.one_apply_ne (fun e => hy (ρ.symm.injective e)), Matrix.one_apply_ne hy]

/-- the site relabelling on `colour × space` -/
noncomputable def permP (ρ : S ≃ S) : Matrix (Fin 2 × S) (Fin 2 × S) ℂ :=
  (1 : Matrix (Fin 2) (Fin 2) ℂ) ⊗ₖ permQ ρ

theorem permP_unitary (ρ : S ≃ S) : permP ρ * (permP ρ)ᴴ = 1 := by
  unfold permP
  rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, Matrix.one_mul, permQ_unitary,
    one_kronecker_one]

theorem permP_conj_apply (ρ : S ≃ S) (M : Matrix (Fin 2 × S) (Fin 2 × S) ℂ) (a b : Fin 2 × S) :
    (permP ρ * M * (permP ρ)ᴴ : Matrix (Fin 2 × S) (Fin 2 × S) ℂ) a b
      = M (a.1, ρ.symm a.2) (b.1, ρ.symm b.2) := by
  unfold permP
  rw [conjTranspose_kronecker, conjTranspose_one, kron_conj_apply, permQ_conj_apply]
  rfl

theorem blockDiagonal_perm (ρ : S ≃ S) (u : S → Matrix (Fin 2) (Fin 2) ℂ) :
    blockDiagonal (fun y => u (ρ.symm y)) = permP ρ * blockDiagonal u * (permP ρ)ᴴ := by
  ext ⟨c, y⟩ ⟨c', y'⟩
  rw [permP_conj_apply]
  simp only [blockDiagonal_apply']
  by_cases hy : y = y'
  · subst hy; simp
  · rw [if_neg hy, if_neg (fun e => hy (ρ.symm.injective e))]

end Perm

section Torus

variable {N : ℕ} [NeZero N]

/-- a hop carried forward by the site map -/
theorem torusX_fwd (ρ : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N)) (i j : Fin 3)
    (hF : ∀ x, ρ (x + Pi.single i 1) = ρ x + Pi.single j 1)
    (hs : ∀ x, ((ρ x) j).val + 1 = N ↔ (x i).val + 1 = N)
    (U U' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (hU : ∀ y, U' y j = U (ρ.symm y) i) :
    torusX N U' j = permP ρ * torusX N U i * (permP ρ)ᴴ := by
  ext ⟨c, y⟩ ⟨c', y'⟩
  rw [permP_conj_apply]
  obtain ⟨x, rfl⟩ := ρ.surjective y
  obtain ⟨x', rfl⟩ := ρ.surjective y'
  simp only [Equiv.symm_apply_apply, torusX, shiftMat_apply, torusLink, torusShift, Equiv.coe_addRight,
    Matrix.smul_apply, smul_eq_mul]
  have hiff : (ρ x = ρ x' + -Pi.single j 1) ↔ (x = x' + -Pi.single i 1) := by
    rw [eq_add_neg_iff_add_eq, eq_add_neg_iff_add_eq, ← hF, ρ.apply_eq_iff_eq]
  by_cases hA : x = x' + -Pi.single i 1
  · simp only [eq_true (hiff.2 hA), eq_true hA, if_true, hU, Equiv.symm_apply_apply, hs]
  · simp only [eq_false (fun h => hA (hiff.1 h)), eq_false hA, if_false]

/-- a hop carried backward by the site map (the reversed link carries `ᴴ`) -/
theorem torusX_bwd (ρ : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N)) (i j : Fin 3)
    (hF : ∀ x : Fin 3 → Fin N, ρ (x + Pi.single i 1) + Pi.single j 1 = ρ x)
    (hs : ∀ x : Fin 3 → Fin N, ((ρ (x + Pi.single i 1)) j).val + 1 = N ↔ (x i).val + 1 = N)
    (U U' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hU : ∀ y, U' y j = (U (ρ.symm (y + Pi.single j 1)) i)ᴴ) :
    (torusX N U' j)ᴴ = permP ρ * torusX N U i * (permP ρ)ᴴ := by
  ext ⟨c, y⟩ ⟨c', y'⟩
  rw [permP_conj_apply, conjTranspose_apply]
  obtain ⟨x, rfl⟩ := ρ.surjective y
  obtain ⟨x', rfl⟩ := ρ.surjective y'
  simp only [Equiv.symm_apply_apply, torusX, shiftMat_apply, torusLink, torusShift, Equiv.coe_addRight,
    Matrix.smul_apply, smul_eq_mul]
  have hiff : (ρ x' = ρ x + -Pi.single j 1) ↔ (x = x' + -Pi.single i 1) := by
    rw [eq_add_neg_iff_add_eq, eq_add_neg_iff_add_eq, ← hF x, add_left_inj, ρ.apply_eq_iff_eq, eq_comm]
  by_cases hA : x = x' + -Pi.single i 1
  · have hx' : x' = x + Pi.single i 1 := by rw [hA]; simp
    simp only [eq_true (hiff.2 hA), eq_true hA, if_true]
    subst hx'
    rw [hU, hF x, Equiv.symm_apply_apply, conjTranspose_apply, star_mul', star_star]
    simp only [hs]
    split_ifs <;> simp
  · simp only [eq_false (fun h => hA (hiff.1 h)), eq_false hA, if_false, star_zero]

end Torus

end CubicSym

#print axioms CubicSym.det_std4_rot
#print axioms CubicSym.det_std4_refl
#print axioms CubicSym.torusX_fwd
#print axioms CubicSym.torusX_bwd
#print axioms CubicSym.rot_bwd_b
#print axioms CubicSym.rev_succ_cut
