import FermionLane.TimeRotV10h
import FermionLane.CubicRotActV10c

/-! # 90° rotations in a (space, time) plane: Wilson action and the normalised measure (isotropic lattice)

* `link4`, `shift4`, `Q4`, **`wilsonAction_eq_4d`**: on the isotropic lattice the Wilson action is the sum over
  sites and over the six planes `μ < ν` of `Fin 4` of one plaquette function.
* `swapT` (exchange of the coordinate `a` and time), `swapTPhys`, `pairs4_swap`, **`wilsonAction_swapT`**.
* **`trot_eq`**: the rotation is the exchange followed by the reflection of the axis `a`.
* **`wilsonAction_trot`**, `wfWeight_trot`, `pi_trot_preserving`, **`wfProb_trot`**. -/

namespace CubicSym

open Matrix MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion

variable {h : ℕ} [NeZero (2 * h)]

/-- the spatial unit vector of the direction `μ` (`0` for time) -/
def e4 (μ : Fin 4) : Fin 3 → Fin (2 * h) := fun l => if l.castSucc = μ then 1 else 0

theorem e4_castSucc (i : Fin 3) : e4 (h := h) i.castSucc = Pi.single i 1 := by
  funext l
  simp only [e4, Pi.single_apply]
  by_cases hl : l = i
  · rw [if_pos (by rw [hl]), if_pos hl]
  · rw [if_neg (castSucc_ne_castSucc hl), if_neg hl]

theorem e4_three : e4 (h := h) 3 = 0 := by
  funext l
  simp only [e4, Pi.zero_apply]
  rw [if_neg (castSucc_ne_three l)]

/-- the site `s + e_μ` -/
def shift4 (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (μ : Fin 4) : Fin (2 * h) × (Fin 3 → Fin (2 * h)) :=
  (if μ = 3 then s.1 + 1 else s.1, s.2 + e4 μ)

/-- the link `(s, μ)` as a matrix -/
noncomputable def link4 (ω : PhysLink (2 * h) h → SU2) (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (μ : Fin 4) :
    Matrix (Fin 2) (Fin 2) ℂ := quatMat (ω (s.1, s.2, μ) : Quaternion ℝ)

/-- the plaquette `(s, μ, ν)` -/
noncomputable def Q4 (ω : PhysLink (2 * h) h → SU2) (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (μ ν : Fin 4) : ℝ :=
  plaqE (link4 ω s μ) (link4 ω (shift4 s μ) ν) (link4 ω (shift4 s ν) μ) (link4 ω s ν)

theorem pairs4_eq (g : Fin 4 → Fin 4 → ℝ) :
    ∑ μ, ∑ ν ∈ Finset.Ioi μ, g μ ν = g 0 1 + g 0 2 + g 0 3 + g 1 2 + g 1 3 + g 2 3 := by
  have h0 : Finset.Ioi (0 : Fin 4) = {1, 2, 3} := by decide
  have h1 : Finset.Ioi (1 : Fin 4) = {2, 3} := by decide
  have h2 : Finset.Ioi (2 : Fin 4) = {3} := by decide
  have h3 : Finset.Ioi (3 : Fin 4) = ∅ := by decide
  rw [Fin.sum_univ_four, h0, h1, h2, h3, Finset.sum_insert (by decide), Finset.sum_pair (by decide),
    Finset.sum_pair (by decide), Finset.sum_singleton, Finset.sum_empty]
  ring

theorem physSp_link4 (ω : PhysLink (2 * h) h → SU2) (t : Fin (2 * h)) (x : Fin 3 → Fin (2 * h)) (i : Fin 3) :
    physSp ω t.val x i = link4 ω (t, x) i.castSucc := by
  unfold physSp link4
  rw [dif_pos t.isLt]

theorem physT_link4 (ω : PhysLink (2 * h) h → SU2) (t : Fin (2 * h)) (x : Fin 3 → Fin (2 * h)) :
    physT ω t.val x = link4 ω (t, x) 3 := by
  unfold physT link4
  rw [dif_pos t.isLt]

/-- **the Wilson action as one sum over sites and planes** -/
theorem wilsonAction_eq_4d (ω : PhysLink (2 * h) h → SU2) :
    wilsonAction (2 * h) h ω = ∑ s, ∑ μ, ∑ ν ∈ Finset.Ioi μ, Q4 ω s μ ν := by
  unfold wilsonAction
  rw [Finset.sum_range (fun t => spS (2 * h) (physSp ω t) + tmS (2 * h) (physSp ω t) (physSp ω (sc h t))
    (physT ω t)), Fintype.sum_prod_type]
  refine Finset.sum_congr rfl fun t _ => ?_
  unfold spS tmS
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [pairs4_eq, pairs_eq, Fin.sum_univ_three]
  have hsc : sc h t.val = (t + 1).val := (add_one_val_sc t).symm
  simp only [ev, hsc, physSp_link4, physT_link4, Q4, shift4, e4_castSucc, e4_three, add_zero]
  have c0 : ((0 : Fin 3).castSucc : Fin 4) = 0 := rfl
  have c1 : ((1 : Fin 3).castSucc : Fin 4) = 1 := rfl
  have c2 : ((2 : Fin 3).castSucc : Fin 4) = 2 := rfl
  simp only [c0, c1, c2, if_true, if_neg (show (0 : Fin 4) ≠ 3 by decide), if_neg (show (1 : Fin 4) ≠ 3 by decide),
    if_neg (show (2 : Fin 4) ≠ 3 by decide)]
  have d0 : e4 (h := h) (0 : Fin 4) = Pi.single (0 : Fin 3) 1 := e4_castSucc 0
  have d1 : e4 (h := h) (1 : Fin 4) = Pi.single (1 : Fin 3) 1 := e4_castSucc 1
  have d2 : e4 (h := h) (2 : Fin 4) = Pi.single (2 : Fin 3) 1 := e4_castSucc 2
  simp only [d0, d1, d2]
  ring

/-- the exchange of the coordinate `a` and time -/
def swapT (a : Fin 3) (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) : Fin (2 * h) × (Fin 3 → Fin (2 * h)) :=
  (s.2 a, Function.update s.2 a s.1)

theorem swapT_invol (a : Fin 3) : Function.Involutive (swapT (h := h) a) := by
  intro s
  obtain ⟨t, x⟩ := s
  simp [swapT]

theorem swapT_shift (a : Fin 3) (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (μ : Fin 4) :
    swapT a (shift4 s μ) = shift4 (swapT a s) (Equiv.swap a.castSucc 3 μ) := by
  obtain ⟨t, x⟩ := s
  induction μ using Fin.lastCases with
  | last =>
    have e3 : Equiv.swap a.castSucc 3 (Fin.last 3) = a.castSucc := Equiv.swap_apply_right _ _
    rw [e3]
    simp only [swapT, shift4, if_pos (show Fin.last 3 = (3 : Fin 4) from rfl), if_neg (castSucc_ne_three a),
      e4_castSucc, show e4 (h := h) (Fin.last 3) = 0 from e4_three, add_zero]
    refine Prod.ext rfl ?_
    funext l
    by_cases hl : l = a
    · subst hl; simp
    · simp [Function.update_of_ne hl, Pi.single_apply, hl]
  | cast i =>
    by_cases hia : i = a
    · subst hia
      rw [Equiv.swap_apply_left]
      simp only [swapT, shift4, if_neg (castSucc_ne_three i), if_pos (rfl : (3 : Fin 4) = 3), e4_castSucc, e4_three,
        add_zero, Pi.add_apply, Pi.single_eq_same]
      refine Prod.ext rfl ?_
      funext l
      by_cases hl : l = i
      · subst hl; simp
      · simp [Function.update_of_ne hl, Pi.single_apply, hl]
    · rw [Equiv.swap_apply_of_ne_of_ne (castSucc_ne_castSucc hia) (castSucc_ne_three i)]
      simp only [swapT, shift4, if_neg (castSucc_ne_three i), e4_castSucc]
      refine Prod.ext (by simp [Pi.single_apply, Ne.symm hia]) ?_
      funext l
      by_cases hl : l = a
      · subst hl; simp [Pi.single_apply, Ne.symm hia]
      · simp [Function.update_of_ne hl]

/-- the configuration with the coordinate `a` and time exchanged -/
def swapTPhys (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) : PhysLink (2 * h) h → SU2 := fun l =>
  ω ((swapT a (l.1, l.2.1)).1, (swapT a (l.1, l.2.1)).2, Equiv.swap a.castSucc 3 l.2.2)

theorem Q4_swapT (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) (s : Fin (2 * h) × (Fin 3 → Fin (2 * h))) (μ ν : Fin 4) :
    Q4 (swapTPhys a ω) s μ ν = Q4 ω (swapT a s) (Equiv.swap a.castSucc 3 μ) (Equiv.swap a.castSucc 3 ν) := by
  unfold Q4
  have hl : ∀ s' μ', link4 (swapTPhys a ω) s' μ' = link4 ω (swapT a s') (Equiv.swap a.castSucc 3 μ') := by
    intro s' μ'; rfl
  rw [hl, hl, hl, hl, swapT_shift, swapT_shift]

theorem pairs4_swap (a : Fin 3) (g : Fin 4 → Fin 4 → ℝ) (hg : ∀ μ ν, g μ ν = g ν μ) :
    ∑ μ, ∑ ν ∈ Finset.Ioi μ, g (Equiv.swap a.castSucc 3 μ) (Equiv.swap a.castSucc 3 ν)
      = ∑ μ, ∑ ν ∈ Finset.Ioi μ, g μ ν := by
  rw [pairs4_eq (fun μ ν => g (Equiv.swap a.castSucc 3 μ) (Equiv.swap a.castSucc 3 ν)), pairs4_eq]
  have e1 := hg 0 1; have e2 := hg 0 2; have e3 := hg 0 3; have e4' := hg 1 2; have e5 := hg 1 3
  have e6 := hg 2 3
  fin_cases a <;> simp [Equiv.swap_apply_def] <;> linarith

theorem wilsonAction_swapT (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) :
    wilsonAction (2 * h) h (swapTPhys a ω) = wilsonAction (2 * h) h ω := by
  rw [wilsonAction_eq_4d, wilsonAction_eq_4d]
  simp only [Q4_swapT]
  refine Fintype.sum_equiv (swapT_invol (h := h) a).toPerm _ _ fun s => ?_
  have h := pairs4_swap a (fun μ ν => Q4 ω (swapT a s) μ ν) (fun μ ν => by
    unfold Q4; exact (plaqE_symm _ _ _ _).symm)
  exact h

theorem update_reflSite (a : Fin 3) (z : Fin 3 → Fin (2 * h)) (v : Fin (2 * h)) :
    Function.update (reflSite a z) a v = Function.update z a v := by
  funext l
  by_cases hl : l = a
  · subst hl; simp
  · simp [Function.update_of_ne hl, reflSite_apply, hl]

/-- **the rotation in the plane `(a, time)` is the exchange `a ↔ time` followed by the reflection of the axis `a`** -/
theorem trot_eq (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) : trotPhys a ω = reflPhys a (swapTPhys a ω) := by
  funext l
  obtain ⟨t, y, μ⟩ := l
  by_cases h3 : μ = 3
  · subst h3
    simp only [trotPhys, reflPhys, swapTPhys, swapT, if_true, if_neg (castSucc_ne_three a).symm,
      Equiv.swap_apply_right, reflSite_symm, update_reflSite, reflSite_apply]
  · by_cases ha : μ = a.castSucc
    · subst ha
      simp only [trotPhys, reflPhys, swapTPhys, swapT, if_neg h3, if_true, Equiv.swap_apply_left, reflSite_symm,
        update_reflSite, update_add_single, reflSite_apply]
    · simp only [trotPhys, reflPhys, swapTPhys, swapT, if_neg h3, if_neg ha, Equiv.swap_apply_of_ne_of_ne ha h3,
        reflSite_symm, update_reflSite, reflSite_apply, eq_self_iff_true, if_true]

/-- **the Wilson action is invariant under the rotations in the (space, time) planes** (isotropic lattice) -/
theorem wilsonAction_trot (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) :
    wilsonAction (2 * h) h (trotPhys a ω) = wilsonAction (2 * h) h ω := by
  rw [trot_eq, wilsonAction_refl, wilsonAction_swapT]

theorem wfWeight_trot (a : Fin 3) (j : ℕ) (m β : ℝ) (ω : PhysLink (2 * h) h → SU2) :
    wfWeight (2 * h) h j m β (trotPhys a ω) = wfWeight (2 * h) h j m β ω := by
  unfold wfWeight
  rw [wilsonAction_trot, physDirac_det_trot]

/-- the link relabelling of the exchange (an involution) -/
def swapTLink (a : Fin 3) (l : PhysLink (2 * h) h) : PhysLink (2 * h) h :=
  ((swapT a (l.1, l.2.1)).1, (swapT a (l.1, l.2.1)).2, Equiv.swap a.castSucc 3 l.2.2)

theorem swapTLink_invol (a : Fin 3) : Function.Involutive (swapTLink (h := h) a) := by
  intro l
  obtain ⟨t, y, μ⟩ := l
  have := swapT_invol (h := h) a (t, y)
  simp only [swapTLink, Equiv.swap_apply_self]
  rw [this]

theorem pi_swapT_preserving (a : Fin 3) :
    MeasurePreserving (swapTPhys (h := h) a)
      (Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h1 := measurePreserving_arrowCongr' (fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2))
    (swapTLink_invol (h := h) a).toPerm.symm (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e1 : ⇑(MeasurableEquiv.arrowCongr' (swapTLink_invol (h := h) a).toPerm.symm (MeasurableEquiv.refl SU2))
      = swapTPhys a := by
    funext ω l; rfl
  rw [e1] at h1
  exact h1

theorem pi_trot_preserving (a : Fin 3) :
    MeasurePreserving (trotPhys (h := h) a)
      (Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink (2 * h) h => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have e : trotPhys (h := h) a = reflPhys a ∘ swapTPhys a := by
    funext ω; exact trot_eq a ω
  rw [e]
  exact (pi_refl_preserving h a).comp (pi_swapT_preserving a)

/-- **the normalised Wilson–fermion measure is invariant under the rotations in the (space, time) planes**
(isotropic lattice: spatial torus `(Fin (2h))³`, time circle `2h`) -/
theorem wfProb_trot (hpos : 0 < h) (j : ℕ) (m β : ℝ) (a : Fin 3) :
    (wfProb (2 * h) h j m β).map (trotPhys a) = wfProb (2 * h) h j m β := by
  have hT' := pi_trot_preserving (h := h) a
  have hf : Measurable fun ω => ((wfWeight (2 * h) h j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight (2 * h) h hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight (2 * h) h j m β ω).toNNReal : ENNReal)
      = ((wfWeight (2 * h) h j m β (trotPhys a ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_trot]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end CubicSym

#print axioms CubicSym.wilsonAction_eq_4d
#print axioms CubicSym.wilsonAction_swapT
#print axioms CubicSym.trot_eq
#print axioms CubicSym.wilsonAction_trot
#print axioms CubicSym.wfProb_trot
