import FermionLane.GaugeV9

/-! # the block map of the box commutes with the lattice translations

A coarse vector `a` at level `m` acts on box links by `(y, μ) ↦ (y + a, μ)`;
its fine image is `2a` (`dbl`, through `double`).  The paths of the coarse link `b + a` are the paths of `b`
translated by `2a` (`boxPathsIdx_shift`), so the block map is translation covariant:
**`blockMap_shift`**: `blockMap (U(· + 2a)) = (blockMap U)(· + a)`. -/

namespace BlockShift

open ChainBlockMap BoxWalk WalkCast

variable (L : ℕ) [NeZero L]

/-- the translation of a box link -/
def shiftLk {m : ℕ} (c : Site L m) (ℓ : BoxLk L m) : BoxLk L m := (ℓ.1 + c, ℓ.2)

/-- the translation of a ball configuration -/
def shiftCfg {m : ℕ} (c : Site L m) (U : Cfg (BoxLk L m)) : Cfg (BoxLk L m) := fun ℓ => U (shiftLk L c ℓ)

/-- the fine image `2a` of a coarse vector -/
def dbl (m : ℕ) (a : Site L m) : Site L (m + 1) := fun i => double L m (a i)

/-- the translation of a signed step -/
def shiftStep {m : ℕ} (c : Site L m) (s : BoxLk L m × Bool) : BoxLk L m × Bool := (shiftLk L c s.1, s.2)

theorem base_shift (m : ℕ) (b : BoxLk L m) (a : Site L m) :
    base L m (shiftLk L a b) = base L m b + dbl L m a := by
  funext i
  simp only [base, shiftLk, dbl, Pi.add_apply, map_add]

theorem boxPathsIdx_shift (m : ℕ) (b : BoxLk L m) (a : Site L m) (o : Fin 6) (A : Fin 3 → Fin 3) :
    boxPathsIdx L m (shiftLk L a b) o A = (boxPathsIdx L m b o A).map (shiftStep L (dbl L m a)) := by
  unfold boxPathsIdx pathsCast
  rw [List.map_map]
  have hd : dirB L m (shiftLk L a b) = dirB L m b := rfl
  rw [hd, base_shift]
  refine List.map_congr_left fun l _ => ?_
  simp only [Function.comp, shiftStep, shiftLk, linkCast, add_right_comm]

theorem stepVal_shift {m : ℕ} (c : Site L m) (U : BoxLk L m → Quaternion ℝ) (s : BoxLk L m × Bool) :
    stepVal U (shiftStep L c s) = stepVal (fun ℓ => U (shiftLk L c ℓ)) s := by
  unfold stepVal shiftStep
  rfl

theorem pathProd_shift {m : ℕ} (c : Site L m) (U : BoxLk L m → Quaternion ℝ) (γ : List (BoxLk L m × Bool)) :
    pathProd U (γ.map (shiftStep L c)) = pathProd (fun ℓ => U (shiftLk L c ℓ)) γ := by
  unfold pathProd
  rw [List.map_map]
  congr 1

theorem coarseAvg_shift (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (a : Site L m) (b : BoxLk L m) :
    coarseAvg (boxPaths L) (boxW L) m (shiftCfg L (dbl L m a) U) b
      = coarseAvg (boxPaths L) (boxW L) m U (shiftLk L a b) := by
  rw [coarseAvg_box, coarseAvg_box]
  unfold sixAvg
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  rw [boxPathsIdx_shift, pathProd_shift]
  rfl

/-- **the block map commutes with the lattice translations** (`U(· + 2a) ↦ (blockMap U)(· + a)`) -/
theorem blockMap_shift {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (a : Site L m) :
    blockMap r₀ hr (boxPaths L) (boxW L) m (shiftCfg L (dbl L m a) U)
      = shiftCfg L a (blockMap r₀ hr (boxPaths L) (boxW L) m U) := by
  funext b
  apply Subtype.ext
  simp only [blockMap, shiftCfg]
  rw [coarseAvg_shift]


/-- **the compositions of block maps commute with the lattice translations**, for a family of vectors `v j` at
the levels `j` with `v (j + 1) = 2 v j` between the two levels -/
theorem down_shift {r₀ : ℝ} (hr : 0 < r₀) (n : ℕ) (v : ∀ j, Site L j) :
    ∀ k m, m + k = n → (∀ j, m ≤ j → j < n → v (j + 1) = dbl L j (v j)) → ∀ U : Cfg (BoxLk L n),
      down r₀ hr (boxPaths L) (boxW L) n m (shiftCfg L (v n) U)
        = shiftCfg L (v m) (down r₀ hr (boxPaths L) (boxW L) n m U) := by
  intro k
  induction k with
  | zero =>
    intro m hm _ U
    have : m = n := by omega
    subst this
    rw [down_self, down_self]
  | succ k ih =>
    intro m hm hv U
    have hlt : m < n := by omega
    rw [down_succ r₀ hr (boxPaths L) (boxW L) hlt, down_succ r₀ hr (boxPaths L) (boxW L) hlt,
      ih (m + 1) (by omega) (fun j hj hjn => hv j (by omega) hjn) U, hv m le_rfl hlt, blockMap_shift]

end BlockShift

#print axioms BlockShift.boxPathsIdx_shift
#print axioms BlockShift.coarseAvg_shift
#print axioms BlockShift.blockMap_shift
#print axioms BlockShift.down_shift
