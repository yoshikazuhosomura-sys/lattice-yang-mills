import FermionLane.CubicLatV10c

/-! # The time reflection `t ↦ 2h − 1 − t` and the determinant of the Wilson–Dirac operator

The reversal of the time circle keeps the antiperiodic cut (the link `2h − 1 → 0`) in place.  On the operator,
the conjugation by `rev ⊗ 1` sends the spatial hops of slice `t` to slice `rev t` and the time hop to the reversed
time hop; the spin factor is `γ₁γ₂γ₃` (`refl_spin` with `k = 3`).
* `trefl_conj_apply`, `det_std4_trefl`: the operator level.
* `treflPhys`, **`physDirac_det_trefl`**: `det D(Θ_t ω) = det D(ω)` for the time-reflected configuration (the time
  links reversed, carrying the inverse); no isotropy is needed. -/

namespace CubicSym

open Matrix FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

section Op

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- the time reversal `rev ⊗ 1` -/
noncomputable def treflW (h : ℕ) : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ :=
  permQ (Fin.revPerm : Equiv.Perm (Fin (2 * h))) ⊗ₖ (1 : Matrix L L ℂ)

theorem treflW_unitary (h : ℕ) : treflW (L := L) h * (treflW h)ᴴ = 1 := by
  unfold treflW
  rw [conjTranspose_kronecker, conjTranspose_one, ← mul_kronecker_mul, permQ_unitary, Matrix.one_mul,
    one_kronecker_one]

theorem trefl_conj_apply (h : ℕ) (M : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) (a b : Fin (2 * h) × L) :
    (treflW h * M * (treflW h)ᴴ : Matrix (Fin (2 * h) × L) (Fin (2 * h) × L) ℂ) a b
      = M (Fin.rev a.1, a.2) (Fin.rev b.1, b.2) := by
  unfold treflW
  rw [conjTranspose_kronecker, conjTranspose_one, kron1_conj_apply, permQ_conj_apply]
  simp [Fin.revPerm_symm]

theorem rev_val (h : ℕ) (t : Fin (2 * h)) : (Fin.rev t).val = 2 * h - 1 - t.val := by
  rw [Fin.val_rev]; omega

theorem sc_rev_iff (h : ℕ) (a b : Fin (2 * h)) :
    (Fin.rev b).val = sc h (Fin.rev a).val ↔ a.val = sc h b.val := by
  rw [rev_val, rev_val]
  have ha := a.isLt; have hb := b.isLt
  unfold sc
  split_ifs <;> omega

/-- **the operator level of the time reflection** -/
theorem det_std4_trefl (h : ℕ) (m : ℝ) (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hX : ∀ s, s < 2 * h → X' s = X (2 * h - 1 - s))
    (hv : ∀ s, s < 2 * h → v' s = (v (2 * h - 1 - sc h s))ᴴ) :
    (std4 h m X' v').det = (std4 h m X v).det := by
  rw [det_std4_eq_cliffOp, det_std4_eq_cliffOp]
  have hspin := refl_spin 0 1 2 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  refine det_cliffOp_perm m (treflW h) (treflW_unitary h) _ _ (Equiv.refl (Fin 4)) (fun μ => μ ≠ 3) ?_
    ⟨_, _, hspin⟩
  intro μ
  induction μ using Fin.lastCases with
  | last =>
    have h3 : ¬ (Fin.last 3 ≠ (3 : Fin 4)) := fun h => h rfl
    rw [if_neg h3, Equiv.refl_apply, hop4_last, hop4_last]
    ext a b
    rw [trefl_conj_apply, conjTranspose_apply]
    unfold hopT
    by_cases hc : a.1.val = sc h b.1.val
    · rw [if_pos ((sc_rev_iff h a.1 b.1).2 hc), if_pos hc, hv b.1.val b.1.isLt, conjTranspose_apply, star_star,
        ← hc, rev_val]
    · rw [if_neg (fun e => hc ((sc_rev_iff h a.1 b.1).1 e)), if_neg hc, star_zero]
  | cast i =>
    have hi : i.castSucc ≠ (3 : Fin 4) := fun e => last_ne_castSucc i e.symm
    rw [if_pos hi, Equiv.refl_apply, hop4_castSucc, hop4_castSucc]
    ext a b
    rw [trefl_conj_apply]
    unfold hopSp
    have ha := a.1.isLt; have hb := b.1.isLt
    by_cases hc : b.1.val = a.1.val
    · have hc' : (Fin.rev b.1).val = (Fin.rev a.1).val := by rw [rev_val, rev_val, hc]
      rw [if_pos hc', if_pos hc, hX a.1.val ha, rev_val]
    · have hc' : ¬ (Fin.rev b.1).val = (Fin.rev a.1).val := by rw [rev_val, rev_val]; omega
      rw [if_neg hc', if_neg hc]

end Op

section Phys

variable {N : ℕ} [NeZero N] {hT : ℕ}

/-- the successor on the time circle as an element of `Fin (2h)` -/
def tsc (t : Fin (2 * hT)) : Fin (2 * hT) := ⟨sc hT t.val, sc_lt hT t.val t.isLt⟩

/-- the time-reflected configuration: slice `t` ← slice `rev t`, the time link `t → t+1` ← the reversed old time
link `rev(t+1) → rev(t)` -/
noncomputable def treflPhys (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 := fun l =>
  if l.2.2 = 3 then (ω (Fin.rev (tsc l.1), l.2.1, 3))⁻¹ else ω (Fin.rev l.1, l.2.1, l.2.2)

theorem physSp_trefl (ω : PhysLink N hT → SU2) (s : ℕ) (hs : s < 2 * hT) :
    physSp (treflPhys ω) s = physSp ω (2 * hT - 1 - s) := by
  funext x i
  unfold physSp
  have hs' : 2 * hT - 1 - s < 2 * hT := by omega
  rw [dif_pos hs, dif_pos hs']
  have hi : i.castSucc ≠ (3 : Fin 4) := fun e => last_ne_castSucc i e.symm
  simp only [treflPhys, if_neg hi]
  have e : Fin.rev (⟨s, hs⟩ : Fin (2 * hT)) = ⟨2 * hT - 1 - s, hs'⟩ := Fin.ext (by rw [rev_val])
  rw [e]

theorem physT_trefl (ω : PhysLink N hT → SU2) (s : ℕ) (hs : s < 2 * hT) (x : Fin 3 → Fin N) :
    physT (treflPhys ω) s x = (physT ω (2 * hT - 1 - sc hT s) x)ᴴ := by
  unfold physT
  have hsc := sc_lt hT s hs
  have hs' : 2 * hT - 1 - sc hT s < 2 * hT := by omega
  rw [dif_pos hs, dif_pos hs']
  simp only [treflPhys, if_true]
  rw [quatMat_inv]
  have e : Fin.rev (tsc (⟨s, hs⟩ : Fin (2 * hT))) = ⟨2 * hT - 1 - sc hT s, hs'⟩ := Fin.ext (by rw [rev_val]; rfl)
  rw [e]

theorem eps_trefl (s : ℕ) (hs : s < 2 * hT) : eps (sc hT s) = eps (sc hT (2 * hT - 1 - sc hT s)) := by
  unfold eps sc
  split_ifs <;> first | rfl | omega

/-- **the determinant of the Wilson–Dirac operator is invariant under the time reflection** -/
theorem physDirac_det_trefl (m : ℝ) (ω : PhysLink N hT → SU2) :
    (physDirac N hT m (treflPhys ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  refine det_std4_trefl hT m _ _ _ _ (fun s hs => ?_) (fun s hs => ?_)
  · rw [physSp_trefl ω s hs]
  · rw [conjTranspose_smul, blockDiagonal_conjTranspose]
    have e1 : star (eps (sc hT (2 * hT - 1 - sc hT s))) = eps (sc hT s) := by
      rw [← eps_trefl s hs]; unfold eps; split_ifs <;> simp
    rw [e1]
    congr 2
    funext x
    exact physT_trefl ω s hs x

end Phys

end CubicSym

#print axioms CubicSym.det_std4_trefl
#print axioms CubicSym.physDirac_det_trefl
