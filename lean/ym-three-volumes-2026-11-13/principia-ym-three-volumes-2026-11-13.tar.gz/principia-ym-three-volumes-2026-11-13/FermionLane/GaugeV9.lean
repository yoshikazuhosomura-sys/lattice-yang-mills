import Box.FermionChainV8b

/-! # file I, version g: global gauge covariance of the block map — the field `hsym` reduced to one invariance

Paper side: For a unit quaternion `g` the global gauge transformation acts on ball-valued links by
`q ↦ g q g*` (`conjCfg`) and on this column's `SU(2)` links by `ω ↦ g ω g⁻¹` (`conjPhys`).  Lean:
* `pathProd_conj`, `avg_conj`, `retract_conj`: path products, averages and the radial retraction are covariant;
* **`blockMap_conj`**, **`down_conj`**: the block map and its compositions commute with `conjCfg`;
* `pullBox_conj`: `pullBox ∘ conjPhys g = conjCfg g ∘ pullBox`;
* **`hsym_box_of_invariant`**: if the fine measure is invariant under `conjPhys g` (premise `hinv`), the block
  measures of the box chain are invariant under `conjCfg g` — the field `hsym` of `chain_end_to_end_box` for the
  group of global gauge transformations.  The invariance `hinv` itself (Haar measure: bi-invariance; Wilson action:
  cyclicity of the trace; the determinant: conjugation of the operator by `1 ⊗ g`) is not proved here. -/

namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config

local notation "ℍr" => Quaternion ℝ

theorem star_mul_self_unit {g : ℍr} (hg : ‖g‖ = 1) : star g * g = 1 := by
  rw [Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, hg]; simp

theorem mul_star_self_unit {g : ℍr} (hg : ‖g‖ = 1) : g * star g = 1 := by
  rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hg]; simp

theorem norm_conj {g : ℍr} (hg : ‖g‖ = 1) (q : ℍr) : ‖g * q * star g‖ = ‖q‖ := by
  rw [norm_mul, norm_mul, norm_star, hg]; ring

/-- the global gauge transformation of ball-valued configurations -/
noncomputable def conjCfg {L : Type*} (g : ℍr) (hg : ‖g‖ = 1) (U : Cfg L) : Cfg L :=
  fun ℓ => ⟨g * (U ℓ : ℍr) * star g, by
    rw [mem_ball_iff, norm_conj hg]; exact (mem_ball_iff _).1 (U ℓ).2⟩

theorem stepVal_conj {L : Type*} {g : ℍr} (hg : ‖g‖ = 1) (U : L → ℍr) (s : L × Bool) :
    stepVal (fun ℓ => g * U ℓ * star g) s = g * stepVal U s * star g := by
  unfold stepVal
  split_ifs
  · simp only [star_mul, star_star, mul_assoc]
  · rfl

theorem prod_conj {g : ℍr} (hg : ‖g‖ = 1) (l : List ℍr) :
    (l.map fun a => g * a * star g).prod = g * l.prod * star g := by
  induction l with
  | nil => simp [mul_star_self_unit hg]
  | cons a l ih =>
    rw [List.map_cons, List.prod_cons, ih, List.prod_cons]
    calc g * a * star g * (g * l.prod * star g) = g * a * (star g * g) * l.prod * star g := by
          simp only [mul_assoc]
      _ = g * (a * l.prod) * star g := by rw [star_mul_self_unit hg]; simp only [mul_one, mul_assoc]

theorem pathProd_conj {L : Type*} {g : ℍr} (hg : ‖g‖ = 1) (U : L → ℍr) (γ : List (L × Bool)) :
    pathProd (fun ℓ => g * U ℓ * star g) γ = g * pathProd U γ * star g := by
  unfold pathProd
  rw [← prod_conj hg, List.map_map]
  congr 1
  refine List.map_congr_left fun s _ => ?_
  exact stepVal_conj hg U s

theorem avg_conj {L : Type*} {g : ℍr} (hg : ‖g‖ = 1) (U : L → ℍr) (P : Finset (List (L × Bool)))
    (w : List (L × Bool) → ℝ) : avg (fun ℓ => g * U ℓ * star g) P w = g * avg U P w * star g := by
  unfold avg
  rw [Finset.mul_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun γ _ => ?_
  rw [pathProd_conj hg, mul_smul_comm, smul_mul_assoc]

theorem retract_conj {g : ℍr} (hg : ‖g‖ = 1) (r₀ : ℝ) (q : ℍr) :
    retract r₀ (g * q * star g) = g * retract r₀ q * star g := by
  unfold retract
  rw [norm_conj hg, mul_smul_comm, smul_mul_assoc]

section Block

variable {Lk : ℕ → Type*} (r₀ : ℝ) (hr : 0 < r₀)
  (paths : ∀ m, Lk m → Finset (List (Lk (m + 1) × Bool)))
  (w : ∀ m, Lk m → List (Lk (m + 1) × Bool) → ℝ)

/-- **the block map is gauge covariant** -/
theorem blockMap_conj {g : ℍr} (hg : ‖g‖ = 1) (m : ℕ) (U : Cfg (Lk (m + 1))) :
    blockMap r₀ hr paths w m (conjCfg g hg U) = conjCfg g hg (blockMap r₀ hr paths w m U) := by
  funext b
  apply Subtype.ext
  show retract r₀ (coarseAvg paths w m (conjCfg g hg U) b) = g * retract r₀ (coarseAvg paths w m U b) * star g
  rw [← retract_conj hg]
  congr 1
  unfold coarseAvg
  exact avg_conj hg (fun ℓ => (U ℓ : ℍr)) (paths m b) (w m b)

theorem down_conj {g : ℍr} (hg : ‖g‖ = 1) (n : ℕ) :
    ∀ k m, m + k = n → ∀ U : Cfg (Lk n),
      down r₀ hr paths w n m (conjCfg g hg U) = conjCfg g hg (down r₀ hr paths w n m U) := by
  intro k
  induction k with
  | zero =>
    intro m hm U
    have : m = n := by omega
    subst this
    rw [down_self, down_self]
  | succ k ih =>
    intro m hm U
    have hlt : m < n := by omega
    rw [down_succ r₀ hr paths w hlt, down_succ r₀ hr paths w hlt, ih (m + 1) (by omega) U,
      blockMap_conj r₀ hr paths w hg m]

theorem continuous_conjCfg {L : Type*} {g : ℍr} (hg : ‖g‖ = 1) : Continuous (conjCfg (L := L) g hg) := by
  refine continuous_pi fun ℓ => Continuous.subtype_mk ?_ _
  exact (continuous_const.mul (continuous_subtype_val.comp (continuous_apply ℓ))).mul continuous_const

variable [∀ m, Fintype (Lk m)]

/-- **`hsym` for the global gauge transformations, from the invariance of the fine measures** -/
theorem hsym_of_invariant {g : ℍr} (hg : ‖g‖ = 1) (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n)))
    (hinv : ∀ n, (μ n : Measure (Cfg (Lk n))).map (conjCfg g hg) = μ n) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (Lk m)) ℝ,
      ∫ ω, F (conjCfg g hg ω) ∂(νP r₀ hr paths w μ n m : Measure (Cfg (Lk m)))
        = ∫ ω, F ω ∂(νP r₀ hr paths w μ n m : Measure (Cfg (Lk m))) := by
  filter_upwards [eventually_ge_atTop m] with n hn
  intro F
  have hD := (continuous_down r₀ hr paths w n m).measurable
  have hC := (continuous_conjCfg (L := Lk m) hg).measurable
  have hm1 : Measurable fun ω : Cfg (Lk m) => F (conjCfg g hg ω) := F.continuous.measurable.comp hC
  have hm2 : Measurable fun ω : Cfg (Lk m) => F ω := F.continuous.measurable
  have hm3 : Measurable fun ω : Cfg (Lk n) => F (down r₀ hr paths w n m ω) := F.continuous.measurable.comp hD
  rw [νP, ProbabilityMeasure.toMeasure_map,
    integral_map hD.aemeasurable hm1.aestronglyMeasurable,
    integral_map hD.aemeasurable hm2.aestronglyMeasurable]
  have hfun : (fun ω => F (conjCfg g hg (down r₀ hr paths w n m ω)))
      = fun ω => F (down r₀ hr paths w n m (conjCfg g hg ω)) := by
    funext ω
    rw [down_conj r₀ hr paths w hg n (n - m) m (by omega) ω]
  rw [hfun]
  conv_rhs => rw [← hinv n]
  rw [integral_map (continuous_conjCfg hg).measurable.aemeasurable hm3.aestronglyMeasurable]

end Block

variable (L : ℕ) [NeZero L]

/-- the global gauge transformation of this column's configurations -/
noncomputable def conjPhys {N hT : ℕ} (g : SU2) (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 := fun l => g * ω l * g⁻¹

theorem pullBox_conj (n : ℕ) (g : SU2) (ω : PhysLink (2 * (2 ^ n * L)) (2 ^ n * L) → SU2) :
    pullBox L n (conjPhys g ω) = conjCfg (g : ℍr) (mem_sphere_zero_iff_norm.mp g.2) (pullBox L n ω) := by
  funext ℓ
  apply Subtype.ext
  show (((g * ω _ * g⁻¹ : SU2)) : ℍr) = (g : ℍr) * (ω _ : ℍr) * star (g : ℍr)
  rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, coe_inv_su2]

/-- **`hsym` of the box chain for the fermion family and the global gauge transformations**, from the invariance of
the fine Wilson–fermion measure (premise `hinv`) -/
theorem hsym_box_fermion {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (g : SU2)
    (hinv : ∀ n, (wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n)).map (conjPhys g)
      = wfProb (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n)) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (conjCfg (g : ℍr) (mem_sphere_zero_iff_norm.mp g.2) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) := by
  refine hsym_of_invariant r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (mem_sphere_zero_iff_norm.mp g.2)
    (fermProbBox L j mseq βseq) (fun n => ?_) m
  have hmc : Measurable (conjPhys (N := 2 * (2 ^ n * L)) (hT := 2 ^ n * L) g) :=
    measurable_pi_lambda _ fun l =>
      ((continuous_const.mul (continuous_apply l)).mul continuous_const).measurable
  rw [fermProbBox_toMeasure, Measure.map_map (continuous_conjCfg _).measurable (measurable_pullBox L n)]
  have e : (conjCfg (g : ℍr) (mem_sphere_zero_iff_norm.mp g.2)) ∘ pullBox L n = pullBox L n ∘ conjPhys g := by
    funext ω; exact (pullBox_conj L n g ω).symm
  rw [e, ← Measure.map_map (measurable_pullBox L n) hmc, hinv n]

end BoxFermion

#print axioms BoxFermion.blockMap_conj
#print axioms BoxFermion.down_conj
#print axioms BoxFermion.hsym_of_invariant
#print axioms BoxFermion.pullBox_conj
#print axioms BoxFermion.hsym_box_fermion

/-! ## the reference measure is invariant; `hsym` from the invariance of the density only -/
namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config

theorem haar_conj_preserving (g : SU2) :
    MeasurePreserving (fun x : SU2 => g * x * g⁻¹) (Measure.haarMeasure ⊤) (Measure.haarMeasure ⊤) := by
  haveI := haarTop_isProb SU2
  refine ⟨((continuous_mul_left g).mul continuous_const).measurable, ?_⟩
  have h1 : (fun x : SU2 => g * x * g⁻¹) = (fun x => x * g⁻¹) ∘ (fun x => g * x) := rfl
  rw [h1, ← Measure.map_map (continuous_mul_right _).measurable (continuous_mul_left _).measurable,
    MeasureTheory.map_mul_left_eq_self, CompactHaar.map_mul_right_eq]

theorem pi_conj_preserving {N hT : ℕ} (g : SU2) :
    MeasurePreserving (conjPhys (N := N) (hT := hT) g)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  haveI := haarTop_isProb SU2
  exact measurePreserving_pi _ _ fun _ => haar_conj_preserving g

/-- the Wilson–fermion measure is invariant under `conjPhys g` as soon as its density is -/
theorem wfProb_conj_of_weight {N : ℕ} [NeZero N] {hT : ℕ} (j : ℕ) (m β : ℝ) (g : SU2)
    (hw : ∀ ω, wfWeight N hT j m β (conjPhys g ω) = wfWeight N hT j m β ω) (hpos : 0 < hT) :
    (wfProb N hT j m β).map (conjPhys g) = wfProb N hT j m β := by
  have hT' := pi_conj_preserving (N := N) (hT := hT) g
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (conjPhys g ω)).toNNReal : ENNReal) := fun ω => by rw [hw]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

/-- **`hsym` of the box chain for the global gauge transformations, from the gauge invariance of the density
`exp(−β S_W) Re det D^{2j}`** (premise `hw`, a finite-dimensional identity at each level) -/
theorem hsym_box_fermion_of_weight (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (g : SU2)
    (hw : ∀ n ω, wfWeight (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n) (conjPhys g ω)
      = wfWeight (2 * (2 ^ n * L)) (2 ^ n * L) j (mseq n) (βseq n) ω) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (conjCfg (g : Quaternion ℝ) (mem_sphere_zero_iff_norm.mp g.2) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) :=
  hsym_box_fermion L hr j mseq βseq g (fun n => wfProb_conj_of_weight j (mseq n) (βseq n) g (hw n) (h_pos L n)) m

end BoxFermion

#print axioms BoxFermion.haar_conj_preserving
#print axioms BoxFermion.wfProb_conj_of_weight
#print axioms BoxFermion.hsym_box_fermion_of_weight

/-! ## the Wilson action is gauge invariant; `hsym` from the gauge invariance of the determinant only -/
namespace BoxFermion

open MeasureTheory Filter Matrix ChainBlockMap BoxWalk WilsonGauge FermionSU2Config

theorem quatMat_one' : quatMat (1 : Quaternion ℝ) = 1 := quatMat_one

theorem plaqE_conj (G A B C D : Matrix (Fin 2) (Fin 2) ℂ) (hGG : Gᴴ * G = 1) :
    plaqE (G * A * Gᴴ) (G * B * Gᴴ) (G * C * Gᴴ) (G * D * Gᴴ) = plaqE A B C D := by
  unfold plaqE
  have hc : ∀ X : Matrix (Fin 2) (Fin 2) ℂ, Gᴴ * (G * X) = X := fun X => by
    rw [← Matrix.mul_assoc, hGG, Matrix.one_mul]
  have e : (G * A * Gᴴ * (G * B * Gᴴ) * (G * C * Gᴴ)ᴴ * (G * D * Gᴴ)ᴴ).trace = (A * B * Cᴴ * Dᴴ).trace := by
    simp only [conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc, hc]
    rw [Matrix.trace_mul_comm G]
    simp only [Matrix.mul_assoc, hGG, Matrix.mul_one]
  rw [e]

theorem physSp_conj {N hT : ℕ} (g : SU2) (ω : PhysLink N hT → SU2) (t : ℕ) (x : Fin 3 → Fin N) (i : Fin 3) :
    physSp (conjPhys g ω) t x i
      = quatMat (g : Quaternion ℝ) * physSp ω t x i * (quatMat (g : Quaternion ℝ))ᴴ := by
  unfold physSp conjPhys
  split_ifs
  · rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, coe_inv_su2, quatMat_mul, quatMat_mul, quatMat_star]
  · rw [Matrix.mul_one, ← quatMat_star, ← quatMat_mul, mul_star_self_unit (mem_sphere_zero_iff_norm.mp g.2),
      quatMat_one']

theorem physT_conj {N hT : ℕ} (g : SU2) (ω : PhysLink N hT → SU2) (t : ℕ) (x : Fin 3 → Fin N) :
    physT (conjPhys g ω) t x = quatMat (g : Quaternion ℝ) * physT ω t x * (quatMat (g : Quaternion ℝ))ᴴ := by
  unfold physT conjPhys
  split_ifs
  · rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, coe_inv_su2, quatMat_mul, quatMat_mul, quatMat_star]
  · rw [Matrix.mul_one, ← quatMat_star, ← quatMat_mul, mul_star_self_unit (mem_sphere_zero_iff_norm.mp g.2),
      quatMat_one']

/-- **the Wilson action is invariant under global gauge transformations** -/
theorem wilsonAction_conj (N : ℕ) [NeZero N] (hT : ℕ) (g : SU2) (ω : PhysLink N hT → SU2) :
    wilsonAction N hT (conjPhys g ω) = wilsonAction N hT ω := by
  have hGG : (quatMat (g : Quaternion ℝ))ᴴ * quatMat (g : Quaternion ℝ) = 1 := by
    rw [← quatMat_star, ← quatMat_mul, star_mul_self_unit (mem_sphere_zero_iff_norm.mp g.2), quatMat_one']
  unfold wilsonAction spS tmS
  simp only [physSp_conj, physT_conj, plaqE_conj _ _ _ _ _ hGG]

/-- **`hsym` of the box chain for the global gauge transformations, from the gauge invariance of the determinant
`det D(gωg⁻¹) = det D(ω)`** (premise `hdet`; the Haar measure and the Wilson action are handled in Lean) -/
theorem hsym_box_fermion_of_det (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (j : ℕ) (mseq βseq : ℕ → ℝ) (g : SU2)
    (hdet : ∀ n ω, (physDirac (2 * (2 ^ n * L)) (2 ^ n * L) (mseq n) (conjPhys g ω)).det
      = (physDirac (2 * (2 ^ n * L)) (2 ^ n * L) (mseq n) ω).det) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (conjCfg (g : Quaternion ℝ) (mem_sphere_zero_iff_norm.mp g.2) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L j mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) :=
  hsym_box_fermion_of_weight L hr j mseq βseq g (fun n ω => by
    unfold wfWeight
    rw [wilsonAction_conj, hdet]) m

end BoxFermion

#print axioms BoxFermion.plaqE_conj
#print axioms BoxFermion.wilsonAction_conj
#print axioms BoxFermion.hsym_box_fermion_of_det

namespace BoxFermion

open MeasureTheory Filter ChainBlockMap BoxWalk WilsonGauge FermionSU2Config

/-- **`hsym` for the global gauge transformations without premise when `j = 0`** (the pure-gauge Wilson measure
pushed to the box: the density is `exp(−β S_W)`, gauge invariant by `wilsonAction_conj`) -/
theorem hsym_box_pure_gauge (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀) (mseq βseq : ℕ → ℝ) (g : SU2) (m : ℕ) :
    ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (Cfg (BoxLk (2 * L) m)) ℝ,
      ∫ ω, F (conjCfg (g : Quaternion ℝ) (mem_sphere_zero_iff_norm.mp g.2) ω)
          ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L 0 mseq βseq) n m : Measure (Cfg (BoxLk (2 * L) m)))
        = ∫ ω, F ω ∂(νP r₀ hr (boxPaths (2 * L)) (boxW (2 * L)) (fermProbBox L 0 mseq βseq) n m
          : Measure (Cfg (BoxLk (2 * L) m))) :=
  hsym_box_fermion_of_weight L hr 0 mseq βseq g (fun n ω => by
    unfold wfWeight
    rw [wilsonAction_conj]
    simp) m

end BoxFermion

#print axioms BoxFermion.hsym_box_pure_gauge
