import FermionLane.TimeReflV10b
import FermionLane.CubicPhysV10b

/-! # 90° rotations in a (space, time) plane on the isotropic lattice `N = 2h`

The spatial torus is `(Fin (2h))³` and the time circle has length `2h`.  The rotation in the plane `(a, time)`
(`e_a ↦ e_time ↦ − e_a`) relabels the sites by `(t, x) ↦ (x_a, x with x_a := rev t)`; the antiperiodic cuts
(`N − 1 → 0` in space, `2h − 1 → 0` in time) are kept in place.  The spin factor is `1 + γ₄ γ_a` (`rot_spin`).
* `hopSp_torus_apply`, `hopT_blk_apply`: the hops in site form.
* **`physDirac_det_trot`**: `det D(R ω) = det D(ω)` for the rotated configuration `trotPhys a ω`. -/

namespace CubicSym

open Matrix FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion
open scoped Kronecker

section Hops

variable {h : ℕ} {N : ℕ} [NeZero N]

theorem hopSp_torus_apply (U : ℕ → (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ) (i : Fin 3)
    (p q : Fin (2 * h) × (Fin 2 × (Fin 3 → Fin N))) :
    hopSp h (fun t => torusX N (U t)) i p q
      = if q.1 = p.1 ∧ q.2.2 = p.2.2 + Pi.single i 1 then
          (if (p.2.2 i).val + 1 = N then (-1 : ℂ) else 1) * U p.1.val p.2.2 i p.2.1 q.2.1 else 0 := by
  obtain ⟨t, c, x⟩ := p
  obtain ⟨t', c', y⟩ := q
  unfold hopSp
  simp only [torusX, shiftMat_apply, torusLink, torusShift, Equiv.coe_addRight, Matrix.smul_apply, smul_eq_mul]
  by_cases h1 : t' = t
  · have h1' : t'.val = t.val := by rw [h1]
    by_cases h2 : y = x + Pi.single i 1
    · have h2' : x = y + -Pi.single i 1 := by rw [h2]; simp
      simp only [eq_true h2', if_true, h1, true_and, eq_true h2]
    · have h2' : ¬ x = y + -Pi.single i 1 := fun e => h2 (by rw [e]; simp)
      simp only [eq_true h1', eq_false h2', if_true, if_false, h1, true_and, eq_false h2]
  · have h1' : ¬ t'.val = t.val := fun e => h1 (Fin.ext e)
    simp only [eq_false h1', if_false, eq_false h1, false_and]

theorem hopT_blk_apply (V : ℕ → (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (p q : Fin (2 * h) × (Fin 2 × (Fin 3 → Fin N))) :
    hopT h (fun t => eps (sc h t) • blockDiagonal (V t)) p q
      = if q.1.val = sc h p.1.val ∧ q.2.2 = p.2.2 then eps (sc h p.1.val) * V p.1.val p.2.2 p.2.1 q.2.1 else 0 := by
  obtain ⟨t, c, x⟩ := p
  obtain ⟨t', c', y⟩ := q
  unfold hopT
  simp only [Matrix.smul_apply, smul_eq_mul, blockDiagonal_apply']
  by_cases h1 : t'.val = sc h t.val
  · by_cases h2 : y = x
    · simp only [eq_true h1, if_true, h2, true_and]
    · simp only [eq_true h1, if_true, eq_false (Ne.symm h2), if_false, mul_zero, true_and, eq_false h2]
  · simp only [eq_false h1, if_false, false_and]

end Hops

section Site

variable {h : ℕ} [NeZero (2 * h)]

/-- the site map of the rotation in the plane `(a, time)`: `(t, x) ↦ (x_a, x with x_a := rev t)` -/
def trotSite (a : Fin 3) : Fin (2 * h) × (Fin 3 → Fin (2 * h)) ≃ Fin (2 * h) × (Fin 3 → Fin (2 * h)) where
  toFun p := (p.2 a, Function.update p.2 a (Fin.rev p.1))
  invFun q := (Fin.rev (q.2 a), Function.update q.2 a q.1)
  left_inv p := by
    obtain ⟨t, x⟩ := p
    simp
  right_inv q := by
    obtain ⟨t, y⟩ := q
    simp

/-- the same on `time × (colour × space)` -/
def trotIdx (a : Fin 3) : Fin (2 * h) × (Fin 2 × (Fin 3 → Fin (2 * h))) ≃ Fin (2 * h) × (Fin 2 × (Fin 3 → Fin (2 * h))) where
  toFun p := (p.2.2 a, (p.2.1, Function.update p.2.2 a (Fin.rev p.1)))
  invFun q := (Fin.rev (q.2.2 a), (q.2.1, Function.update q.2.2 a q.1))
  left_inv p := by
    obtain ⟨t, c, x⟩ := p
    simp
  right_inv q := by
    obtain ⟨t, c, y⟩ := q
    simp

theorem add_one_val_sc (z : Fin (2 * h)) : (z + 1).val = sc h z.val := by
  have hz := z.isLt
  have hpos : 0 < 2 * h := by omega
  rw [Fin.val_add, show (1 : Fin (2 * h)).val = 1 % (2 * h) from rfl]
  unfold sc
  rcases Nat.lt_or_ge 1 (2 * h) with h1 | h1
  · rw [Nat.mod_eq_of_lt h1]
    split_ifs with hc
    · rw [hc, Nat.mod_self]
    · rw [Nat.mod_eq_of_lt (by omega)]
  · have h2 : 2 * h = 1 := by omega
    omega

theorem update_add_single (a : Fin 3) (x : Fin 3 → Fin (2 * h)) (r : Fin (2 * h)) :
    Function.update (x + Pi.single a 1) a r = Function.update x a r := by
  funext l
  by_cases hl : l = a
  · subst hl; simp
  · simp [Function.update_of_ne hl, Pi.single_apply, hl]

end Site

section Phys

variable {h : ℕ} [NeZero (2 * h)]

/-- the configuration rotated by 90° in the plane `(a, time)` (`e_a ↦ e_time ↦ − e_a`), on the isotropic lattice:
the new time links are the old `a`-links, the new `a`-links are the reversed old time links -/
noncomputable def trotPhys (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) : PhysLink (2 * h) h → SU2 := fun l =>
  if l.2.2 = 3 then ω (Fin.rev (l.2.1 a), Function.update l.2.1 a l.1, a.castSucc)
  else if l.2.2 = a.castSucc then (ω (Fin.rev ((l.2.1 + Pi.single a 1 : Fin 3 → Fin (2 * h)) a), Function.update l.2.1 a l.1, 3))⁻¹
  else ω (Fin.rev (l.2.1 a), Function.update l.2.1 a l.1, l.2.2)

theorem castSucc_ne_three (i : Fin 3) : i.castSucc ≠ (3 : Fin 4) := fun e => last_ne_castSucc i e.symm

theorem physT_trot (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) (t : Fin (2 * h)) (y : Fin 3 → Fin (2 * h)) :
    physT (trotPhys a ω) t.val y = physSp ω (Fin.rev (y a)).val (Function.update y a t) a := by
  unfold physT physSp
  rw [dif_pos t.isLt, dif_pos (Fin.rev (y a)).isLt]
  simp only [trotPhys, if_true]

theorem physSp_trot_a (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) (t : Fin (2 * h)) (y : Fin 3 → Fin (2 * h)) :
    physSp (trotPhys a ω) t.val y a
      = (physT ω (Fin.rev ((y + Pi.single a 1 : Fin 3 → Fin (2 * h)) a)).val (Function.update y a t))ᴴ := by
  unfold physT physSp
  rw [dif_pos t.isLt, dif_pos (Fin.rev ((y + Pi.single a 1 : Fin 3 → Fin (2 * h)) a)).isLt]
  simp only [trotPhys, if_neg (castSucc_ne_three a), if_true]
  exact quatMat_inv _

theorem physSp_trot_c (a i : Fin 3) (hia : i ≠ a) (ω : PhysLink (2 * h) h → SU2) (t : Fin (2 * h))
    (y : Fin 3 → Fin (2 * h)) :
    physSp (trotPhys a ω) t.val y i = physSp ω (Fin.rev (y a)).val (Function.update y a t) i := by
  unfold physSp
  rw [dif_pos t.isLt, dif_pos (Fin.rev (y a)).isLt]
  simp only [trotPhys, if_neg (castSucc_ne_three i), if_neg (castSucc_ne_castSucc hia)]

theorem trotIdx_apply (a : Fin 3) (t : Fin (2 * h)) (c : Fin 2) (x : Fin 3 → Fin (2 * h)) :
    trotIdx a (t, c, x) = (x a, c, Function.update x a (Fin.rev t)) := rfl

theorem sc_zero_iff (t : Fin (2 * h)) : sc h t.val = 0 ↔ t.val + 1 = 2 * h := by
  unfold sc
  by_cases hc : t.val + 1 = 2 * h <;> simp [hc]

theorem eps_sc (t : Fin (2 * h)) : eps (sc h t.val) = if t.val + 1 = 2 * h then (-1 : ℂ) else 1 := by
  unfold eps
  by_cases hc : t.val + 1 = 2 * h
  · rw [if_pos ((sc_zero_iff t).2 hc), if_pos hc]
  · rw [if_neg (fun e => hc ((sc_zero_iff t).1 e)), if_neg hc]

theorem rev_cut (t : Fin (2 * h)) : (Fin.rev t).val + 1 = 2 * h ↔ t.val = 0 := by
  rw [rev_val]; have := t.isLt; omega

/-- the hop in the direction `a` becomes the forward time hop -/
theorem trot_hop_a (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) :
    permQ (trotIdx a) * hopSp h (fun t => torusX (2 * h) (physSp ω t)) a * (permQ (trotIdx a))ᴴ
      = hopT h (fun t => eps (sc h t) • blockDiagonal (physT (trotPhys a ω) t)) := by
  ext p q
  rw [permQ_conj_apply]
  obtain ⟨p0, rfl⟩ := (trotIdx a).surjective p
  obtain ⟨q0, rfl⟩ := (trotIdx a).surjective q
  rw [Equiv.symm_apply_apply, Equiv.symm_apply_apply, hopSp_torus_apply, hopT_blk_apply]
  obtain ⟨t, c, x⟩ := p0
  obtain ⟨t', c', x'⟩ := q0
  simp only [trotIdx_apply]
  by_cases hc : t' = t ∧ x' = x + Pi.single a 1
  · obtain ⟨rfl, rfl⟩ := hc
    have hc2 : ((x + Pi.single a 1 : Fin 3 → Fin (2 * h)) a).val = sc h (x a).val ∧
        Function.update (x + Pi.single a 1) a (Fin.rev t') = Function.update x a (Fin.rev t') := by
      refine ⟨?_, update_add_single a x _⟩
      simp only [Pi.add_apply, Pi.single_eq_same]
      exact add_one_val_sc _
    simp only [and_self, if_true, eq_true hc2]
    rw [physT_trot, eps_sc]
    simp only [Function.update_self, Fin.rev_rev, Function.update_idem, Function.update_eq_self]
  · have hc2 : ¬ (((x' a).val = sc h (x a).val) ∧
        Function.update x' a (Fin.rev t') = Function.update x a (Fin.rev t)) := by
      rintro ⟨h1, h2⟩
      apply hc
      have ht : Fin.rev t' = Fin.rev t := by
        have := congrFun h2 a
        simpa using this
      refine ⟨Fin.rev_injective ht, ?_⟩
      funext l
      by_cases hl : l = a
      · subst hl
        simp only [Pi.add_apply, Pi.single_eq_same]
        exact Fin.ext (by rw [add_one_val_sc]; exact h1)
      · have := congrFun h2 l
        simp only [Function.update_of_ne hl] at this
        simp [this, Pi.single_apply, hl]
    simp only [eq_false hc, eq_false hc2, if_false]

/-- the time hop becomes the reversed hop in the direction `a` -/
theorem trot_hop_t (a : Fin 3) (ω : PhysLink (2 * h) h → SU2) :
    permQ (trotIdx a) * hopT h (fun t => eps (sc h t) • blockDiagonal (physT ω t)) * (permQ (trotIdx a))ᴴ
      = (hopSp h (fun t => torusX (2 * h) (physSp (trotPhys a ω) t)) a)ᴴ := by
  ext p q
  rw [permQ_conj_apply, conjTranspose_apply]
  obtain ⟨p0, rfl⟩ := (trotIdx a).surjective p
  obtain ⟨q0, rfl⟩ := (trotIdx a).surjective q
  rw [Equiv.symm_apply_apply, Equiv.symm_apply_apply, hopT_blk_apply, hopSp_torus_apply]
  obtain ⟨t, c, x⟩ := p0
  obtain ⟨t', c', x'⟩ := q0
  simp only [trotIdx_apply]
  by_cases hc : t'.val = sc h t.val ∧ x' = x
  · obtain ⟨h1, rfl⟩ := hc
    have ht' : t' = t + 1 := Fin.ext (by rw [add_one_val_sc]; exact h1)
    have hrev : Fin.rev t' + 1 = Fin.rev t := by rw [ht', Fin.rev_add, sub_add_cancel]
    have hc2 : Function.update x' a (Fin.rev t) = Function.update x' a (Fin.rev t') + Pi.single a 1 := by
      funext l
      by_cases hl : l = a
      · subst hl; simp [hrev]
      · simp [Function.update_of_ne hl, Pi.single_apply, hl]
    have hs : ((Fin.rev t').val + 1 = 2 * h) ↔ (t.val + 1 = 2 * h) := by rw [rev_cut, h1, sc_zero_iff]
    simp only [eq_true h1, eq_self_iff_true, and_self, true_and, eq_true hc2, if_true]
    rw [physSp_trot_a, eps_sc]
    simp only [Pi.add_apply, Function.update_self, Pi.single_eq_same, hrev, Fin.rev_rev, Function.update_idem,
      Function.update_eq_self, conjTranspose_apply, hs]
    split_ifs <;> simp
  · have hc2 : ¬ (x a = x' a ∧ Function.update x a (Fin.rev t) = Function.update x' a (Fin.rev t') + Pi.single a 1) := by
      rintro ⟨h1, h2⟩
      apply hc
      have hr : Fin.rev t = Fin.rev t' + 1 := by
        have := congrFun h2 a
        simpa using this
      have ht' : t' = t + 1 := by
        apply Fin.rev_injective
        rw [Fin.rev_add, hr, add_sub_cancel_right]
      refine ⟨by rw [ht', add_one_val_sc], ?_⟩
      funext l
      by_cases hl : l = a
      · rw [hl, h1]
      · have := congrFun h2 l
        simp [Function.update_of_ne hl, Pi.single_apply, hl] at this
        exact this.symm
    simp only [eq_false hc, eq_false hc2, if_false, star_zero]

/-- the other spatial hops are carried along -/
theorem trot_hop_c (a i : Fin 3) (hia : i ≠ a) (ω : PhysLink (2 * h) h → SU2) :
    permQ (trotIdx a) * hopSp h (fun t => torusX (2 * h) (physSp ω t)) i * (permQ (trotIdx a))ᴴ
      = hopSp h (fun t => torusX (2 * h) (physSp (trotPhys a ω) t)) i := by
  ext p q
  rw [permQ_conj_apply]
  obtain ⟨p0, rfl⟩ := (trotIdx a).surjective p
  obtain ⟨q0, rfl⟩ := (trotIdx a).surjective q
  rw [Equiv.symm_apply_apply, Equiv.symm_apply_apply, hopSp_torus_apply, hopSp_torus_apply]
  obtain ⟨t, c, x⟩ := p0
  obtain ⟨t', c', x'⟩ := q0
  simp only [trotIdx_apply]
  by_cases hc : t' = t ∧ x' = x + Pi.single i 1
  · obtain ⟨rfl, rfl⟩ := hc
    have hc2 : (x + Pi.single i 1 : Fin 3 → Fin (2 * h)) a = x a ∧
        Function.update (x + Pi.single i 1) a (Fin.rev t') = Function.update x a (Fin.rev t') + Pi.single i 1 := by
      refine ⟨by simp [Pi.single_apply, Ne.symm hia], ?_⟩
      funext l
      by_cases hl : l = a
      · subst hl; simp [Pi.single_apply, Ne.symm hia]
      · simp [Function.update_of_ne hl]
    simp only [and_self, if_true, eq_true hc2]
    rw [physSp_trot_c a i hia]
    simp only [Function.update_self, Fin.rev_rev, Function.update_idem, Function.update_eq_self,
      Function.update_of_ne hia]
  · have hc2 : ¬ (x' a = x a ∧
        Function.update x' a (Fin.rev t') = Function.update x a (Fin.rev t) + Pi.single i 1) := by
      rintro ⟨h1, h2⟩
      apply hc
      have hr : Fin.rev t' = Fin.rev t := by
        have := congrFun h2 a
        simpa [Pi.single_apply, Ne.symm hia] using this
      refine ⟨Fin.rev_injective hr, ?_⟩
      funext l
      by_cases hl : l = a
      · rw [hl, h1]; simp [Pi.single_apply, Ne.symm hia]
      · have := congrFun h2 l
        simpa [Function.update_of_ne hl] using this
    simp only [eq_false hc, eq_false hc2, if_false]

/-- **the determinant of the Wilson–Dirac operator is invariant under the 90° rotation in a (space, time) plane**
(isotropic lattice: spatial torus `(Fin (2h))³`, time circle `2h`) -/
theorem physDirac_det_trot (a : Fin 3) (m : ℝ) (ω : PhysLink (2 * h) h → SU2) :
    (physDirac (2 * h) h m (trotPhys a ω)).det = (physDirac (2 * h) h m ω).det := by
  unfold physDirac
  rw [det_std4_eq_cliffOp, det_std4_eq_cliffOp]
  refine det_cliffOp_perm m (permQ (trotIdx a)) (permQ_unitary _) _ _ (Equiv.swap a.castSucc 3) (fun μ => μ ≠ 3)
    ?_ ⟨_, _, rot_spin a.castSucc 3 (castSucc_ne_three a)⟩
  intro μ
  induction μ using Fin.lastCases with
  | last =>
    have e3 : Equiv.swap a.castSucc 3 (Fin.last 3) = a.castSucc := Equiv.swap_apply_right _ _
    rw [if_neg (fun hh => hh rfl), e3, hop4_last, hop4_castSucc]
    exact trot_hop_t a ω
  | cast i =>
    rw [if_pos (castSucc_ne_three i), hop4_castSucc]
    by_cases hia : i = a
    · rw [hia, Equiv.swap_apply_left, show (3 : Fin 4) = Fin.last 3 from rfl, hop4_last]
      exact trot_hop_a a ω
    · rw [Equiv.swap_apply_of_ne_of_ne (castSucc_ne_castSucc hia) (castSucc_ne_three i), hop4_castSucc]
      exact trot_hop_c a i hia ω

end Phys

end CubicSym

#print axioms CubicSym.hopSp_torus_apply
#print axioms CubicSym.hopT_blk_apply
#print axioms CubicSym.add_one_val_sc
#print axioms CubicSym.trot_hop_a
#print axioms CubicSym.trot_hop_t
#print axioms CubicSym.trot_hop_c
#print axioms CubicSym.physDirac_det_trot
