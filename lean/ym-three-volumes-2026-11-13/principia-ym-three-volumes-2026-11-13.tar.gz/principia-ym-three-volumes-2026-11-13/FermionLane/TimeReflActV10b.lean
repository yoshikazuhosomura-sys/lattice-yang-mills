import FermionLane.TimeReflV10b
import FermionLane.TimeShiftV9h

/-! # The time reflection: Wilson action and the normalised Wilson–fermion measure

* `sc_rev_sc`: `sc(2h − 1 − sc s) = 2h − 1 − s`;
* **`wilsonAction_trefl`**: the spatial plaquettes of slice `s` become those of slice `2h − 1 − s`, the temporal
  plaquettes between `s` and `s + 1` become those between `2h − 2 − s` and `2h − 1 − s` read backwards
  (`tmS_reflect`);
* `treflLink` (an involution of the links), `pi_trefl_preserving`, **`wfProb_trefl`**. -/

namespace CubicSym

open Matrix MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion TimeShift

variable {N : ℕ} [NeZero N] {hT : ℕ}

theorem sc_rev_sc (s : ℕ) (hs : s < 2 * hT) : sc hT (2 * hT - 1 - sc hT s) = 2 * hT - 1 - s := by
  unfold sc
  split_ifs <;> omega

/-- **the Wilson action is invariant under the time reflection** -/
theorem wilsonAction_trefl (ω : PhysLink N hT → SU2) : wilsonAction N hT (treflPhys ω) = wilsonAction N hT ω := by
  unfold wilsonAction
  have e : ∀ s ∈ Finset.range (2 * hT),
      spS N (physSp (treflPhys ω) s) + tmS N (physSp (treflPhys ω) s) (physSp (treflPhys ω) (sc hT s))
          (physT (treflPhys ω) s)
        = spS N (physSp ω (2 * hT - 1 - s))
          + tmS N (physSp ω (2 * hT - 1 - sc hT s)) (physSp ω (sc hT (2 * hT - 1 - sc hT s)))
              (physT ω (2 * hT - 1 - sc hT s)) := by
    intro s hs
    rw [Finset.mem_range] at hs
    have hT' : physT (treflPhys ω) s = fun x => (physT ω (2 * hT - 1 - sc hT s) x)ᴴ :=
      funext (physT_trefl ω s hs)
    rw [physSp_trefl ω s hs, physSp_trefl ω (sc hT s) (sc_lt hT s hs), hT', tmS_reflect, sc_rev_sc s hs]
  have h1 : ∑ s ∈ Finset.range (2 * hT), spS N (physSp ω (2 * hT - 1 - s))
      = ∑ s ∈ Finset.range (2 * hT), spS N (physSp ω s) :=
    Finset.sum_range_reflect (fun k => spS N (physSp ω k)) (2 * hT)
  have h2 : ∑ s ∈ Finset.range (2 * hT), tmS N (physSp ω (2 * hT - 1 - sc hT s))
        (physSp ω (sc hT (2 * hT - 1 - sc hT s))) (physT ω (2 * hT - 1 - sc hT s))
      = ∑ s ∈ Finset.range (2 * hT), tmS N (physSp ω s) (physSp ω (sc hT s)) (physT ω s) :=
    (sum_range_sc hT (fun k => tmS N (physSp ω (2 * hT - 1 - k)) (physSp ω (sc hT (2 * hT - 1 - k)))
      (physT ω (2 * hT - 1 - k)))).trans
      (Finset.sum_range_reflect (fun k => tmS N (physSp ω k) (physSp ω (sc hT k)) (physT ω k)) (2 * hT))
  rw [Finset.sum_congr rfl e, Finset.sum_add_distrib, Finset.sum_add_distrib, h1, h2]

theorem wfWeight_trefl (j : ℕ) (m β : ℝ) (ω : PhysLink N hT → SU2) :
    wfWeight N hT j m β (treflPhys ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_trefl, physDirac_det_trefl]

/-- the link relabelling of the time reflection (an involution) -/
def treflLink (l : PhysLink N hT) : PhysLink N hT :=
  if l.2.2 = 3 then (Fin.rev (tsc l.1), l.2.1, l.2.2) else (Fin.rev l.1, l.2.1, l.2.2)

theorem rev_tsc_invol (t : Fin (2 * hT)) : Fin.rev (tsc (Fin.rev (tsc t))) = t := by
  apply Fin.ext
  rw [rev_val]
  show 2 * hT - 1 - sc hT (Fin.rev (tsc t)).val = t.val
  rw [rev_val]
  show 2 * hT - 1 - sc hT (2 * hT - 1 - sc hT t.val) = t.val
  rw [sc_rev_sc t.val t.isLt]
  have := t.isLt
  omega

theorem treflLink_invol : Function.Involutive (treflLink (N := N) (hT := hT)) := by
  intro l
  obtain ⟨t, y, μ⟩ := l
  by_cases h : μ = 3
  · simp only [treflLink, h, if_true, rev_tsc_invol]
  · simp only [treflLink, h, if_false, Fin.rev_rev]

/-- inversion on the time links -/
noncomputable def invOnT (l : PhysLink N hT) : SU2 → SU2 := if l.2.2 = 3 then fun g => g⁻¹ else id

theorem treflPhys_eq (ω : PhysLink N hT → SU2) : treflPhys ω = fun l => invOnT l (ω (treflLink l)) := by
  funext l
  obtain ⟨t, y, μ⟩ := l
  by_cases h : μ = 3
  · simp only [treflPhys, invOnT, treflLink, h, if_true]
  · simp only [treflPhys, invOnT, treflLink, h, if_false, id]

theorem pi_trefl_preserving (hT : ℕ) :
    MeasurePreserving (treflPhys (N := N) (hT := hT))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h1 := measurePreserving_arrowCongr' (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (treflLink_invol (N := N) (hT := hT)).toPerm.symm
    (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e1 : ⇑(MeasurableEquiv.arrowCongr' (treflLink_invol (N := N) (hT := hT)).toPerm.symm (MeasurableEquiv.refl SU2))
      = fun ω => ω ∘ treflLink := by
    funext ω l; rfl
  rw [e1] at h1
  have h2 := measurePreserving_pi (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (f := fun l => invOnT l) (fun l => by
      unfold invOnT
      split_ifs
      · exact haarTop_inv_preserving SU2
      · exact MeasurePreserving.id _)
  have e2 : (treflPhys (N := N) (hT := hT)) = (fun ω l => invOnT l (ω l)) ∘ (fun ω => ω ∘ treflLink) := by
    funext ω
    rw [treflPhys_eq]
    rfl
  rw [e2]
  exact h2.comp h1

/-- **the normalised Wilson–fermion measure is invariant under the time reflection** -/
theorem wfProb_trefl (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    (wfProb N hT j m β).map treflPhys = wfProb N hT j m β := by
  have hT' := pi_trefl_preserving (N := N) hT
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (treflPhys ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_trefl]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end CubicSym

#print axioms CubicSym.wilsonAction_trefl
#print axioms CubicSym.pi_trefl_preserving
#print axioms CubicSym.wfProb_trefl
