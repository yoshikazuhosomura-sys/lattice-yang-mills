import FermionLane.CubicPhysV10b

/-! # The reflections of the spatial axes: Wilson action and the normalised Wilson–fermion measure

* `plaqE_rev`, `plaqE_rev2`: a plaquette read with two of its links reversed (trace cyclic, `tr Mᴴ = conj tr M`).
* `spS_refl`, `tmS_refl`: the spatial and the temporal plaquette sums are invariant when the `k`-links are reversed
  and the sites reflected by `reflSite k`.
* **`wilsonAction_refl`**, `wfWeight_refl`: the Wilson action and the density `e^{−βS_W} Re det D^{2j}`.
* `reflLink` (an involution of the links), `pi_refl_preserving`: `Π Haar` is preserved (link relabelling and the
  inversion `g ↦ g⁻¹` on the reversed links).
* **`wfProb_refl`**: the normalised Wilson–fermion measure is invariant under the reflection of a spatial axis. -/

namespace CubicSym

open Matrix MeasureTheory FermionSliceBlock GaugeDet WilsonGauge FermionSU2Config BoxFermion

variable {N : ℕ} [NeZero N]

theorem plaqE_rev (A B C D : Matrix (Fin 2) (Fin 2) ℂ) : plaqE Aᴴ B Cᴴ D = plaqE A D C B := by
  unfold plaqE
  have h1 : (Aᴴ * B * Cᴴᴴ * Dᴴ).trace = ((A * D * Cᴴ * Bᴴ)ᴴ).trace := by
    simp only [conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]
    rw [Matrix.trace_mul_comm Aᴴ]
    simp only [Matrix.mul_assoc]
  rw [h1, Matrix.trace_conjTranspose, Complex.star_def, Complex.conj_re]

theorem plaqE_rev2 (A B C D : Matrix (Fin 2) (Fin 2) ℂ) : plaqE A Bᴴ C Dᴴ = plaqE C B A D := by
  unfold plaqE
  have h1 : (A * Bᴴ * Cᴴ * Dᴴᴴ).trace = ((C * B * Aᴴ * Dᴴ)ᴴ).trace := by
    simp only [conjTranspose_mul, conjTranspose_conjTranspose, Matrix.mul_assoc]
    rw [Matrix.trace_mul_comm D]
    simp only [Matrix.mul_assoc]
  rw [h1, Matrix.trace_conjTranspose, Complex.star_def, Complex.conj_re]

/-- the reflection `y ↦ reflSite k (y + e_k)` used to relabel the reversed links -/
def reflShift (k : Fin 3) : (Fin 3 → Fin N) ≃ (Fin 3 → Fin N) :=
  (Equiv.addRight (Pi.single k 1)).trans (reflSite k)

theorem reflShift_apply (k : Fin 3) (y : Fin 3 → Fin N) : reflShift k y = reflSite k (y + Pi.single k 1) := rfl

theorem spS_refl (k : Fin 3) (B B' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (hk : ∀ y, B' y k = (B (reflSite k (y + Pi.single k 1)) k)ᴴ)
    (ho : ∀ y i, i ≠ k → B' y i = B (reflSite k y) i) :
    spS N B' = spS N B := by
  unfold spS
  simp only [ev]
  conv_lhs => rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  conv_lhs => rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun j hj => ?_
  have hij : i < j := Finset.mem_Ioi.mp hj
  by_cases hik : i = k
  · rw [hik] at hij ⊢
    have hjk : j ≠ k := (ne_of_lt hij).symm
    refine Fintype.sum_equiv (reflShift k) _ _ fun y => ?_
    have e1 : reflSite k (y + Pi.single j 1 + Pi.single k 1) = reflShift k y + Pi.single j 1 := by
      rw [add_right_comm, refl_fwd k j hjk]; rfl
    have e2 : reflSite k y = reflShift k y + Pi.single k 1 := (refl_bwd k y).symm
    rw [hk y, ho (y + Pi.single k 1) j hjk, hk (y + Pi.single j 1), ho y j hjk, e1, e2]
    exact plaqE_rev _ _ _ _
  · by_cases hjk : j = k
    · rw [hjk] at hij ⊢
      refine Fintype.sum_equiv (reflShift k) _ _ fun y => ?_
      have e1 : reflSite k (y + Pi.single i 1 + Pi.single k 1) = reflShift k y + Pi.single i 1 := by
        rw [add_right_comm, refl_fwd k i hik]; rfl
      have e2 : reflSite k y = reflShift k y + Pi.single k 1 := (refl_bwd k y).symm
      rw [ho y i hik, hk (y + Pi.single i 1), ho (y + Pi.single k 1) i hik, hk y, e1, e2]
      exact plaqE_rev2 _ _ _ _
    · refine Fintype.sum_equiv (reflSite k) _ _ fun y => ?_
      rw [ho y i hik, ho (y + Pi.single i 1) j hjk, ho (y + Pi.single j 1) i hik, ho y j hjk,
        refl_fwd k i hik, refl_fwd k j hjk]

theorem tmS_refl (k : Fin 3) (B0 B1 B0' B1' : (Fin 3 → Fin N) → Fin 3 → Matrix (Fin 2) (Fin 2) ℂ)
    (T T' : (Fin 3 → Fin N) → Matrix (Fin 2) (Fin 2) ℂ)
    (hk0 : ∀ y, B0' y k = (B0 (reflSite k (y + Pi.single k 1)) k)ᴴ)
    (ho0 : ∀ y i, i ≠ k → B0' y i = B0 (reflSite k y) i)
    (hk1 : ∀ y, B1' y k = (B1 (reflSite k (y + Pi.single k 1)) k)ᴴ)
    (ho1 : ∀ y i, i ≠ k → B1' y i = B1 (reflSite k y) i)
    (hT : ∀ y, T' y = T (reflSite k y)) :
    tmS N B0' B1' T' = tmS N B0 B1 T := by
  unfold tmS
  simp only [ev]
  conv_lhs => rw [Finset.sum_comm]
  conv_rhs => rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  by_cases hik : i = k
  · rw [hik]
    refine Fintype.sum_equiv (reflShift k) _ _ fun y => ?_
    have e2 : reflSite k y = reflShift k y + Pi.single k 1 := (refl_bwd k y).symm
    rw [hk0 y, hk1 y, hT, hT, e2]
    exact plaqE_rev _ _ _ _
  · refine Fintype.sum_equiv (reflSite k) _ _ fun y => ?_
    rw [ho0 y i hik, ho1 y i hik, hT, hT, refl_fwd k i hik]

section Phys

variable {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2)

/-- **the Wilson action is invariant under the reflections of the spatial axes** -/
theorem wilsonAction_refl : wilsonAction N hT (reflPhys k ω) = wilsonAction N hT ω := by
  unfold wilsonAction
  refine Finset.sum_congr rfl fun t _ => ?_
  rw [spS_refl k _ _ (fun y => physSp_refl_k k ω t y) (fun y i hik => physSp_refl_o k ω i hik t y),
    tmS_refl k _ _ _ _ _ _ (fun y => physSp_refl_k k ω t y) (fun y i hik => physSp_refl_o k ω i hik t y)
      (fun y => physSp_refl_k k ω (sc hT t) y) (fun y i hik => physSp_refl_o k ω i hik (sc hT t) y)
      (fun y => physT_refl k ω t y)]

theorem wfWeight_refl (j : ℕ) (m β : ℝ) : wfWeight N hT j m β (reflPhys k ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_refl, physDirac_det_refl]

end Phys

/-- the link relabelling of the reflection (an involution) -/
def reflLink {hT : ℕ} (k : Fin 3) (l : PhysLink N hT) : PhysLink N hT :=
  if l.2.2 = k.castSucc then (l.1, reflSite k (l.2.1 + Pi.single k 1), l.2.2) else (l.1, reflSite k l.2.1, l.2.2)

theorem reflSite_invol (k : Fin 3) (y : Fin 3 → Fin N) : reflSite k (reflSite k y) = y :=
  (reflSite k).symm_apply_apply y

theorem reflLink_invol {hT : ℕ} (k : Fin 3) : Function.Involutive (reflLink (N := N) (hT := hT) k) := by
  intro l
  obtain ⟨t, y, μ⟩ := l
  by_cases h : μ = k.castSucc
  · simp only [reflLink, h, if_true]
    rw [refl_bwd, reflSite_invol]
  · simp only [reflLink, h, if_false, reflSite_invol]

/-- inversion on the reversed links -/
noncomputable def invOn {hT : ℕ} (k : Fin 3) (l : PhysLink N hT) : SU2 → SU2 :=
  if l.2.2 = k.castSucc then fun g => g⁻¹ else id

theorem reflPhys_eq {hT : ℕ} (k : Fin 3) (ω : PhysLink N hT → SU2) :
    reflPhys k ω = fun l => invOn k l (ω (reflLink k l)) := by
  funext l
  obtain ⟨t, y, μ⟩ := l
  by_cases h : μ = k.castSucc
  · simp only [reflPhys, invOn, reflLink, h, if_true]
    rfl
  · simp only [reflPhys, invOn, reflLink, h, if_false, id]
    rfl

theorem pi_refl_preserving (hT : ℕ) (k : Fin 3) :
    MeasurePreserving (reflPhys (N := N) (hT := hT) k)
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h1 := measurePreserving_arrowCongr' (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (reflLink_invol (N := N) (hT := hT) k).toPerm.symm
    (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e1 : ⇑(MeasurableEquiv.arrowCongr' (reflLink_invol (N := N) (hT := hT) k).toPerm.symm (MeasurableEquiv.refl SU2))
      = fun ω => ω ∘ reflLink k := by
    funext ω l; rfl
  rw [e1] at h1
  have h2 := measurePreserving_pi (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (f := fun l => invOn k l) (fun l => by
      unfold invOn
      split_ifs
      · exact haarTop_inv_preserving SU2
      · exact MeasurePreserving.id _)
  have e2 : (reflPhys (N := N) (hT := hT) k) = (fun ω l => invOn k l (ω l)) ∘ (fun ω => ω ∘ reflLink k) := by
    funext ω
    rw [reflPhys_eq]
    rfl
  rw [e2]
  exact h2.comp h1

/-- **the normalised Wilson–fermion measure is invariant under the reflections of the spatial axes** -/
theorem wfProb_refl (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) (k : Fin 3) :
    (wfProb N hT j m β).map (reflPhys k) = wfProb N hT j m β := by
  have hT' := pi_refl_preserving (N := N) hT k
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (reflPhys k ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_refl]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end CubicSym

#print axioms CubicSym.spS_refl
#print axioms CubicSym.tmS_refl
#print axioms CubicSym.wilsonAction_refl
#print axioms CubicSym.pi_refl_preserving
#print axioms CubicSym.wfProb_refl
