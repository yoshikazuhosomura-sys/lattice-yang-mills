import FermionLane.BoxTransV9d

/-! # the determinant under the time translation `t ↦ t + 1`

The time circle has length `2h`, `sc h t = t + 1 mod 2h`; the antiperiodic sign sits on the link `2h − 1 → 0`
(`v_t = eps(sc t) U_t`).  Translating the configuration in time moves the sign, which is undone by the signed
permutation `(Qψ)(t) = eps(sc t) ψ(t + 1)` of the time index (`std4_tshift_apply`, `physDirac_det_tshift`). -/

namespace TimeShift

open Matrix FermionSliceBlock WilsonGauge FermionSU2Config GaugeDet

theorem sc_inj (h a b : ℕ) (ha : a < 2 * h) (hb : b < 2 * h) (e : sc h a = sc h b) : a = b := by
  rcases sc_spec h a with ⟨ha1, ha2⟩ | ⟨ha1, ha2⟩ <;> rcases sc_spec h b with ⟨hb1, hb2⟩ | ⟨hb1, hb2⟩ <;>
    rw [ha2, hb2] at e <;> omega

/-- `t ↦ t + 1` on the time circle -/
def tsucc (h : ℕ) (t : Fin (2 * h)) : Fin (2 * h) := ⟨sc h t.val, sc_lt h t.val t.isLt⟩

theorem tsucc_injective (h : ℕ) : Function.Injective (tsucc h) := fun a b e =>
  Fin.ext (sc_inj h a.val b.val a.isLt b.isLt (congrArg Fin.val e))

/-- the sign of the time translation -/
def tsign (h : ℕ) (t : Fin (2 * h)) : ℂ := eps (sc h t.val)

theorem tsign_mul_self (h : ℕ) (t : Fin (2 * h)) : tsign h t * tsign h t = 1 := eps_mul_self _

theorem tsign_star (h : ℕ) (t : Fin (2 * h)) : star (tsign h t) = tsign h t := star_eps _

section Q

variable {L : Type*} [Fintype L] [DecidableEq L]

/-- the signed time translation on `time × spin × (spin × L)` -/
noncomputable def tQ (h : ℕ) : Matrix (Fin (2 * h) × Fin 2 × (Fin 2 × L)) (Fin (2 * h) × Fin 2 × (Fin 2 × L)) ℂ :=
  Matrix.of fun a b => if b = (tsucc h a.1, a.2) then tsign h a.1 else 0

theorem tQ_conj_apply (h : ℕ) (A : Matrix (Fin (2 * h) × Fin 2 × (Fin 2 × L)) (Fin (2 * h) × Fin 2 × (Fin 2 × L)) ℂ)
    (a b : Fin (2 * h) × Fin 2 × (Fin 2 × L)) :
    (tQ h * A * (tQ h)ᴴ : Matrix (Fin (2 * h) × Fin 2 × (Fin 2 × L)) (Fin (2 * h) × Fin 2 × (Fin 2 × L)) ℂ) a b
      = tsign h a.1 * A (tsucc h a.1, a.2) (tsucc h b.1, b.2) * tsign h b.1 := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (tsucc h b.1, b.2)]
  · rw [Matrix.mul_apply, Finset.sum_eq_single (tsucc h a.1, a.2)]
    · simp only [tQ, Matrix.of_apply, conjTranspose_apply, if_true, tsign_star]
    · intro z _ hz
      simp only [tQ, Matrix.of_apply, if_neg hz, zero_mul]
    · intro hz; exact absurd (Finset.mem_univ _) hz
  · intro z _ hz
    simp only [conjTranspose_apply, tQ, Matrix.of_apply, if_neg hz, star_zero, mul_zero]
  · intro hz; exact absurd (Finset.mem_univ _) hz

theorem tQ_unitary (h : ℕ) : tQ (L := L) h * (tQ h)ᴴ = 1 := by
  ext a b
  have e := tQ_conj_apply h 1 a b
  rw [Matrix.mul_one] at e
  rw [e]
  by_cases hab : a = b
  · subst hab
    rw [Matrix.one_apply_eq, Matrix.one_apply_eq, mul_one, tsign_mul_self]
  · have hne : (tsucc h a.1, a.2) ≠ (tsucc h b.1, b.2) := by
      intro e'
      apply hab
      obtain ⟨e1, e2⟩ := Prod.mk.inj e'
      exact Prod.ext (tsucc_injective h e1) e2
    rw [Matrix.one_apply_ne hne, Matrix.one_apply_ne hab, mul_zero, zero_mul]

/-- **the Wilson operator of the time-translated links is the signed time translation of the operator** -/
theorem std4_tshift_apply (h : ℕ) (m : ℝ) (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hX : ∀ t, t < 2 * h → X' t = X (sc h t))
    (hv : ∀ t, t < 2 * h → v' t = (eps (sc h t) * eps (sc h (sc h t))) • v (sc h t))
    (a b : Fin (2 * h) × Fin 2 × (Fin 2 × L)) :
    std4 h m X' v' a b = tsign h a.1 * std4 h m X v (tsucc h a.1, a.2) (tsucc h b.1, b.2) * tsign h b.1 := by
  obtain ⟨t, s, r, l⟩ := a
  obtain ⟨t', s', r', l'⟩ := b
  have ht := t.isLt
  have ht' := t'.isLt
  have hsc := sc_lt h t.val ht
  have hsc' := sc_lt h t'.val ht'
  unfold std4
  simp only [tsucc, tsign]
  -- the three conditions
  have c1 : (sc h t'.val = sc h t.val) ↔ (t'.val = t.val) :=
    ⟨fun e => sc_inj h _ _ ht' ht e, fun e => by rw [e]⟩
  have c2 : (sc h t'.val = sc h (sc h t.val)) ↔ (t'.val = sc h t.val) :=
    ⟨fun e => sc_inj h _ _ ht' hsc e, fun e => by rw [e]⟩
  have c3 : (sc h t.val = sc h (sc h t'.val)) ↔ (t.val = sc h t'.val) :=
    ⟨fun e => sc_inj h _ _ ht hsc' e, fun e => by rw [e]⟩
  simp only [c1, c2, c3]
  rw [hX t.val ht, hv t.val ht, hv t'.val ht']
  have e1 := eps_mul_self (sc h t.val)
  by_cases h1 : t'.val = t.val
  · by_cases h2 : t'.val = sc h t.val
    · exfalso
      rcases sc_spec h t.val with ⟨a1, a2⟩ | ⟨a1, a2⟩ <;> (rw [a2] at h2; omega)
    · by_cases h3 : t.val = sc h t'.val
      · exfalso
        rw [h1] at h3
        rcases sc_spec h t.val with ⟨a1, a2⟩ | ⟨a1, a2⟩ <;> (rw [a2] at h3; omega)
      · simp only [eq_true h1, eq_false h2, eq_false h3, if_true, if_false, mul_zero, add_zero, sub_zero]
        rw [show eps (sc h t'.val) = eps (sc h t.val) by rw [h1]]
        linear_combination (-(stdSlice m (X (sc h t.val)) (s, r, l) (s', r', l'))) * e1
  · by_cases h2 : t'.val = sc h t.val
    · by_cases h3 : t.val = sc h t'.val
      · simp only [eq_false h1, eq_true h2, eq_true h3, if_true, if_false, Matrix.smul_apply, smul_eq_mul,
          star_mul', star_eps]
        rw [show eps (sc h t'.val) = eps (sc h (sc h t.val)) by rw [h2],
          show eps (sc h t.val) = eps (sc h (sc h t'.val)) by rw [h3]]
        ring
      · simp only [eq_false h1, eq_true h2, eq_false h3, if_true, if_false, Matrix.smul_apply, smul_eq_mul,
          mul_zero, add_zero]
        rw [show eps (sc h t'.val) = eps (sc h (sc h t.val)) by rw [h2]]
        ring
    · by_cases h3 : t.val = sc h t'.val
      · simp only [eq_false h1, eq_false h2, eq_true h3, if_true, if_false, Matrix.smul_apply, smul_eq_mul,
          star_mul', star_eps, mul_zero, zero_add]
        rw [show eps (sc h t.val) = eps (sc h (sc h t'.val)) by rw [h3]]
        ring
      · simp only [eq_false h1, eq_false h2, eq_false h3, if_false, mul_zero, add_zero]
        ring

/-- the determinant is invariant under the time translation of the links -/
theorem det_std4_tshift (h : ℕ) (m : ℝ) (X X' : ℕ → Fin 3 → Matrix L L ℂ) (v v' : ℕ → Matrix L L ℂ)
    (hX : ∀ t, t < 2 * h → X' t = X (sc h t))
    (hv : ∀ t, t < 2 * h → v' t = (eps (sc h t) * eps (sc h (sc h t))) • v (sc h t)) :
    (std4 h m X' v').det = (std4 h m X v).det := by
  have e : std4 h m X' v' = tQ h * std4 h m X v * (tQ h)ᴴ := by
    ext a b
    rw [tQ_conj_apply, std4_tshift_apply h m X X' v v' hX hv]
  rw [e]
  exact det_conj_unitary _ _ (tQ_unitary h)

end Q

end TimeShift


namespace TimeShift

open Matrix MeasureTheory Filter ChainBlockMap BoxWalk FermionSliceBlock WilsonGauge FermionSU2Config BoxFermion GaugeDet BlockShift

section Phys

variable {N : ℕ} [NeZero N]

/-- the time translation of a physical configuration -/
def tshiftPhys {hT : ℕ} (ω : PhysLink N hT → SU2) : PhysLink N hT → SU2 :=
  fun l => ω (tsucc hT l.1, l.2.1, l.2.2)

theorem physSp_tshift {hT : ℕ} (ω : PhysLink N hT → SU2) (t : ℕ) (ht : t < 2 * hT) :
    physSp (tshiftPhys ω) t = physSp ω (sc hT t) := by
  funext x i
  unfold physSp tshiftPhys
  rw [dif_pos ht, dif_pos (sc_lt hT t ht)]
  rfl

theorem physT_tshift {hT : ℕ} (ω : PhysLink N hT → SU2) (t : ℕ) (ht : t < 2 * hT) :
    physT (tshiftPhys ω) t = physT ω (sc hT t) := by
  funext x
  unfold physT tshiftPhys
  rw [dif_pos ht, dif_pos (sc_lt hT t ht)]
  rfl

/-- **the determinant of the Wilson–Dirac operator is invariant under the time translation** -/
theorem physDirac_det_tshift (hT : ℕ) (m : ℝ) (ω : PhysLink N hT → SU2) :
    (physDirac N hT m (tshiftPhys ω)).det = (physDirac N hT m ω).det := by
  unfold physDirac
  refine det_std4_tshift hT m _ _ _ _ (fun t ht => ?_) (fun t ht => ?_)
  · show torusX N (physSp (tshiftPhys ω) t) = torusX N (physSp ω (sc hT t))
    rw [physSp_tshift ω t ht]
  · show eps (sc hT t) • blockDiagonal (physT (tshiftPhys ω) t)
      = (eps (sc hT t) * eps (sc hT (sc hT t))) • (eps (sc hT (sc hT t)) • blockDiagonal (physT ω (sc hT t)))
    rw [physT_tshift ω t ht, smul_smul, mul_assoc, eps_mul_self, mul_one]

theorem sum_range_sc (hT : ℕ) (f : ℕ → ℝ) :
    ∑ t ∈ Finset.range (2 * hT), f (sc hT t) = ∑ t ∈ Finset.range (2 * hT), f t := by
  refine Finset.sum_nbij (sc hT) (fun a ha => ?_) (fun a ha b hb e => ?_) (fun k hk => ?_) (fun a _ => rfl)
  · simp only [Finset.mem_range] at ha ⊢
    exact sc_lt hT a ha
  · exact sc_inj hT a b (by simpa using ha) (by simpa using hb) e
  · simp only [Finset.coe_range, Set.mem_Iio, Finset.mem_range] at hk
    by_cases hk0 : k = 0
    · refine ⟨2 * hT - 1, by simp only [Finset.coe_range, Set.mem_Iio, Finset.mem_range]; omega, ?_⟩
      unfold sc; rw [if_pos (by omega)]; exact hk0.symm
    · refine ⟨k - 1, by simp only [Finset.coe_range, Set.mem_Iio, Finset.mem_range]; omega, ?_⟩
      unfold sc; rw [if_neg (by omega)]; omega

/-- **the Wilson action is invariant under the time translation** -/
theorem wilsonAction_tshift (hT : ℕ) (ω : PhysLink N hT → SU2) :
    wilsonAction N hT (tshiftPhys ω) = wilsonAction N hT ω := by
  unfold wilsonAction
  have e : ∀ t ∈ Finset.range (2 * hT),
      spS N (physSp (tshiftPhys ω) t) + tmS N (physSp (tshiftPhys ω) t) (physSp (tshiftPhys ω) (sc hT t))
          (physT (tshiftPhys ω) t)
        = (fun k => spS N (physSp ω k) + tmS N (physSp ω k) (physSp ω (sc hT k)) (physT ω k)) (sc hT t) := by
    intro t ht
    rw [Finset.mem_range] at ht
    simp only
    rw [physSp_tshift ω t ht, physSp_tshift ω (sc hT t) (sc_lt hT t ht), physT_tshift ω t ht]
  rw [Finset.sum_congr rfl e]
  exact sum_range_sc hT (fun k => spS N (physSp ω k) + tmS N (physSp ω k) (physSp ω (sc hT k)) (physT ω k))

theorem wfWeight_tshift (hT j : ℕ) (m β : ℝ) (ω : PhysLink N hT → SU2) :
    wfWeight N hT j m β (tshiftPhys ω) = wfWeight N hT j m β ω := by
  unfold wfWeight
  rw [wilsonAction_tshift, physDirac_det_tshift]

/-- the time translation as a bijection of the time circle -/
noncomputable def tsuccE (hT : ℕ) : Fin (2 * hT) ≃ Fin (2 * hT) :=
  Equiv.ofBijective (tsucc hT) (tsucc_injective hT).bijective_of_finite

/-- the link map of the time translation -/
noncomputable def linkT (hT : ℕ) : PhysLink N hT ≃ PhysLink N hT :=
  Equiv.prodCongr (tsuccE hT) (Equiv.refl _)

theorem pi_tshift_preserving (hT : ℕ) :
    MeasurePreserving (tshiftPhys (N := N) (hT := hT))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
      (Measure.pi fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) := by
  have := haarTop_isProb SU2
  have h := measurePreserving_arrowCongr' (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2))
    (fun _ : PhysLink N hT => (Measure.haarMeasure ⊤ : Measure SU2)) (linkT hT).symm
    (MeasurableEquiv.refl SU2) (fun _ => MeasurePreserving.id _)
  have e : ⇑(MeasurableEquiv.arrowCongr' (linkT (N := N) hT).symm (MeasurableEquiv.refl SU2))
      = tshiftPhys := by
    funext ω l; rfl
  rw [e] at h
  exact h

/-- **the normalised Wilson–fermion measure is invariant under the time translation** -/
theorem wfProb_tshift (hT : ℕ) (hpos : 0 < hT) (j : ℕ) (m β : ℝ) :
    (wfProb N hT j m β).map tshiftPhys = wfProb N hT j m β := by
  have hT' := pi_tshift_preserving (N := N) hT
  have hf : Measurable fun ω => ((wfWeight N hT j m β ω).toNNReal : ENNReal) :=
    (measurable_wfWeight N hT hpos j m β).real_toNNReal.coe_nnreal_ennreal
  unfold wfProb
  rw [Measure.map_smul]
  congr 1
  unfold wfMeasure
  ext s hs
  rw [Measure.map_apply hT'.measurable hs, withDensity_apply _ (hT'.measurable hs), withDensity_apply _ hs]
  have e : ∀ ω, ((wfWeight N hT j m β ω).toNNReal : ENNReal)
      = ((wfWeight N hT j m β (tshiftPhys ω)).toNNReal : ENNReal) := fun ω => by rw [wfWeight_tshift]
  rw [lintegral_congr fun ω => e ω]
  exact hT'.setLIntegral_comp_preimage hs hf

end Phys

end TimeShift

#print axioms TimeShift.det_std4_tshift
#print axioms TimeShift.physDirac_det_tshift
#print axioms TimeShift.wilsonAction_tshift
#print axioms TimeShift.wfProb_tshift
