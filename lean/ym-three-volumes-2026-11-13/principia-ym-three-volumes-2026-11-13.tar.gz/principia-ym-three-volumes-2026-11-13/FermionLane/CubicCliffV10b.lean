import FermionLane.TransV9d

/-! # Cubic symmetry of the Wilson–Dirac operator, the Clifford level

For hops `H : Fin 4 → Matrix n n ℂ` let `cliffOp m H = 1 ⊗ M(H) + Σ_μ γ_μ ⊗ A_μ(H)` with
`M(H) = (m + 4) − ½ Σ_μ (H_μ + H_μᴴ)` and `A_μ(H) = ½ (H_μ − H_μᴴ)` (the Clifford form `det_std4_eq_clifford` of
the textbook Wilson operator `std4`, `r = 1`).
* **`cliffOp_conj`**: if a unitary `W` carries the hops to a permutation `π` of the hops of `H'`, with the hop
  reversed (`ᴴ`) exactly where `σ` fails, and a spin matrix `S` (right inverse `T`) carries `γ_μ` to
  `± γ_{π μ}` with the same signs, then `(S ⊗ W) cliffOp(H) (T ⊗ Wᴴ) = cliffOp(H')`; hence the determinants agree
  (**`det_cliffOp_perm`**).
* `gamma_sq`, `gamma_anti`: `γ_μ² = 1`, `γ_μ γ_ν = − γ_ν γ_μ` (`μ ≠ ν`), from `gammaAll_clifford`.
* **`rot_spin`**: for `a ≠ b`, `S = 1 + γ_b γ_a`, `T = ½ (1 − γ_b γ_a)`: `S T = 1`, `S γ_a T = γ_b`,
  `S γ_b T = − γ_a`, `S γ_κ T = γ_κ` (the 90° rotation in the plane `(a, b)`, `e_a ↦ e_b ↦ − e_a`).
* **`refl_spin`**: for the axis `k` and the other three directions `a, b, c`, `S = γ_a γ_b γ_c`,
  `T = γ_c γ_b γ_a`: `S T = 1`, `S γ_k T = − γ_k`, `S γ_μ T = γ_μ` (`μ ≠ k`) (the reflection of the axis `k`). -/

namespace CubicSym

open Matrix FermionSliceBlock
open scoped Kronecker

section Clifford

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- the Clifford form `1 ⊗ M(H) + Σ_μ γ_μ ⊗ A_μ(H)` of the Wilson operator with the hops `H μ` -/
noncomputable def cliffOp (m : ℝ) (H : Fin 4 → Matrix n n ℂ) :
    Matrix ((Fin 2 × Fin 2) × n) ((Fin 2 × Fin 2) × n) ℂ :=
  (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) ⊗ₖ
      (((m : ℂ) + 4) • (1 : Matrix n n ℂ) - (1 / 2 : ℂ) • ∑ μ, (H μ + (H μ)ᴴ))
    + ∑ μ, gammaAll μ ⊗ₖ ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ))

theorem det_std4_eq_cliffOp {L : Type*} [Fintype L] [DecidableEq L] (h : ℕ) (m : ℝ)
    (X : ℕ → Fin 3 → Matrix L L ℂ) (v : ℕ → Matrix L L ℂ) :
    (std4 h m X v).det = (cliffOp m (hop4 h X v)).det := by
  rw [det_std4_eq_clifford]
  rfl

/-- **conjugation of the Clifford form by `S ⊗ W`** -/
theorem cliffOp_conj (m : ℝ) (W : Matrix n n ℂ) (hW : W * Wᴴ = 1)
    (S T : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ) (hST : S * T = 1)
    (H H' : Fin 4 → Matrix n n ℂ) (π : Equiv.Perm (Fin 4)) (σ : Fin 4 → Prop) [DecidablePred σ]
    (hH : ∀ μ, W * H μ * Wᴴ = if σ μ then H' (π μ) else (H' (π μ))ᴴ)
    (hγ : ∀ μ, S * gammaAll μ * T = if σ μ then gammaAll (π μ) else -gammaAll (π μ)) :
    (S ⊗ₖ W) * cliffOp m H * (T ⊗ₖ Wᴴ) = cliffOp m H' := by
  have hHs : ∀ μ, W * (H μ)ᴴ * Wᴴ = if σ μ then (H' (π μ))ᴴ else H' (π μ) := by
    intro μ
    have e := congrArg conjTranspose (hH μ)
    rw [conjTranspose_mul, conjTranspose_mul, conjTranspose_conjTranspose, ← Matrix.mul_assoc] at e
    rw [e]
    split_ifs <;> simp
  have hM : W * (((m : ℂ) + 4) • (1 : Matrix n n ℂ) - (1 / 2 : ℂ) • ∑ μ, (H μ + (H μ)ᴴ)) * Wᴴ
      = ((m : ℂ) + 4) • (1 : Matrix n n ℂ) - (1 / 2 : ℂ) • ∑ μ, (H' μ + (H' μ)ᴴ) := by
    rw [Matrix.mul_sub, Matrix.sub_mul, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one, hW,
      Matrix.mul_smul, Matrix.smul_mul, Finset.mul_sum, Finset.sum_mul]
    congr 2
    rw [← Equiv.sum_comp π (fun μ => H' μ + (H' μ)ᴴ)]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Matrix.mul_add, Matrix.add_mul, hH μ, hHs μ]
    split_ifs
    · rfl
    · rw [add_comm]
  have hA : ∀ μ, (S * gammaAll μ * T) ⊗ₖ (W * ((1 / 2 : ℂ) • (H μ - (H μ)ᴴ)) * Wᴴ)
      = gammaAll (π μ) ⊗ₖ ((1 / 2 : ℂ) • (H' (π μ) - (H' (π μ))ᴴ)) := by
    intro μ
    rw [Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_sub, Matrix.sub_mul, hH μ, hHs μ, hγ μ]
    split_ifs
    · rfl
    · ext a b
      simp only [kroneckerMap_apply, Matrix.neg_apply, Matrix.smul_apply, Matrix.sub_apply, smul_eq_mul]
      ring
  unfold cliffOp
  rw [Matrix.mul_add, Matrix.add_mul, Finset.mul_sum, Finset.sum_mul]
  rw [← mul_kronecker_mul, ← mul_kronecker_mul, Matrix.mul_one, hST, hM]
  congr 1
  rw [← Equiv.sum_comp π (fun μ => gammaAll μ ⊗ₖ ((1 / 2 : ℂ) • (H' μ - (H' μ)ᴴ)))]
  refine Finset.sum_congr rfl fun μ _ => ?_
  rw [← mul_kronecker_mul, ← mul_kronecker_mul, hA μ]

/-- **the determinant of the Clifford form is invariant under a signed permutation of the hops, when a spin
factor with the same signed permutation of the Dirac matrices exists** -/
theorem det_cliffOp_perm (m : ℝ) (W : Matrix n n ℂ) (hW : W * Wᴴ = 1)
    (H H' : Fin 4 → Matrix n n ℂ) (π : Equiv.Perm (Fin 4)) (σ : Fin 4 → Prop) [DecidablePred σ]
    (hH : ∀ μ, W * H μ * Wᴴ = if σ μ then H' (π μ) else (H' (π μ))ᴴ)
    (hspin : ∃ S T : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ, S * T = 1 ∧
      ∀ μ, S * gammaAll μ * T = if σ μ then gammaAll (π μ) else -gammaAll (π μ)) :
    (cliffOp m H').det = (cliffOp m H).det := by
  obtain ⟨S, T, hST, hγ⟩ := hspin
  rw [← cliffOp_conj m W hW S T hST H H' π σ hH hγ, det_mul, det_mul]
  have h1 : (S ⊗ₖ W) * (T ⊗ₖ Wᴴ) = 1 := by
    rw [← mul_kronecker_mul, hST, hW, one_kronecker_one]
  have h2 := congrArg det h1
  rw [det_mul, det_one] at h2
  calc (S ⊗ₖ W).det * (cliffOp m H).det * (T ⊗ₖ Wᴴ).det
      = (S ⊗ₖ W).det * (T ⊗ₖ Wᴴ).det * (cliffOp m H).det := by ring
    _ = (cliffOp m H).det := by rw [h2, one_mul]

end Clifford

section Spin

local notation "γ" => gammaAll

theorem gamma_sq (μ : Fin 4) : γ μ * γ μ = 1 := by
  have h := gammaAll_clifford μ μ
  rw [if_pos rfl, ← two_smul ℂ (γ μ * γ μ)] at h
  exact smul_right_injective _ (two_ne_zero : (2 : ℂ) ≠ 0) h

theorem gamma_anti {μ ν : Fin 4} (h : μ ≠ ν) : γ μ * γ ν = -(γ ν * γ μ) := by
  have e := gammaAll_clifford μ ν
  rw [if_neg h] at e
  exact eq_neg_of_add_eq_zero_left e

theorem semiconj_anti {μ ν : Fin 4} (h : ν ≠ μ) : SemiconjBy (γ ν) (γ μ) (-γ μ) := by
  unfold SemiconjBy
  rw [gamma_anti h, neg_mul]

theorem semiconj_anti' {μ ν : Fin 4} (h : ν ≠ μ) : SemiconjBy (γ ν) (-γ μ) (γ μ) := by
  have := (semiconj_anti h).neg_right
  rwa [neg_neg] at this

theorem semiconj_self (μ : Fin 4) : SemiconjBy (γ μ) (γ μ) (γ μ) := Commute.refl _

theorem conj_of_semiconj {S T x y : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ} (h : SemiconjBy S x y)
    (hST : S * T = 1) : S * x * T = y := by
  rw [h.eq, Matrix.mul_assoc, hST, Matrix.mul_one]

/-- **the spin factor of the 90° rotation in the plane `(a, b)`** -/
theorem rot_spin (a b : Fin 4) (hab : a ≠ b) :
    (1 + γ b * γ a) * ((1 / 2 : ℂ) • (1 - γ b * γ a)) = 1 ∧
    ∀ μ, (1 + γ b * γ a) * γ μ * ((1 / 2 : ℂ) • (1 - γ b * γ a))
      = if μ ≠ b then γ (Equiv.swap a b μ) else -γ (Equiv.swap a b μ) := by
  have hB : (γ b * γ a) * (γ b * γ a) = -1 := by
    calc (γ b * γ a) * (γ b * γ a) = γ b * (γ a * γ b) * γ a := by noncomm_ring
      _ = -((γ b * γ b) * (γ a * γ a)) := by rw [gamma_anti hab]; noncomm_ring
      _ = -1 := by rw [gamma_sq, gamma_sq, one_mul]
  have hST : (1 + γ b * γ a) * ((1 / 2 : ℂ) • (1 - γ b * γ a)) = 1 := by
    rw [Matrix.mul_smul]
    have e : (1 + γ b * γ a) * (1 - γ b * γ a) = 1 - (γ b * γ a) * (γ b * γ a) := by noncomm_ring
    rw [e, hB, sub_neg_eq_add, ← two_smul ℂ (1 : Matrix (Fin 2 × Fin 2) (Fin 2 × Fin 2) ℂ), smul_smul]
    norm_num
  refine ⟨hST, fun μ => ?_⟩
  by_cases hμa : μ = a
  · rw [hμa, if_pos hab, Equiv.swap_apply_left]
    refine conj_of_semiconj ?_ hST
    unfold SemiconjBy
    have e1 : (1 + γ b * γ a) * γ a = γ a + γ b * (γ a * γ a) := by noncomm_ring
    have e2 : γ b * (1 + γ b * γ a) = γ b + (γ b * γ b) * γ a := by noncomm_ring
    rw [e1, e2, gamma_sq, gamma_sq, mul_one, one_mul, add_comm]
  by_cases hμb : μ = b
  · rw [hμb, if_neg (not_not.mpr rfl), Equiv.swap_apply_right]
    refine conj_of_semiconj ?_ hST
    unfold SemiconjBy
    have e1 : (1 + γ b * γ a) * γ b = γ b - γ a := by
      calc (1 + γ b * γ a) * γ b = γ b + γ b * (γ a * γ b) := by noncomm_ring
        _ = γ b - (γ b * γ b) * γ a := by rw [gamma_anti hab]; noncomm_ring
        _ = γ b - γ a := by rw [gamma_sq, one_mul]
    have e2 : -γ a * (1 + γ b * γ a) = -γ a + γ b := by
      calc -γ a * (1 + γ b * γ a) = -γ a - (γ a * γ b) * γ a := by noncomm_ring
        _ = -γ a + γ b * (γ a * γ a) := by rw [gamma_anti hab]; noncomm_ring
        _ = -γ a + γ b := by rw [gamma_sq, mul_one]
    rw [e1, e2]
    abel
  · rw [if_pos hμb, Equiv.swap_apply_of_ne_of_ne hμa hμb]
    refine conj_of_semiconj ?_ hST
    unfold SemiconjBy
    calc (1 + γ b * γ a) * γ μ = γ μ + γ b * (γ a * γ μ) := by noncomm_ring
      _ = γ μ - (γ b * γ μ) * γ a := by rw [gamma_anti (Ne.symm hμa)]; noncomm_ring
      _ = γ μ + γ μ * (γ b * γ a) := by rw [gamma_anti (Ne.symm hμb)]; noncomm_ring
      _ = γ μ * (1 + γ b * γ a) := by noncomm_ring

/-- **the spin factor of the reflection of the axis `k`** (`a, b, c` the other three directions) -/
theorem refl_spin (a b c k : Fin 4) (hab : a ≠ b) (hac : a ≠ c) (hbc : b ≠ c) (hka : k ≠ a) (hkb : k ≠ b)
    (hkc : k ≠ c) :
    (γ a * γ b * γ c) * (γ c * γ b * γ a) = 1 ∧
    ∀ μ, (γ a * γ b * γ c) * γ μ * (γ c * γ b * γ a)
      = if μ ≠ k then γ ((Equiv.refl (Fin 4)) μ) else -γ ((Equiv.refl (Fin 4)) μ) := by
  have hST : (γ a * γ b * γ c) * (γ c * γ b * γ a) = 1 := by
    calc (γ a * γ b * γ c) * (γ c * γ b * γ a) = γ a * (γ b * (γ c * γ c) * γ b) * γ a := by noncomm_ring
      _ = 1 := by rw [gamma_sq, Matrix.mul_one, gamma_sq, Matrix.mul_one, gamma_sq]
  refine ⟨hST, fun μ => ?_⟩
  simp only [Equiv.refl_apply]
  have hμ : μ = k ∨ μ = a ∨ μ = b ∨ μ = c := by
    simp only [Fin.ext_iff, ne_eq] at *
    have := μ.isLt; have := k.isLt; have := a.isLt; have := b.isLt; have := c.isLt
    omega
  rcases hμ with h | h | h | h <;> rw [h]
  · rw [if_neg (not_not.mpr rfl)]
    refine conj_of_semiconj ?_ hST
    exact ((semiconj_anti hka.symm).mul_left (semiconj_anti' hkb.symm)).mul_left (semiconj_anti hkc.symm)
  · rw [if_pos hka.symm]
    refine conj_of_semiconj ?_ hST
    exact ((semiconj_self _).mul_left (semiconj_anti' hab.symm)).mul_left (semiconj_anti hac.symm)
  · rw [if_pos hkb.symm]
    refine conj_of_semiconj ?_ hST
    exact ((semiconj_anti' hab).mul_left (semiconj_self _).neg_right).mul_left (semiconj_anti hbc.symm)
  · rw [if_pos hkc.symm]
    refine conj_of_semiconj ?_ hST
    have h1 : SemiconjBy (γ a * γ b) (γ c) (γ c) := (semiconj_anti' hac).mul_left (semiconj_anti hbc)
    exact h1.mul_left (semiconj_self c)

end Spin

end CubicSym

#print axioms CubicSym.det_std4_eq_cliffOp
#print axioms CubicSym.cliffOp_conj
#print axioms CubicSym.det_cliffOp_perm
#print axioms CubicSym.rot_spin
#print axioms CubicSym.refl_spin
