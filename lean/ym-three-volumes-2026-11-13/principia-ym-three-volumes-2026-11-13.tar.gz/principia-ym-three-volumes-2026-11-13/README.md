# 三巻の版の束（principia-ym-three-volumes-2026-11-13）

ヤン–ミルズの教科書「ヤン–ミルズと質量ギャップ」（三巻、2026-11-13 の版）が、本書の検討の Lean の定理・定義として名を挙げる宣言と、それらが import で依る全てのファイルを、一つの lake の package にまとめた束です。同じ日の先の束 `principia-ym-premise-first-2026-11-13`（317 モジュール）に、三巻の版で章が挙げるようになった宣言のための 83 モジュールを足したものです。

- Lean 4 `v4.33.1`・Mathlib タグ `v4.33.1`（`lake-manifest.json` がその commit `0df444a3…` を固定）
- パッケージ `ympremisefirst`・ライブラリ `YMPremiseFirst`（名は先の束と同じ）。400 モジュール・115,217 行。最上位の名前は `Area`・`Band`・`Block3`・`Blocks`・`Box`・`BoxWalk`・`Bridge`・`Chain`・`Covering`・`Factor`・`Fermion`・`FermionLane`・`Five`・`FoldChess`・`FreeOS`・`Gauge`・`Infvol`・`Kernel`・`Lam`・`Lattice`・`Lift`・`Linz`・`Peierls`・`Plane`・`PolyT`・`Push`・`PushRare`・`RealSpace`・`SkewOrbit`・`Spec`・`Sweep`・`T1`・`T10`・`Tilt`・`Tuned`・`Tuning`・`UVChain`・`Uniform`・`VortexCert`・`Wilson`
- 章が挙げる宣言 677（うち定理 455）。うち先の束に在ったもの 564（定理 355）、この版で足したもの 113（定理 100）。一覧は `DECLS.tsv`（章・章での書き方・種別・完全な名・モジュール・行。章の番号は三巻の版の番号）
- `sorry`・`admit`・`native_decide`・`polyrith`・`axiom` 宣言・`debug.` の設定：0（字句の検索による）

## 先の束との違い

- 足したモジュール 83 本：`Area`（24）・`Block3`（24）・`PushRare`（10）・`Tuned`（13）・`Tuning`（12）。どれも先の束の 317 本と最上位の名が重ならず、先の束のファイルを一字も変えていません（317 本の sha256 は先の束の `MODULES.tsv` と同じ）。
- 足した宣言の中身：強結合の Wilson ループの面積則（有限体積・無限体積）と渦の自由エネルギーの上界（`AreaLaw`・`VortexStrong`・`VortexStrongMN`）、渦の比の連続・極限・合わせと捩れた箱の欠けの下界（`ThetaTuning`・`ThetaLimit`・`TwistFlat`・`TwistFloor`・`FlatStokes`・`QuadFloor`）、辺 3・中心に置いたブロック写像の対称と押し出した測度の鏡映正値性・合わせた列の存在（`Block3`）、辺 2 の写像の合わせの部品と粗い並進（`TunedCoupling`）。
- `Tuning` の渦の比の鎖は、docstring だけを整えた版（モジュール名の末尾 `V2`）を収めています。末尾 `V1` の版とは注釈を除いた字の列が同じで（import の行の版の印だけが違う）、同じ名を持つので一緒には入れていません。`Area.InfVolV2` も同様に一つ前の版の代わりです。
- `DECLS.tsv` は三巻の版の章の番号で作り直しました。先の束の表が名前空間を略した一字の名（`N`・`s` など、変数の名）に当てていた 10 の宣言は、この版の表から外しました。
- `checks/AxNew_01.lean`・`AxNew_02.lean` を足しました（この版で足した宣言 113 の `#check` と `#print axioms`）。`axioms.txt` は先の束の行（`checks/AxAll_*.lean` の 569 行）に、この 113 行を足したものです。

## 検査の仕方

```bash
lake exe cache get
LEAN_NUM_THREADS=1 lake build
for f in checks/AxAll_*.lean checks/AxNew_*.lean; do lake env lean "$f"; done   # #check と #print axioms
```

一本ずつ確かめるときは、依存の順（`MODULES.tsv` の import の欄）に `lake env lean -o <.olean> <ファイル>` で書き出しても同じです。一つのファイルの検査に要る記憶は多くて 12 GB ほどです（`MODULES.tsv` の `previous_max_rss_kB` は以前の検査の記録で、参考の値）。`Chain.BoxWilsonV2`・`FreeOS.QposUpV1`・`Lam.Up1`・`T1.Cell1.C10`・`T1.Cell1.C12`・`T1.Side1.ACell01`・`T1.Side1.ACell02`・`T1.Side1.ACell05`・`T10.Alias1`・`VortexCert.CertN2V1`・`VortexCert.CertN3V1`・`VortexCert.CertN4V1` は 8 GB を超えた記録があります。この版で足した 83 本は、どれも 7 GB 以下でした。

`checks/AxAll_*.lean`（6 本）と `checks/AxNew_*.lean`（2 本）は、章が挙げる宣言ごとに `#check` と `#print axioms` を並べたものです。同じ名の宣言を持つ写しのモジュールが幾つかあり（同時には import できない）、それらが同じファイルに入らないように分けています。

### 同時に import できないモジュールの組

次の 10 組は、同じ内容の宣言を同じ名で独立に持ちます。一つのファイルで同時に import すると宣言が二重になり通りません（束の中のどのモジュールも、組の両方を import してはいません）。この版で足したモジュールは新しい組を作っていません。

| モジュール | 同じ名の宣言の数 |
|---|---|
| `Chain.BoxWilsonV2`・`UVChain.BoxChainV1` | 522 |
| `FreeOS.QposUpV1`・`T1.Split1`・`T10.Alias1` | 345 |
| `FreeOS.QposUpV1`・`Lam.Up1` | 153 |
| `BoxWalk.BoxL1`・`Chain.BoxWilsonV2`・`UVChain.BoxChainV1` | 107 |
| `Chain.BoxWilsonV2`・`Lattice.TorusDecV2` | 99 |
| `FreeOS.QposUpV1`・`Lam.Up1`・`T10.Alias1` | 95 |
| `SkewOrbit.LimitV1`・`SkewOrbit.Probe` | 17 |
| `T1.Split1`・`T10.Alias1` | 13 |
| `Chain.BoxWilsonV2`・`Lattice.WilsonGapV2` | 12 |
| `BoxWalk.BoxL1`・`Chain.BoxWilsonV2` | 1 |

### 依存の順に一本ずつ確かめる

`MODULES.tsv` の import の欄の順（依存の先が先）に、一本ずつ `lake env lean -o <書き出し先>/<モジュールの道>.olean <ファイル>` で書き出し、書き出し先を `LEAN_PATH` に足して次へ進みます。`lake build` で建てる場合も、上の組があるので、全てを import する一つのファイル（ライブラリ全体をまとめる入口）は作らないでください。`lakefile.lean` の `globs`（最上位の名ごとの `.submodules`）の形は、この束を作った計算機では `lake build` で建てて確かめていません（一本ずつの書き出しと、核の再検査〔leanchecker〕で確かめています）。

### モジュール名の末尾

モジュール名の末尾の `V1`・`V2`・`V10c` などは版の印です（同じ主題のファイルの何版目か）。数学の内容を表す名ではありません。

## 検査の記録の読み方

- `axioms.txt`：宣言ごとに一行、`名<TAB>[公理の一覧]`。**全ての行が `propext`・`Classical.choice`・`Quot.sound` の部分集合**であることを見ます。`sorryAx`・`Lean.ofReduceBool` が出たら、その宣言は閉じていません。
- `MODULES.tsv`：モジュールごとの sha256・Mathlib の外の import・行数。最後の欄 `added_in_this_edition` が `yes` の行がこの版で足したモジュールです。
- `DECLS.tsv`：章の名と、Lean の完全な名・モジュールの対応。章が名前空間を略して書いた名（構造体の欄など）は、束の中で一つに決まるものを当てています。二つの名前空間に同じ短い名が在るとき（`card_bad_ge`・`minBad_conn`）は両方を書いています。

注釈と docstring は、作業の記録への参照（記録の名・節の番号・作業の場所）を取り除いて整えました。注釈を全て取り除いた字の列は、検査に使った元のファイルと一字も違いません（ファイルごとに機械で照合）。

## 章と宣言とモジュールの対応

| 章 | モジュール | 宣言（定理・定義・構造体） |
|---|---|---|
| 9-01 | `Block3.LocalKV1` | `Block3.down_local` |
| 9-01 | `Block3.DownReflV1` | `Block3.down_refl` |
| 9-01 | `Block3.RPFinalV1` | `Block3.rp_push` |
| 9-01 | `Block3.RPProbV1` | `Block3.rp_push_prob` |
| 9-02 | `Block3.BoxV1` | `Block3.paths`・`Block3.wts` |
| 9-02 | `Block3.RPFinalV1` | `Block3.rp_push` |
| 9-05 | `Block3.SignV1` | `Block3.blockMap_flip` |
| 9-05 | `Block3.BoxReflV1` | `Block3.blockMap_refl_cfg` |
| 9-05 | `Block3.TransV1` | `Block3.blockMap_trans` |
| 9-05 | `Block3.DownReflV1` | `Block3.down_refl` |
| 9-05 | `Block3.ReflBAllV1` | `Block3.down_reflB` |
| 9-05 | `Block3.Trans3V1` | `Block3.down_trans` |
| 9-05 | `Tuned.HsymV1` | `TunedCoupling.hsym_translation` |
| 10-01 | `Block3.Tune3V1` | `Block3.tuned3_exists` |
| 10-01 | `Tuning.ThetaLimitV2` | `ThetaLimit.tuning_all` |
| 10-01 | `Tuned.TuneV1` | `TunedCoupling.continuous_Yc`・`TunedCoupling.exists_tuning` |
| 10-03 | `Block3.Tune3V1` | `Block3.tuned3_exists` |
| 10-03 | `Tuning.ThetaLimitV2` | `ThetaLimit.tuning_all` |
| 10-04 | `Block3.Tune3V1` | `Block3.Y3_zero`・`Block3.tendsto_Y3_one`・`Block3.tuned3_exists` |
| 10-04 | `Tuning.ThetaLimitV2` | `ThetaLimit.tuning_all` |
| 12-01 | `Block3.RPFinalV1` | `Block3.rp_push` |
| 12-01 | `Block3.RPProbV1` | `Block3.rp_push_prob` |
| 12-01 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| 12-01 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_rp_dir` |
| 12-01 | `Lattice.TorusDecV2` | `TorusRP.wilson_rp` |
| 12-02 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 12-02 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| 12-03 | `UVChain.BoxChainV1` | `BoxWalk.chain_end_to_end_box` |
| 12-03 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 12-04 | `Infvol.FullTV2` | `FullT.full_rp_torus`・`FullT.wilson_Tpos_full` |
| 12-05 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| 12-05 | `UVChain.BoxChainV1` | `BoxWalk.chain_end_to_end_box`・`ChainBlockMap.chain_end_to_end_blockMap` |
| 12-05 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 12-05 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 12-06 | `Block3.ReflBAllV1` | `Block3.down_reflB` |
| 12-06 | `Block3.Trans3V1` | `Block3.down_trans` |
| 12-06 | `Infvol.TransV2` | `TransI.wilson_infvol_translation` |
| 12-07 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 12-07 | `Lattice.ClusterV1` | `WilsonLimit.cluster_limit` |
| 12-08 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 14-01 | `Block3.Tune3V1` | `Block3.tuned3_exists` |
| 14-01 | `UVChain.BoxChainV1` | `BoxWalk.chain_end_to_end_box` |
| 14-01 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 14-01 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| 14-01 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 14-01 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 14-01 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| 14-01 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_rp_dir` |
| 14-01 | `Tuning.ThetaLimitV2` | `ThetaLimit.tuning_all` |
| 14-01 | `Lattice.TorusDecV2` | `TorusRP.wilson_rp` |
| 14-02 | `Block3.Tune3V1` | `Block3.Y3_zero`・`Block3.tendsto_Y3_one`・`Block3.tuned3_exists` |
| 14-02 | `Block3.SignV1` | `Block3.blockMap_flip` |
| 14-02 | `Block3.BoxReflV1` | `Block3.blockMap_refl_cfg` |
| 14-02 | `Block3.FlipAllV1` | `Block3.down_flipSet` |
| 14-02 | `Block3.LocalKV1` | `Block3.down_local` |
| 14-02 | `Block3.DownReflV1` | `Block3.down_refl` |
| 14-02 | `Block3.BoxV1` | `Block3.paths`・`Block3.wts` |
| 14-02 | `Block3.RPFinalV1` | `Block3.rp_push` |
| 14-02 | `Block3.RPProbV1` | `Block3.rp_push_prob` |
| 14-02 | `Chain.BoxWilsonV2` | `BoxWalk.wilson_hΘp` |
| 14-02 | `Lattice.TorusDecV2` | `TorusRP.wilson_rp` |
| 14-03 | `Block3.Tune3V1` | `Block3.Y3_zero`・`Block3.tendsto_Y3_one`・`Block3.tuned3_exists` |
| 14-03 | `T1.Split1` | `NearAliasB.low` |
| 14-03 | `Tuning.ThetaLimitV2` | `ThetaLimit.tendsto_theta_one`・`ThetaLimit.tuning_all` |
| 14-03 | `Tuning.ThetaContV1` | `ThetaTuning.thetaM_continuous`・`ThetaTuning.thetaM_zero` |
| 14-04 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 14-05 | `SkewOrbit.LimitV1` | `SkewOrbit.limit_independent` |
| 14-06 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| 14-06 | `Area.InfVolV2` | `AreaLaw.area_law_infvol` |
| 14-06 | `Area.InfVolSubV1` | `AreaLaw.area_law_limit_sub` |
| 14-06 | `Area.AreaMainV1` | `AreaLaw.area_law_wilson`・`AreaLaw.area_law_wilson_area` |
| 14-06 | `Area.RectMoveV1` | `AreaLaw.area_law_wilson_general` |
| 14-06 | `Area.ExponentMaxV1` | `AreaLaw.area_law_wilson_max_sharp` |
| 14-06 | `Area.SharpConstV1` | `AreaLaw.area_law_wilson_sharp`・`VortexStrong.vortex_floor_sharp` |
| 14-06 | `Block3.RPFinalV1` | `Block3.rp_push` |
| 14-06 | `Block3.Tune3V1` | `Block3.tuned3_exists` |
| 14-06 | `UVChain.BoxChainV1` | `ChainBlockMap.hcons_blockMap` |
| 14-06 | `FermionLane.LatticeSymV10a` | `CubicSym.wfProb_lattice_generators` |
| 14-06 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 14-06 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| 14-06 | `Lattice.GaugeSectorV1` | `GaugeZ.wilson_massGap_gauge_exists` |
| 14-06 | `Blocks.ThickFloorThetaPosV1` | `HalfSplit.Z1_le_Z0`・`TwistBlocks.theta_nonneg` |
| 14-06 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.polyakov_pair_theta` |
| 14-06 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 14-06 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 14-06 | `PolyT.MainV1` | `PolyakovT.polyakov_pair_all` |
| 14-06 | `Tuning.ThetaLimitV2` | `ThetaLimit.tendsto_theta_one`・`ThetaLimit.tuning_all` |
| 14-06 | `Tuning.ThetaContV1` | `ThetaTuning.thetaM_continuous` |
| 14-06 | `Infvol.TransV2` | `TransI.wilson_infvol_translation` |
| 14-06 | `Blocks.VacuumV1` | `TwistBlocks.SN_bounds` |
| 14-06 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.thick_vortex_floor` |
| 14-06 | `Tuning.NoFlatTwistV2` | `TwistFlat.no_flat_twist11` |
| 14-06 | `Tuning.DefectTwoV1` | `TwistFloor.defect11_sym_half` |
| 14-06 | `Wilson.SU2TwistV2` | `TwistedWilson.twisted_vortex_bound` |
| 14-06 | `VortexCert.CertN4V1` | `VortexCert.SN_four_lt` |
| 14-06 | `VortexCert.CertN3V1` | `VortexCert.SN_three_lt` |
| 14-06 | `VortexCert.CertN2V1` | `VortexCert.SN_two_lt` |
| 14-06 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos` |
| 14-06 | `Area.VortexStrongV1` | `VortexStrong.vortex_floor` |
| 14-06 | `Area.VortexMNSharpV1` | `VortexStrongMN.vortex_floor_MN_sharp` |
| 14-06 | `Gauge.WilsonFullV7c` | `WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.site_reflection_positive_wilson_full` |
| 14-06 | `Lattice.ClusterV1` | `WilsonLimit.cluster_limit` |
| 14-06 | `Lattice.WilsonDobV1` | `WilsonLimit.wilson_massGap_dob_exists` |
| 14-06 | `Lattice.NondegV3` | `WilsonLimit.wilson_massGap_nondegenerate` |
| 15-12 | `T10.Alias1` | `AliasLiftSize.hlift_holds`・`AliasPoinc.coupling_converges_gamma_closed`・`AliasPoinc.hH_holds` |
| 15-12 | `Lam.Up1` | `CouplingLimit.D_lower`・`CouplingLimit.D_upper`・`FreeStageOS.E_lt_four`・`FreeStageOS.E_lt_four_s`・`FreeStageOS.eq_lt_four`・`OSUpBridge.os_up`・`OSUpQpos.EE_bbflip`・`OSUpQpos.Gs_le_G0`・`OSUpQpos.hEE_all`・`OSUpQpos.os_up_Qpos`・`OneStepBridge.Mfam_P_le_row`・`TauSplit.iterate_split`・`TauSplit.omF_chain_le` |
| 15-12 | `T1.Final2` | `HsSplit.hS_split`・`HsSplit.lower_side_c`・`NearAliasB.bracket_Qpos_split` |
| 15-12 | `Push.Lat2` | `LatticeFace.faceCov_eq_posC` |
| 15-12 | `Push.Rec1` | `LatticePath.pathSym_closed`・`LatticeRec.lattice_bracket`・`LatticeRec.projFam_X0`・`LatticeRec.rec_iterate`・`LatticeTorus.torus_step` |
| 15-12 | `Push.Lat1` | `LatticePush.freeCov_phase`・`LatticePush.projFam_stage`・`LatticePush.push_phase`・`LatticePush.stageCov_phase` |
| 15-12 | `T1.Split1` | `NearAliasB.chain_lower`・`NearAliasB.lower_side_split`・`NearAliasB.near_lower` |
| 15-12 | `FreeOS.QposUpV1` | `OneStepBridge.Mfam`・`OneStepBridge.Mfam_P_le`・`OneStepFinal.Qpos`・`OneStepFinal.rqPos`・`OneStepLower.bracket_Qpos_free`・`OneStepLower.lower_side` |
| 15-12 | `T1.T1hArith1` | `StageArith.tauM` |
| 15-12 | `Lam.Torus1` | `TorusLam.stage_tau_17` |
| 15-13 | `Lift.RetractOne1` | `BlockLinearKernel.blockMap_exp_linear_le_one`・`BlockLinearKernel.blockMap_exp_linear_r1` |
| 15-13 | `BoxWalk.BoxL1` | `BoxWalk.boxMap_gauge`・`BoxWalk.boxMap_local` |
| 15-13 | `UVChain.BoxChainV1` | `ChainBlockMap.blockMap` |
| 15-13 | `Lam.Face1` | `FaceTorus.sum_rt_quarter`・`FaceTorus.torus_face_diag`・`FaceTorus.torus_face_upper` |
| 15-13 | `Push.Lat2` | `LatticeFace.faceCov_eq_posC`・`LatticeFace.key_proj` |
| 15-13 | `Push.Join7` | `LatticeFace.lattice_face_T1h` |
| 15-13 | `Push.Lat1` | `LatticePush.freeCov_phase`・`LatticePush.projFam_stage`・`LatticePush.push_phase`・`LatticePush.stageCov_phase` |
| 15-13 | `Push.Rec1` | `LatticeTorus.torus_step` |
| 15-13 | `Lift.PushCov1` | `PushCov.blockLin`・`PushCov.covOp_map`・`PushCov.lattice_pushCov` |
| 15-14 | `T10.Alias1` | `AliasLiftSize.hlift_holds`・`AliasPoinc.coupling_converges_gamma_closed`・`AliasPoinc.hH_holds` |
| 15-14 | `Lift.RetractOne1` | `BlockLinearKernel.blockMap_exp_linear_le_one` |
| 15-14 | `BoxWalk.BoxL1` | `BoxWalk.boxMap_gauge`・`BoxWalk.boxMap_local` |
| 15-14 | `Lam.Up1` | `CouplingLimit.D_lower`・`CouplingLimit.D_upper`・`FreeStageOS.E_lt_four`・`FreeStageOS.E_lt_four_s`・`FreeStageOS.eq_lt_four`・`OSUpQpos.EE_bbflip`・`OSUpQpos.Gs_le_G0`・`OSUpQpos.os_up_Qpos`・`OneStepBridge.Mfam_P_le_row` |
| 15-14 | `FoldChess.CapV1` | `FoldCap.ballQ_ge` |
| 15-14 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 15-14 | `FoldChess.RarityEvenV1` | `FoldEntropy.Zw_ge` |
| 15-14 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| 15-14 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| 15-14 | `T1.Final2` | `HsSplit.hS_split`・`HsSplit.lower_side_c`・`NearAliasB.bracket_Qpos_split` |
| 15-14 | `Push.Lat2` | `LatticeFace.faceCov_eq_posC` |
| 15-14 | `Push.Join7` | `LatticeFace.lattice_face_T1h` |
| 15-14 | `Push.Rec1` | `LatticePath.pathSym_closed`・`LatticeRec.lattice_bracket`・`LatticeRec.rec_iterate`・`LatticeTorus.torus_step` |
| 15-14 | `Push.Lat1` | `LatticePush.freeCov_phase`・`LatticePush.projFam_stage`・`LatticePush.push_phase`・`LatticePush.stageCov_phase` |
| 15-14 | `T1.Split1` | `NearAliasB.chain_lower`・`NearAliasB.near_lower` |
| 15-14 | `FreeOS.QposUpV1` | `OneStepLower.bracket_Qpos_free` |
| 15-14 | `Lift.PushCov1` | `PushCov.lattice_pushCov` |
| 15-14 | `Lam.Torus1` | `TorusLam.stage_tau_17` |
| 16-03 | `Band.Reduction` | `BandReduction.scale` |
| 16-11 | `Area.InfVolV2` | `AreaLaw.area_law_infvol` |
| 16-11 | `Area.AreaMainV1` | `AreaLaw.area_law_wilson` |
| 16-11 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 16-11 | `VortexCert.CertN2V1` | `VortexCert.SN_two_lt` |
| 16-11 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos` |
| 19-01 | `UVChain.BoxChainV1` | `BoxWalk.BoxLk`・`BoxWalk.Site`・`ChainBlockMap.Ball`・`ChainBlockMap.Cfg`・`ChainBlockMap.νP` |
| 19-01 | `Fermion.SliceWilsonV6d` | `FermionSU2Config.PhysLink`・`FermionSU2Config.SU2` |
| 19-01 | `Lattice.GaugeFixV5` | `GaugeFix.act` |
| 19-01 | `Push.Rec1` | `LatticePath.Link` |
| 19-01 | `Lattice.TorusDecV2` | `OSGap.haarProb`・`OSGap.haarProb_isMulLeftInvariant`・`OSGap.haarProb_isProbabilityMeasure`・`TorusRP.Lk`・`TorusRP.QBall`・`TorusRP.action`・`TorusRP.haarBall`・`TorusRP.hol`・`TorusRP.wilsonMeasure` |
| 19-01 | `Lattice.WilsonGapV2` | `TorusRP.wilsonMeasure_univ`・`TorusRP.wilsonMeasure_univ_lt_top`・`TorusRP.wilsonMeasure_univ_pos`・`TorusRP.wilsonProb`・`TorusRP.wilsonWeight_ge`・`TorusRP.wilsonWeight_le` |
| 19-01 | `Wilson.SU2TwistV2` | `TwistedWilson.Link`・`TwistedWilson.Plaq`・`TwistedWilson.SU2`・`TwistedWilson.ZW`・`TwistedWilson.ZW_pos`・`TwistedWilson.haarCfg`・`TwistedWilson.haarProb`・`TwistedWilson.pull`・`TwistedWilson.zt` |
| 19-01 | `Bridge.WilsonTwistV1` | `WilsonBridge.integral_wilsonMeasure`・`WilsonBridge.toBall`・`WilsonBridge.toBall_injective`・`WilsonBridge.wilsonMeasure_eq_map`・`WilsonBridge.wilsonMeasure_univ` |
| 19-01 | `Bridge.TimeAlignV1` | `WilsonBridgeT.action_toBallT`・`WilsonBridgeT.refl_toBallT`・`WilsonBridgeT.wilsonMeasure_eq_mapT` |
| 19-01 | `Bridge.VortexV1` | `WilsonBridgeV.vortex_ratio_eq` |
| 19-01 | `Box.FermionBaseV8a` | `WilsonGauge.action_add_wilsonAction`・`WilsonGauge.gaugeMeasure`・`WilsonGauge.map_pull`・`WilsonGauge.refl_pull`・`WilsonGauge.wilsonMeasure_eq_map` |
| 19-01 | `Gauge.WilsonFullV7c` | `WilsonGauge.wilsonAction` |
| 19-02 | `UVChain.BoxChainV1` | `BoxWalk.Site` |
| 19-02 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.polyLoop` |
| 19-02 | `Blocks.ThickFloorHalfSplitV1` | `HalfSplit.wE` |
| 19-02 | `Push.Rec1` | `LatticePath.Link` |
| 19-02 | `PolyT.TransV3` | `PolyakovT.corr`・`PolyakovT.wE_one` |
| 19-02 | `PolyT.MainV1` | `PolyakovT.polyExp` |
| 19-02 | `Lattice.TorusDecV2` | `TorusRP.hol` |
| 19-02 | `Blocks.TheoremEV2` | `TwistBlocks.SN`・`TwistBlocks.Smin`・`TwistBlocks.Svortex`・`TwistBlocks.thetaM`・`TwistBlocks.vac` |
| 19-02 | `Blocks.VacuumV1` | `TwistBlocks.SN_bounds`・`TwistBlocks.Svortex_le`・`TwistBlocks.vac_term` |
| 19-02 | `Blocks.ThickFloorAttainV1` | `TwistBlocks.Svortex_attained` |
| 19-02 | `Wilson.SU2TwistV2` | `TwistedWilson.Plaq`・`TwistedWilson.Site`・`TwistedWilson.ZW`・`TwistedWilson.ZW_pos`・`TwistedWilson.haarCfg`・`TwistedWilson.hol`・`TwistedWilson.zt` |
| 19-03 | `Infvol.AllNV1` | `AllN.liftS` |
| 19-03 | `UVChain.BoxChainV1` | `ChainBlockMap.Cfg` |
| 19-03 | `Lattice.GaugeSectorV1` | `GaugeZ.Wgi`・`GaugeZ.Winv` |
| 19-03 | `Blocks.ThickFloorHalfSplitV1` | `HalfSplit.Th`・`HalfSplit.fixL`・`HalfSplit.sgL`・`HalfSplit.thL` |
| 19-03 | `Lattice.TorusDecV2` | `LinkReflection.linkRefl`・`TorusRP.QBall`・`TorusRP.fixP`・`TorusRP.holQ_refl`・`TorusRP.posP`・`TorusRP.sig`・`TorusRP.thL`・`TorusRP.wilson_refl_symm` |
| 19-03 | `Lattice.MidPlaneV1` | `MidRP.posM`・`MidRP.thM` |
| 19-03 | `Lattice.MidSetOneV1` | `MidRP.sigT` |
| 19-03 | `Lattice.GapG` | `OSGap.Datum`・`OSGap.Datum.HasMassGap`・`OSGap.Datum.Hilb`・`OSGap.Datum.T`・`OSGap.Datum.T_symm`・`OSGap.Datum.T_Ω`・`OSGap.Datum.contraction`・`OSGap.Datum.decay_of_hasMassGap`・`OSGap.Datum.hasMassGap_of_decay`・`OSGap.Datum.norm_Ω`・`OSGap.Datum.Ω`・`OSGap.exampleDatum`・`OSGap.example_opNorm_eq`・`OSGap.measureDatum`・`OSGap.vacProj`・`OrbitGrowth.contraction_of_bounded` |
| 19-03 | `Blocks.ThickFloorRPCoreV1` | `ThickFloorRP.LinkReflection.linkRefl` |
| 19-03 | `Lattice.TorusGaugeV1` | `TorusGauge.cr` |
| 19-03 | `Bridge.TimeAlignV1` | `WilsonBridgeT.refl_toBallT` |
| 19-03 | `Box.FermionBaseV8a` | `WilsonGauge.refl_pull` |
| 19-03 | `Gauge.WilsonFullV7c` | `WilsonGauge.thetaPhys` |
| 19-03 | `Lattice.WilsonGapV2` | `WilsonLimit.Cfg`・`WilsonLimit.Nn`・`WilsonLimit.Wsub`・`WilsonLimit.liftProb`・`WilsonLimit.perLift`・`WilsonLimit.zRefl`・`WilsonLimit.zShift` |
| 19-04 | `Linz.Expand1` | `BlockLinear.sixSgn` |
| 19-04 | `Lift.RetractOne1` | `BlockLinearKernel.blockMap_exp_linear_le_one` |
| 19-04 | `Linz.Kernel1` | `BlockLinearKernel.expCfg` |
| 19-04 | `Box.FermionChainV8b` | `BoxFermion.fermProbBox` |
| 19-04 | `UVChain.BoxChainV1` | `BoxWalk.BoxLk`・`BoxWalk.boxMap_rev`・`BoxWalk.boxPaths`・`BoxWalk.boxW`・`ChainBlockMap.Ball`・`ChainBlockMap.blockMap`・`ChainBlockMap.blockMap_of_small_field`・`ChainBlockMap.continuous_blockMap`・`ChainBlockMap.down`・`ChainBlockMap.hcons_blockMap`・`ChainBlockMap.norm_sixAvg_le`・`ChainBlockMap.sixWeight`・`ChainBlockMap.sixWeight_total`・`ChainBlockMap.νP`・`ChainBlockMap.νP_self`・`WalkCast.walk` |
| 19-04 | `Push.Lat2` | `LatticeFace.faceCov`・`LatticeFace.faceCov_eq_posC` |
| 19-04 | `Push.Rec1` | `LatticePath.pathSym_closed`・`LatticeTorus.pathKernel` |
| 19-04 | `Push.Lat1` | `LatticePush.freeCov`・`LatticePush.projFam_stage`・`LatticePush.stageCov`・`LatticePush.stageCov_phase`・`LatticePush.stepOp` |
| 19-04 | `FreeOS.QposUpV1` | `OneStepBridge.Mfam`・`TorusFourier.Cop` |
| 19-04 | `Lift.PushCov1` | `PushCov.blockLin`・`PushCov.covForm`・`PushCov.lattice_pushCov` |
| 19-04 | `SkewOrbit.Probe` | `SkewOrbitProbe.Ex.hr` |
| 19-04 | `Lam.Up1` | `TauSplit.Gs` |
| 19-05 | `Fermion.SliceWilsonV6d` | `FermionSU2Config.PhysLink`・`FermionSU2Config.SU2`・`FermionSU2Config.quatMat`・`FermionSliceBlock.eps`・`FermionSliceBlock.gammaSp`・`FermionSliceBlock.gammaT`・`FermionSliceBlock.sc`・`FermionSliceBlock.std4`・`FermionSliceBlock.stdSlice`・`FermionSliceBlock.torusLink`・`FermionSliceBlock.torusX`・`FermionSliceReflection.wilson_weight_nonneg_std4`・`FermionSliceReflection.wilson_weight_nonneg_torus` |
| 19-05 | `SkewOrbit.Probe` | `SkewOrbitProbe.Ex.hT` |
| 19-05 | `Lattice.TorusDecV2` | `TorusRP.wilsonMeasure` |
| 19-05 | `Lattice.WilsonGapV2` | `TorusRP.wilsonProb` |
| 19-05 | `Wilson.SU2TwistV2` | `TwistedWilson.ZW` |
| 19-05 | `Box.FermionBaseV8a` | `WilsonGauge.continuous_fermWeight`・`WilsonGauge.fermWeight_nonneg`・`WilsonGauge.gaugeMeasure`・`WilsonGauge.wfMeasure`・`WilsonGauge.wfProb`・`WilsonGauge.wfProb_isProbability`・`WilsonGauge.wfWeight`・`WilsonGauge.wfWeight_nonneg`・`WilsonGauge.wf_partition_pos`・`WilsonGauge.wilsonMeasure_eq_map` |
| 19-05 | `Gauge.WilsonFullV7c` | `WilsonGauge.fermWeight`・`WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.physDirac`・`WilsonGauge.physDirac_eq_split`・`WilsonGauge.physSp`・`WilsonGauge.physT`・`WilsonGauge.plaqE`・`WilsonGauge.wilsonAction` |
| 19-05 | `Gauge.DirectEntriesV7a` | `WilsonGauge.physDirac_apply` |
| 19-06 | `Linz.Expand1` | `BlockLinear.sixSgn` |
| 19-06 | `Linz.Kernel1` | `BlockLinearKernel.expCfg` |
| 19-06 | `UVChain.BoxChainV1` | `BoxWalk.BoxLk`・`BoxWalk.base`・`BoxWalk.boxPaths`・`BoxWalk.boxPathsIdx`・`BoxWalk.boxW`・`BoxWalk.double`・`ChainBlockMap.Ball`・`ChainBlockMap.blockMap`・`ChainBlockMap.coarseAvg`・`ChainBlockMap.down`・`ChainBlockMap.pathProd`・`ChainBlockMap.retract`・`ChainBlockMap.sixAvg`・`ChainBlockMap.sixWeight`・`ChainBlockMap.wt`・`ChainBlockMap.νP`・`WalkCast.walk` |
| 19-06 | `Fermion.SliceWilsonV6d` | `FermionSU2Config.PhysLink`・`FermionSU2Config.SU2`・`FermionSliceBlock.gammaSp`・`FermionSliceBlock.gammaT`・`FermionSliceBlock.std4` |
| 19-06 | `Blocks.ThickFloorHalfSplitV1` | `HalfSplit.Th` |
| 19-06 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.polyLoop` |
| 19-06 | `Push.Lat2` | `LatticeFace.curl`・`LatticeFace.faceCov` |
| 19-06 | `Push.Lat1` | `LatticePush.freeCov`・`LatticePush.pushOp`・`LatticePush.stageCov`・`LatticePush.stepOp` |
| 19-06 | `Push.Rec1` | `LatticeTorus.pathKernel` |
| 19-06 | `Lattice.TorusDecV2` | `LinkReflection.linkRefl`・`OSGap.SU2`・`OSGap.haarProb`・`TorusRP.Lk`・`TorusRP.QBall`・`TorusRP.action`・`TorusRP.fixP`・`TorusRP.haarBall`・`TorusRP.hol`・`TorusRP.posP`・`TorusRP.sig`・`TorusRP.thL`・`TorusRP.wilsonMeasure` |
| 19-06 | `Lattice.MidPlaneV1` | `MidRP.posM`・`MidRP.thM` |
| 19-06 | `Lattice.GapG` | `OSGap.Datum`・`OSGap.Datum.HasMassGap`・`OSGap.Datum.Hilb`・`OSGap.Datum.T`・`OSGap.Datum.Ω`・`OSGap.measureDatum`・`OSGap.vacProj`・`OrbitGrowth.pairingForm` |
| 19-06 | `FreeOS.QposUpV1` | `OneStepBridge.AM`・`OneStepBridge.Mfam`・`OneStepBridge.Pfam`・`OneStepBridge.thR`・`OneStepET.omF`・`OneStepFinal.Qpos`・`OneStepFinal.rqPos`・`TorusFourier.Cop` |
| 19-06 | `PolyT.MainV1` | `PolyakovT.polyExp` |
| 19-06 | `Lift.PushCov1` | `PushCov.blockLin`・`PushCov.covForm` |
| 19-06 | `Lam.Up1` | `TauSplit.Gs` |
| 19-06 | `Blocks.ThickFloorRPCoreV1` | `ThickFloorRP.LinkReflection.linkRefl` |
| 19-06 | `Lam.Torus1` | `TorusLam.Gst` |
| 19-06 | `Lattice.WilsonGapV2` | `TorusRP.wilsonProb`・`WilsonLimit.liftProb` |
| 19-06 | `Blocks.TheoremEV2` | `TwistBlocks.SN`・`TwistBlocks.Svortex`・`TwistBlocks.thetaM` |
| 19-06 | `Wilson.SU2TwistV2` | `TwistedWilson.SU2`・`TwistedWilson.Site`・`TwistedWilson.ZW`・`TwistedWilson.haarCfg`・`TwistedWilson.haarProb`・`TwistedWilson.hol`・`TwistedWilson.zt` |
| 19-06 | `Bridge.WilsonTwistV1` | `WilsonBridge.integral_wilsonMeasure`・`WilsonBridge.wilsonMeasure_eq_map`・`WilsonBridge.wilsonMeasure_univ` |
| 19-06 | `Bridge.TimeAlignV1` | `WilsonBridgeT.refl_toBallT`・`WilsonBridgeT.wilsonMeasure_eq_mapT` |
| 19-06 | `Bridge.VortexV1` | `WilsonBridgeV.vortex_ratio_eq` |
| 19-06 | `Gauge.WilsonFullV7c` | `WilsonGauge.fermWeight`・`WilsonGauge.physDirac`・`WilsonGauge.plaqE`・`WilsonGauge.thetaPhys`・`WilsonGauge.wilsonAction` |
| 19-06 | `Box.FermionBaseV8a` | `WilsonGauge.gaugeMeasure`・`WilsonGauge.wfMeasure`・`WilsonGauge.wfProb`・`WilsonGauge.wfWeight`・`WilsonGauge.wilsonMeasure_eq_map` |
| 19-07 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| 19-07 | `UVChain.BoxChainV1` | `ChainBlockMap.νP` |
| 19-07 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 19-07 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 19-07 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 19-07 | `Push.Join7` | `LatticeFace.lattice_face_T1h` |
| 19-07 | `Lattice.GapG` | `OSGap.Datum.HasMassGap` |
| 19-07 | `Lam.Torus1` | `TorusLam.stage_tau_17` |
| 19-07 | `Lattice.WilsonGapV2` | `TorusRP.wilsonProb` |
| 19-07 | `Blocks.TheoremEV2` | `TwistBlocks.thetaM` |
| 19-07 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.thick_vortex_floor` |
| 19-07 | `Wilson.SU2TwistV2` | `TwistedWilson.twisted_vortex_bound` |
| 19-07 | `Area.VortexMNSharpV1` | `VortexStrongMN.vortex_floor_MN_sharp` |
| 20-00 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| 20-00 | `Area.InfVolV2` | `AreaLaw.area_law_infvol` |
| 20-00 | `Area.AreaMainV1` | `AreaLaw.area_law_wilson` |
| 20-00 | `Infvol.BindAllUV1` | `Bind.T_range_gauge_all` |
| 20-00 | `FermionLane.LatticeSymV10a` | `CubicSym.wfProb_lattice_generators` |
| 20-00 | `Infvol.FullTV2` | `FullT.wilson_Tpos_full` |
| 20-00 | `FermionLane.GaugeDetV9c` | `GaugeDet.physDirac_det_conj` |
| 20-00 | `Lattice.GaugeSectorV1` | `GaugeZ.wilson_massGap_gauge_exists` |
| 20-00 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 20-00 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 20-00 | `Sweep.DistDecayV1` | `LinkSpec.wilson_cov_dist` |
| 20-00 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| 20-00 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_rp_dir` |
| 20-00 | `Lattice.TorusDecV2` | `TorusRP.wilson_refl_symm`・`TorusRP.wilson_rp`・`TorusRP.wilson_strong_coupling` |
| 20-00 | `Infvol.TransV2` | `TransI.wilson_infvol_translation` |
| 20-00 | `Area.VortexStrongV1` | `VortexStrong.vortex_floor` |
| 20-00 | `Area.VortexMNSharpV1` | `VortexStrongMN.vortex_floor_MN_sharp` |
| 20-00 | `Gauge.WilsonFullV7c` | `WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.site_reflection_positive_wilson_full` |
| 20-00 | `Lattice.ClusterV1` | `WilsonLimit.cluster_limit` |
| 20-00 | `Lattice.WilsonDobV1` | `WilsonLimit.wilson_massGap_dob_exists` |
| 20-01 | `Infvol.FullTV2` | `FullT.full_rp_torus`・`FullT.wilson_Tpos_full` |
| 20-01 | `Lattice.GaugeFixV5` | `GaugeFix.integral_gaugeFix` |
| 20-01 | `Lattice.TorusDecV2` | `LinkReflection.rp_core`・`LinkReflection.rp_weighted`・`TorusRP.weight_factor`・`TorusRP.wilson_refl_symm`・`TorusRP.wilson_rp` |
| 20-01 | `Lattice.RPKernelV1` | `LinkReflection.rp_kernel` |
| 20-01 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| 20-01 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_perm_invariant`・`PeierlsPerm.wilson_rp_dir` |
| 20-01 | `Blocks.ThickFloorRPCoreV1` | `ThickFloorRP.LinkReflection.rp_core`・`ThickFloorRP.LinkReflection.rp_weighted` |
| 20-01 | `Lattice.TorusGaugeV1` | `TorusGauge.wilson_gaugeFix` |
| 20-02 | `Sweep.DistDecayV1` | `LinkSpec.cov_le`・`LinkSpec.iter_invariant`・`LinkSpec.iter_mul_invariant`・`LinkSpec.row_weighted`・`LinkSpec.wilson_cov_dist`・`Sweep.iter_bound`・`TorusRP.wilson_hdec_torus_dob` |
| 20-02 | `Spec.DobrushinRowV2` | `LinkSpec.dobrushin_row`・`LinkSpec.tanhForm_le` |
| 20-02 | `Sweep.HeatBathSweepV1` | `LinkSpec.hbSweep_invariant` |
| 20-02 | `Spec.LinkCoeffV1` | `LinkSpec.spec_coeff` |
| 20-02 | `Lattice.TorusDecV2` | `SwapDecay.covBound_minimal`・`SwapDecay.minimalNonsep_sum_le`・`TorusRP.card_link_plaqs`・`TorusRP.card_touch_le`・`TorusRP.height_lip`・`TorusRP.plaq_degree`・`TorusRP.wilson_covariance`・`TorusRP.wilson_strong_coupling` |
| 20-02 | `Lattice.WilsonDobV1` | `WilsonLimit.dob_window_strict` |
| 20-03 | `Infvol.AllNV1` | `AllN.liftS`・`AllN.lift_closeS`・`AllN.wilson_infvol_allN` |
| 20-03 | `Infvol.CylDetV2` | `CylDet.ext_of_cyl`・`CylDet.subseq_limit_eq`・`CylDet.tendsto_of_cyl_cauchy` |
| 20-03 | `Infvol.CauchyV2` | `InfVol.cauchy_cyl`・`InfVol.infvol_example`・`InfVol.lift_close`・`InfVol.wilson_infvol_unique` |
| 20-03 | `Spec.SweepStepV1` | `LinkSpec.coef` |
| 20-03 | `Lattice.ClusterV1` | `LinkSpec.coordLip`・`WilsonLimit.cluster_limit` |
| 20-03 | `Infvol.BoxSweepV1` | `LinkSpec.torus_box` |
| 20-03 | `Infvol.TransV2` | `TransI.lift_shiftI_invariant`・`TransI.limit_shiftI_invariant`・`TransI.wilson_infvol_translation` |
| 20-03 | `Lattice.WilsonDobV1` | `WilsonLimit.dob_window_strict` |
| 20-03 | `Lattice.WilsonGapV2` | `WilsonLimit.liftProb` |
| 20-03 | `Infvol.ZHeatV2` | `ZHeat.iter_lift` |
| 20-04 | `Infvol.BindAllUV1` | `Bind.T_range_gauge_all` |
| 20-04 | `Infvol.FullTV2` | `FullT.wilson_Tpos_full` |
| 20-04 | `Lattice.GaugeSectorV1` | `GaugeZ.wilson_massGap_gauge_exists` |
| 20-04 | `Lattice.NondegV3` | `HaarRe.integral_sq_sub_ge`・`LinkSpec.wilsonProb_sq_sub_ge`・`OSGap.Datum.exists_unit_orth`・`WilsonLimit.var_limit_ge`・`WilsonLimit.wilson_massGap_nondegenerate` |
| 20-04 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 20-04 | `Sweep.DistDecayV1` | `LinkSpec.wilson_cov_dist`・`TorusRP.wilson_hdec_torus_dob` |
| 20-04 | `Lattice.GapG` | `OSGap.Datum`・`OSGap.Datum.opNorm_gap` |
| 20-04 | `Lattice.WilsonGapV2` | `WilsonLimit.Wsub` |
| 20-04 | `Lattice.WilsonDobV1` | `WilsonLimit.dec_eventually_dob`・`WilsonLimit.wilson_massGap_dob`・`WilsonLimit.wilson_massGap_dob_exists` |
| 20-05 | `FermionLane.GaugeV9` | `BoxFermion.conjPhys` |
| 20-05 | `FermionLane.CubicCliffV10b` | `CubicSym.cliffOp_conj`・`CubicSym.det_cliffOp_perm` |
| 20-05 | `FermionLane.TimeReflV10b` | `CubicSym.physDirac_det_trefl`・`CubicSym.treflPhys` |
| 20-05 | `FermionLane.CubicPhysV10b` | `CubicSym.reflPhys`・`CubicSym.rotPhys` |
| 20-05 | `FermionLane.TimeRotV10h` | `CubicSym.trotPhys` |
| 20-05 | `FermionLane.HyperSymV10a` | `CubicSym.wfProb_hypercubic_generators` |
| 20-05 | `FermionLane.LatticeSymV10a` | `CubicSym.wfProb_lattice_generators` |
| 20-05 | `Fermion.SliceWilsonV6d` | `FermionSliceBlock.wilsonPlane_posDef`・`FermionSliceReflection.site_reflection_positive_phys` |
| 20-05 | `FermionLane.GaugeDetV9c` | `GaugeDet.physDirac_det_conj` |
| 20-05 | `FermionLane.TransV9d` | `GaugeDet.transPhys` |
| 20-05 | `FermionLane.TimeShiftV9h` | `TimeShift.tshiftPhys` |
| 20-05 | `Gauge.WilsonFullV7c` | `WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.physDirac`・`WilsonGauge.physDirac_eq_split`・`WilsonGauge.plaqE_reflect`・`WilsonGauge.site_reflection_positive_wilson_full`・`WilsonGauge.wilsonAction_split` |
| 20-05 | `Box.FermionBaseV8a` | `WilsonGauge.wfProb`・`WilsonGauge.wfWeight` |
| 20-06 | `Area.PlaqBoundV1` | `AreaLaw.ZX_insert_le`・`AreaLaw.q_eq` |
| 20-06 | `Area.WordBoundV1` | `AreaLaw.abs_wordExpect_le`・`AreaLaw.minSpanC` |
| 20-06 | `Area.InfVolV2` | `AreaLaw.area_law_infvol`・`AreaLaw.area_law_limit`・`AreaLaw.rectWord_one_one`・`AreaLaw.zRectWord` |
| 20-06 | `Area.InfVolSubV1` | `AreaLaw.area_law_limit_sub` |
| 20-06 | `Area.AreaMainV1` | `AreaLaw.area_law_wilson`・`AreaLaw.area_law_wilson_area` |
| 20-06 | `Area.RectMoveV1` | `AreaLaw.area_law_wilson_general`・`AreaLaw.expect_perm`・`AreaLaw.rectWordG`・`AreaLaw.wilson_cfgShift_invariant` |
| 20-06 | `Area.SharpConstV1` | `AreaLaw.area_law_wilson_general_sharp`・`AreaLaw.area_law_wilson_sharp`・`AreaLaw.card_nbQ_le`・`AreaLaw.card_rootP_le`・`VortexStrong.vortex_floor_sharp` |
| 20-06 | `Area.ExponentMaxV1` | `AreaLaw.area_law_wilson_max_sharp`・`AreaLaw.wordBd_swap_rect` |
| 20-06 | `Area.AnimalV1` | `AreaLaw.card_conn_le` |
| 20-06 | `Area.AreaLowerV1` | `AreaLaw.card_ge_of_spans_rect`・`AreaLaw.rectWord` |
| 20-06 | `Area.ConnPartsV1` | `AreaLaw.div_plaqBd` |
| 20-06 | `Area.MixV1` | `AreaLaw.exp_eq_mix`・`AreaLaw.integral_mul_prod_one_add`・`AreaLaw.mixVar_mem`・`AreaLaw.prod_one_add_univ` |
| 20-06 | `Area.FlipVanishV1` | `AreaLaw.flipZ_preserving`・`AreaLaw.hol_eq_wordHol`・`AreaLaw.integral_word_mul_prod_eq_zero_of_not_mem_span`・`AreaLaw.wordHol`・`AreaLaw.wordHol_flip` |
| 20-06 | `Area.ConnRectV1` | `AreaLaw.minSpan_rect_conn` |
| 20-06 | `Area.DualF2V1` | `AreaLaw.not_mem_span_iff_exists_sep` |
| 20-06 | `Area.SimpleCycleV1` | `AreaLaw.rect_closed_cases` |
| 20-06 | `Area.DominanceV1` | `AreaLaw.sum_superset_le` |
| 20-06 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 20-06 | `Lattice.TorusDecV2` | `TorusRP.wilsonMeasure` |
| 20-06 | `Area.VortexStrongV1` | `VortexStrong.Good`・`VortexStrong.ZM_gauge`・`VortexStrong.ZM_good`・`VortexStrong.Ztw`・`VortexStrong.abs_Z_sub_le`・`VortexStrong.card_bad_ge`・`VortexStrong.good_twist_iff`・`VortexStrong.minBad_conn`・`VortexStrong.twist`・`VortexStrong.vortex_floor`・`VortexStrong.vortex_floor_rel` |
| 20-06 | `Area.VortexSanityV1` | `VortexStrong.plane_bad` |
| 20-06 | `Area.VortexLinkV1` | `VortexStrong.vortex_floor_wilson` |
| 20-06 | `Area.VortexMNV1` | `VortexStrongMN.card_bad_ge`・`VortexStrongMN.minBad_conn`・`VortexStrongMN.vortex_floor_MN` |
| 20-06 | `Area.VortexMNSharpV1` | `VortexStrongMN.vortex_floor_MN_sharp` |
| 20-06 | `Lattice.WilsonGapV2` | `WilsonLimit.liftProb` |
| 20-07 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| 20-07 | `Area.InfVolV2` | `AreaLaw.area_law_infvol` |
| 20-07 | `Area.InfVolSubV1` | `AreaLaw.area_law_limit_sub` |
| 20-07 | `Area.AreaMainV1` | `AreaLaw.area_law_wilson` |
| 20-07 | `Area.ExponentMaxV1` | `AreaLaw.area_law_wilson_max_sharp` |
| 20-07 | `Area.SharpConstV1` | `AreaLaw.area_law_wilson_sharp`・`VortexStrong.vortex_floor_sharp` |
| 20-07 | `Infvol.BindAllUV1` | `Bind.T_range_gauge_all` |
| 20-07 | `FermionLane.TimeReflV10b` | `CubicSym.physDirac_det_trefl` |
| 20-07 | `FermionLane.HyperSymV10a` | `CubicSym.wfProb_hypercubic_generators` |
| 20-07 | `FermionLane.LatticeSymV10a` | `CubicSym.wfProb_lattice_generators` |
| 20-07 | `Infvol.FullTV2` | `FullT.wilson_Tpos_full` |
| 20-07 | `FermionLane.GaugeDetV9c` | `GaugeDet.physDirac_det_conj` |
| 20-07 | `Lattice.GaugeSectorV1` | `GaugeZ.wilson_massGap_gauge_exists` |
| 20-07 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 20-07 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| 20-07 | `Sweep.DistDecayV1` | `LinkSpec.wilson_cov_dist` |
| 20-07 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| 20-07 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_rp_dir` |
| 20-07 | `Lattice.TorusDecV2` | `TorusRP.wilson_refl_symm`・`TorusRP.wilson_rp`・`TorusRP.wilson_strong_coupling` |
| 20-07 | `Infvol.TransV2` | `TransI.wilson_infvol_translation` |
| 20-07 | `Area.VortexStrongV1` | `VortexStrong.vortex_floor` |
| 20-07 | `Area.VortexMNSharpV1` | `VortexStrongMN.vortex_floor_MN_sharp` |
| 20-07 | `Gauge.WilsonFullV7c` | `WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.site_reflection_positive_wilson_full` |
| 20-07 | `Lattice.ClusterV1` | `WilsonLimit.cluster_limit` |
| 20-07 | `Lattice.WilsonDobV1` | `WilsonLimit.wilson_massGap_dob`・`WilsonLimit.wilson_massGap_dob_exists` |
| 20-07 | `Lattice.NondegV3` | `WilsonLimit.wilson_massGap_nondegenerate` |
| 21-01 | `Covering.IneqV10` | `CoveringInequality.IsSignChar`・`CoveringInequality.Z`・`CoveringInequality.Z_char_shift`・`CoveringInequality.Z_flip_le`・`CoveringInequality.Z_mul_Z`・`CoveringInequality.card_mul_integral_exp`・`CoveringInequality.covering_ineq`・`CoveringInequality.covering_ratio`・`CoveringInequality.dominated_covering_ineq`・`CoveringInequality.invariant_dominated`・`CoveringInequality.mon_ineq`・`CoveringInequality.mon_ratio`・`CoveringInequality.vfe_cover_le` |
| 21-01 | `Wilson.ParityV1` | `TwistedPlane.exists_chi2_eq`・`TwistedWilson.ZEta_parity` |
| 21-01 | `Wilson.EtaV2` | `TwistedWilson.ZEta`・`TwistedWilson.ZEta_flip_any`・`TwistedWilson.ZEta_gauge` |
| 21-01 | `Wilson.SU2TwistV2` | `TwistedWilson.abs_re_le_one`・`TwistedWilson.chiB_isSignChar`・`TwistedWilson.haarCfg_inv`・`TwistedWilson.hol_smul`・`TwistedWilson.integrable_exp`・`TwistedWilson.pull`・`TwistedWilson.signAction`・`TwistedWilson.su2_dominated`・`TwistedWilson.z2_four_covers_two`・`TwistedWilson.z2_four_ratio` |
| 21-01 | `Wilson.GeneralV1` | `TwistedWilson.su2_dominated_general`・`TwistedWilson.su2_dominated_general_instance` |
| 21-01 | `Wilson.ThetaV1` | `TwistedWilson.theta_eq_eta_average` |
| 21-02 | `Plane.TwistedZ2V2` | `TwistedPlane.Z_plane`・`TwistedPlane.Z_plane_const`・`TwistedPlane.Z_plane_flip`・`TwistedPlane.chi2`・`TwistedPlane.plane_flip_ratio`・`TwistedPlane.prod_chi2_univ`・`TwistedPlane.sum_FA_eq_zero` |
| 21-02 | `Wilson.SU2TwistV2` | `TwistedWilson.Z_base`・`TwistedWilson.Z_base_const`・`TwistedWilson.Z_base_flip`・`TwistedWilson.bound_of_base`・`TwistedWilson.chi0_eq`・`TwistedWilson.haarCfg_inv`・`TwistedWilson.hol_smul`・`TwistedWilson.pull`・`TwistedWilson.su2_dominated`・`TwistedWilson.twisted_ratio_lower`・`TwistedWilson.twisted_vortex_bound` |
| 21-02 | `Wilson.GeneralV1` | `TwistedWilson.su2_dominated_general` |
| 21-02 | `Wilson.AbsV1` | `TwistedWilson.su2_dominated_swap`・`TwistedWilson.twisted_vortex_bound_abs` |
| 21-02 | `Wilson.FloorV3` | `TwistedWilson.thin_vortex_floor` |
| 21-02 | `Wilson.Q8TwistV2` | `TwistedWilson.vortex_free_energy_bound` |
| 21-03 | `Blocks.ThickFloorQuatV1` | `ThickFloor.anticomm_conj` |
| 21-03 | `Blocks.ThickFloorAbstractV1` | `ThickFloor.small_action_cost` |
| 21-03 | `Blocks.StageTwoV2` | `TwistBlocks.Keff_le`・`TwistBlocks.block_bound_abs` |
| 21-03 | `Blocks.KeffLaplaceV1` | `TwistBlocks.Keff_le_laplace` |
| 21-03 | `Blocks.VacuumV1` | `TwistBlocks.SN_bounds` |
| 21-03 | `Blocks.ThickFloorAbsV1` | `TwistBlocks.ThickVortexFloorAbs` |
| 21-03 | `Blocks.ThickFloorCanonV1` | `TwistBlocks.canon_holds` |
| 21-03 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.rigidT_all`・`TwistBlocks.thick_vortex_floor`・`TwistBlocks.thick_vortex_floor_unfolded` |
| 21-03 | `Blocks.ThickFloorTransportV1` | `TwistBlocks.thick_vortex_floor_zero_of_rigid` |
| 21-03 | `VortexCert.CertN4V1` | `VortexCert.SN_four_lt` |
| 21-03 | `VortexCert.CertN3V1` | `VortexCert.SN_three_lt` |
| 21-03 | `VortexCert.CertN2V1` | `VortexCert.SN_two_le`・`VortexCert.SN_two_lt` |
| 21-03 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos` |
| 21-04 | `Blocks.LaplaceV1` | `CoarseLaplace.laplace_lower` |
| 21-04 | `Blocks.ThickFloorQuatV1` | `ThickFloor.anticomm_conj` |
| 21-04 | `Blocks.ThickFloorAbstractV1` | `ThickFloor.anticomm_unit`・`ThickFloor.small_action_cost` |
| 21-04 | `Blocks.ThickFloorChainV1` | `TwistBlocks.Canon`・`TwistBlocks.H4_of_local`・`TwistBlocks.LocalVortex`・`TwistBlocks.exists_win_le` |
| 21-04 | `Blocks.UniformV1` | `TwistBlocks.Dmax_le` |
| 21-04 | `Blocks.ThickFloorLowerV1` | `TwistBlocks.H4_fails_below`・`TwistBlocks.kappaC_ge_Svortex` |
| 21-04 | `Blocks.StageTwoV2` | `TwistBlocks.Keff`・`TwistBlocks.Keff_le`・`TwistBlocks.Keff_nonneg`・`TwistBlocks.ZB`・`TwistBlocks.block_bound_abs` |
| 21-04 | `Blocks.KeffLaplaceV1` | `TwistBlocks.Keff_le_laplace` |
| 21-04 | `Blocks.ThickFloorLiftV1` | `TwistBlocks.LocalVortexL`・`TwistBlocks.localVortex_of_local`・`TwistBlocks.thick_vortex_floor_abs_of_localL` |
| 21-04 | `Blocks.ThickFloorTransportV1` | `TwistBlocks.RigidL`・`TwistBlocks.thick_vortex_floor_abs_of_rigid`・`TwistBlocks.thick_vortex_floor_zero_of_rigid` |
| 21-04 | `Blocks.ThickFloorSquareV1` | `TwistBlocks.RigidT`・`TwistBlocks.rigidL_of_rigidT`・`TwistBlocks.rigidT_one`・`TwistBlocks.thick_vortex_floor_abs_of_rigidT` |
| 21-04 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.SL_vacL`・`TwistBlocks.cfA`・`TwistBlocks.cfB`・`TwistBlocks.cf_comm`・`TwistBlocks.flatT_nonempty`・`TwistBlocks.rigidT_all`・`TwistBlocks.thick_vortex_floor`・`TwistBlocks.uniqT` |
| 21-04 | `Blocks.ThickFloorAttainV1` | `TwistBlocks.Svortex_attained` |
| 21-04 | `Blocks.ThickFloorReduceV1` | `TwistBlocks.ZeroVortexL`・`TwistBlocks.localVortexL_of_zero`・`TwistBlocks.thick_vortex_floor_abs_of_zero` |
| 21-04 | `Blocks.ThickFloorAbsV1` | `TwistBlocks.abs_block_bound_exp`・`TwistBlocks.thick_vortex_floor_abs_of_H4`・`TwistBlocks.thick_vortex_floor_abs_of_local` |
| 21-04 | `Blocks.ThickFloorCanonV1` | `TwistBlocks.canon_holds` |
| 21-04 | `Blocks.ThickFloorKappaEqV1` | `TwistBlocks.kappaC_eq_kappa` |
| 21-04 | `Blocks.ThickFloorKappaTwoV1` | `TwistBlocks.kappaC_le_two` |
| 21-05 | `Blocks.TheoremEV2` | `TwistBlocks.SN`・`TwistBlocks.Svortex` |
| 21-05 | `Blocks.VacuumV1` | `TwistBlocks.SN_bounds`・`TwistBlocks.Svortex_le` |
| 21-05 | `Blocks.ThickFloorGridV1` | `TwistBlocks.grid_vortex_floor` |
| 21-05 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.rigidT_all`・`TwistBlocks.thick_vortex_floor` |
| 21-05 | `Blocks.ThickFloorStabV1` | `TwistBlocks.stab_vacT` |
| 21-05 | `Blocks.ThickFloorFourV1` | `TwistBlocks.thick_vortex_floor_four` |
| 21-05 | `Blocks.ThickFloorThreeV1` | `TwistBlocks.thick_vortex_floor_three` |
| 21-05 | `Blocks.ThickFloorTwoV1` | `TwistBlocks.thick_vortex_floor_two`・`TwistBlocks.thick_vortex_floor_two_rate_lt` |
| 21-05 | `VortexCert.CertN4V1` | `VortexCert.SN_four_le`・`VortexCert.SN_four_lt`・`VortexCert.Svortex_four_four_le`・`VortexCert.certN4` |
| 21-05 | `VortexCert.CoreV3` | `VortexCert.SN_le_Svortex`・`VortexCert.Svortex_le_of_cert`・`VortexCert.normSq_cay` |
| 21-05 | `VortexCert.CertN3V1` | `VortexCert.SN_three_le`・`VortexCert.SN_three_lt`・`VortexCert.Svortex_three_eight_le`・`VortexCert.certN3` |
| 21-05 | `VortexCert.CertN2V1` | `VortexCert.SN_two_le`・`VortexCert.SN_two_lt`・`VortexCert.Svortex_two_eight_le`・`VortexCert.certN2` |
| 21-05 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos`・`VortexPos.Svortex_ge_unif`・`VortexPos.linkH_le`・`VortexPos.linkV_le` |
| 21-06 | `Blocks.ThickFloorThetaPosV1` | `HalfSplit.Z1_le_Z0`・`TwistBlocks.theta_lt_one`・`TwistBlocks.theta_nonneg` |
| 21-06 | `Blocks.ThickFloorHalfSplitV1` | `HalfSplit.half_pairing_nonneg`・`HalfSplit.half_split`・`HalfSplit.wE` |
| 21-06 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.odd_fix_bound`・`HalfSplit.polyLoop`・`HalfSplit.polyakov_pair_theta` |
| 21-06 | `Blocks.ThickFloorPolyakovFloorV1` | `HalfSplit.polyakov_pair_floor` |
| 21-06 | `PolyT.ChordV1` | `LogChord.chord` |
| 21-06 | `PolyT.TransV3` | `PolyakovT.Gc_even_nonneg`・`PolyakovT.Gc_swap`・`PolyakovT.corr_shiftZ`・`PolyakovT.cs_even`・`PolyakovT.wpair_cs`・`PolyakovT.wpair_nonneg` |
| 21-06 | `PolyT.MainV1` | `PolyakovT.half_pair_tanh`・`PolyakovT.polyExp`・`PolyakovT.polyakov_pair_all` |
| 21-06 | `PolyT.LinkRPMainV3` | `PolyakovT.link_rp` |
| 21-06 | `PolyT.FlipV2` | `PolyakovT.polyExp_neg`・`PolyakovT.polyakov_pair_evenNM` |
| 21-06 | `PolyT.AllMV2` | `PolyakovT.polyakov_pair_evenM` |
| 21-06 | `Blocks.ThickFloorSignedV1` | `TwistBlocks.thick_vortex_floor_signed` |
| 21-06 | `Wilson.EtaV2` | `TwistedWilson.ZEta_flip_any` |
| 21-06 | `Wilson.ParityV1` | `TwistedWilson.ZEta_parity` |
| 21-06 | `Wilson.SU2TwistV2` | `TwistedWilson.ZW` |
| 21-07 | `Tuning.ApproxStokesV1` | `FlatStokes.approx_torus_commutator` |
| 21-07 | `Tuning.FlatStokesV1` | `FlatStokes.no_twisted_quadruple`・`FlatStokes.torus_commutator` |
| 21-07 | `Tuning.QuadTwoV1` | `QuadFloor.quad_floor_two` |
| 21-07 | `Tuning.ThetaLimitV2` | `ThetaLimit.Smin`・`ThetaLimit.Z10_ge`・`ThetaLimit.Z11_le`・`ThetaLimit.exists_theta_gt`・`ThetaLimit.sanity_half`・`ThetaLimit.tendsto_theta_one`・`ThetaLimit.theta_le_one`・`ThetaLimit.theta_lower`・`ThetaLimit.tuning_all`・`ThetaLimit.tuning_all_pos`・`ThetaLimit.volV_pos` |
| 21-07 | `Tuning.ThetaEnvelopeV2` | `ThetaLimit.envelope_max_sol`・`ThetaLimit.thetaLow`・`ThetaLimit.thetaLow_mono`・`ThetaLimit.theta_gt_neg_one` |
| 21-07 | `Tuning.ThetaRatioV2` | `ThetaLimit.flat_exists_10`・`ThetaLimit.ratio_tendsto_zero` |
| 21-07 | `Tuning.ThetaRateV2` | `ThetaLimit.phi_theta_eq`・`ThetaLimit.tendsto_logratio_div` |
| 21-07 | `Tuning.ThetaContV1` | `ThetaTuning.ZW_continuous`・`ThetaTuning.ZW_zero`・`ThetaTuning.thetaM_continuous`・`ThetaTuning.thetaM_zero`・`ThetaTuning.tuning_exists`・`ThetaTuning.tuning_max_exists` |
| 21-07 | `Blocks.TheoremEV2` | `TwistBlocks.thetaM` |
| 21-07 | `Blocks.ThickFloorThetaPosV1` | `TwistBlocks.theta_nonneg` |
| 21-07 | `Tuning.NoFlatTwistV2` | `TwistFlat.defect11`・`TwistFlat.defect11_floor`・`TwistFlat.minDefect11_pos`・`TwistFlat.no_flat_twist11` |
| 21-07 | `Tuning.DefectTwoV1` | `TwistFloor.Smin_sym_half`・`TwistFloor.defect11_ge_two`・`TwistFloor.defect11_sym_half`・`TwistFloor.defect11_uniform_half`・`TwistFloor.logratio_limit_half` |
| 21-07 | `Tuning.DefectFloorV1` | `TwistFloor.no_floor_10` |
| 21-07 | `Wilson.SU2TwistV2` | `TwistedWilson.ZW` |
| 21-08 | `Covering.IneqV10` | `CoveringInequality.covering_ineq`・`CoveringInequality.dominated_covering_ineq`・`CoveringInequality.invariant_dominated`・`CoveringInequality.mon_ineq` |
| 21-08 | `Blocks.ThickFloorThetaPosV1` | `HalfSplit.Z1_le_Z0`・`TwistBlocks.theta_nonneg` |
| 21-08 | `Blocks.ThickFloorPolyakovFloorV1` | `HalfSplit.polyakov_pair_floor` |
| 21-08 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.polyakov_pair_theta` |
| 21-08 | `PolyT.MainV1` | `PolyakovT.half_pair_tanh`・`PolyakovT.polyakov_pair_all` |
| 21-08 | `PolyT.AllMV2` | `PolyakovT.polyakov_pair_evenM` |
| 21-08 | `PolyT.FlipV2` | `PolyakovT.polyakov_pair_evenNM` |
| 21-08 | `Tuning.ThetaLimitV2` | `ThetaLimit.tendsto_theta_one`・`ThetaLimit.tuning_all` |
| 21-08 | `Tuning.ThetaContV1` | `ThetaTuning.thetaM_continuous` |
| 21-08 | `Blocks.VacuumV1` | `TwistBlocks.SN_bounds` |
| 21-08 | `Blocks.StageTwoV2` | `TwistBlocks.block_bound_abs` |
| 21-08 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.thick_vortex_floor` |
| 21-08 | `Blocks.ThickFloorSignedV1` | `TwistBlocks.thick_vortex_floor_signed` |
| 21-08 | `Blocks.ThickFloorTwoV1` | `TwistBlocks.thick_vortex_floor_two` |
| 21-08 | `Tuning.NoFlatTwistV2` | `TwistFlat.no_flat_twist11` |
| 21-08 | `Tuning.DefectTwoV1` | `TwistFloor.defect11_sym_half` |
| 21-08 | `Wilson.FloorV3` | `TwistedWilson.thin_vortex_floor` |
| 21-08 | `Wilson.SU2TwistV2` | `TwistedWilson.twisted_vortex_bound` |
| 21-08 | `Wilson.AbsV1` | `TwistedWilson.twisted_vortex_bound_abs` |
| 21-08 | `VortexCert.CertN4V1` | `VortexCert.SN_four_lt`・`VortexCert.Svortex_four_four_le` |
| 21-08 | `VortexCert.CertN3V1` | `VortexCert.SN_three_lt`・`VortexCert.Svortex_three_eight_le` |
| 21-08 | `VortexCert.CertN2V1` | `VortexCert.SN_two_lt`・`VortexCert.Svortex_two_eight_le` |
| 21-08 | `VortexCert.CoreV3` | `VortexCert.Svortex_le_of_cert` |
| 21-08 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos`・`VortexPos.Svortex_ge_unif` |
| 22-00 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 22-00 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| 22-00 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| 22-01 | `FoldChess.CapV1` | `FoldCap.ballQ_ge` |
| 22-01 | `FoldChess.ExplicitV1` | `FoldCap.q_lt_one_explicit`・`FoldCap.rarity_explicit` |
| 22-01 | `FoldChess.BridgeV1` | `FoldChess.chess_data` |
| 22-01 | `FoldChess.FourDimV1` | `FoldChess.chess_four` |
| 22-01 | `FoldChess.OneDimV1` | `FoldChess.chess_one` |
| 22-01 | `FoldChess.RarityEvenV1` | `FoldEntropy.Zw_ge`・`FoldEntropy.ballQ` |
| 22-01 | `FoldChess.RarityAllV1` | `FoldEntropy.bigP` |
| 22-01 | `FoldChess.MixCV1` | `FoldMix.action_le_mix`・`FoldMix.dataMix` |
| 22-01 | `FoldChess.MixAllV1` | `FoldMix.rarity_all_mix`・`FoldMix.rarity_orient` |
| 22-01 | `FoldChess.MixAllUniformV1` | `FoldMix.rarity_uniform_all_mix` |
| 22-01 | `FoldChess.PeierlsEvenV1` | `FoldPeierls.Zw` |
| 22-01 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| 22-01 | `FoldChess.WilsonChessV1` | `FoldWilson.data`・`FoldWilson.wilson_chessboard_even` |
| 22-01 | `Lattice.TorusDecV2` | `TorusRP.wilsonMeasure` |
| 22-02 | `FoldChess.CapV1` | `FoldCap.ballQ_ge` |
| 22-02 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 22-02 | `FoldChess.RarityEvenV1` | `FoldEntropy.Zw_ge` |
| 22-02 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| 22-02 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| 26-12 | `Blocks.ThickFloorThetaPosV1` | `TwistBlocks.theta_nonneg` |
| 26-12 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.thick_vortex_floor` |
| 26-12 | `Wilson.FloorV3` | `TwistedWilson.thin_vortex_floor` |
| 26-12 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos` |
| 28-01 | `UVChain.BoxChainV1` | `BoxWalk.boxPaths`・`BoxWalk.boxW`・`BoxWalk.chain_end_to_end_box`・`ChainBlockMap.blockMap`・`ChainBlockMap.chain_end_to_end_blockMap`・`ChainBlockMap.continuous_blockMap`・`ChainBlockMap.down`・`ChainBlockMap.hcons_blockMap`・`ChainBlockMap.νP`・`TransientChainError.CouplingStepsTransientE`・`WeakUltravioletExistence.BlockConclusion`・`WeakUltravioletExistence.ObservableConclusion`・`WeakUltravioletExistence.Representation`・`WeakUltravioletExistence.exists_common_subseq`・`WeakUltravioletExistence.limit_consistent` |
| 28-01 | `Chain.BoxWilsonV2` | `BoxWalk.chain_end_to_end_box_wilson2`・`BoxWalk.continuous_reflCfg`・`BoxWalk.reflCfg`・`BoxWalk.stripSet`・`BoxWalk.stripSet_witness`・`BoxWalk.wilson_hΘp` |
| 28-01 | `Peierls.CubeWeakV3` | `CubeWeak.Bd` |
| 28-01 | `T1.Split1` | `HsSplit.HR` |
| 28-01 | `SkewOrbit.Probe` | `SkewOrbitProbe.Ex.hr` |
| 28-01 | `Blocks.ThickFloorSquareV1` | `TwistBlocks.h0` |
| 28-02 | `Infvol.CylDetV2` | `CylDet.subseq_limit_eq` |
| 28-02 | `SkewOrbit.LimitV1` | `SkewOrbit.Admissible`・`SkewOrbit.IsOrbit`・`SkewOrbit.coarse_cauchy`・`SkewOrbit.coarse_rate`・`SkewOrbit.coarse_step`・`SkewOrbit.coarse_step_mid`・`SkewOrbit.coarse_tendsto`・`SkewOrbit.coarse_tendsto_mid`・`SkewOrbit.limit_independent`・`SkewOrbit.limit_independent_mid`・`SkewOrbit.midpoint_admissible`・`SkewOrbit.observable_tendsto`・`SkewOrbit.orbit_compare`・`SkewOrbit.step`・`SkewOrbit.two_point_bound` |
| 28-02 | `SkewOrbit.Probe` | `SkewOrbitProbe.Ex.admissible`・`SkewOrbitProbe.Ex.bare_not_cauchy`・`SkewOrbitProbe.Ex.coarse_converges`・`SkewOrbitProbe.Ex.hT`・`SkewOrbitProbe.Ex.hr`・`SkewOrbitProbe.Ex.matching_needed`・`SkewOrbitProbe.Sharp.sharp`・`SkewOrbitProbe.coarse_tendsto_window`・`SkewOrbitProbe.limit_independent_window`・`SkewOrbitProbe.one_step_after`・`SkewOrbitProbe.rate_window`・`SkewOrbitProbe.theta_exists_iff` |
| 28-02 | `UVChain.BoxChainV1` | `WeakUltravioletExistence.tendsto_of_summable_increments`・`WeakUltravioletExistence.weak_uv_observable_full` |
| 28-03 | `Band.FiniteSize` | `BandFiniteSize.Hyp`・`BandFiniteSize.doubling` |
| 28-03 | `Band.Reduction` | `BandReduction.Hyp`・`BandReduction.area_exponent`・`BandReduction.band_reduction`・`BandReduction.iterate`・`BandReduction.jump`・`BandReduction.step` |
| 28-03 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| 28-03 | `Lattice.GapG` | `OSGap.Datum`・`OSGap.Datum.HasMassGap`・`OSGap.Datum.hasMassGap_of_decay`・`OSGap.massGap_of_measures_sub` |
| 28-04 | `UVChain.BoxChainV1` | `BoxWalk.chain_end_to_end_box`・`ChainBlockMap.chain_end_to_end_blockMap`・`WeakUltravioletExistence.BlockConclusion` |
| 28-04 | `Uniform.F3Assembly` | `F3Conditional.f3_conditional` |
| 28-04 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| 28-04 | `RealSpace.ThmR` | `RealSpaceThmR.thmR_form` |
| 28-04 | `Lattice.TorusDecV2` | `TorusRP.wilson_rp` |
| A-04 | `T10.Alias1` | `AliasPoinc.coupling_converges_gamma_closed` |
| A-04 | `Infvol.AllNV1` | `AllN.wilson_infvol_allN` |
| A-04 | `Band.FiniteSize` | `BandFiniteSize.doubling` |
| A-04 | `Band.Reduction` | `BandReduction.band_reduction`・`BandReduction.step` |
| A-04 | `Infvol.BindAllUV1` | `Bind.T_range_gauge_all` |
| A-04 | `Lift.RetractOne1` | `BlockLinearKernel.blockMap_exp_linear_le_one` |
| A-04 | `BoxWalk.BoxL1` | `BoxWalk.boxMap_gauge`・`BoxWalk.boxMap_local` |
| A-04 | `UVChain.BoxChainV1` | `BoxWalk.chain_end_to_end_box`・`ChainBlockMap.chain_end_to_end_blockMap`・`ChainBlockMap.continuous_blockMap`・`WeakUltravioletExistence.BlockConclusion`・`WeakUltravioletExistence.exists_common_subseq`・`WeakUltravioletExistence.limit_consistent`・`WeakUltravioletExistence.tendsto_of_summable_increments`・`WeakUltravioletExistence.weak_uv_observable_full` |
| A-04 | `Chain.BoxWilsonV2` | `BoxWalk.chain_end_to_end_box_wilson2` |
| A-04 | `Covering.IneqV10` | `CoveringInequality.covering_ineq`・`CoveringInequality.dominated_covering_ineq`・`CoveringInequality.invariant_dominated`・`CoveringInequality.mon_ineq` |
| A-04 | `FermionLane.TimeReflV10b` | `CubicSym.physDirac_det_trefl` |
| A-04 | `FermionLane.HyperSymV10a` | `CubicSym.wfProb_hypercubic_generators` |
| A-04 | `FermionLane.LatticeSymV10a` | `CubicSym.wfProb_lattice_generators` |
| A-04 | `FoldChess.ExplicitV1` | `FoldCap.rarity_explicit` |
| A-04 | `FoldChess.QuarterCV1` | `FoldQuarter.rarity_uniform4` |
| A-04 | `FoldChess.WilsonChessV1` | `FoldWilson.wilson_chessboard_even` |
| A-04 | `Infvol.FullTV2` | `FullT.wilson_Tpos_full` |
| A-04 | `FermionLane.GaugeDetV9c` | `GaugeDet.physDirac_det_conj` |
| A-04 | `Lattice.GaugeSectorV1` | `GaugeZ.wilson_massGap_gauge_exists` |
| A-04 | `Blocks.ThickFloorThetaPosV1` | `HalfSplit.Z1_le_Z0`・`TwistBlocks.theta_nonneg` |
| A-04 | `Blocks.ThickFloorPolyakovFloorV1` | `HalfSplit.polyakov_pair_floor` |
| A-04 | `Blocks.ThickFloorPolyakovV1` | `HalfSplit.polyakov_pair_theta` |
| A-04 | `T1.Final2` | `HsSplit.lower_side_c`・`NearAliasB.bracket_Qpos_split` |
| A-04 | `Infvol.MainV2` | `InfMain2.wilson_infvol_main2` |
| A-04 | `Infvol.CauchyV2` | `InfVol.wilson_infvol_unique` |
| A-04 | `Push.Join7` | `LatticeFace.lattice_face_T1h` |
| A-04 | `Push.Rec1` | `LatticeRec.lattice_bracket` |
| A-04 | `Sweep.DistDecayV1` | `LinkSpec.wilson_cov_dist` |
| A-04 | `Lattice.MidRPV2` | `MidRP.wilson_rp_mid` |
| A-04 | `Lattice.GapG` | `OSGap.Datum.hasMassGap_of_decay`・`OSGap.massGap_of_measures_sub` |
| A-04 | `Lam.Up1` | `OSUpQpos.Gs_le_G0`・`OSUpQpos.os_up_Qpos`・`OneStepBridge.Mfam_P_le_row` |
| A-04 | `FreeOS.QposUpV1` | `OneStepLower.bracket_Qpos_free` |
| A-04 | `Peierls.PermRPV2` | `PeierlsPerm.wilson_rp_dir` |
| A-04 | `PolyT.MainV1` | `PolyakovT.half_pair_tanh`・`PolyakovT.polyakov_pair_all` |
| A-04 | `PolyT.AllMV2` | `PolyakovT.polyakov_pair_evenM` |
| A-04 | `PolyT.FlipV2` | `PolyakovT.polyakov_pair_evenNM` |
| A-04 | `Lift.PushCov1` | `PushCov.lattice_pushCov` |
| A-04 | `SkewOrbit.LimitV1` | `SkewOrbit.Admissible`・`SkewOrbit.IsOrbit`・`SkewOrbit.coarse_cauchy`・`SkewOrbit.coarse_rate`・`SkewOrbit.coarse_step`・`SkewOrbit.coarse_tendsto`・`SkewOrbit.limit_independent`・`SkewOrbit.midpoint_admissible`・`SkewOrbit.observable_tendsto`・`SkewOrbit.orbit_compare`・`SkewOrbit.two_point_bound` |
| A-04 | `SkewOrbit.Probe` | `SkewOrbitProbe.one_step_after`・`SkewOrbitProbe.rate_window`・`SkewOrbitProbe.theta_exists_iff` |
| A-04 | `Lam.Torus1` | `TorusLam.stage_tau_17` |
| A-04 | `Lattice.TorusDecV2` | `TorusRP.wilsonMeasure`・`TorusRP.wilson_refl_symm`・`TorusRP.wilson_rp`・`TorusRP.wilson_strong_coupling` |
| A-04 | `Infvol.TransV2` | `TransI.wilson_infvol_translation` |
| A-04 | `Blocks.StageTwoV2` | `TwistBlocks.block_bound_abs` |
| A-04 | `Blocks.ThickFloorTorusV1` | `TwistBlocks.thick_vortex_floor` |
| A-04 | `Blocks.ThickFloorSignedV1` | `TwistBlocks.thick_vortex_floor_signed` |
| A-04 | `Blocks.ThickFloorTwoV1` | `TwistBlocks.thick_vortex_floor_two` |
| A-04 | `Wilson.FloorV3` | `TwistedWilson.thin_vortex_floor` |
| A-04 | `Wilson.SU2TwistV2` | `TwistedWilson.twisted_vortex_bound` |
| A-04 | `Wilson.AbsV1` | `TwistedWilson.twisted_vortex_bound_abs` |
| A-04 | `VortexCert.CertN4V1` | `VortexCert.SN_four_lt`・`VortexCert.Svortex_four_four_le` |
| A-04 | `VortexCert.CertN3V1` | `VortexCert.SN_three_lt`・`VortexCert.Svortex_three_eight_le` |
| A-04 | `VortexCert.CertN2V1` | `VortexCert.SN_two_lt`・`VortexCert.Svortex_two_eight_le` |
| A-04 | `VortexCert.CoreV3` | `VortexCert.Svortex_le_of_cert` |
| A-04 | `Blocks.ThickFloorPositiveV1` | `VortexPos.SN_pos`・`VortexPos.Svortex_ge_unif` |
| A-04 | `Bridge.WilsonTwistV1` | `WilsonBridge.integral_wilsonMeasure`・`WilsonBridge.wilsonMeasure_eq_map`・`WilsonBridge.wilsonMeasure_univ` |
| A-04 | `Bridge.TimeAlignV1` | `WilsonBridgeT.refl_toBallT`・`WilsonBridgeT.wilsonMeasure_eq_mapT` |
| A-04 | `Bridge.VortexV1` | `WilsonBridgeV.vortex_ratio_eq` |
| A-04 | `Box.FermionBaseV8a` | `WilsonGauge.gaugeMeasure`・`WilsonGauge.wilsonMeasure_eq_map` |
| A-04 | `Gauge.WilsonFullV7c` | `WilsonGauge.partition_pos_wilson_full`・`WilsonGauge.site_reflection_positive_wilson_full` |
| A-04 | `Lattice.ClusterV1` | `WilsonLimit.cluster_limit` |
| A-04 | `Lattice.WilsonDobV1` | `WilsonLimit.wilson_massGap_dob`・`WilsonLimit.wilson_massGap_dob_exists` |
| A-04 | `Lattice.NondegV3` | `WilsonLimit.wilson_massGap_nondegenerate` |

## この束が言っていないこと

**この束の定理は四次元の Yang–Mills の存在も質量ギャップも示していない。**多くの定理は有限の格子（トーラス）の上の具体の対象についての言明か、名を付けた仮定からの含意です。格子間隔は 1 に固定で、連続極限については何も言いません。面積則と渦の自由エネルギーの上界は強結合の窓の中の言明で、渦の比の極限と合わせは格子の大きさを止めた言明です。仮定の欄が実際の格子ゲージ理論で成り立つこと、章の本文の段が正しく言明に写されていることは、章の本文の側の議論です。機械検査が保証するのは、Lean で述べた言明（仮定から結論へ）の正しさだけです。
