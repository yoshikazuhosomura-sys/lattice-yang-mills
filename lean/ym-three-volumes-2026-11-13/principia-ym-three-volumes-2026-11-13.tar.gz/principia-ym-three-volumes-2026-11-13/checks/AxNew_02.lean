-- 三巻の版で足した宣言（章が挙げるもの）の名の確かめ（#check）と公理（#print axioms）。群 2 / 2
import Tuning.NoFlatTwistV2
import Tuning.QuadTwoV1
import Tuning.ThetaContV1
import Tuning.ThetaEnvelopeV2
import Tuning.ThetaLimitV2
import Tuning.ThetaRateV2
import Tuning.ThetaRatioV2

-- Tuning.NoFlatTwistV2
#check @TwistFlat.defect11
#print axioms TwistFlat.defect11
#check @TwistFlat.defect11_floor
#print axioms TwistFlat.defect11_floor
#check @TwistFlat.minDefect11_pos
#print axioms TwistFlat.minDefect11_pos
#check @TwistFlat.no_flat_twist11
#print axioms TwistFlat.no_flat_twist11
-- Tuning.QuadTwoV1
#check @QuadFloor.quad_floor_two
#print axioms QuadFloor.quad_floor_two
-- Tuning.ThetaContV1
#check @ThetaTuning.ZW_continuous
#print axioms ThetaTuning.ZW_continuous
#check @ThetaTuning.ZW_zero
#print axioms ThetaTuning.ZW_zero
#check @ThetaTuning.thetaM_continuous
#print axioms ThetaTuning.thetaM_continuous
#check @ThetaTuning.thetaM_zero
#print axioms ThetaTuning.thetaM_zero
#check @ThetaTuning.tuning_exists
#print axioms ThetaTuning.tuning_exists
#check @ThetaTuning.tuning_max_exists
#print axioms ThetaTuning.tuning_max_exists
-- Tuning.ThetaEnvelopeV2
#check @ThetaLimit.envelope_max_sol
#print axioms ThetaLimit.envelope_max_sol
#check @ThetaLimit.thetaLow
#print axioms ThetaLimit.thetaLow
#check @ThetaLimit.thetaLow_mono
#print axioms ThetaLimit.thetaLow_mono
#check @ThetaLimit.theta_gt_neg_one
#print axioms ThetaLimit.theta_gt_neg_one
-- Tuning.ThetaLimitV2
#check @ThetaLimit.Smin
#print axioms ThetaLimit.Smin
#check @ThetaLimit.Z10_ge
#print axioms ThetaLimit.Z10_ge
#check @ThetaLimit.Z11_le
#print axioms ThetaLimit.Z11_le
#check @ThetaLimit.exists_theta_gt
#print axioms ThetaLimit.exists_theta_gt
#check @ThetaLimit.sanity_half
#print axioms ThetaLimit.sanity_half
#check @ThetaLimit.tendsto_theta_one
#print axioms ThetaLimit.tendsto_theta_one
#check @ThetaLimit.theta_le_one
#print axioms ThetaLimit.theta_le_one
#check @ThetaLimit.theta_lower
#print axioms ThetaLimit.theta_lower
#check @ThetaLimit.tuning_all
#print axioms ThetaLimit.tuning_all
#check @ThetaLimit.tuning_all_pos
#print axioms ThetaLimit.tuning_all_pos
#check @ThetaLimit.volV_pos
#print axioms ThetaLimit.volV_pos
-- Tuning.ThetaRateV2
#check @ThetaLimit.phi_theta_eq
#print axioms ThetaLimit.phi_theta_eq
#check @ThetaLimit.tendsto_logratio_div
#print axioms ThetaLimit.tendsto_logratio_div
-- Tuning.ThetaRatioV2
#check @ThetaLimit.flat_exists_10
#print axioms ThetaLimit.flat_exists_10
#check @ThetaLimit.ratio_tendsto_zero
#print axioms ThetaLimit.ratio_tendsto_zero
