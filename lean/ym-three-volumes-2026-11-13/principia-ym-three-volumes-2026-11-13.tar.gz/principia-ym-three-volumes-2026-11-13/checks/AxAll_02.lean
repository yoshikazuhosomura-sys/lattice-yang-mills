-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 2 / 6
import Blocks.ThickFloorTwoV1
import Blocks.UniformV1
import Blocks.VacuumV1
import Box.FermionBaseV8a
import Box.FermionChainV8b
import Box.FermionTunedV8b
import Chain.BoxWilsonV2
import Covering.IneqV10
import Fermion.SliceWilsonV6d
import FermionLane.CubicCliffV10b
import FermionLane.CubicPhysV10b
import FermionLane.GaugeDetV9c
import FermionLane.GaugeV9
import FermionLane.HyperSymV10a
import FermionLane.LatticeSymV10a
import FermionLane.TimeReflV10b
import FermionLane.TimeRotV10h
import FermionLane.TimeShiftV9h
import FermionLane.TransV9d
import FoldChess.BridgeV1
import FoldChess.FourDimV1
import FoldChess.OneDimV1
import FreeOS.QposUpV1
import Gauge.DirectEntriesV7a
import Gauge.WilsonFullV7c
import Lam.Face1
import Lattice.GapG
import Lift.PerR3p1
import Peierls.CubeIterV3
import Plane.TwistedZ2V2

-- Blocks.ThickFloorTwoV1
#check @TwistBlocks.thick_vortex_floor_two
#print axioms TwistBlocks.thick_vortex_floor_two
#check @TwistBlocks.thick_vortex_floor_two_rate_lt
#print axioms TwistBlocks.thick_vortex_floor_two_rate_lt
-- Blocks.UniformV1
#check @TwistBlocks.Dmax_le
#print axioms TwistBlocks.Dmax_le
-- Blocks.VacuumV1
#check @TwistBlocks.vac_term
#print axioms TwistBlocks.vac_term
#check @TwistBlocks.Svortex_le
#print axioms TwistBlocks.Svortex_le
#check @TwistBlocks.SN_bounds
#print axioms TwistBlocks.SN_bounds
-- Box.FermionBaseV8a
#check @WilsonGauge.gaugeMeasure
#print axioms WilsonGauge.gaugeMeasure
#check @WilsonGauge.action_add_wilsonAction
#print axioms WilsonGauge.action_add_wilsonAction
#check @WilsonGauge.map_pull
#print axioms WilsonGauge.map_pull
#check @WilsonGauge.wilsonMeasure_eq_map
#print axioms WilsonGauge.wilsonMeasure_eq_map
#check @WilsonGauge.refl_pull
#print axioms WilsonGauge.refl_pull
#check @WilsonGauge.fermWeight_nonneg
#print axioms WilsonGauge.fermWeight_nonneg
#check @WilsonGauge.continuous_fermWeight
#print axioms WilsonGauge.continuous_fermWeight
#check @WilsonGauge.wf_partition_pos
#print axioms WilsonGauge.wf_partition_pos
#check @WilsonGauge.wfWeight
#print axioms WilsonGauge.wfWeight
#check @WilsonGauge.wfMeasure
#print axioms WilsonGauge.wfMeasure
#check @WilsonGauge.wfWeight_nonneg
#print axioms WilsonGauge.wfWeight_nonneg
#check @WilsonGauge.wfProb
#print axioms WilsonGauge.wfProb
#check @WilsonGauge.wfProb_isProbability
#print axioms WilsonGauge.wfProb_isProbability
-- Box.FermionChainV8b
#check @BoxFermion.fermProbBox
#print axioms BoxFermion.fermProbBox
-- Box.FermionTunedV8b
#check @FermionChain.CouplingMassSteps.hε
#print axioms FermionChain.CouplingMassSteps.hε
-- Chain.BoxWilsonV2
#check @BoxWalk.wilson_hΘp
#print axioms BoxWalk.wilson_hΘp
#check @BoxWalk.continuous_reflCfg
#print axioms BoxWalk.continuous_reflCfg
#check @BoxWalk.chain_end_to_end_box_wilson2
#print axioms BoxWalk.chain_end_to_end_box_wilson2
#check @BoxWalk.stripSet_witness
#print axioms BoxWalk.stripSet_witness
#check @BoxWalk.stripSet
#print axioms BoxWalk.stripSet
#check @BoxWalk.reflCfg
#print axioms BoxWalk.reflCfg
-- Covering.IneqV10
#check @CoveringInequality.IsSignChar
#print axioms CoveringInequality.IsSignChar
#check @CoveringInequality.Z
#print axioms CoveringInequality.Z
#check @CoveringInequality.Z_flip_le
#print axioms CoveringInequality.Z_flip_le
#check @CoveringInequality.covering_ineq
#print axioms CoveringInequality.covering_ineq
#check @CoveringInequality.covering_ratio
#print axioms CoveringInequality.covering_ratio
#check @CoveringInequality.vfe_cover_le
#print axioms CoveringInequality.vfe_cover_le
#check @CoveringInequality.Z_mul_Z
#print axioms CoveringInequality.Z_mul_Z
#check @CoveringInequality.mon_ineq
#print axioms CoveringInequality.mon_ineq
#check @CoveringInequality.mon_ratio
#print axioms CoveringInequality.mon_ratio
#check @CoveringInequality.Z_char_shift
#print axioms CoveringInequality.Z_char_shift
#check @CoveringInequality.dominated_covering_ineq
#print axioms CoveringInequality.dominated_covering_ineq
#check @CoveringInequality.invariant_dominated
#print axioms CoveringInequality.invariant_dominated
#check @CoveringInequality.card_mul_integral_exp
#print axioms CoveringInequality.card_mul_integral_exp
-- Fermion.SliceWilsonV6d
#check @FermionSU2Config.PhysLink
#print axioms FermionSU2Config.PhysLink
#check @FermionSU2Config.SU2
#print axioms FermionSU2Config.SU2
#check @FermionSliceBlock.sc
#print axioms FermionSliceBlock.sc
#check @FermionSU2Config.quatMat
#print axioms FermionSU2Config.quatMat
#check @FermionSliceBlock.std4
#print axioms FermionSliceBlock.std4
#check @FermionSliceBlock.stdSlice
#print axioms FermionSliceBlock.stdSlice
#check @FermionSliceBlock.torusX
#print axioms FermionSliceBlock.torusX
#check @FermionSliceBlock.torusLink
#print axioms FermionSliceBlock.torusLink
#check @FermionSliceBlock.eps
#print axioms FermionSliceBlock.eps
#check @FermionSliceBlock.gammaT
#print axioms FermionSliceBlock.gammaT
#check @FermionSliceBlock.gammaSp
#print axioms FermionSliceBlock.gammaSp
#check @FermionSliceReflection.wilson_weight_nonneg_std4
#print axioms FermionSliceReflection.wilson_weight_nonneg_std4
#check @FermionSliceReflection.wilson_weight_nonneg_torus
#print axioms FermionSliceReflection.wilson_weight_nonneg_torus
#check @FermionSliceBlock.wilsonPlane_posDef
#print axioms FermionSliceBlock.wilsonPlane_posDef
#check @FermionSliceReflection.site_reflection_positive_phys
#print axioms FermionSliceReflection.site_reflection_positive_phys
-- FermionLane.CubicCliffV10b
#check @CubicSym.cliffOp_conj
#print axioms CubicSym.cliffOp_conj
#check @CubicSym.det_cliffOp_perm
#print axioms CubicSym.det_cliffOp_perm
-- FermionLane.CubicPhysV10b
#check @CubicSym.rotPhys
#print axioms CubicSym.rotPhys
#check @CubicSym.reflPhys
#print axioms CubicSym.reflPhys
-- FermionLane.GaugeDetV9c
#check @GaugeDet.physDirac_det_conj
#print axioms GaugeDet.physDirac_det_conj
-- FermionLane.GaugeV9
#check @BoxFermion.conjPhys
#print axioms BoxFermion.conjPhys
-- FermionLane.HyperSymV10a
#check @CubicSym.wfProb_hypercubic_generators
#print axioms CubicSym.wfProb_hypercubic_generators
-- FermionLane.LatticeSymV10a
#check @CubicSym.wfProb_lattice_generators
#print axioms CubicSym.wfProb_lattice_generators
-- FermionLane.TimeReflV10b
#check @CubicSym.treflPhys
#print axioms CubicSym.treflPhys
#check @CubicSym.physDirac_det_trefl
#print axioms CubicSym.physDirac_det_trefl
-- FermionLane.TimeRotV10h
#check @CubicSym.trotPhys
#print axioms CubicSym.trotPhys
-- FermionLane.TimeShiftV9h
#check @TimeShift.tshiftPhys
#print axioms TimeShift.tshiftPhys
-- FermionLane.TransV9d
#check @GaugeDet.transPhys
#print axioms GaugeDet.transPhys
-- FoldChess.BridgeV1
#check @FoldChess.Data4.one
#print axioms FoldChess.Data4.one
#check @FoldChess.chess_data
#print axioms FoldChess.chess_data
-- FoldChess.FourDimV1
#check @FoldChess.chess_four
#print axioms FoldChess.chess_four
-- FoldChess.OneDimV1
#check @FoldChess.chess_one
#print axioms FoldChess.chess_one
-- FreeOS.QposUpV1
#check @TorusFourier.Cop
#print axioms TorusFourier.Cop
#check @OneStepBridge.Mfam
#print axioms OneStepBridge.Mfam
#check @OneStepET.omF
#print axioms OneStepET.omF
#check @OneStepBridge.Pfam
#print axioms OneStepBridge.Pfam
#check @OneStepFinal.Qpos
#print axioms OneStepFinal.Qpos
#check @OneStepBridge.thR
#print axioms OneStepBridge.thR
#check @OneStepFinal.rqPos
#print axioms OneStepFinal.rqPos
#check @OneStepBridge.AM
#print axioms OneStepBridge.AM
#check @OneStepLower.lower_side
#print axioms OneStepLower.lower_side
#check @OneStepLower.bracket_Qpos_free
#print axioms OneStepLower.bracket_Qpos_free
#check @OneStepBridge.Mfam_P_le
#print axioms OneStepBridge.Mfam_P_le
-- Gauge.DirectEntriesV7a
#check @WilsonGauge.physDirac_apply
#print axioms WilsonGauge.physDirac_apply
-- Gauge.WilsonFullV7c
#check @WilsonGauge.wilsonAction
#print axioms WilsonGauge.wilsonAction
#check @WilsonGauge.thetaPhys
#print axioms WilsonGauge.thetaPhys
#check @WilsonGauge.plaqE
#print axioms WilsonGauge.plaqE
#check @WilsonGauge.physSp
#print axioms WilsonGauge.physSp
#check @WilsonGauge.physT
#print axioms WilsonGauge.physT
#check @WilsonGauge.physDirac
#print axioms WilsonGauge.physDirac
#check @WilsonGauge.fermWeight
#print axioms WilsonGauge.fermWeight
#check @WilsonGauge.physDirac_eq_split
#print axioms WilsonGauge.physDirac_eq_split
#check @WilsonGauge.partition_pos_wilson_full
#print axioms WilsonGauge.partition_pos_wilson_full
#check @WilsonGauge.site_reflection_positive_wilson_full
#print axioms WilsonGauge.site_reflection_positive_wilson_full
#check @WilsonGauge.wilsonAction_split
#print axioms WilsonGauge.wilsonAction_split
#check @WilsonGauge.plaqE_reflect
#print axioms WilsonGauge.plaqE_reflect
-- Lam.Face1
#check @FaceTorus.torus_face_upper
#print axioms FaceTorus.torus_face_upper
#check @FaceTorus.torus_face_diag
#print axioms FaceTorus.torus_face_diag
#check @FaceTorus.sum_rt_quarter
#print axioms FaceTorus.sum_rt_quarter
-- Lattice.GapG
#check @OrbitGrowth.contraction_of_bounded
#print axioms OrbitGrowth.contraction_of_bounded
#check @OSGap.Datum
#print axioms OSGap.Datum
#check @OSGap.Datum.Hilb
#print axioms OSGap.Datum.Hilb
#check @OSGap.Datum.T
#print axioms OSGap.Datum.T
#check @OSGap.Datum.Ω
#print axioms OSGap.Datum.Ω
#check @OSGap.Datum.contraction
#print axioms OSGap.Datum.contraction
#check @OSGap.Datum.T_symm
#print axioms OSGap.Datum.T_symm
#check @OSGap.Datum.T_Ω
#print axioms OSGap.Datum.T_Ω
#check @OSGap.Datum.norm_Ω
#print axioms OSGap.Datum.norm_Ω
#check @OSGap.measureDatum
#print axioms OSGap.measureDatum
#check @OSGap.exampleDatum
#print axioms OSGap.exampleDatum
#check @OSGap.example_opNorm_eq
#print axioms OSGap.example_opNorm_eq
#check @OSGap.Datum.HasMassGap
#print axioms OSGap.Datum.HasMassGap
#check @OSGap.Datum.hasMassGap_of_decay
#print axioms OSGap.Datum.hasMassGap_of_decay
#check @OSGap.Datum.decay_of_hasMassGap
#print axioms OSGap.Datum.decay_of_hasMassGap
#check @OSGap.Datum.B
#print axioms OSGap.Datum.B
#check @OSGap.Datum.symm
#print axioms OSGap.Datum.symm
#check @OSGap.Datum.one_one
#print axioms OSGap.Datum.one_one
#check @OSGap.Datum.bounded
#print axioms OSGap.Datum.bounded
#check @OSGap.vacProj
#print axioms OSGap.vacProj
#check @OrbitGrowth.pairingForm
#print axioms OrbitGrowth.pairingForm
#check @OSGap.Datum.opNorm_gap
#print axioms OSGap.Datum.opNorm_gap
#check @OSGap.massGap_of_measures_sub
#print axioms OSGap.massGap_of_measures_sub
-- Lift.PerR3p1
#check @PerR3.N
#print axioms PerR3.N
#check @PerR3.D
#print axioms PerR3.D
-- Peierls.CubeIterV3
#check @CubeChess.V
#print axioms CubeChess.V
-- Plane.TwistedZ2V2
#check @TwistedPlane.Z_plane
#print axioms TwistedPlane.Z_plane
#check @TwistedPlane.chi2
#print axioms TwistedPlane.chi2
#check @TwistedPlane.Z_plane_const
#print axioms TwistedPlane.Z_plane_const
#check @TwistedPlane.Z_plane_flip
#print axioms TwistedPlane.Z_plane_flip
#check @TwistedPlane.plane_flip_ratio
#print axioms TwistedPlane.plane_flip_ratio
#check @TwistedPlane.sum_FA_eq_zero
#print axioms TwistedPlane.sum_FA_eq_zero
#check @TwistedPlane.prod_chi2_univ
#print axioms TwistedPlane.prod_chi2_univ
