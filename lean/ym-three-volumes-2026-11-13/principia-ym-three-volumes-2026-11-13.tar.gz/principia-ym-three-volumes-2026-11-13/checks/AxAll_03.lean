-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 3 / 6
import BoxWalk.BoxL1
import Bridge.TimeAlignV1
import Bridge.VortexV1
import Bridge.WilsonTwistV1
import FoldChess.CapV1
import FoldChess.ExplicitV1
import FoldChess.MixAllUniformV1
import FoldChess.MixAllV1
import FoldChess.MixCV1
import FoldChess.PeierlsEvenV1
import FoldChess.QuarterCV1
import FoldChess.RarityAllV1
import FoldChess.RarityEvenV1
import FoldChess.WilsonChessV1
import Infvol.AllNV1
import Infvol.BindAllUV1
import Infvol.BoxSweepV1
import Infvol.CauchyV2
import Infvol.CylDetV2
import Infvol.FullTV2
import Infvol.MainV2
import Infvol.TransV2
import Infvol.ZHeatV2
import Lam.Torus1
import Lam.Up1
import Lattice.ClusterV1
import Lattice.GaugeFixV5
import Lattice.GaugeSectorV1
import Lattice.MidPlaneV1
import Lattice.MidRPV2

-- BoxWalk.BoxL1
#check @BoxWalk.boxMap_local
#print axioms BoxWalk.boxMap_local
#check @BoxWalk.boxMap_gauge
#print axioms BoxWalk.boxMap_gauge
-- Bridge.TimeAlignV1
#check @WilsonBridgeT.wilsonMeasure_eq_mapT
#print axioms WilsonBridgeT.wilsonMeasure_eq_mapT
#check @WilsonBridgeT.refl_toBallT
#print axioms WilsonBridgeT.refl_toBallT
#check @WilsonBridgeT.action_toBallT
#print axioms WilsonBridgeT.action_toBallT
-- Bridge.VortexV1
#check @WilsonBridgeV.vortex_ratio_eq
#print axioms WilsonBridgeV.vortex_ratio_eq
-- Bridge.WilsonTwistV1
#check @WilsonBridge.toBall
#print axioms WilsonBridge.toBall
#check @WilsonBridge.toBall_injective
#print axioms WilsonBridge.toBall_injective
#check @WilsonBridge.wilsonMeasure_eq_map
#print axioms WilsonBridge.wilsonMeasure_eq_map
#check @WilsonBridge.integral_wilsonMeasure
#print axioms WilsonBridge.integral_wilsonMeasure
#check @WilsonBridge.wilsonMeasure_univ
#print axioms WilsonBridge.wilsonMeasure_univ
-- FoldChess.CapV1
#check @FoldCap.ballQ_ge
#print axioms FoldCap.ballQ_ge
-- FoldChess.ExplicitV1
#check @FoldCap.rarity_explicit
#print axioms FoldCap.rarity_explicit
#check @FoldCap.q_lt_one_explicit
#print axioms FoldCap.q_lt_one_explicit
-- FoldChess.MixAllUniformV1
#check @FoldMix.rarity_uniform_all_mix
#print axioms FoldMix.rarity_uniform_all_mix
-- FoldChess.MixAllV1
#check @FoldMix.rarity_orient
#print axioms FoldMix.rarity_orient
#check @FoldMix.rarity_all_mix
#print axioms FoldMix.rarity_all_mix
-- FoldChess.MixCV1
#check @FoldMix.dataMix
#print axioms FoldMix.dataMix
#check @FoldMix.action_le_mix
#print axioms FoldMix.action_le_mix
-- FoldChess.PeierlsEvenV1
#check @FoldPeierls.Zw
#print axioms FoldPeierls.Zw
-- FoldChess.QuarterCV1
#check @FoldQuarter.rarity_uniform4
#print axioms FoldQuarter.rarity_uniform4
-- FoldChess.RarityAllV1
#check @FoldEntropy.bigP
#print axioms FoldEntropy.bigP
-- FoldChess.RarityEvenV1
#check @FoldEntropy.ballQ
#print axioms FoldEntropy.ballQ
#check @FoldEntropy.Zw_ge
#print axioms FoldEntropy.Zw_ge
-- FoldChess.WilsonChessV1
#check @FoldWilson.wilson_chessboard_even
#print axioms FoldWilson.wilson_chessboard_even
#check @FoldWilson.data
#print axioms FoldWilson.data
-- Infvol.AllNV1
#check @AllN.liftS
#print axioms AllN.liftS
#check @AllN.wilson_infvol_allN
#print axioms AllN.wilson_infvol_allN
#check @AllN.lift_closeS
#print axioms AllN.lift_closeS
-- Infvol.BindAllUV1
#check @Bind.T_range_gauge_all
#print axioms Bind.T_range_gauge_all
-- Infvol.BoxSweepV1
#check @LinkSpec.torus_box
#print axioms LinkSpec.torus_box
-- Infvol.CauchyV2
#check @InfVol.wilson_infvol_unique
#print axioms InfVol.wilson_infvol_unique
#check @InfVol.lift_close
#print axioms InfVol.lift_close
#check @InfVol.cauchy_cyl
#print axioms InfVol.cauchy_cyl
#check @InfVol.infvol_example
#print axioms InfVol.infvol_example
-- Infvol.CylDetV2
#check @CylDet.ext_of_cyl
#print axioms CylDet.ext_of_cyl
#check @CylDet.tendsto_of_cyl_cauchy
#print axioms CylDet.tendsto_of_cyl_cauchy
#check @CylDet.subseq_limit_eq
#print axioms CylDet.subseq_limit_eq
-- Infvol.FullTV2
#check @FullT.wilson_Tpos_full
#print axioms FullT.wilson_Tpos_full
#check @FullT.full_rp_torus
#print axioms FullT.full_rp_torus
-- Infvol.MainV2
#check @InfMain2.wilson_infvol_main2
#print axioms InfMain2.wilson_infvol_main2
-- Infvol.TransV2
#check @TransI.wilson_infvol_translation
#print axioms TransI.wilson_infvol_translation
#check @TransI.lift_shiftI_invariant
#print axioms TransI.lift_shiftI_invariant
#check @TransI.limit_shiftI_invariant
#print axioms TransI.limit_shiftI_invariant
-- Infvol.ZHeatV2
#check @ZHeat.iter_lift
#print axioms ZHeat.iter_lift
-- Lam.Torus1
#check @TorusLam.Gst
#print axioms TorusLam.Gst
#check @TorusLam.stage_tau_17
#print axioms TorusLam.stage_tau_17
-- Lam.Up1
#check @TauSplit.Gs
#print axioms TauSplit.Gs
#check @OSUpQpos.os_up_Qpos
#print axioms OSUpQpos.os_up_Qpos
#check @OSUpQpos.Gs_le_G0
#print axioms OSUpQpos.Gs_le_G0
#check @OSUpBridge.os_up
#print axioms OSUpBridge.os_up
#check @OSUpQpos.hEE_all
#print axioms OSUpQpos.hEE_all
#check @FreeStageOS.E_lt_four_s
#print axioms FreeStageOS.E_lt_four_s
#check @FreeStageOS.E_lt_four
#print axioms FreeStageOS.E_lt_four
#check @FreeStageOS.eq_lt_four
#print axioms FreeStageOS.eq_lt_four
#check @OSUpQpos.EE_bbflip
#print axioms OSUpQpos.EE_bbflip
#check @OneStepBridge.Mfam_P_le_row
#print axioms OneStepBridge.Mfam_P_le_row
#check @CouplingLimit.D_lower
#print axioms CouplingLimit.D_lower
#check @CouplingLimit.D_upper
#print axioms CouplingLimit.D_upper
#check @TauSplit.iterate_split
#print axioms TauSplit.iterate_split
#check @TauSplit.omF_chain_le
#print axioms TauSplit.omF_chain_le
-- Lattice.ClusterV1
#check @WilsonLimit.cluster_limit
#print axioms WilsonLimit.cluster_limit
#check @LinkSpec.coordLip
#print axioms LinkSpec.coordLip
-- Lattice.GaugeFixV5
#check @GaugeFix.act
#print axioms GaugeFix.act
#check @GaugeFix.integral_gaugeFix
#print axioms GaugeFix.integral_gaugeFix
-- Lattice.GaugeSectorV1
#check @GaugeZ.Wgi
#print axioms GaugeZ.Wgi
#check @GaugeZ.Winv
#print axioms GaugeZ.Winv
#check @GaugeZ.wilson_massGap_gauge_exists
#print axioms GaugeZ.wilson_massGap_gauge_exists
-- Lattice.MidPlaneV1
#check @MidRP.thM
#print axioms MidRP.thM
#check @MidRP.posM
#print axioms MidRP.posM
-- Lattice.MidRPV2
#check @MidRP.wilson_rp_mid
#print axioms MidRP.wilson_rp_mid
