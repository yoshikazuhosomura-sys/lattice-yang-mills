-- 三巻の版で足した宣言（章が挙げるもの）の名の確かめ（#check）と公理（#print axioms）。群 1 / 2
import Area.AnimalV1
import Area.AreaLowerV1
import Area.AreaMainV1
import Area.ConnPartsV1
import Area.ConnRectV1
import Area.DominanceV1
import Area.DualF2V1
import Area.ExponentMaxV1
import Area.FlipVanishV1
import Area.InfVolSubV1
import Area.InfVolV2
import Area.MixV1
import Area.PlaqBoundV1
import Area.RectMoveV1
import Area.SharpConstV1
import Area.SimpleCycleV1
import Area.VortexLinkV1
import Area.VortexMNSharpV1
import Area.VortexMNV1
import Area.VortexSanityV1
import Area.VortexStrongV1
import Area.WordBoundV1
import Block3.BoxReflV1
import Block3.BoxV1
import Block3.DownReflV1
import Block3.FlipAllV1
import Block3.LocalKV1
import Block3.RPFinalV1
import Block3.RPProbV1
import Block3.ReflBAllV1
import Block3.SignV1
import Block3.Trans3V1
import Block3.TransV1
import Block3.Tune3V1
import Tuned.HsymV1
import Tuned.TuneV1
import Tuning.ApproxStokesV1
import Tuning.DefectFloorV1
import Tuning.DefectTwoV1
import Tuning.FlatStokesV1

-- Area.AnimalV1
#check @AreaLaw.card_conn_le
#print axioms AreaLaw.card_conn_le
-- Area.AreaLowerV1
#check @AreaLaw.card_ge_of_spans_rect
#print axioms AreaLaw.card_ge_of_spans_rect
#check @AreaLaw.rectWord
#print axioms AreaLaw.rectWord
-- Area.AreaMainV1
#check @AreaLaw.area_law_wilson
#print axioms AreaLaw.area_law_wilson
#check @AreaLaw.area_law_wilson_area
#print axioms AreaLaw.area_law_wilson_area
-- Area.ConnPartsV1
#check @AreaLaw.div_plaqBd
#print axioms AreaLaw.div_plaqBd
-- Area.ConnRectV1
#check @AreaLaw.minSpan_rect_conn
#print axioms AreaLaw.minSpan_rect_conn
-- Area.DominanceV1
#check @AreaLaw.sum_superset_le
#print axioms AreaLaw.sum_superset_le
-- Area.DualF2V1
#check @AreaLaw.not_mem_span_iff_exists_sep
#print axioms AreaLaw.not_mem_span_iff_exists_sep
-- Area.ExponentMaxV1
#check @AreaLaw.area_law_wilson_max_sharp
#print axioms AreaLaw.area_law_wilson_max_sharp
#check @AreaLaw.wordBd_swap_rect
#print axioms AreaLaw.wordBd_swap_rect
-- Area.FlipVanishV1
#check @AreaLaw.flipZ_preserving
#print axioms AreaLaw.flipZ_preserving
#check @AreaLaw.hol_eq_wordHol
#print axioms AreaLaw.hol_eq_wordHol
#check @AreaLaw.integral_word_mul_prod_eq_zero_of_not_mem_span
#print axioms AreaLaw.integral_word_mul_prod_eq_zero_of_not_mem_span
#check @AreaLaw.wordHol
#print axioms AreaLaw.wordHol
#check @AreaLaw.wordHol_flip
#print axioms AreaLaw.wordHol_flip
-- Area.InfVolSubV1
#check @AreaLaw.area_law_limit_sub
#print axioms AreaLaw.area_law_limit_sub
-- Area.InfVolV2
#check @AreaLaw.area_law_infvol
#print axioms AreaLaw.area_law_infvol
#check @AreaLaw.area_law_limit
#print axioms AreaLaw.area_law_limit
#check @AreaLaw.rectWord_one_one
#print axioms AreaLaw.rectWord_one_one
#check @AreaLaw.zRectWord
#print axioms AreaLaw.zRectWord
-- Area.MixV1
#check @AreaLaw.exp_eq_mix
#print axioms AreaLaw.exp_eq_mix
#check @AreaLaw.integral_mul_prod_one_add
#print axioms AreaLaw.integral_mul_prod_one_add
#check @AreaLaw.mixVar_mem
#print axioms AreaLaw.mixVar_mem
#check @AreaLaw.prod_one_add_univ
#print axioms AreaLaw.prod_one_add_univ
-- Area.PlaqBoundV1
#check @AreaLaw.ZX_insert_le
#print axioms AreaLaw.ZX_insert_le
#check @AreaLaw.q_eq
#print axioms AreaLaw.q_eq
-- Area.RectMoveV1
#check @AreaLaw.area_law_wilson_general
#print axioms AreaLaw.area_law_wilson_general
#check @AreaLaw.expect_perm
#print axioms AreaLaw.expect_perm
#check @AreaLaw.rectWordG
#print axioms AreaLaw.rectWordG
#check @AreaLaw.wilson_cfgShift_invariant
#print axioms AreaLaw.wilson_cfgShift_invariant
-- Area.SharpConstV1
#check @AreaLaw.area_law_wilson_general_sharp
#print axioms AreaLaw.area_law_wilson_general_sharp
#check @AreaLaw.area_law_wilson_sharp
#print axioms AreaLaw.area_law_wilson_sharp
#check @AreaLaw.card_nbQ_le
#print axioms AreaLaw.card_nbQ_le
#check @AreaLaw.card_rootP_le
#print axioms AreaLaw.card_rootP_le
#check @VortexStrong.vortex_floor_sharp
#print axioms VortexStrong.vortex_floor_sharp
-- Area.SimpleCycleV1
#check @AreaLaw.rect_closed_cases
#print axioms AreaLaw.rect_closed_cases
-- Area.VortexLinkV1
#check @VortexStrong.vortex_floor_wilson
#print axioms VortexStrong.vortex_floor_wilson
-- Area.VortexMNSharpV1
#check @VortexStrongMN.vortex_floor_MN_sharp
#print axioms VortexStrongMN.vortex_floor_MN_sharp
-- Area.VortexMNV1
#check @VortexStrongMN.card_bad_ge
#print axioms VortexStrongMN.card_bad_ge
#check @VortexStrongMN.minBad_conn
#print axioms VortexStrongMN.minBad_conn
#check @VortexStrongMN.vortex_floor_MN
#print axioms VortexStrongMN.vortex_floor_MN
-- Area.VortexSanityV1
#check @VortexStrong.plane_bad
#print axioms VortexStrong.plane_bad
-- Area.VortexStrongV1
#check @VortexStrong.Good
#print axioms VortexStrong.Good
#check @VortexStrong.ZM_gauge
#print axioms VortexStrong.ZM_gauge
#check @VortexStrong.ZM_good
#print axioms VortexStrong.ZM_good
#check @VortexStrong.Ztw
#print axioms VortexStrong.Ztw
#check @VortexStrong.abs_Z_sub_le
#print axioms VortexStrong.abs_Z_sub_le
#check @VortexStrong.card_bad_ge
#print axioms VortexStrong.card_bad_ge
#check @VortexStrong.good_twist_iff
#print axioms VortexStrong.good_twist_iff
#check @VortexStrong.minBad_conn
#print axioms VortexStrong.minBad_conn
#check @VortexStrong.twist
#print axioms VortexStrong.twist
#check @VortexStrong.vortex_floor
#print axioms VortexStrong.vortex_floor
#check @VortexStrong.vortex_floor_rel
#print axioms VortexStrong.vortex_floor_rel
-- Area.WordBoundV1
#check @AreaLaw.abs_wordExpect_le
#print axioms AreaLaw.abs_wordExpect_le
#check @AreaLaw.minSpanC
#print axioms AreaLaw.minSpanC
-- Block3.BoxReflV1
#check @Block3.blockMap_refl_cfg
#print axioms Block3.blockMap_refl_cfg
-- Block3.BoxV1
#check @Block3.paths
#print axioms Block3.paths
#check @Block3.wts
#print axioms Block3.wts
-- Block3.DownReflV1
#check @Block3.down_refl
#print axioms Block3.down_refl
-- Block3.FlipAllV1
#check @Block3.down_flipSet
#print axioms Block3.down_flipSet
-- Block3.LocalKV1
#check @Block3.down_local
#print axioms Block3.down_local
-- Block3.RPFinalV1
#check @Block3.rp_push
#print axioms Block3.rp_push
-- Block3.RPProbV1
#check @Block3.rp_push_prob
#print axioms Block3.rp_push_prob
-- Block3.ReflBAllV1
#check @Block3.down_reflB
#print axioms Block3.down_reflB
-- Block3.SignV1
#check @Block3.blockMap_flip
#print axioms Block3.blockMap_flip
-- Block3.Trans3V1
#check @Block3.down_trans
#print axioms Block3.down_trans
-- Block3.TransV1
#check @Block3.blockMap_trans
#print axioms Block3.blockMap_trans
-- Block3.Tune3V1
#check @Block3.Y3_zero
#print axioms Block3.Y3_zero
#check @Block3.tendsto_Y3_one
#print axioms Block3.tendsto_Y3_one
#check @Block3.tuned3_exists
#print axioms Block3.tuned3_exists
-- Tuned.HsymV1
#check @TunedCoupling.hsym_translation
#print axioms TunedCoupling.hsym_translation
-- Tuned.TuneV1
#check @TunedCoupling.continuous_Yc
#print axioms TunedCoupling.continuous_Yc
#check @TunedCoupling.exists_tuning
#print axioms TunedCoupling.exists_tuning
-- Tuning.ApproxStokesV1
#check @FlatStokes.approx_torus_commutator
#print axioms FlatStokes.approx_torus_commutator
-- Tuning.DefectFloorV1
#check @TwistFloor.no_floor_10
#print axioms TwistFloor.no_floor_10
-- Tuning.DefectTwoV1
#check @TwistFloor.Smin_sym_half
#print axioms TwistFloor.Smin_sym_half
#check @TwistFloor.defect11_ge_two
#print axioms TwistFloor.defect11_ge_two
#check @TwistFloor.defect11_sym_half
#print axioms TwistFloor.defect11_sym_half
#check @TwistFloor.defect11_uniform_half
#print axioms TwistFloor.defect11_uniform_half
#check @TwistFloor.logratio_limit_half
#print axioms TwistFloor.logratio_limit_half
-- Tuning.FlatStokesV1
#check @FlatStokes.no_twisted_quadruple
#print axioms FlatStokes.no_twisted_quadruple
#check @FlatStokes.torus_commutator
#print axioms FlatStokes.torus_commutator
