-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 5 / 6
import SkewOrbit.Probe
import T1.Final2
import T1.Refl1
import T1.Split1
import T1.T1hArith1
import UVChain.BoxChainV1
import Uniform.F3Assembly
import VortexCert.CertN2V1
import VortexCert.CertN3V1
import VortexCert.CertN4V1
import VortexCert.CoreV3
import Wilson.AbsV1
import Wilson.EtaV2
import Wilson.FloorV3
import Wilson.GeneralV1
import Wilson.ParityV1
import Wilson.Q8TwistV2
import Wilson.SU2TwistV2
import Wilson.ThetaV1

-- SkewOrbit.Probe
#check @SkewOrbitProbe.Ex.t
#print axioms SkewOrbitProbe.Ex.t
#check @SkewOrbitProbe.Ex.σ
#print axioms SkewOrbitProbe.Ex.σ
#check @SkewOrbitProbe.Ex.hr
#print axioms SkewOrbitProbe.Ex.hr
#check @SkewOrbitProbe.Ex.hT
#print axioms SkewOrbitProbe.Ex.hT
#check @SkewOrbitProbe.Ex.r
#print axioms SkewOrbitProbe.Ex.r
#check @SkewOrbitProbe.coarse_tendsto_window
#print axioms SkewOrbitProbe.coarse_tendsto_window
#check @SkewOrbitProbe.limit_independent_window
#print axioms SkewOrbitProbe.limit_independent_window
#check @SkewOrbitProbe.Ex.admissible
#print axioms SkewOrbitProbe.Ex.admissible
#check @SkewOrbitProbe.Ex.coarse_converges
#print axioms SkewOrbitProbe.Ex.coarse_converges
#check @SkewOrbitProbe.Ex.bare_not_cauchy
#print axioms SkewOrbitProbe.Ex.bare_not_cauchy
#check @SkewOrbitProbe.one_step_after
#print axioms SkewOrbitProbe.one_step_after
#check @SkewOrbitProbe.theta_exists_iff
#print axioms SkewOrbitProbe.theta_exists_iff
#check @SkewOrbitProbe.rate_window
#print axioms SkewOrbitProbe.rate_window
#check @SkewOrbitProbe.Sharp.sharp
#print axioms SkewOrbitProbe.Sharp.sharp
#check @SkewOrbitProbe.Ex.matching_needed
#print axioms SkewOrbitProbe.Ex.matching_needed
-- T1.Final2
#check @HsSplit.lower_side_c
#print axioms HsSplit.lower_side_c
#check @HsSplit.hS_split
#print axioms HsSplit.hS_split
#check @NearAliasB.bracket_Qpos_split
#print axioms NearAliasB.bracket_Qpos_split
-- T1.Refl1
#check @PolyRefl.Lin.b
#print axioms PolyRefl.Lin.b
#check @PolyRefl.Lin.a
#print axioms PolyRefl.Lin.a
-- T1.Split1
#check @NearAliasB.chain_lower
#print axioms NearAliasB.chain_lower
#check @NearAliasB.near_lower
#print axioms NearAliasB.near_lower
#check @NearAliasB.lower_side_split
#print axioms NearAliasB.lower_side_split
#check @HsSplit.HR
#print axioms HsSplit.HR
-- T1.T1hArith1
#check @StageArith.tauM
#print axioms StageArith.tauM
-- UVChain.BoxChainV1
#check @BoxWalk.Site
#print axioms BoxWalk.Site
#check @BoxWalk.BoxLk
#print axioms BoxWalk.BoxLk
#check @ChainBlockMap.Ball
#print axioms ChainBlockMap.Ball
#check @ChainBlockMap.Cfg
#print axioms ChainBlockMap.Cfg
#check @ChainBlockMap.νP
#print axioms ChainBlockMap.νP
#check @ChainBlockMap.sixWeight_total
#print axioms ChainBlockMap.sixWeight_total
#check @BoxWalk.boxPaths
#print axioms BoxWalk.boxPaths
#check @BoxWalk.boxW
#print axioms BoxWalk.boxW
#check @BoxWalk.boxMap_rev
#print axioms BoxWalk.boxMap_rev
#check @WalkCast.walk
#print axioms WalkCast.walk
#check @ChainBlockMap.sixWeight
#print axioms ChainBlockMap.sixWeight
#check @ChainBlockMap.norm_sixAvg_le
#print axioms ChainBlockMap.norm_sixAvg_le
#check @ChainBlockMap.continuous_blockMap
#print axioms ChainBlockMap.continuous_blockMap
#check @ChainBlockMap.blockMap_of_small_field
#print axioms ChainBlockMap.blockMap_of_small_field
#check @ChainBlockMap.blockMap
#print axioms ChainBlockMap.blockMap
#check @ChainBlockMap.down
#print axioms ChainBlockMap.down
#check @ChainBlockMap.hcons_blockMap
#print axioms ChainBlockMap.hcons_blockMap
#check @ChainBlockMap.νP_self
#print axioms ChainBlockMap.νP_self
#check @BoxWalk.double
#print axioms BoxWalk.double
#check @BoxWalk.base
#print axioms BoxWalk.base
#check @BoxWalk.boxPathsIdx
#print axioms BoxWalk.boxPathsIdx
#check @ChainBlockMap.wt
#print axioms ChainBlockMap.wt
#check @ChainBlockMap.pathProd
#print axioms ChainBlockMap.pathProd
#check @ChainBlockMap.sixAvg
#print axioms ChainBlockMap.sixAvg
#check @ChainBlockMap.coarseAvg
#print axioms ChainBlockMap.coarseAvg
#check @ChainBlockMap.retract
#print axioms ChainBlockMap.retract
#check @BoxWalk.chain_end_to_end_box
#print axioms BoxWalk.chain_end_to_end_box
#check @ChainBlockMap.chain_end_to_end_blockMap
#print axioms ChainBlockMap.chain_end_to_end_blockMap
#check @TransientChainError.CouplingStepsTransientE
#print axioms TransientChainError.CouplingStepsTransientE
#check @TransientChain.CouplingStepsTransient.fix_shift
#print axioms TransientChain.CouplingStepsTransient.fix_shift
#check @TransientChainError.CouplingStepsTransientE.he
#print axioms TransientChainError.CouplingStepsTransientE.he
#check @WeakUltravioletExistence.exists_common_subseq
#print axioms WeakUltravioletExistence.exists_common_subseq
#check @WeakUltravioletExistence.limit_consistent
#print axioms WeakUltravioletExistence.limit_consistent
#check @WeakUltravioletExistence.BlockConclusion
#print axioms WeakUltravioletExistence.BlockConclusion
#check @WeakUltravioletExistence.ObservableConclusion
#print axioms WeakUltravioletExistence.ObservableConclusion
#check @WeakUltravioletExistence.BlockConclusion.reflection_positive
#print axioms WeakUltravioletExistence.BlockConclusion.reflection_positive
#check @WeakUltravioletExistence.BlockConclusion.symmetric
#print axioms WeakUltravioletExistence.BlockConclusion.symmetric
#check @WeakUltravioletExistence.BlockConclusion.small_field_mass
#print axioms WeakUltravioletExistence.BlockConclusion.small_field_mass
#check @WeakUltravioletExistence.ObservableConclusion.continuous
#print axioms WeakUltravioletExistence.ObservableConclusion.continuous
#check @WeakUltravioletExistence.ObservableConclusion.modulus
#print axioms WeakUltravioletExistence.ObservableConclusion.modulus
#check @WeakUltravioletExistence.ObservableConclusion.invariant
#print axioms WeakUltravioletExistence.ObservableConclusion.invariant
#check @WeakUltravioletExistence.ObservableConclusion.positive
#print axioms WeakUltravioletExistence.ObservableConclusion.positive
#check @WeakUltravioletExistence.Representation
#print axioms WeakUltravioletExistence.Representation
#check @WeakUltravioletExistence.tendsto_of_summable_increments
#print axioms WeakUltravioletExistence.tendsto_of_summable_increments
#check @WeakUltravioletExistence.weak_uv_observable_full
#print axioms WeakUltravioletExistence.weak_uv_observable_full
#check @AsymptoticChain.ChainHypothesesAsymptotic.rarity
#print axioms AsymptoticChain.ChainHypothesesAsymptotic.rarity
#check @AsymptoticChain.ChainHypothesesAsymptotic.split
#print axioms AsymptoticChain.ChainHypothesesAsymptotic.split
#check @AsymptoticChain.ChainHypothesesAsymptotic.lattice_vanishing
#print axioms AsymptoticChain.ChainHypothesesAsymptotic.lattice_vanishing
#check @AsymptoticChain.ChainHypothesesAsymptotic.shift_vanishing
#print axioms AsymptoticChain.ChainHypothesesAsymptotic.shift_vanishing
#check @AsymptoticChain.AsymptoticStepsCentred.flow
#print axioms AsymptoticChain.AsymptoticStepsCentred.flow
#check @AsymptoticChain.AsymptoticStepsSigned.small_net
#print axioms AsymptoticChain.AsymptoticStepsSigned.small_net
#check @TransientChain.AsymptoticStepsTransient.transient
#print axioms TransientChain.AsymptoticStepsTransient.transient
#check @AsymptoticChain.AsymptoticStepsCentred.large_rem
#print axioms AsymptoticChain.AsymptoticStepsCentred.large_rem
#check @AsymptoticChain.AsymptoticStepsCentred.act_rec
#print axioms AsymptoticChain.AsymptoticStepsCentred.act_rec
#check @AsymptoticChain.AsymptoticStepsCentred.act_nonneg
#print axioms AsymptoticChain.AsymptoticStepsCentred.act_nonneg
#check @AsymptoticChain.AsymptoticStepsCentred.act_init
#print axioms AsymptoticChain.AsymptoticStepsCentred.act_init
#check @AsymptoticChain.AsymptoticStepsCentred.supply
#print axioms AsymptoticChain.AsymptoticStepsCentred.supply
#check @AsymptoticChain.CouplingStepsSigned.DW
#print axioms AsymptoticChain.CouplingStepsSigned.DW
#check @AsymptoticChain.CouplingStepsSigned.margin
#print axioms AsymptoticChain.CouplingStepsSigned.margin
#check @AsymptoticChain.CouplingStepsSigned.ustar_pos
#print axioms AsymptoticChain.CouplingStepsSigned.ustar_pos
#check @AsymptoticChain.AsymptoticStepsCentred.hD
#print axioms AsymptoticChain.AsymptoticStepsCentred.hD
#check @AsymptoticChain.AsymptoticStepsCentred.hρ
#print axioms AsymptoticChain.AsymptoticStepsCentred.hρ
#check @AsymptoticChain.AsymptoticStepsCentred.hA
#print axioms AsymptoticChain.AsymptoticStepsCentred.hA
#check @AsymptoticChain.AsymptoticStepsCentred.hB
#print axioms AsymptoticChain.AsymptoticStepsCentred.hB
-- Uniform.F3Assembly
#check @F3Conditional.f3_conditional
#print axioms F3Conditional.f3_conditional
-- VortexCert.CertN2V1
#check @VortexCert.SN_two_le
#print axioms VortexCert.SN_two_le
#check @VortexCert.SN_two_lt
#print axioms VortexCert.SN_two_lt
#check @VortexCert.Svortex_two_eight_le
#print axioms VortexCert.Svortex_two_eight_le
#check @VortexCert.certN2
#print axioms VortexCert.certN2
-- VortexCert.CertN3V1
#check @VortexCert.SN_three_lt
#print axioms VortexCert.SN_three_lt
#check @VortexCert.Svortex_three_eight_le
#print axioms VortexCert.Svortex_three_eight_le
#check @VortexCert.SN_three_le
#print axioms VortexCert.SN_three_le
#check @VortexCert.certN3
#print axioms VortexCert.certN3
-- VortexCert.CertN4V1
#check @VortexCert.SN_four_lt
#print axioms VortexCert.SN_four_lt
#check @VortexCert.Svortex_four_four_le
#print axioms VortexCert.Svortex_four_four_le
#check @VortexCert.SN_four_le
#print axioms VortexCert.SN_four_le
#check @VortexCert.certN4
#print axioms VortexCert.certN4
-- VortexCert.CoreV3
#check @VortexCert.SN_le_Svortex
#print axioms VortexCert.SN_le_Svortex
#check @VortexCert.normSq_cay
#print axioms VortexCert.normSq_cay
#check @VortexCert.Svortex_le_of_cert
#print axioms VortexCert.Svortex_le_of_cert
-- Wilson.AbsV1
#check @TwistedWilson.twisted_vortex_bound_abs
#print axioms TwistedWilson.twisted_vortex_bound_abs
#check @TwistedWilson.su2_dominated_swap
#print axioms TwistedWilson.su2_dominated_swap
-- Wilson.EtaV2
#check @TwistedWilson.ZEta
#print axioms TwistedWilson.ZEta
#check @TwistedWilson.ZEta_gauge
#print axioms TwistedWilson.ZEta_gauge
#check @TwistedWilson.ZEta_flip_any
#print axioms TwistedWilson.ZEta_flip_any
-- Wilson.FloorV3
#check @TwistedWilson.thin_vortex_floor
#print axioms TwistedWilson.thin_vortex_floor
-- Wilson.GeneralV1
#check @TwistedWilson.su2_dominated_general
#print axioms TwistedWilson.su2_dominated_general
#check @TwistedWilson.su2_dominated_general_instance
#print axioms TwistedWilson.su2_dominated_general_instance
-- Wilson.ParityV1
#check @TwistedWilson.ZEta_parity
#print axioms TwistedWilson.ZEta_parity
#check @TwistedPlane.exists_chi2_eq
#print axioms TwistedPlane.exists_chi2_eq
-- Wilson.Q8TwistV2
#check @TwistedQ8.Q8.s
#print axioms TwistedQ8.Q8.s
#check @TwistedQ8.Q8.k
#print axioms TwistedQ8.Q8.k
#check @TwistedWilson.vortex_free_energy_bound
#print axioms TwistedWilson.vortex_free_energy_bound
-- Wilson.SU2TwistV2
#check @TwistedWilson.Link
#print axioms TwistedWilson.Link
#check @TwistedWilson.haarProb
#print axioms TwistedWilson.haarProb
#check @TwistedWilson.ZW_pos
#print axioms TwistedWilson.ZW_pos
#check @TwistedWilson.Plaq
#print axioms TwistedWilson.Plaq
#check @TwistedWilson.haarCfg
#print axioms TwistedWilson.haarCfg
#check @TwistedWilson.ZW
#print axioms TwistedWilson.ZW
#check @TwistedWilson.pull
#print axioms TwistedWilson.pull
#check @TwistedWilson.SU2
#print axioms TwistedWilson.SU2
#check @TwistedWilson.zt
#print axioms TwistedWilson.zt
#check @TwistedWilson.Site
#print axioms TwistedWilson.Site
#check @TwistedWilson.hol
#print axioms TwistedWilson.hol
#check @TwistedWilson.twisted_vortex_bound
#print axioms TwistedWilson.twisted_vortex_bound
#check @TwistedWilson.z2_four_covers_two
#print axioms TwistedWilson.z2_four_covers_two
#check @TwistedWilson.z2_four_ratio
#print axioms TwistedWilson.z2_four_ratio
#check @TwistedWilson.signAction
#print axioms TwistedWilson.signAction
#check @TwistedWilson.haarCfg_inv
#print axioms TwistedWilson.haarCfg_inv
#check @TwistedWilson.chiB_isSignChar
#print axioms TwistedWilson.chiB_isSignChar
#check @TwistedWilson.hol_smul
#print axioms TwistedWilson.hol_smul
#check @TwistedWilson.abs_re_le_one
#print axioms TwistedWilson.abs_re_le_one
#check @TwistedWilson.integrable_exp
#print axioms TwistedWilson.integrable_exp
#check @TwistedWilson.su2_dominated
#print axioms TwistedWilson.su2_dominated
#check @TwistedWilson.Z_base_const
#print axioms TwistedWilson.Z_base_const
#check @TwistedWilson.Z_base_flip
#print axioms TwistedWilson.Z_base_flip
#check @TwistedWilson.bound_of_base
#print axioms TwistedWilson.bound_of_base
#check @TwistedWilson.chi0_eq
#print axioms TwistedWilson.chi0_eq
#check @TwistedWilson.Z_base
#print axioms TwistedWilson.Z_base
#check @TwistedWilson.twisted_ratio_lower
#print axioms TwistedWilson.twisted_ratio_lower
-- Wilson.ThetaV1
#check @TwistedWilson.theta_eq_eta_average
#print axioms TwistedWilson.theta_eq_eta_average
