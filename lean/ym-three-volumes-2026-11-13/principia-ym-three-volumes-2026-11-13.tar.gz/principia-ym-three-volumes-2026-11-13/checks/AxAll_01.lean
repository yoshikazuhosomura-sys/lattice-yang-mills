-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 1 / 6
import Band.FiniteSize
import Band.Reduction
import Blocks.KeffLaplaceV1
import Blocks.LaplaceV1
import Blocks.StageTwoV2
import Blocks.TheoremEV2
import Blocks.ThickFloorAbsV1
import Blocks.ThickFloorAbstractV1
import Blocks.ThickFloorAttainV1
import Blocks.ThickFloorCanonV1
import Blocks.ThickFloorChainV1
import Blocks.ThickFloorFourV1
import Blocks.ThickFloorGridV1
import Blocks.ThickFloorHalfSplitV1
import Blocks.ThickFloorKappaEqV1
import Blocks.ThickFloorKappaTwoV1
import Blocks.ThickFloorLiftV1
import Blocks.ThickFloorLowerV1
import Blocks.ThickFloorPolyakovFloorV1
import Blocks.ThickFloorPolyakovV1
import Blocks.ThickFloorPositiveV1
import Blocks.ThickFloorQuatV1
import Blocks.ThickFloorReduceV1
import Blocks.ThickFloorSignedV1
import Blocks.ThickFloorSquareV1
import Blocks.ThickFloorStabV1
import Blocks.ThickFloorThetaPosV1
import Blocks.ThickFloorThreeV1
import Blocks.ThickFloorTorusV1
import Blocks.ThickFloorTransportV1

-- Band.FiniteSize
#check @BandFiniteSize.Hyp.nonneg
#print axioms BandFiniteSize.Hyp.nonneg
#check @BandFiniteSize.Hyp
#print axioms BandFiniteSize.Hyp
#check @BandFiniteSize.doubling
#print axioms BandFiniteSize.doubling
-- Band.Reduction
#check @BandReduction.band_reduction
#print axioms BandReduction.band_reduction
#check @BandReduction.area_exponent
#print axioms BandReduction.area_exponent
#check @BandReduction.jump
#print axioms BandReduction.jump
#check @BandReduction.Hyp
#print axioms BandReduction.Hyp
#check @BandReduction.Hyp.base
#print axioms BandReduction.Hyp.base
#check @BandReduction.Hyp.nest
#print axioms BandReduction.Hyp.nest
#check @BandReduction.Hyp.widen
#print axioms BandReduction.Hyp.widen
#check @BandReduction.iterate
#print axioms BandReduction.iterate
#check @BandReduction.step
#print axioms BandReduction.step
-- Blocks.KeffLaplaceV1
#check @TwistBlocks.Keff_le_laplace
#print axioms TwistBlocks.Keff_le_laplace
-- Blocks.LaplaceV1
#check @CoarseLaplace.laplace_lower
#print axioms CoarseLaplace.laplace_lower
-- Blocks.StageTwoV2
#check @TwistBlocks.block_bound_abs
#print axioms TwistBlocks.block_bound_abs
#check @TwistBlocks.Keff_le
#print axioms TwistBlocks.Keff_le
#check @TwistBlocks.Keff
#print axioms TwistBlocks.Keff
#check @TwistBlocks.ZB
#print axioms TwistBlocks.ZB
#check @TwistBlocks.Keff_nonneg
#print axioms TwistBlocks.Keff_nonneg
-- Blocks.TheoremEV2
#check @TwistBlocks.vac
#print axioms TwistBlocks.vac
#check @TwistBlocks.thetaM
#print axioms TwistBlocks.thetaM
#check @TwistBlocks.Svortex
#print axioms TwistBlocks.Svortex
#check @TwistBlocks.SN
#print axioms TwistBlocks.SN
#check @TwistBlocks.Smin
#print axioms TwistBlocks.Smin
-- Blocks.ThickFloorAbsV1
#check @TwistBlocks.ThickVortexFloorAbs
#print axioms TwistBlocks.ThickVortexFloorAbs
#check @TwistBlocks.abs_block_bound_exp
#print axioms TwistBlocks.abs_block_bound_exp
#check @TwistBlocks.thick_vortex_floor_abs_of_H4
#print axioms TwistBlocks.thick_vortex_floor_abs_of_H4
#check @TwistBlocks.thick_vortex_floor_abs_of_local
#print axioms TwistBlocks.thick_vortex_floor_abs_of_local
-- Blocks.ThickFloorAbstractV1
#check @ThickFloor.small_action_cost
#print axioms ThickFloor.small_action_cost
#check @ThickFloor.anticomm_unit
#print axioms ThickFloor.anticomm_unit
-- Blocks.ThickFloorAttainV1
#check @TwistBlocks.Svortex_attained
#print axioms TwistBlocks.Svortex_attained
-- Blocks.ThickFloorCanonV1
#check @TwistBlocks.canon_holds
#print axioms TwistBlocks.canon_holds
-- Blocks.ThickFloorChainV1
#check @TwistBlocks.Canon
#print axioms TwistBlocks.Canon
#check @TwistBlocks.H4_of_local
#print axioms TwistBlocks.H4_of_local
#check @TwistBlocks.LocalVortex
#print axioms TwistBlocks.LocalVortex
#check @TwistBlocks.exists_win_le
#print axioms TwistBlocks.exists_win_le
-- Blocks.ThickFloorFourV1
#check @TwistBlocks.thick_vortex_floor_four
#print axioms TwistBlocks.thick_vortex_floor_four
-- Blocks.ThickFloorGridV1
#check @TwistBlocks.grid_vortex_floor
#print axioms TwistBlocks.grid_vortex_floor
-- Blocks.ThickFloorHalfSplitV1
#check @HalfSplit.wE
#print axioms HalfSplit.wE
#check @HalfSplit.Th
#print axioms HalfSplit.Th
#check @HalfSplit.thL
#print axioms HalfSplit.thL
#check @HalfSplit.sgL
#print axioms HalfSplit.sgL
#check @HalfSplit.fixL
#print axioms HalfSplit.fixL
#check @HalfSplit.half_split
#print axioms HalfSplit.half_split
#check @HalfSplit.half_pairing_nonneg
#print axioms HalfSplit.half_pairing_nonneg
-- Blocks.ThickFloorKappaEqV1
#check @TwistBlocks.kappaC_eq_kappa
#print axioms TwistBlocks.kappaC_eq_kappa
-- Blocks.ThickFloorKappaTwoV1
#check @TwistBlocks.kappaC_le_two
#print axioms TwistBlocks.kappaC_le_two
-- Blocks.ThickFloorLiftV1
#check @TwistBlocks.thick_vortex_floor_abs_of_localL
#print axioms TwistBlocks.thick_vortex_floor_abs_of_localL
#check @TwistBlocks.LocalVortexL
#print axioms TwistBlocks.LocalVortexL
#check @TwistBlocks.localVortex_of_local
#print axioms TwistBlocks.localVortex_of_local
-- Blocks.ThickFloorLowerV1
#check @TwistBlocks.kappaC_ge_Svortex
#print axioms TwistBlocks.kappaC_ge_Svortex
#check @TwistBlocks.H4_fails_below
#print axioms TwistBlocks.H4_fails_below
-- Blocks.ThickFloorPolyakovFloorV1
#check @HalfSplit.polyakov_pair_floor
#print axioms HalfSplit.polyakov_pair_floor
-- Blocks.ThickFloorPolyakovV1
#check @HalfSplit.polyLoop
#print axioms HalfSplit.polyLoop
#check @HalfSplit.polyakov_pair_theta
#print axioms HalfSplit.polyakov_pair_theta
#check @HalfSplit.odd_fix_bound
#print axioms HalfSplit.odd_fix_bound
-- Blocks.ThickFloorPositiveV1
#check @VortexPos.SN_pos
#print axioms VortexPos.SN_pos
#check @VortexPos.Svortex_ge_unif
#print axioms VortexPos.Svortex_ge_unif
#check @VortexPos.linkH_le
#print axioms VortexPos.linkH_le
#check @VortexPos.linkV_le
#print axioms VortexPos.linkV_le
-- Blocks.ThickFloorQuatV1
#check @ThickFloor.anticomm_conj
#print axioms ThickFloor.anticomm_conj
-- Blocks.ThickFloorReduceV1
#check @TwistBlocks.localVortexL_of_zero
#print axioms TwistBlocks.localVortexL_of_zero
#check @TwistBlocks.thick_vortex_floor_abs_of_zero
#print axioms TwistBlocks.thick_vortex_floor_abs_of_zero
#check @TwistBlocks.ZeroVortexL
#print axioms TwistBlocks.ZeroVortexL
-- Blocks.ThickFloorSignedV1
#check @TwistBlocks.thick_vortex_floor_signed
#print axioms TwistBlocks.thick_vortex_floor_signed
-- Blocks.ThickFloorSquareV1
#check @TwistBlocks.RigidT
#print axioms TwistBlocks.RigidT
#check @TwistBlocks.rigidT_one
#print axioms TwistBlocks.rigidT_one
#check @TwistBlocks.rigidL_of_rigidT
#print axioms TwistBlocks.rigidL_of_rigidT
#check @TwistBlocks.thick_vortex_floor_abs_of_rigidT
#print axioms TwistBlocks.thick_vortex_floor_abs_of_rigidT
#check @TwistBlocks.h0
#print axioms TwistBlocks.h0
-- Blocks.ThickFloorStabV1
#check @TwistBlocks.stab_vacT
#print axioms TwistBlocks.stab_vacT
-- Blocks.ThickFloorThetaPosV1
#check @HalfSplit.Z1_le_Z0
#print axioms HalfSplit.Z1_le_Z0
#check @TwistBlocks.theta_nonneg
#print axioms TwistBlocks.theta_nonneg
#check @TwistBlocks.theta_lt_one
#print axioms TwistBlocks.theta_lt_one
-- Blocks.ThickFloorThreeV1
#check @TwistBlocks.thick_vortex_floor_three
#print axioms TwistBlocks.thick_vortex_floor_three
-- Blocks.ThickFloorTorusV1
#check @TwistBlocks.thick_vortex_floor
#print axioms TwistBlocks.thick_vortex_floor
#check @TwistBlocks.thick_vortex_floor_unfolded
#print axioms TwistBlocks.thick_vortex_floor_unfolded
#check @TwistBlocks.rigidT_all
#print axioms TwistBlocks.rigidT_all
#check @TwistBlocks.cfA
#print axioms TwistBlocks.cfA
#check @TwistBlocks.cfB
#print axioms TwistBlocks.cfB
#check @TwistBlocks.cf_comm
#print axioms TwistBlocks.cf_comm
#check @TwistBlocks.uniqT
#print axioms TwistBlocks.uniqT
#check @TwistBlocks.SL_vacL
#print axioms TwistBlocks.SL_vacL
#check @TwistBlocks.flatT_nonempty
#print axioms TwistBlocks.flatT_nonempty
-- Blocks.ThickFloorTransportV1
#check @TwistBlocks.thick_vortex_floor_zero_of_rigid
#print axioms TwistBlocks.thick_vortex_floor_zero_of_rigid
#check @TwistBlocks.thick_vortex_floor_abs_of_rigid
#print axioms TwistBlocks.thick_vortex_floor_abs_of_rigid
#check @TwistBlocks.RigidL
#print axioms TwistBlocks.RigidL
