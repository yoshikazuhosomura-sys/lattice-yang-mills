-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 6 / 6
import T10.Alias1

-- T10.Alias1
#check @AliasPoinc.coupling_converges_gamma_closed
#print axioms AliasPoinc.coupling_converges_gamma_closed
#check @AliasLiftSize.hlift_holds
#print axioms AliasLiftSize.hlift_holds
#check @AliasPoinc.hH_holds
#print axioms AliasPoinc.hH_holds
