-- 章が挙げる宣言の名の確かめ（#check）と公理（#print axioms）。群 4 / 6
import Lattice.MidSetOneV1
import Lattice.NondegV3
import Lattice.RPKernelV1
import Lattice.TorusDecV2
import Lattice.TorusGaugeV1
import Lattice.WilsonDobV1
import Lattice.WilsonGapV2
import Lift.PushCov1
import Lift.RetractOne1
import Linz.Expand1
import Linz.Kernel1
import Peierls.CubeWeakV3
import Peierls.PermRPV2
import PolyT.AllMV2
import PolyT.ChordV1
import PolyT.FlipV2
import PolyT.LinkRPMainV3
import PolyT.MainV1
import PolyT.TransV3
import Push.Join7
import Push.Lat1
import Push.Lat2
import Push.Rec1
import RealSpace.ThmR
import SkewOrbit.LimitV1
import Spec.DobrushinRowV2
import Spec.LinkCoeffV1
import Spec.SweepStepV1
import Sweep.DistDecayV1
import Sweep.HeatBathSweepV1

-- Lattice.MidSetOneV1
#check @MidRP.sigT
#print axioms MidRP.sigT
-- Lattice.NondegV3
#check @WilsonLimit.wilson_massGap_nondegenerate
#print axioms WilsonLimit.wilson_massGap_nondegenerate
#check @OSGap.Datum.exists_unit_orth
#print axioms OSGap.Datum.exists_unit_orth
#check @HaarRe.integral_sq_sub_ge
#print axioms HaarRe.integral_sq_sub_ge
#check @LinkSpec.wilsonProb_sq_sub_ge
#print axioms LinkSpec.wilsonProb_sq_sub_ge
#check @WilsonLimit.var_limit_ge
#print axioms WilsonLimit.var_limit_ge
-- Lattice.RPKernelV1
#check @LinkReflection.rp_kernel
#print axioms LinkReflection.rp_kernel
-- Lattice.TorusDecV2
#check @TorusRP.Lk
#print axioms TorusRP.Lk
#check @OSGap.haarProb
#print axioms OSGap.haarProb
#check @OSGap.haarProb_isProbabilityMeasure
#print axioms OSGap.haarProb_isProbabilityMeasure
#check @OSGap.haarProb_isMulLeftInvariant
#print axioms OSGap.haarProb_isMulLeftInvariant
#check @TorusRP.wilsonMeasure
#print axioms TorusRP.wilsonMeasure
#check @TorusRP.QBall
#print axioms TorusRP.QBall
#check @TorusRP.haarBall
#print axioms TorusRP.haarBall
#check @TorusRP.action
#print axioms TorusRP.action
#check @TorusRP.hol
#print axioms TorusRP.hol
#check @TorusRP.thL
#print axioms TorusRP.thL
#check @TorusRP.holQ_refl
#print axioms TorusRP.holQ_refl
#check @TorusRP.wilson_refl_symm
#print axioms TorusRP.wilson_refl_symm
#check @LinkReflection.linkRefl
#print axioms LinkReflection.linkRefl
#check @TorusRP.sig
#print axioms TorusRP.sig
#check @TorusRP.fixP
#print axioms TorusRP.fixP
#check @TorusRP.posP
#print axioms TorusRP.posP
#check @OSGap.SU2
#print axioms OSGap.SU2
#check @TorusRP.wilson_rp
#print axioms TorusRP.wilson_rp
#check @TorusRP.wilson_strong_coupling
#print axioms TorusRP.wilson_strong_coupling
#check @TorusRP.weight_factor
#print axioms TorusRP.weight_factor
#check @LinkReflection.rp_core
#print axioms LinkReflection.rp_core
#check @LinkReflection.rp_weighted
#print axioms LinkReflection.rp_weighted
#check @SwapDecay.covBound_minimal
#print axioms SwapDecay.covBound_minimal
#check @TorusRP.wilson_covariance
#print axioms TorusRP.wilson_covariance
#check @TorusRP.card_link_plaqs
#print axioms TorusRP.card_link_plaqs
#check @TorusRP.plaq_degree
#print axioms TorusRP.plaq_degree
#check @TorusRP.card_touch_le
#print axioms TorusRP.card_touch_le
#check @TorusRP.height_lip
#print axioms TorusRP.height_lip
#check @SwapDecay.minimalNonsep_sum_le
#print axioms SwapDecay.minimalNonsep_sum_le
-- Lattice.TorusGaugeV1
#check @TorusGauge.cr
#print axioms TorusGauge.cr
#check @TorusGauge.wilson_gaugeFix
#print axioms TorusGauge.wilson_gaugeFix
-- Lattice.WilsonDobV1
#check @WilsonLimit.wilson_massGap_dob_exists
#print axioms WilsonLimit.wilson_massGap_dob_exists
#check @WilsonLimit.dob_window_strict
#print axioms WilsonLimit.dob_window_strict
#check @WilsonLimit.wilson_massGap_dob
#print axioms WilsonLimit.wilson_massGap_dob
#check @WilsonLimit.dec_eventually_dob
#print axioms WilsonLimit.dec_eventually_dob
-- Lattice.WilsonGapV2
#check @TorusRP.wilsonProb
#print axioms TorusRP.wilsonProb
#check @TorusRP.wilsonWeight_le
#print axioms TorusRP.wilsonWeight_le
#check @TorusRP.wilsonWeight_ge
#print axioms TorusRP.wilsonWeight_ge
#check @TorusRP.wilsonMeasure_univ_pos
#print axioms TorusRP.wilsonMeasure_univ_pos
#check @TorusRP.wilsonMeasure_univ_lt_top
#print axioms TorusRP.wilsonMeasure_univ_lt_top
#check @TorusRP.wilsonMeasure_univ
#print axioms TorusRP.wilsonMeasure_univ
#check @WilsonLimit.liftProb
#print axioms WilsonLimit.liftProb
#check @WilsonLimit.Cfg
#print axioms WilsonLimit.Cfg
#check @WilsonLimit.zRefl
#print axioms WilsonLimit.zRefl
#check @WilsonLimit.zShift
#print axioms WilsonLimit.zShift
#check @WilsonLimit.perLift
#print axioms WilsonLimit.perLift
#check @WilsonLimit.Nn
#print axioms WilsonLimit.Nn
#check @WilsonLimit.Wsub
#print axioms WilsonLimit.Wsub
-- Lift.PushCov1
#check @PushCov.blockLin
#print axioms PushCov.blockLin
#check @PushCov.lattice_pushCov
#print axioms PushCov.lattice_pushCov
#check @PushCov.covForm
#print axioms PushCov.covForm
#check @PushCov.covOp_map
#print axioms PushCov.covOp_map
-- Lift.RetractOne1
#check @BlockLinearKernel.blockMap_exp_linear_le_one
#print axioms BlockLinearKernel.blockMap_exp_linear_le_one
#check @BlockLinearKernel.blockMap_exp_linear_r1
#print axioms BlockLinearKernel.blockMap_exp_linear_r1
-- Linz.Expand1
#check @BlockLinear.sixSgn
#print axioms BlockLinear.sixSgn
-- Linz.Kernel1
#check @BlockLinearKernel.expCfg
#print axioms BlockLinearKernel.expCfg
-- Peierls.CubeWeakV3
#check @CubeWeak.Bd
#print axioms CubeWeak.Bd
-- Peierls.PermRPV2
#check @PeierlsPerm.wilson_rp_dir
#print axioms PeierlsPerm.wilson_rp_dir
#check @PeierlsPerm.wilson_perm_invariant
#print axioms PeierlsPerm.wilson_perm_invariant
-- PolyT.AllMV2
#check @PolyakovT.polyakov_pair_evenM
#print axioms PolyakovT.polyakov_pair_evenM
-- PolyT.ChordV1
#check @LogChord.chord
#print axioms LogChord.chord
-- PolyT.FlipV2
#check @PolyakovT.polyExp_neg
#print axioms PolyakovT.polyExp_neg
#check @PolyakovT.polyakov_pair_evenNM
#print axioms PolyakovT.polyakov_pair_evenNM
-- PolyT.LinkRPMainV3
#check @PolyakovT.link_rp
#print axioms PolyakovT.link_rp
-- PolyT.MainV1
#check @PolyakovT.polyExp
#print axioms PolyakovT.polyExp
#check @PolyakovT.half_pair_tanh
#print axioms PolyakovT.half_pair_tanh
#check @PolyakovT.polyakov_pair_all
#print axioms PolyakovT.polyakov_pair_all
-- PolyT.TransV3
#check @PolyakovT.corr
#print axioms PolyakovT.corr
#check @PolyakovT.wE_one
#print axioms PolyakovT.wE_one
#check @PolyakovT.corr_shiftZ
#print axioms PolyakovT.corr_shiftZ
#check @PolyakovT.Gc_swap
#print axioms PolyakovT.Gc_swap
#check @PolyakovT.wpair_nonneg
#print axioms PolyakovT.wpair_nonneg
#check @PolyakovT.wpair_cs
#print axioms PolyakovT.wpair_cs
#check @PolyakovT.cs_even
#print axioms PolyakovT.cs_even
#check @PolyakovT.Gc_even_nonneg
#print axioms PolyakovT.Gc_even_nonneg
-- Push.Join7
#check @LatticeFace.lattice_face_T1h
#print axioms LatticeFace.lattice_face_T1h
-- Push.Lat1
#check @LatticePush.freeCov
#print axioms LatticePush.freeCov
#check @LatticePush.stepOp
#print axioms LatticePush.stepOp
#check @LatticePush.stageCov
#print axioms LatticePush.stageCov
#check @LatticePush.stageCov_phase
#print axioms LatticePush.stageCov_phase
#check @LatticePush.projFam_stage
#print axioms LatticePush.projFam_stage
#check @LatticePush.pushOp
#print axioms LatticePush.pushOp
#check @LatticePush.push_phase
#print axioms LatticePush.push_phase
#check @LatticePush.freeCov_phase
#print axioms LatticePush.freeCov_phase
-- Push.Lat2
#check @LatticeFace.faceCov
#print axioms LatticeFace.faceCov
#check @LatticeFace.faceCov_eq_posC
#print axioms LatticeFace.faceCov_eq_posC
#check @LatticeFace.curl
#print axioms LatticeFace.curl
#check @LatticeFace.key_proj
#print axioms LatticeFace.key_proj
-- Push.Rec1
#check @LatticeTorus.pathKernel
#print axioms LatticeTorus.pathKernel
#check @LatticePath.pathSym_closed
#print axioms LatticePath.pathSym_closed
#check @LatticeRec.rec_iterate
#print axioms LatticeRec.rec_iterate
#check @LatticeRec.projFam_X0
#print axioms LatticeRec.projFam_X0
#check @LatticeTorus.torus_step
#print axioms LatticeTorus.torus_step
#check @LatticeRec.lattice_bracket
#print axioms LatticeRec.lattice_bracket
#check @LatticePath.Link
#print axioms LatticePath.Link
-- RealSpace.ThmR
#check @RealSpaceThmR.thmR_form
#print axioms RealSpaceThmR.thmR_form
-- SkewOrbit.LimitV1
#check @SkewOrbit.coarse_tendsto
#print axioms SkewOrbit.coarse_tendsto
#check @SkewOrbit.step
#print axioms SkewOrbit.step
#check @SkewOrbit.IsOrbit
#print axioms SkewOrbit.IsOrbit
#check @SkewOrbit.Admissible
#print axioms SkewOrbit.Admissible
#check @SkewOrbit.coarse_tendsto_mid
#print axioms SkewOrbit.coarse_tendsto_mid
#check @SkewOrbit.coarse_step
#print axioms SkewOrbit.coarse_step
#check @SkewOrbit.coarse_cauchy
#print axioms SkewOrbit.coarse_cauchy
#check @SkewOrbit.midpoint_admissible
#print axioms SkewOrbit.midpoint_admissible
#check @SkewOrbit.coarse_rate
#print axioms SkewOrbit.coarse_rate
#check @SkewOrbit.limit_independent
#print axioms SkewOrbit.limit_independent
#check @SkewOrbit.observable_tendsto
#print axioms SkewOrbit.observable_tendsto
#check @SkewOrbit.coarse_step_mid
#print axioms SkewOrbit.coarse_step_mid
#check @SkewOrbit.limit_independent_mid
#print axioms SkewOrbit.limit_independent_mid
#check @SkewOrbit.two_point_bound
#print axioms SkewOrbit.two_point_bound
#check @SkewOrbit.orbit_compare
#print axioms SkewOrbit.orbit_compare
-- Spec.DobrushinRowV2
#check @LinkSpec.tanhForm_le
#print axioms LinkSpec.tanhForm_le
#check @LinkSpec.dobrushin_row
#print axioms LinkSpec.dobrushin_row
-- Spec.LinkCoeffV1
#check @LinkSpec.spec_coeff
#print axioms LinkSpec.spec_coeff
-- Spec.SweepStepV1
#check @LinkSpec.coef
#print axioms LinkSpec.coef
-- Sweep.DistDecayV1
#check @LinkSpec.wilson_cov_dist
#print axioms LinkSpec.wilson_cov_dist
#check @TorusRP.wilson_hdec_torus_dob
#print axioms TorusRP.wilson_hdec_torus_dob
#check @LinkSpec.iter_invariant
#print axioms LinkSpec.iter_invariant
#check @LinkSpec.iter_mul_invariant
#print axioms LinkSpec.iter_mul_invariant
#check @LinkSpec.row_weighted
#print axioms LinkSpec.row_weighted
#check @Sweep.iter_bound
#print axioms Sweep.iter_bound
#check @LinkSpec.cov_le
#print axioms LinkSpec.cov_le
-- Sweep.HeatBathSweepV1
#check @LinkSpec.hbSweep_invariant
#print axioms LinkSpec.hbSweep_invariant
