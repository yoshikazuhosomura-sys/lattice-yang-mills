import Peierls.PermRPV2
import Peierls.ReflCSV2
/-!
The Cauchy–Schwarz inequality for the site reflection of the concrete SU(2) Wilson measure in each of the four
directions (the input of every step of the chessboard estimate):
  (∫ f(Θ_ρ ω) g(ω) dμ_W)² ≤ (∫ f(Θ_ρ ω) f(ω) dμ_W) · (∫ g(Θ_ρ ω) g(ω) dμ_W),
for bounded measurable f, g of the closed positive half in the direction ρ (Θ_ρ = P ∘ Θ ∘ P, P the transposition of
the directions 0 and ρ). Obtained from the time-direction inequality `PeierlsRefl.wilson_refl_cs` by the invariance
of the measure under P.

Paper correspondence: the chessboard estimate for one-scale rarity (reflections in all four directions).
-/

namespace PeierlsPermCS

open MeasureTheory TorusRP LinkReflection PeierlsPerm PeierlsRefl

variable (N : ℕ) [NeZero N] (τ : Fin 4 → Fin 4) (hτ : ∀ j, τ (τ j) = j)

/-- bounded measurable functions of the closed positive half in the relabelled direction -/
def HalfFunPerm (M : ℕ) (f : (Lk N → QBall) → ℝ) : Prop :=
  Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
    (∀ ω ω', (∀ ℓ, fixP N M (linkPerm N τ ℓ) ∨ posP N M (linkPerm N τ ℓ) → ω ℓ = ω' ℓ) → f ω = f ω')

include hτ

theorem halfFun_of_perm (M : ℕ) {f : (Lk N → QBall) → ℝ} (hf : HalfFunPerm N τ M f) :
    HalfFun N M (fun ω => f (cfgPerm N τ ω)) := by
  obtain ⟨hm, ⟨C, hC⟩, hdep⟩ := hf
  refine ⟨hm.comp (cfgPerm_preserving N τ hτ).measurable, ⟨C, fun ω => hC _⟩, fun ω ω' h => ?_⟩
  apply hdep
  intro ℓ hℓ
  exact h _ hℓ

theorem pair_perm (β : ℝ) (f g : (Lk N → QBall) → ℝ) (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (reflPerm N τ ω) * g ω ∂(wilsonMeasure N β) =
      ∫ ω, f (cfgPerm N τ (linkRefl (thL N) (sig N) ω)) * g (cfgPerm N τ ω) ∂(wilsonMeasure N β) := by
  have hPm : Measurable (cfgPerm N τ) := (cfgPerm_preserving N τ hτ).measurable
  have hRm : Measurable (linkRefl (thL N) (sig N)) := (linkRefl_preserving N).measurable
  have hmeas : Measurable (fun ω => f (reflPerm N τ ω) * g ω) := by
    unfold reflPerm
    exact (hf.comp (hPm.comp (hRm.comp hPm))).mul hg
  rw [← wilson_perm_invariant N τ hτ β _ hmeas]
  congr 1
  funext ω
  simp only [reflPerm, cfgPerm_invol N τ hτ]

/-- **Cauchy–Schwarz for the site reflection in the relabelled direction.** -/
theorem wilson_refl_cs_perm (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : HalfFunPerm N τ M f) (hg : HalfFunPerm N τ M g) :
    (∫ ω, f (reflPerm N τ ω) * g ω ∂(wilsonMeasure N β)) ^ 2 ≤
      (∫ ω, f (reflPerm N τ ω) * f ω ∂(wilsonMeasure N β)) *
        (∫ ω, g (reflPerm N τ ω) * g ω ∂(wilsonMeasure N β)) := by
  rw [pair_perm N τ hτ β f g hf.1 hg.1, pair_perm N τ hτ β f f hf.1 hf.1, pair_perm N τ hτ β g g hg.1 hg.1]
  exact wilson_refl_cs N M hN β _ _ (halfFun_of_perm N τ hτ M hf) (halfFun_of_perm N τ hτ M hg)

omit hτ in
/-- In each direction ρ (τ = the transposition of 0 and ρ). -/
theorem wilson_refl_cs_dir (ρ : Fin 4) (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : HalfFunPerm N (Equiv.swap 0 ρ) M f) (hg : HalfFunPerm N (Equiv.swap 0 ρ) M g) :
    (∫ ω, f (reflPerm N (Equiv.swap 0 ρ) ω) * g ω ∂(wilsonMeasure N β)) ^ 2 ≤
      (∫ ω, f (reflPerm N (Equiv.swap 0 ρ) ω) * f ω ∂(wilsonMeasure N β)) *
        (∫ ω, g (reflPerm N (Equiv.swap 0 ρ) ω) * g ω ∂(wilsonMeasure N β)) :=
  wilson_refl_cs_perm N (Equiv.swap 0 ρ) (fun j => Equiv.swap_apply_self 0 ρ j) M hN β f g hf hg

end PeierlsPermCS

#print axioms PeierlsPermCS.wilson_refl_cs_perm
#print axioms PeierlsPermCS.wilson_refl_cs_dir
