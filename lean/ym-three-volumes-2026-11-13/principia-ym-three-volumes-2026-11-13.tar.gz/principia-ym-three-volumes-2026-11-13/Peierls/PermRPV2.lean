import Lattice.TorusDecV2
import Lattice.WilsonGapV2
/-!
Reflection positivity of the concrete SU(2) Wilson measure of (ℤ/N)⁴ (N = 2M) in every direction, from the
time-direction statement `TorusRP.wilson_rp` and the invariance of the measure under an involutive relabelling τ of
the four directions (a site x ↦ x ∘ τ, a link (x, μ) ↦ (x ∘ τ, τ μ)).

Paper correspondence: the chessboard estimate for one-scale rarity needs site reflection positivity in all four
directions; the reflection in the direction τ 0 is Θ_τ := P_τ ∘ Θ ∘ P_τ (P_τ the relabelling of configurations).
* `action_perm` : the Wilson action is invariant (a plaquette whose orientation is reversed has the conjugate
  holonomy, with the same real part).
* `wilson_perm_invariant` : ∫ f(P_τ ω) dμ_W = ∫ f dμ_W.
* `wilson_rp_perm` : ∫ f(Θ_τ ω) f(ω) dμ_W ≥ 0 for bounded measurable f of the links (x, μ) whose relabelled link lies
  in the closed positive half of the time reflection.
-/

namespace PeierlsPerm

open MeasureTheory TorusRP LinkReflection

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (τ : Fin 4 → Fin 4) (hτ : ∀ j, τ (τ j) = j)

def sitePerm (x : Site N) : Site N := fun j => x (τ j)

def linkPerm (ℓ : Lk N) : Lk N := (sitePerm N τ ℓ.1, τ ℓ.2)

def cfgPerm (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (linkPerm N τ ℓ)

include hτ

theorem sitePerm_invol (x : Site N) : sitePerm N τ (sitePerm N τ x) = x := by
  funext j; simp [sitePerm, hτ j]

theorem linkPerm_invol (ℓ : Lk N) : linkPerm N τ (linkPerm N τ ℓ) = ℓ := by
  simp [linkPerm, sitePerm_invol N τ hτ, hτ]

theorem tau_inj {a b : Fin 4} (h : τ a = τ b) : a = b := by
  have := congrArg τ h; rwa [hτ, hτ] at this

theorem sitePerm_add_ev (x : Site N) (μ : Fin 4) :
    sitePerm N τ (x + ev N μ) = sitePerm N τ x + ev N (τ μ) := by
  funext j
  simp only [sitePerm, Pi.add_apply, ev, Pi.single_apply]
  congr 1
  by_cases h : j = τ μ
  · subst h; simp [hτ]
  · have h' : τ j ≠ μ := fun e => h (by rw [← e, hτ])
    simp [h, h']

omit hτ in
theorem re_holQ_swap (U : Lk N → ℍr) (y : Site N) (a b : Fin 4) :
    (holQ N U ((y, a), b)).re = (holQ N U ((y, b), a)).re := by
  have h : holQ N U ((y, a), b) = star (holQ N U ((y, b), a)) := by
    simp only [holQ, star_mul, star_star, mul_assoc]
  rw [h, Quaternion.re_star]

theorem hol_cfgPerm (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (cfgPerm N τ ω) p = holQ N (Uq N ω) ((sitePerm N τ p.1.1, τ p.1.2), τ p.2) := by
  simp only [hol, holQ, Uq, cfgPerm, linkPerm]
  rw [sitePerm_add_ev N τ hτ, sitePerm_add_ev N τ hτ]

/-- the image of an unoriented plaquette -/
def plaqPerm (p : Lk N × Fin 4) : Lk N × Fin 4 :=
  if τ p.1.2 < τ p.2 then ((sitePerm N τ p.1.1, τ p.1.2), τ p.2) else ((sitePerm N τ p.1.1, τ p.2), τ p.1.2)

theorem plaqPerm_mem (p : Lk N × Fin 4) (hp : p ∈ plaqs N) : plaqPerm N τ p ∈ plaqs N := by
  simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
  unfold plaqPerm
  split_ifs with h
  · exact h
  · have hne : τ p.1.2 ≠ τ p.2 := fun e => (ne_of_lt hp) (tau_inj τ hτ e)
    exact lt_of_le_of_ne (not_lt.mp h) (Ne.symm hne)

theorem plaqPerm_invol (p : Lk N × Fin 4) (hp : p ∈ plaqs N) : plaqPerm N τ (plaqPerm N τ p) = p := by
  simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp
  unfold plaqPerm
  split_ifs with h1 h2 h2
  · simp [sitePerm_invol N τ hτ, hτ]
  · simp only [hτ] at h2; exact absurd hp h2
  · simp only [hτ] at h2; exact absurd h2 (not_lt.mpr hp.le)
  · simp only [hτ] at h2
    simp [sitePerm_invol N τ hτ, hτ]

theorem re_hol_cfgPerm (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    (hol N (cfgPerm N τ ω) p).re = (hol N ω (plaqPerm N τ p)).re := by
  rw [hol_cfgPerm N τ hτ]
  unfold plaqPerm hol
  split_ifs
  · rfl
  · exact re_holQ_swap N _ _ _ _

theorem action_perm (ω : Lk N → QBall) : action N (cfgPerm N τ ω) = action N ω := by
  unfold action
  simp_rw [re_hol_cfgPerm N τ hτ]
  apply Finset.sum_nbij' (plaqPerm N τ) (plaqPerm N τ)
  · intro p hp; exact plaqPerm_mem N τ hτ p hp
  · intro p hp; exact plaqPerm_mem N τ hτ p hp
  · intro p hp; exact plaqPerm_invol N τ hτ p hp
  · intro p hp; exact plaqPerm_invol N τ hτ p hp
  · intro p _; rfl

/-- the relabelling of links as an equivalence -/
def linkEquiv : Lk N ≃ Lk N where
  toFun := linkPerm N τ
  invFun := linkPerm N τ
  left_inv := linkPerm_invol N τ hτ
  right_inv := linkPerm_invol N τ hτ

theorem cfgPerm_preserving :
    MeasurePreserving (cfgPerm N τ) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) (linkEquiv N τ hτ)
  convert hre using 1
  funext ω
  funext ℓ
  rw [LinkReflection.piCongrLeft_const]
  rfl

/-- **Invariance of the Wilson measure under the relabelling of directions.** -/
theorem wilson_perm_invariant (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    ∫ ω, f (cfgPerm N τ ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := cfgPerm_preserving N τ hτ
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) • f ω) := hWm.smul hf
  conv_rhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  unfold wilsonWeight
  rw [action_perm N τ hτ]

theorem cfgPerm_invol (ω : Lk N → QBall) : cfgPerm N τ (cfgPerm N τ ω) = ω := by
  funext ℓ; simp [cfgPerm, linkPerm_invol N τ hτ]

/-- the reflection in the relabelled direction -/
noncomputable def reflPerm (ω : Lk N → QBall) : Lk N → QBall :=
  cfgPerm N τ (linkRefl (thL N) (sig N) (cfgPerm N τ ω))

/-- **Site reflection positivity in the relabelled direction.** -/
theorem wilson_rp_perm (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f)
    (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M (linkPerm N τ ℓ) ∨ posP N M (linkPerm N τ ℓ) → ω ℓ = ω' ℓ) →
      f ω = f ω') :
    0 ≤ ∫ ω, f (reflPerm N τ ω) * f ω ∂(wilsonMeasure N β) := by
  have hPm : Measurable (cfgPerm N τ) := (cfgPerm_preserving N τ hτ).measurable
  have hRm : Measurable (linkRefl (thL N) (sig N)) := (linkRefl_preserving N).measurable
  set g : (Lk N → QBall) → ℝ := fun ω => f (cfgPerm N τ ω) with hg
  have hgm : Measurable g := hf.comp hPm
  have hgC : ∀ ω, |g ω| ≤ Cf := fun ω => hfC _
  have hgdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → g ω = g ω' := by
    intro ω ω' h
    apply hfdep
    intro ℓ hℓ
    exact h _ hℓ
  have hrp := wilson_rp N M hN β g hgm Cf hgC hgdep
  have hmeas : Measurable (fun ω => f (reflPerm N τ ω) * f ω) := by
    unfold reflPerm
    exact (hf.comp (hPm.comp (hRm.comp hPm))).mul hf
  have hinv := wilson_perm_invariant N τ hτ β (fun ω => f (reflPerm N τ ω) * f ω) hmeas
  rw [← hinv]
  have e : ∀ ω, f (reflPerm N τ (cfgPerm N τ ω)) * f (cfgPerm N τ ω) =
      g (linkRefl (thL N) (sig N) ω) * g ω := by
    intro ω
    simp only [reflPerm, hg, cfgPerm_invol N τ hτ]
  simp_rw [e]
  exact hrp

/-- **Site reflection positivity in each direction ρ** (τ = the transposition of 0 and ρ). -/
theorem wilson_rp_dir (ρ : Fin 4) (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M (linkPerm N (Equiv.swap 0 ρ) ℓ) ∨ posP N M (linkPerm N (Equiv.swap 0 ρ) ℓ) →
      ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (reflPerm N (Equiv.swap 0 ρ) ω) * f ω ∂(wilsonMeasure N β) :=
  wilson_rp_perm N (Equiv.swap 0 ρ) (fun j => Equiv.swap_apply_self 0 ρ j) M hN β f hf Cf hfC hfdep

end PeierlsPerm

#print axioms PeierlsPerm.action_perm
#print axioms PeierlsPerm.wilson_perm_invariant
#print axioms PeierlsPerm.wilson_rp_perm
#print axioms PeierlsPerm.wilson_rp_dir
