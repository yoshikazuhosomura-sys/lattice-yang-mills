import Lattice.TorusDecV2
import Lattice.WilsonGapV2
/-!
One reflection of the chessboard estimate on the concrete SU(2) Wilson measure of (ℤ/N)⁴, N = 2M: the
Cauchy–Schwarz inequality for the reflected pairing ⟨f, g⟩_Θ := ∫ f(Θω) g(ω) dμ_W through a plane of sites.

Paper correspondence: the chessboard estimate for one-scale rarity, first step (site reflection positivity
`TorusRP.wilson_rp` and the reflection symmetry `TorusRP.wilson_refl_symm` give a positive semidefinite symmetric
form on the bounded measurable functions of the closed positive half; its Cauchy–Schwarz inequality is the step
that is iterated in the chessboard estimate):
  (∫ f(Θω) g(ω) dμ_W)² ≤ (∫ f(Θω) f(ω) dμ_W) · (∫ g(Θω) g(ω) dμ_W).
-/

namespace PeierlsRefl

open MeasureTheory TorusRP LinkReflection

variable (N : ℕ) [NeZero N] (M : ℕ)

/-- The functions on which the reflected pairing is positive: bounded, measurable, depending only on the links of
the closed positive half. -/
def HalfFun (f : (Lk N → QBall) → ℝ) : Prop :=
  Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
    (∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → f ω = f ω')

theorem halfFun_add_smul {f g : (Lk N → QBall) → ℝ} (hf : HalfFun N M f) (hg : HalfFun N M g) (t : ℝ) :
    HalfFun N M (fun ω => f ω + t * g ω) := by
  obtain ⟨hfm, ⟨Cf, hCf⟩, hfd⟩ := hf
  obtain ⟨hgm, ⟨Cg, hCg⟩, hgd⟩ := hg
  refine ⟨hfm.add (measurable_const.mul hgm), ⟨Cf + |t| * Cg, fun ω => ?_⟩, fun ω ω' h => ?_⟩
  · calc |f ω + t * g ω| ≤ |f ω| + |t * g ω| := abs_add_le _ _
      _ = |f ω| + |t| * |g ω| := by rw [abs_mul]
      _ ≤ Cf + |t| * Cg := add_le_add (hCf ω) (mul_le_mul_of_nonneg_left (hCg ω) (abs_nonneg t))
  · simp only [hfd ω ω' h, hgd ω ω' h]

theorem integrable_pair (β : ℝ) {f g : (Lk N → QBall) → ℝ} (hf : HalfFun N M f) (hg : HalfFun N M g) :
    Integrable (fun ω => f (linkRefl (thL N) (sig N) ω) * g ω) (wilsonMeasure N β) := by
  obtain ⟨hfm, ⟨Cf, hCf⟩, -⟩ := hf
  obtain ⟨hgm, ⟨Cg, hCg⟩, -⟩ := hg
  have hP := linkRefl_preserving N
  refine Integrable.of_bound ((hfm.comp hP.measurable).mul hgm).aestronglyMeasurable (Cf * Cg)
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_mul]
  exact mul_le_mul (hCf _) (hCg ω) (abs_nonneg _) (le_trans (abs_nonneg _) (hCf ω))

/-- **Cauchy–Schwarz for the site reflection of the Wilson measure.** -/
theorem wilson_refl_cs (hN : N = 2 * M) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : HalfFun N M f) (hg : HalfFun N M g) :
    (∫ ω, f (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β)) ^ 2 ≤
      (∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β)) *
        (∫ ω, g (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β)) := by
  set a := ∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β)
  set b := ∫ ω, f (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β)
  set c := ∫ ω, g (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β)
  have hsym : ∫ ω, g (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) = b :=
    (wilson_refl_symm N M hN β f g hf.1 hg.1).symm
  have hQ : ∀ t : ℝ, 0 ≤ c * (t * t) + (2 * b) * t + a := by
    intro t
    have hpos := wilson_rp N M hN β (fun ω => f ω + t * g ω) (halfFun_add_smul N M hf hg t).1
      (halfFun_add_smul N M hf hg t).2.1.choose (halfFun_add_smul N M hf hg t).2.1.choose_spec
      (halfFun_add_smul N M hf hg t).2.2
    have hff := integrable_pair N M β hf hf
    have hfg := integrable_pair N M β hf hg
    have hgf := integrable_pair N M β hg hf
    have hgg := integrable_pair N M β hg hg
    have hexp : ∀ ω, (f (linkRefl (thL N) (sig N) ω) + t * g (linkRefl (thL N) (sig N) ω)) *
        (f ω + t * g ω) =
        f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω) +
          t * (g (linkRefl (thL N) (sig N) ω) * f ω) + (t * t) * (g (linkRefl (thL N) (sig N) ω) * g ω) := by
      intro ω; ring
    have hint : ∫ ω, (f (linkRefl (thL N) (sig N) ω) + t * g (linkRefl (thL N) (sig N) ω)) *
        (f ω + t * g ω) ∂(wilsonMeasure N β) = a + t * b + t * b + (t * t) * c := by
      simp_rw [hexp]
      have i1 : Integrable (fun ω => f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω)) (wilsonMeasure N β) :=
        hff.add (hfg.const_mul t)
      have i2 : Integrable (fun ω => f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω) +
          t * (g (linkRefl (thL N) (sig N) ω) * f ω)) (wilsonMeasure N β) := i1.add (hgf.const_mul t)
      have s3 : ∫ ω, (f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω) + t * (g (linkRefl (thL N) (sig N) ω) * f ω) +
          (t * t) * (g (linkRefl (thL N) (sig N) ω) * g ω)) ∂(wilsonMeasure N β) =
          (∫ ω, (f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω) + t * (g (linkRefl (thL N) (sig N) ω) * f ω)) ∂(wilsonMeasure N β)) +
          ∫ ω, (t * t) * (g (linkRefl (thL N) (sig N) ω) * g ω) ∂(wilsonMeasure N β) :=
        integral_add i2 (hgg.const_mul (t * t))
      have s2 : ∫ ω, (f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω) + t * (g (linkRefl (thL N) (sig N) ω) * f ω)) ∂(wilsonMeasure N β) =
          (∫ ω, (f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω)) ∂(wilsonMeasure N β)) +
          ∫ ω, t * (g (linkRefl (thL N) (sig N) ω) * f ω) ∂(wilsonMeasure N β) :=
        integral_add i1 (hgf.const_mul t)
      have s1 : ∫ ω, (f (linkRefl (thL N) (sig N) ω) * f ω + t * (f (linkRefl (thL N) (sig N) ω) * g ω)) ∂(wilsonMeasure N β) =
          (∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β)) +
          ∫ ω, t * (f (linkRefl (thL N) (sig N) ω) * g ω) ∂(wilsonMeasure N β) :=
        integral_add hff (hfg.const_mul t)
      have c1 : ∫ ω, t * (f (linkRefl (thL N) (sig N) ω) * g ω) ∂(wilsonMeasure N β) =
          t * ∫ ω, f (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β) := integral_const_mul t _
      have c2 : ∫ ω, t * (g (linkRefl (thL N) (sig N) ω) * f ω) ∂(wilsonMeasure N β) =
          t * ∫ ω, g (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := integral_const_mul t _
      have c3 : ∫ ω, (t * t) * (g (linkRefl (thL N) (sig N) ω) * g ω) ∂(wilsonMeasure N β) =
          (t * t) * ∫ ω, g (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β) := integral_const_mul (t * t) _
      rw [s3, s2, s1, c1, c2, c3, hsym]
    have : 0 ≤ ∫ ω, (f (linkRefl (thL N) (sig N) ω) + t * g (linkRefl (thL N) (sig N) ω)) *
        (f ω + t * g ω) ∂(wilsonMeasure N β) := hpos
    rw [hint] at this
    linarith
  have hd := discrim_le_zero hQ
  unfold discrim at hd
  nlinarith

end PeierlsRefl

#print axioms PeierlsRefl.wilson_refl_cs
