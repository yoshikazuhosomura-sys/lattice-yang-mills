import Peierls.CubePlaqV1
/-!
A complete chain from the chessboard estimate to a Peierls bound on the concrete SU(2) Wilson measure of (ℤ/2)⁴
(β ≥ 0), in the weak form where the uniform type is bounded by its factor at the corner 0 only:
  (∫ ∏_w F_w(Φ_w ω) dμ_W)^16 ≤ ∏_a B_a,   B_a = Z if no event at a,  B_a = e^{β(#plaquettes − y)} otherwise,
with Z = ∫ 1 dμ_W (μ_W the unnormalised Wilson weight e^{β Σ Re U_p}). Normalised, every corner with an event
contributes the factor (e^{−βy} e^{β #plaquettes}/Z)^{1/16} (rate 1/16 per plaquette; counting the four distinct
images of the plaquette in the uniform type would give 4/16).

Paper correspondence: the chessboard estimate for one-scale rarity, side length 2.
-/

namespace CubeWeak

open MeasureTheory TorusRP CubeTorus CubeChess CubePlaq

theorem Φ_zero (ω : Cfg) : Φ (fun _ => false) ω = ω := by
  simp [Φ, Θ']

theorem bigAt_nonneg (μ ν : Fin 4) (y : ℝ) (ω : Cfg) : 0 ≤ bigAt μ ν y ω := by
  unfold bigAt; split_ifs <;> norm_num

theorem bigAt_le_one (μ ν : Fin 4) (y : ℝ) (ω : Cfg) : bigAt μ ν y ω ≤ 1 := by
  unfold bigAt; split_ifs <;> norm_num

theorem prod_le_zero_factor (μ ν : Fin 4) (y : ℝ) (ω : Cfg) :
    ∏ w : Corner, bigAt μ ν y (Φ w ω) ≤ bigAt μ ν y ω := by
  rw [← Finset.mul_prod_erase Finset.univ (fun w => bigAt μ ν y (Φ w ω)) (Finset.mem_univ (fun _ => false)),
    Φ_zero]
  have h1 : ∏ w ∈ Finset.univ.erase (fun _ => false), bigAt μ ν y (Φ w ω) ≤ 1 :=
    Finset.prod_le_one (fun w _ => bigAt_nonneg μ ν y _) (fun w _ => bigAt_le_one μ ν y _)
  have h0 := bigAt_nonneg μ ν y ω
  nlinarith

section General

variable (N : ℕ) [NeZero N]

theorem cost_nonneg (ω : Lk N → QBall) (p : Lk N × Fin 4) : 0 ≤ 1 - (hol N ω p).re := by
  have := abs_hol_re N ω p
  linarith [(abs_le.mp this).2]

theorem origin_mem (μ ν : Fin 4) (h : μ < ν) : (((0 : Site N), μ), ν) ∈ plaqs N := by
  simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and]; exact h

theorem action_le (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) (ω : Lk N → QBall)
    (h : y < 1 - (hol N ω (((0 : Site N), μ), ν)).re) : action N ω ≤ (plaqs N).card - y := by
  have hs : 1 - (hol N ω (((0 : Site N), μ), ν)).re ≤ ∑ q ∈ plaqs N, (1 - (hol N ω q).re) :=
    Finset.single_le_sum (f := fun q => 1 - (hol N ω q).re) (fun q _ => cost_nonneg N ω q)
      (origin_mem N μ ν hμν)
  rw [Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul, mul_one] at hs
  unfold action
  linarith

theorem integral_const_pi (c : ℝ) : ∫ _ω, c ∂(Measure.pi fun _ : Lk N => haarBall) = c := by
  simp

end General

/-- the uniform type, bounded by its factor at the corner 0 and the maximum of the integrand -/
theorem uniform_le (β : ℝ) (hβ : 0 ≤ β) (μ ν : Fin 4) (hμν : μ < ν) (y : ℝ) :
    ∫ ω, ∏ w : Corner, bigAt μ ν y (Φ w ω) ∂(wilsonMeasure 2 β) ≤
      Real.exp (β * ((plaqs 2).card - y)) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight 2 β ω)) :=
    (continuous_wilsonWeight 2 β).measurable.real_toNNReal
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  have hpt : ∀ ω : Cfg, Real.toNNReal (wilsonWeight 2 β ω) • ∏ w : Corner, bigAt μ ν y (Φ w ω) ≤
      Real.exp (β * ((plaqs 2).card - y)) := by
    intro ω
    have hW : 0 ≤ wilsonWeight 2 β ω := by unfold wilsonWeight; exact (Real.exp_pos _).le
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal _ hW]
    calc wilsonWeight 2 β ω * ∏ w : Corner, bigAt μ ν y (Φ w ω)
        ≤ wilsonWeight 2 β ω * bigAt μ ν y ω := mul_le_mul_of_nonneg_left (prod_le_zero_factor μ ν y ω) hW
      _ ≤ Real.exp (β * ((plaqs 2).card - y)) := by
        unfold bigAt
        split_ifs with hc
        · rw [mul_one]
          unfold wilsonWeight
          exact Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left (action_le 2 μ ν hμν y ω hc) hβ)
        · rw [mul_zero]; exact (Real.exp_pos _).le
  have hnn : ∀ ω : Cfg, 0 ≤ Real.toNNReal (wilsonWeight 2 β ω) • ∏ w : Corner, bigAt μ ν y (Φ w ω) := by
    intro ω
    rw [NNReal.smul_def, smul_eq_mul]
    exact mul_nonneg (NNReal.coe_nonneg _) (Finset.prod_nonneg fun w _ => bigAt_nonneg μ ν y _)
  calc ∫ ω, Real.toNNReal (wilsonWeight 2 β ω) • ∏ w : Corner, bigAt μ ν y (Φ w ω)
        ∂(Measure.pi fun _ : Lk 2 => haarBall)
      ≤ ∫ _ω, Real.exp (β * ((plaqs 2).card - y)) ∂(Measure.pi fun _ : Lk 2 => haarBall) :=
        integral_mono_of_nonneg (Filter.Eventually.of_forall hnn) (integrable_const _)
          (Filter.Eventually.of_forall hpt)
    _ = Real.exp (β * ((plaqs 2).card - y)) := integral_const_pi 2 _

/-- the block function chosen at a corner -/
noncomputable def F (y : ℝ) (o : Option (Fin 4 × Fin 4)) : Cfg → ℝ :=
  match o with
  | none => fun _ => 1
  | some p => bigAt p.1 p.2 y

/-- the bound for the uniform type of a corner -/
noncomputable def Bd (β y : ℝ) (o : Option (Fin 4 × Fin 4)) : ℝ :=
  match o with
  | none => ∫ _ω, (1 : ℝ) ∂(wilsonMeasure 2 β)
  | some _ => Real.exp (β * ((plaqs 2).card - y))

theorem F_nonneg (y : ℝ) (o : Option (Fin 4 × Fin 4)) (ω : Cfg) : 0 ≤ F y o ω := by
  cases o with
  | none => simp [F]
  | some p => exact bigAt_nonneg _ _ _ _

theorem V_le (β : ℝ) (hβ : 0 ≤ β) (y : ℝ) (o : Option (Fin 4 × Fin 4))
    (ho : ∀ p, o = some p → p.1 < p.2) :
    0 ≤ ∫ ω, ∏ w : Corner, F y o (Φ w ω) ∂(wilsonMeasure 2 β) ∧
      ∫ ω, ∏ w : Corner, F y o (Φ w ω) ∂(wilsonMeasure 2 β) ≤ Bd β y o := by
  refine ⟨integral_nonneg fun ω => Finset.prod_nonneg fun w _ => F_nonneg y o _, ?_⟩
  cases o with
  | none => simp [F, Bd]
  | some p => exact uniform_le β hβ p.1 p.2 (ho p rfl) y

/-- **Peierls bound from the chessboard estimate on (ℤ/2)⁴ (weak form).** -/
theorem peierls_two (β : ℝ) (hβ : 0 ≤ β) (y : ℝ) (sel : Corner → Option (Fin 4 × Fin 4))
    (hsel : ∀ w p, sel w = some p → p.1 < p.2) :
    (∫ ω, ∏ w : Corner, F y (sel w) (Φ w ω) ∂(wilsonMeasure 2 β)) ^ 16 ≤
      ∏ a0 : Bool, ∏ a1 : Bool, ∏ a2 : Bool, ∏ a3 : Bool, Bd β y (sel ![a0, a1, a2, a3]) := by
  have hcb := wilson_chessboard_two β (fun w => F y (sel w)) (fun w => by
    cases h : sel w with
    | none => exact base_one
    | some p => exact base_bigAt p.1 p.2 (ne_of_lt (hsel w p h)) y)
  refine le_trans hcb ?_
  have hV := fun a : Corner => V_le β hβ y (sel a) (hsel a)
  apply Finset.prod_le_prod (fun i _ => Finset.prod_nonneg fun j _ => Finset.prod_nonneg fun k _ =>
    Finset.prod_nonneg fun l _ => (hV _).1)
  intro i _
  apply Finset.prod_le_prod (fun j _ => Finset.prod_nonneg fun k _ => Finset.prod_nonneg fun l _ => (hV _).1)
  intro j _
  apply Finset.prod_le_prod (fun k _ => Finset.prod_nonneg fun l _ => (hV _).1)
  intro k _
  apply Finset.prod_le_prod (fun l _ => (hV _).1)
  intro l _
  exact (hV _).2

end CubeWeak

#print axioms CubeWeak.uniform_le
#print axioms CubeWeak.peierls_two
