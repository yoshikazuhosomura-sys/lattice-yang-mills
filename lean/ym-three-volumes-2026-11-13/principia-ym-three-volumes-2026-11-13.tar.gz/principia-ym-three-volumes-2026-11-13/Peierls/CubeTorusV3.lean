import Peierls.PermCSV1
import Peierls.CubeIterV3
/-!
The chessboard estimate for the concrete SU(2) Wilson measure on the torus (ℤ/2)⁴ (side length 2): the sixteen unit
cubes are the corners w ∈ {0,1}⁴, the block functions are the functions of the links of the cube at the origin
(links (y, μ) with y_μ = 0) transported by Φ_w = the composition of the site reflections Θ_d for the directions with
w_d = 1. For every family H of bounded measurable functions of the cube at the origin,
  (∫ ∏_w H_w(Φ_w ω) dμ_W)^16 ≤ ∏ over the corners a of ∫ ∏_w H_a(Φ_w ω) dμ_W.

Paper correspondence: the chessboard estimate for one-scale rarity (Fröhlich–Israel–Lieb–Simon), side length 2.
-/

namespace CubeTorus

open MeasureTheory TorusRP LinkReflection PeierlsPerm PeierlsPermCS CubeChess

abbrev Cfg := Lk 2 → QBall

/-- the site reflection in the direction d -/
noncomputable def Θ (d : Fin 4) : Cfg → Cfg := reflPerm 2 (Equiv.swap 0 d)

/-- the link map of the reflection -/
def tl (d : Fin 4) (ℓ : Lk 2) : Lk 2 := linkPerm 2 (Equiv.swap 0 d) (thL 2 (linkPerm 2 (Equiv.swap 0 d) ℓ))

theorem Θ_apply (d : Fin 4) (ω : Cfg) (ℓ : Lk 2) :
    Θ d ω ℓ = sig 2 (linkPerm 2 (Equiv.swap 0 d) ℓ) (ω (tl d ℓ)) := rfl

theorem tl_comm : ∀ d e : Fin 4, ∀ ℓ : Lk 2, tl e (tl d ℓ) = tl d (tl e ℓ) := by
  unfold tl linkPerm sitePerm thL thS ev
  decide +kernel

theorem tl_snd : ∀ d : Fin 4, ∀ ℓ : Lk 2, (tl d ℓ).2 = ℓ.2 := by
  unfold tl linkPerm sitePerm thL thS ev
  decide +kernel

theorem sig_perm_eq (d : Fin 4) (ℓ ℓ' : Lk 2) (h : ℓ.2 = ℓ'.2) :
    sig 2 (linkPerm 2 (Equiv.swap 0 d) ℓ) = sig 2 (linkPerm 2 (Equiv.swap 0 d) ℓ') := by
  unfold linkPerm; simp only [sig]; rw [h]

theorem sig_comm (ℓ ℓ' : Lk 2) (q : QBall) : sig 2 ℓ (sig 2 ℓ' q) = sig 2 ℓ' (sig 2 ℓ q) := by
  unfold sig; split_ifs <;> rfl

theorem Θ_comm (d e : Fin 4) (ω : Cfg) : Θ d (Θ e ω) = Θ e (Θ d ω) := by
  funext ℓ
  rw [Θ_apply, Θ_apply, Θ_apply, Θ_apply, tl_comm d e ℓ,
    sig_perm_eq e (tl d ℓ) ℓ (tl_snd d ℓ), sig_perm_eq d (tl e ℓ) ℓ (tl_snd e ℓ), sig_comm]

/-- the reflection if the flag is set -/
noncomputable def Θ' (b : Bool) (d : Fin 4) : Cfg → Cfg := if b then Θ d else id

/-- the transport to the corner w -/
noncomputable def Φ (w : Corner) : Cfg → Cfg :=
  Θ' (w 0) 0 ∘ Θ' (w 1) 1 ∘ Θ' (w 2) 2 ∘ Θ' (w 3) 3

theorem Θ'_comm (b : Bool) (d e : Fin 4) (ω : Cfg) : Θ' b d (Θ e ω) = Θ e (Θ' b d ω) := by
  cases b
  · rfl
  · exact Θ_comm d e ω

theorem Θ'_true (d : Fin 4) : Θ' true d = Θ d := by simp [Θ']

theorem Θ'_false (d : Fin 4) : Θ' false d = id := by simp [Θ']

theorem Φ_comm (w : Corner) (e : Fin 4) (ω : Cfg) : Φ w (Θ e ω) = Θ e (Φ w ω) := by
  simp only [Φ, Function.comp_apply, Θ'_comm]

theorem Φ_split0 (w : Corner) (hw : w 0 = true) (ω : Cfg) :
    Φ w ω = Θ 0 (Φ (Function.update w 0 false) ω) := by
  have e0 : Function.update w 0 false 0 = false := by simp
  have e1 : Function.update w 0 false 1 = w 1 := Function.update_of_ne (by decide) _ _
  have e2 : Function.update w 0 false 2 = w 2 := Function.update_of_ne (by decide) _ _
  have e3 : Function.update w 0 false 3 = w 3 := Function.update_of_ne (by decide) _ _
  simp only [Φ, Function.comp_apply, e0, e1, e2, e3, hw, Θ'_true, Θ'_false, id_eq]

theorem Φ_split1 (w : Corner) (hw : w 1 = true) (ω : Cfg) :
    Φ w ω = Θ 1 (Φ (Function.update w 1 false) ω) := by
  have e0 : Function.update w 1 false 0 = w 0 := Function.update_of_ne (by decide) _ _
  have e1 : Function.update w 1 false 1 = false := by simp
  have e2 : Function.update w 1 false 2 = w 2 := Function.update_of_ne (by decide) _ _
  have e3 : Function.update w 1 false 3 = w 3 := Function.update_of_ne (by decide) _ _
  simp only [Φ, Function.comp_apply, e0, e1, e2, e3, hw, Θ'_true, Θ'_false, id_eq]
  rw [Θ'_comm]

theorem Φ_split2 (w : Corner) (hw : w 2 = true) (ω : Cfg) :
    Φ w ω = Θ 2 (Φ (Function.update w 2 false) ω) := by
  have e0 : Function.update w 2 false 0 = w 0 := Function.update_of_ne (by decide) _ _
  have e1 : Function.update w 2 false 1 = w 1 := Function.update_of_ne (by decide) _ _
  have e2 : Function.update w 2 false 2 = false := by simp
  have e3 : Function.update w 2 false 3 = w 3 := Function.update_of_ne (by decide) _ _
  simp only [Φ, Function.comp_apply, e0, e1, e2, e3, hw, Θ'_true, Θ'_false, id_eq]
  rw [Θ'_comm (w 1), Θ'_comm (w 0)]

theorem Φ_split3 (w : Corner) (hw : w 3 = true) (ω : Cfg) :
    Φ w ω = Θ 3 (Φ (Function.update w 3 false) ω) := by
  have e0 : Function.update w 3 false 0 = w 0 := Function.update_of_ne (by decide) _ _
  have e1 : Function.update w 3 false 1 = w 1 := Function.update_of_ne (by decide) _ _
  have e2 : Function.update w 3 false 2 = w 2 := Function.update_of_ne (by decide) _ _
  have e3 : Function.update w 3 false 3 = false := by simp
  simp only [Φ, Function.comp_apply, e0, e1, e2, e3, hw, Θ'_true, Θ'_false, id_eq]
  rw [Θ'_comm (w 2), Θ'_comm (w 1), Θ'_comm (w 0)]

theorem Φ_split (w : Corner) (d : Fin 4) (hw : w d = true) (ω : Cfg) :
    Φ w ω = Θ d (Φ (Function.update w d false) ω) := by
  match d, hw with
  | ⟨0, _⟩, hw => exact Φ_split0 w hw ω
  | ⟨1, _⟩, hw => exact Φ_split1 w hw ω
  | ⟨2, _⟩, hw => exact Φ_split2 w hw ω
  | ⟨3, _⟩, hw => exact Φ_split3 w hw ω

theorem transport (w : Corner) (d : Fin 4) (hw : w d = true) (ω : Cfg) :
    Φ w ω = Φ (Function.update w d false) (Θ d ω) := by
  rw [Φ_comm]; exact Φ_split w d hw ω

/-- the link map of the flagged reflection -/
def tl' (b : Bool) (d : Fin 4) (ℓ : Lk 2) : Lk 2 := if b then tl d ℓ else ℓ

theorem Θ'_det (b : Bool) (d : Fin 4) (X Y : Cfg) (ℓ : Lk 2) (h : X (tl' b d ℓ) = Y (tl' b d ℓ)) :
    Θ' b d X ℓ = Θ' b d Y ℓ := by
  cases b
  · exact h
  · simp only [Θ', if_true, Θ_apply]; simp only [tl', if_true] at h; rw [h]

/-- the link map of the transport -/
def tw (w : Corner) (ℓ : Lk 2) : Lk 2 := tl' (w 3) 3 (tl' (w 2) 2 (tl' (w 1) 1 (tl' (w 0) 0 ℓ)))

theorem Φ_det (w : Corner) (ω ω' : Cfg) (ℓ : Lk 2) (h : ω (tw w ℓ) = ω' (tw w ℓ)) :
    Φ w ω ℓ = Φ w ω' ℓ := by
  simp only [Φ, Function.comp_apply]
  apply Θ'_det; apply Θ'_det; apply Θ'_det; apply Θ'_det
  exact h

/-- the transported links of the cube at the origin lie in the closed positive half when w_d = 0 -/
theorem tw_half : ∀ d : Fin 4, ∀ w : Corner, w d = false → ∀ ℓ : Lk 2, ℓ.1 ℓ.2 = 0 →
    (fixP 2 1 (linkPerm 2 (Equiv.swap 0 d) (tw w ℓ)) ∨ posP 2 1 (linkPerm 2 (Equiv.swap 0 d) (tw w ℓ))) := by
  unfold tw tl' tl linkPerm sitePerm thL thS ev fixP posP tm
  decide +kernel

theorem measurable_Θ (d : Fin 4) : Measurable (Θ d) := by
  unfold Θ reflPerm
  have hP := (cfgPerm_preserving 2 (Equiv.swap 0 d) (fun j => Equiv.swap_apply_self 0 d j)).measurable
  exact hP.comp ((linkRefl_preserving 2).measurable.comp hP)

theorem measurable_Θ' (b : Bool) (d : Fin 4) : Measurable (Θ' b d) := by
  cases b
  · exact measurable_id
  · exact measurable_Θ d

theorem measurable_Φ (w : Corner) : Measurable (Φ w) := by
  unfold Φ
  exact (measurable_Θ' _ _).comp ((measurable_Θ' _ _).comp ((measurable_Θ' _ _).comp (measurable_Θ' _ _)))

/-- bounded measurable functions of the links of the cube at the origin -/
def Base (h : Cfg → ℝ) : Prop :=
  Measurable h ∧ (∃ C, ∀ ω, |h ω| ≤ C) ∧ (∀ ω ω', (∀ ℓ : Lk 2, ℓ.1 ℓ.2 = 0 → ω ℓ = ω' ℓ) → h ω = h ω')

/-- the closed positive half in the direction d -/
def Good (d : Fin 4) (f : Cfg → ℝ) : Prop := HalfFunPerm 2 (Equiv.swap 0 d) 1 f

theorem good_prod (d : Fin 4) (s : Finset Corner) (f : Corner → Cfg → ℝ) (hf : ∀ w ∈ s, Good d (f w)) :
    Good d (fun ω => ∏ w ∈ s, f w ω) := by
  refine ⟨Finset.measurable_prod s (fun w hw => (hf w hw).1), ?_, ?_⟩
  · have hC : ∀ w ∈ s, ∃ C, ∀ ω, |f w ω| ≤ C := fun w hw => (hf w hw).2.1
    choose! C hC using hC
    refine ⟨∏ w ∈ s, C w, fun ω => ?_⟩
    rw [Finset.abs_prod]
    apply Finset.prod_le_prod (fun w _ => abs_nonneg _) (fun w hw => hC w hw ω)
  · intro ω ω' h
    apply Finset.prod_congr rfl
    intro w hw
    exact (hf w hw).2.2 ω ω' h

theorem local_ (d : Fin 4) (h : Cfg → ℝ) (w : Corner) (hh : Base h) (hw : w d = false) :
    Good d (fun ω => h (Φ w ω)) := by
  obtain ⟨hm, ⟨C, hC⟩, hdep⟩ := hh
  refine ⟨hm.comp (measurable_Φ w), ⟨C, fun ω => hC _⟩, fun ω ω' hagree => ?_⟩
  apply hdep
  intro ℓ hℓ
  exact Φ_det w ω ω' ℓ (hagree _ (tw_half d w hw ℓ hℓ))

theorem data (β : ℝ) : Data (wilsonMeasure 2 β) Φ Θ Good Base where
  transport := transport
  good_prod := good_prod
  local_ := local_
  cs := fun d f g hf hg => wilson_refl_cs_dir 2 d 1 rfl β f g hf hg
  rp := fun d f hf => wilson_rp_dir 2 id (fun _ => rfl) d 1 rfl β f hf.1 hf.2.1.choose hf.2.1.choose_spec hf.2.2

/-- **The chessboard estimate for the SU(2) Wilson measure on (ℤ/2)⁴.** -/
theorem wilson_chessboard_two (β : ℝ) (H : Corner → Cfg → ℝ) (hH : ∀ w, Base (H w)) :
    (∫ ω, ∏ w : Corner, H w (Φ w ω) ∂(wilsonMeasure 2 β)) ^ 16 ≤
      ∏ a0 : Bool, ∏ a1 : Bool, ∏ a2 : Bool, ∏ a3 : Bool,
        ∫ ω, ∏ w : Corner, H ![a0, a1, a2, a3] (Φ w ω) ∂(wilsonMeasure 2 β) :=
  chessboard (data β) H hH

end CubeTorus

#print axioms CubeTorus.wilson_chessboard_two
