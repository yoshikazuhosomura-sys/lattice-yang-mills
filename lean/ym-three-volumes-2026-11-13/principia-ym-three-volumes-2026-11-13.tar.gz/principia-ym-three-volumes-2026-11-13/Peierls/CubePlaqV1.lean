import Peierls.CubeTorusV3
/-!
The block functions of the chessboard estimate on (ℤ/2)⁴ include the indicators of the plaquettes at the origin:
for μ < ν and any threshold y, ω ↦ 1[1 − Re U_{(0;μν)}(ω) > y] is a bounded measurable function of the links of the
unit cube at the origin. Hence the chessboard estimate applies to the events "these plaquettes are large".

Paper correspondence: the chessboard estimate for one-scale rarity, the indicator functions of large plaquettes.
-/

namespace CubePlaq

open MeasureTheory TorusRP CubeTorus CubeChess

/-- the indicator that the plaquette (0; μν) has cost larger than y -/
noncomputable def bigAt (μ ν : Fin 4) (y : ℝ) (ω : Cfg) : ℝ :=
  if y < 1 - (hol 2 ω (((0 : Site 2), μ), ν)).re then 1 else 0

theorem hol_dep (μ ν : Fin 4) (hμν : μ ≠ ν) (ω ω' : Cfg)
    (h : ∀ ℓ : Lk 2, ℓ.1 ℓ.2 = 0 → ω ℓ = ω' ℓ) :
    hol 2 ω (((0 : Site 2), μ), ν) = hol 2 ω' (((0 : Site 2), μ), ν) := by
  have e1 : ω ((0 : Site 2), μ) = ω' ((0 : Site 2), μ) := h _ (by simp)
  have e2 : ω ((0 : Site 2) + ev 2 μ, ν) = ω' ((0 : Site 2) + ev 2 μ, ν) :=
    h _ (by simp [ev, Pi.single_apply, Ne.symm hμν])
  have e3 : ω ((0 : Site 2) + ev 2 ν, μ) = ω' ((0 : Site 2) + ev 2 ν, μ) :=
    h _ (by simp [ev, Pi.single_apply, hμν])
  have e4 : ω ((0 : Site 2), ν) = ω' ((0 : Site 2), ν) := h _ (by simp)
  simp only [hol, holQ, Uq]
  rw [e1, e2, e3, e4]

theorem base_bigAt (μ ν : Fin 4) (hμν : μ ≠ ν) (y : ℝ) : Base (bigAt μ ν y) := by
  refine ⟨?_, ⟨1, fun ω => ?_⟩, fun ω ω' h => ?_⟩
  · have hopen : IsOpen {ω : Cfg | y < 1 - (hol 2 ω (((0 : Site 2), μ), ν)).re} :=
      isOpen_lt continuous_const
        (continuous_const.sub (Quaternion.continuous_re.comp (continuous_hol 2 _)))
    exact Measurable.ite hopen.measurableSet measurable_const measurable_const
  · unfold bigAt; split_ifs <;> simp
  · unfold bigAt; rw [hol_dep μ ν hμν ω ω' h]

theorem base_one : Base (fun _ : Cfg => (1 : ℝ)) :=
  ⟨measurable_const, ⟨1, fun _ => by simp⟩, fun _ _ _ => rfl⟩

/-- **The chessboard estimate for large plaquettes on (ℤ/2)⁴**: for every choice, at each corner w, of either no
event or the event that the transported plaquette (0; μ_w ν_w) is large. -/
theorem chessboard_plaquettes (β y : ℝ) (sel : Corner → Option (Fin 4 × Fin 4))
    (hsel : ∀ w p, sel w = some p → p.1 ≠ p.2) :
    (∫ ω, ∏ w : Corner, (match sel w with
        | none => fun _ : Cfg => (1 : ℝ)
        | some p => bigAt p.1 p.2 y) (Φ w ω) ∂(wilsonMeasure 2 β)) ^ 16 ≤
      ∏ a0 : Bool, ∏ a1 : Bool, ∏ a2 : Bool, ∏ a3 : Bool,
        ∫ ω, ∏ w : Corner, (match sel ![a0, a1, a2, a3] with
          | none => fun _ : Cfg => (1 : ℝ)
          | some p => bigAt p.1 p.2 y) (Φ w ω) ∂(wilsonMeasure 2 β) := by
  apply wilson_chessboard_two β (fun w => match sel w with
    | none => fun _ : Cfg => (1 : ℝ)
    | some p => bigAt p.1 p.2 y)
  intro w
  cases h : sel w with
  | none => exact base_one
  | some p => exact base_bigAt p.1 p.2 (hsel w p h) y

end CubePlaq

#print axioms CubePlaq.base_bigAt
#print axioms CubePlaq.chessboard_plaquettes
