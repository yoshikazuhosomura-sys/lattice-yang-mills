import Mathlib
/-!
The chessboard estimate on a 2×2×2×2 block torus, abstract form: four reflections Θ_d (d ∈ Fin 4), a transport
Φ_w for every corner w ∈ {0,1}⁴ with Φ_w = Φ_{w[d:=0]} ∘ Θ_d when w_d = 1, and for each d a class of functions
("the closed positive half in the direction d") with the reflection Cauchy–Schwarz inequality and positivity,
closed under finite products and containing the transports Φ_w of the block functions when w_d = 0.
For a family H of block functions,
  V(H)^16 ≤ ∏ over the 16 corners a of V(the uniform family H_a),   V(H) := ∫ ∏_w H_w(Φ_w ω) dμ.

Paper correspondence: the chessboard estimate for one-scale rarity (Fröhlich–Israel–Lieb–Simon), the case of
side length 2 in every direction; one Cauchy–Schwarz inequality per direction.
-/

namespace CubeChess

open MeasureTheory Finset

variable {Ω : Type*} [MeasurableSpace Ω] (μ : Measure Ω)

/-- corners of the block torus -/
abbrev Corner := Fin 4 → Bool

/-- the value of a family -/
noncomputable def V (Φ : Corner → Ω → Ω) (H : Corner → Ω → ℝ) : ℝ :=
  ∫ ω, ∏ w : Corner, H w (Φ w ω) ∂μ

/-- set the d-th coordinate of every corner to a -/
def T (d : Fin 4) (a : Bool) (H : Corner → Ω → ℝ) : Corner → Ω → ℝ :=
  fun w => H (Function.update w d a)

/-- the abstract hypotheses -/
structure Data (Φ : Corner → Ω → Ω) (Θ : Fin 4 → Ω → Ω) (Good : Fin 4 → (Ω → ℝ) → Prop)
    (Base : (Ω → ℝ) → Prop) : Prop where
  transport : ∀ w d, w d = true → ∀ ω, Φ w ω = Φ (Function.update w d false) (Θ d ω)
  good_prod : ∀ d (s : Finset Corner) (f : Corner → Ω → ℝ), (∀ w ∈ s, Good d (f w)) →
    Good d (fun ω => ∏ w ∈ s, f w ω)
  local_ : ∀ d h w, Base h → w d = false → Good d (fun ω => h (Φ w ω))
  cs : ∀ d f g, Good d f → Good d g →
    (∫ ω, f (Θ d ω) * g ω ∂μ) ^ 2 ≤ (∫ ω, f (Θ d ω) * f ω ∂μ) * (∫ ω, g (Θ d ω) * g ω ∂μ)
  rp : ∀ d f, Good d f → 0 ≤ ∫ ω, f (Θ d ω) * f ω ∂μ

variable {μ} {Φ : Corner → Ω → Ω} {Θ : Fin 4 → Ω → Ω} {Good : Fin 4 → (Ω → ℝ) → Prop}
  {Base : (Ω → ℝ) → Prop}

theorem update_false_of (w : Corner) (d : Fin 4) (h : w d = false) : Function.update w d false = w := by
  funext e; by_cases he : e = d
  · subst he; simp [h]
  · simp [he]

/-- splitting a product over the corners by the d-th coordinate -/
theorem prod_split (d : Fin 4) (g : Corner → ℝ) :
    ∏ w : Corner, g w = (∏ w ∈ univ.filter (fun w : Corner => w d = false), g w) *
      ∏ w ∈ univ.filter (fun w : Corner => w d = false), g (Function.update w d true) := by
  rw [← Finset.prod_filter_mul_prod_filter_not univ (fun w : Corner => w d = false)]
  congr 1
  symm
  apply Finset.prod_nbij' (fun w => Function.update w d true) (fun w => Function.update w d false)
  · intro w hw; simp
  · intro w hw; simp
  · intro w hw
    have hw' : w d = false := by simpa using hw
    simp [update_false_of w d hw']
  · intro w hw
    have hw' : w d = true := by simpa using hw
    funext e; by_cases he : e = d
    · subst he; simp [hw']
    · simp [he]
  · intro w hw; rfl

theorem base_T (H : Corner → Ω → ℝ) (hH : ∀ w, Base (H w)) (d : Fin 4) (a : Bool) :
    ∀ w, Base (T d a H w) := fun w => hH _

/-- **one reflection**: V(H)² ≤ V(T_d^0 H) · V(T_d^1 H), both nonnegative. -/
theorem step (hD : Data μ Φ Θ Good Base) (d : Fin 4) (H : Corner → Ω → ℝ) (hH : ∀ w, Base (H w)) :
    V μ Φ H ^ 2 ≤ V μ Φ (T d false H) * V μ Φ (T d true H) ∧
      0 ≤ V μ Φ (T d false H) ∧ 0 ≤ V μ Φ (T d true H) := by
  set S := univ.filter (fun w : Corner => w d = false) with hS
  have hSd : ∀ w ∈ S, w d = false := fun w hw => (mem_filter.mp hw).2
  set A : Ω → ℝ := fun ω => ∏ w ∈ S, H w (Φ w ω) with hA
  set B : Ω → ℝ := fun ω => ∏ w ∈ S, H (Function.update w d true) (Φ w ω) with hB
  have gA : Good d A := hD.good_prod d S _ (fun w hw => hD.local_ d (H w) w (hH w) (hSd w hw))
  have gB : Good d B := hD.good_prod d S _ (fun w hw =>
    hD.local_ d (H (Function.update w d true)) w (hH _) (hSd w hw))
  have hΦ : ∀ w ∈ S, ∀ ω, Φ (Function.update w d true) ω = Φ w (Θ d ω) := by
    intro w hw ω
    have := hD.transport (Function.update w d true) d (by simp) ω
    rw [this]
    simp [update_false_of w d (hSd w hw)]
  have hV : V μ Φ H = ∫ ω, B (Θ d ω) * A ω ∂μ := by
    unfold V; congr 1; funext ω
    rw [prod_split d (fun w => H w (Φ w ω)), mul_comm]
    congr 1
    simp only [hB]
    apply Finset.prod_congr rfl
    intro w hw
    rw [hΦ w hw ω]
  have hV0 : V μ Φ (T d false H) = ∫ ω, A (Θ d ω) * A ω ∂μ := by
    unfold V T; congr 1; funext ω
    rw [prod_split d (fun w => H (Function.update w d false) (Φ w ω)), mul_comm]
    congr 1
    · simp only [hA]
      apply Finset.prod_congr rfl
      intro w hw
      rw [hΦ w hw ω]
      simp [update_false_of w d (hSd w hw)]
    · simp only [hA]
      apply Finset.prod_congr rfl
      intro w hw
      rw [update_false_of w d (hSd w hw)]
  have hV1 : V μ Φ (T d true H) = ∫ ω, B (Θ d ω) * B ω ∂μ := by
    unfold V T; congr 1; funext ω
    rw [prod_split d (fun w => H (Function.update w d true) (Φ w ω)), mul_comm]
    congr 1
    simp only [hB]
    apply Finset.prod_congr rfl
    intro w hw
    rw [hΦ w hw ω]
    simp
  have hcs := hD.cs d B A gB gA
  rw [← hV, ← hV1, ← hV0] at hcs
  refine ⟨by linarith [hcs, mul_comm (V μ Φ (T d true H)) (V μ Φ (T d false H))], ?_, ?_⟩
  · rw [hV0]; exact hD.rp d A gA
  · rw [hV1]; exact hD.rp d B gB

/-- the iterated product over a list of directions -/
noncomputable def R (μ : Measure Ω) (Φ : Corner → Ω → Ω) : List (Fin 4) → (Corner → Ω → ℝ) → ℝ
  | [], H => V μ Φ H
  | d :: ds, H => R μ Φ ds (T d false H) * R μ Φ ds (T d true H)

theorem iterate (hD : Data μ Φ Θ Good Base) :
    ∀ (ds : List (Fin 4)) (H : Corner → Ω → ℝ), (∀ w, Base (H w)) →
      V μ Φ H ^ (2 ^ ds.length) ≤ R μ Φ ds H ∧
        ∀ d a, 0 ≤ R μ Φ ds (T d a H) := by
  intro ds
  induction ds with
  | nil =>
    intro H hH
    refine ⟨by simp [R], fun d a => ?_⟩
    have := step hD d H hH
    cases a
    · exact this.2.1
    · exact this.2.2
  | cons e ds ih =>
    intro H hH
    obtain ⟨hst, h0, h1⟩ := step hD e H hH
    obtain ⟨i0, _⟩ := ih (T e false H) (base_T H hH e false)
    obtain ⟨i1, _⟩ := ih (T e true H) (base_T H hH e true)
    have hm : V μ Φ H ^ (2 ^ (e :: ds).length) =
        (V μ Φ H ^ 2) ^ (2 ^ ds.length) := by
      rw [← pow_mul]; congr 1; simp [List.length_cons, pow_succ, mul_comm]
    have hnn0 : 0 ≤ V μ Φ (T e false H) ^ (2 ^ ds.length) := pow_nonneg h0 _
    have hnn1 : 0 ≤ V μ Φ (T e true H) ^ (2 ^ ds.length) := pow_nonneg h1 _
    refine ⟨?_, fun d a => ?_⟩
    · rw [hm]
      calc (V μ Φ H ^ 2) ^ (2 ^ ds.length)
          ≤ (V μ Φ (T e false H) * V μ Φ (T e true H)) ^ (2 ^ ds.length) :=
            pow_le_pow_left₀ (sq_nonneg _) hst _
        _ = V μ Φ (T e false H) ^ (2 ^ ds.length) * V μ Φ (T e true H) ^ (2 ^ ds.length) := mul_pow _ _ _
        _ ≤ R μ Φ ds (T e false H) * R μ Φ ds (T e true H) :=
            mul_le_mul i0 i1 hnn1 (le_trans hnn0 i0)
    · -- nonnegativity of the next level: an even power is below it
      obtain ⟨j, _⟩ := ih (T e false (T d a H)) (base_T _ (base_T H hH d a) e false)
      obtain ⟨k, _⟩ := ih (T e true (T d a H)) (base_T _ (base_T H hH d a) e true)
      obtain ⟨_, p0, p1⟩ := step hD e (T d a H) (base_T H hH d a)
      show 0 ≤ R μ Φ ds (T e false (T d a H)) * R μ Φ ds (T e true (T d a H))
      exact mul_nonneg (le_trans (pow_nonneg p0 _) j) (le_trans (pow_nonneg p1 _) k)

/-- composing the four coordinate settings gives the uniform family of a corner -/
theorem T_all (H : Corner → Ω → ℝ) (a0 a1 a2 a3 : Bool) :
    T 3 a3 (T 2 a2 (T 1 a1 (T 0 a0 H))) = fun _ => H ![a0, a1, a2, a3] := by
  funext w
  simp only [T]
  congr 1
  funext j
  fin_cases j <;> simp [Function.update]

/-- **The chessboard estimate on the 2×2×2×2 block torus (abstract).** -/
theorem chessboard (hD : Data μ Φ Θ Good Base) (H : Corner → Ω → ℝ) (hH : ∀ w, Base (H w)) :
    V μ Φ H ^ 16 ≤ ∏ a0 : Bool, ∏ a1 : Bool, ∏ a2 : Bool, ∏ a3 : Bool,
      V μ Φ (fun _ => H ![a0, a1, a2, a3]) := by
  have h := (iterate hD [0, 1, 2, 3] H hH).1
  have e : R μ Φ [0, 1, 2, 3] H = ∏ a0 : Bool, ∏ a1 : Bool, ∏ a2 : Bool, ∏ a3 : Bool,
      V μ Φ (fun _ => H ![a0, a1, a2, a3]) := by
    simp only [R, Fintype.prod_bool, ← T_all]
    ring
  rw [e] at h
  simpa using h

end CubeChess

#print axioms CubeChess.step
#print axioms CubeChess.iterate
#print axioms CubeChess.chessboard
