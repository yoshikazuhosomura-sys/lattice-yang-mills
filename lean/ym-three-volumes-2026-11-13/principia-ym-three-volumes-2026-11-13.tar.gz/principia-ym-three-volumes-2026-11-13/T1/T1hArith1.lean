import Mathlib

/-! # T1h on top of T2c: the stage count `m` with `λ̄ = 3/5` for the lower constants of T1/T2

`tauM R lam m = (π²/4)(1/4)^m + R·lam^m` (
`PaperStageCount16.tauM`, same text). With `R = 1/c`, `lam = 3/5`:
`c = 17/5000 (= 0.0034)`: `m = 22`; `c = 29/1000, 3/100, 1/25`: `m = 17`; `c = 9/500`: `m = 18`.
(The `lower_side` constant `(4/π²)·0.04452²` with `m = 25` is `TauSplit.tauM_cLow_25`.)
`tauM_mono_c`: a larger `c` gives a smaller `tauM`, so any `c₀ ≥ 29/1000` gives `m = 17`.:
 `paper_stage_600` = `PlugArith.paper_stage`
with `λ̄ = 3/5` (`R`, `m` arguments), and `paper_stage_600_c` (`c₀ ≥ 29/1000`, `m = 17`). -/

noncomputable section

namespace StageArith

/-- (= `PaperStageCount16.tauM`) -/
def tauM (R lam : ℝ) (m : ℕ) : ℝ := (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ m + R * lam ^ m

theorem pi_sq_lt : Real.pi ^ 2 < 10 := by
  have := Real.pi_lt_d2; have h0 := Real.pi_pos; nlinarith

theorem tauM_le (R : ℝ) (m : ℕ) : tauM R (3 / 5) m ≤ (10 / 4) * (1 / 4 : ℝ) ^ m + R * (3 / 5) ^ m := by
  unfold tauM
  have h : (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ m ≤ (10 / 4) * (1 / 4 : ℝ) ^ m := by
    gcongr; exact pi_sq_lt.le
  linarith

theorem tau_0034_22 : tauM (1 / (17 / 5000)) (3 / 5) 22 < 1 / 170 :=
  lt_of_le_of_lt (tauM_le _ _) (by norm_num)

theorem tau_29_17 : tauM (1 / (29 / 1000)) (3 / 5) 17 < 1 / 170 :=
  lt_of_le_of_lt (tauM_le _ _) (by norm_num)

theorem tau_3_17 : tauM (1 / (3 / 100)) (3 / 5) 17 < 1 / 170 :=
  lt_of_le_of_lt (tauM_le _ _) (by norm_num)

theorem tau_1_25_17 : tauM (1 / (1 / 25)) (3 / 5) 17 < 1 / 170 :=
  lt_of_le_of_lt (tauM_le _ _) (by norm_num)

theorem tau_9_500_18 : tauM (1 / (9 / 500)) (3 / 5) 18 < 1 / 170 :=
  lt_of_le_of_lt (tauM_le _ _) (by norm_num)

/-- The thresholds are sharp in the stated sense: `m = 21` does not work for `c = 0.0034`,
`m = 16` not for `c = 29/1000` (with `π² > 9.8`). -/
theorem tau_0034_21_fails : 1 / 170 < tauM (1 / (17 / 5000)) (3 / 5) 21 := by
  unfold tauM
  have : 0 ≤ (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ 21 := by positivity
  have h : (1 : ℝ) / 170 < 1 / (17 / 5000) * (3 / 5) ^ 21 := by norm_num
  linarith

theorem tau_29_16_fails : 1 / 170 < tauM (1 / (29 / 1000)) (3 / 5) 16 := by
  unfold tauM
  have : 0 ≤ (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ 16 := by positivity
  have h : (1 : ℝ) / 170 < 1 / (29 / 1000) * (3 / 5) ^ 16 := by norm_num
  linarith

theorem tauM_mono_c {c c' : ℝ} (hc : 0 < c) (hcc : c ≤ c') (m : ℕ) :
    tauM (1 / c') (3 / 5) m ≤ tauM (1 / c) (3 / 5) m := by
  unfold tauM
  have : 1 / c' ≤ 1 / c := one_div_le_one_div_of_le hc hcc
  have h := mul_le_mul_of_nonneg_right this (by positivity : (0 : ℝ) ≤ (3 / 5) ^ m)
  linarith


theorem tauM_nonneg (R lam : ℝ) (hR : 0 ≤ R) (hlam : 0 ≤ lam) (m : ℕ) : 0 ≤ tauM R lam m := by
  unfold tauM; positivity

/-- **T2c, `paper_stage` with `λ̄ = 3/5`** (the form of `PlugArith.paper_stage`, which is
fixed at `λ̄ = 608/1000`; `R` and `m ≥ 5` are arguments): if `τ_m(R) < 1/170` then
`max(a, b) + δ < 1` (`η = 9`, `ε = 1000`, `c ≤ 120`, `c_P ≤ 1/9`, `δ ≤ 1/5`). -/
theorem paper_stage_600 {R : ℝ} {m : ℕ} (hR : 0 ≤ R) (hm : 5 ≤ m)
    (ht : tauM R (3 / 5) m < 1 / 170) {c cP δ : ℝ} (hc0 : 0 ≤ c) (hc : c ≤ 120)
    (hcP : cP ≤ 1 / 9) (hδ : δ ≤ 1 / 5) :
    max ((1 + 1000) * (1 / 16 : ℝ) ^ m + c * (1 + 1 / 9) * tauM R (3 / 5) m)
        ((1 + 1 / 1000) * cP + (1 + 9) * tauM R (3 / 5) m) + δ < 1 := by
  have ht0 := tauM_nonneg R (3 / 5) hR (by norm_num) m
  set t := tauM R (3 / 5) m
  have hq5 : (1 / 16 : ℝ) ^ m ≤ (1 / 16) ^ 5 := pow_le_pow_of_le_one (by norm_num) (by norm_num) hm
  have hq : (1 + 1000) * (1 / 16 : ℝ) ^ m < 1 / 1000 := by
    have : (1 + 1000) * (1 / 16 : ℝ) ^ 5 < 1 / 1000 := by norm_num
    nlinarith
  have ha : c * (1 + 1 / 9) * t ≤ 120 * (1 + 1 / 9) * (1 / 170) := by
    have : c * t ≤ 120 * (1 / 170) := mul_le_mul hc ht.le ht0 (by norm_num)
    nlinarith
  have hmax : max ((1 + 1000) * (1 / 16 : ℝ) ^ m + c * (1 + 1 / 9) * t)
      ((1 + 1 / 1000) * cP + (1 + 9) * t) ≤ 4 / 5 - 1 / 100 := by
    apply max_le
    · norm_num at ha ⊢; linarith
    · nlinarith
  linarith

/-- The stage count closes at `m = 17` for every `c₀ ≥ 29/1000` (`R = 1/c₀`, `λ̄ = 3/5`). -/
theorem paper_stage_600_c {c₀ : ℝ} (hc : 29 / 1000 ≤ c₀) {c cP δ : ℝ} (hc0 : 0 ≤ c)
    (hc' : c ≤ 120) (hcP : cP ≤ 1 / 9) (hδ : δ ≤ 1 / 5) :
    max ((1 + 1000) * (1 / 16 : ℝ) ^ 17 + c * (1 + 1 / 9) * tauM (1 / c₀) (3 / 5) 17)
        ((1 + 1 / 1000) * cP + (1 + 9) * tauM (1 / c₀) (3 / 5) 17) + δ < 1 := by
  have hc00 : 0 < c₀ := by linarith
  have ht := lt_of_le_of_lt (tauM_mono_c (by norm_num : (0 : ℝ) < 29 / 1000) hc 17) tau_29_17
  exact paper_stage_600 (by positivity) (by norm_num) ht hc0 hc' hcP hδ

end StageArith

namespace FaceTorus

/-- `Λ ≤ 2C₊/(c(1 − N^{−4})) ≤ (32/15)·C₊/c` for `N ≥ 2`. -/
theorem torus_lambda_le {N : ℕ} (hN : 2 ≤ N) {lmax diag c Cp : ℝ} (hc : 0 < c) (hCp : 0 ≤ Cp)
    (hup : lmax ≤ Cp) (hd : c / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ diag) :
    lmax / diag ≤ 32 / 15 * Cp / c := by
  have hN' : (2 : ℝ) ≤ N := by exact_mod_cast hN
  have h16 : (16 : ℝ) ≤ (N : ℝ) ^ 4 := by
    have : (2 : ℝ) ^ 4 ≤ (N : ℝ) ^ 4 := pow_le_pow_left₀ (by norm_num) hN' 4
    norm_num at this; linarith
  have hfrac : 1 / (N : ℝ) ^ 4 ≤ 1 / 16 := by
    rw [div_le_div_iff₀ (by linarith) (by norm_num)]; linarith
  have hd' : c / 2 * (15 / 16) ≤ diag := by
    have : c / 2 * (15 / 16) ≤ c / 2 * (1 - 1 / (N : ℝ) ^ 4) :=
      mul_le_mul_of_nonneg_left (by linarith) (by positivity)
    linarith
  have hd0 : 0 < diag := by have : 0 < c / 2 * (15 / 16) := by positivity
                            linarith
  rw [div_le_div_iff₀ hd0 hc]
  have h1 := mul_le_mul_of_nonneg_right hup hc.le
  have h2 := mul_le_mul_of_nonneg_left hd' hCp
  nlinarith

end FaceTorus

namespace T1h

open StageArith

/-- **T1h, the stage count at `c₀ = 3/100`** (`λ̄ = 3/5`): `m = 17` (`τ₁₇(1/c₀) < 1/170`,
`StageArith.tau_3_17`) and the stage inequality of `paper_stage` (`PlugArith`, `λ̄ = 3/5` form). -/
theorem stage_c3 {c cP δ : ℝ} (hc0 : 0 ≤ c) (hc' : c ≤ 120) (hcP : cP ≤ 1 / 9) (hδ : δ ≤ 1 / 5) :
    tauM (1 / (3 / 100)) (3 / 5) 17 < 1 / 170 ∧
    max ((1 + 1000) * (1 / 16 : ℝ) ^ 17 + c * (1 + 1 / 9) * tauM (1 / (3 / 100)) (3 / 5) 17)
        ((1 + 1 / 1000) * cP + (1 + 9) * tauM (1 / (3 / 100)) (3 / 5) 17) + δ < 1 :=
  ⟨tau_3_17, paper_stage_600_c (by norm_num) hc0 hc' hcP hδ⟩

/-- **T1h, `Λ` on the finite torus at `c₀ = 3/100`**: with the upper side `C₊ = 1` (T0) and the
diagonal `≥ (c₀/2)(1 − N^{−4})` (T4b(ii) `torus_face_diag`), `Λ ≤ 32/(15c₀) = 640/9` (`N ≥ 2`).
The infinite-volume form `2/c₀` is not written for the finite torus. -/
theorem torus_lambda_c3 {N : ℕ} (hN : 2 ≤ N) {lmax diag : ℝ} (hup : lmax ≤ 1)
    (hd : (3 / 100 : ℝ) / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ diag) :
    lmax / diag ≤ 640 / 9 := by
  have h := FaceTorus.torus_lambda_le hN (by norm_num : (0 : ℝ) < 3 / 100) (by norm_num : (0 : ℝ) ≤ 1) hup hd
  have e : (32 / 15 * 1 / (3 / 100) : ℝ) = 640 / 9 := by norm_num
  linarith

/-- `32/(15c₀)` at `c₀ = 3/100` is `640/9 ≈ 71.1`; at `c₀ = 29/1000` it is `32000/435 ≈ 73.6`. -/
theorem const_check : (32 / (15 * (3 / 100)) : ℝ) = 640 / 9 := by norm_num

end T1h

end

#print axioms StageArith.tau_3_17
#print axioms StageArith.paper_stage_600_c
#print axioms FaceTorus.torus_lambda_le
#print axioms T1h.stage_c3
#print axioms T1h.torus_lambda_c3
