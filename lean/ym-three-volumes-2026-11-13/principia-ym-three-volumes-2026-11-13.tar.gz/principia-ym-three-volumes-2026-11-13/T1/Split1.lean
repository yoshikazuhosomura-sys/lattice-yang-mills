-- ===== verbatim copy of an earlier file lines 1..4239 (through OneStepCell) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
import Mathlib

/-!
# A uniform bracket for an order-preserving linear iteration (skeleton of Theorem 1)

Setting.  `E` is a real inner product space, `Q` an index type (the momenta), and we work with
families of linear operators `A : Q → E →ₗ[ℝ] E`.  The Loewner order of families is pointwise in
`q` and in the quadratic form:

  `Lw A B  :↔  ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫`.

`M` is a linear map on families which preserves this order (`OrderPreserving M`).  The stages are
`G k = M^[k] G0`.

Part 1 (upper side, order and linearity only).  If `M P ≼ λ P` and `M B ≼ B + e P`
(in : `B = P/ω`, `λ = λ̄`, `e = e_T`), then from `G0 ≼ B + c0 P`
  `G k ≼ B + (λ^k c0 + e Σ_{j<k} λ^j) P`                       (`iterate_upper`, `cSeq_eq`),
and, for `0 ≤ λ < 1`, `P ≽ 0`, `c0 ≤ e/(1-λ)`: `G k ≼ B + (e/(1-λ)) P` for all `k`
(`uniform_upper`).  Two-sided geometric bounds for the differences and convergence of every
quadratic form `⟪x, G k q x⟫` with rate `λ^k/(1-λ)` (`iterate_two_sided`, `quad_tendsto`).
The sharp form: `M G0 ≼ G0` implies `G (k+1) ≼ G k` for all `k` (`iterate_antitone`).

Part 2 (inverse on the range of a projection).  `InvOnRange P G H`: `P` symmetric,
`G (H x) = P x`, `P (H x) = H x` (so `H` is the inverse of `G` on `ran P`, e.g. `H = G⁺` when
`G = P X P`).  No square roots and no C*-algebra are used: the variational inequality
`2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` (equality at `v = H x`) gives the antitonicity of the inverse
on `ran P` (`antitone_inv`), hence
  `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H`   (`inv_lower`),   `m P ≼ G ⇒ H ≼ m⁻¹ P`   (`inv_upper`).

Part 3 (the bracket).  `bracket`: with `B = P/ω`, `h k = ¼ H k`,
  `¼ (ω⁻¹ + e/(1-λ))⁻¹ P ≼ h k ≼ (ω/(4a)) P`   for all `k`, `q`;
`bracket_numeric`: with `ω ≤ 16`, `λ ≤ 0.838`, `e ≤ 15/8`, `a = (4/π²) σ²`, `σ ≥ 0.04452`:
  `(ω/745) P ≼ h k ≼ 312 ω P`.
(`311` needs `σ ≥ 0.04454`, see `const_upper_311`.)
-/

noncomputable section

open scoped RealInnerProductSpace
open Filter Topology
open scoped Real

namespace UniformBracket

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-! ## 0. The Loewner order of families -/

/-- The Loewner order of families of operators, pointwise in `q`. -/
def Lw (A B : Q → E →ₗ[ℝ] E) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

namespace Lw

theorem refl (A : Q → E →ₗ[ℝ] E) : Lw A A := fun _ _ => le_rfl

theorem trans {A B C : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw B C) : Lw A C :=
  fun q x => (h₁ q x).trans (h₂ q x)

theorem add {A B C D : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw C D) : Lw (A + C) (B + D) := by
  intro q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right]
  exact add_le_add (h₁ q x) (h₂ q x)

theorem smul {A B : Q → E →ₗ[ℝ] E} {t : ℝ} (ht : 0 ≤ t) (h : Lw A B) : Lw (t • A) (t • B) := by
  intro q x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_left (h q x) ht

theorem neg {A B : Q → E →ₗ[ℝ] E} (h : Lw A B) : Lw (-B) (-A) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
  linarith [h q x]

/-- Scaling a nonnegative family is monotone in the scalar. -/
theorem smul_left {A : Q → E →ₗ[ℝ] E} {s t : ℝ} (hst : s ≤ t) (hA : Lw 0 A) :
    Lw (s • A) (t • A) := by
  intro q x
  have h0 := hA q x
  simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_right hst h0

end Lw

/-- `M` preserves the Loewner order of families. -/
def OrderPreserving (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E)) : Prop :=
  ∀ A B, Lw A B → Lw (M A) (M B)

/-! ## 1. Part 1: the upper side from order and linearity -/

section Part1

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- The scalar recursion `c_{k+1} = e + λ c_k`, `c_0 = c0`. -/
def cSeq (lam e c0 : ℝ) : ℕ → ℝ
  | 0 => c0
  | k + 1 => e + lam * cSeq lam e c0 k

theorem cSeq_eq (lam e c0 : ℝ) (k : ℕ) :
    cSeq lam e c0 k = lam ^ k * c0 + e * ∑ j ∈ Finset.range k, lam ^ j := by
  induction k with
  | zero => simp [cSeq]
  | succ k ih =>
    have hs : ∑ j ∈ Finset.range k, lam ^ (j + 1) = lam * ∑ j ∈ Finset.range k, lam ^ j := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => pow_succ' lam j)
    rw [cSeq, ih, Finset.sum_range_succ', hs]
    ring

theorem cSeq_nonneg {lam e c0 : ℝ} (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0) (k : ℕ) :
    0 ≤ cSeq lam e c0 k := by
  induction k with
  | zero => exact hc0
  | succ k ih => exact add_nonneg he (mul_nonneg hlam ih)

theorem cSeq_le {lam e c0 : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hc0 : c0 ≤ e / (1 - lam)) (k : ℕ) : cSeq lam e c0 k ≤ e / (1 - lam) := by
  have h1 : (1 - lam) ≠ 0 := by linarith
  have hd : e / (1 - lam) * (1 - lam) = e := div_mul_cancel₀ e h1
  induction k with
  | zero => exact hc0
  | succ k ih =>
    have h := mul_le_mul_of_nonneg_left ih hlam0
    show e + lam * cSeq lam e c0 k ≤ e / (1 - lam)
    nlinarith

/-- One step of the upper comparison. -/
theorem step_upper (hM : OrderPreserving M) {P B G : Q → E →ₗ[ℝ] E} {lam e c : ℝ}
    (hc : 0 ≤ c) (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P))
    (hG : Lw G (B + c • P)) : Lw (M G) (B + (e + lam * c) • P) := by
  have h1 : Lw (M G) (M B + c • M P) := by
    have := hM _ _ hG
    rwa [map_add, map_smul] at this
  have h2 : Lw (M B + c • M P) ((B + e • P) + c • (lam • P)) := Lw.add hB (Lw.smul hc hP)
  have h3 : (B + e • P) + c • (lam • P) = B + (e + lam * c) • P := by
    rw [smul_smul, add_assoc, ← add_smul, mul_comm c lam]
  rw [h3] at h2
  exact h1.trans h2

/-- **Upper side, all stages** (with the source term): `G k ≼ B + c_k P`,
`c_k = λ^k c0 + e Σ_{j<k} λ^j` (`cSeq_eq`). -/
theorem iterate_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + cSeq lam e c0 k • P) := by
  intro k
  induction k with
  | zero => simpa [cSeq] using hG0
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact step_upper M hM (cSeq_nonneg hlam he hc0 k) hP hB ih

/-- **Uniform upper bound**: `G k ≼ B + (e/(1-λ)) P` for all `k`. -/
theorem uniform_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hc0' : c0 ≤ e / (1 - lam)) (hP0 : Lw 0 P)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + (e / (1 - lam)) • P) := by
  intro k
  exact (iterate_upper M hM hlam0 he hc0 hP hB hG0 k).trans
    (Lw.add (Lw.refl B) (Lw.smul_left (cSeq_le hlam0 hlam1 hc0' k) hP0))

/-- The pure contraction (no source): `G0 ≼ c P ⇒ G k ≼ λ^k c P`. -/
theorem iterate_P_le (hM : OrderPreserving M) {P : Q → E →ₗ[ℝ] E} {lam : ℝ}
    (hlam : 0 ≤ lam) (hP : Lw (M P) (lam • P)) : ∀ k, Lw ((⇑M)^[k] P) (lam ^ k • P) := by
  intro k
  induction k with
  | zero => simpa using Lw.refl P
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have h1 : Lw (M ((⇑M)^[k] P)) (lam ^ k • M P) := by
      have := hM _ _ ih
      rwa [map_smul] at this
    have h2 : Lw (lam ^ k • M P) (lam ^ k • lam • P) := Lw.smul (pow_nonneg hlam k) hP
    rw [smul_smul, ← pow_succ] at h2
    exact h1.trans h2

theorem upper_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw X (c • P)) : Lw (M X) ((c * lam) • P) := by
  have h1 : Lw (M X) (c • M P) := by
    have := hM _ _ hX
    rwa [map_smul] at this
  have h2 : Lw (c • M P) (c • lam • P) := Lw.smul hc hP
  rw [smul_smul] at h2
  exact h1.trans h2

theorem lower_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw (-(c • P)) X) : Lw (-((c * lam) • P)) (M X) := by
  have h1 : Lw (-(c • M P)) (M X) := by
    have := hM _ _ hX
    rwa [map_neg, map_smul] at this
  have h2 : Lw (-(c • lam • P)) (-(c • M P)) := Lw.neg (Lw.smul hc hP)
  rw [smul_smul] at h2
  exact h2.trans h1

/-- Two-sided geometric bounds propagate: `-bP ≼ D ≼ bP ⇒ -bλ^k P ≼ M^[k] D ≼ bλ^k P`. -/
theorem iterate_two_sided (hM : OrderPreserving M) {P D : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) D) (hhi : Lw D (b • P)) :
    ∀ k, Lw (-((b * lam ^ k) • P)) ((⇑M)^[k] D) ∧ Lw ((⇑M)^[k] D) ((b * lam ^ k) • P) := by
  intro k
  induction k with
  | zero => simpa using And.intro hlo hhi
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have hc : 0 ≤ b * lam ^ k := mul_nonneg hb (pow_nonneg hlam0 k)
    have e1 : b * lam ^ (k + 1) = b * lam ^ k * lam := by ring
    rw [e1]
    exact ⟨lower_step' M hM hc hP ih.1, upper_step' M hM hc hP ih.2⟩

theorem iter_sub (k : ℕ) (a b : Q → E →ₗ[ℝ] E) :
    (⇑M)^[k] (a - b) = (⇑M)^[k] a - (⇑M)^[k] b := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [Function.iterate_succ_apply', ih, map_sub]

/-- **Geometric convergence of every quadratic form** `⟪x, G k q x⟫`, from the two-sided bound
`-bP ≼ G 1 - G 0 ≼ bP`. -/
theorem quad_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P)) (q : Q) (x : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q x⟫) atTop (𝓝 L) ∧
      ∀ k, |⟪x, (⇑M)^[k] G0 q x⟫ - L| ≤ b * ⟪x, P q x⟫ * lam ^ k / (1 - lam) := by
  set s : ℕ → ℝ := fun k => ⟪x, (⇑M)^[k] G0 q x⟫ with hs
  have hdiff : ∀ k, s (k + 1) - s k = ⟪x, (⇑M)^[k] (M G0 - G0) q x⟫ := by
    intro k
    simp only [hs]
    rw [iter_sub, Function.iterate_succ_apply]
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hu : ∀ k, dist (s k) (s (k + 1)) ≤ b * ⟪x, P q x⟫ * lam ^ k := by
    intro k
    obtain ⟨h1, h2⟩ := iterate_two_sided M hM hlam0 hb hP hlo hhi k
    have l1 := h1 q x
    have l2 := h2 q x
    simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right, Pi.smul_apply,
      LinearMap.smul_apply, real_inner_smul_right] at l1 l2
    rw [Real.dist_eq, abs_sub_comm, abs_le, hdiff k]
    constructor <;> nlinarith
  obtain ⟨L, hL⟩ := cauchySeq_tendsto_of_complete
    (cauchySeq_of_le_geometric lam (b * ⟪x, P q x⟫) hlam1 hu)
  refine ⟨L, hL, fun k => ?_⟩
  have := dist_le_of_le_geometric_of_tendsto lam (b * ⟪x, P q x⟫) hlam1 hu hL k
  rwa [Real.dist_eq] at this

/-- **Sharp form (ii′)**: one step `M G0 ≼ G0` makes the whole sequence decrease. -/
theorem iterate_antitone (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0) :
    ∀ k, Lw ((⇑M)^[k + 1] G0) ((⇑M)^[k] G0) := by
  intro k
  induction k with
  | zero => simpa using h1
  | succ k ih =>
    simp only [Function.iterate_succ_apply'] at ih ⊢
    exact hM _ _ ih

/-- `M` maps the cone `0 ≼ ·` into itself. -/
theorem nonneg_iterate (hM : OrderPreserving M) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw 0 ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => simpa using hG
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have := hM _ _ ih
    rwa [map_zero] at this

/-- **Dominated comparison** (the order part of dropping the alias terms):
if `M₀ ≼ M` on the cone and both preserve the order, then `M₀^[k] G ≼ M^[k] G` for `G ≽ 0`. -/
theorem iterate_dominated (M₀ : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))
    (hM : OrderPreserving M) (hM₀ : OrderPreserving M₀)
    (hdom : ∀ A, Lw 0 A → Lw (M₀ A) (M A)) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw ((⇑M₀)^[k] G) ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => exact Lw.refl G
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply']
    exact (hM₀ _ _ ih).trans (hdom _ (nonneg_iterate M hM hG k))

/-- Polarization: for symmetric `A`, `⟪x, A y⟫` is a combination of quadratic forms. -/
theorem polarization {A : E →ₗ[ℝ] E} (hA : A.IsSymmetric) (x y : E) :
    ⟪x, A y⟫ = (⟪x + y, A (x + y)⟫ - ⟪x - y, A (x - y)⟫) / 4 := by
  have h1 : ⟪y, A x⟫ = ⟪x, A y⟫ := by rw [← hA x y, real_inner_comm]
  simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left, inner_sub_right]
  linarith [h1]

/-- **Convergence of every matrix entry** `⟪x, G k q y⟫` (symmetric stages, by polarization). -/
theorem bilin_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric) (q : Q) (x y : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q y⟫) atTop (𝓝 L) := by
  obtain ⟨L1, h1, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x + y)
  obtain ⟨L2, h2, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x - y)
  refine ⟨(L1 - L2) / 4, ?_⟩
  exact Tendsto.congr (fun k => (polarization (hsym k q) x y).symm) ((h1.sub h2).div_const 4)

end Part1

/-! ## 2. Part 2: the inverse on the range of a projection -/

section Part2

variable {P G H : E →ₗ[ℝ] E}

/-- `H` inverts `G` on the range of the symmetric projection `P`. -/
structure InvOnRange (P G H : E →ₗ[ℝ] E) : Prop where
  symm_P : P.IsSymmetric
  comp : ∀ x, G (H x) = P x
  range : ∀ x, P (H x) = H x

theorem proj_nonneg (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) (v : E) :
    0 ≤ ⟪v, P v⟫ := by
  have : ⟪v, P v⟫ = ⟪P v, P v⟫ := by rw [hPs v (P v), hPP]
  rw [this]
  exact real_inner_self_nonneg

theorem quad_eq (h : InvOnRange P G H) (x : E) : ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  calc ⟪H x, G (H x)⟫ = ⟪H x, P x⟫ := by rw [h.comp]
    _ = ⟪P (H x), x⟫ := (h.symm_P (H x) x).symm
    _ = ⟪H x, x⟫ := by rw [h.range]
    _ = ⟪x, H x⟫ := real_inner_comm _ _

/-- The variational inequality: `2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` for all `v`. -/
theorem variational (h : InvOnRange P G H) (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (x v : E) : 2 * ⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫ := by
  have key := hGp (v - H x)
  have f1 : ⟪H x, G v⟫ = ⟪P x, v⟫ := by rw [← hGs (H x) v, h.comp]
  have f2 : ⟪H x, P x⟫ = ⟪x, H x⟫ := by
    rw [← h.symm_P (H x) x, h.range]
    exact real_inner_comm _ _
  have f3 : ⟪v, P x⟫ = ⟪P x, v⟫ := real_inner_comm _ _
  simp only [map_sub, h.comp, inner_sub_left, inner_sub_right] at key
  rw [f1, f2, f3] at key
  linarith

/-- Equality in the variational inequality at `v = H x`. -/
theorem variational_eq (h : InvOnRange P G H) (x : E) :
    2 * ⟪P x, H x⟫ - ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  rw [quad_eq h x, h.symm_P x (H x), h.range]
  ring

/-- **Antitonicity of the inverse on `ran P`**: `G ≼ G'` (`G` symmetric, `≽ 0`) gives
`H' ≼ H`. -/
theorem antitone_inv {G' H' : E →ₗ[ℝ] E} (h : InvOnRange P G H) (h' : InvOnRange P G' H')
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫) (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫)
    (x : E) : ⟪x, H' x⟫ ≤ ⟪x, H x⟫ := by
  have h1 := variational_eq h' x
  have h2 := variational h hGs hGp x (H' x)
  have h3 := hle (H' x)
  linarith

theorem invOnRange_smul (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) {m : ℝ} (hm : m ≠ 0) :
    InvOnRange P (m • P) (m⁻¹ • P) where
  symm_P := hPs
  comp x := by
    rw [LinearMap.smul_apply, LinearMap.smul_apply, map_smul, hPP, smul_smul,
      mul_inv_cancel₀ hm, one_smul]
  range x := by simp only [LinearMap.smul_apply, map_smul, hPP]

theorem isSymmetric_smul (hPs : P.IsSymmetric) (m : ℝ) : (m • P).IsSymmetric := by
  intro a b
  simp only [LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right, hPs a b]

/-- **Lower bound on the inverse**: `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H` on all of `E`. -/
theorem inv_lower {Mx : ℝ} (hMx : 0 < Mx) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ Mx * ⟪v, P v⟫) (x : E) :
    Mx⁻¹ * ⟪x, P x⟫ ≤ ⟪x, H x⟫ := by
  have := antitone_inv h (invOnRange_smul h.symm_P hPP hMx.ne') hGs hGp
    (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hle v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

/-- **Upper bound on the inverse**: `m P ≼ G ⇒ H ≼ m⁻¹ P` on all of `E`. -/
theorem inv_upper {m : ℝ} (hm : 0 < m) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hge : ∀ v, m * ⟪v, P v⟫ ≤ ⟪v, G v⟫) (x : E) :
    ⟪x, H x⟫ ≤ m⁻¹ * ⟪x, P x⟫ := by
  have hpos : ∀ v, 0 ≤ ⟪v, (m • P) v⟫ := by
    intro v
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg hm.le (proj_nonneg h.symm_P hPP v)
  have := antitone_inv (invOnRange_smul h.symm_P hPP hm.ne') h (isSymmetric_smul h.symm_P m)
    hpos (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hge v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

end Part2

/-! ## 3. Part 3: the bracket -/

section Part3

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The bracket (abstract form of Theorem 1).**  `B = P/ω`, the stages `G k = M^[k] G0`,
`H k q` the inverse of `G k q` on `ran P q`, and `h = ¼ H`.  Inputs: the one-step bounds
`M P ≼ λ P`, `M B ≼ B + e P` (upper side), and the lower bound `a B ≼ G k` for all `k`
(kept as a hypothesis). -/
theorem bracket (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q)
    {lam e a : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (ha : 0 < a)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    (1 / 4) * ((ω q)⁻¹ + e / (1 - lam))⁻¹ * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ ω q / (4 * a) * ⟪x, P q x⟫ := by
  set B : Q → E →ₗ[ℝ] E := fun q => (ω q)⁻¹ • P q with hBdef
  set c : ℝ := e / (1 - lam) with hcdef
  have h1lam : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he h1lam.le
  have hP0 : Lw 0 P := by
    intro q' v
    simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right]
    exact proj_nonneg (hPs q') (hPP q') v
  have hG0' : Lw G0 (B + (0 : ℝ) • P) := by simpa using hG0
  have hup := uniform_upper M hM hlam0 hlam1 he le_rfl (div_nonneg he h1lam.le) hP0 hPstep
    hBstep hG0' k
  set G := (⇑M)^[k] G0 with hGdef
  have hinv : InvOnRange (P q) (G q) (H k q) := ⟨hPs q, hH k q, hHP k q⟩
  have hupv : ∀ v, ⟪v, G q v⟫ ≤ ((ω q)⁻¹ + c) * ⟪v, P q v⟫ := by
    intro v
    have := hup q v
    simp only [hBdef, Pi.add_apply, LinearMap.add_apply, Pi.smul_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right] at this
    linarith
  have hlowv : ∀ v, (a * (ω q)⁻¹) * ⟪v, P q v⟫ ≤ ⟪v, G q v⟫ := by
    intro v
    have := hlow k q v
    simp only [hBdef, Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at this
    linarith
  have hωi : 0 < (ω q)⁻¹ := inv_pos.mpr (hω q)
  have hm : 0 < a * (ω q)⁻¹ := mul_pos ha hωi
  have hGp : ∀ v, 0 ≤ ⟪v, G q v⟫ := fun v =>
    le_trans (mul_nonneg hm.le (proj_nonneg (hPs q) (hPP q) v)) (hlowv v)
  have hMx : 0 < (ω q)⁻¹ + c := by linarith
  have lo := inv_lower hMx hinv (hPP q) (hsym k q) hGp hupv x
  have up := inv_upper hm hinv (hPP q) hlowv x
  have hinv' : (a * (ω q)⁻¹)⁻¹ = ω q / a := by rw [mul_inv, inv_inv]; ring
  rw [hinv'] at up
  have e2 : ω q / (4 * a) * ⟪x, P q x⟫ = (1 / 4) * (ω q / a * ⟪x, P q x⟫) := by ring
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  constructor
  · nlinarith
  · rw [e2]; nlinarith

/-- Arithmetic of the lower constant: `ω/745 ≤ ¼ (ω⁻¹ + e/(1-λ))⁻¹`. -/
theorem const_lower {ω lam e : ℝ} (hω : 0 < ω) (hω16 : ω ≤ 16) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8) :
    ω / 745 ≤ (1 / 4) * (ω⁻¹ + e / (1 - lam))⁻¹ := by
  set c := e / (1 - lam) with hcdef
  have h1 : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he0 h1.le
  have hc : c * (1 - lam) = e := div_mul_cancel₀ e h1.ne'
  have hc1 : c * 0.162 ≤ 15 / 8 := by nlinarith
  have ht : 0 < ω⁻¹ + c := by positivity
  have e1 : 4 * (ω⁻¹ + c) * ω = 4 + 4 * (c * ω) := by
    rw [mul_assoc, add_mul, inv_mul_cancel₀ hω.ne']; ring
  have hkey : 4 * (ω⁻¹ + c) * ω ≤ 745 := by
    rw [e1]
    nlinarith [mul_le_mul_of_nonneg_left hω16 hc0]
  have e3 : (1 / 4 : ℝ) * (ω⁻¹ + c)⁻¹ = 1 / (4 * (ω⁻¹ + c)) := by
    rw [one_div, one_div, mul_inv]
  rw [e3, div_le_div_iff₀ (by norm_num) (by positivity)]
  nlinarith

/-- Arithmetic of the upper constant: `σ ≥ 0.04452`, `a = (4/π²) σ²` give `ω/(4a) ≤ 312 ω`. -/
theorem const_upper {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2) :
    ω / (4 * a) ≤ 312 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hσ2 : (0.0019820304 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1248 * a := by
    rw [ha, show 1248 * (4 / π ^ 2 * σ ^ 2) = 4992 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- The constant `311` needs `σ ≥ 0.04454` (from `σ ≥ 0.04452` one gets only `311.2`). -/
theorem const_upper_311 {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04454 ≤ σ)
    (ha : a = 4 / π ^ 2 * σ ^ 2) : ω / (4 * a) ≤ 311 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.8697 := by nlinarith
  have hσ2 : (0.0019838116 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1244 * a := by
    rw [ha, show 1244 * (4 / π ^ 2 * σ ^ 2) = 4976 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- **The bracket with numbers** (Theorem 1 of + §2.9, numbers as hypotheses):
`(ω/745) P ≼ h k ≼ 312 ω P` for all stages `k` and momenta `q`. -/
theorem bracket_numeric (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q) (hω16 : ∀ q, ω q ≤ 16)
    {lam e σ a : ℝ} (hlam0 : 0 ≤ lam) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8)
    (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    ω q / 745 * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * ω q * ⟪x, P q x⟫ := by
  have hlam1 : lam < 1 := by linarith
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  obtain ⟨lo, up⟩ := bracket M hM hPs hPP hω hlam0 hlam1 he0 ha0 hPstep hBstep hG0 hlow hsym
    hH hHP k q x
  have hPx := proj_nonneg (hPs q) (hPP q) x
  have c1 := const_lower (hω q) (hω16 q) hlam he0 he
  have c2 := const_upper (hω q) hσ ha
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo,
    le_trans up (mul_le_mul_of_nonneg_right c2 hPx)⟩

/-- **Sharp form on the inverse side**: if `G (k+1) ≼ G k` then `h k ≼ h (k+1)`. -/
theorem stage_action_increasing {P G G' H H' : E →ₗ[ℝ] E} (h : InvOnRange P G H)
    (h' : InvOnRange P G' H') (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫) (x : E) :
    ⟪x, ((1 / 4 : ℝ) • H') x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H) x⟫ := by
  have := antitone_inv h h' hGs hGp hle x
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  linarith

end Part3

end UniformBracket


-- ===== verbatim copy of an earlier file (without its import line and #print axioms) =====

/-!
# The one-step norm `λ̄ ≤ 0.838` : the polynomial stages

Setting: `α = 1/8`, four directions.  For one direction `ν` the two aliases `ζ_ν ∈ {0,1}` of
`r_ζ = (q + 2πζ)/2` give `x_ν(r_ζ) = 4α sin²(r_{ζ,ν}/2)` equal to `σ_ν/2` (`ζ_ν = 0`) and
`(1-σ_ν)/2` (`ζ_ν = 1`), where `σ_ν = sin²(q_ν/4) ∈ [0,1]`.  The weight `cos²(r_{ζ,c}/2)` of the
distinguished direction `c` is `1-σ_c` and `σ_c` (`alias_x`, `alias_w`).

Stages, from the back:
* S6 `Dlin_le`: the linear inequality in `y = σ_c(1-σ_c) ≥ 0` with `t = 3/10`:
  `D(y) = 429/512 - (13/40) y ≤ 429/512 ≤ 0.838`.
* S5 one-direction alias sums (`sumT_*`, `sumS_*`) and the transverse bounds on `σ ∈ [0,1]`
  (`Tq_le`, `Tx2_le`, `Tq_antitone`).
* S4 the alias sum over `ζ ∈ {0,1}⁴` of a monomial is the product of one-direction sums
  (`alias_factor`); the closed forms `Msum_eq`, `Lsum_eq`.
* S4' `Msum_le`, `Lsum_le`, `Dsum_le`: `(1+t) M_c + (1+1/t) L̄_c ≤ 429/512` on the box `[0,1]⁴`.
* S2 (matrix level, any finite index type): Lemma 4 of `comp_identity`
  `(N u)_μ = (π_μ - x_μ) u_μ - s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν` for `u ⊥ s̃`, and the square bound
  `normSq_le` (`(a-b)² ≤ (1+t)a² + (1+1/t)b²` and weighted Cauchy–Schwarz).
-/

noncomputable section

open scoped Real
open Finset

namespace OneStepNorm

/-! ## S6. The linear inequality in one variable -/

/-- `D(y)` of after the transverse directions are set to `σ = 0`
(splitting parameter `t`):
`(1+t)·¼(125/64 − 19y/4) + (1+1/t)·(3/8)(3y/4 + 1/8)`. -/
def Dlin (t y : ℝ) : ℝ :=
  (1 + t) * ((1 / 4) * (125 / 64 - 19 / 4 * y)) + (1 + 1 / t) * ((3 / 8) * (3 / 4 * y + 1 / 8))

theorem Dlin_eq (y : ℝ) : Dlin (3 / 10) y = 429 / 512 - 13 / 40 * y := by
  unfold Dlin
  ring

theorem Dlin_le {y : ℝ} (hy : 0 ≤ y) : Dlin (3 / 10) y ≤ 429 / 512 := by
  rw [Dlin_eq]
  linarith

/-- The value at the end point `y = 1/4` (0.7566). -/
theorem Dlin_quarter : Dlin (3 / 10) (1 / 4) = 1937 / 2560 := by
  rw [Dlin_eq]
  norm_num

theorem const_429 : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-! ## S5. One direction: the two aliases -/

/-- `x = 4α sin²(r/2)` (`α = 1/8`) at the two aliases of one direction, `σ = sin²(q/4)`. -/
def xa (σ : ℝ) : Bool → ℝ
  | false => σ / 2
  | true => (1 - σ) / 2

/-- The weight `cos²(r_c/2)` at the two aliases of the distinguished direction. -/
def wa (σ : ℝ) : Bool → ℝ
  | false => 1 - σ
  | true => σ

/-- Trigonometric bridge for `x`: with `θ = q/4` the alias `ζ = 1` shifts `θ` by `π/2`. -/
theorem alias_x (θ : ℝ) (b : Bool) :
    (1 / 2) * Real.sin (θ + (if b then π / 2 else 0)) ^ 2 = xa (Real.sin θ ^ 2) b := by
  cases b <;> simp [xa, Real.sin_add_pi_div_two, Real.cos_sq'] <;> ring

/-- Trigonometric bridge for the weight `cos²(r_c/2)`. -/
theorem alias_w (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) ^ 2 = wa (Real.sin θ ^ 2) b := by
  cases b <;> simp [wa, Real.cos_add_pi_div_two, Real.cos_sq']

theorem sigma_mem (θ : ℝ) : 0 ≤ Real.sin θ ^ 2 ∧ Real.sin θ ^ 2 ≤ 1 :=
  ⟨sq_nonneg _, Real.sin_sq_le_one θ⟩

theorem xa_mem {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ xa σ b ∧ xa σ b ≤ 1 / 2 := by
  cases b <;> simp only [xa] <;> constructor <;> linarith

/-- `T[(1-x)²]`, the transverse factor of `M_c`. -/
def Tq (σ : ℝ) : ℝ := 5 / 4 - σ / 2 + σ ^ 2 / 2

/-- `T[x²]`. -/
def Tx2 (σ : ℝ) : ℝ := (σ ^ 2 + (1 - σ) ^ 2) / 4

/-- `y = σ(1-σ) = S_c[x]`. -/
def yv (σ : ℝ) : ℝ := σ * (1 - σ)

theorem sumT_one : ∑ _b : Bool, (1 : ℝ) = 2 := by
  rw [Fintype.sum_bool]
  norm_num

theorem sumT_x (σ : ℝ) : ∑ b, xa σ b = 1 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_x2 (σ : ℝ) : ∑ b, xa σ b ^ 2 = Tx2 σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tx2]
  ring

theorem sumT_1mx (σ : ℝ) : ∑ b, (1 - xa σ b) = 3 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_1mx2 (σ : ℝ) : ∑ b, (1 - xa σ b) ^ 2 = Tq σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tq]
  ring

theorem sumS_one (σ : ℝ) : ∑ b, wa σ b = 1 := by
  rw [Fintype.sum_bool]
  simp only [wa]
  ring

theorem sumS_x (σ : ℝ) : ∑ b, wa σ b * xa σ b = yv σ := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

theorem sumS_x2 (σ : ℝ) : ∑ b, wa σ b * xa σ b ^ 2 = yv σ / 4 := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

/-! Transverse bounds on `σ ∈ [0,1]` (the maximum is at `σ = 0`). -/

theorem Tq_pos (σ : ℝ) : 0 < Tq σ := by
  unfold Tq
  nlinarith [sq_nonneg (σ - 1 / 2)]

theorem Tq_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tq σ ≤ 5 / 4 := by
  unfold Tq
  nlinarith

/-- The factor `T[(1-x)²]` decreases on `[0, 1/2]` ("正かつ減る"). -/
theorem Tq_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) : Tq σ' ≤ Tq σ := by
  unfold Tq
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem Tx2_nonneg (σ : ℝ) : 0 ≤ Tx2 σ := by
  unfold Tx2
  positivity

theorem Tx2_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tx2 σ ≤ 1 / 4 := by
  unfold Tx2
  nlinarith

theorem Tx2_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) :
    Tx2 σ' ≤ Tx2 σ := by
  unfold Tx2
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem yv_nonneg {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ := by
  unfold yv
  exact mul_nonneg h0 (by linarith)

theorem yv_le (σ : ℝ) : yv σ ≤ 1 / 4 := by
  unfold yv
  nlinarith [sq_nonneg (σ - 1 / 2)]

/-! ## S4. Four directions: the alias sum factors monomial by monomial -/

/-- The alias sum over `ζ ∈ {0,1}⁴` of a product of one-direction factors is the product of the
one-direction sums. -/
theorem alias_factor (f0 f1 f2 f3 : Bool → ℝ) :
    ∑ b0, ∑ b1, ∑ b2, ∑ b3, f0 b0 * f1 b1 * f2 b2 * f3 b3 =
      (∑ b, f0 b) * (∑ b, f1 b) * (∑ b, f2 b) * (∑ b, f3 b) := by
  simp only [Fintype.sum_bool]
  ring

/-- `π_c − x_c` at the alias `(bc, b1, b2, b3)` (`c` the distinguished direction). -/
def pmx (σc σ1 σ2 σ3 : ℝ) (bc b1 b2 b3 : Bool) : ℝ :=
  (1 - xa σ1 b1) * (1 - xa σ2 b2) * (1 - xa σ3 b3) - xa σc bc

/-- `η̄_c = Σ_{μ≠c} x_μ (x_a + x_b)/2 · e₂(x_c, x_a, x_b)` (`{a,b}` the complement of `{μ,c}`). -/
def etaBar (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * ((x2 + x3) / 2) * (xc * x2 + xc * x3 + x2 * x3) +
  x2 * ((x1 + x3) / 2) * (xc * x1 + xc * x3 + x1 * x3) +
  x3 * ((x1 + x2) / 2) * (xc * x1 + xc * x2 + x1 * x2)

/-- `M_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) (π_c − x_c)²(r_ζ)`. -/
def Msum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2

/-- `L̄_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) η̄_c(r_ζ)`. -/
def Lsum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
    wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)

/-- Closed form of `M_c` (`¼[Π_{ν≠c}(5/4 − σ_ν/2 + σ_ν²/2) − (19/4) y_c]`). -/
theorem Msum_eq (σc σ1 σ2 σ3 : ℝ) :
    Msum σc σ1 σ2 σ3 = (1 / 4) * (Tq σ1 * Tq σ2 * Tq σ3 - 19 / 4 * yv σc) := by
  simp only [Msum, pmx, Fintype.sum_bool, xa, wa, Tq, yv]
  ring

/-- Closed form of `L̄_c` (`¼ Σ_{μ≠c} ½[y_c(T_a + T_b + ¼) + (T_a + T_b)/4]`). -/
theorem Lsum_eq (σc σ1 σ2 σ3 : ℝ) :
    Lsum σc σ1 σ2 σ3 = (1 / 4) *
      ((1 / 2) * (yv σc * (Tx2 σ2 + Tx2 σ3 + 1 / 4) + (Tx2 σ2 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ3 + 1 / 4) + (Tx2 σ1 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ2 + 1 / 4) + (Tx2 σ1 + Tx2 σ2) / 4)) := by
  simp only [Lsum, etaBar, Fintype.sum_bool, xa, wa, Tx2, yv]
  ring

/-! ## S4'. The bound on the box -/

theorem Msum_le {σc σ1 σ2 σ3 : ℝ} (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1)
    (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Msum σc σ1 σ2 σ3 ≤ (1 / 4) * (125 / 64 - 19 / 4 * yv σc) := by
  rw [Msum_eq]
  have hprod : Tq σ1 * Tq σ2 * Tq σ3 ≤ (5 / 4) * (5 / 4) * (5 / 4) := by
    apply mul_le_mul _ (Tq_le h3.1 h3.2) (Tq_pos _).le (by norm_num)
    exact mul_le_mul (Tq_le h1.1 h1.2) (Tq_le h2.1 h2.2) (Tq_pos _).le (by norm_num)
  linarith

theorem Lsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Lsum σc σ1 σ2 σ3 ≤ (3 / 8) * (3 / 4 * yv σc + 1 / 8) := by
  rw [Lsum_eq]
  have hy := yv_nonneg hc.1 hc.2
  have t1 := Tx2_le h1.1 h1.2
  have t2 := Tx2_le h2.1 h2.2
  have t3 := Tx2_le h3.1 h3.2
  have m1 := mul_le_mul_of_nonneg_left t1 hy
  have m2 := mul_le_mul_of_nonneg_left t2 hy
  have m3 := mul_le_mul_of_nonneg_left t3 hy
  nlinarith

/-- **The one-step bound on the box** (`t = 3/10`): for every direction `c` and every
`σ ∈ [0,1]⁴`, `D_c = (1+t) M_c + (1+1/t) L̄_c ≤ 429/512`. -/
theorem Dsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 429 / 512 := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have hD := Dlin_le (yv_nonneg hc.1 hc.2)
  unfold Dlin at hD
  have e1 : (1 + 1 / (3 / 10 : ℝ)) = 13 / 3 := by norm_num
  rw [e1]
  rw [e1] at hD
  nlinarith

/-- The same with the number of the request: `≤ 0.838`. -/
theorem Dsum_le_0838 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 0.838 :=
  (Dsum_le hc h1 h2 h3).trans const_429

/-- The same in the trigonometric variables: `σ_ν = sin²(θ_ν)`, `θ_ν = q_ν/4`. -/
theorem Dsum_le_trig (θc θ1 θ2 θ3 : ℝ) :
    (1 + 3 / 10) * Msum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) +
      (1 + 1 / (3 / 10)) *
        Lsum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) ≤
      429 / 512 :=
  Dsum_le (sigma_mem θc) (sigma_mem θ1) (sigma_mem θ2) (sigma_mem θ3)

/-! ## S6'. A general splitting parameter `t`, and `t = 31/100` -/

/-- For any `t > 0` the box bound reduces to the one-variable `D(y)`. -/
theorem Dsum_le_Dlin {t σc σ1 σ2 σ3 : ℝ} (ht : 0 < t) (hc : 0 ≤ σc ∧ σc ≤ 1)
    (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + t) * Msum σc σ1 σ2 σ3 + (1 + 1 / t) * Lsum σc σ1 σ2 σ3 ≤ Dlin t (yv σc) := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have a : 0 ≤ 1 + t := by linarith
  have b : 0 ≤ 1 + 1 / t := by positivity
  unfold Dlin
  have k1 := mul_le_mul_of_nonneg_left hM a
  have k2 := mul_le_mul_of_nonneg_left hL b
  linarith

theorem Dlin31_eq (y : ℝ) : Dlin (31 / 100) y = 26593 / 31744 - 18209 / 49600 * y := by
  unfold Dlin
  ring

/-- With `t = 31/100` (close to the optimal `√(12/125)` at `y = 0`):
`D_c ≤ 26593/31744 = 0.83773…`. -/
theorem Dsum_le_31 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 31 / 100) * Msum σc σ1 σ2 σ3 + (1 + 1 / (31 / 100)) * Lsum σc σ1 σ2 σ3 ≤
      26593 / 31744 := by
  have h := Dsum_le_Dlin (t := 31 / 100) (by norm_num) hc h1 h2 h3
  rw [Dlin31_eq] at h
  have hy := yv_nonneg hc.1 hc.2
  linarith

theorem const_31_0838 : (26593 / 31744 : ℝ) ≤ 0.838 := by norm_num

/-- With `λ = 26593/31744` and `e = 15/8`: `1 + 16 e/(1-λ) ≤ 186`, i.e. `c₁ ≥ 1/186`
(found that `λ = 0.838` gives `186.19`). -/
theorem const_c1_186 : 1 + 16 * ((15 / 8 : ℝ) / (1 - 26593 / 31744)) ≤ 186 := by norm_num

/-! ## S1(b). The alias vector stays physical: `w_ζ ⊥ s(r_ζ)` -/

/-- One direction, with `θ = q/4` and `r/2 = θ + [ζ]π/2`:
`cos(r/2)·(−1)^ζ·sin(r/2) = ½ sin(q/2)`  (`C(r) s(r) = s(2r)/2` and `s(2r_ζ) = S_ζ s(q)`). -/
theorem alias_orth (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) * (if b then -1 else 1) *
      Real.sin (θ + (if b then π / 2 else 0)) = (1 / 2) * Real.sin (2 * θ) := by
  cases b <;> simp [Real.cos_add_pi_div_two, Real.sin_add_pi_div_two, Real.sin_two_mul] <;> ring

/-- **`w_ζ ⊥ s(r_ζ)`**: with `w_ν = cos(r_ν/2)(−1)^{ζ_ν} u_ν` and `s_ν(r_ζ) = sin(r_ν/2)`,
`⟨w_ζ, s(r_ζ)⟩ = ½ ⟨u, s(q)⟩` (`s_ν(q) = sin(q_ν/2) = sin(2θ_ν)`); so `u ⊥ s(q)` gives
`w_ζ ⊥ s(r_ζ)`. -/
theorem alias_orth_sum {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) =
      (1 / 2) * ∑ ν, u ν * Real.sin (2 * θ ν) := by
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro ν _
  have h := alias_orth (θ ν) (ζ ν)
  calc (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))
      = u ν * (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))) := by ring
    _ = u ν * ((1 / 2) * Real.sin (2 * θ ν)) := by rw [h]
    _ = 1 / 2 * (u ν * Real.sin (2 * θ ν)) := by ring

theorem alias_orth_zero {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ)
    (hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) = 0 := by
  rw [alias_orth_sum, hu, mul_zero]

/-! ## e_T ≤ 15/8 : the scalar part -/

/-- `4 sin²(q/2) = 16 σ (1 − σ)` with `σ = sin²(q/4)` (`θ = q/4`). -/
theorem omega_dir (θ : ℝ) :
    4 * Real.sin (2 * θ) ^ 2 = 16 * (Real.sin θ ^ 2) * (1 - Real.sin θ ^ 2) := by
  rw [Real.sin_two_mul]
  have h := Real.sin_sq_add_cos_sq θ
  have hc : Real.cos θ ^ 2 = 1 - Real.sin θ ^ 2 := by linarith
  calc 4 * (2 * Real.sin θ * Real.cos θ) ^ 2 = 16 * Real.sin θ ^ 2 * Real.cos θ ^ 2 := by ring
    _ = _ := by rw [hc]

/-- `4 ω(q/2) − ω(q) = Σ 16 σ_ν² ≥ 0` in the `σ` variables
(`ω(q/2) = Σ 4σ_ν`, `ω(q) = Σ 16 σ_ν(1−σ_ν)`). -/
theorem omega_half (s0 s1 s2 s3 : ℝ) :
    16 * (s0 * (1 - s0) + s1 * (1 - s1) + s2 * (1 - s2) + s3 * (1 - s3)) ≤
      4 * (4 * s0 + 4 * s1 + 4 * s2 + 4 * s3) := by
  nlinarith [sq_nonneg s0, sq_nonneg s1, sq_nonneg s2, sq_nonneg s3]

/-- `ω` at the alias `ζ`: `Σ_ν 4 (σ_ν or 1 − σ_ν)`; for `ζ ≠ 0` and `σ ∈ [0, 1/2]⁴` it is `≥ 2`. -/
def omA (s0 s1 s2 s3 : ℝ) (b0 b1 b2 b3 : Bool) : ℝ :=
  4 * (if b0 then 1 - s0 else s0) + 4 * (if b1 then 1 - s1 else s1) +
    4 * (if b2 then 1 - s2 else s2) + 4 * (if b3 then 1 - s3 else s3)

theorem omA_ge_two {s0 s1 s2 s3 : ℝ} (h0 : 0 ≤ s0 ∧ s0 ≤ 1 / 2) (h1 : 0 ≤ s1 ∧ s1 ≤ 1 / 2)
    (h2 : 0 ≤ s2 ∧ s2 ≤ 1 / 2) (h3 : 0 ≤ s3 ∧ s3 ≤ 1 / 2) (b0 b1 b2 b3 : Bool)
    (hb : (b0 || b1 || b2 || b3) = true) : 2 ≤ omA s0 s1 s2 s3 b0 b1 b2 b3 := by
  unfold omA
  cases b0 <;> cases b1 <;> cases b2 <;> cases b3 <;> simp at hb ⊢ <;> linarith

/-- **The scalar step of `e_T ≤ 15/8`**: if the `ζ = 0` term satisfies `¼ F₀ ≤ 1/ω` and the
fifteen others `F_ζ ≤ 1/2` (from `ν² cos² ≤ 1` and `ω(r_ζ) ≥ 2`), then `¼ Σ_ζ F_ζ ≤ 1/ω + 15/8`. -/
theorem eT_sum (F : Bool → Bool → Bool → Bool → ℝ) {w : ℝ}
    (h0 : (1 / 4) * F false false false false ≤ w)
    (hF : ∀ b0 b1 b2 b3, (b0 || b1 || b2 || b3) = true → F b0 b1 b2 b3 ≤ 1 / 2) :
    (1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, F b0 b1 b2 b3 ≤ w + 15 / 8 := by
  simp only [Fintype.sum_bool]
  have := hF true true true true rfl
  have := hF true true true false rfl
  have := hF true true false true rfl
  have := hF true true false false rfl
  have := hF true false true true rfl
  have := hF true false true false rfl
  have := hF true false false true rfl
  have := hF true false false false rfl
  have := hF false true true true rfl
  have := hF false true true false rfl
  have := hF false true false true rfl
  have := hF false true false false rfl
  have := hF false false true true rfl
  have := hF false false true false rfl
  have := hF false false false true rfl
  linarith

/-! ## S2. Matrix level: Lemma 4 and the square bound -/

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- `(N u)_μ = π_μ u_μ + s̃_μ Σ_{ν≠μ} (1 − E_{μν}) s̃_ν u_ν`
(`N = diag π + diag s̃ 𝔅 diag s̃`, `𝔅_{μν} = 1 − E_{μν}` off the diagonal, `𝔅_{μμ} = 0`). -/
def Nap (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ) (μ : ι) : ℝ :=
  pi μ * u μ + st μ * ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)

/-- **Lemma 4 of **: for `u ⊥ s̃`,
`(N u)_μ = (π_μ − s̃_μ²) u_μ − s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν`. -/
theorem comp_identity (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (μ : ι) :
    Nap pi st E u μ =
      (pi μ - st μ ^ 2) * u μ - st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
  unfold Nap
  have h1 : ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)
      = ∑ ν ∈ univ.erase μ, st ν * u ν - ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro ν _
    ring
  have h2 : ∑ ν ∈ univ.erase μ, st ν * u ν = -(st μ * u μ) := by
    rw [Finset.sum_erase_eq_sub (Finset.mem_univ μ), hu]
    ring
  rw [h1, h2]
  ring

/-- `(a − b)² ≤ (1+t) a² + (1+1/t) b²` for `t > 0`. -/
theorem sq_split (a b : ℝ) {t : ℝ} (ht : 0 < t) :
    (a - b) ^ 2 ≤ (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 := by
  have key : (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 - (a - b) ^ 2 = (t * a + b) ^ 2 / t := by
    field_simp
    ring
  have : 0 ≤ (t * a + b) ^ 2 / t := by positivity
  linarith

omit [Fintype ι] [DecidableEq ι] in
/-- Weighted Cauchy–Schwarz: `(Σ w a b)² ≤ (Σ w a²)(Σ w b²)` for `w ≥ 0`. -/
theorem wcs (s : Finset ι) (w a b : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s, w i * (a i * b i)) ^ 2 ≤ (∑ i ∈ s, w i * a i ^ 2) * ∑ i ∈ s, w i * b i ^ 2 := by
  apply Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul s
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i _
    apply le_of_eq
    ring

/-- The componentwise square bound (the corollary of Lemma 4). -/
theorem comp_sq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) := by
  rw [comp_identity pi st E u hu μ]
  have h := sq_split ((pi μ - st μ ^ 2) * u μ)
    (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ht
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ 1 + 1 / t := by positivity
  have hb : (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ^ 2 ≤
      st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
    rw [mul_pow]
    exact mul_le_mul_of_nonneg_left hcs (sq_nonneg _)
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hb hc
  linarith

/-- **The square bound** `|N u|² ≤ Σ_μ [(1+t)(π_μ − x_μ)² u_μ² + (1+1/t) x_μ ρ'_μ Σ_{ν≠μ} E_{μν} u_ν²]`
for `u ⊥ s̃`, `E ≥ 0`, `x = s̃²`, `ρ'_μ = Σ_{ν≠μ} E_{μν} x_ν`. -/
theorem normSq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2))) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le pi st E u hu hE ht μ

end MatrixLevel

/-! ## S3. The specific `E` and `η ≤ η̄` (directions `c, 1, 2, 3`, all `x ∈ [0, 1/2]`) -/

/-- `E_{μν} = (x_ρ + x_σ)/2 − x_ρ x_σ/3` as a function of the complementary pair `{ρ, σ}`. -/
def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

theorem Ef_nonneg {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) : 0 ≤ Ef y z := by
  unfold Ef
  nlinarith [mul_le_mul_of_nonneg_left hz.2 hy.1]

theorem Ef_le {y z : ℝ} (hy : 0 ≤ y) (hz : 0 ≤ z) : Ef y z ≤ (y + z) / 2 := by
  unfold Ef
  nlinarith [mul_nonneg hy hz]

/-- `ρ'_μ = Σ_{λ≠μ} E_{μλ} x_λ`, the other three directions being `c, a, b`. -/
def rhoP (xc xa xb : ℝ) : ℝ := Ef xa xb * xc + Ef xc xb * xa + Ef xc xa * xb

theorem rhoP_nonneg {xc xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (ha : 0 ≤ xa ∧ xa ≤ 1 / 2)
    (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) : 0 ≤ rhoP xc xa xb := by
  unfold rhoP
  have e1 := mul_nonneg (Ef_nonneg ha hb) hc.1
  have e2 := mul_nonneg (Ef_nonneg hc hb) ha.1
  have e3 := mul_nonneg (Ef_nonneg hc ha) hb.1
  linarith

/-- `ρ'_μ ≤ e₂(x_{−μ})`. -/
theorem rhoP_le {xc xa xb : ℝ} (hc : 0 ≤ xc) (ha : 0 ≤ xa) (hb : 0 ≤ xb) :
    rhoP xc xa xb ≤ xc * xa + xc * xb + xa * xb := by
  unfold rhoP
  have e1 := mul_le_mul_of_nonneg_right (Ef_le ha hb) hc
  have e2 := mul_le_mul_of_nonneg_right (Ef_le hc hb) ha
  have e3 := mul_le_mul_of_nonneg_right (Ef_le hc ha) hb
  nlinarith

/-- `η_c = Σ_{μ≠c} x_μ E_{μc} ρ'_μ` (directions `c, 1, 2, 3`). -/
def eta (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * Ef x2 x3 * rhoP xc x2 x3 + x2 * Ef x1 x3 * rhoP xc x1 x3 + x3 * Ef x1 x2 * rhoP xc x1 x2

/-- One term of `η ≤ η̄`. -/
theorem eta_term_le {xc xm xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (hm : 0 ≤ xm)
    (ha : 0 ≤ xa ∧ xa ≤ 1 / 2) (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) :
    xm * Ef xa xb * rhoP xc xa xb ≤ xm * ((xa + xb) / 2) * (xc * xa + xc * xb + xa * xb) := by
  apply mul_le_mul (mul_le_mul_of_nonneg_left (Ef_le ha.1 hb.1) hm)
    (rhoP_le hc.1 ha.1 hb.1) (rhoP_nonneg hc ha hb)
  exact mul_nonneg hm (by linarith [ha.1, hb.1])

/-- **`η_c ≤ η̄_c`** (`0 ≤ E_{μν} ≤ (x_ρ + x_σ)/2`, `0 ≤ ρ'_μ ≤ e₂(x_{−μ})`). -/
theorem eta_le_etaBar {xc x1 x2 x3 : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (h1 : 0 ≤ x1 ∧ x1 ≤ 1 / 2)
    (h2 : 0 ≤ x2 ∧ x2 ≤ 1 / 2) (h3 : 0 ≤ x3 ∧ x3 ≤ 1 / 2) :
    eta xc x1 x2 x3 ≤ etaBar xc x1 x2 x3 := by
  unfold eta etaBar
  have k1 := eta_term_le hc h1.1 h2 h3
  have k2 := eta_term_le hc h2.1 h1 h3
  have k3 := eta_term_le hc h3.1 h1 h2
  linarith

/-- The coefficient of `u_c²` in the alias sum with the true `η_c` is bounded by `D_c`
(`(1+t) M_c + (1+1/t) L̄_c` with `η̄_c`), alias by alias. -/
theorem alias_coeff_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤ 429 / 512 := by
  have hw : ∀ b, 0 ≤ wa σc b := by
    intro b
    cases b <;> simp only [wa] <;> linarith [hc.1, hc.2]
  have step : ∀ bc b1 b2 b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      (1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) := by
    intro bc b1 b2 b3
    have he := eta_le_etaBar (xa_mem hc.1 hc.2 bc) (xa_mem h1.1 h1.2 b1) (xa_mem h2.1 h2.2 b2)
      (xa_mem h3.1 h3.2 b3)
    have hm := mul_le_mul_of_nonneg_left he (hw bc)
    have hpos : (0 : ℝ) ≤ 1 + 1 / (3 / 10) := by norm_num
    nlinarith [mul_le_mul_of_nonneg_left hm hpos]
  have hD := Dsum_le hc h1 h2 h3
  unfold Msum Lsum at hD
  have hsum : ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) := by
    apply Finset.sum_le_sum; intro bc _
    apply Finset.sum_le_sum; intro b1 _
    apply Finset.sum_le_sum; intro b2 _
    apply Finset.sum_le_sum; intro b3 _
    exact step bc b1 b2 b3
  have hsplit : ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) =
      (1 + 3 / 10) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
      (1 + 1 / (3 / 10)) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) := by
    simp only [Fintype.sum_bool]
    ring
  rw [hsplit] at hsum
  nlinarith

/-! ## S2'. Swapping the off-diagonal double sum (`Σ_μ a_μ Σ_{ν≠μ} E_{μν} v_ν = Σ_ν v_ν η_ν`) -/

section Swap

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem swap_erase (a : ι → ℝ) (E : ι → ι → ℝ) (v : ι → ℝ) :
    ∑ μ, a μ * ∑ ν ∈ univ.erase μ, E μ ν * v ν =
      ∑ ν, v ν * ∑ μ ∈ univ.erase ν, a μ * E μ ν := by
  simp only [Finset.sum_erase_eq_sub (Finset.mem_univ _), mul_sub, Finset.sum_sub_distrib,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  congr 1
  · apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro y _
    ring
  · apply Finset.sum_congr rfl
    intro x _
    ring

end Swap

/-! ## Bridge to `UniformBracket` : a coordinate bound gives `M P ≼ λ P` -/

section Bridge

open scoped RealInnerProductSpace

variable {Q : Type*} {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The Loewner order of families, copied verbatim from `UniformBracket.Lw`. -/
def Lw (A B : Q → V →ₗ[ℝ] V) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

/-- If, in orthonormal coordinates `coord`, the quadratic form of `M P` is bounded by a diagonal
form `Σ_c D_c (P x)_c²` with every `D_c ≤ λ`, then `M P ≼ λ P` (the hypothesis `hPstep` of
`UniformBracket.bracket`). -/
theorem lw_of_coord_bound (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (D : Q → Fin 4 → ℝ) {lam : ℝ}
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, D q c * coord (P q x) c ^ 2)
    (hD : ∀ q c, D q c ≤ lam) : Lw MP (lam • P) := by
  intro q x
  have hPx : ⟪x, P q x⟫ = ∑ c, coord (P q x) c ^ 2 := by
    have h := hPs q x (P q x)
    rw [hPP q x] at h
    rw [← h, hcoord]
  have hsum : ∑ c, D q c * coord (P q x) c ^ 2 ≤ ∑ c, lam * coord (P q x) c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (hD q c) (sq_nonneg _)
  rw [← Finset.mul_sum] at hsum
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [hPx]
  exact (hrep q x).trans hsum

/-- The `D_c` of for the four directions (the other three in increasing order). -/
def Dc (σ : Fin 4 → ℝ) (c : Fin 4) : ℝ :=
  ![(1 + 3 / 10) * Msum (σ 0) (σ 1) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 0) (σ 1) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 1) (σ 0) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 1) (σ 0) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 2) (σ 0) (σ 1) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 2) (σ 0) (σ 1) (σ 3),
    (1 + 3 / 10) * Msum (σ 3) (σ 0) (σ 1) (σ 2) + (1 + 1 / (3 / 10)) * Lsum (σ 3) (σ 0) (σ 1) (σ 2)]
    c

theorem Dc_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) : Dc σ c ≤ 429 / 512 := by
  fin_cases c
  · exact Dsum_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact Dsum_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-- **The hand-over to `UniformBracket`**: if the quadratic form of `M P` at `q` is bounded by
`Σ_c D_c(σ(q)) (P x)_c²` (the alias representation, not formalized here), with
`σ_ν(q) = sin²(q_ν/4) ∈ [0,1]`, then `M P ≼ λ P` with `λ = 429/512 ≤ 0.838`. -/
theorem MP_le (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (σ : Q → Fin 4 → ℝ)
    (hσ : ∀ q ν, 0 ≤ σ q ν ∧ σ q ν ≤ 1)
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, Dc (σ q) c * coord (P q x) c ^ 2) :
    Lw MP ((429 / 512 : ℝ) • P) :=
  lw_of_coord_bound MP P hPs hPP coord hcoord (fun q c => Dc (σ q) c) hrep
    (fun q c => Dc_le (hσ q) c)

end Bridge

end OneStepNorm


-- ===== body of an earlier file (without its import line and #print axioms) =====

/-!
# Fourier analysis on a finite abelian group, decimation by a homomorphism, and the
symbols of the block-constraint operator

Momenta are the characters `ψ : AddChar F ℂ` of a finite additive group `F`
(for the torus `F = (ℤ/2L)^d` these are `y ↦ exp(i k·y)`).  Convention
`f̂(ψ) = Σ_y ψ(-y) f(y)`.

* §1 the transform: translation, convolution, inversion, Plancherel, injectivity;
* §2 decimation along `β : G →+ F` (coarse points `X ↦ β X`): the sampled function has the
  alias-sum transform `|F| (f∘β)^(φ) = |G| Σ_{ψ ∘ β = φ} f̂(ψ)`;
* §3 the constraint operator `(Ca)(X) = Σ_r c(r) a(βX + r)` and its adjoint: alias sums for
  `C`, `C†`, `C C†` and `C T C†` (`T` translation invariant on the fine group);
* §4 a lower bound on the symbol at one alias per coarse momentum gives a real-space lower bound
  `‖C† w‖² ≥ (|G|/|F|) c₀ ‖w‖²`, and `C` is onto (complex and real kernels);
* §5 intertwining of gradients from a symbol identity (`C ∇ = ∇ ∘ res`);
* §6 the torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X`, where `|F|/|G| = 2^d`;
* §7 the alias representation of the one-step map on the projection (linear algebra).
-/

open Finset
open scoped ComplexConjugate

noncomputable section

namespace TorusFourier

/-! ## §1 The transform -/

section Transform

variable {F : Type*} [AddCommGroup F] [Fintype F]

/-- Fourier transform, `f̂(ψ) = Σ_y ψ(-y) f(y)`. -/
def ft (f : F → ℂ) (ψ : AddChar F ℂ) : ℂ := ∑ y, ψ (-y) * f y

theorem ft_add (f g : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => f y + g y) ψ = ft f ψ + ft g ψ := by
  unfold ft; rw [← Finset.sum_add_distrib]; congr 1; ext y; ring

theorem ft_const_mul (k : ℂ) (f : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => k * f y) ψ = k * ft f ψ := by
  unfold ft; rw [Finset.mul_sum]; congr 1; ext y; ring

theorem ft_sum {α : Type*} (s : Finset α) (f : α → F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ i ∈ s, f i y) ψ = ∑ i ∈ s, ft (f i) ψ := by
  unfold ft
  simp_rw [Finset.mul_sum]
  exact Finset.sum_comm

/-- Translation becomes multiplication by the character. -/
theorem ft_translate (f : F → ℂ) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => f (y + r)) ψ = ψ r * ft f ψ := by
  unfold ft
  rw [Finset.mul_sum]
  refine Fintype.sum_equiv (Equiv.addRight r) _ _ (fun y => ?_)
  simp only [Equiv.coe_addRight]
  rw [show -y = -(y + r) + r by abel, AddChar.map_add_eq_mul]
  ring

/-- Convolution `(f ⋆ g)(x) = Σ_y f(y) g(x - y)`. -/
def conv (f g : F → ℂ) (x : F) : ℂ := ∑ y, f y * g (x - y)

/-- Convolution becomes multiplication. -/
theorem ft_conv (f g : F → ℂ) (ψ : AddChar F ℂ) : ft (conv f g) ψ = ft f ψ * ft g ψ := by
  unfold conv
  rw [ft_sum]
  have h : ∀ y, ft (fun x => f y * g (x - y)) ψ = ψ (-y) * f y * ft g ψ := by
    intro y
    rw [ft_const_mul]
    have := ft_translate g (-y) ψ
    simp only [← sub_eq_add_neg] at this
    rw [this]; ring
  simp_rw [h]
  unfold ft
  rw [Finset.sum_mul]

/-- Inversion: `Σ_ψ ψ(y) f̂(ψ) = |F| f(y)`. -/
theorem ft_inv (f : F → ℂ) (y : F) :
    ∑ ψ : AddChar F ℂ, ψ y * ft f ψ = (Fintype.card F : ℂ) * f y := by
  classical
  unfold ft
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  have h : ∀ x, ∑ ψ : AddChar F ℂ, ψ y * (ψ (-x) * f x) =
      (if y - x = 0 then (Fintype.card F : ℂ) else 0) * f x := by
    intro x
    rw [← AddChar.sum_apply_eq_ite, Finset.sum_mul]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    rw [sub_eq_add_neg, AddChar.map_add_eq_mul]; ring
  simp_rw [h, sub_eq_zero, ite_mul, zero_mul]
  rw [Finset.sum_ite_eq]
  simp

/-- The transform is injective. -/
theorem ft_injective {f g : F → ℂ} (h : ∀ ψ, ft f ψ = ft g ψ) : f = g := by
  funext y
  have h1 := ft_inv f y
  have h2 := ft_inv g y
  simp_rw [h] at h1
  have hc : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  exact mul_left_cancel₀ hc (h1.symm.trans h2)

theorem conj_ft (f : F → ℂ) (ψ : AddChar F ℂ) : conj (ft f ψ) = ∑ y, ψ y * conj (f y) := by
  unfold ft
  rw [map_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj, Complex.conj_conj]

/-- Plancherel (sesquilinear form). -/
theorem plancherel (f g : F → ℂ) :
    ∑ ψ : AddChar F ℂ, conj (ft f ψ) * ft g ψ =
      (Fintype.card F : ℂ) * ∑ y, conj (f y) * g y := by
  simp_rw [conj_ft, Finset.sum_mul]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  calc ∑ ψ : AddChar F ℂ, ψ y * conj (f y) * ft g ψ
        = conj (f y) * ∑ ψ : AddChar F ℂ, ψ y * ft g ψ := by
          rw [Finset.mul_sum]; refine Finset.sum_congr rfl fun ψ _ => ?_; ring
    _ = _ := by rw [ft_inv]; ring

/-- Plancherel (norms). -/
theorem plancherel_norm (f : F → ℂ) :
    ∑ ψ : AddChar F ℂ, ‖ft f ψ‖ ^ 2 = (Fintype.card F : ℝ) * ∑ y, ‖f y‖ ^ 2 := by
  have h := plancherel f f
  simp_rw [Complex.conj_mul'] at h
  exact_mod_cast h

end Transform

/-! ## §2 Decimation along a homomorphism -/

section Decimation

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]

/-- Restriction of a fine momentum to the coarse group (for the torus: `k ↦ 2k`). -/
def res (β : G →+ F) (ψ : AddChar F ℂ) : AddChar G ℂ := ψ.compAddMonoidHom β

omit [Fintype F] [Fintype G] in
@[simp] theorem res_apply (β : G →+ F) (ψ : AddChar F ℂ) (X : G) : res β ψ X = ψ (β X) := rfl

omit [Fintype F] in
/-- Orthogonality on the coarse group: `Σ_X φ(-X) ψ(βX) = |G| [ψ ∘ β = φ]`. -/
theorem sum_res_mul (β : G →+ F) (ψ : AddChar F ℂ) (φ : AddChar G ℂ) :
    ∑ X, φ (-X) * ψ (β X) = if res β ψ = φ then (Fintype.card G : ℂ) else 0 := by
  classical
  have h := AddChar.sum_eq_ite (res β ψ - φ)
  have e : ∀ X, (res β ψ - φ) X = φ (-X) * ψ (β X) := by
    intro X
    rw [sub_eq_add_neg, AddChar.add_apply, AddChar.neg_apply, res_apply]
    ring
  simp_rw [e] at h
  rw [h]
  simp only [sub_eq_zero]

/-- **Decimation is an alias sum**: `|F| (f ∘ β)^(φ) = |G| Σ_{ψ : ψ∘β = φ} f̂(ψ)`. -/
theorem ft_sample (β : G →+ F) (f : F → ℂ) (φ : AddChar G ℂ) :
    (Fintype.card F : ℂ) * ft (fun X => f (β X)) φ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ, if res β ψ = φ then ft f ψ else 0 := by
  rw [ft, Finset.mul_sum]
  have h : ∀ X, (Fintype.card F : ℂ) * (φ (-X) * f (β X)) =
      ∑ ψ : AddChar F ℂ, φ (-X) * ψ (β X) * ft f ψ := by
    intro X
    rw [mul_left_comm, ← ft_inv f (β X), Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    ring
  simp_rw [h]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ψ _ => ?_
  rw [← Finset.sum_mul, sum_res_mul]
  split_ifs <;> ring

/-- **The number of aliases**: for an injective `β`, every coarse momentum has exactly
`|F|/|G|` fine momenta above it (`f = δ₀` in `ft_sample`). -/
theorem card_alias (β : G →+ F) (hβ : Function.Injective β) (φ : AddChar G ℂ) :
    (Fintype.card G : ℂ) * ((Finset.univ.filter fun ψ : AddChar F ℂ => res β ψ = φ).card : ℂ) =
      Fintype.card F := by
  classical
  have h := ft_sample β (fun y => if y = 0 then (1 : ℂ) else 0) φ
  have h1 : ∀ ψ : AddChar F ℂ, ft (fun y => if y = 0 then (1 : ℂ) else 0) ψ = 1 := by
    intro ψ
    unfold ft
    simp
  have h2 : ft (fun X => if β X = 0 then (1 : ℂ) else 0) φ = 1 := by
    unfold ft
    have e : ∀ X, (φ (-X) * if β X = 0 then (1 : ℂ) else 0) = if X = 0 then 1 else 0 := by
      intro X
      by_cases hX : X = 0
      · subst hX; simp
      · have : β X ≠ 0 := fun h0 => hX (hβ (h0.trans (map_zero β).symm))
        simp [hX, this]
    simp_rw [e]
    simp
  simp only [h1, h2, mul_one] at h
  rw [h, Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, nsmul_eq_mul, mul_one]

end Decimation

/-! ## §3 The constraint operator, its adjoint, and their symbols -/

section Constraint

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- Componentwise transform of a vector-valued field. -/
def ftv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (a : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ft (fun y => a y ν) ψ

/-- The constraint operator `(Ca)_μ(X) = Σ_r Σ_ν c(r)_{μν} a_ν(βX + r)`. -/
def Cop (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) : G → κ → ℂ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- Its symbol `Q(ψ)_{μν} = Σ_r c(r)_{μν} ψ(r)`. -/
def sym (c : F → κ → ι → ℂ) (ψ : AddChar F ℂ) (μ : κ) (ν : ι) : ℂ := ∑ r, c r μ ν * ψ r

/-- The adjoint `(C†w)_ν(y) = Σ_X Σ_μ conj(c(y - βX)_{μν}) w_μ(X)`. -/
def Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ X, ∑ μ, conj (c (y - β X) μ ν) * w X μ

omit [Fintype ι] in
theorem ft_translate_v (a : F → ι → ℂ) (ν : ι) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => a (y + r) ν) ψ = ψ r * ftv a ψ ν :=
  ft_translate (fun y => a y ν) r ψ

omit [Fintype κ] in
theorem ft_shiftSum (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (μ : κ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) ψ = ∑ ν, sym c ψ μ ν * ftv a ψ ν := by
  rw [ft_sum]
  have h : ∀ r, ft (fun y => ∑ ν, c r μ ν * a (y + r) ν) ψ =
      ∑ ν, c r μ ν * (ψ r * ftv a ψ ν) := by
    intro r
    rw [ft_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ft_const_mul, ft_translate_v]
  simp_rw [h]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ν _ => ?_
  unfold sym
  rw [Finset.sum_mul]
  refine Finset.sum_congr rfl fun r _ => ?_
  ring

omit [Fintype κ] in
/-- **Alias sum for `C`**: `|F| (Ca)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) â(ψ)`. -/
theorem alias_C (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c a) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then ∑ ν, sym c ψ μ ν * ftv a ψ ν else 0 := by
  have h := ft_sample β (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) φ
  simp only [ft_shiftSum] at h
  exact h

omit [Fintype ι] [Fintype κ] in
theorem ft_conj_kernel (c : F → κ → ι → ℂ) (μ : κ) (ν : ι) (ψ : AddChar F ℂ) :
    ft (fun z => conj (c z μ ν)) ψ = conj (sym c ψ μ ν) := by
  unfold ft sym
  rw [map_sum]
  refine Finset.sum_congr rfl fun r _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj]
  ring

omit [Fintype ι] in
/-- **Symbol of the adjoint**: `(C†w)^(ψ) = Q(ψ)† ŵ(ψ ∘ β)`. -/
theorem ftv_Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Cadj β c w) ψ ν = ∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ := by
  unfold ftv Cadj
  rw [ft_sum]
  have h1 : ∀ X, ft (fun y => ∑ μ, conj (c (y - β X) μ ν) * w X μ) ψ =
      ∑ μ, w X μ * (ψ (-(β X)) * conj (sym c ψ μ ν)) := by
    intro X
    rw [ft_sum]
    refine Finset.sum_congr rfl fun μ _ => ?_
    have ht := ft_translate (fun z => conj (c z μ ν)) (-(β X)) ψ
    beta_reduce at ht
    have e : (fun y => conj (c (y - β X) μ ν) * w X μ) =
        fun y => w X μ * conj (c (y + -(β X)) μ ν) := by
      funext y
      rw [sub_eq_add_neg]
      ring
    rw [e, ft_const_mul, ht, ft_conj_kernel]
  simp_rw [h1]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun μ _ => ?_
  unfold ft
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [res_apply, map_neg β X]
  ring

/-- **Symbol of `C C†`** (命題 E): `|F| (CC†w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CCadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (φ : AddChar G ℂ)
    (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Cadj β c w)) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- A translation-invariant operator on the fine group, `(Ta)_ν(y) = Σ_z Σ_ν' t(z)_{νν'} a_ν'(y - z)`. -/
def Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν'

theorem ftv_Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Tconv t a) ψ ν = ∑ ν', ft (fun z => t z ν ν') ψ * ftv a ψ ν' := by
  unfold ftv Tconv
  have e : (fun y => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν') =
      fun y => ∑ ν', conv (fun z => t z ν ν') (fun z => a z ν') y := by
    funext y
    unfold conv
    exact Finset.sum_comm
  rw [e, ft_sum]
  refine Finset.sum_congr rfl fun ν' _ => ?_
  rw [ft_conv]

/-- **Symbol of `C T C†`** (the push-forward of a covariance, the form of the map `𝓡`):
`|F| (C T C† w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) t̂(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CTCadj (β : G →+ F) (c : F → κ → ι → ℂ) (t : F → ι → ι → ℂ) (w : G → κ → ℂ)
    (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Tconv t (Cadj β c w))) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ ν', ft (fun z => t z ν ν') ψ *
            ∑ l, conj (sym c ψ l ν') * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Tconv]
    congr 1
    refine Finset.sum_congr rfl fun ν' _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- `C†` is the adjoint of `C` for the sesquilinear forms `Σ conj(u) v`. -/
theorem Cop_adjoint (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (w : G → κ → ℂ) :
    ∑ X, ∑ μ, conj (w X μ) * Cop β c a X μ = ∑ y, ∑ ν, conj (Cadj β c w y ν) * a y ν := by
  have hL : ∀ X μ, conj (w X μ) * Cop β c a X μ =
      ∑ ν, ∑ r, conj (w X μ) * (c r μ ν * a (β X + r) ν) := by
    intro X μ
    unfold Cop
    rw [Finset.mul_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [Finset.mul_sum]
  have hR : ∀ y ν, conj (Cadj β c w y ν) * a y ν =
      ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    intro y ν
    unfold Cadj
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun X _ => ?_
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [map_mul, Complex.conj_conj]
    ring
  simp_rw [hL, hR]
  -- right side: Σ_y Σ_ν Σ_X Σ_μ  →  Σ_X Σ_μ Σ_ν Σ_y
  have s1 : ∑ y, ∑ ν, ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) =
      ∑ X, ∑ μ, ∑ ν, ∑ y, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    rw [Finset.sum_comm]
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset G))]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun X _ => ?_
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset κ))]
    rw [Finset.sum_comm]
  rw [s1]
  refine Finset.sum_congr rfl fun X _ => ?_
  refine Finset.sum_congr rfl fun μ _ => ?_
  refine Finset.sum_congr rfl fun ν _ => ?_
  refine Fintype.sum_equiv (Equiv.addLeft (β X)) _ _ (fun r => ?_)
  simp only [Equiv.coe_addLeft, add_sub_cancel_left]

end Constraint

/-! ## §4 Lower bound from one alias per coarse momentum; `C` is onto -/

section Onto

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **Real-space lower bound for `C†`**: if for every coarse momentum `φ` one alias `sec φ`
(`sec φ ∘ β = φ`) has `|Q(sec φ)† v|² ≥ c₀ |v|²`, then `|F| ‖C†w‖² ≥ |G| c₀ ‖w‖²`. -/
theorem Cadj_lower (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ}
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : G → κ → ℂ) :
    (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤
      (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 := by
  classical
  set g : AddChar F ℂ → ℝ := fun ψ =>
    ∑ ν, ‖∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ‖ ^ 2 with hg
  have hR : (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = ∑ ψ, g ψ := by
    rw [Finset.sum_comm, Finset.mul_sum]
    have h : ∀ ν, (Fintype.card F : ℝ) * ∑ y, ‖Cadj β c w y ν‖ ^ 2 =
        ∑ ψ : AddChar F ℂ, ‖ftv (Cadj β c w) ψ ν‖ ^ 2 := fun ν =>
      (plancherel_norm (fun y => Cadj β c w y ν)).symm
    simp_rw [h, ftv_Cadj]
    rw [Finset.sum_comm]
  have hinj : Function.Injective sec := fun a b h => by rw [← hsec a, ← hsec b, h]
  have hg0 : ∀ ψ, 0 ≤ g ψ := fun ψ => Finset.sum_nonneg fun ν _ => sq_nonneg _
  have hsub : ∑ φ, g (sec φ) ≤ ∑ ψ, g ψ := by
    rw [← Finset.sum_image (fun a _ b _ h => hinj h)]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      (fun ψ _ _ => hg0 ψ)
  have hlow : ∀ φ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 ≤ g (sec φ) := by
    intro φ
    rw [hg]
    simp only [hsec]
    exact hc₀ φ (fun μ => ftv w φ μ)
  have hL : (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 =
      ∑ φ : AddChar G ℂ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 := by
    rw [← Finset.mul_sum, Finset.sum_comm (s := (Finset.univ : Finset (AddChar G ℂ))),
      Finset.sum_comm (s := (Finset.univ : Finset G))]
    have h : ∀ μ, ∑ φ : AddChar G ℂ, ‖ftv w φ μ‖ ^ 2 =
        (Fintype.card G : ℝ) * ∑ X, ‖w X μ‖ ^ 2 := fun μ => plancherel_norm (fun X => w X μ)
    simp_rw [h]
    rw [← Finset.mul_sum]
    ring
  rw [hL, hR]
  exact (Finset.sum_le_sum fun φ _ => hlow φ).trans hsub

/-- `C C†` as a complex-linear map on coarse fields. -/
def CCL (β : G →+ F) (c : F → κ → ι → ℂ) : (G → κ → ℂ) →ₗ[ℂ] (G → κ → ℂ) where
  toFun w := Cop β c (Cadj β c w)
  map_add' w v := by
    funext X μ
    simp only [Cop, Cadj, Pi.add_apply, mul_add, Finset.sum_add_distrib]
  map_smul' k w := by
    funext X μ
    simp only [Cop, Cadj, Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    refine Finset.sum_congr rfl fun r _ => Finset.sum_congr rfl fun ν _ => ?_
    refine Finset.sum_congr rfl fun X' _ => Finset.sum_congr rfl fun μ' _ => ?_
    ring

/-- **`C` is onto** under the one-alias symbol bound with `c₀ > 0`. -/
theorem Cop_surjective (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (Cop β c) := by
  have hinj : Function.Injective (CCL β c) := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    have hw' : Cop β c (Cadj β c w) = 0 := hw
    have hadj := Cop_adjoint β c (Cadj β c w) w
    rw [hw'] at hadj
    simp only [Pi.zero_apply, mul_zero, Finset.sum_const_zero] at hadj
    simp_rw [Complex.conj_mul'] at hadj
    have hzero : ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = 0 := by exact_mod_cast hadj.symm
    have hlow := Cadj_lower β c sec hsec hc₀ w
    rw [hzero, mul_zero] at hlow
    have hG : (0 : ℝ) < Fintype.card G := Nat.cast_pos.mpr Fintype.card_pos
    have hs0 : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ 0 := by
      by_contra hne
      have hne' : 0 < ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos (mul_pos hG hpos) hne'
      linarith
    have hs : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 = 0 :=
      le_antisymm hs0 (Finset.sum_nonneg fun X _ => Finset.sum_nonneg fun μ _ => sq_nonneg _)
    funext X μ
    have h1 := (Finset.sum_eq_zero_iff_of_nonneg (fun X _ =>
      Finset.sum_nonneg fun μ _ => sq_nonneg ‖w X μ‖)).mp hs X (Finset.mem_univ _)
    have h2 := (Finset.sum_eq_zero_iff_of_nonneg (fun μ _ =>
      sq_nonneg ‖w X μ‖)).mp h1 μ (Finset.mem_univ _)
    simpa using h2
  have hsurj := LinearMap.injective_iff_surjective.mp hinj
  intro v
  obtain ⟨w, hw⟩ := hsurj v
  exact ⟨Cadj β c w, hw⟩

/-- The constraint operator with a real kernel on real fields. -/
def CopR (β : G →+ F) (c : F → κ → ι → ℝ) (a : F → ι → ℝ) : G → κ → ℝ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- **The real constraint operator is onto** (take the real part of a complex preimage). -/
theorem CopR_surjective (β : G →+ F) (c : F → κ → ι → ℝ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ), c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR β c) := by
  intro w
  obtain ⟨a, ha⟩ := Cop_surjective β (fun r μ ν => (c r μ ν : ℂ)) sec hsec hpos hc₀
    (fun X μ => (w X μ : ℂ))
  refine ⟨fun y ν => (a y ν).re, ?_⟩
  funext X μ
  have h := congrFun (congrFun ha X) μ
  have h2 := congrArg Complex.re h
  simp only [Cop, Complex.re_sum, Complex.re_ofReal_mul, Complex.ofReal_re] at h2
  exact h2

end Onto

/-! ## §5 Gradients: `C ∇ = ∇ ∘ res` from a symbol identity -/

section Gradient

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- A translation-invariant "gradient" `(∇χ)_ν(y) = Σ_z d(z)_ν χ(y + z)`. -/
def grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ) (χ : H → ℂ) :
    H → τ → ℂ :=
  fun y ν => ∑ z, d z ν * χ (y + z)

/-- Its symbol `v(ψ)_ν = Σ_z d(z)_ν ψ(z)`. -/
def symv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ∑ z, d z ν * ψ z

theorem ftv_grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (χ : H → ℂ) (ψ : AddChar H ℂ) (ν : τ) :
    ftv (grad d χ) ψ ν = symv d ψ ν * ft χ ψ := by
  unfold ftv grad symv
  rw [ft_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun z _ => ?_
  rw [ft_const_mul, ft_translate]
  ring

omit [Fintype κ] in
/-- **Intertwining**: if `Q(ψ) v_F(ψ) = v_G(ψ ∘ β)` for every fine momentum, then
`C (∇_F χ) = ∇_G (χ ∘ β)` for every `χ` (命題 E の `C∇ = ∇res`). -/
theorem Cop_grad (β : G →+ F) (c : F → κ → ι → ℂ) (dF : F → ι → ℂ) (dG : G → κ → ℂ)
    (hsym : ∀ ψ μ, ∑ ν, sym c ψ μ ν * symv dF ψ ν = symv dG (res β ψ) μ) (χ : F → ℂ) :
    Cop β c (grad dF χ) = grad dG (fun X => χ (β X)) := by
  funext X μ
  have hcF : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have key : ∀ φ, ftv (Cop β c (grad dF χ)) φ μ = ftv (grad dG (fun X => χ (β X))) φ μ := by
    intro φ
    apply mul_left_cancel₀ hcF
    rw [alias_C, ftv_grad, mul_left_comm (Fintype.card F : ℂ), ft_sample,
      mul_left_comm (symv dG φ μ)]
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    split_ifs with h
    · have e : ∑ ν, sym c ψ μ ν * ftv (grad dF χ) ψ ν = symv dG φ μ * ft χ ψ := by
        simp_rw [ftv_grad, ← mul_assoc]
        rw [← Finset.sum_mul, hsym, h]
      rw [e]
    · simp
  exact congrFun (ft_injective (f := fun X => Cop β c (grad dF χ) X μ)
    (g := fun X => grad dG (fun X => χ (β X)) X μ) key) X

end Gradient

/-! ## §6 The torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X` -/

section Torus

instance neZero_two_mul (L : ℕ) [NeZero L] : NeZero (2 * L) :=
  ⟨by have := NeZero.ne L; omega⟩

/-- The doubling embedding `ℤ/L → ℤ/2L`, `x ↦ 2x`. -/
def dbl (L : ℕ) : ZMod L →+ ZMod (2 * L) :=
  ZMod.lift L ⟨zmultiplesHom (ZMod (2 * L)) 2, by
    rw [zmultiplesHom_apply, zsmul_eq_mul, Int.cast_natCast]
    have h := ZMod.natCast_self (2 * L)
    push_cast at h
    linear_combination h⟩

theorem dbl_intCast (L : ℕ) (x : ℤ) : dbl L (x : ZMod L) = 2 * (x : ZMod (2 * L)) := by
  unfold dbl
  rw [ZMod.lift_coe, zmultiplesHom_apply, zsmul_eq_mul]
  ring

/-- Coarse points of the torus: `X ↦ 2X` componentwise. -/
def betaT (d L : ℕ) : (Fin d → ZMod L) →+ (Fin d → ZMod (2 * L)) :=
  AddMonoidHom.compLeft (dbl L) (Fin d)

theorem card_fine (d L : ℕ) [NeZero L] :
    Fintype.card (Fin d → ZMod (2 * L)) = 2 ^ d * Fintype.card (Fin d → ZMod L) := by
  simp only [Fintype.card_fun, ZMod.card, Fintype.card_fin, mul_pow]

theorem dbl_injective (L : ℕ) [NeZero L] : Function.Injective (dbl L) := by
  rw [injective_iff_map_eq_zero]
  intro x hx
  have hx' : dbl L ((x.val : ℤ) : ZMod L) = 0 := by
    rwa [Int.cast_natCast, ZMod.natCast_zmod_val]
  rw [dbl_intCast] at hx'
  have h2 : ((2 * x.val : ℕ) : ZMod (2 * L)) = 0 := by push_cast; simpa using hx'
  rw [ZMod.natCast_eq_zero_iff] at h2
  have h3 : L ∣ x.val := Nat.dvd_of_mul_dvd_mul_left (by norm_num) h2
  have h4 : x.val = 0 := Nat.eq_zero_of_dvd_of_lt h3 (ZMod.val_lt x)
  exact (ZMod.val_eq_zero x).mp h4

theorem betaT_injective (d L : ℕ) [NeZero L] : Function.Injective (betaT d L) := by
  intro x y h
  funext μ
  exact dbl_injective L (congrFun h μ)

/-- **Exactly `2^d` aliases** on the torus: every coarse momentum has `2^d` fine momenta `ψ`
with `ψ ∘ β = φ` (the `k_η = p + πη`, `η ∈ {0,1}^d`). -/
theorem torus_card_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card = 2 ^ d := by
  have h := card_alias (betaT d L) (betaT_injective d L) φ
  rw [card_fine, Nat.cast_mul, mul_comm ((2 ^ d : ℕ) : ℂ) _] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have := mul_left_cancel₀ hG h
  exact_mod_cast this

/-- Every coarse momentum on the torus has a fine momentum above it (a section `sec` exists). -/
theorem torus_exists_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    ∃ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ, res (betaT d L) ψ = φ := by
  have h := torus_card_alias d L φ
  have hpos : 0 < (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card := by rw [h]; positivity
  obtain ⟨ψ, hψ⟩ := Finset.card_pos.mp hpos
  exact ⟨ψ, (Finset.mem_filter.mp hψ).2⟩

variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **(命題 E) the symbol of `C C†` on the torus**:
`(CC†w)^(φ) = 2^{-d} Σ_{ψ : ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`, the `2^d` aliases of `φ`. -/
theorem torus_CCadj (d L : ℕ) [NeZero L] (c : (Fin d → ZMod (2 * L)) → κ → ι → ℂ)
    (w : (Fin d → ZMod L) → κ → ℂ) (φ : AddChar (Fin d → ZMod L) ℂ) (μ : κ) :
    (2 ^ d : ℂ) * ftv (Cop (betaT d L) c (Cadj (betaT d L) c w)) φ μ =
      ∑ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ,
        if res (betaT d L) ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  have h := alias_CCadj (betaT d L) c w φ μ
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 :=
    Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  apply mul_left_cancel₀ hG
  rw [← h]
  ring

/-- **The constant of 命題 E on the four-dimensional torus**: the one-alias bound
`|Q(k_0)† v|² ≥ (121/1152)|v|²` (that is, `σ_min(Q(k_0)) ≥ 11√2/48`) gives
`‖C†w‖² ≥ (121/18432)‖w‖²` in real space. -/
theorem torus_Cadj_lower (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℂ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : (Fin 4 → ZMod L) → κ → ℂ) :
    121 / 18432 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2 := by
  have h := Cadj_lower (betaT 4 L) c sec hsec hc₀ w
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (0 : ℝ) < Fintype.card (Fin 4 → ZMod L) := Nat.cast_pos.mpr Fintype.card_pos
  have h' : (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (121 / 1152 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2) ≤
      (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (2 ^ 4 * ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2) := by
    calc _ = (Fintype.card (Fin 4 → ZMod L) : ℝ) * (121 / 1152) * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := by
            ring
      _ ≤ _ := h
      _ = _ := by ring
  have h'' := le_of_mul_le_mul_left h' hG
  linarith

/-- **The real constraint operator on the four-dimensional torus is onto** under the same
one-alias bound (the hypothesis `hsurj` of the tower theorems, for one stage). -/
theorem torus_CopR_surjective (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℝ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR (betaT 4 L) c) :=
  CopR_surjective (betaT 4 L) c sec hsec (by norm_num) hc₀

end Torus

/-! ## §7 The alias representation of the one-step map on the projection (S1(a)) -/

section AliasRep

open scoped InnerProductSpace

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
variable {Z : Type*} [Fintype Z]

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def Aop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Pq (Sg ζ (Cr ζ (Pr ζ (Nr ζ y))))

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)` (all factors symmetric). -/
def Atr (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Nr ζ (Pr ζ (Cr ζ (Sg ζ (Pq y))))

/-- The one-step map applied to the projection, `(𝓜P)(q) x = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ x`. -/
def MPop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (x : V) : V :=
  (1 / 16 : ℝ) • ∑ ζ, Aop Pq Pr Cr Sg Nr ζ (Pr ζ (Atr Pq Pr Cr Sg Nr ζ x))

omit [Fintype Z] in
theorem Aop_adjoint (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric) (ζ : Z) (x y : V) :
    ⟪x, Aop Pq Pr Cr Sg Nr ζ y⟫_ℝ = ⟪Atr Pq Pr Cr Sg Nr ζ x, y⟫_ℝ := by
  unfold Aop Atr
  rw [inner_smul_right, inner_smul_left, ← hPq, ← hSg, ← hCr, ← hPr, ← hNr]
  simp

/-- **S1(a)**: if `P(r_ζ)` is an orthogonal projection commuting with `N(r_ζ)` and
`w_ζ := C(r_ζ) S_ζ P(q) x` lies in the range of `P(r_ζ)` (S1(b)), then
`⟨x, (𝓜P)(q) x⟩ = ¼ Σ_ζ |N(r_ζ) w_ζ|²`. -/
theorem alias_rep (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x))) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ = (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 := by
  unfold MPop
  rw [inner_smul_right, inner_sum, Finset.mul_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [Aop_adjoint Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr]
  have hA : Atr Pq Pr Cr Sg Nr ζ x = (2 : ℝ) • Nr ζ (Cr ζ (Sg ζ (Pq x))) := by
    unfold Atr
    rw [horth]
  rw [hA, map_smul, hNP, horth, inner_smul_left, inner_smul_right, real_inner_self_eq_norm_sq]
  simp only [RCLike.conj_to_real]
  ring

/-- With `w_ζ ⊥ s(r_ζ)` and a bound per alias `|N(r_ζ) w_ζ|² ≤ Σ_c b(ζ)_c u_c²` on coordinates
of `u = P(q)x`, the coordinate bound `hrep` of `OneStepNorm.MP_le` follows with
`D_c = ¼ Σ_ζ b(ζ)_c`. -/
theorem alias_rep_le (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) {ι : Type*} [Fintype ι]
    (coord : V → ι → ℝ) (b : Z → ι → ℝ) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x)))
    (hb : ∀ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 ≤ ∑ c, b ζ c * coord (Pq x) c ^ 2) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ ≤ ∑ c, ((1 / 4) * ∑ ζ, b ζ c) * coord (Pq x) c ^ 2 := by
  rw [alias_rep Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr hNP x horth]
  calc (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2
      ≤ (1 / 4) * ∑ ζ, ∑ c, b ζ c * coord (Pq x) c ^ 2 := by
        gcongr with ζ
        exact hb ζ
    _ = _ := by
        rw [Finset.sum_comm, Finset.mul_sum]
        refine Finset.sum_congr rfl fun c _ => ?_
        rw [mul_assoc, Finset.sum_mul]

end AliasRep

end TorusFourier

end


-- ===== new part : HrepConcrete.part.lean =====
/-!
# The coordinate bound `hrep` for the concrete one-step map 

Coordinates `Fin 4 → ℝ`, `θ = q/4`, aliases `ζ : Fin 4 → Bool`, `r_ζ/2 = θ + [ζ]π/2`.
* `s(r_ζ)_ν = sin(r_ν/2)`, `x_ν = 4α sin²(r_ν/2) = s_ν²/2` (`α = 1/8`), `C(r_ζ) = diag cos(r_ν/2)`,
  `S_ζ = diag (−1)^{ζ_ν}`, `s(q)_ν = sin(q_ν/2) = sin(2θ_ν)`;
* `N(r) u = diag(π) u + ½ diag(s) 𝔅 diag(s) u` with `𝔅 = 1 − E` off the diagonal;
* `P(p) y = y − (⟨s(p), y⟩/|s(p)|²) s(p)`;
* the quadratic form of the one-step map on the projection,
  `Qf(x) = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`, `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`
  (this is `⟨x, (𝓜P)(q) x⟩` for `𝓜P = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ`).

Main results: `hrep_coord` `Qf(x) ≤ Σ_c D_c(σ) (P(q)x)_c²` with `σ_ν = sin²θ_ν` and the
alias coefficients `D_c`, `Dal_le` `D_c ≤ 429/512`, and `MP_coord_le`
`Qf(x) ≤ (429/512) ⟨x, P(q) x⟩` for every `θ` and `x` (no hypotheses).
-/

noncomputable section

namespace OneStepHrep

open Finset OneStepNorm
open scoped Real

/-! ## Coordinates -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

/-- The orthogonal projection onto `s^⊥` (the identity when `s = 0`). -/
def proj (s y : Fin 4 → ℝ) : Fin 4 → ℝ := fun i => y i - (dot s y / dot s s) * s i

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem dot_proj (s y : Fin 4 → ℝ) : dot s (proj s y) = 0 := by
  by_cases h : dot s s = 0
  · have hs : ∀ i, s i = 0 := by
      intro i
      have h' : ∑ j, s j * s j = 0 := h
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' i
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    unfold dot
    simp [hs]
  · have e : dot s (proj s y) = dot s y - (dot s y / dot s s) * dot s s := by
      unfold proj
      conv_lhs => unfold dot
      simp only [mul_sub, Finset.sum_sub_distrib]
      congr 1
      unfold dot
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      ring
    rw [e]
    field_simp
    ring

theorem proj_of_dot {s y : Fin 4 → ℝ} (h : dot s y = 0) : proj s y = y := by
  funext i; simp [proj, h]

theorem dot_proj_self (s y : Fin 4 → ℝ) : dot (proj s y) (proj s y) = dot y (proj s y) := by
  have h := dot_proj s y
  set p := proj s y with hp_def
  set a := dot s y / dot s s with ha_def
  have hp : ∀ i, p i = y i - a * s i := fun i => rfl
  have e : dot p p = dot y p - a * dot s p := by
    unfold dot
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [show p i * p i = (y i - a * s i) * p i by rw [← hp i]]
    ring
  rw [e, h, mul_zero, sub_zero]

/-! ## The concrete symbols -/

def phi (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := θ ν + (if ζ ν then π / 2 else 0)
def sR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.sin (phi θ ζ ν)
def cR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.cos (phi θ ζ ν)
def sg (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := if ζ ν then -1 else 1
def sQ (θ : Fin 4 → ℝ) (ν : Fin 4) : ℝ := Real.sin (2 * θ ν)

/-- `x = 4α s² = s²/2` (`α = 1/8`). -/
def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

/-- `π_μ = Π_{ν≠μ} (1 − x_ν)`. -/
def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

/-- `E_{μν} = Ef(x_ρ, x_σ)` with `{ρ, σ}` the complement of `{μ, ν}`; zero on the diagonal. -/
def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

/-- `A_ζᵀ x = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q) x`. -/
def Atr (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  fun μ => 2 * Nm (sR θ ζ)
    (proj (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) μ

/-- The quadratic form `⟨x, (𝓜P)(q) x⟩ = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`. -/
def Qf (θ x : Fin 4 → ℝ) : ℝ :=
  (1 / 16) * ∑ ζ : Fin 4 → Bool, dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x))

/-! ## Properties of `N` -/

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

/-- `N` is symmetric. -/
theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

/-- `N s = s` (the leg identity `Σ_{ν≠μ} x_ν 𝔅_{μν} = 1 − π_μ`). -/
theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- `N` preserves `s^⊥`. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-! ## The square bound for one alias (S2 with the concrete `π`, `E`) -/

/-- The per-direction coefficient `(1+t)(π_c − x_c)² + (1+1/t) η_c`, with direction `c` first. -/
def coefT (t xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + t) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 + (1 + 1 / t) * eta xc x1 x2 x3

theorem EF_nonneg {x : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ EF x μ ν := by
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_nonneg (hx _) (hx _)

theorem Nm_eq_Nap (s u : Fin 4 → ℝ) (μ : Fin 4) :
    Nm s u μ = Nap (piF (xs s)) (fun ν => Real.sqrt (1 / 2) * s ν) (EF (xs s)) u μ := by
  have hc : Real.sqrt (1 / 2) * Real.sqrt (1 / 2) = 1 / 2 :=
    Real.mul_self_sqrt (by norm_num)
  unfold Nm Nap
  have e : ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (Real.sqrt (1 / 2) * s ν * u ν) =
      Real.sqrt (1 / 2) * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    ring
  rw [e]
  have : Real.sqrt (1 / 2) * s μ * (Real.sqrt (1 / 2) *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)) =
      (Real.sqrt (1 / 2) * Real.sqrt (1 / 2)) * s μ *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by ring
  rw [this, hc]

set_option maxRecDepth 8000 in
/-- **One alias**: for `w ⊥ s` and `x = s²/2 ∈ [0, 1/2]`,
`|N w|² ≤ Σ_c coef_c(x) w_c²` (directions `c` first, the others in increasing order). -/
theorem normSq_alias (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefT (3 / 10) (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefT (3 / 10) (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefT (3 / 10) (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefT (3 / 10) (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3 / 10)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefT, eta, rhoP, Ef, Matrix.cons_val]
  ring

/-! ## The alias values and the sum over aliases -/

theorem xs_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    xs (sR θ ζ) ν = xa (Real.sin (θ ν) ^ 2) (ζ ν) := by
  rw [← alias_x]
  unfold xs sR phi
  ring

theorem w_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (u : Fin 4 → ℝ) (ν : Fin 4) :
    (cR θ ζ ν * sg ζ ν * u ν) ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := by
  rw [← alias_w]
  unfold cR sg phi
  split_ifs <;> ring

theorem sum_bool4 (F : (Fin 4 → Bool) → ℝ) :
    ∑ ζ, F ζ = ∑ b0, ∑ b1, ∑ b2, ∑ b3, F ![b0, b1, b2, b3] := by
  let e : (Fin 4 → Bool) ≃ Bool × Bool × Bool × Bool :=
    { toFun := fun ζ => (ζ 0, ζ 1, ζ 2, ζ 3)
      invFun := fun b => ![b.1, b.2.1, b.2.2.1, b.2.2.2]
      left_inv := fun ζ => by funext i; fin_cases i <;> rfl
      right_inv := fun b => rfl }
  rw [← e.symm.sum_comp]
  simp only [Fintype.sum_prod_type]
  rfl

/-- The alias coefficients `D_c(σ) = ¼ Σ_ζ cos²(r_{ζ,c}/2) coef_c(x(r_ζ))`. -/
def Dal (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefT (3 / 10) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefT (3 / 10) (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefT (3 / 10) (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefT (3 / 10) (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

/-- **`D_c ≤ 429/512`** on the box `σ ∈ [0,1]⁴` (from `alias_coeff_le`, S3–S6). -/
theorem Dal_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    Dal σ c ≤ 429 / 512 := by
  fin_cases c
  · exact alias_coeff_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact alias_coeff_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-! ## The coordinate bound -/

/-- One alias in full: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4|N(r_ζ) w_ζ|²` and the square bound. -/
theorem alias_term_le (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefT (3 / 10) (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  -- S1(b): `w ⊥ s(r_ζ)`
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

/-- **`hrep` in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ Σ_c D_c(σ) (P(q)x)_c²`, `σ_ν = sin²(q_ν/4)`. -/
theorem hrep_coord (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, Dal, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ (429/512) ⟨x, P(q) x⟩` for every
`q` and `x` (the coordinate form of `M P ≼ (429/512) P`, no hypotheses). -/
theorem MP_coord_le (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (429 / 512) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (429 / 512) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (Dal_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end OneStepHrep

end

-- ===== new part : Bridge.part.lean =====
/-!
# The concrete one-step map `𝓜` on families over `EuclideanSpace ℝ (Fin 4)` and the hypotheses
`hM`, `hPstep`, `hPs`, `hPP` of `UniformBracket.bracket_numeric`

`Q` is any index type of momenta with a coordinate map `th : Q → (Fin 4 → ℝ)` (`th q = q/4`) and
alias maps `rq : Q → (Fin 4 → Bool) → Q` with `th (rq q ζ) = th q / 2 + ζ π/4` (`r_ζ = (q+2πζ)/2`).
`(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`, `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`.
-/

noncomputable section

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

abbrev V := EuclideanSpace ℝ (Fin 4)

/-! ## Matrices for the coordinate maps -/

def projM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun i j => (if i = j then 1 else 0) - s i * s j / dot s s

def NM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun μ ν =>
    if μ = ν then piF (xs s) μ else (1 / 2) * s μ * (1 - EF (xs s) μ ν) * s ν

theorem toE_apply (B : Matrix (Fin 4) (Fin 4) ℝ) (v : V) :
    Matrix.toEuclideanLin B v = WithLp.toLp 2 (B *ᵥ WithLp.ofLp v) := rfl

theorem diag_mulVec (d v : Fin 4 → ℝ) : Matrix.diagonal d *ᵥ v = fun i => d i * v i :=
  funext (Matrix.mulVec_diagonal d v)

theorem projM_mulVec (s y : Fin 4 → ℝ) : projM s *ᵥ y = proj s y := by
  funext i
  simp only [projM, Matrix.mulVec, dotProduct, Matrix.of_apply, sub_mul, Finset.sum_sub_distrib,
    ite_mul, one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true, proj, dot]
  congr 1
  rw [div_mul_eq_mul_div, Finset.sum_mul, Finset.sum_div]
  refine Finset.sum_congr rfl fun j _ => ?_
  ring

theorem NM_mulVec (s u : Fin 4 → ℝ) : NM s *ᵥ u = Nm s u := by
  funext μ
  simp only [NM, Matrix.mulVec, dotProduct, Matrix.of_apply, Nm]
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ μ), if_pos rfl, Finset.mul_sum]
  congr 1
  refine Finset.sum_congr rfl fun ν hν => ?_
  rw [if_neg (Finset.ne_of_mem_erase hν).symm]
  ring

theorem projM_transpose (s : Fin 4 → ℝ) : (projM s)ᵀ = projM s := by
  ext i j
  simp only [projM, Matrix.transpose_apply, Matrix.of_apply]
  rw [mul_comm (s j) (s i)]
  by_cases h : i = j
  · subst h; rfl
  · rw [if_neg h, if_neg (Ne.symm h)]

theorem NM_transpose (s : Fin 4 → ℝ) : (NM s)ᵀ = NM s := by
  ext i j
  simp only [NM, Matrix.transpose_apply, Matrix.of_apply]
  fin_cases i <;> fin_cases j <;> simp [EF] <;> ring

/-! ## The alias data -/

/-- `θ(r_ζ) = θ/2 + ζ π/4`. -/
def thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Fin 4 → ℝ :=
  fun ν => θ ν / 2 + (if ζ ν then π / 4 else 0)

theorem sQ_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : sQ (thR θ ζ) = sR θ ζ := by
  funext ν
  unfold sQ thR sR phi
  congr 1
  split_ifs <;> ring

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`. -/
def AtM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (NM (sR θ ζ) * projM (sR θ ζ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) *
    projM (sQ θ))

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (projM (sQ θ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) * projM (sR θ ζ) *
    NM (sR θ ζ))

theorem AM_transpose (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : (AM θ ζ)ᵀ = AtM θ ζ := by
  unfold AM AtM
  rw [Matrix.transpose_smul]
  simp only [Matrix.transpose_mul, projM_transpose, NM_transpose, Matrix.diagonal_transpose,
    Matrix.mul_assoc]

theorem AtM_mulVec (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : AtM θ ζ *ᵥ x = Atr θ ζ x := by
  unfold AtM Atr
  rw [Matrix.smul_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [projM_mulVec, diag_mulVec, NM_mulVec]
  funext μ
  simp only [Pi.smul_apply, smul_eq_mul]

/-! ## Inner products in coordinates -/

theorem inner_coord (x y : V) : ⟪x, y⟫ = dot (WithLp.ofLp x) (WithLp.ofLp y) := by
  rw [EuclideanSpace.inner_eq_star_dotProduct]
  unfold dot dotProduct
  simp only [star_trivial]
  exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem inner_toE (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (x y : V) :
    ⟪x, Matrix.toEuclideanLin B y⟫ = ⟪Matrix.toEuclideanLin Bt x, y⟫ := by
  rw [inner_coord, inner_coord, toE_apply, toE_apply,
    WithLp.ofLp_toLp, WithLp.ofLp_toLp, ← hB]
  unfold dot
  have h := Matrix.dotProduct_mulVec (WithLp.ofLp x) B (WithLp.ofLp y)
  rw [← Matrix.mulVec_transpose] at h
  exact h

/-! ## The family map -/

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The projection family `P(q)`. -/
def Pfam (q : Q) : V →ₗ[ℝ] V := Matrix.toEuclideanLin (projM (sQ (th q)))

/-- **The concrete one-step map** `(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`. -/
def Mfam : (Q → V →ₗ[ℝ] V) →ₗ[ℝ] (Q → V →ₗ[ℝ] V) where
  toFun G q := (1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool,
    Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)
  map_add' G H := by
    funext q
    simp only [Pi.add_apply, LinearMap.add_comp, LinearMap.comp_add, Finset.sum_add_distrib,
      smul_add]
  map_smul' c G := by
    funext q
    simp only [Pi.smul_apply, RingHom.id_apply, LinearMap.smul_comp, LinearMap.comp_smul,
      ← Finset.smul_sum, smul_comm c (1 / 16 : ℝ)]

theorem Mfam_inner (G : Q → V →ₗ[ℝ] V) (q : Q) (x : V) :
    ⟪x, Mfam th rq G q x⟫ = (1 / 16) * ∑ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
  show ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x⟫ = _
  rw [LinearMap.smul_apply, real_inner_smul_right, LinearMap.sum_apply, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  exact inner_toE _ _ (AM_transpose (th q) ζ) _ _

/-- **`hM`: the concrete `𝓜` preserves the Loewner order of families.** -/
theorem Mfam_orderPreserving : UniformBracket.OrderPreserving (Mfam th rq) := by
  intro A B hAB q x
  rw [Mfam_inner, Mfam_inner]
  gcongr with ζ
  exact hAB _ _

/-- **`hPs`**: `P(q)` is symmetric. -/
theorem Pfam_symm (q : Q) : (Pfam th q).IsSymmetric := by
  intro x y
  unfold Pfam
  rw [real_inner_comm, inner_toE _ _ (projM_transpose _) y x, real_inner_comm]

/-- **`hPP`**: `P(q)` is idempotent. -/
theorem Pfam_idem (q : Q) (x : V) : Pfam th q (Pfam th q x) = Pfam th q x := by
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp,
    projM_mulVec, projM_mulVec, proj_of_dot (dot_proj _ _)]

/-- `⟨x, (𝓜P)(q) x⟩ = Qf(x)` (the quadratic form bounded in `OneStepHrep`). -/
theorem Mfam_P_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (x : V) :
    ⟪x, Mfam th rq (Pfam th) q x⟫ = Qf (th q) (WithLp.ofLp x) := by
  rw [Mfam_inner]
  unfold Qf
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp,
    WithLp.ofLp_toLp, AtM_mulVec, projM_mulVec]

/-- **`hPstep` for the concrete `𝓜`**: `𝓜 P ≼ (429/512) P` (no hypotheses beyond the alias maps). -/
theorem Mfam_P_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((429 / 512 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact MP_coord_le (th q) (WithLp.ofLp x)

/-- `429/512 ≤ 0.838` (the `hlam` of `bracket_numeric`). -/
theorem lam_le : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-- The model index set `Q = ℝ⁴` (`θ = q/4`) with `r_ζ` as alias maps. -/
theorem Mfam_P_le_R4 :
    UniformBracket.Lw (Mfam (fun θ : Fin 4 → ℝ => θ) thR (Pfam fun θ => θ))
      ((429 / 512 : ℝ) • Pfam fun θ : Fin 4 → ℝ => θ) :=
  Mfam_P_le (fun θ => θ) thR (fun _ _ => rfl)

end OneStepBridge

end

-- ===== new part : ETBridge.part.lean =====
/-!
# `‖N‖ ≤ 1`, the step `𝓜(P/ω) ≼ P/ω + (15/8) P` (`e_T ≤ 15/8`), and `bracket_numeric` for the
concrete `𝓜`

* `IminusN_form`, `IplusN_form`: `⟨u, (I ∓ N)u⟩` as sums of squares (Lemma 2(b) of and its
  `+` companion), so `−I ≼ N ≼ I`; `Nm_normSq_le`: `|N u|² ≤ |u|²` from these two without the
  spectral theorem (`2(|u|² − |Nu|²) = ⟨v,(I−N)v⟩ + ⟨w,(I+N)w⟩`, `v = u + Nu`, `w = u − Nu`).
* `eT_alias`: for `σ ∈ [0,1]⁴` with `ω(q) > 0`, `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`
  (the alias nearest to the origin `ζ*` plays the role of `ζ = 0`, so no box for `q` is needed).
* `Mfam_B_le`: `𝓜(P/ω) ≼ P/ω + (15/8) P` (the hypothesis `hBstep`).
* `bracket_concrete`: `UniformBracket.bracket_numeric` for the concrete `𝓜`, `P`, `ω`; the
  remaining hypotheses are the lower side `hlow`, symmetry `hsym` and the inverse `H`.
-/

noncomputable section

namespace OneStepET

open Finset OneStepNorm OneStepHrep OneStepBridge Matrix
open scoped Real RealInnerProductSpace

/-! ## Bilinearity of `dot` and linearity of `N` -/

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (b + c) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.add_apply]; ring

theorem dot_sub_right (a b c : Fin 4 → ℝ) : dot a (b - c) = dot a b - dot a c := by
  unfold dot; rw [← Finset.sum_sub_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.sub_apply]; ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (a + b) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_sub_left (a b c : Fin 4 → ℝ) : dot (a - b) c = dot a c - dot b c := by
  rw [dot_comm, dot_sub_right, dot_comm c a, dot_comm c b]

theorem Nm_add (s u v : Fin 4 → ℝ) : Nm s (u + v) = Nm s u + Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_add]

theorem Nm_sub (s u v : Fin 4 → ℝ) : Nm s (u - v) = Nm s u - Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_sub]

/-! ## `−I ≼ N ≼ I` and `|N u| ≤ |u|` -/

/-- `𝔅_{μν} = 1 − E_{μν}`. -/
def BF (s : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := 1 - EF (xs s) μ ν

set_option maxRecDepth 8000 in
/-- **Lemma 2(b)**: `⟨u, (I − N)u⟩ = ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ − s_μ u_ν)²`. -/
theorem IminusN_form (s u : Fin 4 → ℝ) :
    dot u u - dot u (Nm s u) =
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

set_option maxRecDepth 8000 in
/-- `⟨u, (I + N)u⟩ = 2 Σ_μ π_μ u_μ² + ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ + s_μ u_ν)²`. -/
theorem IplusN_form (s u : Fin 4 → ℝ) :
    dot u u + dot u (Nm s u) = 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 +
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem Ef_le_one {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) :
    Ef y z ≤ 1 := by
  have := Ef_le hy.1 hz.1
  linarith [hy.2, hz.2]

theorem BF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ BF s μ ν := by
  unfold BF
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_le_one (hx _) (hx _)

theorem piF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ : Fin 4) :
    0 ≤ piF (xs s) μ := by
  have h0 : 0 ≤ 1 - xs s 0 := by linarith [(hx 0).2]
  have h1 : 0 ≤ 1 - xs s 1 := by linarith [(hx 1).2]
  have h2 : 0 ≤ 1 - xs s 2 := by linarith [(hx 2).2]
  have h3 : 0 ≤ 1 - xs s 3 := by linarith [(hx 3).2]
  fin_cases μ <;> simp [piF] <;> positivity

theorem IminusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot u (Nm s u) ≤ dot u u := by
  have h := IminusN_form s u
  have : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

theorem IplusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : -dot u u ≤ dot u (Nm s u) := by
  have h := IplusN_form s u
  have h1 : 0 ≤ 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => mul_nonneg (piF_nonneg hx μ) (sq_nonneg _)
  have h2 : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

/-- **`‖N‖ ≤ 1`** (Lemma 2(c), `ν ≤ 1`): `|N u|² ≤ |u|²`. -/
theorem Nm_normSq_le {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot (Nm s u) (Nm s u) ≤ dot u u := by
  set A := Nm s u with hA
  set AA := Nm s A with hAA
  have h1 := IminusN_nonneg hx (u + A)
  have h2 := IplusN_nonneg hx (u - A)
  rw [Nm_add, Nm_sub] at *
  rw [← hA, ← hAA] at h1 h2
  simp only [dot_add_left, dot_add_right, dot_sub_left, dot_sub_right] at h1 h2
  have s1 : dot u AA = dot A A := by rw [hAA, Nm_symm]
  have s2 : dot A u = dot u A := dot_comm _ _
  have s3 : dot AA u = dot A A := by rw [dot_comm, s1]
  have s4 : dot AA A = dot A AA := dot_comm _ _
  linarith

/-! ## The scalar step `e_T ≤ 15/8` with the nearest alias -/

/-- `ω(r_ζ) = Σ_ν 8 x_ν(r_ζ)`. -/
def omR (σ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : ℝ := ∑ ν, 8 * xa (σ ν) (ζ ν)

/-- `ω(q) = Σ_ν 16 σ_ν (1 − σ_ν)`. -/
def omQ (σ : Fin 4 → ℝ) : ℝ := ∑ ν, 16 * (σ ν * (1 - σ ν))

/-- The alias nearest to the origin. -/
def zstar (σ : Fin 4 → ℝ) : Fin 4 → Bool := fun ν => decide (1 / 2 < σ ν)

theorem xa_far {σ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} (ν : Fin 4)
    (h : ζ ν ≠ zstar σ ν) : 1 / 4 ≤ xa (σ ν) (ζ ν) := by
  unfold zstar at h
  by_cases hs : 1 / 2 < σ ν
  · have : ζ ν = false := by
      cases hz : ζ ν
      · rfl
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
    rw [this]; simp only [xa]; linarith
  · have : ζ ν = true := by
      cases hz : ζ ν
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
      · rfl
    have hs' : σ ν ≤ 1 / 2 := le_of_not_gt hs
    rw [this]; simp only [xa]; linarith

theorem omR_far {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) {ζ : Fin 4 → Bool}
    (h : ζ ≠ zstar σ) : 2 ≤ omR σ ζ := by
  obtain ⟨ν, hν⟩ : ∃ ν, ζ ν ≠ zstar σ ν := by
    by_contra hc
    exact h (funext fun ν => by by_contra h'; exact hc ⟨ν, h'⟩)
  have hf := xa_far ν hν
  unfold omR
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ ν)]
  have : 0 ≤ ∑ x ∈ univ.erase ν, 8 * xa (σ x) (ζ x) :=
    Finset.sum_nonneg fun x _ => by
      have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
  linarith

theorem omR_near {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) :
    omQ σ ≤ 4 * omR σ (zstar σ) := by
  unfold omQ omR
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  unfold zstar
  have h0 := (hσ ν).1
  have h1 := (hσ ν).2
  by_cases hs : 1 / 2 < σ ν
  · simp only [hs, decide_true, xa]; nlinarith
  · simp only [hs, decide_false, xa]; nlinarith

theorem wa_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ wa σ b ∧ wa σ b ≤ 1 := by
  cases b <;> simp only [wa] <;> constructor <;> linarith

/-- **The alias sum of `e_T`**: `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`. -/
theorem eT_alias {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (hω : 0 < omQ σ) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omQ σ)⁻¹ + 15 / 8 := by
  have hnear := omR_near hσ
  have hpos : 0 < omR σ (zstar σ) := by linarith
  have hF : ∀ ζ, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omR σ ζ)⁻¹ := by
    intro ζ
    have hw := wa_le (hσ μ).1 (hσ μ).2 (ζ μ)
    have : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    nlinarith
  have hstar : (omR σ (zstar σ))⁻¹ ≤ 4 * (omQ σ)⁻¹ := by
    rw [inv_le_comm₀ hpos (by positivity), mul_inv, inv_inv]
    calc 4⁻¹ * omQ σ ≤ 4⁻¹ * (4 * omR σ (zstar σ)) := by gcongr
      _ = omR σ (zstar σ) := by ring
  have hfar : ∀ ζ ∈ (univ : Finset (Fin 4 → Bool)).erase (zstar σ),
      wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ 1 / 2 := by
    intro ζ hζ
    have h2 := omR_far hσ (Finset.ne_of_mem_erase hζ)
    have : (omR σ ζ)⁻¹ ≤ 1 / 2 := by
      rw [inv_le_comm₀ (by linarith) (by norm_num)]; norm_num; linarith
    exact (hF ζ).trans this
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ (zstar σ))]
  have hsum := Finset.sum_le_sum hfar
  have hcard : ((univ : Finset (Fin 4 → Bool)).erase (zstar σ)).card = 15 := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, Fintype.card_fun,
      Fintype.card_bool, Fintype.card_fin]
    rfl
  rw [Finset.sum_const, hcard, nsmul_eq_mul] at hsum
  have h0 := (hF (zstar σ)).trans hstar
  push_cast at hsum
  linarith

/-! ## The step `𝓜(P/ω) ≼ P/ω + (15/8) P` -/

/-- `ω(q) = Σ_ν 4 sin²(q_ν/2)` from the coordinate `θ = q/4`. -/
def omF {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : ℝ := ∑ ν, 4 * sQ (th q) ν ^ 2

theorem omF_eq {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) :
    omF th q = omQ (fun ν => Real.sin (th q ν) ^ 2) := by
  unfold omF omQ sQ
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [omega_dir]; ring

theorem omF_alias {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool) :
    omF th (rq q ζ) = omR (fun ν => Real.sin (th q ν) ^ 2) ζ := by
  unfold omF omR
  rw [hrq, sQ_thR]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [← xs_alias]; unfold xs; ring

theorem omF_le {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : omF th q ≤ 16 := by
  unfold omF sQ
  rw [Fin.sum_univ_four]
  have h0 := Real.sin_sq_le_one (2 * th q 0)
  have h1 := Real.sin_sq_le_one (2 * th q 1)
  have h2 := Real.sin_sq_le_one (2 * th q 2)
  have h3 := Real.sin_sq_le_one (2 * th q 3)
  linarith

/-- One alias, as an equality: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4 |N(r_ζ) w_ζ|²`. -/
theorem alias_term_eq (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) =
      4 * dot (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν))
        (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) := by
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [proj_of_dot hw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun μ _ => by ring

/-- One alias, the `e_T` bound: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_one (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have h := Nm_normSq_le hx (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
  have e : dot (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
      (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν) =
      ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  rw [e] at h
  linarith

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hBstep` for the concrete `𝓜`**: `𝓜(P/ω) ≼ P/ω + (15/8) P` (where `ω > 0`). -/
theorem Mfam_B_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_one (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 ≤
      ∑ μ, ((omQ σ)⁻¹ + 15 / 8) * u μ ^ 2 :=
    Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right (eT_alias hσ hω' μ) (sq_nonneg _)
  have hRHS : ⟪x, ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) q x⟫ =
      ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by
    simp only [Pi.add_apply, Pi.smul_apply, LinearMap.add_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
    ring
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-! ## `bracket_numeric` for the concrete `𝓜` -/

/-- **The bracket for the concrete one-step map**: with `ω(q) = Σ 4 sin²(q_ν/2) > 0` on `Q` and the
alias maps, every hypothesis of `UniformBracket.bracket_numeric` about `𝓜`, `P`, `ω`, `λ`, `e`
and `G₀ = P/ω` is discharged; what remains is the lower side `hlow`, the symmetry `hsym` of the
stages and the inverse `H` on the range of `P`. -/
theorem bracket_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
    (hsym : ∀ k q, ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric)
    {H : ℕ → Q → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q (H k q x) =
      Pfam th q x)
    (hHP : ∀ k q x, Pfam th q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : V) :
    omF th q / 745 * ⟪x, Pfam th q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF th q * ⟪x, Pfam th q x⟫ :=
  UniformBracket.bracket_numeric (Mfam th rq) (Mfam_orderPreserving th rq) (Pfam_symm th)
    (Pfam_idem th) hω (omF_le th) (by norm_num : (0 : ℝ) ≤ 429 / 512) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl hσ ha (Mfam_P_le th rq hrq) (Mfam_B_le th rq hrq hω)
    (UniformBracket.Lw.refl _) hlow hsym hH hHP k q x

end OneStepET

end

-- ===== new part : Final.part.lean =====
/-!
# The symmetry of the stages and the index set `ω > 0`

* `Mfam_symm`, `iterate_symm`: `𝓜` maps symmetric families to symmetric families, so every stage
  `G_k = 𝓜^k(P/ω)` is symmetric (the hypothesis `hsym`).
* `Qpos`: the momenta with `ω(q) > 0` (`q ∉ 2πℤ⁴`), closed under the aliases `q ↦ r_ζ`
  (`s(q)_ν = ±2 sin(r_ν/2) cos(r_ν/2)`), and `bracket_Qpos`: the bracket with the remaining
  hypotheses `hlow`, `hH`, `hHP` only.
-/

noncomputable section

namespace OneStepFinal

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem term_symm (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (G : V →ₗ[ℝ] V)
    (hG : G.IsSymmetric) (x y : V) :
    ⟪(Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) x, y⟫ =
      ⟪x, (Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) y⟫ := by
  simp only [LinearMap.comp_apply]
  rw [real_inner_comm, inner_toE B Bt hB, inner_toE B Bt hB x, ← hG]
  exact real_inner_comm _ _

/-- `𝓜` preserves symmetric families. -/
theorem Mfam_symm (G : Q → V →ₗ[ℝ] V) (hG : ∀ r, (G r).IsSymmetric) (q : Q) :
    (Mfam th rq G q).IsSymmetric := by
  intro x y
  show ⟪((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x, y⟫ =
    ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y⟫
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    LinearMap.sum_apply, LinearMap.sum_apply, sum_inner, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  exact term_symm _ _ (AM_transpose (th q) ζ) _ (hG _) x y

theorem smul_symm {T : V →ₗ[ℝ] V} (hT : T.IsSymmetric) (c : ℝ) : (c • T).IsSymmetric := by
  intro x y
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    hT]

/-- **`hsym`**: every stage `𝓜^k(P/ω)` is symmetric. -/
theorem iterate_symm (k : ℕ) (q : Q) :
    ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric := by
  induction k generalizing q with
  | zero => exact smul_symm (Pfam_symm th q) _
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact Mfam_symm th rq _ ih q

/-! ## The momenta with `ω > 0` -/

/-- Momenta `q = 4θ` with `ω(q) > 0`. -/
abbrev Qpos : Type := {θ : Fin 4 → ℝ // 0 < ∑ ν, 4 * sQ θ ν ^ 2}

theorem sQ_eq_zero_of_sR {θ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} {ν : Fin 4}
    (h : sR θ ζ ν = 0) : sQ θ ν = 0 := by
  unfold sR phi at h
  unfold sQ
  rw [Real.sin_two_mul]
  cases hz : ζ ν
  · rw [hz] at h; simp at h; rw [h]; ring
  · rw [hz] at h; simp [Real.sin_add_pi_div_two] at h; rw [h]; ring

theorem pos_alias {θ : Fin 4 → ℝ} (hθ : 0 < ∑ ν, 4 * sQ θ ν ^ 2) (ζ : Fin 4 → Bool) :
    0 < ∑ ν, 4 * sQ (thR θ ζ) ν ^ 2 := by
  rw [sQ_thR]
  by_contra hc
  have hle : ∑ ν, 4 * sR θ ζ ν ^ 2 ≤ 0 := le_of_not_gt hc
  have h0 : ∀ ν, sR θ ζ ν = 0 := by
    intro ν
    have hs := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => by positivity)).mp
      (le_antisymm hle (Finset.sum_nonneg fun i _ => by positivity)) ν (Finset.mem_univ _)
    have : sR θ ζ ν ^ 2 = 0 := by linarith
    exact pow_eq_zero_iff (n := 2) (by norm_num) |>.mp this
  have : ∑ ν, 4 * sQ θ ν ^ 2 = 0 := by
    refine Finset.sum_eq_zero fun ν _ => ?_
    rw [sQ_eq_zero_of_sR (h0 ν)]; ring
  linarith

/-- The aliases on `Qpos`. -/
def rqPos (q : Qpos) (ζ : Fin 4 → Bool) : Qpos := ⟨thR q.1 ζ, pos_alias q.2 ζ⟩

/-- **The bracket on `Qpos` for the concrete `𝓜`**: everything is discharged except the lower
side `hlow` and the inverse `H` on the range of `P`. -/
theorem bracket_Qpos {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)))
    {H : ℕ → Qpos → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) = Pfam Subtype.val q x)
    (hHP : ∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) (k : ℕ) (q : Qpos) (x : V) :
    omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_concrete Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) hσ ha hlow
    (iterate_symm Subtype.val rqPos) hH hHP k q x

/-! ## The inverse on the range of `P` from the lower side -/

/-- In finite dimension, a lower bound `c ⟨x, Px⟩ ≤ ⟨x, Gx⟩` (`c > 0`) with `ran G ⊆ ran P`
gives `H` with `G H = P` and `P H = H` (the inverse of `G` on `ran P`). -/
theorem exists_inv_on_range {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] (P G : E →ₗ[ℝ] E) (hPP : ∀ x, P (P x) = P x)
    (hPG : ∀ x, P (G x) = G x) {c : ℝ} (hc : 0 < c) (hlow : ∀ x, c * ⟪x, P x⟫ ≤ ⟪x, G x⟫) :
    ∃ H : E →ₗ[ℝ] E, (∀ x, G (H x) = P x) ∧ (∀ x, P (H x) = H x) := by
  set W := LinearMap.range P
  have hGW : ∀ w ∈ W, G w ∈ W := fun w _ => ⟨G w, hPG w⟩
  let GW : W →ₗ[ℝ] W := G.restrict hGW
  have hinj : Function.Injective GW := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    obtain ⟨y, hy⟩ := w.2
    have h0 : G (w : E) = 0 := congrArg Subtype.val hw
    have hPw : P (w : E) = w := by rw [← hy, hPP]
    have h1 := hlow (w : E)
    rw [h0, inner_zero_right, hPw, real_inner_self_eq_norm_sq] at h1
    have h2 : ‖(w : E)‖ ^ 2 ≤ 0 := by
      by_contra hne
      have : 0 < ‖(w : E)‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos hc this
      linarith
    have h3 : ‖(w : E)‖ = 0 := by nlinarith [norm_nonneg (w : E)]
    exact Subtype.ext (norm_eq_zero.mp h3)
  let e := LinearEquiv.ofInjectiveEndo GW hinj
  refine ⟨W.subtype ∘ₗ (e.symm : W →ₗ[ℝ] W) ∘ₗ P.rangeRestrict, ?_, ?_⟩
  · intro x
    exact congrArg Subtype.val (e.apply_symm_apply (P.rangeRestrict x))
  · intro x
    obtain ⟨y, hy⟩ := (e.symm (P.rangeRestrict x)).2
    show P ((e.symm (P.rangeRestrict x) : W) : E) = ((e.symm (P.rangeRestrict x) : W) : E)
    rw [← hy, hPP]

theorem projM_AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (w : Fin 4 → ℝ) :
    projM (sQ θ) *ᵥ (AM θ ζ *ᵥ w) = AM θ ζ *ᵥ w := by
  unfold AM
  simp only [Matrix.smul_mulVec, Matrix.mulVec_smul, ← Matrix.mulVec_mulVec, projM_mulVec]
  rw [proj_of_dot (dot_proj _ _)]

/-- `ran (𝓜G)(q) ⊆ ran P(q)`. -/
theorem Pfam_Mfam (G : Q → V →ₗ[ℝ] V) (q : Q) (y : V) :
    Pfam th q (Mfam th rq G q y) = Mfam th rq G q y := by
  show Pfam th q (((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y) =
    ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y
  rw [LinearMap.smul_apply, map_smul, LinearMap.sum_apply, map_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp, projM_AM]

/-- Every stage has range in `ran P`. -/
theorem iterate_P (k : ℕ) (q : Q) (y : V) :
    Pfam th q ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y) =
      (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y := by
  cases k with
  | zero =>
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, map_smul, Pfam_idem]
  | succ k =>
    rw [Function.iterate_succ_apply']
    exact Pfam_Mfam th rq _ q y

/-- **The bracket on `Qpos` with the lower side as the only hypothesis**: the inverses `H_k` on
`ran P` exist, and `(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage. -/
theorem bracket_Qpos_low {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  have hex : ∀ k (q : Qpos), ∃ H : V →ₗ[ℝ] V,
      (∀ x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H x) = Pfam Subtype.val q x) ∧
      (∀ x, Pfam Subtype.val q (H x) = H x) := by
    intro k q
    have hω : 0 < omF Subtype.val q := q.2
    refine exists_inv_on_range (Pfam Subtype.val q) _ (Pfam_idem Subtype.val q)
      (iterate_P Subtype.val rqPos k q) (mul_pos ha0 (inv_pos.mpr hω)) fun x => ?_
    have h := hlow k q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h
    linarith
  choose H hH hHP using hex
  exact ⟨H, hH, hHP, fun k q x => bracket_Qpos hσ ha hlow hH hHP k q x⟩

end OneStepFinal

end


-- ===== new part : LowerSide.part.lean =====
/-!
# The lower side `hlow` of Theorem 1 without the box 

For every stage `k` and every momentum `q` with `ω(q) > 0` (no box `q ∈ [−π, π]⁴`):
`G_k(q) = 𝓜^k(P/ω)(q) ≽ a P(q)/ω(q)` with `a = (4/π²)·0.04452²`.

The argument keeps one alias per stage, the alias `ζ*` nearest to the origin
(`ζ*_ν = 1` exactly when `sin²(q_ν/4) > 1/2`), and uses three facts:
* the scale: if `sin²(q_ν/2) ≤ sin²(β)` (`β = π/2^{m+1}`) for all `ν`, then at `r = r_{ζ*}`
  `sin²(r_ν/2) ≤ sin²(β/2)` (`alias_scale`);
* one alias from below: with `w = C(r) S_ζ P(q) x ⊥ s(r)`, `|N(r) w| ≥ n(ξ)|w|` (`Nm_lower`,
  `Nm_sq_lower`) and `|w|² ≥ (1 − b)|P(q)x|²`; the ratio `ω(q) ≥ 4(1 − b) ω(r)` (`omega_ratio`);
* the potentials `τ_m = (2Γ_m/π)⁴ ν_m` with `Γ_m = 2^m sin(π/2^{m+1})`, telescoping exactly in
  the cosine factors (`Gam_rec`, Viète), and `ν_m` absorbing the factors `n(ξ_{m+1})²`.
-/

noncomputable section

namespace OneStepLower

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. `N` on `s^⊥` from below -/

/-- `n(ξ) = (1 − ξ)³ − ξ − ξ²/2 − ξ³` (Lemma 2(e)). -/
def nlow (ξ : ℝ) : ℝ := (1 - ξ) ^ 3 - ξ - ξ ^ 2 / 2 - ξ ^ 3

/-- The multiplier of `⟨s, u⟩` in the identity `Nm_form_perp`. -/
def Lmul (s u : Fin 4 → ℝ) : ℝ :=
  (s 0 ^ 3 * u 0 - s 0 ^ 2 * s 1 * u 1 - s 0 ^ 2 * s 2 * u 2 - s 0 ^ 2 * s 3 * u 3
    - s 0 * s 1 ^ 2 * u 0 - s 0 * s 2 ^ 2 * u 0 - s 0 * s 3 ^ 2 * u 0 + 4 * s 0 * u 0
    + s 1 ^ 3 * u 1 - s 1 ^ 2 * s 2 * u 2 - s 1 ^ 2 * s 3 * u 3 - s 1 * s 2 ^ 2 * u 1
    - s 1 * s 3 ^ 2 * u 1 + 4 * s 1 * u 1 + s 2 ^ 3 * u 2 - s 2 ^ 2 * s 3 * u 3
    - s 2 * s 3 ^ 2 * u 2 + 4 * s 2 * u 2 + s 3 ^ 3 * u 3 + 4 * s 3 * u 3) / 8

/-- The diagonal coefficient `d_μ = π_μ − x_μ(1 + x_μ − X/2)`. -/
def dco (x : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF x μ - x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2)

/-- The cubic remainder `Σ_{μ<ν} x_ρ x_σ s_μ s_ν u_μ u_ν`. -/
def Rem (s u : Fin 4 → ℝ) : ℝ :=
  xs s 2 * xs s 3 * (s 0 * s 1 * u 0 * u 1) + xs s 1 * xs s 3 * (s 0 * s 2 * u 0 * u 2)
  + xs s 1 * xs s 2 * (s 0 * s 3 * u 0 * u 3) + xs s 0 * xs s 3 * (s 1 * s 2 * u 1 * u 2)
  + xs s 0 * xs s 2 * (s 1 * s 3 * u 1 * u 3) + xs s 0 * xs s 1 * (s 2 * s 3 * u 2 * u 3)

set_option maxRecDepth 8000 in
/-- **The identity of Lemma 2(e)**: `⟨u, N u⟩ = Σ d_μ u_μ² + ⅓ Rem + ⟨s, u⟩ L`. -/
theorem Nm_form_perp (s u : Fin 4 → ℝ) :
    dot u (Nm s u) = ∑ μ, dco (xs s) μ * u μ ^ 2 + (1 / 3) * Rem s u + dot s u * Lmul s u := by
  unfold dot Nm dco Rem Lmul
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem prod3_lower {a b c ξ : ℝ} (ha : 0 ≤ a ∧ a ≤ ξ) (hb : 0 ≤ b ∧ b ≤ ξ)
    (hc : 0 ≤ c ∧ c ≤ ξ) (hξ : ξ ≤ 1) : (1 - ξ) ^ 3 ≤ (1 - a) * (1 - b) * (1 - c) := by
  have h1 : 0 ≤ 1 - ξ := by linarith
  have h2 : 1 - ξ ≤ 1 - a := by linarith
  have h3 : 1 - ξ ≤ 1 - b := by linarith
  have h4 : 1 - ξ ≤ 1 - c := by linarith
  have hab : (1 - ξ) * (1 - ξ) ≤ (1 - a) * (1 - b) := mul_le_mul h2 h3 h1 (by linarith)
  have hab0 : 0 ≤ (1 - a) * (1 - b) := mul_nonneg (by linarith) (by linarith)
  calc (1 - ξ) ^ 3 = (1 - ξ) * (1 - ξ) * (1 - ξ) := by ring
    _ ≤ (1 - a) * (1 - b) * (1 - c) := mul_le_mul hab h4 h1 hab0

theorem piF_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : (1 - ξ) ^ 3 ≤ piF x μ := by
  fin_cases μ
  · exact prod3_lower (hx 1) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 2) hξ

theorem dco_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : nlow ξ + ξ ^ 3 ≤ dco x μ := by
  have hp := piF_lower hx hξ μ
  have hX : x μ ≤ x 0 + x 1 + x 2 + x 3 := by
    have h0 := hx 0; have h1 := hx 1; have h2 := hx 2; have h3 := hx 3
    fin_cases μ <;> simp <;> linarith
  have hm := hx μ
  have hprod : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ ξ + ξ ^ 2 / 2 := by
    have e1 : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ x μ * (1 + x μ / 2) :=
      mul_le_mul_of_nonneg_left (by linarith) hm.1
    have e2 : x μ * (1 + x μ / 2) ≤ ξ * (1 + ξ / 2) := by nlinarith
    nlinarith
  unfold dco nlow
  nlinarith

/-- One pair of the remainder: `0 ≤ ξ³(a² + b²) + p · s_a s_b a b` for `0 ≤ p ≤ ξ²`,
`s_a², s_b² ≤ 2ξ`. -/
theorem pair_nonneg {a b sa sb p ξ : ℝ} (hp0 : 0 ≤ p) (hp : p ≤ ξ ^ 2) (hξ : 0 ≤ ξ)
    (ha : sa ^ 2 ≤ 2 * ξ) (hb : sb ^ 2 ≤ 2 * ξ) :
    0 ≤ ξ ^ 3 * (a ^ 2 + b ^ 2) + p * (sa * sb * a * b) := by
  have h1 : 0 ≤ (sa * b + sb * a) ^ 2 := sq_nonneg _
  have h2 : sa ^ 2 * b ^ 2 ≤ 2 * ξ * b ^ 2 := mul_le_mul_of_nonneg_right ha (sq_nonneg b)
  have h3 : sb ^ 2 * a ^ 2 ≤ 2 * ξ * a ^ 2 := mul_le_mul_of_nonneg_right hb (sq_nonneg a)
  have hz : -(ξ * (a ^ 2 + b ^ 2)) ≤ sa * sb * a * b := by nlinarith
  have h4 : p * (-(ξ * (a ^ 2 + b ^ 2))) ≤ p * (sa * sb * a * b) :=
    mul_le_mul_of_nonneg_left hz hp0
  have h5 : p * (ξ * (a ^ 2 + b ^ 2)) ≤ ξ ^ 2 * (ξ * (a ^ 2 + b ^ 2)) :=
    mul_le_mul_of_nonneg_right hp (by positivity)
  nlinarith

/-- **`N ≽ n(ξ)` on `s^⊥`** when every `x_ν = s_ν²/2 ≤ ξ ≤ 1`. -/
theorem Nm_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) : nlow ξ * dot w w ≤ dot w (Nm s w) := by
  have hx' : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ ξ := fun ν => ⟨by unfold xs; positivity, hx ν⟩
  have hs : ∀ ν, s ν ^ 2 ≤ 2 * ξ := fun ν => by have := hx ν; unfold xs at this; linarith
  have hp : ∀ μ ν, 0 ≤ xs s μ * xs s ν ∧ xs s μ * xs s ν ≤ ξ ^ 2 := fun μ ν =>
    ⟨mul_nonneg (hx' μ).1 (hx' ν).1, by
      have := hx' μ; have := hx' ν
      calc xs s μ * xs s ν ≤ ξ * ξ := mul_le_mul (hx' μ).2 (hx' ν).2 (hx' ν).1 hξ0
        _ = ξ ^ 2 := by ring⟩
  rw [Nm_form_perp, hw, zero_mul, add_zero]
  have p01 := pair_nonneg (a := w 0) (b := w 1) (hp 2 3).1 (hp 2 3).2 hξ0 (hs 0) (hs 1)
  have p02 := pair_nonneg (a := w 0) (b := w 2) (hp 1 3).1 (hp 1 3).2 hξ0 (hs 0) (hs 2)
  have p03 := pair_nonneg (a := w 0) (b := w 3) (hp 1 2).1 (hp 1 2).2 hξ0 (hs 0) (hs 3)
  have p12 := pair_nonneg (a := w 1) (b := w 2) (hp 0 3).1 (hp 0 3).2 hξ0 (hs 1) (hs 2)
  have p13 := pair_nonneg (a := w 1) (b := w 3) (hp 0 2).1 (hp 0 2).2 hξ0 (hs 1) (hs 3)
  have p23 := pair_nonneg (a := w 2) (b := w 3) (hp 0 1).1 (hp 0 1).2 hξ0 (hs 2) (hs 3)
  have d0 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 0) (sq_nonneg (w 0))
  have d1 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 1) (sq_nonneg (w 1))
  have d2 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 2) (sq_nonneg (w 2))
  have d3 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 3) (sq_nonneg (w 3))
  unfold dot Rem
  simp only [Fin.sum_univ_four]
  linarith

theorem dot_self_nonneg (a : Fin 4 → ℝ) : 0 ≤ dot a a := by
  unfold dot; exact Finset.sum_nonneg fun i _ => mul_self_nonneg (a i)

theorem dot_cs (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa only [sq] using h

/-- `|N w|² ≥ n(ξ)² |w|²` on `s^⊥` (Cauchy–Schwarz with `Nm_lower`). -/
theorem Nm_sq_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) (hn : 0 ≤ nlow ξ) :
    nlow ξ ^ 2 * dot w w ≤ dot (Nm s w) (Nm s w) := by
  have h1 := Nm_lower hξ0 hξ hx hw
  have hA := dot_self_nonneg w
  have hB := dot_self_nonneg (Nm s w)
  have hcs := dot_cs w (Nm s w)
  have hc0 : 0 ≤ nlow ξ * dot w w := mul_nonneg hn hA
  have hsq : (nlow ξ * dot w w) ^ 2 ≤ dot w (Nm s w) ^ 2 := pow_le_pow_left₀ hc0 h1 2
  rcases eq_or_lt_of_le hA with h0 | hpos
  · rw [← h0]; simpa using hB
  · have : dot w w * (nlow ξ ^ 2 * dot w w) ≤ dot w w * dot (Nm s w) (Nm s w) := by
      nlinarith
    exact le_of_mul_le_mul_left this hpos

/-! ## 2. The scale of the nearest alias -/

/-- `b_m = sin²(π/2^{m+1})`. -/
def bS (m : ℕ) : ℝ := Real.sin (π / 2 ^ (m + 1)) ^ 2

theorem ang_half (m : ℕ) : π / 2 ^ (m + 1 + 1) = (π / 2 ^ (m + 1)) / 2 := by
  rw [pow_succ 2 (m + 1), div_div]

theorem ang_pos (m : ℕ) : 0 < π / 2 ^ (m + 1) := by positivity

theorem ang_le (m : ℕ) : π / 2 ^ (m + 1) ≤ π / 2 := by
  have h2 : (2 : ℝ) ≤ 2 ^ (m + 1) := by
    calc (2 : ℝ) = 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (m + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith [Real.pi_pos]

theorem cos_ang_nonneg (m : ℕ) : 0 ≤ Real.cos (π / 2 ^ (m + 1)) :=
  Real.cos_nonneg_of_mem_Icc ⟨by linarith [ang_pos m, Real.pi_pos], ang_le m⟩

theorem bS_eq (m : ℕ) : bS m = 1 - Real.cos (π / 2 ^ (m + 1)) ^ 2 := by
  unfold bS; rw [Real.sin_sq]

theorem bS_succ (m : ℕ) : bS (m + 1) = (1 - Real.cos (π / 2 ^ (m + 1))) / 2 := by
  unfold bS
  rw [ang_half, Real.sin_sq, Real.cos_sq (π / 2 ^ (m + 1) / 2)]
  have : 2 * (π / 2 ^ (m + 1) / 2) = π / 2 ^ (m + 1) := by ring
  rw [this]; ring

theorem bS_zero : bS 0 = 1 := by
  unfold bS; norm_num

theorem bS_le_one (m : ℕ) : bS m ≤ 1 := Real.sin_sq_le_one _

theorem bS_nonneg (m : ℕ) : 0 ≤ bS m := sq_nonneg _

/-- **The scale of the nearest alias**: if `sin²(q_ν/2) ≤ b_m` for all `ν`, then
`sin²(r_ν/2) ≤ b_{m+1}` at `r = r_{ζ*}` (no box on `q`). -/
theorem alias_scale (θ : Fin 4 → ℝ) (m : ℕ) (h : ∀ ν, sQ θ ν ^ 2 ≤ bS m) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ bS (m + 1) := by
  have hσ := sigma_mem (θ ν)
  have hx := xs_alias θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν
  unfold xs at hx
  have hq := omega_dir (θ ν)
  have hc0 := cos_ang_nonneg m
  have hb := h ν
  rw [bS_eq] at hb
  rw [bS_succ]
  unfold sQ at hb
  set c := Real.cos (π / 2 ^ (m + 1))
  set σ := Real.sin (θ ν) ^ 2
  set t := sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2
  by_cases hs : 1 / 2 < σ
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = true := by
      simp only [zstar, decide_eq_true_eq]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = 1 - σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 2 * σ - 1)]
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = false := by
      simp only [zstar, decide_eq_false_iff_not]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    have hs' : σ ≤ 1 / 2 := le_of_not_gt hs
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 1 - 2 * σ)]

/-! ## 3. The potentials -/

/-- `Γ_m = 2^m sin(π/2^{m+1})` (`Γ_0 = 1`, increasing to `π/2`). -/
def Gam (m : ℕ) : ℝ := 2 ^ m * Real.sin (π / 2 ^ (m + 1))

/-- `κ_{m+1} = cos(π/2^{m+2})`. -/
def kap (m : ℕ) : ℝ := Real.cos (π / 2 ^ (m + 1 + 1))

theorem Gam_rec (m : ℕ) : Gam (m + 1) * kap m = Gam m := by
  unfold Gam kap
  have h := Real.sin_two_mul (π / 2 ^ (m + 1 + 1))
  have e : 2 * (π / 2 ^ (m + 1 + 1)) = π / 2 ^ (m + 1) := by rw [ang_half]; ring
  rw [e] at h
  rw [h, pow_succ]
  ring

theorem one_sub_bS (m : ℕ) : 1 - bS (m + 1) = kap m ^ 2 := by
  unfold bS kap
  have := Real.sin_sq_add_cos_sq (π / 2 ^ (m + 1 + 1))
  linarith

theorem Gam_nonneg (m : ℕ) : 0 ≤ Gam m := by
  unfold Gam
  apply mul_nonneg (by positivity)
  apply Real.sin_nonneg_of_nonneg_of_le_pi (ang_pos m).le
  linarith [ang_le m, Real.pi_pos]

theorem Gam_le (m : ℕ) : Gam m ≤ π / 2 := by
  unfold Gam
  have h := Real.sin_le (ang_pos m).le
  calc 2 ^ m * Real.sin (π / 2 ^ (m + 1)) ≤ 2 ^ m * (π / 2 ^ (m + 1)) :=
        mul_le_mul_of_nonneg_left h (by positivity)
    _ = π / 2 := by rw [pow_succ]; field_simp

theorem Gam_zero : Gam 0 = 1 := by
  unfold Gam; norm_num

/-- `ξ_2 = 3.1416²/128 ≥ sin²(π/8)/2`. -/
def xi2 : ℝ := (3927 / 1250) ^ 2 / 128

/-- The bound `ξ` for `x = sin²(r/2)/2` at the scale `m + 1`. -/
def xiB : ℕ → ℝ
  | 0 => 1 / 4
  | 1 => xi2
  | m + 2 => (π / 2 ^ (m + 4)) ^ 2 / 2

/-- The `N`-part of the potential. -/
def nuT : ℕ → ℝ
  | 0 => nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160))
  | 1 => nlow xi2 ^ 2 * (1 - 33 / 160)
  | m + 2 => 1 - 33 / 10 / (2 ^ (m + 2)) ^ 2

/-- The potential `τ_m = (2Γ_m/π)⁴ ν_m`. -/
def tau (m : ℕ) : ℝ := (2 * Gam m / π) ^ 4 * nuT m

theorem nlow_ge {ξ : ℝ} (_h0 : 0 ≤ ξ) (h1 : ξ ≤ 1) : 1 - 4 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg (sq_nonneg ξ) (by linarith : (0 : ℝ) ≤ 5 / 2 - 2 * ξ)]

theorem sin_sq_le_sq {y : ℝ} (h0 : 0 ≤ y) (h1 : y ≤ π) : Real.sin y ^ 2 ≤ y ^ 2 :=
  pow_le_pow_left₀ (Real.sin_nonneg_of_nonneg_of_le_pi h0 h1) (Real.sin_le h0) 2

theorem bS_half_le (m : ℕ) : bS (m + 1) / 2 ≤ xiB m := by
  match m with
  | 0 =>
    show Real.sin (π / 2 ^ (0 + 1 + 1)) ^ 2 / 2 ≤ 1 / 4
    have e : π / 2 ^ (0 + 1 + 1) = π / 4 := by norm_num
    rw [e, Real.sin_pi_div_four, div_pow, Real.sq_sqrt (by norm_num)]
    norm_num
  | 1 =>
    show Real.sin (π / 2 ^ (1 + 1 + 1)) ^ 2 / 2 ≤ xi2
    have e : π / 2 ^ (1 + 1 + 1) = π / 8 := by norm_num
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 8) (by linarith [Real.pi_pos])
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have : (π / 8) ^ 2 ≤ (3927 / 1250 / 8) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (by norm_num at hp ⊢; linarith) 2
    unfold xi2
    nlinarith
  | k + 2 =>
    show Real.sin (π / 2 ^ (k + 2 + 1 + 1)) ^ 2 / 2 ≤ (π / 2 ^ (k + 4)) ^ 2 / 2
    have e : k + 2 + 1 + 1 = k + 4 := by omega
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 2 ^ (k + 4))
      (by
        have : (1 : ℝ) ≤ 2 ^ (k + 4) := one_le_pow₀ (by norm_num)
        rw [div_le_iff₀ (by positivity)]
        nlinarith [Real.pi_pos])
    linarith

theorem xiB_nonneg (m : ℕ) : 0 ≤ xiB m := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 => simp only [xiB]; positivity

theorem xiB_le (m : ℕ) : xiB m ≤ 1 / 4 := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 =>
    simp only [xiB]
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have h16 : (16 : ℝ) ≤ 2 ^ (k + 4) := by
      calc (16 : ℝ) = 2 ^ 4 := by norm_num
        _ ≤ 2 ^ (k + 4) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h1 : π / 2 ^ (k + 4) ≤ 1 / 4 := by
      rw [div_le_iff₀ (by positivity)]; nlinarith
    have h2 : 0 ≤ π / 2 ^ (k + 4) := by positivity
    nlinarith

theorem nlow_xiB_nonneg (m : ℕ) : 0 ≤ nlow (xiB m) := by
  have := nlow_ge (xiB_nonneg m) (by linarith [xiB_le m])
  linarith [xiB_le m]

theorem nuT_step (m : ℕ) : nuT m ≤ nuT (m + 1) * nlow (xiB m) ^ 2 := by
  match m with
  | 0 => show nuT 0 ≤ nuT 1 * nlow (1 / 4) ^ 2; simp only [nuT]; nlinarith
  | 1 =>
    show nuT 1 ≤ nuT 2 * nlow xi2 ^ 2
    simp only [nuT]
    norm_num
    linarith
  | k + 2 =>
    show 1 - 33 / 10 / (2 ^ (k + 2)) ^ 2 ≤
      (1 - 33 / 10 / (2 ^ (k + 3)) ^ 2) * nlow ((π / 2 ^ (k + 4)) ^ 2 / 2) ^ 2
    set p : ℝ := 2 ^ (k + 2) with hp_def
    have hp4 : (4 : ℝ) ≤ p := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have e3 : (2 : ℝ) ^ (k + 3) = 2 * p := by rw [hp_def, pow_succ]; ring
    have e4 : (2 : ℝ) ^ (k + 4) = 4 * p := by
      rw [hp_def, show k + 4 = k + 2 + 2 by omega, pow_add]; ring
    rw [e3, e4]
    have hπ := Real.pi_lt_d4
    have hπ0 := Real.pi_pos
    have hπ2 : π ^ 2 < 9.87 := by nlinarith
    set e : ℝ := 1 / p ^ 2 with he_def
    have hp0 : 0 < p := by linarith
    have he0 : 0 < e := by positivity
    have he1 : e ≤ 1 / 16 := by
      rw [he_def, div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith
    have hξ : (π / (4 * p)) ^ 2 / 2 = π ^ 2 * e / 32 := by
      rw [he_def]; field_simp; ring
    rw [hξ]
    have hξ0 : 0 ≤ π ^ 2 * e / 32 := by positivity
    have hξ1 : π ^ 2 * e / 32 ≤ 1 := by nlinarith
    have hn := nlow_ge hξ0 hξ1
    have hn0 : 0 ≤ 1 - 4 * (π ^ 2 * e / 32) := by nlinarith
    have hn2 : (1 - 4 * (π ^ 2 * e / 32)) ^ 2 ≤ nlow (π ^ 2 * e / 32) ^ 2 :=
      pow_le_pow_left₀ hn0 hn 2
    have l1 : 33 / 10 / p ^ 2 = 33 / 10 * e := by rw [he_def]; ring
    have l2 : 33 / 10 / (2 * p) ^ 2 = 33 / 10 * e / 4 := by rw [he_def]; field_simp; ring
    rw [l1, l2]
    have hA : 0 ≤ 1 - 33 / 10 * e / 4 := by nlinarith
    have hstep : 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
      have h1 : 1 - 2 * (4 * (π ^ 2 * e / 32)) ≤ (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
        nlinarith [sq_nonneg (4 * (π ^ 2 * e / 32))]
      have h2 := mul_le_mul_of_nonneg_left h1 hA
      have h3 : π ^ 2 * e < 9.87 * e := mul_lt_mul_of_pos_right hπ2 he0
      have h4 : 0 ≤ e * e * π ^ 2 := mul_nonneg (mul_nonneg he0.le he0.le) (sq_nonneg π)
      nlinarith
    calc 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := hstep
      _ ≤ (1 - 33 / 10 * e / 4) * nlow (π ^ 2 * e / 32) ^ 2 :=
        mul_le_mul_of_nonneg_left hn2 hA

theorem nuT_bounds (m : ℕ) : 0 ≤ nuT m ∧ nuT m ≤ 1 := by
  match m with
  | 0 => simp only [nuT]; norm_num [nlow, xi2]
  | 1 => simp only [nuT]; norm_num [nlow, xi2]
  | k + 2 =>
    simp only [nuT]
    have h4 : (4 : ℝ) ≤ 2 ^ (k + 2) := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h16 : (16 : ℝ) ≤ (2 ^ (k + 2)) ^ 2 := by nlinarith
    have h0 : 0 ≤ 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 := by positivity
    have h1 : 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 ≤ 1 := by
      rw [div_le_one (by positivity)]; linarith
    constructor <;> linarith

theorem pref_bounds (m : ℕ) : 0 ≤ (2 * Gam m / π) ^ 4 ∧ (2 * Gam m / π) ^ 4 ≤ 1 := by
  have h0 : 0 ≤ 2 * Gam m / π := div_nonneg (by linarith [Gam_nonneg m]) Real.pi_pos.le
  have h1 : 2 * Gam m / π ≤ 1 := by
    rw [div_le_one Real.pi_pos]; linarith [Gam_le m]
  exact ⟨by positivity, pow_le_one₀ h0 h1⟩

theorem tau_nonneg (m : ℕ) : 0 ≤ tau m :=
  mul_nonneg (pref_bounds m).1 (nuT_bounds m).1

theorem tau_le_one (m : ℕ) : tau m ≤ 1 := by
  unfold tau
  have := pref_bounds m
  have := nuT_bounds m
  nlinarith

/-- **One stage of the potentials**: `τ_m ≤ τ_{m+1} n(ξ_{m+1})² (1 − b_{m+1})²`. -/
theorem tau_step (m : ℕ) :
    tau m ≤ tau (m + 1) * nlow (xiB m) ^ 2 * (1 - bS (m + 1)) ^ 2 := by
  unfold tau
  rw [one_sub_bS, ← Gam_rec m]
  have hs := nuT_step m
  have h0 : 0 ≤ (2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4 := by positivity
  calc (2 * (Gam (m + 1) * kap m) / π) ^ 4 * nuT m
      = ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * nuT m := by ring
    _ ≤ ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * (nuT (m + 1) * nlow (xiB m) ^ 2) :=
      mul_le_mul_of_nonneg_left hs h0
    _ = (2 * Gam (m + 1) / π) ^ 4 * nuT (m + 1) * nlow (xiB m) ^ 2 * (kap m ^ 2) ^ 2 := by ring

/-- `a = (4/π²)·0.04452² ≤ τ_0 = (2/π)⁴ ν_0`. -/
theorem a_le_tau : 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 ≤ tau 0 := by
  unfold tau
  rw [Gam_zero]
  have hν : nuT 0 = nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160)) := rfl
  have hν' : (0.0049 : ℝ) ≤ nuT 0 := by rw [hν]; norm_num [nlow, xi2]
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hp : 0 < π ^ 2 := by positivity
  have e : (2 * 1 / π) ^ 4 = 16 / (π ^ 2) ^ 2 := by field_simp; ring
  rw [e]
  rw [show 16 / (π ^ 2) ^ 2 * nuT 0 = (16 * nuT 0 / π ^ 2) / π ^ 2 by field_simp]
  rw [show 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 = (4 * 0.04452 ^ 2) / π ^ 2 by ring]
  apply div_le_div_of_nonneg_right _ hp.le
  rw [le_div_iff₀ hp]
  nlinarith

/-! ## 4. One alias from below and the ratio of `ω` -/

theorem cR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    cR θ ζ ν ^ 2 = 1 - sR θ ζ ν ^ 2 := by
  unfold cR sR; rw [Real.cos_sq']

theorem sg_sq (ζ : Fin 4 → Bool) (ν : Fin 4) : sg ζ ν ^ 2 = 1 := by
  unfold sg; split_ifs <;> norm_num

theorem sQ_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * sR θ ζ ν ^ 2 * cR θ ζ ν ^ 2 := by
  unfold sQ sR cR phi
  cases ζ ν
  · simp only [Bool.false_eq_true, if_false, add_zero, Real.sin_two_mul]; ring
  · simp only [if_true, Real.sin_add_pi_div_two, Real.cos_add_pi_div_two, Real.sin_two_mul]; ring

/-- **One alias from below**: `4 n(ξ)² (1 − b) |P(q)x|² ≤ ⟨A_ζᵀx, P(r_ζ) A_ζᵀx⟩`
when `sin²(r_ν/2) ≤ b` for all `ν` and `b/2 ≤ ξ ≤ 1`, `n(ξ) ≥ 0`. -/
theorem one_alias_lower (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b ξ : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (hξ : b / 2 ≤ ξ) (hξ1 : ξ ≤ 1) (hn : 0 ≤ nlow ξ) :
    4 * nlow ξ ^ 2 * (1 - b) * dot (proj (sQ θ) x) (proj (sQ θ) x) ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb0 : 0 ≤ b := le_trans (sq_nonneg _) (hsR 0)
  have hξ0 : 0 ≤ ξ := by linarith
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ ξ := fun ν => by unfold xs; linarith [hsR ν]
  have hN := Nm_sq_lower hξ0 hξ1 hx hw hn
  have hww : (1 - b) * dot u u ≤ dot w w := by
    unfold dot
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have e : w ν * w ν = cR θ ζ ν ^ 2 * (u ν * u ν) := by
      rw [hw_def]
      have := sg_sq ζ ν
      calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
          = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * (u ν * u ν) := by ring
        _ = _ := by rw [this, mul_one]
    rw [e, cR_sq]
    exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)
  have hn2 : 0 ≤ nlow ξ ^ 2 := sq_nonneg _
  calc 4 * nlow ξ ^ 2 * (1 - b) * dot u u = 4 * (nlow ξ ^ 2 * ((1 - b) * dot u u)) := by ring
    _ ≤ 4 * (nlow ξ ^ 2 * dot w w) := by gcongr
    _ ≤ 4 * dot (Nm (sR θ ζ) w) (Nm (sR θ ζ) w) := by gcongr

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **The ratio of `ω`**: `4(1 − b) ω(r_ζ) ≤ ω(q)` when `sin²(r_ν/2) ≤ b`. -/
theorem omega_ratio (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    {b : ℝ} (hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ b) :
    4 * (1 - b) * omF th (rq q ζ) ≤ omF th q := by
  unfold omF
  rw [hrq, sQ_thR, Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  rw [sQ_sq_alias (th q) ζ ν, cR_sq]
  have h := hsR ν
  have h0 := sq_nonneg (sR (th q) ζ ν)
  nlinarith

theorem inner_P (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) := by
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, dot_proj_self]

theorem inner_P_nonneg (q : Q) (x : V) : 0 ≤ ⟪x, Pfam th q x⟫ := by
  rw [inner_P]; exact dot_self_nonneg _

theorem alias_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    (x : V) :
    ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        Pfam th (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ =
      dot (Atr (th q) ζ (WithLp.ofLp x)) (proj (sR (th q) ζ) (Atr (th q) ζ (WithLp.ofLp x))) := by
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
    projM_mulVec]

theorem scale_zero (q : Q) (ν : Fin 4) : sQ (th q) ν ^ 2 ≤ bS 0 := by
  rw [bS_zero]; exact Real.sin_sq_le_one _

/-! ## 5. The induction over the stages -/

/-- **The lower side at every scale**: for every stage `k`, scale `m` and momentum `q` with
`sin²(q_ν/2) ≤ b_m`, `τ_m P(q)/ω(q) ≼ G_k(q)`. -/
theorem lower_inv (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) : ∀ (m : ℕ) (q : Q), (∀ ν, sQ (th q) ν ^ 2 ≤ bS m) → ∀ x : V,
      tau m * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ := by
  induction k with
  | zero =>
    intro m q _ x
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
    have h1 := tau_le_one m
    have h0 := inner_P_nonneg th q x
    have hw := (inv_pos.mpr (hω q)).le
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw h0
    nlinarith
  | succ k ih =>
    intro m q hq x
    rw [Function.iterate_succ_apply', Mfam_inner]
    set G := (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) with hG
    set ζs := zstar fun ν => Real.sin (th q ν) ^ 2 with hζs
    set y := Matrix.toEuclideanLin (AtM (th q) ζs) x with hy
    have hnn : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
      intro ζ
      refine le_trans ?_ (ih 0 (rq q ζ) (scale_zero th (rq q ζ)) _)
      exact mul_nonneg (mul_nonneg (tau_nonneg 0) (inv_pos.mpr (hω _)).le)
        (inner_P_nonneg th _ _)
    have hsingle : ⟪y, G (rq q ζs) y⟫ ≤ ∑ ζ : Fin 4 → Bool,
        ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
      Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hnn ζ)
        (Finset.mem_univ ζs)
    have hscale : ∀ ν, sR (th q) ζs ν ^ 2 ≤ bS (m + 1) := alias_scale (th q) m hq
    have hq' : ∀ ν, sQ (th (rq q ζs)) ν ^ 2 ≤ bS (m + 1) := by
      rw [hrq, sQ_thR]; exact hscale
    have hIH := ih (m + 1) (rq q ζs) hq' y
    rw [hy, alias_inner th rq hrq q ζs x] at hIH
    rw [← hy] at hIH
    have hA := one_alias_lower (th q) (WithLp.ofLp x) ζs hscale (bS_half_le m)
      (by linarith [xiB_le m]) (nlow_xiB_nonneg m)
    have hωr := omega_ratio th rq hrq q ζs hscale
    have hτ := tau_step m
    rw [← inner_P th q x] at hA
    -- abbreviations
    set b := bS (m + 1)
    set n2 := nlow (xiB m) ^ 2
    set U := ⟪x, Pfam th q x⟫
    set Y := dot (Atr (th q) ζs (WithLp.ofLp x))
      (proj (sR (th q) ζs) (Atr (th q) ζs (WithLp.ofLp x)))
    set wq := (omF th q)⁻¹
    set wr := (omF th (rq q ζs))⁻¹
    have hU : 0 ≤ U := inner_P_nonneg th q x
    have hb1 : 0 ≤ 1 - b := by linarith [bS_le_one (m + 1)]
    have hτ' : 0 ≤ tau (m + 1) := tau_nonneg _
    have hn2 : 0 ≤ n2 := sq_nonneg _
    have hwq : 0 ≤ wq := (inv_pos.mpr (hω q)).le
    have hwr : 0 ≤ wr := (inv_pos.mpr (hω _)).le
    have e1 : omF th q * wq = 1 := mul_inv_cancel₀ (hω q).ne'
    have e2 : omF th (rq q ζs) * wr = 1 := mul_inv_cancel₀ (hω _).ne'
    have key : 4 * (1 - b) * wq ≤ wr := by
      calc 4 * (1 - b) * wq = 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) := by
            rw [show 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) =
              4 * (1 - b) * wq * (omF th (rq q ζs) * wr) by ring, e2, mul_one]
        _ ≤ omF th q * (wq * wr) := mul_le_mul_of_nonneg_right hωr (mul_nonneg hwq hwr)
        _ = wr := by rw [← mul_assoc, e1, one_mul]
    have hc : 0 ≤ tau (m + 1) * n2 * (1 - b) := mul_nonneg (mul_nonneg hτ' hn2) hb1
    calc tau m * wq * U ≤ (tau (m + 1) * n2 * (1 - b) ^ 2) * wq * U :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hτ hwq) hU
      _ = (tau (m + 1) * n2 * (1 - b)) * ((1 - b) * wq) * U := by ring
      _ ≤ (tau (m + 1) * n2 * (1 - b)) * (wr / 4) * U := by
          apply mul_le_mul_of_nonneg_right _ hU
          apply mul_le_mul_of_nonneg_left _ hc
          linarith
      _ = (1 / 16) * (tau (m + 1) * wr * (4 * n2 * (1 - b) * U)) := by ring
      _ ≤ (1 / 16) * (tau (m + 1) * wr * Y) := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact mul_le_mul_of_nonneg_left hA (mul_nonneg hτ' hwr)
      _ ≤ (1 / 16) * ⟪y, G (rq q ζs) y⟫ := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact hIH
      _ ≤ _ := mul_le_mul_of_nonneg_left hsingle (by norm_num)

/-- **`hlow` without the box**: `(4/π²)·0.04452² · P/ω ≼ 𝓜^k(P/ω)` for every stage `k`. -/
theorem lower_side (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) :
    UniformBracket.Lw ((4 / π ^ 2 * (0.04452 : ℝ) ^ 2) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  have h := lower_inv th rq hrq hω k 0 q (scale_zero th q) x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  have ha := a_le_tau
  have hP := inner_P_nonneg th q x
  have hw := (inv_pos.mpr (hω q)).le
  calc 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫)
      ≤ tau 0 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
        mul_le_mul_of_nonneg_right ha (mul_nonneg hw hP)
    _ = tau 0 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
    _ ≤ _ := h

/-! ## 6. Theorem 1 on `Qpos` without hypotheses -/

/-- **Theorem 1 (the uniform bracket of the stage actions) on every momentum with `ω > 0`**:
the inverses `H_k` of `G_k = 𝓜^k(P/ω)` on `ran P` exist and
`(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage `k`, with no remaining hypothesis. -/
theorem bracket_Qpos_free :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_Qpos_low (σ := 0.04452) (a := 4 / π ^ 2 * (0.04452 : ℝ) ^ 2) le_rfl rfl
    (lower_side Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2))

end OneStepLower

end

-- ===== new part : L3.part.lean =====
/-!
# (L3): the lowest alias, `K̃_0 ≽ 11/48` and `W_0 ≽ 1/√2` (Propositions 1, 2), and the
sharper lower side 

* `K̃_0` of is the transverse average `N(p)` of (the same quadratic form
  `|x|² − ½ Σ_{μ<ν} 𝔅_{μν} (s_ν x_μ − s_μ x_ν)²`); its lowest cell is `s_ν² ≤ ½` (`|p_μ| ≤ π/2`).
* `Nm_cell_lower`: `N ≽ 11/48` on `s^⊥` when every `s_ν² ≤ ½` (Proposition 1);
  `Nm_cell_full`: `N ≽ 11/48` on all of `ℝ⁴` (with `N s = s`).
* `lowest_alias_lower`: the alias `ζ*` nearest to the origin lies in the lowest cell for every
  `θ`, and the real symbol `Q̃ = 2 C N` there satisfies `|Q̃ᵀ v|² = 4|N C v|² ≥ (121/1152)|v|²`
  and `|Q̃ v|² ≥ (121/1152)|v|²` (Proposition 2, `c₀ = 121/1152`).
* `lower_inv_gen`: the induction of `OneStepLower.lower_inv` for any factor `n_m` and potential
  `τ_m`; with `n_0 = 11/48` it gives `G_k ≽ τ'_0 P/ω`, `τ'_0 ≥ 0.0034`, and
  `bracket_Qpos_sharp`: `(ω/745) P ≼ ¼ H_k ≼ 74 ω P` with no hypothesis.
-/

noncomputable section

namespace OneStepCell

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. Proposition 1: `N ≽ 11/48` on the lowest cell -/

set_option maxRecDepth 8000 in
/-- `|u|² − ⟨u, N u⟩ = ½ Σ_{μ<ν} 𝔅_{μν} (s_ν u_μ − s_μ u_ν)²`. -/
theorem IminusN_pairs (s u : Fin 4 → ℝ) :
    dot u u - dot u (Nm s u) = (1 / 2) * (
      (1 - Ef (xs s 2) (xs s 3)) * (s 1 * u 0 - s 0 * u 1) ^ 2
    + (1 - Ef (xs s 1) (xs s 3)) * (s 2 * u 0 - s 0 * u 2) ^ 2
    + (1 - Ef (xs s 1) (xs s 2)) * (s 3 * u 0 - s 0 * u 3) ^ 2
    + (1 - Ef (xs s 0) (xs s 3)) * (s 2 * u 1 - s 1 * u 2) ^ 2
    + (1 - Ef (xs s 0) (xs s 2)) * (s 3 * u 1 - s 1 * u 3) ^ 2
    + (1 - Ef (xs s 0) (xs s 1)) * (s 3 * u 2 - s 2 * u 3) ^ 2) := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

/-- Lagrange: `Σ_{μ<ν} (s_ν u_μ − s_μ u_ν)² = |s|²|u|² − ⟨s, u⟩²`. -/
theorem lagrange4 (s u : Fin 4 → ℝ) :
    (s 1 * u 0 - s 0 * u 1) ^ 2 + (s 2 * u 0 - s 0 * u 2) ^ 2 + (s 3 * u 0 - s 0 * u 3) ^ 2
      + (s 2 * u 1 - s 1 * u 2) ^ 2 + (s 3 * u 1 - s 1 * u 3) ^ 2 + (s 3 * u 2 - s 2 * u 3) ^ 2
      = dot s s * dot u u - dot s u ^ 2 := by
  unfold dot; simp only [Fin.sum_univ_four]; ring

/-- `𝔅 |s|² ≤ 37/24` for one pair (`f(s, t) ≤ f(½, ½)` of Proposition 1). -/
theorem pair_bound {y z S : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 4) (hz : 0 ≤ z ∧ z ≤ 1 / 4)
    (_hS0 : 0 ≤ S) (hS : S ≤ 1 + 2 * (y + z)) : (1 - Ef y z) * S ≤ 37 / 24 := by
  unfold Ef
  have hB : 0 ≤ 1 - ((y + z) / 2 - y * z / 3) := by nlinarith
  have h1 : (1 - ((y + z) / 2 - y * z / 3)) * S ≤
      (1 - ((y + z) / 2 - y * z / 3)) * (1 + 2 * (y + z)) := mul_le_mul_of_nonneg_left hS hB
  have ha : 0 ≤ 1 / 4 - y := by linarith
  have hb : 0 ≤ 1 / 4 - z := by linarith
  nlinarith [mul_nonneg (mul_nonneg ha ha) hb, mul_nonneg (mul_nonneg ha hb) hb, mul_nonneg ha hb,
    mul_nonneg ha ha, mul_nonneg hb hb]

theorem sum6_bound {S W B1 B2 B3 B4 B5 B6 r1 r2 r3 r4 r5 r6 : ℝ}
    (h1 : B1 * S * r1 ≤ 37 / 24 * r1) (h2 : B2 * S * r2 ≤ 37 / 24 * r2)
    (h3 : B3 * S * r3 ≤ 37 / 24 * r3) (h4 : B4 * S * r4 ≤ 37 / 24 * r4)
    (h5 : B5 * S * r5 ≤ 37 / 24 * r5) (h6 : B6 * S * r6 ≤ 37 / 24 * r6)
    (hl : r1 + r2 + r3 + r4 + r5 + r6 = S * W) :
    S * ((1 / 2) * (B1 * r1 + B2 * r2 + B3 * r3 + B4 * r4 + B5 * r5 + B6 * r6)) ≤
      S * ((37 / 48) * W) := by
  have e : S * ((1 / 2) * (B1 * r1 + B2 * r2 + B3 * r3 + B4 * r4 + B5 * r5 + B6 * r6)) =
      (1 / 2) * (B1 * S * r1 + B2 * S * r2 + B3 * S * r3 + B4 * S * r4 + B5 * S * r5 +
        B6 * S * r6) := by ring
  have e2 : S * ((37 / 48) * W) = (1 / 2) * (37 / 24 * (S * W)) := by ring
  rw [e, e2, ← hl]
  linarith

theorem Ef_le_one' {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 4) (hz : 0 ≤ z ∧ z ≤ 1 / 4) :
    0 ≤ 1 - Ef y z := by
  unfold Ef; nlinarith

/-- **Proposition 1**: `N ≽ 11/48` on `s^⊥` when every `x_ν = s_ν²/2 ≤ ¼`. -/
theorem Nm_cell_lower {s w : Fin 4 → ℝ} (hx : ∀ ν, xs s ν ≤ 1 / 4) (hw : dot s w = 0) :
    (11 / 48) * dot w w ≤ dot w (Nm s w) := by
  have hx' : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 4 := fun ν => ⟨by unfold xs; positivity, hx ν⟩
  have hsq : ∀ ν, s ν ^ 2 = 2 * xs s ν := fun ν => by unfold xs; ring
  have hSdef : dot s s = 2 * (xs s 0 + xs s 1 + xs s 2 + xs s 3) := by
    unfold dot; simp only [Fin.sum_univ_four]
    have := hsq 0; have := hsq 1; have := hsq 2; have := hsq 3
    nlinarith
  have hS0 := dot_self_nonneg s
  have hW0 := dot_self_nonneg w
  have hform := IminusN_pairs s w
  have hlag := lagrange4 s w
  rw [hw] at hlag
  set S := dot s s
  have b01 := pair_bound (hx' 2) (hx' 3) hS0 (by linarith [hx' 0, hx' 1])
  have b02 := pair_bound (hx' 1) (hx' 3) hS0 (by linarith [hx' 0, hx' 2])
  have b03 := pair_bound (hx' 1) (hx' 2) hS0 (by linarith [hx' 0, hx' 3])
  have b12 := pair_bound (hx' 0) (hx' 3) hS0 (by linarith [hx' 1, hx' 2])
  have b13 := pair_bound (hx' 0) (hx' 2) hS0 (by linarith [hx' 1, hx' 3])
  have b23 := pair_bound (hx' 0) (hx' 1) hS0 (by linarith [hx' 2, hx' 3])
  have t01 := mul_le_mul_of_nonneg_right b01 (sq_nonneg (s 1 * w 0 - s 0 * w 1))
  have t02 := mul_le_mul_of_nonneg_right b02 (sq_nonneg (s 2 * w 0 - s 0 * w 2))
  have t03 := mul_le_mul_of_nonneg_right b03 (sq_nonneg (s 3 * w 0 - s 0 * w 3))
  have t12 := mul_le_mul_of_nonneg_right b12 (sq_nonneg (s 2 * w 1 - s 1 * w 2))
  have t13 := mul_le_mul_of_nonneg_right b13 (sq_nonneg (s 3 * w 1 - s 1 * w 3))
  have t23 := mul_le_mul_of_nonneg_right b23 (sq_nonneg (s 3 * w 2 - s 2 * w 3))
  -- `S (|w|² − ⟨w, N w⟩) ≤ (37/48) S |w|²`
  have hlag' : (s 1 * w 0 - s 0 * w 1) ^ 2 + (s 2 * w 0 - s 0 * w 2) ^ 2
      + (s 3 * w 0 - s 0 * w 3) ^ 2 + (s 2 * w 1 - s 1 * w 2) ^ 2
      + (s 3 * w 1 - s 1 * w 3) ^ 2 + (s 3 * w 2 - s 2 * w 3) ^ 2 = S * dot w w := by
    rw [hlag]; ring
  have hmain : S * (dot w w - dot w (Nm s w)) ≤ S * ((37 / 48) * dot w w) := by
    rw [hform]
    exact sum6_bound t01 t02 t03 t12 t13 t23 hlag'
  rcases eq_or_lt_of_le hS0 with h0 | hpos
  · -- `s = 0`
    have hs0 : ∀ ν, s ν = 0 := by
      intro ν
      have h' : ∑ j, s j * s j = 0 := h0.symm
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' ν
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    have : dot w w - dot w (Nm s w) = 0 := by
      rw [hform]; simp only [hs0]; ring
    linarith only [this, hW0]
  · have h37 := le_of_mul_le_mul_left hmain hpos
    linarith only [h37]

theorem Nm_smul (s v : Fin 4 → ℝ) (a : ℝ) :
    Nm s (fun i => a * v i) = fun μ => a * Nm s v μ := by
  funext μ
  show piF (xs s) μ * (a * v μ) + 1 / 2 * s μ *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * (a * v ν)) =
    a * (piF (xs s) μ * v μ + 1 / 2 * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * v ν))
  have h : ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * (a * v ν)) =
      a * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * v ν) := by
    rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ν _ => by ring
  rw [h]; ring

/-- **`N ≽ 11/48` on all of `ℝ⁴`** in the lowest cell (`N s = s`, `N` symmetric). -/
theorem Nm_cell_full {s : Fin 4 → ℝ} (hx : ∀ ν, xs s ν ≤ 1 / 4) (u : Fin 4 → ℝ) :
    (11 / 48) * dot u u ≤ dot u (Nm s u) := by
  set a := dot s u / dot s s
  set w := proj s u with hw_def
  have hw : dot s w = 0 := dot_proj s u
  have hu : u = w + fun i => a * s i := by
    funext i; simp only [Pi.add_apply, hw_def, proj]; ring
  have hNw := Nm_cell_lower hx hw
  have hNu : Nm s u = Nm s w + fun i => a * s i := by
    rw [hu, Nm_add, Nm_smul, Nm_self]
  have hsNw : dot s (Nm s w) = 0 := by rw [Nm_symm, Nm_self, hw]
  have hws : dot w s = 0 := by rw [dot_comm, hw]
  have hSs := dot_self_nonneg s
  have e1 : dot u u = dot w w + a ^ 2 * dot s s := by
    rw [hu]
    simp only [dot_add_left, dot_add_right]
    have h1 : dot w (fun i => a * s i) = a * dot w s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h2 : dot (fun i => a * s i) w = a * dot s w := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h3 : dot (fun i => a * s i) (fun i => a * s i) = a ^ 2 * dot s s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [h1, h2, h3, hws, hw]; ring
  have e2 : dot u (Nm s u) = dot w (Nm s w) + a ^ 2 * dot s s := by
    rw [hNu]
    conv_lhs => rw [hu]
    simp only [dot_add_left, dot_add_right]
    have h1 : dot w (fun i => a * s i) = a * dot w s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h2 : dot (fun i => a * s i) (Nm s w) = a * dot s (Nm s w) := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    have h3 : dot (fun i => a * s i) (fun i => a * s i) = a ^ 2 * dot s s := by
      unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [h1, h2, h3, hws, hsNw]; ring
  rw [e1, e2]
  nlinarith [mul_nonneg (sq_nonneg a) hSs]

/-- From a form bound to a norm bound: `c|u|² ≤ ⟨u, N u⟩`, `c ≥ 0` give `c²|u|² ≤ |N u|²`. -/
theorem sq_of_form {s u : Fin 4 → ℝ} {c : ℝ} (hc : 0 ≤ c) (h : c * dot u u ≤ dot u (Nm s u)) :
    c ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) := by
  have hA := dot_self_nonneg u
  have hB := dot_self_nonneg (Nm s u)
  have hcs := dot_cs u (Nm s u)
  have hc0 : 0 ≤ c * dot u u := mul_nonneg hc hA
  have hsq : (c * dot u u) ^ 2 ≤ dot u (Nm s u) ^ 2 := pow_le_pow_left₀ hc0 h 2
  rcases eq_or_lt_of_le hA with h0 | hpos
  · rw [← h0]; simpa using hB
  · have : dot u u * (c ^ 2 * dot u u) ≤ dot u u * dot (Nm s u) (Nm s u) := by nlinarith
    exact le_of_mul_le_mul_left this hpos

/-! ## 2. Proposition 2 at the alias nearest to the origin -/

/-- The alias nearest to the origin is in the lowest cell: `sin²(r_ν/2) ≤ ½` for every `θ`. -/
theorem zstar_cell (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ 1 / 2 := by
  have h := alias_scale θ 0 (fun ν => by rw [bS_zero]; exact Real.sin_sq_le_one _) ν
  have e : bS (0 + 1) = 1 / 2 := by
    rw [bS_succ]
    have : π / 2 ^ (0 + 1) = π / 2 := by norm_num
    rw [this, Real.cos_pi_div_two]; norm_num
  linarith

theorem dot_C_lower (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (v : Fin 4 → ℝ) :
    (1 - b) * dot v v ≤ dot (fun ν => cR θ ζ ν * v ν) (fun ν => cR θ ζ ν * v ν) := by
  unfold dot
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  have e : cR θ ζ ν * v ν * (cR θ ζ ν * v ν) = cR θ ζ ν ^ 2 * (v ν * v ν) := by ring
  rw [e, cR_sq]
  exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)

/-- **Proposition 2 (real form) at the lowest alias `ζ*`**: with `Q̃ = 2 C N` (`C = diag cos`),
`|Q̃ᵀ v|² = |2 N C v|² ≥ (121/1152)|v|²` for every `θ` and `v`. -/
theorem lowest_alias_lower (θ v : Fin 4 → ℝ) :
    (121 / 1152) * dot v v ≤
      dot (fun μ => 2 * Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2))
          (fun ν => cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν * v ν) μ)
        (fun μ => 2 * Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2))
          (fun ν => cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν * v ν) μ) := by
  set ζ := zstar fun ν => Real.sin (θ ν) ^ 2
  have hcell := zstar_cell θ
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ 1 / 4 := fun ν => by unfold xs; linarith [hcell ν]
  have h1 := sq_of_form (by norm_num : (0 : ℝ) ≤ 11 / 48)
    (Nm_cell_full hx (fun ν => cR θ ζ ν * v ν))
  have h2 := dot_C_lower θ ζ hcell v
  have e : dot (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν) μ)
      (fun μ => 2 * Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν) μ) =
      4 * dot (Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν)) (Nm (sR θ ζ) (fun ν => cR θ ζ ν * v ν)) := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
  rw [e]
  have hv := dot_self_nonneg v
  nlinarith

/-- The other order, `|Q̃ v|² = |2 C N v|² ≥ (121/1152)|v|²` at `ζ*`. -/
theorem lowest_alias_lower' (θ v : Fin 4 → ℝ) :
    (121 / 1152) * dot v v ≤
      dot (fun μ => 2 * (cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) μ *
          Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2)) v μ))
        (fun μ => 2 * (cR θ (zstar fun ν => Real.sin (θ ν) ^ 2) μ *
          Nm (sR θ (zstar fun ν => Real.sin (θ ν) ^ 2)) v μ)) := by
  set ζ := zstar fun ν => Real.sin (θ ν) ^ 2
  have hcell := zstar_cell θ
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ 1 / 4 := fun ν => by unfold xs; linarith [hcell ν]
  have h1 := sq_of_form (by norm_num : (0 : ℝ) ≤ 11 / 48) (Nm_cell_full hx v)
  have h2 := dot_C_lower θ ζ hcell (Nm (sR θ ζ) v)
  have e : dot (fun μ => 2 * (cR θ ζ μ * Nm (sR θ ζ) v μ))
      (fun μ => 2 * (cR θ ζ μ * Nm (sR θ ζ) v μ)) =
      4 * dot (fun μ => cR θ ζ μ * Nm (sR θ ζ) v μ) (fun μ => cR θ ζ μ * Nm (sR θ ζ) v μ) := by
    unfold dot; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
  rw [e]
  have hv := dot_self_nonneg v
  nlinarith

/-! ## 3. The induction for any factors and potentials, and the sharper lower side -/

/-- One alias from below with any form bound `n` of `N(r)` on `s(r)^⊥`. -/
theorem one_alias_gen (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b n : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (hn : 0 ≤ n)
    (hN : ∀ w, dot (sR θ ζ) w = 0 → n * dot w w ≤ dot w (Nm (sR θ ζ) w)) :
    4 * n ^ 2 * (1 - b) * dot (proj (sQ θ) x) (proj (sQ θ) x) ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hNs := sq_of_form hn (hN w hw)
  have hww : (1 - b) * dot u u ≤ dot w w := by
    unfold dot
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have e : w ν * w ν = cR θ ζ ν ^ 2 * (u ν * u ν) := by
      rw [hw_def]
      have := sg_sq ζ ν
      calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
          = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * (u ν * u ν) := by ring
        _ = _ := by rw [this, mul_one]
    rw [e, cR_sq]
    exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)
  have hn2 : 0 ≤ n ^ 2 := sq_nonneg _
  calc 4 * n ^ 2 * (1 - b) * dot u u = 4 * (n ^ 2 * ((1 - b) * dot u u)) := by ring
    _ ≤ 4 * (n ^ 2 * dot w w) := by gcongr
    _ ≤ 4 * dot (Nm (sR θ ζ) w) (Nm (sR θ ζ) w) := by gcongr

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **The lower side for any factors `n_m` and potentials `τ_m`**: if `N(r) ≽ n_m` on `s(r)^⊥`
at scale `m + 1`, `0 ≤ τ_m ≤ 1` and `τ_m ≤ τ_{m+1} n_m² (1 − b_{m+1})²`, then
`τ_m P/ω ≼ G_k` at scale `m`. -/
theorem lower_inv_gen (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (nf τ : ℕ → ℝ) (hn : ∀ m, 0 ≤ nf m) (hτ0 : ∀ m, 0 ≤ τ m) (hτ1 : ∀ m, τ m ≤ 1)
    (hτs : ∀ m, τ m ≤ τ (m + 1) * nf m ^ 2 * (1 - bS (m + 1)) ^ 2)
    (hN : ∀ m (s w : Fin 4 → ℝ), (∀ ν, s ν ^ 2 ≤ bS (m + 1)) → dot s w = 0 →
      nf m * dot w w ≤ dot w (Nm s w))
    (k : ℕ) : ∀ (m : ℕ) (q : Q), (∀ ν, sQ (th q) ν ^ 2 ≤ bS m) → ∀ x : V,
      τ m * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ := by
  induction k with
  | zero =>
    intro m q _ x
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
    have h1 := hτ1 m
    have h0 := inner_P_nonneg th q x
    have hw := (inv_pos.mpr (hω q)).le
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw h0
    nlinarith
  | succ k ih =>
    intro m q hq x
    rw [Function.iterate_succ_apply', Mfam_inner]
    set G := (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) with hG
    set ζs := zstar fun ν => Real.sin (th q ν) ^ 2 with hζs
    set y := Matrix.toEuclideanLin (AtM (th q) ζs) x with hy
    have hnn : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
      intro ζ
      refine le_trans ?_ (ih 0 (rq q ζ) (scale_zero th (rq q ζ)) _)
      exact mul_nonneg (mul_nonneg (hτ0 0) (inv_pos.mpr (hω _)).le)
        (inner_P_nonneg th _ _)
    have hsingle : ⟪y, G (rq q ζs) y⟫ ≤ ∑ ζ : Fin 4 → Bool,
        ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
      Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hnn ζ)
        (Finset.mem_univ ζs)
    have hscale : ∀ ν, sR (th q) ζs ν ^ 2 ≤ bS (m + 1) := alias_scale (th q) m hq
    have hq' : ∀ ν, sQ (th (rq q ζs)) ν ^ 2 ≤ bS (m + 1) := by
      rw [hrq, sQ_thR]; exact hscale
    have hIH := ih (m + 1) (rq q ζs) hq' y
    rw [hy, alias_inner th rq hrq q ζs x] at hIH
    rw [← hy] at hIH
    have hA := one_alias_gen (th q) (WithLp.ofLp x) ζs hscale (hn m)
      (fun w hw => hN m _ w hscale hw)
    have hωr := omega_ratio th rq hrq q ζs hscale
    have hτ := hτs m
    rw [← inner_P th q x] at hA
    set b := bS (m + 1)
    set n2 := nf m ^ 2
    set U := ⟪x, Pfam th q x⟫
    set Y := dot (Atr (th q) ζs (WithLp.ofLp x))
      (proj (sR (th q) ζs) (Atr (th q) ζs (WithLp.ofLp x)))
    set wq := (omF th q)⁻¹
    set wr := (omF th (rq q ζs))⁻¹
    have hU : 0 ≤ U := inner_P_nonneg th q x
    have hb1 : 0 ≤ 1 - b := by linarith [bS_le_one (m + 1)]
    have hτ' : 0 ≤ τ (m + 1) := hτ0 _
    have hn2 : 0 ≤ n2 := sq_nonneg _
    have hwq : 0 ≤ wq := (inv_pos.mpr (hω q)).le
    have hwr : 0 ≤ wr := (inv_pos.mpr (hω _)).le
    have e1 : omF th q * wq = 1 := mul_inv_cancel₀ (hω q).ne'
    have e2 : omF th (rq q ζs) * wr = 1 := mul_inv_cancel₀ (hω _).ne'
    have key : 4 * (1 - b) * wq ≤ wr := by
      calc 4 * (1 - b) * wq = 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) := by
            rw [show 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) =
              4 * (1 - b) * wq * (omF th (rq q ζs) * wr) by ring, e2, mul_one]
        _ ≤ omF th q * (wq * wr) := mul_le_mul_of_nonneg_right hωr (mul_nonneg hwq hwr)
        _ = wr := by rw [← mul_assoc, e1, one_mul]
    have hc : 0 ≤ τ (m + 1) * n2 * (1 - b) := mul_nonneg (mul_nonneg hτ' hn2) hb1
    calc τ m * wq * U ≤ (τ (m + 1) * n2 * (1 - b) ^ 2) * wq * U :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hτ hwq) hU
      _ = (τ (m + 1) * n2 * (1 - b)) * ((1 - b) * wq) * U := by ring
      _ ≤ (τ (m + 1) * n2 * (1 - b)) * (wr / 4) * U := by
          apply mul_le_mul_of_nonneg_right _ hU
          apply mul_le_mul_of_nonneg_left _ hc
          linarith
      _ = (1 / 16) * (τ (m + 1) * wr * (4 * n2 * (1 - b) * U)) := by ring
      _ ≤ (1 / 16) * (τ (m + 1) * wr * Y) := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact mul_le_mul_of_nonneg_left hA (mul_nonneg hτ' hwr)
      _ ≤ (1 / 16) * ⟪y, G (rq q ζs) y⟫ := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact hIH
      _ ≤ _ := mul_le_mul_of_nonneg_left hsingle (by norm_num)

/-- The sharper factors: `n_0 = 11/48` (the lowest cell), `n_m = n(ξ_{m+1})` for `m ≥ 1`. -/
def nfS : ℕ → ℝ
  | 0 => 11 / 48
  | m + 1 => nlow (xiB (m + 1))

/-- The sharper `ν`: `ν'_0 = (11/48)² ν_1`, `ν'_m = ν_m` for `m ≥ 1`. -/
def nuS : ℕ → ℝ
  | 0 => (11 / 48) ^ 2 * nuT 1
  | m + 1 => nuT (m + 1)

def tauS (m : ℕ) : ℝ := (2 * Gam m / π) ^ 4 * nuS m

theorem nuS_bounds (m : ℕ) : 0 ≤ nuS m ∧ nuS m ≤ 1 := by
  match m with
  | 0 =>
    obtain ⟨h0, h1⟩ := nuT_bounds 1
    simp only [nuS]; constructor <;> nlinarith
  | k + 1 => simp only [nuS]; exact nuT_bounds (k + 1)

theorem nuS_step (m : ℕ) : nuS m ≤ nuS (m + 1) * nfS m ^ 2 := by
  match m with
  | 0 => show (11 / 48) ^ 2 * nuT 1 ≤ nuT 1 * (11 / 48) ^ 2; exact le_of_eq (by ring)
  | k + 1 =>
    show nuT (k + 1) ≤ nuT (k + 1 + 1) * nlow (xiB (k + 1)) ^ 2
    exact nuT_step (k + 1)

theorem tauS_step (m : ℕ) :
    tauS m ≤ tauS (m + 1) * nfS m ^ 2 * (1 - bS (m + 1)) ^ 2 := by
  unfold tauS
  rw [one_sub_bS, ← Gam_rec m]
  have hs := nuS_step m
  have h0 : 0 ≤ (2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4 := by positivity
  calc (2 * (Gam (m + 1) * kap m) / π) ^ 4 * nuS m
      = ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * nuS m := by ring
    _ ≤ ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * (nuS (m + 1) * nfS m ^ 2) :=
      mul_le_mul_of_nonneg_left hs h0
    _ = (2 * Gam (m + 1) / π) ^ 4 * nuS (m + 1) * nfS m ^ 2 * (kap m ^ 2) ^ 2 := by ring

theorem nfS_nonneg (m : ℕ) : 0 ≤ nfS m := by
  match m with
  | 0 => norm_num [nfS]
  | k + 1 => simp only [nfS]; exact nlow_xiB_nonneg (k + 1)

theorem nfS_form (m : ℕ) (s w : Fin 4 → ℝ) (hs : ∀ ν, s ν ^ 2 ≤ bS (m + 1))
    (hw : dot s w = 0) : nfS m * dot w w ≤ dot w (Nm s w) := by
  match m with
  | 0 =>
    have e : bS (0 + 1) = 1 / 2 := by
      rw [bS_succ]
      have : π / 2 ^ (0 + 1) = π / 2 := by norm_num
      rw [this, Real.cos_pi_div_two]; norm_num
    have e' : bS 1 = 1 / 2 := e
    simp only [nfS]
    exact Nm_cell_lower (fun ν => by unfold xs; linarith [hs ν]) hw
  | k + 1 =>
    simp only [nfS]
    have hb := bS_half_le (k + 1)
    exact Nm_lower (xiB_nonneg _) (by linarith [xiB_le (k + 1)])
      (fun ν => by unfold xs; linarith [hs ν]) hw

theorem tauS_zero_ge : (0.0034 : ℝ) ≤ tauS 0 := by
  unfold tauS
  rw [Gam_zero]
  have hν : nuS 0 = (11 / 48) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160)) := rfl
  have hν' : (0.02074 : ℝ) ≤ nuS 0 := by rw [hν]; norm_num [nlow, xi2]
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.8697 := by nlinarith
  have hπ2' : 0 < π ^ 2 := by positivity
  have hπ4 : π ^ 4 < 97.412 := by
    have : π ^ 4 = π ^ 2 * π ^ 2 := by ring
    rw [this]; nlinarith
  have e : (2 * 1 / π) ^ 4 = 16 / π ^ 4 := by rw [div_pow]; norm_num
  rw [e, div_mul_eq_mul_div, le_div_iff₀ (by positivity)]
  nlinarith

/-- **The sharper lower side**: `0.0034 · P/ω ≼ 𝓜^k(P/ω)` (`σ ≥ 0.0915` in the form
`(4/π²)σ²`). -/
theorem lower_side_sharp (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) :
    UniformBracket.Lw ((0.0034 : ℝ) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  have h := lower_inv_gen th rq hrq hω nfS tauS nfS_nonneg
    (fun m => mul_nonneg (pref_bounds m).1 (nuS_bounds m).1)
    (fun m => by
      unfold tauS
      obtain ⟨a0, a1⟩ := pref_bounds m
      obtain ⟨b0, b1⟩ := nuS_bounds m
      nlinarith)
    tauS_step nfS_form k 0 q (scale_zero th q) x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  have ha := tauS_zero_ge
  have hP := inner_P_nonneg th q x
  have hw := (inv_pos.mpr (hω q)).le
  calc (0.0034 : ℝ) * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫)
      ≤ tauS 0 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
        mul_le_mul_of_nonneg_right ha (mul_nonneg hw hP)
    _ = tauS 0 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
    _ ≤ _ := h

/-- **Theorem 1 with the sharper upper constant, no hypotheses**: on every momentum with
`ω > 0` and every stage, `(ω/745) P ≼ ¼ H_k ≼ 74 ω P`. -/
theorem bracket_Qpos_sharp :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 74 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  obtain ⟨H, hH, hHP, _⟩ := bracket_Qpos_free
  refine ⟨H, hH, hHP, fun k q x => ?_⟩
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hlow := lower_side_sharp Subtype.val rqPos hrq hω
  obtain ⟨lo, up⟩ := UniformBracket.bracket (Mfam (Subtype.val : Qpos → _) rqPos)
    (Mfam_orderPreserving _ _) (Pfam_symm _) (Pfam_idem _) hω
    (by norm_num : (0 : ℝ) ≤ 429 / 512) (by norm_num : (429 / 512 : ℝ) < 1)
    (by norm_num : (0 : ℝ) ≤ 15 / 8) (by norm_num : (0 : ℝ) < 0.0034)
    (Mfam_P_le _ _ hrq) (Mfam_B_le _ _ hrq hω) (UniformBracket.Lw.refl _) hlow
    (iterate_symm _ _) hH hHP k q x
  have hPx : 0 ≤ ⟪x, Pfam Subtype.val q x⟫ := inner_P_nonneg _ q x
  have c1 := UniformBracket.const_lower (hω q) (omF_le _ q) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl
  have c2 : omF Subtype.val q / (4 * 0.0034) ≤ 74 * omF Subtype.val q := by
    have := hω q
    rw [div_le_iff₀ (by norm_num)]; nlinarith
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo,
    le_trans up (mul_le_mul_of_nonneg_right c2 hPx)⟩

end OneStepCell

end

-- ===== new part : Near16b.part.lean =====
/-!
# 3c (second form): as `Near16`, with the sharper bound of `N` on `s^⊥` 

`nfun` is now `max 0 (max (nB s (Bmid s)) (1 − ½|s|²𝔅max))`, where for any `b`
`nB s b = 1 − ½ max_μ (b|s|² + 2Σ_{ν≠μ} (𝔅_{μν} − b)₊ s_ν²)` (`N_form_gen`: split `𝔅 = b + (𝔅 − b)`,
Lagrange for the `b` part, `L² ≤ 2(s_ν²w_μ² + s_μ²w_ν²)` for the rest). With `b` the midpoint of the
entries of `𝔅` the slope of the bound at the corner is halved in the direction (−1,−1,1,1).

For `k ≥ 1`, `G_{k} = 𝓜 G_{k−1}` is the sum over the sixteen aliases
`r_ζ` of `(1/16) A_ζ G_{k−1}(r_ζ) A_ζᵀ`. Each `G_{k−1}(r)` is bounded below **pointwise** (not by
the box index of `r`, which jumps at the corner) by `g(r) P/ω` with `g` the chain of `d` steps to
the nearest alias, ending in the box potential `tauS d` of :

* `nfun s = max 0 (1 − ½|s|² 𝔅max(s))` bounds `N(s)` on `s^⊥` (from `IminusN_pairs` and Lagrange;
  it equals `11/48` at the corner): `N_pt`.
* `cm2 s = 1 − max_ν s_ν²` bounds `|C S u|² ≥ cm2 |u|²`.
* `gpt m d θ`: `gpt m 0 = tauS m`, `gpt m (d+1) θ = ¼ nfun(s')² cm2(s') (ω(θ)/ω(θ')) gpt (m+1) d θ'`
  at the nearest alias `θ'`. `chain_lower`: `gpt m d (θ q) · P/ω ≼ G_k(q)` for every `k`, `q` in box `m`.
* `near_lower`: `⟨x, G_{k+1}(q) x⟩ ≥ Σ_ν Dn d θ ν · u_ν²`, `u = P(q)x`,
  `Dn d θ ν = ¼ Σ_ζ gpt 0 d(θ_ζ) ω(θ_ζ)⁻¹ nfun(s(r_ζ))² cos²(r_{ζ,ν}/2)`.
* `lower_side_near`: if the scalar inequality `c ≤ ω(θ) Dn d θ ν` holds for every `θ` with
  `ω(θ) > 0` and every `ν` (the hypothesis `hS`, a statement about explicit real functions), then
  `c · P/ω ≼ G_k` for every stage `k`.
-/

noncomputable section

namespace NearAliasB

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. Pointwise factors -/

/-- The largest entry of `𝔅 = 1 − E` (off the diagonal). -/
def Bm (s : Fin 4 → ℝ) : ℝ :=
  max (max (max (1 - Ef (xs s 2) (xs s 3)) (1 - Ef (xs s 1) (xs s 3)))
      (max (1 - Ef (xs s 1) (xs s 2)) (1 - Ef (xs s 0) (xs s 3))))
    (max (1 - Ef (xs s 0) (xs s 2)) (1 - Ef (xs s 0) (xs s 1)))

/-- The smallest entry of `𝔅`. -/
def Bmn (s : Fin 4 → ℝ) : ℝ :=
  min (min (min (1 - Ef (xs s 2) (xs s 3)) (1 - Ef (xs s 1) (xs s 3)))
      (min (1 - Ef (xs s 1) (xs s 2)) (1 - Ef (xs s 0) (xs s 3))))
    (min (1 - Ef (xs s 0) (xs s 2)) (1 - Ef (xs s 0) (xs s 1)))

def Bmid (s : Fin 4 → ℝ) : ℝ := (Bmn s + Bm s) / 2

/-- `(𝔅_{μν} − b)₊`. -/
def ep (s : Fin 4 → ℝ) (b : ℝ) (μ ν : Fin 4) : ℝ := max (1 - EF (xs s) μ ν - b) 0

def rowB (s : Fin 4 → ℝ) (b : ℝ) (μ : Fin 4) : ℝ :=
  b * dot s s + 2 * ∑ ν ∈ univ.erase μ, ep s b μ ν * s ν ^ 2

def nB (s : Fin 4 → ℝ) (b : ℝ) : ℝ :=
  1 - (1 / 2) * max (max (rowB s b 0) (rowB s b 1)) (max (rowB s b 2) (rowB s b 3))

/-- The pointwise lower bound of `N(s)` on `s^⊥`. -/
def nfun (s : Fin 4 → ℝ) : ℝ := max 0 (max (nB s (Bmid s)) (1 - (1 / 2) * dot s s * Bm s))

/-- `1 − max_ν s_ν²`. -/
def cm2 (s : Fin 4 → ℝ) : ℝ := 1 - max (max (s 0 ^ 2) (s 1 ^ 2)) (max (s 2 ^ 2) (s 3 ^ 2))

/-- `ω(θ) = Σ 4 sin²(2θ_ν)`. -/
def omT (θ : Fin 4 → ℝ) : ℝ := ∑ ν, 4 * sQ θ ν ^ 2

/-- The nearest alias. -/
def zs (θ : Fin 4 → ℝ) : Fin 4 → Bool := zstar fun ν => Real.sin (θ ν) ^ 2

def low (θ : Fin 4 → ℝ) : Fin 4 → ℝ := thR θ (zs θ)

/-- The chain of `d` nearest-alias steps from box `m`, ending in `tauS (m + d)`. -/
def gpt : ℕ → ℕ → (Fin 4 → ℝ) → ℝ
  | m, 0, _ => tauS m
  | m, d + 1, θ => (1 / 4) * nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) *
      (omT θ / omT (low θ)) * gpt (m + 1) d (low θ)

theorem Bm_ge (s : Fin 4 → ℝ) :
    1 - Ef (xs s 2) (xs s 3) ≤ Bm s ∧ 1 - Ef (xs s 1) (xs s 3) ≤ Bm s ∧
    1 - Ef (xs s 1) (xs s 2) ≤ Bm s ∧ 1 - Ef (xs s 0) (xs s 3) ≤ Bm s ∧
    1 - Ef (xs s 0) (xs s 2) ≤ Bm s ∧ 1 - Ef (xs s 0) (xs s 1) ≤ Bm s := by
  unfold Bm
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
  simp only [le_max_iff, le_refl, true_or, or_true]

theorem form_old (s w : Fin 4 → ℝ) (hw : dot s w = 0) :
    (1 - (1 / 2) * dot s s * Bm s) * dot w w ≤ dot w (Nm s w) := by
  have hI := IminusN_pairs s w
  have hL := lagrange4 s w
  rw [hw] at hL
  obtain ⟨b1, b2, b3, b4, b5, b6⟩ := Bm_ge s
  have q1 := mul_le_mul_of_nonneg_right b1 (sq_nonneg (s 1 * w 0 - s 0 * w 1))
  have q2 := mul_le_mul_of_nonneg_right b2 (sq_nonneg (s 2 * w 0 - s 0 * w 2))
  have q3 := mul_le_mul_of_nonneg_right b3 (sq_nonneg (s 3 * w 0 - s 0 * w 3))
  have q4 := mul_le_mul_of_nonneg_right b4 (sq_nonneg (s 2 * w 1 - s 1 * w 2))
  have q5 := mul_le_mul_of_nonneg_right b5 (sq_nonneg (s 3 * w 1 - s 1 * w 3))
  have q6 := mul_le_mul_of_nonneg_right b6 (sq_nonneg (s 3 * w 2 - s 2 * w 3))
  have hsum : dot w w - dot w (Nm s w) ≤ (1 / 2) * (Bm s * (dot s s * dot w w)) := by
    rw [hI]
    have : Bm s * (dot s s * dot w w) = Bm s * ((s 1 * w 0 - s 0 * w 1) ^ 2 +
        (s 2 * w 0 - s 0 * w 2) ^ 2 + (s 3 * w 0 - s 0 * w 3) ^ 2 +
        (s 2 * w 1 - s 1 * w 2) ^ 2 + (s 3 * w 1 - s 1 * w 3) ^ 2 +
        (s 3 * w 2 - s 2 * w 3) ^ 2) := by rw [hL]; ring
    rw [this]
    linarith
  nlinarith [hsum]

/-- One pair: `𝔅 L² ≤ b L² + 2 e₊ (s_ν² w_μ² + s_μ² w_ν²)` when `𝔅 ≤ b + e₊`, `e₊ ≥ 0`. -/
theorem pair_split {B b e sμ sν wμ wν : ℝ} (hB : B ≤ b + e) (he : 0 ≤ e) :
    B * (sν * wμ - sμ * wν) ^ 2 ≤
      b * (sν * wμ - sμ * wν) ^ 2 + e * (2 * (sν ^ 2 * wμ ^ 2 + sμ ^ 2 * wν ^ 2)) := by
  have hL2 : (sν * wμ - sμ * wν) ^ 2 ≤ 2 * (sν ^ 2 * wμ ^ 2 + sμ ^ 2 * wν ^ 2) := by
    nlinarith [sq_nonneg (sν * wμ + sμ * wν)]
  have h1 := mul_le_mul_of_nonneg_right hB (sq_nonneg (sν * wμ - sμ * wν))
  have h2 := mul_le_mul_of_nonneg_left hL2 he
  nlinarith

theorem ep_ge (s : Fin 4 → ℝ) (b : ℝ) (μ ν : Fin 4) : 1 - EF (xs s) μ ν ≤ b + ep s b μ ν := by
  have := le_max_left (1 - EF (xs s) μ ν - b) 0
  unfold ep; linarith

theorem ep_nonneg (s : Fin 4 → ℝ) (b : ℝ) (μ ν : Fin 4) : 0 ≤ ep s b μ ν := le_max_right _ _

/-- **`N(s) ≽ nB(s, b)` on `s^⊥` for every `b`.** -/
theorem N_form_gen (s w : Fin 4 → ℝ) (hw : dot s w = 0) (b : ℝ) :
    nB s b * dot w w ≤ dot w (Nm s w) := by
  have hI := IminusN_pairs s w
  have hL := lagrange4 s w
  rw [hw] at hL
  have p1 := pair_split (sμ := s 0) (sν := s 1) (wμ := w 0) (wν := w 1)
    (ep_ge s b 0 1) (ep_nonneg s b 0 1)
  have p2 := pair_split (sμ := s 0) (sν := s 2) (wμ := w 0) (wν := w 2)
    (ep_ge s b 0 2) (ep_nonneg s b 0 2)
  have p3 := pair_split (sμ := s 0) (sν := s 3) (wμ := w 0) (wν := w 3)
    (ep_ge s b 0 3) (ep_nonneg s b 0 3)
  have p4 := pair_split (sμ := s 1) (sν := s 2) (wμ := w 1) (wν := w 2)
    (ep_ge s b 1 2) (ep_nonneg s b 1 2)
  have p5 := pair_split (sμ := s 1) (sν := s 3) (wμ := w 1) (wν := w 3)
    (ep_ge s b 1 3) (ep_nonneg s b 1 3)
  have p6 := pair_split (sμ := s 2) (sν := s 3) (wμ := w 2) (wν := w 3)
    (ep_ge s b 2 3) (ep_nonneg s b 2 3)
  have f01 : EF (xs s) 0 1 = Ef (xs s 2) (xs s 3) := by simp [EF]
  have f02 : EF (xs s) 0 2 = Ef (xs s 1) (xs s 3) := by simp [EF]
  have f03 : EF (xs s) 0 3 = Ef (xs s 1) (xs s 2) := by simp [EF]
  have f12 : EF (xs s) 1 2 = Ef (xs s 0) (xs s 3) := by simp [EF]
  have f13 : EF (xs s) 1 3 = Ef (xs s 0) (xs s 2) := by simp [EF]
  have f23 : EF (xs s) 2 3 = Ef (xs s 0) (xs s 1) := by simp [EF]
  rw [f01] at p1; rw [f02] at p2; rw [f03] at p3; rw [f12] at p4; rw [f13] at p5; rw [f23] at p6
  -- the symmetric entries of `ep`
  have e10 : ep s b 1 0 = ep s b 0 1 := by simp [ep, EF]
  have e20 : ep s b 2 0 = ep s b 0 2 := by simp [ep, EF]
  have e30 : ep s b 3 0 = ep s b 0 3 := by simp [ep, EF]
  have e21 : ep s b 2 1 = ep s b 1 2 := by simp [ep, EF]
  have e31 : ep s b 3 1 = ep s b 1 3 := by simp [ep, EF]
  have e32 : ep s b 3 2 = ep s b 2 3 := by simp [ep, EF]
  set M := max (max (rowB s b 0) (rowB s b 1)) (max (rowB s b 2) (rowB s b 3)) with hM
  have r0 : rowB s b 0 ≤ M := le_trans (le_max_left _ _) (le_max_left _ _)
  have r1 : rowB s b 1 ≤ M := le_trans (le_max_right _ _) (le_max_left _ _)
  have r2 : rowB s b 2 ≤ M := le_trans (le_max_left _ _) (le_max_right _ _)
  have r3 : rowB s b 3 ≤ M := le_trans (le_max_right _ _) (le_max_right _ _)
  have R0 : rowB s b 0 = b * dot s s + 2 * (ep s b 0 1 * s 1 ^ 2 + ep s b 0 2 * s 2 ^ 2 +
      ep s b 0 3 * s 3 ^ 2) := by
    simp only [rowB, sum_erase4]; ring
  have R1 : rowB s b 1 = b * dot s s + 2 * (ep s b 0 1 * s 0 ^ 2 + ep s b 1 2 * s 2 ^ 2 +
      ep s b 1 3 * s 3 ^ 2) := by
    simp only [rowB, sum_erase4]; rw [e10]; ring
  have R2 : rowB s b 2 = b * dot s s + 2 * (ep s b 0 2 * s 0 ^ 2 + ep s b 1 2 * s 1 ^ 2 +
      ep s b 2 3 * s 3 ^ 2) := by
    simp only [rowB, sum_erase4]; rw [e20, e21]; ring
  have R3 : rowB s b 3 = b * dot s s + 2 * (ep s b 0 3 * s 0 ^ 2 + ep s b 1 3 * s 1 ^ 2 +
      ep s b 2 3 * s 2 ^ 2) := by
    simp only [rowB, sum_erase4]; rw [e30, e31, e32]; ring
  have m0 := mul_le_mul_of_nonneg_left r0 (sq_nonneg (w 0))
  have m1 := mul_le_mul_of_nonneg_left r1 (sq_nonneg (w 1))
  have m2 := mul_le_mul_of_nonneg_left r2 (sq_nonneg (w 2))
  have m3 := mul_le_mul_of_nonneg_left r3 (sq_nonneg (w 3))
  rw [R0] at m0; rw [R1] at m1; rw [R2] at m2; rw [R3] at m3
  have hww : dot w w = w 0 ^ 2 + w 1 ^ 2 + w 2 ^ 2 + w 3 ^ 2 := by
    unfold dot; simp only [Fin.sum_univ_four]; ring
  have hbL : b * ((s 1 * w 0 - s 0 * w 1) ^ 2 + (s 2 * w 0 - s 0 * w 2) ^ 2 +
      (s 3 * w 0 - s 0 * w 3) ^ 2 + (s 2 * w 1 - s 1 * w 2) ^ 2 + (s 3 * w 1 - s 1 * w 3) ^ 2 +
      (s 3 * w 2 - s 2 * w 3) ^ 2) = b * dot s s * (w 0 ^ 2 + w 1 ^ 2 + w 2 ^ 2 + w 3 ^ 2) := by
    rw [hL, hww]; ring
  have hsum : dot w w - dot w (Nm s w) ≤ (1 / 2) * (M * dot w w) := by
    rw [hI, hww]
    linarith [p1, p2, p3, p4, p5, p6, hbL, m0, m1, m2, m3]
  unfold nB
  rw [← hM]
  linarith [hsum]

/-- **`N(s) ≽ nfun(s)` on `s^⊥`**, as a norm bound. -/
theorem N_pt (s w : Fin 4 → ℝ) (hw : dot s w = 0) :
    nfun s ^ 2 * dot w w ≤ dot (Nm s w) (Nm s w) := by
  set n0 := max (nB s (Bmid s)) (1 - (1 / 2) * dot s s * Bm s) with hn0
  have hform : n0 * dot w w ≤ dot w (Nm s w) := by
    rcases le_total (nB s (Bmid s)) (1 - (1 / 2) * dot s s * Bm s) with h | h
    · rw [hn0, max_eq_right h]; exact form_old s w hw
    · rw [hn0, max_eq_left h]; exact N_form_gen s w hw _
  unfold nfun
  rw [← hn0]
  rcases le_total n0 0 with h | h
  · rw [max_eq_left h]
    simpa using dot_self_nonneg (Nm s w)
  · rw [max_eq_right h]
    exact sq_of_form h hform

theorem cm2_le (s : Fin 4 → ℝ) (ν : Fin 4) : cm2 s ≤ 1 - s ν ^ 2 := by
  unfold cm2
  have : s ν ^ 2 ≤ max (max (s 0 ^ 2) (s 1 ^ 2)) (max (s 2 ^ 2) (s 3 ^ 2)) := by
    fin_cases ν <;> simp [le_max_iff]
  linarith

theorem cm2_nonneg (θ : Fin 4 → ℝ) : 0 ≤ cm2 (sQ θ) := by
  unfold cm2 sQ
  have h0 := Real.sin_sq_le_one (2 * θ 0)
  have h1 := Real.sin_sq_le_one (2 * θ 1)
  have h2 := Real.sin_sq_le_one (2 * θ 2)
  have h3 := Real.sin_sq_le_one (2 * θ 3)
  have : max (max (Real.sin (2 * θ 0) ^ 2) (Real.sin (2 * θ 1) ^ 2))
      (max (Real.sin (2 * θ 2) ^ 2) (Real.sin (2 * θ 3) ^ 2)) ≤ 1 := by
    simp only [max_le_iff]; exact ⟨⟨h0, h1⟩, ⟨h2, h3⟩⟩
  linarith

theorem cm2_le_one (s : Fin 4 → ℝ) : cm2 s ≤ 1 := by
  have := cm2_le s 0; nlinarith [sq_nonneg (s 0)]

theorem Ef_le_half {y z : ℝ} (hy : 0 ≤ y) (hy1 : y ≤ 1 / 2) (hz : 0 ≤ z) (hz1 : z ≤ 1 / 2) :
    Ef y z ≤ 1 / 2 := by
  unfold Ef; nlinarith [mul_nonneg hy hz]

theorem Bmn_le (s : Fin 4 → ℝ) : Bmn s ≤ 1 - Ef (xs s 2) (xs s 3) := by
  unfold Bmn
  exact le_trans (min_le_left _ _) (le_trans (min_le_left _ _) (min_le_left _ _))

theorem nfun_le_one (θ : Fin 4 → ℝ) : nfun (sQ θ) ≤ 1 := by
  unfold nfun
  have hx : ∀ ν, 0 ≤ xs (sQ θ) ν ∧ xs (sQ θ) ν ≤ 1 / 2 := fun ν => by
    unfold xs sQ
    have := Real.sin_sq_le_one (2 * θ ν)
    constructor <;> nlinarith [sq_nonneg (Real.sin (2 * θ ν))]
  have hE := Ef_le_half (hx 2).1 (hx 2).2 (hx 3).1 (hx 3).2
  have hB : 0 ≤ Bm (sQ θ) := by
    have := (Bm_ge (sQ θ)).1
    linarith
  have hmn : 0 ≤ Bmn (sQ θ) := by
    unfold Bmn
    have e1 := Ef_le_half (hx 2).1 (hx 2).2 (hx 3).1 (hx 3).2
    have e2 := Ef_le_half (hx 1).1 (hx 1).2 (hx 3).1 (hx 3).2
    have e3 := Ef_le_half (hx 1).1 (hx 1).2 (hx 2).1 (hx 2).2
    have e4 := Ef_le_half (hx 0).1 (hx 0).2 (hx 3).1 (hx 3).2
    have e5 := Ef_le_half (hx 0).1 (hx 0).2 (hx 2).1 (hx 2).2
    have e6 := Ef_le_half (hx 0).1 (hx 0).2 (hx 1).1 (hx 1).2
    simp only [le_min_iff]
    refine ⟨⟨⟨?_, ?_⟩, ?_, ?_⟩, ?_, ?_⟩ <;> linarith
  have hmid : 0 ≤ Bmid (sQ θ) := by unfold Bmid; linarith
  have hd := dot_self_nonneg (sQ θ)
  have : 0 ≤ (1 / 2) * dot (sQ θ) (sQ θ) * Bm (sQ θ) := by positivity
  have hr0 : 0 ≤ rowB (sQ θ) (Bmid (sQ θ)) 0 := by
    unfold rowB
    have : 0 ≤ ∑ ν ∈ univ.erase (0 : Fin 4), ep (sQ θ) (Bmid (sQ θ)) 0 ν * sQ θ ν ^ 2 :=
      Finset.sum_nonneg fun ν _ => mul_nonneg (ep_nonneg _ _ _ _) (sq_nonneg _)
    have : 0 ≤ Bmid (sQ θ) * dot (sQ θ) (sQ θ) := mul_nonneg hmid hd
    linarith
  have hnB : nB (sQ θ) (Bmid (sQ θ)) ≤ 1 := by
    unfold nB
    have : rowB (sQ θ) (Bmid (sQ θ)) 0 ≤ max (max (rowB (sQ θ) (Bmid (sQ θ)) 0)
        (rowB (sQ θ) (Bmid (sQ θ)) 1)) (max (rowB (sQ θ) (Bmid (sQ θ)) 2)
        (rowB (sQ θ) (Bmid (sQ θ)) 3)) := le_trans (le_max_left _ _) (le_max_left _ _)
    linarith
  simp only [max_le_iff]
  refine ⟨by norm_num, hnB, by linarith⟩

theorem nfun_nonneg (s : Fin 4 → ℝ) : 0 ≤ nfun s := le_max_left _ _

theorem omT_nonneg (θ : Fin 4 → ℝ) : 0 ≤ omT θ := by
  unfold omT; exact Finset.sum_nonneg fun ν _ => by positivity

/-- `ω(q) ≤ 4 ω(r_ζ)`. -/
theorem omT_alias_le (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : omT θ ≤ 4 * omT (thR θ ζ) := by
  unfold omT
  rw [sQ_thR, Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  rw [sQ_sq_alias θ ζ ν, cR_sq]
  nlinarith [sq_nonneg (sR θ ζ ν), sq_nonneg (sR θ ζ ν ^ 2)]

theorem sQ_low (θ : Fin 4 → ℝ) : sQ (low θ) = sR θ (zs θ) := sQ_thR θ (zs θ)

theorem tauS_bounds (m : ℕ) : 0 ≤ tauS m ∧ tauS m ≤ 1 := by
  unfold tauS
  obtain ⟨a0, a1⟩ := pref_bounds m
  obtain ⟨b0, b1⟩ := nuS_bounds m
  constructor <;> nlinarith

theorem gpt_bounds : ∀ (d m : ℕ) (θ : Fin 4 → ℝ), 0 ≤ gpt m d θ ∧ gpt m d θ ≤ 1 := by
  intro d
  induction d with
  | zero => intro m θ; exact tauS_bounds m
  | succ d ih =>
    intro m θ
    obtain ⟨g0, g1⟩ := ih (m + 1) (low θ)
    have hn0 := nfun_nonneg (sQ (low θ))
    have hn1 := nfun_le_one (low θ)
    have hc0 := cm2_nonneg (low θ)
    have hc1 := cm2_le_one (sQ (low θ))
    have hω0 := omT_nonneg θ
    have hω0' := omT_nonneg (low θ)
    have hr0 : 0 ≤ omT θ / omT (low θ) := div_nonneg hω0 hω0'
    have hr1 : omT θ / omT (low θ) ≤ 4 := by
      rcases eq_or_lt_of_le hω0' with h | h
      · rw [← h, div_zero]; norm_num
      · rw [div_le_iff₀ h]; have := omT_alias_le θ (zs θ); unfold low; linarith
    have hn2 : nfun (sQ (low θ)) ^ 2 ≤ 1 := by nlinarith
    show 0 ≤ (1 / 4) * nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) *
      (omT θ / omT (low θ)) * gpt (m + 1) d (low θ) ∧ (1 / 4) * nfun (sQ (low θ)) ^ 2 *
      cm2 (sQ (low θ)) * (omT θ / omT (low θ)) * gpt (m + 1) d (low θ) ≤ 1
    have hA : 0 ≤ nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) := mul_nonneg (sq_nonneg _) hc0
    have hA1 : nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) ≤ 1 := by nlinarith
    have hB1 : nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) * (omT θ / omT (low θ)) ≤ 4 := by
      nlinarith
    have hB0 : 0 ≤ nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) * (omT θ / omT (low θ)) :=
      mul_nonneg hA hr0
    constructor
    · have := mul_nonneg hB0 g0; nlinarith
    · nlinarith [mul_le_mul hB1 g1 g0 (by norm_num : (0 : ℝ) ≤ 4)]

/-! ## 2. One alias as a lower bound, pointwise -/

/-- `|C S u|² ≥ cm2 |u|²` and `N` on top: `4 nfun² cm2 |u|² ≤ ⟨A_ζᵀx, P(r_ζ) A_ζᵀx⟩`. -/
theorem one_alias_pt (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    4 * nfun (sR θ ζ) ^ 2 * cm2 (sR θ ζ) * dot (proj (sQ θ) x) (proj (sQ θ) x) ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hN := N_pt (sR θ ζ) w hw
  have hww : cm2 (sR θ ζ) * dot u u ≤ dot w w := by
    unfold dot
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have e : w ν * w ν = cR θ ζ ν ^ 2 * (u ν * u ν) := by
      rw [hw_def]
      have := sg_sq ζ ν
      calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
          = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * (u ν * u ν) := by ring
        _ = _ := by rw [this, mul_one]
    rw [e, cR_sq]
    exact mul_le_mul_of_nonneg_right (cm2_le _ ν) (mul_self_nonneg _)
  have hn2 : 0 ≤ nfun (sR θ ζ) ^ 2 := sq_nonneg _
  calc 4 * nfun (sR θ ζ) ^ 2 * cm2 (sR θ ζ) * dot u u
      = 4 * (nfun (sR θ ζ) ^ 2 * (cm2 (sR θ ζ) * dot u u)) := by ring
    _ ≤ 4 * (nfun (sR θ ζ) ^ 2 * dot w w) := by gcongr
    _ ≤ 4 * dot (Nm (sR θ ζ) w) (Nm (sR θ ζ) w) := by gcongr

/-- The same with the exact `|C S u|² = Σ cos² u²` (for the top step). -/
theorem one_alias_diag (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    4 * nfun (sR θ ζ) ^ 2 * ∑ ν, cR θ ζ ν ^ 2 * (proj (sQ θ) x ν) ^ 2 ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hN := N_pt (sR θ ζ) w hw
  have hww : dot w w = ∑ ν, cR θ ζ ν ^ 2 * u ν ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [hw_def]
    have := sg_sq ζ ν
    calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
        = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * u ν ^ 2 := by ring
      _ = _ := by rw [this, mul_one]
  rw [← hww]
  linarith

/-! ## 3. The chain -/

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The stage covariances `G_k = 𝓜^k(P/ω)`. -/
def Gs (k : ℕ) : Q → V →ₗ[ℝ] V :=
  (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)

theorem omF_eq_omT (q : Q) : omF th q = omT (th q) := rfl

/-- The box potential (`lower_inv_gen` with `nfS`, `tauS`) at any box `m`. -/
theorem box_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k m : ℕ) (q : Q) (hq : ∀ ν, sQ (th q) ν ^ 2 ≤ bS m) (x : V) :
    tauS m * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤ ⟪x, Gs th rq k q x⟫ :=
  lower_inv_gen th rq hrq hω nfS tauS nfS_nonneg
    (fun m => mul_nonneg (pref_bounds m).1 (nuS_bounds m).1)
    (fun m => by
      unfold tauS
      obtain ⟨a0, a1⟩ := pref_bounds m
      obtain ⟨b0, b1⟩ := nuS_bounds m
      nlinarith)
    tauS_step nfS_form k m q hq x

theorem Gs_nonneg (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) (q : Q) (x : V) : 0 ≤ ⟪x, Gs th rq k q x⟫ :=
  le_trans (mul_nonneg (mul_nonneg (tauS_bounds 0).1 (inv_pos.mpr (hω q)).le)
    (inner_P_nonneg th q x)) (box_lower th rq hrq hω k 0 q (scale_zero th q) x)

/-- **The pointwise chain**: `gpt m d (θ q) · P/ω ≼ G_k(q)` for every `k`, `q` in box `m`. -/
theorem chain_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    ∀ (d m : ℕ) (q : Q), (∀ ν, sQ (th q) ν ^ 2 ≤ bS m) → ∀ (k : ℕ) (x : V),
      gpt m d (th q) * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤ ⟪x, Gs th rq k q x⟫ := by
  intro d
  induction d with
  | zero => intro m q hq k x; exact box_lower th rq hrq hω k m q hq x
  | succ d ih =>
    intro m q hq k x
    cases k with
    | zero =>
      simp only [Gs, Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
      have h1 := (gpt_bounds (d + 1) m (th q)).2
      have h0 := inner_P_nonneg th q x
      have hw := (inv_pos.mpr (hω q)).le
      have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw h0
      nlinarith
    | succ k =>
      show _ ≤ ⟪x, (⇑(Mfam th rq))^[k + 1] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫
      rw [Function.iterate_succ_apply', Mfam_inner]
      set G := (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) with hG
      set ζs := zs (th q) with hζs
      set y := Matrix.toEuclideanLin (AtM (th q) ζs) x with hy
      have hnn : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
        fun ζ => Gs_nonneg th rq hrq hω k (rq q ζ) _
      have hsingle : ⟪y, G (rq q ζs) y⟫ ≤ ∑ ζ : Fin 4 → Bool,
          ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
            G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
        Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
            G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hnn ζ)
          (Finset.mem_univ ζs)
      have hscale : ∀ ν, sR (th q) ζs ν ^ 2 ≤ bS (m + 1) := alias_scale (th q) m hq
      have hq' : ∀ ν, sQ (th (rq q ζs)) ν ^ 2 ≤ bS (m + 1) := by
        rw [hrq, sQ_thR]; exact hscale
      have hIH := ih (m + 1) (rq q ζs) hq' k y
      rw [hy, alias_inner th rq hrq q ζs x] at hIH
      rw [← hy] at hIH
      have hA := one_alias_pt (th q) (WithLp.ofLp x) ζs
      rw [← inner_P th q x] at hA
      have hthr : th (rq q ζs) = low (th q) := hrq q ζs
      rw [hthr] at hIH
      have homr : omF th (rq q ζs) = omT (low (th q)) := by
        rw [omF_eq_omT, hthr]
      rw [homr] at hIH
      -- abbreviations
      set n2 := nfun (sR (th q) ζs) ^ 2
      set cc := cm2 (sR (th q) ζs)
      set U := ⟪x, Pfam th q x⟫
      set Y := dot (Atr (th q) ζs (WithLp.ofLp x))
        (proj (sR (th q) ζs) (Atr (th q) ζs (WithLp.ofLp x)))
      set g' := gpt (m + 1) d (low (th q))
      set ωq := omF th q
      set ωr := omT (low (th q))
      have hgdef : gpt m (d + 1) (th q) = (1 / 4) * n2 * cc * (ωq / ωr) * g' := by
        show (1 / 4) * nfun (sQ (low (th q))) ^ 2 * cm2 (sQ (low (th q))) *
          (omT (th q) / omT (low (th q))) * gpt (m + 1) d (low (th q)) = _
        rw [sQ_low]
        rfl
      have hU : 0 ≤ U := inner_P_nonneg th q x
      have hg0 : 0 ≤ g' := (gpt_bounds d (m + 1) _).1
      have hωq : 0 < ωq := hω q
      have hωr0 : 0 ≤ ωr := omT_nonneg _
      have e1 : ωq / ωr * ωq⁻¹ = ωr⁻¹ := by
        rw [div_mul_eq_mul_div, mul_inv_cancel₀ hωq.ne', one_div]
      have hcc : 0 ≤ cc := by
        have := cm2_nonneg (low (th q)); rw [sQ_low] at this; exact this
      have hwr : 0 ≤ ωr⁻¹ := inv_nonneg.mpr hωr0
      rw [hgdef]
      calc (1 / 4) * n2 * cc * (ωq / ωr) * g' * ωq⁻¹ * U
          = (1 / 16) * (g' * ωr⁻¹ * (4 * n2 * cc * U)) := by
            rw [show (1 / 4) * n2 * cc * (ωq / ωr) * g' * ωq⁻¹ * U =
              (1 / 4) * n2 * cc * (ωq / ωr * ωq⁻¹) * g' * U by ring, e1]
            ring
        _ ≤ (1 / 16) * (g' * ωr⁻¹ * Y) := by
            apply mul_le_mul_of_nonneg_left _ (by norm_num)
            exact mul_le_mul_of_nonneg_left hA (mul_nonneg hg0 hwr)
        _ ≤ (1 / 16) * ⟪y, G (rq q ζs) y⟫ := by
            apply mul_le_mul_of_nonneg_left _ (by norm_num)
            exact hIH
        _ ≤ _ := mul_le_mul_of_nonneg_left hsingle (by norm_num)

/-! ## 4. The sixteen aliases at the top -/

/-- The diagonal weights `D_ν = ¼ Σ_ζ gpt 0 d (θ_ζ) ω(θ_ζ)⁻¹ nfun(s(r_ζ))² cos²(r_{ζ,ν}/2)`. -/
def Dn (d : ℕ) (θ : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  (1 / 4) * ∑ ζ : Fin 4 → Bool,
    gpt 0 d (thR θ ζ) * (omT (thR θ ζ))⁻¹ * nfun (sR θ ζ) ^ 2 * cR θ ζ ν ^ 2

/-- **The sixteen nearest aliases**: `⟨x, G_{k+1}(q) x⟩ ≥ Σ_ν D_ν u_ν²`, `u = P(q)x`. -/
theorem near_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (d k : ℕ) (q : Q) (x : V) :
    ∑ ν, Dn d (th q) ν * (proj (sQ (th q)) (WithLp.ofLp x) ν) ^ 2 ≤
      ⟪x, Gs th rq (k + 1) q x⟫ := by
  show _ ≤ ⟪x, (⇑(Mfam th rq))^[k + 1] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫
  rw [Function.iterate_succ_apply', Mfam_inner]
  set u := proj (sQ (th q)) (WithLp.ofLp x)
  have hterm : ∀ ζ : Fin 4 → Bool,
      gpt 0 d (thR (th q) ζ) * (omT (thR (th q) ζ))⁻¹ * nfun (sR (th q) ζ) ^ 2 *
          (4 * ∑ ν, cR (th q) ζ ν ^ 2 * u ν ^ 2) ≤
        ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) (rq q ζ)
            (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
    intro ζ
    have hIH := chain_lower th rq hrq hω d 0 (rq q ζ) (scale_zero th (rq q ζ)) k
      (Matrix.toEuclideanLin (AtM (th q) ζ) x)
    rw [alias_inner th rq hrq q ζ x, hrq] at hIH
    have hom : omF th (rq q ζ) = omT (thR (th q) ζ) := by rw [omF_eq_omT, hrq]
    rw [hom] at hIH
    have hA := one_alias_diag (th q) (WithLp.ofLp x) ζ
    have hg0 := (gpt_bounds d 0 (thR (th q) ζ)).1
    have hwr : 0 ≤ (omT (thR (th q) ζ))⁻¹ := inv_nonneg.mpr (omT_nonneg _)
    calc gpt 0 d (thR (th q) ζ) * (omT (thR (th q) ζ))⁻¹ * nfun (sR (th q) ζ) ^ 2 *
          (4 * ∑ ν, cR (th q) ζ ν ^ 2 * u ν ^ 2)
        = gpt 0 d (thR (th q) ζ) * (omT (thR (th q) ζ))⁻¹ *
          (4 * nfun (sR (th q) ζ) ^ 2 * ∑ ν, cR (th q) ζ ν ^ 2 * u ν ^ 2) := by ring
      _ ≤ gpt 0 d (thR (th q) ζ) * (omT (thR (th q) ζ))⁻¹ *
          dot (Atr (th q) ζ (WithLp.ofLp x))
            (proj (sR (th q) ζ) (Atr (th q) ζ (WithLp.ofLp x))) :=
          mul_le_mul_of_nonneg_left hA (mul_nonneg hg0 hwr)
      _ ≤ _ := hIH
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (Finset.univ : Finset (Fin 4 → Bool))) =>
    hterm ζ
  have e : ∑ ν, Dn d (th q) ν * u ν ^ 2 = (1 / 16) * ∑ ζ : Fin 4 → Bool,
      gpt 0 d (thR (th q) ζ) * (omT (thR (th q) ζ))⁻¹ * nfun (sR (th q) ζ) ^ 2 *
        (4 * ∑ ν, cR (th q) ζ ν ^ 2 * u ν ^ 2) := by
    unfold Dn
    simp only [Finset.mul_sum, Finset.sum_mul]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun ζ _ => Finset.sum_congr rfl fun ν _ => ?_
    ring
  rw [e]
  exact mul_le_mul_of_nonneg_left hsum (by norm_num)

/-- Pointwise form: at a momentum `q` with `c ≤ ω D_ν` for every `ν`, `c P/ω ≼ G_k` at `q`. -/
theorem near_point (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {c : ℝ} (hc1 : c ≤ 1) (d : ℕ) (q : Q)
    (hS : ∀ ν, c ≤ omT (th q) * Dn d (th q) ν) (k : ℕ) (x : V) :
    c * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) ≤
      ⟪x, ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) q x⟫ := by
  have hP := inner_P_nonneg th q x
  have hw := (inv_pos.mpr (hω q)).le
  cases k with
  | zero =>
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw hP
    nlinarith
  | succ k =>
    have h := near_lower th rq hrq hω d k q x
    set u := proj (sQ (th q)) (WithLp.ofLp x)
    have hωq := hω q
    have hD : ∀ ν, c * (omF th q)⁻¹ ≤ Dn d (th q) ν := fun ν => by
      have := hS ν
      rw [← omF_eq_omT] at this
      rw [← div_eq_mul_inv, div_le_iff₀ hωq]
      linarith
    have hU : ⟪x, Pfam th q x⟫ = ∑ ν, u ν ^ 2 := by
      rw [inner_P]; unfold dot; exact Finset.sum_congr rfl fun ν _ => by ring
    calc c * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) = ∑ ν, c * (omF th q)⁻¹ * u ν ^ 2 := by
          rw [hU, Finset.mul_sum, Finset.mul_sum]
          exact Finset.sum_congr rfl fun ν _ => by ring
      _ ≤ ∑ ν, Dn d (th q) ν * u ν ^ 2 :=
          Finset.sum_le_sum fun ν _ => mul_le_mul_of_nonneg_right (hD ν) (sq_nonneg _)
      _ ≤ _ := h

/-- **The lower side from the sixteen aliases**: if the scalar inequality
`c ≤ ω(θ) D_ν(θ)` holds at every `θ` with `ω(θ) > 0` and every `ν`, then `c P/ω ≼ G_k`. -/
theorem lower_side_near (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {c : ℝ} (hc1 : c ≤ 1) (d : ℕ)
    (hS : ∀ θ : Fin 4 → ℝ, 0 < omT θ → ∀ ν, c ≤ omT θ * Dn d θ ν) (k : ℕ) :
    UniformBracket.Lw (c • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact near_point th rq hrq hω hc1 d q (hS (th q) (hω q)) k x

/-- **The lower side with the region split**: at each `θ` either the single chain
(`gpt 0 d₁`, the nearest alias only; region I) or the sixteen aliases (`Dn d₂`) give `c`. -/
theorem lower_side_split (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {c : ℝ} (hc1 : c ≤ 1) (d₁ d₂ : ℕ)
    (hS : ∀ θ : Fin 4 → ℝ, 0 < omT θ → c ≤ gpt 0 d₁ θ ∨ ∀ ν, c ≤ omT θ * Dn d₂ θ ν) (k : ℕ) :
    UniformBracket.Lw (c • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rcases hS (th q) (hω q) with h1 | h2
  · have hc := chain_lower th rq hrq hω d₁ 0 q (scale_zero th q) k x
    have hP := inner_P_nonneg th q x
    have hw := (inv_pos.mpr (hω q)).le
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw hP
    calc c * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫)
        ≤ gpt 0 d₁ (th q) * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
          mul_le_mul_of_nonneg_right h1 this
      _ = gpt 0 d₁ (th q) * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
      _ ≤ _ := hc
  · exact near_point th rq hrq hω hc1 d₂ q h2 k x

/-! ## 5. The bracket with the constant `c` (conditional on `hS`) -/

/-- **Theorem 1 with the lower constant `c`**: under `hS`, on every momentum with `ω > 0`,
`(ω/745) P ≼ ¼ H_k ≼ ω/(4c) P`. -/
theorem bracket_Qpos_near {c : ℝ} (hc0 : 0 < c) (hc1 : c ≤ 1) (d : ℕ)
    (hS : ∀ θ : Fin 4 → ℝ, 0 < omT θ → ∀ ν, c ≤ omT θ * Dn d θ ν) :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ omF Subtype.val q / (4 * c) * ⟪x, Pfam Subtype.val q x⟫ := by
  obtain ⟨H, hH, hHP, _⟩ := bracket_Qpos_free
  refine ⟨H, hH, hHP, fun k q x => ?_⟩
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hlow := lower_side_near Subtype.val rqPos hrq hω hc1 d hS
  obtain ⟨lo, up⟩ := UniformBracket.bracket (Mfam (Subtype.val : Qpos → _) rqPos)
    (Mfam_orderPreserving _ _) (Pfam_symm _) (Pfam_idem _) hω
    (by norm_num : (0 : ℝ) ≤ 429 / 512) (by norm_num : (429 / 512 : ℝ) < 1)
    (by norm_num : (0 : ℝ) ≤ 15 / 8) hc0
    (Mfam_P_le _ _ hrq) (Mfam_B_le _ _ hrq hω) (UniformBracket.Lw.refl _) hlow
    (iterate_symm _ _) hH hHP k q x
  have hPx : 0 ≤ ⟪x, Pfam Subtype.val q x⟫ := inner_P_nonneg _ q x
  have c1 := UniformBracket.const_lower (hω q) (omF_le _ q) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo, up⟩

end NearAliasB

end

-- ===== new part : XCoord.part.lean =====
/-!
# 3c: the x-coordinates of the sixteen aliases (fable-01 §0, §2.2) 

With `σ_ν = sin²θ_ν` and the alias `ζ`, `x_ν = ½ sR² = xa σ_ν (ζ_ν) ∈ {σ/2, (1−σ)/2}`: the sixteen
aliases are the vertices of the box `Π_ν {a_ν, ½ − a_ν}` (`a = σ/2`), centred at `¼·1`.
* `omT_vertex`: `ω(θ) = Σ_ν 32 x_ν (1 − 2x_ν)` at **every** vertex (the invariant `32 Y`).
* `omT_alias`: `ω(θ_ζ) = 8 Σ_ν x_ν`; `cR_sq_x`: `cos²(r_ν/2) = 1 − 2x_ν`.
* `vertex_sum_prod`: `Σ_ζ Π_ν f_ν(ζ_ν) = Π_ν (f_ν(false) + f_ν(true))` (a polynomial in `x` sums
  over the vertices coordinate by coordinate).
* `pk_*`: `a^k + (½ − a)^k` as polynomials in `y = a(1 − 2a)` for `k ≤ 4`.
-/

noncomputable section

namespace XCoord

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
open scoped Real

theorem x_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sR θ ζ ν ^ 2 / 2 = xa (Real.sin (θ ν) ^ 2) (ζ ν) := by
  have := xs_alias θ ζ ν; unfold xs at this; exact this

theorem omT_vertex (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    NearAliasB.omT θ = ∑ ν, 32 * (sR θ ζ ν ^ 2 / 2) * (1 - 2 * (sR θ ζ ν ^ 2 / 2)) := by
  unfold NearAliasB.omT
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [sQ_sq_alias θ ζ ν, cR_sq]; ring

theorem omT_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    NearAliasB.omT (thR θ ζ) = 8 * ∑ ν, sR θ ζ ν ^ 2 / 2 := by
  unfold NearAliasB.omT
  rw [sQ_thR, Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by ring

theorem cR_sq_x (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    cR θ ζ ν ^ 2 = 1 - 2 * (sR θ ζ ν ^ 2 / 2) := by rw [cR_sq]; ring

/-- The two values of `x` at a coordinate add to `½`. -/
theorem xa_pair (σ : ℝ) : xa σ false + xa σ true = 1 / 2 := by simp [xa]; ring

theorem xa_prod (σ : ℝ) : xa σ false * xa σ true = (σ * (1 - σ)) / 4 := by simp [xa]; ring

/-- **The vertex sum of a product is the product of the pair sums.** -/
theorem vertex_sum_prod (f : Fin 4 → Bool → ℝ) :
    ∑ ζ : Fin 4 → Bool, ∏ ν, f ν (ζ ν) = ∏ ν, (f ν false + f ν true) := by
  have h := Finset.sum_prod_piFinset (Finset.univ : Finset Bool) f
  rw [Fintype.piFinset_univ] at h
  rw [h]
  refine Finset.prod_congr rfl fun ν _ => ?_
  simp [Fintype.sum_bool, add_comm]

/-- `a + b = ½`, `y = 2ab`: the power sums `p_k = a^k + b^k` in `y`. -/
theorem pk_1 (a : ℝ) : a + (1 / 2 - a) = 1 / 2 := by ring
theorem pk_2 (a : ℝ) : a ^ 2 + (1 / 2 - a) ^ 2 = 1 / 4 - a * (1 - 2 * a) := by ring
theorem pk_3 (a : ℝ) : a ^ 3 + (1 / 2 - a) ^ 3 = 1 / 8 - 3 / 4 * (a * (1 - 2 * a)) := by ring
theorem pk_4 (a : ℝ) :
    a ^ 4 + (1 / 2 - a) ^ 4 = (1 / 4 - a * (1 - 2 * a)) ^ 2 - (a * (1 - 2 * a)) ^ 2 / 2 := by ring

/-- `Y = Σ a(1 − 2a)` is the same at every vertex: `x(1 − 2x)` is invariant under `x ↦ ½ − x`. -/
theorem y_invariant (a : ℝ) : (1 / 2 - a) * (1 - 2 * (1 / 2 - a)) = a * (1 - 2 * a) := by ring

end XCoord

end

-- ===== new part : Reduce.part.lean =====
/-!
# hS: the chain telescopes, and the step below the alias is polynomial 

* `xt_rel`: with `t = xs(s(low θ))` (the coordinates one step down), `xs(s(θ)) = 4t(1 − 2t)` and
  `0 ≤ t ≤ ¼` — no square root.
* `gpt_step_lb`: if the coordinates of `low θ` are `≤ μ`, one step of the chain is at least
  `nd(μ)²(1 − 2μ)²` times the next (`omT θ ≥ 4(1 − 2μ) omT(low θ)`).
* `deep_lb`: the chain of `j` steps under a sequence of coordinate bounds `μ i` with
  `μ i ≤ 4 μ(i+1)(1 − 2μ(i+1))` is at least `Lam μ j k` (a product of explicit factors).
* `alias_W`: `gpt 0 (j+1) θ' / ω(θ') = ¼ nfun(s')² cm2(s') gpt 1 j (low θ') / ω(low θ')`.
-/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

/-- The coordinates one step down (at the nearest alias). -/
def tx (θ : Fin 4 → ℝ) (ν : Fin 4) : ℝ := xs (sQ (low θ)) ν

/-- `nd μ = 1 − 4μ(1 − Ef(μ, μ))`: the old bound of `N` at the diagonal point `μ·1`. -/
def nd (μ : ℝ) : ℝ := 1 - 4 * μ * (1 - Ef μ μ)

theorem sQ_sq_sigma (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * Real.sin (θ ν) ^ 2 * (1 - Real.sin (θ ν) ^ 2) := by
  unfold sQ
  rw [Real.sin_two_mul]
  have := Real.sin_sq_add_cos_sq (θ ν)
  have hc : Real.cos (θ ν) ^ 2 = 1 - Real.sin (θ ν) ^ 2 := by linarith
  calc (2 * Real.sin (θ ν) * Real.cos (θ ν)) ^ 2
      = 4 * Real.sin (θ ν) ^ 2 * Real.cos (θ ν) ^ 2 := by ring
    _ = _ := by rw [hc]

/-- **One step down is polynomial**: `x = 4t(1 − 2t)`, `0 ≤ t ≤ ¼`. -/
theorem xt_rel (θ : Fin 4 → ℝ) (ν : Fin 4) :
    xs (sQ θ) ν = 4 * tx θ ν * (1 - 2 * tx θ ν) ∧ 0 ≤ tx θ ν ∧ tx θ ν ≤ 1 / 4 := by
  unfold tx
  rw [sQ_low]
  have hx := xs_alias θ (zs θ) ν
  rw [hx]
  have hσ := sigma_mem (θ ν)
  have hq := sQ_sq_sigma θ ν
  set σ := Real.sin (θ ν) ^ 2 with hσdef
  unfold xs
  rw [hq]
  by_cases hs : 1 / 2 < σ
  · have hz : zs θ ν = true := by
      simp only [zs, zstar, decide_eq_true_eq]; exact hs
    rw [hz]; simp only [xa]
    refine ⟨by ring, by linarith, by linarith⟩
  · have hz : zs θ ν = false := by
      simp only [zs, zstar, decide_eq_false_iff_not]; exact hs
    rw [hz]; simp only [xa]
    have hs' : σ ≤ 1 / 2 := le_of_not_gt hs
    refine ⟨by ring, by linarith, by linarith⟩

theorem omT_xs (θ : Fin 4 → ℝ) : omT θ = ∑ ν, 8 * xs (sQ θ) ν := by
  unfold omT xs
  exact Finset.sum_congr rfl fun ν _ => by ring

theorem omT_low (θ : Fin 4 → ℝ) : omT (low θ) = ∑ ν, 8 * tx θ ν := omT_xs (low θ)

theorem xs_nonneg (s : Fin 4 → ℝ) (ν : Fin 4) : 0 ≤ xs s ν := by unfold xs; positivity

/-- `t ↦ 4t(1 − 2t)` is increasing on `[0, ¼]`. -/
theorem quad_mono {a b : ℝ} (ha : 0 ≤ a) (hb : b ≤ 1 / 4) (ha1 : a ≤ 1 / 4) (hb0 : 0 ≤ b)
    (h : 4 * a * (1 - 2 * a) ≤ 4 * b * (1 - 2 * b)) : a ≤ b := by
  by_contra hc
  push_neg at hc
  have : 0 < 4 * (a - b) * (1 - 2 * (a + b)) := by
    apply mul_pos (by linarith)
    nlinarith
  nlinarith

/-- One pair of the old bound at points `≤ μ`. -/
theorem pair_le {p q r s μ : ℝ} (hp : 0 ≤ p) (hq : 0 ≤ q) (hr : 0 ≤ r) (hs : 0 ≤ s)
    (hp1 : p ≤ μ) (hq1 : q ≤ μ) (hr1 : r ≤ μ) (hs1 : s ≤ μ) (hμ : μ ≤ 1 / 4) :
    (p + q + r + s) * (1 - Ef r s) ≤ 4 * μ * (1 - Ef μ μ) := by
  unfold Ef
  have hE : 0 ≤ 1 - ((r + s) / 2 - r * s / 3) := by nlinarith [mul_nonneg hr hs]
  have h1 : (p + q + r + s) * (1 - ((r + s) / 2 - r * s / 3)) ≤
      (2 * μ + r + s) * (1 - ((r + s) / 2 - r * s / 3)) := by
    apply mul_le_mul_of_nonneg_right _ hE; linarith
  have h2 : (2 * μ + r + s) * (1 - ((r + s) / 2 - r * s / 3)) ≤
      (3 * μ + s) * (1 - ((μ + s) / 2 - μ * s / 3)) := by
    nlinarith [mul_nonneg (sub_nonneg.2 hr1) hs, mul_nonneg (sub_nonneg.2 hr1) (sub_nonneg.2 hs1),
      mul_nonneg (mul_nonneg (sub_nonneg.2 hr1) hs) hs, mul_nonneg (sub_nonneg.2 hr1) hr,
      mul_nonneg (mul_nonneg (sub_nonneg.2 hr1) hs) hr]
  have h3 : (3 * μ + s) * (1 - ((μ + s) / 2 - μ * s / 3)) ≤
      4 * μ * (1 - ((μ + μ) / 2 - μ * μ / 3)) := by
    nlinarith [mul_nonneg (sub_nonneg.2 hs1) hs, mul_nonneg (sub_nonneg.2 hs1) hp,
      mul_nonneg (mul_nonneg (sub_nonneg.2 hs1) hs) hp, mul_nonneg (sub_nonneg.2 hs1) (le_trans hp hp1)]
  linarith

theorem dot_xs (s : Fin 4 → ℝ) : (1 / 2) * dot s s = ∑ ν, xs s ν := by
  unfold dot xs; rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun ν _ => by ring

/-- `q ≤ nfun s` as soon as `q` is below all six branches of the old bound. -/
theorem nfun_ge_of {s : Fin 4 → ℝ} {q : ℝ}
    (h : ∀ K : ℝ, K = 1 - Ef (xs s 2) (xs s 3) ∨ K = 1 - Ef (xs s 1) (xs s 3) ∨
      K = 1 - Ef (xs s 1) (xs s 2) ∨ K = 1 - Ef (xs s 0) (xs s 3) ∨
      K = 1 - Ef (xs s 0) (xs s 2) ∨ K = 1 - Ef (xs s 0) (xs s 1) →
      q ≤ 1 - (∑ ν, xs s ν) * K) : q ≤ nfun s := by
  have hB : q ≤ 1 - (1 / 2) * dot s s * Bm s := by
    rw [dot_xs]
    unfold Bm
    rcases le_total (max (max (1 - Ef (xs s 2) (xs s 3)) (1 - Ef (xs s 1) (xs s 3)))
        (max (1 - Ef (xs s 1) (xs s 2)) (1 - Ef (xs s 0) (xs s 3))))
        (max (1 - Ef (xs s 0) (xs s 2)) (1 - Ef (xs s 0) (xs s 1))) with h1 | h1
    · rw [max_eq_right h1]
      rcases le_total (1 - Ef (xs s 0) (xs s 2)) (1 - Ef (xs s 0) (xs s 1)) with h2 | h2
      · rw [max_eq_right h2]; exact h _ (by tauto)
      · rw [max_eq_left h2]; exact h _ (by tauto)
    · rw [max_eq_left h1]
      rcases le_total (max (1 - Ef (xs s 2) (xs s 3)) (1 - Ef (xs s 1) (xs s 3)))
          (max (1 - Ef (xs s 1) (xs s 2)) (1 - Ef (xs s 0) (xs s 3))) with h2 | h2
      · rw [max_eq_right h2]
        rcases le_total (1 - Ef (xs s 1) (xs s 2)) (1 - Ef (xs s 0) (xs s 3)) with h3 | h3
        · rw [max_eq_right h3]; exact h _ (by tauto)
        · rw [max_eq_left h3]; exact h _ (by tauto)
      · rw [max_eq_left h2]
        rcases le_total (1 - Ef (xs s 2) (xs s 3)) (1 - Ef (xs s 1) (xs s 3)) with h3 | h3
        · rw [max_eq_right h3]; exact h _ (by tauto)
        · rw [max_eq_left h3]; exact h _ (by tauto)
  unfold nfun
  exact le_trans hB (le_trans (le_max_right _ _) (le_max_right _ _))

theorem nfun_ge_nd {s : Fin 4 → ℝ} {μ : ℝ} (hx : ∀ ν, xs s ν ≤ μ) (hμ : μ ≤ 1 / 4) :
    nd μ ≤ nfun s := by
  have h0 := xs_nonneg s
  apply nfun_ge_of
  intro K hK
  have hsum : ∑ ν, xs s ν = xs s 0 + xs s 1 + xs s 2 + xs s 3 := Fin.sum_univ_four _
  rw [hsum]
  unfold nd
  rcases hK with hK | hK | hK | hK | hK | hK <;> rw [hK]
  · have := pair_le (h0 0) (h0 1) (h0 2) (h0 3) (hx 0) (hx 1) (hx 2) (hx 3) hμ; linarith
  · have := pair_le (h0 0) (h0 2) (h0 1) (h0 3) (hx 0) (hx 2) (hx 1) (hx 3) hμ; linarith
  · have := pair_le (h0 0) (h0 3) (h0 1) (h0 2) (hx 0) (hx 3) (hx 1) (hx 2) hμ; linarith
  · have := pair_le (h0 1) (h0 2) (h0 0) (h0 3) (hx 1) (hx 2) (hx 0) (hx 3) hμ; linarith
  · have := pair_le (h0 1) (h0 3) (h0 0) (h0 2) (hx 1) (hx 3) (hx 0) (hx 2) hμ; linarith
  · have := pair_le (h0 2) (h0 3) (h0 0) (h0 1) (hx 2) (hx 3) (hx 0) (hx 1) hμ; linarith

theorem cm2_eq (s : Fin 4 → ℝ) :
    cm2 s = 1 - 2 * max (max (xs s 0) (xs s 1)) (max (xs s 2) (xs s 3)) := by
  unfold cm2 xs
  have e : ∀ a b : ℝ, max (a / 2) (b / 2) = max a b / 2 := fun a b => by
    rcases le_total a b with h | h
    · rw [max_eq_right h, max_eq_right (by linarith)]
    · rw [max_eq_left h, max_eq_left (by linarith)]
  rw [e, e, e]; ring

theorem cm2_ge {s : Fin 4 → ℝ} {μ : ℝ} (hx : ∀ ν, xs s ν ≤ μ) : 1 - 2 * μ ≤ cm2 s := by
  rw [cm2_eq]
  have : max (max (xs s 0) (xs s 1)) (max (xs s 2) (xs s 3)) ≤ μ := by
    simp only [max_le_iff]; exact ⟨⟨hx 0, hx 1⟩, hx 2, hx 3⟩
  linarith

theorem omT_low_pos {θ : Fin 4 → ℝ} (hω : 0 < omT θ) : 0 < omT (low θ) := by
  rw [omT_low]
  rw [omT_xs] at hω
  have : ∑ ν, 8 * xs (sQ θ) ν ≤ 4 * ∑ ν, 8 * tx θ ν := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    obtain ⟨e, h0, h1⟩ := xt_rel θ ν
    rw [e]; nlinarith
  linarith

theorem omT_ratio {θ : Fin 4 → ℝ} {μ : ℝ} (ht : ∀ ν, tx θ ν ≤ μ) :
    4 * (1 - 2 * μ) * omT (low θ) ≤ omT θ := by
  rw [omT_low, omT_xs, Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  obtain ⟨e, h0, h1⟩ := xt_rel θ ν
  rw [e]
  nlinarith [mul_nonneg h0 (sub_nonneg.2 (ht ν))]

theorem gpt_succ (k j : ℕ) (θ : Fin 4 → ℝ) :
    gpt k (j + 1) θ = (1 / 4) * nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) *
      (omT θ / omT (low θ)) * gpt (k + 1) j (low θ) := rfl

/-- **One step of the chain from below.** -/
theorem gpt_step_lb (k j : ℕ) {θ : Fin 4 → ℝ} {μ : ℝ} (hω : 0 < omT θ)
    (ht : ∀ ν, tx θ ν ≤ μ) (hμ : μ ≤ 1 / 4) (hnd : 0 ≤ nd μ) :
    nd μ ^ 2 * (1 - 2 * μ) ^ 2 * gpt (k + 1) j (low θ) ≤ gpt k (j + 1) θ := by
  rw [gpt_succ]
  have hn := nfun_ge_nd (s := sQ (low θ)) (fun ν => ht ν) hμ
  have hc := cm2_ge (s := sQ (low θ)) (fun ν => ht ν)
  have hr := omT_ratio ht
  have hl := omT_low_pos hω
  have hg := (gpt_bounds j (k + 1) (low θ)).1
  have hμ0 : 0 ≤ 1 - 2 * μ := by linarith
  have hq : 4 * (1 - 2 * μ) ≤ omT θ / omT (low θ) := by rw [le_div_iff₀ hl]; linarith
  have hn2 : nd μ ^ 2 ≤ nfun (sQ (low θ)) ^ 2 := by gcongr
  have hA : nd μ ^ 2 * (1 - 2 * μ) ≤ nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) :=
    mul_le_mul hn2 hc hμ0 (sq_nonneg _)
  have hB : nd μ ^ 2 * (1 - 2 * μ) * (4 * (1 - 2 * μ)) ≤
      nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) * (omT θ / omT (low θ)) :=
    mul_le_mul hA hq (by positivity) (le_trans (by positivity) hA)
  calc nd μ ^ 2 * (1 - 2 * μ) ^ 2 * gpt (k + 1) j (low θ)
      = (1 / 4) * (nd μ ^ 2 * (1 - 2 * μ) * (4 * (1 - 2 * μ))) * gpt (k + 1) j (low θ) := by ring
    _ ≤ (1 / 4) * (nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) * (omT θ / omT (low θ))) *
        gpt (k + 1) j (low θ) := by gcongr
    _ = _ := by ring

/-- The product of the deep factors under the coordinate bounds `μ 0, μ 1, …`. -/
def Lam : (ℕ → ℝ) → ℕ → ℕ → ℝ
  | _, 0, k => tauS k
  | μ, j + 1, k => nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2 * Lam (fun i => μ (i + 1)) j (k + 1)

/-- The coordinates two steps down are bounded through `4t(1 − 2t)`. -/
theorem tx_low_le {θ : Fin 4 → ℝ} {μ μ' : ℝ} (ht : ∀ ν, tx θ ν ≤ μ) (hμ' : 0 ≤ μ')
    (hμ'1 : μ' ≤ 1 / 4) (hrec : μ ≤ 4 * μ' * (1 - 2 * μ')) (ν : Fin 4) : tx (low θ) ν ≤ μ' := by
  obtain ⟨e, h0, h1⟩ := xt_rel (low θ) ν
  have : xs (sQ (low θ)) ν = tx θ ν := rfl
  rw [this] at e
  exact quad_mono h0 hμ'1 h1 hμ' (by rw [← e]; linarith [ht ν])

/-- **The deep chain from below.** -/
theorem deep_lb : ∀ (j : ℕ) (μ : ℕ → ℝ) (k : ℕ) (θ : Fin 4 → ℝ),
    (∀ i, 0 ≤ μ i ∧ μ i ≤ 1 / 4 ∧ 0 ≤ nd (μ i)) →
    (∀ i, μ i ≤ 4 * μ (i + 1) * (1 - 2 * μ (i + 1))) →
    0 < omT θ → (∀ ν, tx θ ν ≤ μ 0) → Lam μ j k ≤ gpt k j θ := by
  intro j
  induction j with
  | zero => intro μ k θ _ _ _ _; exact le_refl _
  | succ j ih =>
    intro μ k θ hμ hrec hω ht
    have hstep := gpt_step_lb k j hω ht (hμ 0).2.1 (hμ 0).2.2
    have hIH := ih (fun i => μ (i + 1)) (k + 1) (low θ) (fun i => hμ (i + 1))
      (fun i => hrec (i + 1)) (omT_low_pos hω)
      (tx_low_le ht (hμ 1).1 (hμ 1).2.1 (hrec 0))
    have hf : 0 ≤ nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2 := by positivity
    show nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2 * Lam (fun i => μ (i + 1)) j (k + 1) ≤ _
    exact le_trans (mul_le_mul_of_nonneg_left hIH hf) hstep

/-- **At an alias**: `gpt 0 (j+1) θ' / ω(θ') = ¼ nfun(s')² cm2(s') gpt 1 j (low θ') / ω(low θ')`. -/
theorem alias_W (j : ℕ) {θ : Fin 4 → ℝ} (hω : 0 < omT θ) :
    gpt 0 (j + 1) θ * (omT θ)⁻¹ = (1 / 4) * nfun (sQ (low θ)) ^ 2 * cm2 (sQ (low θ)) *
      gpt 1 j (low θ) * (omT (low θ))⁻¹ := by
  rw [gpt_succ]
  field_simp

end HsChain

end

-- ===== new part : Vertex.part.lean =====
/-!
# hS: the sixteen-vertex form of `ω·D_ν`, the factor at the alias, region I, and `tauS` 

* `omDn_eq`: `ω(θ)·D_ν = Σ_ζ (ω/32)·nfun(x_ζ)²(1 − 2x_{ζ,ν})·nfun(t_ζ)² cm2(t_ζ) gpt 1 j (low θ_ζ)/(4T_ζ)`.
* `nfun_t_lb`: for coordinates in `[0, ¼]` below `m`, `1 − T + (11/24)T(T − 2m) ≤ nfun`.
* `K_lb`: the factor at the alias from below by `ι²(1 − 2m)·Lam μ j 1/(4T)`.
* `tauS_two_ge`, `tauS_four_ge`, `tauS_five_ge`; `regionI_lb`.
-/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

theorem omT_alias_pos {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (ζ : Fin 4 → Bool) :
    0 < omT (thR θ ζ) := by
  rw [XCoord.omT_alias]
  rw [XCoord.omT_vertex θ ζ] at hω
  have : ∑ ν, 32 * (sR θ ζ ν ^ 2 / 2) * (1 - 2 * (sR θ ζ ν ^ 2 / 2)) ≤
      4 * (8 * ∑ ν, sR θ ζ ν ^ 2 / 2) := by
    rw [Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have h0 : 0 ≤ sR θ ζ ν ^ 2 := sq_nonneg _
    nlinarith [mul_nonneg h0 h0]
  linarith

/-- **The sixteen vertices.** -/
theorem omDn_eq (j : ℕ) {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (ν : Fin 4) :
    omT θ * Dn (j + 1) θ ν = ∑ ζ : Fin 4 → Bool, (omT θ / 32) *
      (nfun (sR θ ζ) ^ 2 * (1 - 2 * xs (sR θ ζ) ν) *
        (nfun (sQ (low (thR θ ζ))) ^ 2 * cm2 (sQ (low (thR θ ζ))) * gpt 1 j (low (thR θ ζ)) /
          (4 * ∑ μ, tx (thR θ ζ) μ))) := by
  unfold Dn
  rw [← mul_assoc, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  have hp := omT_alias_pos hω ζ
  have hl := omT_low_pos hp
  rw [omT_low] at hl
  have hT : 0 < ∑ μ, tx (thR θ ζ) μ := by
    rw [← Finset.mul_sum] at hl; linarith
  have e1 : gpt 0 (j + 1) (thR θ ζ) * (omT (thR θ ζ))⁻¹ * nfun (sR θ ζ) ^ 2 * cR θ ζ ν ^ 2 =
      (gpt 0 (j + 1) (thR θ ζ) * (omT (thR θ ζ))⁻¹) * nfun (sR θ ζ) ^ 2 * cR θ ζ ν ^ 2 := by ring
  rw [e1, alias_W j hp, omT_low, XCoord.cR_sq_x]
  have e2 : ∑ μ, 8 * tx (thR θ ζ) μ = 8 * ∑ μ, tx (thR θ ζ) μ := by rw [Finset.mul_sum]
  rw [e2]
  unfold xs
  field_simp
  ring

/-- `Ef a b ≥ (11/24)(a + b)` on `[0, ¼]²`. -/
theorem Ef_lin {a b : ℝ} (ha : 0 ≤ a) (hb : 0 ≤ b) (ha1 : a ≤ 1 / 4) (hb1 : b ≤ 1 / 4) :
    (11 / 24) * (a + b) ≤ Ef a b := by
  unfold Ef
  nlinarith [mul_nonneg ha (sub_nonneg.2 hb1), mul_nonneg hb (sub_nonneg.2 ha1)]

/-- **`nfun` one step down**: `1 − T + (11/24)T(T − 2m) ≤ nfun s` for coordinates in `[0, ¼]`,
all `≤ m`. -/
theorem nfun_t_lb {s : Fin 4 → ℝ} {m : ℝ} (h0 : ∀ ν, 0 ≤ xs s ν) (h1 : ∀ ν, xs s ν ≤ 1 / 4)
    (hm : ∀ ν, xs s ν ≤ m) :
    1 - (∑ ν, xs s ν) + (11 / 24) * (∑ ν, xs s ν) * ((∑ ν, xs s ν) - 2 * m) ≤ nfun s := by
  apply nfun_ge_of
  intro K hK
  have hsum : ∑ ν, xs s ν = xs s 0 + xs s 1 + xs s 2 + xs s 3 := Fin.sum_univ_four _
  rw [hsum]
  have hT : 0 ≤ xs s 0 + xs s 1 + xs s 2 + xs s 3 := by linarith [h0 0, h0 1, h0 2, h0 3]
  set T := xs s 0 + xs s 1 + xs s 2 + xs s 3
  have key : ∀ a b c d : ℝ, 0 ≤ a → 0 ≤ b → a ≤ 1 / 4 → b ≤ 1 / 4 → c ≤ m → d ≤ m →
      a + b + c + d = T → 1 - T + (11 / 24) * T * (T - 2 * m) ≤ 1 - T * (1 - Ef a b) := by
    intro a b c d ha hb ha1 hb1 hc hd he
    have hE := Ef_lin ha hb ha1 hb1
    have : (11 / 24) * (T - 2 * m) ≤ Ef a b := by linarith
    nlinarith [mul_le_mul_of_nonneg_left this hT]
  rcases hK with hK | hK | hK | hK | hK | hK <;> rw [hK]
  · exact key _ _ (xs s 0) (xs s 1) (h0 2) (h0 3) (h1 2) (h1 3) (hm 0) (hm 1) (by ring)
  · exact key _ _ (xs s 0) (xs s 2) (h0 1) (h0 3) (h1 1) (h1 3) (hm 0) (hm 2) (by ring)
  · exact key _ _ (xs s 0) (xs s 3) (h0 1) (h0 2) (h1 1) (h1 2) (hm 0) (hm 3) (by ring)
  · exact key _ _ (xs s 1) (xs s 2) (h0 0) (h0 3) (h1 0) (h1 3) (hm 1) (hm 2) (by ring)
  · exact key _ _ (xs s 1) (xs s 3) (h0 0) (h0 2) (h1 0) (h1 2) (hm 1) (hm 3) (by ring)
  · exact key _ _ (xs s 2) (xs s 3) (h0 0) (h0 1) (h1 0) (h1 1) (hm 2) (hm 3) (by ring)

theorem Lam_nonneg : ∀ (j : ℕ) (μ : ℕ → ℝ) (k : ℕ), 0 ≤ Lam μ j k
  | 0, _, k => (tauS_bounds k).1
  | j + 1, μ, k => mul_nonneg (by positivity) (Lam_nonneg j _ (k + 1))

/-- **The factor at an alias from below.** `θ'` is the alias, `m` bounds its coordinates one step
down, `μ` bounds the coordinates further down. -/
theorem K_lb (j : ℕ) {θ' : Fin 4 → ℝ} (hω : 0 < omT θ') {m : ℝ} (hm : ∀ ν, tx θ' ν ≤ m)
    (μ : ℕ → ℝ) (hμ : ∀ i, 0 ≤ μ i ∧ μ i ≤ 1 / 4 ∧ 0 ≤ nd (μ i))
    (hrec : ∀ i, μ i ≤ 4 * μ (i + 1) * (1 - 2 * μ (i + 1))) (hm0 : m ≤ 4 * μ 0 * (1 - 2 * μ 0))
    (hι : 0 ≤ 1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m)) :
    (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m)) ^ 2 *
        (1 - 2 * m) * Lam μ j 1 / (4 * ∑ ν, tx θ' ν) ≤
      nfun (sQ (low θ')) ^ 2 * cm2 (sQ (low θ')) * gpt 1 j (low θ') / (4 * ∑ ν, tx θ' ν) := by
  have hl := omT_low_pos hω
  have ht0 : ∀ ν, 0 ≤ tx θ' ν := fun ν => (xt_rel θ' ν).2.1
  have ht1 : ∀ ν, tx θ' ν ≤ 1 / 4 := fun ν => (xt_rel θ' ν).2.2
  have hn := nfun_t_lb (s := sQ (low θ')) ht0 ht1 hm
  have hc := cm2_ge (s := sQ (low θ')) hm
  have hd := deep_lb j μ 1 (low θ') hμ hrec hl
    (tx_low_le hm (hμ 0).1 (hμ 0).2.1 hm0)
  have hT : 0 ≤ 4 * ∑ ν, tx θ' ν := by
    have := Finset.sum_nonneg fun ν (_ : ν ∈ (univ : Finset (Fin 4))) => ht0 ν
    linarith
  have hm1 : 0 ≤ 1 - 2 * m := by nlinarith [sq_nonneg (μ 0 - 1 / 4)]
  have hL0 : 0 ≤ Lam μ j 1 := Lam_nonneg j μ 1
  apply div_le_div_of_nonneg_right _ hT
  have hn2 : (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m)) ^ 2 ≤
      nfun (sQ (low θ')) ^ 2 := by gcongr; exact hn
  have hg0 : 0 ≤ gpt 1 j (low θ') := (gpt_bounds j 1 _).1
  calc _ = (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m)) ^ 2 *
        ((1 - 2 * m) * Lam μ j 1) := by ring
    _ ≤ nfun (sQ (low θ')) ^ 2 * (cm2 (sQ (low θ')) * gpt 1 j (low θ')) := by
        apply mul_le_mul hn2 (mul_le_mul hc hd hL0 (le_trans hm1 hc)) (by positivity) (sq_nonneg _)
    _ = _ := by ring

/-! ## `tauS` from below and region I -/

theorem pref_ge (m : ℕ) : (1 - (π / 2 ^ (m + 1)) ^ 2 / 6) ^ 4 ≤ (2 * Gam m / π) ^ 4 := by
  set a := π / 2 ^ (m + 1) with ha_def
  have ha : 0 < a := ang_pos m
  have hle : a ≤ π / 2 := ang_le m
  have hs := Real.sin_gt_sub_cube ha
  have e : 2 * Gam m / π = Real.sin a / a := by
    unfold Gam
    rw [ha_def, pow_succ]
    field_simp
  rw [e]
  have h1 : 1 - a ^ 2 / 6 ≤ Real.sin a / a := by
    rw [le_div_iff₀ ha]; nlinarith
  have h0 : 0 ≤ 1 - a ^ 2 / 6 := by
    have := Real.pi_lt_d2
    nlinarith
  exact pow_le_pow_left₀ h0 h1 4

theorem tauS_ge (m : ℕ) : (1 - (π / 2 ^ (m + 1)) ^ 2 / 6) ^ 4 * nuS m ≤ tauS m := by
  unfold tauS
  exact mul_le_mul_of_nonneg_right (pref_ge m) (nuS_bounds m).1

theorem tauS_ge_of {m : ℕ} {A : ℝ} (hA : (π / 2 ^ (m + 1)) ^ 2 ≤ A) (hA6 : A ≤ 6) :
    (1 - A / 6) ^ 4 * nuS m ≤ tauS m := by
  have h := tauS_ge m
  have h0 : 0 ≤ 1 - A / 6 := by linarith
  have h1 : 1 - A / 6 ≤ 1 - (π / 2 ^ (m + 1)) ^ 2 / 6 := by linarith
  have := pow_le_pow_left₀ h0 h1 4
  exact le_trans (mul_le_mul_of_nonneg_right this (nuS_bounds m).1) h

theorem ang_sq_le (m : ℕ) : (π / 2 ^ (m + 1)) ^ 2 ≤ (63 / 20) ^ 2 / (4 ^ (m + 1)) := by
  have hπ := Real.pi_lt_d2
  have hπ0 := Real.pi_pos
  rw [div_pow, show ((2 : ℝ) ^ (m + 1)) ^ 2 = 4 ^ (m + 1) by rw [← pow_mul, mul_comm, pow_mul]; norm_num]
  apply div_le_div_of_nonneg_right _ (by positivity)
  nlinarith

theorem tauS_two_ge : (7 / 10 : ℝ) ≤ tauS 2 := by
  have h := tauS_ge_of (ang_sq_le 2) (by norm_num)
  have hn : nuS 2 = 1 - 33 / 10 / (2 ^ 2) ^ 2 := rfl
  rw [hn] at h
  norm_num at h ⊢
  linarith

theorem tauS_four_ge : (98 / 100 : ℝ) ≤ tauS 4 := by
  have h := tauS_ge_of (ang_sq_le 4) (by norm_num)
  have hn : nuS 4 = 1 - 33 / 10 / (2 ^ 4) ^ 2 := rfl
  rw [hn] at h
  norm_num at h ⊢
  linarith

theorem tauS_five_ge : (995 / 1000 : ℝ) ≤ tauS 5 := by
  have h := tauS_ge_of (ang_sq_le 5) (by norm_num)
  have hn : nuS 5 = 1 - 33 / 10 / (2 ^ 5) ^ 2 := rfl
  rw [hn] at h
  norm_num at h ⊢
  linarith

/-- The sequence `b, 1/50, ¼, ¼, …` of coordinate bounds for region I. -/
def muI (b : ℝ) : ℕ → ℝ
  | 0 => b
  | 1 => 1 / 50
  | _ + 2 => 1 / 4

theorem muI_ok {b : ℝ} (hb0 : 0 ≤ b) (hb : b ≤ 19 / 250) :
    (∀ i, 0 ≤ muI b i ∧ muI b i ≤ 1 / 4 ∧ 0 ≤ nd (muI b i)) ∧
    (∀ i, muI b i ≤ 4 * muI b (i + 1) * (1 - 2 * muI b (i + 1))) := by
  constructor
  · intro i
    match i with
    | 0 =>
      simp only [muI, nd, Ef]
      refine ⟨hb0, by linarith, by nlinarith [mul_nonneg hb0 hb0]⟩
    | 1 => simp only [muI, nd, Ef]; norm_num
    | k + 2 => simp only [muI, nd, Ef]; norm_num
  · intro i
    match i with
    | 0 => simp only [muI]; norm_num; linarith
    | 1 => simp only [muI]; norm_num
    | k + 2 => simp only [muI]; norm_num

/-- **Region I in one point**: if every coordinate one step down is `≤ 19/250` (that is
`σ_ν ∈ [0, 0.152] ∪ [0.848, 1]`), the chain of two steps gives `gpt 0 2 θ ≥ 19/100`. -/
theorem regionI_lb {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (hb : ∀ ν, tx θ ν ≤ 19 / 250) :
    (19 / 100 : ℝ) ≤ gpt 0 2 θ := by
  obtain ⟨h1, h2⟩ := muI_ok (b := 19 / 250) (by norm_num) le_rfl
  have hd := deep_lb 2 (muI (19 / 250)) 0 θ h1 h2 hω hb
  have e : Lam (muI (19 / 250)) 2 0 = nd (19 / 250) ^ 2 * (1 - 2 * (19 / 250)) ^ 2 *
      (nd (1 / 50) ^ 2 * (1 - 2 * (1 / 50)) ^ 2 * tauS 2) := rfl
  rw [e] at hd
  have ht := tauS_two_ge
  have hn : nd (19 / 250) ^ 2 * (1 - 2 * (19 / 250)) ^ 2 * (nd (1 / 50) ^ 2 *
      (1 - 2 * (1 / 50)) ^ 2) = (nd (19 / 250) ^ 2 * (1 - 2 * (19 / 250)) ^ 2 * (nd (1 / 50) ^ 2 *
      (1 - 2 * (1 / 50)) ^ 2)) := rfl
  have hv : (19 / 100 : ℝ) ≤ nd (19 / 250) ^ 2 * (1 - 2 * (19 / 250)) ^ 2 *
      (nd (1 / 50) ^ 2 * (1 - 2 * (1 / 50)) ^ 2) * (7 / 10) := by
    norm_num [nd, Ef]
  have hpos : 0 ≤ nd (19 / 250) ^ 2 * (1 - 2 * (19 / 250)) ^ 2 * (nd (1 / 50) ^ 2 *
      (1 - 2 * (1 / 50)) ^ 2) := by positivity
  nlinarith

end HsChain

end

-- ===== new part : Assemble.part.lean =====
/-!
# hS on a box of vertices from polynomial inequalities 

`box_of`: if on a box `B` of vertex coordinates (every `x_ν ∈ [lo, hi] ⊆ [0, ½]`)
* `q ≤ 1 − X(1 − Ef(x_ρ, x_σ))` for every pair `ρ ≠ σ` (so `q ≤ nfun`), `0 ≤ r`, `0 ≤ k`,
* `k ≤ K` at every alias whose vertex lies in `B` (the factor below the alias),
* `Q ≤ (2rq − r²)(1 − 2x_ν)k`,
then `ω(θ)·D_ν ≥ (ω/32)·Σ_ζ Q(x_ζ)` whenever every vertex of `θ` lies in `B`.
-/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

/-- The factor below the alias `θ'` (one step down and the deep chain). -/
def Kal (j : ℕ) (θ' : Fin 4 → ℝ) : ℝ :=
  nfun (sQ (low θ')) ^ 2 * cm2 (sQ (low θ')) * gpt 1 j (low θ') / (4 * ∑ μ, tx θ' μ)

theorem Kal_nonneg (j : ℕ) (θ' : Fin 4 → ℝ) : 0 ≤ Kal j θ' := by
  unfold Kal
  have h1 := cm2_nonneg (low θ')
  have h2 := (gpt_bounds j 1 (low θ')).1
  have h3 : 0 ≤ 4 * ∑ μ, tx θ' μ := by
    have := Finset.sum_nonneg fun ν (_ : ν ∈ (univ : Finset (Fin 4))) => (xt_rel θ' ν).2.1
    linarith
  positivity

/-- `q` below every pair gives `q ≤ nfun`. -/
theorem nfun_ge_poly {s : Fin 4 → ℝ} {q : ℝ}
    (h : ∀ ρ σ : Fin 4, ρ ≠ σ → q ≤ 1 - (∑ ν, xs s ν) * (1 - Ef (xs s ρ) (xs s σ))) :
    q ≤ nfun s := by
  apply nfun_ge_of
  intro K hK
  rcases hK with hK | hK | hK | hK | hK | hK <;> rw [hK]
  · exact h 2 3 (by decide)
  · exact h 1 3 (by decide)
  · exact h 1 2 (by decide)
  · exact h 0 3 (by decide)
  · exact h 0 2 (by decide)
  · exact h 0 1 (by decide)

/-- The tangent: `n² ≥ 2rq − r²` when `q ≤ n`, `0 ≤ r`. -/
theorem sq_tangent {n q r : ℝ} (hq : q ≤ n) (hr : 0 ≤ r) : 2 * r * q - r ^ 2 ≤ n ^ 2 := by
  nlinarith [sq_nonneg (n - r), mul_le_mul_of_nonneg_left hq hr]

/-- **One vertex.** -/
theorem vertex_lb {n w K A k Q : ℝ} (hn : A ≤ n ^ 2) (hw : 0 ≤ w) (hk : 0 ≤ k) (hK : k ≤ K)
    (hQ : Q ≤ A * w * k) : Q ≤ n ^ 2 * w * K := by
  have h1 : A * w * k ≤ n ^ 2 * w * k :=
    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hn hw) hk
  have h2 : n ^ 2 * w * k ≤ n ^ 2 * w * K :=
    mul_le_mul_of_nonneg_left hK (mul_nonneg (sq_nonneg _) hw)
  linarith

/-- The vertex coordinates of `θ` (the sixteen aliases). -/
theorem xs_sR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    xs (sR θ ζ) ν = xa (Real.sin (θ ν) ^ 2) (ζ ν) := xs_alias θ ζ ν

/-- **The box form, pointwise**: a lower bound `Q` of each vertex term. -/
theorem box_of_pt (j : ℕ) (B : (Fin 4 → ℝ) → Prop) (Q : Fin 4 → (Fin 4 → ℝ) → ℝ)
    (HV : ∀ θ' : Fin 4 → ℝ, 0 < omT θ' → B (xs (sQ θ')) → ∀ ν,
      Q ν (xs (sQ θ')) ≤ nfun (sQ θ') ^ 2 * (1 - 2 * xs (sQ θ') ν) * Kal j θ')
    {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (hθ : ∀ ζ, B (xs (sR θ ζ))) (ν : Fin 4) :
    (omT θ / 32) * ∑ ζ : Fin 4 → Bool, Q ν (xs (sR θ ζ)) ≤ omT θ * Dn (j + 1) θ ν := by
  rw [omDn_eq j hω ν, Finset.mul_sum]
  refine Finset.sum_le_sum fun ζ _ => ?_
  apply mul_le_mul_of_nonneg_left _ (by linarith)
  have hp := omT_alias_pos hω ζ
  have hsq : sQ (thR θ ζ) = sR θ ζ := sQ_thR θ ζ
  have h := HV (thR θ ζ) hp (by rw [hsq]; exact hθ ζ) ν
  rw [hsq] at h
  unfold Kal at h
  calc Q ν (xs (sR θ ζ)) ≤ _ := h
    _ = _ := by ring

/-- **The box form.** -/
theorem box_of (j : ℕ) (B : (Fin 4 → ℝ) → Prop) (hB : ∀ x, B x → ∀ ν, 0 ≤ x ν ∧ x ν ≤ 1 / 2)
    (q r k : (Fin 4 → ℝ) → ℝ) (Q : Fin 4 → (Fin 4 → ℝ) → ℝ)
    (Hq : ∀ x, B x → ∀ ρ σ : Fin 4, ρ ≠ σ → q x ≤ 1 - (∑ ν, x ν) * (1 - Ef (x ρ) (x σ)))
    (Hr : ∀ x, B x → 0 ≤ r x) (Hk : ∀ x, B x → 0 ≤ k x)
    (HK : ∀ θ' : Fin 4 → ℝ, 0 < omT θ' → B (xs (sQ θ')) → k (xs (sQ θ')) ≤ Kal j θ')
    (HQ : ∀ x, B x → ∀ ν, Q ν x ≤ (2 * r x * q x - r x ^ 2) * (1 - 2 * x ν) * k x)
    {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (hθ : ∀ ζ, B (xs (sR θ ζ))) (ν : Fin 4) :
    (omT θ / 32) * ∑ ζ : Fin 4 → Bool, Q ν (xs (sR θ ζ)) ≤ omT θ * Dn (j + 1) θ ν := by
  refine box_of_pt j B Q (fun θ' hp hBx ν => ?_) hω hθ ν
  have hnq : q (xs (sQ θ')) ≤ nfun (sQ θ') := nfun_ge_poly (Hq _ hBx)
  have hA := sq_tangent hnq (Hr _ hBx)
  have hw : 0 ≤ 1 - 2 * xs (sQ θ') ν := by linarith [(hB _ hBx ν).2]
  exact vertex_lb hA hw (Hk _ hBx) (HK θ' hp hBx) (HQ _ hBx ν)

/-- `ω(θ) = Σ 16σ(1 − σ)`, `σ = sin²θ`. -/
theorem omT_sigma (θ : Fin 4 → ℝ) :
    omT θ = ∑ ν, 16 * (Real.sin (θ ν) ^ 2 * (1 - Real.sin (θ ν) ^ 2)) := by
  unfold omT
  exact Finset.sum_congr rfl fun ν _ => by rw [sQ_sq_sigma]; ring

/-- The sixteen vertices written out. -/
theorem vertex_sum_eq (θ : Fin 4 → ℝ) (F : (Fin 4 → ℝ) → ℝ) :
    ∑ ζ : Fin 4 → Bool, F (xs (sR θ ζ)) = ∑ b0 : Bool, ∑ b1 : Bool, ∑ b2 : Bool, ∑ b3 : Bool,
      F ![xa (Real.sin (θ 0) ^ 2) b0, xa (Real.sin (θ 1) ^ 2) b1, xa (Real.sin (θ 2) ^ 2) b2,
        xa (Real.sin (θ 3) ^ 2) b3] := by
  rw [sum_bool4]
  refine Finset.sum_congr rfl fun b0 _ => Finset.sum_congr rfl fun b1 _ =>
    Finset.sum_congr rfl fun b2 _ => Finset.sum_congr rfl fun b3 _ => ?_
  congr 1
  funext ν
  rw [xs_sR]
  fin_cases ν <;> rfl

/-- Each vertex term of `ω·D_ν` is nonnegative. -/
theorem term_nonneg (j : ℕ) {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    0 ≤ (omT θ / 32) * (nfun (sR θ ζ) ^ 2 * (1 - 2 * xs (sR θ ζ) ν) *
        (nfun (sQ (low (thR θ ζ))) ^ 2 * cm2 (sQ (low (thR θ ζ))) * gpt 1 j (low (thR θ ζ)) /
          (4 * ∑ μ, tx (thR θ ζ) μ))) := by
  have hK := Kal_nonneg j (thR θ ζ)
  unfold Kal at hK
  have hx : xs (sR θ ζ) ν ≤ 1 / 2 := by
    rw [xs_sR]; exact (xa_mem (sigma_mem _).1 (sigma_mem _).2 _).2
  have : 0 ≤ 1 - 2 * xs (sR θ ζ) ν := by linarith
  have h32 : 0 ≤ omT θ / 32 := by linarith
  positivity

/-- **The box form on a set `S` of vertices** (the others are dropped, their terms are `≥ 0`). -/
theorem box_of_sub (j : ℕ) (B : (Fin 4 → ℝ) → Prop) (Q : Fin 4 → (Fin 4 → ℝ) → ℝ)
    (HV : ∀ θ' : Fin 4 → ℝ, 0 < omT θ' → B (xs (sQ θ')) → ∀ ν,
      Q ν (xs (sQ θ')) ≤ nfun (sQ θ') ^ 2 * (1 - 2 * xs (sQ θ') ν) * Kal j θ')
    {θ : Fin 4 → ℝ} (hω : 0 < omT θ) (S : Finset (Fin 4 → Bool))
    (hθ : ∀ ζ ∈ S, B (xs (sR θ ζ))) (ν : Fin 4) :
    (omT θ / 32) * ∑ ζ ∈ S, Q ν (xs (sR θ ζ)) ≤ omT θ * Dn (j + 1) θ ν := by
  rw [omDn_eq j hω ν, Finset.mul_sum]
  calc ∑ ζ ∈ S, omT θ / 32 * Q ν (xs (sR θ ζ))
      ≤ ∑ ζ ∈ S, (omT θ / 32) * (nfun (sR θ ζ) ^ 2 * (1 - 2 * xs (sR θ ζ) ν) *
        (nfun (sQ (low (thR θ ζ))) ^ 2 * cm2 (sQ (low (thR θ ζ))) * gpt 1 j (low (thR θ ζ)) /
          (4 * ∑ μ, tx (thR θ ζ) μ))) := by
        refine Finset.sum_le_sum fun ζ hζ => ?_
        apply mul_le_mul_of_nonneg_left _ (by linarith)
        have hp := omT_alias_pos hω ζ
        have hsq : sQ (thR θ ζ) = sR θ ζ := sQ_thR θ ζ
        have h := HV (thR θ ζ) hp (by rw [hsq]; exact hθ ζ hζ) ν
        rw [hsq] at h
        unfold Kal at h
        calc Q ν (xs (sR θ ζ)) ≤ _ := h
          _ = _ := by ring
    _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ S)
        fun ζ _ _ => term_nonneg j hω ζ ν

/-- The vertex coordinate relative to the nearest alias: `a` or `½ − a`, `a = tx θ ν`. -/
theorem xs_vertex (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    xs (sR θ ζ) ν = if ζ ν = zs θ ν then tx θ ν else 1 / 2 - tx θ ν := by
  unfold tx
  rw [sQ_low, xs_sR, xs_sR]
  by_cases h : ζ ν = zs θ ν
  · rw [if_pos h, h]
  · rw [if_neg h]
    have : ζ ν = !zs θ ν := by
      cases hz : zs θ ν <;> cases hζ : ζ ν <;> simp_all
    rw [this]
    cases zs θ ν <;> simp [xa] <;> ring

/-- `ω/32 = Σ a(1 − 2a)` with `a = tx θ ν`. -/
theorem omT_tx (θ : Fin 4 → ℝ) : omT θ / 32 = ∑ ν, tx θ ν * (1 - 2 * tx θ ν) := by
  rw [omT_xs, Finset.sum_div]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [(xt_rel θ ν).1]; ring

end HsChain

end

-- ===== new part : Order.part.lean =====
/-!
# hS: the smallest pair gives `nfun`, the largest index gives `cm2` 
-/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

theorem Ef_comm (a b : ℝ) : Ef a b = Ef b a := by unfold Ef; ring

theorem Ef_mono {a b a' b' : ℝ} (ha : a ≤ a') (hb : b ≤ b') (ha0 : 0 ≤ a) (hb1 : b' ≤ 1 / 2)
    (ha1 : a' ≤ 1 / 2) : Ef a b ≤ Ef a' b' := by
  unfold Ef
  nlinarith [mul_nonneg (sub_nonneg.2 ha) (sub_nonneg.2 hb), mul_nonneg (sub_nonneg.2 ha) ha0,
    mul_nonneg (sub_nonneg.2 hb) (sub_nonneg.2 ha1), mul_nonneg (sub_nonneg.2 ha) (sub_nonneg.2 hb1)]

/-- The two smallest coordinates give the smallest `Ef`. -/
theorem Ef_minpair {x : Fin 4 → ℝ} (h0 : ∀ ν, 0 ≤ x ν) (h1 : ∀ ν, x ν ≤ 1 / 2) {ρ σ : Fin 4}
    (hρσ : ρ ≠ σ) (hs : ∀ k, k ≠ ρ → k ≠ σ → x ρ ≤ x k ∧ x σ ≤ x k) {α β : Fin 4} (hαβ : α ≠ β) :
    Ef (x ρ) (x σ) ≤ Ef (x α) (x β) := by
  -- reduce to `min ≤ min`, `max ≤ max`
  have key : ∀ a b c d : ℝ, a ≤ b → c ≤ d → 0 ≤ a → b ≤ 1 / 2 → d ≤ 1 / 2 → a ≤ c → b ≤ d →
      Ef a b ≤ Ef c d := fun a b c d _ hcd ha0 _ hd1 hac hbd =>
    Ef_mono hac hbd ha0 hd1 (le_trans hcd hd1)
  by_cases hin : (α = ρ ∨ α = σ) ∧ (β = ρ ∨ β = σ)
  · obtain ⟨hα, hβ⟩ := hin
    rcases hα with rfl | rfl <;> rcases hβ with rfl | rfl
    · exact absurd rfl hαβ
    · exact le_rfl
    · exact le_of_eq (Ef_comm _ _)
    · exact absurd rfl hαβ
  · -- one of `α, β` is outside `{ρ, σ}`: its value is ≥ both `x ρ, x σ`
    have hout : (α ≠ ρ ∧ α ≠ σ) ∨ (β ≠ ρ ∧ β ≠ σ) := by tauto
    have hle : ∀ k, x ρ ⊓ x σ ≤ x k := by
      intro k
      by_cases hk1 : k = ρ
      · subst hk1; exact inf_le_left
      · by_cases hk2 : k = σ
        · subst hk2; exact inf_le_right
        · exact le_trans inf_le_left (hs k hk1 hk2).1
    have hmax : x ρ ⊔ x σ ≤ x α ⊔ x β := by
      rcases hout with ⟨h1', h2'⟩ | ⟨h1', h2'⟩
      · exact le_trans (sup_le (hs α h1' h2').1 (hs α h1' h2').2) le_sup_left
      · exact le_trans (sup_le (hs β h1' h2').1 (hs β h1' h2').2) le_sup_right
    have hmin : x ρ ⊓ x σ ≤ x α ⊓ x β := le_inf (hle α) (hle β)
    have e1 : Ef (x ρ) (x σ) = Ef (x ρ ⊓ x σ) (x ρ ⊔ x σ) := by
      rcases le_total (x ρ) (x σ) with h | h
      · rw [inf_eq_left.2 h, sup_eq_right.2 h]
      · rw [inf_eq_right.2 h, sup_eq_left.2 h, Ef_comm]
    have e2 : Ef (x α) (x β) = Ef (x α ⊓ x β) (x α ⊔ x β) := by
      rcases le_total (x α) (x β) with h | h
      · rw [inf_eq_left.2 h, sup_eq_right.2 h]
      · rw [inf_eq_right.2 h, sup_eq_left.2 h, Ef_comm]
    rw [e1, e2]
    apply key _ _ _ _ inf_le_sup inf_le_sup (le_inf (h0 ρ) (h0 σ)) (sup_le (h1 ρ) (h1 σ))
      (sup_le (h1 α) (h1 β)) hmin hmax

/-- **The smallest pair**: `1 − X(1 − Ef(x_ρ, x_σ)) ≤ nfun` when `x_ρ, x_σ` are the two smallest. -/
theorem nfun_ge_minpair {s : Fin 4 → ℝ} (h1 : ∀ ν, xs s ν ≤ 1 / 2) {ρ σ : Fin 4} (hρσ : ρ ≠ σ)
    (hs : ∀ k, k ≠ ρ → k ≠ σ → xs s ρ ≤ xs s k ∧ xs s σ ≤ xs s k) :
    1 - (∑ ν, xs s ν) * (1 - Ef (xs s ρ) (xs s σ)) ≤ nfun s := by
  apply nfun_ge_poly
  intro α β hαβ
  have hE := Ef_minpair (x := xs s) (xs_nonneg s) h1 hρσ hs hαβ
  have hX : 0 ≤ ∑ ν, xs s ν := Finset.sum_nonneg fun ν _ => xs_nonneg s ν
  nlinarith [mul_le_mul_of_nonneg_left hE hX]

end HsChain

end

-- ===== new part : Glue.part.lean =====
/-!
# hS: the deep chain of four steps from below by explicit factors 
-/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

theorem Lam_four (μ : ℕ → ℝ) : Lam μ 4 1 = (nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2) *
    ((nd (μ 1) ^ 2 * (1 - 2 * μ 1) ^ 2) * ((nd (μ 2) ^ 2 * (1 - 2 * μ 2) ^ 2) *
      ((nd (μ 3) ^ 2 * (1 - 2 * μ 3) ^ 2) * tauS 5))) := rfl

/-- Four steps from below by factors `e i ≤ nd(μ i)²(1 − 2μ i)²`, `0 ≤ e i`. -/
theorem Lam_four_ge (μ : ℕ → ℝ) {e0 e1 e2 e3 : ℝ}
    (h0 : 0 ≤ e0 ∧ e0 ≤ nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2)
    (h1 : 0 ≤ e1 ∧ e1 ≤ nd (μ 1) ^ 2 * (1 - 2 * μ 1) ^ 2)
    (h2 : 0 ≤ e2 ∧ e2 ≤ nd (μ 2) ^ 2 * (1 - 2 * μ 2) ^ 2)
    (h3 : 0 ≤ e3 ∧ e3 ≤ nd (μ 3) ^ 2 * (1 - 2 * μ 3) ^ 2) :
    e0 * (e1 * (e2 * (e3 * (995 / 1000)))) ≤ Lam μ 4 1 := by
  rw [Lam_four]
  have ht := tauS_five_ge
  have k3 : e3 * (995 / 1000) ≤ (nd (μ 3) ^ 2 * (1 - 2 * μ 3) ^ 2) * tauS 5 :=
    mul_le_mul h3.2 ht (by norm_num) (le_trans h3.1 h3.2)
  have p3 : 0 ≤ e3 * (995 / 1000) := mul_nonneg h3.1 (by norm_num)
  have k2 := mul_le_mul h2.2 k3 p3 (le_trans h2.1 h2.2)
  have p2 : 0 ≤ e2 * (e3 * (995 / 1000)) := mul_nonneg h2.1 p3
  have k1 := mul_le_mul h1.2 k2 p2 (le_trans h1.1 h1.2)
  have p1 : 0 ≤ e1 * (e2 * (e3 * (995 / 1000))) := mul_nonneg h1.1 p2
  exact mul_le_mul h0.2 k1 p1 (le_trans h0.1 h0.2)

/-- **The factor below an alias, with the largest coordinate one step down.** -/
theorem Kal_ge (θ' : Fin 4 → ℝ) (hω : 0 < omT θ') {m : ℝ} (hm : ∀ ν, tx θ' ν ≤ m)
    (μ : ℕ → ℝ) (hμ : ∀ i, 0 ≤ μ i ∧ μ i ≤ 1 / 4 ∧ 0 ≤ nd (μ i))
    (hrec : ∀ i, μ i ≤ 4 * μ (i + 1) * (1 - 2 * μ (i + 1))) (hm0 : m ≤ 4 * μ 0 * (1 - 2 * μ 0))
    (hι : 0 ≤ 1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m))
    {e0 e1 e2 e3 : ℝ}
    (h0 : 0 ≤ e0 ∧ e0 ≤ nd (μ 0) ^ 2 * (1 - 2 * μ 0) ^ 2)
    (h1 : 0 ≤ e1 ∧ e1 ≤ nd (μ 1) ^ 2 * (1 - 2 * μ 1) ^ 2)
    (h2 : 0 ≤ e2 ∧ e2 ≤ nd (μ 2) ^ 2 * (1 - 2 * μ 2) ^ 2)
    (h3 : 0 ≤ e3 ∧ e3 ≤ nd (μ 3) ^ 2 * (1 - 2 * μ 3) ^ 2) :
    (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m)) ^ 2 *
        (1 - 2 * m) * (e0 * (e1 * (e2 * (e3 * (995 / 1000))))) / (4 * ∑ ν, tx θ' ν) ≤
      Kal 4 θ' := by
  have hK := K_lb 4 hω hm μ hμ hrec hm0 hι
  have hL := Lam_four_ge μ h0 h1 h2 h3
  have hm1 : 0 ≤ 1 - 2 * m := by nlinarith [sq_nonneg (μ 0 - 1 / 4)]
  have hT : 0 ≤ 4 * ∑ ν, tx θ' ν := by
    have := Finset.sum_nonneg fun ν (_ : ν ∈ (univ : Finset (Fin 4))) => (xt_rel θ' ν).2.1
    linarith
  unfold Kal
  refine le_trans ?_ hK
  apply div_le_div_of_nonneg_right _ hT
  exact mul_le_mul_of_nonneg_left hL (mul_nonneg (sq_nonneg _) hm1)

end HsChain

end

-- ===== new part : OneVarCerts.part.lean (generated by a generating script) =====
/-! # T1b, the certificates: one-variable polynomial inequalities on `m ∈ [0, t̄]`

Generated from earlier data files (work-02 §3 format, exact identities checked by
sympy in the generator) and `coef.json`. `t̄ = u(1/2 − b) = 156208249503/1024000000000`.
`μ₀ = m/4 + c₂m²`, `μ_{j+1} = λ_j μ_j`; `ℓ_j` quadratic minorants of `nd(μ_j)²(1 − 2μ_j)²`;
`φ̂ ≤ (1 − 2m)Πℓ_j`. These certificates do not depend on the smallest pair `n_p`. -/

noncomputable section

namespace HsCert

theorem cert_mu2 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -95550625*m^4/536870912 - 9775*m^3/16384 + 1583*m^2/16384 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (548672589872268143/879609302220800000) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe1 1)) + (95550625/536870912) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) (pow_nonneg pe1 1)) + (1319160524245947017737517071/900719925474099200000000000000) * (pow_nonneg pe1 1)


theorem cert_mu3 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -1675095044805625*m^4/144115188075855872 - 171365221975*m^3/4398046511104 - 15751919*m^2/536870912 + 91*m/16384 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  linear_combination (11466458039523/281474976710656) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe1 1)) + (37600937869525660410151/288230376151711744000000000) * (pow_nonneg pa0 1) + (10007717243783/281474976710656) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (1635835004693/140737488355328) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) (pow_nonneg pe1 1)) + (7/144115188075855872) * (pow_nonneg pa0 4) + (150680082421/144115188075855872000000000) * (pow_nonneg pa0 3) + (174980892931/288230376151711744000000000) * (pow_nonneg pa0 2)


theorem cert_mu4 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -444277083258571890625*m^4/604462909807314587353088 - 45450340998319375*m^3/18446744073709551616 - 4146728910625*m^2/2251799813685248 + 12561*m/33554432 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 93/1000) ^ 2 := sq_nonneg _
  have pe3 : (0:ℝ) ≤ (m - 83/1000) ^ 2 := sq_nonneg _
  have pe4 : (0:ℝ) ≤ (m - 47/500) ^ 2 := sq_nonneg _
  have pe5 : (0:ℝ) ≤ (m - 2/25) ^ 2 := sq_nonneg _
  linear_combination (725078102351/281474976710656) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe1 1)) + (9651019549302938869203/288230376151711744000000000) * (pow_nonneg pa0 1) + (628949810099/281474976710656) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (103443918181/140737488355328) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) (pow_nonneg pe1 1)) + (123860169221118447/288230376151711744000000000) * (pow_nonneg pa0 2) + (405973556316898457/144115188075855872000000000) * (pow_nonneg pa0 3) + (11162298922917951/604462909807314587353088) * (pow_nonneg pa0 4)


theorem cert_mu5 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -29924215857041537648691390625*m^4/649037107316853453566312041152512 - 3061300854940310756899375*m^3/19807040628566084398385987584 - 270741177812069428225*m^2/2417851639229258349412352 + 32344575*m/1099511627776 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 97/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 41/1000) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 3/500) ^ 2 := sq_nonneg _
  have pe3 : (0:ℝ) ≤ (m - 1/500) ^ 2 := sq_nonneg _
  have pe4 : (0:ℝ) ≤ (m - 31/250) ^ 2 := sq_nonneg _
  have pe5 : (0:ℝ) ≤ (m - 139/1000) ^ 2 := sq_nonneg _
  have pe6 : (0:ℝ) ≤ (m - 93/1000) ^ 2 := sq_nonneg _
  have pe7 : (0:ℝ) ≤ (m - 111/1000) ^ 2 := sq_nonneg _
  have pe8 : (0:ℝ) ≤ (m - 83/1000) ^ 2 := sq_nonneg _
  have pe9 : (0:ℝ) ≤ (m - 143/1000) ^ 2 := sq_nonneg _
  have pe10 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  have pe11 : (0:ℝ) ≤ (m - 131/1000) ^ 2 := sq_nonneg _
  have pe12 : (0:ℝ) ≤ (m - 1/200) ^ 2 := sq_nonneg _
  have pe13 : (0:ℝ) ≤ (m - 27/1000) ^ 2 := sq_nonneg _
  have pe14 : (0:ℝ) ≤ (m - 23/500) ^ 2 := sq_nonneg _
  have pe15 : (0:ℝ) ≤ (m - 8/125) ^ 2 := sq_nonneg _
  have pe16 : (0:ℝ) ≤ (m - 19/1000) ^ 2 := sq_nonneg _
  have pe17 : (0:ℝ) ≤ (m - 51/500) ^ 2 := sq_nonneg _
  have pe18 : (0:ℝ) ≤ (m - 99/1000) ^ 2 := sq_nonneg _
  have pe19 : (0:ℝ) ≤ (m - 47/500) ^ 2 := sq_nonneg _
  have pe20 : (0:ℝ) ≤ (m - 59/1000) ^ 2 := sq_nonneg _
  have pe21 : (0:ℝ) ≤ (m - 19/125) ^ 2 := sq_nonneg _
  have pe22 : (0:ℝ) ≤ (m - 3/20) ^ 2 := sq_nonneg _
  have pe23 : (0:ℝ) ≤ (m - 21/200) ^ 2 := sq_nonneg _
  have pe24 : (0:ℝ) ≤ (m - 21/1000) ^ 2 := sq_nonneg _
  have pe25 : (0:ℝ) ≤ (m - 11/100) ^ 2 := sq_nonneg _
  have pe26 : (0:ℝ) ≤ (m - 2/25) ^ 2 := sq_nonneg _
  have pe27 : (0:ℝ) ≤ (m - 47/1000) ^ 2 := sq_nonneg _
  have pe28 : (0:ℝ) ≤ (m - 37/500) ^ 2 := sq_nonneg _
  have pe29 : (0:ℝ) ≤ (m - 17/125) ^ 2 := sq_nonneg _
  have pe30 : (0:ℝ) ≤ (m - 11/200) ^ 2 := sq_nonneg _
  linear_combination (45484976899/281474976710656) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe10 1)) + (308951631243113350323/36028797018963968000000000) * (pow_nonneg pa0 1) + (4807143059/35184372088832) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (12982757787/281474976710656) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) (pow_nonneg pe10 1)) + (2029324407279938115227/4722366482869645213696000000000) * (pow_nonneg pa0 2) + (108977725742906622923827317/38685626227668133590597632000000000) * (pow_nonneg pa0 3) + (11985426427060253671413599/649037107316853453566312041152512) * (pow_nonneg pa0 4)


theorem cert_ell2 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 83355474591976505420074462890625*m^16/47852207848256971424537054170092404736 + 8527414280509105413818359375*m^15/365083372865730067631050523148288 + 13452813874141270034423828125*m^14/243388915243820045087367015432192 - 22275459495956119619140625*m^13/44565841414273689896368472064 - 97901573510205097966796875*m^12/44565841414273689896368472064 + 2062799328052969046875*m^11/453347182355485940514816 + 1262974813857436585625*m^10/42501298345826806923264 - 61935968824969325*m^9/2594073385365405696 - 751172035999245967*m^8/3458764513820540928 + 16832569906973*m^7/158329674399744 + 294989006903495*m^6/316659348799488 - 3401324311*m^5/6442450944 - 7065941939*m^4/3221225472 + 190019*m^3/98304 - 36567*m^2/131072 + 8701*m/1048576 + 1049/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 19/200) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 19/200) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  linear_combination (48937164735435647849040303314639225795101788824059518978335558270261750795378738940703667101125418527881553402731262334751059384503250511585373739030221859821509535070794735947097173/21202164777340611954999570008915022189929806762507427497459274415511437312000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 3)) + (66253436727752575239573698712255496148446393455909223412504880291940443452820699360949184408313750269050668275867178820718209788584059162819197428094658579391/60659880001088939538000783945794169015683574950716288082483123060736000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 3) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (1383864679008197773169476069416185969505129727426498885552388647936178226889586352753083183101352875392883280935327500090560254972856533/19283256531107883306503545108093951230266435925393514023616512000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 5) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (131923713404041770905182738822224471846033282385358503400210160644012882893809730940747241970031803467175684872511/55169839471171998900900492977411130610274608398609678336000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 7) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (3861823556349651867160427862799755882938933908124333792789697384946837354219831132258273279/52614058943912505055332653977786188707613571547136000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 9) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (31652970882571685531675055405483099387067475794338124263787264374677/16725558898897967356151788704486271129485312000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 11) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (1297198826078499568748782364155262462457394559/47852207848256971424537054170092404736) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 13) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (41839532053369654312253328033293903149465058005965979439186987109010463687080100324184882259751051276600808378544900153143882217525557582783416768354951394551560868270310519820195517990076936389313596027072336596057/7588550360256754183279148073529370729071901715047420004889892225542594864082845696000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pb0 1) + (742368535495779724366175101327303478884349738928581590369131143480482239547132353716504723983891232520811661340190771727623004068615974971568048587212927630438404138446249269128486216238046437439105557/7410693711188236507108543040556026102609279018600996098525285376506440296955904000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pa0 2) + (14965503283984798731462776531540124972962932288585563476938318634197697423631559538299367617652743909844500056328515700971822473436878531598058164242008776423702953930891/20705239040371691362304267586831076357353326916511159665487572671397888000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 2) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (23552897464499980886879606047819779029672614915418870456579406636515675574222551105001544082913841204845639853300101034112033/56493915618480126874522104808868997744921199000176310616064000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 6) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (19777820718379488916364794173334287197701634370114220489228097543460104273106593/51380916937414555718098294900181824909778878464000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 10) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (405266315757006429537540638229901113228114873603586654177/49000660836615138738725943470174622449664000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 12) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (1238137640954927223259533913976393067536778408536143528586735462160104700437613667013456726868129327518194259072765364789477536706722781829374456237975797694451985091140018272641271827563736842332241848892934902373930417990329/7770675568902916283677847627294075626569627356208558085007249638955617140820833992704000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (zero_le_one' ℝ) + (714051440956512933096610707106565675004185923069581228567302200067318063458733945869952166455228689888653942096708644023490474211565809398462659297/59238164063563417517578890572064618179378491162808875080549924864000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 4) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (241299396090149475741172557538573285393152376555197741165915783838547401939577257139442448067329976779/17958932119522135058886879224417685745532099088089088000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 8) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (5541420553484611741746158113819192485104099598387731175421351678360326486921607744507178941241043671504138032104808994665180624815839897115278640664189283390670842498703301356030525374290134943/21711016731996786641919559689128982722488122124807605757398297001483711807488000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pe2 1)) + (666669333849/549755813888) * (pow_nonneg pa0 7) + (8740503783035/1099511627776) * (pow_nonneg pa0 8) + (4733174337/1099511627776) * (pow_nonneg pa0 4) + (7162134444167/137438953472) * (pow_nonneg pa0 9) + (682565196313/1099511627776) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pe1 1)) + (93900619130697/274877906944) * (pow_nonneg pa0 10) + (203396971949/1099511627776) * (pow_nonneg pa0 6) + (2462206299494757/1099511627776) * (pow_nonneg pa0 11) + (16802137/1099511627776) * (pow_nonneg pa0 1) + (4035157007879743/274877906944) * (pow_nonneg pa0 12) + (15513811007/549755813888) * (pow_nonneg pa0 5) + (413310515491283/4294967296) * (pow_nonneg pa0 13) + (722032107/1099511627776) * (pow_nonneg pa0 3) + (1354697876743525/2147483648) * (pow_nonneg pa0 14) + (2220130227115067/536870912) * (pow_nonneg pa0 15) + (3638433565127057/134217728) * (pow_nonneg pa0 16)


theorem cert_ell3 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 7873318415253324033542946814996284422856412418188629150390625*m^16/248462868484460296347651211041972916288239922998133915985850872056774656 + 805454569335378417753754149871742651954620196234130859375*m^15/1895621250034029360562524498306067781740111717209884002577597595648 - 192449048749250433468443900627646561448307748291015625*m^14/57849769593323649919510635324281853690799307776180542070849536 - 282099025409856775790126929563247603689365498046875*m^13/4707826301540010572876842067405749812076766583348025884672 + 237315638108802910769941176871886168476380859375*m^12/1724057483474124965653140405544097831571081512456552448 + 196003298259355919265952499595784051224203125*m^11/52614058943912505055332653977786188707613571547136 - 2843104865484338814037629647694917238125*m^10/1070435769529469910793714477087121352287059968 - 25595713077891010263297906777334602575*m^9/196002643346460554954903773880698489798656 + 1289176420802605565415508128107321*m^8/47852207848256971424537054170092404736 + 2019072658030413156051617854669*m^7/730166745731460135262101046296576 - 22831400809180902035671235*m^6/44565841414273689896368472064 - 996802424408681761417*m^5/28334198897217871282176 + 53969253401068639*m^4/3458764513820540928 + 26368207756117*m^3/105553116266496 - 45467461*m^2/1073741824 + 263*m/262144 + 1049/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 99/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 99/1000) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  linear_combination (6156587166726022309482087579412300655768404151489204285020811469750218934726025286877545088490357679166121074489807453503463401999325765152118615876860245706759653624567346346892163067114081144510650624473542304949/110087933567523432557319402974500173158235119480077493939404264290572298052247270787360890549286032954621952000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 3)) + (757719761560142344294404291463519176344742789299460416948216204029765270097198006170209628828317172177364991931177351596083534858422382365257113583466975536008538443214671697154992599017845983/314964104368753717109640320704937476610856398048622590845310967323033231884710132944185897491319750656000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 3) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (25405875534532849812443206648650081383286921351493687289330042402267265927526622695642384419876918279101109525431461990428652652901915596215289071833760847303906008361887/300373176926377980336799927430093266116005323456404295773802726099999648937902577346979043475456000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 5) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (269935837601558372064860614452074151148105763453414705742989588218986485980917377589611973366463452905707526730569450032462498843581961190131768181/95486061390679035293833391644189601299287580953090761748569083563486623426406408102346752000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 7) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (23705320653065838816031327021280323784170617331084248133120672355762854607298507147777312675353626650517945454421359563581727/273187812969243150598049330647057346246588461741707120176036120119533415106982445056000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 9) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (582893420705612813163217304729665305648653896917306096769862693121180929054365725407030508117709582303/260532200783961439703034716269547792669857465497691269088779564017804541689856000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 11) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (7962692915933679283479789747103184707404828957944701794202328907746105290270367/248462868484460296347651211041972916288239922998133915985850872056774656) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 13) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (44209081003235718451053782503420266573926005928903634463824400459013576157938441618924145529964286040403678828464879154306473848815517618313516945875249608667245857565858493884062123742958805205781511393539768206091418229637364083460909236258474041/39402006196394479212279040100143613805079739270465446667948293404245721771497210611414266254884915640806627990306816000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pb0 1) + (4556936505194710792147791057325062599287890498277794953130652199211163575404314260002825949142368202423851777749317265404505178922730471949835184920299289986170651308866147840047681769577787207927593329102062130016217708943957284647541/38478521676166483605741250097796497856523182881313912761668255277583712667477744737709244389536050430475222646784000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pa0 2) + (46822763520852012316741586092550632716783927017935951241789962309731789480368674519507042879585761146025746809560977847554590696931547095157250159130606576763206311292014877953139846389832706020696765483/107507747624534602106757229467285325349838983867263177675199476846262009816647725378282119677037141557248000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 2) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (144569882875042199144920192052701747229325761150357720839483799820447148092363031880158179798970141712676955004821503523821180406547299891454498196392613392129/293333180592165996422656179130950455191411448687894820091604224707030907165920485690409222144000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 6) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (40467893731222875171839999748959159561916264088922203366342260143794559257869059099893669280794681775093645781803/88928324534258838085302516486672313231311348223211953182303424518077283563470848000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 10) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (2487676643455877560859082851583161525768731528912486525145232787364116072443835102663377601/254425977328087343459994840106980266279157681150089129969511292986137247744000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 12) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (33458146082646858644298901402022357299646214314095858275421408211704334158440614007333095193247573545089870755200495418591350696096080922860389822841300462416903747777509176132966624219207830716964506410133502665710085016757684082039487374275299112805423348377/40347654345107946713373737062547060536401653012956617387979052445947619094013143666088208645002153616185987062074179584000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (zero_le_one' ℝ) + (4408713219603903992828333608947186919029263850189419287547194953380496880527845434805443615953653051092567507312727738326939971524625288440244877836277404174481234620654448811892161/307582133172611051864883125688415504502789451219357998872373991526399640512412239203306540518866944000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 4) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (4443559970706236853481200774964116855654679334657636289544940335323942623946396271388273174274483750580017407723196449200449603547631681/279744320480504986212402514582586722556506584823508091060260987002402217069550023737344000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 8) (pow_nonneg pb0 1)) (pow_nonneg pe2 1)) + (21953392141877540212058735808616993725898841071371133675241012677873175190012354271906803994243671829039951538634169126618105752277580395518024417506169192843129810358879177014254160208930645635241077465234122436818902688928959/112730043973143994938695068645888177314032762347599353793949966633546033205501205286257551922468897745532878848000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pe1 1)) + (31552910213/1099511627776) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pe2 1)) + (2583273446003/274877906944) * (pow_nonneg pa0 8) + (2797798361/549755813888) * (pow_nonneg pa0 4) + (67737062981589/1099511627776) * (pow_nonneg pa0 9) + (788141841773/549755813888) * (pow_nonneg pa0 7) + (222020132463667/549755813888) * (pow_nonneg pa0 10) + (60114383527/274877906944) * (pow_nonneg pa0 6) + (727710016488049/274877906944) * (pow_nonneg pa0 11) + (9931811/549755813888) * (pow_nonneg pa0 1) + (4770395028781441/274877906944) * (pow_nonneg pa0 12) + (36681103987/1099511627776) * (pow_nonneg pa0 5) + (122154752875323/1073741824) * (pow_nonneg pa0 13) + (853592157/1099511627776) * (pow_nonneg pa0 3) + (6406138848226627/8589934592) * (pow_nonneg pa0 14) + (164040986788053/33554432) * (pow_nonneg pa0 15) + (8602770775828467/268435456) * (pow_nonneg pa0 16)


theorem cert_ell4 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 38959703944066679295582497764569224453035691768892847904879448080122470855712890625*m^16/76895533293152762966220781422103876125697362804839499718093497881599910128103059800826635129716736 + 3985647462308611692642710768753884854530505551804894926330378320217132568359375*m^15/586666361184331992845312358261900910382822897375789640183208449414061814331840971380818444288 - 23644046857325399376394540736584797388821098476347947939122794437408447265625*m^14/71614546043009276470375043733142200974465685714818071311426812672614967569804806076760064 - 1021762935380120260026377132428897555753909602927057811940029144287109375*m^13/242833611528216133864932738352939863330300854881517440156476551217363035650651062272 + 51029288932305373037547293264464917239979847281914308405864715576171875*m^12/533569947205553028511815098920033879387868089339271719093820547108463701380825088 + 9101574451846819891264626500770917801456937984638727442974853515625*m^11/8141631274498794990719834883423368520933045796802852159024361375556391927808 - 5259387518718208763750493419434816816504592094763186985107421875*m^10/331283824645947061796868281389297221717653230664178554647801162742366208 - 4933046822882141346694491356321854807202606119500060244140625*m^9/30329940000544469769000391972897084507841787475358144041241561530368 + 24255441962234119093339471849890416432308958095413062890625*m^8/14809541015890854379394722643016154544844622790702218770137481216 + 1525253702490244831712702793662658078339866363515625*m^7/110339678942343997801800985954822261220549216797219356672 - 351463600436592574641098901493514211176796875*m^6/3288378683994531565958290873611636794225848221696 - 346591556583051143221307939814821875*m^5/510423550381407695195061911147652317184 + 263016050030274333086340480625*m^4/60847228810955011271841753858048 + 16143223664666055969875*m^3/906694364710971881029632 - 13906611297553*m^2/4503599627370496 - 2355*m/33554432 + 1049/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 61/500) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 61/500) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 31/250) ^ 2 := sq_nonneg _
  have pe3 : (0:ℝ) ≤ (m - 31/250) ^ 2 := sq_nonneg _
  have pe4 : (0:ℝ) ≤ (m - 123/1000) ^ 2 := sq_nonneg _
  have pe5 : (0:ℝ) ≤ (m - 123/1000) ^ 2 := sq_nonneg _
  have pe6 : (0:ℝ) ≤ (m - 121/1000) ^ 2 := sq_nonneg _
  have pe7 : (0:ℝ) ≤ (m - 121/1000) ^ 2 := sq_nonneg _
  linear_combination (791514800711264222062777175647776132910936348346472909385544298659936866577742632720604003591927858707814036395728722119418145822214844381526048945757654528615593892378720545329206912439578264025100217775347513084624664037975062891800507093/34070565201356572994499553494750212547826938782218034075694853086592466630315527655915205502207667135660743200293727090634434451341312000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 3)) + (245100748175464623062787264798213070121505874391246955799474251725858951828713258066159295183580838244897972224123254778430447550786669541509926058251336275762410310861348267317832607857267462016905311937354428188596031/97476668933934897407053623661280286448937240931181051470837172755982780352541525809999100214598657042486409760361844322112372736000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 5) (pow_nonneg pb0 1)) + (8218043429611276472615844187120257513297951926282976439711283491051627473406754309165502003691699451140132881369826405236086324310397776826131173318123939902119310113386698968414850873454704002559/92960995611128709227613090192108427475869408541852046461903736835463314392606283006667232718084961931692514191018909761536000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 7) (pow_nonneg pb0 1)) + (87316191469358369277499220296580299568691045429422391451033412332083716344813839646805736700863263973592277938991620274045605197644543474500942163287624874499657140847911317/29551504647295859409209280075107710353809804452849085000961220053184291328622907958560699691163686730604970992730112000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 9) (pow_nonneg pb0 1)) + (7667964123975829019463633419176057978925789163128483443953095441163809343434030148651405171280680197129550437871650074639347729272984487613519111533439/84547532979857996204021301484416132985524571760699515345462474975159524904125903964693163941851673309149659136000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 11) (pow_nonneg pb0 1)) + (188548634438636532064764592021764081948422547447929121229572952985930859213119832026504290804741279515026470971423431634097566271/80630810718400951580067922100463994012379237900447383256399607634696507362485794033711589757777856167936000000000000000000) * (mul_nonneg (pow_nonneg pa0 13) (pow_nonneg pb0 1)) + (2575693638703383952808473088267517815378478311868060507266807519518698427631099121686857596878024492785919/76895533293152762966220781422103876125697362804839499718093497881599910128103059800826635129716736) * (mul_nonneg (pow_nonneg pa0 15) (pow_nonneg pb0 1)) + (2524585876200398271161265860822299411813971347499753423722541785386954080865129163748070395768547407298377727717178936285461563151438172535275199321921351096930729234099287542338176662862428088187635051518397745492004847226193518521392000062437521831584027133889185327354663/6097165137335922326917182089439777940915230747392521779021790936768304177382354726797472857545882756171536974846497310342671827498609932238848000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pb0 1) + (18932460364050550000815188972228593348147198455825022414541557926095624332505261373715653034637465745099349385867809522779024004241192453579914465228190844652590612177240298634053953038409296081687908975064274755545619998846115329956614450105867949979392589965163/11908525658859223294760121268437066290850060053501019099651935423375594096449911575776314174894302258147533153997065059263030913083222523904000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (13945002051492165467882519302152032484380403766210698416903565084642738473126090019652380411393824653044168106587294578126146909413746446555531048352802016282483133795896426993386912203119064639513440190345434941408701716574507531/33272036329449778314940970209717004441237244904509798902045754967375455693667507476479692873249674937168694531536842861947689893888000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 4) (pow_nonneg pb0 1)) + (46764032321124851094864505996033051925920670952824721084892716555815773810848893461172451294731030058504103582549575088623047395742877424914121075554217619444334514836578431947059976353/90782222276492880105090908390730886206903719279152389122952868003382142961529573248698469451254845636418470889666904064000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 8) (pow_nonneg pb0 1)) + (4363385501013403559953467773535497000535246858225687349450509985640594153729141565506898685469743110098067800787744243528841737145049479257/9173994463960286046443283581208347763186259956673124494950355357547691504353939232280074212440502746218496000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 12) (pow_nonneg pb0 1)) + (804689189115736335008268299862958856574798566285725259085369833466638091370657277420869379200373667033862258717148257/78741026092188429277410080176234369152714099512155647711327741830758307971177533236046474372829937664000000000) * (mul_nonneg (pow_nonneg pa0 14) (pow_nonneg pb0 1)) + (5851660567630400935332154738158595450284049515989749919723610843303430701122994486991596461715040325559232388013077337684884194023873968758979369595553253170507781910292082396111898423845493919035990616792905865977392213332805365381848946811378568011382912743759916151631176071125517511/6243497100631984462763194459586332611497196285329942301718313919250743477639531240240612206126983942319653862242813245790895951358576570612580352000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (zero_le_one' ℝ) + (1426361107270177249895864442222575723262115691652307155505915468283017712656478691797244187343496150284757697222436426815499198167124790339632809771883640796107630592666140692779699741651149882400749022478177/95192059505795798249075804356719029735290274346856495576989426519514433938028833798827246303319001018053134531603363595812864000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 6) (pow_nonneg pb0 1)) + (1437359103669586424374584658922064044761912189944900097452888737138136514617303661676472646851721745156523038211105199149571802835450857638581206410274324239630817/86576673771374588112917812720042120177177161482956303713753574374563353501824925659845799876456113468569250955264000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 10) (pow_nonneg pb0 1)) + (28308998410724444269193854354359166817522508560675443573694608469036145479666988094348669889902258720540326497195417631898625029460153515055279667161894564065812368248345672661909076045578252363214608381506640220639179980545319726716529085344204325663/34888258766189130746367542778624217648974785312991266893511529560670685829443100319657170434260651146916601037100776540809660878173503488000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pa0 3) + (38338667789/1099511627776) * (pow_nonneg pa0 5) + (70797998761385/1099511627776) * (pow_nonneg pa0 9) + (731056663/137438953472) * (pow_nonneg pa0 4) + (464105775221983/1099511627776) * (pow_nonneg pa0 10) + (20761229/1099511627776) * (pow_nonneg pa0 1) + (3042376541183781/1099511627776) * (pow_nonneg pa0 11) + (12871199745/8589934592) * (pow_nonneg pa0 7) + (4985961989978577/274877906944) * (pow_nonneg pa0 12) + (45850306139/1099511627776) * (mul_nonneg (pow_nonneg pa0 3) (pow_nonneg pb0 1)) + (8171183490600489/68719476736) * (pow_nonneg pa0 13) + (68048577/549755813888) * (pow_nonneg pa0 2) + (6695622607157989/8589934592) * (pow_nonneg pa0 14) + (125661723823/549755813888) * (pow_nonneg pa0 6) + (2743260027697075/536870912) * (pow_nonneg pa0 15) + (10800030717609/1099511627776) * (pow_nonneg pa0 8) + (2247879255176481/67108864) * (pow_nonneg pa0 16)


theorem cert_ell5 (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 801846273840071038085759126959313536155111830921678126391746621442977444773402442057799416188001692295074462890625*m^16/102211695604069718983498660484250637643480816346654102227084559259777399890946582967745616506623001406982229600881181271903303354023936 + 82030309344252791620026509151847932087479471194033567917314232372683114554823779238649556643273830413818359375*m^15/779813351471479179256428989290242291591497927449448411766697382047862242820332206479992801716789256339891278082894754576898981888 - 2118754508209754171583322170426190662030625988739478799537099715773332056905620694798204184500980377197265625*m^14/95192059505795798249075804356719029735290274346856495576989426519514433938028833798827246303319001018053134531603363595812864 - 85961899517374095260607050120595916604712809903005176421418283172945205750114099384441991298675537109375*m^13/322781234760863573706989896500376484291213224103652939103832419567580952752105149328705669160017228929487896496593436672 + 19561198779705122198915586769568587497367362181524651874493531898919478548881634780725846587371826171875*m^12/709236111535100625821022721802585048491435306868378040023069281276422991886949791005456792587928481534519303825522688 + 3107386070447174555301495208859572033812649718995175863219786373211235071415598635034767193603515625*m^11/10822084221421823514114726590005265022147145185369537964219196796820419187728115707480724984557014183571156369408 - 8454735906802133160792736986139402525573900344200989957953255643267861619326885217309641357421875*m^10/440351734270093730229277611898000692632940477920309975757617057162289192208989083149443562197144131818487808 - 6787148107050895315660085091410308299424533448265274103008521514974224157743303581828994140625*m^9/40315405359200475790033961050231997006189618950223691628199803817348253681242897016855794878888928083968 + 159647259831242677951289353439198454241791518543501354712232791946035600013346585439812890625*m^8/19685256523047107319352520044058592288178524878038911927831935457689576992794383309011618593207484416 + 256182918509579668973070426029328698464418451816817232602860511629176714170234375*m^7/4475909127688079779398440233321387560904105357176129456964175792038435473112800379797504 - 8569344106518783412276391223700620382941816897781359524024598544296875*m^6/4070815637249397495359917441711684260466522898401426079512180687778195963904 - 215074458856294226861882315625243495158225596246870128125*m^5/19283256531107883306503545108093951230266435925393514023616512 + 22932166458283545277247672334865068749888280625*m^4/70152078591883340073776871970381584943484762062848 + 36641200587986362933589838301592125*m^3/31901471898837980949691369446728269824 - 870323340455995632625*m^2/4835703278458516698824704 - 48168445*m/1099511627776 + 1049/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 97/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 97/1000) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  have pe3 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  have pe4 : (0:ℝ) ≤ (m - 3/500) ^ 2 := sq_nonneg _
  have pe5 : (0:ℝ) ≤ (m - 3/1000) ^ 2 := sq_nonneg _
  have pe6 : (0:ℝ) ≤ (m - 31/250) ^ 2 := sq_nonneg _
  have pe7 : (0:ℝ) ≤ (m - 31/250) ^ 2 := sq_nonneg _
  have pe8 : (0:ℝ) ≤ (m - 139/1000) ^ 2 := sq_nonneg _
  have pe9 : (0:ℝ) ≤ (m - 139/1000) ^ 2 := sq_nonneg _
  have pe10 : (0:ℝ) ≤ (m - 93/1000) ^ 2 := sq_nonneg _
  have pe11 : (0:ℝ) ≤ (m - 93/1000) ^ 2 := sq_nonneg _
  have pe12 : (0:ℝ) ≤ (m - 111/1000) ^ 2 := sq_nonneg _
  have pe13 : (0:ℝ) ≤ (m - 111/1000) ^ 2 := sq_nonneg _
  have pe14 : (0:ℝ) ≤ (m - 143/1000) ^ 2 := sq_nonneg _
  have pe15 : (0:ℝ) ≤ (m - 143/1000) ^ 2 := sq_nonneg _
  have pe16 : (0:ℝ) ≤ (m) ^ 2 := sq_nonneg _
  have pe17 : (0:ℝ) ≤ (m - 131/1000) ^ 2 := sq_nonneg _
  have pe18 : (0:ℝ) ≤ (m - 131/1000) ^ 2 := sq_nonneg _
  have pe19 : (0:ℝ) ≤ (m - 1/200) ^ 2 := sq_nonneg _
  have pe20 : (0:ℝ) ≤ (m - 51/500) ^ 2 := sq_nonneg _
  have pe21 : (0:ℝ) ≤ (m - 51/500) ^ 2 := sq_nonneg _
  have pe22 : (0:ℝ) ≤ (m - 99/1000) ^ 2 := sq_nonneg _
  have pe23 : (0:ℝ) ≤ (m - 99/1000) ^ 2 := sq_nonneg _
  have pe24 : (0:ℝ) ≤ (m - 47/500) ^ 2 := sq_nonneg _
  have pe25 : (0:ℝ) ≤ (m - 47/500) ^ 2 := sq_nonneg _
  have pe26 : (0:ℝ) ≤ (m - 3/20) ^ 2 := sq_nonneg _
  have pe27 : (0:ℝ) ≤ (m - 3/20) ^ 2 := sq_nonneg _
  have pe28 : (0:ℝ) ≤ (m - 21/200) ^ 2 := sq_nonneg _
  have pe29 : (0:ℝ) ≤ (m - 21/200) ^ 2 := sq_nonneg _
  have pe30 : (0:ℝ) ≤ (m - 11/100) ^ 2 := sq_nonneg _
  have pe31 : (0:ℝ) ≤ (m - 11/100) ^ 2 := sq_nonneg _
  have pe32 : (0:ℝ) ≤ (m - 17/125) ^ 2 := sq_nonneg _
  have pe33 : (0:ℝ) ≤ (m - 17/125) ^ 2 := sq_nonneg _
  linear_combination (5672392619564596970306617465560957865536114686808479514571462389385308542814127795464551232642100699304459842008793298635003456773862804162676688995081280051825182140356108390027750418600136841206611369291994119476727069935829923706827766310770518447531262254395324026428296805070659346324209265362864087415897/16209045190941378744189093217543598246142368094697019140608036444104112544581672446873855659949624196438272994575393707743731058888327247296433104820757670652582741419537146576896000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (pow_nonneg pb0 1) + (479010789291878949847744564088177774111600728807349984082437966129732870963804158713122671460861042017800940725907714138682181643353111426075590743313482167634619501802755123516543504830584101024824301595559901779090652465199147562824211308110679806469546239611673495063523073484977988299/46374450276207100136344222691183848131587127956477219983886823017418229707474725094434325198983070935549563392378026126128380943932515851868914904081604968984363769777881088000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe16 1)) + (18778720748534584120592953947341695542610094891921333679682566945020111784798795368657976029753154162939563322553987963102744028599321276396211865523556590655951921337628897484958454673758864105163705952524272058496297402880887755978882381581431781267056940896796811/44226122165877437721580717745956276065432670551755161270033667581003408153032994360384297560675688682126582519891763807419186538631931163662829307633976906761516351488000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 2) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (1923917054131969492404648830868873580732083467837903050824953156725104549244622228975615218734586282743743306928201359642161817210159319353255493535377595992616781128612831522135741296668817443225082678852419515851374424554000685307873739827937/126531950471527398266546395528668239780710231452241405305958750479707931956385596352723019296671930357341525611567775175340232482810777178753364489461832733425664000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 4) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (63076618314823081870652173654102697607252299654448333409589270791294873218794597133437544927305025571786841766153193996184969829208694624813928234212711451417773410612380607883895417079528618372797910215964264722389672993/120670271369483373896166224983852615147314292385331540399512052993495876270661922791216868683502130849210286723678374457683784945307519129517902841054756864000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 6) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (1938749656358680401188093254979624158741347257719171859939221643820136699873072446488923791449876696638135366230163610818041071033255011408283904387720467516304208531903502853371611943514581620583777/115080138558848737617651200279095282695116321931201496505271962159629703779851839820114964183332568024835859988859533746417794175441283349531081048064000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 8) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (5885454872795825775103491930229970502094586143964501211603304470580738949558037863078342375103700330463397810288154363648760700504592865109724071476337090700340815539137939417/12194330274671844653834364178879555881830461494785043558043581873536608354764709453594945715091765512343073949692994620685343654997219864477696000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 10) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (1085387002378633970390272049875222276799308104874806128822296305405388641444687260259667194571239506070276148949121898739056459772803290326905795092328417/104664776298567392239102628335872652946924355938973800680534588682012057488329300958971511302781953440749803111302329622428982634520510464000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 12) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (3474166716008775459607473964236017649421586446246096474321361128388873207846562727783071855717877678908181217873967193124910114689736945632639/102211695604069718983498660484250637643480816346654102227084559259777399890946582967745616506623001406982229600881181271903303354023936) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 13) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (330585159602998630609243342710991236270349221013814126292656427910177992296650859202878423412135225597542322681266783877382224459688830909996450016663982512738279860403095118697083143903903377931262252085982369447337959576204388547405327521464091185765311/129568717282844055824943509021356277535447277007095199033301760491220922323338850665188371759792056685917722226245401779548398062398235831043445237208916719027879936000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 3) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (29778937006241788805958506303968813451398983001306357916962790698547063962735399295198225312749974541656033411547770389876460641177812375874492839684201182650902687456637768875694603516909988999370237500125647378030122076246296822358852922448849026249312877522818571716084950365712948439557735521799/15829145694278690179872161345257420162248406342477557754500035589945422406818039498900249667919554879334250971265032917718487362195632077437922953926521162746662833417516744704000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (117774490572796648594526375101370216845236027298255577183806598509079564047997071890919443847586715318303580296832516323123331175989050116419941648656765581068884842266841236413048394416606836168936239376704277/39280687294753702440158276361931189826599704552516777473799496417153605556856094658599241107910849885810640209530720852110607078550624716639942331072512000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 7) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (254319605512312361298024377200516670958962553270516343737654251976292068009535216181388623981694259612050606676140795328631491686581047990440859609759030283953026751/107176730929733009652841091415933596617650540481509171896867418810380346868049204181986827574048720323327798385973585533367278217749002715136000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 11) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (11084724146965758379184484060533965595049614791285715228005484683009568208015616115700745053867919304936595785129882423285230421137346489800359563562971370723580812013658018017126344166717254012406885827212338477486987069281124772479/123566357882350974869674214383465077910849835402579497369100342265339777301157808938206073531906181989591333605046655444668195783994899588626332509240071028736000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 5) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (3163029602823521922404471242266514630442037632490865141304239719364954529379867792541031900718951738796642769558065192573534437068120196696706458104927178918676164849176564320753199477267841110997283010092037762377041035710908625576087039061163147400138152098114760826182734933/45287549097858496226898654971859226691003054644997285140514475602947489948705786225033520702131905210497620500369166138797247015559097511590737211017192352523792743923712000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (10342761786093796636046037490341732890082097719548721644972230947056958209173048557028656123300819605126483123974669407682883114961661134228432575746330028421867812087849428317856309237759/112382947811375720329737500272553987006949533135938961430929650546513382597511562324331019710285710961753769520370638424236127124454378271026446336000000000000000000000000000000000000) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 9) (pow_nonneg pb0 1)) (pow_nonneg pe16 1)) + (15718699311702423675922603267702710134083242525404756413682294012808067289093576801919107930907129604482627427295865986373562233638219012870646551434055108787149187432655898649836433525517497132318855359652479710124370626057629749078230393655478981018171372371372888966083158046734184689284669033147013390802259158895450809/16598062275523971834049631454764644604049784928969747599982629318762611245651632585598828195788415177152791546445203156729580604301647101231547499336455854748244727213606038094741504000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000) * (zero_le_one' ℝ) + (5266839/274877906944) * (pow_nonneg pa0 1) + (10959278435263/1099511627776) * (pow_nonneg pa0 8) + (255029241313/1099511627776) * (pow_nonneg pa0 6) + (71841923543827/1099511627776) * (pow_nonneg pa0 9) + (5934689433/1099511627776) * (pow_nonneg pa0 4) + (235474534613057/549755813888) * (pow_nonneg pa0 10) + (138103923/1099511627776) * (pow_nonneg pa0 2) + (1543618369778475/549755813888) * (pow_nonneg pa0 11) + (38903975935/1099511627776) * (pow_nonneg pa0 5) + (2529740291697593/137438953472) * (pow_nonneg pa0 12) + (26121974185/17179869184) * (pow_nonneg pa0 7) + (4145834274022425/34359738368) * (pow_nonneg pa0 13) + (905319773/1099511627776) * (pow_nonneg pa0 3) + (6794350346582417/8589934592) * (pow_nonneg pa0 14) + (5567419436102491/1073741824) * (pow_nonneg pa0 15) + (285128062253617/8388608) * (pow_nonneg pa0 16)


theorem cert_ell2_nonneg (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 293487*m^2/131072 - 3154429*m/1048576 + 1047527/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (5156243330233592936057149/9007199254740992000000000) * (zero_le_one' ℝ) + (255437050818269/140737488355328) * (pow_nonneg pe1 1) + (22145151969117/8796093022208) * (pow_nonneg pb0 1) + (4552937769475157/70368744177664000) * (pow_nonneg pa0 1) + (59692215882019/140737488355328) * (pow_nonneg pa0 2)


theorem cert_ell3_nonneg (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -178421*m^2/1048576 - 201239*m/262144 + 1047527/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (48922509836122231999605859/57646075230342348800000000) * (zero_le_one' ℝ) + (277382789862735/281474976710656) * (pow_nonneg pb0 1) + (1727932401178237031033281/18014398509481984000000000) * (pow_nonneg pa0 1) + (14055130751073/17592186044416) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (11061723095137/17592186044416) * (pow_nonneg pa0 2)


theorem cert_ell4_nonneg (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -25283*m^2/262144 - 6315*m/32768 + 1047527/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (269527494006153419938862189/288230376151711744000000000) * (zero_le_one' ℝ) + (117884524535437/281474976710656) * (pow_nonneg pb0 1) + (30462887792906641045785553/288230376151711744000000000) * (pow_nonneg pa0 1) + (222162004929649/281474976710656) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (195014590393457/281474976710656) * (pow_nonneg pa0 2)


theorem cert_ell5_nonneg (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ -3625*m^2/131072 - 50585*m/1048576 + 1047527/1048576 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (138057113211005804972093629/144115188075855872000000000) * (zero_le_one' ℝ) + (37859085044957/140737488355328) * (pow_nonneg pb0 1) + (15603671025351838080579829/144115188075855872000000000) * (pow_nonneg pa0 1) + (103782499649557/140737488355328) * (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 1)) + (99890185537557/140737488355328) * (pow_nonneg pa0 2)


theorem cert_phihat (m : ℝ)
    (l0 : (0 : ℝ) ≤ m) (u0 : m ≤ (156208249503/1024000000000 : ℝ))
    : 0 ≤ 4799228783788073625*m^9/2361183241434822606848 + 123062438543434350805*m^8/9444732965739290427392 - 14153306651771911263011*m^7/151115727451828646838272 - 146343123300172654951353*m^6/302231454903657293676544 + 916899599262149274651339*m^5/604462909807314587353088 + 3632134849946392904174741*m^4/1208925819614629174706176 - 7336790321829647991044629*m^3/604462909807314587353088 + 1880257225055447767702545*m^2/604462909807314587353088 - 9293338783248922852815*m/37778931862957161709568 + 8252949182755634578913/1208925819614629174706176 := by
  have pa0 : (0:ℝ) ≤ m - 0 := by linarith
  have pb0 : (0:ℝ) ≤ 156208249503/1024000000000 - m := by linarith
  have pe0 : (0:ℝ) ≤ (m - 61/1000) ^ 2 := sq_nonneg _
  have pe1 : (0:ℝ) ≤ (m - 61/1000) ^ 2 := sq_nonneg _
  have pe2 : (0:ℝ) ≤ (m - 153/1000) ^ 2 := sq_nonneg _
  linear_combination (267828988280291072054135204895266771626561434482572046239/154742504910672534362390528000000000000000000000000000000000000) * (zero_le_one' ℝ) + (2531716787561391/281474976710656) * (mul_nonneg (pow_nonneg pb0 1) (pow_nonneg pe1 1)) + (23585232867679/281474976710656) * (mul_nonneg (pow_nonneg pb0 2) (pow_nonneg pe1 1)) + (444983972205281/140737488355328) * (pow_nonneg pb0 4) + (34291273237372633751556568718379414441323705778657/3022314549036572936765440000000000000000000000000000000) * (pow_nonneg pa0 1) + (73716867890025/70368744177664) * (mul_nonneg (mul_nonneg (pow_nonneg pa0 1) (pow_nonneg pb0 3)) (pow_nonneg pe2 1)) + (17734184065128630618947314125569462378671042282231/1511157274518286468382720000000000000000000000000000) * (pow_nonneg pa0 2) + (85565774362151/70368744177664) * (mul_nonneg (pow_nonneg pa0 2) (pow_nonneg pb0 1)) + (1473586359623480271035002710988366594105292273/3022314549036572936765440000000000000000000000000) * (pow_nonneg pa0 3) + (9433473355740120076225750803412227/2951479051793528258560000000000000000) * (pow_nonneg pa0 4) + (33855021311243524737882374319/47223664828696452136960000000) * (pow_nonneg pa0 5) + (81076240971435015189944845059/590295810358705651712000000000) * (pow_nonneg pa0 6) + (786082712707839/281474976710656) * (mul_nonneg (pow_nonneg pa0 6) (pow_nonneg pb0 1)) + (53148326684983779599353950013/59029581035870565171200000000) * (pow_nonneg pa0 7) + (207431463878655/17592186044416) * (mul_nonneg (pow_nonneg pa0 7) (pow_nonneg pb0 1)) + (108876865295569267604756763401/18446744073709551616000000000) * (pow_nonneg pa0 8) + (1361253052367159/35184372088832) * (mul_nonneg (pow_nonneg pa0 8) (pow_nonneg pb0 1)) + (91356945189676339471001/2361183241434822606848) * (pow_nonneg pa0 9)



/-- `t̄ = u(1/2 − b)`. -/
def tbar : ℝ := 156208249503/1024000000000

/-- `nd q = 1 − 4q(1 − Ef(q,q))`, written out (`= HsChain.nd`). -/
def ndq (q : ℝ) : ℝ := 1 - 4 * q * (1 - ((q + q) / 2 - q * q / 3))

def mu0 (m : ℝ) : ℝ := m / 4 + 9775/65536 * m ^ 2
def mu1 (m : ℝ) : ℝ := 4187/16384 * mu0 m
def mu2 (m : ℝ) : ℝ := 515/2048 * mu1 m
def mu3 (m : ℝ) : ℝ := 8207/32768 * mu2 m

def ell0 (m : ℝ) : ℝ := 293487/131072*m^2 - 3154429/1048576*m + 1047527/1048576
def ell1 (m : ℝ) : ℝ := -178421/1048576*m^2 - 201239/262144*m + 1047527/1048576
def ell2 (m : ℝ) : ℝ := -25283/262144*m^2 - 6315/32768*m + 1047527/1048576
def ell3 (m : ℝ) : ℝ := -3625/131072*m^2 - 50585/1048576*m + 1047527/1048576

/-- `φ̂(m)`. -/
def phihat (m : ℝ) : ℝ := 259307/262144 + (-1507563/262144) * m + 10548925/1048576 * m ^ 2

theorem ell0_le (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    ell0 m ≤ ndq (mu0 m) ^ 2 * (1 - 2 * mu0 m) ^ 2 := by
  have h := cert_ell2 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [ndq, mu0, mu1, mu2, mu3, ell0, ell1, ell2, ell3]; ring

theorem ell0_nonneg (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) : 0 ≤ ell0 m := by
  have h := cert_ell2_nonneg m l0 u0
  convert h using 1
  simp only [ell0, ell1, ell2, ell3]; ring

theorem ell1_le (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    ell1 m ≤ ndq (mu1 m) ^ 2 * (1 - 2 * mu1 m) ^ 2 := by
  have h := cert_ell3 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [ndq, mu0, mu1, mu2, mu3, ell0, ell1, ell2, ell3]; ring

theorem ell1_nonneg (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) : 0 ≤ ell1 m := by
  have h := cert_ell3_nonneg m l0 u0
  convert h using 1
  simp only [ell0, ell1, ell2, ell3]; ring

theorem ell2_le (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    ell2 m ≤ ndq (mu2 m) ^ 2 * (1 - 2 * mu2 m) ^ 2 := by
  have h := cert_ell4 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [ndq, mu0, mu1, mu2, mu3, ell0, ell1, ell2, ell3]; ring

theorem ell2_nonneg (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) : 0 ≤ ell2 m := by
  have h := cert_ell4_nonneg m l0 u0
  convert h using 1
  simp only [ell0, ell1, ell2, ell3]; ring

theorem ell3_le (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    ell3 m ≤ ndq (mu3 m) ^ 2 * (1 - 2 * mu3 m) ^ 2 := by
  have h := cert_ell5 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [ndq, mu0, mu1, mu2, mu3, ell0, ell1, ell2, ell3]; ring

theorem ell3_nonneg (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) : 0 ≤ ell3 m := by
  have h := cert_ell5_nonneg m l0 u0
  convert h using 1
  simp only [ell0, ell1, ell2, ell3]; ring

theorem mu_start (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) : m ≤ 4 * mu0 m * (1 - 2 * mu0 m) := by
  have h := cert_mu2 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [mu0]; ring

theorem mu_rec0 (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    mu0 m ≤ 4 * mu1 m * (1 - 2 * mu1 m) := by
  have h := cert_mu3 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [mu0, mu1, mu2, mu3]; ring

theorem mu_rec1 (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    mu1 m ≤ 4 * mu2 m * (1 - 2 * mu2 m) := by
  have h := cert_mu4 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [mu0, mu1, mu2, mu3]; ring

theorem mu_rec2 (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    mu2 m ≤ 4 * mu3 m * (1 - 2 * mu3 m) := by
  have h := cert_mu5 m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [mu0, mu1, mu2, mu3]; ring

theorem phihat_le (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    phihat m ≤ (1 - 2 * m) * (ell0 m * (ell1 m * (ell2 m * ell3 m))) := by
  have h := cert_phihat m l0 u0
  rw [← sub_nonneg]
  convert h using 1
  simp only [phihat, ell0, ell1, ell2, ell3]; ring

theorem mu_bounds (m : ℝ) (l0 : 0 ≤ m) (u0 : m ≤ tbar) :
    (0 ≤ mu0 m ∧ mu0 m ≤ 1 / 4) ∧ (0 ≤ mu1 m ∧ mu1 m ≤ 1 / 4) ∧ (0 ≤ mu2 m ∧ mu2 m ≤ 1 / 4) ∧
      (0 ≤ mu3 m ∧ mu3 m ≤ 1 / 4) := by
  unfold tbar at u0
  have a0 : 0 ≤ mu0 m := by unfold mu0; positivity
  have a1 : mu0 m ≤ 1 / 20 := by unfold mu0; nlinarith
  refine ⟨⟨a0, by linarith⟩, ?_, ?_, ?_⟩
  · unfold mu1; constructor <;> nlinarith
  · unfold mu2 mu1; constructor <;> nlinarith
  · unfold mu3 mu2 mu1; constructor <;> nlinarith

theorem ndq_nonneg {q : ℝ} (h0 : 0 ≤ q) (h1 : q ≤ 1 / 4) : 0 ≤ ndq q := by
  unfold ndq; nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0]

theorem tbar_quad : (53 / 125 : ℝ) ≤ 4 * tbar * (1 - 2 * tbar) := by unfold tbar; norm_num

end HsCert

end

#print axioms HsCert.ell0_le
#print axioms HsCert.ell0_nonneg
#print axioms HsCert.ell3_le
#print axioms HsCert.mu_start
#print axioms HsCert.mu_rec2
#print axioms HsCert.phihat_le
#print axioms HsCert.mu_bounds
#print axioms HsCert.ndq_nonneg
#print axioms HsCert.tbar_quad

-- ===== new part : OneVarStage.part.lean =====
/-! # T1b: the one-variable stage of the chain (`Kal_ge` with all its hypotheses paid)

Paper: For every `θ′` with `0 < ω(θ′)` and `x = xs(sQ θ′) ∈ [0, 53/125]⁴`, and
an index `i` of the largest `t_i = tx θ′ i`:
`(199/200)·n̂² ·φ̂(t_i)/(4T) ≤ Kal 4 θ′`, `n̂ = 1 − T + (11/24)T(T − 2t_i)`, `T = Σ t`.
The hypotheses of `HsChain.Kal_ge` are paid by: `t_i ≤ t̄` (`quad_mono`, `53/125 ≤ 4t̄(1 − 2t̄)`),
the chain `μ_j` of `HsCert` (`mu_start`, `mu_rec*`, `mu_bounds`, `ndq_nonneg`; `μ_j = μ₃` for
`j ≥ 3`, a fixed point region), `n̂ ≥ 0` (from `T ≤ 4t_i ≤ 4t̄`, no certificate), and
`e_j = ℓ_j(t_i)` (`ell*_le`, `ell*_nonneg`), then `φ̂ ≤ (1 − 2m)Πℓ_j` (`phihat_le`). -/

noncomputable section

namespace HsChain

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB
open scoped Real

theorem nd_eq_ndq (q : ℝ) : nd q = HsCert.ndq q := by
  unfold nd HsCert.ndq Ef; ring

set_option maxHeartbeats 2000000 in
/-- **T1b**. -/
theorem kal_onevar (θ' : Fin 4 → ℝ) (hω : 0 < omT θ') (hB : ∀ ν, xs (sQ θ') ν ≤ 53 / 125)
    (i : Fin 4) (hi : ∀ ν, tx θ' ν ≤ tx θ' i) :
    (199 / 200) * (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) *
        ((∑ ν, tx θ' ν) - 2 * tx θ' i)) ^ 2 * HsCert.phihat (tx θ' i) / (4 * ∑ ν, tx θ' ν) ≤
      Kal 4 θ' := by
  set m := tx θ' i with hm_def
  obtain ⟨ex, ht0, ht1⟩ := xt_rel θ' i
  have hm0 : 0 ≤ m := ht0
  have hmt : m ≤ HsCert.tbar := by
    have htb : HsCert.tbar ≤ 1 / 4 := by unfold HsCert.tbar; norm_num
    have htb0 : 0 ≤ HsCert.tbar := by unfold HsCert.tbar; norm_num
    apply quad_mono hm0 htb ht1 htb0
    have := hB i
    rw [ex] at this
    linarith [HsCert.tbar_quad]
  have hmt' : m ≤ 0.1526 := by
    have : HsCert.tbar ≤ 0.1526 := by unfold HsCert.tbar; norm_num
    linarith
  obtain ⟨b0, b1, b2, b3⟩ := HsCert.mu_bounds m hm0 hmt
  -- the chain
  set μ : ℕ → ℝ := fun j => if j = 0 then HsCert.mu0 m else if j = 1 then HsCert.mu1 m
    else if j = 2 then HsCert.mu2 m else HsCert.mu3 m with hμdef
  have hμ : ∀ j, 0 ≤ μ j ∧ μ j ≤ 1 / 4 ∧ 0 ≤ nd (μ j) := by
    intro j
    have key : ∀ q : ℝ, 0 ≤ q ∧ q ≤ 1 / 4 → 0 ≤ q ∧ q ≤ 1 / 4 ∧ 0 ≤ nd q := fun q hq =>
      ⟨hq.1, hq.2, by rw [nd_eq_ndq]; exact HsCert.ndq_nonneg hq.1 hq.2⟩
    simp only [hμdef]
    split_ifs
    · exact key _ b0
    · exact key _ b1
    · exact key _ b2
    · exact key _ b3
  have hrec : ∀ j, μ j ≤ 4 * μ (j + 1) * (1 - 2 * μ (j + 1)) := by
    intro j
    rcases j with _ | _ | _ | j
    · simp only [hμdef]; simpa using HsCert.mu_rec0 m hm0 hmt
    · simp only [hμdef]; simpa using HsCert.mu_rec1 m hm0 hmt
    · simp only [hμdef]; simpa using HsCert.mu_rec2 m hm0 hmt
    · simp only [hμdef]
      have h1 : j + 3 ≠ 0 := by omega
      have h2 : j + 3 ≠ 1 := by omega
      have h3 : j + 3 ≠ 2 := by omega
      have h1' : j + 1 + 3 ≠ 0 := by omega
      have h2' : j + 1 + 3 ≠ 1 := by omega
      have h3' : j + 1 + 3 ≠ 2 := by omega
      simp only [show j + 1 + 1 + 1 = j + 3 by ring, show j + 3 + 1 = j + 1 + 3 by ring,
        if_neg h1, if_neg h2, if_neg h3, if_neg h1', if_neg h2', if_neg h3']
      nlinarith [b3.1, b3.2]
  have hstart : m ≤ 4 * μ 0 * (1 - 2 * μ 0) := by
    simp only [hμdef, if_true]; exact HsCert.mu_start m hm0 hmt
  -- n̂ ≥ 0
  have hT0 : 0 ≤ ∑ ν, tx θ' ν := Finset.sum_nonneg fun ν _ => (xt_rel θ' ν).2.1
  have hT4 : ∑ ν, tx θ' ν ≤ 4 * m := by
    have := Finset.sum_le_sum fun ν (_ : ν ∈ (univ : Finset (Fin 4))) => hi ν
    simpa using this
  have hι : 0 ≤ 1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m) := by
    nlinarith [sq_nonneg ((∑ ν, tx θ' ν) - m)]
  -- the levels
  have lev : ∀ (j : ℕ) (q : ℝ) (e : ℝ), μ j = q → e ≤ HsCert.ndq q ^ 2 * (1 - 2 * q) ^ 2 → 0 ≤ e →
      0 ≤ e ∧ e ≤ nd (μ j) ^ 2 * (1 - 2 * μ j) ^ 2 := by
    intro j q e hq h1 h0
    rw [hq, nd_eq_ndq]; exact ⟨h0, h1⟩
  have e0 := lev 0 _ _ (by simp [hμdef]) (HsCert.ell0_le m hm0 hmt) (HsCert.ell0_nonneg m hm0 hmt)
  have e1 := lev 1 _ _ (by simp [hμdef]) (HsCert.ell1_le m hm0 hmt) (HsCert.ell1_nonneg m hm0 hmt)
  have e2 := lev 2 _ _ (by simp [hμdef]) (HsCert.ell2_le m hm0 hmt) (HsCert.ell2_nonneg m hm0 hmt)
  have e3 := lev 3 _ _ (by simp [hμdef]) (HsCert.ell3_le m hm0 hmt) (HsCert.ell3_nonneg m hm0 hmt)
  have hK := Kal_ge θ' hω hi μ hμ hrec hstart hι e0 e1 e2 e3
  refine le_trans ?_ hK
  have hph := HsCert.phihat_le m hm0 hmt
  have hT : 0 ≤ 4 * ∑ ν, tx θ' ν := by linarith
  apply div_le_div_of_nonneg_right _ hT
  set N := 1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) * ((∑ ν, tx θ' ν) - 2 * m) with hN
  have hn2 : 0 ≤ N ^ 2 := sq_nonneg _
  have h199 : (199 / 200 : ℝ) * HsCert.phihat m ≤
      (1 - 2 * m) * (HsCert.ell0 m * (HsCert.ell1 m * (HsCert.ell2 m * (HsCert.ell3 m * (995 / 1000))))) := by
    calc (199 / 200 : ℝ) * HsCert.phihat m
        ≤ (199 / 200) * ((1 - 2 * m) * (HsCert.ell0 m * (HsCert.ell1 m * (HsCert.ell2 m * HsCert.ell3 m)))) :=
          mul_le_mul_of_nonneg_left hph (by norm_num)
      _ = (1 - 2 * m) * (HsCert.ell0 m * (HsCert.ell1 m * (HsCert.ell2 m * (HsCert.ell3 m * (995 / 1000))))) := by
          ring
  calc (199 / 200) * N ^ 2 * HsCert.phihat m = N ^ 2 * ((199 / 200) * HsCert.phihat m) := by ring
    _ ≤ N ^ 2 * ((1 - 2 * m) * (HsCert.ell0 m * (HsCert.ell1 m * (HsCert.ell2 m * (HsCert.ell3 m * (995 / 1000)))))) :=
        mul_le_mul_of_nonneg_left h199 hn2
    _ = N ^ 2 * (1 - 2 * m) * (HsCert.ell0 m * (HsCert.ell1 m * (HsCert.ell2 m * (HsCert.ell3 m * (995 / 1000))))) := by
        ring

end HsChain

end

#print axioms HsChain.kal_onevar
-- ===== new part : HsSplit.part.lean =====
/-! # T1d–T1h: `hS_split` with `c₀ = 3/100`, given named polynomial inequalities

The fit-dependent polynomials `r`, `A₂`, `Q₃` are the
fit earlier data files (`npair` = the smallest pair itself, `k̃` fixed to the
`certs_all_v1` one, so T1b `kal_onevar` and T1c `kal_ktil` apply unchanged), rationalised with
denominator `2^20` exactly as in the certificate scripts (a generating script).

The polynomial inequalities are hypotheses (named `Prop`s below):
* `HUge`, `HUle`, `HK0`, `HKc`: word for word the statements of `HsCert.u_ge`, `u_le`,
  `ktil3_nonneg`, `ktil3_le_ceil` (closed in `GlueKtil.lean`).
* `HR` (`r ≥ 0`), `HA` (`A₂ ≤ A_p`, `p` the two smallest), `HM` (`main`), `HF` (the final
  vertex sum, all `ν` and all L-sets): on the set `B` = the box `[0, 53/125]⁴` with a coordinate
  `≥ 19/250` (every kept vertex lies in `B`; region I goes to `regionI_lb`).
The chain itself (T1d `A ≤ nfun²`, T1e the vertex bound = `box_of_sub`'s `HV`, T1f the vertex
sum, the region split, `lower_side_c`, `bracket_Qpos_split`) is proved here. -/

noncomputable section

namespace HsCert

/-- `u(x)` (same text as in `KtilCerts.part.lean`). -/
def upoly (x : ℝ) : ℝ := 1/65536 + 291077/1048576 * x + (-134921/1048576) * x ^ 2 + 398689/524288 * x ^ 3

/-- `k̃₃` (same text as in `KtilCerts.part.lean`, `certs_all_v1`). -/
def ktil3 (x0 x1 x2 x3 : ℝ) : ℝ := 45387/131072*x3^2 + 397397/524288*x2*x3 - 63733/524288*x2^2 + 397397/524288*x1*x3 + 165109/1048576*x1*x2 - 63733/524288*x1^2 + 397397/524288*x0*x3 + 165109/1048576*x0*x2 + 165109/1048576*x0*x1 - 63733/524288*x0^2 - 485493/262144*x3 - 485849/1048576*x2 - 485849/1048576*x1 - 485849/1048576*x0 + 503807/524288

/-- `r(x)` (symmetric). -/
def rpoly (x0 x1 x2 x3 : ℝ) : ℝ := -167877/1048576*x3^2 + 992471/1048576*x2*x3 - 167877/1048576*x2^2 + 992471/1048576*x1*x3 + 992471/1048576*x1*x2 - 167877/1048576*x1^2 + 992471/1048576*x0*x3 + 992471/1048576*x0*x2 + 992471/1048576*x0*x1 - 167877/1048576*x0^2 - 1191243/1048576*x3 - 1191243/1048576*x2 - 1191243/1048576*x1 - 1191243/1048576*x0 + 270255/262144

/-- `A₂(x₀, x₁, x₂, x₃)` (`x₃ = x_ν` distinguished). -/
def A2 (x0 x1 x2 x3 : ℝ) : ℝ := 1180139/1048576*x3^3 - 2197233/1048576*x2*x3^2 - 1143821/524288*x2^2*x3 + 489519/524288*x2^3 - 2197233/1048576*x1*x3^2 - 545241/1048576*x1*x2*x3 - 850289/524288*x1*x2^2 - 1143821/524288*x1^2*x3 - 850289/524288*x1^2*x2 + 489519/524288*x1^3 - 2197233/1048576*x0*x3^2 - 545241/1048576*x0*x2*x3 - 850289/524288*x0*x2^2 - 545241/1048576*x0*x1*x3 - 895975/524288*x0*x1*x2 - 850289/524288*x0*x1^2 - 1143821/524288*x0^2*x3 - 850289/524288*x0^2*x2 - 850289/524288*x0^2*x1 + 489519/524288*x0^3 + 555583/1048576*x3^2 + 3707371/1048576*x2*x3 + 680313/1048576*x2^2 + 3707371/1048576*x1*x3 + 3421431/1048576*x1*x2 + 680313/1048576*x1^2 + 3707371/1048576*x0*x3 + 3421431/1048576*x0*x2 + 3421431/1048576*x0*x1 + 680313/1048576*x0^2 - 535651/262144*x3 - 2154529/1048576*x2 - 2154529/1048576*x1 - 2154529/1048576*x0 + 16409/16384

/-- `Q₃(x₀, x₁, x₂, x₃)` (`x₃ = x_ν` distinguished). -/
def Q3 (x0 x1 x2 x3 : ℝ) : ℝ := 185641/1048576*x3^3 - 2002745/1048576*x2*x3^2 - 1071785/1048576*x2^2*x3 + 318325/1048576*x2^3 - 2002745/1048576*x1*x3^2 - 3880799/1048576*x1*x2*x3 - 797297/1048576*x1*x2^2 - 1071785/1048576*x1^2*x3 - 797297/1048576*x1^2*x2 + 318325/1048576*x1^3 - 2002745/1048576*x0*x3^2 - 3880799/1048576*x0*x2*x3 - 797297/1048576*x0*x2^2 - 3880799/1048576*x0*x1*x3 - 627415/262144*x0*x1*x2 - 797297/1048576*x0*x1^2 - 1071785/1048576*x0^2*x3 - 797297/1048576*x0^2*x2 - 797297/1048576*x0^2*x1 + 318325/1048576*x0^3 + 1411903/1048576*x3^2 + 3989723/1048576*x2*x3 + 453153/1048576*x2^2 + 3989723/1048576*x1*x3 + 42827/16384*x1*x2 + 453153/1048576*x1^2 + 3989723/1048576*x0*x3 + 42827/16384*x0*x2 + 42827/16384*x0*x1 + 453153/1048576*x0^2 - 1054153/524288*x3 - 373623/262144*x2 - 373623/262144*x1 - 373623/262144*x0 + 638935/1048576


end HsCert

namespace HsSplit

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB HsChain
open scoped Real

/-! ## The hypotheses -/

/-- = `HsCert.u_ge`. -/
def HUge : Prop := ∀ x : ℝ, 0 ≤ x → x ≤ 53 / 125 → x ≤ 4 * HsCert.upoly x * (1 - 2 * HsCert.upoly x)
/-- = `HsCert.u_le`. -/
def HUle : Prop := ∀ x : ℝ, 0 ≤ x → x ≤ 53 / 125 → HsCert.upoly x ≤ 1 / 4
/-- = `HsCert.ktil3_nonneg`. -/
def HK0 : Prop := ∀ x0 x1 x2 x3 : ℝ, 0 ≤ x0 → x0 ≤ 53 / 125 → 0 ≤ x1 → x1 ≤ 53 / 125 →
  0 ≤ x2 → x2 ≤ 53 / 125 → 0 ≤ x3 → x3 ≤ 53 / 125 → x0 ≤ x3 → x1 ≤ x3 → x2 ≤ x3 →
  0 ≤ HsCert.ktil3 x0 x1 x2 x3
/-- = `HsCert.ktil3_le_ceil`. -/
def HKc : Prop := ∀ t0 t1 t2 t3 : ℝ, 0 ≤ t0 → t0 ≤ HsCert.tbar → 0 ≤ t1 → t1 ≤ HsCert.tbar →
  0 ≤ t2 → t2 ≤ HsCert.tbar → 0 ≤ t3 → t3 ≤ HsCert.tbar → t0 ≤ t3 → t1 ≤ t3 → t2 ≤ t3 →
  HsCert.ktil3 (4 * t0 * (1 - 2 * t0)) (4 * t1 * (1 - 2 * t1)) (4 * t2 * (1 - 2 * t2))
      (4 * t3 * (1 - 2 * t3)) ≤
    (199 / 200) * (1 - (t0 + t1 + t2 + t3) + (11 / 24) * (t0 + t1 + t2 + t3) *
      ((t0 + t1 + t2 + t3) - 2 * t3)) ^ 2 * HsCert.phihat t3

/-- The others of an index, in increasing order. -/
def oa : Fin 4 → Fin 4 := ![1, 0, 0, 0]
def ob : Fin 4 → Fin 4 := ![2, 2, 1, 1]
def oc : Fin 4 → Fin 4 := ![3, 3, 3, 2]

theorem sum_o (i : Fin 4) (f : Fin 4 → ℝ) : ∑ ν, f ν = f (oa i) + f (ob i) + f (oc i) + f i := by
  rw [Fin.sum_univ_four]
  fin_cases i <;> (simp [oa, ob, oc]; try ring)

/-- `Q_ν(x)`, `A₂` with `ν` distinguished, `k̃_i`, `r`, `U`. -/
def Qv (ν : Fin 4) (x : Fin 4 → ℝ) : ℝ := HsCert.Q3 (x (oa ν)) (x (ob ν)) (x (oc ν)) (x ν)
def Av (ν : Fin 4) (x : Fin 4 → ℝ) : ℝ := HsCert.A2 (x (oa ν)) (x (ob ν)) (x (oc ν)) (x ν)
def kv (i : Fin 4) (x : Fin 4 → ℝ) : ℝ := HsCert.ktil3 (x (oa i)) (x (ob i)) (x (oc i)) (x i)
def rv (x : Fin 4 → ℝ) : ℝ := HsCert.rpoly (x 0) (x 1) (x 2) (x 3)
def Uv (x : Fin 4 → ℝ) : ℝ := ∑ k, HsCert.upoly (x k)

/-- The set `B`: the box `[0, 53/125]⁴` with a coordinate `≥ 19/250`. -/
def inB (x : Fin 4 → ℝ) : Prop := (∀ k, 0 ≤ x k ∧ x k ≤ 53 / 125) ∧ ∃ k, 19 / 250 ≤ x k

/-- `r ≥ 0` on `B`. -/
def HR : Prop := ∀ x : Fin 4 → ℝ, inB x → 0 ≤ rv x
/-- `A₂ ≤ A_p = 2r·n_p − r²`, `n_p = 1 − X(1 − Ef(x_ρ, x_σ))`, `ρ, σ` the two smallest, on `B`. -/
def HA : Prop := ∀ (x : Fin 4 → ℝ) (ν ρ σ : Fin 4), inB x → ρ ≠ σ →
  (∀ k, k ≠ ρ → k ≠ σ → x ρ ≤ x k ∧ x σ ≤ x k) →
  Av ν x ≤ 2 * rv x * (1 - (∑ k, x k) * (1 - Ef (x ρ) (x σ))) - rv x ^ 2
/-- `main`: `4U·Q_ν ≤ A₂(1 − 2x_ν)k̃_i`, `i` a largest coordinate, on `B`. -/
def HM : Prop := ∀ (x : Fin 4 → ℝ) (ν i : Fin 4), inB x → (∀ k, x k ≤ x i) →
  4 * Uv x * Qv ν x ≤ Av ν x * (1 - 2 * x ν) * kv i x

/-- The kept vertices: the L coordinates (`a_j ≤ 19/250`) unflipped. -/
def keep (a : Fin 4 → ℝ) (z : Fin 4 → Bool) : Finset (Fin 4 → Bool) :=
  univ.filter fun ζ => ∀ j, a j ≤ 19 / 250 → ζ j = z j
/-- The vertex `ζ` of the box `Π{a_j, ½ − a_j}` (`z` the nearest alias). -/
def vtx (a : Fin 4 → ℝ) (z ζ : Fin 4 → Bool) : Fin 4 → ℝ :=
  fun j => if ζ j = z j then a j else 1 / 2 - a j
/-- The final inequality: `3/100 ≤ Y·Σ_{kept} Q_ν`, `Y = Σ a(1 − 2a)`. -/
def HF : Prop := ∀ (ν : Fin 4) (a : Fin 4 → ℝ) (z : Fin 4 → Bool), (∀ j, 0 ≤ a j ∧ a j ≤ 1 / 4) →
  (∃ j, 19 / 250 < a j) →
  (3 / 100 : ℝ) ≤ (∑ j, a j * (1 - 2 * a j)) * ∑ ζ ∈ keep a z, Qv ν (vtx a z ζ)

/-! ## T1c with the certificates as hypotheses (the proof of `kal_ktil`) -/

theorem tx_le_tbar' (θ' : Fin 4 → ℝ) (hB : ∀ ν, xs (sQ θ') ν ≤ 53 / 125) (ν : Fin 4) :
    tx θ' ν ≤ HsCert.tbar := by
  obtain ⟨ex, ht0, ht1⟩ := xt_rel θ' ν
  have htb : HsCert.tbar ≤ 1 / 4 := by unfold HsCert.tbar; norm_num
  have htb0 : 0 ≤ HsCert.tbar := by unfold HsCert.tbar; norm_num
  apply quad_mono ht0 htb ht1 htb0
  have := hB ν
  rw [ex] at this
  linarith [HsCert.tbar_quad]

theorem kal_ktil_of (hUge : HUge) (hUle : HUle) (hK0 : HK0) (hKc : HKc)
    (θ' : Fin 4 → ℝ) (hω : 0 < omT θ') (hB : ∀ ν, xs (sQ θ') ν ≤ 53 / 125)
    (a b c i : Fin 4) (hperm : ∀ f : Fin 4 → ℝ, ∑ ν, f ν = f a + f b + f c + f i)
    (hi : ∀ ν, tx θ' ν ≤ tx θ' i) :
    0 ≤ HsCert.ktil3 (xs (sQ θ') a) (xs (sQ θ') b) (xs (sQ θ') c) (xs (sQ θ') i) ∧
      HsCert.ktil3 (xs (sQ θ') a) (xs (sQ θ') b) (xs (sQ θ') c) (xs (sQ θ') i) /
          (4 * ∑ ν, HsCert.upoly (xs (sQ θ') ν)) ≤ Kal 4 θ' := by
  have xr := fun ν => xt_rel θ' ν
  have tb := tx_le_tbar' θ' hB
  have hx0 : ∀ ν, 0 ≤ xs (sQ θ') ν := fun ν => xs_nonneg _ ν
  have mono : ∀ ν, xs (sQ θ') ν ≤ xs (sQ θ') i := by
    intro ν
    rw [(xr ν).1, (xr i).1]
    have h1 := hi ν
    have h2 := (xr i).2.2
    have h3 := (xr ν).2.1
    nlinarith [mul_nonneg (sub_nonneg.2 h1) (by linarith : (0 : ℝ) ≤ 1 - 2 * (tx θ' i + tx θ' ν))]
  have hk0 : 0 ≤ HsCert.ktil3 (xs (sQ θ') a) (xs (sQ θ') b) (xs (sQ θ') c) (xs (sQ θ') i) :=
    hK0 _ _ _ _ (hx0 a) (hB a) (hx0 b) (hB b) (hx0 c) (hB c) (hx0 i) (hB i)
      (mono a) (mono b) (mono c)
  refine ⟨hk0, ?_⟩
  have hceil := hKc (tx θ' a) (tx θ' b) (tx θ' c) (tx θ' i) (xr a).2.1 (tb a)
    (xr b).2.1 (tb b) (xr c).2.1 (tb c) (xr i).2.1 (tb i) (hi a) (hi b) (hi c)
  rw [← (xr a).1, ← (xr b).1, ← (xr c).1, ← (xr i).1, ← hperm (fun ν => tx θ' ν)] at hceil
  have h1b := kal_onevar θ' hω hB i hi
  have hT : 0 < ∑ ν, tx θ' ν := by
    have := omT_low_pos hω
    rw [omT_low] at this
    have e : ∑ ν, 8 * tx θ' ν = 8 * ∑ ν, tx θ' ν := by rw [Finset.mul_sum]
    linarith
  have hU : ∑ ν, tx θ' ν ≤ ∑ ν, HsCert.upoly (xs (sQ θ') ν) := by
    refine Finset.sum_le_sum fun ν _ => ?_
    have hge := hUge _ (hx0 ν) (hB ν)
    have hle := hUle _ (hx0 ν) (hB ν)
    have hu0 : 0 ≤ HsCert.upoly (xs (sQ θ') ν) := by nlinarith [hx0 ν]
    apply quad_mono (xr ν).2.1 hle (xr ν).2.2 hu0
    rw [← (xr ν).1]; exact hge
  set C := (199 / 200) * (1 - (∑ ν, tx θ' ν) + (11 / 24) * (∑ ν, tx θ' ν) *
      ((∑ ν, tx θ' ν) - 2 * tx θ' i)) ^ 2 * HsCert.phihat (tx θ' i) with hC
  have hC0 : 0 ≤ C := le_trans hk0 hceil
  calc HsCert.ktil3 (xs (sQ θ') a) (xs (sQ θ') b) (xs (sQ θ') c) (xs (sQ θ') i) /
        (4 * ∑ ν, HsCert.upoly (xs (sQ θ') ν))
      ≤ C / (4 * ∑ ν, HsCert.upoly (xs (sQ θ') ν)) :=
        div_le_div_of_nonneg_right hceil (by linarith)
    _ ≤ C / (4 * ∑ ν, tx θ' ν) := div_le_div_of_nonneg_left hC0 (by linarith) (by linarith)
    _ ≤ Kal 4 θ' := h1b

/-! ## T1d–T1e: the vertex bound (`box_of_sub`'s `HV`) -/

theorem two_smallest (x : Fin 4 → ℝ) :
    ∃ ρ σ : Fin 4, ρ ≠ σ ∧ ∀ k, k ≠ ρ → k ≠ σ → x ρ ≤ x k ∧ x σ ≤ x k := by
  obtain ⟨ρ, -, hρ⟩ := Finset.exists_min_image univ x univ_nonempty
  have hne : (univ.erase ρ).Nonempty := by
    apply Finset.card_pos.1
    rw [Finset.card_erase_of_mem (mem_univ _)]
    simp
  obtain ⟨σ, hσm, hσ⟩ := Finset.exists_min_image (univ.erase ρ) x hne
  refine ⟨ρ, σ, (Finset.ne_of_mem_erase hσm).symm, fun k hk1 hk2 => ⟨hρ k (mem_univ _), ?_⟩⟩
  exact hσ k (Finset.mem_erase.2 ⟨hk1, mem_univ _⟩)

/-- **T1d + T1e**: on `B`, `Q_ν(x) ≤ nfun² (1 − 2x_ν) Kal 4 θ′`. -/
theorem vertex_HV (hUge : HUge) (hUle : HUle) (hK0 : HK0) (hKc : HKc) (hR : HR) (hA : HA)
    (hM : HM) :
    ∀ θ' : Fin 4 → ℝ, 0 < omT θ' → inB (xs (sQ θ')) → ∀ ν,
      Qv ν (xs (sQ θ')) ≤ nfun (sQ θ') ^ 2 * (1 - 2 * xs (sQ θ') ν) * Kal 4 θ' := by
  intro θ' hp hBx ν
  obtain ⟨i, -, hi⟩ := Finset.exists_max_image univ (tx θ') univ_nonempty
  have hi' : ∀ ν, tx θ' ν ≤ tx θ' i := fun ν => hi ν (mem_univ _)
  have hB53 : ∀ k, xs (sQ θ') k ≤ 53 / 125 := fun k => (hBx.1 k).2
  have hB0 : ∀ k, 0 ≤ xs (sQ θ') k := fun k => (hBx.1 k).1
  obtain ⟨hk0, hkK⟩ := kal_ktil_of hUge hUle hK0 hKc θ' hp hB53 (oa i) (ob i) (oc i) i
    (sum_o i) hi'
  have xr := fun ν => xt_rel θ' ν
  have mono : ∀ k, xs (sQ θ') k ≤ xs (sQ θ') i := by
    intro k
    rw [(xr k).1, (xr i).1]
    have h1 := hi' k
    have h2 := (xr i).2.2
    have h3 := (xr k).2.1
    nlinarith [mul_nonneg (sub_nonneg.2 h1) (by linarith : (0 : ℝ) ≤ 1 - 2 * (tx θ' i + tx θ' k))]
  obtain ⟨ρ, σ, hρσ, hs⟩ := two_smallest (xs (sQ θ'))
  have hn := nfun_ge_minpair (s := sQ θ') (fun k => by linarith [hB53 k]) hρσ hs
  have hAn : Av ν (xs (sQ θ')) ≤ nfun (sQ θ') ^ 2 :=
    le_trans (hA _ ν ρ σ hBx hρσ hs) (sq_tangent hn (hR _ hBx))
  have hw : 0 ≤ 1 - 2 * xs (sQ θ') ν := by linarith [hB53 ν]
  have hu0 : ∀ k, 0 ≤ HsCert.upoly (xs (sQ θ') k) := fun k => by
    have h1 := hUge _ (hB0 k) (hB53 k)
    have h2 := hUle _ (hB0 k) (hB53 k)
    nlinarith [hB0 k]
  have hU : 0 < Uv (xs (sQ θ')) := by
    obtain ⟨k0, hk0'⟩ := hBx.2
    have h1 := hUge _ (hB0 k0) (hB53 k0)
    have hpos : 0 < HsCert.upoly (xs (sQ θ') k0) := by
      nlinarith [sq_nonneg (HsCert.upoly (xs (sQ θ') k0))]
    unfold Uv
    exact Finset.sum_pos' (fun k _ => hu0 k) ⟨k0, mem_univ _, hpos⟩
  have hkv0 : 0 ≤ kv i (xs (sQ θ')) := hk0
  have hkvK : kv i (xs (sQ θ')) / (4 * Uv (xs (sQ θ'))) ≤ Kal 4 θ' := hkK
  have hQ : Qv ν (xs (sQ θ')) ≤
      Av ν (xs (sQ θ')) * (1 - 2 * xs (sQ θ') ν) * (kv i (xs (sQ θ')) / (4 * Uv (xs (sQ θ')))) := by
    have h := hM _ ν i hBx mono
    rw [← mul_div_assoc, le_div_iff₀ (by linarith)]
    linarith
  exact vertex_lb hAn hw (div_nonneg hkv0 (by linarith)) hkvK hQ

/-! ## T1f + the split: `hS_split` -/

/-- **`hS_split`** (`c₀ = 3/100`, `d₁ = 2`, `d₂ = 5`), conditional on the named inequalities. -/
theorem hS_split_of (hUge : HUge) (hUle : HUle) (hK0 : HK0) (hKc : HKc) (hR : HR) (hA : HA)
    (hM : HM) (hF : HF) :
    ∀ θ : Fin 4 → ℝ, 0 < omT θ →
      (3 / 100 : ℝ) ≤ gpt 0 2 θ ∨ ∀ ν, (3 / 100 : ℝ) ≤ omT θ * Dn 5 θ ν := by
  intro θ hω
  by_cases hI : ∀ ν, tx θ ν ≤ 19 / 250
  · left
    have := regionI_lb hω hI
    linarith
  · right
    push_neg at hI
    obtain ⟨j0, hj0⟩ := hI
    intro ν
    have hθ : ∀ ζ ∈ keep (tx θ) (zs θ), inB (xs (sR θ ζ)) := by
      intro ζ hζ
      rw [keep, Finset.mem_filter] at hζ
      refine ⟨fun k => ?_, ⟨j0, ?_⟩⟩
      · obtain ⟨_, h0, h1⟩ := xt_rel θ k
        rw [xs_vertex θ ζ k]
        split_ifs with hk
        · constructor <;> linarith
        · have : 19 / 250 < tx θ k := by
            by_contra hc
            push_neg at hc
            exact hk (hζ.2 k hc)
          constructor <;> linarith
      · obtain ⟨_, h0, h1⟩ := xt_rel θ j0
        rw [xs_vertex θ ζ j0]
        split_ifs <;> linarith
    have hbox : (omT θ / 32) * ∑ ζ ∈ keep (tx θ) (zs θ), Qv ν (xs (sR θ ζ)) ≤
        omT θ * Dn 5 θ ν :=
      box_of_sub 4 inB Qv (vertex_HV hUge hUle hK0 hKc hR hA hM) hω _ hθ ν
    have hF' := hF ν (tx θ) (zs θ) (fun j => ⟨(xt_rel θ j).2.1, (xt_rel θ j).2.2⟩) ⟨j0, hj0⟩
    have e2 : ∀ ζ, xs (sR θ ζ) = vtx (tx θ) (zs θ) ζ := fun ζ => funext fun j => xs_vertex θ ζ j
    simp only [e2] at hbox
    rw [omT_tx θ] at hbox
    linarith

/-- **`lower_side_c`** (`c₀ = 3/100`) for every closed family, conditional on the inequalities. -/
theorem lower_side_c_of (hUge : HUge) (hUle : HUle) (hK0 : HK0) (hKc : HKc) (hR : HR) (hA : HA)
    (hM : HM) (hF : HF) {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) (k : ℕ) :
    UniformBracket.Lw ((3 / 100 : ℝ) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) :=
  lower_side_split th rq hrq hω (by norm_num) 2 5
    (hS_split_of hUge hUle hK0 hKc hR hA hM hF) k

end HsSplit

namespace NearAliasB

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
open scoped Real RealInnerProductSpace

/-- **`bracket_Qpos_split`** (`c₀ = 3/100`): `bracket_Qpos_near` with `lower_side_split`. -/
theorem bracket_Qpos_split_of (hUge : HsSplit.HUge) (hUle : HsSplit.HUle) (hK0 : HsSplit.HK0)
    (hKc : HsSplit.HKc) (hR : HsSplit.HR) (hA : HsSplit.HA) (hM : HsSplit.HM) (hF : HsSplit.HF) :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤
          omF Subtype.val q / (4 * (3 / 100 : ℝ)) * ⟪x, Pfam Subtype.val q x⟫ := by
  obtain ⟨H, hH, hHP, _⟩ := bracket_Qpos_free
  refine ⟨H, hH, hHP, fun k q x => ?_⟩
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  have hlow := lower_side_split Subtype.val rqPos hrq hω (by norm_num : (3 / 100 : ℝ) ≤ 1) 2 5
    (HsSplit.hS_split_of hUge hUle hK0 hKc hR hA hM hF)
  obtain ⟨lo, up⟩ := UniformBracket.bracket (Mfam (Subtype.val : Qpos → _) rqPos)
    (Mfam_orderPreserving _ _) (Pfam_symm _) (Pfam_idem _) hω
    (by norm_num : (0 : ℝ) ≤ 429 / 512) (by norm_num : (429 / 512 : ℝ) < 1)
    (by norm_num : (0 : ℝ) ≤ 15 / 8) (by norm_num : (0 : ℝ) < 3 / 100)
    (Mfam_P_le _ _ hrq) (Mfam_B_le _ _ hrq hω) (UniformBracket.Lw.refl _) hlow
    (iterate_symm _ _) hH hHP k q x
  have hPx : 0 ≤ ⟪x, Pfam Subtype.val q x⟫ := inner_P_nonneg _ q x
  have c1 := UniformBracket.const_lower (hω q) (omF_le _ q) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo, up⟩

end NearAliasB

end

#print axioms HsSplit.kal_ktil_of
#print axioms HsSplit.vertex_HV
#print axioms HsSplit.hS_split_of
#print axioms HsSplit.lower_side_c_of
#print axioms NearAliasB.bracket_Qpos_split_of
