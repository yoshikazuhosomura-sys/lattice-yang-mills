import T1.Split1
import T1.Refl1
import T1.T1hArith1
import T1.Cell1.C00
import T1.Cell1.C01
import T1.Cell1.C02
import T1.Cell1.C03
import T1.Cell1.C04
import T1.Cell1.C05
import T1.Cell1.C06
import T1.Cell1.C07
import T1.Cell1.C08
import T1.Cell1.C09
import T1.Cell1.C10
import T1.Cell1.C11
import T1.Cell1.C12
import T1.Cell1.C13
import T1.Cell1.C14
import T1.Cell1.C15
import T1.Cell1.C16
import T1.Cell1.C17
import T1.Cell1.C18
import T1.Cell1.C19
import T1.Cell1.C20
import T1.Cell1.C21
import T1.Cell1.C22
import T1.Cell1.C23
import T1.Cell1.C24
import T1.Cell1.C25
import T1.Cell1.C26
import T1.Cell1.C27
import T1.Cell1.C28
import T1.Cell1.C29
import T1.Cell1.C30
import T1.Cell1.C31
import T1.Cell1.C32
import T1.Cell1.C33
import T1.Cell1.C34
import T1.Cell1.C35
import T1.Cell1.C36
import T1.Cell1.C37
import T1.Cell1.C38
import T1.Cell1.C39
import T1.Cell1.C40
import T1.Cell1.C41
import T1.Cell1.C42
import T1.Cell1.C43
import T1.Cell1.C44
import T1.Cell1.C45
import T1.Cell1.C46
import T1.Cell1.C47
import T1.Cell1.C48
import T1.Cell1.C49
import T1.Cell1.C50
import T1.Cell1.C51
import T1.Cell1.C52
import T1.Cell1.C53
import T1.Cell1.C54
import T1.Cell1.C55
import T1.Side1.KtilProps
import T1.Side1.FinalCerts
import T1.Side1.FinalRed2
import T1.Side1.ACell00
import T1.Side1.ACell01
import T1.Side1.ACell02
import T1.Side1.ACell03
import T1.Side1.ACell04
import T1.Side1.ACell05
import T1.Side1.ReduceA2
import T1.Red1.HMof

/-! # T1 with no hypothesis left (import chain)

(acceptance: `hS_split`, `lower_side_c`, `bracket_Qpos_split`
with `c₀ = 3/100`, no hypothesis slot; T1h: `m = 17`, `Λ ≤ 640/9`).
Every named polynomial inequality of `HsSplit.hS_split_of` is discharged here by a theorem of an imported module;
the modules were written with `lean -o` (records: `.olean.src.sha256` next to each `.lean`, logs `*.log`).
Made by a generating script. -/

noncomputable section

namespace HsSplit

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
  NearAliasB HsChain
open scoped Real

/-- `P2s` from its 8 cells. -/
theorem P2s_holds : P2s :=
  P2s_of_cells C_M2_cell0000s0010_holds C_M2_cell0000s0011_holds C_M2_cell0000s0110_holds C_M2_cell0000s0111_holds C_M2_cell0000s1010_holds C_M2_cell0000s1011_holds C_M2_cell0000s1110_holds C_M2_cell0000s1111_holds

/-- `P3s` from its 8 cells. -/
theorem P3s_holds : P3s :=
  P3s_of_cells C_M3_cell0000s0001_holds C_M3_cell0000s0011_holds C_M3_cell0000s0101_holds C_M3_cell0000s0111_holds C_M3_cell0000s1001_holds C_M3_cell0000s1011_holds C_M3_cell0000s1101_holds C_M3_cell0000s1111_holds

/-- `P3t0001` from its 16 cells. -/
theorem P3t0001_holds : P3t0001 :=
  P3t0001_of_cells C_M3_cell0001t0000_holds C_M3_cell0001t0001_holds C_M3_cell0001t0010_holds C_M3_cell0001t0011_holds C_M3_cell0001t0100_holds C_M3_cell0001t0101_holds C_M3_cell0001t0110_holds C_M3_cell0001t0111_holds C_M3_cell0001t1000_holds C_M3_cell0001t1001_holds C_M3_cell0001t1010_holds C_M3_cell0001t1011_holds C_M3_cell0001t1100_holds C_M3_cell0001t1101_holds C_M3_cell0001t1110_holds C_M3_cell0001t1111_holds

/-- `P3t1101` from its 10 cells. -/
theorem P3t1101_holds : P3t1101 :=
  P3t1101_of_cells C_M3_cell1101t0000_holds C_M3_cell1101t0001_holds C_M3_cell1101t0010_holds C_M3_cell1101t0011_holds C_M3_cell1101t0101_holds C_M3_cell1101t0111_holds C_M3_cell1101t1001_holds C_M3_cell1101t1011_holds C_M3_cell1101t1101_holds C_M3_cell1101t1111_holds

/-- `RM2` (the main inequality, kind M2). -/
theorem RM2_holds : RM2 :=
  RM2_of_parts P2s_holds C_M2_cell0010_holds C_M2_cell0011_holds C_M2_cell0110_holds C_M2_cell0111_holds C_M2_cell1010_holds C_M2_cell1011_holds C_M2_cell1110_holds C_M2_cell1111_holds

/-- `RM3` (the main inequality, kind M3). -/
theorem RM3_holds : RM3 :=
  RM3_of_parts P3s_holds P3t0001_holds P3t1101_holds C_M3_cell0011_holds C_M3_cell0101_holds C_M3_cell0111_holds C_M3_cell1001_holds C_M3_cell1011_holds C_M3_cell1111_holds

/-- `HM` (`main` on `B`). -/
theorem HM_holds : HM :=
  HM_of RM3_holds RM2_holds

/-- `RA01` from its cells. -/
theorem RA01_holds : RA01 :=
  RA01_of_cells C_A01_cell0000s0001_holds C_A01_cell0000s0010_holds C_A01_cell0000s0011_holds C_A01_cell0000s0111_holds C_A01_cell0000s1011_holds C_A01_cell0000s1111_holds C_A01_cell0001_holds C_A01_cell0010_holds C_A01_cell0011_holds C_A01_cell0111_holds C_A01_cell1011_holds C_A01_cell1111_holds

/-- `RA03` from its cells. -/
theorem RA03_holds : RA03 :=
  RA03_of_cells C_A03_cell0000s0010_holds C_A03_cell0000s0100_holds C_A03_cell0000s0110_holds C_A03_cell0000s0111_holds C_A03_cell0000s1110_holds C_A03_cell0000s1111_holds C_A03_cell0010_holds C_A03_cell0100_holds C_A03_cell0110_holds C_A03_cell0111_holds C_A03_cell1110_holds C_A03_cell1111_holds

/-- `HR` (`r ≥ 0` on `B`). -/
theorem HR_holds : HR :=
  HR_of (RR_of C_R_holds)

/-- `HA` (`A₂ ≤ A_p` on `B`). -/
theorem HA_holds : HA :=
  HA_of RA01_holds RA03_holds

/-- `HF` (the final vertex sums, all `ν` and all L-sets). -/
theorem HF_holds : HF :=
  HF_of C_F_S_holds C_F_S0_holds C_F_S3_holds C_F_S01_holds C_F_S03_holds C_F_S012_holds C_F_S013_holds

/-- **`hS_split`** (`c₀ = 3/100`, `d₁ = 2`, `d₂ = 5`): no hypothesis. The statement is word for word the
`hS` slot of `lower_side_split` with `c = 3/100`, `d₁ = 2`, `d₂ = 5`. -/
theorem hS_split : ∀ θ : Fin 4 → ℝ, 0 < omT θ →
    (3 / 100 : ℝ) ≤ gpt 0 2 θ ∨ ∀ ν, (3 / 100 : ℝ) ≤ omT θ * Dn 5 θ ν :=
  hS_split_of HUge_holds HUle_holds HK0_holds HKc_holds HR_holds HA_holds HM_holds HF_holds

/-- **`lower_side_c`** (`c₀ = 3/100`) for every closed family: `lower_side_split` fed with `hS_split` directly. -/
theorem lower_side_c {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) (k : ℕ) :
    UniformBracket.Lw ((3 / 100 : ℝ) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) :=
  lower_side_split th rq hrq hω (by norm_num) 2 5 hS_split k

end HsSplit

namespace NearAliasB

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower OneStepCell
open scoped Real RealInnerProductSpace

/-- **`bracket_Qpos_split`** (`c₀ = 3/100`) on `Qpos` (the family's `hrq`, `hω` are discharged inside). -/
theorem bracket_Qpos_split :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤
          omF Subtype.val q / (4 * (3 / 100 : ℝ)) * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_Qpos_split_of HsSplit.HUge_holds HsSplit.HUle_holds HsSplit.HK0_holds HsSplit.HKc_holds
    HsSplit.HR_holds HsSplit.HA_holds HsSplit.HM_holds HsSplit.HF_holds

end NearAliasB

namespace T1h

open StageArith

/-- **T1 with T1h**: the constant `c₀ = 3/100` of `hS_split` (closed, no hypothesis) gives `m = 17`
(`τ₁₇(1/c₀) < 1/170`, `λ̄ = 3/5`) and, on the finite torus (`N ≥ 2`, upper side `≤ 1`, diagonal
`≥ (c₀/2)(1 − N⁻⁴)`), `Λ ≤ 32/(15 c₀) = 640/9`. -/
theorem t1_with_stages : ∃ c₀ : ℝ, c₀ = 3 / 100 ∧
    (∀ θ : Fin 4 → ℝ, 0 < NearAliasB.omT θ → c₀ ≤ NearAliasB.gpt 0 2 θ ∨ ∀ ν, c₀ ≤ NearAliasB.omT θ * NearAliasB.Dn 5 θ ν) ∧
    tauM (1 / c₀) (3 / 5) 17 < 1 / 170 ∧
    (∀ {N : ℕ}, 2 ≤ N → ∀ {lmax diag : ℝ}, lmax ≤ 1 → c₀ / 2 * (1 - 1 / (N : ℝ) ^ 4) ≤ diag →
      lmax / diag ≤ 640 / 9) :=
  ⟨3 / 100, rfl, HsSplit.hS_split, tau_3_17, fun {_} hN {_ _} hup hd => torus_lambda_c3 hN hup hd⟩

end T1h

end

#print axioms HsSplit.hS_split
#print axioms HsSplit.lower_side_c
#print axioms NearAliasB.bracket_Qpos_split
#print axioms T1h.t1_with_stages
