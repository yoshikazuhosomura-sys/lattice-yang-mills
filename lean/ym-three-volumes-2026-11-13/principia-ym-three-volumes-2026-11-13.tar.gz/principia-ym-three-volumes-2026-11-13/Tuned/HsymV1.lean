import Tuned.SanityChainV1
/-!
**The field `hsym` of the chain theorem for coarse translations, for the Wilson family with any couplings.**

`hsym_translation` : with `actb v m := shV (2^m L) (v m)` (a coarse translation at every level), for every level m
and every n ≥ m, the chain's pushed-forward measure ν_{n,m} is invariant: ∫ F(actb v m ω) dν_{n,m} = ∫ F dν_{n,m}
for every bounded continuous F.  No hypothesis on the couplings.

Paper correspondence: the symmetry field of Theorem W's chain, translation part (fine translation invariance of the
Wilson measure and the translation covariance of the block map).
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP FoldAffine PushLocal

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem hsym_translation (β : ℕ → ℝ) :
    ∀ (v : ∀ m, Site (2 ^ m * L)) (m : ℕ), ∀ᶠ n in atTop,
      ∀ F : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ,
      ∫ ω, F (shV (2 ^ m * L) (v m) ω) ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) =
      ∫ ω, F ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) := by
  intro v m
  refine Filter.eventually_atTop.2 ⟨m, fun n hn => ?_⟩
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
  intro F
  rw [νP_wFam L hr β m k]
  exact νk_shV_invariant L hr m k _ (v m) F F.continuous

end TunedCoupling

#print axioms TunedCoupling.hsym_translation
