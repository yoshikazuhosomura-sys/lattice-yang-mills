import Tuned.RetractBoundV1
/-!
**The largest solution of the tuning equation at each level.**

* `tuning_max_at_level` : for r₀ ≤ 1, κ₀ < 1 and Y(m, k, 0) ≤ κ₀, the set {β ≥ 0 | Y(m, k, β) = κ₀} has a largest
  element β*, and Y(m, k, β) > κ₀ for every β > β* (beyond β* the coarse plaquette average stays above κ₀);
* `tuned_max_exists` : under the lower-end hypothesis ∀ k, Y(m₀, k, 0) ≤ κ₀ (known in Lean only at k = 0), the tuned
  sequence can be taken as the largest solution at every level.
-/

namespace FlatPush

open MeasureTheory Filter Topology Set TunedCoupling

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem tuning_max_at_level (hr1 : r₀ ≤ 1) (m k : ℕ) (κ₀ : ℝ) (hκ : κ₀ < 1) (hlow : Yc L hr m k 0 ≤ κ₀) :
    ∃ β, 0 ≤ β ∧ Yc L hr m k β = κ₀ ∧ ∀ β', β < β' → κ₀ < Yc L hr m k β' := by
  have hc := continuous_Yc L hr m k
  obtain ⟨B, hB⟩ := eventually_atTop.1 ((tendsto_Yc_one L hr hr1 m k).eventually (eventually_gt_nhds hκ))
  set S := {β : ℝ | 0 ≤ β ∧ Yc L hr m k β = κ₀}
  obtain ⟨β0, h0, e0⟩ := tuning_at_level L hr hr1 m k κ₀ 0 hκ hlow
  have hne : S.Nonempty := ⟨β0, h0, e0⟩
  have hbdd : BddAbove S := ⟨B, fun β hβ => by
    by_contra h; push Not at h
    have := hB β h.le
    rw [hβ.2] at this; exact lt_irrefl _ this⟩
  have hcl : IsClosed S := (isClosed_le continuous_const continuous_id).inter (isClosed_eq hc continuous_const)
  have hmem : sSup S ∈ S := hcl.csSup_mem hne hbdd
  refine ⟨sSup S, hmem.1, hmem.2, fun β' hβ' => ?_⟩
  by_contra hle; push Not at hle
  set B' := max β' B + 1
  have hB' : κ₀ < Yc L hr m k B' := hB B' (by simp only [B']; linarith [le_max_right β' B])
  have h12 : β' ≤ B' := by simp only [B']; linarith [le_max_left β' B]
  obtain ⟨β, hβ, e⟩ := exists_tuning L hr m k h12 (Set.mem_uIcc.2 (Or.inl ⟨hle, hB'.le⟩))
  have hin : β ∈ S := ⟨by linarith [hβ.1, hmem.1], e⟩
  have := le_csSup hbdd hin
  linarith [hβ.1]

theorem tuned_max_exists (hr1 : r₀ ≤ 1) (m₀ : ℕ) (κ₀ : ℝ) (hκ : κ₀ < 1) (hlow : ∀ k, Yc L hr m₀ k 0 ≤ κ₀) :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned L hr m₀ κ₀ β ∧
      ∀ k, ∀ β', β (m₀ + k) < β' → κ₀ < Yc L hr m₀ k β' := by
  choose b hb e hmax using fun k => tuning_max_at_level L hr hr1 m₀ k κ₀ hκ (hlow k)
  exact ⟨fun n => b (n - m₀), fun n => hb _, fun k => by simpa using e k,
    fun k β' h => hmax k β' (by simpa using h)⟩

end Box

end FlatPush

#print axioms FlatPush.tuning_max_at_level
#print axioms FlatPush.tuned_max_exists
