import Tuned.UpperEndV1
/-!
**Existence of the tuned coupling sequence under an explicit lower-end hypothesis; separation from β ≡ 0.**

* `tuning_at_level` : for r₀ ≤ 1 and one k, if Y(m₀, k, β₁) ≤ κ₀ < 1 then Y(m₀, k, β) = κ₀ for some β ≥ β₁
  (upper end `tendsto_Yc_one` and the intermediate value theorem);
* `tuned_exists_of_low` : for r₀ ≤ 1, κ₀ < 1 and the **lower-end hypothesis** ∀ k, Y(m₀, k, 0) ≤ κ₀, a coupling
  sequence β ≥ 0 satisfying `Tuned` exists.  The lower-end hypothesis is an inequality between defined numbers.
  It is known (in Lean) only at k = 0 (`low_end_level_zero`: Y(m₀, 0, 0) = 0 ≤ κ₀ for κ₀ ≥ 0).  For k ≥ 1 no
  example is known: the values Y(m₀, k, 0) (k ≥ 1) are not computed in Lean, and a bound uniform in k is open;
* `tuned_limit_ne_zero_coupling_limit` : if κ₀ stays at distance ≥ ε from Y(m₀, k, 0) for all large k, then every
  level-m₀ subsequential limit of the tuned chain differs from every level-m₀ subsequential limit of the chain with
  β ≡ 0 (the integral of the coarse plaquette average is kept by weak limits);
* `tuned_exists_separated` : with ∀ k, Y(m₀, k, 0) ≤ κ₁ < κ₀ < 1 both hold at once.

Paper correspondence: the existence of the tuned coupling sequence (bracket (a) upper end, (b) lower end as a
hypothesis) and the separation of the tuned limit from the β ≡ 0 limit.
-/

namespace FlatPush

open MeasureTheory Filter Topology Set TunedCoupling

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **one level**: from a value ≤ κ₀ < 1 the tuning equation has a solution beyond it (r₀ ≤ 1) -/
theorem tuning_at_level (hr1 : r₀ ≤ 1) (m k : ℕ) (κ₀ β₁ : ℝ) (hκ : κ₀ < 1) (hlow : Yc L hr m k β₁ ≤ κ₀) :
    ∃ β, β₁ ≤ β ∧ Yc L hr m k β = κ₀ := by
  have hev := (tendsto_Yc_one L hr hr1 m k).eventually (eventually_gt_nhds hκ)
  obtain ⟨β₂, h2, h12⟩ := (hev.and (eventually_ge_atTop β₁)).exists
  obtain ⟨β, hβ, e⟩ := exists_tuning L hr m k h12 (Set.mem_uIcc.2 (Or.inl ⟨hlow, h2.le⟩))
  exact ⟨β, hβ.1, e⟩

/-- **existence of the tuned coupling sequence** under the lower-end hypothesis (r₀ ≤ 1, κ₀ < 1).
The hypothesis `hlow` is known in Lean only at k = 0; for k ≥ 1 no example is known. -/
theorem tuned_exists_of_low (hr1 : r₀ ≤ 1) (m₀ : ℕ) (κ₀ : ℝ) (hκ : κ₀ < 1)
    (hlow : ∀ k, Yc L hr m₀ k 0 ≤ κ₀) :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned L hr m₀ κ₀ β := by
  choose b hb e using fun k => tuning_at_level L hr hr1 m₀ k κ₀ 0 hκ (hlow k)
  exact ⟨fun n => b (n - m₀), fun n => hb _, fun k => by simpa using e k⟩

/-- the lower-end hypothesis at k = 0 holds for κ₀ ≥ 0 (when 2^m₀ L ≥ 2) -/
theorem low_end_level_zero (m₀ : ℕ) (hN : 1 < 2 ^ m₀ * L) (κ₀ : ℝ) (hκ : 0 ≤ κ₀) : Yc L hr m₀ 0 0 ≤ κ₀ := by
  rw [Yc_zero_zero L hr m₀ hN]; exact hκ

/-- **sanity**: at k = 0 the tuning equation is solvable for every κ₀ ∈ [0, 1) (no hypothesis left).  The
corresponding statement for all k at once needs `hlow` at k ≥ 1, for which no example is known. -/
theorem tuning_level_zero_exists (hr1 : r₀ ≤ 1) (m₀ : ℕ) (hN : 1 < 2 ^ m₀ * L) (κ₀ : ℝ) (h0 : 0 ≤ κ₀)
    (hκ : κ₀ < 1) : ∃ β, 0 ≤ β ∧ Yc L hr m₀ 0 β = κ₀ :=
  tuning_at_level L hr hr1 m₀ 0 κ₀ 0 hκ (low_end_level_zero L hr m₀ hN κ₀ h0)

/-- **the tuned limit is not a β ≡ 0 limit** (level m₀), when κ₀ is eventually ε-separated from Y(m₀, k, 0) -/
theorem tuned_limit_ne_zero_coupling_limit (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β)
    (hsep : ∃ ε > 0, ∀ᶠ k in atTop, ε ≤ |Yc L hr m₀ k 0 - κ₀|)
    (φ ψ : ℕ → ℕ) (hφ : StrictMono φ) (hψ : StrictMono ψ)
    (νt νz : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)))
    (htl : Tendsto (fun j => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ j) m₀)
      atTop (𝓝 νt))
    (hzl : Tendsto (fun j => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)
      (wFam L (fun _ => 0)) (ψ j) m₀) atTop (𝓝 νz)) :
    νt ≠ νz := by
  intro heq
  have h1 := tuned_limit_avg L hr m₀ κ₀ β ht φ hφ νt htl
  have h2 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hzl) (avgBC L m₀)
  have h3 : ∫ ω, avgBC L m₀ ω ∂(νz : Measure _) = κ₀ := by rw [← heq]; exact h1
  rw [h3] at h2
  obtain ⟨ε, hε, hev⟩ := hsep
  have hg : Tendsto (fun j => ψ j - m₀) atTop atTop := (tendsto_sub_atTop_nat m₀).comp hψ.tendsto_atTop
  have hA := hg.eventually hev
  have hB := h2.eventually (Metric.ball_mem_nhds κ₀ hε)
  have hC : ∀ᶠ j in atTop, m₀ ≤ ψ j := hψ.tendsto_atTop.eventually (eventually_ge_atTop m₀)
  obtain ⟨j, hA', hB', hC'⟩ := (hA.and (hB.and hC)).exists
  obtain ⟨k, hk⟩ := Nat.exists_eq_add_of_le hC'
  have e : ∫ ω, avgBC L m₀ ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)
      (wFam L (fun _ => 0)) (ψ j) m₀ : Measure _) = Yc L hr m₀ k 0 := by
    rw [hk]
    show ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(_ : Measure _) = _
    rw [νP_wFam L hr (fun _ => 0) m₀ k, integral_νk]
  simp only [Real.dist_eq] at hB'
  rw [e] at hB'
  simp only [hk, Nat.add_sub_cancel_left] at hA'
  linarith

/-- **both at once**: if Y(m₀, k, 0) ≤ κ₁ for all k and κ₁ < κ₀ < 1 (r₀ ≤ 1), a tuned sequence β ≥ 0 exists and every
level-m₀ subsequential limit of its chain differs from every level-m₀ subsequential limit of the β ≡ 0 chain.
The hypothesis on Y(m₀, k, 0) for k ≥ 1 has no known example. -/
theorem tuned_exists_separated (hr1 : r₀ ≤ 1) (m₀ : ℕ) (κ₁ κ₀ : ℝ) (h10 : κ₁ < κ₀) (hκ : κ₀ < 1)
    (hlow : ∀ k, Yc L hr m₀ k 0 ≤ κ₁) :
    ∃ β : ℕ → ℝ, (∀ n, 0 ≤ β n) ∧ Tuned L hr m₀ κ₀ β ∧
      ∀ (φ ψ : ℕ → ℕ), StrictMono φ → StrictMono ψ →
      ∀ νt νz : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)),
      Tendsto (fun j => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ j) m₀)
        atTop (𝓝 νt) →
      Tendsto (fun j => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)
        (wFam L (fun _ => 0)) (ψ j) m₀) atTop (𝓝 νz) → νt ≠ νz := by
  obtain ⟨β, hβ, ht⟩ := tuned_exists_of_low L hr hr1 m₀ κ₀ hκ (fun k => (hlow k).trans h10.le)
  refine ⟨β, hβ, ht, fun φ ψ hφ hψ νt νz htl hzl => ?_⟩
  refine tuned_limit_ne_zero_coupling_limit L hr m₀ κ₀ β ht ⟨κ₀ - κ₁, by linarith,
    Eventually.of_forall fun k => ?_⟩ φ ψ hφ hψ νt νz htl hzl
  rw [abs_sub_comm, abs_of_pos (by linarith [hlow k])]
  linarith [hlow k]

end Box

end FlatPush

#print axioms FlatPush.tuning_at_level
#print axioms FlatPush.tuned_exists_of_low
#print axioms FlatPush.low_end_level_zero
#print axioms FlatPush.tuning_level_zero_exists
#print axioms FlatPush.tuned_limit_ne_zero_coupling_limit
#print axioms FlatPush.tuned_exists_separated
