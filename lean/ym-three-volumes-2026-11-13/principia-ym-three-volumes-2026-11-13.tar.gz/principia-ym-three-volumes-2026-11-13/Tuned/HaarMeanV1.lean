import Tuned.HsymV1
/-!
**The plaquette average has mean zero under the product Haar measure; consequences for the tuning.**

* `negB_preserving` : q ↦ −q preserves the SU(2) Haar measure on the ball (left multiplication by −1);
* `integral_re_hol_haar` : for N ≥ 2 and every unoriented plaquette p, ∫ Re U_p d(∏ Haar) = 0
  (flip the sign of the first link of p: the other three links differ from it when N ≥ 2);
* `integral_plaqAvg_haar` : ∫ Ȳ d(∏ Haar) = 0;
* `Yc_zero_zero` : Y(m, 0, 0) = 0 when 2^m L ≥ 2 (β = 0 is the product Haar measure);
* `zero_coupling_not_tuned` : for κ₀ ≠ 0 the coupling sequence β ≡ 0 does not satisfy the tuning equation;
* `tuned_limit_ne_haar` : for κ₀ ≠ 0 the level-m₀ limit of the tuned chain is not the product Haar measure; for
  κ₀ < 1 it is not concentrated on {Ȳ = 1} (`limit_not_flat`).
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP PushLocal OSGap

/-- q ↦ −q on the closed unit ball of ℍ -/
noncomputable def negB (q : QBall) : QBall :=
  ⟨-(q : Quaternion ℝ), by rw [mem_closedBall_zero_iff, norm_neg]; exact mem_closedBall_zero_iff.mp q.2⟩

theorem continuous_negB : Continuous negB :=
  (continuous_subtype_val.neg).subtype_mk _

/-- −1 as an element of SU(2) -/
def mOne : SU2 := ⟨-1, by rw [mem_sphere_zero_iff_norm, norm_neg, norm_one]⟩

theorem negB_incl (q : SU2) : negB (incl q) = incl (mOne * q) := by
  apply Subtype.ext
  show -((q : Quaternion ℝ)) = ((mOne * q : SU2) : Quaternion ℝ)
  rw [Metric.unitSphere.coe_mul]
  show -((q : Quaternion ℝ)) = (-1 : Quaternion ℝ) * (q : Quaternion ℝ)
  rw [neg_one_mul]

theorem negB_preserving : MeasurePreserving negB haarBall haarBall := by
  refine ⟨continuous_negB.measurable, ?_⟩
  unfold haarBall
  rw [Measure.map_map continuous_negB.measurable continuous_incl.measurable]
  have hc : negB ∘ incl = incl ∘ (fun q : SU2 => mOne * q) := funext negB_incl
  rw [hc, ← Measure.map_map continuous_incl.measurable (continuous_mul_left mOne).measurable]
  congr 1
  exact map_mul_left_eq_self _ mOne

section Flip

variable (N : ℕ) [NeZero N]

/-- flip the sign of the link ℓ₀ -/
noncomputable def flipAt (ℓ₀ : Lk N) (ω : Lk N → QBall) : Lk N → QBall :=
  fun ℓ => (if ℓ = ℓ₀ then negB else id) (ω ℓ)

theorem flipAt_preserving (ℓ₀ : Lk N) :
    MeasurePreserving (flipAt N ℓ₀) (Measure.pi fun _ : Lk N => haarBall) (Measure.pi fun _ : Lk N => haarBall) :=
  measurePreserving_pi _ _ (fun ℓ => by
    by_cases h : ℓ = ℓ₀
    · simp only [h, if_true]; exact negB_preserving
    · simp only [h, if_false]; exact MeasurePreserving.id _)

theorem hol_flipAt (hN : 1 < N) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) (ω : Lk N → QBall) :
    hol N (flipAt N p.1 ω) p = -(hol N ω p) := by
  have : Fact (1 < N) := ⟨hN⟩
  have hlt : p.1.2 < p.2 := (Finset.mem_filter.mp hp).2
  have hne : p.1.2 ≠ p.2 := ne_of_lt hlt
  have h2 : ((p.1.1 + ev N p.1.2, p.2) : Lk N) ≠ p.1 := fun h => hne (congrArg Prod.snd h).symm
  have h4 : ((p.1.1, p.2) : Lk N) ≠ p.1 := fun h => hne (congrArg Prod.snd h).symm
  have h3 : ((p.1.1 + ev N p.2, p.1.2) : Lk N) ≠ p.1 := by
    intro h
    have hx := congrArg (fun l : Lk N => l.1 p.2) h
    simp only [ev, Pi.add_apply, Pi.single_eq_same] at hx
    exact one_ne_zero (add_eq_left.mp hx)
  simp only [hol, holQ, Uq, flipAt, if_neg h2, if_neg h3, if_neg h4, id]
  show -(ω p.1 : Quaternion ℝ) * _ * _ * _ = _
  simp only [neg_mul]

theorem integral_re_hol_haar (hN : 1 < N) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ∫ ω, (hol N ω p).re ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  have hF := flipAt_preserving N p.1
  have hm : Measurable (fun ω : Lk N → QBall => (hol N ω p).re) :=
    (Quaternion.continuous_re.comp (continuous_hol N p)).measurable
  have h : ∫ ω, (hol N ω p).re ∂(Measure.pi fun _ : Lk N => haarBall) =
      ∫ ω, (hol N (flipAt N p.1 ω) p).re ∂(Measure.pi fun _ : Lk N => haarBall) := by
    conv_lhs => rw [← hF.map_eq]
    rw [integral_map hF.measurable.aemeasurable hm.aestronglyMeasurable]
  simp_rw [hol_flipAt N hN p hp, Quaternion.re_neg, integral_neg] at h
  linarith

theorem integral_plaqAvg_haar (hN : 1 < N) :
    ∫ ω, plaqAvg N ω ∂(Measure.pi fun _ : Lk N => haarBall) = 0 := by
  unfold plaqAvg
  have hi : ∀ p ∈ plaqs N, Integrable (fun ω : Lk N → QBall => (hol N ω p).re)
      (Measure.pi fun _ : Lk N => haarBall) := fun p _ =>
    integrable_cont N _ (Quaternion.continuous_re.comp (continuous_hol N p))
  rw [integral_div, integral_finsetSum _ hi]
  rw [Finset.sum_eq_zero (fun p hp => integral_re_hol_haar N hN p hp), zero_div]

end Flip

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **β = 0, k = 0: the plaquette average vanishes** (2^m L ≥ 2) -/
theorem Yc_zero_zero (m : ℕ) (hN : 1 < 2 ^ m * L) : Yc L hr m 0 0 = 0 := by
  rw [Yc_zero_steps, integral_wilsonProb_div, integral_wilson]
  simp only [zero_mul, Real.exp_zero, one_mul]
  rw [integral_plaqAvg_haar _ hN, zero_div]

/-- for κ₀ ≠ 0 the coupling sequence β ≡ 0 does not satisfy the tuning equation -/
theorem zero_coupling_not_tuned (m₀ : ℕ) (hN : 1 < 2 ^ m₀ * L) (κ₀ : ℝ) (hκ : κ₀ ≠ 0) :
    ¬ Tuned L hr m₀ κ₀ (fun _ => 0) := by
  intro ht
  exact hκ ((ht 0).symm.trans (Yc_zero_zero L hr m₀ hN))

/-- for κ₀ ≠ 0 the level-m₀ limit of the tuned chain is not the product Haar measure -/
theorem tuned_limit_ne_haar (m₀ : ℕ) (hN : 1 < 2 ^ m₀ * L) (κ₀ : ℝ) (hκ : κ₀ ≠ 0)
    (νl : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)))
    (hlimκ : ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl : Measure (Lk (2 ^ m₀ * L) → QBall)) = κ₀) :
    (νl : Measure (Lk (2 ^ m₀ * L) → QBall)) ≠ Measure.pi fun _ : Lk (2 ^ m₀ * L) => haarBall := by
  intro h
  rw [h, integral_plaqAvg_haar _ hN] at hlimκ
  exact hκ hlimκ.symm

end Box

end TunedCoupling

#print axioms TunedCoupling.integral_re_hol_haar
#print axioms TunedCoupling.Yc_zero_zero
#print axioms TunedCoupling.zero_coupling_not_tuned
#print axioms TunedCoupling.tuned_limit_ne_haar
