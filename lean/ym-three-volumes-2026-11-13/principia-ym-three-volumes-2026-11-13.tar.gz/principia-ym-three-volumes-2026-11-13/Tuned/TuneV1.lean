import PushRare.PushFormV1
import PushRare.DownEqV1
import Lattice.WilsonGapV2
/-!
**Tuning the bare coupling by the coarse plaquette average, and what it gives the chain.**

Generic part (any lattice size N, any continuous coarse-graining map T):
* `plaqAvg N V` : the average of Re U_p over the unoriented plaquettes of (ℤ/N)⁴ (the function Ȳ);
* `continuous_integral_wilson` : β ↦ ∫ g dμ_W(N, β) is continuous for every continuous g;
* `markov_avg`, `markov_plaq` : for a probability measure ν with ∫ Ȳ dν = κ₀,
  ν(1 − Ȳ ≥ y) ≤ (1 − κ₀)/y and, for one plaquette p, ν(1 − Re U_p ≥ y) ≤ |plaqs|·(1 − κ₀)/y;
* `limit_integral_eq` : a weak limit of probability measures with ∫ F dν_n = κ₀ (eventually) has ∫ F dν = κ₀.

Box block map (paths and weights only through `downK`, i.e. only through a continuous map):
* `Yc L hr m k β := ∫ Ȳ(downK m k ω) d(wilsonProb (2^(m+k) L) β)`, the coarse plaquette average of the k-fold
  pushed-forward normalised Wilson measure (definition (i));
* `continuous_Yc` (ii), `exists_tuning` (iii, intermediate value form), `tuned_markov_plaq` (iv),
  `tuned_limit_nondegenerate` (v): for a coupling sequence satisfying the tuning equation at level m₀,
  a common subsequence of the chain's pushed-forward measures converges at every level, and the limit at level m₀
  has coarse plaquette average κ₀ (hence charges {Ȳ < 1} when κ₀ < 1 and obeys the Markov bounds).

Paper correspondence: the tuning (a) at level m₀, the rarity field of the chain theorem at level m₀ in Markov form,
and the non-degeneracy of the limit at level m₀.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP FoldPeierls PushLocal

section Generic

variable (N : ℕ) [NeZero N]

/-- the average of Re U_p over the unoriented plaquettes of (ℤ/N)⁴ -/
noncomputable def plaqAvg (V : Lk N → QBall) : ℝ :=
  (∑ p ∈ plaqs N, (hol N V p).re) / ((plaqs N).card : ℝ)

theorem plaqs_card_pos : 0 < (plaqs N).card := by
  apply Finset.card_pos.mpr
  refine ⟨((fun _ => 0, 0), 1), ?_⟩
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, show (0 : Fin 4) < 1 by decide⟩

theorem re_hol_le_one (V : Lk N → QBall) (p : Lk N × Fin 4) : (hol N V p).re ≤ 1 :=
  (abs_le.mp (abs_hol_re N V p)).2

theorem neg_one_le_re_hol (V : Lk N → QBall) (p : Lk N × Fin 4) : -1 ≤ (hol N V p).re :=
  (abs_le.mp (abs_hol_re N V p)).1

theorem plaqAvg_le_one (V : Lk N → QBall) : plaqAvg N V ≤ 1 := by
  have hc : (0 : ℝ) < (plaqs N).card := by exact_mod_cast plaqs_card_pos N
  unfold plaqAvg
  rw [div_le_one hc]
  calc ∑ p ∈ plaqs N, (hol N V p).re ≤ ∑ _p ∈ plaqs N, (1 : ℝ) :=
        Finset.sum_le_sum (fun p _ => re_hol_le_one N V p)
    _ = (plaqs N).card := by simp

theorem neg_one_le_plaqAvg (V : Lk N → QBall) : -1 ≤ plaqAvg N V := by
  have hc : (0 : ℝ) < (plaqs N).card := by exact_mod_cast plaqs_card_pos N
  unfold plaqAvg
  rw [le_div_iff₀ hc]
  calc -1 * ((plaqs N).card : ℝ) = ∑ _p ∈ plaqs N, (-1 : ℝ) := by simp
    _ ≤ ∑ p ∈ plaqs N, (hol N V p).re := Finset.sum_le_sum (fun p _ => neg_one_le_re_hol N V p)

theorem continuous_action' : Continuous (action N) :=
  continuous_finsetSum _ (fun p _ => Quaternion.continuous_re.comp (continuous_hol N p))

theorem continuous_plaqAvg : Continuous (plaqAvg N) :=
  (continuous_finsetSum _ (fun p _ => Quaternion.continuous_re.comp (continuous_hol N p))).div_const _

/-- one plaquette is controlled by the average: 1 − Re U_p ≤ |plaqs|·(1 − Ȳ) -/
theorem one_sub_re_le (V : Lk N → QBall) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    1 - (hol N V p).re ≤ (plaqs N).card * (1 - plaqAvg N V) := by
  have hc : ((plaqs N).card : ℝ) ≠ 0 := by exact_mod_cast (plaqs_card_pos N).ne'
  have e : ((plaqs N).card : ℝ) * (1 - plaqAvg N V) = ∑ q ∈ plaqs N, (1 - (hol N V q).re) := by
    unfold plaqAvg
    rw [mul_sub, mul_one, mul_div_cancel₀ _ hc, Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul,
      mul_one]
  rw [e]
  exact Finset.single_le_sum (f := fun q => 1 - (hol N V q).re)
    (fun q _ => by linarith [re_hol_le_one N V q]) hp

/-- integrals against the Wilson measure as integrals against the product Haar measure -/
theorem integral_wilson (β : ℝ) (g : (Lk N → QBall) → ℝ) :
    ∫ ω, g ω ∂(wilsonMeasure N β) =
      ∫ ω, Real.exp (β * action N ω) * g ω ∂(Measure.pi fun _ : Lk N => haarBall) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  congr 1
  funext ω
  rw [NNReal.smul_def, smul_eq_mul]
  show ((Real.toNNReal (Real.exp (β * action N ω)) : ℝ)) * g ω = _
  rw [Real.coe_toNNReal _ (Real.exp_pos _).le]

/-- **(ii) continuity in β** of the Wilson integral of a continuous function -/
theorem continuous_integral_wilson (g : (Lk N → QBall) → ℝ) (hg : Continuous g) :
    Continuous fun β : ℝ => ∫ ω, g ω ∂(wilsonMeasure N β) := by
  have e : (fun β : ℝ => ∫ ω, g ω ∂(wilsonMeasure N β)) =
      fun β => ∫ ω in univ, Real.exp (β * action N ω) * g ω ∂(Measure.pi fun _ : Lk N => haarBall) := by
    funext β
    rw [Measure.restrict_univ, integral_wilson]
  rw [e]
  exact continuous_parametric_integral_of_continuous
    (f := fun (β : ℝ) (ω : Lk N → QBall) => Real.exp (β * action N ω) * g ω)
    ((Real.continuous_exp.comp (continuous_fst.mul ((continuous_action' N).comp continuous_snd))).mul
      (hg.comp continuous_snd)) isCompact_univ

/-- the normalised Wilson integral is the Wilson integral divided by Z -/
theorem integral_wilsonProb_div (β : ℝ) (g : (Lk N → QBall) → ℝ) :
    ∫ ω, g ω ∂(wilsonProb N β : Measure (Lk N → QBall)) =
      (∫ ω, g ω ∂(wilsonMeasure N β)) / (wilsonMeasure N β univ).toReal := by
  rw [wilsonProb_toMeasure, integral_smul_measure, ENNReal.toReal_inv, smul_eq_mul, div_eq_inv_mul]

theorem wilson_total_pos (β : ℝ) : 0 < (wilsonMeasure N β univ).toReal :=
  ENNReal.toReal_pos (wilsonMeasure_univ_pos N β).ne' (measure_ne_top _ _)

theorem continuous_integral_wilsonProb (g : (Lk N → QBall) → ℝ) (hg : Continuous g) :
    Continuous fun β : ℝ => ∫ ω, g ω ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  have hZ : Continuous fun β : ℝ => (wilsonMeasure N β univ).toReal := by
    have e : (fun β : ℝ => (wilsonMeasure N β univ).toReal) =
        fun β => ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
      funext β; rw [integral_const, smul_eq_mul, mul_one]; rfl
    rw [e]; exact continuous_integral_wilson N _ continuous_const
  simp_rw [integral_wilsonProb_div]
  exact (continuous_integral_wilson N g hg).div hZ (fun β => (wilson_total_pos N β).ne')

end Generic

/-! ## Markov and limits for an arbitrary probability measure -/

section MarkovGen

variable (N : ℕ) [NeZero N]

theorem integrable_cont {μ : Measure (Lk N → QBall)} [IsFiniteMeasure μ] (f : (Lk N → QBall) → ℝ)
    (hf : Continuous f) : Integrable f μ :=
  (BoundedContinuousFunction.mkOfCompact ⟨f, hf⟩).integrable μ

/-- **(iv) Markov, average form** -/
theorem markov_avg (ν : Measure (Lk N → QBall)) [IsProbabilityMeasure ν] (κ₀ : ℝ)
    (hκ : ∫ V, plaqAvg N V ∂ν = κ₀) (y : ℝ) (hy : 0 < y) :
    ν.real {V | y ≤ 1 - plaqAvg N V} ≤ (1 - κ₀) / y := by
  have hint : Integrable (fun V => 1 - plaqAvg N V) ν :=
    integrable_cont N _ (continuous_const.sub (continuous_plaqAvg N))
  have hI : ∫ V, (1 - plaqAvg N V) ∂ν = 1 - κ₀ := by
    rw [integral_sub (integrable_const _) (integrable_cont N _ (continuous_plaqAvg N)), hκ]
    simp
  have hM := mul_meas_ge_le_integral_of_nonneg
    (Filter.Eventually.of_forall (fun V => by
      show (0 : ℝ) ≤ 1 - plaqAvg N V
      linarith [plaqAvg_le_one N V])) hint y
  rw [hI] at hM
  rw [le_div_iff₀ hy, mul_comm]
  exact hM

/-- **(iv) Markov, one plaquette**: ν(1 − Re U_p ≥ y) ≤ |plaqs|·(1 − κ₀)/y -/
theorem markov_plaq (ν : Measure (Lk N → QBall)) [IsProbabilityMeasure ν] (κ₀ : ℝ)
    (hκ : ∫ V, plaqAvg N V ∂ν = κ₀) (y : ℝ) (hy : 0 < y) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ν.real {V | y ≤ 1 - (hol N V p).re} ≤ (plaqs N).card * (1 - κ₀) / y := by
  have hc : (0 : ℝ) < (plaqs N).card := by exact_mod_cast plaqs_card_pos N
  have hsub : {V | y ≤ 1 - (hol N V p).re} ⊆ {V | y / (plaqs N).card ≤ 1 - plaqAvg N V} := by
    intro V hV
    simp only [Set.mem_ofPred_eq] at hV ⊢
    rw [div_le_iff₀ hc]
    have := one_sub_re_le N V p hp
    linarith
  calc ν.real {V | y ≤ 1 - (hol N V p).re}
      ≤ ν.real {V | y / (plaqs N).card ≤ 1 - plaqAvg N V} := measureReal_mono hsub
    _ ≤ (1 - κ₀) / (y / (plaqs N).card) := markov_avg N ν κ₀ hκ _ (div_pos hy hc)
    _ = (plaqs N).card * (1 - κ₀) / y := by field_simp

/-- **non-flatness, quantitative**: ν(1 − Ȳ ≥ y) ≥ (1 − κ₀ − y)/2 -/
theorem nonflat_avg (ν : Measure (Lk N → QBall)) [IsProbabilityMeasure ν] (κ₀ : ℝ)
    (hκ : ∫ V, plaqAvg N V ∂ν = κ₀) (y : ℝ) (hy : 0 ≤ y) :
    (1 - κ₀ - y) / 2 ≤ ν.real {V | y ≤ 1 - plaqAvg N V} := by
  set S := {V | y ≤ 1 - plaqAvg N V}
  have hS : MeasurableSet S :=
    measurableSet_le measurable_const (measurable_const.sub (continuous_plaqAvg N).measurable)
  have hpt : ∀ V, 1 - plaqAvg N V ≤ y + 2 * S.indicator (fun _ => (1 : ℝ)) V := by
    intro V
    by_cases hV : V ∈ S
    · rw [indicator_of_mem hV]; linarith [neg_one_le_plaqAvg N V]
    · rw [indicator_of_notMem hV]; simp only [S, Set.mem_ofPred_eq, not_le] at hV; linarith
  have hint : Integrable (fun V => 1 - plaqAvg N V) ν :=
    integrable_cont N _ (continuous_const.sub (continuous_plaqAvg N))
  have hI : ∫ V, (1 - plaqAvg N V) ∂ν = 1 - κ₀ := by
    rw [integral_sub (integrable_const _) (integrable_cont N _ (continuous_plaqAvg N)), hκ]
    simp
  have h2 : Integrable (fun V => y + 2 * S.indicator (fun _ => (1 : ℝ)) V) ν :=
    (integrable_const _).add (((integrable_const (1 : ℝ)).indicator hS).const_mul 2)
  have hR : ∫ V, (y + 2 * S.indicator (fun _ => (1 : ℝ)) V) ∂ν = y + 2 * ν.real S := by
    rw [integral_add (integrable_const _) (((integrable_const (1 : ℝ)).indicator hS).const_mul 2),
      integral_const, integral_const_mul, integral_indicator hS, setIntegral_const]
    simp
  have := integral_mono hint h2 hpt
  rw [hI, hR] at this
  linarith

end MarkovGen

section Limit

variable {E : Type*} [MeasurableSpace E] [TopologicalSpace E] [OpensMeasurableSpace E]

/-- **(v) generic**: weak limits keep an integral that is eventually equal to κ₀ -/
theorem limit_integral_eq (F : BoundedContinuousFunction E ℝ) (ν : ℕ → ProbabilityMeasure E) (κ₀ : ℝ)
    (hev : ∀ᶠ n in atTop, ∫ ω, F ω ∂(ν n : Measure E) = κ₀) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (νl : ProbabilityMeasure E) (hlim : Tendsto (fun k => ν (φ k)) atTop (𝓝 νl)) :
    ∫ ω, F ω ∂(νl : Measure E) = κ₀ := by
  have h1 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) F
  have h2 : Tendsto (fun k => ∫ ω, F ω ∂(ν (φ k) : Measure E)) atTop (𝓝 κ₀) :=
    tendsto_const_nhds.congr' ((hφ.tendsto_atTop.eventually hev).mono (fun k hk => hk.symm))
  exact tendsto_nhds_unique h1 h2

end Limit

/-! ## The box block map: the coarse plaquette average of the pushed-forward Wilson measure -/

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **(i)** Y(m, k, β): coarse plaquette average of the k-fold pushed-forward normalised Wilson measure,
fine torus (ℤ/2^(m+k) L)⁴, coarse torus (ℤ/2^m L)⁴ -/
noncomputable def Yc (m k : ℕ) (β : ℝ) : ℝ :=
  ∫ ω, plaqAvg (2 ^ m * L) (downK L hr m k ω) ∂(wilsonProb (2 ^ (m + k) * L) β : Measure _)

/-- **(ii)** continuity of Y in β -/
theorem continuous_Yc (m k : ℕ) : Continuous (Yc L hr m k) :=
  continuous_integral_wilsonProb (2 ^ (m + k) * L) _
    ((continuous_plaqAvg (2 ^ m * L)).comp (PushReduceK.continuous_downK L hr m k))

/-- **(iii) existence of the tuned coupling** (intermediate value form) -/
theorem exists_tuning (m k : ℕ) {β₁ β₂ κ₀ : ℝ} (h12 : β₁ ≤ β₂)
    (hκ : κ₀ ∈ uIcc (Yc L hr m k β₁) (Yc L hr m k β₂)) :
    ∃ β ∈ Icc β₁ β₂, Yc L hr m k β = κ₀ := by
  have h := intermediate_value_uIcc (continuous_Yc L hr m k).continuousOn hκ
  obtain ⟨β, hβ, e⟩ := h
  rw [uIcc_of_le h12] at hβ
  exact ⟨β, hβ, e⟩

/-- the tuning equation at level m₀ for a coupling sequence indexed by the fine level -/
def Tuned (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) : Prop := ∀ k, Yc L hr m₀ k (β (m₀ + k)) = κ₀

/-- a tuned sequence exists as soon as κ₀ is bracketed at every k -/
theorem tuned_exists (m₀ : ℕ) (κ₀ : ℝ)
    (hbr : ∀ k, ∃ β₁ β₂, β₁ ≤ β₂ ∧ κ₀ ∈ uIcc (Yc L hr m₀ k β₁) (Yc L hr m₀ k β₂)) :
    ∃ β : ℕ → ℝ, Tuned L hr m₀ κ₀ β := by
  choose β₁ β₂ h12 hκ using hbr
  choose b hb e using fun k => exists_tuning L hr m₀ k (h12 k) (hκ k)
  exact ⟨fun n => b (n - m₀), fun k => by simpa using e k⟩

/-- the pushed-forward measure (k steps) of the normalised Wilson measure -/
noncomputable def νk (m k : ℕ) (β : ℝ) : ProbabilityMeasure (Lk (2 ^ m * L) → QBall) :=
  (wilsonProb (2 ^ (m + k) * L) β).map (PushReduceK.continuous_downK L hr m k).measurable.aemeasurable

theorem integral_νk (m k : ℕ) (β : ℝ) :
    ∫ V, plaqAvg (2 ^ m * L) V ∂(νk L hr m k β : Measure _) = Yc L hr m k β := by
  unfold νk Yc
  rw [ProbabilityMeasure.toMeasure_map, integral_map
    (PushReduceK.continuous_downK L hr m k).measurable.aemeasurable
    (continuous_plaqAvg _).aestronglyMeasurable]

/-- **(iv) Markov under the tuning equation**: one coarse plaquette at level m₀ -/
theorem tuned_markov_plaq (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β) (k : ℕ)
    (y : ℝ) (hy : 0 < y) (p : Lk (2 ^ m₀ * L) × Fin 4) (hp : p ∈ plaqs (2 ^ m₀ * L)) :
    (νk L hr m₀ k (β (m₀ + k)) : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤
      (plaqs (2 ^ m₀ * L)).card * (1 - κ₀) / y :=
  markov_plaq _ _ κ₀ ((integral_νk L hr m₀ k _).trans (ht k)) y hy p hp

/-- the chain's family of fine measures: the normalised Wilson measures with couplings β n -/
noncomputable def wFam (β : ℕ → ℝ) : ∀ n, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L n)) :=
  fun n => wilsonProb (2 ^ n * L) (β n)

/-- the chain's pushed-forward measure at level m₀ from level m₀ + k is `νk` -/
theorem νP_wFam (β : ℕ → ℝ) (m k : ℕ) :
    ((ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (m + k) m :
      ProbabilityMeasure _) : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) =
      (νk L hr m k (β (m + k)) : Measure (Lk (2 ^ m * L) → QBall)) := by
  rw [νP_eq_map]
  unfold νk
  rw [ProbabilityMeasure.toMeasure_map]
  rfl

/-- the coarse plaquette average as a bounded continuous function on the configurations of level m -/
noncomputable def avgBC (m : ℕ) : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ :=
  BoundedContinuousFunction.mkOfCompact ⟨plaqAvg (2 ^ m * L), continuous_plaqAvg _⟩

/-- **(v) the limit at level m₀ is non-degenerate**: along any subsequence for which the chain's pushed-forward
measures at level m₀ converge, the limit has coarse plaquette average κ₀. -/
theorem tuned_limit_avg (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β)
    (φ : ℕ → ℕ) (hφ : StrictMono φ) (νl : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)))
    (hlim : Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m₀)
      atTop (𝓝 νl)) :
    ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl : Measure _) = κ₀ := by
  have h := limit_integral_eq (avgBC L m₀)
    (fun n => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m₀) κ₀ ?_ φ hφ νl hlim
  · exact h
  · refine Filter.eventually_atTop.2 ⟨m₀, fun n hn => ?_⟩
    obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
    show ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(_ : Measure _) = κ₀
    rw [νP_wFam L hr β m₀ k, integral_νk]
    exact ht k

/-- **(v) with the subsequence**: for a tuned coupling sequence, a subsequence common to all levels exists along
which the chain's pushed-forward measures converge at every level; the limit at level m₀ has coarse plaquette
average κ₀, charges {Ȳ < 1} when κ₀ < 1, and obeys the Markov bounds of the tuning. -/
theorem tuned_limit_nondegenerate (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)),
      (∀ m, Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m)
        atTop (𝓝 (νl m))) ∧
      ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (2 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤
          (plaqs (2 ^ m₀ * L)).card * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤ (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (2 ^ m₀ * L) V}) := by
  obtain ⟨φ, hφ, νl, hlim⟩ := WeakUltravioletExistence.exists_common_subseq
    (fun n m => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m)
  have hκ := tuned_limit_avg L hr m₀ κ₀ β ht φ hφ (νl m₀) (hlim m₀)
  refine ⟨φ, hφ, νl, hlim, hκ, fun y hy p hp => ?_, fun y hy => ?_⟩
  · exact markov_plaq (2 ^ m₀ * L) (νl m₀ : Measure (Lk (2 ^ m₀ * L) → QBall)) κ₀ hκ y hy p hp
  · exact nonflat_avg (2 ^ m₀ * L) (νl m₀ : Measure (Lk (2 ^ m₀ * L) → QBall)) κ₀ hκ y hy

end Box

end TunedCoupling

#print axioms TunedCoupling.continuous_Yc
#print axioms TunedCoupling.exists_tuning
#print axioms TunedCoupling.tuned_exists
#print axioms TunedCoupling.tuned_markov_plaq
#print axioms TunedCoupling.tuned_limit_avg
#print axioms TunedCoupling.tuned_limit_nondegenerate
