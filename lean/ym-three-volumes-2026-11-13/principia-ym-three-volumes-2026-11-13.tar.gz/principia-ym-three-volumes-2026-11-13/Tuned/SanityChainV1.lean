import Tuned.ChainYV1
/-!
**Checks on the hypotheses of `chain_end_to_end_tuned_box`: satisfiable, and what the trivial choices give.**

* `hY_trivial` : κ m := −1 satisfies the lower-bound hypothesis at every level (so it is not empty), but then
  P₁ m = 12/yh m: the plaquette part of the rarity is paid only in a useless form.  The content of the hypothesis
  at the levels m ≠ m₀ is that κ m can be taken close to 1;
* `kappa_le_one` : κ m ≤ 1 is forced (κ m ≤ Y ≤ 1), so P₁ m ≥ 0 and κ m cannot absorb the bound;
* `P1_lower` : P₁ m = 6(1 − κ m)/yh m ≥ 6(1 − Y(m, k, β))/yh m for every k beyond the threshold: the number in the
  rarity field is bounded below by a defined quantity;
* `hS_empty` : with no background points (pts = ∅) the background hypothesis holds with S = 0.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP PushLocal
open scoped ENNReal

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem hY_trivial (β : ℕ → ℝ) : ∀ m, ∀ᶠ k in atTop, (-1 : ℝ) ≤ Yc L hr m k (β (m + k)) :=
  fun m => Filter.Eventually.of_forall (fun k => (Yc_mem_Icc L hr m k _).1)

theorem kappa_le_one (β : ℕ → ℝ) (κ : ℕ → ℝ) (hY : ∀ m, ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k))) (m : ℕ) :
    κ m ≤ 1 := by
  obtain ⟨k, hk⟩ := (hY m).exists
  exact hk.trans (Yc_mem_Icc L hr m k _).2

theorem P1_lower (β : ℕ → ℝ) (κ : ℕ → ℝ) (yh : ℕ → ℝ) (hyh : ∀ m, 0 < yh m) (m k : ℕ)
    (hk : κ m ≤ Yc L hr m k (β (m + k))) :
    6 * (1 - Yc L hr m k (β (m + k))) / yh m ≤ 6 * (1 - κ m) / yh m ∧ 0 ≤ 6 * (1 - Yc L hr m k (β (m + k))) / yh m := by
  constructor
  · apply div_le_div_of_nonneg_right _ (hyh m).le; linarith
  · apply div_nonneg _ (hyh m).le; linarith [(Yc_mem_Icc L hr m k (β (m + k))).2]

theorem hS_empty (β : ℕ → ℝ) {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (f : ∀ m, Pt m → ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ℝ) (θ : ℕ → ℝ) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ (fun _ _ => (∅ : Finset (Pt m))) m i,
      (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) {ω | θ m < f m x ω} ≤ (0 : ℝ≥0∞) := by
  intro m
  exact Filter.Eventually.of_forall (fun n i _ x hx => absurd hx (Finset.notMem_empty x))

end Box

end TunedCoupling

#print axioms TunedCoupling.hY_trivial
#print axioms TunedCoupling.kappa_le_one
#print axioms TunedCoupling.P1_lower
#print axioms TunedCoupling.hS_empty
