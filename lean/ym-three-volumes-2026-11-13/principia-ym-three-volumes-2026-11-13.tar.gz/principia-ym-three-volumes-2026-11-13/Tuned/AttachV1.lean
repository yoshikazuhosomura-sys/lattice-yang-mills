import Tuned.TransV1
/-!
**Attaching the tuning to the conclusion of the chain theorem, and checks against trivial choices.**

* `attach_tuned` : whatever the chain theorem `ChainBlockMap.chain_end_to_end_blockMap` concludes about its common
  subsequence and limits (any property P of (φ, νl)), for the family of normalised Wilson measures with a tuned
  coupling sequence the same (φ, νl) also satisfy: the level-m₀ limit has coarse plaquette average κ₀, the
  six-orientation Markov bound (in the limit), the |plaqs| Markov bound, and the non-flatness bound;
* sanity: `Yc_zero_steps` (k = 0 is the plain Wilson average), `Yc_mem_Icc` and `tuned_kappa_mem` (κ₀ ∈ [−1, 1]),
  `zero_not_tuned` (β ≡ 0 does not satisfy the tuning equation unless κ₀ = Y(m₀, 0, 0)), `plaqs_nonempty`,
  `limit_not_flat` (κ₀ < 1 ⇒ the limit charges a set where Ȳ ≤ (1 + κ₀)/2).

Paper correspondence: the tuning (a) inserted into the conclusion of the chain theorem (Theorem W chain), level m₀.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP FoldPeierls FoldAffine PushLocal

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- the limit of translation-invariant probability measures is translation invariant (on continuous functions) -/
theorem limit_shV_invariant (m₀ : ℕ) (β : ℕ → ℝ) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (νl : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)))
    (hlim : Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m₀)
      atTop (𝓝 νl))
    (v : Site (2 ^ m₀ * L)) (f : (Lk (2 ^ m₀ * L) → QBall) → ℝ) (hf : Continuous f) :
    ∫ V, f (shV _ v V) ∂(νl : Measure (Lk (2 ^ m₀ * L) → QBall)) =
      ∫ V, f V ∂(νl : Measure (Lk (2 ^ m₀ * L) → QBall)) := by
  let F : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)) ℝ :=
    BoundedContinuousFunction.mkOfCompact ⟨f, hf⟩
  let G : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)) ℝ :=
    BoundedContinuousFunction.mkOfCompact ⟨fun V => f (shV _ v V), hf.comp (continuous_shV _ v)⟩
  have h1 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) F
  have h2 := (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp hlim) G
  have hn : ∀ᶠ n in atTop,
      ∫ V, G V ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m₀ : Measure _) =
      ∫ V, F V ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m₀ : Measure _) := by
    refine Filter.eventually_atTop.2 ⟨m₀, fun n hn => ?_⟩
    obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hn
    show ∫ V, f (shV _ v V) ∂(_ : Measure _) = ∫ V, f V ∂(_ : Measure _)
    rw [νP_wFam L hr β m₀ k]
    exact νk_shV_invariant L hr m₀ k _ v f hf
  have hev := hφ.tendsto_atTop.eventually hn
  exact tendsto_nhds_unique (h2.congr' hev) h1

/-- **The tuning attached to the conclusion of the chain theorem.**  P is any property of the common subsequence
and of the limits (in the application: the conclusion `BlockConclusion …` and the observable part of
`chain_end_to_end_blockMap`, with μ := wFam L β, paths := boxPaths L, w := boxW L). -/
theorem attach_tuned (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β)
    (P : (ℕ → ℕ) → (∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) → Prop)
    (h : ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)),
      (∀ m, Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m)
        atTop (𝓝 (νl m))) ∧ P φ νl) :
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)),
      (∀ m, Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m)
        atTop (𝓝 (νl m))) ∧ P φ νl ∧
      ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (2 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤ (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (2 ^ m₀ * L) V}) := by
  obtain ⟨φ, hφ, νl, hlim, hP⟩ := h
  have hκ := tuned_limit_avg L hr m₀ κ₀ β ht φ hφ (νl m₀) (hlim m₀)
  refine ⟨φ, hφ, νl, hlim, hP, hκ, fun y hy p hp => ?_, fun y hy => ?_⟩
  · exact markov_plaq_six (2 ^ m₀ * L) (νl m₀ : Measure (Lk (2 ^ m₀ * L) → QBall))
      (fun v f hf => limit_shV_invariant L hr m₀ β φ hφ (νl m₀) (hlim m₀) v f hf) κ₀ hκ y hy p hp
  · exact nonflat_avg (2 ^ m₀ * L) (νl m₀ : Measure (Lk (2 ^ m₀ * L) → QBall)) κ₀ hκ y hy

/-! ### Sanity: the definitions are not trivial, and the hypothesis is not met by trivial choices -/

/-- k = 0: Y is the plaquette average of the normalised Wilson measure itself -/
theorem Yc_zero_steps (m : ℕ) (β : ℝ) :
    Yc L hr m 0 β = ∫ V, plaqAvg (2 ^ m * L) V ∂(wilsonProb (2 ^ m * L) β : Measure _) := rfl

theorem Yc_mem_Icc (m k : ℕ) (β : ℝ) : Yc L hr m k β ∈ Icc (-1 : ℝ) 1 := by
  rw [← integral_νk]
  have hi := integrable_cont (2 ^ m * L) (μ := (νk L hr m k β : Measure _)) _ (continuous_plaqAvg _)
  constructor
  · have := integral_mono (integrable_const (-1 : ℝ)) hi (fun V => neg_one_le_plaqAvg _ V)
    simpa using this
  · have := integral_mono hi (integrable_const (1 : ℝ)) (fun V => plaqAvg_le_one _ V)
    simpa using this

/-- the tuning equation forces κ₀ ∈ [−1, 1] -/
theorem tuned_kappa_mem (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β) : κ₀ ∈ Icc (-1 : ℝ) 1 := by
  rw [← ht 0]; exact Yc_mem_Icc L hr m₀ 0 _

/-- β ≡ 0 does not satisfy the tuning equation when κ₀ differs from the β = 0 value at k = 0 -/
theorem zero_not_tuned (m₀ : ℕ) (κ₀ : ℝ) (hκ : κ₀ ≠ Yc L hr m₀ 0 0) : ¬ Tuned L hr m₀ κ₀ (fun _ => 0) := by
  intro ht
  exact hκ (ht 0).symm

theorem plaqs_nonempty (N : ℕ) [NeZero N] : (plaqs N).Nonempty :=
  Finset.card_pos.mp (plaqs_card_pos N)

/-- κ₀ < 1: the level-m₀ limit is not concentrated on the flat set {Ȳ = 1}; quantitatively it gives mass at
least (1 − κ₀)/4 to {1 − Ȳ ≥ (1 − κ₀)/2} -/
theorem limit_not_flat (m₀ : ℕ) (κ₀ : ℝ) (hκ1 : κ₀ < 1)
    (νl : ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m₀)))
    (hκ : ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl : Measure (Lk (2 ^ m₀ * L) → QBall)) = κ₀) :
    (1 - κ₀) / 4 ≤ (νl : Measure (Lk (2 ^ m₀ * L) → QBall)).real
      {V | (1 - κ₀) / 2 ≤ 1 - plaqAvg (2 ^ m₀ * L) V} ∧ 0 < (1 - κ₀) / 4 := by
  have h := nonflat_avg (2 ^ m₀ * L) (νl : Measure (Lk (2 ^ m₀ * L) → QBall)) κ₀ hκ ((1 - κ₀) / 2)
    (by linarith)
  constructor
  · linarith
  · linarith

end Box

end TunedCoupling

#print axioms TunedCoupling.limit_shV_invariant
#print axioms TunedCoupling.attach_tuned
#print axioms TunedCoupling.Yc_zero_steps
#print axioms TunedCoupling.Yc_mem_Icc
#print axioms TunedCoupling.tuned_kappa_mem
#print axioms TunedCoupling.zero_not_tuned
#print axioms TunedCoupling.limit_not_flat
