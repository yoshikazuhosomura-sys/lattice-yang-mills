import Tuned.LinkDefV2
/-!
**A flat field is carried to a flat field by the box block map.**

Abstract part (any additive group G of sites, unit vectors e, a quaternion field U on G × Fin 4):
`FlatQ e U` : every link value is a unit quaternion and U(y,a) U(y+e_a,b) = U(y,b) U(y+e_b,a) for all a, b
(the plaquette relation: one transverse step and one longitudinal step can be exchanged).
* `comm_spine` : under `FlatQ`, a transverse step can be moved across the straight two-step spine;
* `pathProd_walk_flat` : for a flat field the product along every path of the block map's recipe
  (transverse walk · two straight steps · return of the transverse walk) is the straight two-step product;
* `blockMap_flat_val` : for r₀ ≤ 1 the box block map sends a flat field to U(2y,μ) U(2y+e_μ,μ);
* `blockMap_flatQ` : and the image is again flat (the coarse plaquette is the 2×2 fine square);
* `downK_flatQ` : the same for k steps (induction on k);
* `flatQ_of_re` : Re U_p = 1 for all unoriented plaquettes p ⇒ flat;  `plaqAvg_eq_one_of_flatQ` : flat ⇒ Ȳ = 1.

Paper correspondence: the upper end of the tuning bracket, part (i) (flat configurations are pushed to flat
configurations).
-/

namespace FlatPush

open WalkCast ChainBlockMap BoxWalk

local notation "ℍr" => Quaternion ℝ

section Abstract

variable {G : Type*} [AddCommGroup G]

/-- flat quaternion field: unit link values and the plaquette exchange relation -/
def FlatQ (e : Fin 4 → G) (U : G × Fin 4 → ℍr) : Prop :=
  (∀ ℓ, U ℓ * star (U ℓ) = 1) ∧ ∀ y a b, U (y, a) * U (y + e a, b) = U (y, b) * U (y + e b, a)

theorem star_mul_of_mul_star {q : ℍr} (h : q * star q = 1) : star q * q = 1 := by
  rw [Quaternion.star_mul_self, ← Quaternion.self_mul_star, h]

variable {e : Fin 4 → G} {U : G × Fin 4 → ℍr}

/-- the straight two-step product in direction μ from y -/
noncomputable def spine (e : Fin 4 → G) (U : G × Fin 4 → ℍr) (μ : Fin 4) (y : G) : ℍr := U (y, μ) * U (y + e μ, μ)

/-- **exchange of one transverse step with the spine** -/
theorem comm_spine (hf : FlatQ e U) (μ n : Fin 4) (y : G) :
    U (y, n) * spine e U μ (y + e n) = spine e U μ y * U (y + e μ + e μ, n) := by
  unfold spine
  have h1 := hf.2 y n μ
  have h2 := hf.2 (y + e μ) n μ
  have p : y + e n + e μ = y + e μ + e n := by abel
  rw [← mul_assoc, h1, p, mul_assoc, h2, ← mul_assoc]

variable (φ : (Fin 4 → ℤ) →+ G) (x : G)

/-- product along a cast list of signed links -/
noncomputable def pv (U : G × Fin 4 → ℍr) (γ : List Link) : ℍr := pathProd U (γ.map (linkCast φ x))

theorem pv_append (a b : List Link) : pv φ x U (a ++ b) = pv φ x U a * pv φ x U b := by
  simp [pv, pathProd, List.map_append, List.prod_append]

theorem pv_fwd_one (z : Fin 4 → ℤ) (n : Fin 4) : pv φ x U (fwd 1 z n) = U (x + φ z, n) := by
  simp [pv, fwd, pathProd, stepVal, linkCast]

theorem pv_fwd_neg (z : Fin 4 → ℤ) (n : Fin 4) :
    pv φ x U (fwd (-1) z n) = star (U (x + φ (z - WalkCast.ev n), n)) := by
  simp [pv, fwd, pathProd, stepVal, linkCast]

theorem pv_fwd_zero (z : Fin 4 → ℤ) (n : Fin 4) : pv φ x U (fwd 0 z n) = 1 := by
  simp [pv, fwd, pathProd]

theorem pv_back_one (w : Fin 4 → ℤ) (n : Fin 4) :
    pv φ x U (back 1 w n) = star (U (x + φ (w - WalkCast.ev n), n)) := by
  simp [pv, back, pathProd, stepVal, linkCast]

theorem pv_back_neg (w : Fin 4 → ℤ) (n : Fin 4) : pv φ x U (back (-1) w n) = U (x + φ w, n) := by
  simp [pv, back, pathProd, stepVal, linkCast]

theorem pv_back_zero (w : Fin 4 → ℤ) (n : Fin 4) : pv φ x U (back 0 w n) = 1 := by
  simp [pv, back, pathProd]

/-- **one transverse step and its return around the spine** -/
theorem pv_step (hf : FlatQ (fun a => φ (WalkCast.ev a)) U) (μ n : Fin 4) (d : ℤ)
    (hd : d = -1 ∨ d = 0 ∨ d = 1) (z z' w : Fin 4 → ℤ) (hz : z' = z + d • WalkCast.ev n)
    (hw : w = z' + 2 • WalkCast.ev μ) :
    pv φ x U (fwd d z n) * spine (fun a => φ (WalkCast.ev a)) U μ (x + φ z') * pv φ x U (back d w n) =
      spine (fun a => φ (WalkCast.ev a)) U μ (x + φ z) := by
  subst hz hw
  rcases hd with rfl | rfl | rfl
  · rw [pv_fwd_neg, pv_back_neg]
    have hc := comm_spine hf μ n (x + φ (z - WalkCast.ev n))
    have p1' : x + φ (z - WalkCast.ev n) + φ (WalkCast.ev n) = x + φ z := by
      simp only [map_sub]; abel
    have p2 : x + φ (z - WalkCast.ev n) + φ (WalkCast.ev μ) + φ (WalkCast.ev μ) =
        x + φ (z + (-1 : ℤ) • WalkCast.ev n + 2 • WalkCast.ev μ) := by
      simp only [map_add, map_sub, map_zsmul, map_nsmul]; abel
    have p3 : x + φ (z + (-1 : ℤ) • WalkCast.ev n) = x + φ (z - WalkCast.ev n) := by
      simp only [map_add, map_sub, map_zsmul]; abel
    rw [p1', p2] at hc
    rw [p3, mul_assoc, ← hc, ← mul_assoc, star_mul_of_mul_star (hf.1 _), one_mul]
  · rw [pv_fwd_zero, pv_back_zero, one_mul, mul_one, zero_smul, add_zero]
  · rw [pv_fwd_one, pv_back_one]
    have hc := comm_spine hf μ n (x + φ z)
    have p1 : x + φ z + φ (WalkCast.ev n) = x + φ (z + (1 : ℤ) • WalkCast.ev n) := by
      simp only [map_add, one_smul]; abel
    have p2 : x + φ z + φ (WalkCast.ev μ) + φ (WalkCast.ev μ) =
        x + φ (z + (1 : ℤ) • WalkCast.ev n + 2 • WalkCast.ev μ - WalkCast.ev n) := by
      simp only [map_add, map_sub, one_smul, map_nsmul]; abel
    rw [p1, p2] at hc
    rw [hc, mul_assoc, hf.1 _, mul_one]

theorem dv_cases (i : Fin 3) : dv i = -1 ∨ dv i = 0 ∨ dv i = 1 := by
  fin_cases i <;> simp [dv]

/-- **the product along each path of the recipe is the straight two-step product** (flat field) -/
theorem pathProd_walk_flat (hf : FlatQ (fun a => φ (WalkCast.ev a)) U) (μ : Fin 4) (o : Fin 6)
    (A : Fin 3 → Fin 3) :
    pathProd U ((walk μ o A).map (linkCast φ x)) = spine (fun a => φ (WalkCast.ev a)) U μ x := by
  show pv φ x U (walk μ o A) = _
  simp only [walk]
  set n0 := tr μ (ord o 0)
  set n1 := tr μ (ord o 1)
  set n2 := tr μ (ord o 2)
  set d0 := dv (A (ord o 0))
  set d1 := dv (A (ord o 1))
  set d2 := dv (A (ord o 2))
  have hd0 : d0 = -1 ∨ d0 = 0 ∨ d0 = 1 := dv_cases _
  have hd1 : d1 = -1 ∨ d1 = 0 ∨ d1 = 1 := dv_cases _
  have hd2 : d2 = -1 ∨ d2 = 0 ∨ d2 = 1 := dv_cases _
  simp only [pv_append]
  set z3 := d0 • WalkCast.ev n0 + d1 • WalkCast.ev n1 + d2 • WalkCast.ev n2
  have hmid : pv φ x U [(1, z3, μ), (1, z3 + WalkCast.ev μ, μ)] =
      spine (fun a => φ (WalkCast.ev a)) U μ (x + φ z3) := by
    simp [pv, pathProd, stepVal, linkCast, spine, map_add, add_assoc]
  rw [hmid]
  have s2 := pv_step φ x hf μ n2 d2 hd2 (d0 • WalkCast.ev n0 + d1 • WalkCast.ev n1) z3
    (z3 + 2 • WalkCast.ev μ) rfl rfl
  have s1 := pv_step φ x hf μ n1 d1 hd1 (d0 • WalkCast.ev n0) (d0 • WalkCast.ev n0 + d1 • WalkCast.ev n1)
    (z3 + 2 • WalkCast.ev μ - d2 • WalkCast.ev n2) rfl (by simp only [z3]; abel)
  have s0 := pv_step φ x hf μ n0 d0 hd0 0 (d0 • WalkCast.ev n0)
    (z3 + 2 • WalkCast.ev μ - d2 • WalkCast.ev n2 - d1 • WalkCast.ev n1) (by simp) (by simp only [z3]; abel)
  rw [map_zero, add_zero] at s0
  calc _ = pv φ x U (fwd d0 0 n0) * (pv φ x U (fwd d1 (d0 • WalkCast.ev n0) n1) *
          (pv φ x U (fwd d2 (d0 • WalkCast.ev n0 + d1 • WalkCast.ev n1) n2) *
            spine (fun a => φ (WalkCast.ev a)) U μ (x + φ z3) *
            pv φ x U (back d2 (z3 + 2 • WalkCast.ev μ) n2)) *
          pv φ x U (back d1 (z3 + 2 • WalkCast.ev μ - d2 • WalkCast.ev n2) n1)) *
        pv φ x U (back d0 (z3 + 2 • WalkCast.ev μ - d2 • WalkCast.ev n2 - d1 • WalkCast.ev n1) n0) := by
          simp only [mul_assoc]
    _ = _ := by rw [s2, s1, s0]

/-- the 2×2 square: two spines in directions a, b commute around the square -/
theorem spine_square (hf : FlatQ e U) (a b : Fin 4) (Y : G) :
    spine e U a Y * spine e U b (Y + e a + e a) = spine e U b Y * spine e U a (Y + e b + e b) := by
  have p : Y + e a + e a + e b = Y + e b + e a + e a := by abel
  calc spine e U a Y * spine e U b (Y + e a + e a)
      = spine e U a Y * U (Y + e a + e a, b) * U (Y + e b + e a + e a, b) := by
        rw [mul_assoc, ← p]; rfl
    _ = U (Y, b) * spine e U a (Y + e b) * U (Y + e b + e a + e a, b) := by
        rw [comm_spine hf a b Y]
    _ = U (Y, b) * (U (Y + e b, b) * spine e U a (Y + e b + e b)) := by
        rw [mul_assoc, ← comm_spine hf a b (Y + e b)]
    _ = spine e U b Y * spine e U a (Y + e b + e b) := by
        unfold spine; simp only [mul_assoc]

theorem spine_unit (hf : FlatQ e U) (μ : Fin 4) (y : G) : spine e U μ y * star (spine e U μ y) = 1 := by
  unfold spine
  rw [star_mul, mul_assoc, ← mul_assoc (U (y + e μ, μ)), hf.1, one_mul, hf.1]

theorem norm_eq_one_of_unit {q : ℍr} (h : q * star q = 1) : ‖q‖ = 1 := by
  have h2 : ((Quaternion.normSq q : ℝ) : ℍr) = 1 := by rw [← Quaternion.self_mul_star, h]
  have h3 : Quaternion.normSq q = 1 := by
    have := congrArg QuaternionAlgebra.re h2
    simp only [Quaternion.re_coe] at this
    exact this.trans rfl
  rw [Quaternion.normSq_eq_norm_mul_self] at h3
  have h4 : 0 ≤ ‖q‖ := norm_nonneg q
  nlinarith

theorem unit_of_norm_eq_one {q : ℍr} (h : ‖q‖ = 1) : q * star q = 1 := by
  rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, h]; simp

theorem eq_one_of_re {q : ℍr} (hn : ‖q‖ ≤ 1) (hre : q.re = 1) : q = 1 := by
  have h := norm_sub_sq_real q 1
  have hi : inner ℝ q (1 : ℍr) = q.re := by rw [Quaternion.inner_def, star_one, mul_one]
  rw [hi, hre, norm_one] at h
  have h0 : ‖q - 1‖ ^ 2 ≤ 0 := by nlinarith [norm_nonneg q]
  have : ‖q - 1‖ = 0 := by nlinarith [norm_nonneg (q - 1)]
  exact sub_eq_zero.mp (norm_eq_zero.mp this)

/-- the plaquette relation from a trivial holonomy -/
theorem exch_of_hol {A B C D : ℍr} (hC : C * star C = 1) (hD : D * star D = 1)
    (h : A * B * star C * star D = 1) : A * B = D * C := by
  calc A * B = A * B * (star C * (star D * D) * C) := by
        rw [star_mul_of_mul_star hD, mul_one, star_mul_of_mul_star hC, mul_one]
    _ = (A * B * star C * star D) * (D * C) := by simp only [mul_assoc]
    _ = D * C := by rw [h, one_mul]

end Abstract

section Torus

open TorusRP

variable (N : ℕ) [NeZero N]

omit [NeZero N] in
/-- flat ⇒ every plaquette holonomy is 1 -/
theorem holQ_eq_one {U : Lk N → ℍr}
    (hf : FlatQ (TorusRP.ev N) U) (p : Lk N × Fin 4) : holQ N U p = 1 := by
  obtain ⟨⟨y, a⟩, b⟩ := p
  simp only [holQ]
  rw [hf.2 y a b, mul_assoc (U (y, b)), hf.1, mul_one, hf.1]

theorem plaqAvg_eq_one_of_flatQ (ω : Lk N → QBall) (hf : FlatQ (TorusRP.ev N) (Uq N ω)) :
    TunedCoupling.plaqAvg N ω = 1 := by
  have hc : ((plaqs N).card : ℝ) ≠ 0 := by exact_mod_cast (TunedCoupling.plaqs_card_pos N).ne'
  unfold TunedCoupling.plaqAvg
  have e : ∀ p ∈ plaqs N, (hol N ω p).re = 1 := fun p _ => by
    rw [hol, holQ_eq_one N hf p]; rfl
  rw [Finset.sum_congr rfl e, Finset.sum_const, nsmul_eq_mul, mul_one, div_self hc]

/-- **Re U_p = 1 on every unoriented plaquette ⇒ flat** -/
theorem flatQ_of_re (ω : Lk N → QBall) (h : ∀ p ∈ plaqs N, (hol N ω p).re = 1) :
    FlatQ (TorusRP.ev N) (Uq N ω) := by
  have hn : ∀ ℓ, ‖Uq N ω ℓ‖ = 1 := by
    intro ℓ
    have h1 := TunedCoupling.linkDef_le N ℓ ω
    rw [h _ (TunedCoupling.plaqOf_mem N ℓ)] at h1
    have h2 : ‖Uq N ω ℓ‖ ≤ 1 := mem_closedBall_zero_iff.1 (ω ℓ).2
    show ‖((ω ℓ : QBall) : Quaternion ℝ)‖ = 1
    exact le_antisymm h2 (by simpa using h1)
  have hu : ∀ ℓ, Uq N ω ℓ * star (Uq N ω ℓ) = 1 := fun ℓ => unit_of_norm_eq_one (hn ℓ)
  have hhol : ∀ p ∈ plaqs N, hol N ω p = 1 := fun p hp => by
    apply eq_one_of_re _ (h p hp)
    have := abs_re_le (hol N ω p)
    simp only [hol, holQ]
    rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star, hn, hn, hn, hn]; norm_num
  have hlt : ∀ y (a b : Fin 4), a < b →
      Uq N ω (y, a) * Uq N ω (y + TorusRP.ev N a, b) = Uq N ω (y, b) * Uq N ω (y + TorusRP.ev N b, a) := by
    intro y a b hab
    have hp : (((y, a), b) : Lk N × Fin 4) ∈ plaqs N := Finset.mem_filter.mpr ⟨Finset.mem_univ _, hab⟩
    have := hhol _ hp
    simp only [hol, holQ] at this
    exact exch_of_hol (hu _) (hu _) this
  refine ⟨hu, fun y a b => ?_⟩
  rcases lt_trichotomy a b with hab | rfl | hab
  · exact hlt y a b hab
  · rfl
  · exact (hlt y b a hab).symm

end Torus

section Box

variable (L : ℕ) [NeZero L]

omit [NeZero L] in
theorem red_ev (m : ℕ) (a : Fin 4) :
    red L m (WalkCast.ev a) = TorusRP.ev (2 ^ (m + 1) * L) a := by
  funext i
  by_cases h : i = a
  · subst h; simp [red, WalkCast.ev, TorusRP.ev]
  · simp [red, WalkCast.ev, TorusRP.ev, h]

theorem double_one (m : ℕ) : double L m 1 = 1 + 1 := by
  have := double_intCast L m 1
  push_cast at this
  rw [this]; norm_num

/-- the fine base point of the shifted coarse site -/
theorem base_add_ev (m : ℕ) (y : Site L m) (a c : Fin 4) :
    base L m (y + TorusRP.ev (2 ^ m * L) a, c) =
      base L m (y, c) + TorusRP.ev (2 ^ (m + 1) * L) a + TorusRP.ev (2 ^ (m + 1) * L) a := by
  funext i
  simp only [base, Pi.add_apply, map_add]
  by_cases h : i = a
  · subst h; simp [TorusRP.ev, double_one, add_assoc]
  · simp [TorusRP.ev, h]

variable {r₀ : ℝ} (hr : 0 < r₀)

/-- **for r₀ ≤ 1 the box block map sends a flat field to the straight two-step products** -/
theorem blockMap_flat_val (hr1 : r₀ ≤ 1) (m : ℕ) (U : Cfg (BoxLk L (m + 1)))
    (hf : FlatQ (TorusRP.ev (2 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr))) (b : BoxLk L m) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
      spine (TorusRP.ev (2 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base L m b) := by
  have he : (fun a => red L m (WalkCast.ev a)) = TorusRP.ev (2 ^ (m + 1) * L) := funext (red_ev L m)
  have hf' : FlatQ (fun a => red L m (WalkCast.ev a)) (fun ℓ => (U ℓ : ℍr)) := by rw [he]; exact hf
  have hpath : ∀ o A, pathProd (fun ℓ => (U ℓ : ℍr)) (boxPathsIdx L m b o A) =
      spine (TorusRP.ev (2 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base L m b) := by
    intro o A
    have := pathProd_walk_flat (red L m) (base L m b) hf' b.2 o A
    rw [he] at this
    exact this
  have hsix : sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr)) =
      spine (TorusRP.ev (2 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr)) b.2 (base L m b) := by
    unfold sixAvg
    simp only [hpath, ← Finset.sum_smul, sixWeight_total, one_smul]
  rw [boxMap_eq L hr, hsix]
  have hn := norm_eq_one_of_unit (spine_unit hf b.2 (base L m b))
  rw [(retract_of_le hr (by rw [hn]; exact hr1)).1, hn, inv_one, one_smul]

/-- **flat ⇒ flat under one step of the box block map** (r₀ ≤ 1) -/
theorem blockMap_flatQ (hr1 : r₀ ≤ 1) (m : ℕ) (U : Cfg (BoxLk L (m + 1)))
    (hf : FlatQ (TorusRP.ev (2 ^ (m + 1) * L)) (fun ℓ => (U ℓ : ℍr))) :
    FlatQ (TorusRP.ev (2 ^ m * L)) (fun b => (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr)) := by
  refine ⟨fun b => ?_, fun y a c => ?_⟩
  · dsimp only
    rw [blockMap_flat_val L hr hr1 m U hf b]; exact spine_unit hf _ _
  · dsimp only
    rw [blockMap_flat_val L hr hr1 m U hf, blockMap_flat_val L hr hr1 m U hf,
      blockMap_flat_val L hr hr1 m U hf, blockMap_flat_val L hr hr1 m U hf]
    rw [base_add_ev, base_add_ev]
    have hy : ∀ d : Fin 4, base L m (y, d) = base L m (y, a) := fun d => rfl
    rw [hy c]
    exact spine_square hf a c _

/-- **flat ⇒ flat under k steps** (r₀ ≤ 1) -/
theorem downK_flatQ (hr1 : r₀ ≤ 1) (m : ℕ) : ∀ (k : ℕ) (U : Cfg (BoxLk L (m + k))),
    FlatQ (TorusRP.ev (2 ^ (m + k) * L)) (fun ℓ => (U ℓ : ℍr)) →
      FlatQ (TorusRP.ev (2 ^ m * L)) (fun b => (PushLocal.downK L hr m k U b : ℍr))
  | 0, U, hf => hf
  | k + 1, U, hf => downK_flatQ hr1 m k _ (blockMap_flatQ L hr hr1 (m + k) U hf)

/-- **(i) of the upper end**: if every fine plaquette has Re U_p = 1, then after k block steps the coarse plaquette
average is 1 (r₀ ≤ 1) -/
theorem plaqAvg_downK_of_flat (hr1 : r₀ ≤ 1) (m k : ℕ) (ω : Cfg (BoxLk L (m + k)))
    (h : ∀ p ∈ TorusRP.plaqs (2 ^ (m + k) * L), (TorusRP.hol (2 ^ (m + k) * L) ω p).re = 1) :
    TunedCoupling.plaqAvg (2 ^ m * L) (PushLocal.downK L hr m k ω) = 1 :=
  plaqAvg_eq_one_of_flatQ _ _ (downK_flatQ L hr hr1 m k ω (flatQ_of_re _ ω h))

end Box

end FlatPush

#print axioms FlatPush.pathProd_walk_flat
#print axioms FlatPush.blockMap_flatQ
#print axioms FlatPush.downK_flatQ
#print axioms FlatPush.plaqAvg_downK_of_flat
