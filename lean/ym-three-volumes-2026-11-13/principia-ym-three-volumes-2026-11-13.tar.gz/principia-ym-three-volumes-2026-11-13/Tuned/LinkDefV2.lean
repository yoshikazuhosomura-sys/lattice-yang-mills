import Tuned.HaarMeanV1
/-!
**The length defect of the coarse links is controlled by the plaquettes; the chain with this background part.**

The coarse links are values of the radial retraction (closed unit ball).  For a link ℓ, `plaqOf ℓ` is an unoriented
plaquette containing ℓ, and 1 − ‖U_ℓ‖ ≤ 1 − Re U_{plaqOf ℓ} (`linkDef_le`): the length defect (how much the block
average collapsed) is bounded deterministically by one plaquette variable.  Hence, taking the background part of the
two-stage index to be the length defects of the links of the block (`linkDef`), the background hypothesis of
`chain_end_to_end_tuned_box` is discharged with S m = 6(1 − κ m)/θ m (`hS_linkDef`).  In
`chain_end_to_end_tuned_box_links` the measure hypotheses that replace the rarity field are the tuning equation at
level m₀ and the lower bounds κ m ≤ Y at the levels m ≠ m₀; the other fields of the chain theorem (reflection
positivity `hΘp` and symmetry `hsym` of the pushed-forward measures, `hpos`, `hbr`, `HR` through s, the coupling
flow `HE`, the observable fields) remain hypotheses.  The length defect is dominated by one plaquette variable, so
this background part adds no information independent of the plaquettes.  The conclusion has content only when
yh m < 2, θ m < 1 and 6·|R m|·(1 − κ m)·(n_p/yh m + n_pt/θ m) < 1; a coupling sequence satisfying the tuning
equation is a hypothesis here (its existence is a separate statement).

Paper correspondence: the background-invariant side of the two-stage index, case of the length defect.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP PushLocal
open scoped ENNReal

section Link

variable (N : ℕ) [NeZero N]

/-- an unoriented plaquette containing the link ℓ (as its first link, or as its last link when ℓ.2 = 3) -/
def plaqOf (ℓ : Lk N) : Lk N × Fin 4 :=
  if ℓ.2 = 3 then ((ℓ.1, 0), 3) else (ℓ, 3)

theorem plaqOf_mem (ℓ : Lk N) : plaqOf N ℓ ∈ plaqs N := by
  unfold plaqOf
  split_ifs with h
  · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, show (0 : Fin 4) < 3 by decide⟩
  · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, lt_of_le_of_ne (Fin.le_last ℓ.2) h⟩

omit [NeZero N] in
theorem norm_hol_plaqOf_le (ℓ : Lk N) (ω : Lk N → QBall) :
    ‖hol N ω (plaqOf N ℓ)‖ ≤ ‖((ω ℓ : QBall) : Quaternion ℝ)‖ := by
  have hb : ∀ ℓ', ‖Uq N ω ℓ'‖ ≤ 1 := fun ℓ' => mem_closedBall_zero_iff.1 (ω ℓ').2
  unfold plaqOf
  split_ifs with h
  · simp only [hol, holQ]
    rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
    have e : ((ℓ.1, ℓ.2) : Lk N) = ℓ := rfl
    have hℓ : ((ℓ.1, (3 : Fin 4)) : Lk N) = ℓ := by rw [← h]
    simp only [hℓ]
    calc ‖Uq N ω (ℓ.1, 0)‖ * ‖Uq N ω (ℓ.1 + ev N 0, 3)‖ * ‖Uq N ω (ℓ.1 + ev N 3, 0)‖ * ‖Uq N ω ℓ‖
        = (‖Uq N ω (ℓ.1, 0)‖ * ‖Uq N ω (ℓ.1 + ev N 0, 3)‖ * ‖Uq N ω (ℓ.1 + ev N 3, 0)‖) * ‖Uq N ω ℓ‖ := rfl
      _ ≤ 1 * ‖Uq N ω ℓ‖ := mul_le_mul_of_nonneg_right
          (mul_le_one₀ (mul_le_one₀ (hb _) (norm_nonneg _) (hb _)) (norm_nonneg _) (hb _)) (norm_nonneg _)
      _ = ‖((ω ℓ : QBall) : Quaternion ℝ)‖ := one_mul _
  · simp only [hol, holQ]
    rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
    calc ‖Uq N ω ℓ‖ * ‖Uq N ω (ℓ.1 + ev N ℓ.2, 3)‖ * ‖Uq N ω (ℓ.1 + ev N 3, ℓ.2)‖ * ‖Uq N ω (ℓ.1, 3)‖
        = ‖Uq N ω ℓ‖ * (‖Uq N ω (ℓ.1 + ev N ℓ.2, 3)‖ * ‖Uq N ω (ℓ.1 + ev N 3, ℓ.2)‖ * ‖Uq N ω (ℓ.1, 3)‖) := by
          ring
      _ ≤ ‖Uq N ω ℓ‖ * 1 := mul_le_mul_of_nonneg_left
          (mul_le_one₀ (mul_le_one₀ (hb _) (norm_nonneg _) (hb _)) (norm_nonneg _) (hb _)) (norm_nonneg _)
      _ = ‖((ω ℓ : QBall) : Quaternion ℝ)‖ := mul_one _

omit [NeZero N] in
/-- **the length defect of a link is at most one plaquette variable** -/
theorem linkDef_le (ℓ : Lk N) (ω : Lk N → QBall) :
    1 - ‖((ω ℓ : QBall) : Quaternion ℝ)‖ ≤ 1 - (hol N ω (plaqOf N ℓ)).re := by
  have h1 := (le_abs_self _).trans (abs_re_le (hol N ω (plaqOf N ℓ)))
  linarith [norm_hol_plaqOf_le N ℓ ω]

end Link

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- the length defect of a coarse link at level m -/
noncomputable def linkDef (m : ℕ) (ℓ : Lk (2 ^ m * L)) (ω : ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) : ℝ :=
  1 - ‖((ω ℓ : ChainBlockMap.Ball) : Quaternion ℝ)‖

/-- **the background hypothesis for length defects, from lower bounds on Y** -/
theorem hS_linkDef (β : ℕ → ℝ) {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (pts : ∀ m, ι m → Finset (Lk (2 ^ m * L))) (θ : ℕ → ℝ) (hθ : ∀ m, 0 < θ m) (κ : ℕ → ℝ)
    (hY : ∀ m, ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k))) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) {ω | θ m < linkDef L m x ω} ≤
        ENNReal.ofReal (6 * (1 - κ m) / θ m) := by
  intro m
  obtain ⟨K, hK⟩ := Filter.eventually_atTop.1 (hY m)
  filter_upwards [Filter.eventually_ge_atTop (m + K)] with n hn
  intro i _ x _
  obtain ⟨k, rfl⟩ : ∃ k, n = m + k := ⟨n - m, by omega⟩
  rw [νP_wFam L hr β m k]
  refine le_trans (measure_mono ?_) (plaq_measure_le L hr m k _ (κ m) (θ m) (hθ m) (hK k (by omega))
    (plaqOf _ x) (plaqOf_mem _ x))
  intro V (hV : θ m < 1 - ‖((V x : QBall) : Quaternion ℝ)‖)
  show θ m < 1 - (hol (2 ^ m * L) V (plaqOf _ x)).re
  linarith [linkDef_le (2 ^ m * L) x V]

/-- **The chain theorem for the tuned Wilson family, background = length defects of the block's links.**  The
rarity field is replaced by the tuning at level m₀ and the lower bounds κ m ≤ Y at the levels m ≠ m₀; the other
measure fields of the chain (`hΘp`, `hsym`, and `hpos`, `hbr`, `HR` through s) remain hypotheses.  Content only when
yh m < 2, θ m < 1 and 6·|R m|·(1 − κ m)·(n_p/yh m + n_pt/θ m) < 1. -/
theorem chain_end_to_end_tuned_box_links {X : Type*} [MetricSpace X]
    (β : ℕ → ℝ) (m₀ : ℕ) (κ₀ : ℝ) (ht : Tuned L hr m₀ κ₀ β) (κ : ℕ → ℝ) (hκ0 : κ m₀ = κ₀)
    (hY : ∀ m, m ≠ m₀ → ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k)))
    {u z w' rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    {ι : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Lk (2 ^ m * L) × Fin 4)) (pts : ∀ m, ι m → Finset (Lk (2 ^ m * L)))
    (yh θ : ℕ → ℝ)
    (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : TransientChainError.CouplingStepsTransientE u z w' rs rl Φ W Dfun δ e b binf bp D₀ ρ A
      B Y ustar)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d'))
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Θ : ∀ m, ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) (Aset : ∀ m, Set (BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) (Cset : ∀ m, Set (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)))
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ,
      ∫ ω, F (actb g m ω) ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) =
        ∫ ω, F ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, plaqDev L m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, linkDef L m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L (lev x))) ℝ)
    (HR : WeakUltravioletExistence.Representation (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β)) Dset s lev Fo)
    (hplaq : ∀ m, ∀ i ∈ R m, plaq m i ⊆ plaqs (2 ^ m * L))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m) (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hyh : ∀ m, 0 < yh m)
    (hθ : ∀ m, 0 < θ m) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (e ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (e ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)),
      (∀ m, Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m) atTop (𝓝 (νl m))) ∧
      (WeakUltravioletExistence.BlockConclusion νl (ChainBlockMap.blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L))
        (ChainBlockMap.continuous_blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)) Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * ENNReal.ofReal (6 * (1 - κ m) / yh m) + npt m * ENNReal.ofReal (6 * (1 - κ m) / θ m))) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L (lev d))))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset) ∧
      ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (2 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤ (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (2 ^ m₀ * L) V}) := by
  have hYall : ∀ m, ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k)) := by
    intro m
    by_cases h : m = m₀
    · subst h
      exact Filter.Eventually.of_forall (fun k => by rw [hκ0, ht k])
    · exact hY m h
  exact chain_end_to_end_tuned_box L hr β m₀ κ₀ ht κ hκ0 hY R plaq pts (linkDef L) yh θ
    (fun m => ENNReal.ofReal (6 * (1 - κ m) / θ m)) np npt HE lattice_vanishing shift_vanishing split h0 hCu Θ Aset
    actb Cset hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd hac ham hbr hbv hpos lev Fo HR hplaq hnp
    hnpt hyh (hS_linkDef L hr β R pts θ hθ κ hYall)

end Box

end TunedCoupling

#print axioms TunedCoupling.linkDef_le
#print axioms TunedCoupling.hS_linkDef
#print axioms TunedCoupling.chain_end_to_end_tuned_box_links
