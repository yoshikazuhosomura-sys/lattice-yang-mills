import Tuned.TuneV1
/-!
**Translation invariance of the pushed-forward Wilson measure, and the six-orientation Markov bound.**

* `νk_shV_invariant` : the k-fold pushed-forward normalised Wilson measure on (ℤ/2^m L)⁴ is invariant under every
  coarse translation (fine translation invariance `FoldAffine.wilson_shV_invariant` and the covariance
  `PushLocal.downK_trans`);
* `card_plaqs` : |plaqs (ℤ/N)⁴| = 6 N⁴;
* `tuned_markov_plaq6` : under the tuning equation at level m₀, for one coarse plaquette p,
  ν(1 − Re U_p ≥ y) ≤ 6(1 − κ₀)/y (volume-independent).

Paper correspondence: the rarity field of the chain theorem at level m₀ (one block, Markov form) with the
translation-invariant constant 6.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP FoldPeierls FoldAffine PushLocal

section Count

variable (N : ℕ) [NeZero N]

theorem card_site : Fintype.card (Site N) = N ^ 4 := by
  show Fintype.card (Fin 4 → ZMod N) = N ^ 4
  simp [ZMod.card]

theorem card_plaqs : (plaqs N).card = 6 * N ^ 4 := by
  have e : plaqs N = (Finset.univ ×ˢ ((Finset.univ : Finset (Fin 4 × Fin 4)).filter (fun q => q.1 < q.2))).map
      (Equiv.prodAssoc (Site N) (Fin 4) (Fin 4)).symm.toEmbedding := by
    ext p
    obtain ⟨⟨x, μ⟩, ν⟩ := p
    simp [plaqs]
  rw [e, Finset.card_map, Finset.card_product, Finset.card_univ, card_site]
  have h6 : ((Finset.univ : Finset (Fin 4 × Fin 4)).filter (fun q => q.1 < q.2)).card = 6 := by decide
  rw [h6, mul_comm]

omit [NeZero N] in
theorem continuous_shV (v : Site N) : Continuous (shV N v) :=
  continuous_pi fun _ => continuous_apply _

/-- the six-orientation bound for a translation-invariant probability measure -/
theorem plaq_mean_le_six (ν : Measure (Lk N → QBall)) [IsProbabilityMeasure ν]
    (hinv : ∀ (v : Site N) (f : (Lk N → QBall) → ℝ), Continuous f → ∫ V, f (shV N v V) ∂ν = ∫ V, f V ∂ν)
    (κ₀ : ℝ) (hκ : ∫ V, plaqAvg N V ∂ν = κ₀) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ∫ V, (1 - (hol N V p).re) ∂ν ≤ 6 * (1 - κ₀) := by
  set g : (Lk N → QBall) → ℝ := fun V => 1 - (hol N V p).re
  have hgc : Continuous g := continuous_const.sub (Quaternion.continuous_re.comp (continuous_hol N p))
  let sh : Site N → Lk N × Fin 4 := fun a => ((p.1.1 + a, p.1.2), p.2)
  have hsh_inj : Function.Injective sh := by
    intro a b h
    have := congrArg (fun q : Lk N × Fin 4 => q.1.1) h
    simpa [sh] using this
  have hsub : Finset.univ.image sh ⊆ plaqs N := by
    intro q hq
    obtain ⟨a, -, rfl⟩ := Finset.mem_image.mp hq
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    exact hp
  -- pointwise: the orbit sum is at most the full sum
  have hpt : ∀ V, ∑ a : Site N, (1 - (hol N V (sh a)).re) ≤ (plaqs N).card * (1 - plaqAvg N V) := by
    intro V
    have hc : ((plaqs N).card : ℝ) ≠ 0 := by exact_mod_cast (plaqs_card_pos N).ne'
    have e : ((plaqs N).card : ℝ) * (1 - plaqAvg N V) = ∑ q ∈ plaqs N, (1 - (hol N V q).re) := by
      unfold plaqAvg
      rw [mul_sub, mul_one, mul_div_cancel₀ _ hc, Finset.sum_sub_distrib, Finset.sum_const, nsmul_eq_mul,
        mul_one]
    rw [e, ← Finset.sum_image (f := fun q => 1 - (hol N V q).re) (fun a _ b _ h => hsh_inj h)]
    exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun q _ _ => by linarith [re_hol_le_one N V q])
  -- each term of the orbit has the same mean
  have hterm : ∀ a : Site N, ∫ V, (1 - (hol N V (sh a)).re) ∂ν = ∫ V, g V ∂ν := by
    intro a
    have := hinv a g hgc
    rw [← this]
    congr 1
    funext V
    simp only [g, hol_shV, sh]
  have hint : ∀ q : Lk N × Fin 4, Integrable (fun V => 1 - (hol N V q).re) ν := fun q =>
    integrable_cont N _ (continuous_const.sub (Quaternion.continuous_re.comp (continuous_hol N q)))
  have hL : ∫ V, ∑ a : Site N, (1 - (hol N V (sh a)).re) ∂ν = (N : ℝ) ^ 4 * ∫ V, g V ∂ν := by
    rw [integral_finsetSum _ (fun a _ => hint (sh a))]
    simp_rw [hterm]
    rw [Finset.sum_const, Finset.card_univ, card_site, nsmul_eq_mul]
    push_cast; ring
  have hR : ∫ V, (plaqs N).card * (1 - plaqAvg N V) ∂ν = 6 * (N : ℝ) ^ 4 * (1 - κ₀) := by
    rw [integral_const_mul, integral_sub (integrable_const _) (integrable_cont N _ (continuous_plaqAvg N)), hκ,
      card_plaqs]
    simp
  have h2 : Integrable (fun V => ((plaqs N).card : ℝ) * (1 - plaqAvg N V)) ν :=
    (integrable_cont N (μ := ν) _ (continuous_const.sub (continuous_plaqAvg N))).const_mul _
  have hmono := integral_mono (integrable_finsetSum _ (fun a _ => hint (sh a))) h2 hpt
  rw [hL, hR] at hmono
  have hN : (0 : ℝ) < (N : ℝ) ^ 4 := by
    have : (0 : ℝ) < N := by exact_mod_cast Nat.pos_of_ne_zero (NeZero.ne N)
    positivity
  nlinarith

/-- Markov for one plaquette of a translation-invariant measure: ν(1 − Re U_p ≥ y) ≤ 6(1 − κ₀)/y -/
theorem markov_plaq_six (ν : Measure (Lk N → QBall)) [IsProbabilityMeasure ν]
    (hinv : ∀ (v : Site N) (f : (Lk N → QBall) → ℝ), Continuous f → ∫ V, f (shV N v V) ∂ν = ∫ V, f V ∂ν)
    (κ₀ : ℝ) (hκ : ∫ V, plaqAvg N V ∂ν = κ₀) (y : ℝ) (hy : 0 < y) (p : Lk N × Fin 4) (hp : p ∈ plaqs N) :
    ν.real {V | y ≤ 1 - (hol N V p).re} ≤ 6 * (1 - κ₀) / y := by
  have hi : Integrable (fun V => 1 - (hol N V p).re) ν :=
    integrable_cont N (μ := ν) _ (continuous_const.sub (Quaternion.continuous_re.comp (continuous_hol N p)))
  have h0 : 0 ≤ᵐ[ν] (fun V => 1 - (hol N V p).re) :=
    Filter.Eventually.of_forall (fun V => by
      show (0 : ℝ) ≤ 1 - (hol N V p).re
      linarith [re_hol_le_one N V p])
  have hM := mul_meas_ge_le_integral_of_nonneg h0 hi y
  have h6 := plaq_mean_le_six N ν hinv κ₀ hκ p hp
  rw [le_div_iff₀ hy]
  linarith

end Count

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **coarse translation invariance of the pushed-forward measure** -/
theorem νk_shV_invariant (m k : ℕ) (β : ℝ) (v : Site (2 ^ m * L)) (f : (Lk (2 ^ m * L) → QBall) → ℝ)
    (hf : Continuous f) :
    ∫ V, f (shV _ v V) ∂(νk L hr m k β : Measure _) = ∫ V, f V ∂(νk L hr m k β : Measure _) := by
  have hD := PushReduceK.continuous_downK L hr m k
  unfold νk
  rw [ProbabilityMeasure.toMeasure_map]
  have hm1 : AEStronglyMeasurable (fun V : Lk (2 ^ m * L) → QBall => f (shV _ v V))
      ((wilsonProb (2 ^ (m + k) * L) β : Measure (Lk (2 ^ (m + k) * L) → QBall)).map (downK L hr m k)) :=
    (hf.comp (continuous_shV _ v)).aestronglyMeasurable
  have hm2 : AEStronglyMeasurable (fun V : Lk (2 ^ m * L) → QBall => f V)
      ((wilsonProb (2 ^ (m + k) * L) β : Measure (Lk (2 ^ (m + k) * L) → QBall)).map (downK L hr m k)) :=
    hf.aestronglyMeasurable
  rw [integral_map hD.measurable.aemeasurable hm1, integral_map hD.measurable.aemeasurable hm2]
  have e : ∀ ω : Lk (2 ^ (m + k) * L) → QBall,
      f (shV _ v (downK L hr m k ω)) = f (downK L hr m k (shV _ (fun i => scale L m k (v i)) ω)) := by
    intro ω
    congr 1
    exact (downK_trans L hr m k v ω).symm
  simp_rw [e]
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_shV_invariant _ _ β (fun ω => f (downK L hr m k ω)) (hf.comp hD).measurable]

/-- **(iv) Markov under the tuning equation, volume-independent constant 6** -/
theorem tuned_markov_plaq6 (m₀ : ℕ) (κ₀ : ℝ) (β : ℕ → ℝ) (ht : Tuned L hr m₀ κ₀ β) (k : ℕ)
    (y : ℝ) (hy : 0 < y) (p : Lk (2 ^ m₀ * L) × Fin 4) (hp : p ∈ plaqs (2 ^ m₀ * L)) :
    (νk L hr m₀ k (β (m₀ + k)) : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤
      6 * (1 - κ₀) / y :=
  markov_plaq_six _ _ (fun v f hf => νk_shV_invariant L hr m₀ k _ v f hf) κ₀
    ((integral_νk L hr m₀ k _).trans (ht k)) y hy p hp

end Box

end TunedCoupling

#print axioms TunedCoupling.card_plaqs
#print axioms TunedCoupling.νk_shV_invariant
#print axioms TunedCoupling.tuned_markov_plaq6
