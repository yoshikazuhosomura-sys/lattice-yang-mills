import Tuned.FlatWalkV1
/-!
**The upper end of the tuning bracket: Y(m, k, β) → 1 as β → ∞ (r₀ ≤ 1).**

* `exists_gap` (uniform continuity by compactness): for a continuous F that equals 1 on the flat set
  {Re U_p = 1 for all plaquettes}, for every ε > 0 there is δ > 0 with action > |plaqs| − δ ⇒ F > 1 − ε;
* `volume_pos` : the product Haar measure of {action > c} is positive for c < |plaqs| (it is an open set containing
  the configuration with all links equal to 1; a product of balls around it has positive measure);
* `one_sub_integral_le` : for β ≥ 0, 1 − ∫ F dμ_β ≤ ε + 2 e^{−δβ/2}/v (no Laplace-type estimate is used);
* `tendsto_integral_of_flat` : ∫ F dμ_β → 1;
* `tendsto_Yc_one` : for r₀ ≤ 1, every m and k, Y(m, k, β) → 1 as β → ∞ (part (i) from `plaqAvg_downK_of_flat`).

Paper correspondence: the upper end (a) of the bracket for the existence of the tuned coupling sequence.
-/

namespace FlatPush

open MeasureTheory Filter Topology Set TorusRP OSGap

local notation "ℍr" => Quaternion ℝ

section Conc

variable (N : ℕ) [NeZero N]

/-- the reference product measure -/
noncomputable abbrev Hm : Measure (Lk N → QBall) := Measure.pi fun _ : Lk N => haarBall

theorem action_le (ω : Lk N → QBall) : action N ω ≤ (plaqs N).card := by
  unfold action
  calc ∑ p ∈ plaqs N, (hol N ω p).re ≤ ∑ _p ∈ plaqs N, (1 : ℝ) :=
        Finset.sum_le_sum (fun p _ => TunedCoupling.re_hol_le_one N ω p)
    _ = (plaqs N).card := by simp

theorem re_one_of_action (ω : Lk N → QBall) (h : ((plaqs N).card : ℝ) ≤ action N ω) :
    ∀ p ∈ plaqs N, (hol N ω p).re = 1 := by
  have hnn : ∀ p ∈ plaqs N, 0 ≤ 1 - (hol N ω p).re := fun p _ => by
    linarith [TunedCoupling.re_hol_le_one N ω p]
  have hs : ∑ p ∈ plaqs N, (1 - (hol N ω p).re) = 0 := by
    apply le_antisymm _ (Finset.sum_nonneg hnn)
    rw [Finset.sum_sub_distrib]
    unfold action at h
    simp only [Finset.sum_const, nsmul_eq_mul, mul_one]
    linarith
  intro p hp
  have := (Finset.sum_eq_zero_iff_of_nonneg hnn).1 hs p hp
  linarith

/-- **uniform continuity by compactness** -/
theorem exists_gap (F : (Lk N → QBall) → ℝ) (hF : Continuous F)
    (hflat : ∀ ω, (∀ p ∈ plaqs N, (hol N ω p).re = 1) → F ω = 1) (ε : ℝ) (hε : 0 < ε) :
    ∃ δ > 0, ∀ ω, ((plaqs N).card : ℝ) - δ < action N ω → 1 - ε < F ω := by
  set K := {ω : Lk N → QBall | F ω ≤ 1 - ε}
  have hKc : IsCompact K := (isClosed_le hF continuous_const).isCompact
  by_cases hK : K.Nonempty
  · obtain ⟨ω0, h0K, hmax⟩ := hKc.exists_isMaxOn hK (TunedCoupling.continuous_action' N).continuousOn
    have hlt : action N ω0 < (plaqs N).card := by
      by_contra hc
      push Not at hc
      have h1 := hflat ω0 (re_one_of_action N ω0 hc)
      have h2 : F ω0 ≤ 1 - ε := h0K
      linarith
    refine ⟨(plaqs N).card - action N ω0, by linarith, fun ω hω => ?_⟩
    by_contra hc
    push Not at hc
    have := hmax (show ω ∈ K from hc)
    simp only [Set.mem_ofPred_eq] at this
    linarith
  · refine ⟨1, one_pos, fun ω _ => ?_⟩
    by_contra hc
    push Not at hc
    exact hK ⟨ω, hc⟩

/-- the configuration with every link equal to 1 -/
def oneCfg : Lk N → QBall := fun _ => ⟨1, by simp⟩

theorem action_oneCfg : action N (oneCfg N) = (plaqs N).card := by
  unfold action
  have e : ∀ p ∈ plaqs N, (hol N (oneCfg N) p).re = 1 := fun p _ => by
    simp [hol, holQ, Uq, oneCfg]; rfl
  rw [Finset.sum_congr rfl e]; simp

omit [NeZero N] in
theorem haarBall_ball_pos (r : ℝ) (hr : 0 < r) : 0 < haarBall (Metric.ball (oneCfg N (Classical.arbitrary _)) r) := by
  have hI : (haarProb SU2).IsOpenPosMeasure := by unfold haarProb; infer_instance
  unfold haarBall
  rw [Measure.map_apply continuous_incl.measurable Metric.isOpen_ball.measurableSet]
  have h1 : incl 1 = oneCfg N (Classical.arbitrary _) := by
    apply Subtype.ext; simp [incl, oneCfg]
  have hmem : (1 : SU2) ∈ incl ⁻¹' Metric.ball (oneCfg N (Classical.arbitrary _)) r := by
    show incl 1 ∈ Metric.ball (oneCfg N (Classical.arbitrary _)) r
    rw [h1]; exact Metric.mem_ball_self hr
  exact (Metric.isOpen_ball.preimage continuous_incl).measure_pos (haarProb SU2) ⟨1, hmem⟩

/-- **the product Haar measure of {action > c} is positive** for c < |plaqs| -/
theorem volume_pos (c : ℝ) (hc : c < (plaqs N).card) : 0 < (Hm N).real {ω | c < action N ω} := by
  have hO : IsOpen {ω : Lk N → QBall | c < action N ω} :=
    isOpen_lt continuous_const (TunedCoupling.continuous_action' N)
  have h1 : oneCfg N ∈ {ω : Lk N → QBall | c < action N ω} := by
    show c < action N (oneCfg N); rw [action_oneCfg]; exact hc
  obtain ⟨r, hr, hball⟩ := Metric.isOpen_iff.1 hO _ h1
  have hpi : Metric.ball (oneCfg N) r = Set.pi univ fun ℓ => Metric.ball (oneCfg N ℓ) r :=
    ball_pi _ hr
  have hpos : 0 < (Hm N) (Metric.ball (oneCfg N) r) := by
    rw [hpi, Measure.pi_pi]
    apply pos_iff_ne_zero.2
    rw [Finset.prod_ne_zero_iff]
    intro ℓ _
    exact (haarBall_ball_pos N r hr).ne'
  rw [measureReal_def]
  exact ENNReal.toReal_pos (lt_of_lt_of_le hpos (measure_mono hball)).ne' (measure_ne_top _ _)

theorem integrable_H (f : (Lk N → QBall) → ℝ) (hf : Continuous f) : Integrable f (Hm N) :=
  TunedCoupling.integrable_cont N f hf

theorem Z_eq (β : ℝ) : (wilsonMeasure N β univ).toReal = ∫ ω, Real.exp (β * action N ω) ∂(Hm N) := by
  have h := TunedCoupling.integral_wilson N β (fun _ => 1)
  simp only [mul_one] at h
  rw [← h, integral_const, smul_eq_mul, mul_one]; rfl

/-- **the deficit bound** (β ≥ 0) -/
theorem one_sub_integral_le (F : (Lk N → QBall) → ℝ) (hF : Continuous F) (hF1 : ∀ ω, F ω ≤ 1)
    (hFm : ∀ ω, -1 ≤ F ω) (ε δ : ℝ) (hε : 0 < ε) (hδ : 0 < δ)
    (hgap : ∀ ω, ((plaqs N).card : ℝ) - δ < action N ω → 1 - ε < F ω) (β : ℝ) (hβ : 0 ≤ β) :
    1 - ∫ ω, F ω ∂(wilsonProb N β : Measure _) ≤
      ε + 2 * Real.exp (-(δ / 2 * β)) / (Hm N).real {ω | ((plaqs N).card : ℝ) - δ / 2 < action N ω} := by
  set M : ℝ := ((plaqs N).card : ℝ)
  set O := {ω : Lk N → QBall | M - δ / 2 < action N ω}
  set v := (Hm N).real O
  have hv : 0 < v := volume_pos N _ (by linarith)
  have hA := TunedCoupling.continuous_action' N
  have hexpc : Continuous fun ω => Real.exp (β * action N ω) := Real.continuous_exp.comp (continuous_const.mul hA)
  set Z := ∫ ω, Real.exp (β * action N ω) ∂(Hm N)
  set I1 := ∫ ω, Real.exp (β * action N ω) * F ω ∂(Hm N)
  have hP : ∫ ω, F ω ∂(wilsonProb N β : Measure _) = I1 / Z := by
    rw [TunedCoupling.integral_wilsonProb_div, TunedCoupling.integral_wilson, Z_eq]
  set E := Real.exp (β * (M - δ))
  set E2 := Real.exp (β * (M - δ / 2))
  -- lower bound on Z
  have hZlow : E2 * v ≤ Z := by
    have hO : MeasurableSet O := (isOpen_lt continuous_const hA).measurableSet
    calc E2 * v ≤ ∫ ω in O, Real.exp (β * action N ω) ∂(Hm N) :=
          setIntegral_ge_of_const_le_real hO (measure_ne_top _ _)
            (fun ω hω => Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left (le_of_lt hω) hβ))
            (integrable_H N _ hexpc).integrableOn
      _ ≤ Z := setIntegral_le_integral (integrable_H N _ hexpc)
            (Eventually.of_forall fun ω => (Real.exp_pos _).le)
  have hZ : 0 < Z := lt_of_lt_of_le (mul_pos (Real.exp_pos _) hv) hZlow
  -- pointwise bound
  have hpt : ∀ ω, Real.exp (β * action N ω) * (1 - F ω) ≤ ε * Real.exp (β * action N ω) + 2 * E := by
    intro ω
    have hE : 0 ≤ E := (Real.exp_pos _).le
    have he : 0 < Real.exp (β * action N ω) := Real.exp_pos _
    by_cases h : M - δ < action N ω
    · have h1 := hgap ω h
      have e1 : Real.exp (β * action N ω) * (1 - F ω) ≤ Real.exp (β * action N ω) * ε :=
        mul_le_mul_of_nonneg_left (by linarith) he.le
      linarith [mul_comm ε (Real.exp (β * action N ω))]
    · push Not at h
      have e1 : Real.exp (β * action N ω) ≤ E := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left h hβ)
      have e2 : Real.exp (β * action N ω) * (1 - F ω) ≤ E * 2 :=
        mul_le_mul e1 (by linarith [hFm ω]) (by linarith [hF1 ω]) hE
      have e3 : 0 ≤ ε * Real.exp (β * action N ω) := mul_nonneg hε.le he.le
      linarith
  have hint1 : Integrable (fun ω => Real.exp (β * action N ω) * (1 - F ω)) (Hm N) :=
    integrable_H N _ (hexpc.mul (continuous_const.sub hF))
  have hint2 : Integrable (fun ω => ε * Real.exp (β * action N ω) + 2 * E) (Hm N) :=
    integrable_H N _ ((continuous_const.mul hexpc).add continuous_const)
  have hI : ∫ ω, Real.exp (β * action N ω) * (1 - F ω) ∂(Hm N) = Z - I1 := by
    have e : (fun ω => Real.exp (β * action N ω) * (1 - F ω)) =
        fun ω => Real.exp (β * action N ω) - Real.exp (β * action N ω) * F ω := by
      funext ω; ring
    rw [e, integral_sub (integrable_H N _ hexpc)
      (integrable_H N (fun ω => Real.exp (β * action N ω) * F ω) (hexpc.mul hF))]
  have hI2 : ∫ ω, (ε * Real.exp (β * action N ω) + 2 * E) ∂(Hm N) = ε * Z + 2 * E := by
    rw [integral_add (integrable_H N (fun ω => ε * Real.exp (β * action N ω)) (continuous_const.mul hexpc))
      (integrable_const _),
      integral_const_mul, integral_const]
    simp only [probReal_univ, smul_eq_mul, one_mul]
    rfl
  have hZI : Z - I1 ≤ ε * Z + 2 * E := by
    rw [← hI, ← hI2]; exact integral_mono hint1 hint2 hpt
  have hEE : E = E2 * Real.exp (-(δ / 2 * β)) := by
    show Real.exp (β * (M - δ)) = Real.exp (β * (M - δ / 2)) * Real.exp (-(δ / 2 * β))
    rw [← Real.exp_add]; congr 1; ring
  have h4 : E / Z ≤ Real.exp (-(δ / 2 * β)) / v := by
    rw [div_le_div_iff₀ hZ hv, hEE]
    calc E2 * Real.exp (-(δ / 2 * β)) * v = Real.exp (-(δ / 2 * β)) * (E2 * v) := by ring
      _ ≤ Real.exp (-(δ / 2 * β)) * Z := mul_le_mul_of_nonneg_left hZlow (Real.exp_pos _).le
  rw [hP]
  have h1 : 1 - I1 / Z = (Z - I1) / Z := by field_simp
  have h2 : (Z - I1) / Z ≤ (ε * Z + 2 * E) / Z := div_le_div_of_nonneg_right hZI hZ.le
  have h3 : (ε * Z + 2 * E) / Z = ε + 2 * (E / Z) := by field_simp
  have h5 : 2 * Real.exp (-(δ / 2 * β)) / v = 2 * (Real.exp (-(δ / 2 * β)) / v) := by ring
  rw [h1, h5]
  linarith

/-- **concentration**: ∫ F dμ_β → 1 for every continuous F ≤ 1 (≥ −1) equal to 1 on the flat set -/
theorem tendsto_integral_of_flat (F : (Lk N → QBall) → ℝ) (hF : Continuous F) (hF1 : ∀ ω, F ω ≤ 1)
    (hFm : ∀ ω, -1 ≤ F ω) (hflat : ∀ ω, (∀ p ∈ plaqs N, (hol N ω p).re = 1) → F ω = 1) :
    Tendsto (fun β => ∫ ω, F ω ∂(wilsonProb N β : Measure _)) atTop (𝓝 1) := by
  rw [tendsto_order]
  refine ⟨fun a ha => ?_, fun a ha => Eventually.of_forall fun β => ?_⟩
  · have hε : 0 < (1 - a) / 2 := by linarith
    obtain ⟨δ, hδ, hgap⟩ := exists_gap N F hF hflat _ hε
    set v := (Hm N).real {ω | ((plaqs N).card : ℝ) - δ / 2 < action N ω}
    have hv : 0 < v := volume_pos N _ (by linarith)
    have hlim : Tendsto (fun β : ℝ => 2 * Real.exp (-(δ / 2 * β)) / v) atTop (𝓝 0) := by
      have hexp : Tendsto (fun β : ℝ => Real.exp (-(δ / 2 * β))) atTop (𝓝 0) :=
        Real.tendsto_exp_neg_atTop_nhds_zero.comp (Tendsto.const_mul_atTop (by linarith) tendsto_id)
      simpa using (hexp.const_mul 2).div_const v
    filter_upwards [hlim.eventually (gt_mem_nhds hε), eventually_ge_atTop 0] with β h1 h2
    have := one_sub_integral_le N F hF hF1 hFm _ δ hε hδ hgap β h2
    linarith
  · have hle : ∫ ω, F ω ∂(wilsonProb N β : Measure _) ≤ 1 := by
      have := integral_mono (TunedCoupling.integrable_cont N (μ := (wilsonProb N β : Measure _)) F hF)
        (integrable_const (1 : ℝ)) hF1
      simpa using this
    linarith

end Conc

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- **the upper end**: for r₀ ≤ 1, every m, k: Y(m, k, β) → 1 as β → ∞ -/
theorem tendsto_Yc_one (hr1 : r₀ ≤ 1) (m k : ℕ) : Tendsto (TunedCoupling.Yc L hr m k) atTop (𝓝 1) :=
  tendsto_integral_of_flat (2 ^ (m + k) * L) _
    ((TunedCoupling.continuous_plaqAvg _).comp (PushReduceK.continuous_downK L hr m k))
    (fun _ => TunedCoupling.plaqAvg_le_one _ _) (fun _ => TunedCoupling.neg_one_le_plaqAvg _ _)
    (fun ω h => plaqAvg_downK_of_flat L hr hr1 m k ω h)

end Box

end FlatPush

#print axioms FlatPush.exists_gap
#print axioms FlatPush.volume_pos
#print axioms FlatPush.tendsto_integral_of_flat
#print axioms FlatPush.tendsto_Yc_one
