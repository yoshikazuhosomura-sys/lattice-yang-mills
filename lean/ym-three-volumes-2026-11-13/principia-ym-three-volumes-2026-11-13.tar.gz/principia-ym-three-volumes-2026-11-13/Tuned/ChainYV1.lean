import Tuned.AttachV1
/-!
**The rarity field of the chain theorem from the coarse plaquette averages, and the chain with a tuned coupling.**

* `plaqDev L m p ω := 1 − Re U_p(ω)` on the coarse torus of level m (the plaquette variable of the two-stage index);
* `plaq_measure_le` : ν_k(1 − Re U_p > y) ≤ 6(1 − κ)/y whenever κ ≤ Y(m, k, β) (Markov + translation invariance);
* `rarity_of_Y` : the field `rarity` of `ChainBlockMap.chain_end_to_end_blockMap` (box block map, normalised Wilson
  measures with couplings β n) holds with Yf := plaqDev, P₁ m := 6(1 − κ m)/yh m, as soon as
  (a) κ m ≤ Y(m, k, β (m + k)) for all large k, at every level m, and (b) the background-invariant part of the
  index (points x, functions f) has the bound S m — (b) is kept as a hypothesis;
* `chain_end_to_end_tuned_box` : the chain theorem for the tuned Wilson family: the hypothesis (a) at the tuning
  level m₀ is paid by the tuning equation (κ m₀ = κ₀), (a) at the other levels and (b) remain hypotheses; the
  conclusion is the chain's conclusion together with the level-m₀ statements of `attach_tuned`.

Paper correspondence: the rarity field of Theorem W's chain (one block, two-stage index), its plaquette part
reduced to the defined numbers Y(m, k, β); the tuning (a) pays the level m₀.
-/

namespace TunedCoupling

open MeasureTheory Filter Topology Set TorusRP FoldPeierls FoldAffine PushLocal
open scoped ENNReal

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

/-- the plaquette variable of the two-stage index: 1 − Re U_p on the coarse torus of level m -/
noncomputable def plaqDev (m : ℕ) (p : Lk (2 ^ m * L) × Fin 4) (ω : ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) : ℝ :=
  1 - (hol (2 ^ m * L) ω p).re

/-- one coarse plaquette, measure form, from a lower bound on Y -/
theorem plaq_measure_le (m k : ℕ) (b κ y : ℝ) (hy : 0 < y) (hY : κ ≤ Yc L hr m k b)
    (p : Lk (2 ^ m * L) × Fin 4) (hp : p ∈ plaqs (2 ^ m * L)) :
    (νk L hr m k b : Measure (Lk (2 ^ m * L) → QBall)) {V | y < 1 - (hol (2 ^ m * L) V p).re} ≤
      ENNReal.ofReal (6 * (1 - κ) / y) := by
  have h1 := markov_plaq_six (2 ^ m * L) (νk L hr m k b : Measure (Lk (2 ^ m * L) → QBall))
    (fun v f hf => νk_shV_invariant L hr m k b v f hf) _ rfl y hy p hp
  rw [integral_νk] at h1
  have h2 : 6 * (1 - Yc L hr m k b) / y ≤ 6 * (1 - κ) / y := by
    apply div_le_div_of_nonneg_right _ hy.le
    linarith
  calc (νk L hr m k b : Measure (Lk (2 ^ m * L) → QBall)) {V | y < 1 - (hol (2 ^ m * L) V p).re}
      ≤ (νk L hr m k b : Measure (Lk (2 ^ m * L) → QBall)) {V | y ≤ 1 - (hol (2 ^ m * L) V p).re} :=
        measure_mono (fun V (hV : y < 1 - (hol (2 ^ m * L) V p).re) =>
          (le_of_lt hV : y ≤ 1 - (hol (2 ^ m * L) V p).re))
    _ = ENNReal.ofReal ((νk L hr m k b : Measure (Lk (2 ^ m * L) → QBall)).real
          {V | y ≤ 1 - (hol (2 ^ m * L) V p).re}) := (ofReal_measureReal (measure_ne_top _ _)).symm
    _ ≤ ENNReal.ofReal (6 * (1 - κ) / y) := ENNReal.ofReal_le_ofReal (h1.trans h2)

/-- **the rarity field of the chain theorem from lower bounds on Y** (plaquette part); the background part is a
hypothesis -/
theorem rarity_of_Y (β : ℕ → ℝ) {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Lk (2 ^ m * L) × Fin 4)) (pts : ∀ m, ι m → Finset (Pt m))
    (f : ∀ m, Pt m → ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ℝ) (yh θ : ℕ → ℝ) (S : ℕ → ℝ≥0∞)
    (np npt : ℕ → ℕ) (κ : ℕ → ℝ)
    (hplaq : ∀ m, ∀ i ∈ R m, plaq m i ⊆ plaqs (2 ^ m * L))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m) (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hyh : ∀ m, 0 < yh m)
    (hY : ∀ m, ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k)))
    (hS : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) {ω | θ m < f m x ω} ≤ S m) :
    ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m,
      (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) {ω | (1 / 2 : ℝ) <
        TwoStageSmallField.twoStageIndex (plaq m i) (pts m i) (plaqDev L m) (f m) (yh m) (θ m) ω} ≤
        (np m : ℝ≥0∞) * ENNReal.ofReal (6 * (1 - κ m) / yh m) + npt m * S m := by
  intro m
  obtain ⟨K, hK⟩ := Filter.eventually_atTop.1 (hY m)
  filter_upwards [hS m, Filter.eventually_ge_atTop (m + K)] with n hSn hn
  intro i hi
  obtain ⟨k, rfl⟩ : ∃ k, n = m + k := ⟨n - m, by omega⟩
  rw [TwoStageSmallField.index_bad_eq]
  refine TwoStageSmallField.block_bad_le_counts _ _ _ _ _ _ _ _ _ _ _ (hnp m i hi) (hnpt m i hi) ?_ (hSn i hi)
  intro p hp
  rw [νP_wFam L hr β m k]
  exact plaq_measure_le L hr m k _ (κ m) (yh m) (hyh m) (hK k (by omega)) p (hplaq m i hi hp)

/-- **The chain theorem for the tuned Wilson family** (box block map).  Hypotheses beyond the chain's own fields:
the tuning equation at level m₀ (`ht`), lower bounds κ m on Y at the other levels (`hY`), and the background part of
the two-stage index (`hS`).  The field `rarity` of the chain theorem is discharged by `rarity_of_Y`. -/
theorem chain_end_to_end_tuned_box {X : Type*} [MetricSpace X]
    (β : ℕ → ℝ) (m₀ : ℕ) (κ₀ : ℝ) (ht : Tuned L hr m₀ κ₀ β) (κ : ℕ → ℝ) (hκ0 : κ m₀ = κ₀)
    (hY : ∀ m, m ≠ m₀ → ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k)))
    {u z w' rs rl : ℕ → ℝ → ℝ} {Φ W Dfun : ℝ → ℝ} {δ : ℕ → ℝ}
    {e : ℝ → ℝ} {b binf bp D₀ ρ A B Y ustar : ℝ}
    {ι Pt : ℕ → Type*} (R : ∀ m, Finset (ι m))
    (plaq : ∀ m, ι m → Finset (Lk (2 ^ m * L) × Fin 4)) (pts : ∀ m, ι m → Finset (Pt m))
    (f : ∀ m, Pt m → ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ℝ) (yh θ : ℕ → ℝ)
    (S : ℕ → ℝ≥0∞) (np npt : ℕ → ℕ)
    {Dset : Set X} {s : ℕ → X → ℝ} {τ : ℕ → ℝ} {Ωr : ℝ → ℝ}
    (HE : TransientChainError.CouplingStepsTransientE u z w' rs rl Φ W Dfun δ e b binf bp D₀ ρ A
      B Y ustar)
    (lattice_vanishing : Tendsto τ atTop (𝓝 0))
    (shift_vanishing : ∀ η > 0, ∃ δ > 0, ∀ r, 0 ≤ r → r < δ → Ωr r ≤ η)
    (split : ∀ n, ∀ d ∈ Dset, ∀ d' ∈ Dset, |s n d - s n d'| ≤ τ n + Ωr (dist d d'))
    (h0 : ∀ x, u 0 x = x) (hCu : ∀ k, ContinuousOn (u (k + 1)) {x | ∀ j ≤ k, ustar ≤ u j x})
    (Θ : ∀ m, ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) (Aset : ∀ m, Set (BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ))
    {Gb : Type*} (actb : Gb → ∀ m, ChainBlockMap.Cfg (BoxWalk.BoxLk L m) → ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) (Cset : ∀ m, Set (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)))
    (hΘc : ∀ m, Continuous (Θ m))
    (hΘp : ∀ m, ∀ᶠ n in atTop,
      ∀ F ∈ Aset m, 0 ≤ ∫ ω, F (Θ m ω) * F ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))))
    (hsc : ∀ g m, Continuous (actb g m))
    (hsym : ∀ g m, ∀ᶠ n in atTop, ∀ F : BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)) ℝ,
      ∫ ω, F (actb g m ω) ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) =
        ∫ ω, F ω ∂(ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))))
    (hCc : ∀ m, IsClosed (Cset m))
    (hgood : ∀ m, {ω | ∀ i ∈ R m, (∀ p ∈ plaq m i, plaqDev L m p ω ≤ yh m) ∧
      (∀ x ∈ pts m i, f m x ω ≤ θ m)} ⊆ Cset m)
    (Bd : ℝ) {G : Type*} (act : G → X → X) (εb : G → ℕ → X → ℝ)
    (Pset : Set (Σ m : ℕ, (Fin m → Fin m → X) × (Fin m → ℝ)))
    (hcount : Dset.Countable) (hdense : Dense Dset) (hbd : ∀ n, ∀ d ∈ Dset, |s n d| ≤ Bd)
    (hac : ∀ g, Continuous (act g)) (ham : ∀ g, ∀ d ∈ Dset, act g d ∈ Dset)
    (hbr : ∀ g n, ∀ d ∈ Dset, |s n (act g d) - s n d| ≤ εb g n d)
    (hbv : ∀ g, ∀ d ∈ Dset, Tendsto (fun n => εb g n d) atTop (𝓝 0))
    (hpos : ∀ p ∈ Pset, (∀ a b, p.2.1 a b ∈ Dset) ∧
      ∀ᶠ n in atTop, 0 ≤ ∑ a, ∑ b, p.2.2 a * p.2.2 b * s n (p.2.1 a b))
    (lev : X → ℕ) (Fo : ∀ x, BoundedContinuousFunction (ChainBlockMap.Cfg (BoxWalk.BoxLk L (lev x))) ℝ)
    (HR : WeakUltravioletExistence.Representation (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β)) Dset s lev Fo)
    (hplaq : ∀ m, ∀ i ∈ R m, plaq m i ⊆ plaqs (2 ^ m * L))
    (hnp : ∀ m, ∀ i ∈ R m, (plaq m i).card ≤ np m) (hnpt : ∀ m, ∀ i ∈ R m, (pts m i).card ≤ npt m)
    (hyh : ∀ m, 0 < yh m)
    (hS : ∀ m, ∀ᶠ n in atTop, ∀ i ∈ R m, ∀ x ∈ pts m i,
      (ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) n m :
        Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m))) {ω | θ m < f m x ω} ≤ S m) :
    (∀ t, ustar + D₀ ≤ t → ∀ n : ℕ, ∃ x : ℝ, t + (binf - (e ustar + Y)) * n - D₀ ≤ x ∧
      x ≤ t + (bp + (e ustar + Y)) * n ∧ u n x = t ∧ ∀ k ≤ n, t - D₀ ≤ u k x) ∧
    ∃ φ : ℕ → ℕ, StrictMono φ ∧ ∃ νl : ∀ m, ProbabilityMeasure (ChainBlockMap.Cfg (BoxWalk.BoxLk L m)),
      (∀ m, Tendsto (fun k => ChainBlockMap.νP r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) (φ k) m) atTop (𝓝 (νl m))) ∧
      (WeakUltravioletExistence.BlockConclusion νl (ChainBlockMap.blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L))
        (ChainBlockMap.continuous_blockMap r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L)) Θ Aset actb Cset
        (fun m => 1 - (R m).card * ((np m : ℝ≥0∞) * ENNReal.ofReal (6 * (1 - κ m) / yh m) + npt m * S m)) ∧
      ∃ Sf : X → ℝ,
        (∀ d ∈ Dset, Sf d = ∫ ω, Fo d ω ∂(νl (lev d) : Measure (ChainBlockMap.Cfg (BoxWalk.BoxLk L (lev d))))) ∧
        (∀ d ∈ Dset, Tendsto (fun k => s (φ k) d) atTop (𝓝 (Sf d))) ∧
        WeakUltravioletExistence.ObservableConclusion Dset Sf Bd act Pset) ∧
      ∫ V, plaqAvg (2 ^ m₀ * L) V ∂(νl m₀ : Measure _) = κ₀ ∧
      (∀ y, 0 < y → ∀ p ∈ plaqs (2 ^ m₀ * L),
        (νl m₀ : Measure _).real {V | y ≤ 1 - (hol (2 ^ m₀ * L) V p).re} ≤ 6 * (1 - κ₀) / y) ∧
      (∀ y, 0 ≤ y → (1 - κ₀ - y) / 2 ≤ (νl m₀ : Measure _).real {V | y ≤ 1 - plaqAvg (2 ^ m₀ * L) V}) := by
  have hYall : ∀ m, ∀ᶠ k in atTop, κ m ≤ Yc L hr m k (β (m + k)) := by
    intro m
    by_cases h : m = m₀
    · subst h
      exact Filter.Eventually.of_forall (fun k => by rw [hκ0, ht k])
    · exact hY m h
  have hrar := rarity_of_Y L hr β R plaq pts f yh θ S np npt κ hplaq hnp hnpt hyh hYall hS
  obtain ⟨h1, h2⟩ := ChainBlockMap.chain_end_to_end_blockMap (Lk := BoxWalk.BoxLk L)
    (Pl := fun m => Lk (2 ^ m * L) × Fin 4) r₀ hr (BoxWalk.boxPaths L) (BoxWalk.boxW L) (wFam L β) R plaq pts
    (plaqDev L) f yh θ (fun m => ENNReal.ofReal (6 * (1 - κ m) / yh m)) S np npt HE hrar lattice_vanishing
    shift_vanishing split h0 hCu Θ Aset actb Cset hΘc hΘp hsc hsym hCc hgood Bd act εb Pset hcount hdense hbd hac
    ham hbr hbv hpos lev Fo HR
  exact ⟨h1, attach_tuned L hr m₀ κ₀ β ht _ h2⟩

end Box

end TunedCoupling

#print axioms TunedCoupling.plaq_measure_le
#print axioms TunedCoupling.rarity_of_Y
#print axioms TunedCoupling.chain_end_to_end_tuned_box
