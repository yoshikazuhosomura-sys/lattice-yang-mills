import Tuned.TunedExistsV1
/-!
**Why r₀ ≤ 1 is needed for the tuning: for r₀ ≥ 1 and k ≥ 1, Y(m, k, β) ≤ r₀⁻⁴.**

* `downK_succ_is_block` : after at least one step, every coarse value is a value of the block map;
* `norm_blockMap_le` : for r₀ ≥ 1 every value of the box block map has norm ≤ 1/r₀;
* `Yc_succ_le` : for r₀ ≥ 1, Y(m, k + 1, β) ≤ (1/r₀)⁴ for every β;
* `not_tuned_of_large_radius` : for r₀ > 1 and κ₀ > (1/r₀)⁴ no coupling sequence satisfies `Tuned`
  (the statements built on `Tuned` are then empty), so the radius condition r₀ ≤ 1 of `tendsto_Yc_one` is not
  removable by this route.
-/

namespace FlatPush

open MeasureTheory Filter Topology Set TunedCoupling ChainBlockMap BoxWalk TorusRP

local notation "ℍr" => Quaternion ℝ

section Box

variable (L : ℕ) [NeZero L] {r₀ : ℝ} (hr : 0 < r₀)

theorem downK_succ_is_block (m : ℕ) : ∀ (k : ℕ) (U : Cfg (BoxLk L (m + (k + 1)))),
    ∃ V : Cfg (BoxLk L (m + 1)), PushLocal.downK L hr m (k + 1) U = blockMap r₀ hr (boxPaths L) (boxW L) m V
  | 0, U => ⟨U, rfl⟩
  | k + 1, U => downK_succ_is_block m k (blockMap r₀ hr (boxPaths L) (boxW L) (m + (k + 1)) U)

theorem norm_blockMap_le (hr1 : 1 ≤ r₀) (m : ℕ) (V : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    ‖(blockMap r₀ hr (boxPaths L) (boxW L) m V b : ℍr)‖ ≤ r₀⁻¹ := by
  rw [boxMap_eq L hr]
  set q := sixAvg (boxPathsIdx L m b) (fun ℓ => (V ℓ : ℍr))
  have hq : ‖q‖ ≤ 1 := norm_sixAvg_le (fun ℓ => mem_closedBall_zero_iff.1 (V ℓ).2) _
  have hmax : max ‖q‖ r₀ = r₀ := max_eq_right (hq.trans hr1)
  rw [norm_retract hr, hmax, div_eq_mul_inv]
  calc ‖q‖ * r₀⁻¹ ≤ 1 * r₀⁻¹ := mul_le_mul_of_nonneg_right hq (inv_nonneg.2 hr.le)
    _ = r₀⁻¹ := one_mul _

theorem plaqAvg_le_of_norm (N : ℕ) [NeZero N] (c : ℝ) (hc : 0 ≤ c) (ω : Lk N → QBall)
    (hω : ∀ ℓ, ‖((ω ℓ : QBall) : ℍr)‖ ≤ c) : plaqAvg N ω ≤ c ^ 4 := by
  have hcard : (0 : ℝ) < (plaqs N).card := by exact_mod_cast plaqs_card_pos N
  unfold plaqAvg
  rw [div_le_iff₀ hcard]
  have hp : ∀ p, (hol N ω p).re ≤ c ^ 4 := fun p => by
    refine (le_abs_self _).trans ((abs_re_le _).trans ?_)
    simp only [hol, holQ]
    rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
    have h := hω
    have e : c ^ 4 = c * c * c * c := by ring
    rw [e]
    exact mul_le_mul (mul_le_mul (mul_le_mul (h _) (h _) (norm_nonneg _) hc) (h _) (norm_nonneg _)
      (mul_nonneg hc hc)) (h _) (norm_nonneg _) (mul_nonneg (mul_nonneg hc hc) hc)
  calc ∑ p ∈ plaqs N, (hol N ω p).re ≤ ∑ _p ∈ plaqs N, c ^ 4 := Finset.sum_le_sum (fun p _ => hp p)
    _ = c ^ 4 * (plaqs N).card := by rw [Finset.sum_const, nsmul_eq_mul, mul_comm]

/-- **for r₀ ≥ 1 and k ≥ 1, Y(m, k, β) ≤ r₀⁻⁴** -/
theorem Yc_succ_le (hr1 : 1 ≤ r₀) (m k : ℕ) (β : ℝ) : Yc L hr m (k + 1) β ≤ (r₀⁻¹) ^ 4 := by
  unfold Yc
  have hpt : ∀ ω : Lk (2 ^ (m + (k + 1)) * L) → QBall,
      plaqAvg (2 ^ m * L) (PushLocal.downK L hr m (k + 1) ω) ≤ (r₀⁻¹) ^ 4 := by
    intro ω
    obtain ⟨V, hV⟩ := downK_succ_is_block L hr m k ω
    rw [hV]
    exact plaqAvg_le_of_norm _ _ (inv_nonneg.2 hr.le) _ (fun b => norm_blockMap_le L hr hr1 m V b)
  have := integral_mono (integrable_cont _ (μ := (wilsonProb (2 ^ (m + (k + 1)) * L) β : Measure _)) _
    ((continuous_plaqAvg _).comp (PushReduceK.continuous_downK L hr m (k + 1))))
    (integrable_const ((r₀⁻¹) ^ 4)) hpt
  simpa using this

/-- **for r₀ > 1 the tuning equation is unsatisfiable when κ₀ > r₀⁻⁴** -/
theorem not_tuned_of_large_radius (hr1 : 1 ≤ r₀) (m₀ : ℕ) (κ₀ : ℝ) (hκ : (r₀⁻¹) ^ 4 < κ₀) (β : ℕ → ℝ) :
    ¬ Tuned L hr m₀ κ₀ β := by
  intro ht
  have := Yc_succ_le L hr hr1 m₀ 0 (β (m₀ + 1))
  rw [ht 1] at this
  linarith

end Box

end FlatPush

#print axioms FlatPush.Yc_succ_le
#print axioms FlatPush.not_tuned_of_large_radius
