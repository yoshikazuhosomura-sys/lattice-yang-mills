import PolyT.GaugeLoopV1

/-!
# The reflection through the link mid-planes `x₄ = −½` and `x₄ = (M−1)/2`

`rP x = (x₁, x₂, x₃, −1 − x₄)`; on links `thP` (time links `(x, 4)` go to `(rP(x + e₄), 4)`), values of
time links inverted (`HalfSplit.sgL`); `ThP ω = linkRefl thP sgL ω`.
* `ThP_ThP`, `ThP_mp` : an involution preserving the Haar product.
* `polyLoop_ThP` : `P_b(t) ∘ ThP = P_b(−1 − t)`.
* `ThP_gauge` : `ThP (g·ω) = (g ∘ rP)·(ThP ω)`; hence `F ∘ ThP` is gauge invariant when `F` is
  (`gaugeInv_comp_ThP`).
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- sites: `x₄ ↦ −1 − x₄` -/
def rP (x : Site N M) : Site N M := (x.1, (x.2.1, -1 - x.2.2))

/-- links -/
def thP (ℓ : Link N M) : Link N M :=
  if ℓ.2 = 3 then (rP N M (ℓ.1 + ev N M 3), 3) else (rP N M ℓ.1, ℓ.2)

noncomputable def ThP (ω : Link N M → SU2) : Link N M → SU2 :=
  ThickFloorRP.LinkReflection.linkRefl (thP N M) (sgL N M) ω

theorem rP_rP (x : Site N M) : rP N M (rP N M x) = x := by
  obtain ⟨a, b, c⟩ := x
  simp [rP]

theorem ev3_snd : (ev N M 3) = ((0, 0), (0, 1)) := rfl

theorem rP_add_ev (x : Site N M) (d : Fin 4) (hd : d ≠ 3) : rP N M (x + ev N M d) = rP N M x + ev N M d := by
  obtain ⟨⟨a1, a2⟩, ⟨a3, a4⟩⟩ := x
  fin_cases d <;> simp_all [rP, ev]

theorem rP_add_ev3 (x : Site N M) : rP N M (x + ev N M 3) + ev N M 3 = rP N M x := by
  obtain ⟨⟨a1, a2⟩, ⟨a3, a4⟩⟩ := x
  simp [rP, ev]
  ring

theorem thP_invol : Function.Involutive (thP N M) := by
  intro ℓ
  obtain ⟨x, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd
    simp only [thP, if_true]
    rw [rP_add_ev3, rP_rP]
  · simp only [thP, hd, if_false, rP_rP]

theorem ThP_mp : MeasurePreserving (ThP N M) (haarCfg N M) (haarCfg N M) := by
  have h1 := measurePreserving_piCongrLeft (fun _ : Link N M => haarSU2) (thP_invol N M).toPerm
  have h2 := measurePreserving_pi (fun _ : Link N M => haarSU2) (fun _ : Link N M => haarSU2)
    (f := fun ℓ => sgL N M ℓ) (fun ℓ => sgL_mp N M ℓ)
  have h := h2.comp h1
  unfold haarCfg
  convert h using 1
  funext ω ℓ
  simp only [ThP, ThickFloorRP.LinkReflection.linkRefl, Function.comp]
  rw [ThickFloorRP.LinkReflection.piCongrLeft_const, Function.Involutive.toPerm_symm,
    Function.Involutive.coe_toPerm]

theorem ThP_ne (ω : Link N M → SU2) (z : Site N M) (d : Fin 4) (hd : d ≠ 3) :
    ThP N M ω (z, d) = ω (rP N M z, d) := by
  simp only [ThP, ThickFloorRP.LinkReflection.linkRefl, thP, sgL, hd, if_false, id_eq]

theorem ThP_three (ω : Link N M → SU2) (z : Site N M) :
    ThP N M ω (z, 3) = (ω (rP N M (z + ev N M 3), 3))⁻¹ := by
  simp only [ThP, ThickFloorRP.LinkReflection.linkRefl, thP, sgL, if_true]

theorem ThP_ThP (ω : Link N M → SU2) : ThP N M (ThP N M ω) = ω := by
  funext ℓ
  obtain ⟨x, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd
    rw [ThP_three, ThP_three, inv_inv, rP_add_ev3, rP_rP]
  · rw [ThP_ne N M _ x d hd, ThP_ne N M _ _ d hd, rP_rP]

theorem polyLoop_ThP (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) :
    polyLoop N M b t (ThP N M ω) = polyLoop N M b (-1 - t) ω := by
  unfold polyLoop
  congr 1

/-- **Gauge covariance of the reflection.** -/
theorem ThP_gauge (g : Site N M → SU2) (ω : Link N M → SU2) :
    ThP N M (gAct N M g ω) = gAct N M (fun x => g (rP N M x)) (ThP N M ω) := by
  funext ℓ
  obtain ⟨x, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd
    rw [ThP_three]
    show (g (rP N M (x + ev N M 3)) * ω (rP N M (x + ev N M 3), 3)
        * (g (rP N M (x + ev N M 3) + ev N M 3))⁻¹)⁻¹
      = g (rP N M x) * ThP N M ω (x, 3) * (g (rP N M (x + ev N M 3)))⁻¹
    rw [ThP_three, rP_add_ev3]
    group
  · rw [ThP_ne N M _ x d hd]
    show g (rP N M x) * ω (rP N M x, d) * (g (rP N M x + ev N M d))⁻¹
      = g (rP N M x) * ThP N M ω (x, d) * (g (rP N M (x + ev N M d)))⁻¹
    rw [ThP_ne N M _ x d hd, rP_add_ev N M x d hd]

theorem gaugeInv_comp_ThP (F : (Link N M → SU2) → ℝ)
    (hF : ∀ g ω, F (gAct N M g ω) = F ω) (g : Site N M → SU2) (ω : Link N M → SU2) :
    F (ThP N M (gAct N M g ω)) = F (ThP N M ω) := by
  rw [ThP_gauge, hF]

end PolyakovT

#print axioms PolyakovT.ThP_mp
#print axioms PolyakovT.ThP_ThP
#print axioms PolyakovT.polyLoop_ThP
#print axioms PolyakovT.ThP_gauge
