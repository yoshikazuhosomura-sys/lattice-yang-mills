import Blocks.ThickFloorPolyakovV1

/-!
# Polyakov loop correlations: time translation, reflection and the weighted Cauchy–Schwarz

Lattice, configurations and Polyakov loops are those of `TwistedWilson` / `HalfSplit`
(`Site N M = (ZMod N × ZMod N) × (ZMod M × ZMod M)`, directions `0,1,2,3` are `x₁,x₂,x₃,x₄`).
The measure `⟨·⟩₀` is the SU(2) Wilson measure with background twist `n₁₂ = 1` and no `(3,4)` twist:
weight `wE β 1 = exp(β Σ_B zt true false B · Re U_B)` (`wE_one`) on the Haar product `haarCfg`,
normalised by `ZW β true false` (`integral_wE_one`).
* `corr β b b' s t = ∫ P_b(s) P_{b'}(t) wE β 1`, `P_b(t) = polyLoop b t` (Re of the product of the
  direction-3 links around the `x₃` circle at transverse position `b`, time `x₄ = t`).
* `corr_shiftZ` : invariance under time translation `x₄ ↦ x₄ + c` (Haar product and weight).
* `wpair_cs`, `wpair_nonneg` : the reflection `Θ` (`x₄ ↦ −x₄`) gives a positive semidefinite pairing
  `∫ F(Θω) G(ω) wE β 1` on bounded functions of the closed upper half (`M` even, every real `β`).
* `cs_even` : `Gc b b' (u+v)² ≤ Gc b b (2u) · Gc b' b' (2v)` for `2u, 2v ≤ M`, `Gc b b' T = corr 0 T`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-! ## The weight -/

theorem wE_one (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) ω = Real.exp (β * ∑ B, zt N M true false B * (hol N M ω B).re) := by
  unfold wE SB ce
  congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  simp [etaB]

theorem integral_wE_one (β : ℝ) :
    ∫ ω, wE N M β (fun _ => 1) ω ∂(haarCfg N M) = ZW N M β true false := by
  rw [integral_wE]
  exact ZEta_one N M β true

theorem continuous_wE (β : ℝ) (η : Pt M → ℝ) : Continuous (wE N M β η) :=
  continuous_exp_SB N M β _

theorem wE_pos (β : ℝ) (η : Pt M → ℝ) (ω : Link N M → SU2) : 0 < wE N M β η ω := Real.exp_pos _

/-! ## Time translation -/

/-- one step in the time direction `x₄` on links -/
def tE : Link N M ≃ Link N M where
  toFun ℓ := (ℓ.1 + ev N M 3, ℓ.2)
  invFun ℓ := (ℓ.1 - ev N M 3, ℓ.2)
  left_inv ℓ := by simp
  right_inv ℓ := by simp

/-- the same on plaquettes -/
def pE : Plaq N M ≃ Plaq N M where
  toFun B := (B.1 + ev N M 3, B.2)
  invFun B := (B.1 - ev N M 3, B.2)
  left_inv B := by simp
  right_inv B := by simp

/-- time translation of configurations `(τω)(x, d) = ω(x + e₄, d)` -/
def tau (ω : Link N M → SU2) : Link N M → SU2 := fun ℓ => ω (tE N M ℓ)

theorem tau_mp : MeasurePreserving (tau N M) (haarCfg N M) (haarCfg N M) := by
  have h := measurePreserving_piCongrLeft (fun _ : Link N M => haarSU2) (tE N M).symm
  unfold haarCfg
  convert h using 1
  funext ω ℓ
  rw [ThickFloorRP.LinkReflection.piCongrLeft_const, Equiv.symm_symm]
  rfl

theorem integral_tau (H : (Link N M → SU2) → ℝ) (hH : Measurable H) :
    ∫ ω, H (tau N M ω) ∂(haarCfg N M) = ∫ ω, H ω ∂(haarCfg N M) := by
  conv_rhs => rw [← (tau_mp N M).map_eq]
  rw [integral_map (tau_mp N M).measurable.aemeasurable hH.aestronglyMeasurable]

theorem hol_tau (ω : Link N M → SU2) (B : Plaq N M) :
    hol N M (tau N M ω) B = hol N M ω (pE N M B) := by
  obtain ⟨x, P⟩ := B
  have e : ∀ d : Fin 4, x + ev N M d + ev N M 3 = x + ev N M 3 + ev N M d :=
    fun d => add_right_comm _ _ _
  simp only [hol, l1, l2, l3, l4, tau, tE, pE, Equiv.coe_fn_mk, e]

theorem zt_tau (B : Plaq N M) : zt N M true false (pE N M B) = zt N M true false B := by
  obtain ⟨x, P⟩ := B
  have h1 : (x + ev N M 3).1 = x.1 := by
    show x.1 + (ev N M 3).1 = x.1
    simp [ev]
  simp [zt, pE, h1, tw]

theorem wE_tau (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) (tau N M ω) = wE N M β (fun _ => 1) ω := by
  rw [wE_one, wE_one]
  congr 2
  have e : ∀ B : Plaq N M, zt N M true false B * (hol N M (tau N M ω) B).re
      = (fun B => zt N M true false B * (hol N M ω B).re) (pE N M B) := by
    intro B
    simp only [hol_tau, zt_tau]
  rw [Finset.sum_congr rfl (fun B _ => e B)]
  exact Equiv.sum_comp (pE N M) (fun B => zt N M true false B * (hol N M ω B).re)

theorem polyLoop_tau (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) :
    polyLoop N M b t (tau N M ω) = polyLoop N M b (t + 1) ω := by
  unfold polyLoop
  congr 1
  congr 1
  refine List.map_congr_left fun k _ => ?_
  have hs : (((b, ((k : ZMod M), t)) : Site N M) + ev N M 3) = (b, ((k : ZMod M), t + 1)) := by
    simp [ev]
  show ((ω ((((b, ((k : ZMod M), t)) : Site N M) + ev N M 3), 2) : SU2) : ℍr) = _
  rw [hs]

theorem polyLoop_Th (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) :
    polyLoop N M b t (Th N M ω) = polyLoop N M b (-t) ω := by
  unfold polyLoop
  congr 1

/-! ## Correlations -/

/-- the unnormalised correlation `∫ P_b(s) P_{b'}(t) wE β 1` -/
noncomputable def corr (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) : ℝ :=
  ∫ ω, (polyLoop N M b s ω * polyLoop N M b' t ω) * wE N M β (fun _ => 1) ω ∂(haarCfg N M)

theorem measurable_corrInt (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) :
    Measurable fun ω => (polyLoop N M b s ω * polyLoop N M b' t ω) * wE N M β (fun _ => 1) ω :=
  (((continuous_polyLoop N M b s).mul (continuous_polyLoop N M b' t)).mul
    (continuous_wE N M β _)).measurable

theorem corr_shift1 (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) :
    corr N M β b b' (s + 1) (t + 1) = corr N M β b b' s t := by
  have h := integral_tau N M _ (measurable_corrInt N M β b b' s t)
  simp only [polyLoop_tau, wE_tau] at h
  exact h

theorem corr_shiftN (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) (k : ℕ) :
    corr N M β b b' (s + k) (t + k) = corr N M β b b' s t := by
  induction k with
  | zero => simp
  | succ k ih =>
    have e1 : s + ((k + 1 : ℕ) : ZMod M) = (s + k) + 1 := by push_cast; ring
    have e2 : t + ((k + 1 : ℕ) : ZMod M) = (t + k) + 1 := by push_cast; ring
    rw [e1, e2, corr_shift1, ih]

theorem corr_shiftZ (β : ℝ) (b b' : ZMod N × ZMod N) (s t c : ZMod M) :
    corr N M β b b' (s + c) (t + c) = corr N M β b b' s t := by
  have h := corr_shiftN N M β b b' s t c.val
  rwa [ZMod.natCast_zmod_val] at h

theorem corr_zero (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) :
    corr N M β b b' s t = corr N M β b b' 0 (t - s) := by
  have h := corr_shiftZ N M β b b' 0 (t - s) s
  rw [zero_add, sub_add_cancel] at h
  exact h

/-- `Gc b b' T = ∫ P_b(0) P_{b'}(T) wE β 1` -/
noncomputable def Gc (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ) : ℝ := corr N M β b b' 0 (T : ZMod M)

theorem Gc_swap (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ) (hT : T ≤ M) :
    Gc N M β b b' (M - T) = Gc N M β b' b T := by
  unfold Gc
  have e : ((M - T : ℕ) : ZMod M) = -(T : ZMod M) := by
    rw [Nat.cast_sub hT, ZMod.natCast_self, zero_sub]
  rw [e, corr_zero N M β b b' 0 (-(T : ZMod M))]
  have h := corr_shiftZ N M β b b' (0 : ZMod M) (-(T : ZMod M)) (T : ZMod M)
  rw [zero_add, neg_add_cancel] at h
  rw [show (-(T : ZMod M) - 0) = -(T : ZMod M) by ring, ← h]
  unfold corr
  congr 1
  funext ω
  ring

/-! ## The weighted reflection pairing -/

theorem w_split (hM : M % 2 = 0) (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) ω = aW N M β (fun _ => 1) ω * aW N M β (fun _ => 1) (Th N M ω) := by
  rw [aW_mul_refl N M hM, glue_one_one]

theorem pair_absorb (hM : M % 2 = 0) (β : ℝ) (F G : (Link N M → SU2) → ℝ) :
    ∫ ω, F (Th N M ω) * G ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)
      = ∫ ω, (F (Th N M ω) * aW N M β (fun _ => 1) (Th N M ω))
          * (G ω * aW N M β (fun _ => 1) ω) ∂(haarCfg N M) := by
  refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
  dsimp only
  rw [w_split N M hM]
  ring

theorem aW_bounds (hM : M % 2 = 0) (β : ℝ) :
    Measurable (aW N M β (fun _ => 1)) ∧
    (∀ ω, |aW N M β (fun _ => 1) ω| ≤ Real.exp (|β| * ∑ B, |ca N M (fun _ => 1) B|)) ∧
    (∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) →
      aW N M β (fun _ => 1) ω = aW N M β (fun _ => 1) ω') := by
  refine ⟨(continuous_exp_SB N M β _).measurable, fun ω => exp_SB_le N M β _ ω, fun ω ω' h => ?_⟩
  show Real.exp (β * SB N M (ca N M (fun _ => 1)) ω) = Real.exp (β * SB N M (ca N M (fun _ => 1)) ω')
  rw [SB_ca_dep N M hM _ ω ω' h]

/-- **Weighted Cauchy–Schwarz** (`M` even, every real `β`). -/
theorem wpair_cs (hM : M % 2 = 0) (β : ℝ) (F G : (Link N M → SU2) → ℝ)
    (hF : Measurable F) (hG : Measurable G) (CF CG : ℝ) (hFC : ∀ ω, |F ω| ≤ CF)
    (hGC : ∀ ω, |G ω| ≤ CG)
    (hdF : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω')
    (hdG : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → G ω = G ω') :
    (∫ ω, F (Th N M ω) * G ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)) ^ 2
      ≤ (∫ ω, F (Th N M ω) * F ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M))
        * ∫ ω, G (Th N M ω) * G ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M) := by
  obtain ⟨ha, haK, hda⟩ := aW_bounds N M hM β
  set a := aW N M β (fun _ => 1)
  set K := Real.exp (|β| * ∑ B, |ca N M (fun _ => 1) B|)
  rw [pair_absorb N M hM, pair_absorb N M hM, pair_absorb N M hM]
  have hCF : 0 ≤ CF := (abs_nonneg _).trans (hFC (fun _ => 1))
  have hCG : 0 ≤ CG := (abs_nonneg _).trans (hGC (fun _ => 1))
  exact pair_cauchy_schwarz N M hM (fun ω => F ω * a ω) (fun ω => G ω * a ω) (hF.mul ha) (hG.mul ha)
    (CF * K) (CG * K)
    (fun ω => by
      show |F ω * a ω| ≤ CF * K
      rw [abs_mul]; exact mul_le_mul (hFC ω) (haK ω) (abs_nonneg _) hCF)
    (fun ω => by
      show |G ω * a ω| ≤ CG * K
      rw [abs_mul]; exact mul_le_mul (hGC ω) (haK ω) (abs_nonneg _) hCG)
    (fun ω ω' h => by
      show F ω * a ω = F ω' * a ω'
      rw [hdF ω ω' h, hda ω ω' h])
    (fun ω ω' h => by
      show G ω * a ω = G ω' * a ω'
      rw [hdG ω ω' h, hda ω ω' h])

/-- **Weighted reflection positivity** (`M` even, every real `β`). -/
theorem wpair_nonneg (hM : M % 2 = 0) (β : ℝ) (F : (Link N M → SU2) → ℝ)
    (hF : Measurable F) (CF : ℝ) (hFC : ∀ ω, |F ω| ≤ CF)
    (hdF : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω') :
    0 ≤ ∫ ω, F (Th N M ω) * F ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M) := by
  obtain ⟨ha, haK, hda⟩ := aW_bounds N M hM β
  set a := aW N M β (fun _ => 1)
  set K := Real.exp (|β| * ∑ B, |ca N M (fun _ => 1) B|)
  rw [pair_absorb N M hM]
  have hCF : 0 ≤ CF := (abs_nonneg _).trans (hFC (fun _ => 1))
  exact half_pairing_nonneg N M hM (fun ω => F ω * a ω) (hF.mul ha) (CF * K)
    (fun ω => by
      show |F ω * a ω| ≤ CF * K
      rw [abs_mul]; exact mul_le_mul (hFC ω) (haK ω) (abs_nonneg _) hCF)
    (fun ω ω' h => by
      show F ω * a ω = F ω' * a ω'
      rw [hdF ω ω' h, hda ω ω' h])

/-! ## Polyakov loops in the closed upper half -/

theorem polyLoop_dep (b : ZMod N × ZMod N) (u : ℕ) (hu : 2 * u ≤ M) (ω ω' : Link N M → SU2)
    (h : ∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) :
    polyLoop N M b (u : ZMod M) ω = polyLoop N M b (u : ZMod M) ω' := by
  have hM0 := NeZero.ne M
  have hv : ((u : ZMod M)).val = u := ZMod.val_cast_of_lt (by omega)
  have hc : ∀ k : ℕ, fixL N M ((b, ((k : ZMod M), (u : ZMod M))), 2)
      ∨ posL N M ((b, ((k : ZMod M), (u : ZMod M))), 2) := by
    intro k
    by_cases h0 : u = 0
    · exact Or.inl ⟨(show (2 : Fin 4) ≠ 3 by decide), Or.inl (by show ((u : ZMod M)).val = 0; rw [hv, h0])⟩
    · by_cases h2 : 2 * u = M
      · exact Or.inl ⟨(show (2 : Fin 4) ≠ 3 by decide), Or.inr (by show 2 * ((u : ZMod M)).val = M; rw [hv]; exact h2)⟩
      · exact Or.inr (Or.inl ⟨(show (2 : Fin 4) ≠ 3 by decide), by show 0 < ((u : ZMod M)).val; rw [hv]; omega,
          by show 2 * ((u : ZMod M)).val < M; rw [hv]; omega⟩)
  unfold polyLoop
  congr 1
  congr 1
  refine List.map_congr_left fun k _ => ?_
  rw [h _ (hc k)]

/-- the pairing of two Polyakov loops of the upper half is a correlation -/
theorem pair_corr (β : ℝ) (b b' : ZMod N × ZMod N) (u v : ℕ) :
    ∫ ω, polyLoop N M b (u : ZMod M) (Th N M ω) * polyLoop N M b' (v : ZMod M) ω
        * wE N M β (fun _ => 1) ω ∂(haarCfg N M)
      = Gc N M β b b' (u + v) := by
  simp only [polyLoop_Th]
  show corr N M β b b' (-(u : ZMod M)) (v : ZMod M) = _
  rw [corr_zero]
  unfold Gc
  congr 1
  push_cast
  ring

/-- **Midpoint log-convexity on even separations** (`M` even, every real `β`, `2u, 2v ≤ M`). -/
theorem cs_even (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) (u v : ℕ)
    (hu : 2 * u ≤ M) (hv : 2 * v ≤ M) :
    Gc N M β b b' (u + v) ^ 2 ≤ Gc N M β b b (2 * u) * Gc N M β b' b' (2 * v) := by
  have h := wpair_cs N M hM β (polyLoop N M b (u : ZMod M)) (polyLoop N M b' (v : ZMod M))
    (continuous_polyLoop N M b _).measurable (continuous_polyLoop N M b' _).measurable 1 1
    (abs_polyLoop_le N M b _) (abs_polyLoop_le N M b' _)
    (polyLoop_dep N M b u hu) (polyLoop_dep N M b' v hv)
  rw [pair_corr, pair_corr, pair_corr, show u + u = 2 * u by ring, show v + v = 2 * v by ring] at h
  exact h

/-- even separations have nonnegative correlation (`2u ≤ M`) -/
theorem Gc_even_nonneg (hM : M % 2 = 0) (β : ℝ) (b : ZMod N × ZMod N) (u : ℕ) (hu : 2 * u ≤ M) :
    0 ≤ Gc N M β b b (2 * u) := by
  have h := wpair_nonneg N M hM β (polyLoop N M b (u : ZMod M))
    (continuous_polyLoop N M b _).measurable 1 (abs_polyLoop_le N M b _) (polyLoop_dep N M b u hu)
  rw [pair_corr, show u + u = 2 * u by ring] at h
  exact h

theorem integrable_corrInt (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) :
    Integrable (fun ω => (polyLoop N M b s ω * polyLoop N M b' t ω) * wE N M β (fun _ => 1) ω)
      (haarCfg N M) := by
  refine Integrable.of_bound (measurable_corrInt N M β b b' s t).aestronglyMeasurable
    (1 * Real.exp (|β| * ∑ B, |ce N M (fun _ => 1) B|)) (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_mul]
  refine mul_le_mul ?_ (exp_SB_le N M β _ ω) (abs_nonneg _) zero_le_one
  rw [abs_mul]
  exact mul_le_one₀ (abs_polyLoop_le N M b s ω) (abs_nonneg _) (abs_polyLoop_le N M b' t ω)

/-- `|∫ P_b(0) P_{b'}(T) w| ≤ Z₀` -/
theorem abs_Gc_le (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ) :
    |Gc N M β b b' T| ≤ ZW N M β true false := by
  unfold Gc corr
  rw [← integral_wE_one N M β]
  refine (abs_integral_le_integral_abs).trans (integral_mono
    (integrable_corrInt N M β b b' 0 (T : ZMod M)).abs (integrable_wE N M β _) fun ω => ?_)
  dsimp only
  rw [abs_mul, abs_of_pos (wE_pos N M β _ ω)]
  refine mul_le_of_le_one_left (wE_pos N M β _ ω).le ?_
  rw [abs_mul]
  exact mul_le_one₀ (abs_polyLoop_le N M b _ ω) (abs_nonneg _) (abs_polyLoop_le N M b' _ ω)

end PolyakovT

#print axioms PolyakovT.cs_even
#print axioms PolyakovT.Gc_even_nonneg
#print axioms PolyakovT.abs_Gc_le
#print axioms PolyakovT.Gc_swap
