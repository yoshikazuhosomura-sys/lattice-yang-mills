import PolyT.LinkSplitV3
import Lattice.RPKernelV1

/-!
# Reflection positivity through the link mid-planes (`M` even, `M ≥ 4`, `β ≥ 0`)

`PolyakovT.link_rp` : for `F` bounded, measurable, gauge invariant and depending only on the links of
the positive side (`posPL` : spatial links with `x₄ ≤ M/2 − 1`, time links with `x₄ ≤ M/2 − 2`) and
the crossing links,
`0 ≤ ∫ F(ThP ω) F(ω) wE β 1 (ω) dHaar`.
Steps: gauge fixing of the crossing links (`integral_fix_crossing`), the split of the action
(`split_sum`), the crossing plaquettes as `Σ_j φ_j(ω) φ_j(Θω)` with `φ` the quaternion components of
the positive-side spatial links next to the planes (`cross_term`), and the abstract
`LinkReflection.rp_kernel` (positive-definite kernel `exp(β⟨·,·⟩)`, `β ≥ 0`).
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem half_add_half (hM : M % 2 = 0) : halfPt M + halfPt M = 0 := by
  rw [halfPt, ← Nat.cast_add, show M / 2 + M / 2 = M by omega, ZMod.natCast_self]

theorem time_add_ev (x : Site N M) (d : Fin 4) (hd : d ≠ 3) : (x + ev N M d).2.2 = x.2.2 := by
  rw [ev_v4, if_neg hd]

/-- values: identity on crossing links, `sgL` elsewhere -/
noncomputable def sgP (ℓ : Link N M) : SU2 → SU2 := if crP N M ℓ then id else sgL N M ℓ

/-- the reflection used with crossing links frozen -/
noncomputable def ThQ (ω : Link N M → SU2) : Link N M → SU2 :=
  LinkReflection.linkRefl (thP N M) (sgP N M) ω

/-- positive-side links -/
def posPL (ℓ : Link N M) : Prop :=
  (ℓ.2 ≠ 3 ∧ ℓ.1.2.2.val + 1 ≤ M / 2) ∨ (ℓ.2 = 3 ∧ ℓ.1.2.2.val + 2 ≤ M / 2)

instance : DecidablePred (posPL N M) := fun ℓ => by unfold posPL; infer_instance

theorem time_thP3 (y : Site N M) : (rP N M (y + ev N M 3)).2.2 = -1 - (y.2.2 + 1) := by
  rw [time_rP, time_add_e4]

theorem crP_thP (hM : M % 2 = 0) (ℓ : Link N M) : crP N M (thP N M ℓ) ↔ crP N M ℓ := by
  have hh := half_add_half M hM
  obtain ⟨y, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd
    simp only [crP, thP, if_true, time_thP3, true_and]
    constructor
    · rintro (h | h)
      · left; linear_combination (-1 : ZMod M) * h
      · right; linear_combination (-1 : ZMod M) * h - hh
    · rintro (h | h)
      · left; linear_combination (-1 : ZMod M) * h
      · right; linear_combination (-1 : ZMod M) * h - hh
  · simp [crP, thP, hd]

theorem rP_e4_of_cross (hM : M % 2 = 0) (y : Site N M)
    (hy : y.2.2 + 1 = 0 ∨ y.2.2 + 1 = halfPt M) : rP N M (y + ev N M 3) = y := by
  have hh := half_add_half M hM
  obtain ⟨⟨a1, a2⟩, ⟨a3, a4⟩⟩ := y
  simp only at hy
  have e3 : (ev N M 3) = ((0, 0), (0, 1)) := rfl
  simp only [rP, e3, Prod.mk_add_mk, add_zero, Prod.mk.injEq, true_and]
  rcases hy with h | h
  · linear_combination (-2 : ZMod M) * h
  · linear_combination (-2 : ZMod M) * h - hh

theorem thP_fix (hM : M % 2 = 0) (ℓ : Link N M) (h : crP N M ℓ) : thP N M ℓ = ℓ := by
  obtain ⟨y, d⟩ := ℓ
  obtain ⟨hd, hy⟩ := h
  simp only at hd
  subst hd
  simp only [thP, if_true]
  rw [rP_e4_of_cross N M hM y hy]

theorem setOne_ThP (hM : M % 2 = 0) (ω : Link N M → SU2) :
    ThP N M (GroupGaugeFix.setOne (crP N M) ω) = GroupGaugeFix.setOne (crP N M) (ThQ N M ω) := by
  funext ℓ
  show sgL N M ℓ (GroupGaugeFix.setOne (crP N M) ω (thP N M ℓ))
    = GroupGaugeFix.setOne (crP N M) (fun ℓ => sgP N M ℓ (ω (thP N M ℓ))) ℓ
  unfold GroupGaugeFix.setOne
  by_cases hc : crP N M ℓ
  · have hc' : crP N M (thP N M ℓ) := (crP_thP N M hM ℓ).2 hc
    rw [if_pos hc', if_pos hc]
    have h3 : ℓ.2 = 3 := hc.1
    simp [sgL, h3]
  · have hc' : ¬ crP N M (thP N M ℓ) := fun h => hc ((crP_thP N M hM ℓ).1 h)
    rw [if_neg hc', if_neg hc]
    simp only [sgP, if_neg hc]

/-- positive-side half weight -/
noncomputable def AP (β : ℝ) (ω : Link N M → SU2) : ℝ :=
  Real.exp (β * SB N M (fun B => cP N M B * zt N M true false B) ω)

theorem wE_split (hM : M % 2 = 0) (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) ω
      = AP N M β ω * AP N M β (ThP N M ω) * Real.exp (β * ∑ B, crI N M B * (hol N M ω B).re) := by
  rw [wE_one, split_sum N M hM, AP, AP, SB, SB, ← Real.exp_add, ← Real.exp_add]
  congr 1
  ring

/-- quaternion components -/
noncomputable def comp (c : Fin 4) (q : ℍr) : ℝ :=
  if c = 0 then q.re else if c = 1 then q.imI else if c = 2 then q.imJ else q.imK

theorem continuous_comp (c : Fin 4) : Continuous (comp c) := by
  unfold comp
  split_ifs
  · exact Quaternion.continuous_re
  · exact Quaternion.continuous_imI
  · exact Quaternion.continuous_imJ
  · exact Quaternion.continuous_imK

theorem abs_comp_le (c : Fin 4) (q : SU2) : |comp c (q : ℍr)| ≤ 1 := by
  have hq : ‖(q : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h1 : Quaternion.normSq (q : ℍr) = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, hq, mul_one]
  rw [Quaternion.normSq_def'] at h1
  have := sq_nonneg (q : ℍr).re; have := sq_nonneg (q : ℍr).imI
  have := sq_nonneg (q : ℍr).imJ; have := sq_nonneg (q : ℍr).imK
  unfold comp
  split_ifs <;> rw [abs_le] <;> constructor <;> nlinarith

theorem comp_0 (q : ℍr) : comp 0 q = q.re := rfl
theorem comp_1 (q : ℍr) : comp 1 q = q.imI := rfl
theorem comp_2 (q : ℍr) : comp 2 q = q.imJ := rfl
theorem comp_3 (q : ℍr) : comp 3 q = q.imK := rfl

theorem re_mul_star_eq (a b : ℍr) : (a * star b).re = ∑ c : Fin 4, comp c a * comp c b := by
  rw [Fin.sum_univ_four, comp_0, comp_0, comp_1, comp_1, comp_2, comp_2, comp_3, comp_3]
  simp only [Quaternion.re_mul, Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star,
    Quaternion.imK_star]
  ring

/-- the positive-side spatial link of a crossing plaquette -/
def posLink (B : Plaq N M) : Link N M :=
  if B.1.2.2 + 1 = 0 then (B.1 + ev N M 3, B.2.1.1) else (B.1, B.2.1.1)

noncomputable def φP (ω : Link N M → SU2) (j : Plaq N M × Fin 4) : ℝ :=
  if crPl N M j.1 then comp j.2 (ω (posLink N M j.1) : ℍr) else 0

theorem cross_cond (hM : M % 2 = 0) (B : Plaq N M) (hB : crPl N M B) :
    B.1.2.2 + 1 = 0 ∨ B.1.2.2 + 1 = halfPt M := by
  have hlt := ZMod.val_lt B.1.2.2
  have h1 := val_add_one_eq M B.1.2.2
  rcases hB.2 with h | h
  · by_cases hm : B.1.2.2.val + 1 = M
    · left; rw [if_pos hm] at h1; exact (ZMod.val_eq_zero _).1 h1
    · right
      rw [if_neg hm] at h1
      apply ZMod.val_injective
      rw [h1, halfPt, ZMod.val_cast_of_lt (by omega)]; exact h
  · left; rw [if_pos h] at h1; exact (ZMod.val_eq_zero _).1 h1

theorem cross_term (hM : M % 2 = 0) (ω : Link N M → SU2) :
    ∑ B, crI N M B * (hol N M (GroupGaugeFix.setOne (crP N M) ω) B).re
      = ∑ j, φP N M ω j * φP N M (ThQ N M ω) j := by
  rw [Fintype.sum_prod_type (f := fun j : Plaq N M × Fin 4 => φP N M ω j * φP N M (ThQ N M ω) j)]
  refine Finset.sum_congr rfl fun B _ => ?_
  by_cases hB : crPl N M B
  · have hc := cross_cond N M hM B hB
    simp only [crI, φP, if_pos hB, one_mul]
    obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
    have hν : ν = 3 := hB.1
    subst hν
    have hμ3 : μ ≠ 3 := fin_ne_three μ 3 hμν
    simp only at hc
    have hx : rP N M (x + ev N M 3) = x := rP_e4_of_cross N M hM x hc
    have hx' : rP N M x = x + ev N M 3 := by rw [← hx, rP_rP, hx]
    -- the values of the frozen configuration on the plaquette
    have s1 : GroupGaugeFix.setOne (crP N M) ω (x, μ) = ω (x, μ) := by
      unfold GroupGaugeFix.setOne; rw [if_neg (fun h => hμ3 h.1)]
    have s3 : GroupGaugeFix.setOne (crP N M) ω (x + ev N M 3, μ) = ω (x + ev N M 3, μ) := by
      unfold GroupGaugeFix.setOne; rw [if_neg (fun h => hμ3 h.1)]
    have s2 : GroupGaugeFix.setOne (crP N M) ω (x + ev N M μ, 3) = 1 := by
      unfold GroupGaugeFix.setOne; rw [if_pos ⟨rfl, by rw [time_add_ev N M x μ hμ3]; exact hc⟩]
    have s4 : GroupGaugeFix.setOne (crP N M) ω (x, 3) = 1 := by
      unfold GroupGaugeFix.setOne; rw [if_pos ⟨rfl, hc⟩]
    have hq : ∀ z : Site N M, ThQ N M ω (z, μ) = ω (rP N M z, μ) := by
      intro z
      show sgP N M (z, μ) (ω (thP N M (z, μ))) = _
      have hn : ¬ crP N M (z, μ) := fun h => hμ3 h.1
      simp only [sgP, if_neg hn, sgL, thP, if_neg hμ3, id_eq]
    simp only [hol, l1, l2, l3, l4]
    rw [s1, s2, s3, s4, Metric.unitSphere.coe_one, mul_one, star_one, mul_one]
    unfold posLink
    by_cases h0 : x.2.2 + 1 = 0
    · simp only [if_pos h0]
      rw [hq, hx, re_mul_star_eq]
      exact Finset.sum_congr rfl fun c _ => by ring
    · simp only [if_neg h0]
      rw [hq, hx', re_mul_star_eq]
  · simp [crI, φP, hB]

end PolyakovT

#print axioms PolyakovT.wE_split
#print axioms PolyakovT.cross_term
#print axioms PolyakovT.setOne_ThP
