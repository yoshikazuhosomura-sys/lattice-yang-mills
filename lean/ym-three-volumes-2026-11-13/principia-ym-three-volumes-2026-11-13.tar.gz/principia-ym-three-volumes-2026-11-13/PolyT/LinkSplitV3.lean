import PolyT.LinkFixV2

/-!
# The weight split for the link mid-plane reflection (`M` even)

`rhoPP` : the plaquette map of `ThP`; `re_hol_ThP` : `Re U_B(ThP ω) = Re U_{rhoPP B}(ω)`.
`cP` : the plaquettes of the positive side (spatial plaquettes with `x₄ ≤ M/2 − 1`, time plaquettes
with `x₄ ≤ M/2 − 2`); `crI` : the plaquettes crossing a mid-plane (time plaquettes with
`x₄ + 1 ∈ {M/2, M}`).
`split_sum` : `Σ_B z_B Re U_B(ω) = Σ_B cP_B z_B Re U_B(ω) + Σ_B cP_B z_B Re U_B(ThP ω)
  + Σ_B crI_B Re U_B(ω)`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- plaquettes -/
def rhoPP (B : Plaq N M) : Plaq N M :=
  if B.2.1.2 = 3 then (rP N M (B.1 + ev N M 3), B.2) else (rP N M B.1, B.2)

theorem rhoPP_invol : Function.Involutive (rhoPP N M) := by
  intro B
  obtain ⟨x, P⟩ := B
  by_cases h : P.1.2 = 3
  · simp [rhoPP, h, rP_add_ev3, rP_rP]
  · simp [rhoPP, h, rP_rP]

theorem rhoPP_snd (B : Plaq N M) : (rhoPP N M B).2 = B.2 := by
  unfold rhoPP; split_ifs <;> rfl

theorem rhoPP_fst_fst (B : Plaq N M) : (rhoPP N M B).1.1 = B.1.1 := by
  unfold rhoPP; split_ifs
  · show (B.1 + ev N M 3).1 = B.1.1
    show B.1.1 + (ev N M 3).1 = B.1.1
    simp [ev]
  · rfl

theorem re_hol_ThP (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (ThP N M ω) B).re = (hol N M ω (rhoPP N M B)).re := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have hμ3 : μ ≠ 3 := fin_ne_three μ ν hμν
  by_cases hν : ν = 3
  · subst hν
    have hr : rhoPP N M (x, ⟨(μ, 3), hμν⟩) = (rP N M (x + ev N M 3), ⟨(μ, 3), hμν⟩) := by
      simp [rhoPP]
    rw [hr]
    simp only [hol, l1, l2, l3, l4]
    rw [ThP_ne N M ω x μ hμ3, ThP_three, ThP_ne N M ω _ μ hμ3, ThP_three, coe_inv_su2, coe_inv_su2,
      star_star]
    have e1 : rP N M x = rP N M (x + ev N M 3) + ev N M 3 := (rP_add_ev3 N M x).symm
    have e2 : rP N M (x + ev N M μ + ev N M 3) = rP N M (x + ev N M 3) + ev N M μ := by
      rw [add_right_comm, rP_add_ev N M _ μ hμ3]
    rw [e2, e1]
    exact re_rev _ _ _ _
  · have hr : rhoPP N M (x, ⟨(μ, ν), hμν⟩) = (rP N M x, ⟨(μ, ν), hμν⟩) := by
      simp [rhoPP, hν]
    rw [hr]
    simp only [hol, l1, l2, l3, l4]
    rw [ThP_ne N M ω x μ hμ3, ThP_ne N M ω _ ν hν, ThP_ne N M ω _ μ hμ3, ThP_ne N M ω x ν hν,
      rP_add_ev N M x μ hμ3, rP_add_ev N M x ν hν]

theorem zt_rhoPP (B : Plaq N M) : zt N M true false (rhoPP N M B) = zt N M true false B := by
  unfold zt
  rw [rhoPP_snd, rhoPP_fst_fst]
  simp [tw]

/-- `(−1 − a).val = M − 1 − a.val` -/
theorem val_neg_one_sub (a : ZMod M) : (-1 - a).val = M - 1 - a.val := by
  have hlt := ZMod.val_lt a
  have e : (-1 - a) = ((M - 1 - a.val : ℕ) : ZMod M) := by
    rw [Nat.cast_sub (by omega : a.val ≤ M - 1), Nat.cast_sub (by omega : 1 ≤ M), ZMod.natCast_self,
      Nat.cast_one, ZMod.natCast_zmod_val]
    ring
  rw [e, ZMod.val_cast_of_lt (by omega)]

theorem time_add_e4 (x : Site N M) : (x + ev N M 3).2.2 = x.2.2 + 1 := by
  show x.2.2 + (ev N M 3).2.2 = x.2.2 + 1
  simp [ev]

theorem time_rP (x : Site N M) : (rP N M x).2.2 = -1 - x.2.2 := rfl

/-- positive-side plaquettes -/
noncomputable def cP (B : Plaq N M) : ℝ :=
  if B.2.1.2 = 3 then (if B.1.2.2.val + 2 ≤ M / 2 then 1 else 0)
  else (if B.1.2.2.val + 1 ≤ M / 2 then 1 else 0)

/-- crossing plaquettes -/
def crPl (B : Plaq N M) : Prop :=
  B.2.1.2 = 3 ∧ (B.1.2.2.val + 1 = M / 2 ∨ B.1.2.2.val + 1 = M)

instance : DecidablePred (crPl N M) := fun B => by unfold crPl; infer_instance

noncomputable def crI (B : Plaq N M) : ℝ := if crPl N M B then 1 else 0

theorem coef_sum (hM : M % 2 = 0) (B : Plaq N M) :
    cP N M B + cP N M (rhoPP N M B) + crI N M B = 1 := by
  obtain ⟨x, P⟩ := B
  have hlt := ZMod.val_lt x.2.2
  by_cases h : P.1.2 = 3
  · have hr : rhoPP N M (x, P) = (rP N M (x + ev N M 3), P) := by simp [rhoPP, h]
    have hv : (rP N M (x + ev N M 3)).2.2.val = M - 1 - (if x.2.2.val + 1 = M then 0 else x.2.2.val + 1) := by
      rw [time_rP, time_add_e4, val_neg_one_sub, val_add_one_eq M]
    rw [hr]
    simp only [cP, crI, crPl, h, if_true, true_and] at hv ⊢
    rw [hv]
    split_ifs <;> first | omega | norm_num
  · have hr : rhoPP N M (x, P) = (rP N M x, P) := by simp [rhoPP, h]
    have hv : (rP N M x).2.2.val = M - 1 - x.2.2.val := by rw [time_rP, val_neg_one_sub]
    rw [hr]
    simp only [cP, crI, crPl, h, if_false, false_and] at hv ⊢
    rw [hv]
    split_ifs <;> first | omega | norm_num

theorem zt_cross (B : Plaq N M) (hB : crPl N M B) : zt N M true false B = 1 := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have h3 : ν = 3 := hB.1
  unfold zt
  have hne : (⟨(μ, ν), hμν⟩ : Plane) ≠ p01 := by
    intro e
    have := congrArg (fun P : Plane => P.1.2) e
    simp only [p01] at this
    rw [h3] at this
    exact absurd this (by decide)
  simp [hne, tw]

/-- **The split of the action** (`M` even, any configuration). -/
theorem split_sum (hM : M % 2 = 0) (ω : Link N M → SU2) :
    ∑ B, zt N M true false B * (hol N M ω B).re
      = ∑ B, cP N M B * zt N M true false B * (hol N M ω B).re
        + ∑ B, cP N M B * zt N M true false B * (hol N M (ThP N M ω) B).re
        + ∑ B, crI N M B * (hol N M ω B).re := by
  have h2 : ∑ B, cP N M B * zt N M true false B * (hol N M (ThP N M ω) B).re
      = ∑ B, cP N M (rhoPP N M B) * zt N M true false B * (hol N M ω B).re := by
    simp only [re_hol_ThP]
    rw [← Equiv.sum_comp (rhoPP_invol N M).toPerm
      (fun B => cP N M (rhoPP N M B) * zt N M true false B * (hol N M ω B).re)]
    refine Finset.sum_congr rfl fun B _ => ?_
    simp only [Function.Involutive.coe_toPerm, rhoPP_invol N M B, zt_rhoPP]
  rw [h2, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  have hc := coef_sum N M hM B
  by_cases hB : crPl N M B
  · have hz := zt_cross N M B hB
    have hi : crI N M B = 1 := by simp [crI, hB]
    rw [hi] at hc
    rw [hz, hi]
    have : cP N M B + cP N M (rhoPP N M B) = 0 := by linarith
    linear_combination (-(hol N M ω B).re) * this
  · have hi : crI N M B = 0 := by simp [crI, hB]
    rw [hi] at hc ⊢
    linear_combination (-(zt N M true false B * (hol N M ω B).re)) * hc

end PolyakovT

#print axioms PolyakovT.split_sum
