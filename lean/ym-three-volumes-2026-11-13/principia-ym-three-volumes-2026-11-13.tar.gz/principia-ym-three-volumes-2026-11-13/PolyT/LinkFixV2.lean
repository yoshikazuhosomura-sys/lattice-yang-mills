import PolyT.LinkReflV2
import PolyT.MainV1

/-!
# Gauge invariance of the weight and gauge fixing of the links crossing the mid-planes

* `hol_gauge`, `wE_gauge` : `Re U_B` and the weight `wE β 1` are gauge invariant.
* crossing links `crP` : time links `(x, 4)` with `x₄ + 1 ∈ {0, M/2}` (they cross `x₄ = −½` and
  `x₄ = (M−1)/2`); `M` even, `M ≥ 4`.
* `integral_fix_crossing` : for gauge invariant measurable `H`,
  `∫ H dHaar = ∫ H(crossing links set to 1) dHaar`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem coe_gAct (g : Site N M → SU2) (ω : Link N M → SU2) (ℓ : Link N M) :
    ((gAct N M g ω ℓ : SU2) : ℍr)
      = (g ℓ.1 : ℍr) * (ω ℓ : ℍr) * star (g (ℓ.1 + ev N M ℓ.2) : ℍr) := by
  show ((g ℓ.1 * ω ℓ * (g (ℓ.1 + ev N M ℓ.2))⁻¹ : SU2) : ℍr) = _
  rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, coe_inv_su2]

theorem hol_gauge (g : Site N M → SU2) (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (gAct N M g ω) B).re = (hol N M ω B).re := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [hol, l1, l2, l3, l4, coe_gAct]
  have e : x + ev N M ν + ev N M μ = x + ev N M μ + ev N M ν := add_right_comm _ _ _
  rw [e]
  set a := (g x : ℍr)
  set b := (g (x + ev N M μ) : ℍr)
  set c := (g (x + ev N M μ + ev N M ν) : ℍr)
  set d := (g (x + ev N M ν) : ℍr)
  have hb : star b * b = 1 := star_mul_unit _
  have hc : star c * c = 1 := star_mul_unit _
  have hd : star d * d = 1 := star_mul_unit _
  simp only [star_mul, star_star]
  rw [← re_conj (g x) ((ω (x, μ) : ℍr) * (ω (x + ev N M μ, ν) : ℍr)
    * star (ω (x + ev N M ν, μ) : ℍr) * star (ω (x, ν) : ℍr))]
  congr 1
  calc _ = a * (ω (x, μ) : ℍr) * (star b * b) * (ω (x + ev N M μ, ν) : ℍr) * (star c * c)
        * star (ω (x + ev N M ν, μ) : ℍr) * (star d * d) * star (ω (x, ν) : ℍr) * star a := by
        noncomm_ring
    _ = _ := by rw [hb, hc, hd]; noncomm_ring

theorem wE_gauge (β : ℝ) (g : Site N M → SU2) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) (gAct N M g ω) = wE N M β (fun _ => 1) ω := by
  rw [wE_one, wE_one]
  congr 2
  exact Finset.sum_congr rfl fun B _ => by rw [hol_gauge]

/-- the links crossing the two mid-planes -/
def crP (ℓ : Link N M) : Prop := ℓ.2 = 3 ∧ (ℓ.1.2.2 + 1 = 0 ∨ ℓ.1.2.2 + 1 = halfPt M)

instance : DecidablePred (crP N M) := fun ℓ => by unfold crP; infer_instance

/-- the sites that receive a crossing link -/
def inP (x : Site N M) : Prop := x.2.2 = 0 ∨ x.2.2 = halfPt M

instance : DecidablePred (inP N M) := fun x => by unfold inP; infer_instance

/-- the crossing link into `x` -/
def kP (x : Site N M) : Link N M := (x - ev N M 3, 3)

theorem halfPt_ne (hM : M % 2 = 0) (hM4 : 4 ≤ M) :
    halfPt M ≠ 0 ∧ halfPt M - 1 ≠ 0 ∧ (-1 : ZMod M) ≠ halfPt M ∧ (1 : ZMod M) ≠ 0 := by
  have hv : (halfPt M).val = M / 2 := by
    rw [halfPt, ZMod.val_cast_of_lt (by omega)]
  have hv1 : ((1 : ZMod M)).val = 1 := ZMod.val_one'' (by omega)
  refine ⟨fun h => ?_, fun h => ?_, fun h => ?_, fun h => ?_⟩
  · have := congrArg ZMod.val h; rw [hv, ZMod.val_zero] at this; omega
  · have h' : halfPt M = 1 := sub_eq_zero.mp h
    have := congrArg ZMod.val h'; rw [hv, hv1] at this; omega
  · have h' : halfPt M + 1 = 0 := by rw [← h]; ring
    have := congrArg ZMod.val h'
    rw [ZMod.val_add, hv, hv1, ZMod.val_zero, Nat.mod_eq_of_lt (by omega)] at this
    omega
  · have := congrArg ZMod.val h; rw [hv1, ZMod.val_zero] at this; omega

/-- **Gauge fixing of the crossing links** (`M` even, `M ≥ 4`). -/
theorem integral_fix_crossing (hM : M % 2 = 0) (hM4 : 4 ≤ M) (H : (Link N M → SU2) → ℝ)
    (hH : Measurable H) (hinv : ∀ g ω, H (gAct N M g ω) = H ω) :
    ∫ ω, H ω ∂(haarCfg N M)
      = ∫ ω, H (GroupGaugeFix.setOne (crP N M) ω) ∂(haarCfg N M) := by
  obtain ⟨h0, h1, h2, h3⟩ := halfPt_ne M hM hM4
  have hev : ∀ x : Site N M, (x - ev N M 3).2.2 + 1 = x.2.2 := by
    intro x; show x.2.2 - (ev N M 3).2.2 + 1 = x.2.2; simp [ev]
  unfold haarCfg
  refine GroupGaugeFix.integral_gaugeFix haarSU2 (fun ℓ : Link N M => ℓ.1)
    (fun ℓ : Link N M => ℓ.1 + ev N M ℓ.2) (crP N M) (inP N M) (kP N M)
    GroupGaugeFix.haarSU2_two_sided ?_ ?_ ?_ H hH hinv
  · intro x hx
    refine ⟨⟨rfl, ?_⟩, ?_⟩
    · show (x - ev N M 3).2.2 + 1 = 0 ∨ (x - ev N M 3).2.2 + 1 = halfPt M
      rw [hev]; exact hx
    · show x - ev N M 3 + ev N M 3 = x
      exact sub_add_cancel _ _
  · rintro ⟨y, d⟩ ⟨hd, hy⟩
    simp only at hd hy
    subst hd
    refine ⟨?_, ?_⟩
    · show (y + ev N M 3).2.2 = 0 ∨ (y + ev N M 3).2.2 = halfPt M
      have : (y + ev N M 3).2.2 = y.2.2 + 1 := by show y.2.2 + (ev N M 3).2.2 = _; simp [ev]
      rw [this]; exact hy
    · show (y + ev N M 3 - ev N M 3, (3 : Fin 4)) = (y, 3)
      rw [add_sub_cancel_right]
  · rintro ⟨y, d⟩ ⟨hd, hy⟩
    simp only at hd hy
    show ¬ (y.2.2 = 0 ∨ y.2.2 = halfPt M)
    rintro (e | e)
    · rcases hy with hy | hy
      · rw [e, zero_add] at hy; exact h3 hy
      · rw [e, zero_add] at hy; exact h1 (by rw [← hy]; ring)
    · rcases hy with hy | hy
      · rw [e] at hy; exact h2 (by linear_combination (-1 : ZMod M) * hy)
      · rw [e] at hy; exact h3 (by linear_combination hy)

end PolyakovT

#print axioms PolyakovT.wE_gauge
#print axioms PolyakovT.integral_fix_crossing
