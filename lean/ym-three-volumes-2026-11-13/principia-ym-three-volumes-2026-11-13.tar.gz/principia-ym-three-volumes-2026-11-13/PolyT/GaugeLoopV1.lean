import PolyT.GroupFixV2

/-!
# Gauge invariance of the Polyakov loop on `(ℤ/N)² × (ℤ/M)²`

`PolyakovT.gAct g ω` : the gauge action `ω(x,μ) ↦ g(x) ω(x,μ) g(x + e_μ)⁻¹` (the action of
`GroupGaugeFix.act` with source `x` and target `x + e_μ`).
`PolyakovT.polyLoop_gauge` : `P_b(t)(g·ω) = P_b(t)(ω)` for every gauge transformation `g`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- the gauge action on configurations -/
noncomputable def gAct (g : Site N M → SU2) (ω : Link N M → SU2) : Link N M → SU2 :=
  GroupGaugeFix.act (fun ℓ : Link N M => ℓ.1) (fun ℓ : Link N M => ℓ.1 + ev N M ℓ.2) g ω

theorem unit_mul_star (q : SU2) : (q : ℍr) * star (q : ℍr) = 1 := by
  have h : ‖(q : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, h]
  simp

theorem star_mul_unit (q : SU2) : star (q : ℍr) * (q : ℍr) = 1 := by
  have h : ‖(q : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  rw [Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, h]
  simp

theorem coe_inv_su2 (q : SU2) : ((q⁻¹ : SU2) : ℍr) = star (q : ℍr) := by
  rw [Metric.unitSphere.coe_inv]
  exact inv_eq_of_mul_eq_one_right (unit_mul_star q)

/-- telescoping of a gauge-transformed path -/
theorem tele (u : ℕ → ℍr) (g : ℕ → SU2) (n : ℕ) :
    ((List.range n).map fun k => (g k : ℍr) * u k * star (g (k + 1) : ℍr)).prod
      = (g 0 : ℍr) * ((List.range n).map u).prod * star (g n : ℍr) := by
  induction n with
  | zero => simp [unit_mul_star]
  | succ n ih =>
    rw [List.range_succ, List.map_append, List.map_append, List.prod_append, List.prod_append, ih]
    simp only [List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, mul_one]
    have h := star_mul_unit (g n)
    calc (g 0 : ℍr) * ((List.range n).map u).prod * star (g n : ℍr)
          * ((g n : ℍr) * u n * star (g (n + 1) : ℍr))
        = (g 0 : ℍr) * ((List.range n).map u).prod * (star (g n : ℍr) * (g n : ℍr))
          * u n * star (g (n + 1) : ℍr) := by noncomm_ring
      _ = (g 0 : ℍr) * (((List.range n).map u).prod * u n) * star (g (n + 1) : ℍr) := by
          rw [h, mul_one]; noncomm_ring

theorem re_conj (q : SU2) (X : ℍr) : ((q : ℍr) * X * star (q : ℍr)).re = X.re := by
  have h1 : ((q : ℍr) * X * star (q : ℍr)).re = (X * star (q : ℍr) * (q : ℍr)).re := by
    rw [Quaternion.re_mul, Quaternion.re_mul]
    simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul]
    ring
  rw [h1, mul_assoc, star_mul_unit, mul_one]

/-- **The Polyakov loop is gauge invariant.** -/
theorem polyLoop_gauge (b : ZMod N × ZMod N) (t : ZMod M) (g : Site N M → SU2)
    (ω : Link N M → SU2) : polyLoop N M b t (gAct N M g ω) = polyLoop N M b t ω := by
  unfold polyLoop
  set gk : ℕ → SU2 := fun k => g (b, ((k : ZMod M), t))
  have hlink : ∀ k : ℕ, (((gAct N M g ω) ((b, ((k : ZMod M), t)), 2) : SU2) : ℍr)
      = (gk k : ℍr) * ((ω ((b, ((k : ZMod M), t)), 2) : SU2) : ℍr) * star (gk (k + 1) : ℍr) := by
    intro k
    have hs : ((b, ((k : ZMod M), t)) : Site N M) + ev N M 2 = (b, (((k + 1 : ℕ) : ZMod M), t)) := by
      simp [ev]
    show ((g (b, ((k : ZMod M), t)) * ω ((b, ((k : ZMod M), t)), 2)
      * (g (((b, ((k : ZMod M), t)) : Site N M) + ev N M 2))⁻¹ : SU2) : ℍr) = _
    rw [hs, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, coe_inv_su2]
  rw [List.map_congr_left (fun k _ => hlink k), tele]
  have hM : gk M = gk 0 := by
    show g (b, (((M : ℕ) : ZMod M), t)) = g (b, (((0 : ℕ) : ZMod M), t))
    rw [ZMod.natCast_self, Nat.cast_zero]
  rw [hM, re_conj]

end PolyakovT

#print axioms PolyakovT.polyLoop_gauge
