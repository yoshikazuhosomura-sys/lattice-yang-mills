import PolyT.LinkRPV3

/-!
# Reflection positivity through the link mid-planes: assembly

`PolyakovT.link_rp` (`M` even, `M ≥ 4`, `β ≥ 0`): for `F` bounded, measurable, gauge invariant, and
depending only on the crossing links and the positive-side links `posPL`,
`0 ≤ ∫ F(ThP ω) F(ω) wE β 1 (ω) dHaar`, with `ThP` the reflection `x₄ ↦ −1 − x₄`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem val_t1 (t : ZMod M) (h : t.val + 1 ≠ M) : (t + 1).val = t.val + 1 := by
  rw [val_add_one_eq M, if_neg h]

theorem pos_not_cr (hM : M % 2 = 0) (ℓ : Link N M) (hp : posPL N M ℓ) : ¬ crP N M ℓ := by
  obtain ⟨y, d⟩ := ℓ
  rintro ⟨hd, hc⟩
  simp only at hd hc
  have hlt := ZMod.val_lt y.2.2
  rcases hp with ⟨hd', _⟩ | ⟨_, hv⟩
  · exact hd' hd
  · have hv' : y.2.2.val + 2 ≤ M / 2 := hv
    have h1 := val_t1 M y.2.2 (by omega)
    rcases hc with e | e
    · rw [e, ZMod.val_zero] at h1; omega
    · rw [e, halfPt, ZMod.val_cast_of_lt (by omega)] at h1; omega

theorem time_thP_val (y : Site N M) :
    (rP N M (y + ev N M 3)).2.2.val = M - 1 - (y.2.2 + 1).val := by
  rw [time_rP, time_add_e4, val_neg_one_sub]

theorem pos_refl_not (hM : M % 2 = 0) (ℓ : Link N M) (hp : posPL N M ℓ) :
    ¬ posPL N M (thP N M ℓ) := by
  obtain ⟨y, d⟩ := ℓ
  have hlt := ZMod.val_lt y.2.2
  by_cases hd : d = 3
  · subst hd
    have hv : y.2.2.val + 2 ≤ M / 2 := by
      rcases hp with ⟨h, _⟩ | ⟨_, hv⟩
      · exact absurd rfl h
      · exact hv
    have h1 := val_t1 M y.2.2 (by omega)
    have hv' := time_thP_val N M y
    rw [h1] at hv'
    rw [show thP N M (y, 3) = (rP N M (y + ev N M 3), 3) by simp [thP]]
    unfold posPL
    rintro (⟨h, _⟩ | ⟨_, h⟩)
    · exact h rfl
    · have h' : (rP N M (y + ev N M 3)).2.2.val + 2 ≤ M / 2 := h
      omega
  · have hv : y.2.2.val + 1 ≤ M / 2 := by
      rcases hp with ⟨_, hv⟩ | ⟨h, _⟩
      · exact hv
      · exact absurd h hd
    have hv' : (rP N M y).2.2.val = M - 1 - y.2.2.val := by rw [time_rP, val_neg_one_sub]
    rw [show thP N M (y, d) = (rP N M y, d) by simp [thP, hd]]
    unfold posPL
    rintro (⟨_, h⟩ | ⟨h, _⟩)
    · have h' : (rP N M y).2.2.val + 1 ≤ M / 2 := h
      omega
    · exact hd h

theorem neg_refl_pos (hM : M % 2 = 0) (ℓ : Link N M) (hc : ¬ crP N M ℓ) (hp : ¬ posPL N M ℓ) :
    posPL N M (thP N M ℓ) := by
  obtain ⟨y, d⟩ := ℓ
  have hlt := ZMod.val_lt y.2.2
  by_cases hd : d = 3
  · subst hd
    have hv1 := val_add_one_eq M y.2.2
    have hn0 : ¬ (y.2.2 + 1 = 0) := fun e => hc ⟨rfl, Or.inl e⟩
    have hnh : ¬ (y.2.2 + 1 = halfPt M) := fun e => hc ⟨rfl, Or.inr e⟩
    have hm : y.2.2.val + 1 ≠ M := by
      intro hm; rw [if_pos hm] at hv1; exact hn0 ((ZMod.val_eq_zero _).1 hv1)
    rw [if_neg hm] at hv1
    have hh : y.2.2.val + 1 ≠ M / 2 := by
      intro e; apply hnh; apply ZMod.val_injective
      rw [hv1, halfPt, ZMod.val_cast_of_lt (by omega)]; exact e
    have hnp : ¬ (y.2.2.val + 2 ≤ M / 2) := fun h => hp (Or.inr ⟨rfl, h⟩)
    have hv' := time_thP_val N M y
    rw [hv1] at hv'
    rw [show thP N M (y, 3) = (rP N M (y + ev N M 3), 3) by simp [thP]]
    unfold posPL
    right
    refine ⟨rfl, ?_⟩
    show (rP N M (y + ev N M 3)).2.2.val + 2 ≤ M / 2
    omega
  · have hnp : ¬ (y.2.2.val + 1 ≤ M / 2) := fun h => hp (Or.inl ⟨hd, h⟩)
    have hv' : (rP N M y).2.2.val = M - 1 - y.2.2.val := by rw [time_rP, val_neg_one_sub]
    rw [show thP N M (y, d) = (rP N M y, d) by simp [thP, hd]]
    unfold posPL
    left
    refine ⟨hd, ?_⟩
    show (rP N M y).2.2.val + 1 ≤ M / 2
    omega

theorem posLink_pos (hM : M % 2 = 0) (hM4 : 4 ≤ M) (B : Plaq N M) (hB : crPl N M B) :
    posPL N M (posLink N M B) := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have hlt := ZMod.val_lt x.2.2
  have hν : ν = 3 := hB.1
  have hB2 : x.2.2.val + 1 = M / 2 ∨ x.2.2.val + 1 = M := hB.2
  subst hν
  have hμ3 : μ ≠ 3 := fin_ne_three μ 3 hμν
  by_cases h0 : x.2.2 + 1 = 0
  · rw [show posLink N M (x, ⟨(μ, 3), hμν⟩) = (x + ev N M 3, μ) by simp [posLink, h0]]
    left
    refine ⟨hμ3, ?_⟩
    show (x + ev N M 3).2.2.val + 1 ≤ M / 2
    rw [time_add_e4, h0, ZMod.val_zero]
    omega
  · rw [show posLink N M (x, ⟨(μ, 3), hμν⟩) = (x, μ) by simp [posLink, h0]]
    left
    refine ⟨hμ3, ?_⟩
    show x.2.2.val + 1 ≤ M / 2
    have hv1 := val_add_one_eq M x.2.2
    rcases hB2 with e | e
    · omega
    · exfalso; rw [if_pos e] at hv1; exact h0 ((ZMod.val_eq_zero _).1 hv1)

theorem hol_eq_pos (ω ω' : Link N M → SU2) (h : ∀ ℓ, posPL N M ℓ → ω ℓ = ω' ℓ) (B : Plaq N M)
    (hB : cP N M B ≠ 0) : hol N M ω B = hol N M ω' B := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have hμ3 : μ ≠ 3 := fin_ne_three μ ν hμν
  have hlt := ZMod.val_lt x.2.2
  simp only [hol, l1, l2, l3, l4]
  by_cases hν : ν = 3
  · subst hν
    have hv : x.2.2.val + 2 ≤ M / 2 := by
      by_contra hc; apply hB; simp [cP, hc]
    have h1 := val_t1 M x.2.2 (by omega)
    have p1 : posPL N M (x, μ) := Or.inl ⟨hμ3, by simp only; omega⟩
    have p2 : posPL N M (x + ev N M μ, 3) :=
      Or.inr ⟨rfl, by simp only; rw [time_add_ev N M x μ hμ3]; exact hv⟩
    have p3 : posPL N M (x + ev N M 3, μ) :=
      Or.inl ⟨hμ3, by simp only; rw [time_add_e4, h1]; omega⟩
    have p4 : posPL N M (x, 3) := Or.inr ⟨rfl, hv⟩
    rw [h _ p1, h _ p2, h _ p3, h _ p4]
  · have hv : x.2.2.val + 1 ≤ M / 2 := by
      by_contra hc; apply hB; simp [cP, hν, hc]
    have key : ∀ (z : Site N M) (d : Fin 4), d ≠ 3 → z.2.2 = x.2.2 → posPL N M (z, d) := by
      intro z d hd hz
      exact Or.inl ⟨hd, by simp only; rw [hz]; exact hv⟩
    rw [h _ (key x μ hμ3 rfl), h _ (key _ ν hν (time_add_ev N M x μ hμ3)),
      h _ (key _ μ hμ3 (time_add_ev N M x ν hν)), h _ (key x ν hν rfl)]

theorem AP_dep (β : ℝ) (ω ω' : Link N M → SU2) (h : ∀ ℓ, posPL N M ℓ → ω ℓ = ω' ℓ) :
    AP N M β ω = AP N M β ω' := by
  unfold AP SB
  congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  by_cases hB : cP N M B = 0
  · simp [hB]
  · rw [hol_eq_pos N M ω ω' h B hB]

/-- **Link mid-plane reflection positivity.** -/
theorem link_rp (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (F : (Link N M → SU2) → ℝ) (hFm : Measurable F) (C : ℝ) (hFC : ∀ ω, |F ω| ≤ C)
    (hFg : ∀ g ω, F (gAct N M g ω) = F ω)
    (hFd : ∀ ω ω', (∀ ℓ, crP N M ℓ ∨ posPL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω') :
    0 ≤ ∫ ω, F (ThP N M ω) * F ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M) := by
  have : Nonempty SU2 := ⟨1⟩
  set s := GroupGaugeFix.setOne (crP N M) (G := SU2) with hs
  set H : (Link N M → SU2) → ℝ := fun ω => F (ThP N M ω) * F ω * wE N M β (fun _ => 1) ω with hHdef
  have hHm : Measurable H :=
    ((hFm.comp (ThP_mp N M).measurable).mul hFm).mul (continuous_wE N M β _).measurable
  have hinv : ∀ g ω, H (gAct N M g ω) = H ω := by
    intro g ω
    simp only [hHdef]
    rw [gaugeInv_comp_ThP N M F hFg, hFg, wE_gauge]
  have hfix := integral_fix_crossing N M hM hM4 H hHm hinv
  set K := Real.exp (|β| * ∑ B, |cP N M B * zt N M true false B|)
  set gP : (Link N M → SU2) → ℝ := fun ω => F (s ω) * AP N M β (s ω) with hgP
  let e := Fintype.equivFin (Plaq N M × Fin 4)
  set φF : (Link N M → SU2) → Fin (Fintype.card (Plaq N M × Fin 4)) → ℝ :=
    fun ω i => φP N M ω (e.symm i) with hφF
  have hsum : ∀ ω ω' : Link N M → SU2, ∑ i, φF ω i * φF ω' i = ∑ j, φP N M ω j * φP N M ω' j :=
    fun ω ω' => Equiv.sum_comp e.symm (fun j => φP N M ω j * φP N M ω' j)
  have hpt : ∀ ω, H (s ω) = gP ω * gP (LinkReflection.linkRefl (thP N M) (sgP N M) ω)
      * Real.exp (β * ∑ i, φF ω i * φF (LinkReflection.linkRefl (thP N M) (sgP N M) ω) i) := by
    intro ω
    rw [show LinkReflection.linkRefl (thP N M) (sgP N M) ω = ThQ N M ω from rfl]
    have h1 : ThP N M (s ω) = s (ThQ N M ω) := setOne_ThP N M hM ω
    have h2 := wE_split N M hM β (s ω)
    have h3 := cross_term N M hM ω
    simp only [hHdef, hgP]
    rw [hsum, h2, h1, h3]
    show _ = F (s ω) * AP N M β (s ω) * (F (s (ThQ N M ω)) * AP N M β (s (ThQ N M ω))) * _
    ring
  show 0 ≤ ∫ ω, H ω ∂(haarCfg N M)
  rw [hfix, integral_congr_ae (Filter.Eventually.of_forall hpt)]
  have hsm : Measurable s := GroupGaugeFix.measurable_setOne (crP N M)
  have hdeps : ∀ ω ω' : Link N M → SU2, (∀ ℓ, crP N M ℓ ∨ posPL N M ℓ → ω ℓ = ω' ℓ) →
      ∀ ℓ, crP N M ℓ ∨ posPL N M ℓ → s ω ℓ = s ω' ℓ := by
    intro ω ω' h ℓ hℓ
    simp only [hs, GroupGaugeFix.setOne]
    split_ifs with hc
    · rfl
    · exact h ℓ hℓ
  unfold haarCfg
  refine LinkReflection.rp_kernel haarSU2 (thP N M) (sgP N M) (crP N M) (posPL N M)
    (thP_invol N M) (fun ℓ hℓ => ⟨thP_fix N M hM ℓ hℓ, fun x => by simp [sgP, hℓ]⟩)
    (fun ℓ hp hc => pos_not_cr N M hM ℓ hp hc) (pos_refl_not N M hM) (neg_refl_pos N M hM)
    (fun ℓ => by
      unfold sgP
      split_ifs
      · exact MeasurePreserving.id _
      · exact sgL_mp N M ℓ)
    gP ((hFm.comp hsm).mul ((continuous_exp_SB N M β _).measurable.comp hsm)) (C * K)
    (fun ω => by
      show |F (s ω) * AP N M β (s ω)| ≤ C * K
      rw [abs_mul]
      exact mul_le_mul (hFC _) (exp_SB_le N M β _ _) (abs_nonneg _)
        ((abs_nonneg _).trans (hFC ω)))
    (fun ω ω' h => by
      show F (s ω) * AP N M β (s ω) = F (s ω') * AP N M β (s ω')
      rw [hFd _ _ (hdeps ω ω' h), AP_dep N M β (s ω) (s ω') (fun ℓ hℓ => hdeps ω ω' h ℓ (Or.inr hℓ))])
    φF
    (fun i => by
      show Measurable fun ω => φP N M ω (e.symm i)
      unfold φP
      split_ifs
      · have hc : Continuous fun ω : Link N M → SU2 =>
            comp (e.symm i).2 ((ω (posLink N M (e.symm i).1) : SU2) : ℍr) :=
          (continuous_comp _).comp (continuous_subtype_val.comp (continuous_apply _))
        exact hc.measurable
      · exact measurable_const)
    1
    (fun ω i => by
      show |φP N M ω (e.symm i)| ≤ 1
      unfold φP
      split_ifs
      · exact abs_comp_le _ _
      · simp)
    (fun ω ω' h => by
      funext i
      show φP N M ω (e.symm i) = φP N M ω' (e.symm i)
      unfold φP
      split_ifs with hj
      · rw [h _ (Or.inr (posLink_pos N M hM hM4 _ hj))]
      · rfl)
    β hβ

end PolyakovT

#print axioms PolyakovT.link_rp
