import PolyT.TransV3
import PolyT.ChordV1

/-!
# Polyakov loop pairs at every time separation (Wilson SU(2), `(ℤ/N)² × (ℤ/M)²`)

`⟨·⟩₀` : the SU(2) Wilson measure on `(ℤ/N)² × (ℤ/M)²` with background twist `n₁₂ = 1` and no `(3,4)`
twist (weight `wE β 1`, `PolyakovT.wE_one`), normalised by `Z₀ = ZW β true false`
(`PolyakovT.integral_wE_one`).  `P_b(t)` : `HalfSplit.polyLoop b t`, the real part of the ordered
product of the `M` direction-3 links at transverse position `b`, time `x₄ = t`.
`polyExp β b b' s t = ⟨P_b(s) P_{b'}(t)⟩₀`.  `t_N(β) = tanh(N²|β|)`.

* `half_pair_tanh` (`M` even, every real `β`) : `|⟨P_b(0) P_{b'}(M/2)⟩₀| ≤ 2 t_N(β)^{M·M/2}`.
* `diag_chord` (`M % 4 = 0`, every real `β`, `4k ≤ M`) : with `G(T) = ⟨P_b(0)P_b(T)⟩₀`,
  `G(2k)^{M/4} ≤ G(0)^{M/4−k} · G(M/2)^k` (the integer-power form of
  `G(T) ≤ G(0)^{1−2T/M} G(M/2)^{2T/M}`, `T = 2k ≤ M/2`).
* `polyakov_pair_all` (`M % 4 = 0`, every real `β`, every `T ≤ M`, every `b, b'`) :
  `|⟨P_b(0) P_{b'}(T)⟩₀| ≤ 2 t_N(β)^{M·min(T, M−T)}`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- the normalised expectation `⟨P_b(s) P_{b'}(t)⟩₀` -/
noncomputable def polyExp (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) : ℝ :=
  corr N M β b b' s t / ZW N M β true false

theorem tanh_nonneg' (x : ℝ) (hx : 0 ≤ x) : 0 ≤ Real.tanh x := by
  rw [Real.tanh_eq_sinh_div_cosh]
  exact div_nonneg (Real.sinh_nonneg_iff.mpr hx) (Real.cosh_pos x).le

theorem tN_nonneg (β : ℝ) : 0 ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) :=
  tanh_nonneg' _ (by positivity)

/-- `(⟨P_b(0)P_{b'}(M/2)⟩₀)² ≤ 4 θ ≤ 4 t^{M²}` -/
theorem half_sq (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) :
    (polyExp N M β b b' 0 (halfPt M)) ^ 2 ≤ 4 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by
  have hθ0 := TwistBlocks.theta_nonneg N M hM β
  have hθ1 : TwistBlocks.thetaM N M β ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by
    unfold TwistBlocks.thetaM
    exact twisted_vortex_bound N M β true
  have hZ := ZW_pos N M β true false
  have hh := polyakov_pair_theta N M hM β b b'
  have h1 : |corr N M β b b' 0 (halfPt M)| / ZW N M β true false
      ≤ 2 * Real.sqrt (TwistBlocks.thetaM N M β) :=
    hh.trans (div_le_self (mul_nonneg zero_le_two (Real.sqrt_nonneg _)) (by linarith))
  have e : (polyExp N M β b b' 0 (halfPt M)) ^ 2
      = (|corr N M β b b' 0 (halfPt M)| / ZW N M β true false) ^ 2 := by
    unfold polyExp
    rw [div_pow, div_pow, sq_abs]
  rw [e]
  calc (|corr N M β b b' 0 (halfPt M)| / ZW N M β true false) ^ 2
      ≤ (2 * Real.sqrt (TwistBlocks.thetaM N M β)) ^ 2 :=
        pow_le_pow_left₀ (div_nonneg (abs_nonneg _) hZ.le) h1 2
    _ = 4 * TwistBlocks.thetaM N M β := by rw [mul_pow, Real.sq_sqrt hθ0]; ring
    _ ≤ 4 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by linarith

/-- **(a)** `M` even, every real `β`: `|⟨P_b(0) P_{b'}(M/2)⟩₀| ≤ 2 tanh(N²|β|)^{M·M/2}` -/
theorem half_pair_tanh (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) :
    |polyExp N M β b b' 0 (halfPt M)| ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * M / 2) := by
  have hd : 2 ∣ M * M := Dvd.dvd.mul_right (Nat.dvd_of_mod_eq_zero hM) M
  have e : 2 * (M * M / 2) = M ^ 2 := by rw [Nat.mul_div_cancel' hd]; ring
  have ht := tN_nonneg N β
  have h := half_sq N M hM β b b'
  rw [← e, pow_mul', ← sq_abs] at h
  have h2 : |polyExp N M β b b' 0 (halfPt M)| ^ 2
      ≤ (2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * M / 2)) ^ 2 := by
    calc |polyExp N M β b b' 0 (halfPt M)| ^ 2
        ≤ 4 * (Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * M / 2)) ^ 2 := h
      _ = (2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * M / 2)) ^ 2 := by ring
  exact (pow_le_pow_iff_left₀ (abs_nonneg _) (mul_nonneg zero_le_two (pow_nonneg ht _))
    two_ne_zero).1 h2

/-- **(b) the chord bound** (`M % 4 = 0`, every real `β`): for `4k ≤ M`,
`Gc(2k)^{M/4} ≤ Gc(0)^{M/4 − k} · Gc(M/2)^k` (unnormalised). -/
theorem diag_chord (hM : M % 4 = 0) (β : ℝ) (b : ZMod N × ZMod N) (k : ℕ) (hk : 4 * k ≤ M) :
    Gc N M β b b (2 * k) ^ (M / 4)
      ≤ Gc N M β b b 0 ^ (M / 4 - k) * Gc N M β b b (M / 2) ^ k := by
  have hM2 : M % 2 = 0 := by omega
  have hc : ∀ j, 1 ≤ j → j + 1 ≤ M / 4 →
      Gc N M β b b (2 * j) ^ 2 ≤ Gc N M β b b (2 * (j - 1)) * Gc N M β b b (2 * (j + 1)) := by
    intro j hj1 hj2
    have h := cs_even N M hM2 β b b (j - 1) (j + 1) (by omega) (by omega)
    rwa [show j - 1 + (j + 1) = 2 * j by omega] at h
  have h := LogChord.chord (fun j => Gc N M β b b (2 * j)) (M / 4)
    (fun j hj => Gc_even_nonneg N M hM2 β b j (by omega)) hc k (by omega)
  simp only [Nat.mul_zero] at h
  rwa [show 2 * (M / 4) = M / 2 by omega] at h

/-- the same, normalised, with `G(0) ≤ 1` used: `G(2k)^{M/4} ≤ G(M/2)^k` -/
theorem diag_chord_norm (hM : M % 4 = 0) (β : ℝ) (b : ZMod N × ZMod N) (k : ℕ) (hk : 4 * k ≤ M) :
    (Gc N M β b b (2 * k) / ZW N M β true false) ^ (M / 4)
      ≤ (Gc N M β b b (M / 2) / ZW N M β true false) ^ k := by
  have hM2 : M % 2 = 0 := by omega
  have hZ := ZW_pos N M β true false
  have hch := diag_chord N M hM β b k hk
  have g0 : 0 ≤ Gc N M β b b 0 := by
    have := Gc_even_nonneg N M hM2 β b 0 (by omega); simpa using this
  have g0le : Gc N M β b b 0 ≤ ZW N M β true false :=
    (le_abs_self _).trans (abs_Gc_le N M β b b 0)
  have gh : 0 ≤ Gc N M β b b (M / 2) := by
    have := Gc_even_nonneg N M hM2 β b (M / 4) (by omega)
    rwa [show 2 * (M / 4) = M / 2 by omega] at this
  have hZm : ZW N M β true false ^ (M / 4 - k) * ZW N M β true false ^ k
      = ZW N M β true false ^ (M / 4) := by
    rw [← pow_add, Nat.sub_add_cancel (by omega)]
  have y0 : (Gc N M β b b 0 / ZW N M β true false) ^ (M / 4 - k) ≤ 1 :=
    pow_le_one₀ (div_nonneg g0 hZ.le) ((div_le_one hZ).2 g0le)
  calc (Gc N M β b b (2 * k) / ZW N M β true false) ^ (M / 4)
      = Gc N M β b b (2 * k) ^ (M / 4) / ZW N M β true false ^ (M / 4) := div_pow _ _ _
    _ ≤ (Gc N M β b b 0 ^ (M / 4 - k) * Gc N M β b b (M / 2) ^ k) / ZW N M β true false ^ (M / 4) :=
        div_le_div_of_nonneg_right hch (pow_pos hZ _).le
    _ = (Gc N M β b b 0 / ZW N M β true false) ^ (M / 4 - k)
          * (Gc N M β b b (M / 2) / ZW N M β true false) ^ k := by
        rw [div_pow, div_pow, div_mul_div_comm, hZm]
    _ ≤ (Gc N M β b b (M / 2) / ZW N M β true false) ^ k :=
        mul_le_of_le_one_left (pow_nonneg (div_nonneg gh hZ.le) _) y0

/-- diagonal even separations: `0 ≤ G(2k) ≤ 2 t^{M·2k}` (`M % 4 = 0`, `4k ≤ M`, every real `β`) -/
theorem diag_even (hM : M % 4 = 0) (β : ℝ) (b : ZMod N × ZMod N) (k : ℕ) (hk : 4 * k ≤ M) :
    0 ≤ Gc N M β b b (2 * k) / ZW N M β true false ∧
    Gc N M β b b (2 * k) / ZW N M β true false
      ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * (2 * k)) := by
  have hM2 : M % 2 = 0 := by omega
  have hZ := ZW_pos N M β true false
  have ht := tN_nonneg N β
  obtain ⟨m, hm⟩ : ∃ m, M = 4 * m := ⟨M / 4, by omega⟩
  have hm4 : M / 4 = m := by omega
  have hm1 : 1 ≤ m := by have := NeZero.ne M; omega
  have hx0 : 0 ≤ Gc N M β b b (2 * k) / ZW N M β true false :=
    div_nonneg (Gc_even_nonneg N M hM2 β b k (by omega)) hZ.le
  refine ⟨hx0, ?_⟩
  have hch := diag_chord_norm N M hM β b k hk
  rw [hm4] at hch
  have hsq := half_sq N M hM2 β b b
  have hhalf : polyExp N M β b b 0 (halfPt M) = Gc N M β b b (M / 2) / ZW N M β true false := rfl
  rw [hhalf] at hsq
  have gh : 0 ≤ Gc N M β b b (M / 2) / ZW N M β true false := by
    have := Gc_even_nonneg N M hM2 β b (M / 4) (by omega)
    rw [show 2 * (M / 4) = M / 2 by omega] at this
    exact div_nonneg this hZ.le
  set x := Gc N M β b b (2 * k) / ZW N M β true false
  set y := Gc N M β b b (M / 2) / ZW N M β true false
  set t := Real.tanh ((N : ℝ) ^ 2 * |β|)
  have hexp : M * (2 * k) * (2 * m) = M ^ 2 * k := by rw [hm]; ring
  have hkm : k ≤ m := by omega
  have h4 : (4 : ℝ) ^ m = 2 ^ (2 * m) := by rw [pow_mul]; norm_num
  have key : x ^ (2 * m) ≤ (2 * t ^ (M * (2 * k))) ^ (2 * m) := by
    calc x ^ (2 * m) = (x ^ m) ^ 2 := by ring
      _ ≤ (y ^ k) ^ 2 := pow_le_pow_left₀ (pow_nonneg hx0 _) hch 2
      _ = (y ^ 2) ^ k := by ring
      _ ≤ (4 * t ^ (M ^ 2)) ^ k := pow_le_pow_left₀ (by positivity) hsq k
      _ = 4 ^ k * t ^ (M ^ 2 * k) := by rw [mul_pow, ← pow_mul]
      _ ≤ 4 ^ m * t ^ (M ^ 2 * k) :=
          mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by norm_num) hkm) (pow_nonneg ht _)
      _ = (2 * t ^ (M * (2 * k))) ^ (2 * m) := by
          rw [mul_pow, ← pow_mul, hexp, h4]
  exact (pow_le_pow_iff_left₀ hx0 (mul_nonneg zero_le_two (pow_nonneg ht _)) (by omega)).1 key

/-- every separation `T ≤ M/2`, every `b, b'` (unnormalised) -/
theorem pair_half_range (hM : M % 4 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ)
    (hT : 2 * T ≤ M) :
    |Gc N M β b b' T| ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * T) * ZW N M β true false := by
  have hM2 : M % 2 = 0 := by omega
  have hZ := ZW_pos N M β true false
  have ht := tN_nonneg N β
  set t := Real.tanh ((N : ℝ) ^ 2 * |β|)
  have dg : ∀ (c : ZMod N × ZMod N) (k : ℕ), 4 * k ≤ M →
      0 ≤ Gc N M β c c (2 * k) ∧ Gc N M β c c (2 * k) ≤ 2 * t ^ (M * (2 * k)) * ZW N M β true false := by
    intro c k hk
    obtain ⟨h0, h1⟩ := diag_even N M hM β c k hk
    have h0' := mul_nonneg h0 hZ.le
    rw [div_mul_cancel₀ _ hZ.ne'] at h0'
    exact ⟨h0', (div_le_iff₀ hZ).1 h1⟩
  have hP : ∀ j : ℕ, 0 ≤ 2 * t ^ j * ZW N M β true false :=
    fun j => mul_nonneg (mul_nonneg zero_le_two (pow_nonneg ht _)) hZ.le
  have fin : Gc N M β b b' T ^ 2 ≤ (2 * t ^ (M * T) * ZW N M β true false) ^ 2 →
      |Gc N M β b b' T| ≤ 2 * t ^ (M * T) * ZW N M β true false := by
    intro h
    rw [← sq_abs] at h
    exact (pow_le_pow_iff_left₀ (abs_nonneg _) (hP _) two_ne_zero).1 h
  apply fin
  rcases Nat.even_or_odd T with ⟨k, hk⟩ | ⟨k, hk⟩
  · -- T = k + k
    have h := cs_even N M hM2 β b b' k k (by omega) (by omega)
    rw [← hk, show 2 * k = T by omega] at h
    obtain ⟨a0, a1⟩ := dg b k (by omega)
    obtain ⟨b0, b1⟩ := dg b' k (by omega)
    rw [show 2 * k = T by omega] at a0 a1 b0 b1
    calc Gc N M β b b' T ^ 2 ≤ Gc N M β b b T * Gc N M β b' b' T := h
      _ ≤ (2 * t ^ (M * T) * ZW N M β true false) * (2 * t ^ (M * T) * ZW N M β true false) :=
          mul_le_mul a1 b1 b0 (hP _)
      _ = (2 * t ^ (M * T) * ZW N M β true false) ^ 2 := by ring
  · -- T = 2k + 1, and 2(k+1) ≤ M/2 since M/2 is even
    subst hk
    have h := cs_even N M hM2 β b b' k (k + 1) (by omega) (by omega)
    rw [show k + (k + 1) = 2 * k + 1 by omega] at h
    obtain ⟨a0, a1⟩ := dg b k (by omega)
    obtain ⟨b0, b1⟩ := dg b' (k + 1) (by omega)
    have hac : M * (2 * k) + M * (2 * (k + 1)) = M * (2 * k + 1) + M * (2 * k + 1) := by ring
    calc Gc N M β b b' (2 * k + 1) ^ 2 ≤ Gc N M β b b (2 * k) * Gc N M β b' b' (2 * (k + 1)) := h
      _ ≤ (2 * t ^ (M * (2 * k)) * ZW N M β true false)
            * (2 * t ^ (M * (2 * (k + 1))) * ZW N M β true false) :=
          mul_le_mul a1 b1 b0 (hP _)
      _ = 4 * (t ^ (M * (2 * k)) * t ^ (M * (2 * (k + 1)))) * ZW N M β true false ^ 2 := by ring
      _ = 4 * t ^ (M * (2 * k + 1) + M * (2 * k + 1)) * ZW N M β true false ^ 2 := by
          rw [← pow_add, hac]
      _ = (2 * t ^ (M * (2 * k + 1)) * ZW N M β true false) ^ 2 := by rw [pow_add]; ring

/-- **(b) every separation** (`M % 4 = 0`, every real `β`, every `T ≤ M`, every `b, b'`):
`|⟨P_b(0) P_{b'}(T)⟩₀| ≤ 2 tanh(N²|β|)^{M·min(T, M−T)}`. -/
theorem polyakov_pair_all (hM : M % 4 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ) (hT : T ≤ M) :
    |polyExp N M β b b' 0 (T : ZMod M)|
      ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * min T (M - T)) := by
  have hZ := ZW_pos N M β true false
  have e : polyExp N M β b b' 0 (T : ZMod M) = Gc N M β b b' T / ZW N M β true false := rfl
  rw [e, abs_div, abs_of_pos hZ, div_le_iff₀ hZ]
  by_cases h2 : 2 * T ≤ M
  · rw [min_eq_left (by omega)]
    exact pair_half_range N M hM β b b' T h2
  · rw [min_eq_right (by omega)]
    have hs := Gc_swap N M β b b' (M - T) (by omega)
    rw [show M - (M - T) = T by omega] at hs
    rw [hs]
    exact pair_half_range N M hM β b' b (M - T) (by omega)

end PolyakovT

#print axioms PolyakovT.half_pair_tanh
#print axioms PolyakovT.diag_chord
#print axioms PolyakovT.diag_even
#print axioms PolyakovT.polyakov_pair_all
