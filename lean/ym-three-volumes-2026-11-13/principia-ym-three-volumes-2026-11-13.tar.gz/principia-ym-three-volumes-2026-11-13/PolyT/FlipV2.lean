import PolyT.AllMV2

/-!
# `β ↦ −β` for even `N` and `M` (the staggered sign field)

`stag` : the `ℤ₂` link field `s_1 = 1`, `s_2 = (−1)^{x₁}`, `s_3 = (−1)^{x₁+x₂}`, `s_4 = (−1)^{x₁+x₂+x₃}`
(coordinates as `ZMod` values).  For `N`, `M` even every plaquette has `χ_B(stag) = −1`
(`chi_stag`), so `ω ↦ stag • ω` maps the weight with `β` to the weight with `−β` and preserves the
Haar product; each Polyakov loop gets the same sign `(−1)^{M(M−1)/2}`, and the pair is unchanged.
* `polyExp_neg` : `⟨P_b(s) P_{b'}(t)⟩₀` at `−β` equals the one at `β` (`N`, `M` even).
* `polyakov_pair_evenNM` : `N`, `M` even, `M ≥ 4`, **every real `β`**, every `T ≤ M`:
  `|⟨P_b(0) P_{b'}(T)⟩₀| ≤ 2 tanh(N²|β|)^{M·min(T, M−T)}`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit CoveringInequality

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- the parity sign of a `ZMod` value -/
def par {n : ℕ} (a : ZMod n) : ℤˣ := (-1) ^ a.val

/-- the same as a real number -/
def parR {n : ℕ} (a : ZMod n) : ℝ := (-1) ^ a.val

theorem sgn_par {n : ℕ} (a : ZMod n) : sgn (par a) = parR a := by
  simp [sgn, par, parR]

theorem parR_sq {n : ℕ} (a : ZMod n) : parR a ^ 2 = 1 := by
  unfold parR; rw [← pow_mul, mul_comm, pow_mul]; simp

theorem parR_pow4 {n : ℕ} (a : ZMod n) : parR a ^ 4 = 1 := by
  rw [show 4 = 2 * 2 by rfl, pow_mul, parR_sq, one_pow]

theorem parR_add_one {n : ℕ} [NeZero n] (hn : n % 2 = 0) (a : ZMod n) : parR (a + 1) = - parR a := by
  unfold parR
  rw [val_add_one_eq n a]
  split_ifs with h
  · obtain ⟨k, hk⟩ : ∃ k, a.val = 2 * k + 1 := ⟨a.val / 2, by omega⟩
    rw [hk, pow_succ, pow_mul]; simp
  · rw [pow_succ]; ring

/-- the staggered sign field -/
def stag (ℓ : Link N M) : ℤˣ :=
  if ℓ.2 = 0 then 1 else if ℓ.2 = 1 then par ℓ.1.1.1
  else if ℓ.2 = 2 then par ℓ.1.1.1 * par ℓ.1.1.2 else par ℓ.1.1.1 * par ℓ.1.1.2 * par ℓ.1.2.1

theorem sgn_stag (x : Site N M) (d : Fin 4) :
    sgn (stag N M (x, d)) = if d = 0 then 1 else if d = 1 then parR x.1.1
      else if d = 2 then parR x.1.1 * parR x.1.2 else parR x.1.1 * parR x.1.2 * parR x.2.1 := by
  unfold stag
  split_ifs <;> first | (simp only [sgn_mul', sgn_par]; done) | simp [sgn]

theorem chi_stag (hN : N % 2 = 0) (hM : M % 2 = 0) (B : Plaq N M) : chiB N M B (stag N M) = -1 := by
  obtain ⟨⟨⟨x1, x2⟩, ⟨x3, x4⟩⟩, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  unfold chiB
  simp only [l1, l2, l3, l4, sgn_stag]
  have a1 := parR_add_one hN x1
  have a2 := parR_add_one hN x2
  have a3 := parR_add_one hM x3
  have q1 := parR_sq x1
  have q2 := parR_sq x2
  have q3 := parR_sq x3
  fin_cases μ <;> fin_cases ν <;> simp at hμν <;>
    simp [ev, a1, a2, a3] <;> (try ring_nf) <;> simp [q1, q2, q3, parR_pow4]

theorem hol_stag (hN : N % 2 = 0) (hM : M % 2 = 0) (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (stag N M • ω) B).re = - (hol N M ω B).re := by
  rw [hol_smul, chi_stag N M hN hM]; ring

theorem wE_stag (hN : N % 2 = 0) (hM : M % 2 = 0) (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) (stag N M • ω) = wE N M (-β) (fun _ => 1) ω := by
  rw [wE_one, wE_one]
  congr 1
  simp only [hol_stag N M hN hM]
  rw [show ∑ B, zt N M true false B * -(hol N M ω B).re = -∑ B, zt N M true false B * (hol N M ω B).re
    by rw [← Finset.sum_neg_distrib]; exact Finset.sum_congr rfl fun B _ => by ring]
  ring

theorem prod_const_smul (l : List ℕ) (c : ℝ) (u : ℕ → ℍr) :
    (l.map fun k => c • u k).prod = c ^ l.length • (l.map u).prod := by
  induction l with
  | nil => simp
  | cons a l ih =>
    rw [List.map_cons, List.prod_cons, ih, smul_mul_smul_comm, List.map_cons, List.prod_cons,
      List.length_cons, pow_succ']

/-- every Polyakov loop is unchanged (`M` even) -/
theorem polyLoop_stag (hM : M % 2 = 0) (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) :
    polyLoop N M b t (stag N M • ω) = polyLoop N M b t ω := by
  have hs : ∀ k : ℕ, (((stag N M • ω) ((b, ((k : ZMod M), t)), 2) : SU2) : ℍr)
      = (parR b.1 * parR b.2) • ((ω ((b, ((k : ZMod M), t)), 2) : SU2) : ℍr) := by
    intro k
    rw [coe_smul_apply, Quaternion.coe_mul_eq_smul, sgn_stag]
    simp
  unfold polyLoop
  rw [List.map_congr_left (fun k _ => hs k), prod_const_smul, List.length_range, Quaternion.re_smul,
    smul_eq_mul]
  have h1 : (parR b.1 * parR b.2) ^ M = 1 := by
    rw [show M = 2 * (M / 2) by omega, pow_mul, mul_pow, parR_sq, parR_sq]; simp
  rw [h1, one_mul]

theorem corr_neg (hN : N % 2 = 0) (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) (s t : ZMod M) :
    corr N M (-β) b b' s t = corr N M β b b' s t := by
  unfold corr
  rw [← haarCfg_inv N M (stag N M)]
  refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
  simp only
  rw [polyLoop_stag N M hM, polyLoop_stag N M hM, wE_stag N M hN hM, neg_neg]

theorem ZW_neg (hN : N % 2 = 0) (hM : M % 2 = 0) (β : ℝ) :
    ZW N M (-β) true false = ZW N M β true false := by
  rw [← integral_wE_one, ← integral_wE_one, ← haarCfg_inv N M (stag N M)]
  refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
  simp only
  rw [wE_stag N M hN hM, neg_neg]

theorem polyExp_neg (hN : N % 2 = 0) (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N)
    (s t : ZMod M) : polyExp N M (-β) b b' s t = polyExp N M β b b' s t := by
  unfold polyExp
  rw [corr_neg N M hN hM, ZW_neg N M hN hM]

/-- **`N`, `M` even, `M ≥ 4`, every real `β`, every `T ≤ M`, every `b, b'`.** -/
theorem polyakov_pair_evenNM (hN : N % 2 = 0) (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ)
    (b b' : ZMod N × ZMod N) (T : ℕ) (hT : T ≤ M) :
    |polyExp N M β b b' 0 (T : ZMod M)|
      ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * min T (M - T)) := by
  rcases le_or_gt 0 β with hβ | hβ
  · exact polyakov_pair_evenM N M hM hM4 β hβ b b' T hT
  · have h := polyakov_pair_evenM N M hM hM4 (-β) (by linarith) b b' T hT
    rwa [polyExp_neg N M hN hM, abs_neg] at h

end PolyakovT

#print axioms PolyakovT.chi_stag
#print axioms PolyakovT.polyakov_pair_evenNM
