import PolyT.LinkRPMainV3

/-!
# Odd separations: Cauchy–Schwarz through the link mid-planes (`M` even, `M ≥ 4`, `β ≥ 0`)

* `Gc_symm` : `G_{bb'}(T) = G_{b'b}(T)` (site reflection, every real `β`).
* `cs_odd` : `G_{bb'}(u+v+1)² ≤ G_{bb}(2u+1) · G_{b'b'}(2v+1)` for `u + 1, v + 1 ≤ M/2`;
  `Gc_odd_nonneg` : `G_{bb}(2u+1) ≥ 0`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem wE_Th (hM : M % 2 = 0) (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) (Th N M ω) = wE N M β (fun _ => 1) ω := by
  rw [w_split N M hM, w_split N M hM, Th_Th, mul_comm]

theorem Gc_symm (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) (T : ℕ) (hT : T ≤ M) :
    Gc N M β b b' T = Gc N M β b' b T := by
  have h := integral_Th N M _ (measurable_corrInt N M β b b' 0 (T : ZMod M))
  simp only [polyLoop_Th, wE_Th N M hM, neg_zero] at h
  rw [← Gc_swap N M β b b' T hT]
  unfold Gc
  rw [Nat.cast_sub hT, ZMod.natCast_self, zero_sub]
  exact h.symm

theorem polyLoop_dep_link (b : ZMod N × ZMod N) (u : ℕ) (hu : u + 1 ≤ M / 2) (ω ω' : Link N M → SU2)
    (h : ∀ ℓ, crP N M ℓ ∨ posPL N M ℓ → ω ℓ = ω' ℓ) :
    polyLoop N M b (u : ZMod M) ω = polyLoop N M b (u : ZMod M) ω' := by
  have hM0 := NeZero.ne M
  have hv : ((u : ZMod M)).val = u := ZMod.val_cast_of_lt (by omega)
  unfold polyLoop
  congr 1
  congr 1
  refine List.map_congr_left fun k _ => ?_
  have hp : posPL N M ((b, ((k : ZMod M), (u : ZMod M))), 2) := by
    refine Or.inl ⟨(show (2 : Fin 4) ≠ 3 by decide), ?_⟩
    show ((u : ZMod M)).val + 1 ≤ M / 2
    rw [hv]; exact hu
  rw [h _ (Or.inr hp)]

/-- the quadratic form of the link reflection on two Polyakov loops -/
theorem link_quad (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b b' : ZMod N × ZMod N)
    (u v : ℕ) (hu : u + 1 ≤ M / 2) (hv : v + 1 ≤ M / 2) (t : ℝ) :
    0 ≤ Gc N M β b' b' (2 * v + 1) * (t * t) + 2 * Gc N M β b b' (u + v + 1) * t
      + Gc N M β b b (2 * u + 1) := by
  set F : (Link N M → SU2) → ℝ := fun ω => polyLoop N M b (u : ZMod M) ω
    + t * polyLoop N M b' (v : ZMod M) ω with hF
  have hFm : Measurable F :=
    ((continuous_polyLoop N M b _).add (continuous_const.mul (continuous_polyLoop N M b' _))).measurable
  have hFC : ∀ ω, |F ω| ≤ 1 + |t| * 1 := fun ω => by
    refine (abs_add_le _ _).trans (add_le_add (abs_polyLoop_le N M b _ ω) ?_)
    rw [abs_mul]; exact mul_le_mul_of_nonneg_left (abs_polyLoop_le N M b' _ ω) (abs_nonneg _)
  have hFg : ∀ g ω, F (gAct N M g ω) = F ω := fun g ω => by
    simp only [hF, polyLoop_gauge]
  have hFd : ∀ ω ω', (∀ ℓ, crP N M ℓ ∨ posPL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω' := fun ω ω' h => by
    simp only [hF]
    rw [polyLoop_dep_link N M b u hu ω ω' h, polyLoop_dep_link N M b' v hv ω ω' h]
  have hp := link_rp N M hM hM4 β hβ F hFm _ hFC hFg hFd
  have e : ∀ ω, F (ThP N M ω) * F ω * wE N M β (fun _ => 1) ω
      = (polyLoop N M b (-1 - (u : ZMod M)) ω * polyLoop N M b (u : ZMod M) ω) * wE N M β (fun _ => 1) ω
        + t * ((polyLoop N M b' (-1 - (v : ZMod M)) ω * polyLoop N M b (u : ZMod M) ω) * wE N M β (fun _ => 1) ω)
        + t * ((polyLoop N M b (-1 - (u : ZMod M)) ω * polyLoop N M b' (v : ZMod M) ω) * wE N M β (fun _ => 1) ω)
        + (t * t) * ((polyLoop N M b' (-1 - (v : ZMod M)) ω * polyLoop N M b' (v : ZMod M) ω) * wE N M β (fun _ => 1) ω) :=
    fun ω => by simp only [hF, polyLoop_ThP]; ring
  rw [integral_congr_ae (Filter.Eventually.of_forall e)] at hp
  have i1 := integrable_corrInt N M β b b (-1 - (u : ZMod M)) (u : ZMod M)
  have i2 := (integrable_corrInt N M β b' b (-1 - (v : ZMod M)) (u : ZMod M)).const_mul t
  have i3 := (integrable_corrInt N M β b b' (-1 - (u : ZMod M)) (v : ZMod M)).const_mul t
  have i4 := (integrable_corrInt N M β b' b' (-1 - (v : ZMod M)) (v : ZMod M)).const_mul (t * t)
  rw [integral_add (by exact (i1.add i2).add i3) (by exact i4),
    integral_add (by exact i1.add i2) (by exact i3), integral_add (by exact i1) (by exact i2),
    integral_const_mul, integral_const_mul, integral_const_mul] at hp
  have c1 : ∫ ω, (polyLoop N M b (-1 - (u : ZMod M)) ω * polyLoop N M b (u : ZMod M) ω) * wE N M β (fun _ => 1) ω
      ∂(haarCfg N M) = Gc N M β b b (2 * u + 1) := by
    show corr N M β b b _ _ = _
    rw [corr_zero]; unfold Gc; congr 1; push_cast; ring
  have c2 : ∫ ω, (polyLoop N M b' (-1 - (v : ZMod M)) ω * polyLoop N M b (u : ZMod M) ω) * wE N M β (fun _ => 1) ω
      ∂(haarCfg N M) = Gc N M β b b' (u + v + 1) := by
    show corr N M β b' b _ _ = _
    rw [corr_zero, Gc_symm N M hM β b b' (u + v + 1) (by omega)]; unfold Gc; congr 1; push_cast; ring
  have c3 : ∫ ω, (polyLoop N M b (-1 - (u : ZMod M)) ω * polyLoop N M b' (v : ZMod M) ω) * wE N M β (fun _ => 1) ω
      ∂(haarCfg N M) = Gc N M β b b' (u + v + 1) := by
    show corr N M β b b' _ _ = _
    rw [corr_zero]; unfold Gc; congr 1; push_cast; ring
  have c4 : ∫ ω, (polyLoop N M b' (-1 - (v : ZMod M)) ω * polyLoop N M b' (v : ZMod M) ω) * wE N M β (fun _ => 1) ω
      ∂(haarCfg N M) = Gc N M β b' b' (2 * v + 1) := by
    show corr N M β b' b' _ _ = _
    rw [corr_zero]; unfold Gc; congr 1; push_cast; ring
  rw [c1, c2, c3, c4] at hp
  linarith

/-- **Odd separations** (`M` even, `M ≥ 4`, `β ≥ 0`, `u + 1, v + 1 ≤ M/2`). -/
theorem cs_odd (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b b' : ZMod N × ZMod N)
    (u v : ℕ) (hu : u + 1 ≤ M / 2) (hv : v + 1 ≤ M / 2) :
    Gc N M β b b' (u + v + 1) ^ 2 ≤ Gc N M β b b (2 * u + 1) * Gc N M β b' b' (2 * v + 1) := by
  have hd := discrim_le_zero (link_quad N M hM hM4 β hβ b b' u v hu hv)
  unfold discrim at hd
  nlinarith [hd]

theorem Gc_odd_nonneg (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b : ZMod N × ZMod N)
    (u : ℕ) (hu : u + 1 ≤ M / 2) : 0 ≤ Gc N M β b b (2 * u + 1) := by
  have h := link_quad N M hM hM4 β hβ b b u u hu hu 0
  simpa using h

end PolyakovT

#print axioms PolyakovT.cs_odd
#print axioms PolyakovT.Gc_odd_nonneg
#print axioms PolyakovT.Gc_symm
