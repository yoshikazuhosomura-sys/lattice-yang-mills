import PolyT.OddV3

/-!
# Polyakov loop pairs for every even `M ≥ 4` (`β ≥ 0`)

With the site reflection (even separations, every real `β`) and the link mid-plane reflection
(odd separations, `β ≥ 0`), `k ↦ G(k) = ∫ P_b(0) P_b(k) w₀` is log-convex on `{0, …, M/2}`
(`conv_all`, `nonneg_all`).  The chord from `0` to `M/2` and the twist bound at `M/2` give
`polyakov_pair_evenM` : for every even `M ≥ 4`, every `β ≥ 0`, every `T ≤ M` and every `b, b'`,
`|⟨P_b(0) P_{b'}(T)⟩₀| ≤ 2 tanh(N²β)^{M·min(T, M−T)}`.
-/

open Finset MeasureTheory TwistedWilson TwistedPlane HalfSplit

namespace PolyakovT

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem nonneg_all (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b : ZMod N × ZMod N)
    (k : ℕ) (hk : k ≤ M / 2) : 0 ≤ Gc N M β b b k := by
  rcases Nat.even_or_odd k with ⟨w, hw⟩ | ⟨w, hw⟩
  · have h := Gc_even_nonneg N M hM β b w (by omega)
    rwa [show 2 * w = k by omega] at h
  · have h := Gc_odd_nonneg N M hM hM4 β hβ b w (by omega)
    rwa [← hw] at h

theorem conv_all (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b : ZMod N × ZMod N)
    (k : ℕ) (hk1 : 1 ≤ k) (hk2 : k + 1 ≤ M / 2) :
    Gc N M β b b k ^ 2 ≤ Gc N M β b b (k - 1) * Gc N M β b b (k + 1) := by
  rcases Nat.even_or_odd k with ⟨w, hw⟩ | ⟨w, hw⟩
  · have h := cs_odd N M hM hM4 β hβ b b (w - 1) w (by omega) (by omega)
    rwa [show w - 1 + w + 1 = k by omega, show 2 * (w - 1) + 1 = k - 1 by omega,
      show 2 * w + 1 = k + 1 by omega] at h
  · have h := cs_even N M hM β b b w (w + 1) (by omega) (by omega)
    rwa [show w + (w + 1) = k by omega, show 2 * w = k - 1 by omega,
      show 2 * (w + 1) = k + 1 by omega] at h

/-- diagonal, every `k ≤ M/2` -/
theorem diag_all (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β) (b : ZMod N × ZMod N)
    (k : ℕ) (hk : k ≤ M / 2) :
    0 ≤ Gc N M β b b k ∧
    Gc N M β b b k ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * k) * ZW N M β true false := by
  have hZ := ZW_pos N M β true false
  have ht := tN_nonneg N β
  have g0 := nonneg_all N M hM hM4 β hβ b 0 (by omega)
  have g0le : Gc N M β b b 0 ≤ ZW N M β true false := (le_abs_self _).trans (abs_Gc_le N M β b b 0)
  have gk := nonneg_all N M hM hM4 β hβ b k hk
  have gh := nonneg_all N M hM hM4 β hβ b (M / 2) le_rfl
  refine ⟨gk, ?_⟩
  have hch := LogChord.chord (fun j => Gc N M β b b j) (M / 2)
    (fun j hj => nonneg_all N M hM hM4 β hβ b j hj)
    (fun j h1 h2 => conv_all N M hM hM4 β hβ b j h1 h2) k hk
  try simp only at hch
  -- normalise
  set Z := ZW N M β true false
  set x := Gc N M β b b k / Z
  set y := Gc N M β b b (M / 2) / Z
  set t := Real.tanh ((N : ℝ) ^ 2 * |β|)
  have hx0 : 0 ≤ x := div_nonneg gk hZ.le
  have hy0 : 0 ≤ y := div_nonneg gh hZ.le
  have hZm : Z ^ (M / 2 - k) * Z ^ k = Z ^ (M / 2) := by
    rw [← pow_add, Nat.sub_add_cancel hk]
  have y0 : (Gc N M β b b 0 / Z) ^ (M / 2 - k) ≤ 1 :=
    pow_le_one₀ (div_nonneg g0 hZ.le) ((div_le_one hZ).2 g0le)
  have hxy : x ^ (M / 2) ≤ y ^ k := by
    calc x ^ (M / 2) = Gc N M β b b k ^ (M / 2) / Z ^ (M / 2) := div_pow _ _ _
      _ ≤ (Gc N M β b b 0 ^ (M / 2 - k) * Gc N M β b b (M / 2) ^ k) / Z ^ (M / 2) :=
          div_le_div_of_nonneg_right hch (pow_pos hZ _).le
      _ = (Gc N M β b b 0 / Z) ^ (M / 2 - k) * y ^ k := by
          rw [div_pow, div_pow, div_mul_div_comm, hZm]
      _ ≤ y ^ k := mul_le_of_le_one_left (pow_nonneg hy0 _) y0
  have hsq := half_sq N M hM β b b
  have hhalf : polyExp N M β b b 0 (halfPt M) = y := rfl
  rw [hhalf] at hsq
  have hM2 : M = 2 * (M / 2) := by omega
  have h4 : (4 : ℝ) ^ (M / 2) = 2 ^ M := by
    conv_rhs => rw [hM2]
    rw [pow_mul]; norm_num
  have hexp : M * k * M = M ^ 2 * k := by ring
  have key : x ^ M ≤ (2 * t ^ (M * k)) ^ M := by
    calc x ^ M = (x ^ (M / 2)) ^ 2 := by rw [← pow_mul, mul_comm, ← hM2]
      _ ≤ (y ^ k) ^ 2 := pow_le_pow_left₀ (pow_nonneg hx0 _) hxy 2
      _ = (y ^ 2) ^ k := by ring
      _ ≤ (4 * t ^ (M ^ 2)) ^ k := pow_le_pow_left₀ (by positivity) hsq k
      _ = 4 ^ k * t ^ (M ^ 2 * k) := by rw [mul_pow, ← pow_mul]
      _ ≤ 4 ^ (M / 2) * t ^ (M ^ 2 * k) :=
          mul_le_mul_of_nonneg_right (pow_le_pow_right₀ (by norm_num) hk) (pow_nonneg ht _)
      _ = (2 * t ^ (M * k)) ^ M := by rw [mul_pow, ← pow_mul, hexp, h4]
  have hx := (pow_le_pow_iff_left₀ hx0 (mul_nonneg zero_le_two (pow_nonneg ht _))
    (by omega : M ≠ 0)).1 key
  exact (div_le_iff₀ hZ).1 hx

/-- every `T ≤ M/2`, every `b, b'` -/
theorem pair_half_all (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (b b' : ZMod N × ZMod N) (T : ℕ) (hT : 2 * T ≤ M) :
    |Gc N M β b b' T| ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * T) * ZW N M β true false := by
  have hZ := ZW_pos N M β true false
  have ht := tN_nonneg N β
  set t := Real.tanh ((N : ℝ) ^ 2 * |β|)
  have hP : 0 ≤ 2 * t ^ (M * T) * ZW N M β true false :=
    mul_nonneg (mul_nonneg zero_le_two (pow_nonneg ht _)) hZ.le
  obtain ⟨a0, a1⟩ := diag_all N M hM hM4 β hβ b T (by omega)
  obtain ⟨b0, b1⟩ := diag_all N M hM hM4 β hβ b' T (by omega)
  have hcs : Gc N M β b b' T ^ 2 ≤ Gc N M β b b T * Gc N M β b' b' T := by
    rcases Nat.even_or_odd T with ⟨w, hw⟩ | ⟨w, hw⟩
    · have h := cs_even N M hM β b b' w w (by omega) (by omega)
      rwa [← hw, show 2 * w = T by omega] at h
    · have h := cs_odd N M hM hM4 β hβ b b' w w (by omega) (by omega)
      rwa [show w + w + 1 = T by omega, show 2 * w + 1 = T by omega] at h
  have h2 : Gc N M β b b' T ^ 2 ≤ (2 * t ^ (M * T) * ZW N M β true false) ^ 2 := by
    calc Gc N M β b b' T ^ 2 ≤ Gc N M β b b T * Gc N M β b' b' T := hcs
      _ ≤ (2 * t ^ (M * T) * ZW N M β true false) * (2 * t ^ (M * T) * ZW N M β true false) :=
          mul_le_mul a1 b1 b0 hP
      _ = _ := by ring
  rw [← sq_abs] at h2
  exact (pow_le_pow_iff_left₀ (abs_nonneg _) hP two_ne_zero).1 h2

/-- **Every even `M ≥ 4`, every `β ≥ 0`, every `T ≤ M`, every `b, b'`:**
`|⟨P_b(0) P_{b'}(T)⟩₀| ≤ 2 tanh(N²β)^{M·min(T, M−T)}`. -/
theorem polyakov_pair_evenM (hM : M % 2 = 0) (hM4 : 4 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (b b' : ZMod N × ZMod N) (T : ℕ) (hT : T ≤ M) :
    |polyExp N M β b b' 0 (T : ZMod M)|
      ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M * min T (M - T)) := by
  have hZ := ZW_pos N M β true false
  have e : polyExp N M β b b' 0 (T : ZMod M) = Gc N M β b b' T / ZW N M β true false := rfl
  rw [e, abs_div, abs_of_pos hZ, div_le_iff₀ hZ]
  by_cases h2 : 2 * T ≤ M
  · rw [min_eq_left (by omega)]
    exact pair_half_all N M hM hM4 β hβ b b' T h2
  · rw [min_eq_right (by omega)]
    have hs := Gc_swap N M β b b' (M - T) (by omega)
    rw [show M - (M - T) = T by omega] at hs
    rw [hs]
    exact pair_half_all N M hM hM4 β hβ b' b (M - T) (by omega)

end PolyakovT

#print axioms PolyakovT.polyakov_pair_evenM
#print axioms PolyakovT.diag_all
