import Mathlib

/-!
# Discrete log-convexity gives the chord bound

`LogChord.chord` : a sequence `g ≥ 0` on `{0, …, m}` with `g k² ≤ g (k−1) g (k+1)` for
`1 ≤ k ≤ m − 1` satisfies `g k ^ m ≤ g 0 ^ (m − k) * g m ^ k` for `k ≤ m`
(the integer-power form of `g k ≤ g 0^{1−k/m} g m^{k/m}`).
-/

namespace LogChord

theorem step (g : ℕ → ℝ) (m : ℕ) (hg : ∀ k ≤ m, 0 ≤ g k)
    (hc : ∀ k, 1 ≤ k → k + 1 ≤ m → g k ^ 2 ≤ g (k - 1) * g (k + 1)) :
    ∀ k, k + 1 ≤ m → g k ^ (k + 1) ≤ g 0 * g (k + 1) ^ k := by
  intro k
  induction k with
  | zero => intro _; simp
  | succ k ih =>
    intro hk
    have ih' := ih (by omega)
    have h2 := hc (k + 1) (by omega) hk
    simp only [Nat.add_sub_cancel] at h2
    rw [show k + 1 + 1 = k + 2 from rfl] at h2
    have g0 := hg 0 (by omega)
    have gk := hg k (by omega)
    have gk1 := hg (k + 1) (by omega)
    have gk2 := hg (k + 2) (by omega)
    -- g(k+1)^{2(k+1)} ≤ g0 g(k+1)^k g(k+2)^{k+1}
    have big : g (k + 1) ^ k * g (k + 1) ^ (k + 2) ≤ g (k + 1) ^ k * (g 0 * g (k + 2) ^ (k + 1)) := by
      calc g (k + 1) ^ k * g (k + 1) ^ (k + 2) = (g (k + 1) ^ 2) ^ (k + 1) := by ring
        _ ≤ (g k * g (k + 2)) ^ (k + 1) := pow_le_pow_left₀ (by positivity) h2 _
        _ = g k ^ (k + 1) * g (k + 2) ^ (k + 1) := by ring
        _ ≤ (g 0 * g (k + 1) ^ k) * g (k + 2) ^ (k + 1) :=
            mul_le_mul_of_nonneg_right ih' (by positivity)
        _ = g (k + 1) ^ k * (g 0 * g (k + 2) ^ (k + 1)) := by ring
    rcases eq_or_lt_of_le gk1 with h0 | hpos
    · rw [← h0, zero_pow (by omega)]; positivity
    · exact le_of_mul_le_mul_left big (by positivity)

theorem chord (g : ℕ → ℝ) (m : ℕ) (hg : ∀ k ≤ m, 0 ≤ g k)
    (hc : ∀ k, 1 ≤ k → k + 1 ≤ m → g k ^ 2 ≤ g (k - 1) * g (k + 1)) :
    ∀ k ≤ m, g k ^ m ≤ g 0 ^ (m - k) * g m ^ k := by
  have hP := step g m hg hc
  have g0 := hg 0 (by omega)
  have gm := hg m le_rfl
  -- downward induction on j = m - k
  have key : ∀ j, j ≤ m → g (m - j) ^ m ≤ g 0 ^ j * g m ^ (m - j) := by
    intro j
    induction j with
    | zero => intro _; simp
    | succ j ih =>
      intro hj
      obtain ⟨k, hk⟩ : ∃ k, k = m - (j + 1) := ⟨_, rfl⟩
      have hk1 : m - j = k + 1 := by omega
      rw [← hk]
      have ih' := ih (by omega)
      rw [hk1] at ih'
      have hPk := hP k (by omega)
      have gk := hg k (by omega)
      have gk1 := hg (k + 1) (by omega)
      -- m = k + 1 + j
      have hm : m = k + 1 + j := by omega
      have hmk : m - k = j + 1 := by omega
      have lhs : (g k ^ m) ^ (k + 1) ≤ (g 0 ^ (j + 1) * g m ^ k) ^ (k + 1) := by
        calc (g k ^ m) ^ (k + 1) = (g k ^ (k + 1)) ^ m := by ring
          _ ≤ (g 0 * g (k + 1) ^ k) ^ m := pow_le_pow_left₀ (by positivity) hPk _
          _ = g 0 ^ m * (g (k + 1) ^ m) ^ k := by ring
          _ ≤ g 0 ^ m * (g 0 ^ j * g m ^ (k + 1)) ^ k :=
              mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (by positivity) ih' _) (by positivity)
          _ = (g 0 ^ (j + 1) * g m ^ k) ^ (k + 1) := by rw [hm]; ring
      exact (pow_le_pow_iff_left₀ (by positivity) (by positivity) (by omega)).1 lhs
  intro k hk
  have := key (m - k) (by omega)
  rwa [show m - (m - k) = k by omega] at this

end LogChord

#print axioms LogChord.chord
