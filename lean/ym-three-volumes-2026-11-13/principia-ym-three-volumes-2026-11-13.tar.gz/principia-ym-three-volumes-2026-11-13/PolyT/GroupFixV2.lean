import Blocks.ThickFloorPolyakovV1

/-!
# Gauge fixing of crossing links for a group-valued configuration (abstract), and the SU(2) case

Links `ι` with source/target sites `src`, `tgt`, values in a topological group `G` with a probability
measure `μ` invariant under `q ↦ a q b⁻¹`.  A decidable set `cr` of links ("crossing") such that each
site `x` with `hasIn x` receives exactly the crossing link `k x`, and no crossing link starts at such
a site.  For `H` invariant under all gauge transformations `ω_ℓ ↦ g(src ℓ) ω_ℓ g(tgt ℓ)⁻¹`,
`∫ H dμ^ι = ∫ H(ω with the crossing links set to 1) dμ^ι` (`GroupGaugeFix.integral_gaugeFix`).
The change of variables is the skew product (crossing values, rest) ↦ (crossing values,
`g(ω_cr) · rest`).
`GroupGaugeFix.haarSU2_two_sided` : the SU(2) Haar probability measure is invariant under
`q ↦ a q b⁻¹`.
-/

namespace GroupGaugeFix

open MeasureTheory

section Abstract

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [MeasurableSpace G]
  [BorelSpace G] [SecondCountableTopology G]
variable (μ : Measure G) [IsProbabilityMeasure μ]
variable {ι S : Type*} [Fintype ι] [DecidableEq ι] (src tgt : ι → S)

/-- the gauge action -/
def act (g : S → G) (ω : ι → G) : ι → G := fun ℓ => g (src ℓ) * ω ℓ * (g (tgt ℓ))⁻¹

variable (cr : ι → Prop) [DecidablePred cr] (hasIn : S → Prop) [DecidablePred hasIn] (k : S → ι)

/-- the gauge transformation read off a configuration -/
def gOf (ω : ι → G) (x : S) : G := if hasIn x then ω (k x) else 1

/-- the same, from the crossing values only -/
def gSub (hk : ∀ x, hasIn x → cr (k x)) (a : {i // cr i} → G) (x : S) : G :=
  if h : hasIn x then a ⟨k x, hk x h⟩ else 1

/-- the fibre map of the skew product -/
def fiber (hk : ∀ x, hasIn x → cr (k x)) (a : {i // cr i} → G) (b : {i // ¬ cr i} → G) :
    {i // ¬ cr i} → G :=
  fun j => gSub cr hasIn k hk a (src j.1) * b j * (gSub cr hasIn k hk a (tgt j.1))⁻¹

/-- the change of variables: crossing values kept, the others gauge transformed -/
def Φ (ω : ι → G) : ι → G :=
  fun ℓ => if cr ℓ then ω ℓ else gOf hasIn k ω (src ℓ) * ω ℓ * (gOf hasIn k ω (tgt ℓ))⁻¹

/-- set the crossing links to `1` -/
def setOne (ω : ι → G) : ι → G := fun ℓ => if cr ℓ then 1 else ω ℓ

theorem measurable_setOne : Measurable (setOne cr : (ι → G) → ι → G) := by
  refine measurable_pi_lambda _ fun ℓ => ?_
  unfold setOne
  split_ifs
  · exact measurable_const
  · exact measurable_pi_apply ℓ

theorem Φ_preserving (hLR : ∀ a b : G, MeasurePreserving (fun q => a * q * b⁻¹) μ μ)
    (hk : ∀ x, hasIn x → cr (k x)) :
    MeasurePreserving (Φ src tgt cr hasIn k) (Measure.pi fun _ : ι => μ)
      (Measure.pi fun _ : ι => μ) := by
  have he_mp := measurePreserving_piEquivPiSubtypeProd (fun _ : ι => μ) cr
  have hG : ∀ x, Continuous (fun a : {i // cr i} → G => gSub cr hasIn k hk a x) := by
    intro x
    unfold gSub
    split_ifs with h
    · exact continuous_apply _
    · exact continuous_const
  have hgc : Continuous (Function.uncurry (fiber (G := G) src tgt cr hasIn k hk)) := by
    refine continuous_pi fun j => ?_
    show Continuous (fun p : ({i // cr i} → G) × ({i // ¬ cr i} → G) =>
      gSub cr hasIn k hk p.1 (src j.1) * p.2 j * (gSub cr hasIn k hk p.1 (tgt j.1))⁻¹)
    exact (((hG _).comp continuous_fst).mul ((continuous_apply j).comp continuous_snd)).mul
      ((hG _).comp continuous_fst).inv
  have hgm : Measurable (Function.uncurry (fiber (G := G) src tgt cr hasIn k hk)) := hgc.measurable
  have hg : ∀ᵐ a ∂(Measure.pi fun _ : {i // cr i} => μ),
      Measure.map (fiber src tgt cr hasIn k hk a) (Measure.pi fun _ : {i // ¬ cr i} => μ)
        = Measure.pi fun _ : {i // ¬ cr i} => μ := by
    refine Filter.Eventually.of_forall fun a => ?_
    exact (measurePreserving_pi (fun _ : {i // ¬ cr i} => μ) (fun _ => μ)
      (fun j => hLR _ _)).map_eq
  have hΨ := MeasurePreserving.skew_product
    (MeasurePreserving.id (Measure.pi fun _ : {i // cr i} => μ)) hgm hg
  have hcomp := (he_mp.symm _).comp (hΨ.comp he_mp)
  convert hcomp using 1
  funext ω ℓ
  show _ = (Equiv.piEquivPiSubtypeProd cr (fun _ : ι => G)).symm
    ((fun i => ω i.1), fiber src tgt cr hasIn k hk (fun i => ω i.1) (fun i => ω i.1)) ℓ
  rw [Equiv.piEquivPiSubtypeProd_symm_apply]
  unfold Φ
  by_cases h : cr ℓ
  · rw [if_pos h, dif_pos h]
  · rw [if_neg h, dif_neg h]
    show gOf hasIn k ω (src ℓ) * ω ℓ * (gOf hasIn k ω (tgt ℓ))⁻¹
      = gSub cr hasIn k hk (fun i => ω i.1) (src ℓ) * ω ℓ
          * (gSub cr hasIn k hk (fun i => ω i.1) (tgt ℓ))⁻¹
    have e1 : ∀ x, gSub cr hasIn k hk (fun i => ω i.1) x = gOf hasIn k ω x := fun x => by
      unfold gSub gOf
      split_ifs <;> rfl
    rw [e1, e1]

/-- **Gauge fixing** (abstract group). -/
theorem integral_gaugeFix (hLR : ∀ a b : G, MeasurePreserving (fun q => a * q * b⁻¹) μ μ)
    (hk1 : ∀ x, hasIn x → cr (k x) ∧ tgt (k x) = x)
    (hk2 : ∀ c, cr c → hasIn (tgt c) ∧ k (tgt c) = c)
    (hk3 : ∀ c, cr c → ¬ hasIn (src c))
    (H : (ι → G) → ℝ) (hH : Measurable H)
    (hinv : ∀ (g : S → G) ω, H (act src tgt g ω) = H ω) :
    ∫ ω, H ω ∂(Measure.pi fun _ : ι => μ)
      = ∫ ω, H (setOne cr ω) ∂(Measure.pi fun _ : ι => μ) := by
  have hk : ∀ x, hasIn x → cr (k x) := fun x h => (hk1 x h).1
  have hΦ := Φ_preserving μ src tgt cr hasIn k hLR hk
  have key : ∀ ω : ι → G, H ω = H (setOne cr (Φ src tgt cr hasIn k ω)) := by
    intro ω
    rw [← hinv (gOf hasIn k ω) ω]
    congr 1
    funext ℓ
    unfold act setOne Φ
    by_cases h : cr ℓ
    · rw [if_pos h]
      obtain ⟨h1, h2⟩ := hk2 ℓ h
      have hs : gOf hasIn k ω (src ℓ) = 1 := by unfold gOf; rw [if_neg (hk3 ℓ h)]
      have ht : gOf hasIn k ω (tgt ℓ) = ω ℓ := by unfold gOf; rw [if_pos h1, h2]
      rw [hs, ht, one_mul, mul_inv_cancel]
    · rw [if_neg h, if_neg h]
  rw [integral_congr_ae (Filter.Eventually.of_forall key)]
  have hm : AEStronglyMeasurable (fun ω => H (setOne cr ω))
      (Measure.map (Φ src tgt cr hasIn k) (Measure.pi fun _ : ι => μ)) := by
    rw [hΦ.map_eq]
    exact (hH.comp (measurable_setOne cr)).aestronglyMeasurable
  have := integral_map hΦ.measurable.aemeasurable hm
  rw [hΦ.map_eq] at this
  exact this.symm

end Abstract

open TwistedWilson

/-- the SU(2) Haar probability measure is invariant under `q ↦ a q b⁻¹` -/
theorem haarSU2_two_sided (a b : SU2) :
    MeasurePreserving (fun q : SU2 => a * q * b⁻¹) haarSU2 haarSU2 := by
  have hf : Measurable (fun q : SU2 => a * q * b⁻¹) :=
    ((continuous_mul_const b⁻¹).comp (continuous_const_mul a)).measurable
  refine ⟨hf, ?_⟩
  have e : (fun q : SU2 => a * q * b⁻¹) = (· * b⁻¹) ∘ (a * ·) := rfl
  rw [e, ← Measure.map_map (continuous_mul_const b⁻¹).measurable (continuous_const_mul a).measurable,
    map_mul_left_eq_self]
  rw [show haarSU2 = Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2) from rfl]
  have : IsProbabilityMeasure (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2)) :=
    haarProb_isProbabilityMeasure SU2
  exact ThickFloorRP.CompactHaar.map_mul_right_eq _ b⁻¹

end GroupGaugeFix

#print axioms GroupGaugeFix.integral_gaugeFix
#print axioms GroupGaugeFix.haarSU2_two_sided
