import Sweep.PotentialV1

/-!
# Weighted potential for the sweep (groundwork for distance decay) — 

Generalises `Sweep.potential_step` to site weights `ρ > 0` with the weighted row condition
`Σ_{y ≠ x} ρ_y C x y ≤ α ρ_x` (for `ρ_y = e^{-λ d(y, A)}` and neighbours changing `d` by at most 1
this follows from `Σ_{y≠x} C x y ≤ α₀` with `α = e^λ α₀`).  The sweep may run along any list
(for instance all links outside a set `A`, which are never resampled).  The potential
`Ψ = Σ_y (1 if processed else α) ρ_y δ_y` does not increase (`potential_sweep_w`).
-/

namespace Sweep

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

noncomputable def Ψw (α : ℝ) (ρ : ι → ℝ) (P : Finset ι) (δ : ι → ℝ) : ℝ :=
  ∑ y, (if y ∈ P then 1 else α) * (ρ y * δ y)

theorem potential_step_w (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x) (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (P : Finset ι) (x : ι) (hx : x ∉ P) :
    Ψw α ρ (insert x P) (step C x δ) ≤ Ψw α ρ P δ := by
  unfold Ψw
  rw [← Finset.sum_erase_add _ _ (Finset.mem_univ x),
    ← Finset.sum_erase_add univ (fun y => (if y ∈ P then 1 else α) * (ρ y * δ y))
      (Finset.mem_univ x)]
  simp only [Finset.mem_insert_self, if_true, if_neg hx]
  have hs : step C x δ x = 0 := by unfold step; rw [if_pos rfl]
  rw [hs, mul_zero, mul_zero, add_zero]
  have e : ∑ y ∈ univ.erase x, (if y ∈ insert x P then (1 : ℝ) else α) * (ρ y * step C x δ y)
      = ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * (ρ y * δ y)
        + δ x * ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * (ρ y * C x y) := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun y hy => ?_
    have hyx : y ≠ x := Finset.ne_of_mem_erase hy
    have hm : (y ∈ insert x P) ↔ (y ∈ P) := by
      rw [Finset.mem_insert]; exact ⟨fun h => h.resolve_left hyx, Or.inr⟩
    unfold step
    rw [if_neg hyx]
    by_cases hP : y ∈ P
    · rw [if_pos (hm.2 hP), if_pos hP]; ring
    · rw [if_neg (fun h => hP (hm.1 h)), if_neg hP]; ring
  rw [e]
  have hw : ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * (ρ y * C x y) ≤ α * ρ x := by
    refine le_trans (Finset.sum_le_sum fun y _ => ?_) (hrow x)
    split_ifs
    · rw [one_mul]
    · exact mul_le_of_le_one_left (mul_nonneg (hρ y) (hC0 x y)) hα1
  have := mul_le_mul_of_nonneg_left hw (hδ x)
  nlinarith [this]

theorem potential_sweep_w (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x) :
    ∀ (L : List ι) (P : Finset ι) (δ : ι → ℝ), (∀ y, 0 ≤ δ y) → L.Nodup →
      (∀ x ∈ L, x ∉ P) → Ψw α ρ (P ∪ L.toFinset) (sweep C L δ) ≤ Ψw α ρ P δ
  | [], P, δ, _, _, _ => by simp [sweep]
  | x :: L, P, δ, hδ, hnd, hdisj => by
    have hxP : x ∉ P := hdisj x (List.mem_cons_self ..)
    have hnd' := List.nodup_cons.1 hnd
    have ih := potential_sweep_w C α hα1 hC0 ρ hρ hrow L (insert x P) (step C x δ)
      (step_nonneg C hC0 x δ hδ) hnd'.2 (fun z hz => by
        rw [Finset.mem_insert]
        rintro (h | h)
        · exact hnd'.1 (h ▸ hz)
        · exact hdisj z (List.mem_cons_of_mem _ hz) h)
    have e : P ∪ (x :: L).toFinset = insert x P ∪ L.toFinset := by
      ext z; simp [or_left_comm]
    show Ψw α ρ (P ∪ (x :: L).toFinset) (sweep C L (step C x δ)) ≤ Ψw α ρ P δ
    rw [e]
    exact ih.trans (potential_step_w C α hα1 hC0 ρ hρ hrow δ hδ P x hxP)

end Sweep

#print axioms Sweep.potential_step_w
#print axioms Sweep.potential_sweep_w
