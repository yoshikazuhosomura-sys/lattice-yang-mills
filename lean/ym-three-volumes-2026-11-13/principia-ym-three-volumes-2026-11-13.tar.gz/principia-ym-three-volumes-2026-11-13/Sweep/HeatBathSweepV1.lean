import Spec.LinkDLRV2
import Spec.SweepStepV1
import Sweep.PotentialV1

/-!
# The heat-bath sweep of the Wilson specification contracts oscillations by `18 tanh |β|`


`hbSweep β L f` applies the heat-bath operators `P_x` along the list `L` (first element first).
`hbSweep_osc`: if `δ` bounds the single-link oscillations of `f`, then `Sweep.sweep (coef β) L δ`
bounds those of `hbSweep β L f` (by `sweep_step`), and the result stays measurable and bounded.
`heatBath_sweep_contract`: over one sweep of all links, the total oscillation is multiplied by at
most `α = 18 tanh |β|` (`Sweep.sweep_contract` with `dobrushin_row`), provided `α ≤ 1`.
`hbSweep_invariant`: the sweep preserves the Wilson measure (`dlr`).
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset

variable (N : ℕ) [NeZero N]

theorem measurable_heatBath (β : ℝ) (x : Lk N) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    Measurable (heatBath N β x f) := by
  have hupd : Measurable (fun z : (Lk N → QBall) × QBall => Function.update z.1 x z.2) :=
    (continuous_fst.update x continuous_snd).measurable
  have hNum : Measurable (fun ω => ∫ U, f (Function.update ω x U) *
      Real.exp (locAct N β ω x U) ∂haarBall) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        f (Function.update z.1 x z.2) * Real.exp (locAct N β z.1 x z.2)) :=
      ((hf.comp hupd).mul (Real.continuous_exp.comp
        (continuous_locAct₂ N β x)).measurable).stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hDen : Measurable (fun ω => ∫ U, Real.exp (locAct N β ω x U) ∂haarBall) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        Real.exp (locAct N β z.1 x z.2)) :=
      (Real.continuous_exp.comp (continuous_locAct₂ N β x)).measurable.stronglyMeasurable
    exact this.integral_prod_right'.measurable
  exact hNum.div hDen

theorem abs_heatBath_le (β : ℝ) (x : Lk N) (f : (Lk N → QBall) → ℝ) (hf : Measurable f)
    (Cf : ℝ) (hfb : ∀ ω, |f ω| ≤ Cf) (ω : Lk N → QBall) : |heatBath N β x f ω| ≤ Cf :=
  abs_avg_le N β ω x _ (hf.comp (continuous_const.update x continuous_id).measurable) Cf
    (fun U => hfb _)

/-- the heat-bath operators applied along a list of links -/
noncomputable def hbSweep (β : ℝ) : List (Lk N) → ((Lk N → QBall) → ℝ) → ((Lk N → QBall) → ℝ)
  | [], f => f
  | x :: L, f => hbSweep β L (heatBath N β x f)

theorem hbSweep_osc (β : ℝ) :
    ∀ (L : List (Lk N)) (f : (Lk N → QBall) → ℝ), Measurable f → ∀ Cf : ℝ, (∀ ω, |f ω| ≤ Cf) →
      ∀ δ : Lk N → ℝ, (∀ y, 0 ≤ δ y) →
      (∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ δ y) →
      Measurable (hbSweep N β L f) ∧ (∀ ω, |hbSweep N β L f ω| ≤ Cf) ∧
      ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
        |hbSweep N β L f ω - hbSweep N β L f ω'| ≤ Sweep.sweep (coef N β) L δ y
  | [], f, hf, Cf, hfb, δ, _, hosc => ⟨hf, hfb, hosc⟩
  | x :: L, f, hf, Cf, hfb, δ, hδ, hosc => by
    have h1 := (sweep_step N β x f hf Cf hfb δ hδ hosc).1
    have hC0 : ∀ x y, 0 ≤ coef N β x y := fun x y => by
      unfold coef
      have : 1 ≤ Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) :=
        Real.one_le_exp (by positivity)
      exact div_nonneg (by linarith) (by linarith)
    exact hbSweep_osc β L (heatBath N β x f) (measurable_heatBath N β x f hf) Cf
      (abs_heatBath_le N β x f hf Cf hfb) (Sweep.step (coef N β) x δ)
      (Sweep.step_nonneg (coef N β) hC0 x δ hδ) h1

theorem hbSweep_invariant (β : ℝ) :
    ∀ (L : List (Lk N)) (f : (Lk N → QBall) → ℝ), Measurable f → ∀ Cf : ℝ, (∀ ω, |f ω| ≤ Cf) →
      ∫ ω, hbSweep N β L f ω ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β)
  | [], f, _, _, _ => rfl
  | x :: L, f, hf, Cf, hfb => by
    show ∫ ω, hbSweep N β L (heatBath N β x f) ω ∂(wilsonMeasure N β) = _
    rw [hbSweep_invariant β L (heatBath N β x f) (measurable_heatBath N β x f hf) Cf
      (abs_heatBath_le N β x f hf Cf hfb)]
    exact (dlr N β x f hf Cf hfb).symm

/-- **One sweep of all links contracts the total oscillation by `18 tanh |β|`.** -/
theorem heatBath_sweep_contract (β : ℝ)
    (hα : 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) ≤ 1)
    (f : (Lk N → QBall) → ℝ) (hf : Measurable f) (Cf : ℝ) (hfb : ∀ ω, |f ω| ≤ Cf)
    (δ : Lk N → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ δ y) :
    ∃ δ' : Lk N → ℝ, (∀ y, 0 ≤ δ' y) ∧
      (∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
        |hbSweep N β (univ : Finset (Lk N)).toList f ω
          - hbSweep N β (univ : Finset (Lk N)).toList f ω'| ≤ δ' y) ∧
      ∑ y, δ' y ≤ 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) * ∑ y, δ y := by
  have hC0 : ∀ x y, 0 ≤ coef N β x y := fun x y => by
    unfold coef
    have : 1 ≤ Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) :=
      Real.one_le_exp (by positivity)
    exact div_nonneg (by linarith) (by linarith)
  refine ⟨Sweep.sweep (coef N β) (univ : Finset (Lk N)).toList δ,
    Sweep.sweep_nonneg (coef N β) hC0 _ δ hδ,
    (hbSweep_osc N β _ f hf Cf hfb δ hδ hosc).2.2,
    Sweep.sweep_contract (coef N β) _ hα hC0 (fun x => dobrushin_row N β x) δ hδ⟩

end LinkSpec

#print axioms LinkSpec.hbSweep_osc
#print axioms LinkSpec.hbSweep_invariant
#print axioms LinkSpec.heatBath_sweep_contract
