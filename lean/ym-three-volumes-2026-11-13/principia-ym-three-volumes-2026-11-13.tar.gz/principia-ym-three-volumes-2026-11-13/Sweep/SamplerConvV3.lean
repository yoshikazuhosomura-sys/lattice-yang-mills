import Sweep.HeatBathSweepV1

/-!
# Volume-uniform convergence of the heat-bath sweeps of the Wilson measure 

`osc_total`: single-link oscillation bounds `δ` give `|g ω - g ω'| ≤ Σ_y δ y` (change the links one
at a time).  `sampler_conv`: with `Q` one heat-bath sweep of all links and `α = 18 tanh |β| ≤ 1`,
`|Q^k f(ω) - ⟨f⟩_W| ≤ α^k Σ_y δ_y(f)` for every configuration `ω`, where `⟨·⟩_W` is the normalised
Wilson expectation.  The constants `α`, `Σ_y δ_y(f)` do not depend on `N` for a local `f`.
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset

variable (N : ℕ) [NeZero N]

theorem osc_total (g : (Lk N → QBall) → ℝ) (δ : Lk N → ℝ)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |g ω - g ω'| ≤ δ y) :
    ∀ (L : List (Lk N)) (ω ω' : Lk N → QBall), (∀ ℓ, ℓ ∉ L → ω ℓ = ω' ℓ) →
      |g ω - g ω'| ≤ (L.map δ).sum
  | [], ω, ω', h => by
    have : ω = ω' := funext fun ℓ => h ℓ (List.not_mem_nil)
    rw [this, sub_self, abs_zero]; simp
  | y :: L, ω, ω', h => by
    have h1 : |g ω - g (Function.update ω y (ω' y))| ≤ δ y := hosc y ω (Function.update ω y (ω' y)) (fun ℓ hℓ => by
      rw [Function.update_of_ne hℓ])
    have h2 : |g (Function.update ω y (ω' y)) - g ω'| ≤ (L.map δ).sum := osc_total g δ hosc L (Function.update ω y (ω' y)) ω' (fun ℓ hℓ => by
      by_cases hℓy : ℓ = y
      · rw [hℓy, Function.update_self]
      · rw [Function.update_of_ne hℓy]
        exact h ℓ (fun hm => (List.mem_cons.1 hm).elim hℓy hℓ))
    rw [List.map_cons, List.sum_cons]
    calc |g ω - g ω'| = |(g ω - g (Function.update ω y (ω' y))) + (g (Function.update ω y (ω' y)) - g ω')| := by ring_nf
      _ ≤ |g ω - g (Function.update ω y (ω' y))| + |g (Function.update ω y (ω' y)) - g ω'| := abs_add_le _ _
      _ ≤ δ y + (L.map δ).sum := add_le_add h1 h2

/-- **Volume-uniform convergence of the heat-bath sweeps** (Gibbs sampler of the Wilson measure). -/
theorem sampler_conv (β : ℝ)
    (hα : 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) ≤ 1)
    (f : (Lk N → QBall) → ℝ) (hf : Measurable f) (Cf : ℝ) (hfb : ∀ ω, |f ω| ≤ Cf)
    (δ : Lk N → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ δ y)
    (k : ℕ) (ω : Lk N → QBall) :
    |(hbSweep N β (univ : Finset (Lk N)).toList)^[k] f ω
        - ∫ ω', f ω' ∂(wilsonProb N β : Measure (Lk N → QBall))|
      ≤ (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) ^ k * ∑ y, δ y := by
  set α := 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)) with hαdef
  set Q := hbSweep N β (univ : Finset (Lk N)).toList with hQ
  -- invariant along the iteration
  have key : ∀ k : ℕ, Measurable (Q^[k] f) ∧ (∀ ω, |Q^[k] f ω| ≤ Cf) ∧
      ∫ ω, Q^[k] f ω ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) ∧
      ∃ δk : Lk N → ℝ, (∀ y, 0 ≤ δk y) ∧
        (∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
          |Q^[k] f ω - Q^[k] f ω'| ≤ δk y) ∧ ∑ y, δk y ≤ α ^ k * ∑ y, δ y := by
    intro k
    induction k with
    | zero => exact ⟨hf, hfb, rfl, δ, hδ, hosc, by simp⟩
    | succ k ih =>
      obtain ⟨hm, hb, hi, δk, hδk, hok, hsum⟩ := ih
      have hs := hbSweep_osc N β (univ : Finset (Lk N)).toList (Q^[k] f) hm Cf hb δk hδk hok
      obtain ⟨δ', hδ'0, hδ'o, hδ'sum⟩ :=
        heatBath_sweep_contract N β hα (Q^[k] f) hm Cf hb δk hδk hok
      rw [Function.iterate_succ_apply']
      refine ⟨hs.1, hs.2.1, ?_, δ', hδ'0, hδ'o, ?_⟩
      · rw [hbSweep_invariant N β _ (Q^[k] f) hm Cf hb, hi]
      · have hα0 : 0 ≤ α := by
          rw [hαdef]
          have : 1 ≤ Real.exp (2 * |β|) := Real.one_le_exp (by positivity)
          exact mul_nonneg (by norm_num) (div_nonneg (by linarith) (by linarith))
        calc ∑ y, δ' y ≤ α * ∑ y, δk y := hδ'sum
          _ ≤ α * (α ^ k * ∑ y, δ y) := mul_le_mul_of_nonneg_left hsum hα0
          _ = α ^ (k + 1) * ∑ y, δ y := by ring
  obtain ⟨hm, hb, hi, δk, hδk, hok, hsum⟩ := key k
  -- the normalised integrals agree
  have hiP : ∫ ω', Q^[k] f ω' ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω', f ω' ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
    rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure, hi]
  rw [← hiP]
  -- |g ω - ∫ g| ≤ sup |g ω - g ω'| ≤ Σ δk
  have hrange : ∀ ω', |Q^[k] f ω - Q^[k] f ω'| ≤ ∑ y, δk y := fun ω' => by
    have := osc_total N (Q^[k] f) δk hok (univ : Finset (Lk N)).toList ω ω'
      (fun ℓ hℓ => absurd (Finset.mem_toList.2 (Finset.mem_univ ℓ)) hℓ)
    rwa [Finset.sum_map_toList] at this
  have hint : Integrable (Q^[k] f) (wilsonProb N β : Measure (Lk N → QBall)) :=
    Integrable.of_bound hm.aestronglyMeasurable Cf
      (Filter.Eventually.of_forall fun ω' => by rw [Real.norm_eq_abs]; exact hb ω')
  have e : Q^[k] f ω - ∫ ω', Q^[k] f ω' ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω', (Q^[k] f ω - Q^[k] f ω') ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
    rw [integral_sub (integrable_const _) hint, integral_const]
    simp
  rw [e]
  have hn := norm_integral_le_of_norm_le_const (μ := (wilsonProb N β : Measure (Lk N → QBall)))
    (C := ∑ y, δk y)
    (Filter.Eventually.of_forall fun ω' => by
      rw [Real.norm_eq_abs]; exact hrange ω')
  rw [probReal_univ, mul_one, Real.norm_eq_abs] at hn
  exact hn.trans hsum

end LinkSpec

#print axioms LinkSpec.osc_total
#print axioms LinkSpec.sampler_conv
