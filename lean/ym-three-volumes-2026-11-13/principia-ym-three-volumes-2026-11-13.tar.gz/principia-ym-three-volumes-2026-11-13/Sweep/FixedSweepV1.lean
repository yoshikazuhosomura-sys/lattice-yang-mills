import Sweep.HeatBathSweepV1

/-!
# Sweeps that never touch the support of `F` (step (a) of the distance-decay plan)

If `F` does not depend on the link `x`, then `∫ F · P_x h dμ_W = ∫ F · h dμ_W` (`dlr` applied to
`F h`, and `P_x (F h) = F · P_x h`).  Along a list of links none of which `F` depends on, the same
holds for the sweep (`hbSweep_mul_invariant`).  Hence the covariance of `F` and `G` equals that of
`F` and `Q′^K G` for the sweep `Q′` over the links outside the support of `F`.
-/

namespace LinkSpec

open MeasureTheory TorusRP

variable (N : ℕ) [NeZero N]

theorem heatBath_mul_invariant (β : ℝ) (x : Lk N) (F h : (Lk N → QBall) → ℝ)
    (hF : Measurable F) (CF : ℝ) (hFb : ∀ ω, |F ω| ≤ CF)
    (hh : Measurable h) (Ch : ℝ) (hhb : ∀ ω, |h ω| ≤ Ch)
    (hFx : ∀ ω U, F (Function.update ω x U) = F ω) :
    ∫ ω, F ω * heatBath N β x h ω ∂(wilsonMeasure N β) = ∫ ω, F ω * h ω ∂(wilsonMeasure N β) := by
  have hCF : 0 ≤ CF := (abs_nonneg _).trans (hFb (fun _ => Classical.arbitrary QBall))
  have hd := dlr N β x (fun ω => F ω * h ω) (hF.mul hh) (CF * Ch) (fun ω => by
    rw [abs_mul]; exact mul_le_mul (hFb ω) (hhb ω) (abs_nonneg _) hCF)
  beta_reduce at hd
  rw [hd]
  refine integral_congr_ae (Filter.Eventually.of_forall fun ω => ?_)
  have hnum : specNum N β x (fun ω => F ω * h ω) ω = F ω * specNum N β x h ω := by
    unfold specNum
    simp only [hFx]
    rw [← integral_const_mul]
    congr 1
    funext U
    ring
  show F ω * (specNum N β x h ω / specDen N β x ω) = specNum N β x (fun ω => F ω * h ω) ω / specDen N β x ω
  rw [hnum]
  ring

theorem hbSweep_mul_invariant (β : ℝ) (F : (Lk N → QBall) → ℝ) (hF : Measurable F) (CF : ℝ)
    (hFb : ∀ ω, |F ω| ≤ CF) :
    ∀ (L : List (Lk N)), (∀ x ∈ L, ∀ ω U, F (Function.update ω x U) = F ω) →
      ∀ (h : (Lk N → QBall) → ℝ), Measurable h → ∀ Ch : ℝ, (∀ ω, |h ω| ≤ Ch) →
      ∫ ω, F ω * hbSweep N β L h ω ∂(wilsonMeasure N β) = ∫ ω, F ω * h ω ∂(wilsonMeasure N β)
  | [], _, h, _, _, _ => rfl
  | x :: L, hL, h, hh, Ch, hhb => by
    show ∫ ω, F ω * hbSweep N β L (heatBath N β x h) ω ∂(wilsonMeasure N β) = _
    rw [hbSweep_mul_invariant β F hF CF hFb L (fun y hy => hL y (List.mem_cons_of_mem _ hy))
      (heatBath N β x h) (measurable_heatBath N β x h hh) Ch (abs_heatBath_le N β x h hh Ch hhb)]
    exact heatBath_mul_invariant N β x F h hF CF hFb hh Ch hhb (hL x (List.mem_cons_self ..))

end LinkSpec

#print axioms LinkSpec.heatBath_mul_invariant
#print axioms LinkSpec.hbSweep_mul_invariant
