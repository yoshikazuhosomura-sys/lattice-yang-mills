import Mathlib

/-!
# Dobrushin's sweep contraction on oscillation vectors 

Pure finite-sum statement (no measure theory).  For a matrix `C ≥ 0` with row sums
`Σ_{y ≠ x} C x y ≤ α ≤ 1`, the single-site update `step x δ` (`δ x ↦ 0`, `δ y ↦ δ y + δ x C x y`)
does not increase the potential `Ψ_P(δ) = Σ_y (1 if y ∈ P else α) δ y` when `x ∉ P` joins the
processed set `P` (`potential_step`).  Iterating over a list of all sites, the total oscillation
after one sweep is at most `α` times the initial total (`sweep_contract`).  With
`C x y = tanh(|β| n_{xy})` and `α = 18 tanh |β|` (`LinkSpec.dobrushin_row`, `LinkSpec.sweep_step`)
this is the contraction of the heat-bath sweep of the Wilson specification; composing the
operators (measurability of `P_x f`) is not in this file.
-/

namespace Sweep

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- one heat-bath step on the oscillation vector -/
def step (C : ι → ι → ℝ) (x : ι) (δ : ι → ℝ) : ι → ℝ :=
  fun y => if y = x then 0 else δ y + δ x * C x y

/-- the potential: weight `1` on processed sites, `α` on the others -/
noncomputable def Ψ (α : ℝ) (P : Finset ι) (δ : ι → ℝ) : ℝ :=
  ∑ y, (if y ∈ P then 1 else α) * δ y

theorem step_nonneg (C : ι → ι → ℝ) (hC0 : ∀ x y, 0 ≤ C x y) (x : ι) (δ : ι → ℝ)
    (hδ : ∀ y, 0 ≤ δ y) (y : ι) : 0 ≤ step C x δ y := by
  unfold step
  split_ifs
  · exact le_rfl
  · exact add_nonneg (hδ y) (mul_nonneg (hδ x) (hC0 x y))

theorem potential_step (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, C x y ≤ α) (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (P : Finset ι) (x : ι) (hx : x ∉ P) :
    Ψ α (insert x P) (step C x δ) ≤ Ψ α P δ := by
  unfold Ψ
  rw [← Finset.sum_erase_add _ _ (Finset.mem_univ x),
    ← Finset.sum_erase_add univ (fun y => (if y ∈ P then 1 else α) * δ y) (Finset.mem_univ x)]
  simp only [Finset.mem_insert_self, if_true, if_neg hx]
  have hs : step C x δ x = 0 := by unfold step; rw [if_pos rfl]
  rw [hs, mul_zero, add_zero]
  have e : ∑ y ∈ univ.erase x, (if y ∈ insert x P then (1 : ℝ) else α) * step C x δ y
      = ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * δ y
        + δ x * ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * C x y := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun y hy => ?_
    have hyx : y ≠ x := Finset.ne_of_mem_erase hy
    have hm : (y ∈ insert x P) ↔ (y ∈ P) := by
      rw [Finset.mem_insert]; exact ⟨fun h => h.resolve_left hyx, Or.inr⟩
    unfold step
    rw [if_neg hyx]
    by_cases hP : y ∈ P
    · rw [if_pos (hm.2 hP), if_pos hP]; ring
    · rw [if_neg (fun h => hP (hm.1 h)), if_neg hP]; ring
  rw [e]
  have hw : ∑ y ∈ univ.erase x, (if y ∈ P then (1 : ℝ) else α) * C x y ≤ α := by
    refine le_trans (Finset.sum_le_sum fun y _ => ?_) (hrow x)
    split_ifs
    · rw [one_mul]
    · exact mul_le_of_le_one_left (hC0 x y) hα1
  have := mul_le_mul_of_nonneg_left hw (hδ x)
  linarith

/-- iterate the steps along a list of sites -/
def sweep (C : ι → ι → ℝ) : List ι → (ι → ℝ) → (ι → ℝ)
  | [], δ => δ
  | x :: L, δ => sweep C L (step C x δ)

theorem sweep_nonneg (C : ι → ι → ℝ) (hC0 : ∀ x y, 0 ≤ C x y) :
    ∀ (L : List ι) (δ : ι → ℝ), (∀ y, 0 ≤ δ y) → ∀ y, 0 ≤ sweep C L δ y
  | [], δ, hδ => hδ
  | x :: L, δ, hδ => sweep_nonneg C hC0 L _ (step_nonneg C hC0 x δ hδ)

theorem potential_sweep (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, C x y ≤ α) :
    ∀ (L : List ι) (P : Finset ι) (δ : ι → ℝ), (∀ y, 0 ≤ δ y) → L.Nodup →
      (∀ x ∈ L, x ∉ P) → Ψ α (P ∪ L.toFinset) (sweep C L δ) ≤ Ψ α P δ
  | [], P, δ, _, _, _ => by simp [sweep]
  | x :: L, P, δ, hδ, hnd, hdisj => by
    have hxP : x ∉ P := hdisj x (List.mem_cons_self ..)
    have hnd' := List.nodup_cons.1 hnd
    have ih := potential_sweep C α hα1 hC0 hrow L (insert x P) (step C x δ)
      (step_nonneg C hC0 x δ hδ) hnd'.2 (fun z hz => by
        rw [Finset.mem_insert]
        rintro (h | h)
        · exact hnd'.1 (h ▸ hz)
        · exact hdisj z (List.mem_cons_of_mem _ hz) h)
    have e : P ∪ (x :: L).toFinset = insert x P ∪ L.toFinset := by
      ext z; simp [or_left_comm]
    show Ψ α (P ∪ (x :: L).toFinset) (sweep C L (step C x δ)) ≤ Ψ α P δ
    rw [e]
    exact ih.trans (potential_step C α hα1 hC0 hrow δ hδ P x hxP)

/-- **One sweep contracts the total oscillation by `α`.** -/
theorem sweep_contract (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, C x y ≤ α) (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) :
    ∑ y, sweep C (univ : Finset ι).toList δ y ≤ α * ∑ y, δ y := by
  have h := potential_sweep C α hα1 hC0 hrow (univ : Finset ι).toList ∅ δ hδ
    (Finset.nodup_toList _) (fun x _ => Finset.notMem_empty x)
  unfold Ψ at h
  simp only [Finset.empty_union, Finset.toList_toFinset, Finset.mem_univ, if_true, one_mul,
    Finset.notMem_empty, if_false] at h
  rw [Finset.mul_sum]
  exact h

end Sweep

#print axioms Sweep.potential_step
#print axioms Sweep.sweep_contract
