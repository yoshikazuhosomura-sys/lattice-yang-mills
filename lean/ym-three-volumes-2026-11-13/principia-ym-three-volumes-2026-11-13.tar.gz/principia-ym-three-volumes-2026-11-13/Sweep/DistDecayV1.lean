import Sweep.WeightedV1
import Sweep.FixedSweepV1
import Sweep.SamplerConvV3
import Spec.DobrushinRowV2

/-!
# Decay of the Wilson covariance with the time distance (Dobrushin's comparison, sweep form)


* `Sweep.sweep_ge_of_not_mem`, `Sweep.iter_bound` : with the links of `A` never resampled and
  weights `ρ` satisfying `Σ_{y≠x} ρ_y C_{xy} ≤ α ρ_x`, after `K` sweeps the oscillation is at most
  `(Σ_y ρ_y δ_y)/ρ_A + (Σ_y ρ_y⁻¹) α^K Σ_y ρ_y δ_y`.
* `LinkSpec.cov_le` : `|E(FH) - E(F)E(H)| ≤ 2 c_F S` when `|H - c| ≤ S`.
* `LinkSpec.wilson_cov_dist` : for `F` depending on the links of `A` (time distance `≤ r` from
  `t₀`) and `G` with single-link oscillations `δ`,
  `|E(FG) - E(F)E(G)| ≤ 2 c_F e^{λ r} Σ_y e^{-λ d(y)} δ_y`, `d(y)` the time distance of `y` from `t₀`,
  whenever `e^λ · 18 tanh|β| < 1`.  Constants do not depend on `N`.
* `TorusRP.wilson_hdec_torus_dob` : the torus `hdec` form (same shape as `wilson_hdec_torus`).
-/

namespace Sweep

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem sweep_ge_of_not_mem (C : ι → ι → ℝ) (hC0 : ∀ x y, 0 ≤ C x y) :
    ∀ (L : List ι) (δ : ι → ℝ), (∀ y, 0 ≤ δ y) → ∀ y, y ∉ L → δ y ≤ sweep C L δ y
  | [], _, _, _, _ => le_rfl
  | x :: L, δ, hδ, y, hy => by
    have hyx : y ≠ x := fun h => hy (h ▸ List.mem_cons_self ..)
    have hyL : y ∉ L := fun h => hy (List.mem_cons_of_mem _ h)
    have h1 : δ y ≤ step C x δ y := by
      unfold step
      rw [if_neg hyx]
      have := mul_nonneg (hδ x) (hC0 x y)
      linarith
    exact h1.trans (sweep_ge_of_not_mem C hC0 L _ (step_nonneg C hC0 x δ hδ) y hyL)

/-- weighted oscillation on `A` -/
noncomputable def aS (A : Finset ι) (ρ δ : ι → ℝ) : ℝ := ∑ y, if y ∈ A then ρ y * δ y else 0

/-- weighted oscillation off `A` -/
noncomputable def bS (A : Finset ι) (ρ δ : ι → ℝ) : ℝ := ∑ y, if y ∈ A then 0 else ρ y * δ y

theorem Ψw_A (α : ℝ) (A : Finset ι) (ρ δ : ι → ℝ) : Ψw α ρ A δ = aS A ρ δ + α * bS A ρ δ := by
  unfold Ψw aS bS
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun y _ => ?_
  split_ifs <;> ring

theorem Ψw_univ (α : ℝ) (ρ δ : ι → ℝ) (A : Finset ι) :
    Ψw α ρ univ δ = aS A ρ δ + bS A ρ δ := by
  unfold Ψw aS bS
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun y _ => ?_
  simp only [Finset.mem_univ, if_true, one_mul]
  split_ifs <;> ring

theorem bS_nonneg (A : Finset ι) (ρ δ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y) (hδ : ∀ y, 0 ≤ δ y) :
    0 ≤ bS A ρ δ :=
  Finset.sum_nonneg fun y _ => by split_ifs; exact le_rfl; exact mul_nonneg (hρ y) (hδ y)

/-- one sweep over the links outside `A`: `a' + b' ≤ a + α b` and `a ≤ a'` -/
theorem one_sweep (C : ι → ι → ℝ) (α : ℝ) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : ∀ x ∈ L, x ∉ A) (hcov : ∀ y, y ∉ A → y ∈ L)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) :
    aS A ρ (sweep C L δ) + bS A ρ (sweep C L δ) ≤ aS A ρ δ + α * bS A ρ δ ∧
      aS A ρ δ ≤ aS A ρ (sweep C L δ) := by
  constructor
  · have h := potential_sweep_w C α hα1 hC0 ρ hρ hrow L A δ hδ hnd hLA
    have e : A ∪ L.toFinset = univ := by
      ext y
      simp only [Finset.mem_union, List.mem_toFinset, Finset.mem_univ, iff_true]
      by_cases hy : y ∈ A
      · exact Or.inl hy
      · exact Or.inr (hcov y hy)
    rw [e, Ψw_univ α ρ _ A, Ψw_A] at h
    exact h
  · unfold aS
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · exact mul_le_mul_of_nonneg_left
        (sweep_ge_of_not_mem C hC0 L δ hδ y (fun h => hLA y h hy)) (hρ y)
    · exact le_rfl

/-- `K` sweeps: `b_K ≤ α^K b_0` and `a_K + b_K ≤ a_0 + b_0` -/
theorem iter_ab (C : ι → ι → ℝ) (α : ℝ) (hα0 : 0 ≤ α) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : ∀ x ∈ L, x ∉ A) (hcov : ∀ y, y ∉ A → y ∈ L)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) :
    ∀ K : ℕ, bS A ρ ((sweep C L)^[K] δ) ≤ α ^ K * bS A ρ δ ∧
      aS A ρ ((sweep C L)^[K] δ) + bS A ρ ((sweep C L)^[K] δ) ≤ aS A ρ δ + bS A ρ δ
  | 0 => by simp
  | K + 1 => by
    obtain ⟨ih1, ih2⟩ := iter_ab C α hα0 hα1 hC0 ρ hρ hrow A L hnd hLA hcov δ hδ K
    have hδK : ∀ y, 0 ≤ ((sweep C L)^[K] δ) y := by
      clear ih1 ih2
      induction K generalizing δ with
      | zero => exact hδ
      | succ K ihK =>
        rw [Function.iterate_succ_apply]
        exact ihK _ (sweep_nonneg C hC0 L δ hδ)
    obtain ⟨h1, h2⟩ := one_sweep C α hα1 hC0 ρ hρ hrow A L hnd hLA hcov _ hδK
    rw [Function.iterate_succ_apply']
    have hb := bS_nonneg A ρ _ hρ hδK
    constructor
    · have : bS A ρ (sweep C L ((sweep C L)^[K] δ)) ≤ α * bS A ρ ((sweep C L)^[K] δ) := by linarith
      calc _ ≤ α * bS A ρ ((sweep C L)^[K] δ) := this
        _ ≤ α * (α ^ K * bS A ρ δ) := mul_le_mul_of_nonneg_left ih1 hα0
        _ = α ^ (K + 1) * bS A ρ δ := by ring
    · have : α * bS A ρ ((sweep C L)^[K] δ) ≤ bS A ρ ((sweep C L)^[K] δ) :=
        mul_le_of_le_one_left hb hα1
      linarith

theorem iter_nonneg (C : ι → ι → ℝ) (hC0 : ∀ x y, 0 ≤ C x y) (L : List ι) :
    ∀ (K : ℕ) (δ : ι → ℝ), (∀ y, 0 ≤ δ y) → ∀ y, 0 ≤ ((sweep C L)^[K] δ) y
  | 0, _, hδ => hδ
  | K + 1, δ, hδ => by
    rw [Function.iterate_succ_apply]
    exact iter_nonneg C hC0 L K _ (sweep_nonneg C hC0 L δ hδ)

/-- **Total oscillation after `K` sweeps outside `A`.** -/
theorem iter_bound (C : ι → ι → ℝ) (α : ℝ) (hα0 : 0 ≤ α) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 < ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : ∀ x ∈ L, x ∉ A) (hcov : ∀ y, y ∉ A → y ∈ L)
    (ρA : ℝ) (hρA : 0 < ρA) (hρA' : ∀ y ∈ A, ρA ≤ ρ y)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) (K : ℕ) :
    ∑ y, ((sweep C L)^[K] δ) y ≤
      (∑ y, ρ y * δ y) / ρA + (∑ y, (ρ y)⁻¹) * (α ^ K * bS A ρ δ) := by
  have hρ0 : ∀ y, 0 ≤ ρ y := fun y => (hρ y).le
  obtain ⟨hb, hab⟩ := iter_ab C α hα0 hα1 hC0 ρ hρ0 hrow A L hnd hLA hcov δ hδ K
  set δK := (sweep C L)^[K] δ with hδKdef
  have hδK : ∀ y, 0 ≤ δK y := iter_nonneg C hC0 L K δ hδ
  have htot : aS A ρ δ + bS A ρ δ = ∑ y, ρ y * δ y := by
    rw [← Ψw_univ 1 ρ δ A]
    unfold Ψw
    simp
  have hbK := bS_nonneg A ρ δK hρ0 hδK
  have hsplit : ∑ y, δK y = (∑ y, if y ∈ A then δK y else 0) + ∑ y, if y ∈ A then 0 else δK y := by
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun y _ => ?_
    split_ifs <;> ring
  have hA : (∑ y, if y ∈ A then δK y else 0) ≤ aS A ρ δK / ρA := by
    unfold aS
    rw [Finset.sum_div]
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · rw [le_div_iff₀ hρA]
      nlinarith [hρA' y hy, hδK y]
    · simp
  have hB : (∑ y, if y ∈ A then 0 else δK y) ≤ (∑ y, (ρ y)⁻¹) * bS A ρ δK := by
    rw [Finset.sum_mul]
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · exact mul_nonneg (inv_nonneg.2 (hρ0 y)) hbK
    · have hle : ρ y * δK y ≤ bS A ρ δK := by
        unfold bS
        have := Finset.single_le_sum (f := fun z => if z ∈ A then 0 else ρ z * δK z)
          (fun z _ => by
            show 0 ≤ (if z ∈ A then 0 else ρ z * δK z)
            split_ifs; exact le_rfl; exact mul_nonneg (hρ0 z) (hδK z)) (Finset.mem_univ y)
        simpa [hy] using this
      rw [inv_mul_eq_div, le_div_iff₀ (hρ y)]
      linarith
  have haK : aS A ρ δK ≤ ∑ y, ρ y * δ y := by linarith
  have h1 : aS A ρ δK / ρA ≤ (∑ y, ρ y * δ y) / ρA := div_le_div_of_nonneg_right haK hρA.le
  have hinv : 0 ≤ ∑ y, (ρ y)⁻¹ := Finset.sum_nonneg fun y _ => inv_nonneg.2 (hρ0 y)
  have h2 : (∑ y, (ρ y)⁻¹) * bS A ρ δK ≤ (∑ y, (ρ y)⁻¹) * (α ^ K * bS A ρ δ) :=
    mul_le_mul_of_nonneg_left hb hinv
  linarith

end Sweep

namespace LinkSpec

open MeasureTheory TorusRP Finset Filter SwapDecay

/-- **Covariance bound from an oscillation bound** (any finite measure with positive mass). -/
theorem cov_le {Ω : Type*} [MeasurableSpace Ω] [Nonempty Ω] (μ : Measure Ω) [IsFiniteMeasure μ]
    (hZ : 0 < ∫ _x, (1 : ℝ) ∂μ) (F H : Ω → ℝ) (hF : Measurable F) (hH : Measurable H)
    (cF : ℝ) (hFb : ∀ x, |F x| ≤ cF) (c S : ℝ) (hHS : ∀ x, |H x - c| ≤ S) :
    |(∫ x, F x * H x ∂μ) / (∫ _x, (1 : ℝ) ∂μ)
        - (∫ x, F x ∂μ) / (∫ _x, (1 : ℝ) ∂μ) * ((∫ x, H x ∂μ) / (∫ _x, (1 : ℝ) ∂μ))|
      ≤ 2 * cF * S := by
  set Z := ∫ _x, (1 : ℝ) ∂μ with hZdef
  have hZr : Z = μ.real Set.univ := by rw [hZdef]; simp
  have hS0 : 0 ≤ S := (abs_nonneg _).trans (hHS (Classical.arbitrary _))
  have hcF : 0 ≤ cF := (abs_nonneg _).trans (hFb (Classical.arbitrary _))
  have iF : Integrable F μ := Integrable.of_bound hF.aestronglyMeasurable cF
    (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hFb x)
  have iH : Integrable H μ := by
    have : Integrable (fun x => (H x - c) + c) μ :=
      (Integrable.of_bound (hH.sub measurable_const).aestronglyMeasurable S
        (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hHS x)).add
        (integrable_const c)
    simpa using this
  set e := (∫ x, F x ∂μ) / Z with hedef
  have he : |e| ≤ cF := by
    rw [hedef, abs_div, abs_of_pos hZ, div_le_iff₀ hZ]
    have := norm_integral_le_of_norm_le (integrable_const (μ := μ) cF)
      (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hFb x)
    rw [Real.norm_eq_abs, integral_const, smul_eq_mul, ← hZr] at this
    linarith
  have iFH : Integrable (fun x => F x * H x) μ := by
    refine Integrable.of_bound (hF.mul hH).aestronglyMeasurable (cF * (S + |c|))
      (Eventually.of_forall fun x => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have h1 : |H x| ≤ S + |c| := by
      have := hHS x
      have := abs_sub_abs_le_abs_sub (H x) c
      linarith
    exact mul_le_mul (hFb x) h1 (abs_nonneg _) hcF
  -- the centred product
  have iG : Integrable (fun x => (F x - e) * (H x - c)) μ := by
    refine Integrable.of_bound ((hF.sub measurable_const).mul (hH.sub measurable_const)).aestronglyMeasurable
      (2 * cF * S) (Eventually.of_forall fun x => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    have h1 : |F x - e| ≤ 2 * cF := (abs_sub _ _).trans (by linarith [hFb x])
    calc |F x - e| * |H x - c| ≤ (2 * cF) * S := mul_le_mul h1 (hHS x) (abs_nonneg _) (by linarith)
      _ = 2 * cF * S := by ring
  have hexp : ∫ x, (F x - e) * (H x - c) ∂μ
      = ∫ x, F x * H x ∂μ - e * ∫ x, H x ∂μ - c * ∫ x, F x ∂μ + e * c * Z := by
    have pt : ∀ x, (F x - e) * (H x - c) = ((F x * H x - e * H x) - c * F x) + e * c := fun x => by ring
    simp only [pt]
    have a1 : ∫ x, (F x * H x - e * H x) ∂μ = ∫ x, F x * H x ∂μ - ∫ x, e * H x ∂μ :=
      integral_sub iFH (iH.const_mul e)
    have a2 : ∫ x, ((F x * H x - e * H x) - c * F x) ∂μ
        = ∫ x, (F x * H x - e * H x) ∂μ - ∫ x, c * F x ∂μ :=
      integral_sub (iFH.sub (iH.const_mul e)) (iF.const_mul c)
    have a3 : ∫ x, (((F x * H x - e * H x) - c * F x) + e * c) ∂μ
        = ∫ x, ((F x * H x - e * H x) - c * F x) ∂μ + ∫ _x, e * c ∂μ :=
      integral_add ((iFH.sub (iH.const_mul e)).sub (iF.const_mul c)) (integrable_const _)
    have a4 : ∫ _x, e * c ∂μ = e * c * Z := by rw [hZr]; simp [mul_comm]
    rw [a3, a2, a1, integral_const_mul, integral_const_mul, a4]
  have hcFe : c * ∫ x, F x ∂μ = c * e * Z := by
    rw [hedef]; field_simp
  have hbound : |∫ x, (F x - e) * (H x - c) ∂μ| ≤ 2 * cF * S * Z := by
    have := norm_integral_le_of_norm_le (integrable_const (μ := μ) (2 * cF * S))
      (Eventually.of_forall fun x => by
        rw [Real.norm_eq_abs, abs_mul]
        have h1 : |F x - e| ≤ 2 * cF := (abs_sub _ _).trans (by linarith [hFb x])
        calc |F x - e| * |H x - c| ≤ (2 * cF) * S :=
              mul_le_mul h1 (hHS x) (abs_nonneg _) (by linarith)
          _ = 2 * cF * S := by ring)
    rw [Real.norm_eq_abs, integral_const, smul_eq_mul, ← hZr] at this
    linarith
  have key : (∫ x, F x * H x ∂μ) / Z - e * ((∫ x, H x ∂μ) / Z)
      = (∫ x, (F x - e) * (H x - c) ∂μ) / Z := by
    rw [hexp, hcFe]
    field_simp
    ring
  rw [key, abs_div, abs_of_pos hZ, div_le_iff₀ hZ]
  exact hbound

variable (N : ℕ) [NeZero N]

/-- the time distance of a link from `t₀` -/
def tdist (t₀ : ZMod N) (y : Lk N) : ℕ := cdist N (y.1 0 - t₀)

theorem coef_nonneg (β : ℝ) (x y : Lk N) : 0 ≤ coef N β x y := by
  unfold coef
  have : 1 ≤ Real.exp (2 * |β| * ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card) :=
    Real.one_le_exp (by positivity)
  exact div_nonneg (by linarith) (by linarith)

theorem coef_eq_zero (β : ℝ) (x y : Lk N)
    (h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card = 0) : coef N β x y = 0 := by
  unfold coef; rw [h]; simp

/-- neighbours (sharing a plaquette) are at time distance `≤ 1` -/
theorem tdist_lip (t₀ : ZMod N) (x y : Lk N)
    (h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0) :
    tdist N t₀ x ≤ tdist N t₀ y + 1 := by
  obtain ⟨p, hp⟩ := Finset.card_pos.1 (Nat.pos_of_ne_zero h)
  rw [Finset.mem_filter] at hp
  have hx : x ∈ plaqLinks N p := (Finset.mem_filter.1 hp.1).2
  obtain ⟨e, he, hpe⟩ := plaqLinks_time N p x hx
  obtain ⟨e', he', hqe⟩ := plaqLinks_time N p y hp.2
  have hq : x.1 0 - t₀ = (y.1 0 - t₀) + ((e - e' : ℤ) : ZMod N) := by
    push_cast; linear_combination hpe - hqe
  have h1 := cdist_add_le N (y.1 0 - t₀) ((e - e' : ℤ) : ZMod N)
  have h2 := cdist_intCast_le N (e - e')
  have h3 : (e - e').natAbs ≤ 1 := by rcases he with rfl | rfl <;> rcases he' with rfl | rfl <;> decide
  unfold tdist
  rw [hq]
  omega

/-- the weighted Dobrushin row condition with `ρ_y = e^{-λ d(y)}` -/
theorem row_weighted (β lam : ℝ) (hlam : 0 ≤ lam) (t₀ : ZMod N) (x : Lk N) :
    ∑ y ∈ univ.erase x, Real.exp (-(lam * tdist N t₀ y)) * coef N β x y
      ≤ (Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)))) *
          Real.exp (-(lam * tdist N t₀ x)) := by
  have hrow := dobrushin_row N β x
  have hterm : ∀ y ∈ univ.erase x, Real.exp (-(lam * tdist N t₀ y)) * coef N β x y
      ≤ (Real.exp lam * Real.exp (-(lam * tdist N t₀ x))) * coef N β x y := by
    intro y _
    by_cases h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card = 0
    · rw [coef_eq_zero N β x y h]; simp
    · refine mul_le_mul_of_nonneg_right ?_ (coef_nonneg N β x y)
      rw [← Real.exp_add]
      apply Real.exp_le_exp.2
      have := tdist_lip N t₀ x y h
      have : (tdist N t₀ x : ℝ) ≤ tdist N t₀ y + 1 := by exact_mod_cast this
      nlinarith
  calc _ ≤ ∑ y ∈ univ.erase x, (Real.exp lam * Real.exp (-(lam * tdist N t₀ x))) * coef N β x y :=
        Finset.sum_le_sum hterm
    _ = (Real.exp lam * Real.exp (-(lam * tdist N t₀ x))) * ∑ y ∈ univ.erase x, coef N β x y := by
        rw [Finset.mul_sum]
    _ ≤ (Real.exp lam * Real.exp (-(lam * tdist N t₀ x))) *
          (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) :=
        mul_le_mul_of_nonneg_left hrow (by positivity)
    _ = _ := by ring

/-- iterates of the sweep: invariance, product invariance, oscillation -/
theorem iter_props (β : ℝ) (L : List (Lk N)) :
    ∀ (K : ℕ) (G : (Lk N → QBall) → ℝ), Measurable G → ∀ cG : ℝ, (∀ ω, |G ω| ≤ cG) →
      ∀ δ : Lk N → ℝ, (∀ y, 0 ≤ δ y) →
      (∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |G ω - G ω'| ≤ δ y) →
      Measurable ((hbSweep N β L)^[K] G) ∧ (∀ ω, |(hbSweep N β L)^[K] G ω| ≤ cG) ∧
      ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
        |(hbSweep N β L)^[K] G ω - (hbSweep N β L)^[K] G ω'| ≤ ((Sweep.sweep (coef N β) L)^[K] δ) y
  | 0, G, hG, cG, hGb, δ, _, hosc => ⟨hG, hGb, hosc⟩
  | K + 1, G, hG, cG, hGb, δ, hδ, hosc => by
    obtain ⟨m1, b1, o1⟩ := hbSweep_osc N β L G hG cG hGb δ hδ hosc
    rw [Function.iterate_succ_apply, Function.iterate_succ_apply]
    exact iter_props β L K _ m1 cG b1 _ (Sweep.sweep_nonneg _ (coef_nonneg N β) L δ hδ) o1

theorem bound_osc (G : (Lk N → QBall) → ℝ) (cG : ℝ) (hGb : ∀ ω, |G ω| ≤ cG) :
    ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |G ω - G ω'| ≤ (fun _ => 2 * cG) y :=
  fun _ ω ω' _ => (abs_sub _ _).trans (by linarith [hGb ω, hGb ω'])

theorem iter_invariant (β : ℝ) (L : List (Lk N)) :
    ∀ (K : ℕ) (G : (Lk N → QBall) → ℝ), Measurable G → ∀ cG : ℝ, (∀ ω, |G ω| ≤ cG) →
      ∫ ω, (hbSweep N β L)^[K] G ω ∂(wilsonMeasure N β) = ∫ ω, G ω ∂(wilsonMeasure N β)
  | 0, _, _, _, _ => rfl
  | K + 1, G, hG, cG, hGb => by
    have hc : 0 ≤ cG := (abs_nonneg _).trans (hGb (fun _ => Classical.arbitrary QBall))
    obtain ⟨m1, b1, -⟩ := hbSweep_osc N β L G hG cG hGb (fun _ => 2 * cG) (fun _ => by linarith)
      (bound_osc N G cG hGb)
    rw [Function.iterate_succ_apply, iter_invariant β L K _ m1 cG b1]
    exact hbSweep_invariant N β L G hG cG hGb

theorem iter_mul_invariant (β : ℝ) (L : List (Lk N)) (F : (Lk N → QBall) → ℝ) (hF : Measurable F)
    (cF : ℝ) (hFb : ∀ ω, |F ω| ≤ cF) (hFL : ∀ x ∈ L, ∀ ω U, F (Function.update ω x U) = F ω) :
    ∀ (K : ℕ) (G : (Lk N → QBall) → ℝ), Measurable G → ∀ cG : ℝ, (∀ ω, |G ω| ≤ cG) →
      ∫ ω, F ω * (hbSweep N β L)^[K] G ω ∂(wilsonMeasure N β) = ∫ ω, F ω * G ω ∂(wilsonMeasure N β)
  | 0, _, _, _, _ => rfl
  | K + 1, G, hG, cG, hGb => by
    have hc : 0 ≤ cG := (abs_nonneg _).trans (hGb (fun _ => Classical.arbitrary QBall))
    obtain ⟨m1, b1, -⟩ := hbSweep_osc N β L G hG cG hGb (fun _ => 2 * cG) (fun _ => by linarith)
      (bound_osc N G cG hGb)
    rw [Function.iterate_succ_apply, iter_mul_invariant β L F hF cF hFb hFL K _ m1 cG b1]
    exact hbSweep_mul_invariant N β F hF cF hFb L hFL G hG cG hGb

/-- **Decay of the covariance with the time distance (Dobrushin, sweep form).**
`F` depends only on the links of `A` (time distance `≤ r` from `t₀`), `G` has single-link
oscillations `δ`.  If `e^λ · 18 tanh|β| < 1` then
`|E(FG) - E(F)E(G)| ≤ 2 c_F e^{λ r} Σ_y e^{-λ d(y)} δ_y`. -/
theorem wilson_cov_dist (β lam : ℝ) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) < 1)
    (t₀ : ZMod N) (r : ℕ) (A : Finset (Lk N)) (hA : ∀ ℓ ∈ A, tdist N t₀ ℓ ≤ r)
    (F G : (Lk N → QBall) → ℝ) (hF : Measurable F) (hG : Measurable G) (cF cG : ℝ)
    (hFb : ∀ ω, |F ω| ≤ cF) (hGb : ∀ ω, |G ω| ≤ cG)
    (hFdep : ∀ ω ω', (∀ i ∈ A, ω i = ω' i) → F ω = F ω')
    (δ : Lk N → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |G ω - G ω'| ≤ δ y) :
    |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => F ω * G ω)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * (Real.exp (lam * r) * ∑ y, Real.exp (-(lam * tdist N t₀ y)) * δ y) := by
  set α := Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) with hαdef
  have hα0 : 0 ≤ α := by
    have : 1 ≤ Real.exp (2 * |β|) := Real.one_le_exp (by positivity)
    rw [hαdef]
    exact mul_nonneg (Real.exp_pos _).le (mul_nonneg (by norm_num) (div_nonneg (by linarith) (by linarith)))
  set L : List (Lk N) := ((univ : Finset (Lk N)).filter (fun y => y ∉ A)).toList with hLdef
  have hnd : L.Nodup := Finset.nodup_toList _
  have hLA : ∀ x ∈ L, x ∉ A := fun x hx => (Finset.mem_filter.1 (Finset.mem_toList.1 hx)).2
  have hcov : ∀ y, y ∉ A → y ∈ L := fun y hy =>
    Finset.mem_toList.2 (Finset.mem_filter.2 ⟨Finset.mem_univ _, hy⟩)
  have hFL : ∀ x ∈ L, ∀ ω U, F (Function.update ω x U) = F ω := fun x hx ω U =>
    hFdep _ _ (fun i hi => by
      have : i ≠ x := fun h => hLA x hx (h ▸ hi)
      rw [Function.update_of_ne this])
  set ρ : Lk N → ℝ := fun y => Real.exp (-(lam * tdist N t₀ y)) with hρdef
  have hρ : ∀ y, 0 < ρ y := fun y => Real.exp_pos _
  have hρA : ∀ y ∈ A, Real.exp (-(lam * r)) ≤ ρ y := fun y hy => by
    apply Real.exp_le_exp.2
    have : (tdist N t₀ y : ℝ) ≤ r := by exact_mod_cast hA y hy
    nlinarith
  have hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * coef N β x y ≤ α * ρ x := fun x =>
    row_weighted N β lam hlam t₀ x
  have hZ : 0 < ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
    rw [integral_const, smul_eq_mul, mul_one, measureReal_def]
    exact ENNReal.toReal_pos (wilsonMeasure_univ_pos N β).ne' (wilsonMeasure_univ_lt_top N β).ne
  -- the bound for every number of sweeps
  have hK : ∀ K : ℕ,
      |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => F ω * G ω)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) +
          (∑ y, (ρ y)⁻¹) * (α ^ K * Sweep.bS A ρ δ)) := by
    intro K
    obtain ⟨mH, bH, oH⟩ := iter_props N β L K G hG cG hGb δ hδ hosc
    set H := (hbSweep N β L)^[K] G with hHdef
    have e1 := iter_mul_invariant N β L F hF cF hFb hFL K G hG cG hGb
    have e2 := iter_invariant N β L K G hG cG hGb
    rw [gibbs_eq, gibbs_eq, gibbs_eq, ← e1, ← e2]
    set ω₀ : Lk N → QBall := fun _ => Classical.arbitrary QBall
    have hrange : ∀ ω, |H ω - H ω₀| ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y := fun ω => by
      have := osc_total N H _ oH (univ : Finset (Lk N)).toList ω ω₀
        (fun ℓ hℓ => absurd (Finset.mem_toList.2 (Finset.mem_univ ℓ)) hℓ)
      rwa [Finset.sum_map_toList] at this
    have hc := cov_le (wilsonMeasure N β) hZ F H hF mH cF hFb (H ω₀) _ hrange
    refine hc.trans (mul_le_mul_of_nonneg_left ?_ ?_)
    · exact Sweep.iter_bound (coef N β) α hα0 hα.le (coef_nonneg N β) ρ hρ hrow A L hnd hLA hcov
        (Real.exp (-(lam * r))) (Real.exp_pos _) hρA δ hδ K
    · have := (abs_nonneg _).trans (hFb (fun _ => Classical.arbitrary QBall)); linarith
  -- let the number of sweeps go to infinity
  have hlim : Tendsto (fun K : ℕ => 2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) +
      (∑ y, (ρ y)⁻¹) * (α ^ K * Sweep.bS A ρ δ))) atTop
      (nhds (2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) + (∑ y, (ρ y)⁻¹) * (0 * Sweep.bS A ρ δ)))) :=
    ((((tendsto_pow_atTop_nhds_zero_of_lt_one hα0 hα).mul_const _).const_mul _).const_add _).const_mul _
  have := ge_of_tendsto' hlim hK
  rw [zero_mul, mul_zero, add_zero] at this
  refine this.trans_eq ?_
  rw [div_eq_mul_inv, ← Real.exp_neg, neg_neg, mul_comm (∑ y, ρ y * δ y)]

end LinkSpec

namespace TorusRP

open MeasureTheory LinkReflection LinkSpec Finset SwapDecay

variable (N : ℕ) [NeZero N]

/-- **The torus `hdec` from the Dobrushin distance decay** (same shape as `wilson_hdec_torus`;
window `e^λ · 18 tanh|β| < 1` instead of `24 (1 - e^{-4|β|}) < 1`, rate `e^{-λ(d+2)}`). -/
theorem wilson_hdec_torus_dob (M : ℕ) (hN : N = 2 * M) (β lam : ℝ) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) < 1)
    (k : ℕ) (t₀ : ZMod N) (r d : ℕ) (A A' : Finset (Lk N))
    (hA : ∀ ℓ ∈ A, cdist N (ℓ.1 0 - t₀) ≤ r)
    (hA' : ∀ ℓ ∈ A', r + 2 + d ≤ cdist N (ℓ.1 0 - t₀))
    (F : (Lk N → QBall) → ℝ) (cF : ℝ) (hFm : Measurable F) (hFC : ∀ x, |F x| ≤ cF)
    (hdepΘ : ∀ x y, (∀ i ∈ A, x i = y i) →
      F ((tShift N)^[k] (linkRefl (thL N) (sig N) x)) = F ((tShift N)^[k] (linkRefl (thL N) (sig N) y)))
    (hdepT : ∀ x y, (∀ i ∈ A', x i = y i) → F ((tShift N)^[k] x) = F ((tShift N)^[k] y)) :
    gibbs (fun _ : Lk N => haarBall) (plaqW N β)
        (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω)) * F ((tShift N)^[k] ω))
      - (gibbs (fun _ : Lk N => haarBall) (plaqW N β) F) ^ 2
      ≤ 2 * cF * (2 * cF * A'.card * Real.exp (-(lam * (d + 2)))) := by
  have hT : Measurable (tShift N) := (tShift_preserving N).measurable
  have hR : Measurable (linkRefl (thL N) (sig N)) := (linkRefl_preserving N).measurable
  have hFT : Measurable (fun ω => F ((tShift N)^[k] ω)) := hFm.comp (hT.iterate k)
  have hcF : 0 ≤ cF := (abs_nonneg _).trans (hFC (fun _ => Classical.arbitrary QBall))
  set δ : Lk N → ℝ := fun y => if y ∈ A' then 2 * cF else 0 with hδdef
  have hδ : ∀ y, 0 ≤ δ y := fun y => by rw [hδdef]; dsimp only; split_ifs <;> linarith
  have hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
      |F ((tShift N)^[k] ω) - F ((tShift N)^[k] ω')| ≤ δ y := by
    intro y ω ω' h
    rw [hδdef]; dsimp only
    split_ifs with hy
    · exact (abs_sub _ _).trans (by linarith [hFC ((tShift N)^[k] ω), hFC ((tShift N)^[k] ω')])
    · rw [hdepT ω ω' (fun i hi => h i (fun e => hy (e ▸ hi))), sub_self, abs_zero]
  have hc := wilson_cov_dist N β lam hlam hα t₀ r A hA
    (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω))) (fun ω => F ((tShift N)^[k] ω))
    (hFT.comp hR) hFT cF cF (fun x => hFC _) (fun x => hFC _) hdepΘ δ hδ hosc
  have e1 : gibbs (fun _ : Lk N => haarBall) (plaqW N β)
      (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω))) =
      gibbs (fun _ : Lk N => haarBall) (plaqW N β) F := by
    rw [gibbs_refl N M hN β (fun ω => F ((tShift N)^[k] ω)) hFT, gibbs_shift_iter N β F hFm k]
  have e2 := gibbs_shift_iter N β F hFm k
  rw [e1, e2] at hc
  have hsum : Real.exp (lam * r) * ∑ y, Real.exp (-(lam * tdist N t₀ y)) * δ y
      ≤ 2 * cF * A'.card * Real.exp (-(lam * (d + 2))) := by
    have hterm : ∀ y, Real.exp (-(lam * tdist N t₀ y)) * δ y
        ≤ (if y ∈ A' then Real.exp (-(lam * (r + 2 + d))) * (2 * cF) else 0) := fun y => by
      rw [hδdef]; dsimp only
      split_ifs with hy
      · refine mul_le_mul_of_nonneg_right (Real.exp_le_exp.2 ?_) (by linarith)
        have h0 : r + 2 + d ≤ tdist N t₀ y := hA' y hy
        have : ((r + 2 + d : ℕ) : ℝ) ≤ tdist N t₀ y := by exact_mod_cast h0
        push_cast at this
        nlinarith
      · simp
    have hs : ∑ y, Real.exp (-(lam * tdist N t₀ y)) * δ y
        ≤ A'.card * (Real.exp (-(lam * (r + 2 + d))) * (2 * cF)) := by
      refine (Finset.sum_le_sum fun y _ => hterm y).trans ?_
      rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, Finset.filter_mem_eq_inter,
        Finset.univ_inter]
    have hexp : Real.exp (lam * r) * Real.exp (-(lam * (r + 2 + d))) = Real.exp (-(lam * (d + 2))) := by
      rw [← Real.exp_add]; congr 1; ring
    calc Real.exp (lam * r) * ∑ y, Real.exp (-(lam * tdist N t₀ y)) * δ y
        ≤ Real.exp (lam * r) * (A'.card * (Real.exp (-(lam * (r + 2 + d))) * (2 * cF))) :=
          mul_le_mul_of_nonneg_left hs (Real.exp_pos _).le
      _ = 2 * cF * A'.card * (Real.exp (lam * r) * Real.exp (-(lam * (r + 2 + d)))) := by ring
      _ = _ := by rw [hexp]
  rw [sq]
  exact (le_abs_self _).trans (hc.trans (mul_le_mul_of_nonneg_left hsum (by linarith)))

end TorusRP

#print axioms Sweep.iter_bound
#print axioms LinkSpec.cov_le
#print axioms LinkSpec.row_weighted
#print axioms LinkSpec.wilson_cov_dist
#print axioms TorusRP.wilson_hdec_torus_dob
