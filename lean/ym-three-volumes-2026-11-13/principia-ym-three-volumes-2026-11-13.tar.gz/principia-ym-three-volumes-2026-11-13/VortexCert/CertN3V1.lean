import VortexCert.CoreV3
import VortexCert.DataN3V2

/-!
# `S_渦(3, 8) ≤ 909321/100000` と `S_3 < 2·3²`（太い渦は薄い渦より真に安い、N = 3）

紙：（`S_渦`・`S_N`、自明な上界 `S_N ≤ 2N²`）。数値（冷却）では `S_渦(3, 8) ≈ 9.09321`。
ここでは、冷却で得た配位を Cayley の媒介変数（`s = 2^16`）で有理数に丸めた配位（`tabN3`）の作用を、
升ごとに `2^32` を分母とする上への丸めで足した整数の和（`certSum`）を `decide +kernel` で評価し、
`Svortex_le_of_cert`（`CoreV1`）で実の作用の上界に写す。
-/

open Finset TwistedWilson TwistBlocks

namespace VortexCert

/-- 整数の和の不等式（核で評価） -/
theorem certN3 : certSum 3 8 16 32 tabN3 * 100000 ≤ 909321 * 2 ^ 32 := by
  decide +kernel

/-- **`S_渦(3, 8) ≤ 9.09321`**：枠を捩れた真空 V に止め、角の (3,4) の升を一枚反転した一辺 8 の塊の最小作用の上界 -/
theorem Svortex_three_eight_le : Svortex 3 8 ≤ (909321 : ℝ) / 100000 := by
  have h := Svortex_le_of_cert 3 8 16 32 tabN3 909321 100000 (by norm_num) (by exact_mod_cast certN3)
  exact_mod_cast h

/-- **`S_3 ≤ 9.09321`** -/
theorem SN_three_le : SN 3 ≤ (909321 : ℝ) / 100000 :=
  (SN_le_Svortex 3 ⟨8, by norm_num⟩).trans Svortex_three_eight_le

/-- **`S_3 < 2·3² = 8`**：太い渦の床の指数 `S_N` は、N = 3 で薄い渦の床の指数 `2N²` より真に小さい -/
theorem SN_three_lt : SN 3 < 2 * 3 ^ 2 := by
  have := SN_three_le
  linarith

end VortexCert

#print axioms VortexCert.certN3
#print axioms VortexCert.Svortex_three_eight_le
#print axioms VortexCert.SN_three_lt
