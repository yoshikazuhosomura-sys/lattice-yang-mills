import VortexCert.CoreV3
import VortexCert.DataN4V1

/-!
# `S_渦(4, 4) ≤ 1202057/100000` と `S_4 < 2·4²`（太い渦は薄い渦より真に安い、N = 4）

紙：（`S_渦`・`S_N`、自明な上界 `S_N ≤ 2N²`）。数値（冷却）では `S_渦(4, 4) ≈ 12.02057`。
ここでは、冷却で得た配位（V に小さい雑音を足した初期値から）を Cayley の媒介変数（`s = 2^16`）で有理数に丸めた配位（`tabN4`）の作用を、
升ごとに `2^32` を分母とする上への丸めで足した整数の和（`certSum`）を `decide +kernel` で評価し、
`Svortex_le_of_cert`（`CoreV1`）で実の作用の上界に写す。
-/

open Finset TwistedWilson TwistBlocks

namespace VortexCert

/-- 整数の和の不等式（核で評価） -/
theorem certN4 : certSum 4 4 16 32 tabN4 * 100000 ≤ 1202057 * 2 ^ 32 := by
  decide +kernel

/-- **`S_渦(4, 4) ≤ 12.02057`**：枠を捩れた真空 V に止め、角の (3,4) の升を一枚反転した一辺 4 の塊の最小作用の上界 -/
theorem Svortex_four_four_le : Svortex 4 4 ≤ (1202057 : ℝ) / 100000 := by
  have h := Svortex_le_of_cert 4 4 16 32 tabN4 1202057 100000 (by norm_num) (by exact_mod_cast certN4)
  exact_mod_cast h

/-- **`S_4 ≤ 12.02057`** -/
theorem SN_four_le : SN 4 ≤ (1202057 : ℝ) / 100000 :=
  (SN_le_Svortex 4 ⟨4, by norm_num⟩).trans Svortex_four_four_le

/-- **`S_4 < 2·4² = 32`**：太い渦の床の指数 `S_N` は、N = 4 で薄い渦の床の指数 `2N²` より真に小さい -/
theorem SN_four_lt : SN 4 < 2 * 4 ^ 2 := by
  have := SN_four_le
  linarith

end VortexCert

#print axioms VortexCert.certN4
#print axioms VortexCert.Svortex_four_four_le
#print axioms VortexCert.SN_four_lt
