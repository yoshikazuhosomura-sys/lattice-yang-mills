import Blocks.ThickFloorAttainV1

/-!
# 有理数の配位による `S_渦(N, m)` の上界の証明書（一般の部分）

紙： の `S_渦(N, m) = S^V_min(−)`（枠を捩れた真空 V に止め、塊の角の (3,4) の升を一枚反転した
塊の作用の下限）。Lean の定義は `TwistBlocks.Svortex`（格子 `(ZMod N)² × (ZMod (2m))²`、塊 `(0,0)`、`k = 2`）。

ここでは、内部のリンクを整数の媒介変数 `t ∈ ℤ³` と `s = 2^p` の Cayley の形
`q = (s² − |t|², 2s t) / (s² + |t|²)`（成分は有理数、ノルムはちょうど 1）で与えた配位について、
塊の作用の各項を整数の計算 `uZ`（`2^K` を分母とする上への丸め）で上から押さえる。
主定理 `Svortex_le_of_cert`：整数の和 `certSum` が `certSum · bd ≤ bn · 2^K` を満たせば `Svortex N m ≤ bn / bd`。
整数の和の不等式は具体の表について `decide +kernel` で確かめる（別のファイル）。
-/

open Finset BigOperators TwistedWilson TwistBlocks

namespace VortexCert

local notation "ℍr" => Quaternion ℝ

/-! ## 整数の四元数 -/

/-- 整数の成分の四元数 -/
structure ZQ where
  a : ℤ
  b : ℤ
  c : ℤ
  d : ℤ

/-- Hamilton の積（Mathlib の `Quaternion` の積と同じ約束） -/
def ZQ.mul (x y : ZQ) : ZQ :=
  ⟨x.a * y.a - x.b * y.b - x.c * y.c - x.d * y.d,
   x.a * y.b + x.b * y.a + x.c * y.d - x.d * y.c,
   x.a * y.c - x.b * y.d + x.c * y.a + x.d * y.b,
   x.a * y.d + x.b * y.c - x.c * y.b + x.d * y.a⟩

/-- 共役 -/
def ZQ.conj (x : ZQ) : ZQ := ⟨x.a, -x.b, -x.c, -x.d⟩

/-- 分母 `e` で割った実の四元数 -/
noncomputable def toH (x : ZQ) (e : ℤ) : ℍr := ⟨x.a / e, x.b / e, x.c / e, x.d / e⟩

theorem toH_re (x : ZQ) (e : ℤ) : (toH x e).re = (x.a : ℝ) / e := rfl
theorem toH_imI (x : ZQ) (e : ℤ) : (toH x e).imI = (x.b : ℝ) / e := rfl
theorem toH_imJ (x : ZQ) (e : ℤ) : (toH x e).imJ = (x.c : ℝ) / e := rfl
theorem toH_imK (x : ZQ) (e : ℤ) : (toH x e).imK = (x.d : ℝ) / e := rfl

theorem toH_mul (x y : ZQ) {e f : ℤ} (he : e ≠ 0) (hf : f ≠ 0) :
    toH x e * toH y f = toH (x.mul y) (e * f) := by
  have he' : (e : ℝ) ≠ 0 := by exact_mod_cast he
  have hf' : (f : ℝ) ≠ 0 := by exact_mod_cast hf
  ext <;> simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    toH_re, toH_imI, toH_imJ, toH_imK, ZQ.mul] <;> push_cast <;> field_simp <;> ring

theorem star_toH (x : ZQ) (e : ℤ) : star (toH x e) = toH x.conj e := by
  ext <;> simp only [Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star, Quaternion.imK_star,
    toH_re, toH_imI, toH_imJ, toH_imK, ZQ.conj] <;> push_cast <;> ring

theorem re_toH (x : ZQ) (e : ℤ) : (toH x e).re = (x.a : ℝ) / e := rfl

/-! ## Cayley の媒介変数 -/

/-- `t = (t₁,t₂,t₃)`、`s = 2^p`：分子 `(s² − |t|², 2s t₁, 2s t₂, 2s t₃)` -/
def cayQ (p : ℕ) (t : ℤ × ℤ × ℤ) : ZQ :=
  ⟨2 ^ p * 2 ^ p - (t.1 * t.1 + t.2.1 * t.2.1 + t.2.2 * t.2.2), 2 * 2 ^ p * t.1, 2 * 2 ^ p * t.2.1,
   2 * 2 ^ p * t.2.2⟩

/-- 分母 `s² + |t|²` -/
def cayD (p : ℕ) (t : ℤ × ℤ × ℤ) : ℤ := 2 ^ p * 2 ^ p + (t.1 * t.1 + t.2.1 * t.2.1 + t.2.2 * t.2.2)

theorem cayD_pos (p : ℕ) (t : ℤ × ℤ × ℤ) : 0 < cayD p t := by
  unfold cayD
  have h1 : (0 : ℤ) < 2 ^ p := by positivity
  nlinarith [mul_self_nonneg t.1, mul_self_nonneg t.2.1, mul_self_nonneg t.2.2]

/-- Cayley の形の四元数はノルムがちょうど 1（有理数の恒等式） -/
theorem normSq_cay (p : ℕ) (t : ℤ × ℤ × ℤ) : Quaternion.normSq (toH (cayQ p t) (cayD p t)) = 1 := by
  have hD : ((cayD p t : ℤ) : ℝ) ≠ 0 := by exact_mod_cast (cayD_pos p t).ne'
  rw [Quaternion.normSq_def']
  simp only [toH]
  rw [div_pow, div_pow, div_pow, div_pow, ← add_div, ← add_div, ← add_div, div_eq_one_iff_eq (pow_ne_zero 2 hD)]
  unfold cayQ cayD
  push_cast
  ring

/-! ## 格子の上の配位と升ごとの整数の上界 -/

instance twoMulNeZero (m : ℕ) [NeZero m] : NeZero (2 * m) := ⟨by have := NeZero.ne m; omega⟩

/-- 表の型：`[向き][x₁][x₂][x₃][x₄] ↦ t` -/
abbrev Tab := List (List (List (List (List (ℤ × ℤ × ℤ)))))

variable (N m : ℕ) [NeZero N] [NeZero m]

/-- 表を引く（範囲の外は 0） -/
def look (tab : Tab) (ℓ : Link N (2 * m)) : ℤ × ℤ × ℤ :=
  ((((tab.getD ℓ.2.val []).getD ℓ.1.1.1.val []).getD ℓ.1.1.2.val []).getD ℓ.1.2.1.val []).getD
    ℓ.1.2.2.val (0, 0, 0)

/-- 捩れた真空 V の整数の四元数（`vac` と同じ場合分け） -/
def vacZ (ℓ : Link N (2 * m)) : ZQ :=
  if ℓ.2 = 0 ∧ ℓ.1.1.1 = 0 then ⟨0, 1, 0, 0⟩ else if ℓ.2 = 1 ∧ ℓ.1.1.2 = 0 then ⟨0, 0, 1, 0⟩
  else ⟨1, 0, 0, 0⟩

/-- 貼った配位のリンク（分子と分母）：枠は V、塊 (0,0) の内部は表の Cayley の形、他は 1 -/
def linkQ (p : ℕ) (tab : Tab) (ℓ : Link N (2 * m)) : ZQ × ℤ :=
  if fr N (2 * m) m 2 ℓ then (vacZ N m ℓ, 1)
  else if blk2 (2 * m) m 2 ℓ.1.2 = (0, 0) then (cayQ p (look N m tab ℓ), cayD p (look N m tab ℓ))
  else (⟨1, 0, 0, 0⟩, 1)

/-- 背景 n₁₂ = 1 の符号（`zt N M true false` と同じ場合分け） -/
def zZ (B : Plaq N (2 * m)) : ℤ := if B.2 = p01 ∧ B.1.1 = 0 then -1 else 1

/-- 角の反転の符号（`etaB` と `etaSign … true` と同じ場合分け） -/
def eZ (B : Plaq N (2 * m)) : ℤ :=
  if B.2 = p23 then (if B.1.2 = corner (2 * m) m 2 (0, 0) then -1 else 1) else 1

/-- 四本のリンク（分子と分母）と符号 `σ` の升の作用 `1 − σ Re(A B C* D*)` の、`2^K` を分母とする
上への丸め（整数の分子） -/
def plaqU (K : ℕ) (σ : ℤ) (A Bq C D : ZQ × ℤ) : ℤ :=
  -((-((A.2 * Bq.2 * C.2 * D.2 - σ * (((A.1.mul Bq.1).mul C.1.conj).mul D.1.conj).a) * 2 ^ K))
    / (A.2 * Bq.2 * C.2 * D.2))

/-- 升 `B` の作用 `1 − z η Re U_B` の上への丸め -/
def uZ (p K : ℕ) (tab : Tab) (B : Plaq N (2 * m)) : ℤ :=
  plaqU K (zZ N m B * eZ N m B) (linkQ N m p tab (l1 N (2 * m) B)) (linkQ N m p tab (l2 N (2 * m) B))
    (linkQ N m p tab (l3 N (2 * m) B)) (linkQ N m p tab (l4 N (2 * m) B))

/-- 塊 (0,0) の升の上での和 -/
def certSum (p K : ℕ) (tab : Tab) : ℤ :=
  ∑ B ∈ univ.filter (fun B : Plaq N (2 * m) => blk2 (2 * m) m 2 B.1.2 = (0, 0)), uZ N m p K tab B

/-! ## 健全性 -/

theorem linkQ_pos (p : ℕ) (tab : Tab) (ℓ : Link N (2 * m)) : 0 < (linkQ N m p tab ℓ).2 := by
  unfold linkQ
  split_ifs
  · exact one_pos
  · exact cayD_pos p _
  · exact one_pos

/-- 有理数の配位の内部（塊 (0,0)） -/
noncomputable def yCert (p : ℕ) (tab : Tab) : Inner N (2 * m) m 2 (0, 0) → SU2 := fun j =>
  unitOf (toH (cayQ p (look N m tab j.1.1)) (cayD p (look N m tab j.1.1))) (normSq_cay p _)

/-- 貼った配位の各リンクは `linkQ` の実の四元数 -/
theorem glue_cert (p : ℕ) (tab : Tab) (ℓ : Link N (2 * m)) :
    (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) (yCert N m p tab) ℓ : ℍr)
      = toH (linkQ N m p tab ℓ).1 (linkQ N m p tab ℓ).2 := by
  unfold glueB BlockFubini.glue linkQ
  by_cases h : fr N (2 * m) m 2 ℓ
  · rw [dif_pos h, if_pos h]
    simp only [vac, vacZ]
    split_ifs <;>
      first
      | (show ((qI : SU2) : ℍr) = _; simp only [qI, unitOf, TwistedQ8.basis, toH]; ext <;> simp)
      | (show ((qJ : SU2) : ℍr) = _; simp only [qJ, unitOf, TwistedQ8.basis, toH]; ext <;> simp)
      | (show (((1 : SU2)) : ℍr) = _; ext <;> simp [toH, Quaternion.re_one, Quaternion.imI_one,
          Quaternion.imJ_one, Quaternion.imK_one])
  · rw [dif_neg h, if_neg h]
    by_cases hb : blk2 (2 * m) m 2 ℓ.1.2 = (0, 0)
    · have hb' : blkL N (2 * m) m 2 ⟨ℓ, h⟩ = (0, 0) := hb
      rw [dif_pos hb', if_pos hb]
      rfl
    · have hb' : ¬ blkL N (2 * m) m 2 ⟨ℓ, h⟩ = (0, 0) := hb
      rw [dif_neg hb', if_neg hb]
      ext <;> simp [toH, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one]

theorem zt_eq (B : Plaq N (2 * m)) : zt N (2 * m) true false B = (zZ N m B : ℝ) := by
  unfold zt zZ tw
  split_ifs <;> simp_all

theorem etaB_eq (B : Plaq N (2 * m)) :
    etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) B = (eZ N m B : ℝ) := by
  unfold etaB etaSign eZ etaAt
  split_ifs <;> simp_all

/-- 上への丸め：`D > 0` なら `a ≤ (−((−a) / D)) · D` -/
theorem ceil_mul_ge (a D : ℤ) (hD : 0 < D) : a ≤ (-((-a) / D)) * D := by
  have := Int.ediv_mul_le (-a) hD.ne'
  linarith [neg_mul ((-a) / D) D]

/-- 升ごとの上界 -/
theorem term_le (p K : ℕ) (tab : Tab) (B : Plaq N (2 * m)) :
    1 - zt N (2 * m) true false B * etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) B
        * (hol N (2 * m) (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) (yCert N m p tab)) B).re
      ≤ (uZ N m p K tab B : ℝ) / 2 ^ K := by
  set A := linkQ N m p tab (l1 N (2 * m) B)
  set Bq := linkQ N m p tab (l2 N (2 * m) B)
  set C := linkQ N m p tab (l3 N (2 * m) B)
  set D := linkQ N m p tab (l4 N (2 * m) B)
  have hA := linkQ_pos N m p tab (l1 N (2 * m) B)
  have hB := linkQ_pos N m p tab (l2 N (2 * m) B)
  have hC := linkQ_pos N m p tab (l3 N (2 * m) B)
  have hD := linkQ_pos N m p tab (l4 N (2 * m) B)
  have hhol : hol N (2 * m) (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) (yCert N m p tab)) B
      = toH (((A.1.mul Bq.1).mul C.1.conj).mul D.1.conj) (A.2 * Bq.2 * C.2 * D.2) := by
    unfold hol
    rw [glue_cert, glue_cert, glue_cert, glue_cert, star_toH, star_toH,
      toH_mul _ _ hA.ne' hB.ne', toH_mul _ _ (mul_pos hA hB).ne' hC.ne',
      toH_mul _ _ (mul_pos (mul_pos hA hB) hC).ne' hD.ne']
  rw [hhol, re_toH, zt_eq, etaB_eq]
  set R := (((A.1.mul Bq.1).mul C.1.conj).mul D.1.conj).a
  set Dn := A.2 * Bq.2 * C.2 * D.2
  have hDn : 0 < Dn := mul_pos (mul_pos (mul_pos hA hB) hC) hD
  have hu : uZ N m p K tab B = -((-((Dn - zZ N m B * eZ N m B * R) * 2 ^ K)) / Dn) := rfl
  have hc := ceil_mul_ge ((Dn - zZ N m B * eZ N m B * R) * 2 ^ K) Dn hDn
  rw [← hu] at hc
  have hc' : (((Dn - zZ N m B * eZ N m B * R) * 2 ^ K : ℤ) : ℝ) ≤ ((uZ N m p K tab B * Dn : ℤ) : ℝ) := by
    exact_mod_cast hc
  push_cast at hc'
  have hDnR : (0 : ℝ) < Dn := by exact_mod_cast hDn
  have h2K : (0 : ℝ) < 2 ^ K := by positivity
  rw [le_div_iff₀ h2K]
  have key : (1 - (zZ N m B : ℝ) * (eZ N m B : ℝ) * ((R : ℝ) / (Dn : ℝ))) * 2 ^ K
      = ((Dn : ℝ) - zZ N m B * eZ N m B * R) * 2 ^ K / Dn := by
    field_simp
  rw [key, div_le_iff₀ hDnR]
  linarith

/-- **主定理（一般の形）**：整数の和の不等式 `certSum · bd ≤ bn · 2^K` から `S_渦(N, m) ≤ bn / bd`。
示している上界は、枠が真空 V に等しく角の一枚を反転した類（`Svortex` の定義の inf の範囲）の
一つの配位 `glueB … (yCert …)` の作用についてのもの。 -/
theorem Svortex_le_of_cert (p K : ℕ) (tab : Tab) (bn bd : ℕ) (hbd : 0 < bd)
    (h : certSum N m p K tab * bd ≤ bn * 2 ^ K) : Svortex N m ≤ (bn : ℝ) / bd := by
  unfold Svortex Smin
  refine (ciInf_le (bdd_Smin N (2 * m) m 2 (0, 0) _ true) (yCert N m p tab)).trans ?_
  unfold actB
  have hsum := Finset.sum_le_sum fun B (_ : B ∈ univ.filter
      (fun B : Plaq N (2 * m) => blk2 (2 * m) m 2 B.1.2 = (0, 0))) => term_le N m p K tab B
  refine hsum.trans ?_
  rw [← Finset.sum_div]
  have hcast : ((certSum N m p K tab * bd : ℤ) : ℝ) ≤ ((bn * 2 ^ K : ℤ) : ℝ) := by exact_mod_cast h
  push_cast at hcast
  unfold certSum at hcast
  push_cast at hcast
  have h2K : (0 : ℝ) < 2 ^ K := by positivity
  have hbdR : (0 : ℝ) < bd := by exact_mod_cast hbd
  rw [div_le_div_iff₀ h2K hbdR]
  linarith

/-- `S_N ≤ S_渦(N, m)` -/
theorem SN_le_Svortex (m : ℕ+) : SN N ≤ Svortex N (m : ℕ) := by
  have hbdd : BddBelow (Set.range fun j : ℕ+ => Svortex N (j : ℕ)) :=
    ⟨0, by rintro _ ⟨j, rfl⟩; exact Svortex_nonneg N j⟩
  exact ciInf_le hbdd m

end VortexCert

#print axioms VortexCert.Svortex_le_of_cert
#print axioms VortexCert.SN_le_Svortex
