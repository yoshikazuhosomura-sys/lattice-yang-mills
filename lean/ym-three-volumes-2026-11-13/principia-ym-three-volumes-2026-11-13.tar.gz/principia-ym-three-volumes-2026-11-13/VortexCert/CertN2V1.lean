import VortexCert.CoreV3
import VortexCert.DataN2V2

/-!
# `S_渦(2, 8) ≤ 667401/100000` と `S_2 < 2·2²`（太い渦は薄い渦より真に安い、N = 2）

紙：（`S_渦`・`S_N`、自明な上界 `S_N ≤ 2N²`）。数値（冷却）では `S_渦(2, 8) ≈ 6.67401`。
ここでは、冷却で得た配位を Cayley の媒介変数（`s = 2^16`）で有理数に丸めた配位（`tabN2`）の作用を、
升ごとに `2^32` を分母とする上への丸めで足した整数の和（`certSum`）を `decide +kernel` で評価し、
`Svortex_le_of_cert`（`CoreV1`）で実の作用の上界に写す。
-/

open Finset TwistedWilson TwistBlocks

namespace VortexCert

/-- 整数の和の不等式（核で評価） -/
theorem certN2 : certSum 2 8 16 32 tabN2 * 100000 ≤ 667401 * 2 ^ 32 := by
  decide +kernel

/-- **`S_渦(2, 8) ≤ 6.67401`**：枠を捩れた真空 V に止め、角の (3,4) の升を一枚反転した一辺 8 の塊の最小作用の上界 -/
theorem Svortex_two_eight_le : Svortex 2 8 ≤ (667401 : ℝ) / 100000 := by
  have h := Svortex_le_of_cert 2 8 16 32 tabN2 667401 100000 (by norm_num) (by exact_mod_cast certN2)
  exact_mod_cast h

/-- **`S_2 ≤ 6.67401`** -/
theorem SN_two_le : SN 2 ≤ (667401 : ℝ) / 100000 :=
  (SN_le_Svortex 2 ⟨8, by norm_num⟩).trans Svortex_two_eight_le

/-- **`S_2 < 2·2² = 8`**：太い渦の床の指数 `S_N` は、N = 2 で薄い渦の床の指数 `2N²` より真に小さい -/
theorem SN_two_lt : SN 2 < 2 * 2 ^ 2 := by
  have := SN_two_le
  linarith

end VortexCert

#print axioms VortexCert.certN2
#print axioms VortexCert.Svortex_two_eight_le
#print axioms VortexCert.SN_two_lt
