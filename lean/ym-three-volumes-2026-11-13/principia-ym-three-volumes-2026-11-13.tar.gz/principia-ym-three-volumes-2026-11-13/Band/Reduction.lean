import Mathlib

/-!
# The band reduction (13-02, Theorem 1) including the jump step

`θ R L` : sector bias of a container of planar size `R` with transverse torus of side `L`.
Hypotheses (A) base, (B) nesting, (C) transverse widening (strong form).
Conclusion: along the dyadic scales `R_k = 2^k s L₀`, `c θ_k ≤ (c t₀)^(4^k)` with `c³ = 4 C C_D`,
and the area-exponent form `4^k log (1/(c t₀)) ≤ log (1/θ_k)`.
Only the inequalities between real numbers are formalised; that the actual biases satisfy
(A)(B)(C) is outside this file.
-/

namespace BandReduction

structure Hyp (θ : ℕ → ℕ → ℝ) (L₀ : ℕ) (ε₀ C_D C : ℝ) : Prop where
  nonneg : ∀ R L, 0 ≤ θ R L
  base   : θ L₀ L₀ ≤ 1 - ε₀
  nest   : ∀ R L n, θ (n * R) L ≤ C_D * θ R L ^ (n ^ 2)
  widen  : ∀ R L L', 0 < L → L ≤ L' → L' ≤ R → θ R L' ≤ C * ((L' : ℝ) / L) ^ 2 * θ R L

/-- the dyadic scales `2^k s L₀` -/
def scale (L₀ s k : ℕ) : ℕ := 2 ^ k * (s * L₀)

/-- the jump: one application of (B) and one of (C) from the base scale. -/
theorem jump {θ : ℕ → ℕ → ℝ} {L₀ : ℕ} {ε₀ C_D C : ℝ} (h : Hyp θ L₀ ε₀ C_D C)
    (hL : 0 < L₀) {s : ℕ} (hs : 1 ≤ s) (hC : 0 ≤ C) (hCD : 0 ≤ C_D) :
    θ (s * L₀) (s * L₀) ≤ C * (s : ℝ) ^ 2 * (C_D * (1 - ε₀) ^ (s ^ 2)) := by
  have h1 : θ (s * L₀) L₀ ≤ C_D * (1 - ε₀) ^ (s ^ 2) := by
    calc θ (s * L₀) L₀ ≤ C_D * θ L₀ L₀ ^ (s ^ 2) := h.nest L₀ L₀ s
      _ ≤ C_D * (1 - ε₀) ^ (s ^ 2) := by
        apply mul_le_mul_of_nonneg_left _ hCD
        exact pow_le_pow_left₀ (h.nonneg _ _) h.base _
  have hle : L₀ ≤ s * L₀ := Nat.le_mul_of_pos_left L₀ hs
  have h2 := h.widen (s * L₀) L₀ (s * L₀) hL hle le_rfl
  have hq : ((s * L₀ : ℕ) : ℝ) / (L₀ : ℝ) = s := by
    have : (L₀ : ℝ) ≠ 0 := by exact_mod_cast hL.ne'
    push_cast; field_simp
  rw [hq] at h2
  calc θ (s * L₀) (s * L₀) ≤ C * (s : ℝ) ^ 2 * θ (s * L₀) L₀ := h2
    _ ≤ C * (s : ℝ) ^ 2 * (C_D * (1 - ε₀) ^ (s ^ 2)) := by
      apply mul_le_mul_of_nonneg_left h1; positivity

/-- one doubling step: `t_{k+1} ≤ 4 C C_D t_k^4`. -/
theorem step {θ : ℕ → ℕ → ℝ} {L₀ : ℕ} {ε₀ C_D C : ℝ} (h : Hyp θ L₀ ε₀ C_D C)
    (hC : 0 ≤ C) {s : ℕ} (hR : 0 < s * L₀) (k : ℕ) :
    θ (scale L₀ s (k + 1)) (scale L₀ s (k + 1))
      ≤ 4 * C * C_D * θ (scale L₀ s k) (scale L₀ s k) ^ 4 := by
  have hRpos : 0 < scale L₀ s k := by unfold scale; positivity
  have hS : scale L₀ s (k + 1) = 2 * scale L₀ s k := by unfold scale; ring
  rw [hS]
  set R := scale L₀ s k
  have h1 : θ (2 * R) R ≤ C_D * θ R R ^ 4 := by
    have := h.nest R R 2; simpa using this
  have h2 := h.widen (2 * R) R (2 * R) hRpos (by omega) le_rfl
  have hq : ((2 * R : ℕ) : ℝ) / (R : ℝ) = 2 := by
    have : (R : ℝ) ≠ 0 := by exact_mod_cast hRpos.ne'
    push_cast; field_simp
  rw [hq] at h2
  calc θ (2 * R) (2 * R) ≤ C * (2:ℝ) ^ 2 * θ (2 * R) R := h2
    _ ≤ C * (2:ℝ) ^ 2 * (C_D * θ R R ^ 4) := by
      apply mul_le_mul_of_nonneg_left h1; positivity
    _ = 4 * C * C_D * θ R R ^ 4 := by ring

/-- the iteration `c t_{k+1} ≤ (c t_k)^4` when `c^3 = K`. -/
theorem iterate (c K : ℝ) (t : ℕ → ℝ) (hc : 0 ≤ c) (hK : c ^ 3 = K) (ht : ∀ k, 0 ≤ t k)
    (hrec : ∀ k, t (k + 1) ≤ K * t k ^ 4) (k : ℕ) : c * t k ≤ (c * t 0) ^ (4 ^ k) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have h0 : 0 ≤ c * t k := mul_nonneg hc (ht k)
    calc c * t (k + 1) ≤ c * (K * t k ^ 4) := mul_le_mul_of_nonneg_left (hrec k) hc
      _ = (c * t k) ^ 4 := by rw [← hK]; ring
      _ ≤ ((c * t 0) ^ (4 ^ k)) ^ 4 := pow_le_pow_left₀ h0 ih 4
      _ = (c * t 0) ^ (4 ^ (k + 1)) := by rw [← pow_mul, pow_succ]

/-- Theorem 1 of 13-02 (strong form), multiplicative version. -/
theorem band_reduction {θ : ℕ → ℕ → ℝ} {L₀ : ℕ} {ε₀ C_D C c : ℝ} (h : Hyp θ L₀ ε₀ C_D C)
    (hL : 0 < L₀) {s : ℕ} (hs : 1 ≤ s) (hC : 0 ≤ C) (hCD : 0 ≤ C_D) (hc : 0 ≤ c)
    (hK : c ^ 3 = 4 * C * C_D) (k : ℕ) :
    c * θ (scale L₀ s k) (scale L₀ s k)
      ≤ (c * (C * (s : ℝ) ^ 2 * (C_D * (1 - ε₀) ^ (s ^ 2)))) ^ (4 ^ k) := by
  have hR : 0 < s * L₀ := Nat.mul_pos (by omega) hL
  have hit := iterate c (4 * C * C_D) (fun k => θ (scale L₀ s k) (scale L₀ s k)) hc hK
    (fun k => h.nonneg _ _) (fun k => step h hC hR k) k
  have h0 : scale L₀ s 0 = s * L₀ := by unfold scale; simp
  simp only [h0] at hit
  refine le_trans hit ?_
  apply pow_le_pow_left₀ (mul_nonneg hc (h.nonneg _ _))
  exact mul_le_mul_of_nonneg_left (jump h hL hs hC hCD) hc

/-- area-exponent form: if `1 ≤ c` and `0 < c t₀ < 1` then `4^k log(1/(c t₀)) ≤ log (1/θ_k)`. -/
theorem area_exponent {c T θk : ℝ} (hc : 1 ≤ c) (hT : 0 < c * T) (hT1 : c * T < 1)
    (hθ : 0 < θk) (k : ℕ) (hb : c * θk ≤ (c * T) ^ (4 ^ k)) :
    (4 : ℝ) ^ k * Real.log (1 / (c * T)) ≤ Real.log (1 / θk) := by
  have hcθ : 0 < c * θk := by positivity
  have h1 : Real.log (c * θk) ≤ Real.log ((c * T) ^ (4 ^ k)) := Real.log_le_log hcθ hb
  rw [Real.log_pow] at h1
  have h2 : Real.log θk ≤ Real.log (c * θk) := by
    apply Real.log_le_log hθ; nlinarith
  rw [one_div, Real.log_inv, one_div, Real.log_inv]
  push_cast at h1
  nlinarith

end BandReduction

#print axioms BandReduction.band_reduction
#print axioms BandReduction.area_exponent
