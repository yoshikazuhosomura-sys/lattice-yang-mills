import Mathlib

/-!
# The band as a finite-size criterion plus a small-bias widening inequality

Replace the base (A) + jump by one finite-size number `θ R₀ R₀ ≤ t₀`, and use the widening
inequality (C) only at doubling steps (`L' = 2L`, container `2L`) where the bias is already
small (`θ (2L) L ≤ δ`).  Together with (B) at `s = 2` this gives the doubling bound on all
dyadic scales `2^k R₀`.
-/

namespace BandFiniteSize

structure Hyp (θ : ℕ → ℕ → ℝ) (C_D C δ : ℝ) : Prop where
  nonneg : ∀ R L, 0 ≤ θ R L
  nest2  : ∀ L, θ (2 * L) L ≤ C_D * θ L L ^ 4
  widenSmall : ∀ L, 0 < L → θ (2 * L) L ≤ δ → θ (2 * L) (2 * L) ≤ 4 * C * θ (2 * L) L

theorem doubling {θ : ℕ → ℕ → ℝ} {C_D C δ c t₀ : ℝ} {R₀ : ℕ} (h : Hyp θ C_D C δ)
    (hR : 0 < R₀) (hC : 0 ≤ C) (hCD : 0 ≤ C_D) (hc : 1 ≤ c) (hK : c ^ 3 = 4 * C * C_D)
    (hF : θ R₀ R₀ ≤ t₀) (hct : c * t₀ ≤ 1) (hδ : C_D * t₀ ^ 4 ≤ δ) :
    ∀ k, θ (2 ^ k * R₀) (2 ^ k * R₀) ≤ t₀ ∧
      c * θ (2 ^ k * R₀) (2 ^ k * R₀) ≤ (c * t₀) ^ (4 ^ k) := by
  intro k
  induction k with
  | zero =>
    simp only [pow_zero, one_mul]
    exact ⟨hF, by
      have := mul_le_mul_of_nonneg_left hF (by linarith : (0:ℝ) ≤ c); simpa using this⟩
  | succ k ih =>
    obtain ⟨h1, h2⟩ := ih
    set L := 2 ^ k * R₀ with hL
    have hLpos : 0 < L := by rw [hL]; positivity
    have hS : 2 ^ (k + 1) * R₀ = 2 * L := by rw [hL]; ring
    rw [hS]
    have ht0 : 0 ≤ θ L L := h.nonneg L L
    have hn := h.nest2 L
    have hsmall : θ (2 * L) L ≤ δ := by
      calc θ (2 * L) L ≤ C_D * θ L L ^ 4 := hn
        _ ≤ C_D * t₀ ^ 4 := by
          apply mul_le_mul_of_nonneg_left _ hCD
          exact pow_le_pow_left₀ ht0 h1 4
        _ ≤ δ := hδ
    have hw := h.widenSmall L hLpos hsmall
    have hrec : θ (2 * L) (2 * L) ≤ c ^ 3 * θ L L ^ 4 := by
      rw [hK]
      calc θ (2 * L) (2 * L) ≤ 4 * C * θ (2 * L) L := hw
        _ ≤ 4 * C * (C_D * θ L L ^ 4) := by
          apply mul_le_mul_of_nonneg_left hn; positivity
        _ = 4 * C * C_D * θ L L ^ 4 := by ring
    have hc0 : 0 ≤ c := by linarith
    have hct0 : 0 ≤ c * θ L L := mul_nonneg hc0 ht0
    have hmain : c * θ (2 * L) (2 * L) ≤ (c * θ L L) ^ 4 := by
      calc c * θ (2 * L) (2 * L) ≤ c * (c ^ 3 * θ L L ^ 4) :=
            mul_le_mul_of_nonneg_left hrec hc0
        _ = (c * θ L L) ^ 4 := by ring
    have hle1 : c * θ L L ≤ 1 := by
      calc c * θ L L ≤ c * t₀ := mul_le_mul_of_nonneg_left h1 hc0
        _ ≤ 1 := hct
    constructor
    · -- θ_{k+1} ≤ (cθ_k)^4 / c ≤ cθ_k / c = θ_k ≤ t₀
      have h4 : (c * θ L L) ^ 4 ≤ c * θ L L := by
        calc (c * θ L L) ^ 4 ≤ (c * θ L L) ^ 1 :=
              pow_le_pow_of_le_one hct0 hle1 (by norm_num)
          _ = c * θ L L := pow_one _
      have : c * θ (2 * L) (2 * L) ≤ c * t₀ := by
        calc c * θ (2 * L) (2 * L) ≤ c * θ L L := le_trans hmain h4
          _ ≤ c * t₀ := mul_le_mul_of_nonneg_left h1 hc0
      exact le_of_mul_le_mul_left this (by linarith)
    · calc c * θ (2 * L) (2 * L) ≤ (c * θ L L) ^ 4 := hmain
        _ ≤ ((c * t₀) ^ (4 ^ k)) ^ 4 := pow_le_pow_left₀ hct0 h2 4
        _ = (c * t₀) ^ (4 ^ (k + 1)) := by rw [← pow_mul, pow_succ]

end BandFiniteSize

#print axioms BandFiniteSize.doubling
