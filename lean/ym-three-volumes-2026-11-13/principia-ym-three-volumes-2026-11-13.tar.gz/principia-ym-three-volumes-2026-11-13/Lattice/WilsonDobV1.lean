import Sweep.DistDecayV1
import Lattice.NondegV3

/-!
# Mass gap with non-degeneracy in the Dobrushin window `18 tanh|β| < 1`

Paper correspondence: (the field `hdec` of statement G from the distance decay
`TorusRP.wilson_hdec_torus_dob`) and (non-degeneracy).
* `WilsonLimit.dec_eventually_dob` : `hdec` with rate `e^{-2λk}` whenever `e^λ · 18 tanh|β| < 1`.
* `WilsonLimit.wilson_massGap_dob` : at every weak limit point, `‖T - P_Ω‖ ≤ e^{-λ}`, the reflected
  variance of `Re x_{ℓ₀}` is `≥ e^{-12|β|}/4`, and a unit vector orthogonal to the vacuum exists.
* `WilsonLimit.wilson_massGap_dob_exists` : with `m = -ln(18 tanh|β|)/2`, for `β ≠ 0` and
  `18 tanh|β| < 1` (for instance `|β| < 1/19`, `dob_window_strict`).
Formalisation of a known result (strong-coupling mass gap, Dobrushin–Osterwalder–Seiler type).
-/

namespace WilsonLimit

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open scoped BoundedContinuousFunction InnerProductSpace

/-- the Dobrushin constant `18 tanh|β|` in the form used by the sweep lemmas -/
noncomputable def dobConst (β : ℝ) : ℝ := 18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))

/-- (b′) `hdec` for `F ∈ W` from the Dobrushin distance decay: rate `e^{-2λk}`, constant
`max(‖F‖², 4‖F‖²|S|)` (independent of `n` and `k`). -/
theorem dec_eventually_dob (β lam : ℝ) (hlam : 0 ≤ lam) (hα : Real.exp lam * dobConst β < 1)
    (F : Cfg →ᵇ ℝ) (hF : F ∈ Wsub) :
    ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ n in atTop,
      ∫ x, F (zShift^[k] (zRefl x)) * F (zShift^[k] x) ∂(liftProb β n : Measure Cfg)
        - (∫ x, F x ∂(liftProb β n : Measure Cfg)) ^ 2
        ≤ C * Real.exp (-(2 * lam * k)) := by
  obtain ⟨S, R, hSR, hdep⟩ := (mem_Wsub F).1 hF
  refine ⟨max (‖F‖ * ‖F‖) (4 * ‖F‖ * ‖F‖ * S.card), fun k => ?_⟩
  by_cases hk : k = 0
  · subst hk
    refine Eventually.of_forall (fun n => ?_)
    simp only [Nat.cast_zero, mul_zero, neg_zero, Real.exp_zero, mul_one]
    exact (pair_sub_sq_le _ F _ _ ((continuous_zShift.iterate 0).comp continuous_zRefl)
      (continuous_zShift.iterate 0)).trans (le_max_left _ _)
  · filter_upwards [eventually_ge_atTop (2 * k + 2 * R + 1)] with n hn
    have h1 := integral_lift β n (fun x => F (zShift^[k] (zRefl x)) * F (zShift^[k] x))
      ((F.continuous.comp ((continuous_zShift.iterate k).comp continuous_zRefl)).mul
        (F.continuous.comp (continuous_zShift.iterate k)))
    have h2 := integral_lift β n (fun x => F x) F.continuous
    simp only [zRefl_lift, zShift_iter_lift] at h1
    rw [h1, h2, integral_wilsonProb_gibbs, integral_wilsonProb_gibbs]
    have hA : ∀ ℓ' ∈ S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ))),
        cdist (Nn n) (ℓ'.1 0 - (((-((k : ℤ) + R + 1)) : ℤ) : ZMod (Nn n))) ≤ R + 1 := by
      intro ℓ' hℓ'
      obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
      obtain ⟨h0, h1'⟩ := hSR ℓ hℓ
      rw [proj_time, ← Int.cast_sub]
      refine (cdist_intCast_le (Nn n) _).trans ?_
      rw [zthL_time, zsh_snd, zsh_time]
      split_ifs <;> omega
    have hA' : ∀ ℓ' ∈ S.image (fun ℓ => zproj (Nn n) (zsh k ℓ)),
        R + 1 + 2 + (2 * k - 2) ≤
          cdist (Nn n) (ℓ'.1 0 - (((-((k : ℤ) + R + 1)) : ℤ) : ZMod (Nn n))) := by
      intro ℓ' hℓ'
      obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
      obtain ⟨h0, h1'⟩ := hSR ℓ hℓ
      have hj0 : 0 ≤ ℓ.1 0 + (k : ℤ) - -((k : ℤ) + R + 1) := by omega
      have hj1 : (ℓ.1 0 + (k : ℤ) - -((k : ℤ) + R + 1)).toNat ≤ Nn n / 2 := by
        rw [Nn_half]; omega
      rw [proj_time, ← Int.cast_sub, zsh_time, cdist_intCast_eq (Nn n) _ hj0 hj1]
      omega
    have hdepΘ : ∀ x y : Lk (Nn n) → QBall,
        (∀ i ∈ S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ))), x i = y i) →
        (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] (linkRefl (thL (Nn n)) (sig (Nn n)) x))
          = (fun ω => F (perLift (Nn n) ω))
              ((tShift (Nn n))^[k] (linkRefl (thL (Nn n)) (sig (Nn n)) y)) := by
      intro x y hxy
      simp only [← zShift_iter_lift, ← zRefl_lift]
      apply hdep
      intro ℓ hℓ
      rw [zShift_iter_apply, zShift_iter_apply]
      show zsig (zsh k ℓ) (x (zproj (Nn n) (zthL (zsh k ℓ))))
        = zsig (zsh k ℓ) (y (zproj (Nn n) (zthL (zsh k ℓ))))
      rw [hxy _ (Finset.mem_image_of_mem _ hℓ)]
    have hdepT : ∀ x y : Lk (Nn n) → QBall,
        (∀ i ∈ S.image (fun ℓ => zproj (Nn n) (zsh k ℓ)), x i = y i) →
        (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] x)
          = (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] y) := by
      intro x y hxy
      simp only [← zShift_iter_lift]
      apply hdep
      intro ℓ hℓ
      rw [zShift_iter_apply, zShift_iter_apply]
      exact hxy _ (Finset.mem_image_of_mem _ hℓ)
    have key := wilson_hdec_torus_dob (Nn n) (n + 1) rfl β lam hlam hα k _ (R + 1) (2 * k - 2) _ _
      hA hA' (fun ω => F (perLift (Nn n) ω)) ‖F‖
      ((F.continuous.comp (continuous_perLift _)).measurable)
      (fun ω => abs_le_norm' F _) hdepΘ hdepT
    have hd : (((2 * k - 2 : ℕ) : ℝ) + 2) = 2 * (k : ℝ) := by
      have h2k : 2 ≤ 2 * k := by omega
      rw [Nat.cast_sub h2k]
      push_cast
      ring
    rw [hd] at key
    refine le_trans key ?_
    have hA'c : ((S.image (fun ℓ => zproj (Nn n) (zsh k ℓ))).card : ℝ) ≤ S.card := by
      exact_mod_cast Finset.card_image_le
    have he : Real.exp (-(lam * (2 * (k : ℝ)))) = Real.exp (-(2 * lam * k)) := by
      congr 1; ring
    rw [he]
    have hF0 : 0 ≤ 4 * ‖F‖ * ‖F‖ := by positivity
    calc 2 * ‖F‖ * (2 * ‖F‖ * ((S.image (fun ℓ => zproj (Nn n) (zsh k ℓ))).card : ℝ) *
          Real.exp (-(2 * lam * k)))
        = (4 * ‖F‖ * ‖F‖ * ((S.image (fun ℓ => zproj (Nn n) (zsh k ℓ))).card : ℝ)) *
            Real.exp (-(2 * lam * k)) := by ring
      _ ≤ (4 * ‖F‖ * ‖F‖ * S.card) * Real.exp (-(2 * lam * k)) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hA'c hF0) (Real.exp_pos _).le
      _ ≤ _ := mul_le_mul_of_nonneg_right (le_max_right _ _) (Real.exp_pos _).le

/-- **Mass gap with non-degeneracy at every weak limit point, Dobrushin window.**
For `λ > 0` with `e^λ · 18 tanh|β| < 1`: `‖T - P_Ω‖ ≤ e^{-λ}`, the reflected variance of
`F₀ = Re x_{ℓ₀}` is at least `e^{-12|β|}/4`, and the orthogonal complement of the vacuum is not
zero.  -/
theorem wilson_massGap_dob (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
      ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨D, hB, hτ, hone, hgap⟩ :=
    massGap_of_measures_sub (fun n => liftProb β (φ n)) ν hlim (ContinuousMap.id Cfg) zReflC zShiftC
      Wsub one_mem_Wsub shift_mem_Wsub
      (fun F hF => hφ.tendsto_atTop.eventually (rp_eventually β F hF))
      (fun F _ G _ => Eventually.of_forall (fun n => sym_lift β F G (φ n)))
      (fun F _ G _ => Eventually.of_forall (fun n => shift_lift β F G (φ n)))
      lam (fun F hF => by
        obtain ⟨C, hC⟩ := dec_eventually_dob β lam hlam.le hα F hF
        exact ⟨C, fun k => hφ.tendsto_atTop.eventually (hC k)⟩)
  have hFF : D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ = ∫ x, F0 x * F0 x ∂(ν : Measure Cfg) := by
    rw [hB]
    show ∫ x, F0 (zRefl x) * F0 x ∂(ν : Measure Cfg) = _
    simp only [F0_refl]
  have h1F : D.B D.one ⟨F0, F0_mem⟩ = ∫ x, F0 x ∂(ν : Measure Cfg) := by
    rw [hB, hone]
    show ∫ x, (1 : Cfg →ᵇ ℝ) (zRefl x) * F0 x ∂(ν : Measure Cfg) = _
    simp only [BoundedContinuousFunction.coe_one, Pi.one_apply, one_mul]
  have hvar : Real.exp (-(12 * |β|)) / 4 ≤
      D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 := by
    rw [hFF, h1F]
    exact var_limit_ge β ν φ hlim
  exact ⟨D, hB, hτ, hone, hgap, hvar, D.exists_unit_orth _ (lt_of_lt_of_le (by positivity) hvar)⟩

theorem dobConst_pos (β : ℝ) (hβ0 : β ≠ 0) : 0 < dobConst β := by
  unfold dobConst
  have h1 : 1 < Real.exp (2 * |β|) := Real.one_lt_exp_iff.2 (by have := abs_pos.2 hβ0; linarith)
  exact mul_pos (by norm_num) (div_pos (by linarith) (by linarith))

/-- the rate `λ = -ln(18 tanh|β|)/2` is admissible -/
theorem dob_rate (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    0 < -Real.log (dobConst β) / 2 ∧ Real.exp (-Real.log (dobConst β) / 2) * dobConst β < 1 := by
  have hq0 := dobConst_pos β hβ0
  have hl : Real.log (dobConst β) < 0 := Real.log_neg hq0 hq
  refine ⟨by linarith, ?_⟩
  set L := Real.log (dobConst β) with hL
  have hq' : dobConst β = Real.exp L := (Real.exp_log hq0).symm
  rw [hq', ← Real.exp_add]
  calc Real.exp (-L / 2 + L) < Real.exp 0 := Real.exp_lt_exp.2 (by linarith)
    _ = 1 := Real.exp_zero

/-- an explicit window: `|β| < 1/19 ⇒ 18 tanh|β| < 1` -/
theorem dob_window_strict (β : ℝ) (h : |β| < 1 / 19) : dobConst β < 1 := by
  unfold dobConst
  have ht0 : 0 ≤ |β| := abs_nonneg β
  have hX := Real.exp_bound_div_one_sub_of_interval (by positivity : (0 : ℝ) ≤ 2 * |β|)
    (by linarith)
  have hX1 : 1 ≤ Real.exp (2 * |β|) := Real.one_le_exp (by positivity)
  have hX2 : Real.exp (2 * |β|) < 19 / 17 := by
    refine lt_of_le_of_lt hX ?_
    rw [div_lt_div_iff₀ (by linarith) (by norm_num)]
    linarith
  rw [← mul_div_assoc, div_lt_one (by linarith)]
  linarith

/-- **Combined statement, Dobrushin window** (no hypothesis besides `β ≠ 0`, `18 tanh|β| < 1`). -/
theorem wilson_massGap_dob_exists (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃ ν : ProbabilityMeasure Cfg, ∃ φ : ℕ → ℕ, StrictMono φ ∧
      Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν) ∧
      ∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
        ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨ν, φ, hφ, h⟩ := exists_limitPoint β
  obtain ⟨hl, hα⟩ := dob_rate β hβ0 hq
  exact ⟨ν, φ, hφ, h, wilson_massGap_dob β _ hl hα ν φ hφ h⟩

/-- the hypotheses are satisfiable: `β = 1/20` -/
theorem dob_example : (1 / 20 : ℝ) ≠ 0 ∧ dobConst (1 / 20) < 1 :=
  ⟨by norm_num, dob_window_strict _ (by rw [abs_of_pos (by norm_num)]; norm_num)⟩

end WilsonLimit

#print axioms WilsonLimit.dec_eventually_dob
#print axioms WilsonLimit.wilson_massGap_dob
#print axioms WilsonLimit.dob_rate
#print axioms WilsonLimit.dob_window_strict
#print axioms WilsonLimit.wilson_massGap_dob_exists
#print axioms WilsonLimit.dob_example
