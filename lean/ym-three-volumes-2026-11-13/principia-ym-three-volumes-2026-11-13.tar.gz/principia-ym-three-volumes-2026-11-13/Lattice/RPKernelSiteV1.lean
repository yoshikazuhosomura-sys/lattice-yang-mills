import Lattice.RPKernelV1

/-!
# The hypotheses of `rp_kernel` are satisfiable: the site reflection of the torus

`TorusRP.rp_kernel_site` : for the site reflection `x₀ ↦ -x₀` of `(ℤ/2M)⁴` (planes `x₀ = 0, M`), every
bounded measurable `g` and bounded measurable `φ` of the closed positive half and `β ≥ 0`,
`0 ≤ ∫ g(ω) g(Θω) e^{β Σ_j φ_j(ω) φ_j(Θω)} dHaar(ω)`.  All hypotheses of `rp_kernel` are discharged by
the lemmas used for `wilson_rp`.
-/

namespace TorusRP

open MeasureTheory LinkReflection

variable (N : ℕ) [NeZero N] (M : ℕ)

theorem rp_kernel_site (hN : N = 2 * M) (g : (Lk N → QBall) → ℝ) (hg : Measurable g) (C : ℝ)
    (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → g ω = g ω')
    {d : ℕ} (φ : (Lk N → QBall) → Fin d → ℝ) (hφ : ∀ j, Measurable fun ω => φ ω j) (Cφ : ℝ)
    (hφb : ∀ ω j, |φ ω j| ≤ Cφ)
    (hφdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → φ ω = φ ω')
    (β : ℝ) (hβ : 0 ≤ β) :
    0 ≤ ∫ ω, g ω * g (linkRefl (thL N) (sig N) ω) *
      Real.exp (β * ∑ j, φ ω j * φ (linkRefl (thL N) (sig N) ω) j)
        ∂(Measure.pi fun _ : Lk N => haarBall) :=
  rp_kernel haarBall (thL N) (sig N) (fixP N M) (posP N M) (thL_invol N)
    (hfix_torus hN) (fun ℓ h => hposfix_torus ℓ h) (hA_torus hN) (hB_torus hN)
    (sig_preserving N) g hg C hgC hdep φ hφ Cφ hφb hφdep β hβ

end TorusRP

#print axioms TorusRP.rp_kernel_site
