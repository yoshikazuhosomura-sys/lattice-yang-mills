import Mathlib

/-!
# Premise 10 for the Wilson measure of SU(2) on the periodic lattice (table 2, row 10)

Paper A, premise 10 / (RP1) / Appendix RP: site reflection positivity of the lattice measure
(Osterwalder–Seiler), here proved in Lean for the plain Wilson measure of `SU(2)` on `(ℤ/N)⁴`,
`N = 2M`, every real `β`, with the reflection `x₀ ↦ -x₀` of `BoxReflSlab.lean`.

Assembled from: `ReflectionProduct.lean` (two statements, copied), `parts/linkrp.part`
(abstract link form, checked alone as `LinkRP.v1.lean`), `CompactHaarInv.lean` (section
`Group`, copied), the `SU2` / `haarProb` definitions of `GapSU2.lean` (namespace `OSGap`,
copied verbatim so that the two agree), `parts/torusrp.part` (the torus).
-/

namespace ReflectionProduct

open MeasureTheory

variable {A P : Type*} [MeasurableSpace A] [MeasurableSpace P]
  (μ : Measure A) [SFinite μ] (ν : Measure P) [SFinite ν]

theorem refl_pairing_eq (h g : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * g z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    ∫ z : P × (A × A), h z.2.1 z.1 * g z.2.2 z.1 ∂(ν.prod (μ.prod μ))
      = ∫ p, (∫ a, h a p ∂μ) * (∫ b, g b p ∂μ) ∂ν := by
  rw [integral_prod _ hint]
  refine integral_congr_ae (Filter.Eventually.of_forall (fun p => ?_))
  exact integral_prod_mul (fun a => h a p) (fun b => g b p)

/-- **Reflection positivity (integral form) for a product measure with a factorised weight.** -/
theorem refl_pos_integral (h : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * h z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    0 ≤ ∫ z : P × (A × A), h z.2.1 z.1 * h z.2.2 z.1 ∂(ν.prod (μ.prod μ)) := by
  rw [refl_pairing_eq μ ν h h hint]
  exact integral_nonneg (fun p => mul_self_nonneg _)

end ReflectionProduct

/-! ## Reflection positivity for a product measure on link variables (abstract index form)

Paper A, premise 10 / Appendix RP (site reflection positivity of the lattice measure);
Osterwalder–Seiler.  This is the bridge from a *link-indexed* configuration space `Λ → X`
with the product measure `ν^Λ` to the plane/positive/negative product form
`P × (A × A)` of `ReflectionProduct.refl_pos_integral` (the same form as the configuration
space of the fermion lane, plane configuration × positive configuration).

Data: a reflection of the links `θ : Λ → Λ` (an involution), a map on the values `σ ℓ : X → X`
(the identity on spatial links, `star` = inverse on temporal links), measure preserving for `ν`,
and two decidable predicates: `fix ℓ` (links in the reflection planes, fixed by `θ` and with
`σ ℓ = id`) and `pos ℓ` (links strictly on the positive side).  Every link that is neither is
sent by `θ` to a positive link, and positive links are sent to non-positive links.  The closed
positive half is `fix ∨ pos`.  The reflected configuration is `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`.

Statement (`rp_core`): for every bounded measurable `g` that depends only on the links of the
closed positive half, `0 ≤ ∫ g(Θω) g(ω) d ν^Λ`.  With a weight that factorises as
`W(ω) = a(ω) a(Θω)`, `a` bounded measurable on the closed positive half (`rp_weighted`).
Nothing here is specific to a lattice; the concrete torus is in the next section.
-/

namespace LinkReflection

open MeasureTheory

variable {Λ X : Type*} [Fintype Λ] [MeasurableSpace X]

/-- The reflected configuration `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`. -/
def linkRefl (θ : Λ → Λ) (σ : Λ → X → X) (ω : Λ → X) : Λ → X := fun ℓ => σ ℓ (ω (θ ℓ))

section Split

variable (θ : Λ → Λ) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]

/-- links off the planes -/
abbrev Off := {ℓ : Λ // ¬ fix ℓ}
/-- links strictly on the positive side (as a subtype of `Off`) -/
abbrev PosI := {q : Off fix // pos q.1}
/-- links strictly on the negative side -/
abbrev NegI := {q : Off fix // ¬ pos q.1}

/-- The reflection identifies the negative links with the positive links. -/
def negPosEquiv (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ)) : NegI fix pos ≃ PosI fix pos where
  toFun b := ⟨⟨θ b.1.1, hposfix _ (hB _ b.1.2 b.2)⟩, hB _ b.1.2 b.2⟩
  invFun a := ⟨⟨θ a.1.1, fun h => a.1.2 (by
      have h2 := hfix _ h
      rw [hθ] at h2
      rw [h2]; exact h)⟩, hA _ a.2⟩
  left_inv b := Subtype.ext (Subtype.ext (hθ _))
  right_inv a := Subtype.ext (Subtype.ext (hθ _))

/-- Gluing a plane configuration and a positive configuration into a configuration (the other
links get an arbitrary value; only the closed positive half matters). -/
noncomputable def glue [Nonempty X] (p : {ℓ // fix ℓ} → X) (a : PosI fix pos → X) : Λ → X :=
  fun ℓ => if h : fix ℓ then p ⟨ℓ, h⟩ else if h' : pos ℓ then a ⟨⟨ℓ, h⟩, h'⟩
    else Classical.arbitrary X

theorem measurable_glue [Nonempty X] :
    Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => glue fix pos z.1 z.2) := by
  refine measurable_pi_lambda _ (fun ℓ => ?_)
  unfold glue
  by_cases h : fix ℓ
  · simp only [dif_pos h]
    exact (measurable_pi_apply _).comp measurable_fst
  · by_cases h' : pos ℓ
    · simp only [dif_neg h, dif_pos h']
      exact (measurable_pi_apply _).comp measurable_snd
    · simp only [dif_neg h, dif_neg h']
      exact measurable_const

end Split

theorem piCongrLeft_const {α β Y : Type*} [MeasurableSpace Y] (e : α ≃ β) (c : α → Y) (b : β) :
    MeasurableEquiv.piCongrLeft (fun _ : β => Y) e c b = c (e.symm b) := by
  obtain ⟨a, rfl⟩ := e.surjective b
  rw [MeasurableEquiv.piCongrLeft_apply_apply, Equiv.symm_apply_apply]

/-- **Reflection positivity of the product measure on link variables** (premise 10, the
reference measure; Osterwalder–Seiler).  `g` bounded, measurable, depending only on the closed
positive half `fix ∨ pos`. -/
theorem rp_core [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (g : (Λ → X) → ℝ) (hg : Measurable g) (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → g ω = g ω') :
    0 ≤ ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
  classical
  let e := negPosEquiv θ fix pos hθ (fun ℓ h => (hfix ℓ h).1) hposfix hA hB
  let Ψ : (Λ → X) → ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) :=
    fun ω => (fun i => ω i.1, (fun a => ω a.1.1, fun a => σ a.1.1 (ω (θ a.1.1))))
  have hs1 := measurePreserving_piEquivPiSubtypeProd (fun _ : Λ => ν) fix
  have hs2 := measurePreserving_piEquivPiSubtypeProd (fun _ : Off fix => ν)
    (fun q : Off fix => pos q.1)
  have hre := measurePreserving_piCongrLeft (fun _ : PosI fix pos => ν) e
  have hσp := measurePreserving_pi (fun _ : PosI fix pos => ν) (fun _ : PosI fix pos => ν)
    (f := fun a => σ a.1.1) (fun a => hσ a.1.1)
  have hτ := hσp.comp hre
  have hcomp := ((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod
    ((MeasurePreserving.id (Measure.pi fun _ : PosI fix pos => ν)).prod hτ)).comp
    (((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod hs2).comp hs1)
  have hΨ : MeasurePreserving Ψ (Measure.pi fun _ : Λ => ν)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    convert hcomp using 1
    funext ω
    refine Prod.ext rfl (Prod.ext rfl ?_)
    funext a
    show σ a.1.1 (ω (θ a.1.1)) = σ a.1.1 (MeasurableEquiv.piCongrLeft (fun _ : PosI fix pos => X) e
      (fun b => ω b.1.1) a)
    rw [piCongrLeft_const]
    rfl
  let G : ({ℓ // fix ℓ} → X) → (PosI fix pos → X) → ℝ := fun p a => g (glue fix pos p a)
  have hG : Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => G z.1 z.2) :=
    hg.comp (measurable_glue fix pos)
  have hH : Measurable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2) := by
    refine Measurable.mul ?_ ?_
    · exact hG.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    · exact hG.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have h1 : ∀ ω, g ω = G (Ψ ω).1 (Ψ ω).2.1 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show ω ℓ = glue fix pos (fun i => ω i.1) (fun a => ω a.1.1) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have h2 : ∀ ω, g (linkRefl θ σ ω) = G (Ψ ω).1 (Ψ ω).2.2 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show σ ℓ (ω (θ ℓ)) =
      glue fix pos (fun i => ω i.1) (fun a => σ a.1.1 (ω (θ a.1.1))) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h, (hfix ℓ h).1, (hfix ℓ h).2]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have hC : 0 ≤ C := le_trans (abs_nonneg _) (hgC (fun _ => Classical.arbitrary X))
  have hint : Integrable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    refine Integrable.of_bound hH.aestronglyMeasurable (C * C) (ae_of_all _ fun z => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    exact mul_le_mul (hgC _) (hgC _) (abs_nonneg _) hC
  calc (0 : ℝ) ≤ ∫ z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)),
        G z.1 z.2.1 * G z.1 z.2.2
        ∂((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
          ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) :=
        ReflectionProduct.refl_pos_integral (Measure.pi fun _ : PosI fix pos => ν)
          (Measure.pi fun _ : {ℓ // fix ℓ} => ν) (fun a p => G p a) hint
    _ = ∫ ω, G (Ψ ω).1 (Ψ ω).2.1 * G (Ψ ω).1 (Ψ ω).2.2 ∂(Measure.pi fun _ : Λ => ν) := by
        rw [← hΨ.map_eq, integral_map hΨ.measurable.aemeasurable hH.aestronglyMeasurable]
    _ = ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
        congr 1
        funext ω
        rw [h1 ω, h2 ω, mul_comm]

/-- **With a factorised weight** `W(ω) = a(ω) a(Θω)` (Wilson's action: plaquettes of the
positive side, half of the plaquettes in the planes).  `f`, `a` bounded measurable on the
closed positive half. -/
theorem rp_weighted [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (f a : (Λ → X) → ℝ) (hf : Measurable f) (ha : Measurable a) (Cf Ca : ℝ)
    (hfC : ∀ ω, |f ω| ≤ Cf) (haC : ∀ ω, |a ω| ≤ Ca)
    (hfdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → f ω = f ω')
    (hadep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → a ω = a ω') :
    0 ≤ ∫ ω, f (linkRefl θ σ ω) * f ω * (a ω * a (linkRefl θ σ ω)) ∂(Measure.pi fun _ : Λ => ν) := by
  have hCa : 0 ≤ Ca := le_trans (abs_nonneg _) (haC (fun _ => Classical.arbitrary X))
  have h := rp_core ν θ σ fix pos hθ hfix hposfix hA hB hσ (fun ω => a ω * f ω) (ha.mul hf)
    (Ca * Cf) (fun ω => by rw [abs_mul]; exact mul_le_mul (haC ω) (hfC ω) (abs_nonneg _) hCa)
    (fun ω ω' h => by rw [hadep ω ω' h, hfdep ω ω' h])
  calc (0 : ℝ) ≤ _ := h
    _ = _ := by
      congr 1
      funext ω
      ring

end LinkReflection

namespace CompactHaar

open MeasureTheory Measure

section Group

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [MeasurableSpace G] [BorelSpace G]

/-- **Right invariance.** -/
theorem map_mul_right_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ]
    (g : G) : map (· * g) μ = μ := by
  have hreg : (map (· * g) μ).Regular := by
    have h := Regular.map (μ := μ) (Homeomorph.mulRight g)
    exact h
  have hc := isMulLeftInvariant_eq_smul_of_regular (map (· * g) μ) μ
  have h1 : (map (· * g) μ) Set.univ = 1 := by
    rw [map_apply (continuous_mul_right g).measurable MeasurableSet.univ, Set.preimage_univ,
      measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isMulRightInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ]
    [IsProbabilityMeasure μ] : IsMulRightInvariant μ :=
  ⟨fun g => map_mul_right_eq μ g⟩

/-- **Inversion invariance.** -/
theorem inv_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    μ.inv = μ := by
  haveI : IsMulRightInvariant μ := isMulRightInvariant μ
  have hc := isMulLeftInvariant_eq_smul_of_regular μ.inv μ
  have h1 : μ.inv Set.univ = 1 := by
    rw [inv_apply, Set.inv_univ, measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isInvInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    IsInvInvariant μ :=
  ⟨inv_eq μ⟩

/-- the normalised Haar measure `haarMeasure ⊤` of a compact group is inversion invariant -/
theorem haarTop_inv_eq : (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)).inv
    = haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G) := by
  haveI : IsProbabilityMeasure (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)) := by
    refine ⟨?_⟩
    have h : haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)
        ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 := haarMeasure_self
    rwa [TopologicalSpace.PositiveCompacts.coe_top] at h
  exact inv_eq _

end Group

end CompactHaar

namespace OSGap

section SU2

open MeasureTheory

/-- `SU(2)` realised as the group of unit quaternions -/
abbrev SU2 : Type := Metric.sphere (0 : Quaternion ℝ) 1

noncomputable instance : MeasurableSpace SU2 := borel SU2

instance : BorelSpace SU2 := ⟨rfl⟩

/-- the normalised Haar measure of a compact group -/
noncomputable def haarProb (G : Type*) [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
    [CompactSpace G] [MeasurableSpace G] [BorelSpace G] : Measure G :=
  Measure.haarMeasure ⊤

instance haarProb_isProbabilityMeasure (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    IsProbabilityMeasure (haarProb G) := by
  refine ⟨?_⟩
  have h : haarProb G ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 :=
    Measure.haarMeasure_self
  rwa [TopologicalSpace.PositiveCompacts.coe_top] at h

instance haarProb_isMulLeftInvariant (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    (haarProb G).IsMulLeftInvariant := by
  unfold haarProb
  infer_instance

/-- the normalised Haar measure of `SU(2)` -/
noncomputable abbrev haarSU2 : Measure SU2 := haarProb SU2

end SU2

end OSGap

namespace TorusRP

/-- Borel σ-algebra on the quaternions (the same instance as `BoxReflSlab.lean`). -/
noncomputable instance instMeasurableSpaceQuaternion : MeasurableSpace (Quaternion ℝ) :=
  borel (Quaternion ℝ)
instance instBorelSpaceQuaternion : BorelSpace (Quaternion ℝ) := ⟨rfl⟩

end TorusRP

/-! ## The concrete four-dimensional periodic lattice: Wilson measure and site reflection

Paper A, premise 10 (site reflection positivity of `μ_n`, Appendix RP) for the plain Wilson
measure of `SU(2)` on the periodic lattice `(ℤ/N)⁴`, `N = 2M` even, with the reflection
`x₀ ↦ -x₀` (planes `x₀ = 0` and `x₀ = M`).  The reflection of the links is the one of
`BoxReflSlab.lean` (`reflV` / `reflCfg`): a temporal link `(x, 0)` goes to the star of the link
`(Θx - e₀, 0)`, a spatial link `(x, ν)` to `(Θx, ν)`.  Link values are in the closed unit ball
of the quaternions (as in `BoxReflSlab.lean`); the reference measure is the image of the
normalised Haar measure of `SU2` (the unit sphere), so the configurations are `SU(2)`-valued
almost surely.  Wilson's weight is `exp(β Σ_p Re U_p)` over the unoriented plaquettes
`(x, μ, ν)`, `μ < ν` (`Re U = ½ tr U`); the constant `1` of `1 - ½tr` and the normalisation
`Z` are positive factors and are omitted (they do not change the sign of the pairing).

Everything is in finite volume (the statement is for each `N`); nothing here is uniform in the
volume or the lattice spacing, and nothing is needed to be: reflection positivity is an exact
property of each finite-volume measure.
-/

namespace TorusRP

open MeasureTheory LinkReflection

local notation "ℍr" => Quaternion ℝ

/-- Values of a link variable (as in `BoxReflSlab.lean`). -/
abbrev QBall := Metric.closedBall (0 : ℍr) 1

section Geometry

variable (N : ℕ) [NeZero N]

abbrev Site := Fin 4 → ZMod N
abbrev Lk := Site N × Fin 4

/-- `Θ x = (-x₀, x₁, x₂, x₃)` -/
def thS (y : Site N) : Site N := fun i => if i = 0 then -y i else y i

/-- unit vector -/
def ev (μ : Fin 4) : Site N := Pi.single μ 1

/-- the reflection of the links (the index map of `reflV`) -/
def thL (ℓ : Lk N) : Lk N := if ℓ.2 = 0 then (thS N ℓ.1 - ev N 0, 0) else (thS N ℓ.1, ℓ.2)

noncomputable def starB (q : QBall) : QBall :=
  ⟨star (q : ℍr), by rw [mem_closedBall_zero_iff, norm_star]; exact mem_closedBall_zero_iff.1 q.2⟩

/-- the map on the values: `star` (= inverse on `SU(2)`) on temporal links -/
noncomputable def sig (ℓ : Lk N) : QBall → QBall := if ℓ.2 = 0 then starB else id

theorem thS_add (x y : Site N) : thS N (x + y) = thS N x + thS N y := by
  funext i; simp only [thS, Pi.add_apply]; split_ifs <;> abel

theorem thS_sub (x y : Site N) : thS N (x - y) = thS N x - thS N y := by
  funext i; simp only [thS, Pi.sub_apply]; split_ifs <;> abel

theorem thS_thS (x : Site N) : thS N (thS N x) = x := by
  funext i; simp only [thS]; split_ifs <;> simp

theorem thS_ev0 : thS N (ev N 0) = -ev N 0 := by
  funext i; simp only [thS, ev, Pi.neg_apply]; split_ifs with h
  · subst h; simp
  · simp [Pi.single_apply, h]

theorem thS_ev {ν : Fin 4} (hν : ν ≠ 0) : thS N (ev N ν) = ev N ν := by
  funext i; simp only [thS, ev]; split_ifs with h
  · subst h; simp [Pi.single_apply, Ne.symm hν]
  · rfl

theorem ev_zero {ν : Fin 4} (hν : ν ≠ 0) : ev N ν 0 = 0 := by
  simp [ev, Pi.single_apply, Ne.symm hν]

theorem thL_snd (ℓ : Lk N) : (thL N ℓ).2 = ℓ.2 := by
  unfold thL; split_ifs with h
  · exact h.symm
  · rfl

theorem thL_invol : Function.Involutive (thL N) := by
  intro ℓ
  obtain ⟨x, μ⟩ := ℓ
  by_cases h : μ = 0
  · subst h
    simp only [thL, if_true, thS_sub, thS_thS, thS_ev0, sub_neg_eq_add, add_sub_cancel_right]
  · simp only [thL, h, if_false, thS_thS]

theorem thL_time (ℓ : Lk N) :
    (thL N ℓ).1 0 = if ℓ.2 = 0 then -(ℓ.1 0) - 1 else -(ℓ.1 0) := by
  unfold thL; split_ifs <;> simp [thS, ev]

/-- the reflected configuration is the map of `reflCfg` -/
theorem refl_apply (ω : Lk N → QBall) (ℓ : Lk N) :
    ((linkRefl (thL N) (sig N) ω ℓ : QBall) : ℍr) =
      if ℓ.2 = 0 then star (ω (thL N ℓ) : ℍr) else (ω (thL N ℓ) : ℍr) := by
  unfold linkRefl sig; split_ifs <;> rfl

/-! ### time coordinate -/

theorem val_neg_sub_one (t : ZMod N) : (-t - 1).val = N - 1 - t.val := by
  have hv := ZMod.val_lt t
  have h : (N - 1 - t.val) + t.val + 1 = N := by omega
  have h2 := congrArg (Nat.cast : ℕ → ZMod N) h
  rw [Nat.cast_add, Nat.cast_add, Nat.cast_one, ZMod.natCast_self, ZMod.natCast_zmod_val] at h2
  have h3 : ((N - 1 - t.val : ℕ) : ZMod N) = -t - 1 := by linear_combination h2
  rw [← h3, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem val_neg' (t : ZMod N) (ht : t.val ≠ 0) : (-t).val = N - t.val := by
  have hv := ZMod.val_lt t
  have h : (N - t.val) + t.val = N := by omega
  have h2 := congrArg (Nat.cast : ℕ → ZMod N) h
  rw [Nat.cast_add, ZMod.natCast_self, ZMod.natCast_zmod_val] at h2
  have h3 : ((N - t.val : ℕ) : ZMod N) = -t := by linear_combination h2
  rw [← h3, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem val_add_one (t : ZMod N) (ht : t.val + 1 < N) : (t + 1).val = t.val + 1 := by
  have h2 : ((t.val + 1 : ℕ) : ZMod N) = t + 1 := by
    rw [Nat.cast_add, Nat.cast_one, ZMod.natCast_zmod_val]
  rw [← h2, ZMod.val_natCast, Nat.mod_eq_of_lt ht]

/-- time of the base point of a link -/
def tm (ℓ : Lk N) : ℕ := (ℓ.1 0).val

variable (M : ℕ)

/-- links in the reflection planes `x₀ = 0`, `x₀ = M` (spatial) -/
def fixP (ℓ : Lk N) : Prop := ℓ.2 ≠ 0 ∧ (tm N ℓ = 0 ∨ tm N ℓ = M)

/-- links strictly on the positive side -/
def posP (ℓ : Lk N) : Prop := if ℓ.2 = 0 then tm N ℓ < M else (0 < tm N ℓ ∧ tm N ℓ < M)

instance : DecidablePred (fixP N M) := fun ℓ => by unfold fixP; infer_instance
instance : DecidablePred (posP N M) := fun ℓ => by unfold posP; infer_instance

theorem tm_thL_temporal (ℓ : Lk N) (h : ℓ.2 = 0) : tm N (thL N ℓ) = N - 1 - tm N ℓ := by
  unfold tm; rw [thL_time, if_pos h, val_neg_sub_one]

theorem tm_thL_spatial (ℓ : Lk N) (h : ℓ.2 ≠ 0) (h0 : tm N ℓ ≠ 0) :
    tm N (thL N ℓ) = N - tm N ℓ := by
  unfold tm; rw [thL_time, if_neg h, val_neg' N _ h0]

theorem tm_thL_spatial0 (ℓ : Lk N) (h : ℓ.2 ≠ 0) (h0 : tm N ℓ = 0) : tm N (thL N ℓ) = 0 := by
  unfold tm at h0 ⊢
  rw [ZMod.val_eq_zero] at h0
  rw [thL_time, if_neg h, ZMod.val_eq_zero, h0, neg_zero]

theorem tm_lt (ℓ : Lk N) : tm N ℓ < N := ZMod.val_lt _

variable {N M}

theorem hfix_torus (hN : N = 2 * M) (ℓ : Lk N) (h : fixP N M ℓ) :
    thL N ℓ = ℓ ∧ ∀ x, sig N ℓ x = x := by
  obtain ⟨h2, h0⟩ := h
  refine ⟨?_, fun x => by simp [sig, h2]⟩
  obtain ⟨x, μ⟩ := ℓ
  simp only at h2
  simp only [tm] at h0
  have hx : x 0 = -x 0 := by
    rcases h0 with h0 | h0
    · rw [ZMod.val_eq_zero] at h0; rw [h0, neg_zero]
    · have hc : ((x 0).val : ZMod N) = (M : ZMod N) := by rw [h0]
      rw [ZMod.natCast_zmod_val] at hc
      have hNM : ((2 * M : ℕ) : ZMod N) = 0 := by rw [← hN, ZMod.natCast_self]
      rw [Nat.cast_mul, Nat.cast_ofNat] at hNM
      rw [hc]; linear_combination hNM
  have hth : thS N x = x := by
    funext i
    simp only [thS]
    split_ifs with hi
    · subst hi; exact hx.symm
    · rfl
  simp only [thL, h2, if_false, ↓reduceIte, hth]

theorem hposfix_torus (ℓ : Lk N) (h : posP N M ℓ) : ¬ fixP N M ℓ := by
  rintro ⟨h2, h0⟩
  unfold posP at h
  rw [if_neg h2] at h
  omega

theorem hA_torus (hN : N = 2 * M) (ℓ : Lk N) (h : posP N M ℓ) : ¬ posP N M (thL N ℓ) := by
  have hlt := tm_lt N ℓ
  unfold posP at h ⊢
  rw [thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at h ⊢
    rw [tm_thL_temporal N ℓ h2]
    omega
  · rw [if_neg h2] at h ⊢
    rw [tm_thL_spatial N ℓ h2 (by omega)]
    omega

theorem hB_torus (hN : N = 2 * M) (ℓ : Lk N) (hf : ¬ fixP N M ℓ) (hp : ¬ posP N M ℓ) :
    posP N M (thL N ℓ) := by
  have hlt := tm_lt N ℓ
  unfold posP at hp ⊢
  rw [thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at hp ⊢
    rw [tm_thL_temporal N ℓ h2]
    omega
  · rw [if_neg h2] at hp ⊢
    have h0 : tm N ℓ ≠ 0 := fun h0 => hf ⟨h2, Or.inl h0⟩
    have hM : tm N ℓ ≠ M := fun h0 => hf ⟨h2, Or.inr h0⟩
    rw [tm_thL_spatial N ℓ h2 h0]
    omega

/-- spatial links with time in `[0, M]` are in the closed positive half -/
theorem closed_spatial (z : Site N) (κ : Fin 4) (hκ : κ ≠ 0) (hv : (z 0).val ≤ M) :
    fixP N M (z, κ) ∨ posP N M (z, κ) := by
  by_cases h0 : (z 0).val = 0 ∨ (z 0).val = M
  · exact Or.inl ⟨hκ, h0⟩
  · right
    show if κ = 0 then (z 0).val < M else (0 < (z 0).val ∧ (z 0).val < M)
    rw [if_neg hκ]
    omega

/-- temporal links with time in `[0, M)` are strictly positive -/
theorem closed_temporal (z : Site N) (hv : (z 0).val < M) :
    fixP N M (z, 0) ∨ posP N M (z, 0) := by
  right
  show if (0 : Fin 4) = 0 then (z 0).val < M else (0 < (z 0).val ∧ (z 0).val < M)
  rw [if_pos rfl]
  exact hv

end Geometry

/-! ### the reference measure: image of the Haar measure of `SU2` -/

section Measure

open OSGap

noncomputable def incl (q : SU2) : QBall :=
  ⟨(q : ℍr), by rw [mem_closedBall_zero_iff]; exact le_of_eq (mem_sphere_zero_iff_norm.1 q.2)⟩

theorem continuous_incl : Continuous incl :=
  (continuous_subtype_val).subtype_mk _

/-- the reference measure on a link: `SU(2)` Haar measure in the ball -/
noncomputable def haarBall : Measure QBall := (haarProb SU2).map incl

instance : IsProbabilityMeasure haarBall :=
  Measure.isProbabilityMeasure_map continuous_incl.measurable.aemeasurable

theorem continuous_starB : Continuous starB :=
  (continuous_star.comp continuous_subtype_val).subtype_mk _

theorem starB_incl (q : SU2) : starB (incl q) = incl q⁻¹ := by
  apply Subtype.ext
  show star (q : ℍr) = ((q⁻¹ : SU2) : ℍr)
  have hn : ‖(q : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h1 : (q : ℍr) * star (q : ℍr) = 1 := by
    rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hn]
    simp
  have h2 : (q : ℍr)⁻¹ = star (q : ℍr) := inv_eq_of_mul_eq_one_right h1
  rw [Metric.unitSphere.coe_inv, h2]

theorem starB_preserving : MeasurePreserving starB haarBall haarBall := by
  refine ⟨continuous_starB.measurable, ?_⟩
  unfold haarBall
  rw [Measure.map_map continuous_starB.measurable continuous_incl.measurable]
  have hc : starB ∘ incl = incl ∘ (fun q : SU2 => q⁻¹) := funext starB_incl
  rw [hc, ← Measure.map_map continuous_incl.measurable continuous_inv.measurable]
  congr 1
  have h := CompactHaar.haarTop_inv_eq (G := SU2)
  rw [Measure.inv_def] at h
  exact h

theorem sig_preserving (N : ℕ) [NeZero N] (ℓ : Lk N) :
    MeasurePreserving (sig N ℓ) haarBall haarBall := by
  unfold sig; split_ifs
  · exact starB_preserving
  · exact MeasurePreserving.id _

end Measure

/-! ### Wilson's weight and its factorisation -/

section Wilson

variable (N : ℕ) [NeZero N] (M : ℕ)

instance : Nonempty QBall := ⟨⟨0, by rw [mem_closedBall_zero_iff, norm_zero]; exact zero_le_one⟩⟩

/-- link variable as a quaternion -/
noncomputable def Uq (ω : Lk N → QBall) (ℓ : Lk N) : ℍr := (ω ℓ : ℍr)

/-- plaquette holonomy `U(x,μ) U(x+μ,ν) U(x+ν,μ)* U(x,ν)*` of a quaternion field -/
noncomputable def holQ (U : Lk N → ℍr) (p : Lk N × Fin 4) : ℍr :=
  U p.1 * U (p.1.1 + ev N p.1.2, p.2) * star (U (p.1.1 + ev N p.2, p.1.2)) * star (U (p.1.1, p.2))

noncomputable def hol (ω : Lk N → QBall) (p : Lk N × Fin 4) : ℍr := holQ N (Uq N ω) p

/-- the unoriented plaquettes `(x, μ, ν)`, `μ < ν` -/
def plaqs : Finset (Lk N × Fin 4) := Finset.univ.filter (fun p => p.1.2 < p.2)

/-- Wilson's action without the constant: `Σ_p Re U_p` (`Re U = ½ tr U`) -/
noncomputable def action (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, (hol N ω p).re

/-- share of a plaquette in the positive half: `1` strictly positive, `½` in a plane -/
noncomputable def wt (p : Lk N × Fin 4) : ℝ :=
  if p.1.2 = 0 then (if tm N p.1 < M then 1 else 0)
  else (if 0 < tm N p.1 ∧ tm N p.1 < M then 1 else if tm N p.1 = 0 ∨ tm N p.1 = M then 1 / 2 else 0)

noncomputable def halfAction (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, wt N M p * (hol N ω p).re

/-- Wilson's weight `exp(β Σ_p ½ tr U_p)` -/
noncomputable def wilsonWeight (β : ℝ) (ω : Lk N → QBall) : ℝ := Real.exp (β * action N ω)

/-- the weight of the closed positive half -/
noncomputable def halfWeight (β : ℝ) (ω : Lk N → QBall) : ℝ := Real.exp (β * halfAction N M ω)

/-- the reflected quaternion field (the field of `reflCfg`) -/
noncomputable def reflQ (U : Lk N → ℍr) (ℓ : Lk N) : ℍr :=
  if ℓ.2 = 0 then star (U (thL N ℓ)) else U (thL N ℓ)

theorem Uq_refl (ω : Lk N → QBall) : Uq N (linkRefl (thL N) (sig N) ω) = reflQ N (Uq N ω) := by
  funext ℓ; exact refl_apply N ω ℓ

theorem re_cyc (p q : ℍr) : (p * q).re = (q * p).re := by
  simp only [Quaternion.re_mul]; ring

theorem quat4 (a b c d : ℍr) :
    (star a * b * star (star c) * star d).re = (a * d * star c * star b).re := by
  rw [star_star, mul_assoc (star a * b), mul_assoc (star a), re_cyc,
    show b * (c * star d) * star a = star (a * d * star c * star b) by
      simp only [star_mul, star_star, mul_assoc],
    Quaternion.re_star]

/-- **Reflection of a plaquette.**  `Re U_p(Θω) = Re U_{θp}(ω)`; for a temporal plaquette the
reflected holonomy is a cyclic rotation of the star of the holonomy of the reflected plaquette. -/
theorem holQ_refl (U : Lk N → ℍr) (x : Site N) (μ ν : Fin 4) (hlt : μ < ν) :
    (holQ N (reflQ N U) ((x, μ), ν)).re = (holQ N U (thL N (x, μ), ν)).re := by
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  by_cases hμ : μ = 0
  · subst hμ
    have e1 : thS N (x + ev N 0) = thS N x - ev N 0 := by
      rw [thS_add, thS_ev0, sub_eq_add_neg]
    have e2 : thS N (x + ev N ν) - ev N 0 = thS N x - ev N 0 + ev N ν := by
      rw [thS_add, thS_ev N hν]; abel
    simp only [holQ, reflQ, thL, hν, if_true, if_false, eq_self_iff_true, ↓reduceIte]
    rw [e1, e2, sub_add_cancel]
    exact quat4 _ _ _ _
  · simp only [holQ, reflQ, thL, hμ, hν, if_false, ↓reduceIte, thS_add, thS_ev N hμ, thS_ev N hν]

theorem sum_refl (g : Lk N × Fin 4 → ℝ) :
    ∑ p ∈ plaqs N, g (thL N p.1, p.2) = ∑ p ∈ plaqs N, g p := by
  refine Finset.sum_nbij' (fun p => (thL N p.1, p.2)) (fun p => (thL N p.1, p.2)) ?_ ?_ ?_ ?_ ?_
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thL_snd]; exact hp
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thL_snd]; exact hp
  · intro p _; exact Prod.ext (thL_invol N p.1) rfl
  · intro p _; exact Prod.ext (thL_invol N p.1) rfl
  · intro p _; rfl

theorem wt_add (hN : N = 2 * M) (ℓ : Lk N) (ν : Fin 4) :
    wt N M (thL N ℓ, ν) + wt N M (ℓ, ν) = 1 := by
  have hlt := tm_lt N ℓ
  simp only [wt, thL_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [tm_thL_temporal N ℓ h2]
    simp only [h2, ↓reduceIte]
    split_ifs <;> first | omega | (norm_num; done) | simp_all
  · by_cases h0 : tm N ℓ = 0
    · rw [tm_thL_spatial0 N ℓ h2 h0]
      simp only [h2, ↓reduceIte]
      split_ifs <;> first | omega | (norm_num; done) | simp_all
    · rw [tm_thL_spatial N ℓ h2 h0]
      simp only [h2, ↓reduceIte]
      split_ifs <;> first | omega | (norm_num; done) | simp_all

/-- **The action splits**: `S(ω) = S₊(ω) + S₊(Θω)`. -/
theorem action_split (hN : N = 2 * M) (ω : Lk N → QBall) :
    action N ω = halfAction N M ω + halfAction N M (linkRefl (thL N) (sig N) ω) := by
  have h1 : ∀ p ∈ plaqs N,
      (hol N (linkRefl (thL N) (sig N) ω) p).re = (hol N ω (thL N p.1, p.2)).re := by
    rintro ⟨⟨x, μ⟩, ν⟩ hp
    have hlt : μ < ν := by simpa [plaqs] using hp
    show (holQ N (Uq N (linkRefl (thL N) (sig N) ω)) _).re = (holQ N (Uq N ω) _).re
    rw [Uq_refl]
    exact holQ_refl N _ x μ ν hlt
  have h2 : ∑ p ∈ plaqs N, wt N M p * (hol N (linkRefl (thL N) (sig N) ω) p).re
      = ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re := by
    calc ∑ p ∈ plaqs N, wt N M p * (hol N (linkRefl (thL N) (sig N) ω) p).re
        = ∑ p ∈ plaqs N, wt N M p * (hol N ω (thL N p.1, p.2)).re :=
          Finset.sum_congr rfl (fun p hp => by rw [h1 p hp])
      _ = ∑ p ∈ plaqs N, (fun q => wt N M (thL N q.1, q.2) * (hol N ω q).re) (thL N p.1, p.2) :=
          Finset.sum_congr rfl (fun p _ => by simp only [thL_invol N p.1, Prod.mk.eta])
      _ = ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re :=
          sum_refl N (fun q => wt N M (thL N q.1, q.2) * (hol N ω q).re)
  have h3 : action N ω = ∑ p ∈ plaqs N, wt N M p * (hol N ω p).re
      + ∑ p ∈ plaqs N, wt N M (thL N p.1, p.2) * (hol N ω p).re := by
    unfold action
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun p _ => ?_)
    have h := wt_add N M hN p.1 p.2
    rw [Prod.mk.eta] at h
    linear_combination (-(hol N ω p).re) * h
  rw [h3]
  unfold halfAction
  rw [h2]

/-- **Wilson's weight factorises**: `W(ω) = a(ω) a(Θω)`. -/
theorem weight_factor (hN : N = 2 * M) (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β ω = halfWeight N M β ω * halfWeight N M β (linkRefl (thL N) (sig N) ω) := by
  unfold wilsonWeight halfWeight
  rw [← Real.exp_add, action_split N M hN, mul_add]

theorem add_ev_zero (x : Site N) {κ : Fin 4} (hκ : κ ≠ 0) : (x + ev N κ) 0 = x 0 := by
  simp [ev_zero N hκ]

theorem add_ev0_val (x : Site N) (h : (x 0).val + 1 < N) : ((x + ev N 0) 0).val = (x 0).val + 1 := by
  simp only [Pi.add_apply, ev, Pi.single_eq_same]
  exact val_add_one N _ h

/-- **The half weight depends only on the closed positive half.** -/
theorem halfAction_dep (hN : N = 2 * M) (ω ω' : Lk N → QBall)
    (h : ∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) : halfAction N M ω = halfAction N M ω' := by
  unfold halfAction
  refine Finset.sum_congr rfl (fun p hp => ?_)
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  have hlt : μ < ν := by simpa [plaqs] using hp
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  have hv := ZMod.val_lt (x 0)
  have hall : ∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → (ω ℓ : ℍr) = (ω' ℓ : ℍr) :=
    fun ℓ h' => by rw [h ℓ h']
  by_cases hw : wt N M ((x, μ), ν) = 0
  · rw [hw, zero_mul, zero_mul]
  · congr 1
    simp only [hol, holQ, Uq]
    by_cases hμ : μ = 0
    · subst hμ
      have hvM : (x 0).val < M := by
        by_contra hc
        apply hw
        simp only [wt]
        rw [if_neg (show ¬ tm N (x, 0) < M from hc)]
        simp
      rw [hall (x, 0) (closed_temporal x hvM),
        hall (x + ev N 0, ν) (closed_spatial (x + ev N 0) ν hν
          (by rw [add_ev0_val N x (by omega)]; omega)),
        hall (x + ev N ν, 0) (closed_temporal (x + ev N ν) (by rw [add_ev_zero N x hν]; exact hvM)),
        hall (x, ν) (closed_spatial x ν hν (by omega))]
    · have hvM : (x 0).val ≤ M := by
        by_contra hc
        apply hw
        have ht : tm N (x, μ) = (x 0).val := rfl
        simp only [wt]
        rw [if_neg hμ, if_neg (show ¬ (0 < tm N (x, μ) ∧ tm N (x, μ) < M) by omega),
          if_neg (show ¬ (tm N (x, μ) = 0 ∨ tm N (x, μ) = M) by omega)]
      rw [hall (x, μ) (closed_spatial x μ hμ hvM),
        hall (x + ev N μ, ν) (closed_spatial (x + ev N μ) ν hν (by rw [add_ev_zero N x hμ]; exact hvM)),
        hall (x + ev N ν, μ) (closed_spatial (x + ev N ν) μ hμ (by rw [add_ev_zero N x hν]; exact hvM)),
        hall (x, ν) (closed_spatial x ν hν hvM)]

theorem abs_re_le (q : ℍr) : |q.re| ≤ ‖q‖ := by
  have h := abs_real_inner_le_norm q 1
  rw [Quaternion.inner_def, star_one, mul_one, norm_one, mul_one] at h
  exact h

theorem abs_hol_re (ω : Lk N → QBall) (p : Lk N × Fin 4) : |(hol N ω p).re| ≤ 1 := by
  refine (abs_re_le _).trans ?_
  have hb : ∀ ℓ, ‖Uq N ω ℓ‖ ≤ 1 := fun ℓ => mem_closedBall_zero_iff.1 (ω ℓ).2
  simp only [hol, holQ]
  rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
  exact mul_le_one₀ (mul_le_one₀ (mul_le_one₀ (hb _) (norm_nonneg _) (hb _)) (norm_nonneg _)
    (hb _)) (norm_nonneg _) (hb _)

theorem abs_wt (p : Lk N × Fin 4) : |wt N M p| ≤ 1 := by
  unfold wt; split_ifs <;> norm_num

theorem abs_halfAction (ω : Lk N → QBall) : |halfAction N M ω| ≤ (plaqs N).card := by
  unfold halfAction
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ p ∈ plaqs N, |wt N M p * (hol N ω p).re| ≤ ∑ _p ∈ plaqs N, (1 : ℝ) :=
        Finset.sum_le_sum (fun p _ => by
          rw [abs_mul]; exact mul_le_one₀ (abs_wt N M p) (abs_nonneg _) (abs_hol_re N ω p))
    _ = (plaqs N).card := by simp

theorem abs_halfWeight (β : ℝ) (ω : Lk N → QBall) :
    |halfWeight N M β ω| ≤ Real.exp (|β| * (plaqs N).card) := by
  unfold halfWeight
  rw [abs_of_pos (Real.exp_pos _), Real.exp_le_exp]
  calc β * halfAction N M ω ≤ |β * halfAction N M ω| := le_abs_self _
    _ = |β| * |halfAction N M ω| := abs_mul _ _
    _ ≤ |β| * (plaqs N).card := mul_le_mul_of_nonneg_left (abs_halfAction N M ω) (abs_nonneg _)

theorem continuous_Uq (ℓ : Lk N) : Continuous (fun ω : Lk N → QBall => Uq N ω ℓ) :=
  continuous_subtype_val.comp (continuous_apply ℓ)

theorem continuous_hol (p : Lk N × Fin 4) : Continuous (fun ω : Lk N → QBall => hol N ω p) := by
  simp only [hol, holQ]
  exact (((continuous_Uq N _).mul (continuous_Uq N _)).mul (continuous_Uq N _).star).mul
    (continuous_Uq N _).star

theorem continuous_halfWeight (β : ℝ) : Continuous (halfWeight N M β) := by
  unfold halfWeight halfAction
  exact Real.continuous_exp.comp (continuous_const.mul (continuous_finsetSum _ (fun p _ =>
    continuous_const.mul (Quaternion.continuous_re.comp (continuous_hol N p)))))

theorem continuous_wilsonWeight (β : ℝ) : Continuous (wilsonWeight N β) := by
  unfold wilsonWeight action
  exact Real.continuous_exp.comp (continuous_const.mul (continuous_finsetSum _ (fun p _ =>
    Quaternion.continuous_re.comp (continuous_hol N p))))

/-- The Wilson measure of `SU(2)` on the periodic lattice `(ℤ/N)⁴` (unnormalised: the positive
constant `Z⁻¹ e^{-β·#plaquettes}` is omitted; it does not change the sign of the pairing). -/
noncomputable def wilsonMeasure (β : ℝ) : Measure (Lk N → QBall) :=
  (Measure.pi fun _ : Lk N => haarBall).withDensity
    (fun ω => ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal))

/-- **Premise 10 for the Wilson measure (Lean).**  Site reflection positivity of the Wilson
measure of `SU(2)` on `(ℤ/N)⁴`, `N = 2M`, for every real `β`, every bounded measurable `f` of
the links of the closed positive half (`fixP ∨ posP`: spatial links at times `0 … M`, temporal
links from times `0 … M - 1`).  Paper A, (RP1) / Appendix RP; Osterwalder–Seiler. -/
theorem wilson_rp (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f)
    (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  have key : ∀ ω, (Real.toNNReal (wilsonWeight N β ω)) • (f (linkRefl (thL N) (sig N) ω) * f ω)
      = f (linkRefl (thL N) (sig N) ω) * f ω *
        (halfWeight N M β ω * halfWeight N M β (linkRefl (thL N) (sig N) ω)) := by
    intro ω
    rw [NNReal.smul_def, smul_eq_mul, Real.coe_toNNReal (wilsonWeight N β ω) (Real.exp_pos _).le,
      weight_factor N M hN β ω]
    ring
  simp_rw [key]
  exact rp_weighted haarBall (thL N) (sig N) (fixP N M) (posP N M) (thL_invol N)
    (hfix_torus hN) (fun ℓ h => hposfix_torus ℓ h) (hA_torus hN) (hB_torus hN)
    (sig_preserving N) f (halfWeight N M β) hf (continuous_halfWeight N M β).measurable Cf
    (Real.exp (|β| * (plaqs N).card)) hfC (abs_halfWeight N M β) hfdep
    (fun ω ω' h => by unfold halfWeight; rw [halfAction_dep N M hN ω ω' h])

/-- the half-slab of `BoxReflSlab.lean` (`halfSlab L n` with `N = 2ⁿ L`) -/
def halfSlabT : Set (ZMod N) := {t | ∃ i : ℕ, 2 * i + 2 ≤ N ∧ t = (i : ZMod N)}

theorem halfSlab_closed (hN : N = 2 * M) (ℓ : Lk N) (h : ℓ.1 0 ∈ halfSlabT N) :
    fixP N M ℓ ∨ posP N M ℓ := by
  obtain ⟨i, hi, he⟩ := h
  obtain ⟨x, κ⟩ := ℓ
  simp only at he
  have hv : (x 0).val = i := by rw [he, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]
  by_cases h2 : κ = 0
  · subst h2; exact closed_temporal x (by omega)
  · exact closed_spatial x κ h2 (by omega)

/-- **The hypothesis `hRP` of `reflection_positive_down_slab`, for the Wilson measure**, on
the class narrowed to bounded measurable functions of the half-slab links (the class of
`FineRP` and of paper A's (RP1)). -/
theorem wilson_rp_halfSlab (hN : N = 2 * M) (β : ℝ) :
    ∀ f ∈ {f : (Lk N → QBall) → ℝ | Measurable f ∧ (∃ C, ∀ ω, |f ω| ≤ C) ∧
        ∃ φ : ({ℓ : Lk N // ℓ.1 0 ∈ halfSlabT N} → QBall) → ℝ, ∀ ω, f ω = φ (fun ℓ => ω ℓ.1)},
      0 ≤ ∫ ω, f (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := by
  rintro f ⟨hf, ⟨C, hC⟩, φ, hφ⟩
  refine wilson_rp N M hN β f hf C hC (fun ω ω' h => ?_)
  rw [hφ ω, hφ ω']
  congr 1
  funext ℓ
  exact h ℓ.1 (halfSlab_closed N M hN ℓ.1 ℓ.2)

/-- the side condition `N = 2M` is met by `N = 2ⁿ L` for `n ≥ 1` -/
theorem even_box (L n : ℕ) (hn : 1 ≤ n) : 2 ^ n * L = 2 * (2 ^ (n - 1) * L) := by
  obtain ⟨k, rfl⟩ : ∃ k, n = k + 1 := ⟨n - 1, by omega⟩
  rw [pow_succ]; simp; ring

end Wilson

end TorusRP



/-!
# Replica-and-swap covariance bound (table 2, row 10; the first volume-uniform example)

The statement `SwapDecay.CovBound` is copied verbatim from an earlier file
an earlier file (definitions `gibbs`, `Separated`, `CovBound`). Here it
is **proved** for a constant fibre (`Ω i = Y` for every site, site measures `μ i` arbitrary
probability measures on `Y`), which covers lattice gauge theories (`Y = SU(2)`).

Paper proof : `2 Z² Cov = ∫∫ (F x - F y)(G x - G y) W x W y`; expand
`W x W y = ∏_b (1 + σ_b)`, `σ_b = w_b(x) w_b(y) - 1 ≥ 0`, over bond sets `Γ`; for a separated
`Γ` the swap of the two replicas on `T` reverses the sign of the term; the rest is bounded by
`Σ_{π ∈ P} ∏_{b ∈ π} σ_b ∏_{b ∉ π}(1 + σ_b) ≤ Σ_π (1 - M⁻²)^{|π|} W x W y`.
The bound has no volume factor: it depends only on the bond sets `π` (for a lattice, the chains
from `A` to `A'`), which is what makes it uniform in the volume.
-/

open MeasureTheory

namespace SwapDecay

/-- Gibbs expectation for the weight `∏ b, w b` over the product measure. -/
noncomputable def gibbs {ι B : Type*} [Fintype ι] [Fintype B] {Ω : ι → Type*}
    [∀ i, MeasurableSpace (Ω i)] (μ : ∀ i, Measure (Ω i)) (w : B → (∀ i, Ω i) → ℝ)
    (H : (∀ i, Ω i) → ℝ) : ℝ :=
  (∫ x, H x * ∏ b, w b x ∂(Measure.pi μ)) / ∫ x, ∏ b, w b x ∂(Measure.pi μ)

/-- the bond set `Γ` does not connect `A` to `A'` -/
def Separated {ι B : Type*} [DecidableEq ι] (supp : B → Finset ι) (A A' : Finset ι)
    (Γ : Finset B) : Prop :=
  ∃ T : Finset ι, A ⊆ T ∧ Disjoint T A' ∧ ∀ b ∈ Γ, supp b ⊆ T ∨ Disjoint (supp b) T

/-- **Statement (verbatim): replica-and-swap covariance bound.** -/
def CovBound {ι B : Type*} [Fintype ι] [DecidableEq ι] [Fintype B]
    {Ω : ι → Type*} [∀ i, MeasurableSpace (Ω i)]
    (μ : ∀ i, Measure (Ω i)) [∀ i, IsProbabilityMeasure (μ i)]
    (supp : B → Finset ι) (w : B → (∀ i, Ω i) → ℝ) (M : ℝ) (A A' : Finset ι)
    (F G : (∀ i, Ω i) → ℝ) (cF cG : ℝ) (P : Finset (Finset B)) : Prop :=
  (∀ b, Measurable (w b)) →
  (∀ b x y, (∀ i ∈ supp b, x i = y i) → w b x = w b y) →
  1 ≤ M → (∀ b x, 1 ≤ w b x ∧ w b x ≤ M) →
  Measurable F → Measurable G →
  (∀ x y, (∀ i ∈ A, x i = y i) → F x = F y) →
  (∀ x y, (∀ i ∈ A', x i = y i) → G x = G y) →
  (∀ x, |F x| ≤ cF) → (∀ x, |G x| ≤ cG) →
  (∀ Γ : Finset B, ¬ Separated supp A A' Γ → ∃ π ∈ P, π ⊆ Γ) →
  |gibbs μ w (fun x => F x * G x) - gibbs μ w F * gibbs μ w G|
    ≤ 2 * cF * cG * ∑ π ∈ P, (1 - M⁻¹ ^ 2) ^ π.card

section Proof

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Y : Type*} [MeasurableSpace Y]

lemma intg {α : Type*} [MeasurableSpace α] {ρ : Measure α} [IsFiniteMeasure ρ] {h : α → ℝ}
    (hm : Measurable h) (C : ℝ) (hC : ∀ x, |h x| ≤ C) : Integrable h ρ :=
  Integrable.of_bound hm.aestronglyMeasurable C (ae_of_all _ fun x => by
    rw [Real.norm_eq_abs]; exact hC x)

/-- take the coordinates in `T` from `y`, the others from `x` -/
def mixT (T : Finset ι) (x y : ι → Y) : ι → Y := fun i => if i ∈ T then y i else x i

/-- the swap of the two replicas on `T` -/
def swapT (T : Finset ι) (p : (ι → Y) × (ι → Y)) : (ι → Y) × (ι → Y) :=
  (mixT T p.1 p.2, mixT T p.2 p.1)

theorem swapT_preserving (μ : ι → Measure Y) [∀ i, IsProbabilityMeasure (μ i)] (T : Finset ι) :
    MeasurePreserving (swapT T) ((Measure.pi μ).prod (Measure.pi μ))
      ((Measure.pi μ).prod (Measure.pi μ)) := by
  have he := measurePreserving_arrowProdEquivProdArrow Y Y ι μ μ
  have hcw := measurePreserving_pi (fun i => (μ i).prod (μ i)) (fun i => (μ i).prod (μ i))
    (f := fun i => if i ∈ T then (Prod.swap : Y × Y → Y × Y) else id)
    (fun i => by
      by_cases hi : i ∈ T
      · simp only [hi, if_true]; exact Measure.measurePreserving_swap
      · simp only [hi, if_false]; exact MeasurePreserving.id _)
  have hcomp := (he.comp hcw).comp he.symm
  convert hcomp using 1
  funext p
  obtain ⟨x, y⟩ := p
  refine Prod.ext (funext fun i => ?_) (funext fun i => ?_)
  · by_cases hi : i ∈ T
    · simp [swapT, mixT, hi, MeasurableEquiv.arrowProdEquivProdArrow, Equiv.arrowProdEquivProdArrow]
    · simp [swapT, mixT, hi, MeasurableEquiv.arrowProdEquivProdArrow, Equiv.arrowProdEquivProdArrow]
  · by_cases hi : i ∈ T
    · simp [swapT, mixT, hi, MeasurableEquiv.arrowProdEquivProdArrow, Equiv.arrowProdEquivProdArrow]
    · simp [swapT, mixT, hi, MeasurableEquiv.arrowProdEquivProdArrow, Equiv.arrowProdEquivProdArrow]

theorem measurable_mixT (T : Finset ι) :
    Measurable (fun p : (ι → Y) × (ι → Y) => mixT T p.1 p.2) := by
  refine measurable_pi_lambda _ (fun i => ?_)
  unfold mixT
  by_cases hi : i ∈ T
  · simp only [hi, if_true]; exact (measurable_pi_apply i).comp measurable_snd
  · simp only [hi, if_false]; exact (measurable_pi_apply i).comp measurable_fst

/-- `∏_{b ∈ univ \ Γ} g_b` with `g = 0` on `π`, `1` off `π` is the indicator of `π ⊆ Γ` -/
lemma prod_indicator {B : Type*} [Fintype B] [DecidableEq B] (π Γ : Finset B) :
    ∏ b ∈ Finset.univ \ Γ, (if b ∈ π then (0 : ℝ) else 1) = if π ⊆ Γ then 1 else 0 := by
  split_ifs with h
  · refine Finset.prod_eq_one (fun b hb => ?_)
    have hb' : b ∉ Γ := (Finset.mem_sdiff.1 hb).2
    have : b ∉ π := fun hπ => hb' (h hπ)
    simp [this]
  · obtain ⟨b, hbπ, hbΓ⟩ := Finset.not_subset.1 h
    exact Finset.prod_eq_zero (Finset.mem_sdiff.2 ⟨Finset.mem_univ b, hbΓ⟩) (by simp [hbπ])

/-- the sum over the supersets of `π` -/
lemma sum_supersets {B : Type*} [Fintype B] [DecidableEq B] (π : Finset B) (σ : B → ℝ) :
    ∑ Γ ∈ Finset.univ.powerset, (if π ⊆ Γ then ∏ b ∈ Γ, σ b else 0)
      = ∏ b, (σ b + if b ∈ π then 0 else 1) := by
  rw [Finset.prod_add]
  refine Finset.sum_congr rfl (fun Γ _ => ?_)
  rw [prod_indicator]
  split_ifs <;> simp

/-- the weight `W x = ∏_b w_b x` -/
noncomputable def Wt {B : Type*} [Fintype B] (w : B → (ι → Y) → ℝ) (x : ι → Y) : ℝ := ∏ b, w b x

/-- `σ_b(x, y) = w_b(x) w_b(y) - 1` -/
noncomputable def sg {B : Type*} (w : B → (ι → Y) → ℝ) (b : B) (p : (ι → Y) × (ι → Y)) : ℝ :=
  w b p.1 * w b p.2 - 1

/-- the term of the bond set `Γ` -/
noncomputable def dT {B : Type*} (F G : (ι → Y) → ℝ) (w : B → (ι → Y) → ℝ) (Γ : Finset B)
    (p : (ι → Y) × (ι → Y)) : ℝ :=
  (F p.1 - F p.2) * (G p.1 - G p.2) * ∏ b ∈ Γ, sg w b p

theorem covBound_const {B : Type*} [Fintype B] [DecidableEq B]
    (μ : ι → Measure Y) [∀ i, IsProbabilityMeasure (μ i)]
    (supp : B → Finset ι) (w : B → (ι → Y) → ℝ) (M : ℝ) (A A' : Finset ι)
    (F G : (ι → Y) → ℝ) (cF cG : ℝ) (P : Finset (Finset B)) :
    CovBound (Ω := fun _ => Y) μ supp w M A A' F G cF cG P := by
  classical
  intro hwm hwdep hM hw hFm hGm hFdep hGdep hFC hGC hP
  -- a point of the configuration space
  have hne : Nonempty (ι → Y) := by
    by_cases h : IsEmpty ι
    · exact ⟨fun i => (h.false i).elim⟩
    · obtain ⟨i⟩ := not_isEmpty_iff.1 h
      haveI := nonempty_of_isProbabilityMeasure (μ i)
      exact ⟨fun _ => Classical.arbitrary Y⟩
  obtain ⟨x₀⟩ := hne
  have hcF : 0 ≤ cF := (abs_nonneg _).trans (hFC x₀)
  have hcG : 0 ≤ cG := (abs_nonneg _).trans (hGC x₀)
  have hM0 : 0 ≤ M := zero_le_one.trans hM
  -- the weight
  have hW1 : ∀ x, 1 ≤ Wt w x := fun x => by
    have h := Finset.prod_le_prod (s := Finset.univ) (f := fun _ => (1 : ℝ)) (g := fun b => w b x)
      (fun b _ => zero_le_one) (fun b _ => (hw b x).1)
    simpa [Wt] using h
  have hW0 : ∀ x, 0 ≤ Wt w x := fun x => zero_le_one.trans (hW1 x)
  set K : ℝ := M ^ Fintype.card B with hK
  have hWM : ∀ x, Wt w x ≤ K := fun x => by
    have h := Finset.prod_le_prod (s := Finset.univ) (f := fun b => w b x) (g := fun _ => M)
      (fun b _ => zero_le_one.trans (hw b x).1) (fun b _ => (hw b x).2)
    simpa [Wt, Finset.prod_const, hK] using h
  have hWm : Measurable (Wt w) := by
    unfold Wt; exact Finset.measurable_prod _ (fun b _ => hwm b)
  have hWa : ∀ x, |Wt w x| ≤ K := fun x => by rw [abs_of_nonneg (hW0 x)]; exact hWM x
  have hFa : ∀ x, |F x| ≤ cF := hFC
  -- integrability on the replica space
  have iW : Integrable (Wt w) (Measure.pi μ) := intg hWm K hWa
  have iFW : Integrable (fun x => F x * Wt w x) (Measure.pi μ) :=
    intg (hFm.mul hWm) (cF * K) (fun x => by
      rw [abs_mul]; exact mul_le_mul (hFC x) (hWa x) (abs_nonneg _) hcF)
  have iGW : Integrable (fun x => G x * Wt w x) (Measure.pi μ) :=
    intg (hGm.mul hWm) (cG * K) (fun x => by
      rw [abs_mul]; exact mul_le_mul (hGC x) (hWa x) (abs_nonneg _) hcG)
  have iFGW : Integrable (fun x => F x * G x * Wt w x) (Measure.pi μ) :=
    intg ((hFm.mul hGm).mul hWm) (cF * cG * K) (fun x => by
      rw [abs_mul, abs_mul]
      exact mul_le_mul (mul_le_mul (hFC x) (hGC x) (abs_nonneg _) hcF) (hWa x) (abs_nonneg _)
        (mul_nonneg hcF hcG))
  -- Z
  set Z : ℝ := ∫ x, Wt w x ∂(Measure.pi μ) with hZ
  have hZ1 : 1 ≤ Z := by
    have h := integral_mono (integrable_const (1 : ℝ)) iW hW1
    simpa using h
  have hZ0 : 0 < Z := lt_of_lt_of_le zero_lt_one hZ1
  -- step 1: the double integral
  have e1 : ∫ p : (ι → Y) × (ι → Y), F p.1 * G p.1 * Wt w p.1 * Wt w p.2
      ∂((Measure.pi μ).prod (Measure.pi μ)) = (∫ x, F x * G x * Wt w x ∂(Measure.pi μ)) * Z :=
    integral_prod_mul (fun x => F x * G x * Wt w x) (Wt w)
  have e2 : ∫ p : (ι → Y) × (ι → Y), F p.1 * Wt w p.1 * (G p.2 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ))
      = (∫ x, F x * Wt w x ∂(Measure.pi μ)) * ∫ x, G x * Wt w x ∂(Measure.pi μ) :=
    integral_prod_mul (fun x => F x * Wt w x) (fun x => G x * Wt w x)
  have e3 : ∫ p : (ι → Y) × (ι → Y), G p.1 * Wt w p.1 * (F p.2 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ))
      = (∫ x, G x * Wt w x ∂(Measure.pi μ)) * ∫ x, F x * Wt w x ∂(Measure.pi μ) :=
    integral_prod_mul (fun x => G x * Wt w x) (fun x => F x * Wt w x)
  have e4 : ∫ p : (ι → Y) × (ι → Y), Wt w p.1 * (F p.2 * G p.2 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ)) = Z * ∫ x, F x * G x * Wt w x ∂(Measure.pi μ) :=
    integral_prod_mul (Wt w) (fun x => F x * G x * Wt w x)
  have i1 : Integrable (fun p : (ι → Y) × (ι → Y) => F p.1 * G p.1 * Wt w p.1 * Wt w p.2)
      ((Measure.pi μ).prod (Measure.pi μ)) := iFGW.mul_prod iW
  have i2 : Integrable (fun p : (ι → Y) × (ι → Y) => F p.1 * Wt w p.1 * (G p.2 * Wt w p.2))
      ((Measure.pi μ).prod (Measure.pi μ)) := iFW.mul_prod iGW
  have i3 : Integrable (fun p : (ι → Y) × (ι → Y) => G p.1 * Wt w p.1 * (F p.2 * Wt w p.2))
      ((Measure.pi μ).prod (Measure.pi μ)) := iGW.mul_prod iFW
  have i4 : Integrable (fun p : (ι → Y) × (ι → Y) => Wt w p.1 * (F p.2 * G p.2 * Wt w p.2))
      ((Measure.pi μ).prod (Measure.pi μ)) := iW.mul_prod iFGW
  have i12 : Integrable (fun p : (ι → Y) × (ι → Y) => F p.1 * G p.1 * Wt w p.1 * Wt w p.2
      - F p.1 * Wt w p.1 * (G p.2 * Wt w p.2)) ((Measure.pi μ).prod (Measure.pi μ)) := i1.sub i2
  have i123 : Integrable (fun p : (ι → Y) × (ι → Y) => F p.1 * G p.1 * Wt w p.1 * Wt w p.2
      - F p.1 * Wt w p.1 * (G p.2 * Wt w p.2) - G p.1 * Wt w p.1 * (F p.2 * Wt w p.2))
      ((Measure.pi μ).prod (Measure.pi μ)) := i12.sub i3
  have hD : ∫ p : (ι → Y) × (ι → Y), (F p.1 - F p.2) * (G p.1 - G p.2) * (Wt w p.1 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ))
      = 2 * (Z * (∫ x, F x * G x * Wt w x ∂(Measure.pi μ))
        - (∫ x, F x * Wt w x ∂(Measure.pi μ)) * ∫ x, G x * Wt w x ∂(Measure.pi μ)) := by
    have hfun : (fun p : (ι → Y) × (ι → Y) =>
        (F p.1 - F p.2) * (G p.1 - G p.2) * (Wt w p.1 * Wt w p.2))
        = fun p => F p.1 * G p.1 * Wt w p.1 * Wt w p.2 - F p.1 * Wt w p.1 * (G p.2 * Wt w p.2)
          - G p.1 * Wt w p.1 * (F p.2 * Wt w p.2) + Wt w p.1 * (F p.2 * G p.2 * Wt w p.2) := by
      funext p; ring
    rw [hfun, integral_add i123 i4, integral_sub i12 i3, integral_sub i1 i2, e1, e2, e3, e4]
    ring
  -- step 2: expansion over bond sets
  have hsg0 : ∀ b p, 0 ≤ sg w b p := fun b p => by
    unfold sg; nlinarith [(hw b p.1).1, (hw b p.2).1]
  have hsgM : ∀ b p, sg w b p ≤ M ^ 2 := fun b p => by
    unfold sg; nlinarith [(hw b p.1).1, (hw b p.2).1, (hw b p.1).2, (hw b p.2).2]
  have hsgm : ∀ b, Measurable (sg w b) := fun b => by
    unfold sg; exact (((hwm b).comp measurable_fst).mul ((hwm b).comp measurable_snd)).sub_const _
  have hWW : ∀ p : (ι → Y) × (ι → Y), Wt w p.1 * Wt w p.2
      = ∑ Γ ∈ (Finset.univ : Finset B).powerset, ∏ b ∈ Γ, sg w b p := by
    intro p
    have h : Wt w p.1 * Wt w p.2 = ∏ b, (sg w b p + 1) := by
      unfold Wt sg; rw [← Finset.prod_mul_distrib]; simp
    rw [h, Finset.prod_add]
    simp
  have hdm : ∀ Γ : Finset B, Measurable (dT F G w Γ) := fun Γ => by
    unfold dT
    exact (((hFm.comp measurable_fst).sub (hFm.comp measurable_snd)).mul
      ((hGm.comp measurable_fst).sub (hGm.comp measurable_snd))).mul
      (Finset.measurable_prod _ (fun b _ => hsgm b))
  have hdb : ∀ Γ : Finset B, ∀ p, |dT F G w Γ p| ≤ 2 * cF * (2 * cG) * ∏ b ∈ Γ, sg w b p :=
    fun Γ p => by
      unfold dT
      rw [abs_mul, abs_mul, abs_of_nonneg (Finset.prod_nonneg (fun b _ => hsg0 b p))]
      refine mul_le_mul_of_nonneg_right (mul_le_mul ?_ ?_ (abs_nonneg _) (by linarith)) 
        (Finset.prod_nonneg (fun b _ => hsg0 b p))
      · exact (abs_sub _ _).trans (by linarith [hFC p.1, hFC p.2])
      · exact (abs_sub _ _).trans (by linarith [hGC p.1, hGC p.2])
  have hdi : ∀ Γ : Finset B, Integrable (dT F G w Γ) ((Measure.pi μ).prod (Measure.pi μ)) :=
    fun Γ => intg (hdm Γ) (2 * cF * (2 * cG) * (M ^ 2) ^ Γ.card) (fun p =>
      (hdb Γ p).trans (mul_le_mul_of_nonneg_left
        (by
          have h := Finset.prod_le_prod (s := Γ) (fun b _ => hsg0 b p) (fun b _ => hsgM b p)
          simpa [Finset.prod_const] using h)
        (by positivity)))
  have hsum : ∀ p : (ι → Y) × (ι → Y),
      (F p.1 - F p.2) * (G p.1 - G p.2) * (Wt w p.1 * Wt w p.2)
        = ∑ Γ ∈ (Finset.univ : Finset B).powerset, dT F G w Γ p := by
    intro p
    rw [hWW p, Finset.mul_sum]
    rfl
  -- step 3: separated bond sets give zero
  have hsep0 : ∀ Γ : Finset B, Separated supp A A' Γ →
      ∫ p, dT F G w Γ p ∂((Measure.pi μ).prod (Measure.pi μ)) = 0 := by
    rintro Γ ⟨T, hAT, hTA', hΓ⟩
    have hinv : ∀ p, dT F G w Γ (swapT T p) = - dT F G w Γ p := by
      rintro ⟨x, y⟩
      have f1 : F (mixT T x y) = F y := hFdep _ _ (fun i hi => by simp [mixT, hAT hi])
      have f2 : F (mixT T y x) = F x := hFdep _ _ (fun i hi => by simp [mixT, hAT hi])
      have g1 : G (mixT T x y) = G x := hGdep _ _ (fun i hi => by
        simp [mixT, Finset.disjoint_right.1 hTA' hi])
      have g2 : G (mixT T y x) = G y := hGdep _ _ (fun i hi => by
        simp [mixT, Finset.disjoint_right.1 hTA' hi])
      have hs : ∏ b ∈ Γ, sg w b (swapT T (x, y)) = ∏ b ∈ Γ, sg w b (x, y) := by
        refine Finset.prod_congr rfl (fun b hb => ?_)
        simp only [sg, swapT]
        rcases hΓ b hb with h | h
        · rw [hwdep b (mixT T x y) y (fun i hi => by simp [mixT, h hi]),
            hwdep b (mixT T y x) x (fun i hi => by simp [mixT, h hi])]
          ring
        · rw [hwdep b (mixT T x y) x (fun i hi => by simp [mixT, Finset.disjoint_left.1 h hi]),
            hwdep b (mixT T y x) y (fun i hi => by simp [mixT, Finset.disjoint_left.1 h hi])]
      unfold dT
      simp only [swapT] at hs ⊢
      rw [hs, f1, f2, g1, g2]
      ring
    have h1 : ∫ p, dT F G w Γ p ∂((Measure.pi μ).prod (Measure.pi μ))
        = ∫ p, dT F G w Γ (swapT T p) ∂((Measure.pi μ).prod (Measure.pi μ)) := by
      conv_lhs => rw [← (swapT_preserving μ T).map_eq]
      exact integral_map (swapT_preserving μ T).measurable.aemeasurable
        (hdm Γ).aestronglyMeasurable
    have h2 : ∫ p, dT F G w Γ (swapT T p) ∂((Measure.pi μ).prod (Measure.pi μ))
        = - ∫ p, dT F G w Γ p ∂((Measure.pi μ).prod (Measure.pi μ)) := by
      rw [← integral_neg]
      congr 1
      funext p
      exact hinv p
    linarith
  -- step 4: the remaining bond sets
  set S := (Finset.univ : Finset B).powerset.filter (fun Γ => ¬ Separated supp A A' Γ) with hS
  have hint_split : ∫ p, (F p.1 - F p.2) * (G p.1 - G p.2) * (Wt w p.1 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ))
      = ∫ p, ∑ Γ ∈ S, dT F G w Γ p ∂((Measure.pi μ).prod (Measure.pi μ)) := by
    rw [integral_congr_ae (Filter.Eventually.of_forall hsum),
      integral_finset_sum _ (fun Γ _ => hdi Γ), integral_finset_sum _ (fun Γ _ => hdi Γ),
      ← Finset.sum_filter_add_sum_filter_not (Finset.univ : Finset B).powerset
        (fun Γ => ¬ Separated supp A A' Γ)]
    have h0 : ∑ Γ ∈ (Finset.univ : Finset B).powerset.filter
        (fun Γ => ¬ ¬ Separated supp A A' Γ),
        ∫ p, dT F G w Γ p ∂((Measure.pi μ).prod (Measure.pi μ)) = 0 :=
      Finset.sum_eq_zero (fun Γ hΓ => hsep0 Γ (not_not.1 (Finset.mem_filter.1 hΓ).2))
    rw [h0, add_zero]
  set c : ℝ := 1 - M⁻¹ ^ 2 with hc
  have hc0 : 0 ≤ c := by
    rw [hc, sub_nonneg]
    have : M⁻¹ ≤ 1 := inv_le_one_of_one_le₀ hM
    have h0 : 0 ≤ M⁻¹ := inv_nonneg.2 hM0
    nlinarith
  have hfac : ∀ b p, sg w b p ≤ c * (sg w b p + 1) := fun b p => by
    have hMp : 0 < M := lt_of_lt_of_le zero_lt_one hM
    have hww : w b p.1 * w b p.2 ≤ M ^ 2 := by
      nlinarith [(hw b p.1).1, (hw b p.2).1, (hw b p.1).2, (hw b p.2).2]
    have e : sg w b p + 1 = w b p.1 * w b p.2 := by unfold sg; ring
    rw [e, hc]
    unfold sg
    have hM2 : M⁻¹ ^ 2 * (w b p.1 * w b p.2) ≤ 1 := by
      rw [inv_pow]
      rw [inv_mul_le_iff₀ (by positivity)]
      linarith
    nlinarith [hM2]
  have hpoint : ∀ p : (ι → Y) × (ι → Y), ∑ Γ ∈ S, ∏ b ∈ Γ, sg w b p
      ≤ ∑ π ∈ P, c ^ π.card * (Wt w p.1 * Wt w p.2) := by
    intro p
    have ha0 : ∀ Γ : Finset B, 0 ≤ ∏ b ∈ Γ, sg w b p :=
      fun Γ => Finset.prod_nonneg (fun b _ => hsg0 b p)
    calc ∑ Γ ∈ S, ∏ b ∈ Γ, sg w b p
        ≤ ∑ Γ ∈ S, ∑ π ∈ P, (if π ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0) := by
          refine Finset.sum_le_sum (fun Γ hΓ => ?_)
          obtain ⟨π, hπP, hπΓ⟩ := hP Γ (Finset.mem_filter.1 hΓ).2
          calc ∏ b ∈ Γ, sg w b p = (if π ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0) := by
                rw [if_pos hπΓ]
            _ ≤ ∑ π' ∈ P, (if π' ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0) :=
                Finset.single_le_sum (f := fun π' => if π' ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0)
                  (fun π' _ => by split_ifs; exacts [ha0 Γ, le_rfl]) hπP
      _ = ∑ π ∈ P, ∑ Γ ∈ S, (if π ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0) := Finset.sum_comm
      _ ≤ ∑ π ∈ P, ∑ Γ ∈ (Finset.univ : Finset B).powerset,
            (if π ⊆ Γ then ∏ b ∈ Γ, sg w b p else 0) := by
          refine Finset.sum_le_sum (fun π _ => ?_)
          exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
            (fun Γ _ _ => by split_ifs; exacts [ha0 Γ, le_rfl])
      _ = ∑ π ∈ P, ∏ b, (sg w b p + if b ∈ π then 0 else 1) := by
          refine Finset.sum_congr rfl (fun π _ => ?_)
          exact sum_supersets π (fun b => sg w b p)
      _ ≤ ∑ π ∈ P, c ^ π.card * (Wt w p.1 * Wt w p.2) := by
          refine Finset.sum_le_sum (fun π _ => ?_)
          have h1 : ∀ b ∈ (Finset.univ : Finset B), (sg w b p + if b ∈ π then 0 else 1)
              ≤ (if b ∈ π then c else 1) * (sg w b p + 1) := by
            intro b _
            split_ifs
            · simpa using hfac b p
            · simp
          have h2 := Finset.prod_le_prod (fun b _ => by
            split_ifs
            · simpa using hsg0 b p
            · linarith [hsg0 b p]) h1
          rw [Finset.prod_mul_distrib, Fintype.prod_ite_mem, Finset.prod_const] at h2
          have h3 : ∏ b, (sg w b p + 1) = Wt w p.1 * Wt w p.2 := by
            unfold Wt sg; rw [← Finset.prod_mul_distrib]; simp
          rw [h3] at h2
          exact h2
  -- step 5: the bound
  have iWW2 : Integrable (fun p : (ι → Y) × (ι → Y) => Wt w p.1 * Wt w p.2)
      ((Measure.pi μ).prod (Measure.pi μ)) := iW.mul_prod iW
  have hbound : |∫ p, (F p.1 - F p.2) * (G p.1 - G p.2) * (Wt w p.1 * Wt w p.2)
      ∂((Measure.pi μ).prod (Measure.pi μ))|
      ≤ 2 * cF * (2 * cG) * (∑ π ∈ P, c ^ π.card) * (Z * Z) := by
    rw [hint_split]
    have iS : Integrable (fun p => ∑ Γ ∈ S, dT F G w Γ p)
        ((Measure.pi μ).prod (Measure.pi μ)) := integrable_finset_sum _ (fun Γ _ => hdi Γ)
    have iWW : Integrable (fun p : (ι → Y) × (ι → Y) =>
        2 * cF * (2 * cG) * ∑ π ∈ P, c ^ π.card * (Wt w p.1 * Wt w p.2))
        ((Measure.pi μ).prod (Measure.pi μ)) :=
      (integrable_finset_sum _ (fun π _ => (iWW2.const_mul _))).const_mul _
    refine (abs_integral_le_integral_abs).trans ?_
    calc ∫ p, |∑ Γ ∈ S, dT F G w Γ p| ∂((Measure.pi μ).prod (Measure.pi μ))
        ≤ ∫ p, 2 * cF * (2 * cG) * ∑ π ∈ P, c ^ π.card * (Wt w p.1 * Wt w p.2)
            ∂((Measure.pi μ).prod (Measure.pi μ)) := by
          refine integral_mono iS.abs iWW (fun p => ?_)
          calc |∑ Γ ∈ S, dT F G w Γ p| ≤ ∑ Γ ∈ S, |dT F G w Γ p| := Finset.abs_sum_le_sum_abs _ _
            _ ≤ ∑ Γ ∈ S, 2 * cF * (2 * cG) * ∏ b ∈ Γ, sg w b p :=
                Finset.sum_le_sum (fun Γ _ => hdb Γ p)
            _ = 2 * cF * (2 * cG) * ∑ Γ ∈ S, ∏ b ∈ Γ, sg w b p := by rw [Finset.mul_sum]
            _ ≤ 2 * cF * (2 * cG) * ∑ π ∈ P, c ^ π.card * (Wt w p.1 * Wt w p.2) :=
                mul_le_mul_of_nonneg_left (hpoint p) (by positivity)
      _ = 2 * cF * (2 * cG) * (∑ π ∈ P, c ^ π.card) * (Z * Z) := by
          rw [integral_const_mul, integral_finset_sum _ (fun π _ => (iWW2.const_mul _))]
          have e : ∀ π ∈ P, ∫ p : (ι → Y) × (ι → Y), c ^ π.card * (Wt w p.1 * Wt w p.2)
              ∂((Measure.pi μ).prod (Measure.pi μ)) = c ^ π.card * (Z * Z) := by
            intro π _
            rw [integral_const_mul]
            congr 1
            exact integral_prod_mul (Wt w) (Wt w)
          rw [Finset.sum_congr rfl e, ← Finset.sum_mul]
          ring
  -- conclusion
  have hg1 : gibbs μ w (fun x => F x * G x) = (∫ x, F x * G x * Wt w x ∂(Measure.pi μ)) / Z := rfl
  have hg2 : gibbs μ w F = (∫ x, F x * Wt w x ∂(Measure.pi μ)) / Z := rfl
  have hg3 : gibbs μ w G = (∫ x, G x * Wt w x ∂(Measure.pi μ)) / Z := rfl
  rw [hg1, hg2, hg3]
  rw [hD] at hbound
  have hZZ : 0 < Z * Z := mul_pos hZ0 hZ0
  have ecov : (∫ x, F x * G x * Wt w x ∂(Measure.pi μ)) / Z
      - (∫ x, F x * Wt w x ∂(Measure.pi μ)) / Z * ((∫ x, G x * Wt w x ∂(Measure.pi μ)) / Z)
      = (2 * (Z * (∫ x, F x * G x * Wt w x ∂(Measure.pi μ))
        - (∫ x, F x * Wt w x ∂(Measure.pi μ)) * ∫ x, G x * Wt w x ∂(Measure.pi μ)))
        / (2 * (Z * Z)) := by
    field_simp
  rw [ecov, abs_div, abs_of_pos (by positivity : (0 : ℝ) < 2 * (Z * Z)), div_le_iff₀ (by positivity)]
  calc _ ≤ 2 * cF * (2 * cG) * (∑ π ∈ P, c ^ π.card) * (Z * Z) := hbound
    _ = 2 * cF * cG * (∑ π ∈ P, c ^ π.card) * (2 * (Z * Z)) := by ring

/-! ### The family `P` can always be taken to be the minimal non-separated bond sets -/

open Classical in
/-- the minimal bond sets that do not separate `A` from `A'` (for a graph: the self-avoiding
chains of bonds from `A` to `A'`) -/
noncomputable def minimalNonsep {B : Type*} [Fintype B] (supp : B → Finset ι) (A A' : Finset ι) :
    Finset (Finset B) :=
  (Finset.univ : Finset (Finset B)).filter
    (fun π => ¬ Separated supp A A' π ∧ ∀ π' ⊂ π, Separated supp A A' π')

theorem exists_minimal_nonsep {B : Type*} [Fintype B] (supp : B → Finset ι) (A A' : Finset ι)
    (Γ : Finset B) (h : ¬ Separated supp A A' Γ) :
    ∃ π ∈ minimalNonsep supp A A', π ⊆ Γ := by
  classical
  obtain ⟨π, hπ, hmin⟩ := Finset.exists_min_image
    (Γ.powerset.filter (fun π => ¬ Separated supp A A' π)) Finset.card
    ⟨Γ, Finset.mem_filter.2 ⟨Finset.mem_powerset.2 subset_rfl, h⟩⟩
  rw [Finset.mem_filter, Finset.mem_powerset] at hπ
  refine ⟨π, ?_, hπ.1⟩
  unfold minimalNonsep
  rw [Finset.mem_filter]
  refine ⟨Finset.mem_univ _, hπ.2, fun π' hπ' => ?_⟩
  by_contra hns
  have h2 := hmin π' (Finset.mem_filter.2
    ⟨Finset.mem_powerset.2 (hπ'.subset.trans hπ.1), hns⟩)
  exact absurd (Finset.card_lt_card hπ') (not_lt.2 h2)

/-- **The covariance bound with no hypothesis on `P`**: the sum runs over the minimal
non-separated bond sets. -/
theorem covBound_minimal {B : Type*} [Fintype B] [DecidableEq B]
    (μ : ι → Measure Y) [∀ i, IsProbabilityMeasure (μ i)]
    (supp : B → Finset ι) (w : B → (ι → Y) → ℝ) (M : ℝ) (A A' : Finset ι)
    (F G : (ι → Y) → ℝ) (cF cG : ℝ)
    (hwm : ∀ b, Measurable (w b))
    (hwdep : ∀ b x y, (∀ i ∈ supp b, x i = y i) → w b x = w b y)
    (hM : 1 ≤ M) (hw : ∀ b x, 1 ≤ w b x ∧ w b x ≤ M)
    (hFm : Measurable F) (hGm : Measurable G)
    (hFdep : ∀ x y, (∀ i ∈ A, x i = y i) → F x = F y)
    (hGdep : ∀ x y, (∀ i ∈ A', x i = y i) → G x = G y)
    (hFC : ∀ x, |F x| ≤ cF) (hGC : ∀ x, |G x| ≤ cG) :
    |gibbs μ w (fun x => F x * G x) - gibbs μ w F * gibbs μ w G|
      ≤ 2 * cF * cG * ∑ π ∈ minimalNonsep supp A A', (1 - M⁻¹ ^ 2) ^ π.card :=
  covBound_const μ supp w M A A' F G cF cG (minimalNonsep supp A A') hwm hwdep hM hw hFm hGm
    hFdep hGdep hFC hGC (exists_minimal_nonsep supp A A')

/-! ### A concrete instance: a chain, uniform in its length

Sites `0, …, L`, bonds `b = (b, b + 1)`.  `F` depends on the site `s`, `G` on the site `t ≥ s`.
Every bond set that does not separate `s` from `t` contains all the bonds between them, so `P`
is one chain of `t - s` bonds and `|Cov| ≤ 2 cF cG (1 - M⁻²)^{t - s}`, for every `L`. -/

/-- the two sites of the bond `b` -/
def chainSupp (L : ℕ) (b : Fin L) : Finset (Fin (L + 1)) := {b.castSucc, b.succ}

/-- the bonds between `s` and `t` -/
def chainPi (L s t : ℕ) : Finset (Fin L) := Finset.univ.filter (fun b => s ≤ b.val ∧ b.val < t)

theorem chain_hP (L : ℕ) (s t : Fin (L + 1)) (Γ : Finset (Fin L))
    (h : ¬ Separated (chainSupp L) {s} {t} Γ) : chainPi L s.val t.val ⊆ Γ := by
  intro j hj
  by_contra hjΓ
  apply h
  simp only [chainPi, Finset.mem_filter, Finset.mem_univ, true_and] at hj
  refine ⟨Finset.univ.filter (fun i : Fin (L + 1) => i.val ≤ j.val), ?_, ?_, ?_⟩
  · intro i hi
    rw [Finset.mem_singleton] at hi
    subst hi
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    omega
  · rw [Finset.disjoint_singleton_right]
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, not_le]
    omega
  · intro b hb
    have hbj : b.val ≠ j.val := fun e => hjΓ (Fin.ext e ▸ hb)
    rcases Nat.lt_or_gt_of_ne hbj with hlt | hgt
    · left
      intro i hi
      simp only [chainSupp, Finset.mem_insert, Finset.mem_singleton] at hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      rcases hi with rfl | rfl
      · simp only [Fin.coe_castSucc]; omega
      · simp only [Fin.val_succ]; omega
    · right
      rw [Finset.disjoint_left]
      intro i hi
      simp only [chainSupp, Finset.mem_insert, Finset.mem_singleton] at hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, not_le]
      rcases hi with rfl | rfl
      · simp only [Fin.coe_castSucc]; omega
      · simp only [Fin.val_succ]; omega

theorem card_chainPi (L : ℕ) (s t : ℕ) (ht : t ≤ L) : (chainPi L s t).card = t - s := by
  have h : (chainPi L s t).map Fin.valEmbedding = Finset.Ico s t := by
    ext n
    simp only [chainPi, Finset.mem_map, Finset.mem_filter, Finset.mem_univ, true_and,
      Fin.valEmbedding_apply, Finset.mem_Ico]
    constructor
    · rintro ⟨b, ⟨h1, h2⟩, rfl⟩
      exact ⟨h1, h2⟩
    · rintro ⟨h1, h2⟩
      exact ⟨⟨n, by omega⟩, ⟨h1, h2⟩, rfl⟩
  rw [← Finset.card_map, h, Nat.card_Ico]

/-- **Volume-uniform decay of correlations on a chain** (all hypotheses of `CovBound` paid):
nearest-neighbour weights `1 ≤ w_b ≤ M` on sites `0 … L`, `F` at site `s`, `G` at site `t`:
`|⟨F G⟩ - ⟨F⟩⟨G⟩| ≤ 2 cF cG (1 - M⁻²)^{t - s}`, the same bound for every `L`.  Meaningful for `s ≤ t` (for `t < s` the natural-number
exponent `t - s` is `0` and the bound is the trivial `2 cF cG`). -/
theorem chain_covariance (L : ℕ) (μ : Fin (L + 1) → Measure Y) [∀ i, IsProbabilityMeasure (μ i)]
    (w : Fin L → (Fin (L + 1) → Y) → ℝ) (M : ℝ) (s t : Fin (L + 1))
    (F G : (Fin (L + 1) → Y) → ℝ) (cF cG : ℝ)
    (hwm : ∀ b, Measurable (w b))
    (hwdep : ∀ b x y, (∀ i ∈ chainSupp L b, x i = y i) → w b x = w b y)
    (hM : 1 ≤ M) (hw : ∀ b x, 1 ≤ w b x ∧ w b x ≤ M)
    (hFm : Measurable F) (hGm : Measurable G)
    (hFdep : ∀ x y, x s = y s → F x = F y) (hGdep : ∀ x y, x t = y t → G x = G y)
    (hFC : ∀ x, |F x| ≤ cF) (hGC : ∀ x, |G x| ≤ cG) :
    |gibbs μ w (fun x => F x * G x) - gibbs μ w F * gibbs μ w G|
      ≤ 2 * cF * cG * (1 - M⁻¹ ^ 2) ^ (t.val - s.val) := by
  have h := covBound_const μ (chainSupp L) w M {s} {t} F G cF cG {chainPi L s.val t.val}
    hwm hwdep hM hw hFm hGm
    (fun x y hxy => hFdep x y (hxy s (Finset.mem_singleton_self s)))
    (fun x y hxy => hGdep x y (hxy t (Finset.mem_singleton_self t))) hFC hGC
    (fun Γ hΓ => ⟨_, Finset.mem_singleton_self _, chain_hP L s t Γ hΓ⟩)
  rw [Finset.sum_singleton, card_chainPi L s.val t.val (Nat.lt_succ_iff.1 t.isLt)] at h
  exact h

end Proof

end SwapDecay

/-! # Strong-coupling covariance bound for the Wilson measure of `SU(2)` on `(ℤ/N)⁴`

`SwapDecay.covBound_minimal` applied with sites = links (`Y` = the ball, reference measure the
`SU(2)` Haar measure `haarBall`), bonds = unoriented plaquettes, `w_p = exp(β Re U_p + |β|)`
(`1 ≤ w_p ≤ e^{2|β|}`).  `∏_p w_p = e^{|β| #plaquettes} · wilsonWeight`, so `gibbs` is the
Wilson expectation (`prod_plaqW`).  The bound is a sum over the minimal plaquette sets that do not
separate the supports (`minimalNonsep`) with the weight `(1 - e^{-4|β|})^{|π|}`; it has no volume
factor.  That this sum is bounded uniformly in `N` when `|β|` is small (counting the
plaquette-connected chains) is the paper step that remains (not in Lean). -/

namespace TorusRP

open MeasureTheory SwapDecay

variable (N : ℕ) [NeZero N]

/-- the four links of a plaquette -/
def plaqLinks (p : Lk N × Fin 4) : Finset (Lk N) :=
  {p.1, (p.1.1 + ev N p.1.2, p.2), (p.1.1 + ev N p.2, p.1.2), (p.1.1, p.2)}

/-- the plaquette weight shifted to be `≥ 1` -/
noncomputable def plaqW (β : ℝ) (p : plaqs N) (ω : Lk N → QBall) : ℝ :=
  Real.exp (β * (hol N ω p.1).re + |β|)

theorem prod_plaqW (β : ℝ) (ω : Lk N → QBall) :
    ∏ p : plaqs N, plaqW N β p ω = Real.exp (|β| * (plaqs N).card) * wilsonWeight N β ω := by
  unfold plaqW wilsonWeight action
  rw [← Real.exp_sum, ← Real.exp_add]
  congr 1
  rw [Finset.sum_coe_sort (plaqs N) (fun p => β * (hol N ω p).re + |β|), Finset.sum_add_distrib,
    ← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul]
  ring

theorem plaqW_bounds (β : ℝ) (p : plaqs N) (ω : Lk N → QBall) :
    1 ≤ plaqW N β p ω ∧ plaqW N β p ω ≤ Real.exp (2 * |β|) := by
  have h := abs_hol_re N ω p.1
  have h2 : |β * (hol N ω p.1).re| ≤ |β| := by
    rw [abs_mul]; exact mul_le_of_le_one_right (abs_nonneg _) h
  have h3 := abs_le.1 h2
  unfold plaqW
  constructor
  · exact Real.one_le_exp (by linarith)
  · exact Real.exp_le_exp.2 (by linarith)

theorem plaqW_dep (β : ℝ) (p : plaqs N) (x y : Lk N → QBall)
    (h : ∀ ℓ ∈ plaqLinks N p.1, x ℓ = y ℓ) : plaqW N β p x = plaqW N β p y := by
  unfold plaqW hol holQ Uq
  rw [h p.1.1 (by simp [plaqLinks]), h (p.1.1.1 + ev N p.1.1.2, p.1.2) (by simp [plaqLinks]),
    h (p.1.1.1 + ev N p.1.2, p.1.1.2) (by simp [plaqLinks]), h (p.1.1.1, p.1.2) (by simp [plaqLinks])]

theorem plaqW_measurable (β : ℝ) (p : plaqs N) : Measurable (plaqW N β p) :=
  (Real.continuous_exp.comp ((continuous_const.mul (Quaternion.continuous_re.comp
    (continuous_hol N p.1))).add continuous_const)).measurable

/-- **Covariance bound for the `SU(2)` Wilson measure on `(ℤ/N)⁴` (every `β`, every `N`).**
`F` depends on the links in `A`, `G` on those in `A'`. -/
theorem wilson_covariance (β : ℝ) (A A' : Finset (Lk N)) (F G : (Lk N → QBall) → ℝ) (cF cG : ℝ)
    (hFm : Measurable F) (hGm : Measurable G)
    (hFdep : ∀ x y, (∀ i ∈ A, x i = y i) → F x = F y)
    (hGdep : ∀ x y, (∀ i ∈ A', x i = y i) → G x = G y)
    (hFC : ∀ x, |F x| ≤ cF) (hGC : ∀ x, |G x| ≤ cG) :
    |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun x => F x * G x)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F
          * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * cG * ∑ π ∈ minimalNonsep (fun p : plaqs N => plaqLinks N p.1) A A',
          (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) ^ π.card :=
  covBound_minimal (fun _ : Lk N => haarBall) (fun p : plaqs N => plaqLinks N p.1) (plaqW N β)
    (Real.exp (2 * |β|)) A A' F G cF cG (plaqW_measurable N β)
    (fun p x y h => plaqW_dep N β p x y h)
    (Real.one_le_exp (by positivity))
    (plaqW_bounds N β) hFm hGm hFdep hGdep hFC hGC

end TorusRP

#print axioms TorusRP.prod_plaqW
#print axioms TorusRP.wilson_covariance

/-! # Minimal non-separated bond sets are self-avoiding chains, and their count — 

For bonds `b : B` with supports `supp b ⊆ ι` (for the lattice: plaquettes and their four links):
* `walk_not_separated` : the vertex set of a walk of bonds (consecutive bonds share a site) from a
  bond meeting `A` to a bond meeting `A'` is not separated.
* `exists_path_of_not_separated` : conversely a non-separated `Γ` (with `A ∩ A' = ∅`) contains a
  self-avoiding such path (reachability set; `Walk.bypass`).
* `minimal_eq_path` : every minimal non-separated set is exactly the vertex set of such a path.
* `card_chainsFrom` : at most `D^k` chains of `k + 1` bonds start at a given bond, if every bond
  meets at most `D` bonds (itself included).
* `minimalNonsep_sum_le` : with a 1-Lipschitz height `h` separating `A` and `A'` by `d₀`,
  `Σ_{π minimal} c^{|π|} ≤ #{bonds meeting A} · c (cD)^{d₀} / (1 - cD)` when `cD < 1`.
  No volume factor. Paper: (the count `|A|·24^ℓ`), here with the bond-degree `D`.
-/

namespace SwapDecay

open Finset

section ChainCount

variable {ι B : Type*} [Fintype ι] [DecidableEq ι] [Fintype B] [DecidableEq B]
  (supp : B → Finset ι)

/-- the bond graph: distinct bonds sharing a site -/
def bondGraph : SimpleGraph B where
  Adj p q := p ≠ q ∧ (supp p ∩ supp q).Nonempty
  symm := ⟨fun p q h => ⟨h.1.symm, by rw [Finset.inter_comm]; exact h.2⟩⟩
  loopless := ⟨fun p h => h.1 rfl⟩

theorem walk_sub_T {T : Finset ι} {Γ : Finset B}
    (hΓ : ∀ b ∈ Γ, supp b ⊆ T ∨ Disjoint (supp b) T)
    {u v : B} (w : (bondGraph supp).Walk u v) (hs : ∀ x ∈ w.support, x ∈ Γ)
    (hu : supp u ⊆ T) : supp v ⊆ T := by
  induction w with
  | nil => exact hu
  | @cons a b c hadj w' ih =>
    apply ih (fun x hx => hs x (by simp [hx]))
    obtain ⟨i, hi⟩ := hadj.2
    rw [Finset.mem_inter] at hi
    rcases hΓ b (hs b (by simp)) with h | h
    · exact h
    · exact absurd (hu hi.1) (Finset.disjoint_left.1 h hi.2)

/-- a walk from `A` to `A'` is not separated -/
theorem walk_not_separated (A A' : Finset ι) {u v : B} (w : (bondGraph supp).Walk u v)
    (hu : (supp u ∩ A).Nonempty) (hv : (supp v ∩ A').Nonempty) :
    ¬ Separated supp A A' w.support.toFinset := by
  rintro ⟨T, hAT, hTA', hΓ⟩
  have huT : supp u ⊆ T := by
    obtain ⟨i, hi⟩ := hu
    rw [Finset.mem_inter] at hi
    rcases hΓ u (List.mem_toFinset.2 w.start_mem_support) with h | h
    · exact h
    · exact absurd (hAT hi.2) (Finset.disjoint_left.1 h hi.1)
  have hvT := walk_sub_T supp hΓ w (fun x hx => List.mem_toFinset.2 hx) huT
  obtain ⟨i, hi⟩ := hv
  rw [Finset.mem_inter] at hi
  exact Finset.disjoint_left.1 hTA' (hvT hi.1) hi.2

open Classical in
/-- a non-separated bond set contains a self-avoiding path of bonds from `A` to `A'` -/
theorem exists_path_of_not_separated (A A' : Finset ι) (hAA' : Disjoint A A') (Γ : Finset B)
    (h : ¬ Separated supp A A' Γ) :
    ∃ u v, (supp u ∩ A).Nonempty ∧ (supp v ∩ A').Nonempty ∧
      ∃ w : (bondGraph supp).Walk u v, w.IsPath ∧ ∀ x ∈ w.support, x ∈ Γ := by
  by_contra hno
  apply h
  refine ⟨A ∪ (Γ.filter (fun q => ∃ u, (supp u ∩ A).Nonempty ∧
      ∃ w : (bondGraph supp).Walk u q, ∀ x ∈ w.support, x ∈ Γ)).biUnion supp,
    Finset.subset_union_left, ?_, ?_⟩
  · rw [Finset.disjoint_union_left]
    refine ⟨hAA', ?_⟩
    rw [Finset.disjoint_biUnion_left]
    intro q hq
    obtain ⟨_, u, hu, w, hw⟩ := Finset.mem_filter.1 hq
    by_contra hnd
    rw [Finset.not_disjoint_iff] at hnd
    obtain ⟨i, hi1, hi2⟩ := hnd
    exact hno ⟨u, q, hu, ⟨i, Finset.mem_inter.2 ⟨hi1, hi2⟩⟩, w.bypass, w.bypass_isPath,
      fun x hx => hw x (w.support_bypass_subset hx)⟩
  · intro b hb
    by_cases hbR : b ∈ Γ.filter (fun q => ∃ u, (supp u ∩ A).Nonempty ∧
        ∃ w : (bondGraph supp).Walk u q, ∀ x ∈ w.support, x ∈ Γ)
    · left
      exact fun x hx => Finset.mem_union_right _ (Finset.subset_biUnion_of_mem supp hbR hx)
    · right
      rw [Finset.disjoint_union_right]
      constructor
      · by_contra hnd
        rw [Finset.not_disjoint_iff] at hnd
        obtain ⟨i, hi1, hi2⟩ := hnd
        apply hbR
        refine Finset.mem_filter.2 ⟨hb, b, ⟨i, Finset.mem_inter.2 ⟨hi1, hi2⟩⟩,
          SimpleGraph.Walk.nil, fun x hx => ?_⟩
        simp only [SimpleGraph.Walk.support_nil, List.mem_singleton] at hx
        rw [hx]; exact hb
      · rw [Finset.disjoint_biUnion_right]
        intro q hq
        by_contra hnd
        rw [Finset.not_disjoint_iff] at hnd
        obtain ⟨i, hi1, hi2⟩ := hnd
        obtain ⟨_, u, hu, w, hw⟩ := Finset.mem_filter.1 hq
        by_cases hqb : q = b
        · exact hbR (hqb ▸ hq)
        · have hadj : (bondGraph supp).Adj q b := ⟨hqb, ⟨i, Finset.mem_inter.2 ⟨hi2, hi1⟩⟩⟩
          apply hbR
          refine Finset.mem_filter.2 ⟨hb, u, hu, w.concat hadj, fun x hx => ?_⟩
          rw [SimpleGraph.Walk.support_concat, List.mem_append,
            List.mem_singleton] at hx
          rcases hx with hx | hx
          · exact hw x hx
          · rw [hx]; exact hb

/-- membership in a filter with an explicit (unified, not synthesised) decidability instance -/
theorem prop_of_mem_filter {α : Type*} {p : α → Prop} {s : Finset α} (inst : DecidablePred p)
    {a : α} (h : a ∈ @Finset.filter α p inst s) : p a :=
  ((@Finset.mem_filter α p inst s a).1 h).2

/-- **a minimal non-separated bond set is the vertex set of a self-avoiding path** -/
theorem minimal_eq_path (A A' : Finset ι) (hAA' : Disjoint A A') {π : Finset B}
    (hπ : π ∈ minimalNonsep supp A A') :
    ∃ u v, (supp u ∩ A).Nonempty ∧ (supp v ∩ A').Nonempty ∧
      ∃ w : (bondGraph supp).Walk u v, w.IsPath ∧ π = w.support.toFinset := by
  have hπ' : ¬ Separated supp A A' π ∧ ∀ π' ⊂ π, Separated supp A A' π' := by
    unfold minimalNonsep at hπ
    first
      | (rw [Set.mem_setOf_eq] at hπ; exact hπ)
      | simpa using hπ
      | exact (Finset.mem_filter.1 hπ).2
  obtain ⟨hns, hmin⟩ := hπ'
  obtain ⟨u, v, hu, hv, w, hw, hsub⟩ := exists_path_of_not_separated supp A A' hAA' π hns
  refine ⟨u, v, hu, hv, w, hw, ?_⟩
  have hS : w.support.toFinset ⊆ π := fun x hx => hsub x (List.mem_toFinset.1 hx)
  by_contra hne
  exact walk_not_separated supp A A' w hu hv
    (hmin _ (Finset.ssubset_iff_subset_ne.2 ⟨hS, fun h => hne h.symm⟩))

/-- chains of `k + 1` bonds starting at `v`, consecutive bonds sharing a site -/
def chainsFrom : ℕ → B → Finset (List B)
  | 0, v => {[v]}
  | k + 1, v => (univ.filter (fun q => (supp v ∩ supp q).Nonempty)).biUnion
      (fun q => (chainsFrom k q).image (v :: ·))

theorem mem_chainsFrom (k : ℕ) : ∀ (v : B) (l : List B), l.length = k + 1 → l.head? = some v →
    l.IsChain (fun p q => (supp p ∩ supp q).Nonempty) → l ∈ chainsFrom supp k v := by
  induction k with
  | zero =>
    intro v l hl hh _
    match l, hl, hh with
    | [x], _, hh =>
      simp only [List.head?_cons, Option.some.injEq] at hh
      subst hh
      simp [chainsFrom]
  | succ k ih =>
    intro v l hl hh hc
    match l, hl, hh, hc with
    | a :: b :: l', hl, hh, hc =>
      simp only [List.head?_cons, Option.some.injEq] at hh
      subst hh
      rw [List.isChain_cons_cons] at hc
      simp only [chainsFrom, Finset.mem_biUnion, Finset.mem_filter, Finset.mem_univ, true_and,
        Finset.mem_image]
      refine ⟨b, hc.1, b :: l', ih b (b :: l') (by simpa using hl) rfl hc.2, rfl⟩

theorem card_chainsFrom (D : ℕ)
    (hD : ∀ p, (univ.filter (fun q => (supp p ∩ supp q).Nonempty)).card ≤ D) (k : ℕ) :
    ∀ v, (chainsFrom supp k v).card ≤ D ^ k := by
  induction k with
  | zero => intro v; simp [chainsFrom]
  | succ k ih =>
    intro v
    simp only [chainsFrom]
    calc _ ≤ ∑ q ∈ univ.filter (fun q => (supp v ∩ supp q).Nonempty),
          ((chainsFrom supp k q).image (v :: ·)).card := card_biUnion_le
      _ ≤ ∑ q ∈ univ.filter (fun q => (supp v ∩ supp q).Nonempty), D ^ k :=
          sum_le_sum (fun q _ => card_image_le.trans (ih q))
      _ ≤ D * D ^ k := by rw [sum_const, smul_eq_mul]; exact Nat.mul_le_mul_right _ (hD v)
      _ = D ^ (k + 1) := by ring

theorem walk_lip (h : B → ℤ) (hlip : ∀ p q, (supp p ∩ supp q).Nonempty → h q ≤ h p + 1)
    {u v : B} (w : (bondGraph supp).Walk u v) : h v ≤ h u + w.length := by
  induction w with
  | nil => simp
  | @cons a b c hadj w' ih =>
    have := hlip a b hadj.2
    rw [SimpleGraph.Walk.length_cons]; push_cast; linarith

theorem geom_tail_le (x : ℝ) (hx0 : 0 ≤ x) (hx1 : x < 1) (d₀ K : ℕ) :
    ∑ k ∈ Ico d₀ K, x ^ k ≤ x ^ d₀ / (1 - x) := by
  rw [Finset.sum_Ico_eq_sum_range]
  simp_rw [pow_add]
  rw [← mul_sum, div_eq_mul_inv]
  apply mul_le_mul_of_nonneg_left _ (pow_nonneg hx0 _)
  exact ((summable_geometric_of_lt_one hx0 hx1).sum_le_tsum (range (K - d₀))
    (fun j _ => pow_nonneg hx0 j)).trans_eq (tsum_geometric_of_lt_one hx0 hx1)

/-- **The sum over minimal non-separated bond sets is bounded with no volume factor.** -/
theorem minimalNonsep_sum_le (A A' : Finset ι) (hAA' : Disjoint A A') (D : ℕ)
    (hD : ∀ p, (univ.filter (fun q => (supp p ∩ supp q).Nonempty)).card ≤ D)
    (h : B → ℤ) (hlip : ∀ p q, (supp p ∩ supp q).Nonempty → h q ≤ h p + 1)
    (a : ℤ) (d₀ : ℕ) (hA : ∀ u, (supp u ∩ A).Nonempty → h u ≤ a)
    (hA' : ∀ v, (supp v ∩ A').Nonempty → a + d₀ ≤ h v)
    (c : ℝ) (hc0 : 0 ≤ c) (hcD : c * D < 1) :
    ∑ π ∈ minimalNonsep supp A A', c ^ π.card ≤
      (univ.filter (fun u => (supp u ∩ A).Nonempty)).card * c * (c * D) ^ d₀ / (1 - c * D) := by
  classical
  have key : ∀ π ∈ minimalNonsep supp A A', d₀ + 1 ≤ π.card ∧
      π ∈ ((univ.filter (fun u => (supp u ∩ A).Nonempty)).biUnion
        (chainsFrom supp (π.card - 1))).image List.toFinset := by
    intro π hπ
    obtain ⟨u, v, hu, hv, w, hw, rfl⟩ := minimal_eq_path supp A A' hAA' hπ
    have hcard : w.support.toFinset.card = w.length + 1 := by
      rw [List.toFinset_card_of_nodup hw.support_nodup, SimpleGraph.Walk.length_support]
    have hlen : h v ≤ h u + w.length := walk_lip supp h hlip w
    have h1 := hA u hu
    have h2 := hA' v hv
    refine ⟨?_, ?_⟩
    · rw [hcard]; omega
    · rw [Finset.mem_image]
      refine ⟨w.support, ?_, rfl⟩
      rw [Finset.mem_biUnion]
      refine ⟨u, Finset.mem_filter.2 ⟨Finset.mem_univ _, hu⟩, ?_⟩
      rw [hcard, Nat.add_sub_cancel]
      exact mem_chainsFrom supp _ u w.support (SimpleGraph.Walk.length_support w)
        (by rw [SimpleGraph.Walk.support_eq_cons]; rfl)
        (w.isChain_adj_support.imp (fun _ _ hq => hq.2))
  have hmaps : ∀ π ∈ minimalNonsep supp A A', π.card - 1 ∈ Ico d₀ (Fintype.card B) := by
    intro π hπ
    have h1 := (key π hπ).1
    have h2 : π.card ≤ Fintype.card B := Finset.card_le_univ π
    rw [Finset.mem_Ico]; omega
  rw [← Finset.sum_fiberwise_of_maps_to hmaps]
  have hx0 : 0 ≤ c * D := by positivity
  calc ∑ k ∈ Ico d₀ (Fintype.card B), ∑ π ∈ minimalNonsep supp A A' with π.card - 1 = k,
        c ^ π.card
      ≤ ∑ k ∈ Ico d₀ (Fintype.card B),
          ((univ.filter (fun u => (supp u ∩ A).Nonempty)).card * D ^ k : ℝ) * c ^ (k + 1) := by
        apply sum_le_sum
        intro k _
        have hfil : ∀ π ∈ (minimalNonsep supp A A').filter (fun π => π.card - 1 = k),
            c ^ π.card = c ^ (k + 1) := by
          intro π hπ
          rw [Finset.mem_filter] at hπ
          have := (key π hπ.1).1
          congr 1; omega
        rw [sum_congr rfl hfil, sum_const, nsmul_eq_mul]
        apply mul_le_mul_of_nonneg_right _ (pow_nonneg hc0 _)
        have hsub : (minimalNonsep supp A A').filter (fun π => π.card - 1 = k) ⊆
            ((univ.filter (fun u => (supp u ∩ A).Nonempty)).biUnion
              (chainsFrom supp k)).image List.toFinset := by
          intro π hπ
          rw [Finset.mem_filter] at hπ
          have := (key π hπ.1).2
          rwa [hπ.2] at this
        have h1 := card_le_card hsub
        have h2 := card_image_le (s := (univ.filter (fun u => (supp u ∩ A).Nonempty)).biUnion
          (chainsFrom supp k)) (f := List.toFinset)
        have h3 : ((univ.filter (fun u => (supp u ∩ A).Nonempty)).biUnion
            (chainsFrom supp k)).card ≤ (univ.filter (fun u => (supp u ∩ A).Nonempty)).card * D ^ k := by
          calc _ ≤ ∑ u ∈ univ.filter (fun u => (supp u ∩ A).Nonempty),
                (chainsFrom supp k u).card := card_biUnion_le
            _ ≤ ∑ u ∈ univ.filter (fun u => (supp u ∩ A).Nonempty), D ^ k :=
                sum_le_sum (fun u _ => card_chainsFrom supp D hD k u)
            _ = _ := by rw [sum_const, smul_eq_mul]
        exact_mod_cast (h1.trans h2).trans h3
    _ = (univ.filter (fun u => (supp u ∩ A).Nonempty)).card * c *
          ∑ k ∈ Ico d₀ (Fintype.card B), (c * D) ^ k := by
        rw [mul_sum]; apply sum_congr rfl; intro k _; ring
    _ ≤ (univ.filter (fun u => (supp u ∩ A).Nonempty)).card * c * ((c * D) ^ d₀ / (1 - c * D)) :=
        mul_le_mul_of_nonneg_left (geom_tail_le _ hx0 hcD d₀ _) (by positivity)
    _ = _ := by ring

end ChainCount

end SwapDecay

#print axioms SwapDecay.minimal_eq_path
#print axioms SwapDecay.minimalNonsep_sum_le

/-! # Strong coupling: volume-uniform exponential clustering of the `SU(2)` Wilson measure


`wilson_covariance` bounds the covariance by `Σ_{π minimal non-separated} c^{|π|}`,
`c = 1 - e^{-4|β|}`.  Here the plaquette geometry of `(ℤ/N)⁴` is fed to
`SwapDecay.minimalNonsep_sum_le`:
* every link lies in at most `6` unoriented plaquettes (`card_link_plaqs`), so a plaquette meets at
  most `24` plaquettes, itself included (`plaq_degree`), and at most `6|A|` plaquettes meet `A`;
* the cyclic time distance of the base point from `t₀` (`height`) changes by at most `1` between
  plaquettes sharing a link (`height_lip`).
Result (`wilson_strong_coupling`): if `24 c < 1` (i.e. `|β| < ln(24/23)/4 ≈ 0.01064`), `F` depends
on links at cyclic time distance `≤ r` from `t₀` and `G` on links at distance `≥ r + 2 + d`, then
`|⟨FG⟩ - ⟨F⟩⟨G⟩| ≤ 2 cF cG · 6|A| · c (24c)^d / (1 - 24c)` — no `N` in the constants.
Known result (Osterwalder–Seiler strong-coupling cluster expansion); this is one formalisation. -/

namespace TorusRP

open MeasureTheory SwapDecay Finset

variable (N : ℕ) [NeZero N]

/-- cyclic distance on `ℤ/N` -/
def cdist (a : ZMod N) : ℕ := a.valMinAbs.natAbs

theorem cdist_add_le (a b : ZMod N) : cdist N (a + b) ≤ cdist N a + cdist N b :=
  (ZMod.natAbs_valMinAbs_add_le a b).trans (Int.natAbs_add_le _ _)

theorem cdist_intCast_le (k : ℤ) : cdist N (k : ZMod N) ≤ k.natAbs :=
  ZMod.natAbs_min_of_le_div_two N _ k (ZMod.coe_valMinAbs _) (ZMod.natAbs_valMinAbs_le _)

theorem ev_time (μ : Fin 4) : ev N μ 0 = ((if μ = 0 then 1 else 0 : ℤ) : ZMod N) := by
  unfold ev; rw [Pi.single_apply]; split_ifs with h1 h2 h2 <;> simp_all

theorem plaqLinks_time (p : Lk N × Fin 4) (ℓ : Lk N) (h : ℓ ∈ plaqLinks N p) :
    ∃ e : ℤ, (e = 0 ∨ e = 1) ∧ ℓ.1 0 = p.1.1 0 + (e : ZMod N) := by
  simp only [plaqLinks, Finset.mem_insert, Finset.mem_singleton] at h
  rcases h with h | h | h | h <;> subst h
  · exact ⟨0, Or.inl rfl, by simp⟩
  · refine ⟨if p.1.2 = 0 then 1 else 0, by split_ifs <;> simp, ?_⟩
    simp [ev_time]
  · refine ⟨if p.2 = 0 then 1 else 0, by split_ifs <;> simp, ?_⟩
    simp [ev_time]
  · exact ⟨0, Or.inl rfl, by simp⟩

/-- the height of a plaquette: cyclic time distance of its base point from `t₀` -/
def height (t₀ : ZMod N) (p : plaqs N) : ℤ := (cdist N (p.1.1.1 0 - t₀) : ℤ)

theorem height_lip (t₀ : ZMod N) (p q : plaqs N)
    (h : (plaqLinks N p.1 ∩ plaqLinks N q.1).Nonempty) : height N t₀ q ≤ height N t₀ p + 1 := by
  obtain ⟨ℓ, hℓ⟩ := h
  rw [Finset.mem_inter] at hℓ
  obtain ⟨e, he, hpe⟩ := plaqLinks_time N p.1 ℓ hℓ.1
  obtain ⟨e', he', hqe⟩ := plaqLinks_time N q.1 ℓ hℓ.2
  have hq : q.1.1.1 0 - t₀ = (p.1.1.1 0 - t₀) + ((e - e' : ℤ) : ZMod N) := by
    push_cast; linear_combination hpe - hqe
  have h1 := cdist_add_le N (p.1.1.1 0 - t₀) ((e - e' : ℤ) : ZMod N)
  have h2 := cdist_intCast_le N (e - e')
  have h3 : (e - e').natAbs ≤ 1 := by
    rcases he with rfl | rfl <;> rcases he' with rfl | rfl <;> norm_num
  unfold height; rw [hq]; omega

/-- the plaquette having the link `ℓ` in position `jd.1`, with other direction `jd.2` -/
def plaqOf (ℓ : Lk N) (jd : Fin 4 × Fin 4) : Lk N × Fin 4 :=
  if jd.1 = 0 then ((ℓ.1, ℓ.2), jd.2)
  else if jd.1 = 1 then ((ℓ.1 - ev N jd.2, jd.2), ℓ.2)
  else if jd.1 = 2 then ((ℓ.1 - ev N jd.2, ℓ.2), jd.2)
  else ((ℓ.1, jd.2), ℓ.2)

theorem card_posOK (κ : Fin 4) :
    (univ.filter (fun jd : Fin 4 × Fin 4 =>
      ((jd.1 = 0 ∨ jd.1 = 2) ∧ κ < jd.2) ∨ ((jd.1 = 1 ∨ jd.1 = 3) ∧ jd.2 < κ))).card = 6 := by
  fin_cases κ <;> decide

theorem mem_link_image (ℓ : Lk N) (q : Lk N × Fin 4) (hq : q ∈ plaqs N)
    (h : ℓ ∈ plaqLinks N q) :
    q ∈ (univ.filter (fun jd : Fin 4 × Fin 4 =>
      ((jd.1 = 0 ∨ jd.1 = 2) ∧ ℓ.2 < jd.2) ∨ ((jd.1 = 1 ∨ jd.1 = 3) ∧ jd.2 < ℓ.2))).image
        (plaqOf N ℓ) := by
  obtain ⟨⟨x, μ⟩, ν⟩ := q
  simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hq
  simp only [plaqLinks, Finset.mem_insert, Finset.mem_singleton] at h
  rw [Finset.mem_image]
  rcases h with h | h | h | h <;> subst h
  · exact ⟨(0, ν), by simp [hq], by simp [plaqOf]⟩
  · exact ⟨(1, μ), by simp [hq], by simp [plaqOf]⟩
  · exact ⟨(2, ν), by simp [hq], by simp [plaqOf]⟩
  · exact ⟨(3, μ), by simp [hq], by simp [plaqOf]⟩

/-- **every link lies in at most six unoriented plaquettes** -/
theorem card_link_plaqs (ℓ : Lk N) :
    (univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).card ≤ 6 := by
  have hsub : (univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).map
      (Function.Embedding.subtype _) ⊆
      (univ.filter (fun jd : Fin 4 × Fin 4 =>
        ((jd.1 = 0 ∨ jd.1 = 2) ∧ ℓ.2 < jd.2) ∨ ((jd.1 = 1 ∨ jd.1 = 3) ∧ jd.2 < ℓ.2))).image
          (plaqOf N ℓ) := by
    intro q hq
    rw [Finset.mem_map] at hq
    obtain ⟨q', hq', rfl⟩ := hq
    rw [Finset.mem_filter] at hq'
    exact mem_link_image N ℓ q'.1 q'.2 hq'.2
  calc (univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).card
      = ((univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).map
          (Function.Embedding.subtype _)).card := (card_map _).symm
    _ ≤ _ := card_le_card hsub
    _ ≤ _ := card_image_le
    _ = 6 := card_posOK ℓ.2

theorem card_plaqLinks_le (p : Lk N × Fin 4) : (plaqLinks N p).card ≤ 4 := by
  unfold plaqLinks
  have h1 := card_insert_le p.1
    ({(p.1.1 + ev N p.1.2, p.2), (p.1.1 + ev N p.2, p.1.2), (p.1.1, p.2)} : Finset (Lk N))
  have h2 := card_insert_le (p.1.1 + ev N p.1.2, p.2)
    ({(p.1.1 + ev N p.2, p.1.2), (p.1.1, p.2)} : Finset (Lk N))
  have h3 := card_insert_le (p.1.1 + ev N p.2, p.1.2) ({(p.1.1, p.2)} : Finset (Lk N))
  rw [card_singleton] at h3
  omega

/-- **a plaquette meets at most 24 plaquettes (itself included)** -/
theorem plaq_degree (p : plaqs N) :
    (univ.filter (fun q : plaqs N => (plaqLinks N p.1 ∩ plaqLinks N q.1).Nonempty)).card ≤ 24 := by
  have hsub : univ.filter (fun q : plaqs N => (plaqLinks N p.1 ∩ plaqLinks N q.1).Nonempty) ⊆
      (plaqLinks N p.1).biUnion (fun ℓ => univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)) := by
    intro q hq
    rw [Finset.mem_filter] at hq
    obtain ⟨ℓ, hℓ⟩ := hq.2
    rw [Finset.mem_inter] at hℓ
    rw [Finset.mem_biUnion]
    exact ⟨ℓ, hℓ.1, Finset.mem_filter.2 ⟨Finset.mem_univ _, hℓ.2⟩⟩
  calc _ ≤ _ := card_le_card hsub
    _ ≤ ∑ ℓ ∈ plaqLinks N p.1, (univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).card :=
        card_biUnion_le
    _ ≤ ∑ _ℓ ∈ plaqLinks N p.1, 6 := sum_le_sum (fun ℓ _ => card_link_plaqs N ℓ)
    _ ≤ 4 * 6 := by
        rw [sum_const, smul_eq_mul]; exact Nat.mul_le_mul_right _ (card_plaqLinks_le N p.1)
    _ = 24 := rfl

/-- at most `6|A|` plaquettes meet `A` -/
theorem card_touch_le (A : Finset (Lk N)) :
    (univ.filter (fun u : plaqs N => (plaqLinks N u.1 ∩ A).Nonempty)).card ≤ 6 * A.card := by
  have hsub : univ.filter (fun u : plaqs N => (plaqLinks N u.1 ∩ A).Nonempty) ⊆
      A.biUnion (fun ℓ => univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)) := by
    intro q hq
    rw [Finset.mem_filter] at hq
    obtain ⟨ℓ, hℓ⟩ := hq.2
    rw [Finset.mem_inter] at hℓ
    rw [Finset.mem_biUnion]
    exact ⟨ℓ, hℓ.2, Finset.mem_filter.2 ⟨Finset.mem_univ _, hℓ.1⟩⟩
  calc _ ≤ _ := card_le_card hsub
    _ ≤ ∑ ℓ ∈ A, (univ.filter (fun q : plaqs N => ℓ ∈ plaqLinks N q.1)).card := card_biUnion_le
    _ ≤ ∑ _ℓ ∈ A, 6 := sum_le_sum (fun ℓ _ => card_link_plaqs N ℓ)
    _ = 6 * A.card := by rw [sum_const, smul_eq_mul, mul_comm]

/-- **Strong-coupling clustering of the `SU(2)` Wilson measure on `(ℤ/N)⁴`, uniform in `N`.**
`c = 1 - e^{-4|β|}` (written `1 - (e^{2|β|})⁻¹²`); window `24 c < 1`.  `F` depends on the links in
`A` (cyclic time distance `≤ r` from `t₀`), `G` on those in `A'` (distance `≥ r + 2 + d`).  The
constants `2 cF cG`, `6|A|`, `c/(1 - 24c)` and the rate `24c` do not depend on `N`. -/
theorem wilson_strong_coupling (β : ℝ)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1)
    (t₀ : ZMod N) (r d : ℕ) (A A' : Finset (Lk N))
    (hA : ∀ ℓ ∈ A, cdist N (ℓ.1 0 - t₀) ≤ r)
    (hA' : ∀ ℓ ∈ A', r + 2 + d ≤ cdist N (ℓ.1 0 - t₀))
    (F G : (Lk N → QBall) → ℝ) (cF cG : ℝ)
    (hFm : Measurable F) (hGm : Measurable G)
    (hFdep : ∀ x y, (∀ i ∈ A, x i = y i) → F x = F y)
    (hGdep : ∀ x y, (∀ i ∈ A', x i = y i) → G x = G y)
    (hFC : ∀ x, |F x| ≤ cF) (hGC : ∀ x, |G x| ≤ cG) :
    |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun x => F x * G x)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F
          * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * cG * (6 * A.card * ((1 - (Real.exp (2 * |β|))⁻¹ ^ 2) *
          (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) ^ d /
            (1 - 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)))) := by
  have hcov := wilson_covariance N β A A' F G cF cG hFm hGm hFdep hGdep hFC hGC
  set c := 1 - (Real.exp (2 * |β|))⁻¹ ^ 2 with hc
  have hc0 : 0 ≤ c := by
    have h1 : (Real.exp (2 * |β|))⁻¹ ≤ 1 := inv_le_one_of_one_le₀ (Real.one_le_exp (by positivity))
    have h2 : 0 ≤ (Real.exp (2 * |β|))⁻¹ := by positivity
    nlinarith
  have hAA' : Disjoint A A' := by
    rw [Finset.disjoint_left]
    intro ℓ h1 h2
    have := hA ℓ h1
    have := hA' ℓ h2
    omega
  have hAh : ∀ u : plaqs N, (plaqLinks N u.1 ∩ A).Nonempty → height N t₀ u ≤ (r + 1 : ℤ) := by
    intro u ⟨ℓ, hℓ⟩
    rw [Finset.mem_inter] at hℓ
    obtain ⟨e, he, hue⟩ := plaqLinks_time N u.1 ℓ hℓ.1
    have hq : u.1.1.1 0 - t₀ = (ℓ.1 0 - t₀) + ((-e : ℤ) : ZMod N) := by
      push_cast; linear_combination -hue
    have h1 := cdist_add_le N (ℓ.1 0 - t₀) ((-e : ℤ) : ZMod N)
    have h2 := cdist_intCast_le N (-e)
    have h3 : (-e).natAbs ≤ 1 := by rcases he with rfl | rfl <;> norm_num
    have h4 := hA ℓ hℓ.2
    unfold height; rw [hq]; omega
  have hA'h : ∀ v : plaqs N, (plaqLinks N v.1 ∩ A').Nonempty →
      (r + 1 : ℤ) + d ≤ height N t₀ v := by
    intro v ⟨ℓ, hℓ⟩
    rw [Finset.mem_inter] at hℓ
    obtain ⟨e, he, hve⟩ := plaqLinks_time N v.1 ℓ hℓ.1
    have hq : ℓ.1 0 - t₀ = (v.1.1.1 0 - t₀) + ((e : ℤ) : ZMod N) := by
      linear_combination hve
    have h1 := cdist_add_le N (v.1.1.1 0 - t₀) ((e : ℤ) : ZMod N)
    have h2 := cdist_intCast_le N e
    have h3 : e.natAbs ≤ 1 := by rcases he with rfl | rfl <;> norm_num
    have h4 := hA' ℓ hℓ.2
    rw [hq] at h4
    unfold height; omega
  have hsum := minimalNonsep_sum_le (fun p : plaqs N => plaqLinks N p.1) A A' hAA' 24
    (plaq_degree N) (height N t₀) (height_lip N t₀) (r + 1 : ℤ) d hAh hA'h c hc0
    (by push_cast; linarith)
  have hsum' : ∑ π ∈ minimalNonsep (fun p : plaqs N => plaqLinks N p.1) A A', c ^ π.card ≤
      ((univ.filter (fun u : plaqs N => (plaqLinks N u.1 ∩ A).Nonempty)).card : ℝ) *
        (c * (24 * c) ^ d / (1 - 24 * c)) := by
    have e1 : (c * ((24 : ℕ) : ℝ)) = 24 * c := by push_cast; ring
    rw [e1] at hsum
    calc _ ≤ _ := hsum
      _ = _ := by ring
  have hX : 0 ≤ c * (24 * c) ^ d / (1 - 24 * c) :=
    div_nonneg (mul_nonneg hc0 (pow_nonneg (by positivity) _)) (by linarith)
  have hT : ((univ.filter (fun u : plaqs N => (plaqLinks N u.1 ∩ A).Nonempty)).card : ℝ) ≤
      6 * A.card := by exact_mod_cast card_touch_le N A
  have x0 : Lk N → QBall := fun _ => ⟨0, Metric.mem_closedBall_self zero_le_one⟩
  have hcF : 0 ≤ cF := (abs_nonneg _).trans (hFC x0)
  have hcG : 0 ≤ cG := (abs_nonneg _).trans (hGC x0)
  calc _ ≤ _ := hcov
    _ ≤ 2 * cF * cG * (((univ.filter (fun u : plaqs N => (plaqLinks N u.1 ∩ A).Nonempty)).card
          : ℝ) * (c * (24 * c) ^ d / (1 - 24 * c))) :=
        mul_le_mul_of_nonneg_left hsum' (by positivity)
    _ ≤ 2 * cF * cG * (6 * A.card * (c * (24 * c) ^ d / (1 - 24 * c))) :=
        mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hT hX) (by positivity)

end TorusRP

#print axioms TorusRP.card_link_plaqs
#print axioms TorusRP.plaq_degree
#print axioms TorusRP.height_lip
#print axioms TorusRP.wilson_strong_coupling

/-! # The distance hypotheses of `wilson_strong_coupling` are satisfiable (audit point 1) -/

namespace TorusRP

open Finset

variable (N : ℕ) [NeZero N]

theorem cdist_natCast (k : ℕ) (hk : k ≤ N / 2) : cdist N (k : ZMod N) = k := by
  unfold cdist
  rw [ZMod.valMinAbs_natCast_of_le_half hk]
  simp

/-- one link at time `t₀` (distance `0 ≤ r`) and one at time `t₀ + k` (distance `k` when
`k ≤ N/2`): the two support hypotheses of `wilson_strong_coupling` hold with `k = r + 2 + d`. -/
theorem strong_coupling_supports (t₀ : ZMod N) (r d : ℕ) (hk : r + 2 + d ≤ N / 2) :
    (∀ ℓ ∈ ({((fun _ => t₀), 0)} : Finset (Lk N)), cdist N (ℓ.1 0 - t₀) ≤ r) ∧
    (∀ ℓ ∈ ({((fun _ => t₀ + ((r + 2 + d : ℕ) : ZMod N)), 0)} : Finset (Lk N)),
      r + 2 + d ≤ cdist N (ℓ.1 0 - t₀)) := by
  constructor
  · intro ℓ hℓ
    rw [Finset.mem_singleton] at hℓ
    subst hℓ
    simp [cdist]
  · intro ℓ hℓ
    rw [Finset.mem_singleton] at hℓ
    subst hℓ
    simp only [add_sub_cancel_left]
    rw [cdist_natCast N _ hk]

end TorusRP

#print axioms TorusRP.strong_coupling_supports
/-! # Reflection symmetry of the Wilson measure on `(ℤ/N)⁴` (the field `hsym` of the
reconstruction datum; paper A (St3) for the reflection)

`Θ` is an involution (`linkRefl_invol`), it preserves the product of the `SU(2)` Haar measures
(`linkRefl_preserving`) and Wilson's weight (`wilsonWeight_refl`), so
`∫ f(Θω) g(ω) dμ_W = ∫ g(Θω) f(ω) dμ_W` for measurable `f`, `g` (`wilson_refl_symm`). -/

namespace TorusRP

open MeasureTheory LinkReflection

variable (N : ℕ) [NeZero N]

theorem sig_sig (ℓ : Lk N) (q : QBall) : sig N ℓ (sig N (thL N ℓ) q) = q := by
  unfold sig
  rw [thL_snd]
  split_ifs
  · apply Subtype.ext
    show star (star (q : Quaternion ℝ)) = q
    exact star_star _
  · rfl

theorem linkRefl_invol (ω : Lk N → QBall) :
    linkRefl (thL N) (sig N) (linkRefl (thL N) (sig N) ω) = ω := by
  funext ℓ
  show sig N ℓ (sig N (thL N ℓ) (ω (thL N (thL N ℓ)))) = ω ℓ
  rw [thL_invol N ℓ, sig_sig]

theorem linkRefl_preserving :
    MeasurePreserving (linkRefl (thL N) (sig N)) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  let e : Lk N ≃ Lk N := (thL_invol N).toPerm
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) e
  have hσ := measurePreserving_pi (fun _ : Lk N => haarBall) (fun _ : Lk N => haarBall)
    (f := fun ℓ => sig N ℓ) (sig_preserving N)
  have hcomp := hσ.comp hre
  convert hcomp using 1
  funext ω
  funext ℓ
  show sig N ℓ (ω (thL N ℓ)) = sig N ℓ (MeasurableEquiv.piCongrLeft (fun _ : Lk N => QBall) e ω ℓ)
  rw [piCongrLeft_const]
  rfl

theorem wilsonWeight_refl (M : ℕ) (hN : N = 2 * M) (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β (linkRefl (thL N) (sig N) ω) = wilsonWeight N β ω := by
  rw [weight_factor N M hN, weight_factor N M hN, linkRefl_invol, mul_comm]

/-- **Reflection symmetry of the pairing for the Wilson measure** (every `β`, measurable `f`,
`g`). -/
theorem wilson_refl_symm (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonMeasure N β)
      = ∫ ω, g (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := linkRefl_preserving N
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) •
      (f (linkRefl (thL N) (sig N) ω) * g ω)) :=
    hWm.smul ((hf.comp hP.measurable).mul hg)
  conv_lhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  rw [linkRefl_invol, wilsonWeight_refl N M hN, mul_comm (f ω)]

end TorusRP

#print axioms TorusRP.linkRefl_preserving
#print axioms TorusRP.wilson_refl_symm

/-! # Time-translation invariance of the Wilson measure on `(ℤ/N)⁴` — 

Groundwork for the fields `hshift` / `hdec` of the reconstruction datum: the translation
`(Tω)_ℓ = ω_{ℓ + e₀}` preserves the product Haar measure (`tShift_preserving`) and Wilson's
weight (`wilsonWeight_tShift`), so `∫ f(Tω) dμ_W = ∫ f dμ_W` (`wilson_shift_invariant`). -/

namespace TorusRP

open MeasureTheory

variable (N : ℕ) [NeZero N]

/-- time translation of a link by one step -/
def shL (ℓ : Lk N) : Lk N := (ℓ.1 + ev N 0, ℓ.2)

def shEquiv : Lk N ≃ Lk N where
  toFun ℓ := (ℓ.1 - ev N 0, ℓ.2)
  invFun := shL N
  left_inv ℓ := by simp [shL]
  right_inv ℓ := by simp [shL]

/-- the translated configuration `(Tω)_ℓ = ω_{ℓ + e₀}` -/
def tShift (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (shL N ℓ)

theorem tShift_preserving :
    MeasurePreserving (tShift N) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) (shEquiv N)
  convert hre using 1
  funext ω
  funext ℓ
  rw [LinkReflection.piCongrLeft_const]
  rfl

theorem hol_tShift (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (tShift N ω) p = hol N ω ((p.1.1 + ev N 0, p.1.2), p.2) := by
  simp only [hol, holQ, Uq, tShift, shL]
  rw [add_right_comm p.1.1 (ev N p.1.2) (ev N 0), add_right_comm p.1.1 (ev N p.2) (ev N 0)]

theorem action_tShift (ω : Lk N → QBall) : action N (tShift N ω) = action N ω := by
  unfold action
  simp_rw [hol_tShift]
  apply Finset.sum_nbij' (fun p => ((p.1.1 + ev N 0, p.1.2), p.2))
    (fun p => ((p.1.1 - ev N 0, p.1.2), p.2))
  · intro p hp; simpa [plaqs] using hp
  · intro p hp; simpa [plaqs] using hp
  · intro p _; simp
  · intro p _; simp
  · intro p _; rfl

theorem wilsonWeight_tShift (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β (tShift N ω) = wilsonWeight N β ω := by
  unfold wilsonWeight; rw [action_tShift]

/-- **Time-translation invariance of the Wilson measure** (every `β`, measurable `f`). -/
theorem wilson_shift_invariant (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    ∫ ω, f (tShift N ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := tShift_preserving N
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) • f ω) := hWm.smul hf
  conv_rhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  rw [wilsonWeight_tShift]

end TorusRP

#print axioms TorusRP.tShift_preserving
#print axioms TorusRP.wilson_shift_invariant

/-! # Reflection and translation: the torus form of the field `hshift` — 
`Θ ∘ T⁻¹ = T ∘ Θ` on configurations (`refl_tShiftInv`), hence
`∫ f(T(Θω)) g(ω) dμ_W = ∫ f(Θω) g(Tω) dμ_W` (`wilson_shift_pairing`): the transfer step is
symmetric for the reflected pairing (the `hshift` field of `measureDatum`, on the torus). -/

namespace TorusRP

open MeasureTheory LinkReflection

variable (N : ℕ) [NeZero N]

/-- the inverse translation `(T⁻¹ω)_ℓ = ω_{ℓ - e₀}` -/
def tShiftInv (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (ℓ.1 - ev N 0, ℓ.2)

theorem tShiftInv_tShift (ω : Lk N → QBall) : tShiftInv N (tShift N ω) = ω := by
  funext ℓ; simp [tShift, tShiftInv, shL]

theorem measurable_tShiftInv : Measurable (tShiftInv N) :=
  measurable_pi_lambda _ (fun ℓ => measurable_pi_apply _)

theorem thL_shL (ℓ : Lk N) : thL N (shL N ℓ) = ((thL N ℓ).1 - ev N 0, (thL N ℓ).2) := by
  obtain ⟨x, κ⟩ := ℓ
  have h1 : thS N (x + ev N 0) = thS N x - ev N 0 := by
    rw [thS_add, thS_ev0, sub_eq_add_neg]
  by_cases h : κ = 0
  · simp [thL, shL, h, h1]
  · simp [thL, shL, h, h1]

theorem refl_tShiftInv (ω : Lk N → QBall) :
    linkRefl (thL N) (sig N) (tShiftInv N ω) = tShift N (linkRefl (thL N) (sig N) ω) := by
  funext ℓ
  show sig N ℓ (ω ((thL N ℓ).1 - ev N 0, (thL N ℓ).2)) = sig N (shL N ℓ) (ω (thL N (shL N ℓ)))
  rw [thL_shL]
  rfl

/-- **The torus form of `hshift`**: `∫ f(T(Θω)) g(ω) dμ_W = ∫ f(Θω) g(Tω) dμ_W`. -/
theorem wilson_shift_pairing (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (tShift N (linkRefl (thL N) (sig N) ω)) * g ω ∂(wilsonMeasure N β)
      = ∫ ω, f (linkRefl (thL N) (sig N) ω) * g (tShift N ω) ∂(wilsonMeasure N β) := by
  have hR := (linkRefl_preserving N).measurable
  have hH : Measurable (fun ω => f (linkRefl (thL N) (sig N) (tShiftInv N ω)) * g ω) :=
    (hf.comp (hR.comp (measurable_tShiftInv N))).mul hg
  have h := wilson_shift_invariant N β _ hH
  simp only [tShiftInv_tShift] at h
  rw [h]
  congr 1
  funext ω
  rw [refl_tShiftInv]

end TorusRP

#print axioms TorusRP.refl_tShiftInv
#print axioms TorusRP.wilson_shift_pairing

/-! # The field `hdec` of the reconstruction datum on the torus, at strong coupling — 

`gibbs` (the weight `∏ w_p`) is the normalised Wilson expectation (`gibbs_eq`); it is invariant
under the reflection (`gibbs_refl`) and the time translations (`gibbs_shift_iter`).  So the
truncated reflected pairing of `measureDatum`'s `hdec`,
`⟨F(T^k Θ ω) F(T^k ω)⟩ - ⟨F⟩²`, is the covariance of `F ∘ T^k ∘ Θ` and `F ∘ T^k`, and
`wilson_strong_coupling` bounds it (`wilson_hdec_torus`).  The support hypotheses (`hdepΘ`,
`hdepT`: which links the two functions depend on) are left as hypotheses. -/

namespace TorusRP

open MeasureTheory SwapDecay LinkReflection

variable (N : ℕ) [NeZero N]

theorem integral_wilson (β : ℝ) (H : (Lk N → QBall) → ℝ) :
    ∫ ω, H ω ∂(wilsonMeasure N β) =
      ∫ ω, H ω * wilsonWeight N β ω ∂(Measure.pi fun _ : Lk N => haarBall) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm]
  congr 1
  funext ω
  have h0 : 0 ≤ wilsonWeight N β ω := (Real.exp_pos _).le
  rw [NNReal.smul_def, Real.coe_toNNReal _ h0, smul_eq_mul, mul_comm]

/-- `gibbs` with the plaquette weights is the normalised Wilson expectation -/
theorem gibbs_eq (β : ℝ) (H : (Lk N → QBall) → ℝ) :
    gibbs (fun _ : Lk N => haarBall) (plaqW N β) H =
      (∫ ω, H ω ∂(wilsonMeasure N β)) / (∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β)) := by
  unfold gibbs
  rw [integral_wilson, integral_wilson]
  simp_rw [prod_plaqW, one_mul]
  rw [show (fun x => H x * (Real.exp (|β| * (plaqs N).card) * wilsonWeight N β x)) =
      fun x => Real.exp (|β| * (plaqs N).card) * (H x * wilsonWeight N β x) by
    funext x; ring]
  rw [integral_const_mul, integral_const_mul]
  exact mul_div_mul_left _ _ (ne_of_gt (Real.exp_pos _))

theorem gibbs_refl (M : ℕ) (hN : N = 2 * M) (β : ℝ) (H : (Lk N → QBall) → ℝ)
    (hH : Measurable H) :
    gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => H (linkRefl (thL N) (sig N) ω)) =
      gibbs (fun _ : Lk N => haarBall) (plaqW N β) H := by
  rw [gibbs_eq, gibbs_eq]
  have h := wilson_refl_symm N M hN β H (fun _ => (1 : ℝ)) hH measurable_const
  simp only [mul_one, one_mul] at h
  rw [h]

theorem gibbs_shift_iter (β : ℝ) (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (k : ℕ) :
    gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => H ((tShift N)^[k] ω)) =
      gibbs (fun _ : Lk N => haarBall) (plaqW N β) H := by
  have hT : Measurable (tShift N) := (tShift_preserving N).measurable
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [← ih, gibbs_eq, gibbs_eq]
    simp only [Function.iterate_succ_apply]
    rw [wilson_shift_invariant N β (fun ω => H ((tShift N)^[k] ω)) (hH.comp (hT.iterate k))]

/-- **The `hdec` form on the torus at strong coupling.** -/
theorem wilson_hdec_torus (M : ℕ) (hN : N = 2 * M) (β : ℝ)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1)
    (k : ℕ) (t₀ : ZMod N) (r d : ℕ) (A A' : Finset (Lk N))
    (hA : ∀ ℓ ∈ A, cdist N (ℓ.1 0 - t₀) ≤ r)
    (hA' : ∀ ℓ ∈ A', r + 2 + d ≤ cdist N (ℓ.1 0 - t₀))
    (F : (Lk N → QBall) → ℝ) (cF : ℝ) (hFm : Measurable F) (hFC : ∀ x, |F x| ≤ cF)
    (hdepΘ : ∀ x y, (∀ i ∈ A, x i = y i) →
      F ((tShift N)^[k] (linkRefl (thL N) (sig N) x)) = F ((tShift N)^[k] (linkRefl (thL N) (sig N) y)))
    (hdepT : ∀ x y, (∀ i ∈ A', x i = y i) → F ((tShift N)^[k] x) = F ((tShift N)^[k] y)) :
    gibbs (fun _ : Lk N => haarBall) (plaqW N β)
        (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω)) * F ((tShift N)^[k] ω))
      - (gibbs (fun _ : Lk N => haarBall) (plaqW N β) F) ^ 2
      ≤ 2 * cF * cF * (6 * A.card * ((1 - (Real.exp (2 * |β|))⁻¹ ^ 2) *
          (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) ^ d /
            (1 - 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)))) := by
  have hT : Measurable (tShift N) := (tShift_preserving N).measurable
  have hR : Measurable (linkRefl (thL N) (sig N)) := (linkRefl_preserving N).measurable
  have hFT : Measurable (fun ω => F ((tShift N)^[k] ω)) := hFm.comp (hT.iterate k)
  have hc := wilson_strong_coupling N β hβ t₀ r d A A' hA hA'
    (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω))) (fun ω => F ((tShift N)^[k] ω))
    cF cF (hFT.comp hR) hFT hdepΘ hdepT (fun x => hFC _) (fun x => hFC _)
  have e1 : gibbs (fun _ : Lk N => haarBall) (plaqW N β)
      (fun ω => F ((tShift N)^[k] (linkRefl (thL N) (sig N) ω))) =
      gibbs (fun _ : Lk N => haarBall) (plaqW N β) F := by
    rw [gibbs_refl N M hN β (fun ω => F ((tShift N)^[k] ω)) hFT, gibbs_shift_iter N β F hFm k]
  have e2 := gibbs_shift_iter N β F hFm k
  rw [e1, e2] at hc
  rw [sq]
  exact (le_abs_self _).trans hc

end TorusRP

#print axioms TorusRP.gibbs_eq
#print axioms TorusRP.gibbs_shift_iter
#print axioms TorusRP.wilson_hdec_torus
