import Lattice.WilsonDobV1

/-!
# Clustering in every lattice direction at the weak limit points (Dobrushin window)


* `LinkSpec.wilson_cov_gen` : the distance decay of `wilson_cov_dist` for any distance `D` that
  changes by at most one between links sharing a plaquette.
* `LinkSpec.coordLip` : the cyclic distance of the `i`-th base coordinate is such a `D`.
* `WilsonLimit.cluster_limit` : at every weak limit point `ν`, for cylinder functions `F`, `G` with
  supports in the slab `0 ≤ x_i ≤ R` and the shift by `k ≥ R` in direction `i` (any of the four),
  `|Cov_ν(F, G ∘ S_i^k)| ≤ 4‖F‖‖G‖|S_G| e^{-λ(k-R)}`.
Formalisation of a known result.
-/

namespace LinkSpec

open MeasureTheory TorusRP Finset Filter SwapDecay

variable (N : ℕ) [NeZero N]

theorem ev_coord (μ i : Fin 4) : ev N μ i = ((if μ = i then 1 else 0 : ℤ) : ZMod N) := by
  unfold ev; rw [Pi.single_apply]; split_ifs with h1 h2 h2 <;> simp_all

theorem plaqLinks_coord (i : Fin 4) (p : Lk N × Fin 4) (ℓ : Lk N) (h : ℓ ∈ plaqLinks N p) :
    ∃ e : ℤ, (e = 0 ∨ e = 1) ∧ ℓ.1 i = p.1.1 i + (e : ZMod N) := by
  simp only [plaqLinks, Finset.mem_insert, Finset.mem_singleton] at h
  rcases h with h | h | h | h <;> subst h
  · exact ⟨0, Or.inl rfl, by simp⟩
  · refine ⟨if p.1.2 = i then 1 else 0, by split_ifs <;> simp, ?_⟩
    simp [ev_coord]
  · refine ⟨if p.2 = i then 1 else 0, by split_ifs <;> simp, ?_⟩
    simp [ev_coord]
  · exact ⟨0, Or.inl rfl, by simp⟩

/-- the cyclic distance of the `i`-th base coordinate from `s₀` -/
def cdistI (i : Fin 4) (s₀ : ZMod N) (y : Lk N) : ℕ := cdist N (y.1 i - s₀)

theorem coordLip (i : Fin 4) (s₀ : ZMod N) (x y : Lk N)
    (h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0) :
    cdistI N i s₀ x ≤ cdistI N i s₀ y + 1 := by
  obtain ⟨p, hp⟩ := Finset.card_pos.1 (Nat.pos_of_ne_zero h)
  rw [Finset.mem_filter] at hp
  have hx : x ∈ plaqLinks N p := (Finset.mem_filter.1 hp.1).2
  obtain ⟨e, he, hpe⟩ := plaqLinks_coord N i p x hx
  obtain ⟨e', he', hqe⟩ := plaqLinks_coord N i p y hp.2
  have hq : x.1 i - s₀ = (y.1 i - s₀) + ((e - e' : ℤ) : ZMod N) := by
    push_cast; linear_combination hpe - hqe
  have h1 := cdist_add_le N (y.1 i - s₀) ((e - e' : ℤ) : ZMod N)
  have h2 := cdist_intCast_le N (e - e')
  have h3 : (e - e').natAbs ≤ 1 := by rcases he with rfl | rfl <;> rcases he' with rfl | rfl <;> decide
  unfold cdistI
  rw [hq]
  omega

/-- the weighted Dobrushin row condition with `ρ_y = e^{-λ D(y)}`, `D` changing by at most one between plaquette neighbours -/
theorem row_weighted_gen (β lam : ℝ) (hlam : 0 ≤ lam) (D : Lk N → ℕ)
    (hlip : ∀ x y : Lk N, ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0 →
      D x ≤ D y + 1) (x : Lk N) :
    ∑ y ∈ univ.erase x, Real.exp (-(lam * D y)) * coef N β x y
      ≤ (Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1)))) *
          Real.exp (-(lam * D x)) := by
  have hrow := dobrushin_row N β x
  have hterm : ∀ y ∈ univ.erase x, Real.exp (-(lam * D y)) * coef N β x y
      ≤ (Real.exp lam * Real.exp (-(lam * D x))) * coef N β x y := by
    intro y _
    by_cases h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card = 0
    · rw [coef_eq_zero N β x y h]; simp
    · refine mul_le_mul_of_nonneg_right ?_ (coef_nonneg N β x y)
      rw [← Real.exp_add]
      apply Real.exp_le_exp.2
      have := hlip x y h
      have : (D x : ℝ) ≤ D y + 1 := by exact_mod_cast this
      nlinarith
  calc _ ≤ ∑ y ∈ univ.erase x, (Real.exp lam * Real.exp (-(lam * D x))) * coef N β x y :=
        Finset.sum_le_sum hterm
    _ = (Real.exp lam * Real.exp (-(lam * D x))) * ∑ y ∈ univ.erase x, coef N β x y := by
        rw [Finset.mul_sum]
    _ ≤ (Real.exp lam * Real.exp (-(lam * D x))) *
          (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) :=
        mul_le_mul_of_nonneg_left hrow (by positivity)
    _ = _ := by ring

/-- **Decay of the covariance with any plaquette-Lipschitz distance `D` (Dobrushin, sweep form).**
`F` depends only on the links of `A` (with `D ≤ r`), `G` has single-link
oscillations `δ`.  If `e^λ · 18 tanh|β| < 1` then
`|E(FG) - E(F)E(G)| ≤ 2 c_F e^{λ r} Σ_y e^{-λ D(y)} δ_y`. -/
theorem wilson_cov_gen (β lam : ℝ) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) < 1)
    (D : Lk N → ℕ) (hlip : ∀ x y : Lk N, ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0 →
      D x ≤ D y + 1) (r : ℕ) (A : Finset (Lk N)) (hA : ∀ ℓ ∈ A, D ℓ ≤ r)
    (F G : (Lk N → QBall) → ℝ) (hF : Measurable F) (hG : Measurable G) (cF cG : ℝ)
    (hFb : ∀ ω, |F ω| ≤ cF) (hGb : ∀ ω, |G ω| ≤ cG)
    (hFdep : ∀ ω ω', (∀ i ∈ A, ω i = ω' i) → F ω = F ω')
    (δ : Lk N → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |G ω - G ω'| ≤ δ y) :
    |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => F ω * G ω)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * (Real.exp (lam * r) * ∑ y, Real.exp (-(lam * D y)) * δ y) := by
  set α := Real.exp lam * (18 * ((Real.exp (2 * |β|) - 1) / (Real.exp (2 * |β|) + 1))) with hαdef
  have hα0 : 0 ≤ α := by
    have : 1 ≤ Real.exp (2 * |β|) := Real.one_le_exp (by positivity)
    rw [hαdef]
    exact mul_nonneg (Real.exp_pos _).le (mul_nonneg (by norm_num) (div_nonneg (by linarith) (by linarith)))
  set L : List (Lk N) := ((univ : Finset (Lk N)).filter (fun y => y ∉ A)).toList with hLdef
  have hnd : L.Nodup := Finset.nodup_toList _
  have hLA : ∀ x ∈ L, x ∉ A := fun x hx => (Finset.mem_filter.1 (Finset.mem_toList.1 hx)).2
  have hcov : ∀ y, y ∉ A → y ∈ L := fun y hy =>
    Finset.mem_toList.2 (Finset.mem_filter.2 ⟨Finset.mem_univ _, hy⟩)
  have hFL : ∀ x ∈ L, ∀ ω U, F (Function.update ω x U) = F ω := fun x hx ω U =>
    hFdep _ _ (fun i hi => by
      have : i ≠ x := fun h => hLA x hx (h ▸ hi)
      rw [Function.update_of_ne this])
  set ρ : Lk N → ℝ := fun y => Real.exp (-(lam * D y)) with hρdef
  have hρ : ∀ y, 0 < ρ y := fun y => Real.exp_pos _
  have hρA : ∀ y ∈ A, Real.exp (-(lam * r)) ≤ ρ y := fun y hy => by
    apply Real.exp_le_exp.2
    have : (D y : ℝ) ≤ r := by exact_mod_cast hA y hy
    nlinarith
  have hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * coef N β x y ≤ α * ρ x := fun x =>
    row_weighted_gen N β lam hlam D hlip x
  have hZ : 0 < ∫ _ω, (1 : ℝ) ∂(wilsonMeasure N β) := by
    rw [integral_const, smul_eq_mul, mul_one, measureReal_def]
    exact ENNReal.toReal_pos (wilsonMeasure_univ_pos N β).ne' (wilsonMeasure_univ_lt_top N β).ne
  -- the bound for every number of sweeps
  have hK : ∀ K : ℕ,
      |gibbs (fun _ : Lk N => haarBall) (plaqW N β) (fun ω => F ω * G ω)
        - gibbs (fun _ : Lk N => haarBall) (plaqW N β) F * gibbs (fun _ : Lk N => haarBall) (plaqW N β) G|
      ≤ 2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) +
          (∑ y, (ρ y)⁻¹) * (α ^ K * Sweep.bS A ρ δ)) := by
    intro K
    obtain ⟨mH, bH, oH⟩ := iter_props N β L K G hG cG hGb δ hδ hosc
    set H := (hbSweep N β L)^[K] G with hHdef
    have e1 := iter_mul_invariant N β L F hF cF hFb hFL K G hG cG hGb
    have e2 := iter_invariant N β L K G hG cG hGb
    rw [gibbs_eq, gibbs_eq, gibbs_eq, ← e1, ← e2]
    set ω₀ : Lk N → QBall := fun _ => Classical.arbitrary QBall
    have hrange : ∀ ω, |H ω - H ω₀| ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y := fun ω => by
      have := osc_total N H _ oH (univ : Finset (Lk N)).toList ω ω₀
        (fun ℓ hℓ => absurd (Finset.mem_toList.2 (Finset.mem_univ ℓ)) hℓ)
      rwa [Finset.sum_map_toList] at this
    have hc := cov_le (wilsonMeasure N β) hZ F H hF mH cF hFb (H ω₀) _ hrange
    refine hc.trans (mul_le_mul_of_nonneg_left ?_ ?_)
    · exact Sweep.iter_bound (coef N β) α hα0 hα.le (coef_nonneg N β) ρ hρ hrow A L hnd hLA hcov
        (Real.exp (-(lam * r))) (Real.exp_pos _) hρA δ hδ K
    · have := (abs_nonneg _).trans (hFb (fun _ => Classical.arbitrary QBall)); linarith
  -- let the number of sweeps go to infinity
  have hlim : Tendsto (fun K : ℕ => 2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) +
      (∑ y, (ρ y)⁻¹) * (α ^ K * Sweep.bS A ρ δ))) atTop
      (nhds (2 * cF * ((∑ y, ρ y * δ y) / Real.exp (-(lam * r)) + (∑ y, (ρ y)⁻¹) * (0 * Sweep.bS A ρ δ)))) :=
    ((((tendsto_pow_atTop_nhds_zero_of_lt_one hα0 hα).mul_const _).const_mul _).const_add _).const_mul _
  have := ge_of_tendsto' hlim hK
  rw [zero_mul, mul_zero, add_zero] at this
  refine this.trans_eq ?_
  rw [div_eq_mul_inv, ← Real.exp_neg, neg_neg, mul_comm (∑ y, ρ y * δ y)]

end LinkSpec

namespace WilsonLimit

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay LinkSpec
open scoped BoundedContinuousFunction

/-- translation of a link of ℤ⁴ by `k` steps in direction `i` -/
def zshI (i : Fin 4) (k : ℕ) (ℓ : ZLk) : ZLk := (ℓ.1 + Pi.single i (k : ℤ), ℓ.2)

/-- the translation of configurations -/
def zShI (i : Fin 4) (k : ℕ) (x : Cfg) : Cfg := fun ℓ => x (zshI i k ℓ)

theorem continuous_zShI (i : Fin 4) (k : ℕ) : Continuous (zShI i k) :=
  continuous_pi fun _ => continuous_apply _

theorem proj_coord (N : ℕ) [NeZero N] (i : Fin 4) (ℓ : ZLk) :
    (zproj N ℓ).1 i = ((ℓ.1 i : ℤ) : ZMod N) := rfl

theorem zshI_coord (i : Fin 4) (k : ℕ) (ℓ : ZLk) : (zshI i k ℓ).1 i = ℓ.1 i + k := by
  simp [zshI]

/-- **Clustering at every weak limit point**, direction `i` (Dobrushin window). -/
theorem cluster_limit (β lam : ℝ) (hlam : 0 ≤ lam) (hα : Real.exp lam * dobConst β < 1)
    (i : Fin 4) (F G : Cfg →ᵇ ℝ) (SF SG : Finset ZLk) (R : ℕ)
    (hSF : ∀ ℓ ∈ SF, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) (hSG : ∀ ℓ ∈ SG, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R)
    (hF : ∀ x y : Cfg, (∀ ℓ ∈ SF, x ℓ = y ℓ) → F x = F y)
    (hG : ∀ x y : Cfg, (∀ ℓ ∈ SG, x ℓ = y ℓ) → G x = G y)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (k : ℕ) (hk : R ≤ k) :
    |∫ x, F x * G (zShI i k x) ∂(ν : Measure Cfg)
        - (∫ x, F x ∂(ν : Measure Cfg)) * ∫ x, G (zShI i k x) ∂(ν : Measure Cfg)|
      ≤ 4 * ‖F‖ * ‖G‖ * SG.card * Real.exp (-(lam * ((k : ℝ) - R))) := by
  set Gk : Cfg →ᵇ ℝ := G.compContinuous ⟨zShI i k, continuous_zShI i k⟩ with hGk
  have hGk_apply : ∀ x, Gk x = G (zShI i k x) := fun x => rfl
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
  have t1 := h (F * Gk)
  have t2 := h F
  have t3 := h Gk
  simp only [BoundedContinuousFunction.coe_mul, Pi.mul_apply, hGk_apply] at t1 t3
  have hT := ((t1.sub (t2.mul t3)).abs)
  refine le_of_tendsto hT ?_
  filter_upwards [hφ.tendsto_atTop.eventually (eventually_ge_atTop (k + R))] with n hn
  have e1 := integral_lift β (φ n) (fun x => F x * G (zShI i k x))
    (F.continuous.mul (G.continuous.comp (continuous_zShI i k)))
  have e2 := integral_lift β (φ n) (fun x => F x) F.continuous
  have e3 := integral_lift β (φ n) (fun x => G (zShI i k x)) (G.continuous.comp (continuous_zShI i k))
  rw [e1, e2, e3, integral_wilsonProb_gibbs, integral_wilsonProb_gibbs, integral_wilsonProb_gibbs]
  have hNhalf : Nn (φ n) / 2 = φ n + 1 := Nn_half (φ n)
  have hA : ∀ ℓ' ∈ SF.image (zproj (Nn (φ n))), cdistI (Nn (φ n)) i 0 ℓ' ≤ R := by
    intro ℓ' hℓ'
    obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
    obtain ⟨a, b⟩ := hSF ℓ hℓ
    unfold cdistI
    rw [proj_coord, sub_zero]
    refine (cdist_intCast_le (Nn (φ n)) _).trans ?_
    omega
  have hA' : ∀ ℓ' ∈ SG.image (fun ℓ => zproj (Nn (φ n)) (zshI i k ℓ)),
      k ≤ cdistI (Nn (φ n)) i 0 ℓ' := by
    intro ℓ' hℓ'
    obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
    obtain ⟨a, b⟩ := hSG ℓ hℓ
    unfold cdistI
    rw [proj_coord, sub_zero, zshI_coord]
    have hj0 : 0 ≤ ℓ.1 i + (k : ℤ) := by omega
    have hj1 : (ℓ.1 i + (k : ℤ)).toNat ≤ Nn (φ n) / 2 := by rw [hNhalf]; omega
    rw [cdist_intCast_eq (Nn (φ n)) _ hj0 hj1]
    omega
  have hFdep : ∀ ω ω' : Lk (Nn (φ n)) → QBall, (∀ j ∈ SF.image (zproj (Nn (φ n))), ω j = ω' j) →
      F (perLift (Nn (φ n)) ω) = F (perLift (Nn (φ n)) ω') := fun ω ω' h =>
    hF _ _ (fun ℓ hℓ => h _ (Finset.mem_image_of_mem _ hℓ))
  have hGdep : ∀ ω ω' : Lk (Nn (φ n)) → QBall,
      (∀ j ∈ SG.image (fun ℓ => zproj (Nn (φ n)) (zshI i k ℓ)), ω j = ω' j) →
      G (zShI i k (perLift (Nn (φ n)) ω)) = G (zShI i k (perLift (Nn (φ n)) ω')) := fun ω ω' h =>
    hG _ _ (fun ℓ hℓ => h _ (Finset.mem_image_of_mem (fun ℓ => zproj (Nn (φ n)) (zshI i k ℓ)) hℓ))
  set A' := SG.image (fun ℓ => zproj (Nn (φ n)) (zshI i k ℓ)) with hA'def
  set δ : Lk (Nn (φ n)) → ℝ := fun y => if y ∈ A' then 2 * ‖G‖ else 0 with hδdef
  have hδ : ∀ y, 0 ≤ δ y := fun y => by
    rw [hδdef]; dsimp only; split_ifs <;> positivity
  have hosc : ∀ y, ∀ ω ω' : Lk (Nn (φ n)) → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
      |G (zShI i k (perLift (Nn (φ n)) ω)) - G (zShI i k (perLift (Nn (φ n)) ω'))| ≤ δ y := by
    intro y ω ω' hyy
    rw [hδdef]; dsimp only
    split_ifs with hy
    · have g1 := abs_le_norm' G (zShI i k (perLift (Nn (φ n)) ω))
      have g2 := abs_le_norm' G (zShI i k (perLift (Nn (φ n)) ω'))
      exact (abs_sub _ _).trans (by linarith)
    · rw [hGdep ω ω' (fun j hj => hyy j (fun e => hy (e ▸ hj))), sub_self, abs_zero]
  have hc := wilson_cov_gen (Nn (φ n)) β lam hlam hα (cdistI (Nn (φ n)) i 0) (coordLip (Nn (φ n)) i 0)
    R _ hA (fun ω => F (perLift (Nn (φ n)) ω)) (fun ω => G (zShI i k (perLift (Nn (φ n)) ω)))
    ((F.continuous.comp (continuous_perLift _)).measurable)
    ((G.continuous.comp ((continuous_zShI i k).comp (continuous_perLift _))).measurable)
    ‖F‖ ‖G‖ (fun ω => abs_le_norm' F _) (fun ω => abs_le_norm' G _) hFdep δ hδ hosc
  refine hc.trans ?_
  have hterm : ∀ y, Real.exp (-(lam * cdistI (Nn (φ n)) i 0 y)) * δ y
      ≤ (if y ∈ A' then Real.exp (-(lam * k)) * (2 * ‖G‖) else 0) := fun y => by
    rw [hδdef]; dsimp only
    split_ifs with hy
    · refine mul_le_mul_of_nonneg_right (Real.exp_le_exp.2 ?_) (by positivity)
      have h0 := hA' y hy
      have : (k : ℝ) ≤ cdistI (Nn (φ n)) i 0 y := by exact_mod_cast h0
      nlinarith
    · simp
  have hs : ∑ y, Real.exp (-(lam * cdistI (Nn (φ n)) i 0 y)) * δ y
      ≤ A'.card * (Real.exp (-(lam * k)) * (2 * ‖G‖)) := by
    refine (Finset.sum_le_sum fun y _ => hterm y).trans ?_
    rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, Finset.filter_mem_eq_inter,
      Finset.univ_inter]
  have hA'c : (A'.card : ℝ) ≤ SG.card := by exact_mod_cast Finset.card_image_le
  have hexp : Real.exp (lam * R) * Real.exp (-(lam * k)) = Real.exp (-(lam * ((k : ℝ) - R))) := by
    rw [← Real.exp_add]; congr 1; ring
  have hF0 : 0 ≤ ‖F‖ := norm_nonneg _
  have hG0 : 0 ≤ ‖G‖ := norm_nonneg _
  calc 2 * ‖F‖ * (Real.exp (lam * R) * ∑ y, Real.exp (-(lam * cdistI (Nn (φ n)) i 0 y)) * δ y)
      ≤ 2 * ‖F‖ * (Real.exp (lam * R) * (A'.card * (Real.exp (-(lam * k)) * (2 * ‖G‖)))) := by
        gcongr
    _ = 4 * ‖F‖ * ‖G‖ * A'.card * (Real.exp (lam * R) * Real.exp (-(lam * k))) := by ring
    _ ≤ 4 * ‖F‖ * ‖G‖ * SG.card * (Real.exp (lam * R) * Real.exp (-(lam * k))) := by gcongr
    _ = _ := by rw [hexp]

end WilsonLimit

#print axioms LinkSpec.coordLip
#print axioms LinkSpec.wilson_cov_gen
#print axioms WilsonLimit.cluster_limit
