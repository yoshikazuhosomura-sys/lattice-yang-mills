import Lattice.GaugeFixV5

/-!
# Gauge fixing on the torus: the temporal links crossing the planes `x₀ = ½` and `x₀ = M + ½`


* `TorusGauge.hol_act` : a gauge transformation conjugates the plaquette holonomy at its base point,
  so the Wilson weight is gauge invariant (`wilsonWeight_act`).
* `TorusGauge.crossing_data` : on `(ℤ/2M)⁴`, `M ≥ 2`, the temporal links with base time `0` or `M`
  point into the distinct sites of time `1` and `M+1`, and none starts there.
* `TorusGauge.wilson_gaugeFix` : for gauge-invariant bounded measurable `F`,
  `∫ F dμ_W = ∫ F(ω°) e^{β S(ω°)} dHaar(ω)`, `ω°` = `ω` with the crossing temporal links set to `1`.
-/

namespace TorusGauge

open MeasureTheory TorusRP OSGap GaugeFix

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N]

def src (ℓ : Lk N) : Site N := ℓ.1
def tgt (ℓ : Lk N) : Site N := ℓ.1 + ev N ℓ.2

theorem coe_mulB (a b U : QBall) : ((mulB a b U : QBall) : ℍr) = (a : ℍr) * (U : ℍr) * star (b : ℍr) :=
  rfl

theorem hol_act (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (act (src N) (tgt N) g ω) p = ((g p.1.1 : QBall) : ℍr) * hol N ω p * star ((g p.1.1 : QBall) : ℍr) := by
  have hcanc : ∀ (y : Site N) (z : ℍr), star ((g y : QBall) : ℍr) * (((g y : QBall) : ℍr) * z) = z := by
    intro y z
    rw [← mul_assoc, Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, hg y]
    simp
  unfold hol holQ Uq act
  simp only [coe_mulB, src, tgt]
  rw [add_right_comm p.1.1 (ev N p.2) (ev N p.1.2)]
  simp only [star_mul, star_star, mul_assoc, hcanc]

theorem wilsonWeight_act (β : ℝ) (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (ω : Lk N → QBall) : wilsonWeight N β (act (src N) (tgt N) g ω) = wilsonWeight N β ω := by
  unfold wilsonWeight action
  congr 2
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [hol_act N g hg]
  refine GaugeZ.re_conj _ _ ?_
  rw [Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, hg]
  simp

/-- crossing temporal links: base time `0` or `M` -/
def cr (M : ℕ) (ℓ : Lk N) : Prop := ℓ.2 = 0 ∧ (ℓ.1 0 = 0 ∨ ℓ.1 0 = (M : ZMod N))

instance (M : ℕ) : DecidablePred (cr N M) := fun ℓ => by unfold cr; infer_instance

/-- sites receiving a crossing link: time `1` or `M + 1` -/
def hasIn (M : ℕ) (x : Site N) : Prop := x 0 = 1 ∨ x 0 = (M : ZMod N) + 1

instance (M : ℕ) : DecidablePred (hasIn N M) := fun x => by unfold hasIn; infer_instance

/-- the crossing link into `x` -/
def kIn (x : Site N) : Lk N := (x - ev N 0, 0)

theorem ev_zero_zero : ev N 0 0 = 1 := by simp [ev]

theorem natCast_ne (M a b : ℕ) (hN : N = 2 * M) (ha : a < N) (hb : b < N) (hab : a ≠ b) :
    ((a : ℕ) : ZMod N) ≠ ((b : ℕ) : ZMod N) := by
  intro h
  rw [ZMod.natCast_eq_natCast_iff'] at h
  rw [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at h
  exact hab h

theorem crossing_data (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) :
    (∀ x, hasIn N M x → cr N M (kIn N x) ∧ tgt N (kIn N x) = x) ∧
    (∀ c, cr N M c → hasIn N M (tgt N c) ∧ kIn N (tgt N c) = c) ∧
    (∀ c, cr N M c → ¬ hasIn N M (src N c)) := by
  refine ⟨fun x hx => ⟨⟨rfl, ?_⟩, ?_⟩, fun c hc => ⟨?_, ?_⟩, fun c hc hin => ?_⟩
  · show (x - ev N 0) 0 = 0 ∨ (x - ev N 0) 0 = (M : ZMod N)
    rw [Pi.sub_apply, ev_zero_zero]
    rcases hx with h | h
    · left; rw [h, sub_self]
    · right; rw [h, add_sub_cancel_right]
  · show (x - ev N 0) + ev N 0 = x
    rw [sub_add_cancel]
  · obtain ⟨h0, h1⟩ := hc
    show (c.1 + ev N c.2) 0 = 1 ∨ (c.1 + ev N c.2) 0 = (M : ZMod N) + 1
    rw [h0, Pi.add_apply, ev_zero_zero]
    rcases h1 with h | h
    · left; rw [h, zero_add]
    · right; rw [h]
  · obtain ⟨h0, -⟩ := hc
    show ((c.1 + ev N c.2) - ev N 0, (0 : Fin 4)) = c
    rw [h0, add_sub_cancel_right]
    exact Prod.ext rfl h0.symm
  · obtain ⟨-, h1⟩ := hc
    show False
    have hin' : c.1 0 = 1 ∨ c.1 0 = (M : ZMod N) + 1 := hin
    have e1 : (1 : ZMod N) = ((1 : ℕ) : ZMod N) := by simp
    have e0 : (0 : ZMod N) = ((0 : ℕ) : ZMod N) := by simp
    have eM : (M : ZMod N) + 1 = ((M + 1 : ℕ) : ZMod N) := by push_cast; rfl
    rcases h1 with h | h <;> rcases hin' with h' | h' <;> rw [h] at h'
    · rw [e0, e1] at h'; exact natCast_ne N M 0 1 hN (by omega) (by omega) (by omega) h'
    · rw [e0, eM] at h'; exact natCast_ne N M 0 (M + 1) hN (by omega) (by omega) (by omega) h'
    · rw [e1] at h'; exact natCast_ne N M M 1 hN (by omega) (by omega) (by omega) h'
    · rw [eM] at h'; exact natCast_ne N M M (M + 1) hN (by omega) (by omega) (by omega) h'

/-- **Gauge fixing of the crossing temporal links for the Wilson measure.** -/
theorem wilson_gaugeFix (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (β : ℝ)
    (F : (Lk N → QBall) → ℝ) (hF : Measurable F)
    (hinv : ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : ℍr)‖ = 1) → ∀ ω,
      F (act (src N) (tgt N) g ω) = F ω) :
    ∫ ω, F ω ∂(wilsonMeasure N β)
      = ∫ ω, F (setOne (cr N M) ω) * wilsonWeight N β (setOne (cr N M) ω)
          ∂(Measure.pi fun _ : Lk N => haarBall) := by
  obtain ⟨hk1, hk2, hk3⟩ := crossing_data N M hN hM
  rw [integral_wilson]
  exact integral_gaugeFix (src N) (tgt N) (cr N M) (hasIn N M) (kIn N) hk1 hk2 hk3
    (fun ω => F ω * wilsonWeight N β ω) (hF.mul (continuous_wilsonWeight N β).measurable)
    (fun g hg ω => by
      show F (act (src N) (tgt N) g ω) * wilsonWeight N β (act (src N) (tgt N) g ω)
        = F ω * wilsonWeight N β ω
      rw [hinv g hg ω, wilsonWeight_act N β g hg ω])

end TorusGauge

#print axioms TorusGauge.hol_act
#print axioms TorusGauge.wilsonWeight_act
#print axioms TorusGauge.crossing_data
#print axioms TorusGauge.wilson_gaugeFix
