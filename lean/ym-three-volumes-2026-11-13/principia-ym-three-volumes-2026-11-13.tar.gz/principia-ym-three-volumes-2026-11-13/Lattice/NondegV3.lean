import Spec.LinkDLRV2
import Spec.DobrushinRowV2

/-!
# Non-degeneracy of the strong-coupling limit points (table 2, row 10)

Paper correspondence: (non-degeneracy of the limit points).
* `HaarRe.integral_sq_sub_ge` : `∫ (Re U - c)² dHaar ≥ 1/4` (left invariance under `-1, i, j, k`).
* `LinkSpec.wilsonProb_sq_sub_ge` : for every torus, link `x`, constant `c`,
  `∫ (Re ω_x - c)² dP_N ≥ e^{-12|β|}/4` (single-link DLR, local action in `[-6|β|, 6|β|]`).
* `WilsonLimit.var_limit_ge` : at every weak limit point `ν`, `Var_ν(Re x_{ℓ₀}) ≥ e^{-12|β|}/4`,
  `ℓ₀` the spatial link at the origin (time `0`, fixed by the reflection).
* `OSGap.Datum.exists_unit_orth` : a positive reflected variance gives a unit vector orthogonal
  to the vacuum.
* `WilsonLimit.wilson_massGap_nondegenerate` : the mass-gap statement of `WilsonGapV2` together
  with `κ ≤ B(F₀,F₀) - B(1,F₀)²` and `∃ v, ⟪v, Ω⟫ = 0 ∧ ‖v‖ = 1`.
Formalisation of a known result (Osterwalder–Seiler type strong coupling).
-/

open MeasureTheory

namespace HaarRe

open OSGap TorusRP

theorem norm_eq_one_of_normSq (q : Quaternion ℝ) (h : Quaternion.normSq q = 1) : ‖q‖ = 1 := by
  rw [Quaternion.normSq_eq_norm_mul_self] at h
  exact (mul_self_eq_one_iff.mp h).resolve_right (by linarith [norm_nonneg q])

/-- an element of `SU2` from a quaternion of norm one -/
def mk (q : Quaternion ℝ) (h : Quaternion.normSq q = 1) : SU2 :=
  ⟨q, mem_sphere_zero_iff_norm.2 (norm_eq_one_of_normSq q h)⟩

theorem coe_mul (g q : SU2) : ((g * q : SU2) : Quaternion ℝ) = (g : Quaternion ℝ) * q := rfl

theorem integrable_cont {X : Type*} [TopologicalSpace X] [CompactSpace X] [MeasurableSpace X]
    [OpensMeasurableSpace X] (μ : Measure X) [IsFiniteMeasure μ] (f : X → ℝ) (hf : Continuous f) :
    Integrable f μ :=
  BoundedContinuousFunction.integrable μ (BoundedContinuousFunction.mkOfCompact ⟨f, hf⟩)

/-- the four coordinates of a unit quaternion -/
noncomputable def c0 (q : SU2) : ℝ := (q : Quaternion ℝ).re
noncomputable def c1 (q : SU2) : ℝ := (q : Quaternion ℝ).imI
noncomputable def c2 (q : SU2) : ℝ := (q : Quaternion ℝ).imJ
noncomputable def c3 (q : SU2) : ℝ := (q : Quaternion ℝ).imK

noncomputable def qi : Quaternion ℝ := ⟨0, 1, 0, 0⟩
noncomputable def qj : Quaternion ℝ := ⟨0, 0, 1, 0⟩
noncomputable def qk : Quaternion ℝ := ⟨0, 0, 0, 1⟩

theorem qi_normSq : Quaternion.normSq qi = 1 := by
  rw [Quaternion.normSq_def']
  show (0 : ℝ) ^ 2 + 1 ^ 2 + 0 ^ 2 + 0 ^ 2 = 1
  norm_num

theorem qj_normSq : Quaternion.normSq qj = 1 := by
  rw [Quaternion.normSq_def']
  show (0 : ℝ) ^ 2 + 0 ^ 2 + 1 ^ 2 + 0 ^ 2 = 1
  norm_num

theorem qk_normSq : Quaternion.normSq qk = 1 := by
  rw [Quaternion.normSq_def']
  show (0 : ℝ) ^ 2 + 0 ^ 2 + 0 ^ 2 + 1 ^ 2 = 1
  norm_num

theorem neg_one_normSq : Quaternion.normSq (-1 : Quaternion ℝ) = 1 := by
  rw [Quaternion.normSq_neg, map_one]

theorem c0_qi (q : SU2) : c0 (mk qi qi_normSq * q) = -c1 q := by
  unfold c0 c1
  rw [coe_mul, Quaternion.re_mul]
  show (0 : ℝ) * _ - 1 * _ - 0 * _ - 0 * _ = _
  ring

theorem c0_qj (q : SU2) : c0 (mk qj qj_normSq * q) = -c2 q := by
  unfold c0 c2
  rw [coe_mul, Quaternion.re_mul]
  show (0 : ℝ) * _ - 0 * _ - 1 * _ - 0 * _ = _
  ring

theorem c0_qk (q : SU2) : c0 (mk qk qk_normSq * q) = -c3 q := by
  unfold c0 c3
  rw [coe_mul, Quaternion.re_mul]
  show (0 : ℝ) * _ - 0 * _ - 0 * _ - 1 * _ = _
  ring

theorem c0_neg (q : SU2) : c0 (mk (-1) neg_one_normSq * q) = -c0 q := by
  unfold c0
  rw [coe_mul]
  show ((-1 : Quaternion ℝ) * (q : Quaternion ℝ)).re = _
  rw [neg_one_mul, Quaternion.re_neg]

theorem sum_sq (q : SU2) : c0 q ^ 2 + c1 q ^ 2 + c2 q ^ 2 + c3 q ^ 2 = 1 := by
  have hn : ‖(q : Quaternion ℝ)‖ = 1 := mem_sphere_zero_iff_norm.mp q.2
  have h2 : Quaternion.normSq (q : Quaternion ℝ) = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, hn, mul_one]
  rw [Quaternion.normSq_def'] at h2
  exact h2

theorem continuous_c0 : Continuous c0 := Quaternion.continuous_re.comp continuous_subtype_val
theorem continuous_c1 : Continuous c1 := Quaternion.continuous_imI.comp continuous_subtype_val
theorem continuous_c2 : Continuous c2 := Quaternion.continuous_imJ.comp continuous_subtype_val
theorem continuous_c3 : Continuous c3 := Quaternion.continuous_imK.comp continuous_subtype_val

/-- `E Re U = 0` (invariance under `q ↦ -q`) -/
theorem integral_re : ∫ q, c0 q ∂haarSU2 = 0 := by
  have h := integral_mul_left_eq_self (μ := haarSU2) c0 (mk (-1) neg_one_normSq)
  simp only [c0_neg, integral_neg] at h
  linarith

/-- `E (Re U)² = 1/4` (invariance under `q ↦ i q, j q, k q`) -/
theorem integral_re_sq : ∫ q, c0 q ^ 2 ∂haarSU2 = 1 / 4 := by
  have hi := integral_mul_left_eq_self (μ := haarSU2) (fun q => c0 q ^ 2) (mk qi qi_normSq)
  have hj := integral_mul_left_eq_self (μ := haarSU2) (fun q => c0 q ^ 2) (mk qj qj_normSq)
  have hk := integral_mul_left_eq_self (μ := haarSU2) (fun q => c0 q ^ 2) (mk qk qk_normSq)
  simp only [c0_qi, c0_qj, c0_qk, neg_sq] at hi hj hk
  have I0 : Integrable (fun q => c0 q ^ 2) haarSU2 := integrable_cont haarSU2 _ (continuous_c0.pow 2)
  have I1 : Integrable (fun q => c1 q ^ 2) haarSU2 := integrable_cont haarSU2 _ (continuous_c1.pow 2)
  have I2 : Integrable (fun q => c2 q ^ 2) haarSU2 := integrable_cont haarSU2 _ (continuous_c2.pow 2)
  have I3 : Integrable (fun q => c3 q ^ 2) haarSU2 := integrable_cont haarSU2 _ (continuous_c3.pow 2)
  have a1 : ∫ q, (c0 q ^ 2 + c1 q ^ 2) ∂haarSU2 = ∫ q, c0 q ^ 2 ∂haarSU2 + ∫ q, c1 q ^ 2 ∂haarSU2 :=
    integral_add I0 I1
  have a2 : ∫ q, (c0 q ^ 2 + c1 q ^ 2 + c2 q ^ 2) ∂haarSU2
      = ∫ q, (c0 q ^ 2 + c1 q ^ 2) ∂haarSU2 + ∫ q, c2 q ^ 2 ∂haarSU2 := integral_add (I0.add I1) I2
  have a3 : ∫ q, (c0 q ^ 2 + c1 q ^ 2 + c2 q ^ 2 + c3 q ^ 2) ∂haarSU2
      = ∫ q, (c0 q ^ 2 + c1 q ^ 2 + c2 q ^ 2) ∂haarSU2 + ∫ q, c3 q ^ 2 ∂haarSU2 :=
    integral_add ((I0.add I1).add I2) I3
  have htot : ∫ q, (c0 q ^ 2 + c1 q ^ 2 + c2 q ^ 2 + c3 q ^ 2) ∂haarSU2 = 1 := by
    simp only [sum_sq]
    simp
  linarith

/-- `∫ (Re U - c)² dHaar = 1/4 + c² ≥ 1/4` -/
theorem integral_sq_sub_ge (c : ℝ) : 1 / 4 ≤ ∫ q, (c0 q - c) ^ 2 ∂haarSU2 := by
  have e : ∀ q : SU2, (c0 q - c) ^ 2 = c0 q ^ 2 + (-(2 * c)) * c0 q + c ^ 2 := fun q => by ring
  simp only [e]
  have I0 : Integrable (fun q => c0 q ^ 2) haarSU2 := integrable_cont haarSU2 _ (continuous_c0.pow 2)
  have I1 : Integrable (fun q => (-(2 * c)) * c0 q) haarSU2 :=
    integrable_cont haarSU2 _ (continuous_const.mul continuous_c0)
  have a1 : ∫ q, (c0 q ^ 2 + (-(2 * c)) * c0 q) ∂haarSU2
      = ∫ q, c0 q ^ 2 ∂haarSU2 + ∫ q, (-(2 * c)) * c0 q ∂haarSU2 := integral_add I0 I1
  have a2 : ∫ q, (c0 q ^ 2 + (-(2 * c)) * c0 q + c ^ 2) ∂haarSU2
      = ∫ q, (c0 q ^ 2 + (-(2 * c)) * c0 q) ∂haarSU2 + ∫ _q, c ^ 2 ∂haarSU2 :=
    integral_add (I0.add I1) (integrable_const _)
  have a3 : ∫ q, (-(2 * c)) * c0 q ∂haarSU2 = (-(2 * c)) * ∫ q, c0 q ∂haarSU2 :=
    integral_const_mul _ _
  have a4 : ∫ _q, c ^ 2 ∂haarSU2 = c ^ 2 := by simp
  rw [a2, a1, a3, a4, integral_re, integral_re_sq]
  nlinarith [sq_nonneg c]

/-- the same on the closed ball (the reference measure of a link) -/
theorem haarBall_sq_sub_ge (c : ℝ) :
    1 / 4 ≤ ∫ U, (((U : QBall) : Quaternion ℝ).re - c) ^ 2 ∂haarBall := by
  have hc : Continuous (fun U : QBall => (((U : QBall) : Quaternion ℝ).re - c) ^ 2) :=
    ((Quaternion.continuous_re.comp continuous_subtype_val).sub continuous_const).pow 2
  rw [haarBall, integral_map continuous_incl.measurable.aemeasurable hc.aestronglyMeasurable]
  exact integral_sq_sub_ge c

end HaarRe

namespace LinkSpec

open TorusRP Filter

variable (N : ℕ) [NeZero N]

/-- the observable `(Re ω_x - c)²` -/
noncomputable def sqDev (x : Lk N) (c : ℝ) (ω : Lk N → QBall) : ℝ :=
  (((ω x : QBall) : Quaternion ℝ).re - c) ^ 2

theorem continuous_sqDev (x : Lk N) (c : ℝ) : Continuous (sqDev N x c) :=
  ((Quaternion.continuous_re.comp (continuous_subtype_val.comp (continuous_apply x))).sub
    continuous_const).pow 2

theorem abs_re_le (U : QBall) : |((U : QBall) : Quaternion ℝ).re| ≤ 1 := by
  have h2 : ‖(U : Quaternion ℝ)‖ ≤ 1 := mem_closedBall_zero_iff.1 U.2
  have h3 : ((U : Quaternion ℝ).re) ^ 2 ≤ ‖(U : Quaternion ℝ)‖ ^ 2 := by
    rw [sq ‖(U : Quaternion ℝ)‖, ← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
    nlinarith [sq_nonneg (U : Quaternion ℝ).imI, sq_nonneg (U : Quaternion ℝ).imJ,
      sq_nonneg (U : Quaternion ℝ).imK]
  have h4 := (sq_le_sq.1 h3).trans_eq (abs_norm _)
  linarith

theorem abs_sqDev_le (x : Lk N) (c : ℝ) (ω : Lk N → QBall) : |sqDev N x c ω| ≤ (1 + |c|) ^ 2 := by
  unfold sqDev
  rw [abs_pow]
  have h := abs_re_le (ω x)
  have : |((ω x : QBall) : Quaternion ℝ).re - c| ≤ 1 + |c| :=
    (abs_sub _ _).trans (by linarith)
  exact pow_le_pow_left₀ (abs_nonneg _) this 2

/-- the single-link conditional average of `(Re ω_x - c)²` is at least `e^{-12|β|}/4` -/
theorem spec_sqDev_ge (β : ℝ) (x : Lk N) (c : ℝ) (ω : Lk N → QBall) :
    Real.exp (-(12 * |β|)) / 4 ≤ specNum N β x (sqDev N x c) ω / specDen N β x ω := by
  have h6 : |β| * (plaqsAt N x).card ≤ 6 * |β| := by
    have := plaqsAt_card_le N x
    have : ((plaqsAt N x).card : ℝ) ≤ 6 := by exact_mod_cast this
    nlinarith [abs_nonneg β]
  have hlo : ∀ U, Real.exp (-(6 * |β|)) ≤ Real.exp (locAct N β ω x U) := fun U => by
    apply Real.exp_le_exp.2
    have := abs_locAct_le N β ω x U
    have := neg_abs_le (locAct N β ω x U)
    linarith
  have hhi : ∀ U, Real.exp (locAct N β ω x U) ≤ Real.exp (6 * |β|) := fun U => by
    apply Real.exp_le_exp.2
    have := abs_locAct_le N β ω x U
    have := le_abs_self (locAct N β ω x U)
    linarith
  have hd := specDen_pos N β x ω
  have hcU : Continuous (fun U : QBall => (((U : QBall) : Quaternion ℝ).re - c) ^ 2) :=
    ((Quaternion.continuous_re.comp continuous_subtype_val).sub continuous_const).pow 2
  have hnum : specNum N β x (sqDev N x c) ω
      = ∫ U, (((U : QBall) : Quaternion ℝ).re - c) ^ 2 * Real.exp (locAct N β ω x U) ∂haarBall := by
    unfold specNum sqDev
    simp only [Function.update_self]
  have hnum_ge : Real.exp (-(6 * |β|)) * (1 / 4) ≤ specNum N β x (sqDev N x c) ω := by
    rw [hnum]
    have hint1 : Integrable (fun U : QBall => Real.exp (-(6 * |β|)) *
        (((U : QBall) : Quaternion ℝ).re - c) ^ 2) haarBall :=
      HaarRe.integrable_cont haarBall _ (continuous_const.mul hcU)
    have hint2 : Integrable (fun U : QBall => (((U : QBall) : Quaternion ℝ).re - c) ^ 2 *
        Real.exp (locAct N β ω x U)) haarBall :=
      HaarRe.integrable_cont haarBall _
        (hcU.mul (Real.continuous_exp.comp (continuous_locAct N β ω x)))
    calc Real.exp (-(6 * |β|)) * (1 / 4)
        ≤ Real.exp (-(6 * |β|)) * ∫ U, (((U : QBall) : Quaternion ℝ).re - c) ^ 2 ∂haarBall :=
          mul_le_mul_of_nonneg_left (HaarRe.haarBall_sq_sub_ge c) (Real.exp_pos _).le
      _ = ∫ U, Real.exp (-(6 * |β|)) * (((U : QBall) : Quaternion ℝ).re - c) ^ 2 ∂haarBall :=
          (integral_const_mul _ _).symm
      _ ≤ _ := integral_mono hint1 hint2 (fun U => by
          rw [mul_comm]
          exact mul_le_mul_of_nonneg_left (hlo U) (sq_nonneg _))
  have hden_le : specDen N β x ω ≤ Real.exp (6 * |β|) := by
    unfold specDen
    calc ∫ U, Real.exp (locAct N β ω x U) ∂haarBall ≤ ∫ _U, Real.exp (6 * |β|) ∂haarBall :=
          integral_mono (integrable_exp_locAct N β x ω) (integrable_const _) hhi
      _ = Real.exp (6 * |β|) := by simp
  rw [le_div_iff₀ hd]
  have e12 : Real.exp (-(12 * |β|)) = Real.exp (-(6 * |β|)) * (Real.exp (6 * |β|))⁻¹ := by
    rw [← Real.exp_neg, ← Real.exp_add]; ring_nf
  calc Real.exp (-(12 * |β|)) / 4 * specDen N β x ω
      ≤ Real.exp (-(12 * |β|)) / 4 * Real.exp (6 * |β|) :=
        mul_le_mul_of_nonneg_left hden_le (by positivity)
    _ = Real.exp (-(6 * |β|)) * (1 / 4) := by
        rw [e12]; field_simp
    _ ≤ _ := hnum_ge

/-- **Uniform lower bound in finite volume:** `∫ (Re ω_x - c)² dP_N ≥ e^{-12|β|}/4` for every
torus size `N`, link `x`, constant `c` and coupling `β`. -/
theorem wilsonProb_sq_sub_ge (β : ℝ) (x : Lk N) (c : ℝ) :
    Real.exp (-(12 * |β|)) / 4 ≤
      ∫ ω, (((ω x : QBall) : Quaternion ℝ).re - c) ^ 2 ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  have hH : Measurable (sqDev N x c) := (continuous_sqDev N x c).measurable
  have hdlr := dlr N β x (sqDev N x c) hH _ (abs_sqDev_le N x c)
  -- measurability of the ratio (as in the proof of `dlr`)
  have hf := (update_preserving N x).measurable
  have hNum : Measurable (fun ω => specNum N β x (sqDev N x c) ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        sqDev N x c (Function.update z.1 x z.2) * Real.exp (locAct N β z.1 x z.2)) :=
      ((hH.comp hf).mul (Real.continuous_exp.comp (continuous_locAct₂ N β x)).measurable).stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hDen : Measurable (fun ω => specDen N β x ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        Real.exp (locAct N β z.1 x z.2)) :=
      (Real.continuous_exp.comp (continuous_locAct₂ N β x)).measurable.stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hint : Integrable (fun ω => specNum N β x (sqDev N x c) ω / specDen N β x ω)
      (wilsonMeasure N β) :=
    Integrable.of_bound (hNum.div hDen).aestronglyMeasurable _
      (Eventually.of_forall fun ω => by
        rw [Real.norm_eq_abs]; exact abs_spec_le N β x _ hH _ (abs_sqDev_le N x c) ω)
  have hmono : ∫ _ω, Real.exp (-(12 * |β|)) / 4 ∂(wilsonMeasure N β)
      ≤ ∫ ω, specNum N β x (sqDev N x c) ω / specDen N β x ω ∂(wilsonMeasure N β) :=
    integral_mono (integrable_const _) hint (fun ω => spec_sqDev_ge N β x c ω)
  rw [← hdlr, integral_const, smul_eq_mul] at hmono
  have hpos : 0 < (wilsonMeasure N β).real Set.univ := by
    rw [measureReal_def]
    exact ENNReal.toReal_pos (wilsonMeasure_univ_pos N β).ne' (wilsonMeasure_univ_lt_top N β).ne
  rw [wilsonProb_toMeasure, integral_smul_measure, smul_eq_mul, ENNReal.toReal_inv,
    ← measureReal_def]
  change ∫ ω, sqDev N x c ω ∂(wilsonMeasure N β) ≥ _ at hmono
  rw [le_inv_mul_iff₀ hpos]
  exact hmono

end LinkSpec

namespace OSGap

open scoped InnerProductSpace

namespace Datum

variable {V : Type*} [AddCommGroup V] [Module ℝ V]

/-- **A positive reflected variance gives a unit vector orthogonal to the vacuum.** -/
theorem exists_unit_orth (D : Datum V) (x : V) (h : 0 < D.B x x - (D.B D.one x) ^ 2) :
    ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  set a := D.B D.one x with ha
  set y := x - a • D.one with hy
  have hxo : D.B x D.one = a := D.symm _ _
  have hyy : D.B y y = D.B x x - a ^ 2 := by
    rw [hy]
    simp only [map_sub, map_smul, LinearMap.sub_apply, LinearMap.smul_apply, smul_eq_mul]
    rw [hxo, ← ha, D.one_one]
    ring
  have hyo : D.B y D.one = 0 := by
    rw [hy]
    simp only [map_sub, map_smul, LinearMap.sub_apply, LinearMap.smul_apply, smul_eq_mul]
    rw [hxo, D.one_one]
    ring
  have hs : 0 < D.B y y := by rw [hyy]; exact h
  have hn : ‖D.emb y‖ = Real.sqrt (D.B y y) := by
    rw [← norm_emb_sq, Real.sqrt_sq (norm_nonneg _)]
  have hnpos : 0 < ‖D.emb y‖ := by rw [hn]; exact Real.sqrt_pos.2 hs
  refine ⟨‖D.emb y‖⁻¹ • D.emb y, ?_, ?_⟩
  · rw [real_inner_smul_left]
    unfold Ω
    rw [inner_emb, hyo, mul_zero]
  · rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.2 hnpos), inv_mul_cancel₀ hnpos.ne']

end Datum

end OSGap

namespace WilsonLimit

open Filter Topology TorusRP LinkReflection OSGap OrbitGrowth
open scoped BoundedContinuousFunction InnerProductSpace

/-- the spatial link at the origin (time `0`, direction `1`), fixed by the reflection -/
def ell0 : ZLk := (0, 1)

theorem zthL_ell0 : zthL ell0 = ell0 := by
  unfold zthL
  rw [if_neg (by decide)]
  refine Prod.ext (funext fun i => ?_) rfl
  simp [zthS, ell0]

theorem zRefl_ell0 (x : Cfg) : zRefl x ell0 = x ell0 := by
  show zsig ell0 (x (zthL ell0)) = x ell0
  rw [zthL_ell0]
  unfold zsig
  rw [if_neg (by decide)]
  rfl

theorem continuous_re0 : Continuous (fun x : Cfg => ((x ell0 : QBall) : Quaternion ℝ).re) :=
  Quaternion.continuous_re.comp (continuous_subtype_val.comp (continuous_apply ell0))

/-- `F₀ x = Re x_{ℓ₀}` -/
noncomputable def F0 : Cfg →ᵇ ℝ :=
  BoundedContinuousFunction.mkOfCompact ⟨fun x => ((x ell0 : QBall) : Quaternion ℝ).re, continuous_re0⟩

theorem F0_apply (x : Cfg) : F0 x = ((x ell0 : QBall) : Quaternion ℝ).re := rfl

theorem F0_mem : F0 ∈ Wsub := by
  refine (mem_Wsub _).2 ⟨{ell0}, 0, ?_, ?_⟩
  · intro ℓ hℓ
    rw [Finset.mem_singleton] at hℓ
    subst hℓ
    simp [ell0]
  · intro x y h
    rw [F0_apply, F0_apply, h ell0 (Finset.mem_singleton_self _)]

theorem F0_refl (x : Cfg) : F0 (zRefl x) = F0 x := by
  rw [F0_apply, F0_apply, zRefl_ell0]

/-- variance identity for a probability measure and a bounded continuous function -/
theorem integral_sq_sub_mean (μ : ProbabilityMeasure Cfg) (F : Cfg →ᵇ ℝ) :
    ∫ x, (F x - ∫ y, F y ∂(μ : Measure Cfg)) ^ 2 ∂(μ : Measure Cfg)
      = ∫ x, F x * F x ∂(μ : Measure Cfg) - (∫ y, F y ∂(μ : Measure Cfg)) ^ 2 := by
  set m := ∫ y, F y ∂(μ : Measure Cfg)
  have e : ∀ x, (F x - m) ^ 2 = F x * F x + (-(2 * m)) * F x + m ^ 2 := fun x => by ring
  simp only [e]
  have I0 : Integrable (fun x => F x * F x) (μ : Measure Cfg) :=
    BoundedContinuousFunction.integrable _ (F * F)
  have I1 : Integrable (fun x => (-(2 * m)) * F x) (μ : Measure Cfg) :=
    (BoundedContinuousFunction.integrable _ F).const_mul _
  have a1 : ∫ x, (F x * F x + (-(2 * m)) * F x) ∂(μ : Measure Cfg)
      = ∫ x, F x * F x ∂(μ : Measure Cfg) + ∫ x, (-(2 * m)) * F x ∂(μ : Measure Cfg) :=
    integral_add I0 I1
  have a2 : ∫ x, (F x * F x + (-(2 * m)) * F x + m ^ 2) ∂(μ : Measure Cfg)
      = ∫ x, (F x * F x + (-(2 * m)) * F x) ∂(μ : Measure Cfg) + ∫ _x, m ^ 2 ∂(μ : Measure Cfg) :=
    integral_add (I0.add I1) (integrable_const _)
  have a3 : ∫ x, (-(2 * m)) * F x ∂(μ : Measure Cfg) = (-(2 * m)) * m := integral_const_mul _ _
  have a4 : ∫ _x, m ^ 2 ∂(μ : Measure Cfg) = m ^ 2 := by simp
  rw [a2, a1, a3, a4]
  ring

/-- finite volume, lifted: `Var_{μ_n}(F₀) ≥ e^{-12|β|}/4` for every `n` -/
theorem var_lift_ge (β : ℝ) (n : ℕ) :
    Real.exp (-(12 * |β|)) / 4 ≤ ∫ x, F0 x * F0 x ∂(liftProb β n : Measure Cfg)
      - (∫ x, F0 x ∂(liftProb β n : Measure Cfg)) ^ 2 := by
  rw [← integral_sq_sub_mean]
  set c := ∫ y, F0 y ∂(liftProb β n : Measure Cfg)
  have hcont : Continuous (fun x : Cfg => (F0 x - c) ^ 2) := (F0.continuous.sub continuous_const).pow 2
  rw [integral_lift β n _ hcont]
  exact LinkSpec.wilsonProb_sq_sub_ge (Nn n) β (zproj (Nn n) ell0) c

/-- **At every weak limit point, `Var_ν(Re x_{ℓ₀}) ≥ e^{-12|β|}/4`.** -/
theorem var_limit_ge (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    Real.exp (-(12 * |β|)) / 4 ≤ ∫ x, F0 x * F0 x ∂(ν : Measure Cfg)
      - (∫ x, F0 x ∂(ν : Measure Cfg)) ^ 2 := by
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
  have h2 := h (F0 * F0)
  have h1 := h F0
  simp only [BoundedContinuousFunction.coe_mul, Pi.mul_apply] at h2
  exact ge_of_tendsto' (h2.sub (h1.pow 2)) (fun n => var_lift_ge β (φ n))

/-- **Mass gap with non-degeneracy at every weak limit point (strong coupling, SU(2), ℤ⁴).**
Statement G of `wilson_massGap_limitPoint` together with: the reflected variance of
`F₀ = Re x_{ℓ₀}` (`ℓ₀` the spatial link at the origin) is at least `e^{-12|β|}/4`, so the orthogonal
complement of the vacuum in the reconstructed Hilbert space is not zero.
Paper: Formalisation of a known result (Osterwalder–Seiler type). -/
theorem wilson_massGap_nondegenerate (β : ℝ) (hβ0 : β ≠ 0)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap (-Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
      ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨D, hB, hτ, hone, hgap⟩ := wilson_massGap_limitPoint β hβ0 hβ ν φ hφ hlim
  have hFF : D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ = ∫ x, F0 x * F0 x ∂(ν : Measure Cfg) := by
    rw [hB]
    simp only [F0_refl]
  have h1F : D.B D.one ⟨F0, F0_mem⟩ = ∫ x, F0 x ∂(ν : Measure Cfg) := by
    rw [hB, hone]
    simp only [BoundedContinuousFunction.coe_one, Pi.one_apply, one_mul]
  have hvar : Real.exp (-(12 * |β|)) / 4 ≤
      D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 := by
    rw [hFF, h1F]
    exact var_limit_ge β ν φ hlim
  refine ⟨D, hB, hτ, hone, hgap, hvar, D.exists_unit_orth _ (lt_of_lt_of_le (by positivity) hvar)⟩

/-- **Combined statement with non-degeneracy (no hypothesis besides the window).** -/
theorem wilson_massGap_nondegenerate_exists (β : ℝ) (hβ0 : β ≠ 0)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1) :
    ∃ ν : ProbabilityMeasure Cfg, ∃ φ : ℕ → ℕ, StrictMono φ ∧
      Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν) ∧
      ∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
        ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨ν, φ, hφ, h⟩ := exists_limitPoint β
  exact ⟨ν, φ, hφ, h, wilson_massGap_nondegenerate β hβ0 hβ ν φ hφ h⟩

end WilsonLimit

#print axioms HaarRe.integral_re
#print axioms HaarRe.integral_re_sq
#print axioms HaarRe.haarBall_sq_sub_ge
#print axioms LinkSpec.spec_sqDev_ge
#print axioms LinkSpec.wilsonProb_sq_sub_ge
#print axioms OSGap.Datum.exists_unit_orth
#print axioms WilsonLimit.var_limit_ge
#print axioms WilsonLimit.wilson_massGap_nondegenerate
#print axioms WilsonLimit.wilson_massGap_nondegenerate_exists
