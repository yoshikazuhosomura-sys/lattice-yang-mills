import Lattice.RPKernelSiteV1

/-!
# The middle-plane reflection of the torus satisfies the hypotheses of `rp_kernel`

Paper correspondence: (step 2, the index part).
On `(ℤ/2M)⁴`, `M ≥ 2`: `thM = shL ∘ thL` is the reflection `x₀ ↦ 1 - x₀` of the links (planes
`x₀ = ½`, `x₀ = M + ½`).  With `fix` = the crossing temporal links (base time `0` or `M`), `posM` =
spatial links of time `1 … M` and temporal links of base time `1 … M-1`, and `sigM` = `star` on the
other temporal links, the hypotheses `hθ`, `hfix`, `hposfix`, `hA`, `hB`, `hσ` of
`LinkReflection.rp_kernel` hold (`mid_hyps`).  The factorisation of the Wilson weight with the
crossing links set to `1` is not in this file.
-/

namespace MidRP

open MeasureTheory TorusRP LinkReflection TorusGauge

variable (N : ℕ) [NeZero N]

/-- the middle-plane reflection of links -/
def thM (ℓ : Lk N) : Lk N := shL N (thL N ℓ)

theorem thM_snd (ℓ : Lk N) : (thM N ℓ).2 = ℓ.2 := by
  unfold thM shL; exact thL_snd N ℓ

theorem thM_invol : Function.Involutive (thM N) := by
  intro ℓ
  obtain ⟨x, μ⟩ := ℓ
  by_cases h : μ = 0
  · subst h
    simp only [thM, shL, thL, if_true, sub_add_cancel, thS_thS]
  · simp only [thM, shL, thL, h, if_false, thS_add, thS_thS, thS_ev0, neg_add_cancel_right]

theorem thM_time (ℓ : Lk N) :
    (thM N ℓ).1 0 = if ℓ.2 = 0 then -(ℓ.1 0) else 1 - ℓ.1 0 := by
  unfold thM shL
  show ((thL N ℓ).1 + ev N 0) 0 = _
  rw [Pi.add_apply, thL_time]
  have : ev N 0 0 = 1 := by simp [ev]
  rw [this]
  split_ifs <;> ring

/-- the values: `star` on the temporal links that are not crossing -/
noncomputable def sigM (M : ℕ) (ℓ : Lk N) : QBall → QBall :=
  if ℓ.2 = 0 ∧ ¬ cr N M ℓ then starB else id

theorem sigM_preserving (M : ℕ) (ℓ : Lk N) : MeasurePreserving (sigM N M ℓ) haarBall haarBall := by
  unfold sigM; split_ifs
  · exact starB_preserving
  · exact MeasurePreserving.id _

/-- the open positive side of the middle planes -/
def posM (M : ℕ) (ℓ : Lk N) : Prop :=
  if ℓ.2 = 0 then 1 ≤ tm N ℓ ∧ tm N ℓ < M else 1 ≤ tm N ℓ ∧ tm N ℓ ≤ M

instance (M : ℕ) : DecidablePred (posM N M) := fun ℓ => by unfold posM; infer_instance

theorem val_M (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) : ((M : ZMod N)).val = M := by
  rw [ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem cr_iff (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ℓ : Lk N) :
    cr N M ℓ ↔ ℓ.2 = 0 ∧ (tm N ℓ = 0 ∨ tm N ℓ = M) := by
  unfold cr tm
  constructor
  · rintro ⟨h2, h | h⟩
    · exact ⟨h2, Or.inl (by rw [h, ZMod.val_zero])⟩
    · exact ⟨h2, Or.inr (by rw [h, val_M N M hN hM])⟩
  · rintro ⟨h2, h | h⟩
    · exact ⟨h2, Or.inl ((ZMod.val_eq_zero _).1 h)⟩
    · refine ⟨h2, Or.inr ?_⟩
      rw [← ZMod.natCast_zmod_val (ℓ.1 0), h]

theorem val_one_sub (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (t : ZMod N) :
    (1 - t).val = if t.val = 0 then 1 else if t.val = 1 then 0 else N + 1 - t.val := by
  have hv := ZMod.val_lt t
  haveI : Fact (1 < N) := ⟨by omega⟩
  split_ifs with h0 h1
  · rw [(ZMod.val_eq_zero t).1 h0, sub_zero, ZMod.val_one]
  · have : t = 1 := by
      rw [← ZMod.natCast_zmod_val t, h1, Nat.cast_one]
    rw [this, sub_self, ZMod.val_zero]
  · have h : (N + 1 - t.val) + t.val = N + 1 := by omega
    have h2 := congrArg (Nat.cast : ℕ → ZMod N) h
    rw [Nat.cast_add, Nat.cast_add, Nat.cast_one, ZMod.natCast_self, ZMod.natCast_zmod_val,
      zero_add] at h2
    have h3 : ((N + 1 - t.val : ℕ) : ZMod N) = 1 - t := by linear_combination h2
    rw [← h3, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

theorem tm_thM_temporal (ℓ : Lk N) (h : ℓ.2 = 0) :
    tm N (thM N ℓ) = if tm N ℓ = 0 then 0 else N - tm N ℓ := by
  unfold tm
  rw [thM_time, if_pos h]
  split_ifs with h0
  · rw [(ZMod.val_eq_zero _).1 h0, neg_zero, ZMod.val_zero]
  · exact val_neg' N _ h0

theorem tm_thM_spatial (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ℓ : Lk N) (h : ℓ.2 ≠ 0) :
    tm N (thM N ℓ) = if tm N ℓ = 0 then 1 else if tm N ℓ = 1 then 0 else N + 1 - tm N ℓ := by
  unfold tm
  rw [thM_time, if_neg h, val_one_sub N M hN hM]

theorem hfix_mid (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ℓ : Lk N) (h : cr N M ℓ) :
    thM N ℓ = ℓ ∧ ∀ x, sigM N M ℓ x = x := by
  refine ⟨?_, fun x => by unfold sigM; rw [if_neg (fun h' => h'.2 h)]; rfl⟩
  obtain ⟨h2, h0⟩ := h
  obtain ⟨x, μ⟩ := ℓ
  simp only at h2 h0
  subst h2
  have hx : -(x 0) = x 0 := by
    rcases h0 with h0 | h0
    · rw [h0, neg_zero]
    · have hNM : ((2 * M : ℕ) : ZMod N) = 0 := by rw [← hN, ZMod.natCast_self]
      rw [Nat.cast_mul, Nat.cast_ofNat] at hNM
      rw [h0]; linear_combination -hNM
  refine Prod.ext (funext fun i => ?_) rfl
  by_cases hi : i = 0
  · subst hi
    have := thM_time N (x, 0)
    rw [if_pos rfl] at this
    rw [this, hx]
  · simp only [thM, shL, thL, if_true, sub_add_cancel, thS, if_neg hi]

theorem hposfix_mid (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ℓ : Lk N) (h : posM N M ℓ) :
    ¬ cr N M ℓ := by
  rw [cr_iff N M hN hM]
  rintro ⟨h2, h0⟩
  unfold posM at h
  rw [if_pos h2] at h
  omega

theorem hA_mid (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (ℓ : Lk N) (h : posM N M ℓ) :
    ¬ posM N M (thM N ℓ) := by
  have hlt := tm_lt N ℓ
  unfold posM at h ⊢
  rw [thM_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at h ⊢
    rw [tm_thM_temporal N ℓ h2]
    split_ifs <;> omega
  · rw [if_neg h2] at h ⊢
    rw [tm_thM_spatial N M hN (by omega) ℓ h2]
    split_ifs <;> omega

theorem hB_mid (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (ℓ : Lk N) (hf : ¬ cr N M ℓ)
    (hp : ¬ posM N M ℓ) : posM N M (thM N ℓ) := by
  have hlt := tm_lt N ℓ
  rw [cr_iff N M hN (by omega)] at hf
  unfold posM at hp ⊢
  rw [thM_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at hp ⊢
    have h0 : tm N ℓ ≠ 0 := fun h0 => hf ⟨h2, Or.inl h0⟩
    have hM' : tm N ℓ ≠ M := fun h0 => hf ⟨h2, Or.inr h0⟩
    rw [tm_thM_temporal N ℓ h2, if_neg h0]
    omega
  · rw [if_neg h2] at hp ⊢
    rw [tm_thM_spatial N M hN (by omega) ℓ h2]
    split_ifs <;> omega

/-- **The middle-plane data satisfy all hypotheses of `rp_kernel`**: hence for every bounded
measurable `g`, `φ` of the closed positive half (crossing links ∪ `posM`) and `β ≥ 0`,
`0 ≤ ∫ g(ω) g(Θ′ω) e^{β Σ φ(ω)φ(Θ′ω)} dHaar(ω)`. -/
theorem rp_kernel_mid (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M)
    (g : (Lk N → QBall) → ℝ) (hg : Measurable g) (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → g ω = g ω')
    {d : ℕ} (φ : (Lk N → QBall) → Fin d → ℝ) (hφ : ∀ j, Measurable fun ω => φ ω j) (Cφ : ℝ)
    (hφb : ∀ ω j, |φ ω j| ≤ Cφ)
    (hφdep : ∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → φ ω = φ ω')
    (β : ℝ) (hβ : 0 ≤ β) :
    0 ≤ ∫ ω, g ω * g (linkRefl (thM N) (sigM N M) ω) *
      Real.exp (β * ∑ j, φ ω j * φ (linkRefl (thM N) (sigM N M) ω) j)
        ∂(Measure.pi fun _ : Lk N => haarBall) :=
  rp_kernel haarBall (thM N) (sigM N M) (cr N M) (posM N M) (thM_invol N)
    (hfix_mid N M hN (by omega)) (hposfix_mid N M hN (by omega)) (hA_mid N M hN hM)
    (hB_mid N M hN hM) (sigM_preserving N M) g hg C hgC hdep φ hφ Cφ hφb hφdep β hβ

end MidRP

#print axioms MidRP.thM_invol
#print axioms MidRP.hfix_mid
#print axioms MidRP.hA_mid
#print axioms MidRP.hB_mid
#print axioms MidRP.rp_kernel_mid
