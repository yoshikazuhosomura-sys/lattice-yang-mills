import Lattice.TorusGaugeV1
import Kernel.ExpKernelV2

/-!
# Reflection positivity with a positive-definite crossing kernel (abstract; step 3 of the
# link-plane reflection positivity)


The measure isomorphism of `LinkReflection.rp_core` (fixed links × positive side × positive side)
with the weight `exp(β Σ_j φ_j(ω) φ_j(Θω))`, `φ` bounded measurable on the closed positive half:
for `β ≥ 0`, `0 ≤ ∫ g(ω) g(Θω) e^{β Σ_j φ_j(ω) φ_j(Θω)} dν^Λ` (`rp_kernel`).  The inner integral
over the two positive halves is `KernelPD.kernel_exp_nonneg` for each value of the fixed links.
-/

namespace LinkReflection

open MeasureTheory

variable {Λ X : Type*} [Fintype Λ] [MeasurableSpace X]

theorem rp_kernel [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (g : (Λ → X) → ℝ) (hg : Measurable g) (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → g ω = g ω')
    {d : ℕ} (φ : (Λ → X) → Fin d → ℝ) (hφ : ∀ j, Measurable fun ω => φ ω j) (Cφ : ℝ)
    (hφb : ∀ ω j, |φ ω j| ≤ Cφ)
    (hφdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → φ ω = φ ω')
    (β : ℝ) (hβ : 0 ≤ β) :
    0 ≤ ∫ ω, g ω * g (linkRefl θ σ ω) *
      Real.exp (β * ∑ j, φ ω j * φ (linkRefl θ σ ω) j) ∂(Measure.pi fun _ : Λ => ν) := by
  classical
  let e := negPosEquiv θ fix pos hθ (fun ℓ h => (hfix ℓ h).1) hposfix hA hB
  let Ψ : (Λ → X) → ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) :=
    fun ω => (fun i => ω i.1, (fun a => ω a.1.1, fun a => σ a.1.1 (ω (θ a.1.1))))
  have hs1 := measurePreserving_piEquivPiSubtypeProd (fun _ : Λ => ν) fix
  have hs2 := measurePreserving_piEquivPiSubtypeProd (fun _ : Off fix => ν)
    (fun q : Off fix => pos q.1)
  have hre := measurePreserving_piCongrLeft (fun _ : PosI fix pos => ν) e
  have hσp := measurePreserving_pi (fun _ : PosI fix pos => ν) (fun _ : PosI fix pos => ν)
    (f := fun a => σ a.1.1) (fun a => hσ a.1.1)
  have hτ := hσp.comp hre
  have hcomp := ((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod
    ((MeasurePreserving.id (Measure.pi fun _ : PosI fix pos => ν)).prod hτ)).comp
    (((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod hs2).comp hs1)
  have hΨ : MeasurePreserving Ψ (Measure.pi fun _ : Λ => ν)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    convert hcomp using 1
    funext ω
    refine Prod.ext rfl (Prod.ext rfl ?_)
    funext a
    show σ a.1.1 (ω (θ a.1.1)) = σ a.1.1 (MeasurableEquiv.piCongrLeft (fun _ : PosI fix pos => X) e
      (fun b => ω b.1.1) a)
    rw [piCongrLeft_const]
    rfl
  let G : ({ℓ // fix ℓ} → X) → (PosI fix pos → X) → ℝ := fun p a => g (glue fix pos p a)
  let Φ' : ({ℓ // fix ℓ} → X) → (PosI fix pos → X) → Fin d → ℝ := fun p a => φ (glue fix pos p a)
  have hG : Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => G z.1 z.2) :=
    hg.comp (measurable_glue fix pos)
  have hΦ' : ∀ j, Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => Φ' z.1 z.2 j) :=
    fun j => (hφ j).comp (measurable_glue fix pos)
  -- the integrand after the change of variables
  let K : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) → ℝ := fun z =>
    G z.1 z.2.1 * G z.1 z.2.2 * Real.exp (β * ∑ j, Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j)
  have hK : Measurable K := by
    refine Measurable.mul (Measurable.mul ?_ ?_) (Real.continuous_exp.measurable.comp
      (measurable_const.mul (Finset.measurable_sum _ fun j _ => Measurable.mul ?_ ?_)))
    · exact hG.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    · exact hG.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
    · exact (hΦ' j).comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    · exact (hΦ' j).comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have glue_eq : ∀ ω, (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = glue fix pos (Ψ ω).1 (Ψ ω).2.1 ℓ) := by
    intro ω ℓ hℓ
    show ω ℓ = glue fix pos (fun i => ω i.1) (fun a => ω a.1.1) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have glue_eq2 : ∀ ω, (∀ ℓ, fix ℓ ∨ pos ℓ →
      linkRefl θ σ ω ℓ = glue fix pos (Ψ ω).1 (Ψ ω).2.2 ℓ) := by
    intro ω ℓ hℓ
    show σ ℓ (ω (θ ℓ)) =
      glue fix pos (fun i => ω i.1) (fun a => σ a.1.1 (ω (θ a.1.1))) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h, (hfix ℓ h).1, (hfix ℓ h).2]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have hKΨ : ∀ ω, K (Ψ ω) = g ω * g (linkRefl θ σ ω) *
      Real.exp (β * ∑ j, φ ω j * φ (linkRefl θ σ ω) j) := by
    intro ω
    show g (glue fix pos (Ψ ω).1 (Ψ ω).2.1) * g (glue fix pos (Ψ ω).1 (Ψ ω).2.2) *
        Real.exp (β * ∑ j, φ (glue fix pos (Ψ ω).1 (Ψ ω).2.1) j * φ (glue fix pos (Ψ ω).1 (Ψ ω).2.2) j)
      = _
    rw [← hdep _ _ (glue_eq ω), ← hdep _ _ (glue_eq2 ω), ← hφdep _ _ (glue_eq ω),
      ← hφdep _ _ (glue_eq2 ω)]
  have hC : 0 ≤ C := le_trans (abs_nonneg _) (hgC (fun _ => Classical.arbitrary X))
  have hKb : ∀ z, |K z| ≤ C * C * Real.exp (β * (d * Cφ ^ 2)) := by
    intro z
    show |G z.1 z.2.1 * G z.1 z.2.2 * Real.exp (β * ∑ j, Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j)| ≤ _
    rw [abs_mul, abs_mul, abs_of_pos (Real.exp_pos _)]
    have h1 : |∑ j, Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j| ≤ (d : ℝ) * Cφ ^ 2 := by
      calc |∑ j, Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j| ≤ ∑ j, |Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j| :=
            Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _j : Fin d, Cφ ^ 2 := Finset.sum_le_sum fun j _ => by
            rw [abs_mul, sq]
            exact mul_le_mul (hφb (glue fix pos z.1 z.2.1) j) (hφb (glue fix pos z.1 z.2.2) j)
              (abs_nonneg _) ((abs_nonneg _).trans (hφb (glue fix pos z.1 z.2.1) j))
        _ = (d : ℝ) * Cφ ^ 2 := by simp
    have h2 : β * ∑ j, Φ' z.1 z.2.1 j * Φ' z.1 z.2.2 j ≤ β * (d * Cφ ^ 2) :=
      mul_le_mul_of_nonneg_left ((le_abs_self _).trans h1) hβ
    exact mul_le_mul (mul_le_mul (hgC _) (hgC _) (abs_nonneg _) hC) (Real.exp_le_exp.2 h2)
      (Real.exp_pos _).le (mul_nonneg hC hC)
  have hint : Integrable K ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
      ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) :=
    Integrable.of_bound hK.aestronglyMeasurable _
      (ae_of_all _ fun z => by rw [Real.norm_eq_abs]; exact hKb z)
  calc (0 : ℝ) ≤ ∫ z, K z ∂((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
        rw [integral_prod _ hint]
        refine integral_nonneg fun p => ?_
        have hGp : Measurable (G p) := hG.comp (measurable_const.prodMk measurable_id)
        have hΦp : ∀ j, Measurable fun a => Φ' p a j :=
          fun j => (hΦ' j).comp (measurable_const.prodMk measurable_id)
        exact KernelPD.kernel_exp_nonneg (Measure.pi fun _ : PosI fix pos => ν) (Φ' p) (G p) hΦp hGp
          Cφ C (fun a j => hφb _ j) (fun a => hgC _) β hβ
    _ = ∫ ω, K (Ψ ω) ∂(Measure.pi fun _ : Λ => ν) := by
        rw [← hΨ.map_eq, integral_map hΨ.measurable.aemeasurable hK.aestronglyMeasurable]
    _ = _ := by
        congr 1
        funext ω
        exact hKΨ ω

end LinkReflection

#print axioms LinkReflection.rp_kernel
