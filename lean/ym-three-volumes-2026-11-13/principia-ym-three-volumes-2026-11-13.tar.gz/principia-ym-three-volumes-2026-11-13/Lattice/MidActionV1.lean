import Lattice.MidGaugeV1

/-!
# The Wilson action and the middle-plane reflection

`MidRP.action_split_mid` : `S(ω) = A(ω) + A(Θ′ω) + C(ω)`, `A` = plaquettes of the open positive
side of the middle planes (temporal base time `1 … M-1`, spatial time `1 … M`), `C` = the plaquettes
crossing the planes `x₀ = ½`, `M + ½` (temporal, base time `0` or `M`), `Θ′` with `star` on all
temporal links.  Same scheme as the site version (`holQ_refl`, `wt_add`, `action_split`).
-/

namespace MidRP

open MeasureTheory TorusRP LinkReflection TorusGauge GaugeFix

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (M : ℕ)

/-- the reflected quaternion field for the middle plane -/
noncomputable def reflM (U : Lk N → ℍr) (ℓ : Lk N) : ℍr :=
  if ℓ.2 = 0 then star (U (thM N ℓ)) else U (thM N ℓ)

theorem Uq_reflM (ω : Lk N → QBall) : Uq N (linkRefl (thM N) (sigT N) ω) = reflM N (Uq N ω) := by
  funext ℓ
  unfold Uq reflM linkRefl sigT
  split_ifs <;> rfl

theorem thM_temporal (x : Site N) : thM N (x, 0) = (thS N x, 0) := by
  simp only [thM, shL, thL, if_true, sub_add_cancel]

theorem thM_spatial (x : Site N) {μ : Fin 4} (hμ : μ ≠ 0) : thM N (x, μ) = (thS N x + ev N 0, μ) := by
  simp only [thM, shL, thL, hμ, if_false]

theorem holQ_reflM (U : Lk N → ℍr) (x : Site N) (μ ν : Fin 4) (hlt : μ < ν) :
    (holQ N (reflM N U) ((x, μ), ν)).re = (holQ N U (thM N (x, μ), ν)).re := by
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  by_cases hμ : μ = 0
  · subst hμ
    have e1 : thM N (x + ev N 0, ν) = (thS N x, ν) := by
      rw [thM_spatial N _ hν, thS_add, thS_ev0, neg_add_cancel_right]
    have e2 : thM N (x + ev N ν, 0) = (thS N x + ev N ν, 0) := by
      rw [thM_temporal, thS_add, thS_ev N hν]
    have e3 : thM N (x, ν) = (thS N x + ev N 0, ν) := thM_spatial N x hν
    simp only [holQ, reflM, hν, if_true, if_false, ↓reduceIte]
    rw [thM_temporal, e1, e2, e3]
    simp only [if_true]
    exact quat4 _ _ _ _
  · have e0 : thM N (x, μ) = (thS N x + ev N 0, μ) := thM_spatial N x hμ
    have e1 : thM N (x + ev N μ, ν) = (thS N x + ev N 0 + ev N μ, ν) := by
      rw [thM_spatial N _ hν, thS_add, thS_ev N hμ]; abel_nf
    have e2 : thM N (x + ev N ν, μ) = (thS N x + ev N 0 + ev N ν, μ) := by
      rw [thM_spatial N _ hμ, thS_add, thS_ev N hν]; abel_nf
    have e3 : thM N (x, ν) = (thS N x + ev N 0, ν) := thM_spatial N x hν
    simp only [holQ, reflM, hμ, hν, if_false, ↓reduceIte]
    rw [e0, e1, e2, e3]

theorem sum_reflM (g : Lk N × Fin 4 → ℝ) :
    ∑ p ∈ plaqs N, g (thM N p.1, p.2) = ∑ p ∈ plaqs N, g p := by
  refine Finset.sum_nbij' (fun p => (thM N p.1, p.2)) (fun p => (thM N p.1, p.2)) ?_ ?_ ?_ ?_ ?_
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thM_snd]; exact hp
  · intro p hp
    simp only [plaqs, Finset.mem_filter, Finset.mem_univ, true_and] at hp ⊢
    rw [thM_snd]; exact hp
  · intro p _; exact Prod.ext (thM_invol N p.1) rfl
  · intro p _; exact Prod.ext (thM_invol N p.1) rfl
  · intro p _; rfl

/-- weight `1` on the plaquettes of the open positive side -/
noncomputable def wtM (p : Lk N × Fin 4) : ℝ :=
  if p.1.2 = 0 then (if 1 ≤ tm N p.1 ∧ tm N p.1 < M then 1 else 0)
  else (if 1 ≤ tm N p.1 ∧ tm N p.1 ≤ M then 1 else 0)

/-- indicator of the crossing plaquettes -/
noncomputable def crW (p : Lk N × Fin 4) : ℝ :=
  if p.1.2 = 0 ∧ (tm N p.1 = 0 ∨ tm N p.1 = M) then 1 else 0

theorem wtM_add (hN : N = 2 * M) (hM : 2 ≤ M) (ℓ : Lk N) (ν : Fin 4) :
    wtM N M (thM N ℓ, ν) + wtM N M (ℓ, ν) + crW N M (ℓ, ν) = 1 := by
  have hlt := tm_lt N ℓ
  simp only [wtM, crW, thM_snd]
  by_cases h2 : ℓ.2 = 0
  · rw [tm_thM_temporal N ℓ h2]
    simp only [h2, true_and, ↓reduceIte]
    split_ifs <;> first | omega | (norm_num; done) | simp_all | omega
  · rw [tm_thM_spatial N M hN (by omega) ℓ h2]
    simp only [h2, false_and, ↓reduceIte]
    split_ifs <;> first | omega | (norm_num; done) | simp_all | omega

/-- the action of the open positive side -/
noncomputable def actA (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, wtM N M p * (hol N ω p).re

/-- the action of the crossing plaquettes -/
noncomputable def actC (ω : Lk N → QBall) : ℝ := ∑ p ∈ plaqs N, crW N M p * (hol N ω p).re

theorem action_split_mid (hN : N = 2 * M) (hM : 2 ≤ M) (ω : Lk N → QBall) :
    action N ω = actA N M ω + actA N M (linkRefl (thM N) (sigT N) ω) + actC N M ω := by
  have h1 : ∀ p ∈ plaqs N,
      (hol N (linkRefl (thM N) (sigT N) ω) p).re = (hol N ω (thM N p.1, p.2)).re := by
    rintro ⟨⟨x, μ⟩, ν⟩ hp
    have hlt : μ < ν := by simpa [plaqs] using hp
    show (holQ N (Uq N (linkRefl (thM N) (sigT N) ω)) _).re = (holQ N (Uq N ω) _).re
    rw [Uq_reflM]
    exact holQ_reflM N _ x μ ν hlt
  have h2 : ∑ p ∈ plaqs N, wtM N M p * (hol N (linkRefl (thM N) (sigT N) ω) p).re
      = ∑ p ∈ plaqs N, wtM N M (thM N p.1, p.2) * (hol N ω p).re := by
    calc ∑ p ∈ plaqs N, wtM N M p * (hol N (linkRefl (thM N) (sigT N) ω) p).re
        = ∑ p ∈ plaqs N, wtM N M p * (hol N ω (thM N p.1, p.2)).re :=
          Finset.sum_congr rfl (fun p hp => by rw [h1 p hp])
      _ = ∑ p ∈ plaqs N, (fun q => wtM N M (thM N q.1, q.2) * (hol N ω q).re) (thM N p.1, p.2) :=
          Finset.sum_congr rfl (fun p _ => by simp only [thM_invol N p.1, Prod.mk.eta])
      _ = ∑ p ∈ plaqs N, wtM N M (thM N p.1, p.2) * (hol N ω p).re :=
          sum_reflM N (fun q => wtM N M (thM N q.1, q.2) * (hol N ω q).re)
  unfold actA actC
  rw [h2]
  unfold action
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl (fun p _ => ?_)
  have h := wtM_add N M hN hM p.1 p.2
  rw [Prod.mk.eta] at h
  linear_combination (-(hol N ω p).re) * h

end MidRP

#print axioms MidRP.holQ_reflM
#print axioms MidRP.wtM_add
#print axioms MidRP.action_split_mid
