import Lattice.MidActionV1

/-!
# (RP1) for the middle planes `x₀ = ½`, `x₀ = M + ½` (gauge-invariant functions, `β ≥ 0`)

Paper correspondence: `MidRP.wilson_rp_mid`: on `(ℤ/2M)⁴`,
`M ≥ 2`, for `β ≥ 0` and every bounded measurable gauge-invariant `F` of the closed positive half
of the middle planes (crossing temporal links, spatial links of time `1 … M`, temporal links of base
time `1 … M-1`): `0 ≤ ∫ F(ω) F(Θ′ω) dμ_W`, `Θ′` the reflection `x₀ ↦ 1 - x₀` with `star` on the
temporal links.  Chain: gauge fixing (`TorusGauge.wilson_gaugeFix`), action split
(`action_split_mid`), crossing plaquettes as a kernel `Σ ψ(ω)ψ(Θ′ω)` (`actC_setOne`), kernel
reflection positivity (`rp_kernel_mid`).
-/

namespace MidRP

open MeasureTheory TorusRP LinkReflection TorusGauge GaugeFix

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (M : ℕ)

/-- the four real coordinates of a quaternion -/
def coord (c : Fin 4) (q : ℍr) : ℝ := ![q.re, q.imI, q.imJ, q.imK] c

theorem re_mul_star_sum (V W : ℍr) : (V * star W).re = ∑ c : Fin 4, coord c V * coord c W := by
  rw [KernelPD.re_mul_star, Fin.sum_univ_four]
  rfl

theorem abs_coord_le (c : Fin 4) (q : ℍr) : |coord c q| ≤ ‖q‖ := by
  have h : |coord c q| ^ 2 ≤ ‖q‖ ^ 2 := by
    rw [sq_abs, sq ‖q‖, ← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
    fin_cases c <;> simp [coord] <;> nlinarith [sq_nonneg q.re, sq_nonneg q.imI, sq_nonneg q.imJ,
      sq_nonneg q.imK]
  exact (sq_le_sq₀ (abs_nonneg _) (norm_nonneg _)).1 h

theorem continuous_coord (c : Fin 4) : Continuous (coord c) := by
  fin_cases c
  · exact Quaternion.continuous_re
  · exact Quaternion.continuous_imI
  · exact Quaternion.continuous_imJ
  · exact Quaternion.continuous_imK

/-- the link of a crossing plaquette that lies on the positive side -/
def Lp (p : Lk N × Fin 4) : Lk N := if tm N p.1 = 0 then (p.1.1 + ev N 0, p.2) else (p.1.1, p.2)

/-- indicator of the crossing plaquettes -/
noncomputable def ind (p : Lk N × Fin 4) : ℝ := if p ∈ plaqs N then crW N M p else 0

/-- the kernel coordinates -/
noncomputable def psi (ω : Lk N → QBall) (j : (Lk N × Fin 4) × Fin 4) : ℝ :=
  ind N M j.1 * coord j.2 ((ω (Lp N j.1) : QBall) : ℍr)

theorem thS_fix (x : Site N) (h : -(x 0) = x 0) : thS N x = x := by
  funext i
  simp only [thS]
  split_ifs with hi
  · subst hi; exact h
  · rfl

theorem actC_setOne (hN : N = 2 * M) (hM : 2 ≤ M) (ω : Lk N → QBall) :
    actC N M (setOne (cr N M) ω)
      = ∑ j, psi N M ω j * psi N M (linkRefl (thM N) (sigM N M) ω) j := by
  unfold actC
  rw [Fintype.sum_prod_type]
  have hfil : (Finset.univ.filter (fun p : Lk N × Fin 4 => p ∈ plaqs N)) = plaqs N := by
    rw [Finset.filter_mem_eq_inter, Finset.univ_inter]
  rw [← hfil, Finset.sum_filter]
  refine Finset.sum_congr rfl fun p _ => ?_
  unfold psi ind
  by_cases hp : p ∈ plaqs N
  · rw [if_pos hp]
    simp only [if_pos hp]
    unfold crW
    by_cases hc : p.1.2 = 0 ∧ (tm N p.1 = 0 ∨ tm N p.1 = M)
    · rw [if_pos hc]
      obtain ⟨⟨x, μ⟩, ν⟩ := p
      obtain ⟨hμ, ht⟩ := hc
      simp only at hμ ht
      subst hμ
      have hlt : (0 : Fin 4) < ν := by simpa [plaqs] using hp
      have hν : ν ≠ 0 := ne_of_gt hlt
      have hcr1 : cr N M (x, 0) := (cr_iff N M hN (by omega) _).2 ⟨rfl, ht⟩
      have hcr2 : cr N M (x + ev N ν, 0) := by
        refine (cr_iff N M hN (by omega) _).2 ⟨rfl, ?_⟩
        show ((x + ev N ν) 0).val = 0 ∨ ((x + ev N ν) 0).val = M
        rw [add_ev_zero N x hν]; exact ht
      have hn1 : ¬ cr N M (x + ev N 0, ν) := fun h => hν h.1
      have hn2 : ¬ cr N M (x, ν) := fun h => hν h.1
      have hhol : (hol N (setOne (cr N M) ω) ((x, 0), ν)).re
          = ((ω (x + ev N 0, ν) : QBall) * star ((ω (x, ν) : QBall) : ℍr)).re := by
        show (holQ N (Uq N (setOne (cr N M) ω)) ((x, 0), ν)).re = _
        simp only [holQ, Uq, setOne, if_pos hcr1, if_pos hcr2, if_neg hn1, if_neg hn2]
        show ((1 : ℍr) * _ * star (1 : ℍr) * _).re = _
        rw [star_one, one_mul, mul_one]
      rw [hhol, re_mul_star_sum, one_mul]
      apply Finset.sum_congr rfl
      intro c _
      have hx0 : -(x 0) = x 0 := by
        rcases ht with h | h
        · have h0' : x 0 = 0 := (ZMod.val_eq_zero _).1 h
          rw [h0', neg_zero]
        · have h1 : (x 0).val = M := h
          have h' : x 0 = (M : ZMod N) := by
            rw [← ZMod.natCast_zmod_val (x 0), h1]
          have hNM : ((2 * M : ℕ) : ZMod N) = 0 := by rw [← hN, ZMod.natCast_self]
          rw [Nat.cast_mul, Nat.cast_ofNat] at hNM
          rw [h']; linear_combination -hNM
      have hth : thS N x = x := thS_fix N x hx0
      by_cases h0 : tm N (x, 0) = 0
      · have eL : Lp N ((x, 0), ν) = (x + ev N 0, ν) := by
          unfold Lp; rw [if_pos h0]
        have eR : linkRefl (thM N) (sigM N M) ω (x + ev N 0, ν) = ω (x, ν) := by
          unfold linkRefl sigM
          rw [if_neg (fun h => hν h.1), thM_spatial N _ hν, thS_add, thS_ev0, hth,
            neg_add_cancel_right]
          rfl
        rw [eL, eR]
        ring
      · have eL : Lp N ((x, 0), ν) = (x, ν) := by
          unfold Lp; rw [if_neg h0]
        have eR : linkRefl (thM N) (sigM N M) ω (x, ν) = ω (x + ev N 0, ν) := by
          unfold linkRefl sigM
          rw [if_neg (fun h => hν h.1), thM_spatial N _ hν, hth]
          rfl
        rw [eL, eR]
        ring
    · rw [if_neg hc]
      simp
  · simp [hp]

theorem posM_spatial (z : Site N) (κ : Fin 4) (hκ : κ ≠ 0) (h1 : 1 ≤ (z 0).val) (h2 : (z 0).val ≤ M) :
    posM N M (z, κ) := by
  show if κ = 0 then 1 ≤ (z 0).val ∧ (z 0).val < M else 1 ≤ (z 0).val ∧ (z 0).val ≤ M
  rw [if_neg hκ]; exact ⟨h1, h2⟩

theorem posM_temporal (z : Site N) (h1 : 1 ≤ (z 0).val) (h2 : (z 0).val < M) :
    posM N M (z, 0) := by
  show if (0 : Fin 4) = 0 then 1 ≤ (z 0).val ∧ (z 0).val < M else 1 ≤ (z 0).val ∧ (z 0).val ≤ M
  rw [if_pos rfl]; exact ⟨h1, h2⟩

/-- `A` depends only on the closed positive half -/
theorem actA_dep (hN : N = 2 * M) (hM : 2 ≤ M) (ω ω' : Lk N → QBall)
    (h : ∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) : actA N M ω = actA N M ω' := by
  unfold actA
  refine Finset.sum_congr rfl (fun p hp => ?_)
  obtain ⟨⟨x, μ⟩, ν⟩ := p
  have hlt : μ < ν := by simpa [plaqs] using hp
  have hν : ν ≠ 0 := by rintro rfl; simp at hlt
  have hv := ZMod.val_lt (x 0)
  have hall : ∀ ℓ, posM N M ℓ → ((ω ℓ : QBall) : ℍr) = ((ω' ℓ : QBall) : ℍr) :=
    fun ℓ h' => by rw [h ℓ (Or.inr h')]
  by_cases hw : wtM N M ((x, μ), ν) = 0
  · rw [hw, zero_mul, zero_mul]
  · congr 1
    show (holQ N (Uq N ω) ((x, μ), ν)).re = (holQ N (Uq N ω') ((x, μ), ν)).re
    simp only [holQ, Uq]
    by_cases hμ : μ = 0
    · subst hμ
      have ht : 1 ≤ (x 0).val ∧ (x 0).val < M := by
        by_contra hc
        apply hw
        simp only [wtM, if_true]
        rw [if_neg (show ¬ (1 ≤ tm N (x, 0) ∧ tm N (x, 0) < M) from hc)]
      rw [hall (x, 0) (posM_temporal N M x ht.1 ht.2),
        hall (x + ev N 0, ν) (posM_spatial N M (x + ev N 0) ν hν
          (by rw [add_ev0_val N x (by omega)]; omega) (by rw [add_ev0_val N x (by omega)]; omega)),
        hall (x + ev N ν, 0) (posM_temporal N M (x + ev N ν) (by rw [add_ev_zero N x hν]; exact ht.1)
          (by rw [add_ev_zero N x hν]; exact ht.2)),
        hall (x, ν) (posM_spatial N M x ν hν ht.1 (by omega))]
    · have ht : 1 ≤ (x 0).val ∧ (x 0).val ≤ M := by
        by_contra hc
        apply hw
        simp only [wtM]
        rw [if_neg hμ, if_neg (show ¬ (1 ≤ tm N (x, μ) ∧ tm N (x, μ) ≤ M) from hc)]
      rw [hall (x, μ) (posM_spatial N M x μ hμ ht.1 ht.2),
        hall (x + ev N μ, ν) (posM_spatial N M (x + ev N μ) ν hν (by rw [add_ev_zero N x hμ]; exact ht.1)
          (by rw [add_ev_zero N x hμ]; exact ht.2)),
        hall (x + ev N ν, μ) (posM_spatial N M (x + ev N ν) μ hμ (by rw [add_ev_zero N x hν]; exact ht.1)
          (by rw [add_ev_zero N x hν]; exact ht.2)),
        hall (x, ν) (posM_spatial N M x ν hν ht.1 ht.2)]

theorem abs_actA (ω : Lk N → QBall) : |actA N M ω| ≤ (plaqs N).card := by
  unfold actA
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  calc ∑ p ∈ plaqs N, |wtM N M p * (hol N ω p).re| ≤ ∑ _p ∈ plaqs N, (1 : ℝ) :=
        Finset.sum_le_sum (fun p _ => by
          rw [abs_mul]
          have h1 : |wtM N M p| ≤ 1 := by unfold wtM; split_ifs <;> norm_num
          exact mul_le_one₀ h1 (abs_nonneg _) (abs_hol_re N ω p))
    _ = (plaqs N).card := by simp

theorem continuous_actA : Continuous (actA N M) := by
  unfold actA
  exact continuous_finset_sum _ fun p _ =>
    continuous_const.mul (Quaternion.continuous_re.comp (continuous_hol N p))

theorem psi_dep (hN : N = 2 * M) (hM : 2 ≤ M) (ω ω' : Lk N → QBall)
    (h : ∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) : psi N M ω = psi N M ω' := by
  funext j
  unfold psi
  by_cases hi : ind N M j.1 = 0
  · rw [hi, zero_mul, zero_mul]
  · obtain ⟨⟨⟨x, μ⟩, ν⟩, c⟩ := j
    simp only at hi ⊢
    unfold ind at hi
    by_cases hp : ((x, μ), ν) ∈ plaqs N
    · rw [if_pos hp] at hi
      have hlt : μ < ν := by simpa [plaqs] using hp
      have hν : ν ≠ 0 := by rintro rfl; simp at hlt
      unfold crW at hi
      by_cases hc : μ = 0 ∧ (tm N (x, μ) = 0 ∨ tm N (x, μ) = M)
      · obtain ⟨-, ht⟩ := hc
        have hv := ZMod.val_lt (x 0)
        have hL : posM N M (Lp N ((x, μ), ν)) := by
          unfold Lp
          split_ifs with h0
          · have h0' : (x 0).val = 0 := h0
            exact posM_spatial N M _ ν hν (by rw [add_ev0_val N x (by omega)]; omega)
              (by rw [add_ev0_val N x (by omega)]; omega)
          · have hM' : (x 0).val = M := by
              rcases ht with h' | h'
              · exact absurd h' h0
              · exact h'
            exact posM_spatial N M x ν hν (by omega) (by omega)
        rw [h _ (Or.inr hL)]
      · rw [if_neg hc] at hi; exact absurd rfl hi
    · rw [if_neg hp] at hi; exact absurd rfl hi

theorem abs_psi (ω : Lk N → QBall) (j : (Lk N × Fin 4) × Fin 4) : |psi N M ω j| ≤ 1 := by
  unfold psi
  rw [abs_mul]
  have h1 : |ind N M j.1| ≤ 1 := by unfold ind crW; split_ifs <;> norm_num
  have h2 : |coord j.2 ((ω (Lp N j.1) : QBall) : ℍr)| ≤ 1 :=
    (abs_coord_le _ _).trans (mem_closedBall_zero_iff.1 (ω (Lp N j.1)).2)
  exact mul_le_one₀ h1 (abs_nonneg _) h2

theorem continuous_psi (j : (Lk N × Fin 4) × Fin 4) : Continuous (fun ω : Lk N → QBall => psi N M ω j) :=
  continuous_const.mul ((continuous_coord j.2).comp (continuous_subtype_val.comp (continuous_apply _)))

theorem measurable_linkRefl_T : Measurable (linkRefl (thM N) (sigT N)) := by
  refine measurable_pi_lambda _ fun ℓ => ?_
  unfold linkRefl sigT
  split_ifs
  · exact continuous_starB.measurable.comp (measurable_pi_apply _)
  · exact measurable_pi_apply _

/-- **(RP1) for the middle planes.** -/
theorem wilson_rp_mid (hN : N = 2 * M) (hM : 2 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (F : (Lk N → QBall) → ℝ) (hF : Measurable F) (CF : ℝ) (hFb : ∀ ω, |F ω| ≤ CF)
    (hFdep : ∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω')
    (hinv : ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : ℍr)‖ = 1) → ∀ ω,
      F (act (src N) (tgt N) g ω) = F ω) :
    0 ≤ ∫ ω, F ω * F (linkRefl (thM N) (sigT N) ω) ∂(wilsonMeasure N β) := by
  have hH := wilson_gaugeFix N M hN hM β (fun ω => F ω * F (linkRefl (thM N) (sigT N) ω))
    (hF.mul (hF.comp (measurable_linkRefl_T N)))
    (fun g hg ω => by
      show F (act (src N) (tgt N) g ω) * F (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω))
        = F ω * F (linkRefl (thM N) (sigT N) ω)
      rw [hinv g hg ω, gauge_inv_refl N F hinv g hg ω])
  rw [hH]
  set e := Fintype.equivFin ((Lk N × Fin 4) × Fin 4) with he
  set gg : (Lk N → QBall) → ℝ := fun ω =>
    F (setOne (cr N M) ω) * Real.exp (β * actA N M (setOne (cr N M) ω)) with hgg
  set ps : (Lk N → QBall) → Fin (Fintype.card ((Lk N × Fin 4) × Fin 4)) → ℝ :=
    fun ω j => psi N M ω (e.symm j) with hps
  have key : ∀ ω, F (setOne (cr N M) ω) * F (linkRefl (thM N) (sigT N) (setOne (cr N M) ω)) *
      wilsonWeight N β (setOne (cr N M) ω)
      = gg ω * gg (linkRefl (thM N) (sigM N M) ω) *
        Real.exp (β * ∑ j, ps ω j * ps (linkRefl (thM N) (sigM N M) ω) j) := by
    intro ω
    have hT : linkRefl (thM N) (sigT N) (setOne (cr N M) ω)
        = setOne (cr N M) (linkRefl (thM N) (sigM N M) ω) := by
      rw [linkRefl_true_eq N M hN (by omega), setOne_linkRefl N M hN (by omega)]
    have hsum : ∑ j, ps ω j * ps (linkRefl (thM N) (sigM N M) ω) j
        = actC N M (setOne (cr N M) ω) := by
      rw [actC_setOne N M hN hM]
      exact Equiv.sum_comp e.symm (fun j => psi N M ω j * psi N M (linkRefl (thM N) (sigM N M) ω) j)
    have hw : wilsonWeight N β (setOne (cr N M) ω)
        = Real.exp (β * actA N M (setOne (cr N M) ω)) *
          Real.exp (β * actA N M (setOne (cr N M) (linkRefl (thM N) (sigM N M) ω))) *
          Real.exp (β * actC N M (setOne (cr N M) ω)) := by
      unfold wilsonWeight
      rw [action_split_mid N M hN hM, hT, ← Real.exp_add, ← Real.exp_add]
      congr 1; ring
    rw [hT, hw, hsum]
    simp only [hgg]
    ring
  have hint := integral_congr_ae (μ := Measure.pi fun _ : Lk N => haarBall)
    (Filter.Eventually.of_forall key)
  rw [hint]
  have hggm : Measurable gg :=
    (hF.comp (measurable_setOne (cr N M))).mul (Real.continuous_exp.measurable.comp
      (measurable_const.mul ((continuous_actA N M).measurable.comp (measurable_setOne (cr N M)))))
  have hggb : ∀ ω, |gg ω| ≤ CF * Real.exp (|β| * (plaqs N).card) := by
    intro ω
    simp only [hgg]
    rw [abs_mul, abs_of_pos (Real.exp_pos _)]
    have hCF : 0 ≤ CF := (abs_nonneg _).trans (hFb ω)
    refine mul_le_mul (hFb _) (Real.exp_le_exp.2 ?_) (Real.exp_pos _).le hCF
    have := abs_actA N M (setOne (cr N M) ω)
    calc β * actA N M (setOne (cr N M) ω) ≤ |β * actA N M (setOne (cr N M) ω)| := le_abs_self _
      _ = |β| * |actA N M (setOne (cr N M) ω)| := abs_mul _ _
      _ ≤ |β| * (plaqs N).card := mul_le_mul_of_nonneg_left this (abs_nonneg _)
  have hsetdep : ∀ ω ω' : Lk N → QBall, (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) →
      ∀ ℓ, cr N M ℓ ∨ posM N M ℓ → setOne (cr N M) ω ℓ = setOne (cr N M) ω' ℓ := by
    intro ω ω' h ℓ hℓ
    unfold setOne
    split_ifs
    · rfl
    · exact h ℓ hℓ
  have hggdep : ∀ ω ω', (∀ ℓ, cr N M ℓ ∨ posM N M ℓ → ω ℓ = ω' ℓ) → gg ω = gg ω' := by
    intro ω ω' h
    simp only [hgg]
    rw [hFdep _ _ (hsetdep ω ω' h), actA_dep N M hN hM _ _ (hsetdep ω ω' h)]
  exact rp_kernel_mid N M hN hM gg hggm _ hggb hggdep ps
    (fun j => continuous_psi N M (e.symm j) |>.measurable) 1 (fun ω j => abs_psi N M ω _)
    (fun ω ω' h => by simp only [hps]; rw [psi_dep N M hN hM ω ω' h]) β hβ

end MidRP

#print axioms MidRP.actC_setOne
#print axioms MidRP.actA_dep
#print axioms MidRP.psi_dep
#print axioms MidRP.wilson_rp_mid
