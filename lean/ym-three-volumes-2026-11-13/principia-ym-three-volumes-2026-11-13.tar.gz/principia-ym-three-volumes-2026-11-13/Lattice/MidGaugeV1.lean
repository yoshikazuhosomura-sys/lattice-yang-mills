import Lattice.MidSetOneV1

/-!
# Gauge covariance of the middle-plane reflection

`MidRP.linkRefl_act` : `Θ′(g·ω) = (g∘Θ′_s)·(Θ′ω)` with `Θ′_s x = Θx + e₀` (the site map
`x₀ ↦ 1 - x₀`) and `star` on all temporal links (`sigT`).  Hence `F ∘ Θ′` is gauge invariant
when `F` is (`gauge_inv_refl`).
-/

namespace MidRP

open MeasureTheory TorusRP LinkReflection TorusGauge GaugeFix

variable (N : ℕ) [NeZero N]

/-- the site map of the middle-plane reflection -/
def thSM (x : Site N) : Site N := thS N x + ev N 0

theorem linkRefl_act (g : Site N → QBall) (ω : Lk N → QBall) :
    linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω)
      = act (src N) (tgt N) (fun x => g (thSM N x)) (linkRefl (thM N) (sigT N) ω) := by
  funext ℓ
  obtain ⟨x, μ⟩ := ℓ
  apply Subtype.ext
  by_cases h : μ = 0
  · subst h
    have e1 : thM N (x, 0) = (thS N x, 0) := by
      simp only [thM, shL, thL, if_true, sub_add_cancel]
    have e2 : thSM N (x + ev N 0) = thS N x := by
      simp only [thSM, thS_add, thS_ev0, neg_add_cancel_right]
    show ((sigT N (x, 0) (act (src N) (tgt N) g ω (thM N (x, 0))) : QBall) : Quaternion ℝ)
      = ((g (thSM N x) : QBall) : Quaternion ℝ) *
          ((sigT N (x, 0) (ω (thM N (x, 0))) : QBall) : Quaternion ℝ) *
          star ((g (thSM N (x + ev N 0)) : QBall) : Quaternion ℝ)
    rw [e1, e2]
    simp only [sigT, if_true, act, src, tgt]
    show star (((g (thS N x) : QBall) : Quaternion ℝ) * ((ω (thS N x, 0) : QBall) : Quaternion ℝ) *
        star ((g (thS N x + ev N 0) : QBall) : Quaternion ℝ))
      = ((g (thSM N x) : QBall) : Quaternion ℝ) * star ((ω (thS N x, 0) : QBall) : Quaternion ℝ) *
          star ((g (thS N x) : QBall) : Quaternion ℝ)
    simp only [thSM, star_mul, star_star, mul_assoc]
  · have e1 : thM N (x, μ) = (thS N x + ev N 0, μ) := by
      simp only [thM, shL, thL, h, if_false]
    have e2 : thSM N (x + ev N μ) = thS N x + ev N 0 + ev N μ := by
      simp only [thSM, thS_add, thS_ev N h]
      abel
    show ((sigT N (x, μ) (act (src N) (tgt N) g ω (thM N (x, μ))) : QBall) : Quaternion ℝ)
      = ((g (thSM N x) : QBall) : Quaternion ℝ) *
          ((sigT N (x, μ) (ω (thM N (x, μ))) : QBall) : Quaternion ℝ) *
          star ((g (thSM N (x + ev N μ)) : QBall) : Quaternion ℝ)
    rw [e1, e2]
    simp only [sigT, h, if_false, id, act, src, tgt]
    rfl

/-- `F ∘ Θ′` is gauge invariant when `F` is -/
theorem gauge_inv_refl (F : (Lk N → QBall) → ℝ)
    (hinv : ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : Quaternion ℝ)‖ = 1) → ∀ ω,
      F (act (src N) (tgt N) g ω) = F ω) :
    ∀ g : Site N → QBall, (∀ x, ‖((g x : QBall) : Quaternion ℝ)‖ = 1) → ∀ ω,
      F (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω)) = F (linkRefl (thM N) (sigT N) ω) := by
  intro g hg ω
  rw [linkRefl_act]
  exact hinv _ (fun x => hg _) _

end MidRP

#print axioms MidRP.linkRefl_act
#print axioms MidRP.gauge_inv_refl
