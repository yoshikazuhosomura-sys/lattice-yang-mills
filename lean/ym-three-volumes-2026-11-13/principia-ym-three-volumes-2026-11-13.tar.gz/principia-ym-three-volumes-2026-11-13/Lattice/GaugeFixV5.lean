import Lattice.GaugeSectorV1

/-!
# Gauge fixing of a set of links pointing into distinct sites (abstract; step 1 of the
# link-plane reflection positivity)

Paper correspondence: and 
Links `ι` with source/target sites `src`, `tgt`; a decidable set `cr` of links ("crossing") such
that each site `x` with `hasIn x` receives exactly the crossing link `k x`, and no crossing link
starts at such a site.  For `H` invariant under all gauge transformations with unit values,
`∫ H dHaar^ι = ∫ H(ω with the crossing links set to 1) dHaar^ι` (`integral_gaugeFix`).
The change of variables is the skew product (crossing values, rest) ↦ (crossing values,
`g(ω_cr) · rest`), measure preserving by the left/right invariance of the Haar measure of SU(2).
-/

namespace GaugeFix

open MeasureTheory TorusRP OSGap

local notation "ℍr" => Quaternion ℝ

/-- `a U b*` for `a, b, U` in the closed unit ball -/
noncomputable def mulB (a b U : QBall) : QBall :=
  ⟨(a : ℍr) * (U : ℍr) * star (b : ℍr), by
    rw [mem_closedBall_zero_iff, norm_mul, norm_mul, norm_star]
    have ha := mem_closedBall_zero_iff.1 a.2
    have hb := mem_closedBall_zero_iff.1 b.2
    have hU := mem_closedBall_zero_iff.1 U.2
    calc ‖(a : ℍr)‖ * ‖(U : ℍr)‖ * ‖(b : ℍr)‖ ≤ 1 * 1 * 1 := by gcongr
      _ = 1 := by norm_num⟩

theorem continuous_mulB : Continuous (fun p : QBall × QBall × QBall => mulB p.1 p.2.1 p.2.2) := by
  unfold mulB
  refine Continuous.subtype_mk ?_ _
  have c1 : Continuous (fun p : QBall × QBall × QBall => (p.1 : ℍr)) :=
    continuous_subtype_val.comp continuous_fst
  have c2 : Continuous (fun p : QBall × QBall × QBall => (p.2.1 : ℍr)) :=
    continuous_subtype_val.comp (continuous_fst.comp continuous_snd)
  have c3 : Continuous (fun p : QBall × QBall × QBall => (p.2.2 : ℍr)) :=
    continuous_subtype_val.comp (continuous_snd.comp continuous_snd)
  exact (c1.mul c3).mul (continuous_star.comp c2)

theorem continuous_mulB' {X : Type*} [TopologicalSpace X] {f g h : X → QBall} (hf : Continuous f)
    (hg : Continuous g) (hh : Continuous h) : Continuous (fun x => mulB (f x) (g x) (h x)) := by
  unfold mulB
  refine Continuous.subtype_mk ?_ _
  exact ((continuous_subtype_val.comp hf).mul (continuous_subtype_val.comp hh)).mul
    (continuous_star.comp (continuous_subtype_val.comp hg))

/-- the unit `1` of the ball -/
noncomputable def oneB : QBall := ⟨1, by rw [mem_closedBall_zero_iff, norm_one]⟩

/-- left/right multiplication by unit quaternions preserves the Haar measure of the ball -/
theorem mulB_preserving (a b : QBall) (ha : ‖(a : ℍr)‖ = 1) (hb : ‖(b : ℍr)‖ = 1) :
    MeasurePreserving (mulB a b) haarBall haarBall := by
  have hm : Measurable (mulB a b) :=
    (continuous_mulB.comp (continuous_const.prodMk (continuous_const.prodMk continuous_id))).measurable
  refine ⟨hm, ?_⟩
  set A : SU2 := ⟨a, mem_sphere_zero_iff_norm.2 ha⟩
  set B : SU2 := ⟨b, mem_sphere_zero_iff_norm.2 hb⟩
  have hc : mulB a b ∘ incl = incl ∘ (fun q : SU2 => A * q * B⁻¹) := by
    funext q
    apply Subtype.ext
    show (a : ℍr) * (q : ℍr) * star (b : ℍr) = ((A * q * B⁻¹ : SU2) : ℍr)
    have hBinv : ((B⁻¹ : SU2) : ℍr) = star (b : ℍr) := by
      rw [Metric.unitSphere.coe_inv]
      have h1 : (b : ℍr) * star (b : ℍr) = 1 := by
        rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hb]
        simp
      exact inv_eq_of_mul_eq_one_right h1
    rw [show ((A * q * B⁻¹ : SU2) : ℍr) = (A : ℍr) * (q : ℍr) * ((B⁻¹ : SU2) : ℍr) from rfl, hBinv]
  have hf : Measurable (fun q : SU2 => A * q * B⁻¹) :=
    ((continuous_mul_right B⁻¹).comp (continuous_mul_left A)).measurable
  unfold haarBall
  rw [Measure.map_map hm continuous_incl.measurable, hc,
    ← Measure.map_map continuous_incl.measurable hf]
  congr 1
  have e : (fun q : SU2 => A * q * B⁻¹) = (· * B⁻¹) ∘ (A * ·) := rfl
  rw [e, ← Measure.map_map (continuous_mul_right B⁻¹).measurable (continuous_mul_left A).measurable,
    map_mul_left_eq_self]
  rw [show haarProb SU2 = Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2) from rfl]
  haveI : IsProbabilityMeasure (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2)) :=
    haarProb_isProbabilityMeasure SU2
  exact CompactHaar.map_mul_right_eq _ B⁻¹

/-- almost every configuration has unit values -/
theorem ae_unit_pi (J : Type*) [Fintype J] :
    ∀ᵐ a ∂(Measure.pi fun _ : J => haarBall), ∀ j, ‖((a j : QBall) : ℍr)‖ = 1 := by
  rw [ae_all_iff]
  intro j
  have hm : MeasurableSet {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ :=
    ((isClosed_eq (continuous_norm.comp continuous_subtype_val) continuous_const).measurableSet).compl
  have hs : haarBall {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ = 0 := by
    rw [haarBall, Measure.map_apply continuous_incl.measurable hm]
    have : incl ⁻¹' {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ = ∅ := by
      ext q
      simp only [Set.mem_preimage, Set.mem_compl_iff, Set.mem_setOf_eq, Set.mem_empty_iff_false,
        iff_false, not_not]
      exact GaugeZ.unit_norm q
    rw [this, measure_empty]
  have := Measure.pi_eval_preimage_null (fun _ : J => haarBall) (i := j) hs
  rw [ae_iff]
  exact this

theorem oneB_norm : ‖((oneB : QBall) : ℍr)‖ = 1 := by
  show ‖(1 : ℍr)‖ = 1
  exact norm_one

section Fix

variable {ι S : Type*} [Fintype ι] [DecidableEq ι] (src tgt : ι → S)

/-- the gauge action with ball-valued `g` (a gauge transformation when `g` has unit values) -/
noncomputable def act (g : S → QBall) (ω : ι → QBall) : ι → QBall :=
  fun ℓ => mulB (g (src ℓ)) (g (tgt ℓ)) (ω ℓ)

variable (cr : ι → Prop) [DecidablePred cr] (hasIn : S → Prop) [DecidablePred hasIn] (k : S → ι)

/-- the gauge transformation read off a configuration -/
noncomputable def gOf (ω : ι → QBall) (x : S) : QBall := if hasIn x then ω (k x) else oneB

/-- the same, from the crossing values only -/
noncomputable def gSub (hk : ∀ x, hasIn x → cr (k x)) (a : {i // cr i} → QBall) (x : S) : QBall :=
  if h : hasIn x then a ⟨k x, hk x h⟩ else oneB

/-- the fibre map of the skew product -/
noncomputable def fiber (hk : ∀ x, hasIn x → cr (k x)) (a : {i // cr i} → QBall)
    (b : {i // ¬ cr i} → QBall) : {i // ¬ cr i} → QBall :=
  fun j => mulB (gSub cr hasIn k hk a (src j.1)) (gSub cr hasIn k hk a (tgt j.1)) (b j)

/-- the change of variables: crossing values kept, the others gauge transformed -/
noncomputable def Φ (ω : ι → QBall) : ι → QBall :=
  fun ℓ => if cr ℓ then ω ℓ else mulB (gOf hasIn k ω (src ℓ)) (gOf hasIn k ω (tgt ℓ)) (ω ℓ)

/-- set the crossing links to `1` -/
noncomputable def setOne (ω : ι → QBall) : ι → QBall := fun ℓ => if cr ℓ then oneB else ω ℓ

theorem measurable_setOne : Measurable (setOne cr) := by
  refine measurable_pi_lambda _ fun ℓ => ?_
  unfold setOne
  split_ifs
  · exact measurable_const
  · exact measurable_pi_apply ℓ

theorem Φ_preserving (hk : ∀ x, hasIn x → cr (k x)) :
    MeasurePreserving (Φ src tgt cr hasIn k) (Measure.pi fun _ : ι => haarBall)
      (Measure.pi fun _ : ι => haarBall) := by
  have he_mp := measurePreserving_piEquivPiSubtypeProd (fun _ : ι => haarBall) cr
  have hG : ∀ x, Continuous (fun a : {i // cr i} → QBall => gSub cr hasIn k hk a x) := by
    intro x
    unfold gSub
    split_ifs with h
    · exact continuous_apply _
    · exact continuous_const
  have hgc : Continuous (Function.uncurry (fiber src tgt cr hasIn k hk)) := by
    refine continuous_pi fun j => ?_
    show Continuous (fun p : ({i // cr i} → QBall) × ({i // ¬ cr i} → QBall) =>
      mulB (gSub cr hasIn k hk p.1 (src j.1)) (gSub cr hasIn k hk p.1 (tgt j.1)) (p.2 j))
    exact continuous_mulB' ((hG _).comp continuous_fst) ((hG _).comp continuous_fst)
      ((continuous_apply j).comp continuous_snd)
  have hgm : Measurable (Function.uncurry (fiber src tgt cr hasIn k hk)) := hgc.measurable
  have hgu : ∀ a : {i // cr i} → QBall, (∀ c, ‖((a c : QBall) : ℍr)‖ = 1) →
      ∀ x, ‖((gSub cr hasIn k hk a x : QBall) : ℍr)‖ = 1 := by
    intro a ha x
    unfold gSub
    split_ifs
    · exact ha _
    · exact oneB_norm
  have hg : ∀ᵐ a ∂(Measure.pi fun _ : {i // cr i} => haarBall),
      Measure.map (fiber src tgt cr hasIn k hk a) (Measure.pi fun _ : {i // ¬ cr i} => haarBall)
        = Measure.pi fun _ : {i // ¬ cr i} => haarBall := by
    filter_upwards [ae_unit_pi {i // cr i}] with a ha
    exact (measurePreserving_pi (fun _ : {i // ¬ cr i} => haarBall) (fun _ => haarBall)
      (fun j => mulB_preserving _ _ (hgu a ha _) (hgu a ha _))).map_eq
  have hΨ := MeasurePreserving.skew_product
    (MeasurePreserving.id (Measure.pi fun _ : {i // cr i} => haarBall)) hgm hg
  have hcomp := (he_mp.symm _).comp (hΨ.comp he_mp)
  convert hcomp using 1
  funext ω ℓ
  show _ = (Equiv.piEquivPiSubtypeProd cr (fun _ : ι => QBall)).symm
    ((fun i => ω i.1), fiber src tgt cr hasIn k hk (fun i => ω i.1) (fun i => ω i.1)) ℓ
  rw [Equiv.piEquivPiSubtypeProd_symm_apply]
  unfold Φ
  by_cases h : cr ℓ
  · rw [if_pos h, dif_pos h]
  · rw [if_neg h, dif_neg h]
    show mulB (gOf hasIn k ω (src ℓ)) (gOf hasIn k ω (tgt ℓ)) (ω ℓ)
      = mulB (gSub cr hasIn k hk (fun i => ω i.1) (src ℓ)) (gSub cr hasIn k hk (fun i => ω i.1) (tgt ℓ))
          (ω ℓ)
    have e1 : ∀ x, gSub cr hasIn k hk (fun i => ω i.1) x = gOf hasIn k ω x := fun x => by
      unfold gSub gOf
      split_ifs <;> rfl
    rw [e1, e1]

/-- **Gauge fixing.** -/
theorem integral_gaugeFix
    (hk1 : ∀ x, hasIn x → cr (k x) ∧ tgt (k x) = x)
    (hk2 : ∀ c, cr c → hasIn (tgt c) ∧ k (tgt c) = c)
    (hk3 : ∀ c, cr c → ¬ hasIn (src c))
    (H : (ι → QBall) → ℝ) (hH : Measurable H)
    (hinv : ∀ g : S → QBall, (∀ x, ‖((g x : QBall) : ℍr)‖ = 1) → ∀ ω, H (act src tgt g ω) = H ω) :
    ∫ ω, H ω ∂(Measure.pi fun _ : ι => haarBall)
      = ∫ ω, H (setOne cr ω) ∂(Measure.pi fun _ : ι => haarBall) := by
  have hk : ∀ x, hasIn x → cr (k x) := fun x h => (hk1 x h).1
  have hΦ := Φ_preserving src tgt cr hasIn k hk
  have hgu : ∀ ω : ι → QBall, (∀ ℓ, ‖((ω ℓ : QBall) : ℍr)‖ = 1) →
      ∀ x, ‖((gOf hasIn k ω x : QBall) : ℍr)‖ = 1 := by
    intro ω hω x
    unfold gOf
    split_ifs
    · exact hω _
    · exact oneB_norm
  have step1 : ∫ ω, H ω ∂(Measure.pi fun _ : ι => haarBall)
      = ∫ ω, H (act src tgt (gOf hasIn k ω) ω) ∂(Measure.pi fun _ : ι => haarBall) := by
    refine integral_congr_ae ?_
    filter_upwards [ae_unit_pi ι] with ω hω
    exact (hinv _ (hgu ω hω) ω).symm
  have step2 : ∫ ω, H (act src tgt (gOf hasIn k ω) ω) ∂(Measure.pi fun _ : ι => haarBall)
      = ∫ ω, H (setOne cr (Φ src tgt cr hasIn k ω)) ∂(Measure.pi fun _ : ι => haarBall) := by
    refine integral_congr_ae ?_
    filter_upwards [ae_unit_pi ι] with ω hω
    congr 1
    funext ℓ
    unfold act setOne Φ
    by_cases h : cr ℓ
    · rw [if_pos h]
      obtain ⟨h1, h2⟩ := hk2 ℓ h
      have hs : gOf hasIn k ω (src ℓ) = oneB := by unfold gOf; rw [if_neg (hk3 ℓ h)]
      have ht : gOf hasIn k ω (tgt ℓ) = ω ℓ := by unfold gOf; rw [if_pos h1, h2]
      rw [hs, ht]
      apply Subtype.ext
      show (1 : ℍr) * (ω ℓ : ℍr) * star (ω ℓ : ℍr) = 1
      rw [one_mul, Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self, hω ℓ]
      simp
    · rw [if_neg h, if_neg h]
  rw [step1, step2]
  have hm : AEStronglyMeasurable (fun ω => H (setOne cr ω))
      (Measure.map (Φ src tgt cr hasIn k) (Measure.pi fun _ : ι => haarBall)) := by
    rw [hΦ.map_eq]
    exact (hH.comp (measurable_setOne cr)).aestronglyMeasurable
  have := integral_map hΦ.measurable.aemeasurable hm
  rw [hΦ.map_eq] at this
  exact this.symm

end Fix

end GaugeFix

#print axioms GaugeFix.mulB_preserving
#print axioms GaugeFix.Φ_preserving
#print axioms GaugeFix.integral_gaugeFix
