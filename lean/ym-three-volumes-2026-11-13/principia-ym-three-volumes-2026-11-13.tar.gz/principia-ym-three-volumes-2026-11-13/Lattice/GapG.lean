import Mathlib

/-!
# Mass gap of the reconstructed transfer operator from decay of reflected correlations

Row 10 of the roadmap table (confinement and mass gap): the vessel in which "mass gap" is stated,
and the arrow "decay of truncated reflected correlations ⇒ gap of the transfer operator".

Paper correspondence: textbook 4-10 (Osterwalder–Schrader reconstruction), 4-11 §02
(mass gap ⇔ uniform exponential decay of connected correlations), 14-01 arrows G1/G2
(the transfer-operator step).

* `OrbitGrowth.*` : the algebraic core (orbit growth of a symmetric map on a semi-inner-product
  space bounds one step).  No topology, no spectral theorem.
* `OSGap.Datum` : pre-Hilbert reconstruction datum `(V, B, τ, one)`:
  `V` positive-time observables, `B F G = ⟨ΘF · G⟩` the reflected pairing (positive
  semidefinite, symmetric), `τ` the shift by one time step (symmetric for `B`, bounded orbits),
  `one` the constant observable.
* `OSGap.Datum.Hilb`, `OSGap.Datum.T`, `OSGap.Datum.Ω` : the completed Hilbert space, the
  transfer operator (a bounded operator, obtained from `τ` by completion) and the vacuum vector.
* `OSGap.Datum.HasMassGap D m` : `‖T - P_Ω‖ ≤ e^{-m}` where `P_Ω v = ⟪Ω, v⟫ Ω`
  (one time step is the unit; `m` is the gap in lattice units of that step).
* `OSGap.Datum.hasMassGap_of_decay` : if for every observable `x` the truncated reflected
  correlation decays, `B (τ^k x) (τ^k x) - (B one x)^2 ≤ C_x e^{-2mk}` (constant depending on
  `x`), then `HasMassGap D m`.
* `OSGap.Datum.decay_of_hasMassGap` : the converse, with `C_x = B x x - (B one x)^2`.
  So the arrow is a restatement (an equivalence): its hypothesis is the mass gap itself, said in
  terms of correlations.
* `OSGap.exampleDatum`, `OSGap.example_opNorm_eq` : a two-dimensional datum where all hypotheses
  are discharged and `‖T - P_Ω‖ = |r|` exactly (the orthogonal complement of the vacuum is not
  zero and the bound is attained).
* `OSGap.measureDatum`, `OSGap.massGap_of_measures` : the datum of a reflection positive
  probability measure and **statement G** (weak limit of measures with uniformly decaying
  truncated reflected correlations ⇒ mass gap of the reconstructed transfer operator);
  `OSGap.measure_hasMassGap_iff` : for one measure, mass gap ⇔ decay;
  `OSGap.massGap_of_measures_sub` : statement G with all hypotheses restricted to a
  shift-invariant subspace of observables (cylinder observables; periodic boxes).
* `OSGap.RevKernel`, `RevKernel.step_gap`, `RevKernel.opNorm_le` : a lattice object satisfying
  all hypotheses with no assumption left: a reversible Markov kernel on a finite set with a
  Doeblin minorization `p x y ≥ ε π y` has `‖T - P_Ω‖ ≤ 1 - ε`.
* `OSGap.RevKernel.odd_sector_bound` : on functions odd under a centre flip `c`, the one-step
  contraction is bounded by the total variation distance between `p x ·` and `p x (c ·)`.
* `OSGap.twoState`, `OSGap.twoState_opNorm_eq` : the symmetric two-state chain (Ising chain;
  lattice `ℤ₂` gauge theory in 1+1 dimensions on one spatial link, temporal gauge):
  `‖T - P_Ω‖ = 1 - 2b` exactly.
* `OSGap.exists_pos_eigenvector` : the symmetric case of the Perron–Frobenius theorem (a
  symmetric matrix with strictly positive entries on a finite nonempty set has a strictly
  positive eigenvector).
* `OSGap.ofTransfer`, `OSGap.transfer_gap` : **every symmetric transfer matrix with strictly
  positive entries on a finite set has a mass gap** (ground-state transform + minorization).
* `OSGap.z2Transfer`, `OSGap.z2_gauge_gap` : the temporal-gauge transfer matrix of `ℤ₂` lattice
  gauge theory (Wilson action) on an arbitrary finite spatial complex has a mass gap for every
  coupling `β`.  (Finite spatial volume; nothing is claimed about uniformity in the volume.)
* `OSGap.exists_invariant_pos_eigenvector`, `OSGap.transfer_flux_gap` : the flux sector of a
  finite transfer matrix with a centre flip `c`: if `|K x y - K x (c y)| ≤ t (K x y + K x (c y))`
  then the functions odd under `c` are contracted by `t`.
* `OSGap.flipOn`, `OSGap.z2_flux_gap`, `OSGap.hplaq_of_even`, `OSGap.hplaq_of_isEmpty` : for `ℤ₂`
  lattice gauge theory and a set `C` of links meeting every plaquette in an even number of links,
  the odd (electric flux) sector is contracted by `tanh (β |C|)` for every `β ≥ 0`
  (the slab confinement bound of textbook 12-04 in transfer-operator form).
-/

namespace OrbitGrowth

/-- monotonicity of ratios for a nonnegative log-convex sequence -/
lemma ratio_mono (a : ℕ → ℝ) (ha : ∀ k, 0 ≤ a k)
    (hc : ∀ k, a (k + 1) ^ 2 ≤ a k * a (k + 2)) :
    ∀ k, a 1 * a (k + 1) ≤ a 0 * a (k + 2) := by
  intro k
  induction k with
  | zero => simpa [sq] using hc 0
  | succ k ih =>
    rcases (ha (k + 2)).lt_or_eq with hpos | hzero
    · have key : a 1 * a (k + 2) * a (k + 2) ≤ a 0 * a (k + 3) * a (k + 2) := by
        calc a 1 * a (k + 2) * a (k + 2) = a 1 * a (k + 2) ^ 2 := by ring
          _ ≤ a 1 * (a (k + 1) * a (k + 3)) :=
              mul_le_mul_of_nonneg_left (hc (k + 1)) (ha 1)
          _ = (a 1 * a (k + 1)) * a (k + 3) := by ring
          _ ≤ (a 0 * a (k + 2)) * a (k + 3) := mul_le_mul_of_nonneg_right ih (ha _)
          _ = a 0 * a (k + 3) * a (k + 2) := by ring
      exact le_of_mul_le_mul_right key hpos
    · rw [← hzero, mul_zero]
      exact mul_nonneg (ha 0) (ha _)

/-- `a 1 ^ (k+1) ≤ a 0 ^ k * a (k+1)` -/
lemma pow_bound (a : ℕ → ℝ) (ha : ∀ k, 0 ≤ a k)
    (hc : ∀ k, a (k + 1) ^ 2 ≤ a k * a (k + 2)) :
    ∀ k, a 1 ^ (k + 1) ≤ a 0 ^ k * a (k + 1) := by
  intro k
  induction k with
  | zero => simp
  | succ k ih =>
    calc a 1 ^ (k + 2) = a 1 * a 1 ^ (k + 1) := by ring
      _ ≤ a 1 * (a 0 ^ k * a (k + 1)) := mul_le_mul_of_nonneg_left ih (ha 1)
      _ = a 0 ^ k * (a 1 * a (k + 1)) := by ring
      _ ≤ a 0 ^ k * (a 0 * a (k + 2)) :=
          mul_le_mul_of_nonneg_left (ratio_mono a ha hc k) (pow_nonneg (ha 0) k)
      _ = a 0 ^ (k + 1) * a (k + 2) := by ring

/-- **Sequence form.** A nonnegative log-convex sequence with `a k ≤ C * ρ ^ k` satisfies
`a 1 ≤ ρ * a 0`.  (The case `a 0 = 0` is handled by log-convexity itself.) -/
theorem seq_bound (a : ℕ → ℝ) (ha : ∀ k, 0 ≤ a k)
    (hc : ∀ k, a (k + 1) ^ 2 ≤ a k * a (k + 2))
    (C ρ : ℝ) (hρ : 0 ≤ ρ) (hdec : ∀ k : ℕ, a k ≤ C * ρ ^ k) :
    a 1 ≤ ρ * a 0 := by
  by_contra hcon
  have hcon' : ρ * a 0 < a 1 := lt_of_not_ge hcon
  have hpb := pow_bound a ha hc
  have ha1pos : 0 < a 1 := lt_of_le_of_lt (mul_nonneg hρ (ha 0)) hcon'
  rcases (ha 0).lt_or_eq with h0pos | h0zero
  · set q := a 1 / a 0 with hq
    have hqr : ρ < q := by rw [hq, lt_div_iff₀ h0pos]; linarith
    have hk : ∀ k : ℕ, q ^ (k + 1) * a 0 ≤ C * ρ ^ (k + 1) := by
      intro k
      have h1 := hpb k
      have h2 : a 0 ^ k * a (k + 1) ≤ a 0 ^ k * (C * ρ ^ (k + 1)) :=
        mul_le_mul_of_nonneg_left (hdec (k + 1)) (pow_nonneg (ha 0) k)
      have h3 : q ^ (k + 1) * a 0 ^ (k + 1) = a 1 ^ (k + 1) := by
        rw [hq, div_pow, div_mul_cancel₀]; exact pow_ne_zero _ (ne_of_gt h0pos)
      have h4 : q ^ (k + 1) * a 0 ^ (k + 1) ≤ a 0 ^ k * (C * ρ ^ (k + 1)) := by
        rw [h3]; exact le_trans h1 h2
      have h5 : a 0 ^ (k + 1) = a 0 ^ k * a 0 := pow_succ _ _
      rw [h5] at h4
      have hpk : 0 < a 0 ^ k := pow_pos h0pos k
      nlinarith [h4, hpk]
    rcases hρ.lt_or_eq with hρpos | hρzero
    · have hgt : 1 < q / ρ := by rw [lt_div_iff₀ hρpos]; linarith
      have hC : ∀ k : ℕ, (q / ρ) ^ (k + 1) ≤ C / a 0 := by
        intro k
        have := hk k
        rw [div_pow, div_le_div_iff₀ (pow_pos hρpos _) h0pos]
        linarith [this]
      obtain ⟨k, hk'⟩ := pow_unbounded_of_one_lt (C / a 0) hgt
      have := hC k
      have hmono : (q / ρ) ^ k ≤ (q / ρ) ^ (k + 1) :=
        pow_le_pow_right₀ (le_of_lt hgt) (Nat.le_succ k)
      linarith
    · have := hk 0
      rw [← hρzero] at this
      simp at this
      have hq0 : 0 < q := by rw [hq]; exact div_pos ha1pos h0pos
      nlinarith [mul_pos hq0 h0pos]
  · -- a 0 = 0: log-convexity gives a 1 ^ 2 ≤ a 0 * a 2 = 0
    have h := hc 0
    rw [← h0zero, zero_mul] at h
    have h' : a 1 ^ 2 ≤ 0 := by simpa using h
    nlinarith [ha1pos, h']

variable {V : Type*} [AddCommGroup V] [Module ℝ V]

/-- **Form bound.**  `B` positive semidefinite and symmetric, `τ` symmetric for `B`.
If the orbit of `x` satisfies `B (τ^[k] x) (τ^[k] x) ≤ C * ρ ^ k` for all `k`,
then `B (τ x) (τ x) ≤ ρ * B x x`.  The constant `C` may depend on `x`. -/
theorem form_bound (B : LinearMap.BilinForm ℝ V) (hs : ∀ x, 0 ≤ B x x)
    (hsymm : ∀ x y, B x y = B y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (x : V) (C ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ k : ℕ, B (τ^[k] x) (τ^[k] x) ≤ C * ρ ^ k) :
    B (τ x) (τ x) ≤ ρ * B x x := by
  have hc : ∀ k : ℕ, (B (τ^[k + 1] x) (τ^[k + 1] x)) ^ 2
      ≤ B (τ^[k] x) (τ^[k] x) * B (τ^[k + 2] x) (τ^[k + 2] x) := by
    intro k
    have h1 : τ^[k + 1] x = τ (τ^[k] x) := Function.iterate_succ_apply' _ _ _
    have h2 : τ^[k + 2] x = τ (τ^[k + 1] x) := Function.iterate_succ_apply' _ _ _
    have h3 : B (τ^[k + 1] x) (τ^[k + 1] x) = B (τ^[k] x) (τ^[k + 2] x) := by
      rw [h2]
      rw [← hτ]
      rw [← h1]
    have hcs := LinearMap.BilinForm.apply_mul_apply_le_of_forall_zero_le B hs
      (τ^[k] x) (τ^[k + 2] x)
    rw [hsymm (τ^[k + 2] x) (τ^[k] x)] at hcs
    calc (B (τ^[k + 1] x) (τ^[k + 1] x)) ^ 2
        = B (τ^[k] x) (τ^[k + 2] x) * B (τ^[k] x) (τ^[k + 2] x) := by rw [h3]; ring
      _ ≤ B (τ^[k] x) (τ^[k] x) * B (τ^[k + 2] x) (τ^[k + 2] x) := hcs
  have key := seq_bound (fun k => B (τ^[k] x) (τ^[k] x)) (fun k => hs _) hc C ρ hρ hdec
  simpa using key

/-- **Contraction from a bounded orbit** (`ρ = 1`). -/
theorem contraction_of_bounded (B : LinearMap.BilinForm ℝ V) (hs : ∀ x, 0 ≤ B x x)
    (hsymm : ∀ x y, B x y = B y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (x : V) (C : ℝ) (hbd : ∀ k : ℕ, B (τ^[k] x) (τ^[k] x) ≤ C) :
    B (τ x) (τ x) ≤ B x x := by
  have h := form_bound B hs hsymm τ hτ x C 1 zero_le_one (by intro k; simpa using hbd k)
  simpa using h

/-- the null space of `B` is preserved by `τ` when orbits are bounded -/
theorem null_preserved (B : LinearMap.BilinForm ℝ V) (hs : ∀ x, 0 ≤ B x x)
    (hsymm : ∀ x y, B x y = B y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (x : V) (C : ℝ) (hbd : ∀ k : ℕ, B (τ^[k] x) (τ^[k] x) ≤ C) (hx : B x x = 0) :
    B (τ x) (τ x) = 0 :=
  le_antisymm (by simpa [hx] using contraction_of_bounded B hs hsymm τ hτ x C hbd) (hs _)

/-- `B one (τ^[k] x) = B one x` when `τ one = one` -/
lemma pair_one_iterate (B : LinearMap.BilinForm ℝ V)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (one : V) (hτ1 : τ one = one) (x : V) (k : ℕ) :
    B one (τ^[k] x) = B one x := by
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', ← hτ, hτ1, ih]

/-- `τ^[k] (x - c • one) = τ^[k] x - c • one` when `τ one = one` -/
lemma iterate_sub_smul_one (τ : V →ₗ[ℝ] V) (one : V) (hτ1 : τ one = one) (x : V) (c : ℝ)
    (k : ℕ) : τ^[k] (x - c • one) = τ^[k] x - c • one := by
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', ih, Function.iterate_succ_apply', map_sub, map_smul, hτ1]

/-- the truncated form: `B (y - c • one) (y - c • one) = B y y - c^2` when `c = B one y`
and `B one one = 1` -/
lemma truncated_form (B : LinearMap.BilinForm ℝ V) (hsymm : ∀ x y, B x y = B y x)
    (one : V) (h1 : B one one = 1) (y : V) :
    B (y - (B one y) • one) (y - (B one y) • one) = B y y - (B one y) ^ 2 := by
  simp only [map_sub, map_smul, LinearMap.sub_apply, LinearMap.smul_apply, smul_eq_mul]
  rw [hsymm y one, h1]
  ring

/-- **Gap from decay** (pre-Hilbert form).  Vacuum vector `one` with `B one one = 1`,
`τ one = one`.  If the truncated reflected correlation of `x` decays,
`B (τ^[k] x) (τ^[k] x) - (B one x)^2 ≤ C * ρ ^ k` for all `k`, then
`B (τ x) (τ x) - (B one x)^2 ≤ ρ * (B x x - (B one x)^2)`.
With `ρ = e^{-2m}` this is `‖T v‖² ≤ e^{-2m} ‖v‖²` for `v = [x] - ⟨Ω,[x]⟩Ω`. -/
theorem gap_of_decay (B : LinearMap.BilinForm ℝ V) (hs : ∀ x, 0 ≤ B x x)
    (hsymm : ∀ x y, B x y = B y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (one : V) (h1 : B one one = 1) (hτ1 : τ one = one)
    (x : V) (C ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ k : ℕ, B (τ^[k] x) (τ^[k] x) - (B one x) ^ 2 ≤ C * ρ ^ k) :
    B (τ x) (τ x) - (B one x) ^ 2 ≤ ρ * (B x x - (B one x) ^ 2) := by
  set c := B one x with hc
  have horb : ∀ k : ℕ, B (τ^[k] (x - c • one)) (τ^[k] (x - c • one))
      = B (τ^[k] x) (τ^[k] x) - c ^ 2 := by
    intro k
    rw [iterate_sub_smul_one τ one hτ1 x c k]
    have hk : B one (τ^[k] x) = c := pair_one_iterate B τ hτ one hτ1 x k
    have := truncated_form B hsymm one h1 (τ^[k] x)
    rw [hk] at this
    exact this
  have hmain := form_bound B hs hsymm τ hτ (x - c • one) C ρ hρ
    (by intro k; rw [horb k]; exact hdec k)
  have e1 : B (τ (x - c • one)) (τ (x - c • one)) = B (τ x) (τ x) - c ^ 2 := by
    have := horb 1
    simpa using this
  have e0 : B (x - c • one) (x - c • one) = B x x - c ^ 2 := by
    have := horb 0
    simpa using this
  rw [e1, e0] at hmain
  exact hmain


/-! ### The hypotheses are satisfiable: a two-dimensional example

`V = ℝ × ℝ` with the Euclidean form, `τ (a, b) = (a, r b)`, vacuum vector `(1, 0)`.
The decay hypothesis holds with `C = b²`, `ρ = r²` (as an equality), so `gap_of_decay`
is not an empty statement.  With `r = 1` the decay hypothesis fails for `b ≠ 0` unless
`ρ ≥ 1`, which is the gapless case. -/

/-- the Euclidean form on `ℝ × ℝ` -/
noncomputable def B₂ : LinearMap.BilinForm ℝ (ℝ × ℝ) :=
  LinearMap.mk₂ ℝ (fun x y => x.1 * y.1 + x.2 * y.2)
    (by intro x x' y; simp only [Prod.fst_add, Prod.snd_add]; ring)
    (by intro c x y; simp only [Prod.smul_fst, Prod.smul_snd, smul_eq_mul]; ring)
    (by intro x y y'; simp only [Prod.fst_add, Prod.snd_add]; ring)
    (by intro c x y; simp only [Prod.smul_fst, Prod.smul_snd, smul_eq_mul]; ring)

/-- the diagonal map `(a, b) ↦ (a, r b)` -/
noncomputable def τ₂ (r : ℝ) : (ℝ × ℝ) →ₗ[ℝ] (ℝ × ℝ) :=
  LinearMap.prodMap LinearMap.id (r • LinearMap.id)

lemma τ₂_apply (r : ℝ) (x : ℝ × ℝ) : τ₂ r x = (x.1, r * x.2) := by
  simp [τ₂]

lemma τ₂_iterate (r : ℝ) (x : ℝ × ℝ) (k : ℕ) : (τ₂ r)^[k] x = (x.1, r ^ k * x.2) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply', ih, τ₂_apply]
    refine Prod.ext ?_ ?_
    · rfl
    · show r * (r ^ k * x.2) = r ^ (k + 1) * x.2
      ring

/-- `gap_of_decay` applied to the example: all hypotheses are discharged. -/
theorem example_gap (r : ℝ) (x : ℝ × ℝ) :
    B₂ (τ₂ r x) (τ₂ r x) - (B₂ (1, 0) x) ^ 2 ≤ r ^ 2 * (B₂ x x - (B₂ (1, 0) x) ^ 2) := by
  refine gap_of_decay B₂ ?_ ?_ (τ₂ r) ?_ (1, 0) ?_ ?_ x (x.2 ^ 2) (r ^ 2) (sq_nonneg r) ?_
  · intro y
    show 0 ≤ y.1 * y.1 + y.2 * y.2
    nlinarith [mul_self_nonneg y.1, mul_self_nonneg y.2]
  · intro y z
    show y.1 * z.1 + y.2 * z.2 = z.1 * y.1 + z.2 * y.2
    ring
  · intro y z
    rw [τ₂_apply, τ₂_apply]
    show y.1 * z.1 + r * y.2 * z.2 = y.1 * z.1 + y.2 * (r * z.2)
    ring
  · show (1 : ℝ) * 1 + 0 * 0 = 1
    norm_num
  · rw [τ₂_apply]
    simp
  · intro k
    rw [τ₂_iterate]
    show x.1 * x.1 + r ^ k * x.2 * (r ^ k * x.2) - (1 * x.1 + 0 * x.2) ^ 2
        ≤ x.2 ^ 2 * (r ^ 2) ^ k
    exact le_of_eq (by ring)


/-! ### The gap passes to pointwise limits of forms

Two forms of the conditional statement "decay of truncated reflected correlations at a common
rate for the approximating theories gives the gap inequality for the limit":

* `gap_of_decay_limit`: every approximant satisfies the hypotheses for all times (infinite time
  extent); the decay constants may depend on the approximant.  Only the rate `ρ` is common.
* `gap_of_eventual_decay_limit`: the structural properties and the decay bound hold eventually
  along the family for each fixed observable and each fixed time (growing periodic boxes);
  then the decay constant must not depend on the approximant.
-/

section Limit

open Filter Topology

variable {ι : Type*} {l : Filter ι} [l.NeBot]

/-- the gap inequality is a closed condition under pointwise convergence of the forms -/
theorem gap_limit (Bj : ι → LinearMap.BilinForm ℝ V) (B : LinearMap.BilinForm ℝ V)
    (hlim : ∀ x y, Tendsto (fun j => Bj j x y) l (𝓝 (B x y)))
    (τ : V →ₗ[ℝ] V) (one x : V) (ρ : ℝ)
    (hj : ∀ j, Bj j (τ x) (τ x) - (Bj j one x) ^ 2 ≤ ρ * (Bj j x x - (Bj j one x) ^ 2)) :
    B (τ x) (τ x) - (B one x) ^ 2 ≤ ρ * (B x x - (B one x) ^ 2) := by
  have h1 : Tendsto (fun j => Bj j (τ x) (τ x) - (Bj j one x) ^ 2) l
      (𝓝 (B (τ x) (τ x) - (B one x) ^ 2)) :=
    (hlim (τ x) (τ x)).sub ((hlim one x).pow 2)
  have h2 : Tendsto (fun j => ρ * (Bj j x x - (Bj j one x) ^ 2)) l
      (𝓝 (ρ * (B x x - (B one x) ^ 2))) :=
    ((hlim x x).sub ((hlim one x).pow 2)).const_mul ρ
  exact le_of_tendsto_of_tendsto' h1 h2 hj

/-- **Conditional statement, approximants with all times.**  Each `Bj j` is positive
semidefinite, symmetric, `τ`-symmetric, normalised, and has decay of the truncated reflected
correlation at rate `ρ` with a constant that may depend on `j` and on `x`.  If `Bj j → B`
pointwise, then `B` satisfies the gap inequality with the same `ρ`. -/
theorem gap_of_decay_limit (Bj : ι → LinearMap.BilinForm ℝ V) (B : LinearMap.BilinForm ℝ V)
    (hlim : ∀ x y, Tendsto (fun j => Bj j x y) l (𝓝 (B x y)))
    (hs : ∀ j x, 0 ≤ Bj j x x) (hsymm : ∀ j x y, Bj j x y = Bj j y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ j x y, Bj j (τ x) y = Bj j x (τ y))
    (one : V) (h1 : ∀ j, Bj j one one = 1) (hτ1 : τ one = one)
    (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ j x, ∃ C : ℝ, ∀ k : ℕ,
      Bj j (τ^[k] x) (τ^[k] x) - (Bj j one x) ^ 2 ≤ C * ρ ^ k)
    (x : V) :
    B (τ x) (τ x) - (B one x) ^ 2 ≤ ρ * (B x x - (B one x) ^ 2) := by
  refine gap_limit Bj B hlim τ one x ρ (fun j => ?_)
  obtain ⟨C, hC⟩ := hdec j x
  exact gap_of_decay (Bj j) (hs j) (hsymm j) τ (hτ j) one (h1 j) hτ1 x C ρ hρ hC

/-- **Conditional statement, eventual form.**  The structural properties hold eventually along
the family for each fixed pair of observables, and for each observable `x` there is one
constant `C` such that for each time `k` the decay bound holds eventually.  If `Bj j → B`
pointwise, then `B` is positive semidefinite, symmetric, `τ`-symmetric, normalised, and
satisfies the gap inequality with rate `ρ`. -/
theorem gap_of_eventual_decay_limit (Bj : ι → LinearMap.BilinForm ℝ V)
    (B : LinearMap.BilinForm ℝ V)
    (hlim : ∀ x y, Tendsto (fun j => Bj j x y) l (𝓝 (B x y)))
    (hs : ∀ x, ∀ᶠ j in l, 0 ≤ Bj j x x)
    (hsymm : ∀ x y, ∀ᶠ j in l, Bj j x y = Bj j y x)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, ∀ᶠ j in l, Bj j (τ x) y = Bj j x (τ y))
    (one : V) (h1 : ∀ᶠ j in l, Bj j one one = 1) (hτ1 : τ one = one)
    (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ x, ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ j in l,
      Bj j (τ^[k] x) (τ^[k] x) - (Bj j one x) ^ 2 ≤ C * ρ ^ k)
    (x : V) :
    B (τ x) (τ x) - (B one x) ^ 2 ≤ ρ * (B x x - (B one x) ^ 2) := by
  have hsB : ∀ y, 0 ≤ B y y := fun y => ge_of_tendsto (hlim y y) (hs y)
  have hsymmB : ∀ y z, B y z = B z y := fun y z =>
    tendsto_nhds_unique_of_eventuallyEq (hlim y z) (hlim z y) (hsymm y z)
  have hτB : ∀ y z, B (τ y) z = B y (τ z) := fun y z =>
    tendsto_nhds_unique_of_eventuallyEq (hlim (τ y) z) (hlim y (τ z)) (hτ y z)
  have h1B : B one one = 1 :=
    tendsto_nhds_unique_of_eventuallyEq (hlim one one) tendsto_const_nhds h1
  obtain ⟨C, hC⟩ := hdec x
  refine gap_of_decay B hsB hsymmB τ hτB one h1B hτ1 x C ρ hρ (fun k => ?_)
  have ht : Tendsto (fun j => Bj j (τ^[k] x) (τ^[k] x) - (Bj j one x) ^ 2) l
      (𝓝 (B (τ^[k] x) (τ^[k] x) - (B one x) ^ 2)) :=
    (hlim _ _).sub ((hlim one x).pow 2)
  exact le_of_tendsto ht (hC k)

end Limit


/-! ### The conditional statement for weakly convergent probability measures

`X` : the joint window (a positive-time window together with its mirror image),
`r : X → Y` : restriction to the positive-time window, `θr : X → Y` : reflection followed by
restriction (as in `InfiniteVolumeLimit.reflection_positivity_limit_two_maps`),
`sh : Y → Y` : the time shift by one step acting on the window variables.
Observables are bounded continuous functions `F : Y →ᵇ ℝ`.  The reflected pairing is
`⟨ΘF · G⟩ = ∫ F (θr x) * G (r x) dμ`, the vacuum vector is the constant `1`, and the shift acts
by `F ↦ F ∘ sh`.

`gap_of_measures`: if the measures `μ n` converge weakly to `ν`, and (eventually in `n`, for each
fixed observable) reflection positivity, symmetry of the pairing, symmetry of the shift and the
decay of the truncated reflected correlation at rate `ρ` hold, then the limit satisfies
`⟨Θ(τF) · τF⟩ - ⟨F⟩² ≤ ρ (⟨ΘF · F⟩ - ⟨F⟩²)`, the pre-Hilbert form of
`‖T v‖² ≤ ρ ‖v‖²` on the orthogonal complement of the vacuum.
-/

section Measures

open Filter Topology MeasureTheory
open scoped BoundedContinuousFunction

variable {X Y : Type*} [MeasurableSpace X] [TopologicalSpace X] [OpensMeasurableSpace X]
  [TopologicalSpace Y]

/-- the integrand `x ↦ F (θr x) * G (r x)` as a bounded continuous function -/
noncomputable def integrand (r θr : C(X, Y)) (F G : Y →ᵇ ℝ) : X →ᵇ ℝ :=
  F.compContinuous θr * G.compContinuous r

lemma integrand_apply (r θr : C(X, Y)) (F G : Y →ᵇ ℝ) (x : X) :
    integrand r θr F G x = F (θr x) * G (r x) := rfl

/-- the reflected pairing `∫ F (θr x) * G (r x) dμ` -/
noncomputable def pair (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (F G : Y →ᵇ ℝ) : ℝ :=
  ∫ x, integrand r θr F G x ∂(μ : Measure X)

lemma pair_add_left (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (F F' G : Y →ᵇ ℝ) :
    pair μ r θr (F + F') G = pair μ r θr F G + pair μ r θr F' G := by
  unfold pair
  rw [← integral_add (BoundedContinuousFunction.integrable (μ : Measure X) (integrand r θr F G))
    (BoundedContinuousFunction.integrable (μ : Measure X) (integrand r θr F' G))]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  simp only [integrand_apply]
  exact add_mul _ _ _

lemma pair_smul_left (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (c : ℝ) (F G : Y →ᵇ ℝ) :
    pair μ r θr (c • F) G = c • pair μ r θr F G := by
  unfold pair
  rw [smul_eq_mul, ← integral_const_mul]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  simp only [integrand_apply]
  exact mul_assoc _ _ _

lemma pair_add_right (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (F G G' : Y →ᵇ ℝ) :
    pair μ r θr F (G + G') = pair μ r θr F G + pair μ r θr F G' := by
  unfold pair
  rw [← integral_add (BoundedContinuousFunction.integrable (μ : Measure X) (integrand r θr F G))
    (BoundedContinuousFunction.integrable (μ : Measure X) (integrand r θr F G'))]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  simp only [integrand_apply]
  exact mul_add _ _ _

lemma pair_smul_right (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (c : ℝ) (F G : Y →ᵇ ℝ) :
    pair μ r θr F (c • G) = c • pair μ r θr F G := by
  unfold pair
  rw [smul_eq_mul, ← integral_const_mul]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  simp only [integrand_apply]
  exact mul_left_comm _ _ _

/-- the reflected pairing as a bilinear form on the bounded continuous observables -/
noncomputable def pairingForm (μ : ProbabilityMeasure X) (r θr : C(X, Y)) :
    LinearMap.BilinForm ℝ (Y →ᵇ ℝ) :=
  LinearMap.mk₂ ℝ (pair μ r θr) (pair_add_left μ r θr) (pair_smul_left μ r θr)
    (pair_add_right μ r θr) (pair_smul_right μ r θr)

lemma pairingForm_apply (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (F G : Y →ᵇ ℝ) :
    pairingForm μ r θr F G = ∫ x, F (θr x) * G (r x) ∂(μ : Measure X) := rfl

/-- weak convergence of the measures gives pointwise convergence of the pairings -/
lemma tendsto_pairingForm (μ : ℕ → ProbabilityMeasure X) (ν : ProbabilityMeasure X)
    (h : Tendsto μ atTop (𝓝 ν)) (r θr : C(X, Y)) (F G : Y →ᵇ ℝ) :
    Tendsto (fun n => pairingForm (μ n) r θr F G) atTop (𝓝 (pairingForm ν r θr F G)) :=
  (ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.mp h) (integrand r θr F G)

/-- the shift of observables `F ↦ F ∘ sh` as a linear map -/
noncomputable def shiftMap (sh : C(Y, Y)) : (Y →ᵇ ℝ) →ₗ[ℝ] (Y →ᵇ ℝ) where
  toFun F := F.compContinuous sh
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

lemma shiftMap_apply (sh : C(Y, Y)) (F : Y →ᵇ ℝ) (y : Y) : shiftMap sh F y = F (sh y) := rfl

lemma shiftMap_iterate_apply (sh : C(Y, Y)) (F : Y →ᵇ ℝ) (k : ℕ) (y : Y) :
    ((shiftMap sh)^[k] F) y = F (sh^[k] y) := by
  induction k generalizing y with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply]
    exact ih (sh y)

lemma pairingForm_one_left (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (F : Y →ᵇ ℝ) :
    pairingForm μ r θr 1 F = ∫ x, F (r x) ∂(μ : Measure X) := by
  rw [pairingForm_apply]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  show (1 : ℝ) * F (r x) = F (r x)
  exact one_mul _

lemma pairingForm_one_one (μ : ProbabilityMeasure X) (r θr : C(X, Y)) :
    pairingForm μ r θr 1 1 = 1 := by
  rw [pairingForm_one_left]
  have h : ∀ x : X, (1 : Y →ᵇ ℝ) (r x) = 1 := fun _ => rfl
  simp only [h]
  simp

lemma pairingForm_iterate (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (sh : C(Y, Y))
    (F : Y →ᵇ ℝ) (k : ℕ) :
    pairingForm μ r θr ((shiftMap sh)^[k] F) ((shiftMap sh)^[k] F)
      = ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(μ : Measure X) := by
  rw [pairingForm_apply]
  refine integral_congr_ae (Eventually.of_forall fun x => ?_)
  show ((shiftMap sh)^[k] F) (θr x) * ((shiftMap sh)^[k] F) (r x) = _
  rw [shiftMap_iterate_apply, shiftMap_iterate_apply]

/-- **Conditional statement for weakly convergent probability measures.**
Hypotheses (each for a fixed observable, eventually along the sequence):
`hRP` reflection positivity, `hsym` symmetry of the reflected pairing, `hshift` symmetry of the
time shift under the pairing, `hdec` decay of the truncated reflected correlation at rate `ρ`
with one constant per observable.  Conclusion: the gap inequality for the weak limit. -/
theorem gap_of_measures (μ : ℕ → ProbabilityMeasure X) (ν : ProbabilityMeasure X)
    (h : Tendsto μ atTop (𝓝 ν)) (r θr : C(X, Y)) (sh : C(Y, Y))
    (hRP : ∀ F : Y →ᵇ ℝ, ∀ᶠ n in atTop, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(μ n : Measure X))
    (hsym : ∀ F G : Y →ᵇ ℝ, ∀ᶠ n in atTop,
      ∫ x, F (θr x) * G (r x) ∂(μ n : Measure X) = ∫ x, G (θr x) * F (r x) ∂(μ n : Measure X))
    (hshift : ∀ F G : Y →ᵇ ℝ, ∀ᶠ n in atTop,
      ∫ x, F (sh (θr x)) * G (r x) ∂(μ n : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(μ n : Measure X))
    (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ F : Y →ᵇ ℝ, ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ n in atTop,
      ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(μ n : Measure X)
        - (∫ x, F (r x) ∂(μ n : Measure X)) ^ 2 ≤ C * ρ ^ k)
    (F : Y →ᵇ ℝ) :
    ∫ x, F (sh (θr x)) * F (sh (r x)) ∂(ν : Measure X) - (∫ x, F (r x) ∂(ν : Measure X)) ^ 2
      ≤ ρ * (∫ x, F (θr x) * F (r x) ∂(ν : Measure X)
          - (∫ x, F (r x) ∂(ν : Measure X)) ^ 2) := by
  have key := gap_of_eventual_decay_limit (l := atTop)
    (fun n => pairingForm (μ n) r θr) (pairingForm ν r θr)
    (fun F G => tendsto_pairingForm μ ν h r θr F G)
    (fun F => hRP F) (fun F G => hsym F G)
    (shiftMap sh) (fun F G => hshift F G)
    (1 : Y →ᵇ ℝ) (Eventually.of_forall fun n => pairingForm_one_one (μ n) r θr) rfl
    ρ hρ
    (fun F => by
      obtain ⟨C, hC⟩ := hdec F
      refine ⟨C, fun k => (hC k).mono fun n hn => ?_⟩
      rw [pairingForm_iterate, pairingForm_one_left]
      exact hn)
    F
  rw [pairingForm_one_left] at key
  have e1 : pairingForm ν r θr (shiftMap sh F) (shiftMap sh F)
      = ∫ x, F (sh (θr x)) * F (sh (r x)) ∂(ν : Measure X) := rfl
  have e0 : pairingForm ν r θr F F = ∫ x, F (θr x) * F (r x) ∂(ν : Measure X) := rfl
  rw [e1, e0] at key
  exact key

end Measures

end OrbitGrowth

namespace OSGap

open scoped InnerProductSpace

/-! ### Converse of `OrbitGrowth.gap_of_decay` at the pre-Hilbert level -/

section Converse

variable {V : Type*} [AddCommGroup V] [Module ℝ V]

/-- the one-step gap inequality for all vectors gives decay with the explicit constant
`B x x - (B one x)^2` -/
theorem decay_of_gap (B : LinearMap.BilinForm ℝ V)
    (τ : V →ₗ[ℝ] V) (hτ : ∀ x y, B (τ x) y = B x (τ y))
    (one : V) (hτ1 : τ one = one) (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hgap : ∀ x, B (τ x) (τ x) - (B one x) ^ 2 ≤ ρ * (B x x - (B one x) ^ 2))
    (x : V) (k : ℕ) :
    B (τ^[k] x) (τ^[k] x) - (B one x) ^ 2 ≤ ρ ^ k * (B x x - (B one x) ^ 2) := by
  induction k with
  | zero => simp
  | succ k ih =>
    have h := hgap (τ^[k] x)
    rw [OrbitGrowth.pair_one_iterate B τ hτ one hτ1 x k] at h
    rw [Function.iterate_succ_apply']
    calc B (τ (τ^[k] x)) (τ (τ^[k] x)) - (B one x) ^ 2
        ≤ ρ * (B (τ^[k] x) (τ^[k] x) - (B one x) ^ 2) := h
      _ ≤ ρ * (ρ ^ k * (B x x - (B one x) ^ 2)) := mul_le_mul_of_nonneg_left ih hρ
      _ = ρ ^ (k + 1) * (B x x - (B one x) ^ 2) := by ring

end Converse

/-! ### Operator form on an inner product space -/

section Hilbert

variable {H : Type*} [SeminormedAddCommGroup H] [InnerProductSpace ℝ H]

/-- the vacuum projection `v ↦ ⟪Ω, v⟫ • Ω` -/
noncomputable def vacProj (Ω : H) : H →L[ℝ] H := (innerSL ℝ Ω).smulRight Ω

lemma vacProj_apply (Ω v : H) : vacProj Ω v = ⟪Ω, v⟫_ℝ • Ω := by
  simp [vacProj]

lemma norm_sub_vac_sq (u Ω : H) (hΩ : ‖Ω‖ = 1) (c : ℝ) (hc : ⟪u, Ω⟫_ℝ = c) :
    ‖u - c • Ω‖ ^ 2 = ‖u‖ ^ 2 - c ^ 2 := by
  rw [norm_sub_sq_real, real_inner_smul_right, hc, norm_smul, hΩ, mul_one, Real.norm_eq_abs,
    sq_abs]
  ring

/-- from the gap inequality for all vectors to the operator norm of `T - P_Ω` -/
theorem opNorm_sub_vacProj_le (T : H →L[ℝ] H) (hT : ∀ x y, ⟪T x, y⟫_ℝ = ⟪x, T y⟫_ℝ)
    (Ω : H) (hΩ : ‖Ω‖ = 1) (hTΩ : T Ω = Ω) (r : ℝ) (hr : 0 ≤ r)
    (hgap : ∀ v, ‖T v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2 ≤ r ^ 2 * (‖v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2)) :
    ‖T - vacProj Ω‖ ≤ r := by
  refine ContinuousLinearMap.opNorm_le_bound _ hr (fun v => ?_)
  have h1 : ⟪T v, Ω⟫_ℝ = ⟪Ω, v⟫_ℝ := by rw [hT, hTΩ, real_inner_comm]
  have h2 : ‖T v - ⟪Ω, v⟫_ℝ • Ω‖ ^ 2 = ‖T v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2 :=
    norm_sub_vac_sq (T v) Ω hΩ _ h1
  have h3 : ‖T v - ⟪Ω, v⟫_ℝ • Ω‖ ^ 2 ≤ (r * ‖v‖) ^ 2 := by
    rw [h2, mul_pow]
    nlinarith [hgap v, mul_nonneg (sq_nonneg r) (sq_nonneg ⟪Ω, v⟫_ℝ)]
  have h4 : (T - vacProj Ω) v = T v - ⟪Ω, v⟫_ℝ • Ω := by
    rw [_root_.sub_apply, vacProj_apply]
  rw [h4]
  exact (sq_le_sq₀ (norm_nonneg _) (mul_nonneg hr (norm_nonneg _))).mp h3

/-- from the operator norm of `T - P_Ω` back to the gap inequality -/
theorem gap_of_opNorm (T : H →L[ℝ] H) (hT : ∀ x y, ⟪T x, y⟫_ℝ = ⟪x, T y⟫_ℝ)
    (Ω : H) (hΩ : ‖Ω‖ = 1) (hTΩ : T Ω = Ω) (r : ℝ)
    (hop : ‖T - vacProj Ω‖ ≤ r) (v : H) :
    ‖T v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2 ≤ r ^ 2 * (‖v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2) := by
  have h1 : ⟪T v, Ω⟫_ℝ = ⟪Ω, v⟫_ℝ := by rw [hT, hTΩ, real_inner_comm]
  have h2 : ‖T v - ⟪Ω, v⟫_ℝ • Ω‖ ^ 2 = ‖T v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2 :=
    norm_sub_vac_sq (T v) Ω hΩ _ h1
  have h2' : ‖v - ⟪Ω, v⟫_ℝ • Ω‖ ^ 2 = ‖v‖ ^ 2 - ⟪Ω, v⟫_ℝ ^ 2 :=
    norm_sub_vac_sq v Ω hΩ _ (real_inner_comm Ω v)
  have hΩΩ : ⟪Ω, Ω⟫_ℝ = 1 := by rw [real_inner_self_eq_norm_sq, hΩ, one_pow]
  have h5 : (T - vacProj Ω) (v - ⟪Ω, v⟫_ℝ • Ω) = T v - ⟪Ω, v⟫_ℝ • Ω := by
    rw [_root_.sub_apply, vacProj_apply, map_sub, map_smul, hTΩ, inner_sub_right,
      real_inner_smul_right, hΩΩ, mul_one, sub_self, zero_smul, sub_zero]
  have h6 := (T - vacProj Ω).le_opNorm (v - ⟪Ω, v⟫_ℝ • Ω)
  rw [h5] at h6
  have h7 : ‖T v - ⟪Ω, v⟫_ℝ • Ω‖ ≤ r * ‖v - ⟪Ω, v⟫_ℝ • Ω‖ :=
    h6.trans (mul_le_mul_of_nonneg_right hop (norm_nonneg _))
  have h8 : ‖T v - ⟪Ω, v⟫_ℝ • Ω‖ ^ 2 ≤ (r * ‖v - ⟪Ω, v⟫_ℝ • Ω‖) ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) h7 2
  rw [mul_pow, h2, h2'] at h8
  exact h8

end Hilbert

/-! ### The reconstruction datum and its completion -/

/-- Pre-Hilbert reconstruction datum.  In the application `V` is a space of positive-time
observables, `B F G = ⟨ΘF · G⟩`, `τ` is the shift by one time step and `one` is the constant
observable `1`.  `bounded` holds for bounded observables of a probability measure
(`|⟨Θ(τ^k F) · τ^k F⟩| ≤ ‖F‖_∞²`). -/
structure Datum (V : Type*) [AddCommGroup V] [Module ℝ V] where
  /-- the reflected pairing -/
  B : LinearMap.BilinForm ℝ V
  nonneg : ∀ x, 0 ≤ B x x
  symm : ∀ x y, B x y = B y x
  /-- the time shift -/
  τ : V →ₗ[ℝ] V
  τ_symm : ∀ x y, B (τ x) y = B x (τ y)
  /-- the constant observable -/
  one : V
  one_one : B one one = 1
  τ_one : τ one = one
  bounded : ∀ x, ∃ C : ℝ, ∀ k : ℕ, B (τ^[k] x) (τ^[k] x) ≤ C

namespace Datum

variable {V : Type*} [AddCommGroup V] [Module ℝ V]

/-- `τ` is a contraction for `B` (so it descends to the completion) -/
theorem contraction (D : Datum V) (x : V) : D.B (D.τ x) (D.τ x) ≤ D.B x x := by
  obtain ⟨C, hC⟩ := D.bounded x
  exact OrbitGrowth.contraction_of_bounded D.B D.nonneg D.symm D.τ D.τ_symm x C hC

/-- type synonym of `V` carrying the semi-inner product `B` -/
def Pre (_D : Datum V) := V

instance (D : Datum V) : AddCommGroup D.Pre := inferInstanceAs (AddCommGroup V)
instance (D : Datum V) : Module ℝ D.Pre := inferInstanceAs (Module ℝ V)

/-- the identification `V ≃ Pre` -/
def toPre (D : Datum V) : V ≃ₗ[ℝ] D.Pre := LinearEquiv.refl ℝ _

/-- the identification `Pre ≃ V` -/
def ofPre (D : Datum V) : D.Pre ≃ₗ[ℝ] V := D.toPre.symm

/-- the semi-inner product core given by `B` -/
noncomputable abbrev core (D : Datum V) : PreInnerProductSpace.Core ℝ D.Pre where
  inner a b := D.B (D.ofPre a) (D.ofPre b)
  conj_inner_symm a b := (conj_trivial _).trans (D.symm _ _)
  re_inner_nonneg a := D.nonneg (D.ofPre a)
  add_left a b c := by simp only [map_add, LinearMap.add_apply]
  smul_left a b r := by
    simp only [map_smul, LinearMap.smul_apply, smul_eq_mul, conj_trivial]

noncomputable instance (D : Datum V) : SeminormedAddCommGroup D.Pre :=
  InnerProductSpace.Core.toSeminormedAddCommGroup (c := D.core)

noncomputable instance (D : Datum V) : InnerProductSpace ℝ D.Pre :=
  InnerProductSpace.ofCore D.core

lemma inner_def (D : Datum V) (a b : D.Pre) : ⟪a, b⟫_ℝ = D.B (D.ofPre a) (D.ofPre b) := rfl

lemma norm_sq (D : Datum V) (a : D.Pre) : ‖a‖ ^ 2 = D.B (D.ofPre a) (D.ofPre a) := by
  rw [← real_inner_self_eq_norm_sq]
  rfl

/-- the shift as a linear map of the pre-Hilbert space -/
def τPre (D : Datum V) : D.Pre →ₗ[ℝ] D.Pre :=
  D.toPre.toLinearMap ∘ₗ D.τ ∘ₗ D.ofPre.toLinearMap

lemma norm_τPre_le (D : Datum V) (a : D.Pre) : ‖D.τPre a‖ ≤ 1 * ‖a‖ := by
  rw [one_mul, ← sq_le_sq₀ (norm_nonneg _) (norm_nonneg _), D.norm_sq, D.norm_sq]
  exact D.contraction (D.ofPre a)

/-- the shift as a continuous linear map (a contraction) of the pre-Hilbert space -/
noncomputable def τL (D : Datum V) : D.Pre →L[ℝ] D.Pre :=
  D.τPre.mkContinuous 1 D.norm_τPre_le

/-- the reconstructed Hilbert space -/
abbrev Hilb (D : Datum V) := UniformSpace.Completion D.Pre

/-- the transfer operator on the reconstructed Hilbert space -/
noncomputable def T (D : Datum V) : D.Hilb →L[ℝ] D.Hilb := D.τL.completion

/-- the canonical map from observables to the Hilbert space -/
noncomputable def emb (D : Datum V) (x : V) : D.Hilb := ((D.toPre x : D.Pre) : D.Hilb)

/-- the vacuum vector -/
noncomputable def Ω (D : Datum V) : D.Hilb := D.emb D.one

lemma T_emb (D : Datum V) (x : V) : D.T (D.emb x) = D.emb (D.τ x) := by
  unfold T emb
  rw [ContinuousLinearMap.completion_apply_coe]
  rfl

lemma inner_emb (D : Datum V) (x y : V) : ⟪D.emb x, D.emb y⟫_ℝ = D.B x y := by
  unfold emb
  rw [UniformSpace.Completion.inner_coe]
  rfl

lemma norm_emb_sq (D : Datum V) (x : V) : ‖D.emb x‖ ^ 2 = D.B x x := by
  rw [← real_inner_self_eq_norm_sq, inner_emb]

lemma coe_eq_emb (D : Datum V) (a : D.Pre) : ((a : D.Pre) : D.Hilb) = D.emb (D.ofPre a) := rfl

/-- the observables are dense in the reconstructed Hilbert space -/
lemma denseRange_emb (D : Datum V) : DenseRange D.emb := by
  have h : D.emb = ((↑) : D.Pre → D.Hilb) ∘ D.toPre := rfl
  rw [h]
  exact UniformSpace.Completion.denseRange_coe.comp D.toPre.surjective.denseRange
    (UniformSpace.Completion.continuous_coe _)

/-- `T` is symmetric -/
theorem T_symm (D : Datum V) (u v : D.Hilb) : ⟪D.T u, v⟫_ℝ = ⟪u, D.T v⟫_ℝ := by
  refine UniformSpace.Completion.induction_on₂ u v ?_ ?_
  · exact isClosed_eq (by fun_prop) (by fun_prop)
  · intro a b
    rw [coe_eq_emb, coe_eq_emb, T_emb, T_emb, inner_emb, inner_emb]
    exact D.τ_symm _ _

lemma T_Ω (D : Datum V) : D.T D.Ω = D.Ω := by
  unfold Ω
  rw [T_emb, D.τ_one]

lemma norm_Ω (D : Datum V) : ‖D.Ω‖ = 1 := by
  have h : ‖D.Ω‖ ^ 2 = 1 := by
    unfold Ω
    rw [norm_emb_sq, D.one_one]
  exact (sq_eq_sq₀ (norm_nonneg _) zero_le_one).mp (by rw [h, one_pow])

/-- **Gap inequality on the reconstructed Hilbert space.**  If the truncated reflected
correlation of every observable decays at rate `ρ` (constant depending on the observable), then
`‖T v‖² - ⟪Ω, v⟫² ≤ ρ (‖v‖² - ⟪Ω, v⟫²)` for every vector `v` of the completion. -/
theorem gap_completion (D : Datum V) (ρ : ℝ) (hρ : 0 ≤ ρ)
    (hdec : ∀ x : V, ∃ C : ℝ, ∀ k : ℕ,
      D.B (D.τ^[k] x) (D.τ^[k] x) - (D.B D.one x) ^ 2 ≤ C * ρ ^ k)
    (v : D.Hilb) :
    ‖D.T v‖ ^ 2 - ⟪D.Ω, v⟫_ℝ ^ 2 ≤ ρ * (‖v‖ ^ 2 - ⟪D.Ω, v⟫_ℝ ^ 2) := by
  refine UniformSpace.Completion.induction_on v ?_ ?_
  · exact isClosed_le (by fun_prop) (by fun_prop)
  · intro a
    obtain ⟨C, hC⟩ := hdec (D.ofPre a)
    have key := OrbitGrowth.gap_of_decay D.B D.nonneg D.symm D.τ D.τ_symm D.one D.one_one
      D.τ_one (D.ofPre a) C ρ hρ hC
    unfold Ω
    rw [coe_eq_emb, T_emb, norm_emb_sq, norm_emb_sq, inner_emb]
    exact key

/-- operator norm form: `‖T - P_Ω‖ ≤ r` when correlations decay at rate `r²` -/
theorem opNorm_gap (D : Datum V) (r : ℝ) (hr : 0 ≤ r)
    (hdec : ∀ x : V, ∃ C : ℝ, ∀ k : ℕ,
      D.B (D.τ^[k] x) (D.τ^[k] x) - (D.B D.one x) ^ 2 ≤ C * (r ^ 2) ^ k) :
    ‖D.T - vacProj D.Ω‖ ≤ r :=
  opNorm_sub_vacProj_le D.T D.T_symm D.Ω D.norm_Ω D.T_Ω r hr
    (fun v => D.gap_completion (r ^ 2) (sq_nonneg r) hdec v)

/-- **Mass gap** (in units of one time step): `‖T - P_Ω‖ ≤ e^{-m}`. -/
def HasMassGap (D : Datum V) (m : ℝ) : Prop := ‖D.T - vacProj D.Ω‖ ≤ Real.exp (-m)

lemma exp_sq_pow (m : ℝ) (k : ℕ) : (Real.exp (-m) ^ 2) ^ k = Real.exp (-(2 * m * k)) := by
  rw [← pow_mul, ← Real.exp_nat_mul]
  congr 1
  push_cast
  ring

/-- **Decay ⇒ mass gap.**  `⟨Θ(τ^k F) · τ^k F⟩ - ⟨F⟩² ≤ C_F e^{-2mk}` for every observable
gives `‖T - P_Ω‖ ≤ e^{-m}`. -/
theorem hasMassGap_of_decay (D : Datum V) (m : ℝ)
    (hdec : ∀ x : V, ∃ C : ℝ, ∀ k : ℕ,
      D.B (D.τ^[k] x) (D.τ^[k] x) - (D.B D.one x) ^ 2 ≤ C * Real.exp (-(2 * m * k))) :
    D.HasMassGap m := by
  refine D.opNorm_gap (Real.exp (-m)) (Real.exp_pos _).le (fun x => ?_)
  obtain ⟨C, hC⟩ := hdec x
  exact ⟨C, fun k => by rw [exp_sq_pow]; exact hC k⟩

/-- **Mass gap ⇒ decay** with the explicit constant `B x x - (B one x)²`.  Together with
`hasMassGap_of_decay` this shows that the decay hypothesis is the mass gap itself. -/
theorem decay_of_hasMassGap (D : Datum V) (m : ℝ) (h : D.HasMassGap m) (x : V) (k : ℕ) :
    D.B (D.τ^[k] x) (D.τ^[k] x) - (D.B D.one x) ^ 2
      ≤ Real.exp (-(2 * m * k)) * (D.B x x - (D.B D.one x) ^ 2) := by
  have hgap : ∀ y : V, D.B (D.τ y) (D.τ y) - (D.B D.one y) ^ 2
      ≤ Real.exp (-m) ^ 2 * (D.B y y - (D.B D.one y) ^ 2) := by
    intro y
    have key := gap_of_opNorm D.T D.T_symm D.Ω D.norm_Ω D.T_Ω (Real.exp (-m)) h (D.emb y)
    unfold Ω at key
    rw [T_emb, norm_emb_sq, norm_emb_sq, inner_emb] at key
    exact key
  have key := decay_of_gap D.B D.τ D.τ_symm D.one D.τ_one (Real.exp (-m) ^ 2) (sq_nonneg _)
    hgap x k
  rwa [exp_sq_pow] at key

/-- a unit observable orthogonal to the vacuum gives a lower bound for `‖T - P_Ω‖`
(the orthogonal complement of the vacuum is not zero, and the gap cannot be better than what
this observable shows) -/
theorem sqrt_le_opNorm (D : Datum V) (x : V) (hx : D.B x x = 1) (h0 : D.B D.one x = 0) :
    Real.sqrt (D.B (D.τ x) (D.τ x)) ≤ ‖D.T - vacProj D.Ω‖ := by
  have hv : ‖D.emb x‖ = 1 := by
    have h : ‖D.emb x‖ ^ 2 = 1 := by rw [norm_emb_sq, hx]
    exact (sq_eq_sq₀ (norm_nonneg _) zero_le_one).mp (by rw [h, one_pow])
  have hΩx : ⟪D.Ω, D.emb x⟫_ℝ = 0 := by
    unfold Ω
    rw [inner_emb, h0]
  have h4 : (D.T - vacProj D.Ω) (D.emb x) = D.emb (D.τ x) := by
    rw [_root_.sub_apply, vacProj_apply, hΩx, zero_smul, sub_zero, T_emb]
  have h5 := (D.T - vacProj D.Ω).le_opNorm (D.emb x)
  rw [h4, hv, mul_one] at h5
  rw [← norm_emb_sq, Real.sqrt_sq (norm_nonneg _)]
  exact h5

end Datum

/-! ### The hypotheses are satisfiable, and the bound is attained: a two-dimensional datum -/

/-- `V = ℝ × ℝ`, Euclidean form, `τ (a, b) = (a, r b)` with `|r| ≤ 1`, vacuum `(1, 0)` -/
noncomputable def exampleDatum (r : ℝ) (hr : |r| ≤ 1) : Datum (ℝ × ℝ) where
  B := OrbitGrowth.B₂
  nonneg := fun y => by
    show 0 ≤ y.1 * y.1 + y.2 * y.2
    nlinarith [mul_self_nonneg y.1, mul_self_nonneg y.2]
  symm := fun y z => by
    show y.1 * z.1 + y.2 * z.2 = z.1 * y.1 + z.2 * y.2
    ring
  τ := OrbitGrowth.τ₂ r
  τ_symm := fun y z => by
    rw [OrbitGrowth.τ₂_apply, OrbitGrowth.τ₂_apply]
    show y.1 * z.1 + r * y.2 * z.2 = y.1 * z.1 + y.2 * (r * z.2)
    ring
  one := (1, 0)
  one_one := by
    show (1 : ℝ) * 1 + 0 * 0 = 1
    norm_num
  τ_one := by
    rw [OrbitGrowth.τ₂_apply]
    simp
  bounded := fun x => ⟨x.1 * x.1 + x.2 * x.2, fun k => by
    rw [OrbitGrowth.τ₂_iterate]
    show x.1 * x.1 + r ^ k * x.2 * (r ^ k * x.2) ≤ x.1 * x.1 + x.2 * x.2
    have h0 : |r ^ k| ≤ 1 := by
      rw [abs_pow]
      exact pow_le_one₀ (abs_nonneg r) hr
    have h1 : (r ^ k) ^ 2 ≤ 1 := by
      calc (r ^ k) ^ 2 = |r ^ k| ^ 2 := (sq_abs _).symm
        _ ≤ 1 ^ 2 := pow_le_pow_left₀ (abs_nonneg _) h0 2
        _ = 1 := one_pow 2
    nlinarith [mul_nonneg (sub_nonneg.mpr h1) (mul_self_nonneg x.2)]⟩

/-- the decay hypothesis holds in the example, so `‖T - P_Ω‖ ≤ |r|` -/
theorem example_opNorm_le (r : ℝ) (hr : |r| ≤ 1) :
    ‖(exampleDatum r hr).T - vacProj (exampleDatum r hr).Ω‖ ≤ |r| := by
  refine (exampleDatum r hr).opNorm_gap |r| (abs_nonneg r) (fun x => ⟨x.2 ^ 2, fun k => ?_⟩)
  show OrbitGrowth.B₂ ((OrbitGrowth.τ₂ r)^[k] x) ((OrbitGrowth.τ₂ r)^[k] x)
      - (OrbitGrowth.B₂ (1, 0) x) ^ 2 ≤ x.2 ^ 2 * (|r| ^ 2) ^ k
  rw [OrbitGrowth.τ₂_iterate, sq_abs]
  show x.1 * x.1 + r ^ k * x.2 * (r ^ k * x.2) - (1 * x.1 + 0 * x.2) ^ 2
      ≤ x.2 ^ 2 * (r ^ 2) ^ k
  exact le_of_eq (by ring)

/-- in the example the bound is attained: `‖T - P_Ω‖ = |r|` -/
theorem example_opNorm_eq (r : ℝ) (hr : |r| ≤ 1) :
    ‖(exampleDatum r hr).T - vacProj (exampleDatum r hr).Ω‖ = |r| := by
  refine le_antisymm (example_opNorm_le r hr) ?_
  have key := (exampleDatum r hr).sqrt_le_opNorm (0, 1)
    (by show (0 : ℝ) * 0 + 1 * 1 = 1; norm_num)
    (by show (1 : ℝ) * 0 + 0 * 1 = 0; norm_num)
  have e : (exampleDatum r hr).B ((exampleDatum r hr).τ (0, 1)) ((exampleDatum r hr).τ (0, 1))
      = r ^ 2 := by
    show OrbitGrowth.B₂ (OrbitGrowth.τ₂ r (0, 1)) (OrbitGrowth.τ₂ r (0, 1)) = r ^ 2
    rw [OrbitGrowth.τ₂_apply]
    show (0 : ℝ) * 0 + r * 1 * (r * 1) = r ^ 2
    ring
  rw [e, Real.sqrt_sq_eq_abs] at key
  exact key

/-- with `r = e^{-m}` the example has mass gap `m` -/
theorem example_hasMassGap (m : ℝ) (hr : |Real.exp (-m)| ≤ 1) :
    (exampleDatum (Real.exp (-m)) hr).HasMassGap m := by
  unfold Datum.HasMassGap
  exact (example_opNorm_le (Real.exp (-m)) hr).trans (le_of_eq (abs_of_pos (Real.exp_pos _)))

/-- the side condition of `example_hasMassGap` holds for `m ≥ 0` -/
lemma abs_exp_neg_le_one (m : ℝ) (hm : 0 ≤ m) : |Real.exp (-m)| ≤ 1 := by
  rw [abs_of_pos (Real.exp_pos _)]
  exact Real.exp_le_one_iff.mpr (by linarith)

end OSGap

/-! ### The reconstruction datum of a probability measure, and the conditional statement G

`X` : the joint window, `r, θr : X → Y` : restriction to the positive-time window and
reflection followed by restriction, `sh : Y → Y` : the time shift by one step.
`measureDatum ν r θr sh` is the datum `(Y →ᵇ ℝ, ⟨ΘF · G⟩_ν, F ↦ F ∘ sh, 1)`.

`massGap_of_measures` (**statement G of the design **): if probability measures `μ n`
converge weakly to `ν` and (eventually, for each fixed pair of observables) are reflection
positive with symmetric pairing and symmetric shift, and the truncated reflected correlations
decay as `C_F e^{-2mk}` (one constant per observable, uniform along the sequence), then the
transfer operator reconstructed from the limit `ν` satisfies `‖T - P_Ω‖ ≤ e^{-m}`.
The decay hypothesis is ledger row ⑥g (uniform decay); the statement is a restatement of it
(`Datum.decay_of_hasMassGap` is the converse for a single measure). -/

namespace OSGap

section Measures

open Filter Topology MeasureTheory
open scoped BoundedContinuousFunction
open OrbitGrowth

variable {X Y : Type*} [MeasurableSpace X] [TopologicalSpace X] [OpensMeasurableSpace X]
  [TopologicalSpace Y]

lemma norm_shiftMap_le (sh : C(Y, Y)) (F : Y →ᵇ ℝ) : ‖shiftMap sh F‖ ≤ ‖F‖ :=
  (BoundedContinuousFunction.norm_le (norm_nonneg F)).mpr
    (fun y => F.norm_coe_le_norm (sh y))

lemma norm_shiftMap_iterate_le (sh : C(Y, Y)) (F : Y →ᵇ ℝ) (k : ℕ) :
    ‖(shiftMap sh)^[k] F‖ ≤ ‖F‖ := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact (norm_shiftMap_le sh _).trans ih

/-- `⟨ΘG · G⟩ ≤ ‖G‖_∞²` for a probability measure -/
lemma pairingForm_self_le (μ : ProbabilityMeasure X) (r θr : C(X, Y)) (G : Y →ᵇ ℝ) :
    pairingForm μ r θr G G ≤ ‖G‖ * ‖G‖ := by
  rw [pairingForm_apply]
  have hint : Integrable (fun x => G (θr x) * G (r x)) (μ : Measure X) :=
    BoundedContinuousFunction.integrable (μ : Measure X) (integrand r θr G G)
  have hle : ∀ x, G (θr x) * G (r x) ≤ ‖G‖ * ‖G‖ := fun x => by
    have h1 := G.norm_coe_le_norm (θr x)
    have h2 := G.norm_coe_le_norm (r x)
    rw [Real.norm_eq_abs] at h1 h2
    calc G (θr x) * G (r x) ≤ |G (θr x) * G (r x)| := le_abs_self _
      _ = |G (θr x)| * |G (r x)| := abs_mul _ _
      _ ≤ ‖G‖ * ‖G‖ := mul_le_mul h1 h2 (abs_nonneg _) (norm_nonneg _)
  have key := integral_mono hint (integrable_const (‖G‖ * ‖G‖)) hle
  simpa using key

/-- the reconstruction datum of a reflection positive probability measure with symmetric
pairing and symmetric shift; the bounded-orbit field is discharged by `‖F‖_∞` -/
noncomputable def measureDatum (ν : ProbabilityMeasure X) (r θr : C(X, Y)) (sh : C(Y, Y))
    (hRP : ∀ F : Y →ᵇ ℝ, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(ν : Measure X))
    (hsym : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (θr x) * G (r x) ∂(ν : Measure X) = ∫ x, G (θr x) * F (r x) ∂(ν : Measure X))
    (hshift : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (sh (θr x)) * G (r x) ∂(ν : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(ν : Measure X)) :
    Datum (Y →ᵇ ℝ) where
  B := pairingForm ν r θr
  nonneg := hRP
  symm := hsym
  τ := shiftMap sh
  τ_symm := hshift
  one := 1
  one_one := pairingForm_one_one ν r θr
  τ_one := rfl
  bounded := fun F => ⟨‖F‖ * ‖F‖, fun k =>
    (pairingForm_self_le ν r θr _).trans
      (mul_le_mul (norm_shiftMap_iterate_le sh F k) (norm_shiftMap_iterate_le sh F k)
        (norm_nonneg _) (norm_nonneg _))⟩

/-- **Statement G (conditional).**  Weak limit of eventually reflection positive measures with
uniformly decaying truncated reflected correlations: the transfer operator reconstructed from
the limit has mass gap at least `m`. -/
theorem massGap_of_measures (μ : ℕ → ProbabilityMeasure X) (ν : ProbabilityMeasure X)
    (h : Tendsto μ atTop (𝓝 ν)) (r θr : C(X, Y)) (sh : C(Y, Y))
    (hRP : ∀ F : Y →ᵇ ℝ, ∀ᶠ n in atTop, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(μ n : Measure X))
    (hsym : ∀ F G : Y →ᵇ ℝ, ∀ᶠ n in atTop,
      ∫ x, F (θr x) * G (r x) ∂(μ n : Measure X) = ∫ x, G (θr x) * F (r x) ∂(μ n : Measure X))
    (hshift : ∀ F G : Y →ᵇ ℝ, ∀ᶠ n in atTop,
      ∫ x, F (sh (θr x)) * G (r x) ∂(μ n : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(μ n : Measure X))
    (m : ℝ)
    (hdec : ∀ F : Y →ᵇ ℝ, ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ n in atTop,
      ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(μ n : Measure X)
        - (∫ x, F (r x) ∂(μ n : Measure X)) ^ 2 ≤ C * Real.exp (-(2 * m * k))) :
    ∃ D : Datum (Y →ᵇ ℝ), D.B = pairingForm ν r θr ∧ D.τ = shiftMap sh ∧ D.one = 1 ∧
      D.HasMassGap m := by
  have hRPν : ∀ F : Y →ᵇ ℝ, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(ν : Measure X) := fun F =>
    ge_of_tendsto (tendsto_pairingForm μ ν h r θr F F) (hRP F)
  have hsymν : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (θr x) * G (r x) ∂(ν : Measure X) = ∫ x, G (θr x) * F (r x) ∂(ν : Measure X) :=
    fun F G => tendsto_nhds_unique_of_eventuallyEq (tendsto_pairingForm μ ν h r θr F G)
      (tendsto_pairingForm μ ν h r θr G F) (hsym F G)
  have hshiftν : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (sh (θr x)) * G (r x) ∂(ν : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(ν : Measure X) :=
    fun F G => tendsto_nhds_unique_of_eventuallyEq
      (tendsto_pairingForm μ ν h r θr (shiftMap sh F) G)
      (tendsto_pairingForm μ ν h r θr F (shiftMap sh G)) (hshift F G)
  refine ⟨measureDatum ν r θr sh hRPν hsymν hshiftν, rfl, rfl, rfl, ?_⟩
  refine Datum.hasMassGap_of_decay _ m (fun F => ?_)
  obtain ⟨C, hC⟩ := hdec F
  refine ⟨C, fun k => ?_⟩
  show pairingForm ν r θr ((shiftMap sh)^[k] F) ((shiftMap sh)^[k] F)
      - (pairingForm ν r θr 1 F) ^ 2 ≤ C * Real.exp (-(2 * m * k))
  have ht : Tendsto (fun n => pairingForm (μ n) r θr ((shiftMap sh)^[k] F) ((shiftMap sh)^[k] F)
      - (pairingForm (μ n) r θr 1 F) ^ 2) atTop
      (𝓝 (pairingForm ν r θr ((shiftMap sh)^[k] F) ((shiftMap sh)^[k] F)
        - (pairingForm ν r θr 1 F) ^ 2)) :=
    (tendsto_pairingForm μ ν h r θr _ _).sub ((tendsto_pairingForm μ ν h r θr 1 F).pow 2)
  refine le_of_tendsto ht ((hC k).mono fun n hn => ?_)
  rw [pairingForm_iterate, pairingForm_one_left]
  exact hn

/-- for a single reflection positive measure: mass gap `m` of the reconstructed transfer
operator is equivalent to the decay of all truncated reflected correlations at rate `e^{-2m}`
per step -/
theorem measure_hasMassGap_iff (ν : ProbabilityMeasure X) (r θr : C(X, Y)) (sh : C(Y, Y))
    (hRP : ∀ F : Y →ᵇ ℝ, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(ν : Measure X))
    (hsym : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (θr x) * G (r x) ∂(ν : Measure X) = ∫ x, G (θr x) * F (r x) ∂(ν : Measure X))
    (hshift : ∀ F G : Y →ᵇ ℝ,
      ∫ x, F (sh (θr x)) * G (r x) ∂(ν : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(ν : Measure X))
    (m : ℝ) :
    (measureDatum ν r θr sh hRP hsym hshift).HasMassGap m ↔
      ∀ F : Y →ᵇ ℝ, ∃ C : ℝ, ∀ k : ℕ,
        ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(ν : Measure X)
          - (∫ x, F (r x) ∂(ν : Measure X)) ^ 2 ≤ C * Real.exp (-(2 * m * k)) := by
  constructor
  · intro hgap F
    refine ⟨∫ x, F (θr x) * F (r x) ∂(ν : Measure X) - (∫ x, F (r x) ∂(ν : Measure X)) ^ 2,
      fun k => ?_⟩
    have key := Datum.decay_of_hasMassGap _ m hgap F k
    have e1 : (measureDatum ν r θr sh hRP hsym hshift).B
        ((measureDatum ν r θr sh hRP hsym hshift).τ^[k] F)
        ((measureDatum ν r θr sh hRP hsym hshift).τ^[k] F)
        = ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(ν : Measure X) :=
      pairingForm_iterate ν r θr sh F k
    have e2 : (measureDatum ν r θr sh hRP hsym hshift).B
        (measureDatum ν r θr sh hRP hsym hshift).one F = ∫ x, F (r x) ∂(ν : Measure X) :=
      pairingForm_one_left ν r θr F
    have e3 : (measureDatum ν r θr sh hRP hsym hshift).B F F
        = ∫ x, F (θr x) * F (r x) ∂(ν : Measure X) := rfl
    rw [e1, e2, e3] at key
    linarith [key]
  · intro hdec
    refine Datum.hasMassGap_of_decay _ m (fun F => ?_)
    obtain ⟨C, hC⟩ := hdec F
    refine ⟨C, fun k => ?_⟩
    have e1 : (measureDatum ν r θr sh hRP hsym hshift).B
        ((measureDatum ν r θr sh hRP hsym hshift).τ^[k] F)
        ((measureDatum ν r θr sh hRP hsym hshift).τ^[k] F)
        = ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(ν : Measure X) :=
      pairingForm_iterate ν r θr sh F k
    have e2 : (measureDatum ν r θr sh hRP hsym hshift).B
        (measureDatum ν r θr sh hRP hsym hshift).one F = ∫ x, F (r x) ∂(ν : Measure X) :=
      pairingForm_one_left ν r θr F
    rw [e1, e2]
    exact hC k

end Measures


/-! ### Statement G on a shift-invariant subspace of observables

For approximants given by periodic boxes (unrolled to infinite time), reflection positivity and
the symmetry of the shift hold eventually only for observables that depend on finitely many
time slices.  `massGap_of_measures_sub` is statement G with every hypothesis restricted to a
subspace `W` of observables that contains `1` and is stable under the shift (for instance the
cylinder observables).  The reconstruction datum lives on `W`. -/

section MeasuresSub

open Filter Topology MeasureTheory
open scoped BoundedContinuousFunction
open OrbitGrowth

variable {X Y : Type*} [MeasurableSpace X] [TopologicalSpace X] [OpensMeasurableSpace X]
  [TopologicalSpace Y]

lemma coe_restrict_iterate {M : Type*} [AddCommGroup M] [Module ℝ M] (f : M →ₗ[ℝ] M)
    (W : Submodule ℝ M) (hW : ∀ x ∈ W, f x ∈ W) (F : W) (k : ℕ) :
    (((f.restrict hW)^[k] F : W) : M) = f^[k] (F : M) := by
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply', LinearMap.coe_restrict_apply,
      ih]

/-- **Statement G on a subspace of observables (conditional).** -/
theorem massGap_of_measures_sub (μ : ℕ → ProbabilityMeasure X) (ν : ProbabilityMeasure X)
    (h : Tendsto μ atTop (𝓝 ν)) (r θr : C(X, Y)) (sh : C(Y, Y))
    (W : Submodule ℝ (Y →ᵇ ℝ)) (h1 : (1 : Y →ᵇ ℝ) ∈ W) (hW : ∀ F ∈ W, shiftMap sh F ∈ W)
    (hRP : ∀ F ∈ W, ∀ᶠ n in atTop, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(μ n : Measure X))
    (hsym : ∀ F ∈ W, ∀ G ∈ W, ∀ᶠ n in atTop,
      ∫ x, F (θr x) * G (r x) ∂(μ n : Measure X) = ∫ x, G (θr x) * F (r x) ∂(μ n : Measure X))
    (hshift : ∀ F ∈ W, ∀ G ∈ W, ∀ᶠ n in atTop,
      ∫ x, F (sh (θr x)) * G (r x) ∂(μ n : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(μ n : Measure X))
    (m : ℝ)
    (hdec : ∀ F ∈ W, ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ n in atTop,
      ∫ x, F (sh^[k] (θr x)) * F (sh^[k] (r x)) ∂(μ n : Measure X)
        - (∫ x, F (r x) ∂(μ n : Measure X)) ^ 2 ≤ C * Real.exp (-(2 * m * k))) :
    ∃ D : Datum W,
      (∀ F G : W, D.B F G
        = ∫ x, (F : Y →ᵇ ℝ) (θr x) * (G : Y →ᵇ ℝ) (r x) ∂(ν : Measure X)) ∧
      (∀ F : W, ((D.τ F : W) : Y →ᵇ ℝ) = shiftMap sh (F : Y →ᵇ ℝ)) ∧
      ((D.one : W) : Y →ᵇ ℝ) = 1 ∧ D.HasMassGap m := by
  have hRPν : ∀ F ∈ W, 0 ≤ ∫ x, F (θr x) * F (r x) ∂(ν : Measure X) := fun F hF =>
    ge_of_tendsto (tendsto_pairingForm μ ν h r θr F F) (hRP F hF)
  have hsymν : ∀ F ∈ W, ∀ G ∈ W,
      ∫ x, F (θr x) * G (r x) ∂(ν : Measure X) = ∫ x, G (θr x) * F (r x) ∂(ν : Measure X) :=
    fun F hF G hG => tendsto_nhds_unique_of_eventuallyEq (tendsto_pairingForm μ ν h r θr F G)
      (tendsto_pairingForm μ ν h r θr G F) (hsym F hF G hG)
  have hshiftν : ∀ F ∈ W, ∀ G ∈ W,
      ∫ x, F (sh (θr x)) * G (r x) ∂(ν : Measure X)
        = ∫ x, F (θr x) * G (sh (r x)) ∂(ν : Measure X) :=
    fun F hF G hG => tendsto_nhds_unique_of_eventuallyEq
      (tendsto_pairingForm μ ν h r θr (shiftMap sh F) G)
      (tendsto_pairingForm μ ν h r θr F (shiftMap sh G)) (hshift F hF G hG)
  have hiter : ∀ (F : W) (k : ℕ),
      ((((shiftMap sh).restrict hW)^[k] F : W) : Y →ᵇ ℝ) = (shiftMap sh)^[k] (F : Y →ᵇ ℝ) :=
    fun F k => coe_restrict_iterate (shiftMap sh) W hW F k
  let D : Datum W :=
    { B := (pairingForm ν r θr).restrict W
      nonneg := fun F => hRPν F F.2
      symm := fun F G => hsymν F F.2 G G.2
      τ := (shiftMap sh).restrict hW
      τ_symm := fun F G => hshiftν F F.2 G G.2
      one := ⟨1, h1⟩
      one_one := pairingForm_one_one ν r θr
      τ_one := Subtype.ext rfl
      bounded := fun F => ⟨‖(F : Y →ᵇ ℝ)‖ * ‖(F : Y →ᵇ ℝ)‖, fun k => by
        show pairingForm ν r θr ((((shiftMap sh).restrict hW)^[k] F : W) : Y →ᵇ ℝ)
          ((((shiftMap sh).restrict hW)^[k] F : W) : Y →ᵇ ℝ) ≤ _
        rw [hiter F k]
        exact (pairingForm_self_le ν r θr _).trans
          (mul_le_mul (norm_shiftMap_iterate_le sh _ k) (norm_shiftMap_iterate_le sh _ k)
            (norm_nonneg _) (norm_nonneg _))⟩ }
  refine ⟨D, fun F G => rfl, fun F => rfl, rfl, ?_⟩
  refine Datum.hasMassGap_of_decay D m (fun F => ?_)
  obtain ⟨C, hC⟩ := hdec F F.2
  refine ⟨C, fun k => ?_⟩
  show pairingForm ν r θr ((((shiftMap sh).restrict hW)^[k] F : W) : Y →ᵇ ℝ)
      ((((shiftMap sh).restrict hW)^[k] F : W) : Y →ᵇ ℝ)
      - (pairingForm ν r θr 1 (F : Y →ᵇ ℝ)) ^ 2 ≤ C * Real.exp (-(2 * m * k))
  rw [hiter F k]
  have ht : Tendsto (fun n => pairingForm (μ n) r θr ((shiftMap sh)^[k] (F : Y →ᵇ ℝ))
      ((shiftMap sh)^[k] (F : Y →ᵇ ℝ)) - (pairingForm (μ n) r θr 1 (F : Y →ᵇ ℝ)) ^ 2) atTop
      (𝓝 (pairingForm ν r θr ((shiftMap sh)^[k] (F : Y →ᵇ ℝ))
        ((shiftMap sh)^[k] (F : Y →ᵇ ℝ)) - (pairingForm ν r θr 1 (F : Y →ᵇ ℝ)) ^ 2)) :=
    (tendsto_pairingForm μ ν h r θr _ _).sub
      ((tendsto_pairingForm μ ν h r θr 1 (F : Y →ᵇ ℝ)).pow 2)
  refine le_of_tendsto ht ((hC k).mono fun n hn => ?_)
  rw [pairingForm_iterate, pairingForm_one_left]
  exact hn

end MeasuresSub

/-! ### The hypotheses of `massGap_of_measures_sub` are satisfiable (minimal witness)

Paper correspondence: COMMON §3 point 1. One-point configuration
space, Dirac measure, constant sequence: every hypothesis holds, for every `m`.  The dynamics is
trivial (the reconstructed Hilbert space is one-dimensional); this only shows that the hypothesis
fields of statement G are not empty.  A path measure of a Markov chain is not yet in Lean. -/

section GExample

open Filter Topology MeasureTheory
open scoped BoundedContinuousFunction
open OrbitGrowth

/-- the Dirac probability measure on the one-point space -/
noncomputable def pointProb : ProbabilityMeasure Unit :=
  ⟨Measure.dirac (), inferInstance⟩

lemma point_integral (φ : Unit → ℝ) : ∫ x, φ x ∂(pointProb : Measure Unit) = φ () := by
  show ∫ x, φ x ∂(Measure.dirac ()) = φ ()
  rw [integral_dirac]

theorem massGap_of_measures_sub_point (m : ℝ) :
    ∃ D : Datum (⊤ : Submodule ℝ (Unit →ᵇ ℝ)),
      (∀ F G : (⊤ : Submodule ℝ (Unit →ᵇ ℝ)), D.B F G
        = ∫ x, (F : Unit →ᵇ ℝ) (ContinuousMap.id Unit x) * (G : Unit →ᵇ ℝ) (ContinuousMap.id Unit x)
            ∂(pointProb : Measure Unit)) ∧
      (∀ F : (⊤ : Submodule ℝ (Unit →ᵇ ℝ)),
        ((D.τ F : (⊤ : Submodule ℝ (Unit →ᵇ ℝ))) : Unit →ᵇ ℝ)
          = shiftMap (ContinuousMap.id Unit) (F : Unit →ᵇ ℝ)) ∧
      ((D.one : (⊤ : Submodule ℝ (Unit →ᵇ ℝ))) : Unit →ᵇ ℝ) = 1 ∧ D.HasMassGap m := by
  refine massGap_of_measures_sub (fun _ => pointProb) pointProb tendsto_const_nhds
    (ContinuousMap.id Unit) (ContinuousMap.id Unit) (ContinuousMap.id Unit) ⊤
    Submodule.mem_top (fun _ _ => Submodule.mem_top) ?_ ?_ ?_ m ?_
  · intro F _
    refine Filter.Eventually.of_forall (fun _ => ?_)
    rw [point_integral]
    exact mul_self_nonneg _
  · intro F _ G _
    refine Filter.Eventually.of_forall (fun _ => ?_)
    rw [point_integral, point_integral]
    exact mul_comm _ _
  · intro F _ G _
    refine Filter.Eventually.of_forall (fun _ => ?_)
    rfl
  · intro F _
    refine ⟨0, fun k => Filter.Eventually.of_forall (fun _ => ?_)⟩
    rw [point_integral, point_integral, zero_mul]
    show F () * F () - F () ^ 2 ≤ 0
    rw [sq, sub_self]

end GExample

end OSGap

#print axioms OSGap.massGap_of_measures_sub
#print axioms OSGap.massGap_of_measures_sub_point
