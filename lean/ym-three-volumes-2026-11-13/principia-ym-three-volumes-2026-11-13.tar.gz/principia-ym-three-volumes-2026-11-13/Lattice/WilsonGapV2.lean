import Lattice.TorusDecV2
import Lattice.GapG

/-!
# Statement G for the strong-coupling SU(2) Wilson measure on ℤ⁴ (table 2, row 10) — 

Paper correspondence: (statement G = `OSGap.massGap_of_measures_sub`), applied to the
periodic lifts of the normalised SU(2) Wilson measures on the tori `(ℤ/2(n+1))⁴`.  This is a
formalisation of a known result (Osterwalder–Seiler type strong-coupling mass gap); the window
`24 (1 - e^{-4|β|}) < 1` (|β| < ln(24/23)/4 ≈ 0.0106) is far from the physical β.

Imports (`lean -o`, root `olean`): `Lattice.TorusDecV2` (copy of an earlier file)
and `Lattice.GapG` (copy of an earlier file). The first block below is a verbatim
copy of earlier data files (the normalised Wilson measure).
-/


/-! # The normalised Wilson measure (a `ProbabilityMeasure`) — 

the chain fields (`hΘp` of `chain_end_to_end_blockMap`)
take a family of `ProbabilityMeasure`s.  `wilsonMeasure N β` is the Wilson measure up to the
positive constant `Z e^{-β #plaquettes}`; here its total mass is shown to be finite and positive,
and `wilsonProb N β := (μ univ)⁻¹ • μ` is the normalised Wilson measure of paper A, line 73. -/

namespace TorusRP

open MeasureTheory

variable (N : ℕ) [NeZero N]

theorem abs_action_le (ω : Lk N → QBall) : |action N ω| ≤ (plaqs N).card := by
  unfold action
  calc |∑ p ∈ plaqs N, (hol N ω p).re| ≤ ∑ p ∈ plaqs N, |(hol N ω p).re| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _p ∈ plaqs N, (1 : ℝ) := Finset.sum_le_sum (fun p _ => abs_hol_re N ω p)
    _ = (plaqs N).card := by simp

theorem abs_beta_action_le (β : ℝ) (ω : Lk N → QBall) :
    |β * action N ω| ≤ |β| * (plaqs N).card := by
  rw [abs_mul]; exact mul_le_mul_of_nonneg_left (abs_action_le N ω) (abs_nonneg _)

theorem wilsonWeight_le (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β ω ≤ Real.exp (|β| * (plaqs N).card) := by
  unfold wilsonWeight
  exact Real.exp_le_exp.2 ((le_abs_self _).trans (abs_beta_action_le N β ω))

theorem wilsonWeight_ge (β : ℝ) (ω : Lk N → QBall) :
    Real.exp (-(|β| * (plaqs N).card)) ≤ wilsonWeight N β ω := by
  unfold wilsonWeight
  apply Real.exp_le_exp.2
  have h1 := abs_beta_action_le N β ω
  have h2 := neg_abs_le (β * action N ω)
  linarith

theorem wilsonMeasure_univ (β : ℝ) : wilsonMeasure N β Set.univ =
    ∫⁻ ω, ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal)
      ∂(Measure.pi fun _ : Lk N => haarBall) := by
  rw [wilsonMeasure, withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ]

theorem wilsonMeasure_univ_lt_top (β : ℝ) : wilsonMeasure N β Set.univ < ⊤ := by
  rw [wilsonMeasure_univ]
  calc ∫⁻ ω, ((Real.toNNReal (wilsonWeight N β ω) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall)
      ≤ ∫⁻ _ω, ((Real.toNNReal (Real.exp (|β| * (plaqs N).card)) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall) :=
        lintegral_mono (fun ω => ENNReal.coe_le_coe.mpr
          (Real.toNNReal_le_toNNReal (wilsonWeight_le N β ω)))
    _ < ⊤ := by
        rw [lintegral_const, measure_univ, mul_one]; exact ENNReal.coe_lt_top

theorem wilsonMeasure_univ_pos (β : ℝ) : 0 < wilsonMeasure N β Set.univ := by
  rw [wilsonMeasure_univ]
  calc (0 : ENNReal) < ((Real.toNNReal (Real.exp (-(|β| * (plaqs N).card))) : NNReal) : ENNReal) := by
        rw [ENNReal.coe_pos, Real.toNNReal_pos]; exact Real.exp_pos _
    _ = ∫⁻ _ω, ((Real.toNNReal (Real.exp (-(|β| * (plaqs N).card))) : NNReal) : ENNReal)
        ∂(Measure.pi fun _ : Lk N => haarBall) := by
        rw [lintegral_const, measure_univ, mul_one]
    _ ≤ _ := lintegral_mono (fun ω => ENNReal.coe_le_coe.mpr
          (Real.toNNReal_le_toNNReal (wilsonWeight_ge N β ω)))

instance wilsonMeasure_finite (β : ℝ) : IsFiniteMeasure (wilsonMeasure N β) :=
  ⟨wilsonMeasure_univ_lt_top N β⟩

instance wilsonMeasure_neZero (β : ℝ) : NeZero (wilsonMeasure N β) :=
  ⟨fun h => by
    have := wilsonMeasure_univ_pos N β
    rw [h] at this
    simp at this⟩

/-- **The normalised Wilson measure** `μ_N = Z⁻¹ e^{β Σ_p Re U_p} ∏ dU` (paper A, line 73; the
constant `e^{-β #plaquettes}` of `1 - ½ tr U_p` cancels in the normalisation). -/
noncomputable def wilsonProb (β : ℝ) : ProbabilityMeasure (Lk N → QBall) :=
  ⟨(wilsonMeasure N β Set.univ)⁻¹ • wilsonMeasure N β, inferInstance⟩

theorem wilsonProb_toMeasure (β : ℝ) :
    (wilsonProb N β : Measure (Lk N → QBall)) =
      (wilsonMeasure N β Set.univ)⁻¹ • wilsonMeasure N β := rfl

/-- (RP1) for the normalised measure (a positive multiple). -/
theorem wilsonProb_rp (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (Cf : ℝ) (hfC : ∀ ω, |f ω| ≤ Cf)
    (hfdep : ∀ ω ω', (∀ ℓ, fixP N M ℓ ∨ posP N M ℓ → ω ℓ = ω' ℓ) → f ω = f ω') :
    0 ≤ ∫ ω, f (LinkReflection.linkRefl (thL N) (sig N) ω) * f ω
      ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  rw [wilsonProb_toMeasure, integral_smul_measure]
  exact smul_nonneg ENNReal.toReal_nonneg (wilson_rp N M hN β f hf Cf hfC hfdep)

end TorusRP


namespace WilsonLimit

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open scoped BoundedContinuousFunction

/-! ## (a) the normalised Wilson measure: symmetry, shift pairing, expectation = `gibbs` -/

section Torus

variable (N : ℕ) [NeZero N]

/-- (a) `hsym` for the normalised measure (a positive multiple of `wilson_refl_symm`). -/
theorem wilsonProb_refl_symm (M : ℕ) (hN : N = 2 * M) (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (linkRefl (thL N) (sig N) ω) * g ω ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω, g (linkRefl (thL N) (sig N) ω) * f ω ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_refl_symm N M hN β f g hf hg]

/-- `hshift` for the normalised measure. -/
theorem wilsonProb_shift_pairing (β : ℝ) (f g : (Lk N → QBall) → ℝ)
    (hf : Measurable f) (hg : Measurable g) :
    ∫ ω, f (tShift N (linkRefl (thL N) (sig N) ω)) * g ω ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω, f (linkRefl (thL N) (sig N) ω) * g (tShift N ω)
          ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_shift_pairing N β f g hf hg]

/-- the expectation under the normalised measure is `gibbs` with the plaquette weights -/
theorem integral_wilsonProb_gibbs (β : ℝ) (H : (Lk N → QBall) → ℝ) :
    ∫ ω, H ω ∂(wilsonProb N β : Measure (Lk N → QBall))
      = gibbs (fun _ : Lk N => haarBall) (plaqW N β) H := by
  rw [wilsonProb_toMeasure, integral_smul_measure, gibbs_eq]
  simp only [integral_const, smul_eq_mul, mul_one, measureReal_def]
  rw [ENNReal.toReal_inv, div_eq_inv_mul]

theorem val_intCast (t : ℤ) (h0 : 0 ≤ t) (h1 : t < N) : ((t : ZMod N)).val = t.toNat := by
  obtain ⟨m, rfl⟩ := Int.eq_ofNat_of_zero_le h0
  rw [Int.cast_natCast, ZMod.val_natCast, Nat.mod_eq_of_lt (show m < N by omega)]
  omega

theorem cdist_intCast_eq (j : ℤ) (h0 : 0 ≤ j) (h1 : j.toNat ≤ N / 2) :
    cdist N (j : ZMod N) = j.toNat := by
  obtain ⟨m, rfl⟩ := Int.eq_ofNat_of_zero_le h0
  rw [Int.cast_natCast, cdist_natCast N m (by simpa using h1)]
  omega

end Torus

/-! ## (c) the common space: link configurations of ℤ⁴, reflection, shift, periodic perLift -/

abbrev ZSite := Fin 4 → ℤ
abbrev ZLk := ZSite × Fin 4
/-- the common configuration space `X = Y` of statement G (compact) -/
abbrev Cfg := ZLk → QBall

/-- `Θ x = (-x₀, x₁, x₂, x₃)` on ℤ⁴ -/
def zthS (y : ZSite) : ZSite := fun i => if i = 0 then -y i else y i

/-- the reflection of the links of ℤ⁴ (same formula as `thL` on the torus) -/
def zthL (ℓ : ZLk) : ZLk :=
  if ℓ.2 = 0 then (zthS ℓ.1 - Pi.single 0 1, 0) else (zthS ℓ.1, ℓ.2)

noncomputable def zsig (ℓ : ZLk) : QBall → QBall := if ℓ.2 = 0 then starB else id

/-- the reflection `θ` of configurations on ℤ⁴ -/
noncomputable def zRefl (x : Cfg) : Cfg := fun ℓ => zsig ℓ (x (zthL ℓ))

/-- translation of a link by `k` time steps -/
def zsh (k : ℕ) (ℓ : ZLk) : ZLk := (ℓ.1 + Pi.single 0 (k : ℤ), ℓ.2)

/-- the time shift by one step: `(T x)_ℓ = x_{ℓ + e₀}` -/
def zShift (x : Cfg) : Cfg := fun ℓ => x (zsh 1 ℓ)

/-- reduction of a link of ℤ⁴ modulo `N` -/
def zproj (N : ℕ) [NeZero N] (ℓ : ZLk) : Lk N := (fun i => ((ℓ.1 i : ℤ) : ZMod N), ℓ.2)

/-- the periodic perLift of a torus configuration to ℤ⁴ -/
def perLift (N : ℕ) [NeZero N] (ω : Lk N → QBall) : Cfg := fun ℓ => ω (zproj N ℓ)

theorem continuous_zsig (ℓ : ZLk) : Continuous (zsig ℓ) := by
  unfold zsig
  split_ifs
  · exact continuous_starB
  · exact continuous_id

theorem continuous_zRefl : Continuous zRefl :=
  continuous_pi fun ℓ => (continuous_zsig ℓ).comp (continuous_apply _)

theorem continuous_zShift : Continuous zShift := continuous_pi fun _ => continuous_apply _

theorem continuous_perLift (N : ℕ) [NeZero N] : Continuous (perLift N) := continuous_pi fun _ => continuous_apply _

theorem measurable_perLift (N : ℕ) [NeZero N] : Measurable (perLift N) :=
  measurable_pi_lambda _ (fun ℓ => measurable_pi_apply (zproj N ℓ))

noncomputable def zReflC : C(Cfg, Cfg) := ⟨zRefl, continuous_zRefl⟩
def zShiftC : C(Cfg, Cfg) := ⟨zShift, continuous_zShift⟩

theorem zsh_snd (k : ℕ) (ℓ : ZLk) : (zsh k ℓ).2 = ℓ.2 := rfl

theorem zsh_time (k : ℕ) (ℓ : ZLk) : (zsh k ℓ).1 0 = ℓ.1 0 + k := by simp [zsh]

theorem zthL_time (ℓ : ZLk) :
    (zthL ℓ).1 0 = if ℓ.2 = 0 then -ℓ.1 0 - 1 else -ℓ.1 0 := by
  unfold zthL
  split_ifs <;> simp [zthS]

theorem zsh_succ (k : ℕ) (ℓ : ZLk) : zsh 1 (zsh k ℓ) = zsh (k + 1) ℓ := by
  refine Prod.ext (funext fun i => ?_) rfl
  simp only [zsh, Pi.add_apply, Pi.single_apply]
  split_ifs <;> push_cast <;> ring

theorem zShift_iter_apply (k : ℕ) (x : Cfg) (ℓ : ZLk) : (zShift^[k] x) ℓ = x (zsh k ℓ) := by
  induction k generalizing x with
  | zero => simp [zsh]
  | succ k ih =>
    rw [Function.iterate_succ_apply, ih]
    show x (zsh 1 (zsh k ℓ)) = _
    rw [zsh_succ]

section Lift

variable (N : ℕ) [NeZero N]

theorem proj_time (ℓ : ZLk) : (zproj N ℓ).1 0 = ((ℓ.1 0 : ℤ) : ZMod N) := rfl

theorem proj_zthL (ℓ : ZLk) : zproj N (zthL ℓ) = thL N (zproj N ℓ) := by
  by_cases h : ℓ.2 = 0
  · have e1 : zthL ℓ = (zthS ℓ.1 - Pi.single 0 1, 0) := if_pos h
    have e2 : thL N (zproj N ℓ) = (thS N (zproj N ℓ).1 - ev N 0, 0) := if_pos h
    rw [e1, e2]
    refine Prod.ext (funext fun i => ?_) rfl
    show (((zthS ℓ.1 - (Pi.single 0 1 : ZSite)) i : ℤ) : ZMod N) = (thS N (zproj N ℓ).1 - ev N 0) i
    simp only [Pi.sub_apply, zthS, thS, ev, zproj, Pi.single_apply]
    split_ifs <;> push_cast <;> ring
  · have e1 : zthL ℓ = (zthS ℓ.1, ℓ.2) := if_neg h
    have e2 : thL N (zproj N ℓ) = (thS N (zproj N ℓ).1, (zproj N ℓ).2) := if_neg h
    rw [e1, e2]
    refine Prod.ext (funext fun i => ?_) rfl
    show (((zthS ℓ.1) i : ℤ) : ZMod N) = (thS N (zproj N ℓ).1) i
    simp only [zthS, thS, zproj]
    split_ifs <;> push_cast <;> ring

theorem proj_zsh1 (ℓ : ZLk) : zproj N (zsh 1 ℓ) = shL N (zproj N ℓ) := by
  refine Prod.ext (funext fun i => ?_) rfl
  simp only [zsh, shL, zproj, ev, Pi.add_apply, Pi.single_apply]
  split_ifs <;> push_cast <;> ring

/-- the perLift intertwines the reflections -/
theorem zRefl_lift (ω : Lk N → QBall) :
    zRefl (perLift N ω) = perLift N (linkRefl (thL N) (sig N) ω) := by
  funext ℓ
  show zsig ℓ (ω (zproj N (zthL ℓ))) = sig N (zproj N ℓ) (ω (thL N (zproj N ℓ)))
  (rw [proj_zthL]) <;> rfl

/-- the perLift intertwines the time shifts -/
theorem zShift_lift (ω : Lk N → QBall) : zShift (perLift N ω) = perLift N (tShift N ω) := by
  funext ℓ
  show ω (zproj N (zsh 1 ℓ)) = ω (shL N (zproj N ℓ))
  rw [proj_zsh1]

theorem zShift_iter_lift (k : ℕ) (ω : Lk N → QBall) :
    zShift^[k] (perLift N ω) = perLift N ((tShift N)^[k] ω) := by
  induction k with
  | zero => rfl
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply', ih, zShift_lift]

end Lift

/-! ## the sequence of lifted measures -/

/-- the torus sizes `N_n = 2(n+1)` -/
def Nn (n : ℕ) : ℕ := 2 * (n + 1)

instance (n : ℕ) : NeZero (Nn n) := ⟨by unfold Nn; omega⟩

theorem Nn_eq (n : ℕ) : Nn n = 2 * (n + 1) := rfl

theorem Nn_half (n : ℕ) : Nn n / 2 = n + 1 := by unfold Nn; omega

/-- the periodic perLift to ℤ⁴ of the normalised Wilson measure on `(ℤ/N_n)⁴` -/
noncomputable def liftProb (β : ℝ) (n : ℕ) : ProbabilityMeasure Cfg :=
  (wilsonProb (Nn n) β).map (measurable_perLift (Nn n)).aemeasurable

theorem integral_lift (β : ℝ) (n : ℕ) (g : Cfg → ℝ) (hg : Continuous g) :
    ∫ x, g x ∂(liftProb β n : Measure Cfg)
      = ∫ ω, g (perLift (Nn n) ω) ∂(wilsonProb (Nn n) β : Measure (Lk (Nn n) → QBall)) := by
  rw [liftProb, ProbabilityMeasure.toMeasure_map,
    integral_map (measurable_perLift _).aemeasurable hg.aestronglyMeasurable]

/-! ## W: cylinder functions of the closed positive half -/

/-- `W` : bounded continuous functions depending only on finitely many links of the closed
positive half (base time `0 ≤ x₀ ≤ R`) -/
def Wsub : Submodule ℝ (Cfg →ᵇ ℝ) where
  carrier := {F | ∃ S : Finset ZLk, ∃ R : ℕ, (∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R) ∧
    ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y}
  add_mem' := by
    rintro F G ⟨S, R, hS, hF⟩ ⟨S', R', hS', hG⟩
    refine ⟨S ∪ S', max R R', fun ℓ hℓ => ?_, fun x y h => ?_⟩
    · rcases Finset.mem_union.1 hℓ with h | h
      · obtain ⟨a, b⟩ := hS ℓ h
        exact ⟨a, b.trans (by exact_mod_cast le_max_left R R')⟩
      · obtain ⟨a, b⟩ := hS' ℓ h
        exact ⟨a, b.trans (by exact_mod_cast le_max_right R R')⟩
    · rw [BoundedContinuousFunction.add_apply, BoundedContinuousFunction.add_apply,
        hF x y (fun ℓ hℓ => h ℓ (Finset.mem_union_left _ hℓ)),
        hG x y (fun ℓ hℓ => h ℓ (Finset.mem_union_right _ hℓ))]
  zero_mem' := by
    simp only [Set.mem_setOf_eq]
    exact ⟨∅, 0, by simp, fun x y _ => by simp⟩
  smul_mem' := by
    rintro a F ⟨S, R, hS, hF⟩
    exact ⟨S, R, hS, fun x y h => by
      rw [BoundedContinuousFunction.smul_apply, BoundedContinuousFunction.smul_apply, hF x y h]⟩

theorem mem_Wsub (F : Cfg →ᵇ ℝ) : F ∈ Wsub ↔ ∃ S : Finset ZLk, ∃ R : ℕ,
    (∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R) ∧ ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y := Iff.rfl

theorem one_mem_Wsub : (1 : Cfg →ᵇ ℝ) ∈ Wsub :=
  (mem_Wsub _).2 ⟨∅, 0, by simp, fun x y _ => by simp⟩

theorem shift_mem_Wsub : ∀ F ∈ Wsub, shiftMap zShiftC F ∈ Wsub := by
  intro F hF
  obtain ⟨S, R, hS, hdep⟩ := (mem_Wsub F).1 hF
  refine (mem_Wsub _).2 ⟨S.image (zsh 1), R + 1, ?_, ?_⟩
  · intro ℓ' hℓ'
    obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
    obtain ⟨a, b⟩ := hS ℓ hℓ
    rw [zsh_time]
    push_cast
    omega
  · intro x y h
    rw [shiftMap_apply, shiftMap_apply]
    apply hdep
    intro ℓ hℓ
    exact h _ (Finset.mem_image_of_mem _ hℓ)

/-! ## the hypotheses of statement G for the lifted Wilson measures -/

/-- a link of the closed positive half of ℤ⁴ with base time `≤ R` reduces into the closed
positive half `fixP ∨ posP` of the torus `(ℤ/N_n)⁴` once `R ≤ n` -/
theorem proj_closed (n : ℕ) (ℓ : ZLk) (R : ℕ) (h0 : 0 ≤ ℓ.1 0) (h1 : ℓ.1 0 ≤ R) (hn : R ≤ n) :
    fixP (Nn n) (n + 1) (zproj (Nn n) ℓ) ∨ posP (Nn n) (n + 1) (zproj (Nn n) ℓ) := by
  have ht : tm (Nn n) (zproj (Nn n) ℓ) = (ℓ.1 0).toNat :=
    val_intCast (Nn n) _ h0 (by simp only [Nn_eq]; push_cast; omega)
  unfold fixP posP
  rw [ht]
  by_cases h2 : (zproj (Nn n) ℓ).2 = 0
  · right
    rw [if_pos h2]
    omega
  · by_cases ht0 : (ℓ.1 0).toNat = 0
    · left
      exact ⟨h2, Or.inl ht0⟩
    · right
      rw [if_neg h2]
      omega

theorem abs_le_norm' (F : Cfg →ᵇ ℝ) (x : Cfg) : |F x| ≤ ‖F‖ := by
  have := F.norm_coe_le_norm x
  rwa [Real.norm_eq_abs] at this

/-- `hRP` (eventually, for each `F ∈ W`) -/
theorem rp_eventually (β : ℝ) (F : Cfg →ᵇ ℝ) (hF : F ∈ Wsub) :
    ∀ᶠ n in atTop, 0 ≤ ∫ x, F (zRefl x) * F x ∂(liftProb β n : Measure Cfg) := by
  obtain ⟨S, R, hSR, hdep⟩ := (mem_Wsub F).1 hF
  filter_upwards [eventually_ge_atTop R] with n hn
  have h1 := integral_lift β n (fun x => F (zRefl x) * F x)
    ((F.continuous.comp continuous_zRefl).mul F.continuous)
  simp only [zRefl_lift] at h1
  rw [h1]
  refine wilsonProb_rp (Nn n) (n + 1) rfl β (fun ω => F (perLift (Nn n) ω))
    ((F.continuous.comp (continuous_perLift _)).measurable) ‖F‖
    (fun ω => abs_le_norm' F _) (fun ω ω' h => ?_)
  apply hdep
  intro ℓ hℓ
  obtain ⟨h0, h1'⟩ := hSR ℓ hℓ
  exact h _ (proj_closed n ℓ R h0 h1' hn)

/-- `hsym` (for every `n`, every pair of bounded continuous functions) -/
theorem sym_lift (β : ℝ) (F G : Cfg →ᵇ ℝ) (n : ℕ) :
    ∫ x, F (zRefl x) * G x ∂(liftProb β n : Measure Cfg)
      = ∫ x, G (zRefl x) * F x ∂(liftProb β n : Measure Cfg) := by
  have h1 := integral_lift β n (fun x => F (zRefl x) * G x)
    ((F.continuous.comp continuous_zRefl).mul G.continuous)
  have h2 := integral_lift β n (fun x => G (zRefl x) * F x)
    ((G.continuous.comp continuous_zRefl).mul F.continuous)
  simp only [zRefl_lift] at h1 h2
  rw [h1, h2]
  exact wilsonProb_refl_symm (Nn n) (n + 1) rfl β (fun ω => F (perLift (Nn n) ω))
    (fun ω => G (perLift (Nn n) ω)) ((F.continuous.comp (continuous_perLift _)).measurable)
    ((G.continuous.comp (continuous_perLift _)).measurable)

/-- `hshift` (for every `n`, every pair of bounded continuous functions) -/
theorem shift_lift (β : ℝ) (F G : Cfg →ᵇ ℝ) (n : ℕ) :
    ∫ x, F (zShift (zRefl x)) * G x ∂(liftProb β n : Measure Cfg)
      = ∫ x, F (zRefl x) * G (zShift x) ∂(liftProb β n : Measure Cfg) := by
  have h1 := integral_lift β n (fun x => F (zShift (zRefl x)) * G x)
    ((F.continuous.comp (continuous_zShift.comp continuous_zRefl)).mul G.continuous)
  have h2 := integral_lift β n (fun x => F (zRefl x) * G (zShift x))
    ((F.continuous.comp continuous_zRefl).mul (G.continuous.comp continuous_zShift))
  simp only [zRefl_lift, zShift_lift] at h1 h2
  rw [h1, h2]
  exact wilsonProb_shift_pairing (Nn n) β (fun ω => F (perLift (Nn n) ω))
    (fun ω => G (perLift (Nn n) ω)) ((F.continuous.comp (continuous_perLift _)).measurable)
    ((G.continuous.comp (continuous_perLift _)).measurable)

/-- the trivial bound of a truncated correlation by `‖F‖²` -/
theorem pair_sub_sq_le (μ : ProbabilityMeasure Cfg) (F : Cfg →ᵇ ℝ) (a b : Cfg → Cfg)
    (ha : Continuous a) (hb : Continuous b) :
    ∫ x, F (a x) * F (b x) ∂(μ : Measure Cfg) - (∫ x, F x ∂(μ : Measure Cfg)) ^ 2
      ≤ ‖F‖ * ‖F‖ := by
  have hint : Integrable (fun x => F (a x) * F (b x)) (μ : Measure Cfg) :=
    BoundedContinuousFunction.integrable (μ : Measure Cfg)
      (F.compContinuous ⟨a, ha⟩ * F.compContinuous ⟨b, hb⟩)
  have hle : ∀ x, F (a x) * F (b x) ≤ ‖F‖ * ‖F‖ := fun x => by
    have h1 := abs_le_norm' F (a x)
    have h2 := abs_le_norm' F (b x)
    calc F (a x) * F (b x) ≤ |F (a x) * F (b x)| := le_abs_self _
      _ = |F (a x)| * |F (b x)| := abs_mul _ _
      _ ≤ ‖F‖ * ‖F‖ := mul_le_mul h1 h2 (abs_nonneg _) (norm_nonneg _)
  have key := integral_mono hint (integrable_const (‖F‖ * ‖F‖)) hle
  have e : ∫ _x, ‖F‖ * ‖F‖ ∂(μ : Measure Cfg) = ‖F‖ * ‖F‖ := by simp
  rw [e] at key
  nlinarith [sq_nonneg (∫ x, F x ∂(μ : Measure Cfg))]

theorem cpos (β : ℝ) (hβ0 : β ≠ 0) : 0 < 1 - (Real.exp (2 * |β|))⁻¹ ^ 2 := by
  have h0 : 0 < |β| := abs_pos.2 hβ0
  have h1 : 1 < Real.exp (2 * |β|) := Real.one_lt_exp_iff.2 (by linarith)
  have h2 : (Real.exp (2 * |β|))⁻¹ < 1 := inv_lt_one_of_one_lt₀ h1
  have h3 : 0 < (Real.exp (2 * |β|))⁻¹ := by positivity
  nlinarith

theorem exp_rate (q : ℝ) (hq : 0 < q) (k : ℕ) :
    Real.exp (-(2 * -Real.log q * (k : ℝ))) = q ^ (2 * k) := by
  rw [show -(2 * -Real.log q * (k : ℝ)) = ((2 * k : ℕ) : ℝ) * Real.log q by push_cast; ring,
    Real.exp_nat_mul, Real.exp_log hq]

/-- (b) `hdec` for `F ∈ W`: the support hypotheses `hdepΘ`, `hdepT` of `wilson_hdec_torus` are
discharged by the cylinder support (distance `d = 2k - 2` in time), and the constant `C` depends
on `F` only through `‖F‖` and the size of its support (not on `n`, not on `k`). -/
theorem dec_eventually (β : ℝ) (hβ0 : β ≠ 0) (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1)
    (F : Cfg →ᵇ ℝ) (hF : F ∈ Wsub) :
    ∃ C : ℝ, ∀ k : ℕ, ∀ᶠ n in atTop,
      ∫ x, F (zShift^[k] (zRefl x)) * F (zShift^[k] x) ∂(liftProb β n : Measure Cfg)
        - (∫ x, F x ∂(liftProb β n : Measure Cfg)) ^ 2
        ≤ C * Real.exp (-(2 * -Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) * (k : ℝ))) := by
  obtain ⟨S, R, hSR, hdep⟩ := (mem_Wsub F).1 hF
  have hc0 := cpos β hβ0
  have hq0 : 0 < 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) := by linarith
  refine ⟨max (‖F‖ * ‖F‖) (2 * ‖F‖ * ‖F‖ * 6 * ((1 - (Real.exp (2 * |β|))⁻¹ ^ 2) /
      (1 - 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) * S.card /
      (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) ^ 2), fun k => ?_⟩
  rw [exp_rate _ hq0 k]
  by_cases hk : k = 0
  · subst hk
    refine Eventually.of_forall (fun n => ?_)
    rw [mul_zero, pow_zero, mul_one]
    exact (pair_sub_sq_le _ F _ _ ((continuous_zShift.iterate 0).comp continuous_zRefl)
      (continuous_zShift.iterate 0)).trans (le_max_left _ _)
  · filter_upwards [eventually_ge_atTop (2 * k + 2 * R + 1)] with n hn
    have h1 := integral_lift β n (fun x => F (zShift^[k] (zRefl x)) * F (zShift^[k] x))
      ((F.continuous.comp ((continuous_zShift.iterate k).comp continuous_zRefl)).mul
        (F.continuous.comp (continuous_zShift.iterate k)))
    have h2 := integral_lift β n (fun x => F x) F.continuous
    simp only [zRefl_lift, zShift_iter_lift] at h1
    rw [h1, h2, integral_wilsonProb_gibbs, integral_wilsonProb_gibbs]
    have hA : ∀ ℓ' ∈ S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ))),
        cdist (Nn n) (ℓ'.1 0 - (((-((k : ℤ) + R + 1)) : ℤ) : ZMod (Nn n))) ≤ R + 1 := by
      intro ℓ' hℓ'
      obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
      obtain ⟨h0, h1'⟩ := hSR ℓ hℓ
      rw [proj_time, ← Int.cast_sub]
      refine (cdist_intCast_le (Nn n) _).trans ?_
      rw [zthL_time, zsh_snd, zsh_time]
      split_ifs <;> omega
    have hA' : ∀ ℓ' ∈ S.image (fun ℓ => zproj (Nn n) (zsh k ℓ)),
        R + 1 + 2 + (2 * k - 2) ≤
          cdist (Nn n) (ℓ'.1 0 - (((-((k : ℤ) + R + 1)) : ℤ) : ZMod (Nn n))) := by
      intro ℓ' hℓ'
      obtain ⟨ℓ, hℓ, rfl⟩ := Finset.mem_image.1 hℓ'
      obtain ⟨h0, h1'⟩ := hSR ℓ hℓ
      have hj0 : 0 ≤ ℓ.1 0 + (k : ℤ) - -((k : ℤ) + R + 1) := by omega
      have hj1 : (ℓ.1 0 + (k : ℤ) - -((k : ℤ) + R + 1)).toNat ≤ Nn n / 2 := by
        rw [Nn_half]; omega
      rw [proj_time, ← Int.cast_sub, zsh_time, cdist_intCast_eq (Nn n) _ hj0 hj1]
      omega
    have hdepΘ : ∀ x y : Lk (Nn n) → QBall,
        (∀ i ∈ S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ))), x i = y i) →
        (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] (linkRefl (thL (Nn n)) (sig (Nn n)) x))
          = (fun ω => F (perLift (Nn n) ω))
              ((tShift (Nn n))^[k] (linkRefl (thL (Nn n)) (sig (Nn n)) y)) := by
      intro x y hxy
      simp only [← zShift_iter_lift, ← zRefl_lift]
      apply hdep
      intro ℓ hℓ
      rw [zShift_iter_apply, zShift_iter_apply]
      show zsig (zsh k ℓ) (x (zproj (Nn n) (zthL (zsh k ℓ))))
        = zsig (zsh k ℓ) (y (zproj (Nn n) (zthL (zsh k ℓ))))
      rw [hxy _ (Finset.mem_image_of_mem _ hℓ)]
    have hdepT : ∀ x y : Lk (Nn n) → QBall,
        (∀ i ∈ S.image (fun ℓ => zproj (Nn n) (zsh k ℓ)), x i = y i) →
        (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] x)
          = (fun ω => F (perLift (Nn n) ω)) ((tShift (Nn n))^[k] y) := by
      intro x y hxy
      simp only [← zShift_iter_lift]
      apply hdep
      intro ℓ hℓ
      rw [zShift_iter_apply, zShift_iter_apply]
      exact hxy _ (Finset.mem_image_of_mem _ hℓ)
    have key := wilson_hdec_torus (Nn n) (n + 1) rfl β hβ k _ (R + 1) (2 * k - 2) _ _ hA hA'
      (fun ω => F (perLift (Nn n) ω)) ‖F‖ ((F.continuous.comp (continuous_perLift _)).measurable)
      (fun ω => abs_le_norm' F _) hdepΘ hdepT
    refine le_trans key ?_
    have hAc : ((S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ)))).card : ℝ) ≤ S.card := by
      exact_mod_cast Finset.card_image_le
    generalize (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) = c at hc0 hβ hq0 ⊢
    have h1q : 0 < 1 - 24 * c := by linarith
    have hpow : (24 * c) ^ (2 * k) = (24 * c) ^ (2 * k - 2) * (24 * c) ^ 2 := by
      rw [← pow_add]
      congr 1
      omega
    rw [hpow]
    have hK0 : 0 ≤ 2 * ‖F‖ * ‖F‖ * 6 * (c / (1 - 24 * c)) :=
      mul_nonneg (by positivity) (div_nonneg hc0.le h1q.le)
    have hqd : 0 ≤ (24 * c) ^ (2 * k - 2) := pow_nonneg hq0.le _
    have hq2 : (24 * c) ^ 2 ≠ 0 := pow_ne_zero 2 hq0.ne'
    calc 2 * ‖F‖ * ‖F‖ * (6 * ((S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ)))).card : ℝ) *
          (c * (24 * c) ^ (2 * k - 2) / (1 - 24 * c)))
        = (2 * ‖F‖ * ‖F‖ * 6 * (c / (1 - 24 * c))) *
            ((S.image (fun ℓ => zproj (Nn n) (zthL (zsh k ℓ)))).card : ℝ) *
            (24 * c) ^ (2 * k - 2) := by ring
      _ ≤ (2 * ‖F‖ * ‖F‖ * 6 * (c / (1 - 24 * c))) * (S.card : ℝ) * (24 * c) ^ (2 * k - 2) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hAc hK0) hqd
      _ = (2 * ‖F‖ * ‖F‖ * 6 * (c / (1 - 24 * c)) * (S.card : ℝ) / (24 * c) ^ 2) *
            ((24 * c) ^ (2 * k - 2) * (24 * c) ^ 2) := by
          rw [eq_comm, div_mul_eq_mul_div, div_eq_iff hq2]
          ring
      _ ≤ _ := mul_le_mul_of_nonneg_right (le_max_right _ _)
            (mul_nonneg hqd (pow_nonneg hq0.le _))

/-! ## (d) statement G at the weak limit points -/

/-- **Mass gap at every weak limit point (strong coupling, SU(2), ℤ⁴).**
For `β ≠ 0` with `24 (1 - e^{-4|β|}) < 1`, every weak limit point `ν` of the periodic lifts of the
normalised Wilson measures on `(ℤ/2(n+1))⁴` carries a reconstruction datum on the cylinder
functions `W` of the closed positive half whose transfer operator `T` satisfies
`‖T - P_Ω‖ ≤ e^{-m}` with `m = -ln(24 (1 - e^{-4|β|})) > 0` (`massGap_pos`).
Formalisation of a known result (Osterwalder–Seiler type); statement G = `massGap_of_measures_sub`
with all hypothesis fields discharged in Lean. -/
theorem wilson_massGap_limitPoint (β : ℝ) (hβ0 : β ≠ 0)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap (-Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) :=
  massGap_of_measures_sub (fun n => liftProb β (φ n)) ν hlim (ContinuousMap.id Cfg) zReflC zShiftC
    Wsub one_mem_Wsub shift_mem_Wsub
    (fun F hF => hφ.tendsto_atTop.eventually (rp_eventually β F hF))
    (fun F _ G _ => Eventually.of_forall (fun n => sym_lift β F G (φ n)))
    (fun F _ G _ => Eventually.of_forall (fun n => shift_lift β F G (φ n)))
    (-Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) (fun F hF => by
        obtain ⟨C, hC⟩ := dec_eventually β hβ0 hβ F hF
        exact ⟨C, fun k => hφ.tendsto_atTop.eventually (hC k)⟩)

/-- the rate is positive in the window -/
theorem massGap_pos (β : ℝ) (hβ0 : β ≠ 0) (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1) :
    0 < -Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) := by
  have hc0 := cpos β hβ0
  have : Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2)) < 0 := Real.log_neg (by linarith) hβ
  linarith

/-- an explicit window: `|β| < 1/96` gives the hypothesis `24 (1 - e^{-4|β|}) < 1` -/
theorem window_of_small (β : ℝ) (h : |β| < 1 / 96) :
    24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1 := by
  have e : (Real.exp (2 * |β|))⁻¹ ^ 2 = Real.exp (-(4 * |β|)) := by
    rw [← Real.exp_neg, ← Real.exp_nat_mul]
    congr 1
    first | (push_cast; ring) | push_cast | ring
  rw [e]
  have := Real.add_one_le_exp (-(4 * |β|))
  linarith

/-- weak limit points exist (compactness: `ProbabilityMeasure Cfg` is compact and metrizable,
Mathlib's `Prokhorov` instance) -/
theorem exists_limitPoint (β : ℝ) : ∃ ν : ProbabilityMeasure Cfg, ∃ φ : ℕ → ℕ,
    StrictMono φ ∧ Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν) := by
  obtain ⟨ν, -, φ, hφ, h⟩ :=
    (isCompact_univ : IsCompact (Set.univ : Set (ProbabilityMeasure Cfg))).tendsto_subseq
      (x := fun n => liftProb β n) (fun n => Set.mem_univ _)
  exact ⟨ν, φ, hφ, h⟩

/-- **Combined statement (no hypothesis besides the window).** -/
theorem wilson_massGap_exists (β : ℝ) (hβ0 : β ≠ 0)
    (hβ : 24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2) < 1) :
    ∃ ν : ProbabilityMeasure Cfg, ∃ φ : ℕ → ℕ, StrictMono φ ∧
      Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν) ∧
      ∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (24 * (1 - (Real.exp (2 * |β|))⁻¹ ^ 2))) := by
  obtain ⟨ν, φ, hφ, h⟩ := exists_limitPoint β
  exact ⟨ν, φ, hφ, h, wilson_massGap_limitPoint β hβ0 hβ ν φ hφ h⟩

end WilsonLimit

#print axioms TorusRP.wilsonProb_rp
#print axioms WilsonLimit.wilsonProb_refl_symm
#print axioms WilsonLimit.integral_wilsonProb_gibbs
#print axioms WilsonLimit.zRefl_lift
#print axioms WilsonLimit.zShift_iter_lift
#print axioms WilsonLimit.rp_eventually
#print axioms WilsonLimit.sym_lift
#print axioms WilsonLimit.shift_lift
#print axioms WilsonLimit.dec_eventually
#print axioms WilsonLimit.wilson_massGap_limitPoint
#print axioms WilsonLimit.massGap_pos
#print axioms WilsonLimit.window_of_small
#print axioms WilsonLimit.exists_limitPoint
#print axioms WilsonLimit.wilson_massGap_exists
