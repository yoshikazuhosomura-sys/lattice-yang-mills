import Lattice.WilsonDobV1

/-!
# The gauge-invariant sector: mass gap and non-degeneracy with a plaquette observable


* `GaugeZ.gaugeAct` : gauge transformations `g : ℤ⁴ → SU(2)` acting on link configurations of ℤ⁴,
  `(g·x)_ℓ = g(b) x_ℓ g(b + e_μ)*`.
* `GaugeZ.Wgi` : bounded continuous cylinder functions of the closed positive half that are gauge
  invariant; contains `1`, closed under the time shift.
* `GaugeZ.Fp` : real part of the holonomy of the plaquette at the origin in the plane `(1,2)`
  (time `0`, fixed by the reflection), gauge invariant (`Fp_gauge`).
* `GaugeZ.var_limit_ge_p` : at every weak limit point, `Var_ν(Fp) ≥ e^{-12|β|}/4`.
* `GaugeZ.wilson_massGap_gauge` : statement G on `Wgi` (mass gap `e^{-λ}` in the Dobrushin window)
  together with non-degeneracy in the gauge-invariant sector.
Formalisation of a known result.
-/

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth WilsonLimit
open scoped BoundedContinuousFunction InnerProductSpace

namespace GaugeZ

local notation "ℍr" => Quaternion ℝ

/-! ## quaternion facts -/

theorem unit_norm (g : SU2) : ‖(g : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp g.2

theorem star_mul_unit (g : SU2) : star (g : ℍr) * (g : ℍr) = 1 := by
  rw [Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self, unit_norm, mul_one]
  rfl

theorem re_mul_comm (a b : ℍr) : (a * b).re = (b * a).re := by
  simp only [Quaternion.re_mul]; ring

theorem re_conj (a q : ℍr) (ha : star a * a = 1) : (a * q * star a).re = q.re := by
  rw [re_mul_comm, ← mul_assoc, ha, one_mul]

/-! ## gauge transformations on ℤ⁴ -/

/-- unit vector of ℤ⁴ -/
def zev (μ : Fin 4) : ZSite := Pi.single μ 1

/-- `g q h*` stays in the unit ball -/
noncomputable def gq (g h : SU2) (q : QBall) : QBall :=
  ⟨(g : ℍr) * (q : ℍr) * star (h : ℍr), by
    rw [mem_closedBall_zero_iff, norm_mul, norm_mul, norm_star, unit_norm, unit_norm, one_mul,
      mul_one]
    exact mem_closedBall_zero_iff.1 q.2⟩

/-- the gauge transformation `g` acting on configurations -/
noncomputable def gaugeAct (g : ZSite → SU2) (x : Cfg) : Cfg :=
  fun ℓ => gq (g ℓ.1) (g (ℓ.1 + zev ℓ.2)) (x ℓ)

/-- gauge-invariant bounded continuous functions -/
noncomputable def Winv : Submodule ℝ (Cfg →ᵇ ℝ) where
  carrier := {F | ∀ g x, F (gaugeAct g x) = F x}
  add_mem' := by
    intro F G hF hG g x
    rw [BoundedContinuousFunction.add_apply, BoundedContinuousFunction.add_apply, hF g x, hG g x]
  zero_mem' := fun _ _ => rfl
  smul_mem' := by
    intro a F hF g x
    rw [BoundedContinuousFunction.smul_apply, BoundedContinuousFunction.smul_apply, hF g x]

/-- `W_gi = W ∩ (gauge invariant)` -/
noncomputable def Wgi : Submodule ℝ (Cfg →ᵇ ℝ) := Wsub ⊓ Winv

theorem one_mem_Wgi : (1 : Cfg →ᵇ ℝ) ∈ Wgi :=
  Submodule.mem_inf.2 ⟨one_mem_Wsub, fun _ _ => rfl⟩

theorem zsh1_eq (ℓ : ZLk) : zsh 1 ℓ = (ℓ.1 + zev 0, ℓ.2) := by
  simp [zsh, zev]

theorem zShift_gauge (g : ZSite → SU2) (x : Cfg) :
    zShift (gaugeAct g x) = gaugeAct (fun s => g (s + zev 0)) (zShift x) := by
  funext ℓ
  show gaugeAct g x (zsh 1 ℓ) = gq (g (ℓ.1 + zev 0)) (g (ℓ.1 + zev ℓ.2 + zev 0)) (x (zsh 1 ℓ))
  rw [zsh1_eq]
  show gq (g (ℓ.1 + zev 0)) (g (ℓ.1 + zev 0 + zev ℓ.2)) _ = _
  rw [add_right_comm]

theorem shift_mem_Wgi : ∀ F ∈ Wgi, shiftMap zShiftC F ∈ Wgi := by
  intro F hF
  obtain ⟨h1, h2⟩ := Submodule.mem_inf.1 hF
  refine Submodule.mem_inf.2 ⟨shift_mem_Wsub F h1, fun g x => ?_⟩
  show F (zShift (gaugeAct g x)) = F (zShift x)
  rw [zShift_gauge]
  exact h2 _ _

theorem mem_Wsub_of_Wgi {F : Cfg →ᵇ ℝ} (hF : F ∈ Wgi) : F ∈ Wsub := (Submodule.mem_inf.1 hF).1

/-! ## the plaquette observable -/

def la : ZLk := (0, 1)
def lb : ZLk := (zev 1, 2)
def lc : ZLk := (zev 2, 1)
def ld : ZLk := (0, 2)

/-- holonomy of the plaquette at the origin in the plane `(1,2)` -/
noncomputable def holP (x : Cfg) : ℍr :=
  (x la : ℍr) * (x lb : ℍr) * star (x lc : ℍr) * star (x ld : ℍr)

theorem continuous_holP : Continuous holP := by
  unfold holP
  have c : ∀ ℓ : ZLk, Continuous (fun x : Cfg => (x ℓ : ℍr)) := fun ℓ =>
    continuous_subtype_val.comp (continuous_apply ℓ)
  exact (((c la).mul (c lb)).mul (continuous_star.comp (c lc))).mul (continuous_star.comp (c ld))

/-- `F_p x = Re U_p` -/
noncomputable def Fp : Cfg →ᵇ ℝ :=
  BoundedContinuousFunction.mkOfCompact ⟨fun x => (holP x).re, Quaternion.continuous_re.comp continuous_holP⟩

theorem Fp_apply (x : Cfg) : Fp x = (holP x).re := rfl

theorem holP_gauge (g : ZSite → SU2) (x : Cfg) :
    holP (gaugeAct g x) = (g 0 : ℍr) * holP x * star (g 0 : ℍr) := by
  unfold holP gaugeAct gq
  simp only [la, lb, lc, ld, zev, zero_add]
  have e : (Pi.single 2 1 : ZSite) + Pi.single 1 1 = Pi.single 1 1 + Pi.single 2 1 := add_comm _ _
  rw [e]
  set a : ℍr := (g 0 : ℍr)
  set b : ℍr := (g (Pi.single 1 1) : ℍr)
  set c : ℍr := (g (Pi.single 1 1 + Pi.single 2 1) : ℍr)
  set d : ℍr := (g (Pi.single 2 1) : ℍr)
  have hb : ∀ z : ℍr, star b * (b * z) = z := fun z => by
    rw [← mul_assoc, star_mul_unit, one_mul]
  have hc : ∀ z : ℍr, star c * (c * z) = z := fun z => by
    rw [← mul_assoc, star_mul_unit, one_mul]
  have hd : ∀ z : ℍr, star d * (d * z) = z := fun z => by
    rw [← mul_assoc, star_mul_unit, one_mul]
  simp only [star_mul, star_star, mul_assoc, hb, hc, hd]

theorem Fp_gauge (g : ZSite → SU2) (x : Cfg) : Fp (gaugeAct g x) = Fp x := by
  rw [Fp_apply, Fp_apply, holP_gauge, re_conj _ _ (star_mul_unit _)]

theorem zthL_fix (ℓ : ZLk) (h2 : ℓ.2 ≠ 0) (h0 : ℓ.1 0 = 0) : zthL ℓ = ℓ := by
  unfold zthL
  rw [if_neg h2]
  refine Prod.ext (funext fun i => ?_) rfl
  simp only [zthS]
  split_ifs with hi
  · subst hi; rw [h0]; simp
  · rfl

theorem zRefl_fix (x : Cfg) (ℓ : ZLk) (h2 : ℓ.2 ≠ 0) (h0 : ℓ.1 0 = 0) : zRefl x ℓ = x ℓ := by
  show zsig ℓ (x (zthL ℓ)) = x ℓ
  rw [zthL_fix ℓ h2 h0]
  unfold zsig
  rw [if_neg h2]
  rfl

theorem Fp_refl (x : Cfg) : Fp (zRefl x) = Fp x := by
  rw [Fp_apply, Fp_apply]
  unfold holP
  rw [zRefl_fix x la (by decide) rfl, zRefl_fix x lb (by decide) (by simp [lb, zev]),
    zRefl_fix x lc (by decide) (by simp [lc, zev]), zRefl_fix x ld (by decide) rfl]

theorem Fp_mem : Fp ∈ Wgi := by
  refine Submodule.mem_inf.2 ⟨(mem_Wsub _).2 ⟨{la, lb, lc, ld}, 0, ?_, ?_⟩, Fp_gauge⟩
  · intro ℓ hℓ
    simp only [Finset.mem_insert, Finset.mem_singleton] at hℓ
    rcases hℓ with rfl | rfl | rfl | rfl <;> simp [la, lb, lc, ld, zev]
  · intro x y h
    rw [Fp_apply, Fp_apply]
    unfold holP
    rw [h la (by simp), h lb (by simp), h lc (by simp), h ld (by simp)]

/-! ## the variance of the plaquette in finite volume -/

section Torus

variable (N : ℕ) [NeZero N]

/-- the four links of the plaquette on the torus -/
def pa : Lk N := zproj N la
def pb : Lk N := zproj N lb
def pc : Lk N := zproj N lc
def pd : Lk N := zproj N ld

noncomputable def restV (ω : Lk N → QBall) : ℍr :=
  (ω (pb N) : ℍr) * star (ω (pc N) : ℍr) * star (ω (pd N) : ℍr)

noncomputable def holT (ω : Lk N → QBall) : ℍr :=
  (ω (pa N) : ℍr) * (ω (pb N) : ℍr) * star (ω (pc N) : ℍr) * star (ω (pd N) : ℍr)

theorem holP_lift (ω : Lk N → QBall) : holP (perLift N ω) = holT N ω := rfl

theorem pb_ne : pb N ≠ pa N := fun h => by
  have := congrArg Prod.snd h
  simp [pb, pa, zproj, lb, la] at this

theorem pd_ne : pd N ≠ pa N := fun h => by
  have := congrArg Prod.snd h
  simp [pd, pa, zproj, ld, la] at this

theorem pc_ne (hN : 2 ≤ N) : pc N ≠ pa N := fun h => by
  haveI : Fact (1 < N) := ⟨by omega⟩
  have := congrFun (congrArg Prod.fst h) 2
  simp [pc, pa, zproj, lc, la, zev] at this

theorem holT_update (hN : 2 ≤ N) (ω : Lk N → QBall) (U : QBall) :
    holT N (Function.update ω (pa N) U) = (U : ℍr) * restV N ω := by
  unfold holT restV
  rw [Function.update_self, Function.update_of_ne (pb_ne N), Function.update_of_ne (pc_ne N hN),
    Function.update_of_ne (pd_ne N)]
  simp only [mul_assoc]

theorem ae_unit (β : ℝ) :
    ∀ᵐ ω ∂(wilsonMeasure N β), ∀ ℓ, ‖((ω ℓ : QBall) : ℍr)‖ = 1 := by
  have h1 : ∀ ℓ : Lk N, ∀ᵐ ω ∂(Measure.pi fun _ : Lk N => haarBall), ‖((ω ℓ : QBall) : ℍr)‖ = 1 := by
    intro ℓ
    have hm : MeasurableSet {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ :=
      ((isClosed_eq (continuous_norm.comp continuous_subtype_val) continuous_const).measurableSet).compl
    have hs : haarBall {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ = 0 := by
      rw [haarBall, Measure.map_apply continuous_incl.measurable hm]
      have : incl ⁻¹' {U : QBall | ‖(U : ℍr)‖ = 1}ᶜ = ∅ := by
        ext q
        simp only [Set.mem_preimage, Set.mem_compl_iff, Set.mem_setOf_eq, Set.mem_empty_iff_false,
          iff_false, not_not]
        exact unit_norm q
      rw [this, measure_empty]
    have := Measure.pi_eval_preimage_null (fun _ : Lk N => haarBall) (i := ℓ) hs
    rw [ae_iff]
    exact this
  rw [ae_all_iff]
  intro ℓ
  unfold wilsonMeasure
  exact (withDensity_absolutelyContinuous _ _).ae_le (h1 ℓ)

/-- Haar: `∫ (Re(U V) - c)² dU ≥ 1/4` for a unit quaternion `V` -/
theorem haar_sq_sub_ge_V (V : ℍr) (hV : ‖V‖ = 1) (c : ℝ) :
    1 / 4 ≤ ∫ U, ((((U : QBall) : ℍr) * V).re - c) ^ 2 ∂haarBall := by
  have hc : Continuous (fun U : QBall => ((((U : QBall) : ℍr) * V).re - c) ^ 2) :=
    ((Quaternion.continuous_re.comp (continuous_subtype_val.mul continuous_const)).sub
      continuous_const).pow 2
  rw [haarBall, integral_map continuous_incl.measurable.aemeasurable hc.aestronglyMeasurable]
  have hn : Quaternion.normSq V = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, hV, mul_one]
  have h := integral_mul_left_eq_self (μ := haarSU2) (fun q => (HaarRe.c0 q - c) ^ 2) (HaarRe.mk V hn)
  have e : ∀ q : SU2, (HaarRe.c0 (HaarRe.mk V hn * q) - c) ^ 2 = ((((incl q : QBall) : ℍr) * V).re - c) ^ 2 :=
    fun q => by
      unfold HaarRe.c0
      rw [HaarRe.coe_mul, re_mul_comm]
      rfl
  simp only [e] at h
  rw [h]
  exact HaarRe.integral_sq_sub_ge c

theorem wilsonProb_plaq_ge (hN : 2 ≤ N) (β c : ℝ) :
    Real.exp (-(12 * |β|)) / 4 ≤
      ∫ ω, ((holT N ω).re - c) ^ 2 ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  set H : (Lk N → QBall) → ℝ := fun ω => ((holT N ω).re - c) ^ 2 with hHdef
  have hcont : Continuous (fun ω : Lk N → QBall => holT N ω) := by
    unfold holT
    have cc : ∀ ℓ : Lk N, Continuous (fun ω : Lk N → QBall => (ω ℓ : ℍr)) := fun ℓ =>
      continuous_subtype_val.comp (continuous_apply ℓ)
    exact (((cc _).mul (cc _)).mul (continuous_star.comp (cc _))).mul (continuous_star.comp (cc _))
  have hHc : Continuous H := ((Quaternion.continuous_re.comp hcont).sub continuous_const).pow 2
  have hH : Measurable H := hHc.measurable
  have hb1 : ∀ ω, |((holT N ω).re)| ≤ 1 := fun ω => by
    have h1 : ‖holT N ω‖ ≤ 1 := by
      unfold holT
      rw [norm_mul, norm_mul, norm_mul, norm_star, norm_star]
      have := fun ℓ => mem_closedBall_zero_iff.1 (ω ℓ).2
      have h0 := fun ℓ => norm_nonneg ((ω ℓ : QBall) : ℍr)
      calc _ ≤ (1 : ℝ) * 1 * 1 * 1 := by gcongr <;> exact this _
        _ = 1 := by norm_num
    have h3 : ((holT N ω).re) ^ 2 ≤ ‖holT N ω‖ ^ 2 := by
      rw [sq ‖holT N ω‖, ← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
      nlinarith [sq_nonneg (holT N ω).imI, sq_nonneg (holT N ω).imJ, sq_nonneg (holT N ω).imK]
    have h4 := (sq_le_sq.1 h3).trans_eq (abs_norm _)
    linarith
  have hHb : ∀ ω, |H ω| ≤ (1 + |c|) ^ 2 := fun ω => by
    simp only [hHdef]
    rw [abs_pow]
    have : |(holT N ω).re - c| ≤ 1 + |c| := (abs_sub _ _).trans (by linarith [hb1 ω])
    exact pow_le_pow_left₀ (abs_nonneg _) this 2
  have hdlr := LinkSpec.dlr N β (pa N) H hH _ hHb
  have hf := (LinkSpec.update_preserving N (pa N)).measurable
  have hNum : Measurable (fun ω => LinkSpec.specNum N β (pa N) H ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        H (Function.update z.1 (pa N) z.2) * Real.exp (LinkSpec.locAct N β z.1 (pa N) z.2)) :=
      ((hH.comp hf).mul (Real.continuous_exp.comp
        (LinkSpec.continuous_locAct₂ N β (pa N))).measurable).stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hDen : Measurable (fun ω => LinkSpec.specDen N β (pa N) ω) := by
    have : StronglyMeasurable (fun z : (Lk N → QBall) × QBall =>
        Real.exp (LinkSpec.locAct N β z.1 (pa N) z.2)) :=
      (Real.continuous_exp.comp (LinkSpec.continuous_locAct₂ N β (pa N))).measurable.stronglyMeasurable
    exact this.integral_prod_right'.measurable
  have hint : Integrable (fun ω => LinkSpec.specNum N β (pa N) H ω / LinkSpec.specDen N β (pa N) ω)
      (wilsonMeasure N β) :=
    Integrable.of_bound (hNum.div hDen).aestronglyMeasurable _
      (Eventually.of_forall fun ω => by
        rw [Real.norm_eq_abs]; exact LinkSpec.abs_spec_le N β (pa N) _ hH _ hHb ω)
  -- pointwise bound where the rest of the plaquette is a unit quaternion
  have hpt : ∀ ω, ‖restV N ω‖ = 1 → Real.exp (-(12 * |β|)) / 4 ≤
      LinkSpec.specNum N β (pa N) H ω / LinkSpec.specDen N β (pa N) ω := by
    intro ω hV
    have h6 : |β| * (LinkSpec.plaqsAt N (pa N)).card ≤ 6 * |β| := by
      have := LinkSpec.plaqsAt_card_le N (pa N)
      have : ((LinkSpec.plaqsAt N (pa N)).card : ℝ) ≤ 6 := by exact_mod_cast this
      nlinarith [abs_nonneg β]
    have hlo : ∀ U, Real.exp (-(6 * |β|)) ≤ Real.exp (LinkSpec.locAct N β ω (pa N) U) := fun U => by
      apply Real.exp_le_exp.2
      have := LinkSpec.abs_locAct_le N β ω (pa N) U
      have := neg_abs_le (LinkSpec.locAct N β ω (pa N) U)
      linarith
    have hhi : ∀ U, Real.exp (LinkSpec.locAct N β ω (pa N) U) ≤ Real.exp (6 * |β|) := fun U => by
      apply Real.exp_le_exp.2
      have := LinkSpec.abs_locAct_le N β ω (pa N) U
      have := le_abs_self (LinkSpec.locAct N β ω (pa N) U)
      linarith
    have hd := LinkSpec.specDen_pos N β (pa N) ω
    have hcU : Continuous (fun U : QBall => ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2) :=
      ((Quaternion.continuous_re.comp (continuous_subtype_val.mul continuous_const)).sub
        continuous_const).pow 2
    have hnum : LinkSpec.specNum N β (pa N) H ω = ∫ U, ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2 *
        Real.exp (LinkSpec.locAct N β ω (pa N) U) ∂haarBall := by
      unfold LinkSpec.specNum
      simp only [hHdef, holT_update N hN]
    have hnum_ge : Real.exp (-(6 * |β|)) * (1 / 4) ≤ LinkSpec.specNum N β (pa N) H ω := by
      rw [hnum]
      have hint1 : Integrable (fun U : QBall => Real.exp (-(6 * |β|)) *
          ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2) haarBall :=
        HaarRe.integrable_cont haarBall _ (continuous_const.mul hcU)
      have hint2 : Integrable (fun U : QBall => ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2 *
          Real.exp (LinkSpec.locAct N β ω (pa N) U)) haarBall :=
        HaarRe.integrable_cont haarBall _
          (hcU.mul (Real.continuous_exp.comp (LinkSpec.continuous_locAct N β ω (pa N))))
      calc Real.exp (-(6 * |β|)) * (1 / 4)
          ≤ Real.exp (-(6 * |β|)) * ∫ U, ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2 ∂haarBall :=
            mul_le_mul_of_nonneg_left (haar_sq_sub_ge_V _ hV c) (Real.exp_pos _).le
        _ = ∫ U, Real.exp (-(6 * |β|)) * ((((U : QBall) : ℍr) * restV N ω).re - c) ^ 2 ∂haarBall :=
            (integral_const_mul _ _).symm
        _ ≤ _ := integral_mono hint1 hint2 (fun U => by
            rw [mul_comm]
            exact mul_le_mul_of_nonneg_left (hlo U) (sq_nonneg _))
    have hden_le : LinkSpec.specDen N β (pa N) ω ≤ Real.exp (6 * |β|) := by
      unfold LinkSpec.specDen
      calc ∫ U, Real.exp (LinkSpec.locAct N β ω (pa N) U) ∂haarBall ≤ ∫ _U, Real.exp (6 * |β|) ∂haarBall :=
            integral_mono (LinkSpec.integrable_exp_locAct N β (pa N) ω) (integrable_const _) hhi
        _ = Real.exp (6 * |β|) := by simp
    rw [le_div_iff₀ hd]
    have e12 : Real.exp (-(12 * |β|)) = Real.exp (-(6 * |β|)) * (Real.exp (6 * |β|))⁻¹ := by
      rw [← Real.exp_neg, ← Real.exp_add]; ring_nf
    calc Real.exp (-(12 * |β|)) / 4 * LinkSpec.specDen N β (pa N) ω
        ≤ Real.exp (-(12 * |β|)) / 4 * Real.exp (6 * |β|) :=
          mul_le_mul_of_nonneg_left hden_le (by positivity)
      _ = Real.exp (-(6 * |β|)) * (1 / 4) := by
          rw [e12]; field_simp
      _ ≤ _ := hnum_ge
  have hae : ∀ᵐ ω ∂(wilsonMeasure N β), Real.exp (-(12 * |β|)) / 4 ≤
      LinkSpec.specNum N β (pa N) H ω / LinkSpec.specDen N β (pa N) ω := by
    filter_upwards [ae_unit N β] with ω hω
    apply hpt
    unfold restV
    rw [norm_mul, norm_mul, norm_star, norm_star, hω, hω, hω, one_mul, one_mul]
  have hmono : ∫ _ω, Real.exp (-(12 * |β|)) / 4 ∂(wilsonMeasure N β)
      ≤ ∫ ω, LinkSpec.specNum N β (pa N) H ω / LinkSpec.specDen N β (pa N) ω ∂(wilsonMeasure N β) :=
    integral_mono_ae (integrable_const _) hint hae
  rw [← hdlr, integral_const, smul_eq_mul] at hmono
  have hpos : 0 < (wilsonMeasure N β).real Set.univ := by
    rw [measureReal_def]
    exact ENNReal.toReal_pos (wilsonMeasure_univ_pos N β).ne' (wilsonMeasure_univ_lt_top N β).ne
  rw [wilsonProb_toMeasure, integral_smul_measure, smul_eq_mul, ENNReal.toReal_inv,
    ← measureReal_def]
  rw [le_inv_mul_iff₀ hpos]
  exact hmono

end Torus

/-- finite volume, lifted: `Var_{μ_n}(F_p) ≥ e^{-12|β|}/4` -/
theorem var_lift_ge_p (β : ℝ) (n : ℕ) :
    Real.exp (-(12 * |β|)) / 4 ≤ ∫ x, Fp x * Fp x ∂(liftProb β n : Measure Cfg)
      - (∫ x, Fp x ∂(liftProb β n : Measure Cfg)) ^ 2 := by
  rw [← integral_sq_sub_mean]
  set c := ∫ y, Fp y ∂(liftProb β n : Measure Cfg)
  have hcont : Continuous (fun x : Cfg => (Fp x - c) ^ 2) := (Fp.continuous.sub continuous_const).pow 2
  rw [integral_lift β n _ hcont]
  exact wilsonProb_plaq_ge (Nn n) (by unfold Nn; omega) β c

/-- **At every weak limit point, `Var_ν(Re U_p) ≥ e^{-12|β|}/4`** (gauge-invariant observable). -/
theorem var_limit_ge_p (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    Real.exp (-(12 * |β|)) / 4 ≤ ∫ x, Fp x * Fp x ∂(ν : Measure Cfg)
      - (∫ x, Fp x ∂(ν : Measure Cfg)) ^ 2 := by
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
  have h2 := h (Fp * Fp)
  have h1 := h Fp
  simp only [BoundedContinuousFunction.coe_mul, Pi.mul_apply] at h2
  exact ge_of_tendsto' (h2.sub (h1.pow 2)) (fun n => var_lift_ge_p β (φ n))

/-- **Mass gap with non-degeneracy in the gauge-invariant sector (Dobrushin window).**
The reconstruction on `W_gi` (gauge-invariant cylinder functions): `‖T - P_Ω‖ ≤ e^{-λ}`, the
reflected variance of the plaquette `Re U_p` is `≥ e^{-12|β|}/4`, and a unit vector orthogonal
to the vacuum exists.  -/
theorem wilson_massGap_gauge (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wgi,
      (∀ F G : Wgi, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
      ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨D, hB, hτ, hone, hgap⟩ :=
    massGap_of_measures_sub (fun n => liftProb β (φ n)) ν hlim (ContinuousMap.id Cfg) zReflC zShiftC
      Wgi one_mem_Wgi shift_mem_Wgi
      (fun F hF => hφ.tendsto_atTop.eventually (rp_eventually β F (mem_Wsub_of_Wgi hF)))
      (fun F _ G _ => Eventually.of_forall (fun n => sym_lift β F G (φ n)))
      (fun F _ G _ => Eventually.of_forall (fun n => shift_lift β F G (φ n)))
      lam (fun F hF => by
        obtain ⟨C, hC⟩ := dec_eventually_dob β lam hlam.le hα F (mem_Wsub_of_Wgi hF)
        exact ⟨C, fun k => hφ.tendsto_atTop.eventually (hC k)⟩)
  have hFF : D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ = ∫ x, Fp x * Fp x ∂(ν : Measure Cfg) := by
    rw [hB]
    show ∫ x, Fp (zRefl x) * Fp x ∂(ν : Measure Cfg) = _
    simp only [Fp_refl]
  have h1F : D.B D.one ⟨Fp, Fp_mem⟩ = ∫ x, Fp x ∂(ν : Measure Cfg) := by
    rw [hB, hone]
    show ∫ x, (1 : Cfg →ᵇ ℝ) (zRefl x) * Fp x ∂(ν : Measure Cfg) = _
    simp only [BoundedContinuousFunction.coe_one, Pi.one_apply, one_mul]
  have hvar : Real.exp (-(12 * |β|)) / 4 ≤
      D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 := by
    rw [hFF, h1F]
    exact var_limit_ge_p β ν φ hlim
  exact ⟨D, hB, hτ, hone, hgap, hvar, D.exists_unit_orth _ (lt_of_lt_of_le (by positivity) hvar)⟩

/-- **Combined, gauge-invariant sector** (hypotheses `β ≠ 0`, `18 tanh|β| < 1`). -/
theorem wilson_massGap_gauge_exists (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃ ν : ProbabilityMeasure Cfg, ∃ φ : ℕ → ℕ, StrictMono φ ∧
      Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν) ∧
      ∃ D : Datum Wgi,
        (∀ F G : Wgi, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
        ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1 := by
  obtain ⟨ν, φ, hφ, h⟩ := exists_limitPoint β
  obtain ⟨hl, hα⟩ := dob_rate β hβ0 hq
  exact ⟨ν, φ, hφ, h, wilson_massGap_gauge β _ hl hα ν φ hφ h⟩

end GaugeZ

#print axioms GaugeZ.holP_gauge
#print axioms GaugeZ.Fp_gauge
#print axioms GaugeZ.Fp_mem
#print axioms GaugeZ.shift_mem_Wgi
#print axioms GaugeZ.ae_unit
#print axioms GaugeZ.wilsonProb_plaq_ge
#print axioms GaugeZ.var_limit_ge_p
#print axioms GaugeZ.wilson_massGap_gauge
#print axioms GaugeZ.wilson_massGap_gauge_exists
