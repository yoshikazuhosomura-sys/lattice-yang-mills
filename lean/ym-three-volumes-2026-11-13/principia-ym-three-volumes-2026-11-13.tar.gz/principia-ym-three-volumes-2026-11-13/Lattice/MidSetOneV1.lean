import Lattice.MidPlaneV1

/-!
# Setting the crossing links to `1` commutes with the middle-plane reflection

`MidRP.setOne_linkRefl` : `setOne ∘ Θ′ = Θ′ ∘ setOne` (the crossing links are fixed by `thM`).
`MidRP.linkRefl_true_eq` : on configurations with the crossing links equal to `1`, the reflection
with `star` on all temporal links (`sigT`) equals the one with `id` on the crossing links (`sigM`).
-/

namespace MidRP

open MeasureTheory TorusRP LinkReflection TorusGauge GaugeFix

variable (N : ℕ) [NeZero N]

/-- the reflection of the values with `star` on every temporal link -/
noncomputable def sigT (ℓ : Lk N) : QBall → QBall := if ℓ.2 = 0 then starB else id

theorem thM_not_cr (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ℓ : Lk N) (h : ¬ cr N M ℓ) :
    ¬ cr N M (thM N ℓ) := fun h' => by
  have e := (hfix_mid N M hN hM _ h').1
  rw [thM_invol N ℓ] at e
  exact h (e ▸ h')

theorem setOne_linkRefl (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ω : Lk N → QBall) :
    setOne (cr N M) (linkRefl (thM N) (sigM N M) ω)
      = linkRefl (thM N) (sigM N M) (setOne (cr N M) ω) := by
  funext ℓ
  unfold setOne linkRefl
  dsimp only
  by_cases h : cr N M ℓ
  · obtain ⟨e1, e2⟩ := hfix_mid N M hN hM ℓ h
    rw [if_pos h, e1, if_pos h, e2]
  · rw [if_neg h, if_neg (thM_not_cr N M hN hM ℓ h)]

theorem starB_oneB : starB oneB = oneB := by
  apply Subtype.ext
  show star (1 : Quaternion ℝ) = 1
  exact star_one _

theorem linkRefl_true_eq (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (ω : Lk N → QBall) :
    linkRefl (thM N) (sigT N) (setOne (cr N M) ω)
      = linkRefl (thM N) (sigM N M) (setOne (cr N M) ω) := by
  funext ℓ
  unfold linkRefl sigT sigM
  by_cases h : cr N M ℓ
  · have e1 := (hfix_mid N M hN hM ℓ h).1
    have hset : setOne (cr N M) ω (thM N ℓ) = oneB := by
      rw [e1]; unfold setOne; rw [if_pos h]
    rw [hset, if_neg (show ¬(ℓ.2 = 0 ∧ ¬ cr N M ℓ) from fun h' => h'.2 h)]
    split_ifs
    · exact starB_oneB
    · rfl
  · by_cases h2 : ℓ.2 = 0
    · rw [if_pos h2, if_pos ⟨h2, h⟩]
    · rw [if_neg h2, if_neg (show ¬(ℓ.2 = 0 ∧ ¬ cr N M ℓ) from fun h' => h2 h'.1)]

end MidRP

#print axioms MidRP.setOne_linkRefl
#print axioms MidRP.linkRefl_true_eq
