import Wilson.ParityV1
import Wilson.AbsV1
import Wilson.Q8TwistV2

/-!
# 弦の張力の形の床と、鎖の全体の確認

`thin_vortex_floor`：β ≠ 0 なら `|Z₀ − Z₁|/(Z₀ + Z₁) ≤ exp(−σ₀ M²)`、`σ₀ = −ln tanh(N²|β|) > 0`
（ の「薄い渦の床 σ_N(β) ≥ −ln tanh(N²β)」の、有限の M ごとの形）。
このファイルは鎖の最後：書き出した全てのモジュールを import し、主な宣言の公理を表示する。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem tanh_pos_of_pos {L : ℝ} (hL : 0 < L) : 0 < Real.tanh L := by
  rw [Real.tanh_eq_sinh_div_cosh]
  exact div_pos (Real.sinh_pos_iff.mpr hL) (Real.cosh_pos L)

/-- **薄い渦の床（指数の形）**：`β ≠ 0` なら `σ₀ := −ln tanh(N²|β|) > 0` で、全ての `M ≥ 1` で
`|Z₀ − Z₁|/(Z₀ + Z₁) ≤ exp(−σ₀ M²)`。仮定は `β ≠ 0` だけ（`β = 0` では両辺とも意味を失う：
tanh 0 = 0）。 -/
theorem thin_vortex_floor (β : ℝ) (hβ : β ≠ 0) (n12 : Bool) :
    0 < -Real.log (Real.tanh ((N : ℝ) ^ 2 * |β|)) ∧
    |ZW N M β n12 false - ZW N M β n12 true| / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.exp (-(-Real.log (Real.tanh ((N : ℝ) ^ 2 * |β|))) * (M : ℝ) ^ 2) := by
  have hN : (0 : ℝ) < (N : ℝ) ^ 2 := by
    have : (0 : ℝ) < N := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne N))
    positivity
  have hL : 0 < (N : ℝ) ^ 2 * |β| := mul_pos hN (abs_pos.mpr hβ)
  have hs := tanh_pos_of_pos hL
  have hs1 := Real.tanh_lt_one ((N : ℝ) ^ 2 * |β|)
  refine ⟨neg_pos.mpr (Real.log_neg hs hs1), ?_⟩
  have hb := twisted_vortex_bound_abs N M β n12
  have e : Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)
      = Real.exp (-(-Real.log (Real.tanh ((N : ℝ) ^ 2 * |β|))) * (M : ℝ) ^ 2) := by
    have h2 : Real.log (Real.tanh ((N : ℝ) ^ 2 * |β|)) * (M : ℝ) ^ 2
        = Real.log (Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)) := by
      rw [Real.log_pow]; push_cast; ring
    rw [neg_neg, h2, Real.exp_log (pow_pos hs _)]
  rw [← e]
  exact hb

end TwistedWilson

#print axioms TwistedPlane.plane_flip_ratio
#print axioms TwistedPlane.exists_chi2_eq
#print axioms TwistedWilson.z2_four_covers_two
#print axioms TwistedWilson.z2_four_ratio
#print axioms TwistedWilson.su2_dominated
#print axioms TwistedWilson.twisted_vortex_bound
#print axioms TwistedWilson.twisted_vortex_bound_unfolded
#print axioms TwistedWilson.twisted_vortex_bound_abs
#print axioms TwistedWilson.twisted_ratio_lower
#print axioms TwistedWilson.vortex_free_energy_bound
#print axioms TwistedWilson.su2_dominated_general
#print axioms TwistedWilson.ZEta_gauge
#print axioms TwistedWilson.ZEta_flip_any
#print axioms TwistedWilson.ZEta_parity
#print axioms TwistedQ8.q8_vortex_bound
#print axioms TwistedWilson.thin_vortex_floor
