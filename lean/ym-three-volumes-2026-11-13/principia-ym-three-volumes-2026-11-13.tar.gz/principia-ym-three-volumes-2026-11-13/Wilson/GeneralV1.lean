import Wilson.SU2TwistV2

/-!
# 定理 F の SU(2) の Wilson 測度への当てはめ：面ごとの結合と任意の底の系

`su2_dominated`（`Wilson.SU2TwistV2`）を、面ごとの実の結合 `β_B`（捩れの背景は `β_B` の符号に
入れる）と、任意の Z₂ の底の系 `(G₀, χ₀, p)`（`χ_B(p t) = χ₀_B(t)`）に広げた形。太い渦の床
のように別の底の系を使うときの差し込み口。

`(∫ exp(Σ_B β_B Re U_B) dμ) · Z₀(ζ|β|) ≤ (∫ exp(Σ_B ζ_B β_B Re U_B) dμ) · Z₀(|β|)`、
`μ` = SU(2) の正規化した Haar 測度の直積、`ζ_B = ±1`。仮定は底の系の三つ（指標であること、引き戻しの式）と
`ζ = ±1` だけ。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- **定理 F（SU(2) の Wilson 測度、面ごとの結合、任意の底の系）**。 -/
theorem su2_dominated_general {G₀ : Type*} [Fintype G₀] [Group G₀]
    (χ₀ : Plaq N M → G₀ → ℝ) (hχ₀ : ∀ B, IsSignChar (χ₀ B)) (p : G₀ → (Link N M → ℤˣ))
    (hp : ∀ B t, chiB N M B (p t) = χ₀ B t)
    (β ζ : Plaq N M → ℝ) (hζ : ∀ B, ζ B = 1 ∨ ζ B = -1) :
    (∫ ω, Real.exp (∑ B, β B * (hol N M ω B).re) ∂(haarCfg N M)) * Z χ₀ (fun B => ζ B * |β B|)
      ≤ (∫ ω, Real.exp (∑ B, ζ B * β B * (hol N M ω B).re) ∂(haarCfg N M))
          * Z χ₀ (fun B => |β B|) := by
  have h := invariant_dominated (haarCfg N M) (haarCfg_inv N M)
    (chiB N M) (chiB_isSignChar N M) χ₀ hχ₀ p hp (fun B ω => Jc N M 1 β B ω)
    (fun B g ω => by
      show 1 * β B * (hol N M (g • ω) B).re = chiB N M B g * (1 * β B * (hol N M ω B).re)
      rw [hol_smul]; ring)
    (fun B => |β B|) ζ
    (fun B ω => by
      show |1 * β B * (hol N M ω B).re| ≤ |β B|
      rw [one_mul, abs_mul]
      exact mul_le_of_le_one_right (abs_nonneg _) (abs_re_le_one _ (norm_hol N M ω B)))
    hζ (fun c => integrable_exp N M 1 β c)
  have e0 : (fun ω => Real.exp (∑ B, Jc N M 1 β B ω))
      = fun ω => Real.exp (∑ B, β B * (hol N M ω B).re) := by
    funext ω; congr 1; refine Finset.sum_congr rfl fun B _ => ?_; unfold Jc; ring
  have e1 : (fun ω => Real.exp (∑ B, ζ B * Jc N M 1 β B ω))
      = fun ω => Real.exp (∑ B, ζ B * β B * (hol N M ω B).re) := by
    funext ω; congr 1; refine Finset.sum_congr rfl fun B _ => ?_; unfold Jc; ring
  simp only [e0, e1] at h
  exact h

/-- 仮定の欄が実際の対象で満たせる例：底を二次元のトーラスの Z₂ のゲージ理論（`chi0`・`pull`）、
結合を一様な `β` に背景の捩れ `z(n₁₂,0)` を掛けたもの、`ζ = z(0,1)` にすると `su2_dominated` に戻る。 -/
theorem su2_dominated_general_instance (β : ℝ) (n12 : Bool) :
    (∫ ω, Real.exp (∑ B, (β * zt N M n12 false B) * (hol N M ω B).re) ∂(haarCfg N M))
        * Z (chi0 N M) (fun B => zt N M false true B * |β * zt N M n12 false B|)
      ≤ (∫ ω, Real.exp (∑ B, zt N M false true B * (β * zt N M n12 false B) * (hol N M ω B).re)
          ∂(haarCfg N M)) * Z (chi0 N M) (fun B => |β * zt N M n12 false B|) :=
  su2_dominated_general N M (chi0 N M) (chi0_isSignChar N M) (pull N M) (fun _ _ => rfl)
    (fun B => β * zt N M n12 false B) (zt N M false true)
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)

end TwistedWilson

#print axioms TwistedWilson.su2_dominated_general
#print axioms TwistedWilson.su2_dominated_general_instance
