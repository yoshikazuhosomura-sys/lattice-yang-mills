import Wilson.SU2TwistV2

/-!
# (3,4) の面の符号の場 η による表示と、その中心のゲージ不変性

太い渦の床の段 1「η の表示」の、Lean で閉じる部分。η : (二次元の面) → ℝ に対し、
(3,4) の面 `((x₁,x₂),(x₃,x₄))` の結合を `η(x₃,x₄)` 倍した SU(2) の分配関数を `ZEta η` とする
（横の N² 枚に同じ倍率）。

* `ZEta_gauge`：二次元の任意の Z₂ の場 `t` について `ZEta (η · χ²ᴰ(t)) = ZEta η`
  （切り口の反転 `U ↦ pull(t)·U` が Haar 測度を保つことから）。
* `ZEta_one`・`ZEta_flip`：`ZW β n₁₂ 0 = ZEta 1`、`ZW β n₁₂ 1 = ZEta (面 0 だけ −1)`。
* `ZEta_flip_any`：捩れの位置に依らない：全ての `P` で `ZEta (面 P だけ −1) = ZW β n₁₂ 1`。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- (3,4) の面に η を載せる -/
noncomputable def etaB (η : Pt M → ℝ) (B : Plaq N M) : ℝ := if B.2 = p23 then η B.1.2 else 1

/-- η つきの分配関数 -/
noncomputable def ZEta (β : ℝ) (n12 : Bool) (η : Pt M → ℝ) : ℝ :=
  ∫ ω, Real.exp (β * ∑ B, zt N M n12 false B * etaB N M η B * (hol N M ω B).re) ∂(haarCfg N M)

/-- **中心のゲージ不変性**：`ZEta (η · χ²ᴰ(t)) = ZEta η`。 -/
theorem ZEta_gauge (β : ℝ) (n12 : Bool) (η : Pt M → ℝ) (t : Cfg2 M) :
    ZEta N M β n12 (fun y => η y * chi2 M y t) = ZEta N M β n12 η := by
  unfold ZEta
  rw [← haarCfg_inv N M (pull N M t)
    (fun ω => Real.exp (β * ∑ B, zt N M n12 false B * etaB N M η B * (hol N M ω B).re))]
  congr 1
  funext ω
  beta_reduce
  congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  show zt N M n12 false B * etaB N M (fun y => η y * chi2 M y t) B * (hol N M ω B).re
    = zt N M n12 false B * etaB N M η B * (hol N M (pull N M t • ω) B).re
  rw [hol_smul]
  have h := chi0_eq N M B t
  unfold chi0 at h
  rw [h]
  unfold etaB
  by_cases hB : B.2 = p23
  · simp only [if_pos hB]; beta_reduce; ring
  · simp only [if_neg hB]; ring

theorem ZEta_one (β : ℝ) (n12 : Bool) : ZEta N M β n12 (fun _ => 1) = ZW N M β n12 false := by
  unfold ZEta ZW etaB
  congr 1; funext ω; congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  split_ifs <;> simp

/-- 面 `P` だけ符号を変える η -/
noncomputable def etaAt (P : Pt M) : Pt M → ℝ := fun y => if y = P then -1 else 1

theorem ZEta_flip (β : ℝ) (n12 : Bool) : ZEta N M β n12 (etaAt M 0) = ZW N M β n12 true := by
  unfold ZEta ZW
  congr 1; funext ω; congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  rw [← zt_mul N M n12 B, zt_false_true]
  unfold etaB etaAt
  by_cases hB : B.2 = p23
  · by_cases h0 : B.1.2 = 0 <;> simp [hB, h0] <;> ring
  · simp [hB]

theorem chi2_one (y : Pt M) : chi2 M y 1 = 1 := by
  simp [chi2, Pi.one_apply, sgn]

/-- 捩れを一歩動かす（第二の向き）：`ZEta(η_P) = ZEta(η_{P − e₂})`。 -/
theorem ZEta_move2 (β : ℝ) (n12 : Bool) (P : Pt M) :
    ZEta N M β n12 (etaAt M (P - e2 M)) = ZEta N M β n12 (etaAt M P) := by
  rw [← ZEta_gauge N M β n12 (etaAt M P) (flipAt M (P, 0))]
  congr 1
  funext y
  have h := chi2_flip0 M P y 1
  rw [one_mul, chi2_one, mul_one] at h
  rw [h]
  unfold etaAt
  by_cases h1 : y = P
  · by_cases h2 : y = P - e2 M
    · rw [if_pos h1, if_pos h2]; norm_num
    · rw [if_pos h1, if_neg h2]; norm_num
  · by_cases h2 : y = P - e2 M
    · rw [if_neg h1, if_pos h2]; norm_num
    · rw [if_neg h1, if_neg h2]; norm_num

/-- 捩れを一歩動かす（第一の向き）：`ZEta(η_P) = ZEta(η_{P − e₁})`。 -/
theorem ZEta_move1 (β : ℝ) (n12 : Bool) (P : Pt M) :
    ZEta N M β n12 (etaAt M (P - e1 M)) = ZEta N M β n12 (etaAt M P) := by
  rw [← ZEta_gauge N M β n12 (etaAt M P) (flipAt M (P, 1))]
  congr 1
  funext y
  have h := chi2_flip1 M P y 1
  rw [one_mul, chi2_one, mul_one] at h
  rw [h]
  unfold etaAt
  by_cases h1 : y = P
  · by_cases h2 : y = P - e1 M
    · rw [if_pos h1, if_pos h2]; norm_num
    · rw [if_pos h1, if_neg h2]; norm_num
  · by_cases h2 : y = P - e1 M
    · rw [if_neg h1, if_pos h2]; norm_num
    · rw [if_neg h1, if_neg h2]; norm_num

/-- **捩れの位置に依らない**：全ての `P` で `ZEta(面 P だけ −1) = Z₁`。 -/
theorem ZEta_flip_any (β : ℝ) (n12 : Bool) (P : Pt M) :
    ZEta N M β n12 (etaAt M P) = ZW N M β n12 true := by
  have k1 : ∀ n : ℕ, ∀ Q : Pt M,
      ZEta N M β n12 (etaAt M (Q - ((n : ZMod M), (0 : ZMod M)))) = ZEta N M β n12 (etaAt M Q) := by
    intro n
    induction n with
    | zero => intro Q; congr 2; ext <;> simp
    | succ n ih =>
      intro Q
      rw [← ih Q, ← ZEta_move1 N M β n12 (Q - ((n : ZMod M), (0 : ZMod M)))]
      congr 2
      simp only [e1, Nat.cast_succ]
      ext <;> simp only [Prod.fst_sub, Prod.snd_sub] <;> ring
  have k2 : ∀ n : ℕ, ∀ Q : Pt M,
      ZEta N M β n12 (etaAt M (Q - ((0 : ZMod M), (n : ZMod M)))) = ZEta N M β n12 (etaAt M Q) := by
    intro n
    induction n with
    | zero => intro Q; congr 2; ext <;> simp
    | succ n ih =>
      intro Q
      rw [← ih Q, ← ZEta_move2 N M β n12 (Q - ((0 : ZMod M), (n : ZMod M)))]
      congr 2
      simp only [e2, Nat.cast_succ]
      ext <;> simp only [Prod.fst_sub, Prod.snd_sub] <;> ring
  have e : (0 : Pt M) = P - (((P.1).val : ZMod M), (0 : ZMod M)) - ((0 : ZMod M), ((P.2).val : ZMod M)) := by
    simp only [ZMod.natCast_zmod_val]
    ext <;> simp only [Prod.fst_sub, Prod.snd_sub, Prod.fst_zero, Prod.snd_zero] <;> ring
  rw [← ZEta_flip N M β n12, e, k2, k1]

end TwistedWilson

#print axioms TwistedWilson.ZEta_gauge
#print axioms TwistedWilson.ZEta_one
#print axioms TwistedWilson.ZEta_flip
#print axioms TwistedWilson.ZEta_flip_any
