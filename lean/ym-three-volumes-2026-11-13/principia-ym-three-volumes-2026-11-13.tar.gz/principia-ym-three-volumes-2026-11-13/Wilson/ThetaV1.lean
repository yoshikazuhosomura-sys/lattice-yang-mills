import Wilson.FloorV3

/-!
# 't Hooft の比を η の平均として：`(Z₀ − Z₁)/(Z₀ + Z₁) = Σ_η (Πη) Z[η] / Σ_η Z[η]`

の段 1（η の表示）の、Lean で閉じる形。η は二次元の面の符号の場（`Pt M → ℤˣ`）全部を走る。
右辺は、配位 (U, η) の同時の測度 `∝ exp(β Σ z η Re U) dU` の下での `Πη` の期待値。
証明は `ZEta_parity`（Z[η] は Πη だけで決まる）と、`η ↦ η·(面 0 の反転)` で Πη = ±1 の個数が等しいこと。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 符号の場の Πη（実数） -/
noncomputable def piSgn (η : Pt M → ℤˣ) : ℝ := ∏ y, sgn (η y)

theorem piSgn_or (η : Pt M → ℤˣ) : piSgn M η = 1 ∨ piSgn M η = -1 :=
  prod_sign_or M (fun y => sgn (η y)) (fun y => sgn_isSignChar.2 (η y))

/-- 面 0 だけ −1 の符号の場 -/
def e0 : Pt M → ℤˣ := Pi.mulSingle 0 (-1)

theorem piSgn_mul_e0 (η : Pt M → ℤˣ) : piSgn M (η * e0 M) = -piSgn M η := by
  unfold piSgn
  have h : ∀ y, sgn ((η * e0 M) y) = sgn (η y) * (if y = 0 then -1 else 1) := by
    intro y
    rw [Pi.mul_apply, sgn_mul']
    congr 1
    unfold e0
    rw [Pi.mulSingle_apply]
    split_ifs <;> simp [sgn]
  simp only [h, Finset.prod_mul_distrib, prod_sign_ite, Finset.mem_univ, if_true]
  ring

theorem ZEta_sgn (β : ℝ) (n12 : Bool) (η : Pt M → ℤˣ) :
    ZEta N M β n12 (fun y => sgn (η y))
      = if piSgn M η = 1 then ZW N M β n12 false else ZW N M β n12 true :=
  ZEta_parity N M β n12 (fun y => sgn (η y)) (fun y => sgn_isSignChar.2 (η y))

/-- **'t Hooft の比 = η の平均**。 -/
theorem theta_eq_eta_average (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      = (∑ η : Pt M → ℤˣ, piSgn M η * ZEta N M β n12 (fun y => sgn (η y)))
        / (∑ η : Pt M → ℤˣ, ZEta N M β n12 (fun y => sgn (η y))) := by
  set Z0 := ZW N M β n12 false
  set Z1 := ZW N M β n12 true
  let c : (Pt M → ℤˣ) → ℝ := fun η => if piSgn M η = 1 then 1 else 0
  let d : (Pt M → ℤˣ) → ℝ := fun η => if piSgn M η = 1 then 0 else 1
  have hcd : ∑ η, c η = ∑ η, d η := by
    rw [← Fintype.sum_equiv (Equiv.mulRight (e0 M)) (fun η => c (η * e0 M)) c (fun _ => rfl)]
    refine Finset.sum_congr rfl fun η _ => ?_
    show (if piSgn M (η * e0 M) = 1 then (1 : ℝ) else 0) = if piSgn M η = 1 then 0 else 1
    rw [piSgn_mul_e0]
    rcases piSgn_or M η with h | h <;> rw [h] <;> norm_num
  have h1 : ∑ η : Pt M → ℤˣ, ZEta N M β n12 (fun y => sgn (η y))
      = (∑ η, c η) * Z0 + (∑ η, d η) * Z1 := by
    rw [Finset.sum_mul, Finset.sum_mul, ← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun η _ => ?_
    rw [ZEta_sgn]
    show _ = (if piSgn M η = 1 then (1 : ℝ) else 0) * Z0 + (if piSgn M η = 1 then (0 : ℝ) else 1) * Z1
    split_ifs <;> ring
  have h2 : ∑ η : Pt M → ℤˣ, piSgn M η * ZEta N M β n12 (fun y => sgn (η y))
      = (∑ η, c η) * Z0 - (∑ η, d η) * Z1 := by
    rw [Finset.sum_mul, Finset.sum_mul, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun η _ => ?_
    rw [ZEta_sgn]
    show _ = (if piSgn M η = 1 then (1 : ℝ) else 0) * Z0 - (if piSgn M η = 1 then (0 : ℝ) else 1) * Z1
    rcases piSgn_or M η with h | h
    · rw [if_pos h, if_pos h, if_pos h, h]; ring
    · have hn : piSgn M η ≠ 1 := by rw [h]; norm_num
      rw [if_neg hn, if_neg hn, if_neg hn, h]; ring
  have hS : 0 < ∑ η, c η := by
    have h1' : piSgn M (1 : Pt M → ℤˣ) = 1 := by
      unfold piSgn; simp [sgn]
    have hle : c 1 ≤ ∑ η, c η :=
      Finset.single_le_sum (f := c) (fun η _ => by
        show (0 : ℝ) ≤ if piSgn M η = 1 then 1 else 0
        split_ifs <;> norm_num) (Finset.mem_univ 1)
    have hc1 : c 1 = 1 := by show (if piSgn M 1 = 1 then (1 : ℝ) else 0) = 1; rw [if_pos h1']
    linarith
  rw [h1, h2, ← hcd]
  rw [← mul_sub, ← mul_add, mul_div_mul_left _ _ hS.ne']

end TwistedWilson

#print axioms TwistedWilson.theta_eq_eta_average
#print axioms TwistedWilson.twisted_vortex_bound
