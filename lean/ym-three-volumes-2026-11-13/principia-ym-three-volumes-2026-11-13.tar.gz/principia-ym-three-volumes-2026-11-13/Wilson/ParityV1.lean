import Wilson.EtaV2

/-!
# η の表示は Πη だけで決まる

* `sum_prod_affine`：二次元の Z₂ のゲージ理論で `Σ_t Π_y (a_y + χ_y(t) b_y) = |配位| (Π a + Π b)`
  （`Z_plane` の芯を任意の係数で）。
* `exists_chi2_eq`：η = ±1 で Πη = 1 なら、`χ_y(t) = η_y`（全ての y）となる二次元の場 t がある。
  証明は数え上げ：`a = ½`、`b = η/2` と置くと左辺の各項は「t の面の符号が η と一致するか」の指示関数で、
  右辺は `|配位|·2^{−M²}(1 + Πη) > 0`。
* `ZEta_parity`：η = ±1 なら `ZEta η = Z₀`（Πη = 1）、`= Z₁`（Πη = −1）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedPlane

variable (M : ℕ) [NeZero M]

/-- 高温展開の閉じた式（任意の係数）。 -/
theorem sum_prod_affine (a b : Pt M → ℝ) :
    ∑ t : Cfg2 M, ∏ y, (a y + chi2 M y t * b y)
      = (Fintype.card (Cfg2 M) : ℝ) * (∏ y, a y + ∏ y, b y) := by
  have hexp : ∀ t : Cfg2 M, ∏ y, (a y + chi2 M y t * b y)
      = ∑ A ∈ (Finset.univ : Finset (Pt M)).powerset,
          (∏ y ∈ A, b y) * (∏ y ∈ Finset.univ \ A, a y) * FA M A t := by
    intro t
    have h1 : ∀ y, a y + chi2 M y t * b y = chi2 M y t * b y + a y := fun y => add_comm _ _
    simp only [h1]
    rw [Finset.prod_add]
    refine Finset.sum_congr rfl fun A _ => ?_
    unfold FA
    rw [Finset.prod_mul_distrib]
    ring
  simp only [hexp]
  rw [Finset.sum_comm]
  have hterm : ∀ A ∈ (Finset.univ : Finset (Pt M)).powerset,
      ∑ t : Cfg2 M, (∏ y ∈ A, b y) * (∏ y ∈ Finset.univ \ A, a y) * FA M A t
        = (∏ y ∈ A, b y) * (∏ y ∈ Finset.univ \ A, a y) * ∑ t : Cfg2 M, FA M A t := by
    intro A _
    rw [Finset.mul_sum]
  rw [Finset.sum_congr rfl hterm]
  have hne : (∅ : Finset (Pt M)) ≠ Finset.univ := by
    intro h
    have : (0 : Pt M) ∈ (∅ : Finset (Pt M)) := h ▸ Finset.mem_univ _
    simp at this
  rw [Finset.sum_eq_add_of_mem ∅ Finset.univ (Finset.empty_mem_powerset _)
    (Finset.mem_powerset_self _) hne (fun A _ hA => by
      rw [sum_FA_eq_zero M A (fun h => h.elim hA.1 hA.2), mul_zero])]
  have f0 : ∀ t, FA M ∅ t = 1 := fun t => by simp [FA]
  have f1 : ∀ t, FA M Finset.univ t = 1 := fun t => prod_chi2_univ M t
  simp only [f0, f1, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one,
    Finset.prod_empty, one_mul, Finset.sdiff_empty, Finset.sdiff_self]
  ring

theorem prod_sign_or (η : Pt M → ℝ) (hη : ∀ y, η y = 1 ∨ η y = -1) :
    ∏ y, η y = 1 ∨ ∏ y, η y = -1 := by
  refine Finset.prod_induction η (fun r => r = 1 ∨ r = -1) ?_ (Or.inl rfl) (fun y _ => hη y)
  intro a b ha hb
  rcases ha with h | h <;> rcases hb with h' | h' <;> rw [h, h'] <;> norm_num

/-- **面の符号の実現**：η = ±1、Πη = 1 なら、`χ_y(t) = η_y` となる t がある。 -/
theorem exists_chi2_eq (η : Pt M → ℝ) (hη : ∀ y, η y = 1 ∨ η y = -1) (hprod : ∏ y, η y = 1) :
    ∃ t : Cfg2 M, ∀ y, chi2 M y t = η y := by
  by_contra hno
  push_neg at hno
  have hs : ∑ t : Cfg2 M, ∏ y, ((1 : ℝ) / 2 + chi2 M y t * (η y * (1 / 2)))
      = (Fintype.card (Cfg2 M) : ℝ) * (∏ _y : Pt M, (1 : ℝ) / 2 + ∏ y, η y * (1 / 2)) :=
    sum_prod_affine M (fun _ => (1 : ℝ) / 2) (fun y => η y * (1 / 2))
  have hl : ∑ t : Cfg2 M, ∏ y, ((1 : ℝ) / 2 + chi2 M y t * (η y * (1 / 2))) = 0 := by
    refine Finset.sum_eq_zero fun t _ => ?_
    obtain ⟨y, hy⟩ := hno t
    refine Finset.prod_eq_zero (Finset.mem_univ y) ?_
    have hsq : η y * η y = 1 := by rcases hη y with h | h <;> rw [h] <;> norm_num
    have key : chi2 M y t = -η y := by
      rcases (chi2_isSignChar M y).2 t with hc | hc <;> rcases hη y with he | he <;> simp_all
    rw [key]
    linear_combination (-1 / 2 : ℝ) * hsq
  rw [hl] at hs
  have hW : (0 : ℝ) < Fintype.card (Cfg2 M) := Nat.cast_pos.mpr Fintype.card_pos
  have hb : ∏ y : Pt M, η y * (1 / 2) = (∏ y, η y) * ∏ _y : Pt M, ((1 : ℝ) / 2) :=
    Finset.prod_mul_distrib
  rw [hb, hprod, one_mul] at hs
  have hp : (0 : ℝ) < ∏ _y : Pt M, ((1 : ℝ) / 2) := Finset.prod_pos fun _ _ => by norm_num
  nlinarith

end TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem prod_etaAt : ∏ y : Pt M, etaAt M 0 y = -1 := by
  simp only [etaAt]
  rw [prod_sign_ite M Finset.univ 0]
  simp

/-- **η の表示は Πη だけで決まる**：η = ±1 なら `ZEta η = Z₀`（Πη = 1）、`= Z₁`（Πη = −1）。 -/
theorem ZEta_parity (β : ℝ) (n12 : Bool) (η : Pt M → ℝ) (hη : ∀ y, η y = 1 ∨ η y = -1) :
    ZEta N M β n12 η = if ∏ y, η y = 1 then ZW N M β n12 false else ZW N M β n12 true := by
  split_ifs with hp
  · obtain ⟨t, ht⟩ := exists_chi2_eq M η hη hp
    have e : η = fun y => (fun _ => (1 : ℝ)) y * chi2 M y t := by
      funext y; show η y = 1 * chi2 M y t; rw [ht y, one_mul]
    rw [e, ZEta_gauge, ZEta_one]
  · have hm : ∏ y, η y = -1 := (prod_sign_or M η hη).resolve_left hp
    have hη' : ∀ y, η y * etaAt M 0 y = 1 ∨ η y * etaAt M 0 y = -1 := by
      intro y
      unfold etaAt
      rcases hη y with h | h <;> split_ifs <;> rw [h] <;> norm_num
    have hp' : ∏ y, η y * etaAt M 0 y = 1 := by
      rw [Finset.prod_mul_distrib, hm, prod_etaAt]; norm_num
    obtain ⟨t, ht⟩ := exists_chi2_eq M (fun y => η y * etaAt M 0 y) hη' hp'
    have e : η = fun y => etaAt M 0 y * chi2 M y t := by
      funext y
      show η y = etaAt M 0 y * chi2 M y t
      rw [ht y]
      show η y = etaAt M 0 y * (η y * etaAt M 0 y)
      simp only [etaAt]
      split_ifs <;> ring
    rw [e, ZEta_gauge, ZEta_flip]

end TwistedWilson

#print axioms TwistedPlane.sum_prod_affine
#print axioms TwistedPlane.exists_chi2_eq
#print axioms TwistedWilson.ZEta_parity
