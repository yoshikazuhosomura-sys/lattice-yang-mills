import Covering.IneqV10
import Plane.TwistedZ2V2

/-!
# 捩れた SU(2) の Wilson の格子ゲージ理論の渦の比の下限（全ての β・N・M）

紙： の目標の言明（壁⑦、薄い渦の床）。既知の型の結果（Mack–Petkova, Ann. Phys. 123 (1979)；
Fröhlich, Phys. Lett. 83B (1979) の線）の形式化。抽象の定理 F・C は `Covering.IneqV10`
（`CoveringInequality.v10.lean` の写し）、二次元の Z₂ の閉じた式は `Plane.TwistedZ2V1`。

## 定義の約束
* 格子：`Site N M = (ZMod N × ZMod N) × (ZMod M × ZMod M)`（座標 `(x₁,x₂), (x₃,x₄)`）。
  向き `μ ∈ Fin 4`（`0,1,2,3` が紙の `1,2,3,4`）、単位 `ev μ`。リンク `(x, μ)`。
* 面：`(x, (μ,ν))`、`μ < ν`（無向、六つの向きの組）。面の四本のリンク
  `(x,μ), (x+e_μ,ν), (x+e_ν,μ), (x,ν)`。`N = 1` や `M = 1` でリンクが重なっても、重なったまま数える。
* SU(2)：単位四元数 `Metric.sphere (0 : ℍ) 1`（群）。リンクの測度は正規化した Haar 測度
  `Measure.haarMeasure ⊤`、配位の測度はその直積 `Measure.pi`。
* ホロノミー `U_p = U(x,μ) U(x+μ,ν) U(x+ν,μ)* U(x,ν)*`（四元数の積）、`Re U_p = ½ tr U_p ∈ [−1,1]`。
* 捩れ：`n₁₂` は (1,2) の面のうち `(x₁,x₂) = (0,0)` のもの、`n₃₄` は (3,4) の面のうち
  `(x₃,x₄) = (0,0)` のものの符号を `(−1)^n` にする（`Bool` の `true` が `n = 1`）。
* 分配関数 `ZW β n₁₂ n₃₄ = ∫ exp(β Σ_p z_p Re U_p) dμ`。

## 主定理
`twisted_vortex_bound`：全ての `N, M ≥ 1`、全ての実数 `β`、`n₁₂ ∈ {0,1}` で
`(Z₀ − Z₁)/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`、`Z_k = ZW β n₁₂ k`。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

local notation "ℍr" => Quaternion ℝ

/-! ## SU(2) と Haar 測度 -/

/-- `SU(2)` = 単位四元数の群 -/
abbrev SU2 : Type := Metric.sphere (0 : ℍr) 1

noncomputable instance : MeasurableSpace SU2 := borel SU2
instance : BorelSpace SU2 := ⟨rfl⟩

/-- コンパクト群の正規化した Haar 測度（`TorusWilsonRP.v3.lean` の `haarProb` と同じ定義） -/
noncomputable def haarProb (G : Type*) [Group G] [TopologicalSpace G] [IsTopologicalGroup G]
    [CompactSpace G] [MeasurableSpace G] [BorelSpace G] : Measure G :=
  Measure.haarMeasure ⊤

instance haarProb_isProbabilityMeasure (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    IsProbabilityMeasure (haarProb G) := by
  refine ⟨?_⟩
  have h : haarProb G ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 :=
    Measure.haarMeasure_self
  rwa [TopologicalSpace.PositiveCompacts.coe_top] at h

instance haarProb_isMulLeftInvariant (G : Type*) [Group G] [TopologicalSpace G]
    [IsTopologicalGroup G] [CompactSpace G] [MeasurableSpace G] [BorelSpace G] :
    (haarProb G).IsMulLeftInvariant := by
  unfold haarProb; infer_instance

/-- `SU(2)` の正規化した Haar 測度 -/
noncomputable abbrev haarSU2 : Measure SU2 := haarProb SU2

/-- 中心 `±1`：`ℤˣ → SU(2)` -/
noncomputable def cen (u : ℤˣ) : SU2 :=
  ⟨(((u : ℤ) : ℝ) : ℍr), by
    rw [mem_sphere_zero_iff_norm, Quaternion.norm_coe]
    rcases Int.units_eq_one_or u with h | h <;> simp [h]⟩

theorem coe_cen (u : ℤˣ) : ((cen u : SU2) : ℍr) = ((sgn u : ℝ) : ℍr) := rfl

noncomputable def cenHom : ℤˣ →* SU2 where
  toFun := cen
  map_one' := by
    apply Subtype.ext
    rw [coe_cen, Metric.unitSphere.coe_one]
    simp [sgn]
  map_mul' a b := by
    apply Subtype.ext
    rw [Metric.unitSphere.coe_mul, coe_cen, coe_cen, coe_cen, sgn_mul', Quaternion.coe_mul]

/-! ## 格子 -/

variable (N M : ℕ) [NeZero N] [NeZero M]

abbrev Site := (ZMod N × ZMod N) × (ZMod M × ZMod M)
abbrev Link := Site N M × Fin 4
abbrev Plane := {p : Fin 4 × Fin 4 // p.1 < p.2}
abbrev Plaq := Site N M × Plane

/-- 単位のずれ -/
def ev : Fin 4 → Site N M :=
  ![((1, 0), (0, 0)), ((0, 1), (0, 0)), ((0, 0), (1, 0)), ((0, 0), (0, 1))]

/-- 面の四本のリンク -/
def l1 (B : Plaq N M) : Link N M := (B.1, B.2.1.1)
def l2 (B : Plaq N M) : Link N M := (B.1 + ev N M B.2.1.1, B.2.1.2)
def l3 (B : Plaq N M) : Link N M := (B.1 + ev N M B.2.1.2, B.2.1.1)
def l4 (B : Plaq N M) : Link N M := (B.1, B.2.1.2)

/-- (1,2) と (3,4) の向きの組 -/
def p01 : Plane := ⟨(0, 1), by decide⟩
def p23 : Plane := ⟨(2, 3), by decide⟩

/-- 捩れの符号 -/
def tw (b : Bool) : ℝ := if b then -1 else 1

/-- 背景 `(n₁₂, n₃₄)` の面の符号 -/
noncomputable def zt (n12 n34 : Bool) (B : Plaq N M) : ℝ :=
  (if B.2 = p01 ∧ B.1.1 = 0 then tw n12 else 1) * (if B.2 = p23 ∧ B.1.2 = 0 then tw n34 else 1)

/-- 面のホロノミー（四元数） -/
noncomputable def hol (ω : Link N M → SU2) (B : Plaq N M) : ℍr :=
  (ω (l1 N M B) : ℍr) * (ω (l2 N M B) : ℍr) * star (ω (l3 N M B) : ℍr) * star (ω (l4 N M B) : ℍr)

/-- 配位の測度：リンクごとの Haar 測度の直積 -/
noncomputable def haarCfg : Measure (Link N M → SU2) := Measure.pi fun _ => haarSU2

instance : IsProbabilityMeasure (haarCfg N M) := by
  unfold haarCfg; infer_instance

/-- **捩れた Wilson の分配関数** `Z = ∫ exp(β Σ_p z_p Re U_p) Π dU` -/
noncomputable def ZW (β : ℝ) (n12 n34 : Bool) : ℝ :=
  ∫ ω, Real.exp (β * ∑ B, zt N M n12 n34 B * (hol N M ω B).re) ∂(haarCfg N M)

/-! ## 中心の符号の群の作用 -/

/-- 符号の場を中心の場に -/
noncomputable def cenField : (Link N M → ℤˣ) →* (Link N M → SU2) where
  toFun g ℓ := cenHom (g ℓ)
  map_one' := by funext ℓ; simp
  map_mul' a b := by funext ℓ; simp

/-- 符号の場の作用 `(g • ω)(ℓ) = ±ω(ℓ)` -/
noncomputable instance (priority := high) signAction : MulAction (Link N M → ℤˣ) (Link N M → SU2) :=
  MulAction.compHom _ (cenField N M)

theorem smul_def (g : Link N M → ℤˣ) (ω : Link N M → SU2) :
    g • ω = cenField N M g * ω := rfl

theorem coe_smul_apply (g : Link N M → ℤˣ) (ω : Link N M → SU2) (ℓ : Link N M) :
    ((g • ω) ℓ : ℍr) = ((sgn (g ℓ) : ℝ) : ℍr) * (ω ℓ : ℍr) := by
  rw [smul_def, Pi.mul_apply, Metric.unitSphere.coe_mul]
  rfl

/-- 面の Z₂ の指標（四本の符号の積、重なりは重なりのまま） -/
noncomputable def chiB (B : Plaq N M) (g : Link N M → ℤˣ) : ℝ :=
  sgn (g (l1 N M B)) * sgn (g (l2 N M B)) * sgn (g (l3 N M B)) * sgn (g (l4 N M B))

theorem chiB_isSignChar (B : Plaq N M) : IsSignChar (chiB N M B) := by
  refine ⟨fun g h => ?_, fun g => ?_⟩
  · simp only [chiB, Pi.mul_apply, sgn_mul']
    ring
  · simp only [chiB]
    rcases sgn_isSignChar.2 (g (l1 N M B)) with h1 | h1 <;>
    rcases sgn_isSignChar.2 (g (l2 N M B)) with h2 | h2 <;>
    rcases sgn_isSignChar.2 (g (l3 N M B)) with h3 | h3 <;>
    rcases sgn_isSignChar.2 (g (l4 N M B)) with h4 | h4 <;>
    rw [h1, h2, h3, h4] <;> norm_num

theorem quat_scal (a b c d : ℝ) (p q r s : ℍr) :
    (a : ℍr) * p * ((b : ℍr) * q) * star ((c : ℍr) * r) * star ((d : ℍr) * s)
      = ((a * b * c * d : ℝ) : ℍr) * (p * q * star r * star s) := by
  rw [star_mul, star_mul, Quaternion.star_coe, Quaternion.star_coe]
  simp only [Quaternion.coe_mul_eq_smul, Quaternion.mul_coe_eq_smul, smul_mul_assoc, mul_smul_comm,
    smul_smul]
  congr 1
  ring

theorem hol_smul (g : Link N M → ℤˣ) (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (g • ω) B).re = chiB N M B g * (hol N M ω B).re := by
  unfold hol
  rw [coe_smul_apply, coe_smul_apply, coe_smul_apply, coe_smul_apply, quat_scal,
    Quaternion.coe_mul_eq_smul, Quaternion.re_smul, smul_eq_mul]
  rfl

theorem norm_hol (ω : Link N M → SU2) (B : Plaq N M) : ‖hol N M ω B‖ = 1 := by
  have h : ∀ ℓ, ‖(ω ℓ : ℍr)‖ = 1 := fun ℓ => mem_sphere_zero_iff_norm.mp (ω ℓ).2
  simp only [hol, norm_mul, Quaternion.norm_star, h, mul_one]

theorem abs_re_le_one (q : ℍr) (hq : ‖q‖ = 1) : |q.re| ≤ 1 := by
  have h1 : Quaternion.normSq q = 1 := by rw [Quaternion.normSq_eq_norm_mul_self, hq, mul_one]
  rw [Quaternion.normSq_def'] at h1
  have h2 : q.re ^ 2 ≤ 1 := by
    have := sq_nonneg q.imI; have := sq_nonneg q.imJ; have := sq_nonneg q.imK
    show q.1 ^ 2 ≤ 1
    nlinarith
  rw [abs_le]; constructor <;> nlinarith

theorem abs_tw (b : Bool) : |tw b| = 1 := by cases b <;> simp [tw]

theorem abs_zt (n12 n34 : Bool) (B : Plaq N M) : |zt N M n12 n34 B| = 1 := by
  unfold zt
  rw [abs_mul]
  split_ifs <;> simp [abs_tw]

/-! ## 可積分性 -/

theorem continuous_hol_re (B : Plaq N M) : Continuous fun ω : Link N M → SU2 => (hol N M ω B).re := by
  have hc : ∀ ℓ : Link N M, Continuous fun ω : Link N M → SU2 => (ω ℓ : ℍr) :=
    fun ℓ => continuous_subtype_val.comp (continuous_apply ℓ)
  unfold hol
  exact Quaternion.continuous_re.comp
    ((((hc _).mul (hc _)).mul (continuous_star.comp (hc _))).mul (continuous_star.comp (hc _)))

/-- 結合 `J_B(ω) = β z_B Re U_B` -/
noncomputable def Jc (β : ℝ) (z : Plaq N M → ℝ) (B : Plaq N M) (ω : Link N M → SU2) : ℝ :=
  β * z B * (hol N M ω B).re

theorem abs_Jc (β : ℝ) (n12 n34 : Bool) (B : Plaq N M) (ω : Link N M → SU2) :
    |Jc N M β (zt N M n12 n34) B ω| ≤ |β| := by
  unfold Jc
  rw [abs_mul, abs_mul, abs_zt, mul_one]
  exact mul_le_of_le_one_right (abs_nonneg β) (abs_re_le_one _ (norm_hol N M ω B))

theorem integrable_exp (β : ℝ) (z : Plaq N M → ℝ) (c : Plaq N M → ℝ) :
    Integrable (fun ω => Real.exp (∑ B, c B * Jc N M β z B ω)) (haarCfg N M) := by
  have hcont : Continuous fun ω : Link N M → SU2 => Real.exp (∑ B, c B * Jc N M β z B ω) := by
    refine Real.continuous_exp.comp (continuous_finset_sum _ fun B _ => ?_)
    unfold Jc
    exact continuous_const.mul (continuous_const.mul (continuous_hol_re N M B))
  refine Integrable.of_bound hcont.aestronglyMeasurable
    (Real.exp (∑ B, |c B| * (|β| * |z B|))) (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
  refine Real.exp_le_exp.mpr (Finset.sum_le_sum fun B _ => ?_)
  have h1 : |(hol N M ω B).re| ≤ 1 := abs_re_le_one _ (norm_hol N M ω B)
  calc c B * Jc N M β z B ω ≤ |c B * Jc N M β z B ω| := le_abs_self _
    _ = |c B| * (|β| * |z B| * |(hol N M ω B).re|) := by unfold Jc; rw [abs_mul, abs_mul, abs_mul]
    _ ≤ |c B| * (|β| * |z B| * 1) := by gcongr
    _ = |c B| * (|β| * |z B|) := by ring

/-! ## 不変性（Haar 測度の左不変性の直積） -/

theorem haarCfg_inv (g : Link N M → ℤˣ) (f : (Link N M → SU2) → ℝ) :
    ∫ ω, f (g • ω) ∂(haarCfg N M) = ∫ ω, f ω ∂(haarCfg N M) := by
  simp only [smul_def]
  unfold haarCfg
  haveI := Measure.pi.isMulLeftInvariant (fun _ : Link N M => haarSU2)
  exact integral_mul_left_eq_self f (cenField N M g)

/-! ## 底の系：二次元のトーラス (ℤ/M)² の Z₂ のゲージ理論 -/

/-- 引き戻し：二次元の符号の場を、向き 3・4 のリンクに（(x₃,x₄) で）、向き 1・2 のリンクは +1。 -/
def pull (t : Cfg2 M) : Link N M → ℤˣ := fun ℓ =>
  if ℓ.2 = 2 then t (ℓ.1.2, 0) else if ℓ.2 = 3 then t (ℓ.1.2, 1) else 1

theorem pull_mul (t t' : Cfg2 M) : pull N M (t * t') = pull N M t * pull N M t' := by
  funext ℓ
  simp only [pull, Pi.mul_apply]
  split_ifs <;> simp

/-- 底の指標：`χ₀_B(t) = χ_B(pull t)` -/
noncomputable def chi0 (B : Plaq N M) (t : Cfg2 M) : ℝ := chiB N M B (pull N M t)

theorem chi0_isSignChar (B : Plaq N M) : IsSignChar (chi0 N M B) := by
  refine ⟨fun g h => ?_, fun g => (chiB_isSignChar N M B).2 _⟩
  simp only [chi0, pull_mul]
  exact (chiB_isSignChar N M B).1 _ _

theorem sgn_one' : sgn 1 = 1 := by simp [sgn]

theorem add_pair_zero (y : Pt M) : y + ((0 : ZMod M), (0 : ZMod M)) = y := by ext <;> simp

/-- **底の指標の計算**：(3,4) の面では二次元の面の指標、ほかの面では 1。 -/
theorem chi0_eq (B : Plaq N M) (t : Cfg2 M) :
    chi0 N M B t = if B.2 = p23 then chi2 M B.1.2 t else 1 := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [chi0, chiB, l1, l2, l3, l4, pull]
  fin_cases μ <;> fin_cases ν <;> simp at hμν <;>
    simp [ev, p23, chi2, e1, e2, sgn_sq, Subtype.ext_iff, sgn_one', add_pair_zero]

/-! ## 底の系の分配関数を二次元の Z₂ のゲージ理論に -/

/-- 底の和の分解：(3,4) の向きでない面で結合が `K` なら
`Σ_B c_B χ₀_B(t) = A + Σ_y (Σ_{a} c((a,y),(3,4))) χ²ᴰ_y(t)`、`A = Σ_B [B ∉ (3,4)] K`。 -/
theorem base_sum (K : ℝ) (c : Plaq N M → ℝ) (hc : ∀ B, B.2 ≠ p23 → c B = K) (t : Cfg2 M) :
    ∑ B, c B * chi0 N M B t
      = (∑ B : Plaq N M, if B.2 = p23 then 0 else K)
        + ∑ y : Pt M, (∑ a : ZMod N × ZMod N, c ((a, y), p23)) * chi2 M y t := by
  have h1 : ∀ B : Plaq N M, c B * chi0 N M B t
      = (if B.2 = p23 then c B * chi2 M B.1.2 t else 0) + (if B.2 = p23 then 0 else K) := by
    intro B
    rw [chi0_eq]
    by_cases h : B.2 = p23
    · simp [h]
    · simp [h, hc B h]
  rw [Finset.sum_congr rfl fun B _ => h1 B, Finset.sum_add_distrib, add_comm]
  congr 1
  rw [Fintype.sum_prod_type]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [Fintype.sum_prod_type, Finset.sum_comm]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [Finset.sum_mul]

/-- 底の分配関数 = 定数 × 二次元の分配関数（結合 `Σ_a c((a,y),(3,4))`）。 -/
theorem Z_base (K : ℝ) (c : Plaq N M → ℝ) (hc : ∀ B, B.2 ≠ p23 → c B = K) :
    Z (chi0 N M) c = Real.exp (∑ B : Plaq N M, if B.2 = p23 then 0 else K)
      * Z (chi2 M) (fun y => ∑ a : ZMod N × ZMod N, c ((a, y), p23)) := by
  unfold Z
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun t _ => ?_
  rw [base_sum N M K c hc t, Real.exp_add]

theorem card_sq : ((Fintype.card (ZMod N × ZMod N) : ℕ) : ℝ) = (N : ℝ) ^ 2 := by
  simp [Fintype.card_prod, ZMod.card, sq]

/-- 一様な結合 `K`：底は二次元の結合 `N² K` の分配関数。 -/
theorem Z_base_const (K : ℝ) :
    Z (chi0 N M) (fun _ => K) = Real.exp (∑ B : Plaq N M, if B.2 = p23 then 0 else K)
      * Z (chi2 M) (fun _ => (N : ℝ) ^ 2 * K) := by
  rw [Z_base N M K (fun _ => K) (fun _ _ => rfl)]
  congr 2
  funext y
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_sq]

/-- (3,4) の捩れの符号 `ζ = z(0,1)` -/
theorem zt_false_true (B : Plaq N M) :
    zt N M false true B = if B.2 = p23 ∧ B.1.2 = 0 then -1 else 1 := by
  unfold zt tw; simp

/-- 捩れた結合 `ζK`：底は二次元の、面 0 だけ符号を変えた結合 `N² K` の分配関数。 -/
theorem Z_base_flip (K : ℝ) :
    Z (chi0 N M) (fun b => zt N M false true b * K)
      = Real.exp (∑ B : Plaq N M, if B.2 = p23 then 0 else K)
        * Z (chi2 M) (flipC M ((N : ℝ) ^ 2 * K)) := by
  rw [Z_base N M K (fun b => zt N M false true b * K) (fun B hB => by
    simp only [zt_false_true, hB, false_and, if_false, one_mul])]
  congr 2
  funext y
  simp only [zt_false_true, true_and, flipC]
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_sq]
  ring

/-! ## 段 3：四次元の Z₂ のゲージ理論が二次元の Z₂ のゲージ理論を覆う（定理 C の、底が自明でない実例） -/

/-- **四次元の Z₂ から二次元へ**：四次元のトーラスの Z₂ のゲージ理論（結合 `K ≥ 0`、捩れ `ζ`）と、
引き戻しで結ばれた底の系について、定理 C（`covering_ineq`）。仮定は `K ≥ 0` だけ。 -/
theorem z2_four_covers_two (K : ℝ) (hK : 0 ≤ K) :
    Z (chiB N M) (fun _ => K) * Z (chi0 N M) (fun b => zt N M false true b * K)
      ≤ Z (chiB N M) (fun b => zt N M false true b * K) * Z (chi0 N M) (fun _ => K) :=
  covering_ineq (chiB N M) (chiB_isSignChar N M) (chi0 N M) (chi0_isSignChar N M)
    (pull N M) (fun _ _ => rfl) (fun _ => K) (zt N M false true) (fun _ => hK)
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)

/-- 段 3 の比の形：四次元の Z₂ の捩れた比 ≥ 二次元の捩れた比（結合 `N² K`）
`= (1 − tanh(N²K)^{M²})/(1 + tanh(N²K)^{M²})`。 -/
theorem z2_four_ratio (K : ℝ) (hK : 0 ≤ K) :
    (1 - Real.tanh ((N : ℝ) ^ 2 * K) ^ (M ^ 2)) / (1 + Real.tanh ((N : ℝ) ^ 2 * K) ^ (M ^ 2))
      ≤ Z (chiB N M) (fun b => zt N M false true b * K) / Z (chiB N M) (fun _ => K) := by
  have h := covering_ratio (chiB N M) (chiB_isSignChar N M) (chi0 N M) (chi0_isSignChar N M)
    (pull N M) (fun _ _ => rfl) (fun _ => K) (zt N M false true) (fun _ => hK)
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)
  rw [Z_base_flip, Z_base_const, mul_div_mul_left _ _ (Real.exp_pos _).ne',
    plane_flip_ratio] at h
  exact h

/-! ## 段 2 と 5：SU(2) の Wilson 測度への定理 F の当てはめと、主定理 -/

theorem zt_mul (n12 : Bool) (B : Plaq N M) :
    zt N M false true B * zt N M n12 false B = zt N M n12 true B := by
  unfold zt tw; split_ifs <;> simp_all

theorem sum_Jc (β : ℝ) (z : Plaq N M → ℝ) (ω : Link N M → SU2) :
    ∑ B, Jc N M β z B ω = β * ∑ B, z B * (hol N M ω B).re := by
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun B _ => ?_
  unfold Jc; ring

/-- **定理 F の当てはめ**（中心の平均まで含む）：
`Z_{SU(2)}(n₁₂,0) · Z_底(ζ|β|) ≤ Z_{SU(2)}(n₁₂,1) · Z_底(|β|)`。仮定の欄なし。 -/
theorem su2_dominated (β : ℝ) (n12 : Bool) :
    ZW N M β n12 false * Z (chi0 N M) (fun b => zt N M false true b * |β|)
      ≤ ZW N M β n12 true * Z (chi0 N M) (fun _ => |β|) := by
  have h := invariant_dominated (haarCfg N M) (haarCfg_inv N M)
    (chiB N M) (chiB_isSignChar N M) (chi0 N M) (chi0_isSignChar N M) (pull N M)
    (fun _ _ => rfl) (fun B ω => Jc N M β (zt N M n12 false) B ω)
    (fun B g ω => by
      show β * zt N M n12 false B * (hol N M (g • ω) B).re
        = chiB N M B g * (β * zt N M n12 false B * (hol N M ω B).re)
      rw [hol_smul]; ring)
    (fun _ => |β|) (zt N M false true) (fun B ω => abs_Jc N M β n12 false B ω)
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)
    (fun c => integrable_exp N M β _ c)
  have e0 : (∫ ω, Real.exp (∑ B, Jc N M β (zt N M n12 false) B ω) ∂(haarCfg N M))
      = ZW N M β n12 false := by
    unfold ZW
    congr 1; funext ω; rw [sum_Jc]
  have e1 : (∫ ω, Real.exp (∑ B, zt N M false true B * Jc N M β (zt N M n12 false) B ω)
      ∂(haarCfg N M)) = ZW N M β n12 true := by
    unfold ZW
    congr 1; funext ω
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_
    unfold Jc
    rw [← zt_mul N M n12 B]; ring
  rw [e0, e1] at h
  exact h

theorem ZW_pos (β : ℝ) (n12 n34 : Bool) : 0 < ZW N M β n12 n34 := by
  have h := integrable_exp N M β (zt N M n12 n34) (fun _ => 1)
  have e : (fun ω => Real.exp (∑ B, (fun _ => (1 : ℝ)) B * Jc N M β (zt N M n12 n34) B ω))
      = fun ω => Real.exp (β * ∑ B, zt N M n12 n34 B * (hol N M ω B).re) := by
    funext ω; rw [← sum_Jc]; simp
  rw [e] at h
  unfold ZW
  exact integral_exp_pos h

/-- 段 5 の算術：底の系との比べ `Z₀ · Z_底(ζ|β|) ≤ Z₁ · Z_底(|β|)` から、tanh の上限へ。 -/
theorem bound_of_base (β Z0 Z1 : ℝ) (h0 : 0 < Z0) (h1 : 0 < Z1)
    (h : Z0 * Z (chi0 N M) (fun b => zt N M false true b * |β|)
      ≤ Z1 * Z (chi0 N M) (fun _ => |β|)) :
    (Z0 - Z1) / (Z0 + Z1) ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by
  rw [Z_base_flip, Z_base_const, Z_plane_flip, Z_plane_const] at h
  set L := (N : ℝ) ^ 2 * |β|
  set C := Real.cosh L ^ (M ^ 2)
  set S := Real.sinh L ^ (M ^ 2)
  set eA := Real.exp (∑ B : Plaq N M, if B.2 = p23 then 0 else |β|)
  set W := (Fintype.card (Cfg2 M) : ℝ)
  have hE : 0 < eA * W := mul_pos (Real.exp_pos _) (Nat.cast_pos.mpr Fintype.card_pos)
  have h' : Z0 * (C - S) ≤ Z1 * (C + S) := by
    have e1 : Z0 * (eA * (W * (C - S))) = (eA * W) * (Z0 * (C - S)) := by ring
    have e2 : Z1 * (eA * (W * (C + S))) = (eA * W) * (Z1 * (C + S)) := by ring
    rw [e1, e2] at h
    exact le_of_mul_le_mul_left h hE
  have hC : 0 < C := pow_pos (Real.cosh_pos L) _
  have hpos : 0 < Z0 + Z1 := add_pos h0 h1
  have hT : Real.tanh L ^ (M ^ 2) = S / C := by
    rw [Real.tanh_eq_sinh_div_cosh, div_pow]
  rw [hT, div_le_div_iff₀ hpos hC]
  have e : S * (Z0 + Z1) - (Z0 - Z1) * C = Z1 * (C + S) - Z0 * (C - S) := by ring
  linarith

/-- **主定理**（ の目標の言明）：SU(2) の Wilson の格子ゲージ理論、トーラス
`(ℤ/N)² × (ℤ/M)²`、背景の捩れ `n₁₂ ∈ {0,1}`。`Z_k` を (3,4) の捩れ `n₃₄ = k` の分配関数として、
全ての `N, M ≥ 1` と全ての実数 `β` で `(Z₀ − Z₁)/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`。仮定の欄なし。 -/
theorem twisted_vortex_bound (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) :=
  bound_of_base N M β _ _ (ZW_pos N M β n12 false) (ZW_pos N M β n12 true)
    (su2_dominated N M β n12)

/-- 比の形：`Z₁/Z₀ ≥ (1 − t^{M²})/(1 + t^{M²})`、`t = tanh(N²|β|)`。 -/
theorem twisted_ratio_lower (β : ℝ) (n12 : Bool) :
    (1 - Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)) / (1 + Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2))
      ≤ ZW N M β n12 true / ZW N M β n12 false := by
  have h := su2_dominated N M β n12
  rw [Z_base_flip, Z_base_const] at h
  have h0 := ZW_pos N M β n12 false
  have hb : 0 < Z (chi2 M) (fun _ => (N : ℝ) ^ 2 * |β|) := Z_pos _ _
  rw [← plane_flip_ratio, div_le_div_iff₀ hb h0]
  set eA := Real.exp (∑ B : Plaq N M, if B.2 = p23 then 0 else |β|)
  set Zf := Z (chi2 M) (flipC M ((N : ℝ) ^ 2 * |β|))
  set Zc := Z (chi2 M) (fun _ => (N : ℝ) ^ 2 * |β|)
  have hE : 0 < eA := Real.exp_pos _
  have e1 : ZW N M β n12 false * (eA * Zf) = eA * (Zf * ZW N M β n12 false) := by ring
  have e2 : ZW N M β n12 true * (eA * Zc) = eA * (ZW N M β n12 true * Zc) := by ring
  rw [e1, e2] at h
  exact le_of_mul_le_mul_left h hE

end TwistedWilson

#print axioms TwistedWilson.chi0_eq
#print axioms TwistedWilson.haarCfg_inv
#print axioms TwistedWilson.z2_four_covers_two
#print axioms TwistedWilson.z2_four_ratio
#print axioms TwistedWilson.su2_dominated
#print axioms TwistedWilson.bound_of_base
#print axioms TwistedWilson.twisted_ratio_lower
#print axioms TwistedWilson.twisted_vortex_bound
