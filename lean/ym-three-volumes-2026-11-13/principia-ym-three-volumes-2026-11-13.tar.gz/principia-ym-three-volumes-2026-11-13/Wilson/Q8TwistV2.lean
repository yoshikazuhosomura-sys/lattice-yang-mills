import Wilson.SU2TwistV2

/-!
# 有限群 Q₈ の格子ゲージ理論での同じ下限（`equivariant_dominated` の欄を満たす実例）

点検役の指摘 (ii)：中心 Z₂ を持つ有限群のゲージ理論が `equivariant_dominated` の欄を満たす例。
リンクの値は Q₈ = {±1, ±i, ±j, ±k} ⊂ ℍ（`(k, s)` が `s·e_k`）、測度は数え上げ（Q₈ の Haar 測度の
定数倍）。格子・面・捩れ・底の系は `Wilson.SU2TwistV1` と同じ。
結論は SU(2) と同じ形：`(Z₀ − Z₁)/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`、全ての β・N・M ≥ 1。
-/

open Finset BigOperators CoveringInequality TwistedPlane TwistedWilson

namespace TwistedQ8

local notation "ℍr" => Quaternion ℝ

/-- Q₈ の元 `s·e_k`（`k = 0,1,2,3` が `1, i, j, k`、`s ∈ ℤˣ`） -/
structure Q8 where
  k : Fin 4
  s : ℤˣ
  deriving DecidableEq, Fintype

/-- 四元数の基底 `1, i, j, k` -/
def basis : Fin 4 → ℍr := ![⟨1, 0, 0, 0⟩, ⟨0, 1, 0, 0⟩, ⟨0, 0, 1, 0⟩, ⟨0, 0, 0, 1⟩]

instance : Inhabited Q8 := ⟨⟨0, 1⟩⟩

/-- Q₈ の元の四元数としての値 -/
noncomputable def val (q : Q8) : ℍr := ((sgn q.s : ℝ) : ℍr) * basis q.k

theorem normSq_basis (k : Fin 4) : Quaternion.normSq (basis k) = 1 := by
  rw [Quaternion.normSq_def']
  fin_cases k <;> simp [basis]

theorem normSq_val (q : Q8) : Quaternion.normSq (val q) = 1 := by
  unfold val
  rw [map_mul, normSq_basis, Quaternion.normSq_coe, mul_one]
  rcases sgn_isSignChar.2 q.s with h | h <;> rw [h] <;> norm_num

theorem abs_re_le_one' (q : ℍr) (hq : Quaternion.normSq q = 1) : |q.re| ≤ 1 := by
  rw [Quaternion.normSq_def'] at hq
  have := sq_nonneg q.imI; have := sq_nonneg q.imJ; have := sq_nonneg q.imK
  have h2 : q.re ^ 2 ≤ 1 := by show q.1 ^ 2 ≤ 1; nlinarith
  rw [abs_le]; constructor <;> nlinarith

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 中心の符号の場の作用 `(g • ω)(ℓ) = g(ℓ)·ω(ℓ)` -/
noncomputable instance (priority := high) act8 : MulAction (Link N M → ℤˣ) (Link N M → Q8) where
  smul g ω ℓ := ⟨(ω ℓ).k, g ℓ * (ω ℓ).s⟩
  one_smul ω := by funext ℓ; show (⟨(ω ℓ).k, 1 * (ω ℓ).s⟩ : Q8) = ω ℓ; simp
  mul_smul g h ω := by
    funext ℓ
    show (⟨(ω ℓ).k, (g ℓ * h ℓ) * (ω ℓ).s⟩ : Q8) = ⟨(ω ℓ).k, g ℓ * (h ℓ * (ω ℓ).s)⟩
    rw [mul_assoc]

theorem val_smul (g : Link N M → ℤˣ) (ω : Link N M → Q8) (ℓ : Link N M) :
    val ((g • ω) ℓ) = ((sgn (g ℓ) : ℝ) : ℍr) * val (ω ℓ) := by
  show ((sgn (g ℓ * (ω ℓ).s) : ℝ) : ℍr) * basis (ω ℓ).k = ((sgn (g ℓ) : ℝ) : ℍr) * val (ω ℓ)
  rw [sgn_mul', Quaternion.coe_mul, mul_assoc]
  rfl

/-- Q₈ の面のホロノミー -/
noncomputable def hol8 (ω : Link N M → Q8) (B : Plaq N M) : ℍr :=
  val (ω (l1 N M B)) * val (ω (l2 N M B)) * star (val (ω (l3 N M B))) * star (val (ω (l4 N M B)))

theorem hol8_smul (g : Link N M → ℤˣ) (ω : Link N M → Q8) (B : Plaq N M) :
    (hol8 N M (g • ω) B).re = chiB N M B g * (hol8 N M ω B).re := by
  unfold hol8
  rw [val_smul, val_smul, val_smul, val_smul, quat_scal, Quaternion.coe_mul_eq_smul,
    Quaternion.re_smul, smul_eq_mul]
  rfl

theorem abs_hol8_re (ω : Link N M → Q8) (B : Plaq N M) : |(hol8 N M ω B).re| ≤ 1 := by
  apply abs_re_le_one'
  simp only [hol8, map_mul, Quaternion.normSq_star, normSq_val, mul_one]

/-- 捩れた Q₈ の分配関数 `Σ_ω exp(β Σ_p z_p Re U_p)` -/
noncomputable def Z8 (β : ℝ) (n12 n34 : Bool) : ℝ :=
  ∑ ω : Link N M → Q8, Real.exp (β * ∑ B, zt N M n12 n34 B * (hol8 N M ω B).re)

theorem Z8_pos (β : ℝ) (n12 n34 : Bool) : 0 < Z8 N M β n12 n34 :=
  Finset.sum_pos (fun _ _ => Real.exp_pos _) Finset.univ_nonempty

/-- 定理 F の有限の形（`equivariant_dominated`）の Q₈ への当てはめ。仮定の欄なし。 -/
theorem q8_dominated (β : ℝ) (n12 : Bool) :
    Z8 N M β n12 false * Z (chi0 N M) (fun b => zt N M false true b * |β|)
      ≤ Z8 N M β n12 true * Z (chi0 N M) (fun _ => |β|) := by
  have h := equivariant_dominated (Ω := Link N M → Q8)
    (chiB N M) (chiB_isSignChar N M) (chi0 N M) (chi0_isSignChar N M) (pull N M)
    (fun _ _ => rfl) (fun B ω => β * zt N M n12 false B * (hol8 N M ω B).re)
    (fun B g ω => by
      show β * zt N M n12 false B * (hol8 N M (g • ω) B).re
        = chiB N M B g * (β * zt N M n12 false B * (hol8 N M ω B).re)
      rw [hol8_smul]; ring)
    (fun _ => |β|) (zt N M false true)
    (fun B ω => by
      show |β * zt N M n12 false B * (hol8 N M ω B).re| ≤ |β|
      rw [abs_mul, abs_mul, abs_zt, mul_one]
      exact mul_le_of_le_one_right (abs_nonneg β) (abs_hol8_re N M ω B))
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)
  have e0 : (∑ ω : Link N M → Q8, Real.exp (∑ B, β * zt N M n12 false B * (hol8 N M ω B).re))
      = Z8 N M β n12 false := by
    unfold Z8
    refine Finset.sum_congr rfl fun ω _ => ?_
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_
    ring
  have e1 : (∑ ω : Link N M → Q8,
      Real.exp (∑ B, zt N M false true B * (β * zt N M n12 false B * (hol8 N M ω B).re)))
      = Z8 N M β n12 true := by
    unfold Z8
    refine Finset.sum_congr rfl fun ω _ => ?_
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_
    rw [← zt_mul N M n12 B]; ring
  rw [e0, e1] at h
  exact h

/-- **Q₈ の主定理**：`(Z₀ − Z₁)/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`、全ての β・N・M ≥ 1。 -/
theorem q8_vortex_bound (β : ℝ) (n12 : Bool) :
    (Z8 N M β n12 false - Z8 N M β n12 true) / (Z8 N M β n12 false + Z8 N M β n12 true)
      ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) :=
  bound_of_base N M β _ _ (Z8_pos N M β n12 false) (Z8_pos N M β n12 true)
    (q8_dominated N M β n12)

end TwistedQ8

namespace TwistedWilson

open MeasureTheory

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 主定理の言明を、定義を開いた形で（`ZW` が本当に「SU(2) の正規化した Haar 測度の直積の上の
Wilson の重みの積分」であることを字面で見せるため。証明は `twisted_vortex_bound` そのもの）。 -/
theorem twisted_vortex_bound_unfolded (β : ℝ) (n12 : Bool) :
    let Zk : Bool → ℝ := fun k => ∫ ω : Link N M → SU2,
      Real.exp (β * ∑ B : Plaq N M, zt N M n12 k B * (hol N M ω B).re)
        ∂(Measure.pi fun _ => (Measure.haarMeasure ⊤ : Measure SU2))
    (Zk false - Zk true) / (Zk false + Zk true) ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) :=
  twisted_vortex_bound N M β n12

/-- 渦の自由エネルギーの形：`ΔF = −log(Z₁/Z₀) ≤ log((1 + s)/(1 − s)) ≤ 2s/(1 − s)`、
`s = tanh(N²|β|)^{M²}`（`s < 1`）。 -/
theorem vortex_free_energy_bound (β : ℝ) (n12 : Bool) :
    -Real.log (ZW N M β n12 true / ZW N M β n12 false)
      ≤ 2 * Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)
          / (1 - Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)) := by
  set s := Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2)
  have h0 : 0 ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) := by
    rw [Real.tanh_eq_sinh_div_cosh]
    exact div_nonneg (Real.sinh_nonneg_iff.mpr (by positivity)) (Real.cosh_pos _).le
  have hs0 : 0 ≤ s := pow_nonneg h0 _
  have hs1 : s < 1 := by
    have h1 : Real.tanh ((N : ℝ) ^ 2 * |β|) < 1 := Real.tanh_lt_one _
    exact pow_lt_one₀ h0 h1 (pow_ne_zero 2 (NeZero.ne M))
  have hlow := twisted_ratio_lower N M β n12
  have hq : 0 < (1 - s) / (1 + s) := div_pos (by linarith) (by linarith)
  have hr : 0 < ZW N M β n12 true / ZW N M β n12 false :=
    div_pos (ZW_pos N M β n12 true) (ZW_pos N M β n12 false)
  have h1 : -Real.log (ZW N M β n12 true / ZW N M β n12 false) ≤ -Real.log ((1 - s) / (1 + s)) :=
    neg_le_neg (Real.log_le_log hq hlow)
  have h2 : -Real.log ((1 - s) / (1 + s)) = Real.log ((1 + s) / (1 - s)) := by
    rw [← Real.log_inv, inv_div]
  have h3 : Real.log ((1 + s) / (1 - s)) ≤ (1 + s) / (1 - s) - 1 :=
    Real.log_le_sub_one_of_pos (div_pos (by linarith) (by linarith))
  have h4 : (1 + s) / (1 - s) - 1 = 2 * s / (1 - s) := by
    rw [div_sub_one (by linarith : (1 : ℝ) - s ≠ 0)]
    congr 1
    ring
  linarith

end TwistedWilson

#print axioms TwistedQ8.q8_dominated
#print axioms TwistedQ8.q8_vortex_bound
#print axioms TwistedWilson.twisted_vortex_bound_unfolded
#print axioms TwistedWilson.vortex_free_energy_bound
