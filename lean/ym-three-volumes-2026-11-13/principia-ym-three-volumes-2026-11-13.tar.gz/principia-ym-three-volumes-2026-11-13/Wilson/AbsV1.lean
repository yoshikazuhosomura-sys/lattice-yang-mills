import Wilson.GeneralV1

/-!
# 両側の形：`|Z₀ − Z₁|/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`

定理 F（`su2_dominated_general`）を、捩れた側を「元」にして当てはめ直すと（`ζ² = 1`）、
`Z₁ · Z_底(ζ|β|) ≤ Z₀ · Z_底(|β|)` も出る。`bound_of_base` を両方に使うと絶対値の形。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistedWilson

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem zt_mul' (n12 : Bool) (B : Plaq N M) :
    zt N M false true B * zt N M n12 true B = zt N M n12 false B := by
  unfold zt tw; split_ifs <;> simp_all

/-- 捩れた側を元にした定理 F：`Z₁ · Z_底(ζ|β|) ≤ Z₀ · Z_底(|β|)`。仮定の欄なし。 -/
theorem su2_dominated_swap (β : ℝ) (n12 : Bool) :
    ZW N M β n12 true * Z (chi0 N M) (fun b => zt N M false true b * |β|)
      ≤ ZW N M β n12 false * Z (chi0 N M) (fun _ => |β|) := by
  have h := su2_dominated_general N M (chi0 N M) (chi0_isSignChar N M) (pull N M)
    (fun _ _ => rfl) (fun B => β * zt N M n12 true B) (zt N M false true)
    (fun B => by rw [zt_false_true]; split_ifs <;> simp)
  have ea : ∀ B : Plaq N M, |β * zt N M n12 true B| = |β| := by
    intro B; rw [abs_mul, abs_zt, mul_one]
  simp only [ea] at h
  have e0 : (∫ ω, Real.exp (∑ B, β * zt N M n12 true B * (hol N M ω B).re) ∂(haarCfg N M))
      = ZW N M β n12 true := by
    unfold ZW; congr 1; funext ω; congr 1; rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_; ring
  have e1 : (∫ ω, Real.exp (∑ B, zt N M false true B * (β * zt N M n12 true B) * (hol N M ω B).re)
      ∂(haarCfg N M)) = ZW N M β n12 false := by
    unfold ZW; congr 1; funext ω; congr 1; rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_
    rw [← zt_mul' N M n12 B]; ring
  rw [e0, e1] at h
  exact h

/-- **両側の形**：全ての `N, M ≥ 1`、全ての実数 `β`、`n₁₂ ∈ {0,1}` で
`|Z₀ − Z₁|/(Z₀ + Z₁) ≤ tanh(N²|β|)^{M²}`。仮定の欄なし。 -/
theorem twisted_vortex_bound_abs (β : ℝ) (n12 : Bool) :
    |ZW N M β n12 false - ZW N M β n12 true| / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by
  have h0 := ZW_pos N M β n12 false
  have h1 := ZW_pos N M β n12 true
  have a := twisted_vortex_bound N M β n12
  have b := bound_of_base N M β _ _ h1 h0 (su2_dominated_swap N M β n12)
  have hp : 0 < ZW N M β n12 false + ZW N M β n12 true := add_pos h0 h1
  rcases le_total (ZW N M β n12 true) (ZW N M β n12 false) with h | h
  · rw [abs_of_nonneg (by linarith : 0 ≤ ZW N M β n12 false - ZW N M β n12 true)]
    exact a
  · rw [abs_of_nonpos (by linarith : ZW N M β n12 false - ZW N M β n12 true ≤ 0), neg_sub,
      add_comm]
    exact b

end TwistedWilson

#print axioms TwistedWilson.su2_dominated_swap
#print axioms TwistedWilson.twisted_vortex_bound_abs
