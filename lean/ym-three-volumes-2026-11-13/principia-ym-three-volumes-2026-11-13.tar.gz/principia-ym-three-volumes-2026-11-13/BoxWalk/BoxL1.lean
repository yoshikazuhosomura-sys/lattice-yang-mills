import Mathlib

/-!
# L1: the concrete block map `Bm := retract ∘ avg` and the seam (R0) of the chain

Correspondence with the paper (for checking):
* `blockMap` = the coarse field of the fix (F-b).md` §10.5 and
  WALL1 §8.37: on each coarse link `b`, the weighted average of oriented path products of the fine
  links (paper A, definition 2.1; the weights and the path family are left as data here, the
  family `(1/8, 3/4, 1/8)` is one instance), followed by the radial retraction
  `ra(q) = q / max(|q|, r₀)` (`retract`, same definition as `LatticeBlockReflection.retract`).
* `continuous_blockMap` = the field `hB : ∀ m, Continuous (Bm m)` of
  `TransientChainError.chain_end_to_end_error` (stage 1), for this concrete map.
* `down n m` = the coarse field at level `m` of the induction started at the finest level `n`,
  defined by composing the block maps (this is (F-b): the induction's coarse field is *defined*
  as the chain's map). `down_succ` is (R0): `down n m = Bm m ∘ down n (m+1)` for `m < n`.
* `hcons_blockMap` = the field `hcons` of `chain_end_to_end_error` for the push-forwards
  `νP n m := (μ n).map (down n m)` of an arbitrary family of fine measures `μ n`.
* `blockMap_of_small_field` = on the small-field event `r₀ ≤ |q|` the value is the projection
  `q/|q|` used by the induction (unit quaternion = SU(2)); `blockMap_of_lt` = for `|q| < r₀` the
  value lies strictly inside the ball (the extra configurations that (F-b) moves into the
  large-field polymers, `chain-gaps.md` §10.5 (N3-1)).
-/

namespace ChainBlockMap

open MeasureTheory Filter Topology

local notation "ℍr" => Quaternion ℝ

noncomputable instance instMeasurableSpaceQuaternion : MeasurableSpace ℍr := borel ℍr
instance instBorelSpaceQuaternion : BorelSpace ℍr := ⟨rfl⟩

/-- Values of a link variable: the closed unit ball of the quaternions (SU(2) is its boundary). -/
abbrev Ball := Metric.closedBall (0 : ℍr) 1

/-- Configurations on a finite set of links. -/
abbrev Cfg (L : Type*) := L → Ball

theorem mem_ball_iff (q : ℍr) : q ∈ Metric.closedBall (0 : ℍr) 1 ↔ ‖q‖ ≤ 1 :=
  mem_closedBall_zero_iff

/-! ## 1. Radial retraction -/

/-- Radial retraction `ra(q) = q / max(‖q‖, r₀)`. -/
noncomputable def retract (r₀ : ℝ) (q : ℍr) : ℍr := (max ‖q‖ r₀)⁻¹ • q

theorem continuous_retract {r₀ : ℝ} (hr : 0 < r₀) : Continuous (retract r₀) := by
  unfold retract
  have hmax : Continuous fun q : ℍr => max ‖q‖ r₀ := continuous_norm.max continuous_const
  exact (hmax.inv₀ (fun q => ne_of_gt (lt_of_lt_of_le hr (le_max_right _ _)))).smul continuous_id

theorem norm_retract {r₀ : ℝ} (hr : 0 < r₀) (q : ℍr) : ‖retract r₀ q‖ = ‖q‖ / max ‖q‖ r₀ := by
  have hpos : 0 < max ‖q‖ r₀ := lt_of_lt_of_le hr (le_max_right _ _)
  rw [retract, norm_smul, Real.norm_eq_abs, abs_inv, abs_of_pos hpos, inv_mul_eq_div]

theorem norm_retract_le {r₀ : ℝ} (hr : 0 < r₀) (q : ℍr) : ‖retract r₀ q‖ ≤ 1 := by
  have hpos : 0 < max ‖q‖ r₀ := lt_of_lt_of_le hr (le_max_right _ _)
  rw [norm_retract hr, div_le_one hpos]
  exact le_max_left _ _

/-- Small field `r₀ ≤ ‖q‖`: the retraction is the projection `q/‖q‖`, a unit quaternion. -/
theorem retract_of_le {r₀ : ℝ} (hr : 0 < r₀) {q : ℍr} (hq : r₀ ≤ ‖q‖) :
    retract r₀ q = ‖q‖⁻¹ • q ∧ ‖retract r₀ q‖ = 1 := by
  have hmax : max ‖q‖ r₀ = ‖q‖ := max_eq_left hq
  have hpos : 0 < ‖q‖ := lt_of_lt_of_le hr hq
  refine ⟨by simp [retract, hmax], ?_⟩
  rw [norm_retract hr, hmax, div_self hpos.ne']

/-- Inside `‖q‖ < r₀`: the retraction is `q/r₀`, of norm `‖q‖/r₀ < 1`. -/
theorem retract_of_lt {r₀ : ℝ} (hr : 0 < r₀) {q : ℍr} (hq : ‖q‖ < r₀) :
    retract r₀ q = r₀⁻¹ • q ∧ ‖retract r₀ q‖ = ‖q‖ / r₀ ∧ ‖retract r₀ q‖ < 1 := by
  have hmax : max ‖q‖ r₀ = r₀ := max_eq_right hq.le
  refine ⟨by simp [retract, hmax], by rw [norm_retract hr, hmax], ?_⟩
  rw [norm_retract hr, hmax, div_lt_one hr]
  exact hq

/-! ## 2. Oriented path products and the weighted average -/

section Average

variable {L : Type*}

/-- Value of an oriented step: `U ℓ` forward (`false`), `U ℓ*` backward (`true`). -/
noncomputable def stepVal (U : L → ℍr) (s : L × Bool) : ℍr := if s.2 then star (U s.1) else U s.1

/-- Ordered product along a path. -/
noncomputable def pathProd (U : L → ℍr) (γ : List (L × Bool)) : ℍr := (γ.map (stepVal U)).prod

/-- Weighted average over a finite family of paths. -/
noncomputable def avg (U : L → ℍr) (P : Finset (List (L × Bool))) (w : List (L × Bool) → ℝ) : ℍr :=
  ∑ γ ∈ P, w γ • pathProd U γ

theorem continuous_stepVal (s : L × Bool) : Continuous fun U : L → ℍr => stepVal U s := by
  unfold stepVal
  split_ifs
  · exact continuous_star.comp (continuous_apply s.1)
  · exact continuous_apply s.1

theorem continuous_pathProd (γ : List (L × Bool)) : Continuous fun U : L → ℍr => pathProd U γ := by
  induction γ with
  | nil => simpa [pathProd] using continuous_const
  | cons s rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    exact (continuous_stepVal s).mul ih

theorem continuous_avg (P : Finset (List (L × Bool))) (w : List (L × Bool) → ℝ) :
    Continuous fun U : L → ℍr => avg U P w :=
  continuous_finsetSum _ (fun γ _ => (continuous_pathProd γ).const_smul (w γ))

theorem norm_stepVal_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (s : L × Bool) : ‖stepVal U s‖ ≤ 1 := by
  unfold stepVal
  split_ifs
  · rw [norm_star]; exact hU s.1
  · exact hU s.1

theorem norm_pathProd_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (γ : List (L × Bool)) :
    ‖pathProd U γ‖ ≤ 1 := by
  induction γ with
  | nil => simp [pathProd]
  | cons s rest ih =>
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [norm_mul]
    exact mul_le_one₀ (norm_stepVal_le hU s) (norm_nonneg _) ih

/-- With ball-valued links, `‖avg‖ ≤ Σ |w γ|` (so `≤ 1` for a convex family). -/
theorem norm_avg_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1) (P : Finset (List (L × Bool)))
    (w : List (L × Bool) → ℝ) : ‖avg U P w‖ ≤ ∑ γ ∈ P, |w γ| := by
  unfold avg
  refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun γ _ => ?_)
  rw [norm_smul, Real.norm_eq_abs]
  exact mul_le_of_le_one_right (abs_nonneg _) (norm_pathProd_le hU γ)

/-! ### The family of the induction: six orders, weights `(1/8, 3/4, 1/8)` per transverse slot

`sixAvg P U = Σ_o Σ_A (1/6) Π_t wt (A t) · pathProd U (P o A)`, as in `LatticePath.walk`
(the order `o : Fin 6`, the displacement indices `A : Fin 3 → Fin 3`). It is a weighted average
of path products, with nonnegative weights of total mass one. -/

/-- Weights `(α, 1 − 2α, α)`, `α = 1/8` (= `LatticePath.wt`). -/
noncomputable def wt : Fin 3 → ℝ := ![1 / 8, 3 / 4, 1 / 8]

/-- Weight of the path with order `o` and displacements `A`. -/
noncomputable def sixWeight (A : Fin 3 → Fin 3) : ℝ := (1 / 6) * ∏ t, wt (A t)

noncomputable def sixAvg (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) : ℍr :=
  ∑ o, ∑ A, sixWeight A • pathProd U (P o A)

theorem wt_nonneg (a : Fin 3) : 0 ≤ wt a := by
  fin_cases a <;> norm_num [wt]

theorem wt_sum : ∑ a, wt a = 1 := by
  simp [wt, Fin.sum_univ_three]; norm_num

theorem sixWeight_nonneg (A : Fin 3 → Fin 3) : 0 ≤ sixWeight A :=
  mul_nonneg (by norm_num) (Finset.prod_nonneg fun t _ => wt_nonneg _)

/-- Total mass one. -/
theorem sixWeight_total : ∑ _o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A = 1 := by
  have h : ∑ A : Fin 3 → Fin 3, ∏ t, wt (A t) = 1 := by
    rw [← Fintype.prod_sum (fun _ : Fin 3 => wt)]
    simp [wt_sum]
  simp only [sixWeight, ← Finset.mul_sum, h, Finset.sum_const, Finset.card_univ, Fintype.card_fin]
  norm_num

theorem continuous_sixAvg (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) :
    Continuous fun U : L → ℍr => sixAvg P U :=
  continuous_finsetSum _ fun o _ => continuous_finsetSum _ fun A _ =>
    (continuous_pathProd (P o A)).const_smul (sixWeight A)

/-- With ball-valued links the six-order average stays in the unit ball. -/
theorem norm_sixAvg_le {U : L → ℍr} (hU : ∀ ℓ, ‖U ℓ‖ ≤ 1)
    (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) : ‖sixAvg P U‖ ≤ 1 := by
  unfold sixAvg
  calc ‖∑ o, ∑ A, sixWeight A • pathProd U (P o A)‖
      ≤ ∑ o : Fin 6, ∑ A : Fin 3 → Fin 3, sixWeight A := by
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun o _ => ?_)
        refine (norm_sum_le _ _).trans (Finset.sum_le_sum fun A _ => ?_)
        rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (sixWeight_nonneg A)]
        exact mul_le_of_le_one_right (sixWeight_nonneg A) (norm_pathProd_le hU _)
    _ = 1 := sixWeight_total

/-! ### Reversed paths: the reversed coarse link carries the conjugate  -/

/-- Walk a path backwards: reverse the order and flip each orientation. -/
def revPath (γ : List (L × Bool)) : List (L × Bool) := (γ.map fun s => (s.1, !s.2)).reverse

theorem revPath_revPath (γ : List (L × Bool)) : revPath (revPath γ) = γ := by
  simp [revPath, List.map_reverse, Function.comp_def]

theorem revPath_injective : Function.Injective (revPath (L := L)) :=
  Function.LeftInverse.injective revPath_revPath

theorem stepVal_flip (U : L → ℍr) (s : L × Bool) : stepVal U (s.1, !s.2) = star (stepVal U s) := by
  unfold stepVal
  cases s.2 <;> simp

theorem revPath_cons (s : L × Bool) (γ : List (L × Bool)) :
    revPath (s :: γ) = revPath γ ++ [(s.1, !s.2)] := by
  simp [revPath]

theorem pathProd_append (U : L → ℍr) (γ δ : List (L × Bool)) :
    pathProd U (γ ++ δ) = pathProd U γ * pathProd U δ := by
  simp [pathProd, List.map_append, List.prod_append]

/-- The product along the reversed path is the conjugate (the conjugate reverses products). -/
theorem pathProd_rev (U : L → ℍr) (γ : List (L × Bool)) :
    pathProd U (revPath γ) = star (pathProd U γ) := by
  induction γ with
  | nil => simp [revPath, pathProd]
  | cons s γ ih =>
    rw [revPath_cons, pathProd_append, ih]
    have h1 : pathProd U [(s.1, !s.2)] = star (stepVal U s) := by
      simp only [pathProd, List.map_cons, List.map_nil, List.prod_cons, List.prod_nil, mul_one]
      exact stepVal_flip U s
    have h2 : pathProd U (s :: γ) = stepVal U s * pathProd U γ := by
      simp [pathProd]
    rw [h1, h2, star_mul]

/-- The reversal as an embedding (so no decidable equality on paths is needed). -/
def revEmb : List (L × Bool) ↪ List (L × Bool) := ⟨revPath, revPath_injective⟩

/-- Averages over the reversed family (same weights) give the conjugate. -/
theorem avg_rev (U : L → ℍr) (P : Finset (List (L × Bool))) (w w' : List (L × Bool) → ℝ)
    (hw : ∀ γ, w' (revPath γ) = w γ) :
    avg U (P.map revEmb) w' = star (avg U P w) := by
  unfold avg
  rw [Finset.sum_map, star_sum]
  refine Finset.sum_congr rfl fun γ _ => ?_
  simp only [revEmb, Function.Embedding.coeFn_mk]
  rw [hw, pathProd_rev, Quaternion.star_smul]

theorem sixAvg_rev (P P' : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool))
    (hP : ∀ o A, P' o A = revPath (P o A)) (U : L → ℍr) :
    sixAvg P' U = star (sixAvg P U) := by
  unfold sixAvg
  simp only [star_sum, Quaternion.star_smul, hP, pathProd_rev]

end Average

/-! ## 3. The block map between ball-valued configurations -/

section Block

variable {Lk : ℕ → Type*}
  (r₀ : ℝ) (hr : 0 < r₀)
  (paths : ∀ m, Lk m → Finset (List (Lk (m + 1) × Bool)))
  (w : ∀ m, Lk m → List (Lk (m + 1) × Bool) → ℝ)

/-- The coarse value `q_b(U)` before the retraction. -/
noncomputable def coarseAvg (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m) : ℍr :=
  avg (fun ℓ => (U ℓ : ℍr)) (paths m b) (w m b)

include hr in
/-- The block map `Bm m := retract ∘ avg`, as a map of ball-valued configurations. -/
noncomputable def blockMap (m : ℕ) (U : Cfg (Lk (m + 1))) : Cfg (Lk m) :=
  fun b => ⟨retract r₀ (coarseAvg paths w m U b),
    (mem_ball_iff _).2 (norm_retract_le hr _)⟩

theorem continuous_coarseAvg (m : ℕ) (b : Lk m) :
    Continuous fun U : Cfg (Lk (m + 1)) => coarseAvg paths w m U b :=
  (continuous_avg (paths m b) (w m b)).comp
    (continuous_pi fun ℓ => continuous_subtype_val.comp (continuous_apply ℓ))

/-- The field `hB` of the chain for the concrete block map. -/
theorem continuous_blockMap (m : ℕ) : Continuous (blockMap r₀ hr paths w m) := by
  refine continuous_pi fun b => ?_
  exact ((continuous_retract hr).comp (continuous_coarseAvg paths w m b)).subtype_mk _

/-- On the small-field event the block map is the projection `q/‖q‖` of the induction. -/
theorem blockMap_of_small_field (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m)
    (hq : r₀ ≤ ‖coarseAvg paths w m U b‖) :
    (blockMap r₀ hr paths w m U b : ℍr) =
        ‖coarseAvg paths w m U b‖⁻¹ • coarseAvg paths w m U b ∧
      ‖(blockMap r₀ hr paths w m U b : ℍr)‖ = 1 :=
  retract_of_le hr hq

/-- Off the small-field event the value lies strictly inside the ball. -/
theorem blockMap_of_lt (m : ℕ) (U : Cfg (Lk (m + 1))) (b : Lk m)
    (hq : ‖coarseAvg paths w m U b‖ < r₀) :
    (blockMap r₀ hr paths w m U b : ℍr) = r₀⁻¹ • coarseAvg paths w m U b ∧
      ‖(blockMap r₀ hr paths w m U b : ℍr)‖ < 1 :=
  ⟨(retract_of_lt hr hq).1, (retract_of_lt hr hq).2.2⟩

/-- The retraction commutes with the conjugation. -/
theorem retract_star (r₀ : ℝ) (q : ℍr) : retract r₀ (star q) = star (retract r₀ q) := by
  simp only [retract, norm_star, Quaternion.star_smul]

/-- (B5) for reversed coarse links: if the family of the reversed link `rev b` consists of the
reversed paths with the same weights, its coarse value is the conjugate. -/
theorem blockMap_rev (rev : ∀ m, Lk m → Lk m) (m : ℕ) (b : Lk m)
    (hP : paths m (rev m b) = (paths m b).map revEmb)
    (hw : ∀ γ, w m (rev m b) (revPath γ) = w m b γ) (U : Cfg (Lk (m + 1))) :
    (blockMap r₀ hr paths w m U (rev m b) : ℍr) = star (blockMap r₀ hr paths w m U b : ℍr) := by
  simp only [blockMap, coarseAvg, hP, avg_rev _ _ _ _ hw, retract_star]

/-! ## 4. The coarse fields of the induction: composition of block maps (fix (F-b)) -/

/-- Auxiliary: from the finest level `n` down `k` steps to level `m` (`m + k = n`). -/
noncomputable def downAux (n : ℕ) : ∀ (k m : ℕ), m + k = n → Cfg (Lk n) → Cfg (Lk m)
  | 0, m, h, U => cast (congrArg (fun j => Cfg (Lk j)) (show n = m by omega)) U
  | k + 1, m, h, U => blockMap r₀ hr paths w m (downAux n k (m + 1) (by omega) U)

/-- A fixed configuration, used for `m > n` (never used by the chain, which only needs large `n`). -/
noncomputable def oneCfg (L : Type*) : Cfg L := fun _ => ⟨1, (mem_ball_iff _).2 (by simp)⟩

/-- The coarse field at level `m` of the induction started at the finest level `n`. -/
noncomputable def down (n m : ℕ) (U : Cfg (Lk n)) : Cfg (Lk m) :=
  if h : m ≤ n then downAux r₀ hr paths w n (n - m) m (by omega) U else oneCfg (Lk m)

theorem downAux_congr (n : ℕ) {k k' m : ℕ} (hk : k = k') (h : m + k = n) (h' : m + k' = n)
    (U : Cfg (Lk n)) : downAux r₀ hr paths w n k m h U = downAux r₀ hr paths w n k' m h' U := by
  subst hk; rfl

/-- (R0) holds by definition: `down n m = Bm m ∘ down n (m+1)` for `m < n`. -/
theorem down_succ {n m : ℕ} (hmn : m < n) (U : Cfg (Lk n)) :
    down r₀ hr paths w n m U = blockMap r₀ hr paths w m (down r₀ hr paths w n (m + 1) U) := by
  have h1 : m ≤ n := hmn.le
  have h2 : m + 1 ≤ n := hmn
  simp only [down, dif_pos h1, dif_pos h2]
  rw [downAux_congr r₀ hr paths w n (show n - m = (n - (m + 1)) + 1 by omega) _ (by omega)]
  rfl

theorem down_self (n : ℕ) (U : Cfg (Lk n)) : down r₀ hr paths w n n U = U := by
  simp only [down, dif_pos le_rfl]
  rw [downAux_congr r₀ hr paths w n (show n - n = 0 by omega) _ (by omega)]
  exact cast_eq _ _

theorem continuous_downAux (n : ℕ) :
    ∀ (k m : ℕ) (h : m + k = n), Continuous (downAux r₀ hr paths w n k m h) := by
  intro k
  induction k with
  | zero =>
    intro m h
    subst h
    exact continuous_id.congr (fun U => (cast_eq _ U).symm)
  | succ k ih =>
    intro m h
    exact (continuous_blockMap r₀ hr paths w m).comp (ih (m + 1) (by omega))

theorem continuous_down (n m : ℕ) : Continuous (down r₀ hr paths w n m) := by
  by_cases h : m ≤ n
  · have : down r₀ hr paths w n m = downAux r₀ hr paths w n (n - m) m (by omega) := by
      funext U; simp only [down, dif_pos h]
    rw [this]
    exact continuous_downAux r₀ hr paths w n _ _ _
  · have : down r₀ hr paths w n m = fun _ : Cfg (Lk n) => oneCfg (Lk m) := by
      funext U; simp only [down, dif_neg h]
    rw [this]
    exact continuous_const

/-! ## 5. The field `hcons` of the chain for the push-forwards -/

variable [∀ m, Fintype (Lk m)]

/-- `νP n m := (μ n).map (down n m)`: the law of the coarse field at level `m`. -/
noncomputable def νP (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) (n m : ℕ) :
    ProbabilityMeasure (Cfg (Lk m)) :=
  (μ n).map (continuous_down r₀ hr paths w n m).measurable.aemeasurable

/-- The field `hcons` of `chain_end_to_end_error` with `Bm := blockMap`, for every family of fine
measures `μ n`. -/
theorem hcons_blockMap (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) :
    ∀ m, ∀ᶠ n in atTop,
      (νP r₀ hr paths w μ n (m + 1)).map
          (continuous_blockMap r₀ hr paths w m).measurable.aemeasurable =
        νP r₀ hr paths w μ n m := by
  intro m
  filter_upwards [eventually_gt_atTop m] with n hmn
  apply ProbabilityMeasure.toMeasure_injective
  simp only [νP, ProbabilityMeasure.toMeasure_map]
  rw [Measure.map_map (continuous_blockMap r₀ hr paths w m).measurable
    (continuous_down r₀ hr paths w n (m + 1)).measurable]
  congr 1
  funext U
  exact (down_succ r₀ hr paths w hmn U).symm

/-- At the finest level the coarse field is the configuration itself. -/
theorem νP_self (μ : ∀ n, ProbabilityMeasure (Cfg (Lk n))) (n : ℕ) :
    νP r₀ hr paths w μ n n = μ n := by
  apply ProbabilityMeasure.toMeasure_injective
  simp only [νP, ProbabilityMeasure.toMeasure_map]
  have : down r₀ hr paths w n n = id := funext (down_self r₀ hr paths w n)
  rw [this, Measure.map_id]

end Block

/-! ## 6. Axioms -/

#print axioms continuous_retract
#print axioms retract_of_le
#print axioms retract_of_lt
#print axioms norm_avg_le
#print axioms sixWeight_total
#print axioms continuous_sixAvg
#print axioms norm_sixAvg_le
#print axioms continuous_blockMap
#print axioms blockMap_of_small_field
#print axioms blockMap_of_lt
#print axioms down_succ
#print axioms down_self
#print axioms continuous_down
#print axioms hcons_blockMap
#print axioms νP_self
#print axioms pathProd_rev
#print axioms avg_rev
#print axioms sixAvg_rev
#print axioms retract_star
#print axioms blockMap_rev

end ChainBlockMap

/-! # L1 : the paths of the induction (`LatticePath.walk`, ℤ⁴) on the finite box

Paper: plan-01 §1 / : the induction's family is `LatticePath.walk μ o A` (six
orders, weights `(1/8, 3/4, 1/8)`, spine of two steps, reversed return) on `ℤ⁴`. Here it is carried
to the fine links of a finite box by an additive map `φ : ℤ⁴ →+ G` (e.g. the reduction to
`(ZMod N)⁴`) and a base point (the fine image of the coarse site): a signed link `(s, z, n)` goes to
the fine link `(x + φ z, n)` with orientation `s = −1` (backward, `star`). The definitions `tr`,
`ord`, `dv`, `ev`, `Link`, `fwd`, `back`, `walk` are copied from an earlier file (text-matched). Lean:
`walk_sign` (every step has sign `±1`, so the orientation flag is faithful), `walk_end` (copied),
**`walkCast_end`** (the cast path closes on `x + 2 φ(e_μ)`), and **`blockMap_walk`** (the block map
with these paths is continuous and is the projection on the small-field event). -/

namespace WalkCast

open Finset

def tr : Fin 4 → Fin 3 → Fin 4 := ![![1, 2, 3], ![0, 2, 3], ![0, 1, 3], ![0, 1, 2]]

/-- The six orders of the three transverse slots. -/
def ord : Fin 6 → Fin 3 → Fin 3 :=
  ![![0, 1, 2], ![0, 2, 1], ![1, 0, 2], ![1, 2, 0], ![2, 0, 1], ![2, 1, 0]]

/-- Displacement values and weights `(α, 1 − 2α, α)`, `α = 1/8`. -/
def dv : Fin 3 → ℤ := ![-1, 0, 1]
def ev (n : Fin 4) : Fin 4 → ℤ := Pi.single n 1

/-- A signed link: (sign, base point, direction). -/
abbrev Link := ℤ × (Fin 4 → ℤ) × Fin 4

/-- A forward transverse step of displacement `d` from `z` in direction `n`. -/
def fwd (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(1, z, n)] else if d = -1 then [(-1, z - ev n, n)] else []

/-- The step undoing it, from the point `w` reached after it. -/
def back (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : List Link :=
  if d = 1 then [(-1, w - ev n, n)] else if d = -1 then [(1, w, n)] else []

/-- The path of the coarse link in direction `μ` for the order `o` and the displacement
indices `A` (slot `t` is displaced by `dv (A t)` in direction `tr μ t`). -/
def walk (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : List Link :=
  let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  let z1 := d 0 • ev (n 0)
  let z2 := z1 + d 1 • ev (n 1)
  let z3 := z2 + d 2 • ev (n 2)
  let w3 := z3 + 2 • ev μ
  let w2 := w3 - d 2 • ev (n 2)
  let w1 := w2 - d 1 • ev (n 1)
  fwd (d 0) 0 (n 0) ++ fwd (d 1) z1 (n 1) ++ fwd (d 2) z2 (n 2) ++
    [(1, z3, μ), (1, z3 + ev μ, μ)] ++
    back (d 2) w3 (n 2) ++ back (d 1) w2 (n 1) ++ back (d 0) w1 (n 0)


theorem walk_end (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
    let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
    d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ
      - d 2 • ev (n 2) - d 1 • ev (n 1) - d 0 • ev (n 0) = 2 • ev μ := by
  intro n d
  abel

theorem fwd_sign (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) : ∀ l ∈ fwd d z n, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  unfold fwd at hl
  split_ifs at hl <;> simp_all

theorem back_sign (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) : ∀ l ∈ back d w n, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  unfold back at hl
  split_ifs at hl <;> simp_all

/-- Every step of the walk has sign `±1`. -/
theorem walk_sign (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    ∀ l ∈ walk μ o A, l.1 = 1 ∨ l.1 = -1 := by
  intro l hl
  simp only [walk, List.mem_append, List.mem_cons, List.not_mem_nil, or_false] at hl
  rcases hl with ((((((h | h) | h) | h | h) | h) | h) | h)
  · exact fwd_sign _ _ _ l h
  · exact fwd_sign _ _ _ l h
  · exact fwd_sign _ _ _ l h
  · left; rw [h]
  · left; rw [h]
  · exact back_sign _ _ _ l h
  · exact back_sign _ _ _ l h
  · exact back_sign _ _ _ l h

variable {G : Type*} [AddCommGroup G]

/-- A signed link of `ℤ⁴` to an oriented fine link of the box. -/
def linkCast (φ : (Fin 4 → ℤ) →+ G) (x : G) (l : Link) : (G × Fin 4) × Bool :=
  ((x + φ l.2.1, l.2.2), decide (l.1 = -1))

/-- The cast path closes on `x + 2 φ(e_μ)`. -/
theorem walkCast_end (φ : (Fin 4 → ℤ) →+ G) (x : G) (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
    let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
    x + φ (d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ
      - d 2 • ev (n 2) - d 1 • ev (n 1) - d 0 • ev (n 0)) = x + 2 • φ (ev μ) := by
  intro n d
  rw [walk_end μ o A, map_nsmul]

/-- The orientation flag is faithful: `true` exactly for the backward steps. -/
theorem linkCast_flag (φ : (Fin 4 → ℤ) →+ G) (x : G) {μ : Fin 4} {o : Fin 6} {A : Fin 3 → Fin 3}
    {l : Link} (hl : l ∈ walk μ o A) :
    ((linkCast φ x l).2 = true ↔ l.1 = -1) ∧ ((linkCast φ x l).2 = false ↔ l.1 = 1) := by
  rcases walk_sign μ o A l hl with h | h <;> simp [linkCast, h]

/-- The paths of the coarse link `b` (direction `dir b`, fine base point `base b`). -/
def pathsCast {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4) (b : Lc)
    (o : Fin 6) (A : Fin 3 → Fin 3) : List ((G × Fin 4) × Bool) :=
  (walk (dir b) o A).map (linkCast φ (base b))

open ChainBlockMap in
/-- **The block map on the box with the induction's paths**: continuous, and on the small-field
event it is the projection `q/|q|` of the induction. -/
theorem blockMap_walk {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    {r₀ : ℝ} (hr : 0 < r₀) (b : Lc) :
    Continuous (fun U : G × Fin 4 → Quaternion ℝ => retract r₀ (sixAvg (pathsCast φ base dir b) U)) ∧
    ∀ U : G × Fin 4 → Quaternion ℝ, r₀ ≤ ‖sixAvg (pathsCast φ base dir b) U‖ →
      retract r₀ (sixAvg (pathsCast φ base dir b) U) =
        ‖sixAvg (pathsCast φ base dir b) U‖⁻¹ • sixAvg (pathsCast φ base dir b) U := by
  refine ⟨(continuous_retract hr).comp (continuous_sixAvg _), fun U hU => ?_⟩
  exact (retract_of_le hr hU).1

end WalkCast

#print axioms WalkCast.walk_sign
#print axioms WalkCast.walkCast_end
#print axioms WalkCast.linkCast_flag
#print axioms WalkCast.blockMap_walk

/-! # L1 (round two): the concrete box and the reversed coarse link

Paper (for checking): plan-01 §1, (3), work-06 "紙のまま" of L1, 
* `BoxLk L m` = the oriented-positive links of the periodic box of side `2^m L` at level `m`
  (level `m + 1` is the finer one, side `2^(m+1) L`): a site `y ∈ (ZMod (2^m L))⁴` and a
  direction `μ`. The coarse site `y` sits at the fine site `2y` (`double`, well defined
  `ZMod (2^m L) → ZMod (2^(m+1) L)`), the walk is carried by the reduction `ℤ⁴ → (ZMod (2^(m+1) L))⁴`.
* `boxPaths`/`boxW` turn the indexed family `(o, A) ↦ walk` (with weights `sixWeight A`) into the
  `Finset` family with merged weights used by `ChainBlockMap.blockMap`; `coarseAvg_box` says the
  coarse value is exactly the six-order average of the walk (`sixAvg`).
* `walkRev` = the same recipe for the reversed coarse link `−b` (from `y + e_μ` to `y`): the same
  transverse steps in the same order, the spine two steps in `−μ`, the same return.
  `walk_flip_rev` (on `ℤ⁴`): the reversal of `walk` is `walkRev` shifted by `2 e_μ`.
  **`boxMap_rev`**: the coarse value of `−b` by this recipe is the conjugate of the value of `b`
  (this discharges the hypotheses `hP`, `hw` of `ChainBlockMap.blockMap_rev` on the walk).
* `boxWalk_end`: the cast walk of `b = (y, μ)` ends at the fine image `2(y + e_μ)` of the next
  coarse site, which is also the base point of the reversed recipe.
-/

namespace BoxWalk

open WalkCast ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

/-! ## 1. The reversed recipe on `ℤ⁴` -/

/-- Flip the orientation of a signed link. -/
def flipL (l : Link) : Link := (-l.1, l.2)

/-- Translate a signed link. -/
def shiftL (v : Fin 4 → ℤ) (l : Link) : Link := (l.1, l.2.1 + v, l.2.2)

/-- The recipe of `walk` for the reversed coarse link (direction `−μ`), started at the origin
(= the coarse end point): same transverse steps, spine `−μ` twice, same return. -/
def walkRev (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) : List Link :=
  let n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  let d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  let z1 := d 0 • ev (n 0)
  let z2 := z1 + d 1 • ev (n 1)
  let z3 := z2 + d 2 • ev (n 2)
  let w3 := z3 - 2 • ev μ
  let w2 := w3 - d 2 • ev (n 2)
  let w1 := w2 - d 1 • ev (n 1)
  fwd (d 0) 0 (n 0) ++ fwd (d 1) z1 (n 1) ++ fwd (d 2) z2 (n 2) ++
    [(-1, z3 - ev μ, μ), (-1, z3 - 2 • ev μ, μ)] ++
    back (d 2) w3 (n 2) ++ back (d 1) w2 (n 1) ++ back (d 0) w1 (n 0)

theorem fwd_flip_rev (d : ℤ) (z : Fin 4 → ℤ) (n : Fin 4) :
    ((fwd d z n).map flipL).reverse = back d (z + d • ev n) n := by
  unfold fwd back flipL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp [sub_eq_add_neg]
    · simp [h1, h2]

theorem back_flip_rev (d : ℤ) (w : Fin 4 → ℤ) (n : Fin 4) :
    ((back d w n).map flipL).reverse = fwd d (w - d • ev n) n := by
  unfold fwd back flipL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp
    · simp [h1, h2]

theorem fwd_shift (d : ℤ) (z v : Fin 4 → ℤ) (n : Fin 4) :
    (fwd d z n).map (shiftL v) = fwd d (z + v) n := by
  unfold fwd shiftL
  by_cases h1 : d = 1
  · subst h1; simp
  · by_cases h2 : d = -1
    · subst h2; simp only [if_neg (by decide : (-1 : ℤ) ≠ 1), if_true, List.map_cons,
        List.map_nil]
      congr 2; abel
    · simp [h1, h2]

theorem back_shift (d : ℤ) (w v : Fin 4 → ℤ) (n : Fin 4) :
    (back d w n).map (shiftL v) = back d (w + v) n := by
  unfold back shiftL
  by_cases h1 : d = 1
  · subst h1; simp only [if_true, List.map_cons, List.map_nil]
    congr 2; abel
  · by_cases h2 : d = -1
    · subst h2; simp
    · simp [h1, h2]

/-- The core identity with free displacements. -/
theorem flip_rev_core (d0 d1 d2 : ℤ) (n0 n1 n2 μ : Fin 4) :
    (((fwd d0 0 n0 ++ fwd d1 (d0 • ev n0) n1 ++ fwd d2 (d0 • ev n0 + d1 • ev n1) n2 ++
        [(1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2, μ),
          (1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + ev μ, μ)] ++
        back d2 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ) n2 ++
        back d1 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ - d2 • ev n2) n1 ++
        back d0 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 + 2 • ev μ - d2 • ev n2 - d1 • ev n1) n0
        ).map flipL).reverse) =
      (fwd d0 0 n0 ++ fwd d1 (d0 • ev n0) n1 ++ fwd d2 (d0 • ev n0 + d1 • ev n1) n2 ++
        [(-1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - ev μ, μ),
          (-1, d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ, μ)] ++
        back d2 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ) n2 ++
        back d1 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ - d2 • ev n2) n1 ++
        back d0 (d0 • ev n0 + d1 • ev n1 + d2 • ev n2 - 2 • ev μ - d2 • ev n2 - d1 • ev n1) n0
        ).map (shiftL (2 • ev μ)) := by
  simp only [List.map_append, List.reverse_append, fwd_flip_rev, back_flip_rev, fwd_shift,
    back_shift, List.map_cons, List.map_nil, List.reverse_cons, List.reverse_nil, List.nil_append,
    flipL, shiftL, List.append_assoc, List.cons_append, List.singleton_append]
  abel_nf

/-- **The reversal of the walk is the reversed recipe, shifted to the end point `2 e_μ`.** -/
theorem walk_flip_rev (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    ((walk μ o A).map flipL).reverse = (walkRev μ o A).map (shiftL (2 • ev μ)) :=
  flip_rev_core _ _ _ _ _ _ μ

/-! ## 2. Casting to the fine links -/

variable {G : Type*} [AddCommGroup G]

theorem linkCast_shift (φ : (Fin 4 → ℤ) →+ G) (x : G) (v : Fin 4 → ℤ) (l : Link) :
    linkCast φ x (shiftL v l) = linkCast φ (x + φ v) l := by
  simp only [linkCast, shiftL, map_add]
  congr 2
  abel

theorem linkCast_flip (φ : (Fin 4 → ℤ) →+ G) (x : G) {l : Link} (h : l.1 = 1 ∨ l.1 = -1) :
    linkCast φ x (flipL l) = ((linkCast φ x l).1, !(linkCast φ x l).2) := by
  rcases h with h | h <;> simp [linkCast, flipL, h]

/-- The cast of the reversed walk (walked backwards) is the cast of the reversed recipe from
`x + 2 φ(e_μ)`. -/
theorem revPath_walkCast (φ : (Fin 4 → ℤ) →+ G) (x : G) (μ : Fin 4) (o : Fin 6)
    (A : Fin 3 → Fin 3) :
    revPath ((walk μ o A).map (linkCast φ x)) =
      (walkRev μ o A).map (linkCast φ (x + 2 • φ (ev μ))) := by
  have h1 : revPath ((walk μ o A).map (linkCast φ x)) =
      (((walk μ o A).map flipL).reverse).map (linkCast φ x) := by
    rw [revPath, List.map_reverse, List.map_map, List.map_map]
    congr 1
    refine List.map_congr_left fun l hl => ?_
    simp only [Function.comp_apply]
    rw [linkCast_flip φ x (walk_sign μ o A l hl)]
  rw [h1, walk_flip_rev, List.map_map]
  congr 1
  funext l
  simp only [Function.comp_apply, linkCast_shift, map_nsmul]

/-- The family of the reversed coarse link by the same recipe. -/
def pathsCastRev {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    (b : Lc) (o : Fin 6) (A : Fin 3 → Fin 3) : List ((G × Fin 4) × Bool) :=
  (walkRev (dir b) o A).map (linkCast φ (base b + 2 • φ (ev (dir b))))

/-- **The reversed coarse link carries the conjugate** ((3) on the walk). -/
theorem retract_sixAvg_rev {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G)
    (dir : Lc → Fin 4) (r₀ : ℝ) (b : Lc) (U : G × Fin 4 → ℍr) :
    retract r₀ (sixAvg (pathsCastRev φ base dir b) U) =
      star (retract r₀ (sixAvg (pathsCast φ base dir b) U)) := by
  rw [← retract_star]
  congr 1
  exact sixAvg_rev _ _ (fun o A => (revPath_walkCast φ (base b) (dir b) o A).symm) U

/-! ## 3. Indexed families as `Finset` families with merged weights -/

section Merge

variable {L : Type*} [DecidableEq L]

/-- The `Finset` of the paths of an indexed family. -/
def famSet (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) : Finset (List (L × Bool)) :=
  univ.image fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2

/-- Merged weight of a path: the total weight of the indices giving it. -/
noncomputable def famW (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (γ : List (L × Bool)) :
    ℝ :=
  ∑ p ∈ univ.filter (fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2 = γ), sixWeight p.2

theorem avg_famSet (P : Fin 6 → (Fin 3 → Fin 3) → List (L × Bool)) (U : L → ℍr) :
    avg U (famSet P) (famW P) = sixAvg P U := by
  unfold avg famSet famW sixAvg
  simp only [Finset.sum_smul]
  rw [← Fintype.sum_prod_type' (fun o A => sixWeight A • pathProd U (P o A))]
  rw [← Finset.sum_fiberwise_of_maps_to (s := univ)
    (t := univ.image fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2)
    (g := fun p : Fin 6 × (Fin 3 → Fin 3) => P p.1 p.2)
    (fun p _ => Finset.mem_image_of_mem _ (Finset.mem_univ p))]
  refine Finset.sum_congr rfl fun γ _ => Finset.sum_congr rfl fun p hp => ?_
  rw [(Finset.mem_filter.1 hp).2]

end Merge

/-! ## 4. The periodic boxes `(ZMod (2^m L))⁴` -/

section Box

variable (L : ℕ) [NeZero L]

/-- Sites of the box at level `m` (side `2^m L`). -/
abbrev Site (m : ℕ) := Fin 4 → ZMod (2 ^ m * L)

/-- Positively oriented links of the box at level `m`. -/
abbrev BoxLk (m : ℕ) := Site L m × Fin 4

instance (m : ℕ) : NeZero (2 ^ m * L) := ⟨Nat.mul_ne_zero (pow_ne_zero _ two_ne_zero) (NeZero.ne L)⟩

instance (m : ℕ) : Fintype (BoxLk L m) := inferInstance

/-- `ZMod (2^m L) → ZMod (2^(m+1) L)`, `y ↦ 2y` (well defined). -/
def double (m : ℕ) : ZMod (2 ^ m * L) →+ ZMod (2 ^ (m + 1) * L) :=
  ZMod.lift (2 ^ m * L) ⟨(Int.castAddHom (ZMod (2 ^ (m + 1) * L))).comp
      (AddMonoidHom.mulLeft (2 : ℤ)), by
    simp only [AddMonoidHom.coe_comp, Function.comp_apply, AddMonoidHom.coe_mulLeft,
      Int.coe_castAddHom]
    have : ((2 * ((2 ^ m * L : ℕ) : ℤ) : ℤ) : ZMod (2 ^ (m + 1) * L)) =
        ((2 ^ (m + 1) * L : ℕ) : ZMod (2 ^ (m + 1) * L)) := by
      push_cast; ring
    rw [this, ZMod.natCast_self]⟩

theorem double_intCast (m : ℕ) (k : ℤ) :
    double L m (k : ZMod (2 ^ m * L)) = ((2 * k : ℤ) : ZMod (2 ^ (m + 1) * L)) := by
  simp [double, ZMod.lift_coe]

/-- The reduction `ℤ⁴ → (ZMod (2^(m+1) L))⁴` carrying the walk to the fine box. -/
def red (m : ℕ) : (Fin 4 → ℤ) →+ Site L (m + 1) :=
  AddMonoidHom.compLeft (Int.castAddHom (ZMod (2 ^ (m + 1) * L))) (Fin 4)

/-- Fine base point `2y` of the coarse link `(y, μ)`. -/
def base (m : ℕ) (b : BoxLk L m) : Site L (m + 1) := fun i => double L m (b.1 i)

/-- Direction of a link. -/
def dirB (m : ℕ) (b : BoxLk L m) : Fin 4 := b.2

/-- The indexed paths of the coarse link `b` on the fine box. -/
def boxPathsIdx (m : ℕ) (b : BoxLk L m) (o : Fin 6) (A : Fin 3 → Fin 3) :
    List (BoxLk L (m + 1) × Bool) :=
  pathsCast (red L m) (base L m) (dirB L m) b o A

/-- The paths and merged weights of the block map on the box. -/
def boxPaths (m : ℕ) (b : BoxLk L m) : Finset (List (BoxLk L (m + 1) × Bool)) :=
  famSet (boxPathsIdx L m b)

noncomputable def boxW (m : ℕ) (b : BoxLk L m) : List (BoxLk L (m + 1) × Bool) → ℝ :=
  famW (boxPathsIdx L m b)

/-- **The coarse value on the box is the six-order average of the induction's walk.** -/
theorem coarseAvg_box (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    coarseAvg (boxPaths L) (boxW L) m U b = sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr)) :=
  avg_famSet _ _

theorem boxMap_eq {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
      retract r₀ (sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))) := by
  simp only [blockMap, coarseAvg_box]

/-- On the small-field event the box map is the projection `q/|q|` of the induction. -/
theorem boxMap_small {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1)))
    (b : BoxLk L m) (hq : r₀ ≤ ‖sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))‖) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
        ‖sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr))‖⁻¹ •
          sixAvg (boxPathsIdx L m b) (fun ℓ => (U ℓ : ℍr)) ∧
      ‖(blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr)‖ = 1 := by
  have h := blockMap_of_small_field r₀ hr (boxPaths L) (boxW L) m U b
    (by rwa [coarseAvg_box])
  rwa [coarseAvg_box] at h

/-- **The reversed coarse link on the box**: the recipe from `2(y + e_μ)` in direction `−μ`
gives the conjugate of the box map's value on `b = (y, μ)`. -/
theorem boxMap_rev {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    retract r₀ (sixAvg (pathsCastRev (red L m) (base L m) (dirB L m) b) (fun ℓ => (U ℓ : ℍr))) =
      star (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) := by
  rw [boxMap_eq L hr, retract_sixAvg_rev]
  rfl

/-- **End point**: the cast walk of `(y, μ)` ends at `2(y + e_μ)`, the fine image of the next
coarse site (and the base point of the reversed recipe). -/
theorem boxWalk_end (m : ℕ) (b : BoxLk L m) :
    base L m b + 2 • red L m (ev (dirB L m b)) =
      base L m (b.1 + Pi.single b.2 (1 : ZMod (2 ^ m * L)), b.2) := by
  funext i
  simp only [base, dirB, red, Pi.add_apply, Pi.smul_apply, AddMonoidHom.compLeft_apply,
    Function.comp_apply, Int.coe_castAddHom, map_add, ev]
  by_cases h : i = b.2
  · subst h
    have : double L m (1 : ZMod (2 ^ m * L)) = 2 := by
      have := double_intCast L m 1
      simpa using this
    simp [this]
  · simp [h]

/-- The ball-valued configurations of the box carry the instances the chain needs. -/
example (m : ℕ) : CompactSpace (Cfg (BoxLk L m)) := inferInstance
example (m : ℕ) : BorelSpace (Cfg (BoxLk L m)) := inferInstance

end Box

end BoxWalk

#print axioms BoxWalk.walk_flip_rev
#print axioms BoxWalk.revPath_walkCast
#print axioms BoxWalk.retract_sixAvg_rev
#print axioms BoxWalk.avg_famSet
#print axioms BoxWalk.coarseAvg_box
#print axioms BoxWalk.boxMap_eq
#print axioms BoxWalk.boxMap_small
#print axioms BoxWalk.boxMap_rev
#print axioms BoxWalk.boxWalk_end

/-! # L1-2 (round two): locality (B3) of the box map

Paper (for checking): plan-09 §1 L1-2, paper A (B3). `walk_reach`: every link of the walk has its
base point within sup-distance 2 of the origin (displacements in `{−1, 0, 1}`, spine of two steps),
checked by `decide` over the 4·6·27 walks. **`boxMap_local`**: the coarse value on `b = (y, μ)`
depends only on the fine links based in the cube of radius 2 around `2y`; the reach `R = 2`
(fine units) does not depend on the level `m` nor on the side `L`.
-/

namespace BoxWalk

open WalkCast ChainBlockMap

local notation "ℍr" => Quaternion ℝ

theorem walk_reach : ∀ μ : Fin 4, ∀ o : Fin 6, ∀ A : Fin 3 → Fin 3,
    ∀ l ∈ walk μ o A, ∀ i, -2 ≤ l.2.1 i ∧ l.2.1 i ≤ 2 := by
  decide

theorem pathProd_congr {Lt : Type*} (U U' : Lt → ℍr) :
    ∀ γ : List (Lt × Bool), (∀ s ∈ γ, U s.1 = U' s.1) → pathProd U γ = pathProd U' γ := by
  intro γ
  induction γ with
  | nil => intro _; rfl
  | cons s rest ih =>
    intro h
    simp only [pathProd, List.map_cons, List.prod_cons] at ih ⊢
    rw [ih fun s' hs' => h s' (List.mem_cons_of_mem _ hs')]
    congr 1
    unfold stepVal
    rw [h s List.mem_cons_self]

variable (L : ℕ) [NeZero L]

/-- **(B3) for the box map**: the value on `b` depends only on the fine links in the cube of
radius 2 around the fine base point `2y`. -/
theorem boxMap_local {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (U U' : Cfg (BoxLk L (m + 1)))
    (b : BoxLk L m)
    (h : ∀ z : Fin 4 → ℤ, (∀ i, -2 ≤ z i ∧ z i ≤ 2) → ∀ ν,
      U (base L m b + red L m z, ν) = U' (base L m b + red L m z, ν)) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) =
      (blockMap r₀ hr (boxPaths L) (boxW L) m U' b : ℍr) := by
  rw [boxMap_eq L hr, boxMap_eq L hr]
  refine congrArg (retract r₀) ?_
  unfold sixAvg
  refine Finset.sum_congr rfl fun o _ => Finset.sum_congr rfl fun A _ => ?_
  refine congrArg (sixWeight A • ·) ?_
  refine pathProd_congr _ _ _ fun s hs => ?_
  simp only [boxPathsIdx, pathsCast, List.mem_map] at hs
  obtain ⟨l, hl, rfl⟩ := hs
  simp only [linkCast, dirB]
  rw [h l.2.1 (walk_reach _ o A l hl) l.2.2]

end BoxWalk

#print axioms BoxWalk.walk_reach
#print axioms BoxWalk.boxMap_local

/-! # L1-4 (round two): gauge covariance (B2) of the box map

Paper (for checking): plan-09 §1 L1-4, paper A (B2); `LatticeBlockReflection.covariant_path`,
`covariant_average`, `covariant_retract` (companion file) are the abstract form. Here, on the box:
* `Chain x γ y` (on `ℤ⁴`): the signed links of `γ` form a connected path from `x` to `y`
  (forward `(1, z, n)` goes `z → z + e_n`, backward `(−1, z, n)` goes `z + e_n → z`).
  `walk_chain`: the induction's walk is a path from `0` to `2 e_μ` (displacements in `{−1, 0, 1}`).
* `gaugeLink g U (x, ν) = g x · U(x, ν) · g(x + e_ν)*` (the gauge action on fine links).
  `pathProd_gauge`: the product along a cast path from `x₀ + φ x` to `x₀ + φ y` is sandwiched
  by `g(x₀ + φ x)` and `g(x₀ + φ y)*`.
* **`boxMap_gauge`**: the box map is equivariant: its value on the coarse link `(y, μ)` is
  sandwiched by `g(2y)` and `g(2(y + e_μ))*`, i.e. by the restriction of `g` to the even sites
  (= the coarse sites). This is (B2) for the concrete box map.
-/

namespace BoxWalk

open WalkCast ChainBlockMap Finset

local notation "ℍr" => Quaternion ℝ

/-! ## 1. Paths on `ℤ⁴` -/

/-- Start and end of a signed link. -/
def srcL (l : Link) : Fin 4 → ℤ := if l.1 = 1 then l.2.1 else l.2.1 + ev l.2.2
def tgtL (l : Link) : Fin 4 → ℤ := if l.1 = 1 then l.2.1 + ev l.2.2 else l.2.1

/-- `γ` is a connected path from `x` to `y`. -/
def Chain : (Fin 4 → ℤ) → List Link → (Fin 4 → ℤ) → Prop
  | x, [], y => x = y
  | x, l :: rest, y => srcL l = x ∧ Chain (tgtL l) rest y

theorem chain_append : ∀ {x y z : Fin 4 → ℤ} {γ δ : List Link},
    Chain x γ y → Chain y δ z → Chain x (γ ++ δ) z
  | x, y, z, [], δ, h₁, h₂ => by
    simp only [Chain] at h₁; subst h₁; simpa using h₂
  | x, y, z, l :: γ, δ, h₁, h₂ => by
    simp only [Chain, List.cons_append] at h₁ ⊢
    exact ⟨h₁.1, chain_append h₁.2 h₂⟩

theorem chain_fwd {d : ℤ} (hd : d = 1 ∨ d = 0 ∨ d = -1) (z y : Fin 4 → ℤ) (n : Fin 4)
    (hy : y = z + d • ev n) : Chain z (fwd d z n) y := by
  subst hy
  rcases hd with h | h | h <;> subst h
  · simp [fwd, Chain, srcL, tgtL]
  · simp [fwd, Chain]
  · simp [fwd, Chain, srcL, tgtL]
    abel

theorem chain_back {d : ℤ} (hd : d = 1 ∨ d = 0 ∨ d = -1) (w y : Fin 4 → ℤ) (n : Fin 4)
    (hy : y = w - d • ev n) : Chain w (back d w n) y := by
  subst hy
  rcases hd with h | h | h <;> subst h
  · simp [back, Chain, srcL, tgtL]
  · simp [back, Chain]
  · simp [back, Chain, srcL, tgtL]

theorem dv_mem (a : Fin 3) : dv a = 1 ∨ dv a = 0 ∨ dv a = -1 := by
  fin_cases a <;> simp [dv]

/-- **The walk is a connected path from `0` to `2 e_μ`.** -/
theorem walk_chain (μ : Fin 4) (o : Fin 6) (A : Fin 3 → Fin 3) :
    Chain 0 (walk μ o A) (2 • ev μ) := by
  unfold walk
  simp only
  set n : Fin 3 → Fin 4 := fun j => tr μ (ord o j)
  set d : Fin 3 → ℤ := fun j => dv (A (ord o j))
  have hd : ∀ j, d j = 1 ∨ d j = 0 ∨ d j = -1 := fun j => dv_mem _
  have hs : Chain (d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2))
      [(1, d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2), μ),
        (1, d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + ev μ, μ)]
      (d 0 • ev (n 0) + d 1 • ev (n 1) + d 2 • ev (n 2) + 2 • ev μ) := by
    simp only [Chain, srcL, tgtL, if_true, true_and]
    abel
  exact chain_append (chain_append (chain_append (chain_append (chain_append (chain_append
    (chain_fwd (hd 0) _ _ _ (by abel)) (chain_fwd (hd 1) _ _ _ (by abel)))
    (chain_fwd (hd 2) _ _ _ (by abel))) hs)
    (chain_back (hd 2) _ _ _ (by abel))) (chain_back (hd 1) _ _ _ (by abel)))
    (chain_back (hd 0) _ _ _ (by abel))

/-! ## 2. Gauge action on the fine links and the path products -/

section Gauge

variable {G : Type*} [AddCommGroup G]

/-- Gauge action on fine link variables: `(x, ν) ↦ g x · U(x, ν) · g(x + φ e_ν)*`. -/
noncomputable def gaugeLink (φ : (Fin 4 → ℤ) →+ G) (g : G → ℍr) (U : G × Fin 4 → ℍr) :
    G × Fin 4 → ℍr :=
  fun ℓ => g ℓ.1 * U ℓ * star (g (ℓ.1 + φ (ev ℓ.2)))

theorem star_mul_unit {q : ℍr} (h : ‖q‖ = 1) : star q * q = 1 := by
  have : (star q * q : ℍr) = ((‖q‖ * ‖q‖ : ℝ) : ℍr) := by
    rw [Quaternion.star_mul_self, Quaternion.normSq_eq_norm_mul_self]
  rw [this, h, mul_one, Quaternion.coe_one]

theorem mul_star_unit {q : ℍr} (h : ‖q‖ = 1) : q * star q = 1 := by
  have : (q * star q : ℍr) = ((‖q‖ * ‖q‖ : ℝ) : ℍr) := by
    rw [Quaternion.self_mul_star, Quaternion.normSq_eq_norm_mul_self]
  rw [this, h, mul_one, Quaternion.coe_one]

/-- One step of a cast path is a covariant transport from its start to its end. -/
theorem stepVal_gauge (φ : (Fin 4 → ℤ) →+ G) (g : G → ℍr) (U : G × Fin 4 → ℍr) (x₀ : G)
    {l : Link} (hl : l.1 = 1 ∨ l.1 = -1) :
    stepVal (gaugeLink φ g U) (linkCast φ x₀ l) =
      g (x₀ + φ (srcL l)) * stepVal U (linkCast φ x₀ l) * star (g (x₀ + φ (tgtL l))) := by
  rcases hl with h | h
  · simp [stepVal, linkCast, gaugeLink, srcL, tgtL, h, map_add, add_assoc]
  · have h1 : (l.1 = 1) = False := by simp [h]
    simp only [stepVal, linkCast, gaugeLink, srcL, tgtL, h, decide_true, if_true,
      if_neg (by decide : (-1 : ℤ) ≠ 1), star_mul, star_star, map_add, add_assoc, mul_assoc]

/-- **The product along a cast path is covariant from its start to its end.** -/
theorem pathProd_gauge (φ : (Fin 4 → ℤ) →+ G) (g : G → ℍr) (hg : ∀ x, ‖g x‖ = 1)
    (U : G × Fin 4 → ℍr) (x₀ : G) :
    ∀ (γ : List Link) (x y : Fin 4 → ℤ), (∀ l ∈ γ, l.1 = 1 ∨ l.1 = -1) → Chain x γ y →
      pathProd (gaugeLink φ g U) (γ.map (linkCast φ x₀)) =
        g (x₀ + φ x) * pathProd U (γ.map (linkCast φ x₀)) * star (g (x₀ + φ y)) := by
  intro γ
  induction γ with
  | nil =>
    intro x y _ h
    simp only [Chain] at h
    subst h
    simp [pathProd, mul_star_unit (hg _)]
  | cons l rest ih =>
    intro x y hs h
    simp only [Chain] at h
    obtain ⟨hsrc, hrest⟩ := h
    have hl := hs l List.mem_cons_self
    have ih' := ih (tgtL l) y (fun l' hl' => hs l' (List.mem_cons_of_mem _ hl')) hrest
    simp only [List.map_cons, pathProd, List.prod_cons] at ih' ⊢
    rw [stepVal_gauge φ g U x₀ hl, ih', hsrc]
    have e : g (x₀ + φ x) * stepVal U (linkCast φ x₀ l) * star (g (x₀ + φ (tgtL l))) *
        (g (x₀ + φ (tgtL l)) * (List.map (stepVal U) (List.map (linkCast φ x₀) rest)).prod *
          star (g (x₀ + φ y))) =
        g (x₀ + φ x) * stepVal U (linkCast φ x₀ l) *
          (star (g (x₀ + φ (tgtL l))) * g (x₀ + φ (tgtL l))) *
          (List.map (stepVal U) (List.map (linkCast φ x₀) rest)).prod * star (g (x₀ + φ y)) := by
      simp only [mul_assoc]
    rw [e, star_mul_unit (hg _), mul_one]
    simp only [mul_assoc]

/-- The six-order average of the cast walk is covariant from `x₀` to `x₀ + 2 φ(e_μ)`. -/
theorem sixAvg_gauge {Lc : Type*} (φ : (Fin 4 → ℤ) →+ G) (base : Lc → G) (dir : Lc → Fin 4)
    (g : G → ℍr) (hg : ∀ x, ‖g x‖ = 1) (U : G × Fin 4 → ℍr) (b : Lc) :
    sixAvg (pathsCast φ base dir b) (gaugeLink φ g U) =
      g (base b) * sixAvg (pathsCast φ base dir b) U * star (g (base b + 2 • φ (ev (dir b)))) := by
  unfold sixAvg pathsCast
  rw [Finset.mul_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun o _ => ?_
  rw [Finset.mul_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun A _ => ?_
  rw [pathProd_gauge φ g hg U (base b) _ 0 (2 • ev (dir b)) (walk_sign _ _ _) (walk_chain _ _ _)]
  simp only [map_zero, add_zero, map_nsmul, mul_smul_comm, smul_mul_assoc]

theorem retract_mul_unit (r₀ : ℝ) (u v q : ℍr) (hu : ‖u‖ = 1) (hv : ‖v‖ = 1) :
    retract r₀ (u * q * v) = u * retract r₀ q * v := by
  unfold retract
  have hn : ‖u * q * v‖ = ‖q‖ := by rw [norm_mul, norm_mul, hu, hv, one_mul, mul_one]
  rw [hn, mul_smul_comm, smul_mul_assoc]

end Gauge

/-! ## 3. On the box -/

section BoxG

variable (L : ℕ) [NeZero L]

/-- The gauge action on ball-valued fine configurations of the box (unit `g` keeps the ball). -/
noncomputable def gaugeCfg (m : ℕ) (g : Site L (m + 1) → ℍr) (hg : ∀ x, ‖g x‖ = 1)
    (U : Cfg (BoxLk L (m + 1))) : Cfg (BoxLk L (m + 1)) :=
  fun ℓ => ⟨gaugeLink (red L m) g (fun ℓ' => (U ℓ' : ℍr)) ℓ, by
    rw [mem_ball_iff]
    simp only [gaugeLink, norm_mul, norm_star, hg, one_mul, mul_one]
    exact (mem_ball_iff _).1 (U ℓ).2⟩

/-- **(B2) for the box map**: the coarse value on `(y, μ)` of the gauge-transformed field is
sandwiched by `g(2y)` and `g(2(y + e_μ))*` (the restriction of `g` to the coarse sites). -/
theorem boxMap_gauge {r₀ : ℝ} (hr : 0 < r₀) (m : ℕ) (g : Site L (m + 1) → ℍr)
    (hg : ∀ x, ‖g x‖ = 1) (U : Cfg (BoxLk L (m + 1))) (b : BoxLk L m) :
    (blockMap r₀ hr (boxPaths L) (boxW L) m (gaugeCfg L m g hg U) b : ℍr) =
      g (base L m b) * (blockMap r₀ hr (boxPaths L) (boxW L) m U b : ℍr) *
        star (g (base L m (b.1 + Pi.single b.2 (1 : ZMod (2 ^ m * L)), b.2))) := by
  rw [boxMap_eq L hr, boxMap_eq L hr, ← boxWalk_end L m b]
  have h := sixAvg_gauge (red L m) (base L m) (dirB L m) g hg (fun ℓ' => (U ℓ' : ℍr)) b
  have h' : sixAvg (boxPathsIdx L m b) (fun ℓ => ((gaugeCfg L m g hg U ℓ : Ball) : ℍr)) =
      g (base L m b) * sixAvg (boxPathsIdx L m b) (fun ℓ' => (U ℓ' : ℍr)) *
        star (g (base L m b + 2 • red L m (ev (dirB L m b)))) := h
  rw [h']
  exact retract_mul_unit r₀ _ _ _ (hg _) (by rw [norm_star]; exact hg _)

end BoxG

end BoxWalk

#print axioms BoxWalk.walk_chain
#print axioms BoxWalk.pathProd_gauge
#print axioms BoxWalk.sixAvg_gauge
#print axioms BoxWalk.boxMap_gauge
