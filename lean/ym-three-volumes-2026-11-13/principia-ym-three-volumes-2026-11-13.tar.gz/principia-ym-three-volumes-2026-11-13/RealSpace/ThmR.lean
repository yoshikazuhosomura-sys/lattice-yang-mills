import Mathlib

/-!
# Theorem R in real space: weighted Combes–Thomas for the constrained Green function

Copied core (from an earlier file, unchanged): `quad_mono`,
`re_inner_expand_lower`, the `λ`-norm and the relative coercivity lemma (Lemma 1′) with its
a priori bound. New : the assembly of Theorem R with a real-space weight `W`
(no Bloch fibres, no contour shift, no Kato gap symmetry, no antiunitary `Θ`, no dimension count):
the solution of the constrained problem, multiplied by `W`, *is* the solution of the shifted
Petrov–Galerkin problem, so only the a priori bound is needed.
-/

namespace RealSpaceThmR

open RCLike

lemma quad_mono {X x₀ a R : ℝ} (hR : 0 ≤ R) (hX : x₀ * R ≤ X) (hx₀ : a / 2 ≤ x₀) :
    (x₀ ^ 2 - a * x₀) * R ^ 2 ≤ X ^ 2 - a * R * X := by
  have h1 : 0 ≤ X - x₀ * R := by linarith
  have h2 : 0 ≤ X + x₀ * R - a * R := by nlinarith
  nlinarith [mul_nonneg h1 h2]

section Expand
variable {𝕜 F : Type*} [RCLike 𝕜] [NormedAddCommGroup F] [InnerProductSpace 𝕜 F]

local notation "⟪" x ", " y "⟫" => inner 𝕜 x y

/-- `re ⟪a + b + c, a + e⟫ ≥ ‖a‖² − ‖a‖‖e‖ − ‖b‖‖a‖ − ‖b‖‖e‖ − ‖c‖‖a‖ − ‖c‖‖e‖`. -/
lemma re_inner_expand_lower (a b c e : F) :
    ‖a‖ ^ 2 - ‖a‖ * ‖e‖ - ‖b‖ * ‖a‖ - ‖b‖ * ‖e‖ - ‖c‖ * ‖a‖ - ‖c‖ * ‖e‖
      ≤ re ⟪a + b + c, a + e⟫ := by
  have hexp : ⟪a + b + c, a + e⟫ = ⟪a, a⟫ + ⟪a, e⟫ + ⟪b, a⟫ + ⟪b, e⟫ + ⟪c, a⟫ + ⟪c, e⟫ := by
    simp only [inner_add_left, inner_add_right]; ring
  have haa : re ⟪a, a⟫ = ‖a‖ ^ 2 := by
    rw [← inner_self_eq_norm_sq (𝕜 := 𝕜)]
  have hae := re_inner_le_norm (𝕜 := 𝕜) a e
  have hae' : -(‖a‖ * ‖e‖) ≤ re ⟪a, e⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-a) e
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  have hba' : -(‖b‖ * ‖a‖) ≤ re ⟪b, a⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-b) a
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  have hbe' : -(‖b‖ * ‖e‖) ≤ re ⟪b, e⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-b) e
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  have hca' : -(‖c‖ * ‖a‖) ≤ re ⟪c, a⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-c) a
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  have hce' : -(‖c‖ * ‖e‖) ≤ re ⟪c, e⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-c) e
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  rw [hexp]
  simp only [map_add]
  linarith
end Expand


section Relative

variable {𝕜 E F : Type*} [RCLike 𝕜] [NormedAddCommGroup E] [InnerProductSpace 𝕜 E]
  [NormedAddCommGroup F] [InnerProductSpace 𝕜 F]

local notation "⟪" x ", " y "⟫" => inner 𝕜 x y

/-- The `λ`-norm `‖y‖_λ = √(‖B₀ y‖² + (r ‖y‖)²)` (`r = √λ`). -/
noncomputable def lamNorm (B₀ : E →ₗ[𝕜] F) (r : ℝ) (y : E) : ℝ :=
  Real.sqrt (‖B₀ y‖ ^ 2 + (r * ‖y‖) ^ 2)

lemma lamNorm_nonneg (B₀ : E →ₗ[𝕜] F) (r : ℝ) (y : E) : 0 ≤ lamNorm B₀ r y :=
  Real.sqrt_nonneg _

lemma lamNorm_sq (B₀ : E →ₗ[𝕜] F) (r : ℝ) (y : E) :
    lamNorm B₀ r y ^ 2 = ‖B₀ y‖ ^ 2 + (r * ‖y‖) ^ 2 :=
  Real.sq_sqrt (by positivity)

lemma norm_B0_le_lamNorm (B₀ : E →ₗ[𝕜] F) (r : ℝ) (y : E) : ‖B₀ y‖ ≤ lamNorm B₀ r y := by
  apply Real.le_sqrt_of_sq_le
  nlinarith [sq_nonneg (r * ‖y‖)]

lemma r_norm_le_lamNorm (B₀ : E →ₗ[𝕜] F) {r : ℝ} (_hr : 0 ≤ r) (y : E) :
    r * ‖y‖ ≤ lamNorm B₀ r y := by
  apply Real.le_sqrt_of_sq_le
  nlinarith [sq_nonneg ‖B₀ y‖]

/-- Minkowski: the `λ`-norm satisfies the triangle inequality. -/
lemma lamNorm_add_le (B₀ : E →ₗ[𝕜] F) {r : ℝ} (hr : 0 ≤ r) (a b : E) :
    lamNorm B₀ r (a + b) ≤ lamNorm B₀ r a + lamNorm B₀ r b := by
  set pa := ‖B₀ a‖; set pb := ‖B₀ b‖; set qa := r * ‖a‖; set qb := r * ‖b‖
  set Na := lamNorm B₀ r a; set Nb := lamNorm B₀ r b
  have hNa : Na ^ 2 = pa ^ 2 + qa ^ 2 := lamNorm_sq B₀ r a
  have hNb : Nb ^ 2 = pb ^ 2 + qb ^ 2 := lamNorm_sq B₀ r b
  have hNa0 : 0 ≤ Na := lamNorm_nonneg _ _ _
  have hNb0 : 0 ≤ Nb := lamNorm_nonneg _ _ _
  have hp : ‖B₀ (a + b)‖ ≤ pa + pb := by rw [map_add]; exact norm_add_le _ _
  have hq : r * ‖a + b‖ ≤ qa + qb := by
    rw [← mul_add]; exact mul_le_mul_of_nonneg_left (norm_add_le a b) hr
  have hp0 : 0 ≤ ‖B₀ (a + b)‖ := norm_nonneg _
  have hq0 : 0 ≤ r * ‖a + b‖ := mul_nonneg hr (norm_nonneg _)
  have hpa : 0 ≤ pa := norm_nonneg _
  have hpb : 0 ≤ pb := norm_nonneg _
  have hqa : 0 ≤ qa := mul_nonneg hr (norm_nonneg _)
  have hqb : 0 ≤ qb := mul_nonneg hr (norm_nonneg _)
  -- Cauchy–Schwarz in ℝ²
  have hcs : pa * pb + qa * qb ≤ Na * Nb := by
    have h1 : (pa * pb + qa * qb) ^ 2 ≤ (Na * Nb) ^ 2 := by
      rw [mul_pow, hNa, hNb]; nlinarith [sq_nonneg (pa * qb - qa * pb)]
    nlinarith [mul_nonneg hNa0 hNb0, sq_nonneg (pa * pb + qa * qb - Na * Nb),
      mul_nonneg hpa hpb, mul_nonneg hqa hqb]
  apply Real.sqrt_le_iff.mpr
  refine ⟨add_nonneg hNa0 hNb0, ?_⟩
  have e1 : ‖B₀ (a + b)‖ ^ 2 ≤ (pa + pb) ^ 2 := pow_le_pow_left₀ hp0 hp 2
  have e2 : (r * ‖a + b‖) ^ 2 ≤ (qa + qb) ^ 2 := pow_le_pow_left₀ hq0 hq 2
  nlinarith [e1, e2, hcs, hNa, hNb]

/-- On the comparison space (`r‖s‖ ≤ ‖B₀ s‖`) the `λ`-norm is at most `√2 ‖B₀ s‖`. -/
lemma lamNorm_le_of_pos (B₀ : E →ₗ[𝕜] F) {r s₂ : ℝ} (hr : 0 ≤ r) (hs₂ : 0 ≤ s₂) (hs₂sq : s₂ ^ 2 = 2)
    {s : E} (hpos : r * ‖s‖ ≤ ‖B₀ s‖) : lamNorm B₀ r s ≤ s₂ * ‖B₀ s‖ := by
  apply Real.sqrt_le_iff.mpr
  refine ⟨mul_nonneg hs₂ (norm_nonneg _), ?_⟩
  have h0 : 0 ≤ r * ‖s‖ := mul_nonneg hr (norm_nonneg _)
  have h1 : (r * ‖s‖) ^ 2 ≤ ‖B₀ s‖ ^ 2 := pow_le_pow_left₀ h0 hpos 2
  have h2 : (s₂ * ‖B₀ s‖) ^ 2 = 2 * ‖B₀ s‖ ^ 2 := by rw [mul_pow, hs₂sq]
  rw [h2]; linarith

/-- **Coercivity of the shifted Petrov–Galerkin form, relative version (Lemma 1′).**
`N = ‖x‖_λ`; closeness `‖x − s‖_λ ≤ δ₊ N`, `‖v − x‖_λ ≤ δ₋ N`; shifts `‖(B_± − B₀) y‖ ≤ ε ‖y‖_λ`.
Then `re ⟪B₋ v, B₊ x⟫ ≥ (x₀² − a x₀ − b) N²` with `x₀ = (1−δ₊)/√2 − δ₊`,
`a = δ₋ + ε(2+δ₋)`, `b = ε(δ₋ + ε(1+δ₋))`. -/
theorem shifted_coercive_rel (B₀ Bp Bm : E →ₗ[𝕜] F) {x s v : E} {r ε δp δm s₂ : ℝ}
    (hr : 0 ≤ r) (hε : 0 ≤ ε) (hδm : 0 ≤ δm) (hs₂ : 0 < s₂) (hs₂sq : s₂ ^ 2 = 2)
    (hpos : r * ‖s‖ ≤ ‖B₀ s‖)
    (hBp : ∀ y, ‖(Bp - B₀) y‖ ≤ ε * lamNorm B₀ r y)
    (hBm : ∀ y, ‖(Bm - B₀) y‖ ≤ ε * lamNorm B₀ r y)
    (hs : lamNorm B₀ r (x - s) ≤ δp * lamNorm B₀ r x)
    (hv : lamNorm B₀ r (v - x) ≤ δm * lamNorm B₀ r x)
    (hx₀ : (δm + ε * (2 + δm)) / 2 ≤ (1 - δp) / s₂ - δp) :
    (((1 - δp) / s₂ - δp) ^ 2 - (δm + ε * (2 + δm)) * ((1 - δp) / s₂ - δp)
        - ε * (δm + ε * (1 + δm))) * lamNorm B₀ r x ^ 2 ≤ re ⟪Bm v, Bp x⟫ := by
  set N := lamNorm B₀ r x with hN
  set x₀ := (1 - δp) / s₂ - δp with hx₀def
  set a := δm + ε * (2 + δm) with ha
  set b := ε * (δm + ε * (1 + δm)) with hb
  have hN0 : 0 ≤ N := lamNorm_nonneg _ _ _
  -- ‖s‖_λ ≥ (1 − δ₊) N
  have hNs : (1 - δp) * N ≤ lamNorm B₀ r s := by
    have := lamNorm_add_le B₀ hr s (x - s)
    rw [add_sub_cancel] at this
    nlinarith [this, hs]
  -- ‖B₀ s‖ ≥ ‖s‖_λ / √2
  have hBs : lamNorm B₀ r s / s₂ ≤ ‖B₀ s‖ := by
    rw [div_le_iff₀ hs₂]
    have := lamNorm_le_of_pos B₀ hr hs₂.le hs₂sq hpos
    linarith [mul_comm s₂ ‖B₀ s‖]
  -- X = ‖B₀ x‖ ≥ x₀ N
  have hXs : ‖B₀ s‖ ≤ ‖B₀ x‖ + ‖B₀ (x - s)‖ := by
    have : B₀ s = B₀ x - B₀ (x - s) := by rw [map_sub]; abel
    rw [this]; exact norm_sub_le _ _
  have hBxs : ‖B₀ (x - s)‖ ≤ δp * N := le_trans (norm_B0_le_lamNorm B₀ r _) hs
  have hX : x₀ * N ≤ ‖B₀ x‖ := by
    have h1 : (1 - δp) * N / s₂ ≤ lamNorm B₀ r s / s₂ :=
      div_le_div_of_nonneg_right hNs hs₂.le
    have h2 : x₀ * N = (1 - δp) * N / s₂ - δp * N := by
      rw [hx₀def]; field_simp
    rw [h2]; linarith
  -- the remaining pieces
  have hUB : ‖B₀ (v - x)‖ ≤ δm * N := le_trans (norm_B0_le_lamNorm B₀ r _) hv
  have he : ‖(Bp - B₀) x‖ ≤ ε * N := hBp x
  have hvN : lamNorm B₀ r v ≤ N + δm * N := by
    have := lamNorm_add_le B₀ hr x (v - x)
    rw [add_sub_cancel] at this
    linarith
  have hc : ‖(Bm - B₀) v‖ ≤ ε * (N + δm * N) :=
    le_trans (hBm v) (mul_le_mul_of_nonneg_left hvN hε)
  have hdecv : Bm v = B₀ x + B₀ (v - x) + (Bm - B₀) v := by
    simp only [LinearMap.sub_apply, map_sub]; abel
  have hdecx : Bp x = B₀ x + (Bp - B₀) x := by
    simp only [LinearMap.sub_apply]; abel
  have hexp := re_inner_expand_lower (𝕜 := 𝕜) (B₀ x) (B₀ (v - x)) ((Bm - B₀) v) ((Bp - B₀) x)
  rw [← hdecv, ← hdecx] at hexp
  set X := ‖B₀ x‖
  have hXn : 0 ≤ X := norm_nonneg _
  have hUBn : 0 ≤ ‖B₀ (v - x)‖ := norm_nonneg _
  have hen := norm_nonneg ((Bp - B₀) x)
  have hcn := norm_nonneg ((Bm - B₀) v)
  have key : X ^ 2 - a * N * X - b * N ^ 2
      ≤ X ^ 2 - X * ‖(Bp - B₀) x‖ - ‖B₀ (v - x)‖ * X - ‖B₀ (v - x)‖ * ‖(Bp - B₀) x‖
          - ‖(Bm - B₀) v‖ * X - ‖(Bm - B₀) v‖ * ‖(Bp - B₀) x‖ := by
    have t1 : X * ‖(Bp - B₀) x‖ ≤ X * (ε * N) := mul_le_mul_of_nonneg_left he hXn
    have t2 : ‖B₀ (v - x)‖ * X ≤ (δm * N) * X := mul_le_mul_of_nonneg_right hUB hXn
    have t3 : ‖B₀ (v - x)‖ * ‖(Bp - B₀) x‖ ≤ (δm * N) * (ε * N) :=
      mul_le_mul hUB he hen (by positivity)
    have t4 : ‖(Bm - B₀) v‖ * X ≤ (ε * (N + δm * N)) * X := mul_le_mul_of_nonneg_right hc hXn
    have t5 : ‖(Bm - B₀) v‖ * ‖(Bp - B₀) x‖ ≤ (ε * (N + δm * N)) * (ε * N) :=
      mul_le_mul hc he hen (by positivity)
    have : a * N * X + b * N ^ 2 = X * (ε * N) + (δm * N) * X + (δm * N) * (ε * N)
        + (ε * (N + δm * N)) * X + (ε * (N + δm * N)) * (ε * N) := by
      rw [ha, hb]; ring
    nlinarith [t1, t2, t3, t4, t5, this]
  have hq := quad_mono (a := a) hN0 hX hx₀
  nlinarith [hq, key, hexp]

/-- A priori bound in the relative version: `‖x‖ ≤ (1+δ₋)‖w‖/(c r²)`. -/
theorem apriori_bound_rel (B₀ Bp Bm : E →ₗ[𝕜] F) {x v w : E} {r c δm : ℝ} (hr : 0 < r)
    (hc : 0 < c) (hδm : 0 ≤ δm)
    (hcoer : c * lamNorm B₀ r x ^ 2 ≤ re ⟪Bm v, Bp x⟫) (hsol : ⟪Bm v, Bp x⟫ = inner 𝕜 v w)
    (hv : lamNorm B₀ r (v - x) ≤ δm * lamNorm B₀ r x) :
    ‖x‖ ≤ (1 + δm) * ‖w‖ / (c * r ^ 2) := by
  set N := lamNorm B₀ r x
  have hN0 : 0 ≤ N := lamNorm_nonneg _ _ _
  have hrx : r * ‖x‖ ≤ N := r_norm_le_lamNorm B₀ hr.le x
  have hrvx : r * ‖v - x‖ ≤ δm * N := le_trans (r_norm_le_lamNorm B₀ hr.le _) hv
  have hvn : ‖v‖ ≤ ‖x‖ + ‖v - x‖ := by
    have := norm_add_le x (v - x); simpa using this
  have hrv : r * ‖v‖ ≤ (1 + δm) * N := by
    have := mul_le_mul_of_nonneg_left hvn hr.le
    nlinarith [hrx, hrvx]
  rw [hsol] at hcoer
  have h1 : re (inner 𝕜 v w) ≤ ‖v‖ * ‖w‖ := re_inner_le_norm v w
  have hw0 := norm_nonneg w
  -- r c N² ≤ r ‖v‖ ‖w‖ ≤ (1+δm) N ‖w‖
  have h2 : r * (c * N ^ 2) ≤ (1 + δm) * N * ‖w‖ := by
    have : r * (c * N ^ 2) ≤ r * (‖v‖ * ‖w‖) := mul_le_mul_of_nonneg_left (by linarith) hr.le
    nlinarith [mul_le_mul_of_nonneg_right hrv hw0]
  rw [le_div_iff₀ (by positivity)]
  rcases hN0.eq_or_lt with h0 | hNpos
  · have : r * ‖x‖ ≤ 0 := by rw [h0]; exact hrx
    have hx0 : ‖x‖ = 0 := by
      have := (mul_nonpos_iff.mp this)
      rcases this with ⟨_, h⟩ | ⟨h, _⟩
      · exact le_antisymm h (norm_nonneg _)
      · linarith
    rw [hx0]; nlinarith
  · have h3 : r * c * N ≤ (1 + δm) * ‖w‖ := by
      have : r * c * N * N ≤ (1 + δm) * ‖w‖ * N := by nlinarith [h2]
      exact le_of_mul_le_mul_right this hNpos
    have h4 : c * r ^ 2 * ‖x‖ ≤ r * c * N := by
      have := mul_le_mul_of_nonneg_left hrx (mul_nonneg hr.le hc.le)
      nlinarith [this]
    nlinarith [h3, h4]

end Relative


/-! ## 9. Monotonicity of the constant and numerical instances -/

/-! ## New : the real-space assembly of Theorem R -/

section Assembly

variable {𝕜 E F : Type*} [RCLike 𝕜] [NormedAddCommGroup E] [InnerProductSpace 𝕜 E]
  [NormedAddCommGroup F] [InnerProductSpace 𝕜 F]
variable {Z : Type*} [NormedAddCommGroup Z] [NormedSpace 𝕜 Z]

local notation "⟪" x ", " y "⟫" => inner 𝕜 x y

lemma lamNorm_neg (B : E →ₗ[𝕜] F) (r : ℝ) (y : E) : lamNorm B r (-y) = lamNorm B r y := by
  unfold lamNorm; rw [map_neg, norm_neg, norm_neg]

/-- **The weighted solution solves the shifted problem.**  `x` solves the constrained problem
(`⟪B u, B x⟫ = ⟪u, w⟫` for `u ∈ ker T`); `W` is self-adjoint with left inverse `Winv`;
`⟪B₋ u, B₊ y⟫ = ⟪B (W u), B (W⁻¹ y)⟫` (in real space `B₊ = W_F B W⁻¹`, `B₋ = W_F⁻¹ B W`).
Then for every test vector `v` with `W v ∈ ker T`: `⟪B₋ v, B₊ (W x)⟫ = ⟪v, W w⟫`. -/
theorem weighted_solution (B Bp Bm : E →ₗ[𝕜] F) (T : E →ₗ[𝕜] Z) (W Winv : E →ₗ[𝕜] E)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hBpm : ∀ u y, ⟪Bm u, Bp y⟫ = ⟪B (W u), B (Winv y)⟫)
    {x w : E} (hsol : ∀ u, T u = 0 → ⟪B u, B x⟫ = ⟪u, w⟫) {v : E} (hv : T (W v) = 0) :
    ⟪Bm v, Bp (W x)⟫ = ⟪v, W w⟫ := by
  rw [hBpm, hWW, hsol _ hv, hWadj]

/-- **Theorem R, real-space form.**  Inputs: (R1) positivity on `ker T`, (R2) the shifted forms
are `ε`-close in the `λ`-norm, (R3) the trial slice `S₊ = W ker T` is `δ₊`-close to `ker T` and
`δ₋`-close to the test slice `S₋ = W⁻¹ ker T`.  Output: `‖W x‖ ≤ (1+δ₋)‖W w‖/(c r²)`.
No existence or dimension argument is needed: `W x` is the solution. -/
theorem thmR_weighted (B Bp Bm : E →ₗ[𝕜] F) (T : E →ₗ[𝕜] Z) (W Winv : E →ₗ[𝕜] E)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hBpm : ∀ u y, ⟪Bm u, Bp y⟫ = ⟪B (W u), B (Winv y)⟫)
    {r ε δp δm s₂ : ℝ} (hr : 0 < r) (hε : 0 ≤ ε) (hδm : 0 ≤ δm) (hs₂ : 0 < s₂)
    (hs₂sq : s₂ ^ 2 = 2)
    (hR1 : ∀ s, T s = 0 → r * ‖s‖ ≤ ‖B s‖)
    (hR2p : ∀ y, ‖(Bp - B) y‖ ≤ ε * lamNorm B r y)
    (hR2m : ∀ y, ‖(Bm - B) y‖ ≤ ε * lamNorm B r y)
    (hR3p : ∀ y, T (Winv y) = 0 → ∃ s, T s = 0 ∧ lamNorm B r (y - s) ≤ δp * lamNorm B r y)
    (hR3m : ∀ y, T (Winv y) = 0 →
      ∃ v, T (W v) = 0 ∧ lamNorm B r (v - y) ≤ δm * lamNorm B r y)
    (hx₀ : (δm + ε * (2 + δm)) / 2 ≤ (1 - δp) / s₂ - δp)
    (hc : 0 < ((1 - δp) / s₂ - δp) ^ 2 - (δm + ε * (2 + δm)) * ((1 - δp) / s₂ - δp)
        - ε * (δm + ε * (1 + δm)))
    {x w : E} (hx : T x = 0) (hsol : ∀ u, T u = 0 → ⟪B u, B x⟫ = ⟪u, w⟫) :
    ‖W x‖ ≤ (1 + δm) * ‖W w‖ / ((((1 - δp) / s₂ - δp) ^ 2
        - (δm + ε * (2 + δm)) * ((1 - δp) / s₂ - δp) - ε * (δm + ε * (1 + δm))) * r ^ 2) := by
  have hxp : T (Winv (W x)) = 0 := by rw [hWW]; exact hx
  obtain ⟨s, hs0, hs⟩ := hR3p _ hxp
  obtain ⟨v, hv0, hv⟩ := hR3m _ hxp
  have hcoer := shifted_coercive_rel B Bp Bm hr.le hε hδm hs₂ hs₂sq (hR1 s hs0) hR2p hR2m hs hv hx₀
  exact apriori_bound_rel B Bp Bm hr hc hδm hcoer
    (weighted_solution B Bp Bm T W Winv hWW hWadj hBpm hsol hv0) hv

/-- **Reading the entries.**  `W` is diagonal in an orthonormal family `e` with weights
`ω > 0`.  From `‖W x‖ ≤ M ‖W e_j‖` (the solution with source `e_j`):
`|⟪e_i, x⟫| ≤ M ω_j / ω_i`. -/
theorem entry_decay {ι : Type*} (e : ι → E) (he : ∀ i, ‖e i‖ = 1) (W : E →ₗ[𝕜] E)
    (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫) (ω : ι → ℝ) (hω : ∀ i, 0 < ω i)
    (hWe : ∀ i, W (e i) = (ω i : 𝕜) • e i) {M : ℝ} {x : E} {j : ι}
    (hbound : ‖W x‖ ≤ M * ‖W (e j)‖) (i : ι) :
    ‖⟪e i, x⟫‖ ≤ M * (ω j / ω i) := by
  have h1 : ⟪e i, W x⟫ = (ω i : 𝕜) * ⟪e i, x⟫ := by
    rw [← hWadj, hWe, inner_smul_left, RCLike.conj_ofReal]
  have h2 : ‖⟪e i, W x⟫‖ ≤ ‖W x‖ := by
    have := norm_inner_le_norm (𝕜 := 𝕜) (e i) (W x)
    rwa [he, one_mul] at this
  have h3 : ‖W (e j)‖ = ω j := by
    rw [hWe, norm_smul, RCLike.norm_ofReal, he, mul_one, abs_of_pos (hω j)]
  rw [h1, norm_mul, RCLike.norm_ofReal, abs_of_pos (hω i)] at h2
  rw [h3] at hbound
  rw [mul_div_assoc', le_div_iff₀ (hω i)]
  linarith [h2, hbound]

/-- With `ω = e^{ηρ}`: `ω_j/ω_i = e^{−η(ρ_i − ρ_j)}`. -/
lemma exp_ratio (η a b : ℝ) : Real.exp (η * b) / Real.exp (η * a) = Real.exp (-(η * (a - b))) := by
  rw [← Real.exp_sub]; congr 1; ring

/-! ### (R3) from a lift: no Kato, no `Θ` -/

/-- **Drift from a lift.**  `T₀ E₀ = 1`, `‖E₀ z‖_λ ≤ L ‖z‖`, `‖T₀ x‖ ≤ θ ‖x‖_λ`:
then `s = x − E₀ T₀ x ∈ ker T₀` with `‖x − s‖_λ ≤ L θ ‖x‖_λ`. -/
theorem drift_of_lift (B : E →ₗ[𝕜] F) (r : ℝ) (T0 : E →ₗ[𝕜] Z) (E0 : Z →ₗ[𝕜] E)
    (hTE : ∀ z, T0 (E0 z) = z) {L θ : ℝ} (hL0 : 0 ≤ L)
    (hL : ∀ z, lamNorm B r (E0 z) ≤ L * ‖z‖) {x : E}
    (hθ : ‖T0 x‖ ≤ θ * lamNorm B r x) :
    T0 (x - E0 (T0 x)) = 0 ∧
      lamNorm B r (x - (x - E0 (T0 x))) ≤ (L * θ) * lamNorm B r x := by
  refine ⟨by rw [map_sub, hTE, sub_self], ?_⟩
  rw [sub_sub_cancel]
  calc lamNorm B r (E0 (T0 x)) ≤ L * ‖T0 x‖ := hL _
    _ ≤ L * (θ * lamNorm B r x) := mul_le_mul_of_nonneg_left hθ hL0
    _ = (L * θ) * lamNorm B r x := by ring

/-- The test side: `v = x − E₋ T₋ x ∈ ker T₋` with `‖v − x‖_λ ≤ L₋ θ₋ ‖x‖_λ`. -/
theorem drift_of_lift_test (B : E →ₗ[𝕜] F) (r : ℝ) (Tm : E →ₗ[𝕜] Z) (Em : Z →ₗ[𝕜] E)
    (hTE : ∀ z, Tm (Em z) = z) {L θ : ℝ} (hL0 : 0 ≤ L)
    (hL : ∀ z, lamNorm B r (Em z) ≤ L * ‖z‖) {x : E}
    (hθ : ‖Tm x‖ ≤ θ * lamNorm B r x) :
    Tm (x - Em (Tm x)) = 0 ∧
      lamNorm B r ((x - Em (Tm x)) - x) ≤ (L * θ) * lamNorm B r x := by
  refine ⟨by rw [map_sub, hTE, sub_self], ?_⟩
  rw [sub_sub_cancel_left, lamNorm_neg]
  calc lamNorm B r (Em (Tm x)) ≤ L * ‖Tm x‖ := hL _
    _ ≤ L * (θ * lamNorm B r x) := mul_le_mul_of_nonneg_left hθ hL0
    _ = (L * θ) * lamNorm B r x := by ring

/-- **Theorem R with (R3) through lifts.**  `θ₊`: the defect `‖T y‖` of the trial slice
`S₊ = W ker T` in the `λ`-norm; `θ₋`: the defect `‖T₋ y‖` of `S₊` for the test constraint
`T₋` (`ker T₋ ⊆ W⁻¹ ker T`).  `L₀`, `L₋`: the `λ`-norm lift constants.  Then `δ₊ = L₀θ₊`,
`δ₋ = L₋θ₋`. -/
theorem thmR_lift (B Bp Bm : E →ₗ[𝕜] F) (T Tm : E →ₗ[𝕜] Z) (E0 Em : Z →ₗ[𝕜] E)
    (W Winv : E →ₗ[𝕜] E)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hBpm : ∀ u y, ⟪Bm u, Bp y⟫ = ⟪B (W u), B (Winv y)⟫)
    (hTE0 : ∀ z, T (E0 z) = z) (hTEm : ∀ z, Tm (Em z) = z)
    (hTm : ∀ v, Tm v = 0 → T (W v) = 0)
    {r ε L0 Lm θp θm s₂ : ℝ} (hr : 0 < r) (hε : 0 ≤ ε) (hL0 : 0 ≤ L0) (hLm : 0 ≤ Lm)
    (hθm : 0 ≤ θm) (hs₂ : 0 < s₂) (hs₂sq : s₂ ^ 2 = 2)
    (hR1 : ∀ s, T s = 0 → r * ‖s‖ ≤ ‖B s‖)
    (hR2p : ∀ y, ‖(Bp - B) y‖ ≤ ε * lamNorm B r y)
    (hR2m : ∀ y, ‖(Bm - B) y‖ ≤ ε * lamNorm B r y)
    (hE0 : ∀ z, lamNorm B r (E0 z) ≤ L0 * ‖z‖) (hEm : ∀ z, lamNorm B r (Em z) ≤ Lm * ‖z‖)
    (hDp : ∀ y, T (Winv y) = 0 → ‖T y‖ ≤ θp * lamNorm B r y)
    (hDm : ∀ y, T (Winv y) = 0 → ‖Tm y‖ ≤ θm * lamNorm B r y)
    (hx₀ : (Lm * θm + ε * (2 + Lm * θm)) / 2 ≤ (1 - L0 * θp) / s₂ - L0 * θp)
    (hc : 0 < ((1 - L0 * θp) / s₂ - L0 * θp) ^ 2
        - (Lm * θm + ε * (2 + Lm * θm)) * ((1 - L0 * θp) / s₂ - L0 * θp)
        - ε * (Lm * θm + ε * (1 + Lm * θm)))
    {x w : E} (hx : T x = 0) (hsol : ∀ u, T u = 0 → ⟪B u, B x⟫ = ⟪u, w⟫) :
    ‖W x‖ ≤ (1 + Lm * θm) * ‖W w‖ / ((((1 - L0 * θp) / s₂ - L0 * θp) ^ 2
        - (Lm * θm + ε * (2 + Lm * θm)) * ((1 - L0 * θp) / s₂ - L0 * θp)
        - ε * (Lm * θm + ε * (1 + Lm * θm))) * r ^ 2) := by
  refine thmR_weighted B Bp Bm T W Winv hWW hWadj hBpm hr hε (mul_nonneg hLm hθm) hs₂ hs₂sq
    hR1 hR2p hR2m ?_ ?_ hx₀ hc hx hsol
  · intro y hy
    obtain ⟨h1, h2⟩ := drift_of_lift B r T E0 hTE0 hL0 hE0 (hDp y hy)
    exact ⟨_, h1, h2⟩
  · intro y hy
    obtain ⟨h1, h2⟩ := drift_of_lift_test B r Tm Em hTEm hLm hEm (hDm y hy)
    exact ⟨_, hTm _ h1, h2⟩

/-! ### (R2) from locality: the `n` cancels -/

lemma exp_sub_one_le (y : ℝ) : Real.exp y - 1 ≤ y * Real.exp y := by
  have h := Real.add_one_le_exp (-y)
  have hpos := Real.exp_pos y
  have : Real.exp (-y) * Real.exp y = 1 := by rw [← Real.exp_add]; simp
  nlinarith [h, hpos, this]

/-- A local shift `‖(B₊ − B) y‖ ≤ β (e^{η/n} − 1) ‖y‖` with `r = r₀/n` gives
`ε = β η e^{η/n}/r₀` (independent of `n` except through `e^{η/n} ≤ e^{η}`). -/
theorem eps_of_local (B Bp : E →ₗ[𝕜] F) {n η β r₀ : ℝ} (hn : 0 < n) (hr₀ : 0 < r₀)
    (hβ : 0 ≤ β) (hη : 0 ≤ η)
    (hloc : ∀ y, ‖(Bp - B) y‖ ≤ β * (Real.exp (η / n) - 1) * ‖y‖) (y : E) :
    ‖(Bp - B) y‖ ≤ (β * η * Real.exp (η / n) / r₀) * lamNorm B (r₀ / n) y := by
  have hr : 0 < r₀ / n := div_pos hr₀ hn
  have hy : (r₀ / n) * ‖y‖ ≤ lamNorm B (r₀ / n) y := r_norm_le_lamNorm B hr.le y
  have hN0 := lamNorm_nonneg B (r₀ / n) y
  have he := exp_sub_one_le (η / n)
  have hy0 := norm_nonneg y
  -- ‖y‖ ≤ n N / r₀
  have hy' : ‖y‖ ≤ n * lamNorm B (r₀ / n) y / r₀ := by
    rw [le_div_iff₀ hr₀]
    have : (r₀ / n) * ‖y‖ * n = r₀ * ‖y‖ := by field_simp
    nlinarith [mul_le_mul_of_nonneg_right hy hn.le]
  refine (hloc y).trans ?_
  have h0 : 0 ≤ Real.exp (η / n) - 1 := by
    have := Real.one_le_exp (div_nonneg hη hn.le); linarith
  calc β * (Real.exp (η / n) - 1) * ‖y‖
      ≤ β * (Real.exp (η / n) - 1) * (n * lamNorm B (r₀ / n) y / r₀) :=
        mul_le_mul_of_nonneg_left hy' (mul_nonneg hβ h0)
    _ = β * (n * (Real.exp (η / n) - 1)) * lamNorm B (r₀ / n) y / r₀ := by ring
    _ ≤ β * (n * (η / n * Real.exp (η / n))) * lamNorm B (r₀ / n) y / r₀ := by
        gcongr
    _ = (β * η * Real.exp (η / n) / r₀) * lamNorm B (r₀ / n) y := by
        field_simp


/-! ### The one-step form version (the critical path of WALL1 §8.17: `h_k` on `ker Q ∩ Landau`)

Here the quadratic form is `h` (the level-`k` effective Hessian, nonlocal but band-analytic),
factored as `⟪u, h v⟫ = ⟪B u, B v⟫` (any square root).  The weighted form is an operator `hp`
with `⟪v, hp y⟫ = ⟪W v, h (W⁻¹ y)⟫` (for a linear weight this is the shifted symbol
`h(K + iη)`).  Only the form difference `hp − h` enters, relative to the `λ`-norm. -/

/-- **Coercivity, form version.**  `Re⟪v, hp x⟫ ≥ (x₀² − δ₋ x₀ − ε(1+δ₋)) ‖x‖_λ²`. -/
theorem form_coercive (B : E →ₗ[𝕜] F) (h hp : E →ₗ[𝕜] E)
    (hB : ∀ u v, ⟪u, h v⟫ = ⟪B u, B v⟫) {x s v : E} {r ε δp δm s₂ : ℝ}
    (hr : 0 ≤ r) (hε : 0 ≤ ε) (_hδm : 0 ≤ δm) (hs₂ : 0 < s₂) (hs₂sq : s₂ ^ 2 = 2)
    (hpos : r * ‖s‖ ≤ ‖B s‖)
    (hform : ∀ u y, ‖⟪u, (hp - h) y⟫‖ ≤ ε * lamNorm B r u * lamNorm B r y)
    (hs : lamNorm B r (x - s) ≤ δp * lamNorm B r x)
    (hv : lamNorm B r (v - x) ≤ δm * lamNorm B r x)
    (hx₀ : δm / 2 ≤ (1 - δp) / s₂ - δp) :
    (((1 - δp) / s₂ - δp) ^ 2 - δm * ((1 - δp) / s₂ - δp) - ε * (1 + δm))
      * lamNorm B r x ^ 2 ≤ re ⟪v, hp x⟫ := by
  set N := lamNorm B r x with hN
  set x₀ := (1 - δp) / s₂ - δp with hx₀def
  have hN0 : 0 ≤ N := lamNorm_nonneg _ _ _
  have hNs : (1 - δp) * N ≤ lamNorm B r s := by
    have := lamNorm_add_le B hr s (x - s)
    rw [add_sub_cancel] at this
    nlinarith [this, hs]
  have hBs : lamNorm B r s / s₂ ≤ ‖B s‖ := by
    rw [div_le_iff₀ hs₂]
    have := lamNorm_le_of_pos B hr hs₂.le hs₂sq hpos
    linarith [mul_comm s₂ ‖B s‖]
  have hXs : ‖B s‖ ≤ ‖B x‖ + ‖B (x - s)‖ := by
    have : B s = B x - B (x - s) := by rw [map_sub]; abel
    rw [this]; exact norm_sub_le _ _
  have hBxs : ‖B (x - s)‖ ≤ δp * N := le_trans (norm_B0_le_lamNorm B r _) hs
  have hX : x₀ * N ≤ ‖B x‖ := by
    have h1 : (1 - δp) * N / s₂ ≤ lamNorm B r s / s₂ :=
      div_le_div_of_nonneg_right hNs hs₂.le
    have h2 : x₀ * N = (1 - δp) * N / s₂ - δp * N := by
      rw [hx₀def]; field_simp
    rw [h2]; linarith
  have hUB : ‖B (v - x)‖ ≤ δm * N := le_trans (norm_B0_le_lamNorm B r _) hv
  have hvN : lamNorm B r v ≤ N + δm * N := by
    have := lamNorm_add_le B hr x (v - x)
    rw [add_sub_cancel] at this
    linarith
  -- split: ⟪v, hp x⟫ = ⟪B x, B x⟫ + ⟪B (v − x), B x⟫ + ⟪v, (hp − h) x⟫
  have e1 : ⟪v, (hp - h) x⟫ = ⟪v, hp x⟫ - ⟪v, h x⟫ := by
    rw [LinearMap.sub_apply, inner_sub_right]
  have e2 : ⟪v, h x⟫ = ⟪B x, B x⟫ + ⟪B (v - x), B x⟫ := by
    rw [hB, map_sub, inner_sub_left]; ring
  have hsplit : ⟪v, hp x⟫ = ⟪B x, B x⟫ + ⟪B (v - x), B x⟫ + ⟪v, (hp - h) x⟫ := by
    rw [e1, e2]; ring
  have hxx : re ⟪B x, B x⟫ = ‖B x‖ ^ 2 := by
    rw [← inner_self_eq_norm_sq (𝕜 := 𝕜)]
  have h2 : -(‖B (v - x)‖ * ‖B x‖) ≤ re ⟪B (v - x), B x⟫ := by
    have := re_inner_le_norm (𝕜 := 𝕜) (-B (v - x)) (B x)
    rw [inner_neg_left, map_neg, norm_neg] at this; linarith
  have h3 : -(ε * lamNorm B r v * N) ≤ re ⟪v, (hp - h) x⟫ := by
    have a1 := hform v x
    have a2 : |re ⟪v, (hp - h) x⟫| ≤ ‖⟪v, (hp - h) x⟫‖ := abs_re_le_norm _
    have := neg_abs_le (re ⟪v, (hp - h) x⟫)
    linarith
  have hre : re ⟪v, hp x⟫ = ‖B x‖ ^ 2 + re ⟪B (v - x), B x⟫ + re ⟪v, (hp - h) x⟫ := by
    rw [hsplit, map_add, map_add, hxx]
  set X := ‖B x‖
  have hX0 : 0 ≤ X := norm_nonneg _
  have t1 : ‖B (v - x)‖ * X ≤ δm * N * X := mul_le_mul_of_nonneg_right hUB hX0
  have t2 : ε * lamNorm B r v * N ≤ ε * (N + δm * N) * N :=
    mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hvN hε) hN0
  have hq := quad_mono (a := δm) hN0 hX hx₀
  nlinarith [hre, h2, h3, t1, t2, hq]

/-- A priori bound, form version: `‖x‖ ≤ (1+δ₋)‖w‖/(c r²)`. -/
theorem form_apriori (B : E →ₗ[𝕜] F) (hp : E →ₗ[𝕜] E) {x v w : E} {r c δm : ℝ} (hr : 0 < r)
    (hc : 0 < c) (_hδm : 0 ≤ δm)
    (hcoer : c * lamNorm B r x ^ 2 ≤ re ⟪v, hp x⟫) (hsol : ⟪v, hp x⟫ = ⟪v, w⟫)
    (hv : lamNorm B r (v - x) ≤ δm * lamNorm B r x) :
    ‖x‖ ≤ (1 + δm) * ‖w‖ / (c * r ^ 2) := by
  set N := lamNorm B r x
  have hN0 : 0 ≤ N := lamNorm_nonneg _ _ _
  have hrx : r * ‖x‖ ≤ N := r_norm_le_lamNorm B hr.le x
  have hrvx : r * ‖v - x‖ ≤ δm * N := le_trans (r_norm_le_lamNorm B hr.le _) hv
  have hvn : ‖v‖ ≤ ‖x‖ + ‖v - x‖ := by
    have := norm_add_le x (v - x); simpa using this
  have hrv : r * ‖v‖ ≤ (1 + δm) * N := by
    have := mul_le_mul_of_nonneg_left hvn hr.le
    nlinarith [hrx, hrvx]
  rw [hsol] at hcoer
  have h1 : re (inner 𝕜 v w) ≤ ‖v‖ * ‖w‖ := re_inner_le_norm v w
  have hw0 := norm_nonneg w
  have h2 : r * (c * N ^ 2) ≤ (1 + δm) * N * ‖w‖ := by
    have : r * (c * N ^ 2) ≤ r * (‖v‖ * ‖w‖) := mul_le_mul_of_nonneg_left (by linarith) hr.le
    nlinarith [mul_le_mul_of_nonneg_right hrv hw0]
  rw [le_div_iff₀ (by positivity)]
  rcases hN0.eq_or_lt with h0 | hNpos
  · have : r * ‖x‖ ≤ 0 := by rw [h0]; exact hrx
    have hx0 : ‖x‖ = 0 := by
      have := (mul_nonpos_iff.mp this)
      rcases this with ⟨_, h⟩ | ⟨h, _⟩
      · exact le_antisymm h (norm_nonneg _)
      · linarith
    rw [hx0]; nlinarith
  · have h3 : r * c * N ≤ (1 + δm) * ‖w‖ := by
      have : r * c * N * N ≤ (1 + δm) * ‖w‖ * N := by nlinarith [h2]
      exact le_of_mul_le_mul_right this hNpos
    have h4 : c * r ^ 2 * ‖x‖ ≤ r * c * N := by
      have := mul_le_mul_of_nonneg_left hrx (mul_nonneg hr.le hc.le)
      nlinarith [this]
    nlinarith [h3, h4]

/-- **Theorem R, one-step form version.**  `x` solves `⟪u, h x⟫ = ⟪u, w⟫` on `ker T`;
the weighted form `hp` satisfies `⟪v, hp y⟫ = ⟪W v, h (W⁻¹ y)⟫`.  Then
`‖W x‖ ≤ (1+δ₋)‖W w‖/(c r²)`, `c = x₀² − δ₋ x₀ − ε(1+δ₋)`. -/
theorem thmR_form (B : E →ₗ[𝕜] F) (h hp : E →ₗ[𝕜] E) (T : E →ₗ[𝕜] Z) (W Winv : E →ₗ[𝕜] E)
    (hB : ∀ u v, ⟪u, h v⟫ = ⟪B u, B v⟫)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hhp : ∀ u y, ⟪u, hp y⟫ = ⟪W u, h (Winv y)⟫)
    {r ε δp δm s₂ : ℝ} (hr : 0 < r) (hε : 0 ≤ ε) (hδm : 0 ≤ δm) (hs₂ : 0 < s₂)
    (hs₂sq : s₂ ^ 2 = 2)
    (hR1 : ∀ s, T s = 0 → r * ‖s‖ ≤ ‖B s‖)
    (hform : ∀ u y, ‖⟪u, (hp - h) y⟫‖ ≤ ε * lamNorm B r u * lamNorm B r y)
    (hR3p : ∀ y, T (Winv y) = 0 → ∃ s, T s = 0 ∧ lamNorm B r (y - s) ≤ δp * lamNorm B r y)
    (hR3m : ∀ y, T (Winv y) = 0 →
      ∃ v, T (W v) = 0 ∧ lamNorm B r (v - y) ≤ δm * lamNorm B r y)
    (hx₀ : δm / 2 ≤ (1 - δp) / s₂ - δp)
    (hc : 0 < ((1 - δp) / s₂ - δp) ^ 2 - δm * ((1 - δp) / s₂ - δp) - ε * (1 + δm))
    {x w : E} (hx : T x = 0) (hsol : ∀ u, T u = 0 → ⟪u, h x⟫ = ⟪u, w⟫) :
    ‖W x‖ ≤ (1 + δm) * ‖W w‖ /
      ((((1 - δp) / s₂ - δp) ^ 2 - δm * ((1 - δp) / s₂ - δp) - ε * (1 + δm)) * r ^ 2) := by
  have hxp : T (Winv (W x)) = 0 := by rw [hWW]; exact hx
  obtain ⟨s, hs0, hs⟩ := hR3p _ hxp
  obtain ⟨v, hv0, hv⟩ := hR3m _ hxp
  have hcoer := form_coercive B h hp hB hr.le hε hδm hs₂ hs₂sq (hR1 s hs0) hform hs hv hx₀
  refine form_apriori B hp hr hc hδm hcoer ?_ hv
  rw [hhp, hWW, hsol _ hv0, hWadj]

/-- (R2) from the band: `‖(hp − h) y‖ ≤ κ η ‖y‖` gives `ε = κ η / r²`. -/
theorem form_eps_of_band (B : E →ₗ[𝕜] F) (h hp : E →ₗ[𝕜] E) {r κ η : ℝ} (hr : 0 < r)
    (hκη : 0 ≤ κ * η) (hband : ∀ y, ‖(hp - h) y‖ ≤ κ * η * ‖y‖) (u y : E) :
    ‖⟪u, (hp - h) y⟫‖ ≤ (κ * η / r ^ 2) * lamNorm B r u * lamNorm B r y := by
  have hu := r_norm_le_lamNorm B hr.le u
  have hy := r_norm_le_lamNorm B hr.le y
  have h1 : ‖⟪u, (hp - h) y⟫‖ ≤ ‖u‖ * (κ * η * ‖y‖) :=
    (norm_inner_le_norm u _).trans (mul_le_mul_of_nonneg_left (hband y) (norm_nonneg _))
  have h2 : r ^ 2 * (‖u‖ * (κ * η * ‖y‖)) ≤ κ * η * (lamNorm B r u * lamNorm B r y) := by
    have : r ^ 2 * (‖u‖ * (κ * η * ‖y‖)) = κ * η * ((r * ‖u‖) * (r * ‖y‖)) := by ring
    rw [this]
    exact mul_le_mul_of_nonneg_left
      (mul_le_mul hu hy (by positivity) (lamNorm_nonneg _ _ _)) hκη
  have h3 : ‖u‖ * (κ * η * ‖y‖) ≤ (κ * η / r ^ 2) * lamNorm B r u * lamNorm B r y := by
    have e : (κ * η / r ^ 2) * lamNorm B r u * lamNorm B r y
        = κ * η * (lamNorm B r u * lamNorm B r y) / r ^ 2 := by ring
    rw [e, le_div_iff₀ (by positivity)]
    linarith [h2]
  exact h1.trans h3

/-- (R3) inputs from the bracket: an upper bound `‖B y‖ ≤ b ‖y‖` and a lift `‖E z‖ ≤ ℓ ‖z‖`
give the `λ`-norm lift constant `(b + r) ℓ`. -/
theorem lift_const_of_upper (B : E →ₗ[𝕜] F) (E0 : Z →ₗ[𝕜] E) {r b ℓ : ℝ} (hr : 0 ≤ r)
    (hb : 0 ≤ b) (hup : ∀ y, ‖B y‖ ≤ b * ‖y‖) (hE : ∀ z, ‖E0 z‖ ≤ ℓ * ‖z‖) (z : Z) :
    lamNorm B r (E0 z) ≤ ((b + r) * ℓ) * ‖z‖ := by
  have h1 : lamNorm B r (E0 z) ≤ (b + r) * ‖E0 z‖ := by
    apply Real.sqrt_le_iff.mpr
    refine ⟨by positivity, ?_⟩
    have := hup (E0 z)
    have h0 := norm_nonneg (B (E0 z))
    have hy0 := norm_nonneg (E0 z)
    nlinarith [mul_le_mul this this h0 (by positivity), mul_nonneg hb hr,
      mul_nonneg (mul_nonneg hb hr) (mul_nonneg hy0 hy0)]
  calc lamNorm B r (E0 z) ≤ (b + r) * ‖E0 z‖ := h1
    _ ≤ (b + r) * (ℓ * ‖z‖) := mul_le_mul_of_nonneg_left (hE z) (by positivity)
    _ = ((b + r) * ℓ) * ‖z‖ := by ring

/-- (R3) defect from a local constraint shift: on `S₊`, `T y = (T − T₊) y`, and
`‖(T − T₊) y‖ ≤ κ_T η ‖y‖` gives `θ = κ_T η / r`. -/
theorem theta_of_shift (B : E →ₗ[𝕜] F) (T Tp : E →ₗ[𝕜] Z) {r κT η : ℝ} (hr : 0 < r)
    (hκ : 0 ≤ κT * η) (hshift : ∀ y, ‖(T - Tp) y‖ ≤ κT * η * ‖y‖) {y : E} (hy : Tp y = 0) :
    ‖T y‖ ≤ (κT * η / r) * lamNorm B r y := by
  have e : T y = (T - Tp) y := by simp [hy]
  rw [e]
  have hyr := r_norm_le_lamNorm B hr.le y
  refine (hshift y).trans ?_
  rw [div_mul_eq_mul_div, le_div_iff₀ hr]
  nlinarith [mul_le_mul_of_nonneg_left hyr hκ]


/-! ### Small constants: an explicit uniform rate -/

/-- With `δ₊, δ₋ ≤ 1/10` and `ε ≤ 1/100`: `x₀ ≥ δ₋/2` and `c ≥ 1/5`. -/
theorem c_small {s₂ δp δm ε : ℝ} (hs : 0 < s₂) (hsq : s₂ ^ 2 = 2) (hp0 : 0 ≤ δp)
    (hp : δp ≤ 1 / 10) (hm0 : 0 ≤ δm) (hm : δm ≤ 1 / 10) (he0 : 0 ≤ ε) (he : ε ≤ 1 / 100) :
    δm / 2 ≤ (1 - δp) / s₂ - δp ∧
      1 / 5 ≤ ((1 - δp) / s₂ - δp) ^ 2 - δm * ((1 - δp) / s₂ - δp) - ε * (1 + δm) := by
  have hs1 : s₂ < 1415 / 1000 := by nlinarith
  have hs2 : 1414 / 1000 < s₂ := by nlinarith
  have hx_lo : 536 / 1000 ≤ (1 - δp) / s₂ - δp := by
    rw [le_sub_iff_add_le, le_div_iff₀ hs]; nlinarith
  have hx_hi : (1 - δp) / s₂ - δp ≤ 1 := by
    have : (1 - δp) / s₂ ≤ 1 := by rw [div_le_iff₀ hs]; nlinarith
    linarith
  refine ⟨by linarith, ?_⟩
  set x₀ := (1 - δp) / s₂ - δp
  nlinarith [mul_le_mul hx_lo hx_lo (by norm_num) (by linarith), mul_le_mul_of_nonneg_left hx_hi hm0,
    mul_le_mul_of_nonneg_left (show 1 + δm ≤ 11 / 10 by linarith) he0]

/-- **Theorem R, one-step form version with an explicit uniform constant.**
If the drifts are `≤ 1/10` and the form shift `≤ 1/100` (all achieved by taking `η` below an
explicit threshold, see `onestep_uniform`), then `‖W x‖ ≤ (11/2) ‖W w‖ / r²`. -/
theorem thmR_form_small (B : E →ₗ[𝕜] F) (h hp : E →ₗ[𝕜] E) (T : E →ₗ[𝕜] Z)
    (W Winv : E →ₗ[𝕜] E)
    (hB : ∀ u v, ⟪u, h v⟫ = ⟪B u, B v⟫)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hhp : ∀ u y, ⟪u, hp y⟫ = ⟪W u, h (Winv y)⟫)
    {r ε δp δm : ℝ} (hr : 0 < r) (he0 : 0 ≤ ε) (he : ε ≤ 1 / 100)
    (hδp0 : 0 ≤ δp) (hδp : δp ≤ 1 / 10) (hδm0 : 0 ≤ δm) (hδm : δm ≤ 1 / 10)
    (hR1 : ∀ s, T s = 0 → r * ‖s‖ ≤ ‖B s‖)
    (hform : ∀ u y, ‖⟪u, (hp - h) y⟫‖ ≤ ε * lamNorm B r u * lamNorm B r y)
    (hR3p : ∀ y, T (Winv y) = 0 → ∃ s, T s = 0 ∧ lamNorm B r (y - s) ≤ δp * lamNorm B r y)
    (hR3m : ∀ y, T (Winv y) = 0 →
      ∃ v, T (W v) = 0 ∧ lamNorm B r (v - y) ≤ δm * lamNorm B r y)
    {x w : E} (hx : T x = 0) (hsol : ∀ u, T u = 0 → ⟪u, h x⟫ = ⟪u, w⟫) :
    ‖W x‖ ≤ (11 / 2) * ‖W w‖ / r ^ 2 := by
  have hs₂ : 0 < Real.sqrt 2 := by positivity
  have hsq : Real.sqrt 2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  obtain ⟨hx₀, hc⟩ := c_small hs₂ hsq hδp0 hδp hδm0 hδm he0 he
  have hmain := thmR_form B h hp T W Winv hB hWW hWadj hhp hr he0 hδm0 hs₂ hsq hR1 hform hR3p hR3m
    hx₀ (by linarith) hx hsol
  set c := ((1 - δp) / Real.sqrt 2 - δp) ^ 2 - δm * ((1 - δp) / Real.sqrt 2 - δp)
    - ε * (1 + δm)
  have hw0 := norm_nonneg (W w)
  have hr2 : 0 < r ^ 2 := by positivity
  refine hmain.trans ?_
  rw [div_le_div_iff₀ (by positivity) hr2]
  have h1 : (1 + δm) * ‖W w‖ ≤ (11 / 10) * ‖W w‖ := mul_le_mul_of_nonneg_right (by linarith) hw0
  have h2 : (11 / 10) * ‖W w‖ * r ^ 2 ≤ (11 / 2) * ‖W w‖ * (c * r ^ 2) := by
    have : (11 / 10) * ‖W w‖ * r ^ 2 = (11 / 2) * ‖W w‖ * ((1 / 5) * r ^ 2) := by ring
    rw [this]
    exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hc hr2.le) (by positivity)
  nlinarith [mul_le_mul_of_nonneg_right h1 hr2.le]

/-- **The uniform one-step decay** (all inputs named constants; nothing depends on the stage
except through these constants).  Inputs:
* `r² = λ`: positivity of `h` on `ker T` (`T` = one-step constraint and one-layer Landau);
* `κ`: band Lipschitz `‖(h₊ − h) y‖ ≤ κ η ‖y‖`;
* `b`: upper bound `‖B y‖ ≤ b ‖y‖` (`b² = sup ‖h‖`);
* `ℓ₀, ℓ₋`: `L²` lifts of `T` and of the test constraint `T₋`;
* `κT, κTm`: local constraint shifts `‖(T − T₊) y‖ ≤ κT η ‖y‖`, `‖(T₋ − T₊) y‖ ≤ κTm η ‖y‖`.
For `η` with `(b+r)ℓ₀κT η/r ≤ 1/10`, `(b+r)ℓ₋κTm η/r ≤ 1/10`, `κη/r² ≤ 1/100`:
`‖W x‖ ≤ (11/2)‖W w‖/r²`. -/
theorem onestep_uniform (B : E →ₗ[𝕜] F) (h hp : E →ₗ[𝕜] E) (T Tp Tm : E →ₗ[𝕜] Z)
    (E0 Em : Z →ₗ[𝕜] E) (W Winv : E →ₗ[𝕜] E)
    (hB : ∀ u v, ⟪u, h v⟫ = ⟪B u, B v⟫)
    (hWW : ∀ y, Winv (W y) = y) (hWadj : ∀ u y, ⟪W u, y⟫ = ⟪u, W y⟫)
    (hhp : ∀ u y, ⟪u, hp y⟫ = ⟪W u, h (Winv y)⟫)
    (hTE0 : ∀ z, T (E0 z) = z) (hTEm : ∀ z, Tm (Em z) = z)
    (hTm : ∀ v, Tm v = 0 → T (W v) = 0) (hTp : ∀ y, T (Winv y) = 0 → Tp y = 0)
    {r κ b ℓ0 ℓm κT κTm η : ℝ} (hr : 0 < r) (hκ : 0 ≤ κ) (hb : 0 ≤ b) (hℓ0 : 0 ≤ ℓ0)
    (hℓm : 0 ≤ ℓm) (hκT : 0 ≤ κT) (hκTm : 0 ≤ κTm) (hη : 0 ≤ η)
    (hR1 : ∀ s, T s = 0 → r * ‖s‖ ≤ ‖B s‖)
    (hband : ∀ y, ‖(hp - h) y‖ ≤ κ * η * ‖y‖)
    (hup : ∀ y, ‖B y‖ ≤ b * ‖y‖)
    (hE0 : ∀ z, ‖E0 z‖ ≤ ℓ0 * ‖z‖) (hEm : ∀ z, ‖Em z‖ ≤ ℓm * ‖z‖)
    (hshT : ∀ y, ‖(T - Tp) y‖ ≤ κT * η * ‖y‖) (hshTm : ∀ y, ‖(Tm - Tp) y‖ ≤ κTm * η * ‖y‖)
    (hηp : (b + r) * ℓ0 * (κT * η / r) ≤ 1 / 10)
    (hηm : (b + r) * ℓm * (κTm * η / r) ≤ 1 / 10)
    (hηe : κ * η / r ^ 2 ≤ 1 / 100)
    {x w : E} (hx : T x = 0) (hsol : ∀ u, T u = 0 → ⟪u, h x⟫ = ⟪u, w⟫) :
    ‖W x‖ ≤ (11 / 2) * ‖W w‖ / r ^ 2 := by
  have hL0 := lift_const_of_upper B E0 hr.le hb hup hE0
  have hLm := lift_const_of_upper B Em hr.le hb hup hEm
  have hθ0 : 0 ≤ κT * η := mul_nonneg hκT hη
  have hθm0 : 0 ≤ κTm * η := mul_nonneg hκTm hη
  refine thmR_form_small B h hp T W Winv hB hWW hWadj hhp hr (by positivity) hηe
    (by positivity) hηp (by positivity) hηm hR1
    (form_eps_of_band B h hp hr (mul_nonneg hκ hη) hband) ?_ ?_ hx hsol
  · intro y hy
    have hθ := theta_of_shift B T Tp hr hθ0 hshT (hTp y hy)
    obtain ⟨h1, h2⟩ := drift_of_lift B r T E0 hTE0 (by positivity) hL0 hθ
    exact ⟨_, h1, h2⟩
  · intro y hy
    have hθ := theta_of_shift B Tm Tp hr hθm0 hshTm (hTp y hy)
    obtain ⟨h1, h2⟩ := drift_of_lift_test B r Tm Em hTEm (by positivity) hLm hθ
    exact ⟨_, hTm _ h1, h2⟩


/-! ### One-step inputs without the `b/r` loss (fable-02 §2) -/

/-- **Pure-gauge lifts cost only `L²`**: if `B ∘ E = 0` then `‖E z‖_λ = r ‖E z‖ ≤ r ℓ ‖z‖`.
Combined with `θ = κ_T η / r` (`theta_of_shift`) the drift is `κ_T ℓ η`: **`r` cancels**. -/
theorem lift_const_pure_gauge (B : E →ₗ[𝕜] F) (E0 : Z →ₗ[𝕜] E) {r ℓ : ℝ} (hr : 0 ≤ r)
    (hBE : ∀ z, B (E0 z) = 0) (hE : ∀ z, ‖E0 z‖ ≤ ℓ * ‖z‖) (z : Z) :
    lamNorm B r (E0 z) ≤ (r * ℓ) * ‖z‖ := by
  have hℓ : 0 ≤ ℓ * ‖z‖ := le_trans (norm_nonneg _) (hE z)
  unfold lamNorm
  rw [hBE, norm_zero, zero_pow two_ne_zero, zero_add, Real.sqrt_sq (mul_nonneg hr (norm_nonneg _))]
  rw [mul_assoc]
  exact mul_le_mul_of_nonneg_left (hE z) hr

/-- The drift of the pure-gauge (Landau) rows: `δ = ℓ κ_T η`, no `r`, no `b`. -/
theorem drift_pure_gauge (B : E →ₗ[𝕜] F) (T Tp : E →ₗ[𝕜] Z) (E0 : Z →ₗ[𝕜] E)
    {r ℓ κT η : ℝ} (hr : 0 < r) (hℓ : 0 ≤ ℓ) (hκ : 0 ≤ κT * η)
    (hTE : ∀ z, T (E0 z) = z) (hBE : ∀ z, B (E0 z) = 0) (hE : ∀ z, ‖E0 z‖ ≤ ℓ * ‖z‖)
    (hshift : ∀ y, ‖(T - Tp) y‖ ≤ κT * η * ‖y‖) {y : E} (hy : Tp y = 0) :
    T (y - E0 (T y)) = 0 ∧
      lamNorm B r (y - (y - E0 (T y))) ≤ (ℓ * (κT * η)) * lamNorm B r y := by
  have hθ := theta_of_shift B T Tp hr hκ hshift hy
  have h := drift_of_lift B r T E0 hTE (mul_nonneg hr.le hℓ) (lift_const_pure_gauge B E0 hr.le hBE hE) hθ
  refine ⟨h.1, h.2.trans (le_of_eq ?_)⟩
  field_simp

/-- **Energy-controlled constraint shift** (the first-moment argument of fable-02 §2):
`‖(T − T₊) y‖ ≤ κ′ η ‖B y‖` gives `θ = κ′ η` directly, with no `r`. -/
theorem theta_of_energy_shift (B : E →ₗ[𝕜] F) (T Tp : E →ₗ[𝕜] Z) {r κ' η : ℝ}
    (hκ : 0 ≤ κ' * η) (hshift : ∀ y, ‖(T - Tp) y‖ ≤ κ' * η * ‖B y‖) {y : E} (hy : Tp y = 0) :
    ‖T y‖ ≤ (κ' * η) * lamNorm B r y := by
  have e : T y = (T - Tp) y := by simp [hy]
  rw [e]
  exact (hshift y).trans (mul_le_mul_of_nonneg_left (norm_B0_le_lamNorm B r y) hκ)

/-- **Transverse lift**: `‖E z‖_λ² = ‖B E z‖² + r²‖E z‖² ≤ (M + r² ℓ²)‖z‖²`, where `M` bounds the
energy of the lift (the effective Hessian `M̂` of fable-02 §2) and `ℓ` its `L²` size. -/
theorem lift_const_energy (B : E →ₗ[𝕜] F) (E0 : Z →ₗ[𝕜] E) {r M ℓ : ℝ} (hr : 0 ≤ r)
    (hM : 0 ≤ M) (hℓ : 0 ≤ ℓ)
    (hBE : ∀ z, ‖B (E0 z)‖ ^ 2 ≤ M * ‖z‖ ^ 2) (hE : ∀ z, ‖E0 z‖ ≤ ℓ * ‖z‖) (z : Z) :
    lamNorm B r (E0 z) ≤ Real.sqrt (M + r ^ 2 * ℓ ^ 2) * ‖z‖ := by
  unfold lamNorm
  rw [← Real.sqrt_sq (norm_nonneg z), ← Real.sqrt_mul (by positivity)]
  apply Real.sqrt_le_sqrt
  have h1 := hBE z
  have h2 : (r * ‖E0 z‖) ^ 2 ≤ r ^ 2 * ℓ ^ 2 * ‖z‖ ^ 2 := by
    have := pow_le_pow_left₀ (norm_nonneg _) (hE z) 2
    calc (r * ‖E0 z‖) ^ 2 = r ^ 2 * ‖E0 z‖ ^ 2 := by ring
      _ ≤ r ^ 2 * (ℓ * ‖z‖) ^ 2 := mul_le_mul_of_nonneg_left this (by positivity)
      _ = r ^ 2 * ℓ ^ 2 * ‖z‖ ^ 2 := by ring
  nlinarith

end Assembly

end RealSpaceThmR

#print axioms RealSpaceThmR.weighted_solution
#print axioms RealSpaceThmR.thmR_weighted
#print axioms RealSpaceThmR.entry_decay
#print axioms RealSpaceThmR.exp_ratio
#print axioms RealSpaceThmR.drift_of_lift
#print axioms RealSpaceThmR.drift_of_lift_test
#print axioms RealSpaceThmR.thmR_lift
#print axioms RealSpaceThmR.eps_of_local
#print axioms RealSpaceThmR.form_coercive
#print axioms RealSpaceThmR.form_apriori
#print axioms RealSpaceThmR.thmR_form
#print axioms RealSpaceThmR.form_eps_of_band
#print axioms RealSpaceThmR.lift_const_of_upper
#print axioms RealSpaceThmR.theta_of_shift
#print axioms RealSpaceThmR.c_small
#print axioms RealSpaceThmR.thmR_form_small
#print axioms RealSpaceThmR.onestep_uniform
#print axioms RealSpaceThmR.lift_const_pure_gauge
#print axioms RealSpaceThmR.drift_pure_gauge
#print axioms RealSpaceThmR.theta_of_energy_shift
#print axioms RealSpaceThmR.lift_const_energy
