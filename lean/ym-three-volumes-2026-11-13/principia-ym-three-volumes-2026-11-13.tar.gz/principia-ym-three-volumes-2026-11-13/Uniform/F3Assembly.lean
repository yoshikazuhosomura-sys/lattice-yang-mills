import Mathlib

/-!
# Stage-uniform closure of the two-coordinate induction (F3, abstract form)

Class coordinate `r k` and polymer coordinate `w k` (norms at a fixed scale `h`) obey
  `r (k+1) ≤ τ k * r k + a k * w k + sr k`,  `w (k+1) ≤ b k * r k + σ k * w k + sw k`.
If all coefficients are bounded by stage-independent constants with `ab < (1-τ)(1-σ)`,
the invariant ball `(ρ, M)` holds at every stage (`ball_all_stages`).

Scale condition `λ R + C R² h / r_B ≤ 1` (no loss of the parameter `h`):
* solvable once and for all stages when `λ < 1` (`scale_choice`),
* impossible when `λ ≥ 1` (`scale_fails`),
* a per-stage inflation factor `κ > 1` blows the required initial scale up as `κ^k`
  (`scale_blowup`).
-/

namespace StageUniformBall

theorem ball_step {τ σ a b sr sw r w r' w' : ℝ} (hτ0 : 0 ≤ τ) (hσ0 : 0 ≤ σ)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hcross : a * b < (1 - τ) * (1 - σ))
    (hr : r ≤ ((1 - σ) * sr + a * sw) / ((1 - τ) * (1 - σ) - a * b))
    (hw : w ≤ ((1 - τ) * sw + b * sr) / ((1 - τ) * (1 - σ) - a * b))
    (hr' : r' ≤ τ * r + a * w + sr) (hw' : w' ≤ b * r + σ * w + sw) :
    r' ≤ ((1 - σ) * sr + a * sw) / ((1 - τ) * (1 - σ) - a * b) ∧
      w' ≤ ((1 - τ) * sw + b * sr) / ((1 - τ) * (1 - σ) - a * b) := by
  set D := (1 - τ) * (1 - σ) - a * b with hD
  have hDpos : 0 < D := by rw [hD]; linarith
  have hDne : D ≠ 0 := hDpos.ne'
  set Nρ := (1 - σ) * sr + a * sw with hNρ
  set NM := (1 - τ) * sw + b * sr with hNM
  have hfixρ : τ * (Nρ / D) + a * (NM / D) + sr = Nρ / D := by
    field_simp
    rw [hNρ, hNM, hD]; ring
  have hfixM : b * (Nρ / D) + σ * (NM / D) + sw = NM / D := by
    field_simp
    rw [hNρ, hNM, hD]; ring
  constructor
  · have h1 := mul_le_mul_of_nonneg_left hr hτ0
    have h2 := mul_le_mul_of_nonneg_left hw ha
    linarith
  · have h1 := mul_le_mul_of_nonneg_left hr hb
    have h2 := mul_le_mul_of_nonneg_left hw hσ0
    linarith

/-- **F3, abstract form.** Stage-dependent coefficients bounded by stage-independent constants;
the invariant ball of the constants holds at every stage. -/
theorem ball_all_stages (τ σ a b sr sw r w : ℕ → ℝ) {τb σb ab bb srb swb : ℝ}
    (hτb : 0 ≤ τb) (hσb : 0 ≤ σb) (hab : 0 ≤ ab) (hbb : 0 ≤ bb)
    (hcross : ab * bb < (1 - τb) * (1 - σb))
    (hτ : ∀ k, τ k ≤ τb) (hσ : ∀ k, σ k ≤ σb) (ha : ∀ k, a k ≤ ab) (hb : ∀ k, b k ≤ bb)
    (hsr : ∀ k, sr k ≤ srb) (hsw : ∀ k, sw k ≤ swb)
    (hr0 : ∀ k, 0 ≤ r k) (hw0 : ∀ k, 0 ≤ w k)
    (hstep_r : ∀ k, r (k + 1) ≤ τ k * r k + a k * w k + sr k)
    (hstep_w : ∀ k, w (k + 1) ≤ b k * r k + σ k * w k + sw k)
    (hinit_r : r 0 ≤ ((1 - σb) * srb + ab * swb) / ((1 - τb) * (1 - σb) - ab * bb))
    (hinit_w : w 0 ≤ ((1 - τb) * swb + bb * srb) / ((1 - τb) * (1 - σb) - ab * bb)) :
    ∀ k, r k ≤ ((1 - σb) * srb + ab * swb) / ((1 - τb) * (1 - σb) - ab * bb) ∧
      w k ≤ ((1 - τb) * swb + bb * srb) / ((1 - τb) * (1 - σb) - ab * bb) := by
  intro k
  induction k with
  | zero => exact ⟨hinit_r, hinit_w⟩
  | succ k ih =>
    have e1 : r (k + 1) ≤ τb * r k + ab * w k + srb := by
      have := hstep_r k
      have h1 := mul_le_mul_of_nonneg_right (hτ k) (hr0 k)
      have h2 := mul_le_mul_of_nonneg_right (ha k) (hw0 k)
      linarith [hsr k]
    have e2 : w (k + 1) ≤ bb * r k + σb * w k + swb := by
      have := hstep_w k
      have h1 := mul_le_mul_of_nonneg_right (hb k) (hr0 k)
      have h2 := mul_le_mul_of_nonneg_right (hσ k) (hw0 k)
      linarith [hsw k]
    exact ball_step hτb hσb hab hbb hcross ih.1 ih.2 e1 e2

/-! ## The scale condition -/

/-- With `λ < 1` one choice of `R ∈ (1, 1/λ)` and `h` serves every stage. -/
theorem scale_choice {lam C rB R : ℝ} (hlam0 : 0 ≤ lam) (hC : 0 ≤ C) (hrB : 0 < rB)
    (hR1 : 1 < R) (hRlam : lam * R < 1) :
    ∃ h > 0, lam * R + C * R ^ 2 * h / rB ≤ 1 := by
  have hR0 : 0 < R := by linarith
  refine ⟨(1 - lam * R) * rB / (C * R ^ 2 + 1), ?_, ?_⟩
  · apply div_pos (mul_pos (by linarith) hrB); positivity
  · have hden : 0 < C * R ^ 2 + 1 := by positivity
    have key : C * R ^ 2 * ((1 - lam * R) * rB / (C * R ^ 2 + 1)) / rB
        = (1 - lam * R) * (C * R ^ 2 / (C * R ^ 2 + 1)) := by
      field_simp
    rw [key]
    have hfrac : C * R ^ 2 / (C * R ^ 2 + 1) ≤ 1 := by
      rw [div_le_one hden]; linarith
    have hpos : 0 ≤ 1 - lam * R := by linarith
    nlinarith [mul_le_mul_of_nonneg_left hfrac hpos]

/-- With `λ ≥ 1` the scale condition fails for every `R > 1`, `h > 0`. -/
theorem scale_fails {lam C rB R h : ℝ} (hlam : 1 ≤ lam) (hC : 0 ≤ C) (hrB : 0 < rB)
    (hR1 : 1 < R) (hh : 0 < h) : 1 < lam * R + C * R ^ 2 * h / rB := by
  have h1 : 1 < lam * R := by nlinarith
  have h2 : 0 ≤ C * R ^ 2 * h / rB := by positivity
  linarith

/-- Parameter loss accumulates: if the input scale must be `κ` times the output scale at each
stage, `h 0 ≥ κ^k h k`. -/
theorem scale_blowup (h : ℕ → ℝ) {κ : ℝ} (hκ : 0 ≤ κ) (hstep : ∀ k, κ * h (k + 1) ≤ h k) :
    ∀ k, κ ^ k * h k ≤ h 0 := by
  intro k
  induction k with
  | zero => simp
  | succ k ih =>
    have := mul_le_mul_of_nonneg_left (hstep k) (pow_nonneg hκ k)
    calc κ ^ (k + 1) * h (k + 1) = κ ^ k * (κ * h (k + 1)) := by ring
      _ ≤ κ ^ k * h k := this
      _ ≤ h 0 := ih

end StageUniformBall

/-!
# The transfer margin `λ_N` reduced to a local gradient ratio and a Poincaré constant

`N_k(f; □)² = E_□(f) + ℓ² G_k(□)` (fine block, stage-`k` differences) against
`N_{k+m}(f; □')² = E_{□'}(f) + ℓ² G_{k+m}(□')` (coarse block).  Split `f = f̄ + f̃` on `□'`,
`f̄` constant on the residue classes of the coarse lattice.
* class equidistribution: a sum of a class function over `□` is `n` times the sum over the
  classes, over `□'` it is `n'` times (`sum_class_fiber`), so `E_□(f̄) = (n/n') E_{□'}(f̄)`;
* `(1+ε, 1+1/ε)` splitting of a square (`norm_add_sq_le_eps`, `sum_norm_add_sq_le_eps`);
* the abstract bound
  `N_□² ≤ max((1+ε) q, (1+1/ε) c_P + τ) · N_{□'}²` (`transfer_sq_le`),
  from `E_□(f̄) ≤ q E_{□'}(f̄)`, Poincaré `E(f̃) ≤ c_P ℓ² G'` and the local gradient ratio
  `G_□ ≤ τ G'`.
* numbers: `c_P = 1/(4 ℓ² sin²(π/(2ℓ))) ≤ 1/9` for `ℓ ≥ 4` (`poincare_const_le`),
  and the two instances `λ_N² ≤ 4/5` (`q ≤ 1/16`, `τ ≤ 2/3`) and `λ_N² ≤ 1/2`
  (`q ≤ 1/256`, `τ ≤ 3/8`).
-/

namespace TransferSplit

open Finset

theorem norm_add_sq_le_eps {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (x y : E) {ε : ℝ} (hε : 0 < ε) :
    ‖x + y‖ ^ 2 ≤ (1 + ε) * ‖x‖ ^ 2 + (1 + 1 / ε) * ‖y‖ ^ 2 := by
  have h1 : ‖x + y‖ ^ 2 ≤ (‖x‖ + ‖y‖) ^ 2 := by
    have := norm_add_le x y
    have h0 : 0 ≤ ‖x + y‖ := norm_nonneg _
    nlinarith
  have h2 : 2 * ‖x‖ * ‖y‖ ≤ ε * ‖x‖ ^ 2 + (1 / ε) * ‖y‖ ^ 2 := by
    have key : ε * ‖x‖ ^ 2 + (1 / ε) * ‖y‖ ^ 2 - 2 * ‖x‖ * ‖y‖
        = (ε * ‖x‖ - ‖y‖) ^ 2 / ε := by
      field_simp; ring
    have : 0 ≤ (ε * ‖x‖ - ‖y‖) ^ 2 / ε := by positivity
    linarith
  nlinarith

theorem sum_norm_add_sq_le_eps {ι E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    (S : Finset ι) (x y : ι → E) {ε : ℝ} (hε : 0 < ε) :
    ∑ i ∈ S, ‖x i + y i‖ ^ 2 ≤
      (1 + ε) * ∑ i ∈ S, ‖x i‖ ^ 2 + (1 + 1 / ε) * ∑ i ∈ S, ‖y i‖ ^ 2 := by
  rw [mul_sum, mul_sum, ← sum_add_distrib]
  exact sum_le_sum fun i _ => norm_add_sq_le_eps (x i) (y i) hε

/-- Class equidistribution: if every class `j ∈ T` meets `S` in exactly `n` points and `S`
maps into `T`, a class function sums to `n` times its sum over the classes. -/
theorem sum_class_fiber {ι κ : Type*} [DecidableEq κ] (S : Finset ι) (T : Finset κ)
    (c : ι → κ) (n : ℕ) (hmap : ∀ x ∈ S, c x ∈ T)
    (hfib : ∀ j ∈ T, (S.filter (fun x => c x = j)).card = n) (g : κ → ℝ) :
    ∑ x ∈ S, g (c x) = n * ∑ j ∈ T, g j := by
  rw [← sum_fiberwise_of_maps_to hmap, mul_sum]
  refine sum_congr rfl fun j hj => ?_
  rw [sum_congr rfl (fun x hx => by rw [(mem_filter.mp hx).2]), sum_const, hfib j hj,
    nsmul_eq_mul]

/-- Ratio of class sums on a fine block and on the coarse block containing it. -/
theorem class_ratio {ι κ : Type*} [DecidableEq κ] (S S' : Finset ι) (T : Finset κ)
    (c : ι → κ) (n n' : ℕ) (hn' : 0 < n') (hmap : ∀ x ∈ S, c x ∈ T)
    (hmap' : ∀ x ∈ S', c x ∈ T)
    (hfib : ∀ j ∈ T, (S.filter (fun x => c x = j)).card = n)
    (hfib' : ∀ j ∈ T, (S'.filter (fun x => c x = j)).card = n') (g : κ → ℝ) :
    ∑ x ∈ S, g (c x) = ((n : ℝ) / n') * ∑ x ∈ S', g (c x) := by
  rw [sum_class_fiber S T c n hmap hfib, sum_class_fiber S' T c n' hmap' hfib']
  have : (n' : ℝ) ≠ 0 := by exact_mod_cast hn'.ne'
  field_simp

/-- **The abstract transfer bound.** -/
theorem transfer_sq_le {Ebox Ebar' Etil' Ebarbox Etilbox Gbox G' ℓ q cP τ ε : ℝ}
    (hε : 0 < ε) (hℓ : 0 ≤ ℓ) (hcP : 0 ≤ cP) (hτ0 : 0 ≤ τ) (hG' : 0 ≤ G') (hEbar' : 0 ≤ Ebar') (hEtil' : 0 ≤ Etil')
    (hsplit : Ebox ≤ (1 + ε) * Ebarbox + (1 + 1 / ε) * Etilbox)
    (hbar : Ebarbox ≤ q * Ebar') (htil_sub : Etilbox ≤ Etil')
    (hpoinc : Etil' ≤ cP * ℓ ^ 2 * G') (hgrad : Gbox ≤ τ * G') :
    Ebox + ℓ ^ 2 * Gbox ≤
      max ((1 + ε) * q) ((1 + 1 / ε) * cP + τ) * ((Ebar' + Etil') + ℓ ^ 2 * G') := by
  set Λ := max ((1 + ε) * q) ((1 + 1 / ε) * cP + τ)
  have hΛ1 : (1 + ε) * q ≤ Λ := le_max_left _ _
  have hΛ2 : (1 + 1 / ε) * cP + τ ≤ Λ := le_max_right _ _
  have he1 : 0 ≤ 1 + ε := by linarith
  have he2 : 0 ≤ 1 + 1 / ε := by positivity
  have hl2 : 0 ≤ ℓ ^ 2 := sq_nonneg ℓ
  have hl2G : 0 ≤ ℓ ^ 2 * G' := mul_nonneg hl2 hG'
  have s1 : (1 + ε) * Ebarbox ≤ (1 + ε) * q * Ebar' := by
    have := mul_le_mul_of_nonneg_left hbar he1; linarith
  have s2 : (1 + 1 / ε) * Etilbox ≤ (1 + 1 / ε) * cP * (ℓ ^ 2 * G') := by
    have := mul_le_mul_of_nonneg_left (htil_sub.trans hpoinc) he2; nlinarith
  have s3 : ℓ ^ 2 * Gbox ≤ τ * (ℓ ^ 2 * G') := by
    have := mul_le_mul_of_nonneg_left hgrad hl2; nlinarith
  have s4 : (1 + ε) * q * Ebar' ≤ Λ * Ebar' := mul_le_mul_of_nonneg_right hΛ1 hEbar'
  have s5 : ((1 + 1 / ε) * cP + τ) * (ℓ ^ 2 * G') ≤ Λ * (ℓ ^ 2 * G') :=
    mul_le_mul_of_nonneg_right hΛ2 hl2G
  have hΛ0 : 0 ≤ Λ := le_trans (by positivity) hΛ2
  have s6 : 0 ≤ Λ * Etil' := mul_nonneg hΛ0 hEtil'
  nlinarith

/-- **With an energy leak and tails.**  The local gradient ratio is allowed an energy term
`τ₂ E_{□'}` and a tail `δ · Dmax` from other coarse blocks (`Dmax` = the max of the coarse
`N²`).  Then `N_□² ≤ (max(...) + τ₂ + δ) · Dmax`. -/
theorem transfer_sq_le_leak {Ebox Ebar' Etil' Ebarbox Etilbox Gbox G' ℓ q cP τ τ₂ δ ε Dmax : ℝ}
    (hε : 0 < ε) (hℓ : 0 ≤ ℓ) (hcP : 0 ≤ cP) (hτ0 : 0 ≤ τ) (hτ₂ : 0 ≤ τ₂) (hδ : 0 ≤ δ)
    (hG' : 0 ≤ G') (hEbar' : 0 ≤ Ebar') (hEtil' : 0 ≤ Etil')
    (hsplit : Ebox ≤ (1 + ε) * Ebarbox + (1 + 1 / ε) * Etilbox)
    (hbar : Ebarbox ≤ q * Ebar') (htil_sub : Etilbox ≤ Etil')
    (hpoinc : Etil' ≤ cP * ℓ ^ 2 * G')
    (hgrad : ℓ ^ 2 * Gbox ≤ τ * (ℓ ^ 2 * G') + τ₂ * (Ebar' + Etil') + δ * Dmax)
    (hmax : (Ebar' + Etil') + ℓ ^ 2 * G' ≤ Dmax) :
    Ebox + ℓ ^ 2 * Gbox ≤ (max ((1 + ε) * q) ((1 + 1 / ε) * cP + τ) + τ₂ + δ) * Dmax := by
  set Λ := max ((1 + ε) * q) ((1 + 1 / ε) * cP + τ)
  have hΛ1 : (1 + ε) * q ≤ Λ := le_max_left _ _
  have hΛ2 : (1 + 1 / ε) * cP + τ ≤ Λ := le_max_right _ _
  have hΛ0 : 0 ≤ Λ := le_trans (by positivity) hΛ2
  have he1 : 0 ≤ 1 + ε := by linarith
  have he2 : 0 ≤ 1 + 1 / ε := by positivity
  have hl2G : 0 ≤ ℓ ^ 2 * G' := mul_nonneg (sq_nonneg ℓ) hG'
  have s1 : (1 + ε) * Ebarbox ≤ (1 + ε) * q * Ebar' := by
    have := mul_le_mul_of_nonneg_left hbar he1; linarith
  have s2 : (1 + 1 / ε) * Etilbox ≤ (1 + 1 / ε) * cP * (ℓ ^ 2 * G') := by
    have := mul_le_mul_of_nonneg_left (htil_sub.trans hpoinc) he2; nlinarith
  have s4 : (1 + ε) * q * Ebar' ≤ Λ * Ebar' := mul_le_mul_of_nonneg_right hΛ1 hEbar'
  have s5 : ((1 + 1 / ε) * cP + τ) * (ℓ ^ 2 * G') ≤ Λ * (ℓ ^ 2 * G') :=
    mul_le_mul_of_nonneg_right hΛ2 hl2G
  have s6 : 0 ≤ Λ * Etil' := mul_nonneg hΛ0 hEtil'
  have hD : Λ * ((Ebar' + Etil') + ℓ ^ 2 * G') ≤ Λ * Dmax := mul_le_mul_of_nonneg_left hmax hΛ0
  have hD2 : τ₂ * (Ebar' + Etil') ≤ τ₂ * Dmax := by
    apply mul_le_mul_of_nonneg_left _ hτ₂; linarith
  nlinarith

/-! ## A stage count `m` for which the transfer margin is `< 1` on paper -/

open Filter Topology

/-- The τ-type bound of : `(π²/4) 4^{-m} + R λ̄^m`. -/
noncomputable def tauM (R lam : ℝ) (m : ℕ) : ℝ := (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ m + R * lam ^ m

theorem tauM_tendsto {R lam : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) :
    Tendsto (tauM R lam) atTop (𝓝 0) := by
  have h1 : Tendsto (fun m : ℕ => (1 / 4 : ℝ) ^ m) atTop (𝓝 0) :=
    tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
  have h2 : Tendsto (fun m : ℕ => lam ^ m) atTop (𝓝 0) :=
    tendsto_pow_atTop_nhds_zero_of_lt_one hlam0 hlam1
  have := (h1.const_mul (Real.pi ^ 2 / 4)).add (h2.const_mul R)
  rw [mul_zero, mul_zero, add_zero] at this
  exact this

/-- **(H-λ) from (H-τ) for some `m`** (the arithmetic): with `ε = η = 1`, `c_P ≤ 1/9`,
cut-off constant `c_χ ≤ 16`, tail `δ ≤ 1/4`, the transfer bound
`max(2·16^{-m}, 2c_P + 2τ_m) + 2c_χ τ_m + δ` is `< 1` for all large `m`, uniformly in the
stage (only `τ_m = tauM R λ̄ m` enters). -/
theorem exists_m_transfer {R lam cP cχ δ : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hcP : cP ≤ 1 / 9) (hcχ0 : 0 ≤ cχ) (hcχ : cχ ≤ 16) (hδ : δ ≤ 1 / 4) :
    ∃ m0 : ℕ, ∀ m ≥ m0,
      max (2 * (1 / 16 : ℝ) ^ m) (2 * cP + 2 * tauM R lam m) + 2 * cχ * tauM R lam m + δ < 1 := by
  have hT := tauM_tendsto (R := R) hlam0 hlam1
  have hev1 : ∀ᶠ m in atTop, tauM R lam m < 1 / 200 :=
    hT.eventually (gt_mem_nhds (by norm_num))
  have hev2 : ∀ᶠ m in atTop, (1 / 16 : ℝ) ^ m < 1 / 4 :=
    (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num : (0:ℝ) ≤ 1/16) (by norm_num)).eventually
      (gt_mem_nhds (by norm_num))
  obtain ⟨m0, hm0⟩ := eventually_atTop.mp (hev1.and hev2)
  refine ⟨m0, fun m hm => ?_⟩
  obtain ⟨ht, hq⟩ := hm0 m hm
  have ht0 : 0 ≤ tauM R lam m ∨ tauM R lam m < 0 := le_or_gt 0 _
  have hmax : max (2 * (1 / 16 : ℝ) ^ m) (2 * cP + 2 * tauM R lam m) ≤ 1 / 2 := by
    apply max_le <;> linarith
  have hc : 2 * cχ * tauM R lam m ≤ 2 * 16 * (1 / 200) := by
    rcases ht0 with h0 | h0
    · have : cχ * tauM R lam m ≤ 16 * (1 / 200) :=
        mul_le_mul hcχ ht.le h0 (by norm_num)
      linarith
    · have : cχ * tauM R lam m ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hcχ0 h0.le
      linarith
  linarith

/-- With the paper constants of (`R ≤ 2.3·10⁵`, `λ̄ ≤ 0.838`), `m = 110` already gives
`τ_m < 1/200`. -/
theorem tauM_paper_110 : tauM 230000 (838 / 1000) 110 < 1 / 200 := by
  unfold tauM
  have hpi : Real.pi ^ 2 < 10 := by
    have := Real.pi_lt_d2
    have h0 := Real.pi_pos
    nlinarith
  have h1 : (Real.pi ^ 2 / 4) * (1 / 4 : ℝ) ^ 110 ≤ (10 / 4) * (1 / 4 : ℝ) ^ 110 := by
    apply mul_le_mul_of_nonneg_right _ (by positivity); linarith
  have h2 : (10 / 4) * (1 / 4 : ℝ) ^ 110 + 230000 * (838 / 1000 : ℝ) ^ 110 < 1 / 200 := by
    norm_num
  linarith

/-- Same, for an arbitrary (stage-independent) cut-off constant `c_χ ≥ 0`. -/
theorem exists_m_transfer_any {R lam cP cχ δ : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hcP : cP ≤ 1 / 9) (hcχ0 : 0 ≤ cχ) (hδ : δ ≤ 1 / 4) :
    ∃ m0 : ℕ, ∀ m ≥ m0,
      max (2 * (1 / 16 : ℝ) ^ m) (2 * cP + 2 * tauM R lam m) + 2 * cχ * tauM R lam m + δ < 1 := by
  have hT := tauM_tendsto (R := R) hlam0 hlam1
  have hpos : 0 < 1 / (200 * (1 + cχ)) := by positivity
  have hev1 : ∀ᶠ m in atTop, tauM R lam m < 1 / (200 * (1 + cχ)) :=
    hT.eventually (gt_mem_nhds hpos)
  have hev2 : ∀ᶠ m in atTop, (1 / 16 : ℝ) ^ m < 1 / 4 :=
    (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num : (0:ℝ) ≤ 1/16) (by norm_num)).eventually
      (gt_mem_nhds (by norm_num))
  obtain ⟨m0, hm0⟩ := eventually_atTop.mp (hev1.and hev2)
  refine ⟨m0, fun m hm => ?_⟩
  obtain ⟨ht, hq⟩ := hm0 m hm
  have h1c : 0 < 1 + cχ := by linarith
  have ht' : tauM R lam m < 1 / 200 := by
    refine ht.trans_le ?_
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith
  have hmax : max (2 * (1 / 16 : ℝ) ^ m) (2 * cP + 2 * tauM R lam m) ≤ 1 / 2 := by
    apply max_le <;> linarith
  have hc : 2 * cχ * tauM R lam m ≤ 1 / 100 := by
    rcases le_or_gt 0 (tauM R lam m) with h0 | h0
    · have hm1 : (1 + cχ) * tauM R lam m < 1 / 200 := by
        have := mul_lt_mul_of_pos_left ht h1c
        rwa [mul_div_assoc', mul_one, mul_comm 200 (1 + cχ), ← div_div,
          div_self h1c.ne'] at this
      nlinarith
    · have : cχ * tauM R lam m ≤ 0 := mul_nonpos_of_nonneg_of_nonpos hcχ0 h0.le
      linarith
  linarith

/-- The transfer bound as a function of `m` (with `ε = η = 1`). -/
noncomputable def LamM (R lam cP cχ δ : ℝ) (m : ℕ) : ℝ :=
  max (2 * (1 / 16 : ℝ) ^ m) (2 * cP + 2 * tauM R lam m) + 2 * cχ * tauM R lam m + δ

/-- **(H-λ) ⇒ the scale condition at every stage with one choice.**
If at every stage `k` the transfer margin satisfies `λ_N(k,m)² ≤ LamM … m` (the output of
`transfer_sq_le_leak` with the τ-type bound `τ_k^{(m)} ≤ tauM R λ̄ m`), then for all large `m`
there are `R > 1` and `h > 0` with `λ_N(k,m) R + C R² h / r_B ≤ 1` for every `k`. -/
theorem uniform_scale_from_tau {R lam cP cχ δ C rB : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hcP : cP ≤ 1 / 9) (hcχ0 : 0 ≤ cχ) (hδ : δ ≤ 1 / 4) (hC : 0 ≤ C) (hrB : 0 < rB) :
    ∃ m0 : ℕ, ∀ m ≥ m0, ∀ lamN : ℕ → ℝ, (∀ k, 0 ≤ lamN k) →
      (∀ k, lamN k ^ 2 ≤ LamM R lam cP cχ δ m) →
      ∃ Rad > 1, ∃ h > 0, ∀ k, lamN k * Rad + C * Rad ^ 2 * h / rB ≤ 1 := by
  obtain ⟨m0, hm0⟩ := exists_m_transfer_any (R := R) hlam0 hlam1 hcP hcχ0 hδ
  refine ⟨m0, fun m hm lamN hN0 hN => ?_⟩
  set Λ := LamM R lam cP cχ δ m with hΛdef
  have hΛ1 : Λ < 1 := hm0 m hm
  -- λ̄ := (1 + Λ)/2 bounds every λ_N: λ_N² ≤ Λ < λ̄² ... use λ_N ≤ λ̄ with λ̄ < 1
  set lb := (1 + max Λ 0) / 2 with hlb
  have hmax1 : max Λ 0 < 1 := max_lt hΛ1 (by norm_num)
  have hlb1 : lb < 1 := by rw [hlb]; linarith
  have hlb0 : 0 < lb := by rw [hlb]; have := le_max_right Λ 0; linarith
  have hNle : ∀ k, lamN k ≤ lb := by
    intro k
    have h1 : lamN k ^ 2 ≤ max Λ 0 := (hN k).trans (le_max_left _ _)
    have h2 : max Λ 0 ≤ lb := by rw [hlb]; linarith
    have h3 : lamN k ^ 2 ≤ lb := h1.trans h2
    have h4 : lb ≤ 1 := hlb1.le
    nlinarith [hN0 k]
  -- radius `Rad = (1 + 1/lb)/2 ∈ (1, 1/lb)`
  set Rad := (1 + 1 / lb) / 2 with hRad
  have hinv : 1 < 1 / lb := by rw [lt_div_iff₀ hlb0]; linarith
  have hRad1 : 1 < Rad := by rw [hRad]; linarith
  have hRadlb : lb * Rad < 1 := by
    rw [hRad]
    have : lb * (1 / lb) = 1 := by field_simp
    nlinarith
  have hRad0 : 0 < Rad := by linarith
  refine ⟨Rad, hRad1, (1 - lb * Rad) * rB / (C * Rad ^ 2 + 1), ?_, fun k => ?_⟩
  · apply div_pos (mul_pos (by linarith) hrB); positivity
  · have hden : 0 < C * Rad ^ 2 + 1 := by positivity
    have key : C * Rad ^ 2 * ((1 - lb * Rad) * rB / (C * Rad ^ 2 + 1)) / rB
        = (1 - lb * Rad) * (C * Rad ^ 2 / (C * Rad ^ 2 + 1)) := by
      field_simp
    rw [key]
    have hfrac : C * Rad ^ 2 / (C * Rad ^ 2 + 1) ≤ 1 := by
      rw [div_le_one hden]; linarith
    have hpos : 0 ≤ 1 - lb * Rad := by linarith
    have hk : lamN k * Rad ≤ lb * Rad := mul_le_mul_of_nonneg_right (hNle k) hRad0.le
    nlinarith [mul_le_mul_of_nonneg_left hfrac hpos]

end TransferSplit

/-! # Assembly: the conditional stage-uniform statement of F3 -/

namespace F3Conditional

open StageUniformBall TransferSplit Filter Topology

/-- **F3, conditional form.**  Inputs (all uniform in the stage `k`):
* (H-τ) `τ_k^{(m)} ≤ tauM R λ̄ m` (paper);
* (H-σ) `σ_k^{(m)} ≤ C_w 4^{-m}` (paper, conditional);
* (H-λ)  `λ_N(k,m)² ≤ LamM … m` (the output of the localization inequality (L));
* cross terms `ā b̄ < 1/4` (they carry `g²`, so this is a smallness choice of `u⋆`).
Then there is `m₀` such that for every `m ≥ m₀` one choice of `R > 1`, `h > 0` makes the scale
condition hold at every stage, and the two-coordinate ball holds at every stage. -/
theorem f3_conditional {R lam cP cχ δ C rB Cw : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hcP : cP ≤ 1 / 9) (hcχ0 : 0 ≤ cχ) (hδ : δ ≤ 1 / 4) (hC : 0 ≤ C) (hrB : 0 < rB)
    (hCw : 0 ≤ Cw) :
    ∃ m0 : ℕ, ∀ m ≥ m0,
      (∀ lamN : ℕ → ℝ, (∀ k, 0 ≤ lamN k) → (∀ k, lamN k ^ 2 ≤ LamM R lam cP cχ δ m) →
        ∃ Rad > 1, ∃ h > 0, ∀ k, lamN k * Rad + C * Rad ^ 2 * h / rB ≤ 1) ∧
      (∀ (τ σ a b sr sw r w : ℕ → ℝ) (ab bb srb swb : ℝ),
        0 ≤ ab → 0 ≤ bb → ab * bb < 1 / 4 →
        (∀ k, τ k ≤ tauM R lam m) → (∀ k, σ k ≤ Cw * (1 / 4 : ℝ) ^ m) →
        (∀ k, a k ≤ ab) → (∀ k, b k ≤ bb) → (∀ k, sr k ≤ srb) → (∀ k, sw k ≤ swb) →
        (∀ k, 0 ≤ r k) → (∀ k, 0 ≤ w k) →
        (∀ k, r (k + 1) ≤ τ k * r k + a k * w k + sr k) →
        (∀ k, w (k + 1) ≤ b k * r k + σ k * w k + sw k) →
        r 0 ≤ ((1 - 1 / 2) * srb + ab * swb) / ((1 - 1 / 2) * (1 - 1 / 2) - ab * bb) →
        w 0 ≤ ((1 - 1 / 2) * swb + bb * srb) / ((1 - 1 / 2) * (1 - 1 / 2) - ab * bb) →
        ∀ k, r k ≤ ((1 - 1 / 2) * srb + ab * swb) / ((1 - 1 / 2) * (1 - 1 / 2) - ab * bb) ∧
          w k ≤ ((1 - 1 / 2) * swb + bb * srb) / ((1 - 1 / 2) * (1 - 1 / 2) - ab * bb)) := by
  obtain ⟨m1, hm1⟩ := uniform_scale_from_tau (R := R) (cχ := cχ) hlam0 hlam1 hcP hcχ0 hδ hC hrB
  have hT := tauM_tendsto (R := R) hlam0 hlam1
  have hev1 : ∀ᶠ m in atTop, tauM R lam m < 1 / 2 := hT.eventually (gt_mem_nhds (by norm_num))
  have hS : Tendsto (fun m : ℕ => Cw * (1 / 4 : ℝ) ^ m) atTop (𝓝 0) := by
    have := (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num : (0:ℝ) ≤ 1/4)
      (by norm_num)).const_mul Cw
    rwa [mul_zero] at this
  have hev2 : ∀ᶠ m in atTop, Cw * (1 / 4 : ℝ) ^ m < 1 / 2 := hS.eventually (gt_mem_nhds (by norm_num))
  obtain ⟨m2, hm2⟩ := eventually_atTop.mp (hev1.and hev2)
  refine ⟨max m1 m2, fun m hm => ⟨hm1 m (le_of_max_le_left hm), ?_⟩⟩
  intro τ σ a b sr sw r w ab bb srb swb hab hbb hcross hτ hσ ha hb hsr hsw hr0 hw0 hsr' hsw' h0r h0w
  obtain ⟨ht, hs⟩ := hm2 m (le_of_max_le_right hm)
  exact ball_all_stages τ σ a b sr sw r w (τb := 1 / 2) (σb := 1 / 2) (by norm_num) (by norm_num)
    hab hbb (by norm_num; linarith) (fun k => (hτ k).trans ht.le) (fun k => (hσ k).trans hs.le)
    ha hb hsr hsw hr0 hw0 hsr' hsw' h0r h0w

end F3Conditional
