import Infvol.MidTV2

/-!
# Positivity of the transfer operator on all cylinder functions (not only gauge invariant ones)


* `FullT.avgG` : the Haar average over all gauge transformations of the torus (finite product).
* `FullT.pair_split` : for `H` depending only on the open positive side `posM` of the middle plane,
  `∫ H(Θ′(g·ω)) H(h·ω) = ∫ H(Θ′ω) H(ω)` for all unit `g, h` (glue `h` on the positive sites and `g`
  on the others; `Θ′` maps the positive sites outside).
* `FullT.full_rp_torus` : `0 ≤ ∫ H(Θ′ω) H(ω) dP_N` for every bounded measurable `H` of the `posM`
  links (`β ≥ 0`): average over two independent gauge transformations, Fubini, and apply
  `MidRP.wilson_rp_mid` to the gauge-invariant average.
* `FullT.wilson_Tpos_full` : at every weak limit point (`β ≥ 0`, Dobrushin window), the
  reconstruction on all of `W` has `⟪v, T v⟫ ≥ 0` for every `v`.
-/

namespace FullT

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge MidRP MidT InfVol
open scoped BoundedContinuousFunction InnerProductSpace

local notation "ℍr" => Quaternion ℝ

section Torus

variable (N : ℕ) [NeZero N]

/-- the Haar measure on gauge transformations of the torus -/
noncomputable def gam : Measure (Site N → QBall) := Measure.pi fun _ => haarBall

instance : IsProbabilityMeasure (gam N) := by unfold gam; infer_instance

theorem continuous_act :
    Continuous (fun p : (Site N → QBall) × (Lk N → QBall) => act (src N) (tgt N) p.1 p.2) := by
  refine continuous_pi fun ℓ => ?_
  show Continuous fun p : (Site N → QBall) × (Lk N → QBall) =>
    mulB (p.1 (src N ℓ)) (p.1 (tgt N ℓ)) (p.2 ℓ)
  exact continuous_mulB' ((continuous_apply _).comp continuous_fst)
    ((continuous_apply _).comp continuous_fst) ((continuous_apply ℓ).comp continuous_snd)

/-- product in the ball -/
noncomputable def mulQ (a b : QBall) : QBall := mulB a oneB b

theorem act_act (g k : Site N → QBall) (ω : Lk N → QBall) :
    act (src N) (tgt N) g (act (src N) (tgt N) k ω)
      = act (src N) (tgt N) (fun x => mulQ (g x) (k x)) ω := by
  funext ℓ
  apply Subtype.ext
  show ((g (src N ℓ) : QBall) : ℍr) * (((k (src N ℓ) : QBall) : ℍr) * ((ω ℓ : QBall) : ℍr)
        * star ((k (tgt N ℓ) : QBall) : ℍr)) * star ((g (tgt N ℓ) : QBall) : ℍr)
      = (((g (src N ℓ) : QBall) : ℍr) * ((k (src N ℓ) : QBall) : ℍr) * star (1 : ℍr))
        * ((ω ℓ : QBall) : ℍr)
        * star (((g (tgt N ℓ) : QBall) : ℍr) * ((k (tgt N ℓ) : QBall) : ℍr) * star (1 : ℍr))
  simp only [star_one, mul_one, star_mul, mul_assoc]

theorem mulQ_right_preserving (k : Site N → QBall) (hk : ∀ x, ‖((k x : QBall) : ℍr)‖ = 1) :
    MeasurePreserving (fun g : Site N → QBall => fun x => mulQ (g x) (k x)) (gam N) (gam N) := by
  unfold gam
  have h := measurePreserving_pi (fun _ : Site N => haarBall) (fun _ => haarBall)
    (f := fun x => mulB oneB (starB (k x)))
    (fun x => mulB_preserving oneB (starB (k x)) oneB_norm
      (by show ‖star ((k x : QBall) : ℍr)‖ = 1; rw [norm_star]; exact hk x))
  convert h using 1
  funext g x
  apply Subtype.ext
  show ((g x : QBall) : ℍr) * ((k x : QBall) : ℍr) * star (1 : ℍr)
    = (1 : ℍr) * ((g x : QBall) : ℍr) * star (star ((k x : QBall) : ℍr))
  simp

theorem perm_preserving (σ : Site N → Site N) (hσ : Function.Involutive σ) :
    MeasurePreserving (fun g : Site N → QBall => fun x => g (σ x)) (gam N) (gam N) := by
  unfold gam
  have hre := measurePreserving_piCongrLeft (fun _ : Site N => haarBall) (hσ.toPerm σ)
  convert hre using 1
  funext g x
  rw [LinkReflection.piCongrLeft_const]
  rfl

theorem thSM_invol : Function.Involutive (thSM N) := fun x => by
  simp only [thSM, thS_add, thS_thS, thS_ev0]
  abel

/-- the Haar average over gauge transformations -/
noncomputable def avgG (H : (Lk N → QBall) → ℝ) (ω : Lk N → QBall) : ℝ :=
  ∫ g, H (act (src N) (tgt N) g ω) ∂(gam N)

theorem measurable_g (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (ω : Lk N → QBall) :
    Measurable (fun g : Site N → QBall => H (act (src N) (tgt N) g ω)) :=
  hH.comp ((continuous_act N).comp (Continuous.prodMk continuous_id continuous_const)).measurable

theorem measurable_avgG (H : (Lk N → QBall) → ℝ) (hH : Measurable H) :
    Measurable (avgG N H) := by
  have hf : StronglyMeasurable
      (fun p : (Lk N → QBall) × (Site N → QBall) => H (act (src N) (tgt N) p.2 p.1)) :=
    (hH.comp ((continuous_act N).comp continuous_swap).measurable).stronglyMeasurable
  exact (hf.integral_prod_right' (ν := gam N)).measurable

theorem abs_avgG_le (H : (Lk N → QBall) → ℝ) (C : ℝ) (hb : ∀ ω, |H ω| ≤ C) (ω : Lk N → QBall) :
    |avgG N H ω| ≤ C := by
  have h := norm_integral_le_of_norm_le_const (μ := gam N)
    (f := fun g => H (act (src N) (tgt N) g ω))
    (Eventually.of_forall fun g => (by rw [Real.norm_eq_abs]; exact hb _ :
      ‖H (act (src N) (tgt N) g ω)‖ ≤ C))
  show |∫ g, H (act (src N) (tgt N) g ω) ∂(gam N)| ≤ C
  simpa using h

theorem avgG_act (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (k : Site N → QBall)
    (hk : ∀ x, ‖((k x : QBall) : ℍr)‖ = 1) (ω : Lk N → QBall) :
    avgG N H (act (src N) (tgt N) k ω) = avgG N H ω := by
  unfold avgG
  simp_rw [act_act]
  have hmp := mulQ_right_preserving N k hk
  have h := integral_map (μ := gam N) hmp.measurable.aemeasurable (measurable_g N H hH ω).aestronglyMeasurable
  rw [hmp.map_eq] at h
  exact h.symm

theorem avgG_refl (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (ω : Lk N → QBall) :
    avgG N H (linkRefl (thM N) (sigT N) ω)
      = avgG N (fun ω => H (linkRefl (thM N) (sigT N) ω)) ω := by
  unfold avgG
  have e : ∀ g : Site N → QBall, H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω))
      = H (act (src N) (tgt N) (fun x => g (thSM N x)) (linkRefl (thM N) (sigT N) ω)) :=
    fun g => by rw [linkRefl_act]
  simp_rw [e]
  have hmp := perm_preserving N (thSM N) (thSM_invol N)
  have h := integral_map (μ := gam N) hmp.measurable.aemeasurable
    (measurable_g N H hH (linkRefl (thM N) (sigT N) ω)).aestronglyMeasurable
  rw [hmp.map_eq] at h
  exact h

/-- the sites of the open positive side -/
def Ppos (M : ℕ) (x : Site N) : Prop := 1 ≤ (x 0).val ∧ (x 0).val ≤ M

instance (M : ℕ) : DecidablePred (Ppos N M) := fun x => by unfold Ppos; infer_instance

theorem posM_ends (M : ℕ) (hN : N = 2 * M) (ℓ : Lk N) (h : posM N M ℓ) :
    Ppos N M (src N ℓ) ∧ Ppos N M (tgt N ℓ) := by
  unfold posM tm at h
  unfold Ppos
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at h
    have hv : ((ℓ.1 + ev N ℓ.2) 0).val = (ℓ.1 0).val + 1 := by
      rw [h2, Pi.add_apply, ev_zero_zero N]
      exact val_add_one N _ (by omega)
    refine ⟨⟨h.1, by show (ℓ.1 0).val ≤ M; omega⟩, ?_⟩
    show 1 ≤ ((ℓ.1 + ev N ℓ.2) 0).val ∧ ((ℓ.1 + ev N ℓ.2) 0).val ≤ M
    rw [hv]
    omega
  · rw [if_neg h2] at h
    have hv : (ℓ.1 + ev N ℓ.2) 0 = ℓ.1 0 := by rw [Pi.add_apply, ev_zero N h2, add_zero]
    refine ⟨h, ?_⟩
    show 1 ≤ ((ℓ.1 + ev N ℓ.2) 0).val ∧ ((ℓ.1 + ev N ℓ.2) 0).val ≤ M
    rw [hv]
    exact h

theorem thSM_out (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (x : Site N) (hx : Ppos N M x) :
    ¬ Ppos N M (thSM N x) := by
  unfold Ppos at *
  have e1 : (thS N x) 0 = -x 0 := if_pos rfl
  have e : (thSM N x) 0 = 1 - x 0 := by
    show (thS N x + ev N 0) 0 = _
    rw [Pi.add_apply, e1, ev_zero_zero N]
    ring
  rw [e, val_one_sub N M hN hM]
  split_ifs <;> omega

theorem act_agree (M : ℕ) (hN : N = 2 * M) (g h : Site N → QBall)
    (hgh : ∀ x, Ppos N M x → g x = h x) (ω : Lk N → QBall) (ℓ : Lk N) (hℓ : posM N M ℓ) :
    act (src N) (tgt N) g ω ℓ = act (src N) (tgt N) h ω ℓ := by
  obtain ⟨a, b⟩ := posM_ends N M hN ℓ hℓ
  show mulB (g (src N ℓ)) (g (tgt N ℓ)) (ω ℓ) = mulB (h (src N ℓ)) (h (tgt N ℓ)) (ω ℓ)
  rw [hgh _ a, hgh _ b]

/-- **Two independent gauge transformations on the two sides.** -/
theorem pair_split (M : ℕ) (hN : N = 2 * M) (hM : 1 ≤ M) (β : ℝ)
    (H : (Lk N → QBall) → ℝ) (hH : Measurable H)
    (hdep : ∀ ω ω', (∀ ℓ, posM N M ℓ → ω ℓ = ω' ℓ) → H ω = H ω')
    (g h : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (hh : ∀ x, ‖((h x : QBall) : ℍr)‖ = 1) :
    ∫ ω, H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω)) * H (act (src N) (tgt N) h ω)
        ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω, H (linkRefl (thM N) (sigT N) ω) * H ω ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  let k : Site N → QBall := fun x => if Ppos N M x then h x else g x
  have hk : ∀ x, ‖((k x : QBall) : ℍr)‖ = 1 := fun x => by
    show ‖(((if Ppos N M x then h x else g x) : QBall) : ℍr)‖ = 1
    split_ifs
    · exact hh x
    · exact hg x
  have e2 : ∀ ω, H (act (src N) (tgt N) h ω) = H (act (src N) (tgt N) k ω) := fun ω =>
    hdep _ _ (fun ℓ hℓ => act_agree N M hN h k (fun x hx => by
      show h x = (if Ppos N M x then h x else g x); rw [if_pos hx]) ω ℓ hℓ)
  have e1 : ∀ ω, H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω))
      = H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) k ω)) := by
    intro ω
    rw [linkRefl_act, linkRefl_act]
    exact hdep _ _ (fun ℓ hℓ => act_agree N M hN _ _ (fun x hx => by
      show g (thSM N x) = (if Ppos N M (thSM N x) then h (thSM N x) else g (thSM N x))
      rw [if_neg (thSM_out N M hN hM x hx)]) _ ℓ hℓ)
  have hK : Measurable (fun ω => H (linkRefl (thM N) (sigT N) ω) * H ω) :=
    (hH.comp (measurable_linkRefl_T N)).mul hH
  have hinv := CenterFlip.integral_act_prob N β k hk _ hK
  rw [← hinv]
  refine integral_congr_ae (Eventually.of_forall fun ω => ?_)
  show H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω)) * H (act (src N) (tgt N) h ω)
    = H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) k ω)) * H (act (src N) (tgt N) k ω)
  rw [e1, e2]

/-- **Reflection positivity across the middle plane for every function of the positive side.** -/
theorem full_rp_torus (M : ℕ) (hN : N = 2 * M) (hM : 2 ≤ M) (β : ℝ) (hβ : 0 ≤ β)
    (H : (Lk N → QBall) → ℝ) (hH : Measurable H) (C : ℝ) (hb : ∀ ω, |H ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, posM N M ℓ → ω ℓ = ω' ℓ) → H ω = H ω') :
    0 ≤ ∫ ω, H (linkRefl (thM N) (sigT N) ω) * H ω ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  have hC : 0 ≤ C := (abs_nonneg _).trans (hb (fun _ => Classical.arbitrary QBall))
  have hH1 : Measurable (fun ω => H (linkRefl (thM N) (sigT N) ω)) :=
    hH.comp (measurable_linkRefl_T N)
  -- step 1: insert the two averages
  have hf : Integrable (Function.uncurry fun (ω : Lk N → QBall) (z : (Site N → QBall) × (Site N → QBall)) =>
      H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) z.1 ω)) * H (act (src N) (tgt N) z.2 ω))
      ((wilsonProb N β : Measure (Lk N → QBall)).prod ((gam N).prod (gam N))) := by
    refine Integrable.of_bound ?_ (C * C) (Eventually.of_forall fun p => ?_)
    · refine Measurable.aestronglyMeasurable ?_
      refine (hH1.comp ?_).mul (hH.comp ?_)
      · exact ((continuous_act N).comp (Continuous.prodMk (continuous_fst.comp continuous_snd)
          continuous_fst)).measurable
      · exact ((continuous_act N).comp (Continuous.prodMk (continuous_snd.comp continuous_snd)
          continuous_fst)).measurable
    · rw [Real.norm_eq_abs]
      show |H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) p.2.1 p.1))
          * H (act (src N) (tgt N) p.2.2 p.1)| ≤ C * C
      rw [abs_mul]
      exact mul_le_mul (hb _) (hb _) (abs_nonneg _) hC
  have step : ∫ ω, H (linkRefl (thM N) (sigT N) ω) * H ω ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω, avgG N (fun ω => H (linkRefl (thM N) (sigT N) ω)) ω * avgG N H ω
          ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
    have r1 : ∀ ω, avgG N (fun ω => H (linkRefl (thM N) (sigT N) ω)) ω * avgG N H ω
        = ∫ z, H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) z.1 ω))
            * H (act (src N) (tgt N) z.2 ω) ∂((gam N).prod (gam N)) := fun ω =>
      (integral_prod_mul (μ := gam N) (ν := gam N)
        (fun g => H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) g ω)))
        (fun g => H (act (src N) (tgt N) g ω))).symm
    rw [integral_congr_ae (Eventually.of_forall r1), integral_integral_swap hf]
    have hu := ae_unit_pi (Site N)
    have hae : ∀ᵐ z ∂((gam N).prod (gam N)),
        ∫ ω, H (linkRefl (thM N) (sigT N) (act (src N) (tgt N) z.1 ω))
            * H (act (src N) (tgt N) z.2 ω) ∂(wilsonProb N β : Measure (Lk N → QBall))
          = ∫ ω, H (linkRefl (thM N) (sigT N) ω) * H ω
              ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
      have a1 := (Measure.quasiMeasurePreserving_fst (μ := gam N) (ν := gam N)).ae hu
      have a2 := (Measure.quasiMeasurePreserving_snd (μ := gam N) (ν := gam N)).ae hu
      filter_upwards [a1, a2] with z h1 h2
      exact pair_split N M hN (by omega) β H hH hdep z.1 z.2 h1 h2
    rw [integral_congr_ae hae, integral_const]
    simp
  -- step 2: the average of the reflected function is the reflected average
  have e : ∀ ω, avgG N (fun ω => H (linkRefl (thM N) (sigT N) ω)) ω * avgG N H ω
      = avgG N H ω * avgG N H (linkRefl (thM N) (sigT N) ω) := fun ω => by
    rw [avgG_refl N H hH ω]; ring
  rw [step, integral_congr_ae (Eventually.of_forall e), wilsonProb_toMeasure, integral_smul_measure]
  refine smul_nonneg ENNReal.toReal_nonneg ?_
  refine wilson_rp_mid N M hN hM β hβ (avgG N H) (measurable_avgG N H hH) C
    (abs_avgG_le N H C hb) (fun ω ω' hω => ?_) (fun k hk ω => avgG_act N H hH k hk ω)
  unfold avgG
  refine integral_congr_ae (Eventually.of_forall fun g => hdep _ _ (fun ℓ hℓ => ?_))
  show mulB (g (src N ℓ)) (g (tgt N ℓ)) (ω ℓ) = mulB (g (src N ℓ)) (g (tgt N ℓ)) (ω' ℓ)
  rw [hω ℓ (Or.inr hℓ)]

end Torus

theorem G_dep_pos (n R : ℕ) (hn : R + 1 ≤ n) (F : Cfg →ᵇ ℝ) (S : Finset ZLk)
    (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R)
    (hF : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y) (ω ω' : Lk (Nn n) → QBall)
    (h : ∀ ℓ, posM (Nn n) (n + 1) ℓ → ω ℓ = ω' ℓ) :
    F (zShift (perLift (Nn n) ω)) = F (zShift (perLift (Nn n) ω')) := by
  apply hF
  intro ℓ hℓ
  obtain ⟨h0, h1⟩ := hS ℓ hℓ
  show ω (zproj (Nn n) (zsh 1 ℓ)) = ω' (zproj (Nn n) (zsh 1 ℓ))
  apply h
  have ht : tm (Nn n) (zproj (Nn n) (zsh 1 ℓ)) = (ℓ.1 0 + 1).toNat := by
    unfold tm
    rw [proj_time, zsh_time, Nat.cast_one]
    exact val_intCast (Nn n) (ℓ.1 0 + 1) (by omega) (by unfold Nn; push_cast; omega)
  have hsnd : (zproj (Nn n) (zsh 1 ℓ)).2 = ℓ.2 := rfl
  unfold posM
  by_cases h2 : ℓ.2 = 0
  · rw [hsnd, if_pos h2, ht]
    omega
  · rw [hsnd, if_neg h2, ht]
    omega

/-- each torus: `∫ F(θx) F(τx) ≥ 0` for every `F ∈ W` -/
theorem torus_Tpos_full (β : ℝ) (hβ : 0 ≤ β) (F : Cfg →ᵇ ℝ) (n R : ℕ)
    (S : Finset ZLk) (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R)
    (hF : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y) (hn : R + 1 ≤ n) :
    0 ≤ ∫ x, F (zRefl x) * F (zShift x) ∂(liftProb β n : Measure Cfg) := by
  have hc : Continuous (fun x => F (zRefl x) * F (zShift x)) :=
    (F.continuous.comp continuous_zRefl).mul (F.continuous.comp continuous_zShift)
  have hGm : Measurable (fun ω : Lk (Nn n) → QBall => F (zShift (perLift (Nn n) ω))) :=
    (F.continuous.comp (continuous_zShift.comp (continuous_perLift _))).measurable
  have hrp := full_rp_torus (Nn n) (n + 1) rfl (by omega) β hβ
    (fun ω => F (zShift (perLift (Nn n) ω))) hGm ‖F‖ (fun ω => abs_le_norm' F _)
    (fun ω ω' h => G_dep_pos n R hn F S hS hF ω ω' h)
  have e : ∀ ω : Lk (Nn n) → QBall,
      F (zShift (perLift (Nn n) (linkRefl (thM (Nn n)) (sigT (Nn n)) ω)))
        * F (zShift (perLift (Nn n) ω))
      = F (zRefl (perLift (Nn n) ω)) * F (zShift (perLift (Nn n) ω)) := by
    intro ω
    rw [zShift_lift (Nn n) (linkRefl (thM (Nn n)) (sigT (Nn n)) ω), tShift_mid, ← zRefl_lift]
  rw [integral_congr_ae (Eventually.of_forall e)] at hrp
  rw [integral_lift β n _ hc]
  exact hrp

/-- **`T ≥ 0` on the whole reconstruction (all cylinder functions of the closed positive half)**,
at every weak limit point (`β ≥ 0`, Dobrushin window). -/
theorem wilson_Tpos_full (β lam : ℝ) (hβ : 0 ≤ β) (hlam : 0 < lam)
    (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
      (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      ∀ v : D.Hilb, 0 ≤ ⟪v, D.T v⟫_ℝ := by
  obtain ⟨D, hB, hτ, hone, hgap, hvar, hv⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  refine ⟨D, hB, hτ, hone, hgap, hvar, hv, ?_⟩
  have hW : ∀ F : Wsub, 0 ≤ ⟪D.emb F, D.T (D.emb F)⟫_ℝ := by
    intro F
    rw [D.T_emb, D.inner_emb, hB, hτ]
    obtain ⟨S, R, hS, hF⟩ := (mem_Wsub _).1 F.2
    have h : Tendsto (fun n => ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (F : Cfg →ᵇ ℝ) (zShift x)
        ∂(liftProb β (φ n) : Measure Cfg)) atTop
        (𝓝 (∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (F : Cfg →ᵇ ℝ) (zShift x) ∂(ν : Measure Cfg))) :=
      ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
        ((F : Cfg →ᵇ ℝ).compContinuous zReflC * (F : Cfg →ᵇ ℝ).compContinuous zShiftC)
    refine ge_of_tendsto h ?_
    filter_upwards [eventually_ge_atTop (R + 1)] with n hn
    exact torus_Tpos_full β hβ F (φ n) R S hS hF (hn.trans (hφ.id_le n))
  intro v
  exact D.denseRange_emb.induction_on (p := fun b => 0 ≤ ⟪b, D.T b⟫_ℝ) v
    (isClosed_le continuous_const (continuous_id.inner D.T.continuous)) hW

end FullT

#print axioms FullT.full_rp_torus
#print axioms FullT.wilson_Tpos_full
