import Lattice.TorusGaugeV1

/-!
# The full-space non-degeneracy witness `F₀` lies in the kernel of the transfer operator


* `CenterFlip.integral_act_prob` : the normalised Wilson measure on `(ℤ/N)⁴` is invariant under
  every gauge transformation with unit values.
* `CenterFlip.limit_zero` : at every weak limit point `ν` of the periodic lifts and for every
  `G ∈ W`, `∫ G(θx) · Re x_{ℓ₁} dν = 0`, where `ℓ₁` is the spatial link of direction 1 at the
  site `(1,0,0,0)`.  The centre element `-1` placed at that one site changes the sign of
  `Re x_{ℓ₁}` and leaves `G ∘ θ` unchanged (its links have both end points at times `≤ 0`).
* `CenterFlip.F0_kernel` : in the reconstruction of `wilson_massGap_dob`, `B(G, τF₀) = 0` for all
  `G ∈ W`, `T [F₀] = 0` and `B(1, F₀) = 0`: the witness of non-degeneracy is annihilated by `T`.
-/

namespace CenterFlip

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeFix TorusGauge
open scoped BoundedContinuousFunction InnerProductSpace

local notation "ℍr" => Quaternion ℝ

/-- the centre element `-1` in the closed ball -/
noncomputable def negB : QBall := ⟨-1, by rw [mem_closedBall_zero_iff, norm_neg, norm_one]⟩

theorem negB_norm : ‖((negB : QBall) : ℍr)‖ = 1 := by
  show ‖(-1 : ℍr)‖ = 1
  rw [norm_neg, norm_one]

theorem mulB_one_one (U : QBall) : mulB oneB oneB U = U := by
  apply Subtype.ext
  show (1 : ℍr) * (U : ℍr) * star (1 : ℍr) = U
  simp

theorem mulB_neg_one (U : QBall) : ((mulB negB oneB U : QBall) : ℍr) = -(U : ℍr) := by
  show (-1 : ℍr) * (U : ℍr) * star (1 : ℍr) = -(U : ℍr)
  simp

section Torus

variable (N : ℕ) [NeZero N]

/-- the projection of a site of ℤ⁴ to the torus -/
def projS (b : ZSite) : Site N := fun i => ((b i : ℤ) : ZMod N)

/-- the centre flip at the site `s`: `-1` at `s`, `1` elsewhere -/
noncomputable def gC (s : Site N) : Site N → QBall := fun y => if y = s then negB else oneB

theorem gC_unit (s : Site N) : ∀ y, ‖((gC N s y : QBall) : ℍr)‖ = 1 := by
  intro y
  unfold gC
  split_ifs
  · exact negB_norm
  · exact oneB_norm

theorem act_preserving (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1) :
    MeasurePreserving (act (src N) (tgt N) g) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) :=
  measurePreserving_pi (fun _ => haarBall) (fun _ => haarBall)
    (f := fun ℓ => mulB (g (src N ℓ)) (g (tgt N ℓ)))
    (fun ℓ => mulB_preserving (g (src N ℓ)) (g (tgt N ℓ)) (hg _) (hg _))

/-- gauge invariance of the (unnormalised) Wilson measure -/
theorem integral_act (β : ℝ) (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (K : (Lk N → QBall) → ℝ) (hK : Measurable K) :
    ∫ ω, K (act (src N) (tgt N) g ω) ∂(wilsonMeasure N β) = ∫ ω, K ω ∂(wilsonMeasure N β) := by
  rw [integral_wilson, integral_wilson]
  have hmp := act_preserving N g hg
  have hw : Measurable (fun ω => K ω * wilsonWeight N β ω) :=
    hK.mul (continuous_wilsonWeight N β).measurable
  have e : ∀ ω, K (act (src N) (tgt N) g ω) * wilsonWeight N β ω
      = (fun ω => K ω * wilsonWeight N β ω) (act (src N) (tgt N) g ω) := by
    intro ω
    show _ = K (act (src N) (tgt N) g ω) * wilsonWeight N β (act (src N) (tgt N) g ω)
    rw [wilsonWeight_act N β g hg ω]
  rw [integral_congr_ae (Eventually.of_forall e),
    ← integral_map hmp.measurable.aemeasurable hw.aestronglyMeasurable, hmp.map_eq]

/-- gauge invariance of the normalised Wilson measure -/
theorem integral_act_prob (β : ℝ) (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (K : (Lk N → QBall) → ℝ) (hK : Measurable K) :
    ∫ ω, K (act (src N) (tgt N) g ω) ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω, K ω ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    integral_act N β g hg K hK]

theorem intCast_ne_one (R : ℕ) (hN : R + 2 < N) (v : ℤ) (h0 : -(R : ℤ) - 1 ≤ v) (h1 : v ≤ 0) :
    ((v : ℤ) : ZMod N) ≠ 1 := by
  intro h
  have h2 : (((v - 1 : ℤ)) : ZMod N) = 0 := by push_cast; rw [h, sub_self]
  rw [ZMod.intCast_zmod_eq_zero_iff_dvd] at h2
  have h3 := Int.eq_zero_of_abs_lt_dvd h2 (by rw [abs_of_neg (by omega)]; omega)
  omega

/-- the end points of a reflected link of the closed positive half have times `≤ 0` -/
theorem refl_ends (R : ℕ) (hN : R + 2 < N) (ℓ : ZLk) (h0 : 0 ≤ ℓ.1 0) (h1 : ℓ.1 0 ≤ R) :
    src N (zproj N (zthL ℓ)) 0 ≠ 1 ∧ tgt N (zproj N (zthL ℓ)) 0 ≠ 1 := by
  have ht := zthL_time ℓ
  by_cases h2 : ℓ.2 = 0
  · rw [if_pos h2] at ht
    have hm2 : (zthL ℓ).2 = 0 := by unfold zthL; rw [if_pos h2]
    constructor
    · show (((zthL ℓ).1 0 : ℤ) : ZMod N) ≠ 1
      rw [ht]
      exact intCast_ne_one N R hN _ (by omega) (by omega)
    · show (((zthL ℓ).1 0 : ℤ) : ZMod N) + ev N (zthL ℓ).2 0 ≠ 1
      rw [ht, hm2, ev_zero_zero N]
      have e : (((-ℓ.1 0 - 1 : ℤ)) : ZMod N) + 1 = ((-ℓ.1 0 : ℤ) : ZMod N) := by push_cast; ring
      rw [e]
      exact intCast_ne_one N R hN _ (by omega) (by omega)
  · rw [if_neg h2] at ht
    have hm2 : (zthL ℓ).2 = ℓ.2 := by unfold zthL; rw [if_neg h2]
    constructor
    · show (((zthL ℓ).1 0 : ℤ) : ZMod N) ≠ 1
      rw [ht]
      exact intCast_ne_one N R hN _ (by omega) (by omega)
    · show (((zthL ℓ).1 0 : ℤ) : ZMod N) + ev N (zthL ℓ).2 0 ≠ 1
      rw [ht, hm2, ev_zero N h2, add_zero]
      exact intCast_ne_one N R hN _ (by omega) (by omega)

theorem gC_of_time (s y : Site N) (hs : s 0 = 1) (hy : y 0 ≠ 1) : gC N s y = oneB := by
  unfold gC
  rw [if_neg]
  intro h
  exact hy (by rw [h]; exact hs)

/-- the site `(1,0,0,0)` -/
def s0 : ZSite := Pi.single 0 1

theorem projS_s0_time : projS N s0 0 = 1 := by simp [projS, s0]

/-- `G ∘ θ` does not see the flip at `(1,0,0,0)` -/
theorem refl_part (R : ℕ) (hN : R + 2 < N) (S : Finset ZLk)
    (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R) (ω : Lk N → QBall) :
    ∀ ℓ ∈ S, zRefl (perLift N (act (src N) (tgt N) (gC N (projS N s0)) ω)) ℓ
      = zRefl (perLift N ω) ℓ := by
  intro ℓ hℓ
  obtain ⟨h0, h1⟩ := hS ℓ hℓ
  obtain ⟨e1, e2⟩ := refl_ends N R hN ℓ h0 h1
  have hs : projS N s0 0 = 1 := projS_s0_time N
  show zsig ℓ (mulB (gC N (projS N s0) (src N (zproj N (zthL ℓ))))
      (gC N (projS N s0) (tgt N (zproj N (zthL ℓ)))) (ω (zproj N (zthL ℓ))))
    = zsig ℓ (ω (zproj N (zthL ℓ)))
  rw [gC_of_time N _ _ hs e1, gC_of_time N _ _ hs e2, mulB_one_one]

/-- the flip at the base point `b` of the spatial link `(b, 1)` changes its sign -/
theorem flip_link (hN2 : 2 ≤ N) (b : ZSite) (ω : Lk N → QBall) :
    ((perLift N (act (src N) (tgt N) (gC N (projS N b)) ω) (b, 1) : QBall) : ℍr)
      = -((perLift N ω (b, 1) : QBall) : ℍr) := by
  have hsrc : gC N (projS N b) (src N (projS N b, 1)) = negB := by
    show (if projS N b = projS N b then negB else oneB) = negB
    exact if_pos rfl
  have htgt : gC N (projS N b) (tgt N (projS N b, 1)) = oneB := by
    unfold gC
    rw [if_neg]
    intro h
    change projS N b + ev N 1 = projS N b at h
    have h' : ev N 1 = 0 := by
      have : projS N b + ev N 1 = projS N b + 0 := by rw [add_zero]; exact h
      exact add_left_cancel this
    have h1 := congrFun h' 1
    have e : ev N 1 1 = 1 := by simp [ev]
    rw [e] at h1
    have : Fact (1 < N) := ⟨by omega⟩
    exact one_ne_zero h1
  show ((mulB (gC N (projS N b) (src N (projS N b, 1))) (gC N (projS N b) (tgt N (projS N b, 1)))
      (ω (projS N b, 1)) : QBall) : ℍr) = -((ω (projS N b, 1) : QBall) : ℍr)
  rw [hsrc, htgt, mulB_neg_one]

theorem ell1_eq : zsh 1 ell0 = (s0, 1) := by
  refine Prod.ext ?_ rfl
  funext i
  simp [zsh, ell0, s0]

theorem shift_part (hN2 : 2 ≤ N) (ω : Lk N → QBall) :
    F0 (zShift (perLift N (act (src N) (tgt N) (gC N (projS N s0)) ω)))
      = - F0 (zShift (perLift N ω)) := by
  show (((perLift N (act (src N) (tgt N) (gC N (projS N s0)) ω)) (zsh 1 ell0) : QBall) : ℍr).re
      = -(((perLift N ω) (zsh 1 ell0) : QBall) : ℍr).re
  rw [ell1_eq, flip_link N hN2 s0 ω, Quaternion.re_neg]

theorem mean_part (hN2 : 2 ≤ N) (ω : Lk N → QBall) :
    F0 (perLift N (act (src N) (tgt N) (gC N (projS N 0)) ω)) = - F0 (perLift N ω) := by
  show (((perLift N (act (src N) (tgt N) (gC N (projS N 0)) ω)) ((0 : ZSite), (1 : Fin 4)) : QBall)
      : ℍr).re = -(((perLift N ω) ((0 : ZSite), (1 : Fin 4)) : QBall) : ℍr).re
  rw [flip_link N hN2 0 ω, Quaternion.re_neg]

end Torus

/-- on each large torus, `∫ G(θx) Re x_{ℓ₁} = 0` -/
theorem lift_zero (β : ℝ) (G : Cfg →ᵇ ℝ) (S : Finset ZLk) (R : ℕ)
    (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R)
    (hG : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → G x = G y) (n : ℕ) (hn : R + 2 < Nn n) :
    ∫ x, G (zRefl x) * F0 (zShift x) ∂(liftProb β n : Measure Cfg) = 0 := by
  have hc : Continuous (fun x => G (zRefl x) * F0 (zShift x)) :=
    (G.continuous.comp continuous_zRefl).mul (F0.continuous.comp continuous_zShift)
  rw [integral_lift β n _ hc]
  have hK : Measurable (fun ω : Lk (Nn n) → QBall =>
      G (zRefl (perLift (Nn n) ω)) * F0 (zShift (perLift (Nn n) ω))) :=
    (hc.comp (continuous_perLift _)).measurable
  have hinv := integral_act_prob (Nn n) β (gC (Nn n) (projS (Nn n) s0)) (gC_unit _ _) _ hK
  have hN2 : 2 ≤ Nn n := by unfold Nn; omega
  have hneg : ∀ ω : Lk (Nn n) → QBall,
      G (zRefl (perLift (Nn n) (act (src (Nn n)) (tgt (Nn n)) (gC (Nn n) (projS (Nn n) s0)) ω)))
        * F0 (zShift (perLift (Nn n) (act (src (Nn n)) (tgt (Nn n)) (gC (Nn n) (projS (Nn n) s0)) ω)))
      = -(G (zRefl (perLift (Nn n) ω)) * F0 (zShift (perLift (Nn n) ω))) := by
    intro ω
    rw [hG _ _ (refl_part (Nn n) R hn S hS ω), shift_part (Nn n) hN2 ω]
    ring
  rw [integral_congr_ae (Eventually.of_forall hneg), integral_neg] at hinv
  linarith

/-- on each torus, `∫ Re x_{ℓ₀} = 0` -/
theorem lift_mean_zero (β : ℝ) (n : ℕ) :
    ∫ x, F0 x ∂(liftProb β n : Measure Cfg) = 0 := by
  rw [integral_lift β n _ F0.continuous]
  have hK : Measurable (fun ω : Lk (Nn n) → QBall => F0 (perLift (Nn n) ω)) :=
    (F0.continuous.comp (continuous_perLift _)).measurable
  have hinv := integral_act_prob (Nn n) β (gC (Nn n) (projS (Nn n) 0)) (gC_unit _ _) _ hK
  have hN2 : 2 ≤ Nn n := by unfold Nn; omega
  rw [integral_congr_ae (Eventually.of_forall (mean_part (Nn n) hN2)), integral_neg] at hinv
  linarith

theorem limit_zero (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (G : Cfg →ᵇ ℝ) (hGW : G ∈ Wsub) :
    ∫ x, G (zRefl x) * F0 (zShift x) ∂(ν : Measure Cfg) = 0 := by
  obtain ⟨S, R, hS, hG⟩ := (mem_Wsub G).1 hGW
  have h : Tendsto (fun n => ∫ x, G (zRefl x) * F0 (zShift x) ∂(liftProb β (φ n) : Measure Cfg))
      atTop (𝓝 (∫ x, G (zRefl x) * F0 (zShift x) ∂(ν : Measure Cfg))) :=
    ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
      (G.compContinuous zReflC * F0.compContinuous zShiftC)
  have hev : ∀ᶠ n in atTop,
      ∫ x, G (zRefl x) * F0 (zShift x) ∂(liftProb β (φ n) : Measure Cfg) = 0 := by
    filter_upwards [eventually_ge_atTop (R + 2)] with n hn
    refine lift_zero β G S R hS hG (φ n) ?_
    have : n ≤ φ n := hφ.id_le n
    unfold Nn
    omega
  exact tendsto_nhds_unique h (tendsto_const_nhds.congr' (hev.mono fun n hn => hn.symm))

theorem limit_mean_zero (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∫ x, F0 x ∂(ν : Measure Cfg) = 0 := by
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim F0
  exact tendsto_nhds_unique h (tendsto_const_nhds.congr' (Eventually.of_forall fun n =>
    (lift_mean_zero β (φ n)).symm))

/-- **The full-space witness is annihilated by the transfer operator.**  In the reconstruction of
`wilson_massGap_dob` (same `D`, same conjuncts), moreover `B(G, τF₀) = 0` for every `G ∈ W`,
`B(1, F₀) = 0` and `T [F₀] = 0`.  -/
theorem F0_kernel (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
      (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      (∀ G : Wsub, D.B G (D.τ ⟨F0, F0_mem⟩) = 0) ∧
      D.B D.one ⟨F0, F0_mem⟩ = 0 ∧
      D.T (D.emb ⟨F0, F0_mem⟩) = 0 := by
  obtain ⟨D, hB, hτ, hone, hgap, hvar, hv⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  have hBG : ∀ G : Wsub, D.B G (D.τ ⟨F0, F0_mem⟩) = 0 := by
    intro G
    rw [hB, hτ]
    exact limit_zero β ν φ hφ hlim G G.2
  have h1F : D.B D.one ⟨F0, F0_mem⟩ = 0 := by
    rw [hB, hone]
    have e : ∀ x : Cfg, (1 : Cfg →ᵇ ℝ) (zRefl x) * F0 x = F0 x := fun x => by simp
    rw [integral_congr_ae (Eventually.of_forall e)]
    exact limit_mean_zero β ν φ hlim
  refine ⟨D, hB, hτ, hone, hgap, hvar, hv, hBG, h1F, ?_⟩
  rw [D.T_emb]
  have h0 := hBG (D.τ ⟨F0, F0_mem⟩)
  have h1 := D.norm_emb_sq (D.τ ⟨F0, F0_mem⟩)
  rw [h0] at h1
  exact norm_eq_zero.1 ((pow_eq_zero_iff two_ne_zero).1 h1)

end CenterFlip

#print axioms CenterFlip.integral_act_prob
#print axioms CenterFlip.limit_zero
#print axioms CenterFlip.F0_kernel
