import Infvol.BindV2

/-!
# The range of `T` lies in the gauge-invariant sector, for every vector of the completion


`Bind.T_range_gauge_all` : as `Bind.T_emb_gauge_bound` (shift and unit fixed for both data), with
the last conjunct for every `u` in the completion: `∀ u, ∃ w, T u = ι w`.
Proof: `ι` is an isometry from a complete space, so its range is closed; `T` is continuous and
`emb(W)` is dense.
-/

namespace Bind

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ InfVol Restrict
open scoped BoundedContinuousFunction InnerProductSpace

theorem T_range_gauge_all (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub, ∃ D' : Datum Wgi,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      (∀ F G : Wgi, D'.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wgi, ((D'.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧ D'.HasMassGap lam ∧
      ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
        (∀ u, ι (D'.T u) = D.T (ι u)) ∧
        ∀ u : D.Hilb, ∃ w : D'.Hilb, D.T u = ι w := by
  obtain ⟨D, D', hB, hτ, hone, hB', hτ', hone', hg, hg', ι, h1, h2, h3, h4⟩ :=
    T_emb_gauge_bound β lam hlam hα ν φ hφ hlim
  have hiso : Isometry ι := AddMonoidHomClass.isometry_of_norm ι h1
  have hcl : IsClosed (Set.range ι) := hiso.isClosedEmbedding.isClosed_range
  have key : ∀ u : D.Hilb, D.T u ∈ Set.range ι := by
    intro u
    refine (D.denseRange_emb).induction_on u (hcl.preimage D.T.continuous) (fun F => ?_)
    obtain ⟨w, hw⟩ := h4 F
    exact ⟨w, hw.symm⟩
  refine ⟨D, D', hB, hτ, hone, hB', hτ', hone', hg, hg', ι, h1, h2, h3, fun u => ?_⟩
  obtain ⟨w, hw⟩ := key u
  exact ⟨w, hw.symm⟩

end Bind

#print axioms Bind.T_range_gauge_all
