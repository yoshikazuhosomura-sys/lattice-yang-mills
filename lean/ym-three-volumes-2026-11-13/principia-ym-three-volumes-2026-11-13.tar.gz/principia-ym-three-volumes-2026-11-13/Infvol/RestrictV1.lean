import Infvol.MidTV2

/-!
# The gauge-invariant reconstruction is the restriction of the full reconstruction


* `Restrict.subHilb` : a linear map `j : V' → V` with `B(jx, jy) = B'(x, y)`, `τ ∘ j = j ∘ τ'`,
  `j 1 = 1` gives a linear isometry `ι : Hilb' → Hilb` with `ι Ω' = Ω`, `ι T' = T ι` and
  `ι [x] = [j x]`.
* `Restrict.wilson_gauge_restrict` : at every weak limit point, the `W_gi` reconstruction embeds
  isometrically in the `W` reconstruction, intertwining the transfer operators and the vacua.
-/

namespace Restrict

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ
open scoped BoundedContinuousFunction InnerProductSpace

variable {V V' : Type*} [AddCommGroup V] [Module ℝ V] [AddCommGroup V'] [Module ℝ V']

/-- the map on the pre-Hilbert spaces -/
noncomputable def jPre (D : Datum V) (D' : Datum V') (j : V' →ₗ[ℝ] V)
    (hB : ∀ x y, D.B (j x) (j y) = D'.B x y) : D'.Pre →L[ℝ] D.Pre :=
  (D.toPre.toLinearMap ∘ₗ j ∘ₗ D'.ofPre.toLinearMap).mkContinuous 1 (fun a => by
    rw [one_mul, ← sq_le_sq₀ (norm_nonneg _) (norm_nonneg _), D.norm_sq, D'.norm_sq]
    show D.B (j (D'.ofPre a)) (j (D'.ofPre a)) ≤ _
    rw [hB])

theorem norm_jPre (D : Datum V) (D' : Datum V') (j : V' →ₗ[ℝ] V)
    (hB : ∀ x y, D.B (j x) (j y) = D'.B x y) (a : D'.Pre) : ‖jPre D D' j hB a‖ = ‖a‖ := by
  rw [← sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _), D.norm_sq, D'.norm_sq]
  show D.B (j (D'.ofPre a)) (j (D'.ofPre a)) = _
  rw [hB]

/-- **Restriction of reconstructions.** -/
theorem subHilb (D : Datum V) (D' : Datum V') (j : V' →ₗ[ℝ] V)
    (hB : ∀ x y, D.B (j x) (j y) = D'.B x y) (hτ : ∀ x, D.τ (j x) = j (D'.τ x))
    (hone : j D'.one = D.one) :
    ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
      (∀ u, ι (D'.T u) = D.T (ι u)) ∧ ∀ x, ι (D'.emb x) = D.emb (j x) := by
  set ι := (jPre D D' j hB).completion with hι
  have hemb : ∀ x, ι (D'.emb x) = D.emb (j x) := by
    intro x
    show ι (((D'.toPre x : D'.Pre)) : D'.Hilb) = _
    rw [hι, ContinuousLinearMap.completion_apply_coe]
    rfl
  refine ⟨ι, fun u => ?_, ?_, fun u => ?_, hemb⟩
  · refine UniformSpace.Completion.induction_on u
      (isClosed_eq (continuous_norm.comp ι.continuous) continuous_norm) (fun a => ?_)
    rw [hι, ContinuousLinearMap.completion_apply_coe, UniformSpace.Completion.norm_coe,
      UniformSpace.Completion.norm_coe, norm_jPre]
  · show ι (D'.emb D'.one) = D.emb D.one
    rw [hemb, hone]
  · refine UniformSpace.Completion.induction_on u
      (isClosed_eq (ι.continuous.comp D'.T.continuous) (D.T.continuous.comp ι.continuous))
      (fun a => ?_)
    have e1 : ((a : D'.Pre) : D'.Hilb) = D'.emb (D'.ofPre a) := rfl
    rw [e1, D'.T_emb, hemb, hemb, D.T_emb, hτ]

/-- **At every weak limit point the gauge-invariant reconstruction is the restriction of the
full one** (Dobrushin window). -/
theorem wilson_gauge_restrict (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub, ∃ D' : Datum Wgi,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F G : Wgi, D'.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      D.HasMassGap lam ∧ D'.HasMassGap lam ∧
      (∃ v : D'.Hilb, ⟪v, D'.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
        (∀ u, ι (D'.T u) = D.T (ι u)) ∧
        ∀ F : Wgi, ι (D'.emb F) = D.emb (Submodule.inclusion inf_le_left F) := by
  obtain ⟨D, hB, hτ, hone, hgap, -, -⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  obtain ⟨D', hB', hτ', hone', hgap', -, hv'⟩ := wilson_massGap_gauge β lam hlam hα ν φ hφ hlim
  have hBj : ∀ x y : Wgi, D.B (Submodule.inclusion inf_le_left x)
      (Submodule.inclusion inf_le_left y) = D'.B x y := by
    intro x y
    rw [hB, hB']
    rfl
  have hτj : ∀ x : Wgi, D.τ (Submodule.inclusion inf_le_left x)
      = Submodule.inclusion inf_le_left (D'.τ x) := by
    intro x
    apply Subtype.ext
    rw [hτ]
    show _ = ((D'.τ x : Wgi) : Cfg →ᵇ ℝ)
    rw [hτ']
    rfl
  have honej : Submodule.inclusion inf_le_left D'.one = D.one := by
    apply Subtype.ext
    rw [hone]
    show ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1
    exact hone'
  obtain ⟨ι, h1, h2, h3, h4⟩ := subHilb D D' (Submodule.inclusion inf_le_left) hBj hτj honej
  exact ⟨D, D', hB, hB', hgap, hgap', hv', ι, h1, h2, h3, h4⟩

end Restrict

#print axioms Restrict.subHilb
#print axioms Restrict.wilson_gauge_restrict
