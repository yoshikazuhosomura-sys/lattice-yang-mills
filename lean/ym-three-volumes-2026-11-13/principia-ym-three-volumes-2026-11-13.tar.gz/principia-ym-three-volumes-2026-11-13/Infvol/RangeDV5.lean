import Infvol.RangeCV2

/-!
# `T [F] ∈ ι(W_gi)` for every cylinder function `F`


`GaugeRange.T_emb_gauge` : at every weak limit point (Dobrushin window), with `ι` the isometric
embedding of the gauge-invariant reconstruction, every `T [F]` (`F ∈ W`) equals `ι [G]` for a
`G ∈ W_gi`: the transfer operator maps the full reconstruction into the gauge-invariant sector.
-/

namespace GaugeRange

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge ZHeat InfVol Restrict
open scoped BoundedContinuousFunction InnerProductSpace

local notation "ℍr" => Quaternion ℝ

theorem gq_one (q : QBall) : gq 1 1 q = q := by
  apply Subtype.ext
  show ((1 : SU2) : ℍr) * (q : ℍr) * star ((1 : SU2) : ℍr) = q
  rw [show ((1 : SU2) : ℍr) = 1 from rfl]
  simp

theorem T_emb_gauge (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub, ∃ D' : Datum Wgi,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F G : Wgi, D'.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      D.HasMassGap lam ∧ D'.HasMassGap lam ∧
      ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
        (∀ u, ι (D'.T u) = D.T (ι u)) ∧
        ∀ F : Wsub, ∃ w : D'.Hilb, D.T (D.emb F) = ι w := by
  obtain ⟨D, hB, hτ, hone, hgap, -, -⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  obtain ⟨D', hB', hτ', hone', hgap', -, -⟩ := wilson_massGap_gauge β lam hlam hα ν φ hφ hlim
  have hBj : ∀ x y : Wgi, D.B (Submodule.inclusion inf_le_left x)
      (Submodule.inclusion inf_le_left y) = D'.B x y := by
    intro x y; rw [hB, hB']; rfl
  have hτj : ∀ x : Wgi, D.τ (Submodule.inclusion inf_le_left x)
      = Submodule.inclusion inf_le_left (D'.τ x) := by
    intro x; apply Subtype.ext; rw [hτ]
    show _ = ((D'.τ x : Wgi) : Cfg →ᵇ ℝ)
    rw [hτ']; rfl
  have honej : Submodule.inclusion inf_le_left D'.one = D.one := by
    apply Subtype.ext; rw [hone]; show ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1; exact hone'
  obtain ⟨ι, h1, h2, h3, h4⟩ := subHilb D D' (Submodule.inclusion inf_le_left) hBj hτj honej
  refine ⟨D, D', hB, hB', hgap, hgap', ι, h1, h2, h3, fun F => ?_⟩
  obtain ⟨TF, R, hTF, hdep⟩ := (mem_Wsub _).1 F.2
  obtain ⟨S, hSdef⟩ : ∃ S : Finset ZSite,
      S = TF.image (fun ℓ => (zsh 1 ℓ).1) ∪ TF.image (fun ℓ => (zsh 1 ℓ).1 + zev ℓ.2) := ⟨_, rfl⟩
  have hSt : ∀ y ∈ S, 1 ≤ y 0 := by
    intro y hy
    rw [hSdef, Finset.mem_union, Finset.mem_image, Finset.mem_image] at hy
    rcases hy with ⟨ℓ, hℓ, rfl⟩ | ⟨ℓ, hℓ, rfl⟩
    · rw [zsh_time]; have := (hTF ℓ hℓ).1; push_cast; omega
    · have := (hTF ℓ hℓ).1
      simp only [Pi.add_apply, zev, Pi.single_apply]
      rw [zsh_time]
      split_ifs <;> push_cast <;> omega
  obtain ⟨τF, hτFdef⟩ : ∃ τF : Cfg →ᵇ ℝ, τF = shiftMap zShiftC (F : Cfg →ᵇ ℝ) := ⟨_, rfl⟩
  have hτmem : τF ∈ Wsub := by rw [hτFdef]; exact shift_mem_Wsub _ F.2
  have hdepS : DepS S τF := by
    intro x y h
    rw [hτFdef]
    show (F : Cfg →ᵇ ℝ) (zShift x) = (F : Cfg →ᵇ ℝ) (zShift y)
    apply hdep
    intro ℓ hℓ
    show x (zsh 1 ℓ) = y (zsh 1 ℓ)
    apply h
    · rw [hSdef]; exact Finset.mem_union_left _ (Finset.mem_image_of_mem _ hℓ)
    · rw [hSdef]; exact Finset.mem_union_right _ (Finset.mem_image_of_mem (fun ℓ => (zsh 1 ℓ).1 + zev ℓ.2) hℓ)
  have hGmem : avgB S τF ∈ Wgi :=
    Submodule.mem_inf.2 ⟨avgB_mem_Wsub S τF hτmem, avgB_mem_Winv S τF hdepS⟩
  let G : Wgi := ⟨avgB S τF, hGmem⟩
  have hBK : ∀ K : Wsub, D.B K (D.τ F) = D.B K (Submodule.inclusion inf_le_left G) := by
    intro K
    obtain ⟨TK, RK, hTK, hdepK⟩ := (mem_Wsub _).1 K.2
    rw [hB, hB, hτ]
    have hK : ∀ (g : S → SU2) x, (K : Cfg →ᵇ ℝ) (zRefl (gaugeAct (gext S g) x))
        = (K : Cfg →ᵇ ℝ) (zRefl x) := by
      intro g x
      apply hdepK
      intro m hm
      have hm0 := (hTK m hm).1
      have ht := zthL_time m
      have hn1 : ∀ y : ZSite, y 0 ≤ 0 → gext S g y = 1 := by
        intro y hy
        unfold gext
        rw [dif_neg]
        intro hyS
        have := hSt y hyS
        omega
      have ea : gext S g (zthL m).1 = 1 := hn1 _ (by rw [ht]; split_ifs <;> omega)
      have eb : gext S g ((zthL m).1 + zev (zthL m).2) = 1 := by
        apply hn1
        have hm2 : (zthL m).2 = m.2 := by unfold zthL; split_ifs with h <;> simp [h]
        simp only [Pi.add_apply, zev, Pi.single_apply, hm2]
        rw [ht]
        split_ifs <;> omega
      show zsig m (gq (gext S g (zthL m).1) (gext S g ((zthL m).1 + zev (zthL m).2)) (x (zthL m)))
        = zsig m (x (zthL m))
      rw [ea, eb, gq_one]
    have hT : ∀ x y : Cfg, (∀ ℓ ∈ TK.image zthL ∪ TF.image (zsh 1), x ℓ = y ℓ) →
        (K : Cfg →ᵇ ℝ) (zRefl x) * τF x = (K : Cfg →ᵇ ℝ) (zRefl y) * τF y := by
      intro x y h
      have a : (K : Cfg →ᵇ ℝ) (zRefl x) = (K : Cfg →ᵇ ℝ) (zRefl y) := hdepK _ _ (fun m hm => by
        show zsig m (x (zthL m)) = zsig m (y (zthL m))
        rw [h _ (Finset.mem_union_left _ (Finset.mem_image_of_mem _ hm))])
      have b : τF x = τF y := by
        rw [hτFdef]
        show (F : Cfg →ᵇ ℝ) (zShift x) = (F : Cfg →ᵇ ℝ) (zShift y)
        exact hdep _ _ (fun ℓ hℓ => h _ (Finset.mem_union_right _ (Finset.mem_image_of_mem _ hℓ)))
      rw [a, b]
    have hp := pair_avg β ν φ hφ hlim S (K : Cfg →ᵇ ℝ) τF hK _ hT
    rw [← hτFdef]
    exact hp.symm
  obtain ⟨b, hb⟩ : ∃ b : Wsub, b = Submodule.inclusion inf_le_left G := ⟨_, rfl⟩
  have hBK' : ∀ K : Wsub, D.B K (D.τ F) = D.B K b := fun K => by rw [hb]; exact hBK K
  have hsub : D.emb (D.τ F) = D.emb b := by
    have hsq : ‖D.emb (D.τ F) - D.emb b‖ ^ 2 = 0 := by
      rw [norm_sub_sq_real, D.norm_emb_sq, D.norm_emb_sq, D.inner_emb, hBK' (D.τ F), ← hBK' b,
        D.symm b (D.τ F)]
      ring
    exact sub_eq_zero.1 (norm_eq_zero.1 ((pow_eq_zero_iff two_ne_zero).1 hsq))
  exact ⟨D'.emb G, by rw [D.T_emb, hsub, hb, h4]; rfl⟩

end GaugeRange

#print axioms GaugeRange.T_emb_gauge
