import Infvol.CylDetV2
import Infvol.CenterKerV2
import Lattice.ClusterV1

/-!
# The infinite-volume limit without subsequences, conditional on the cylinder Cauchy property


* `InfVol.lift_shift_invariant`, `InfVol.limit_shift_invariant` : each periodic lift, and every weak
  limit point, is invariant under the time translation.
* `InfVol.wilson_infvol_of_cauchy` : if the integrals of every cylinder function along the whole
  sequence `liftProb β n` (tori `(ℤ/2(n+1))⁴`, all `n`) form Cauchy sequences, then the whole
  sequence converges weakly to one `ν_β`; every subsequential limit equals `ν_β`; `ν_β` is
  time-translation invariant and reflection positive on `W`; the reconstruction from `ν_β` has the
  mass gap `-ln(18 tanh|β|)/2` with non-degeneracy and `T [F₀] = 0`; the gauge-invariant sector
  has the same gap with non-degeneracy; clustering holds in the four directions.
  The Cauchy hypothesis is step (a) of and is not proved here.
-/

namespace InfVol

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ CylDet CenterFlip
open scoped BoundedContinuousFunction InnerProductSpace

theorem lift_shift_invariant (β : ℝ) (n : ℕ) (F : Cfg →ᵇ ℝ) :
    ∫ x, F (zShift x) ∂(liftProb β n : Measure Cfg) = ∫ x, F x ∂(liftProb β n : Measure Cfg) := by
  rw [integral_lift β n (fun x => F (zShift x)) (F.continuous.comp continuous_zShift),
    integral_lift β n (fun x => F x) F.continuous]
  simp only [zShift_lift]
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_shift_invariant (Nn n) β (fun ω => F (perLift (Nn n) ω))
      ((F.continuous.comp (continuous_perLift _)).measurable)]

theorem limit_shift_invariant (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (F : Cfg →ᵇ ℝ) :
    ∫ x, F (zShift x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg) := by
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
  have h1 : Tendsto (fun n => ∫ x, F (zShift x) ∂(liftProb β (φ n) : Measure Cfg)) atTop
      (𝓝 (∫ x, F (zShift x) ∂(ν : Measure Cfg))) := h (F.compContinuous zShiftC)
  exact tendsto_nhds_unique h1 ((h F).congr fun n => (lift_shift_invariant β (φ n) F).symm)

/-- **Infinite-volume theorem without subsequences (conditional on the cylinder Cauchy property).**;
the hypothesis `hC` is step (a). -/
theorem wilson_infvol_of_cauchy (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1)
    (hC : ∀ F : Cfg →ᵇ ℝ, IsCyl F →
      CauchySeq (fun n => ∫ x, F x ∂(liftProb β n : Measure Cfg))) :
    ∃ ν : ProbabilityMeasure Cfg,
      Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      (∀ (ν' : ProbabilityMeasure Cfg) (φ : ℕ → ℕ), StrictMono φ →
        Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν') → ν' = ν) ∧
      (∀ F : Cfg →ᵇ ℝ, ∫ x, F (zShift x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg)) ∧
      (∀ F ∈ Wsub, 0 ≤ ∫ x, F (zRefl x) * F x ∂(ν : Measure Cfg)) ∧
      (∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
        (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
        D.T (D.emb ⟨F0, F0_mem⟩) = 0) ∧
      (∃ D : Datum Wgi,
        (∀ F G : Wgi, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
        ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      (∀ (i : Fin 4) (F G : Cfg →ᵇ ℝ) (SF SG : Finset ZLk) (R : ℕ),
        (∀ ℓ ∈ SF, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) → (∀ ℓ ∈ SG, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) →
        (∀ x y : Cfg, (∀ ℓ ∈ SF, x ℓ = y ℓ) → F x = F y) →
        (∀ x y : Cfg, (∀ ℓ ∈ SG, x ℓ = y ℓ) → G x = G y) →
        ∀ k : ℕ, R ≤ k →
          |∫ x, F x * G (zShI i k x) ∂(ν : Measure Cfg)
              - (∫ x, F x ∂(ν : Measure Cfg)) * ∫ x, G (zShI i k x) ∂(ν : Measure Cfg)|
            ≤ 4 * ‖F‖ * ‖G‖ * SG.card
              * Real.exp (-((-Real.log (dobConst β) / 2) * ((k : ℝ) - R)))) := by
  obtain ⟨ν, hν⟩ := tendsto_of_cyl_cauchy (fun n => liftProb β n) hC
  have hid : Tendsto (fun n => liftProb β (id n)) atTop (𝓝 ν) := hν
  obtain ⟨hl, hα⟩ := dob_rate β hβ0 hq
  obtain ⟨D, hB, hτ, hone, hgap, hvar, hv, -, -, hT⟩ :=
    F0_kernel β _ hl hα ν id strictMono_id hid
  refine ⟨ν, hν, fun ν' φ hφ h' => subseq_limit_eq _ ν hν ν' φ hφ h',
    limit_shift_invariant β ν id hid, ?_, ⟨D, hB, hτ, hone, hgap, hvar, hv, hT⟩,
    wilson_massGap_gauge β _ hl hα ν id strictMono_id hid, ?_⟩
  · intro F hF
    have h0 := D.nonneg ⟨F, hF⟩
    rw [hB] at h0
    exact h0
  · intro i F G SF SG R hSF hSG hF hG k hk
    exact cluster_limit β _ hl.le hα i F G SF SG R hSF hSG hF hG ν id strictMono_id hid k hk

end InfVol

#print axioms InfVol.limit_shift_invariant
#print axioms InfVol.wilson_infvol_of_cauchy
