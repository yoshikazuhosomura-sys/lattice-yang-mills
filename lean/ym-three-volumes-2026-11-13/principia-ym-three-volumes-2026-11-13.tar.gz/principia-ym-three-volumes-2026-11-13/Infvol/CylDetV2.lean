import Lattice.WilsonGapV2

/-!
# Cylinder functions determine probability measures on the link configurations of ℤ⁴

Paper correspondence: (steps (b), (c) and the abstract part of (d)).
* `CylDet.ext_of_cyl` : two finite measures on `Cfg = (links of ℤ⁴) → ball` with the same
  integrals of all bounded continuous cylinder functions are equal (finite-dimensional marginals
  agree by `ext_of_forall_integral_eq_of_IsFiniteMeasure`, then Mathlib's uniqueness of the
  projective limit).
* `CylDet.tendsto_of_cyl` : a sequence of probability measures on `Cfg` whose integrals of every
  cylinder function converge, converges weakly (no subsequence): `Cfg` is compact, every
  subsequence has a convergent sub-subsequence, and all such limits agree on cylinder functions.
* `CylDet.tendsto_of_cyl_cauchy` : the same from Cauchy sequences of integrals.
-/

namespace CylDet

open MeasureTheory Filter Topology WilsonLimit TorusRP
open scoped BoundedContinuousFunction

/-- bounded continuous functions of finitely many links -/
def IsCyl (F : Cfg →ᵇ ℝ) : Prop :=
  ∃ S : Finset ZLk, ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y

theorem measurable_restrict' (I : Finset ZLk) :
    Measurable (I.restrict : Cfg → (∀ j : I, QBall)) :=
  measurable_pi_lambda _ (fun _ => measurable_pi_apply _)

theorem continuous_restrict' (I : Finset ZLk) :
    Continuous (I.restrict : Cfg → (∀ j : I, QBall)) :=
  continuous_pi fun j => continuous_apply _

theorem isCyl_restrict (I : Finset ZLk) (f : (∀ j : I, QBall) →ᵇ ℝ) :
    IsCyl (f.compContinuous ⟨I.restrict, continuous_restrict' I⟩) := by
  refine ⟨I, fun x y h => ?_⟩
  show f (I.restrict x) = f (I.restrict y)
  congr 1
  funext j
  exact h j.1 j.2

/-- **(c) Cylinder functions determine the measure.** -/
theorem ext_of_cyl (μ ν : Measure Cfg) [IsFiniteMeasure μ] [IsFiniteMeasure ν]
    (h : ∀ F : Cfg →ᵇ ℝ, IsCyl F → ∫ x, F x ∂μ = ∫ x, F x ∂ν) : μ = ν := by
  have hm : ∀ I : Finset ZLk, ν.map I.restrict = μ.map I.restrict := by
    intro I
    apply ext_of_forall_integral_eq_of_IsFiniteMeasure
    intro f
    rw [integral_map (measurable_restrict' I).aemeasurable f.continuous.aestronglyMeasurable,
      integral_map (measurable_restrict' I).aemeasurable f.continuous.aestronglyMeasurable]
    exact (h _ (isCyl_restrict I f)).symm
  exact IsProjectiveLimit.unique (P := fun I => μ.map I.restrict) (fun I => rfl) hm

/-- **(b)+(d) Convergence on cylinder functions gives weak convergence of the whole sequence.** -/
theorem tendsto_of_cyl (μs : ℕ → ProbabilityMeasure Cfg)
    (h : ∀ F : Cfg →ᵇ ℝ, IsCyl F → ∃ L : ℝ,
      Tendsto (fun n => ∫ x, F x ∂(μs n : Measure Cfg)) atTop (𝓝 L)) :
    ∃ ν : ProbabilityMeasure Cfg, Tendsto μs atTop (𝓝 ν) := by
  obtain ⟨ν, -, φ, hφ, hν⟩ :=
    (isCompact_univ : IsCompact (Set.univ : Set (ProbabilityMeasure Cfg))).tendsto_subseq
      (x := μs) (fun n => Set.mem_univ _)
  have key : ∀ ψ : ℕ → ℕ, Tendsto ψ atTop atTop → ∀ ν' : ProbabilityMeasure Cfg,
      Tendsto (fun n => μs (ψ n)) atTop (𝓝 ν') → ν' = ν := by
    intro ψ hψ ν' hν'
    refine ProbabilityMeasure.toMeasure_injective (ext_of_cyl _ _ fun F hF => ?_)
    obtain ⟨L, hL⟩ := h F hF
    have h1 : Tendsto (fun n => ∫ x, F x ∂(μs (ψ n) : Measure Cfg)) atTop
        (𝓝 (∫ x, F x ∂(ν' : Measure Cfg))) :=
      ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hν' F
    have h2 : Tendsto (fun n => ∫ x, F x ∂(μs (φ n) : Measure Cfg)) atTop
        (𝓝 (∫ x, F x ∂(ν : Measure Cfg))) :=
      ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hν F
    have e1 := tendsto_nhds_unique h1 (hL.comp hψ)
    have e2 := tendsto_nhds_unique h2 (hL.comp hφ.tendsto_atTop)
    rw [e1, e2]
  refine ⟨ν, tendsto_of_subseq_tendsto fun ns hns => ?_⟩
  obtain ⟨ν', -, ψ, hψ, hν'⟩ :=
    (isCompact_univ : IsCompact (Set.univ : Set (ProbabilityMeasure Cfg))).tendsto_subseq
      (x := fun n => μs (ns n)) (fun n => Set.mem_univ _)
  refine ⟨ψ, ?_⟩
  have e := key (fun n => ns (ψ n)) (hns.comp hψ.tendsto_atTop) ν' hν'
  rw [← e]
  exact hν'

theorem tendsto_of_cyl_cauchy (μs : ℕ → ProbabilityMeasure Cfg)
    (h : ∀ F : Cfg →ᵇ ℝ, IsCyl F → CauchySeq (fun n => ∫ x, F x ∂(μs n : Measure Cfg))) :
    ∃ ν : ProbabilityMeasure Cfg, Tendsto μs atTop (𝓝 ν) :=
  tendsto_of_cyl μs fun F hF => cauchySeq_tendsto_of_complete (h F hF)

/-- a limit of the whole sequence is the limit of every subsequence -/
theorem subseq_limit_eq (μs : ℕ → ProbabilityMeasure Cfg) (ν : ProbabilityMeasure Cfg)
    (hν : Tendsto μs atTop (𝓝 ν)) (ν' : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hν' : Tendsto (fun n => μs (φ n)) atTop (𝓝 ν')) : ν' = ν :=
  tendsto_nhds_unique hν' (hν.comp hφ.tendsto_atTop)

end CylDet

#print axioms CylDet.ext_of_cyl
#print axioms CylDet.tendsto_of_cyl
#print axioms CylDet.tendsto_of_cyl_cauchy
