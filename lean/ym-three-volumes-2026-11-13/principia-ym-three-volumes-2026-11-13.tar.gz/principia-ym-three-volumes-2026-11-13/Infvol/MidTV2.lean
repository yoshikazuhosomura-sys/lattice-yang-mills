import Infvol.CauchyV2
import Lattice.MidRPV2

/-!
# Positivity of the transfer operator in the gauge-invariant sector


* `MidT.tShift_mid` : the time translation after the middle-plane reflection `x₀ ↦ 1 - x₀` is the
  site-plane reflection `x₀ ↦ -x₀` (on configurations of the torus).
* `MidT.lift_gauge` : the periodic lift intertwines torus and ℤ⁴ gauge transformations.
* `MidT.torus_Tpos` : for `F ∈ W_gi` (support in base times `0 … R`) and `n ≥ R + 1`, `β ≥ 0`,
  `∫ F(θx) F(τx) d(liftProb β n) ≥ 0` (from `MidRP.wilson_rp_mid` applied to `F ∘ τ ∘ lift`).
* `MidT.wilson_Tpos_gauge` : at every weak limit point (`β ≥ 0`, Dobrushin window), the
  reconstruction on `W_gi` has `⟪v, T v⟫ ≥ 0` for every `v` (besides the gap and non-degeneracy).
* `MidT.wilson_infvol_Tpos` : the same for the limit `ν_β` of the whole sequence (`β > 0`).
-/

namespace MidT

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge MidRP ZHeat InfVol
open scoped BoundedContinuousFunction InnerProductSpace

local notation "ℍr" => Quaternion ℝ

section Torus

variable (N : ℕ) [NeZero N]

theorem tShift_mid (ω : Lk N → QBall) :
    tShift N (linkRefl (thM N) (sigT N) ω) = linkRefl (thL N) (sig N) ω := by
  funext ℓ
  show sigT N (shL N ℓ) (ω (thM N (shL N ℓ))) = sig N ℓ (ω (thL N ℓ))
  have e2 : sigT N (shL N ℓ) = sig N ℓ := rfl
  have e1 : thM N (shL N ℓ) = thL N ℓ := by
    by_cases h : ℓ.2 = 0
    · have a1 : thL N (shL N ℓ) = (thS N (ℓ.1 + ev N 0) - ev N 0, 0) := if_pos h
      have a2 : thL N ℓ = (thS N ℓ.1 - ev N 0, 0) := if_pos h
      show shL N (thL N (shL N ℓ)) = thL N ℓ
      rw [a1, a2]
      refine Prod.ext ?_ rfl
      show thS N (ℓ.1 + ev N 0) - ev N 0 + ev N 0 = thS N ℓ.1 - ev N 0
      rw [thS_add, thS_ev0]
      abel
    · have a1 : thL N (shL N ℓ) = (thS N (ℓ.1 + ev N 0), ℓ.2) := if_neg h
      have a2 : thL N ℓ = (thS N ℓ.1, ℓ.2) := if_neg h
      show shL N (thL N (shL N ℓ)) = thL N ℓ
      rw [a1, a2]
      refine Prod.ext ?_ rfl
      show thS N (ℓ.1 + ev N 0) + ev N 0 = thS N ℓ.1
      rw [thS_add, thS_ev0]
      abel
  rw [e1, e2]

/-- the ℤ⁴ gauge transformation induced by a torus one -/
noncomputable def gLift (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1) :
    ZSite → SU2 :=
  fun y => ⟨((g (pS N y) : QBall) : ℍr), mem_sphere_zero_iff_norm.2 (hg _)⟩

theorem lift_gauge (g : Site N → QBall) (hg : ∀ x, ‖((g x : QBall) : ℍr)‖ = 1)
    (ω : Lk N → QBall) :
    perLift N (act (src N) (tgt N) g ω) = gaugeAct (gLift N g hg) (perLift N ω) := by
  funext ℓ
  apply Subtype.ext
  show ((g (pS N ℓ.1) : QBall) : ℍr) * ((ω (zproj N ℓ) : QBall) : ℍr)
      * star ((g (pS N ℓ.1 + ev N ℓ.2) : QBall) : ℍr)
    = ((g (pS N ℓ.1) : QBall) : ℍr) * ((ω (zproj N ℓ) : QBall) : ℍr)
      * star ((g (pS N (ℓ.1 + zev ℓ.2)) : QBall) : ℍr)
  rw [show zev ℓ.2 = ze ℓ.2 from rfl, pS_add]

end Torus

theorem G_dep (n R : ℕ) (hn : R + 1 ≤ n) (F : Cfg →ᵇ ℝ) (S : Finset ZLk)
    (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R)
    (hF : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y) (ω ω' : Lk (Nn n) → QBall)
    (h : ∀ ℓ, cr (Nn n) (n + 1) ℓ ∨ posM (Nn n) (n + 1) ℓ → ω ℓ = ω' ℓ) :
    F (zShift (perLift (Nn n) ω)) = F (zShift (perLift (Nn n) ω')) := by
  apply hF
  intro ℓ hℓ
  obtain ⟨h0, h1⟩ := hS ℓ hℓ
  show ω (zproj (Nn n) (zsh 1 ℓ)) = ω' (zproj (Nn n) (zsh 1 ℓ))
  apply h
  have ht : tm (Nn n) (zproj (Nn n) (zsh 1 ℓ)) = (ℓ.1 0 + 1).toNat := by
    unfold tm
    rw [proj_time, zsh_time, Nat.cast_one]
    exact val_intCast (Nn n) (ℓ.1 0 + 1) (by omega) (by unfold Nn; push_cast; omega)
  have hsnd : (zproj (Nn n) (zsh 1 ℓ)).2 = ℓ.2 := rfl
  by_cases h2 : ℓ.2 = 0
  · by_cases hM : (ℓ.1 0 + 1).toNat = n + 1
    · left
      rw [cr_iff (Nn n) (n + 1) rfl (by omega)]
      exact ⟨h2, Or.inr (by rw [ht, hM])⟩
    · right
      unfold posM
      rw [hsnd, if_pos h2, ht]
      omega
  · right
    unfold posM
    rw [hsnd, if_neg h2, ht]
    omega

/-- **Reflection positivity across the middle plane, on each torus, for `F ∘ τ`.** -/
theorem torus_Tpos (β : ℝ) (hβ : 0 ≤ β) (F : Cfg →ᵇ ℝ) (hFW : F ∈ Wgi) (n R : ℕ)
    (S : Finset ZLk) (hS : ∀ ℓ ∈ S, 0 ≤ ℓ.1 0 ∧ ℓ.1 0 ≤ R)
    (hF : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y) (hn : R + 1 ≤ n) :
    0 ≤ ∫ x, F (zRefl x) * F (zShift x) ∂(liftProb β n : Measure Cfg) := by
  have hc : Continuous (fun x => F (zRefl x) * F (zShift x)) :=
    (F.continuous.comp continuous_zRefl).mul (F.continuous.comp continuous_zShift)
  have hinvF : ∀ g x, F (gaugeAct g x) = F x := (Submodule.mem_inf.1 hFW).2
  have hGm : Measurable (fun ω : Lk (Nn n) → QBall => F (zShift (perLift (Nn n) ω))) :=
    (F.continuous.comp (continuous_zShift.comp (continuous_perLift _))).measurable
  have hrp := wilson_rp_mid (Nn n) (n + 1) rfl (by omega) β hβ
    (fun ω => F (zShift (perLift (Nn n) ω))) hGm ‖F‖ (fun ω => abs_le_norm' F _)
    (fun ω ω' h => G_dep n R hn F S hS hF ω ω' h)
    (fun g hg ω => by
      show F (zShift (perLift (Nn n) (act (src (Nn n)) (tgt (Nn n)) g ω)))
        = F (zShift (perLift (Nn n) ω))
      rw [lift_gauge (Nn n) g hg ω, zShift_gauge, hinvF])
  have e : ∀ ω : Lk (Nn n) → QBall,
      F (zShift (perLift (Nn n) ω))
        * F (zShift (perLift (Nn n) (linkRefl (thM (Nn n)) (sigT (Nn n)) ω)))
      = F (zRefl (perLift (Nn n) ω)) * F (zShift (perLift (Nn n) ω)) := by
    intro ω
    rw [zShift_lift (Nn n) (linkRefl (thM (Nn n)) (sigT (Nn n)) ω), tShift_mid, ← zRefl_lift]
    ring
  rw [integral_congr_ae (Eventually.of_forall e)] at hrp
  rw [integral_lift β n _ hc, wilsonProb_toMeasure, integral_smul_measure]
  exact smul_nonneg ENNReal.toReal_nonneg hrp

/-- **`T ≥ 0` in the gauge-invariant sector at every weak limit point** (`β ≥ 0`). -/
theorem wilson_Tpos_gauge (β lam : ℝ) (hβ : 0 ≤ β) (hlam : 0 < lam)
    (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wgi,
      (∀ F G : Wgi, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧
      Real.exp (-(12 * |β|)) / 4 ≤
        D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
      (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      ∀ v : D.Hilb, 0 ≤ ⟪v, D.T v⟫_ℝ := by
  obtain ⟨D, hB, hτ, hone, hgap, hvar, hv⟩ := wilson_massGap_gauge β lam hlam hα ν φ hφ hlim
  refine ⟨D, hB, hτ, hone, hgap, hvar, hv, ?_⟩
  have hW : ∀ F : Wgi, 0 ≤ ⟪D.emb F, D.T (D.emb F)⟫_ℝ := by
    intro F
    rw [D.T_emb, D.inner_emb, hB, hτ]
    obtain ⟨S, R, hS, hF⟩ := (mem_Wsub _).1 (mem_Wsub_of_Wgi F.2)
    have h : Tendsto (fun n => ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (F : Cfg →ᵇ ℝ) (zShift x)
        ∂(liftProb β (φ n) : Measure Cfg)) atTop
        (𝓝 (∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (F : Cfg →ᵇ ℝ) (zShift x) ∂(ν : Measure Cfg))) :=
      ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
        ((F : Cfg →ᵇ ℝ).compContinuous zReflC * (F : Cfg →ᵇ ℝ).compContinuous zShiftC)
    refine ge_of_tendsto h ?_
    filter_upwards [eventually_ge_atTop (R + 1)] with n hn
    exact torus_Tpos β hβ F F.2 (φ n) R S hS hF (hn.trans (hφ.id_le n))
  intro v
  exact D.denseRange_emb.induction_on (p := fun b => 0 ≤ ⟪b, D.T b⟫_ℝ) v
    (isClosed_le continuous_const (continuous_id.inner D.T.continuous)) hW

/-- **The limit of the whole sequence, gauge-invariant sector: gap, non-degeneracy, `T ≥ 0`.** -/
theorem wilson_infvol_Tpos (β : ℝ) (hβ : 0 < β) (hq : dobConst β < 1) :
    ∃ ν : ProbabilityMeasure Cfg, Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      ∃ D : Datum Wgi,
        (∀ F G : Wgi, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
        (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
        ∀ v : D.Hilb, 0 ≤ ⟪v, D.T v⟫_ℝ := by
  obtain ⟨ν, hν, -⟩ := wilson_infvol_unique β hβ.ne' hq
  obtain ⟨hl, hα⟩ := dob_rate β hβ.ne' hq
  exact ⟨ν, hν, wilson_Tpos_gauge β _ hβ.le hl hα ν id strictMono_id hν⟩

end MidT

#print axioms MidT.torus_Tpos
#print axioms MidT.wilson_Tpos_gauge
#print axioms MidT.wilson_infvol_Tpos
