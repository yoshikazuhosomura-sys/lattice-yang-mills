import Lattice.ClusterV1

/-!
# Heat-bath sweeps of a box: the torus half of the comparison of two volumes

Paper correspondence: (step (a), the part inside one torus).
* `Sweep.box_one`, `Sweep.box_iter`, `Sweep.box_bound` : sweeping exactly the sites of `A`
  (weights `ρ`, `Σ_{y≠x} ρ_y C_{xy} ≤ α ρ_x`, `0 < α ≤ 1`): the weighted oscillation on `A`
  contracts by `α` per sweep, the total weighted oscillation does not grow, so after `K` sweeps
  `Σ_y δ_y ≤ α^K a_0/ρ_A + (a_0 + b_0)/ρ_out`.
* `LinkSpec.dmax`, `LinkSpec.dmax_lip`, `LinkSpec.row_up` : the max-norm cyclic distance of the base
  point from the origin changes by at most one between plaquette neighbours, so
  `ρ_y = e^{λ d(y)}` (weights growing away from the origin) satisfies the row condition with
  `α = e^λ · 18 tanh|β|`.
* `LinkSpec.torus_box` : on `(ℤ/N)⁴`, for `f` with single-link oscillations `δ`, sweeping a box
  `A` (every link outside `A` has `d ≥ L_b + 1`) `K` times gives, for every configuration `ω`,
  `|E_N f - (Q_A^K f)(ω)| ≤ (α^K + e^{-λ(L_b+1)}) Σ_y e^{λ d(y)} δ_y`.  Constants do not depend
  on `N`.
-/

namespace Sweep

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem aS_add_bS (A : Finset ι) (ρ δ : ι → ℝ) : aS A ρ δ + bS A ρ δ = ∑ y, ρ y * δ y := by
  unfold aS bS
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun y _ => ?_
  split_ifs <;> ring

theorem Ψw_empty (α : ℝ) (ρ δ : ι → ℝ) : Ψw α ρ ∅ δ = α * ∑ y, ρ y * δ y := by
  unfold Ψw
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  simp

theorem aS_nonneg (A : Finset ι) (ρ δ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y) (hδ : ∀ y, 0 ≤ δ y) :
    0 ≤ aS A ρ δ :=
  Finset.sum_nonneg fun y _ => by
    show 0 ≤ (if y ∈ A then ρ y * δ y else 0)
    split_ifs
    · exact mul_nonneg (hρ y) (hδ y)
    · exact le_rfl

/-- one sweep of exactly the sites of `A` -/
theorem box_one (C : ι → ι → ℝ) (α : ℝ) (hα0 : 0 < α) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : L.toFinset = A)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) :
    aS A ρ (sweep C L δ) ≤ α * aS A ρ δ ∧
      aS A ρ (sweep C L δ) + bS A ρ (sweep C L δ) ≤ aS A ρ δ + bS A ρ δ := by
  have h := potential_sweep_w C α hα1 hC0 ρ hρ hrow L ∅ δ hδ hnd
    (fun x _ => Finset.notMem_empty x)
  rw [Finset.empty_union, hLA, Ψw_A, Ψw_empty, ← aS_add_bS A ρ δ] at h
  have hb : bS A ρ δ ≤ bS A ρ (sweep C L δ) := by
    unfold bS
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · exact le_rfl
    · have hyL : y ∉ L := fun hm => hy (hLA ▸ List.mem_toFinset.2 hm)
      exact mul_le_mul_of_nonneg_left (sweep_ge_of_not_mem C hC0 L δ hδ y hyL) (hρ y)
  have ha' := aS_nonneg A ρ (sweep C L δ) hρ (sweep_nonneg C hC0 L δ hδ)
  have hb' : bS A ρ (sweep C L δ) ≤ aS A ρ δ + bS A ρ δ := by
    by_contra hcon
    push_neg at hcon
    have := mul_lt_mul_of_pos_left hcon hα0
    linarith
  have m1 := mul_le_mul_of_nonneg_left hb hα0.le
  have m2 := mul_le_mul_of_nonneg_left hb' (sub_nonneg.2 hα1)
  constructor
  · nlinarith
  · nlinarith

theorem box_iter (C : ι → ι → ℝ) (α : ℝ) (hα0 : 0 < α) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : L.toFinset = A)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) :
    ∀ K : ℕ, aS A ρ ((sweep C L)^[K] δ) ≤ α ^ K * aS A ρ δ ∧
      aS A ρ ((sweep C L)^[K] δ) + bS A ρ ((sweep C L)^[K] δ) ≤ aS A ρ δ + bS A ρ δ
  | 0 => by simp
  | K + 1 => by
    obtain ⟨ih1, ih2⟩ := box_iter C α hα0 hα1 hC0 ρ hρ hrow A L hnd hLA δ hδ K
    have hδK := iter_nonneg C hC0 L K δ hδ
    obtain ⟨h1, h2⟩ := box_one C α hα0 hα1 hC0 ρ hρ hrow A L hnd hLA _ hδK
    rw [Function.iterate_succ_apply']
    constructor
    · calc _ ≤ α * aS A ρ ((sweep C L)^[K] δ) := h1
        _ ≤ α * (α ^ K * aS A ρ δ) := mul_le_mul_of_nonneg_left ih1 hα0.le
        _ = α ^ (K + 1) * aS A ρ δ := by ring
    · linarith

/-- **Total oscillation after `K` sweeps of the box `A`.** -/
theorem box_bound (C : ι → ι → ℝ) (α : ℝ) (hα0 : 0 < α) (hα1 : α ≤ 1) (hC0 : ∀ x y, 0 ≤ C x y)
    (ρ : ι → ℝ) (hρ : ∀ y, 0 ≤ ρ y)
    (hrow : ∀ x, ∑ y ∈ univ.erase x, ρ y * C x y ≤ α * ρ x)
    (A : Finset ι) (L : List ι) (hnd : L.Nodup) (hLA : L.toFinset = A)
    (δ : ι → ℝ) (hδ : ∀ y, 0 ≤ δ y) (ρA ρout : ℝ) (hρA : 0 < ρA) (hρout : 0 < ρout)
    (hA : ∀ y ∈ A, ρA ≤ ρ y) (hO : ∀ y, y ∉ A → ρout ≤ ρ y) (K : ℕ) :
    ∑ y, ((sweep C L)^[K] δ) y ≤ α ^ K * aS A ρ δ / ρA + (aS A ρ δ + bS A ρ δ) / ρout := by
  obtain ⟨h1, h2⟩ := box_iter C α hα0 hα1 hC0 ρ hρ hrow A L hnd hLA δ hδ K
  have hδK : ∀ y, 0 ≤ ((sweep C L)^[K] δ) y := iter_nonneg C hC0 L K δ hδ
  have hsplit : ∑ y, ((sweep C L)^[K] δ) y
      = (∑ y, if y ∈ A then ((sweep C L)^[K] δ) y else 0)
        + ∑ y, if y ∈ A then 0 else ((sweep C L)^[K] δ) y := by
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun y _ => ?_
    split_ifs <;> ring
  have hAs : (∑ y, if y ∈ A then ((sweep C L)^[K] δ) y else 0)
      ≤ aS A ρ ((sweep C L)^[K] δ) / ρA := by
    unfold aS
    rw [Finset.sum_div]
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · rw [le_div_iff₀ hρA]
      nlinarith [hA y hy, hδK y]
    · simp
  have hBs : (∑ y, if y ∈ A then 0 else ((sweep C L)^[K] δ) y)
      ≤ bS A ρ ((sweep C L)^[K] δ) / ρout := by
    unfold bS
    rw [Finset.sum_div]
    refine Finset.sum_le_sum fun y _ => ?_
    split_ifs with hy
    · simp
    · rw [le_div_iff₀ hρout]
      nlinarith [hO y hy, hδK y]
  have hb0 := bS_nonneg A ρ _ hρ hδK
  have ha0 := aS_nonneg A ρ _ hρ hδK
  have e1 : aS A ρ ((sweep C L)^[K] δ) / ρA ≤ α ^ K * aS A ρ δ / ρA :=
    div_le_div_of_nonneg_right h1 hρA.le
  have e2 : bS A ρ ((sweep C L)^[K] δ) / ρout ≤ (aS A ρ δ + bS A ρ δ) / ρout :=
    div_le_div_of_nonneg_right (by linarith) hρout.le
  linarith

end Sweep

namespace LinkSpec

open MeasureTheory TorusRP Finset Filter SwapDecay WilsonLimit

variable (N : ℕ) [NeZero N]

/-- the max-norm cyclic distance of the base point from the origin -/
def dmax (y : Lk N) : ℕ := Finset.univ.sup (fun i => cdistI N i 0 y)

theorem nbr_symm (x y : Lk N)
    (h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0) :
    ((plaqsAt N y).filter (fun p => x ∈ plaqLinks N p)).card ≠ 0 := by
  obtain ⟨p, hp⟩ := Finset.card_pos.1 (Nat.pos_of_ne_zero h)
  rw [Finset.mem_filter] at hp
  obtain ⟨hp1, hy⟩ := hp
  unfold plaqsAt at hp1
  rw [Finset.mem_filter] at hp1
  refine Finset.card_ne_zero_of_mem (a := p) ?_
  rw [Finset.mem_filter]
  refine ⟨?_, hp1.2⟩
  unfold plaqsAt
  rw [Finset.mem_filter]
  exact ⟨hp1.1, hy⟩

theorem dmax_lip (x y : Lk N)
    (h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card ≠ 0) :
    dmax N y ≤ dmax N x + 1 := by
  unfold dmax
  apply Finset.sup_le
  intro i _
  have h1 := coordLip N i 0 y x (nbr_symm N x y h)
  have h2 : cdistI N i 0 x ≤ Finset.univ.sup (fun i => cdistI N i 0 x) :=
    Finset.le_sup (f := fun i => cdistI N i 0 x) (Finset.mem_univ i)
  omega

/-- the row condition with weights growing away from the origin -/
theorem row_up (β lam : ℝ) (hlam : 0 ≤ lam) (x : Lk N) :
    ∑ y ∈ univ.erase x, Real.exp (lam * dmax N y) * coef N β x y
      ≤ (Real.exp lam * dobConst β) * Real.exp (lam * dmax N x) := by
  have hrow := dobrushin_row N β x
  have hterm : ∀ y ∈ univ.erase x, Real.exp (lam * dmax N y) * coef N β x y
      ≤ (Real.exp lam * Real.exp (lam * dmax N x)) * coef N β x y := by
    intro y _
    by_cases h : ((plaqsAt N x).filter (fun p => y ∈ plaqLinks N p)).card = 0
    · rw [coef_eq_zero N β x y h]; simp
    · refine mul_le_mul_of_nonneg_right ?_ (coef_nonneg N β x y)
      rw [← Real.exp_add]
      apply Real.exp_le_exp.2
      have := dmax_lip N x y h
      have : (dmax N y : ℝ) ≤ dmax N x + 1 := by exact_mod_cast this
      nlinarith
  calc _ ≤ ∑ y ∈ univ.erase x, (Real.exp lam * Real.exp (lam * dmax N x)) * coef N β x y :=
        Finset.sum_le_sum hterm
    _ = (Real.exp lam * Real.exp (lam * dmax N x)) * ∑ y ∈ univ.erase x, coef N β x y := by
        rw [Finset.mul_sum]
    _ ≤ (Real.exp lam * Real.exp (lam * dmax N x)) * dobConst β :=
        mul_le_mul_of_nonneg_left hrow (by positivity)
    _ = _ := by ring

/-- **Box sweep on one torus.**  `|E_N f - (Q_A^K f)(ω)| ≤ (α^K + e^{-λ(L_b+1)}) Σ_y e^{λ d(y)} δ_y`
with `α = e^λ · 18 tanh|β|`, for every configuration `ω`. -/
theorem torus_box (β lam : ℝ) (hβ0 : β ≠ 0) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * dobConst β ≤ 1)
    (f : (Lk N → QBall) → ℝ) (hf : Measurable f) (c : ℝ) (hfb : ∀ ω, |f ω| ≤ c)
    (δ : Lk N → ℝ) (hδ : ∀ y, 0 ≤ δ y)
    (hosc : ∀ y, ∀ ω ω' : Lk N → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) → |f ω - f ω'| ≤ δ y)
    (A : Finset (Lk N)) (L : List (Lk N)) (hnd : L.Nodup) (hLA : L.toFinset = A)
    (Lb : ℕ) (hout : ∀ y, y ∉ A → Lb + 1 ≤ dmax N y) (K : ℕ) (ω : Lk N → QBall) :
    |∫ ω', f ω' ∂(wilsonProb N β : Measure (Lk N → QBall)) - (hbSweep N β L)^[K] f ω|
      ≤ ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))))
          * ∑ y, Real.exp (lam * dmax N y) * δ y := by
  have hα0 : 0 < Real.exp lam * dobConst β := mul_pos (Real.exp_pos _) (dobConst_pos β hβ0)
  have hC0 := coef_nonneg N β
  have hρ : ∀ y, 0 ≤ Real.exp (lam * dmax N y) := fun y => (Real.exp_pos _).le
  have hrow : ∀ x, ∑ y ∈ univ.erase x, Real.exp (lam * dmax N y) * coef N β x y
      ≤ (Real.exp lam * dobConst β) * Real.exp (lam * dmax N x) := fun x => row_up N β lam hlam x
  obtain ⟨mK, bK, oK⟩ := iter_props N β L K f hf c hfb δ hδ hosc
  have hsum := Sweep.box_bound (coef N β) _ hα0 hα hC0 (fun y => Real.exp (lam * dmax N y)) hρ hrow
    A L hnd hLA δ hδ 1 (Real.exp (lam * (Lb + 1))) one_pos (Real.exp_pos _)
    (fun y _ => Real.one_le_exp (by positivity))
    (fun y hy => by
      apply Real.exp_le_exp.2
      have h1 := hout y hy
      have h2 : ((Lb : ℝ) + 1) ≤ dmax N y := by exact_mod_cast h1
      nlinarith) K
  have hosc_g : ∀ ω', |(hbSweep N β L)^[K] f ω' - (hbSweep N β L)^[K] f ω|
      ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y := by
    intro ω'
    have h := osc_total N ((hbSweep N β L)^[K] f) _ oK (univ : Finset (Lk N)).toList ω' ω
      (fun ℓ hℓ => absurd (Finset.mem_toList.2 (Finset.mem_univ ℓ)) hℓ)
    rwa [Finset.sum_map_toList] at h
  have hinv : ∫ ω', f ω' ∂(wilsonProb N β : Measure (Lk N → QBall))
      = ∫ ω', (hbSweep N β L)^[K] f ω' ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
    rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
      iter_invariant N β L K f hf c hfb]
  have hgi : Integrable ((hbSweep N β L)^[K] f) (wilsonProb N β : Measure (Lk N → QBall)) :=
    Integrable.of_bound mK.aestronglyMeasurable c
      (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact bK x)
  have hdiff : ∫ ω', (hbSweep N β L)^[K] f ω' ∂(wilsonProb N β : Measure (Lk N → QBall))
        - (hbSweep N β L)^[K] f ω
      = ∫ ω', ((hbSweep N β L)^[K] f ω' - (hbSweep N β L)^[K] f ω)
          ∂(wilsonProb N β : Measure (Lk N → QBall)) := by
    rw [integral_sub hgi (integrable_const _), integral_const]
    simp
  have hbd : |∫ ω', ((hbSweep N β L)^[K] f ω' - (hbSweep N β L)^[K] f ω)
      ∂(wilsonProb N β : Measure (Lk N → QBall))|
      ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y := by
    have h := norm_integral_le_of_norm_le_const (μ := (wilsonProb N β : Measure (Lk N → QBall)))
      (Eventually.of_forall fun ω' => (by rw [Real.norm_eq_abs]; exact hosc_g ω' :
        ‖(hbSweep N β L)^[K] f ω' - (hbSweep N β L)^[K] f ω‖
          ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y))
    simpa using h
  have hab := Sweep.aS_add_bS A (fun y => Real.exp (lam * dmax N y)) δ
  have hb0 := Sweep.bS_nonneg A (fun y => Real.exp (lam * dmax N y)) δ hρ hδ
  have hαK : 0 ≤ (Real.exp lam * dobConst β) ^ K := pow_nonneg hα0.le K
  have e3 : (Sweep.aS A (fun y => Real.exp (lam * dmax N y)) δ
        + Sweep.bS A (fun y => Real.exp (lam * dmax N y)) δ) / Real.exp (lam * (Lb + 1))
      = Real.exp (-(lam * (Lb + 1))) * ∑ y, Real.exp (lam * dmax N y) * δ y := by
    rw [hab, Real.exp_neg, div_eq_inv_mul]
  rw [hinv, hdiff]
  calc _ ≤ ∑ y, ((Sweep.sweep (coef N β) L)^[K] δ) y := hbd
    _ ≤ _ := hsum
    _ ≤ ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))))
          * ∑ y, Real.exp (lam * dmax N y) * δ y := by
        rw [div_one, e3]
        have hle : Sweep.aS A (fun y => Real.exp (lam * dmax N y)) δ
            ≤ ∑ y, Real.exp (lam * dmax N y) * δ y := by linarith
        nlinarith [mul_le_mul_of_nonneg_left hle hαK]

end LinkSpec

#print axioms Sweep.box_bound
#print axioms LinkSpec.row_up
#print axioms LinkSpec.torus_box
