import Infvol.BoxSweepV1

/-!
# The single-link heat bath on ℤ⁴ and its agreement with the torus heat bath inside a box

Paper correspondence: (step (a), the part comparing two volumes).
* `ZHeat.sum_plaqsAt` : on `(ℤ/N)⁴`, `N ≥ 2`, the plaquettes through a link `x = (b, μ)` are the
  `up` and `down` plaquettes in the six directions `ν ≠ μ` (an explicit bijection).
* `ZHeat.locActZ`, `ZHeat.hbZ`, `ZHeat.hbSweepZ` : the same local action, heat bath and sweep on
  the configurations of ℤ⁴ (defined by the explicit six-direction formula).
* `ZHeat.locAct_lift`, `ZHeat.heatBath_lift` : for a link `ℓ` with `|ℓ_i| ≤ L` and a torus with
  `2(L+1) < N`, the torus local action at the projected link equals the ℤ⁴ one of the periodic lift,
  and the torus heat bath of `f ∘ lift` is `(heat bath of f) ∘ lift`, for every `f` depending only
  on the links with `|m_i| ≤ L + 1`.
* `ZHeat.iter_lift` : the same for `K` sweeps of a list of such links: the torus sweeps of
  `f ∘ lift` are `(ℤ⁴ sweeps of f) ∘ lift`, the same function for every large torus.
-/

namespace ZHeat

open MeasureTheory TorusRP LinkSpec WilsonLimit Finset

local notation "ℍr" => Quaternion ℝ

/-- the unit vector of direction `μ` in ℤ⁴ -/
def ze (μ : Fin 4) : ZSite := Pi.single μ 1

/-- plaquette holonomy on ℤ⁴ (the formula of `hol`) -/
noncomputable def holZ (ξ : Cfg) (q : ZLk × Fin 4) : ℍr :=
  ((ξ q.1 : QBall) : ℍr) * ((ξ (q.1.1 + ze q.1.2, q.2) : QBall) : ℍr)
    * star ((ξ (q.1.1 + ze q.2, q.1.2) : QBall) : ℍr) * star ((ξ (q.1.1, q.2) : QBall) : ℍr)

/-- the four links of a plaquette of ℤ⁴ -/
def linksZ (q : ZLk × Fin 4) : Finset ZLk :=
  {q.1, (q.1.1 + ze q.1.2, q.2), (q.1.1 + ze q.2, q.1.2), (q.1.1, q.2)}

theorem holZ_congr (ξ η : Cfg) (q : ZLk × Fin 4) (h : ∀ m ∈ linksZ q, ξ m = η m) :
    holZ ξ q = holZ η q := by
  unfold holZ
  rw [h q.1 (by simp [linksZ]), h (q.1.1 + ze q.1.2, q.2) (by simp [linksZ]),
    h (q.1.1 + ze q.2, q.1.2) (by simp [linksZ]), h (q.1.1, q.2) (by simp [linksZ])]

/-- the plaquette through `ℓ = (b, μ)` spanned by `μ, ν` with base `b` -/
def upZ (ℓ : ZLk) (ν : Fin 4) : ZLk × Fin 4 :=
  if ℓ.2 < ν then ((ℓ.1, ℓ.2), ν) else ((ℓ.1, ν), ℓ.2)

/-- the plaquette through `ℓ = (b, μ)` spanned by `μ, ν` with base `b - e_ν` -/
def dnZ (ℓ : ZLk) (ν : Fin 4) : ZLk × Fin 4 :=
  if ℓ.2 < ν then ((ℓ.1 - ze ν, ℓ.2), ν) else ((ℓ.1 - ze ν, ν), ℓ.2)

/-- the local action of the link `ℓ` of ℤ⁴ -/
noncomputable def locActZ (β : ℝ) (ξ : Cfg) (ℓ : ZLk) (U : QBall) : ℝ :=
  β * ∑ ν ∈ univ.erase ℓ.2,
    ((holZ (Function.update ξ ℓ U) (upZ ℓ ν)).re + (holZ (Function.update ξ ℓ U) (dnZ ℓ ν)).re)

/-- the heat bath of the link `ℓ` of ℤ⁴ -/
noncomputable def hbZ (β : ℝ) (ℓ : ZLk) (f : Cfg → ℝ) (ξ : Cfg) : ℝ :=
  (∫ U, f (Function.update ξ ℓ U) * Real.exp (locActZ β ξ ℓ U) ∂haarBall) /
    (∫ U, Real.exp (locActZ β ξ ℓ U) ∂haarBall)

/-- heat baths along a list of links of ℤ⁴ -/
noncomputable def hbSweepZ (β : ℝ) : List ZLk → (Cfg → ℝ) → (Cfg → ℝ)
  | [], f => f
  | ℓ :: L, f => hbSweepZ β L (hbZ β ℓ f)

/-- the box `|m_i| ≤ R` -/
def inBox (R : ℕ) (m : ZLk) : Prop := ∀ i, |m.1 i| ≤ R

/-- `f` depends only on the links of the box `R` -/
def DepBox (R : ℕ) (f : Cfg → ℝ) : Prop :=
  ∀ ξ η : Cfg, (∀ m, inBox R m → ξ m = η m) → f ξ = f η

theorem box_mono {L : ℕ} {m : ZLk} (h : inBox L m) : inBox (L + 1) m := fun i => by
  have := h i
  push_cast
  linarith

theorem links_up (L : ℕ) (ℓ : ZLk) (hℓ : inBox L ℓ) (ν : Fin 4) :
    ∀ m ∈ linksZ (upZ ℓ ν), inBox (L + 1) m := by
  intro m hm
  unfold upZ at hm
  split_ifs at hm <;>
  · simp only [linksZ, Finset.mem_insert, Finset.mem_singleton] at hm
    rcases hm with rfl | rfl | rfl | rfl <;>
    · intro i
      have a := abs_le.1 (hℓ i)
      simp only [ze, Pi.add_apply, Pi.single_apply]
      first
        | exact abs_le.2 ⟨by push_cast; omega, by push_cast; omega⟩
        | (split_ifs <;> exact abs_le.2 ⟨by push_cast; omega, by push_cast; omega⟩)

theorem links_dn (L : ℕ) (ℓ : ZLk) (hℓ : inBox L ℓ) (ν : Fin 4) :
    ∀ m ∈ linksZ (dnZ ℓ ν), inBox (L + 1) m := by
  intro m hm
  unfold dnZ at hm
  split_ifs at hm <;>
  · simp only [linksZ, Finset.mem_insert, Finset.mem_singleton] at hm
    rcases hm with rfl | rfl | rfl | rfl <;>
    · intro i
      have a := abs_le.1 (hℓ i)
      simp only [ze, Pi.add_apply, Pi.sub_apply, Pi.single_apply]
      first
        | exact abs_le.2 ⟨by push_cast; omega, by push_cast; omega⟩
        | (split_ifs <;> exact abs_le.2 ⟨by push_cast; omega, by push_cast; omega⟩)

section Torus

variable (N : ℕ) [NeZero N]

/-- projection of a site -/
def pS (b : ZSite) : Site N := fun i => ((b i : ℤ) : ZMod N)

/-- projection of a plaquette -/
def projP (q : ZLk × Fin 4) : Lk N × Fin 4 := ((pS N q.1.1, q.1.2), q.2)

theorem pS_add (b : ZSite) (μ : Fin 4) : pS N (b + ze μ) = pS N b + ev N μ := by
  funext i
  simp only [pS, ze, ev, Pi.add_apply, Pi.single_apply]
  split_ifs <;> push_cast <;> ring

theorem pS_sub (b : ZSite) (μ : Fin 4) : pS N (b - ze μ) = pS N b - ev N μ := by
  funext i
  simp only [pS, ze, ev, Pi.sub_apply, Pi.single_apply]
  split_ifs <;> push_cast <;> ring

theorem hol_lift (ω : Lk N → QBall) (q : ZLk × Fin 4) :
    hol N ω (projP N q) = holZ (perLift N ω) q := by
  show ((ω (pS N q.1.1, q.1.2) : QBall) : ℍr) * ((ω (pS N q.1.1 + ev N q.1.2, q.2) : QBall) : ℍr)
      * star ((ω (pS N q.1.1 + ev N q.2, q.1.2) : QBall) : ℍr)
      * star ((ω (pS N q.1.1, q.2) : QBall) : ℍr)
    = ((ω (pS N q.1.1, q.1.2) : QBall) : ℍr) * ((ω (pS N (q.1.1 + ze q.1.2), q.2) : QBall) : ℍr)
      * star ((ω (pS N (q.1.1 + ze q.2), q.1.2) : QBall) : ℍr)
      * star ((ω (pS N q.1.1, q.2) : QBall) : ℍr)
  rw [pS_add, pS_add]

/-- torus plaquettes through `x` -/
def upT (x : Lk N) (ν : Fin 4) : Lk N × Fin 4 :=
  if x.2 < ν then ((x.1, x.2), ν) else ((x.1, ν), x.2)

def dnT (x : Lk N) (ν : Fin 4) : Lk N × Fin 4 :=
  if x.2 < ν then ((x.1 - ev N ν, x.2), ν) else ((x.1 - ev N ν, ν), x.2)

theorem up_proj (ℓ : ZLk) (ν : Fin 4) : upT N (zproj N ℓ) ν = projP N (upZ ℓ ν) := by
  unfold upT upZ projP
  rw [show (zproj N ℓ).2 = ℓ.2 from rfl, show (zproj N ℓ).1 = pS N ℓ.1 from rfl]
  split_ifs <;> rfl

theorem dn_proj (ℓ : ZLk) (ν : Fin 4) : dnT N (zproj N ℓ) ν = projP N (dnZ ℓ ν) := by
  unfold dnT dnZ projP
  rw [show (zproj N ℓ).2 = ℓ.2 from rfl, show (zproj N ℓ).1 = pS N ℓ.1 from rfl]
  split_ifs <;> (simp only [pS_sub]; try rfl)

theorem ev_ne_zero (hN : 2 ≤ N) (ν : Fin 4) : ev N ν ≠ 0 := by
  intro h
  have h1 := congrFun h ν
  have e : ev N ν ν = 1 := by simp [ev]
  rw [e] at h1
  have : Fact (1 < N) := ⟨by omega⟩
  exact one_ne_zero h1

/-- the direction of a plaquette through `x` other than that of `x` -/
def od (x : Lk N) (p : Lk N × Fin 4) : Fin 4 := if p.1.2 = x.2 then p.2 else p.1.2

theorem od_up (x : Lk N) (ν : Fin 4) (hν : ν ≠ x.2) : od N x (upT N x ν) = ν := by
  unfold od upT
  by_cases h : x.2 < ν
  · simp [h]
  · simp [h, hν]

theorem od_dn (x : Lk N) (ν : Fin 4) (hν : ν ≠ x.2) : od N x (dnT N x ν) = ν := by
  unfold od dnT
  by_cases h : x.2 < ν
  · simp [h]
  · simp [h, hν]

theorem base_up (x : Lk N) (ν : Fin 4) : (upT N x ν).1.1 = x.1 := by
  unfold upT; split_ifs <;> rfl

theorem base_dn (x : Lk N) (ν : Fin 4) : (dnT N x ν).1.1 = x.1 - ev N ν := by
  unfold dnT; split_ifs <;> rfl

/-- **The plaquettes through a torus link, explicitly** (`N ≥ 2`). -/
theorem sum_plaqsAt (hN : 2 ≤ N) (x : Lk N) (g : Lk N × Fin 4 → ℝ) :
    ∑ p ∈ plaqsAt N x, g p = ∑ ν ∈ univ.erase x.2, (g (upT N x ν) + g (dnT N x ν)) := by
  have hsplit : ∑ ν ∈ univ.erase x.2, (g (upT N x ν) + g (dnT N x ν))
      = ∑ a ∈ (univ.erase x.2) ×ˢ (univ : Finset Bool),
          g (if a.2 then upT N x a.1 else dnT N x a.1) := by
    rw [Finset.sum_product]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [Fintype.sum_bool]
    simp only [if_true, Bool.false_eq_true, if_false]
  rw [hsplit]
  symm
  refine Finset.sum_bij (fun a _ => if a.2 then upT N x a.1 else dnT N x a.1) ?_ ?_ ?_
    (fun _ _ => rfl)
  · rintro ⟨ν, s⟩ ha
    rw [Finset.mem_product] at ha
    have hν : ν ≠ x.2 := Finset.ne_of_mem_erase ha.1
    unfold plaqsAt plaqs
    rw [Finset.mem_filter, Finset.mem_filter]
    by_cases hlt : x.2 < ν
    · cases s
      · simp only [dnT, if_pos hlt, Bool.false_eq_true, if_false]
        refine ⟨⟨Finset.mem_univ _, hlt⟩, ?_⟩
        simp [plaqLinks]
      · simp only [upT, if_pos hlt, if_true]
        refine ⟨⟨Finset.mem_univ _, hlt⟩, ?_⟩
        simp [plaqLinks]
    · have hgt : ν < x.2 := lt_of_le_of_ne (not_lt.1 hlt) hν
      cases s
      · simp only [dnT, if_neg hlt, Bool.false_eq_true, if_false]
        refine ⟨⟨Finset.mem_univ _, hgt⟩, ?_⟩
        simp [plaqLinks]
      · simp only [upT, if_neg hlt, if_true]
        refine ⟨⟨Finset.mem_univ _, hgt⟩, ?_⟩
        simp [plaqLinks]
  · rintro ⟨ν, s⟩ ha ⟨ν', s'⟩ ha' h
    rw [Finset.mem_product] at ha ha'
    have hν : ν ≠ x.2 := Finset.ne_of_mem_erase ha.1
    have hν' : ν' ≠ x.2 := Finset.ne_of_mem_erase ha'.1
    have hod : ∀ (t : Bool) (μ : Fin 4), μ ≠ x.2 →
        od N x (if t then upT N x μ else dnT N x μ) = μ := by
      intro t μ hμ
      cases t
      · exact od_dn N x μ hμ
      · exact od_up N x μ hμ
    have e1 : ν = ν' := by
      have h2 := congrArg (od N x) h
      simp only at h2
      rw [hod s ν hν, hod s' ν' hν'] at h2
      exact h2
    subst e1
    have hbase := congrArg (fun p : Lk N × Fin 4 => p.1.1) h
    simp only at hbase
    cases s <;> cases s'
    · rfl
    · simp only [Bool.false_eq_true, if_false, if_true, base_dn, base_up] at hbase
      exact absurd (sub_eq_self.1 hbase) (ev_ne_zero N hN ν)
    · simp only [Bool.false_eq_true, if_false, if_true, base_dn, base_up] at hbase
      exact absurd (sub_eq_self.1 hbase.symm) (ev_ne_zero N hN ν)
    · rfl
  · intro p hp
    unfold plaqsAt plaqs at hp
    rw [Finset.mem_filter, Finset.mem_filter] at hp
    obtain ⟨⟨-, hlt⟩, hx⟩ := hp
    obtain ⟨⟨y, a⟩, c⟩ := p
    simp only at hlt
    simp only [plaqLinks, Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with h | h | h | h
    · subst h
      refine ⟨(c, true), Finset.mem_product.2 ⟨Finset.mem_erase.2 ⟨ne_of_gt hlt,
        Finset.mem_univ _⟩, Finset.mem_univ _⟩, ?_⟩
      simp [upT, hlt]
    · subst h
      refine ⟨(a, false), Finset.mem_product.2 ⟨Finset.mem_erase.2 ⟨ne_of_lt hlt,
        Finset.mem_univ _⟩, Finset.mem_univ _⟩, ?_⟩
      simp [dnT, not_lt.2 hlt.le]
    · subst h
      refine ⟨(c, false), Finset.mem_product.2 ⟨Finset.mem_erase.2 ⟨ne_of_gt hlt,
        Finset.mem_univ _⟩, Finset.mem_univ _⟩, ?_⟩
      simp [dnT, hlt]
    · subst h
      refine ⟨(a, true), Finset.mem_product.2 ⟨Finset.mem_erase.2 ⟨ne_of_lt hlt,
        Finset.mem_univ _⟩, Finset.mem_univ _⟩, ?_⟩
      simp [upT, not_lt.2 hlt.le]

/-- the projection is injective on a box of side `< N` -/
theorem box_inj (R : ℕ) (hN : 2 * R < N) (m m' : ZLk) (hm : inBox R m) (hm' : inBox R m')
    (h : zproj N m = zproj N m') : m = m' := by
  have h2 : m.2 = m'.2 := congrArg (fun p : Lk N => p.2) h
  have h1 : m.1 = m'.1 := by
    funext i
    have hi : ((m.1 i : ℤ) : ZMod N) = ((m'.1 i : ℤ) : ZMod N) :=
      congrFun (congrArg Prod.fst h) i
    rw [ZMod.intCast_eq_intCast_iff_dvd_sub] at hi
    have a := abs_le.1 (hm i)
    have b := abs_le.1 (hm' i)
    have z := Int.eq_zero_of_abs_lt_dvd hi (by rw [abs_lt]; constructor <;> push_cast <;> omega)
    omega
  exact Prod.ext h1 h2

theorem lift_update_eq (ω : Lk N → QBall) (ℓ m : ZLk) (U : QBall)
    (hm : zproj N m = zproj N ℓ → m = ℓ) :
    perLift N (Function.update ω (zproj N ℓ) U) m = Function.update (perLift N ω) ℓ U m := by
  by_cases h : m = ℓ
  · subst h
    simp [perLift]
  · rw [Function.update_of_ne h]
    show Function.update ω (zproj N ℓ) U (zproj N m) = ω (zproj N m)
    rw [Function.update_of_ne (fun h' => h (hm h'))]

/-- **The torus local action of a box link is the ℤ⁴ local action of the lift.** -/
theorem locAct_lift (L : ℕ) (hN3 : 2 * (L + 1) < N) (β : ℝ) (ω : Lk N → QBall) (ℓ : ZLk)
    (hℓ : inBox L ℓ) (U : QBall) :
    locAct N β ω (zproj N ℓ) U = locActZ β (perLift N ω) ℓ U := by
  unfold locAct locActZ
  congr 1
  rw [sum_plaqsAt N (by omega) (zproj N ℓ)
    (fun p => (hol N (Function.update ω (zproj N ℓ) U) p).re)]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [up_proj, dn_proj, hol_lift, hol_lift,
    holZ_congr _ _ (upZ ℓ ν) (fun m hm => lift_update_eq N ω ℓ m U (fun h =>
      box_inj N (L + 1) hN3 m ℓ (links_up L ℓ hℓ ν m hm) (box_mono hℓ) h)),
    holZ_congr _ _ (dnZ ℓ ν) (fun m hm => lift_update_eq N ω ℓ m U (fun h =>
      box_inj N (L + 1) hN3 m ℓ (links_dn L ℓ hℓ ν m hm) (box_mono hℓ) h))]

/-- **The torus heat bath commutes with the lift inside the box.** -/
theorem heatBath_lift (L : ℕ) (hN3 : 2 * (L + 1) < N) (β : ℝ) (ℓ : ZLk) (hℓ : inBox L ℓ)
    (f : Cfg → ℝ) (hf : DepBox (L + 1) f) (ω : Lk N → QBall) :
    heatBath N β (zproj N ℓ) (fun ω => f (perLift N ω)) ω = hbZ β ℓ f (perLift N ω) := by
  unfold heatBath avg hbZ
  have e1 : ∀ U, f (perLift N (Function.update ω (zproj N ℓ) U))
      = f (Function.update (perLift N ω) ℓ U) := by
    intro U
    apply hf
    intro m hm
    exact lift_update_eq N ω ℓ m U (fun h => box_inj N (L + 1) hN3 m ℓ hm (box_mono hℓ) h)
  simp only [e1, locAct_lift N L hN3 β ω ℓ hℓ]

end Torus

theorem hbZ_dep (L : ℕ) (β : ℝ) (ℓ : ZLk) (hℓ : inBox L ℓ) (f : Cfg → ℝ) (hf : DepBox (L + 1) f) :
    DepBox (L + 1) (hbZ β ℓ f) := by
  intro ξ η h
  have hupd : ∀ U m, inBox (L + 1) m → Function.update ξ ℓ U m = Function.update η ℓ U m := by
    intro U m hm
    by_cases hmℓ : m = ℓ
    · subst hmℓ
      simp
    · rw [Function.update_of_ne hmℓ, Function.update_of_ne hmℓ]
      exact h m hm
  have e1 : ∀ U, f (Function.update ξ ℓ U) = f (Function.update η ℓ U) :=
    fun U => hf _ _ (hupd U)
  have e2 : ∀ U, locActZ β ξ ℓ U = locActZ β η ℓ U := by
    intro U
    unfold locActZ
    congr 1
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [holZ_congr _ _ _ (fun m hm => hupd U m (links_up L ℓ hℓ ν m hm)),
      holZ_congr _ _ _ (fun m hm => hupd U m (links_dn L ℓ hℓ ν m hm))]
  unfold hbZ
  simp only [e1, e2]

section Torus2

variable (N : ℕ) [NeZero N]

theorem sweep_lift (L : ℕ) (hN3 : 2 * (L + 1) < N) (β : ℝ) :
    ∀ (LZ : List ZLk), (∀ ℓ ∈ LZ, inBox L ℓ) → ∀ f : Cfg → ℝ, DepBox (L + 1) f →
      (hbSweep N β (LZ.map (zproj N)) (fun ω => f (perLift N ω))
          = fun ω => hbSweepZ β LZ f (perLift N ω)) ∧ DepBox (L + 1) (hbSweepZ β LZ f)
  | [], _, f, hf => ⟨rfl, hf⟩
  | ℓ :: LZ, hL, f, hf => by
    have hℓ := hL ℓ (List.mem_cons_self ..)
    have e : heatBath N β (zproj N ℓ) (fun ω => f (perLift N ω))
        = fun ω => hbZ β ℓ f (perLift N ω) := funext (heatBath_lift N L hN3 β ℓ hℓ f hf)
    obtain ⟨ih1, ih2⟩ := sweep_lift L hN3 β LZ (fun m hm => hL m (List.mem_cons_of_mem _ hm))
      (hbZ β ℓ f) (hbZ_dep L β ℓ hℓ f hf)
    refine ⟨?_, ih2⟩
    show hbSweep N β (LZ.map (zproj N)) (heatBath N β (zproj N ℓ) (fun ω => f (perLift N ω))) = _
    rw [e, ih1]
    rfl

/-- **`K` box sweeps on the torus are the `K` ℤ⁴ box sweeps composed with the lift.** -/
theorem iter_lift (L : ℕ) (hN3 : 2 * (L + 1) < N) (β : ℝ) (LZ : List ZLk)
    (hL : ∀ ℓ ∈ LZ, inBox L ℓ) :
    ∀ (K : ℕ) (f : Cfg → ℝ), DepBox (L + 1) f →
      ((hbSweep N β (LZ.map (zproj N)))^[K] (fun ω => f (perLift N ω))
          = fun ω => (hbSweepZ β LZ)^[K] f (perLift N ω)) ∧
        DepBox (L + 1) ((hbSweepZ β LZ)^[K] f)
  | 0, f, hf => ⟨rfl, hf⟩
  | K + 1, f, hf => by
    obtain ⟨e1, d1⟩ := sweep_lift N L hN3 β LZ hL f hf
    obtain ⟨e2, d2⟩ := iter_lift L hN3 β LZ hL K (hbSweepZ β LZ f) d1
    refine ⟨?_, ?_⟩
    · rw [Function.iterate_succ_apply, Function.iterate_succ_apply, e1, e2]
    · rw [Function.iterate_succ_apply]
      exact d2

end Torus2

end ZHeat

#print axioms ZHeat.sum_plaqsAt
#print axioms ZHeat.locAct_lift
#print axioms ZHeat.heatBath_lift
#print axioms ZHeat.iter_lift
