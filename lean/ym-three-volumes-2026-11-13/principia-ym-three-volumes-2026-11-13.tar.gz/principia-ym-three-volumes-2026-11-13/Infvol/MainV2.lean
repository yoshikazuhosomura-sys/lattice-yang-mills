import Infvol.FullTV2
import Infvol.TransV2

/-!
# The infinite-volume strong-coupling theorem in one statement


`InfMain.wilson_infvol_main` : for `0 < β` with `18 tanh β < 1`, there is exactly one `ν_β` to which
the whole sequence of periodic lifts (tori `(ℤ/2(n+1))⁴`, all `n`) converges weakly, and `ν_β` is
invariant under the four unit translations, reflection positive on `W`; the reconstruction on `W`
has the gap `-ln(18 tanh β)/2`, non-degeneracy and `T [F₀] = 0`; the reconstruction on `W_gi` has
the same gap, non-degeneracy and `T ≥ 0`; `T ≥ 0` also on all of `W`; clustering holds in the
four directions.
Formalisation of a known result (Dobrushin uniqueness, Osterwalder–Seiler strong coupling).
-/

namespace InfMain2

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ CenterFlip InfVol
open scoped BoundedContinuousFunction InnerProductSpace

theorem wilson_infvol_main2 (β : ℝ) (hβ : 0 < β) (hq : dobConst β < 1) :
    ∃! ν : ProbabilityMeasure Cfg,
      Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      (∀ (i : Fin 4) (F : Cfg →ᵇ ℝ),
        ∫ x, F (WilsonLimit.zShI i 1 x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg)) ∧
      (∀ F ∈ Wsub, 0 ≤ ∫ x, F (zRefl x) * F x ∂(ν : Measure Cfg)) ∧
      (∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
        (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
        D.T (D.emb ⟨F0, F0_mem⟩) = 0 ∧
        ∀ v : D.Hilb, 0 ≤ ⟪v, D.T v⟫_ℝ) ∧
      (∃ D : Datum Wgi,
        (∀ F G : Wgi, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
        (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
        ∀ v : D.Hilb, 0 ≤ ⟪v, D.T v⟫_ℝ) ∧
      (∀ (i : Fin 4) (F G : Cfg →ᵇ ℝ) (SF SG : Finset ZLk) (R : ℕ),
        (∀ ℓ ∈ SF, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) → (∀ ℓ ∈ SG, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) →
        (∀ x y : Cfg, (∀ ℓ ∈ SF, x ℓ = y ℓ) → F x = F y) →
        (∀ x y : Cfg, (∀ ℓ ∈ SG, x ℓ = y ℓ) → G x = G y) →
        ∀ k : ℕ, R ≤ k →
          |∫ x, F x * G (WilsonLimit.zShI i k x) ∂(ν : Measure Cfg)
              - (∫ x, F x ∂(ν : Measure Cfg)) * ∫ x, G (WilsonLimit.zShI i k x) ∂(ν : Measure Cfg)|
            ≤ 4 * ‖F‖ * ‖G‖ * SG.card
              * Real.exp (-((-Real.log (dobConst β) / 2) * ((k : ℝ) - R)))) := by
  obtain ⟨ν, hν, -, -, hrp, -, -, hcl⟩ := wilson_infvol β hβ.ne' hq
  obtain ⟨hl, hα⟩ := dob_rate β hβ.ne' hq
  have hid : Tendsto (fun n => liftProb β (id n)) atTop (𝓝 ν) := hν
  obtain ⟨D, hB, hτ, hone, hgap, hvar, hv, hpos⟩ :=
    FullT.wilson_Tpos_full β _ hβ.le hl hα ν id strictMono_id hid
  have hT : D.T (D.emb ⟨F0, F0_mem⟩) = 0 := by
    have hBG : ∀ G : Wsub, D.B G (D.τ ⟨F0, F0_mem⟩) = 0 := by
      intro G
      rw [hB, hτ]
      exact limit_zero β ν id strictMono_id hid G G.2
    rw [D.T_emb]
    have h0 := hBG (D.τ ⟨F0, F0_mem⟩)
    have h1 := D.norm_emb_sq (D.τ ⟨F0, F0_mem⟩)
    rw [h0] at h1
    exact norm_eq_zero.1 ((pow_eq_zero_iff two_ne_zero).1 h1)
  refine ⟨ν, ⟨hν, fun i F => TransI.limit_shiftI_invariant i β ν id hid F, hrp,
    ⟨D, hB, hτ, hone, hgap, hvar, hv, hT, hpos⟩,
    MidT.wilson_Tpos_gauge β _ hβ.le hl hα ν id strictMono_id hid, hcl⟩,
    fun ν' h' => tendsto_nhds_unique h'.1 hν⟩

end InfMain2

#print axioms InfMain2.wilson_infvol_main2
