import Infvol.RangeBV8

/-!
# The range of the transfer operator lies in the gauge-invariant sector (assembly)


* `GaugeRange.pair_avg` : `∫ K(θx) (avg_S F)(x) dν = ∫ K(θx) F(x) dν` when the gauge
  transformations on `S` do not touch `K ∘ θ`.
* `GaugeRange.T_emb_gauge` : at every weak limit point, `T [F] = ι [G]` with `G ∈ W_gi`
  (the average of `τ F` over the gauge transformations at the end points of its links).
-/

namespace GaugeRange

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge ZHeat InfVol
open scoped BoundedContinuousFunction InnerProductSpace

theorem hgc_of (S : Finset ZSite) (g : S → SU2) : Continuous (fun x => gaugeAct (gext S g) x) := by
  refine continuous_pi fun ℓ => ?_
  show Continuous fun x : Cfg => gq (gext S g ℓ.1) (gext S g (ℓ.1 + zev ℓ.2)) (x ℓ)
  exact continuous_gq' continuous_const continuous_const (continuous_apply ℓ)

/-- **Fubini with the gauge average.** -/
theorem pair_avg (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (S : Finset ZSite)
    (K F : Cfg →ᵇ ℝ) (hK : ∀ (g : S → SU2) x, K (zRefl (gaugeAct (gext S g) x)) = K (zRefl x))
    (T : Finset ZLk)
    (hT : ∀ x y : Cfg, (∀ ℓ ∈ T, x ℓ = y ℓ) → K (zRefl x) * F x = K (zRefl y) * F y) :
    ∫ x, K (zRefl x) * avgZ S F x ∂(ν : Measure Cfg) = ∫ x, K (zRefl x) * F x ∂(ν : Measure Cfg) := by
  set Hb : Cfg →ᵇ ℝ := K.compContinuous zReflC * F with hHb
  have hHb_apply : ∀ x, Hb x = K (zRefl x) * F x := fun x => rfl
  have hTb : ∀ x y : Cfg, (∀ ℓ ∈ T, x ℓ = y ℓ) → Hb x = Hb y := fun x y h => by
    rw [hHb_apply, hHb_apply]; exact hT x y h
  have hcomp : ∀ (g : S → SU2) x,
      (Hb.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc_of S g⟩) x
        = K (zRefl x) * F (gaugeAct (gext S g) x) := by
    intro g x
    rw [BoundedContinuousFunction.compContinuous_apply, ContinuousMap.coe_mk, hHb_apply, hK]
  have hjc : Continuous (fun p : Cfg × (S → SU2) => K (zRefl p.1) * F (gaugeAct (gext S p.2) p.1)) :=
    (K.continuous.comp (continuous_zRefl.comp continuous_fst)).mul
      (F.continuous.comp (continuous_gaugeAct_gext S))
  have hint : Integrable (Function.uncurry fun (x : Cfg) (g : S → SU2) =>
      K (zRefl x) * F (gaugeAct (gext S g) x)) ((ν : Measure Cfg).prod (hS S)) := by
    refine Integrable.of_bound hjc.aestronglyMeasurable (‖K‖ * ‖F‖) (Eventually.of_forall fun p => ?_)
    rw [Real.norm_eq_abs]
    show |K (zRefl p.1) * F (gaugeAct (gext S p.2) p.1)| ≤ ‖K‖ * ‖F‖
    rw [abs_mul]
    exact mul_le_mul (abs_le_norm' K _) (abs_le_norm' F _) (abs_nonneg _) (norm_nonneg _)
  have e1 : ∀ x, K (zRefl x) * avgZ S F x = ∫ g, K (zRefl x) * F (gaugeAct (gext S g) x) ∂(hS S) := by
    intro x
    unfold avgZ
    rw [integral_const_mul]
  rw [integral_congr_ae (Eventually.of_forall e1), integral_integral_swap hint]
  have e2 : ∀ g : S → SU2, ∫ x, K (zRefl x) * F (gaugeAct (gext S g) x) ∂(ν : Measure Cfg)
      = ∫ x, K (zRefl x) * F x ∂(ν : Measure Cfg) := by
    intro g
    have h := limit_gauge_inv β ν φ hφ hlim S g Hb T hTb (hgc_of S g)
    simp only [hcomp, hHb_apply] at h
    exact h
  rw [integral_congr_ae (Eventually.of_forall e2), integral_const]
  simp

end GaugeRange

#print axioms GaugeRange.pair_avg
