import Infvol.CauchyV2

/-!
# Invariance of the infinite-volume limit under the four lattice translations

Paper correspondence: translations.
* `TransI.wilson_shiftI_invariant` : the Wilson measure on `(ℤ/N)⁴` is invariant under the unit
  translation in each direction `i` (the time direction is `wilson_shift_invariant`).
* `TransI.limit_shiftI_invariant` : every weak limit point of the periodic lifts is invariant under
  the unit translation `zShI i 1` of ℤ⁴, for each of the four directions.
* `TransI.wilson_infvol_translation` : the limit `ν_β` of the whole sequence is invariant under all
  four unit translations (hence under all translations by iteration).
-/

namespace TransI

open MeasureTheory Filter Topology TorusRP LinkReflection WilsonLimit LinkSpec InfVol
open scoped BoundedContinuousFunction

section Torus

variable (N : ℕ) [NeZero N]

/-- translation of a torus link by `e_i` -/
def shI (i : Fin 4) (ℓ : Lk N) : Lk N := (ℓ.1 + ev N i, ℓ.2)

def shEquivI (i : Fin 4) : Lk N ≃ Lk N where
  toFun ℓ := (ℓ.1 - ev N i, ℓ.2)
  invFun := shI N i
  left_inv ℓ := by simp [shI]
  right_inv ℓ := by simp [shI]

/-- the translated configuration `(S_i ω)_ℓ = ω_{ℓ + e_i}` -/
def sShift (i : Fin 4) (ω : Lk N → QBall) : Lk N → QBall := fun ℓ => ω (shI N i ℓ)

theorem sShift_preserving (i : Fin 4) :
    MeasurePreserving (sShift N i) (Measure.pi fun _ : Lk N => haarBall)
      (Measure.pi fun _ : Lk N => haarBall) := by
  have hre := measurePreserving_piCongrLeft (fun _ : Lk N => haarBall) (shEquivI N i)
  convert hre using 1
  funext ω
  funext ℓ
  rw [LinkReflection.piCongrLeft_const]
  rfl

theorem hol_sShift (i : Fin 4) (ω : Lk N → QBall) (p : Lk N × Fin 4) :
    hol N (sShift N i ω) p = hol N ω ((p.1.1 + ev N i, p.1.2), p.2) := by
  simp only [hol, holQ, Uq, sShift, shI]
  rw [add_right_comm p.1.1 (ev N p.1.2) (ev N i), add_right_comm p.1.1 (ev N p.2) (ev N i)]

theorem action_sShift (i : Fin 4) (ω : Lk N → QBall) : action N (sShift N i ω) = action N ω := by
  unfold action
  simp_rw [hol_sShift]
  apply Finset.sum_nbij' (fun p => ((p.1.1 + ev N i, p.1.2), p.2))
    (fun p => ((p.1.1 - ev N i, p.1.2), p.2))
  · intro p hp; simpa [plaqs] using hp
  · intro p hp; simpa [plaqs] using hp
  · intro p _; simp
  · intro p _; simp
  · intro p _; rfl

theorem wilsonWeight_sShift (i : Fin 4) (β : ℝ) (ω : Lk N → QBall) :
    wilsonWeight N β (sShift N i ω) = wilsonWeight N β ω := by
  unfold wilsonWeight; rw [action_sShift]

/-- **Translation invariance of the Wilson measure in each direction.** -/
theorem wilson_shiftI_invariant (i : Fin 4) (β : ℝ) (f : (Lk N → QBall) → ℝ) (hf : Measurable f) :
    ∫ ω, f (sShift N i ω) ∂(wilsonMeasure N β) = ∫ ω, f ω ∂(wilsonMeasure N β) := by
  have hWm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω)) :=
    (continuous_wilsonWeight N β).measurable.real_toNNReal
  have hP := sShift_preserving N i
  rw [wilsonMeasure, integral_withDensity_eq_integral_smul hWm,
    integral_withDensity_eq_integral_smul hWm]
  have hm : Measurable (fun ω => Real.toNNReal (wilsonWeight N β ω) • f ω) := hWm.smul hf
  conv_rhs => rw [← hP.map_eq]
  rw [integral_map hP.measurable.aemeasurable hm.aestronglyMeasurable]
  congr 1
  funext ω
  rw [wilsonWeight_sShift]

theorem zShI_lift (i : Fin 4) (ω : Lk N → QBall) :
    WilsonLimit.zShI i 1 (perLift N ω) = perLift N (sShift N i ω) := by
  funext ℓ
  show ω (zproj N (WilsonLimit.zshI i 1 ℓ)) = ω (shI N i (zproj N ℓ))
  congr 1
  refine Prod.ext (funext fun j => ?_) rfl
  simp only [WilsonLimit.zshI, shI, zproj, ev, Pi.add_apply, Pi.single_apply]
  split_ifs <;> push_cast <;> ring

end Torus

theorem lift_shiftI_invariant (i : Fin 4) (β : ℝ) (n : ℕ) (F : Cfg →ᵇ ℝ) :
    ∫ x, F (WilsonLimit.zShI i 1 x) ∂(liftProb β n : Measure Cfg)
      = ∫ x, F x ∂(liftProb β n : Measure Cfg) := by
  rw [integral_lift β n (fun x => F (WilsonLimit.zShI i 1 x))
      (F.continuous.comp (WilsonLimit.continuous_zShI i 1)),
    integral_lift β n (fun x => F x) F.continuous]
  simp only [zShI_lift]
  rw [wilsonProb_toMeasure, integral_smul_measure, integral_smul_measure,
    wilson_shiftI_invariant (Nn n) i β (fun ω => F (perLift (Nn n) ω))
      ((F.continuous.comp (continuous_perLift _)).measurable)]

theorem limit_shiftI_invariant (i : Fin 4) (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (F : Cfg →ᵇ ℝ) :
    ∫ x, F (WilsonLimit.zShI i 1 x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg) := by
  have h := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim
  have h1 : Tendsto (fun n => ∫ x, F (WilsonLimit.zShI i 1 x) ∂(liftProb β (φ n) : Measure Cfg)) atTop
      (𝓝 (∫ x, F (WilsonLimit.zShI i 1 x) ∂(ν : Measure Cfg))) :=
    h (F.compContinuous ⟨WilsonLimit.zShI i 1, WilsonLimit.continuous_zShI i 1⟩)
  exact tendsto_nhds_unique h1 ((h F).congr fun n => (lift_shiftI_invariant i β (φ n) F).symm)

/-- **The limit of the whole sequence is invariant under the four unit translations.** -/
theorem wilson_infvol_translation (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃! ν : ProbabilityMeasure Cfg, Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      ∀ (i : Fin 4) (F : Cfg →ᵇ ℝ),
        ∫ x, F (WilsonLimit.zShI i 1 x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg) := by
  obtain ⟨ν, hν, huniq⟩ := wilson_infvol_unique β hβ0 hq
  refine ⟨ν, ⟨hν, fun i F => limit_shiftI_invariant i β ν id hν F⟩, fun ν' h' => huniq ν' h'.1⟩

end TransI

#print axioms TransI.wilson_shiftI_invariant
#print axioms TransI.limit_shiftI_invariant
#print axioms TransI.wilson_infvol_translation
