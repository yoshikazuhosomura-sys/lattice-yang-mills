import Infvol.CauchyV2

/-!
# The limit does not depend on the sizes of the tori

Paper correspondence: sizes.
* `AllN.liftS β m` : the periodic lift of the normalised Wilson measure on `(ℤ/(m+1))⁴`
  (every size, odd or even).
* `AllN.lift_closeS` : the estimate of `InfVol.lift_close` for every size `m + 1 > 2(L_b + 1)`,
  with the same number `c_{K,L_b}` (the ℤ⁴ box-sweep value).
* `AllN.wilson_infvol_allN` : the sequence over all sizes converges weakly to the same `ν_β` as the
  even sizes; hence for every sequence of sizes tending to infinity.
-/

namespace AllN

open MeasureTheory Filter Topology TorusRP LinkSpec WilsonLimit ZHeat CylDet Finset InfVol
open scoped BoundedContinuousFunction

/-- the periodic lift of the Wilson measure on the torus of size `m + 1` -/
noncomputable def liftS (β : ℝ) (m : ℕ) : ProbabilityMeasure Cfg :=
  (wilsonProb (m + 1) β).map (measurable_perLift (m + 1)).aemeasurable

theorem integral_liftS (β : ℝ) (m : ℕ) (g : Cfg → ℝ) (hg : Continuous g) :
    ∫ x, g x ∂(liftS β m : Measure Cfg)
      = ∫ ω, g (perLift (m + 1) ω) ∂(wilsonProb (m + 1) β : Measure (Lk (m + 1) → QBall)) := by
  rw [liftS, ProbabilityMeasure.toMeasure_map,
    integral_map (measurable_perLift _).aemeasurable hg.aestronglyMeasurable]

/-- **Each large torus is close to the ℤ⁴ box-sweep value.** -/
theorem lift_closeS (β lam : ℝ) (hβ0 : β ≠ 0) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * dobConst β ≤ 1)
    (F : Cfg →ᵇ ℝ) (S : Finset ZLk) (hS : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y)
    (R0 : ℕ) (hR0 : ∀ m ∈ S, inBox R0 m) (Lb : ℕ) (hLb : R0 ≤ Lb) (K m₀ : ℕ)
    (hm₀ : 2 * (Lb + 1) < m₀ + 1) :
    |∫ x, F x ∂(liftS β m₀ : Measure Cfg)
        - (hbSweepZ β (boxFin Lb).toList)^[K] F (fun _ => q0)|
      ≤ ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))))
          * (2 * ‖F‖ * S.card * Real.exp (lam * R0)) := by
  have hN3 : 2 * (Lb + 1) < m₀ + 1 := hm₀
  have hN2 : 2 * Lb < m₀ + 1 := by omega
  have hLZ : ∀ ℓ ∈ (boxFin Lb).toList, inBox Lb ℓ :=
    fun ℓ h => (mem_boxFin Lb ℓ).1 (Finset.mem_toList.1 h)
  have hnd : ((boxFin Lb).toList.map (zproj (m₀ + 1))).Nodup :=
    List.Nodup.map_on (fun a ha b hb h => box_inj (m₀ + 1) Lb hN2 a b (hLZ a ha) (hLZ b hb) h)
      (Finset.nodup_toList _)
  have hdep : DepBox (Lb + 1) F := fun ξ η h => hS ξ η (fun m hm =>
    h m (box_mono (fun i => (hR0 m hm i).trans (by exact_mod_cast hLb))))
  obtain ⟨hit, -⟩ := iter_lift (m₀ + 1) Lb hN3 β (boxFin Lb).toList hLZ K F hdep
  have hδ : ∀ y : Lk (m₀ + 1), 0 ≤ (if y ∈ S.image (zproj (m₀ + 1)) then 2 * ‖F‖ else 0) := fun y => by
    split_ifs
    · positivity
    · exact le_rfl
  have hosc : ∀ y, ∀ ω ω' : Lk (m₀ + 1) → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
      |F (perLift (m₀ + 1) ω) - F (perLift (m₀ + 1) ω')|
        ≤ (if y ∈ S.image (zproj (m₀ + 1)) then 2 * ‖F‖ else 0) := by
    intro y ω ω' h
    split_ifs with hy
    · exact (abs_sub _ _).trans
        (by linarith [abs_le_norm' F (perLift (m₀ + 1) ω), abs_le_norm' F (perLift (m₀ + 1) ω')])
    · rw [hS (perLift (m₀ + 1) ω) (perLift (m₀ + 1) ω')
        (fun m hm => h _ (fun he => hy (Finset.mem_image.2 ⟨m, hm, he⟩))), sub_self, abs_zero]
  have hmeas : Measurable (fun ω : Lk (m₀ + 1) → QBall => F (perLift (m₀ + 1) ω)) :=
    (F.continuous.comp (continuous_perLift _)).measurable
  have hb := torus_box (m₀ + 1) β lam hβ0 hlam hα (fun ω => F (perLift (m₀ + 1) ω)) hmeas ‖F‖
    (fun ω => abs_le_norm' F _) _ hδ hosc _ ((boxFin Lb).toList.map (zproj (m₀ + 1))) hnd rfl Lb
    (fun y hy => by
      by_contra hcon
      exact hy (box_cover (m₀ + 1) Lb y (by omega))) K (fun _ => q0)
  rw [hit] at hb
  have hT : ∑ y, Real.exp (lam * dmax (m₀ + 1) y)
        * (if y ∈ S.image (zproj (m₀ + 1)) then 2 * ‖F‖ else 0)
      ≤ 2 * ‖F‖ * S.card * Real.exp (lam * R0) := by
    have e : ∀ y : Lk (m₀ + 1), Real.exp (lam * dmax (m₀ + 1) y)
          * (if y ∈ S.image (zproj (m₀ + 1)) then 2 * ‖F‖ else 0)
        = if y ∈ S.image (zproj (m₀ + 1)) then Real.exp (lam * dmax (m₀ + 1) y) * (2 * ‖F‖) else 0 :=
      fun y => by split_ifs <;> ring
    rw [Finset.sum_congr rfl (fun y _ => e y), Fintype.sum_ite_mem]
    calc ∑ y ∈ S.image (zproj (m₀ + 1)), Real.exp (lam * dmax (m₀ + 1) y) * (2 * ‖F‖)
        ≤ ∑ y ∈ S.image (zproj (m₀ + 1)), Real.exp (lam * R0) * (2 * ‖F‖) := by
          apply Finset.sum_le_sum
          intro y hy
          obtain ⟨m, hm, rfl⟩ := Finset.mem_image.1 hy
          have h1 := dmax_proj_le (m₀ + 1) R0 m (hR0 m hm)
          have h' : (dmax (m₀ + 1) (zproj (m₀ + 1) m) : ℝ) ≤ R0 := by exact_mod_cast h1
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact Real.exp_le_exp.2 (mul_le_mul_of_nonneg_left h' hlam)
      _ = (S.image (zproj (m₀ + 1))).card * (Real.exp (lam * R0) * (2 * ‖F‖)) := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ S.card * (Real.exp (lam * R0) * (2 * ‖F‖)) := by
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact_mod_cast Finset.card_image_le
      _ = 2 * ‖F‖ * S.card * Real.exp (lam * R0) := by ring
  have hfac : 0 ≤ (Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))) :=
    add_nonneg (pow_nonneg (mul_nonneg (Real.exp_pos _).le (dobConst_pos β hβ0).le) K)
      (Real.exp_pos _).le
  rw [integral_liftS β m₀ F F.continuous]
  exact hb.trans (mul_le_mul_of_nonneg_left hT hfac)


/-- two real sequences that are eventually within `ε` of common numbers have the same limit -/
theorem same_limit (a b : ℕ → ℝ) (A B : ℝ) (ha : Tendsto a atTop (𝓝 A))
    (hb : Tendsto b atTop (𝓝 B))
    (h : ∀ ε > 0, ∃ c : ℝ, (∀ᶠ n in atTop, |a n - c| ≤ ε) ∧ (∀ᶠ n in atTop, |b n - c| ≤ ε)) :
    A = B := by
  refine eq_of_forall_dist_le fun ε hε => ?_
  obtain ⟨c, h1, h2⟩ := h (ε / 2) (by positivity)
  have hA : |A - c| ≤ ε / 2 :=
    le_of_tendsto ((continuous_abs.comp (continuous_id.sub continuous_const)).continuousAt.tendsto.comp ha) h1
  have hB : |B - c| ≤ ε / 2 :=
    le_of_tendsto ((continuous_abs.comp (continuous_id.sub continuous_const)).continuousAt.tendsto.comp hb) h2
  rw [Real.dist_eq]
  calc |A - B| ≤ |A - c| + |c - B| := abs_sub_le _ _ _
    _ = |A - c| + |B - c| := by rw [abs_sub_comm c B]
    _ ≤ ε := by linarith

/-- for every cylinder `F` and `ε > 0`, one number `c` that both sequences eventually approach -/
theorem common_value (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) (F : Cfg →ᵇ ℝ) (hF : IsCyl F)
    (ε : ℝ) (hε : 0 < ε) : ∃ c : ℝ,
      (∀ᶠ n in atTop, |∫ x, F x ∂(liftProb β n : Measure Cfg) - c| ≤ ε) ∧
      (∀ᶠ m in atTop, |∫ x, F x ∂(liftS β m : Measure Cfg) - c| ≤ ε) := by
  obtain ⟨S, hS⟩ := hF
  obtain ⟨R0, hR0⟩ := cyl_box S
  obtain ⟨hl, hα⟩ := dob_rate β hβ0 hq
  set lam := -Real.log (dobConst β) / 2 with hlamdef
  set Cst := 2 * ‖F‖ * S.card * Real.exp (lam * R0) with hCst
  have hC : 0 ≤ Cst := by positivity
  have hη : 0 < ε / (2 * (Cst + 1)) := by positivity
  obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hη hα
  have he1 : Real.exp (-lam) < 1 := by
    rw [← Real.exp_zero]
    exact Real.exp_lt_exp.2 (by linarith)
  obtain ⟨j, hj⟩ := exists_pow_lt_of_lt_one hη he1
  have hbound : ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * ((max R0 j : ℕ) + 1)))) * Cst
      ≤ ε := by
    have h2 : Real.exp (-(lam * ((max R0 j : ℕ) + 1))) ≤ Real.exp (-lam) ^ j := by
      rw [← Real.exp_nat_mul]
      apply Real.exp_le_exp.2
      have hj' : j ≤ max R0 j + 1 := by have := le_max_right R0 j; omega
      have : (j : ℝ) ≤ ((max R0 j : ℕ) : ℝ) + 1 := by exact_mod_cast hj'
      nlinarith
    have h3 : ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * ((max R0 j : ℕ) + 1)))) * Cst
        ≤ (ε / (2 * (Cst + 1)) + ε / (2 * (Cst + 1))) * Cst :=
      mul_le_mul_of_nonneg_right (add_le_add hK.le (h2.trans hj.le)) hC
    have h4 : (ε / (2 * (Cst + 1)) + ε / (2 * (Cst + 1))) * Cst = ε * (Cst / (Cst + 1)) := by
      field_simp
      ring
    have h5 : Cst / (Cst + 1) ≤ 1 := (div_le_one (by linarith)).2 (by linarith)
    have h6 : ε * (Cst / (Cst + 1)) ≤ ε := mul_le_of_le_one_right hε.le h5
    linarith
  refine ⟨(hbSweepZ β (boxFin (max R0 j)).toList)^[K] F (fun _ => q0), ?_, ?_⟩
  · filter_upwards [eventually_ge_atTop (max R0 j + 1)] with n hn
    exact (lift_close β lam hβ0 hl.le hα.le F S hS R0 hR0 (max R0 j) (le_max_left _ _) K n hn).trans
      hbound
  · filter_upwards [eventually_ge_atTop (2 * (max R0 j + 1))] with m hm
    exact (lift_closeS β lam hβ0 hl.le hα.le F S hS R0 hR0 (max R0 j) (le_max_left _ _) K m
      (by omega)).trans hbound

/-- **Every size: the lifts on `(ℤ/(m+1))⁴` converge to the same `ν_β` as the even sizes.** -/
theorem wilson_infvol_allN (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃ ν : ProbabilityMeasure Cfg, Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      Tendsto (fun m => liftS β m) atTop (𝓝 ν) ∧
      ∀ (s : ℕ → ℕ), Tendsto s atTop atTop → Tendsto (fun k => liftS β (s k)) atTop (𝓝 ν) := by
  have hcS : ∀ F : Cfg →ᵇ ℝ, IsCyl F →
      CauchySeq (fun m => ∫ x, F x ∂(liftS β m : Measure Cfg)) := by
    intro F hF
    rw [Metric.cauchySeq_iff]
    intro ε hε
    obtain ⟨c, -, h2⟩ := common_value β hβ0 hq F hF (ε / 3) (by positivity)
    obtain ⟨M0, hM0⟩ := eventually_atTop.1 h2
    refine ⟨M0, fun m hm m' hm' => ?_⟩
    rw [Real.dist_eq]
    have a := hM0 m hm
    have b := hM0 m' hm'
    rw [abs_sub_comm] at b
    calc _ ≤ _ := abs_sub_le _ c _
      _ < ε := by linarith
  obtain ⟨ν, hν⟩ := tendsto_of_cyl_cauchy (fun n => liftProb β n) (fun F hF => cauchy_cyl β hβ0 hq F hF)
  obtain ⟨ν', hν'⟩ := tendsto_of_cyl_cauchy (fun m => liftS β m) hcS
  have e : ν' = ν := by
    refine ProbabilityMeasure.toMeasure_injective (ext_of_cyl _ _ fun F hF => ?_)
    have t1 := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hν F
    have t2 := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hν' F
    exact (same_limit _ _ _ _ t1 t2 (fun ε hε => common_value β hβ0 hq F hF ε hε)).symm
  rw [e] at hν'
  exact ⟨ν, hν, hν', fun s hs => hν'.comp hs⟩

end AllN

#print axioms AllN.lift_closeS
#print axioms AllN.wilson_infvol_allN
