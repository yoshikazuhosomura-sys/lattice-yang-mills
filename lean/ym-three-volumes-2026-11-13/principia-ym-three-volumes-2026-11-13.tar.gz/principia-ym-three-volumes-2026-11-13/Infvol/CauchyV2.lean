import Infvol.ZHeatV2
import Infvol.LimitV2

/-!
# Step (a): the integrals of every cylinder function form a Cauchy sequence in the volume

Paper correspondence: –(d).
* `InfVol.lift_close` : for a cylinder function `F` (support in the box `R₀`), a box `L_b ≥ R₀` and
  `K` sweeps, every torus `(ℤ/2(n+1))⁴` with `n ≥ L_b + 1` has
  `|E_n F - c_{K,L_b}| ≤ (α^K + e^{-λ(L_b+1)}) · 2‖F‖ |S| e^{λ R₀}`, where `c_{K,L_b}` is the value of
  the `K` ℤ⁴ box sweeps of `F` at the constant configuration (the same number for every `n`).
* `InfVol.cauchy_cyl` : in the window `18 tanh|β| < 1`, `β ≠ 0`, `n ↦ ∫ F d(liftProb β n)` is
  Cauchy for every cylinder function `F`.
* `InfVol.wilson_infvol_unique` : `∃! ν_β`, the whole sequence `liftProb β n` (all `n`) converges
  weakly to `ν_β`.
* `InfVol.wilson_infvol` : the statement of `wilson_infvol_of_cauchy` without its hypothesis.
-/

namespace InfVol

open MeasureTheory Filter Topology TorusRP LinkSpec WilsonLimit ZHeat CylDet Finset
open OSGap GaugeZ CenterFlip LinkReflection OrbitGrowth SwapDecay
open scoped BoundedContinuousFunction InnerProductSpace

/-- the point `0` of the ball (any fixed value would do) -/
noncomputable def q0 : QBall := ⟨0, by simp⟩

/-- the links of the box `|m_i| ≤ L_b` -/
noncomputable def boxFin (Lb : ℕ) : Finset ZLk :=
  (Fintype.piFinset fun _ : Fin 4 => Finset.Icc (-(Lb : ℤ)) Lb) ×ˢ (univ : Finset (Fin 4))

theorem mem_boxFin (Lb : ℕ) (m : ZLk) : m ∈ boxFin Lb ↔ inBox Lb m := by
  unfold boxFin inBox
  rw [Finset.mem_product, Fintype.mem_piFinset]
  simp only [Finset.mem_Icc, Finset.mem_univ, and_true, abs_le]

theorem cyl_box (S : Finset ZLk) : ∃ R0 : ℕ, ∀ m ∈ S, inBox R0 m := by
  refine ⟨S.sup (fun m => univ.sup (fun i => (m.1 i).natAbs)), fun m hm i => ?_⟩
  have h1 : (m.1 i).natAbs ≤ univ.sup (fun i => (m.1 i).natAbs) :=
    Finset.le_sup (f := fun i => (m.1 i).natAbs) (mem_univ i)
  have h2 : univ.sup (fun i => (m.1 i).natAbs)
      ≤ S.sup (fun m => univ.sup (fun i => (m.1 i).natAbs)) :=
    Finset.le_sup (f := fun m => univ.sup (fun i => (m.1 i).natAbs)) hm
  rw [Int.abs_eq_natAbs]
  exact_mod_cast h1.trans h2

theorem dmax_proj_le (N : ℕ) [NeZero N] (R : ℕ) (m : ZLk) (hm : inBox R m) :
    dmax N (zproj N m) ≤ R := by
  unfold dmax
  apply Finset.sup_le
  intro i _
  show cdist N (((m.1 i : ℤ) : ZMod N) - 0) ≤ R
  rw [sub_zero]
  have h := cdist_intCast_le N (m.1 i)
  have h2 : |m.1 i| ≤ R := hm i
  rw [Int.abs_eq_natAbs] at h2
  have h3 : (m.1 i).natAbs ≤ R := by exact_mod_cast h2
  omega

theorem box_cover (N : ℕ) [NeZero N] (Lb : ℕ) (y : Lk N) (hy : dmax N y ≤ Lb) :
    y ∈ ((boxFin Lb).toList.map (zproj N)).toFinset := by
  rw [List.mem_toFinset, List.mem_map]
  refine ⟨(fun i => (y.1 i).valMinAbs, y.2), ?_, ?_⟩
  · rw [Finset.mem_toList, mem_boxFin]
    intro i
    have h1 : cdistI N i 0 y ≤ dmax N y := Finset.le_sup (f := fun i => cdistI N i 0 y) (mem_univ i)
    have h2 : cdistI N i 0 y = (y.1 i).valMinAbs.natAbs := by simp [cdistI, cdist]
    show |(y.1 i).valMinAbs| ≤ Lb
    rw [Int.abs_eq_natAbs]
    have : (y.1 i).valMinAbs.natAbs ≤ Lb := by omega
    exact_mod_cast this
  · refine Prod.ext (funext fun i => ?_) rfl
    show (((y.1 i).valMinAbs : ℤ) : ZMod N) = y.1 i
    exact ZMod.coe_valMinAbs _

/-- **Each large torus is close to the ℤ⁴ box-sweep value.** -/
theorem lift_close (β lam : ℝ) (hβ0 : β ≠ 0) (hlam : 0 ≤ lam)
    (hα : Real.exp lam * dobConst β ≤ 1)
    (F : Cfg →ᵇ ℝ) (S : Finset ZLk) (hS : ∀ x y : Cfg, (∀ ℓ ∈ S, x ℓ = y ℓ) → F x = F y)
    (R0 : ℕ) (hR0 : ∀ m ∈ S, inBox R0 m) (Lb : ℕ) (hLb : R0 ≤ Lb) (K n : ℕ) (hn : Lb + 1 ≤ n) :
    |∫ x, F x ∂(liftProb β n : Measure Cfg)
        - (hbSweepZ β (boxFin Lb).toList)^[K] F (fun _ => q0)|
      ≤ ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))))
          * (2 * ‖F‖ * S.card * Real.exp (lam * R0)) := by
  have hN3 : 2 * (Lb + 1) < Nn n := by unfold Nn; omega
  have hN2 : 2 * Lb < Nn n := by omega
  have hLZ : ∀ ℓ ∈ (boxFin Lb).toList, inBox Lb ℓ :=
    fun ℓ h => (mem_boxFin Lb ℓ).1 (Finset.mem_toList.1 h)
  have hnd : ((boxFin Lb).toList.map (zproj (Nn n))).Nodup :=
    List.Nodup.map_on (fun a ha b hb h => box_inj (Nn n) Lb hN2 a b (hLZ a ha) (hLZ b hb) h)
      (Finset.nodup_toList _)
  have hdep : DepBox (Lb + 1) F := fun ξ η h => hS ξ η (fun m hm =>
    h m (box_mono (fun i => (hR0 m hm i).trans (by exact_mod_cast hLb))))
  obtain ⟨hit, -⟩ := iter_lift (Nn n) Lb hN3 β (boxFin Lb).toList hLZ K F hdep
  have hδ : ∀ y : Lk (Nn n), 0 ≤ (if y ∈ S.image (zproj (Nn n)) then 2 * ‖F‖ else 0) := fun y => by
    split_ifs
    · positivity
    · exact le_rfl
  have hosc : ∀ y, ∀ ω ω' : Lk (Nn n) → QBall, (∀ ℓ, ℓ ≠ y → ω ℓ = ω' ℓ) →
      |F (perLift (Nn n) ω) - F (perLift (Nn n) ω')|
        ≤ (if y ∈ S.image (zproj (Nn n)) then 2 * ‖F‖ else 0) := by
    intro y ω ω' h
    split_ifs with hy
    · exact (abs_sub _ _).trans
        (by linarith [abs_le_norm' F (perLift (Nn n) ω), abs_le_norm' F (perLift (Nn n) ω')])
    · rw [hS (perLift (Nn n) ω) (perLift (Nn n) ω')
        (fun m hm => h _ (fun he => hy (Finset.mem_image.2 ⟨m, hm, he⟩))), sub_self, abs_zero]
  have hmeas : Measurable (fun ω : Lk (Nn n) → QBall => F (perLift (Nn n) ω)) :=
    (F.continuous.comp (continuous_perLift _)).measurable
  have hb := torus_box (Nn n) β lam hβ0 hlam hα (fun ω => F (perLift (Nn n) ω)) hmeas ‖F‖
    (fun ω => abs_le_norm' F _) _ hδ hosc _ ((boxFin Lb).toList.map (zproj (Nn n))) hnd rfl Lb
    (fun y hy => by
      by_contra hcon
      exact hy (box_cover (Nn n) Lb y (by omega))) K (fun _ => q0)
  rw [hit] at hb
  have hT : ∑ y, Real.exp (lam * dmax (Nn n) y)
        * (if y ∈ S.image (zproj (Nn n)) then 2 * ‖F‖ else 0)
      ≤ 2 * ‖F‖ * S.card * Real.exp (lam * R0) := by
    have e : ∀ y : Lk (Nn n), Real.exp (lam * dmax (Nn n) y)
          * (if y ∈ S.image (zproj (Nn n)) then 2 * ‖F‖ else 0)
        = if y ∈ S.image (zproj (Nn n)) then Real.exp (lam * dmax (Nn n) y) * (2 * ‖F‖) else 0 :=
      fun y => by split_ifs <;> ring
    rw [Finset.sum_congr rfl (fun y _ => e y), Fintype.sum_ite_mem]
    calc ∑ y ∈ S.image (zproj (Nn n)), Real.exp (lam * dmax (Nn n) y) * (2 * ‖F‖)
        ≤ ∑ y ∈ S.image (zproj (Nn n)), Real.exp (lam * R0) * (2 * ‖F‖) := by
          apply Finset.sum_le_sum
          intro y hy
          obtain ⟨m, hm, rfl⟩ := Finset.mem_image.1 hy
          have h1 := dmax_proj_le (Nn n) R0 m (hR0 m hm)
          have h' : (dmax (Nn n) (zproj (Nn n) m) : ℝ) ≤ R0 := by exact_mod_cast h1
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact Real.exp_le_exp.2 (mul_le_mul_of_nonneg_left h' hlam)
      _ = (S.image (zproj (Nn n))).card * (Real.exp (lam * R0) * (2 * ‖F‖)) := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ S.card * (Real.exp (lam * R0) * (2 * ‖F‖)) := by
          apply mul_le_mul_of_nonneg_right _ (by positivity)
          exact_mod_cast Finset.card_image_le
      _ = 2 * ‖F‖ * S.card * Real.exp (lam * R0) := by ring
  have hfac : 0 ≤ (Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * (Lb + 1))) :=
    add_nonneg (pow_nonneg (mul_nonneg (Real.exp_pos _).le (dobConst_pos β hβ0).le) K)
      (Real.exp_pos _).le
  rw [integral_lift β n F F.continuous]
  exact hb.trans (mul_le_mul_of_nonneg_left hT hfac)

/-- **Step (a): the cylinder integrals form Cauchy sequences** (window `18 tanh|β| < 1`). -/
theorem cauchy_cyl (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) (F : Cfg →ᵇ ℝ) (hF : IsCyl F) :
    CauchySeq (fun n => ∫ x, F x ∂(liftProb β n : Measure Cfg)) := by
  obtain ⟨S, hS⟩ := hF
  obtain ⟨R0, hR0⟩ := cyl_box S
  obtain ⟨hl, hα⟩ := dob_rate β hβ0 hq
  set lam := -Real.log (dobConst β) / 2 with hlamdef
  have hα0 : 0 < Real.exp lam * dobConst β := mul_pos (Real.exp_pos _) (dobConst_pos β hβ0)
  set Cst := 2 * ‖F‖ * S.card * Real.exp (lam * R0) with hCst
  have hC : 0 ≤ Cst := by positivity
  rw [Metric.cauchySeq_iff]
  intro ε hε
  have hη : 0 < ε / (4 * (Cst + 1)) := by positivity
  obtain ⟨K, hK⟩ := exists_pow_lt_of_lt_one hη hα
  have he1 : Real.exp (-lam) < 1 := by
    rw [← Real.exp_zero]
    exact Real.exp_lt_exp.2 (by linarith)
  obtain ⟨j, hj⟩ := exists_pow_lt_of_lt_one hη he1
  have hclose : ∀ n, max R0 j + 1 ≤ n →
      |∫ x, F x ∂(liftProb β n : Measure Cfg)
        - (hbSweepZ β (boxFin (max R0 j)).toList)^[K] F (fun _ => q0)| < ε / 2 := by
    intro n hn
    have h := lift_close β lam hβ0 hl.le hα.le F S hS R0 hR0 (max R0 j) (le_max_left _ _) K n hn
    have h2 : Real.exp (-(lam * ((max R0 j : ℕ) + 1))) ≤ Real.exp (-lam) ^ j := by
      rw [← Real.exp_nat_mul]
      apply Real.exp_le_exp.2
      have hj' : j ≤ max R0 j + 1 := by have := le_max_right R0 j; omega
      have : (j : ℝ) ≤ ((max R0 j : ℕ) : ℝ) + 1 := by exact_mod_cast hj'
      nlinarith
    have h3 : ((Real.exp lam * dobConst β) ^ K + Real.exp (-(lam * ((max R0 j : ℕ) + 1)))) * Cst
        ≤ (ε / (4 * (Cst + 1)) + ε / (4 * (Cst + 1))) * Cst :=
      mul_le_mul_of_nonneg_right (add_le_add hK.le (h2.trans hj.le)) hC
    have h4 : (ε / (4 * (Cst + 1)) + ε / (4 * (Cst + 1))) * Cst = ε / 2 * (Cst / (Cst + 1)) := by
      field_simp
      ring
    have h5 : Cst / (Cst + 1) < 1 := (div_lt_one (by linarith)).2 (by linarith)
    have h6 : ε / 2 * (Cst / (Cst + 1)) < ε / 2 := mul_lt_of_lt_one_right (by positivity) h5
    calc _ ≤ _ := h
      _ ≤ _ := h3
      _ = _ := h4
      _ < ε / 2 := h6
  refine ⟨max R0 j + 1, fun m hm n hn => ?_⟩
  rw [Real.dist_eq]
  have a := hclose m hm
  have b := hclose n hn
  rw [abs_sub_comm] at b
  calc _ ≤ _ := abs_sub_le _ ((hbSweepZ β (boxFin (max R0 j)).toList)^[K] F (fun _ => q0)) _
    _ < ε := by linarith

/-- **The whole sequence of periodic lifts converges: `∃! ν_β`** (window `18 tanh|β| < 1`,
`β ≠ 0`; tori `(ℤ/2(n+1))⁴`, all `n`, no subsequence). -/
theorem wilson_infvol_unique (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃! ν : ProbabilityMeasure Cfg, Tendsto (fun n => liftProb β n) atTop (𝓝 ν) := by
  obtain ⟨ν, hν⟩ := tendsto_of_cyl_cauchy (fun n => liftProb β n)
    (fun F hF => cauchy_cyl β hβ0 hq F hF)
  exact ⟨ν, hν, fun ν' h' => tendsto_nhds_unique h' hν⟩

/-- **Infinite-volume theorem without subsequences.**  -/
theorem wilson_infvol (β : ℝ) (hβ0 : β ≠ 0) (hq : dobConst β < 1) :
    ∃ ν : ProbabilityMeasure Cfg,
      Tendsto (fun n => liftProb β n) atTop (𝓝 ν) ∧
      (∀ (ν' : ProbabilityMeasure Cfg) (φ : ℕ → ℕ), StrictMono φ →
        Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν') → ν' = ν) ∧
      (∀ F : Cfg →ᵇ ℝ, ∫ x, F (zShift x) ∂(ν : Measure Cfg) = ∫ x, F x ∂(ν : Measure Cfg)) ∧
      (∀ F ∈ Wsub, 0 ≤ ∫ x, F (zRefl x) * F x ∂(ν : Measure Cfg)) ∧
      (∃ D : Datum Wsub,
        (∀ F G : Wsub, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨F0, F0_mem⟩ ⟨F0, F0_mem⟩ - (D.B D.one ⟨F0, F0_mem⟩) ^ 2 ∧
        (∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
        D.T (D.emb ⟨F0, F0_mem⟩) = 0) ∧
      (∃ D : Datum Wgi,
        (∀ F G : Wgi, D.B F G
          = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
        (∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
        ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
        D.HasMassGap (-Real.log (dobConst β) / 2) ∧
        Real.exp (-(12 * |β|)) / 4 ≤
          D.B ⟨Fp, Fp_mem⟩ ⟨Fp, Fp_mem⟩ - (D.B D.one ⟨Fp, Fp_mem⟩) ^ 2 ∧
        ∃ v : D.Hilb, ⟪v, D.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      (∀ (i : Fin 4) (F G : Cfg →ᵇ ℝ) (SF SG : Finset ZLk) (R : ℕ),
        (∀ ℓ ∈ SF, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) → (∀ ℓ ∈ SG, 0 ≤ ℓ.1 i ∧ ℓ.1 i ≤ R) →
        (∀ x y : Cfg, (∀ ℓ ∈ SF, x ℓ = y ℓ) → F x = F y) →
        (∀ x y : Cfg, (∀ ℓ ∈ SG, x ℓ = y ℓ) → G x = G y) →
        ∀ k : ℕ, R ≤ k →
          |∫ x, F x * G (zShI i k x) ∂(ν : Measure Cfg)
              - (∫ x, F x ∂(ν : Measure Cfg)) * ∫ x, G (zShI i k x) ∂(ν : Measure Cfg)|
            ≤ 4 * ‖F‖ * ‖G‖ * SG.card
              * Real.exp (-((-Real.log (dobConst β) / 2) * ((k : ℝ) - R)))) :=
  wilson_infvol_of_cauchy β hβ0 hq (fun F hF => cauchy_cyl β hβ0 hq F hF)

/-- the hypotheses are satisfiable: `β = 1/20` -/
theorem infvol_example : ∃ ν : ProbabilityMeasure Cfg,
    Tendsto (fun n => liftProb (1 / 20) n) atTop (𝓝 ν) :=
  (wilson_infvol_unique (1 / 20) dob_example.1 dob_example.2).exists

end InfVol

#print axioms InfVol.lift_close
#print axioms InfVol.cauchy_cyl
#print axioms InfVol.wilson_infvol_unique
#print axioms InfVol.wilson_infvol
#print axioms InfVol.infvol_example
