import Infvol.RangeAV2

/-!
# The range of the transfer operator lies in the gauge-invariant sector

Paper correspondence: (the general form).
* `GaugeRange.limit_gauge_inv` : every weak limit point is invariant under the gauge
  transformations with finite support (tested on cylinder functions).
* `GaugeRange.pair_avg` : `B(K, avg_S F) = B(K, F)` when the gauge transformations on `S` do not
  touch `K ∘ θ`.
* `GaugeRange.T_range_gauge` : at every weak limit point (Dobrushin window), every vector
  `T u` of the full reconstruction is the image `ι w` of a vector of the gauge-invariant
  reconstruction (`ι` the isometric embedding of `Restrict.subHilb`).
-/

namespace GaugeRange

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge ZHeat InfVol
open scoped BoundedContinuousFunction InnerProductSpace

local notation "ℍr" => Quaternion ℝ

section Torus

variable (N : ℕ) [NeZero N]

/-- the canonical representative of a torus site -/
def liftSite (z : Site N) : ZSite := fun i => (z i).valMinAbs

theorem liftSite_pS (y : ZSite) (hy : ∀ i, 2 * |y i| < N) : liftSite N (pS N y) = y := by
  funext i
  have h := hy i
  have h1 : -(N : ℤ) < y i * 2 := by have := neg_abs_le (y i); linarith
  have h2 : y i * 2 ≤ N := by have := le_abs_self (y i); linarith
  exact (ZMod.valMinAbs_spec _ _).2 ⟨rfl, ⟨h1, h2⟩⟩

/-- the torus gauge transformation copying `gext S g` on the representatives -/
noncomputable def gTor (S : Finset ZSite) (g : S → SU2) : Site N → QBall :=
  fun z => incl (gext S g (liftSite N z))

theorem gTor_unit (S : Finset ZSite) (g : S → SU2) : ∀ z, ‖((gTor N S g z : QBall) : ℍr)‖ = 1 :=
  fun z => unit_norm _

theorem link_eq (S : Finset ZSite) (g : S → SU2) (ω : Lk N → QBall) (ℓ : ZLk)
    (e1 : liftSite N (pS N ℓ.1) = ℓ.1) (e2 : liftSite N (pS N (ℓ.1 + ze ℓ.2)) = ℓ.1 + ze ℓ.2) :
    gaugeAct (gext S g) (perLift N ω) ℓ = perLift N (act (src N) (tgt N) (gTor N S g) ω) ℓ := by
  have a1 : gTor N S g (pS N ℓ.1) = incl (gext S g ℓ.1) := by unfold gTor; rw [e1]
  have a2 : gTor N S g (pS N ℓ.1 + ev N ℓ.2) = incl (gext S g (ℓ.1 + zev ℓ.2)) := by
    rw [show pS N ℓ.1 + ev N ℓ.2 = pS N (ℓ.1 + ze ℓ.2) from (pS_add N ℓ.1 ℓ.2).symm]
    unfold gTor
    rw [e2]
    rfl
  calc gaugeAct (gext S g) (perLift N ω) ℓ
      = gq (gext S g ℓ.1) (gext S g (ℓ.1 + zev ℓ.2)) (ω (zproj N ℓ)) := rfl
    _ = mulB (incl (gext S g ℓ.1)) (incl (gext S g (ℓ.1 + zev ℓ.2))) (ω (zproj N ℓ)) :=
        Subtype.ext rfl
    _ = mulB (gTor N S g (pS N ℓ.1)) (gTor N S g (pS N ℓ.1 + ev N ℓ.2)) (ω (zproj N ℓ)) := by
        rw [a1, a2]
    _ = perLift N (act (src N) (tgt N) (gTor N S g) ω) ℓ := rfl

end Torus

/-- each large torus -/
theorem torus_gauge_inv (β : ℝ) (m : ℕ) (S : Finset ZSite) (g : S → SU2)
    (H : Cfg →ᵇ ℝ) (T : Finset ZLk) (hT : ∀ x y : Cfg, (∀ ℓ ∈ T, x ℓ = y ℓ) → H x = H y)
    (R1 : ℕ) (hR1 : ∀ ℓ ∈ T, inBox R1 ℓ) (hN : 2 * (R1 + 2) < Nn m) :
    ∫ ω, H (gaugeAct (gext S g) (perLift (Nn m) ω)) ∂(wilsonProb (Nn m) β : Measure (Lk (Nn m) → QBall))
      = ∫ ω, H (perLift (Nn m) ω) ∂(wilsonProb (Nn m) β : Measure (Lk (Nn m) → QBall)) := by
  have hinv := CenterFlip.integral_act_prob (Nn m) β (gTor (Nn m) S g)
    (gTor_unit (Nn m) S g) (fun ω => H (perLift (Nn m) ω))
    ((H.continuous.comp (continuous_perLift _)).measurable)
  have hNz : (2 * ((R1 : ℤ) + 2)) < (Nn m : ℤ) := by exact_mod_cast hN
  have key : ∀ ω : Lk (Nn m) → QBall, H (gaugeAct (gext S g) (perLift (Nn m) ω))
      = H (perLift (Nn m) (act (src (Nn m)) (tgt (Nn m)) (gTor (Nn m) S g) ω)) := by
    intro ω
    apply hT
    intro ℓ hℓ
    have hb := hR1 ℓ hℓ
    have e1 : liftSite (Nn m) (pS (Nn m) ℓ.1) = ℓ.1 :=
      liftSite_pS _ _ (fun i => by have := hb i; linarith)
    have hb2 : ∀ i, |(ℓ.1 + ze ℓ.2) i| ≤ (R1 : ℤ) + 1 := fun i => by
      have a := abs_le.1 (hb i)
      simp only [ze, Pi.add_apply, Pi.single_apply]
      split_ifs <;> exact abs_le.2 ⟨by omega, by omega⟩
    have e2 : liftSite (Nn m) (pS (Nn m) (ℓ.1 + ze ℓ.2)) = ℓ.1 + ze ℓ.2 :=
      liftSite_pS _ _ (fun i => by have := hb2 i; linarith)
    exact link_eq (Nn m) S g ω ℓ e1 e2
  calc ∫ ω, H (gaugeAct (gext S g) (perLift (Nn m) ω)) ∂(wilsonProb (Nn m) β : Measure (Lk (Nn m) → QBall))
      = ∫ ω, H (perLift (Nn m) (act (src (Nn m)) (tgt (Nn m)) (gTor (Nn m) S g) ω))
          ∂(wilsonProb (Nn m) β : Measure (Lk (Nn m) → QBall)) :=
        integral_congr_ae (Eventually.of_forall key)
    _ = _ := hinv

theorem tend_g (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (S : Finset ZSite) (g : S → SU2)
    (H : Cfg →ᵇ ℝ) (hgc : Continuous (fun x => gaugeAct (gext S g) x)) :
    Tendsto (fun n => ∫ x, (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩) x
      ∂(liftProb β (φ n) : Measure Cfg)) atTop
      (𝓝 (∫ x, (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩) x ∂(ν : Measure Cfg))) :=
  ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim _

theorem ev_g (β : ℝ) (φ : ℕ → ℕ) (hφ : StrictMono φ) (S : Finset ZSite) (g : S → SU2)
    (H : Cfg →ᵇ ℝ) (T : Finset ZLk) (hT : ∀ x y : Cfg, (∀ ℓ ∈ T, x ℓ = y ℓ) → H x = H y)
    (R1 : ℕ) (hR1 : ∀ ℓ ∈ T, inBox R1 ℓ) (hgc : Continuous (fun x => gaugeAct (gext S g) x))
    (n : ℕ) (hn : R1 + 2 ≤ n) :
    ∫ x, (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩) x ∂(liftProb β (φ n) : Measure Cfg)
      = ∫ x, H x ∂(liftProb β (φ n) : Measure Cfg) := by
  have hle : n ≤ φ n := hφ.id_le n
  have hN : 2 * (R1 + 2) < Nn (φ n) := by unfold Nn; omega
  rw [integral_lift β (φ n) _ (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩).continuous,
    integral_lift β (φ n) _ H.continuous]
  exact torus_gauge_inv β (φ n) S g H T hT R1 hR1 hN

/-- **Gauge invariance of the weak limit points** (finite support, tested on cylinder functions;
stated with the composed bounded continuous function). -/
theorem limit_gauge_inv (β : ℝ) (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) (S : Finset ZSite) (g : S → SU2)
    (H : Cfg →ᵇ ℝ) (T : Finset ZLk) (hT : ∀ x y : Cfg, (∀ ℓ ∈ T, x ℓ = y ℓ) → H x = H y)
    (hgc : Continuous (fun x => gaugeAct (gext S g) x)) :
    ∫ x, (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩) x ∂(ν : Measure Cfg)
      = ∫ x, H x ∂(ν : Measure Cfg) := by
  obtain ⟨R1, hR1⟩ := cyl_box T
  have h2 := ProbabilityMeasure.tendsto_iff_forall_integral_tendsto.1 hlim H
  have hev : ∀ᶠ n in atTop,
      ∫ x, H x ∂(liftProb β (φ n) : Measure Cfg)
        = ∫ x, (H.compContinuous ⟨fun x => gaugeAct (gext S g) x, hgc⟩) x
            ∂(liftProb β (φ n) : Measure Cfg) := by
    filter_upwards [eventually_ge_atTop (R1 + 2)] with n hn
    exact (ev_g β φ hφ S g H T hT R1 hR1 hgc n hn).symm
  exact tendsto_nhds_unique (tend_g β ν φ hlim S g H hgc) (h2.congr' hev)

end GaugeRange

#print axioms GaugeRange.torus_gauge_inv
#print axioms GaugeRange.tend_g
#print axioms GaugeRange.ev_g
#print axioms GaugeRange.limit_gauge_inv
