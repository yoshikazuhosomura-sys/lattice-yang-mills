import Infvol.RangeDV5

/-!
# Restriction and range statements with the shift and the unit bound in the conclusion


The two statements below repeat `Restrict.wilson_gauge_restrict` and `GaugeRange.T_emb_gauge`
with four more conjuncts: for both data `D` (on `W`) and `D'` (on `W_gi`), the map `τ` is the time
shift `F ↦ F ∘ zShift` and `one` is the constant function `1`.  Together with the conjuncts on `B`
this fixes every field of both data (the pairing, the shift and the unit).
* `Bind.wilson_gauge_restrict_bound`
* `Bind.T_emb_gauge_bound`
* `Bind.shift_not_rank_one_sub`, `Bind.shift_not_rank_one_gi` : a datum whose `τ` is the time shift
  can not have the rank-one map `x ↦ B(1,x)·1` as its `τ` (evaluate `τ F₀`, `τ F_p` at the
  constant configurations `0` and `1`).
-/

namespace Bind

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ GaugeFix TorusGauge ZHeat InfVol Restrict GaugeRange
open scoped BoundedContinuousFunction InnerProductSpace

theorem wilson_gauge_restrict_bound (β lam : ℝ) (hlam : 0 < lam)
    (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub, ∃ D' : Datum Wgi,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      (∀ F G : Wgi, D'.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wgi, ((D'.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧ D'.HasMassGap lam ∧
      (∃ v : D'.Hilb, ⟪v, D'.Ω⟫_ℝ = 0 ∧ ‖v‖ = 1) ∧
      ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
        (∀ u, ι (D'.T u) = D.T (ι u)) ∧
        ∀ F : Wgi, ι (D'.emb F) = D.emb (Submodule.inclusion inf_le_left F) := by
  obtain ⟨D, hB, hτ, hone, hgap, -, -⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  obtain ⟨D', hB', hτ', hone', hgap', -, hv'⟩ := wilson_massGap_gauge β lam hlam hα ν φ hφ hlim
  have hBj : ∀ x y : Wgi, D.B (Submodule.inclusion inf_le_left x)
      (Submodule.inclusion inf_le_left y) = D'.B x y := by
    intro x y
    rw [hB, hB']
    rfl
  have hτj : ∀ x : Wgi, D.τ (Submodule.inclusion inf_le_left x)
      = Submodule.inclusion inf_le_left (D'.τ x) := by
    intro x
    apply Subtype.ext
    rw [hτ]
    show _ = ((D'.τ x : Wgi) : Cfg →ᵇ ℝ)
    rw [hτ']
    rfl
  have honej : Submodule.inclusion inf_le_left D'.one = D.one := by
    apply Subtype.ext
    rw [hone]
    show ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1
    exact hone'
  obtain ⟨ι, h1, h2, h3, h4⟩ := subHilb D D' (Submodule.inclusion inf_le_left) hBj hτj honej
  exact ⟨D, D', hB, hτ, hone, hB', hτ', hone', hgap, hgap', hv', ι, h1, h2, h3, h4⟩

theorem T_emb_gauge_bound (β lam : ℝ) (hlam : 0 < lam) (hα : Real.exp lam * dobConst β < 1)
    (ν : ProbabilityMeasure Cfg) (φ : ℕ → ℕ) (hφ : StrictMono φ)
    (hlim : Tendsto (fun n => liftProb β (φ n)) atTop (𝓝 ν)) :
    ∃ D : Datum Wsub, ∃ D' : Datum Wgi,
      (∀ F G : Wsub, D.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧
      (∀ F G : Wgi, D'.B F G
        = ∫ x, (F : Cfg →ᵇ ℝ) (zRefl x) * (G : Cfg →ᵇ ℝ) x ∂(ν : Measure Cfg)) ∧
      (∀ F : Wgi, ((D'.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧
      D.HasMassGap lam ∧ D'.HasMassGap lam ∧
      ∃ ι : D'.Hilb →L[ℝ] D.Hilb, (∀ u, ‖ι u‖ = ‖u‖) ∧ ι D'.Ω = D.Ω ∧
        (∀ u, ι (D'.T u) = D.T (ι u)) ∧
        ∀ F : Wsub, ∃ w : D'.Hilb, D.T (D.emb F) = ι w := by
  obtain ⟨D, hB, hτ, hone, hgap, -, -⟩ := wilson_massGap_dob β lam hlam hα ν φ hφ hlim
  obtain ⟨D', hB', hτ', hone', hgap', -, -⟩ := wilson_massGap_gauge β lam hlam hα ν φ hφ hlim
  have hBj : ∀ x y : Wgi, D.B (Submodule.inclusion inf_le_left x)
      (Submodule.inclusion inf_le_left y) = D'.B x y := by
    intro x y; rw [hB, hB']; rfl
  have hτj : ∀ x : Wgi, D.τ (Submodule.inclusion inf_le_left x)
      = Submodule.inclusion inf_le_left (D'.τ x) := by
    intro x; apply Subtype.ext; rw [hτ]
    show _ = ((D'.τ x : Wgi) : Cfg →ᵇ ℝ)
    rw [hτ']; rfl
  have honej : Submodule.inclusion inf_le_left D'.one = D.one := by
    apply Subtype.ext; rw [hone]; show ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1; exact hone'
  obtain ⟨ι, h1, h2, h3, h4⟩ := subHilb D D' (Submodule.inclusion inf_le_left) hBj hτj honej
  refine ⟨D, D', hB, hτ, hone, hB', hτ', hone', hgap, hgap', ι, h1, h2, h3, fun F => ?_⟩
  obtain ⟨TF, R, hTF, hdep⟩ := (mem_Wsub _).1 F.2
  obtain ⟨S, hSdef⟩ : ∃ S : Finset ZSite,
      S = TF.image (fun ℓ => (zsh 1 ℓ).1) ∪ TF.image (fun ℓ => (zsh 1 ℓ).1 + zev ℓ.2) := ⟨_, rfl⟩
  have hSt : ∀ y ∈ S, 1 ≤ y 0 := by
    intro y hy
    rw [hSdef, Finset.mem_union, Finset.mem_image, Finset.mem_image] at hy
    rcases hy with ⟨ℓ, hℓ, rfl⟩ | ⟨ℓ, hℓ, rfl⟩
    · rw [zsh_time]; have := (hTF ℓ hℓ).1; push_cast; omega
    · have := (hTF ℓ hℓ).1
      simp only [Pi.add_apply, zev, Pi.single_apply]
      rw [zsh_time]
      split_ifs <;> push_cast <;> omega
  obtain ⟨τF, hτFdef⟩ : ∃ τF : Cfg →ᵇ ℝ, τF = shiftMap zShiftC (F : Cfg →ᵇ ℝ) := ⟨_, rfl⟩
  have hτmem : τF ∈ Wsub := by rw [hτFdef]; exact shift_mem_Wsub _ F.2
  have hdepS : DepS S τF := by
    intro x y h
    rw [hτFdef]
    show (F : Cfg →ᵇ ℝ) (zShift x) = (F : Cfg →ᵇ ℝ) (zShift y)
    apply hdep
    intro ℓ hℓ
    show x (zsh 1 ℓ) = y (zsh 1 ℓ)
    apply h
    · rw [hSdef]; exact Finset.mem_union_left _ (Finset.mem_image_of_mem _ hℓ)
    · rw [hSdef]; exact Finset.mem_union_right _ (Finset.mem_image_of_mem (fun ℓ => (zsh 1 ℓ).1 + zev ℓ.2) hℓ)
  have hGmem : avgB S τF ∈ Wgi :=
    Submodule.mem_inf.2 ⟨avgB_mem_Wsub S τF hτmem, avgB_mem_Winv S τF hdepS⟩
  let G : Wgi := ⟨avgB S τF, hGmem⟩
  have hBK : ∀ K : Wsub, D.B K (D.τ F) = D.B K (Submodule.inclusion inf_le_left G) := by
    intro K
    obtain ⟨TK, RK, hTK, hdepK⟩ := (mem_Wsub _).1 K.2
    rw [hB, hB, hτ]
    have hK : ∀ (g : S → SU2) x, (K : Cfg →ᵇ ℝ) (zRefl (gaugeAct (gext S g) x))
        = (K : Cfg →ᵇ ℝ) (zRefl x) := by
      intro g x
      apply hdepK
      intro m hm
      have hm0 := (hTK m hm).1
      have ht := zthL_time m
      have hn1 : ∀ y : ZSite, y 0 ≤ 0 → gext S g y = 1 := by
        intro y hy
        unfold gext
        rw [dif_neg]
        intro hyS
        have := hSt y hyS
        omega
      have ea : gext S g (zthL m).1 = 1 := hn1 _ (by rw [ht]; split_ifs <;> omega)
      have eb : gext S g ((zthL m).1 + zev (zthL m).2) = 1 := by
        apply hn1
        have hm2 : (zthL m).2 = m.2 := by unfold zthL; split_ifs with h <;> simp [h]
        simp only [Pi.add_apply, zev, Pi.single_apply, hm2]
        rw [ht]
        split_ifs <;> omega
      show zsig m (gq (gext S g (zthL m).1) (gext S g ((zthL m).1 + zev (zthL m).2)) (x (zthL m)))
        = zsig m (x (zthL m))
      rw [ea, eb, gq_one]
    have hT : ∀ x y : Cfg, (∀ ℓ ∈ TK.image zthL ∪ TF.image (zsh 1), x ℓ = y ℓ) →
        (K : Cfg →ᵇ ℝ) (zRefl x) * τF x = (K : Cfg →ᵇ ℝ) (zRefl y) * τF y := by
      intro x y h
      have a : (K : Cfg →ᵇ ℝ) (zRefl x) = (K : Cfg →ᵇ ℝ) (zRefl y) := hdepK _ _ (fun m hm => by
        show zsig m (x (zthL m)) = zsig m (y (zthL m))
        rw [h _ (Finset.mem_union_left _ (Finset.mem_image_of_mem _ hm))])
      have b : τF x = τF y := by
        rw [hτFdef]
        show (F : Cfg →ᵇ ℝ) (zShift x) = (F : Cfg →ᵇ ℝ) (zShift y)
        exact hdep _ _ (fun ℓ hℓ => h _ (Finset.mem_union_right _ (Finset.mem_image_of_mem _ hℓ)))
      rw [a, b]
    have hp := pair_avg β ν φ hφ hlim S (K : Cfg →ᵇ ℝ) τF hK _ hT
    rw [← hτFdef]
    exact hp.symm
  obtain ⟨b, hb⟩ : ∃ b : Wsub, b = Submodule.inclusion inf_le_left G := ⟨_, rfl⟩
  have hBK' : ∀ K : Wsub, D.B K (D.τ F) = D.B K b := fun K => by rw [hb]; exact hBK K
  have hsub : D.emb (D.τ F) = D.emb b := by
    have hsq : ‖D.emb (D.τ F) - D.emb b‖ ^ 2 = 0 := by
      rw [norm_sub_sq_real, D.norm_emb_sq, D.norm_emb_sq, D.inner_emb, hBK' (D.τ F), ← hBK' b,
        D.symm b (D.τ F)]
      ring
    exact sub_eq_zero.1 (norm_eq_zero.1 ((pow_eq_zero_iff two_ne_zero).1 hsq))
  exact ⟨D'.emb G, by rw [D.T_emb, hsub, hb, h4]; rfl⟩

/-! ## The rank-one map is excluded -/

/-- the constant configuration with value `q` -/
def cfgC (q : QBall) : Cfg := fun _ => q

/-- the points `0` and `1` of the closed unit ball -/
noncomputable def bZero : QBall := ⟨0, by simp⟩
noncomputable def bOne : QBall := ⟨1, by rw [Metric.mem_closedBall, dist_zero_right, norm_one]⟩

theorem F0_cfgC (q : QBall) : F0 (cfgC q) = ((q : QBall) : Quaternion ℝ).re := rfl

theorem Fp_cfgC (q : QBall) :
    Fp (cfgC q) = (((q : Quaternion ℝ) * (q : Quaternion ℝ)) * star (q : Quaternion ℝ)
      * star (q : Quaternion ℝ)).re := rfl

/-- On the full space: if `τ` is the time shift and `one = 1`, then `τ` is not `x ↦ B(1,x)·1`. -/
theorem shift_not_rank_one_sub (D : Datum Wsub)
    (hτ : ∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ))
    (hone : ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1) :
    ¬ ∀ F : Wsub, D.τ F = D.B D.one F • D.one := by
  intro h
  have e : ∀ q : QBall, F0 (cfgC q) = D.B D.one ⟨F0, F0_mem⟩ := by
    intro q
    have lhs : ((D.τ ⟨F0, F0_mem⟩ : Wsub) : Cfg →ᵇ ℝ) (cfgC q) = F0 (cfgC q) := by
      rw [hτ]; rfl
    have rhs : ((D.B D.one ⟨F0, F0_mem⟩ • D.one : Wsub) : Cfg →ᵇ ℝ) (cfgC q)
        = D.B D.one ⟨F0, F0_mem⟩ := by
      rw [Submodule.coe_smul, hone]; simp
    rw [← lhs, ← rhs, h]
  have h0 := e bZero
  have h1 := e bOne
  rw [F0_cfgC] at h0 h1
  have a0 : ((bZero : QBall) : Quaternion ℝ).re = 0 := rfl
  have a1 : ((bOne : QBall) : Quaternion ℝ).re = 1 := rfl
  linarith

/-- On the gauge-invariant space: the same, with the plaquette `F_p`. -/
theorem shift_not_rank_one_gi (D : Datum Wgi)
    (hτ : ∀ F : Wgi, ((D.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ))
    (hone : ((D.one : Wgi) : Cfg →ᵇ ℝ) = 1) :
    ¬ ∀ F : Wgi, D.τ F = D.B D.one F • D.one := by
  intro h
  have e : ∀ q : QBall, Fp (cfgC q) = D.B D.one ⟨Fp, Fp_mem⟩ := by
    intro q
    have lhs : ((D.τ ⟨Fp, Fp_mem⟩ : Wgi) : Cfg →ᵇ ℝ) (cfgC q) = Fp (cfgC q) := by
      rw [hτ]; rfl
    have rhs : ((D.B D.one ⟨Fp, Fp_mem⟩ • D.one : Wgi) : Cfg →ᵇ ℝ) (cfgC q)
        = D.B D.one ⟨Fp, Fp_mem⟩ := by
      rw [Submodule.coe_smul, hone]; simp
    rw [← lhs, ← rhs, h]
  have h0 := e bZero
  have h1 := e bOne
  rw [Fp_cfgC] at h0 h1
  have a0 : ((bZero : QBall) : Quaternion ℝ) = 0 := rfl
  have a1 : ((bOne : QBall) : Quaternion ℝ) = 1 := rfl
  rw [a0] at h0
  rw [a1] at h1
  simp only [mul_zero, zero_mul, star_zero, mul_one, star_one] at h0 h1
  have r0 : (0 : Quaternion ℝ).re = 0 := rfl
  have r1 : (1 : Quaternion ℝ).re = 1 := rfl
  rw [r0] at h0
  rw [r1] at h1
  linarith

/-- **The rank-one datum of the audit can not be used in the new statements.**  In the form of
`T_emb_gauge_bound` and `wilson_gauge_restrict_bound`, any `D` (resp. `D'`) satisfying the shift and
unit conjuncts has a `τ` different from `x ↦ B(1,x)·1`. -/
theorem rank_one_excluded :
    (¬ ∃ D : Datum Wsub,
      (∀ F : Wsub, ((D.τ F : Wsub) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D.one : Wsub) : Cfg →ᵇ ℝ) = 1 ∧ ∀ F, D.τ F = D.B D.one F • D.one) ∧
    (¬ ∃ D' : Datum Wgi,
      (∀ F : Wgi, ((D'.τ F : Wgi) : Cfg →ᵇ ℝ) = shiftMap zShiftC (F : Cfg →ᵇ ℝ)) ∧
      ((D'.one : Wgi) : Cfg →ᵇ ℝ) = 1 ∧ ∀ F, D'.τ F = D'.B D'.one F • D'.one) :=
  ⟨fun ⟨D, hτ, hone, h⟩ => shift_not_rank_one_sub D hτ hone h,
   fun ⟨D, hτ, hone, h⟩ => shift_not_rank_one_gi D hτ hone h⟩

end Bind

#print axioms Bind.wilson_gauge_restrict_bound
#print axioms Bind.T_emb_gauge_bound
#print axioms Bind.rank_one_excluded
