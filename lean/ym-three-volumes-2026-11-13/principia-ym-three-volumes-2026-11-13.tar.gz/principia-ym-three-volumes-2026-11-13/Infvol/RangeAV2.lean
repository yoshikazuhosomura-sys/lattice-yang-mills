import Infvol.RestrictV1

/-!
# Averages over gauge transformations with finite support on ℤ⁴

Paper correspondence: (the general form).
* `GaugeRange.gext` : a gauge transformation on a finite set `S` of sites, `1` outside.
* `GaugeRange.avgZ` : the Haar average `∫ H(g·x) dg` over the gauge transformations on `S`.
* `GaugeRange.continuous_avgZ` : the average of a bounded continuous function is continuous.
* `GaugeRange.avgZ_gauge` : if `H` reads only links with both end points in `S`, the average is
  invariant under every gauge transformation of ℤ⁴.
-/

namespace GaugeRange

open MeasureTheory Filter Topology TorusRP LinkReflection OSGap OrbitGrowth SwapDecay
open WilsonLimit GaugeZ
open scoped BoundedContinuousFunction

local notation "ℍr" => Quaternion ℝ

/-- the Haar measure on gauge transformations on `S` -/
noncomputable def hS (S : Finset ZSite) : Measure (S → SU2) := Measure.pi fun _ => haarSU2

instance (S : Finset ZSite) : IsProbabilityMeasure (hS S) := by unfold hS; infer_instance

/-- extension by `1` -/
noncomputable def gext (S : Finset ZSite) (g : S → SU2) : ZSite → SU2 :=
  fun y => if h : y ∈ S then g ⟨y, h⟩ else 1

theorem continuous_gext_apply (S : Finset ZSite) (y : ZSite) :
    Continuous (fun g : S → SU2 => gext S g y) := by
  unfold gext
  by_cases h : y ∈ S
  · simp only [h, dif_pos]
    exact continuous_apply _
  · simp only [h, dif_neg, not_false_eq_true]
    exact continuous_const

theorem continuous_gq' {X : Type*} [TopologicalSpace X] {f g : X → SU2} {h : X → QBall}
    (hf : Continuous f) (hg : Continuous g) (hh : Continuous h) :
    Continuous (fun x => gq (f x) (g x) (h x)) := by
  unfold gq
  refine Continuous.subtype_mk ?_ _
  exact ((continuous_subtype_val.comp hf).mul (continuous_subtype_val.comp hh)).mul
    (continuous_star.comp (continuous_subtype_val.comp hg))

theorem continuous_gaugeAct_gext (S : Finset ZSite) :
    Continuous (fun p : Cfg × (S → SU2) => gaugeAct (gext S p.2) p.1) := by
  refine continuous_pi fun ℓ => ?_
  show Continuous fun p : Cfg × (S → SU2) =>
    gq (gext S p.2 ℓ.1) (gext S p.2 (ℓ.1 + zev ℓ.2)) (p.1 ℓ)
  exact continuous_gq' ((continuous_gext_apply S _).comp continuous_snd)
    ((continuous_gext_apply S _).comp continuous_snd) ((continuous_apply ℓ).comp continuous_fst)

/-- the average over the gauge transformations on `S` -/
noncomputable def avgZ (S : Finset ZSite) (H : Cfg → ℝ) (x : Cfg) : ℝ :=
  ∫ g, H (gaugeAct (gext S g) x) ∂(hS S)

theorem continuous_avgZ (S : Finset ZSite) (H : Cfg →ᵇ ℝ) : Continuous (avgZ S H) := by
  have h := continuous_parametric_integral_of_continuous (μ := hS S)
    (f := fun x (g : S → SU2) => H (gaugeAct (gext S g) x))
    (H.continuous.comp (continuous_gaugeAct_gext S)) (isCompact_univ)
  simp only [Measure.restrict_univ] at h
  exact h

/-- the average as a bounded continuous function -/
noncomputable def avgB (S : Finset ZSite) (H : Cfg →ᵇ ℝ) : Cfg →ᵇ ℝ :=
  BoundedContinuousFunction.mkOfCompact ⟨avgZ S H, continuous_avgZ S H⟩

theorem avgB_apply (S : Finset ZSite) (H : Cfg →ᵇ ℝ) (x : Cfg) : avgB S H x = avgZ S H x := rfl

theorem gaugeAct_gaugeAct (a b : ZSite → SU2) (x : Cfg) :
    gaugeAct a (gaugeAct b x) = gaugeAct (fun y => a y * b y) x := by
  funext ℓ
  apply Subtype.ext
  show ((a ℓ.1 : ℍr)) * (((b ℓ.1 : ℍr)) * ((x ℓ : QBall) : ℍr) * star ((b (ℓ.1 + zev ℓ.2) : ℍr)))
      * star ((a (ℓ.1 + zev ℓ.2) : ℍr))
    = (((a ℓ.1 * b ℓ.1 : SU2) : ℍr)) * ((x ℓ : QBall) : ℍr)
      * star (((a (ℓ.1 + zev ℓ.2) * b (ℓ.1 + zev ℓ.2) : SU2) : ℍr))
  rw [show (((a ℓ.1 * b ℓ.1 : SU2) : ℍr)) = (a ℓ.1 : ℍr) * (b ℓ.1 : ℍr) from rfl,
    show (((a (ℓ.1 + zev ℓ.2) * b (ℓ.1 + zev ℓ.2) : SU2) : ℍr))
      = (a (ℓ.1 + zev ℓ.2) : ℍr) * (b (ℓ.1 + zev ℓ.2) : ℍr) from rfl]
  simp only [star_mul, mul_assoc]

/-- `H` reads only links with both end points in `S` -/
def DepS (S : Finset ZSite) (H : Cfg → ℝ) : Prop :=
  ∀ x y : Cfg, (∀ m : ZLk, m.1 ∈ S → m.1 + zev m.2 ∈ S → x m = y m) → H x = H y

theorem right_preserving (S : Finset ZSite) (k : S → SU2) :
    MeasurePreserving (fun g : S → SU2 => fun y => g y * k y) (hS S) (hS S) := by
  unfold hS
  refine measurePreserving_pi (fun _ => haarSU2) (fun _ => haarSU2)
    (f := fun y => (· * k y)) (fun y => ⟨(continuous_mul_right _).measurable, ?_⟩)
  show Measure.map (· * k y) (haarProb SU2) = haarProb SU2
  rw [show haarProb SU2 = Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2) from rfl]
  haveI : IsProbabilityMeasure (Measure.haarMeasure (⊤ : TopologicalSpace.PositiveCompacts SU2)) :=
    haarProb_isProbabilityMeasure SU2
  exact CompactHaar.map_mul_right_eq _ (k y)

/-- **The average is gauge invariant.** -/
theorem avgZ_gauge (S : Finset ZSite) (H : Cfg →ᵇ ℝ) (hH : DepS S H) (k : ZSite → SU2) (x : Cfg) :
    avgZ S H (gaugeAct k x) = avgZ S H x := by
  unfold avgZ
  have e : ∀ g : S → SU2, H (gaugeAct (gext S g) (gaugeAct k x))
      = H (gaugeAct (gext S (fun y => g y * k y)) x) := by
    intro g
    rw [gaugeAct_gaugeAct]
    apply hH
    intro m h1 h2
    show gq (gext S g m.1 * k m.1) (gext S g (m.1 + zev m.2) * k (m.1 + zev m.2)) (x m)
      = gq (gext S (fun y => g y * k y) m.1) (gext S (fun y => g y * k y) (m.1 + zev m.2)) (x m)
    simp only [gext, h1, h2, dif_pos]
  simp_rw [e]
  have hmp := right_preserving S (fun y => k y)
  have hm : Measurable (fun g : S → SU2 => H (gaugeAct (gext S g) x)) :=
    (H.continuous.comp ((continuous_gaugeAct_gext S).comp
      (Continuous.prodMk continuous_const continuous_id))).measurable
  have h := integral_map (μ := hS S) hmp.measurable.aemeasurable hm.aestronglyMeasurable
  rw [hmp.map_eq] at h
  exact h.symm

theorem avgB_mem_Winv (S : Finset ZSite) (H : Cfg →ᵇ ℝ) (hH : DepS S H) : avgB S H ∈ Winv :=
  fun k x => avgZ_gauge S H hH k x

theorem avgB_mem_Wsub (S : Finset ZSite) (H : Cfg →ᵇ ℝ) (hW : H ∈ Wsub) : avgB S H ∈ Wsub := by
  obtain ⟨T, R, hT, hdep⟩ := (mem_Wsub H).1 hW
  refine (mem_Wsub _).2 ⟨T, R, hT, fun x y h => ?_⟩
  show avgZ S H x = avgZ S H y
  unfold avgZ
  refine integral_congr_ae (Eventually.of_forall fun g => hdep _ _ (fun ℓ hℓ => ?_))
  show gq (gext S g ℓ.1) (gext S g (ℓ.1 + zev ℓ.2)) (x ℓ) = gq (gext S g ℓ.1) (gext S g (ℓ.1 + zev ℓ.2)) (y ℓ)
  rw [h ℓ hℓ]

end GaugeRange

#print axioms GaugeRange.continuous_avgZ
#print axioms GaugeRange.avgZ_gauge
