import Blocks.ThickFloorCutV1

/-!
# 補題 2.3 の強い形 `Canon` を閉じる（具体の SU(2) の Wilson 測度、全ての N, M ≥ 1、m·k ≤ M）

紙： 補題 2.3。反転の場 `g = gK ρ`（向き 3 のリンクに κ₃、向き 4 のリンクに κ₄、他は 1。
四次元のリンクの符号は二次元の点と向きだけで決まる＝全ての (x₁,x₂) で同じ切り口の反転）を
内部に施すと、(3,4) の升では Re U が δκ = ρ 倍、他の升では κ が二回現れて変わらない（`chi_key`）。
ρ = σ · (標準の場) なので、η = ext σ の作用と η = 標準の場の作用が等しい。枠では g = 1（`g_frame`）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k] (b : Fin k × Fin k)

noncomputable def sigX (σ : Fib M m k b → ℤˣ) (s : Pt M) : ℤˣ :=
  if h : blk2 M m k s = b then σ ⟨s, h⟩ else 1

noncomputable def canU (t : Bool) (s : Pt M) : ℤˣ :=
  if t = true ∧ s = corner M m k b then -1 else 1

noncomputable def rho (σ : Fib M m k b → ℤˣ) (t : Bool) : Pt M → ℤˣ :=
  fun s => sigX M m k b σ s * canU M m k b t s

/-- 反転の場：向き 3 に κ₃、向き 4 に κ₄（二次元の点だけで決まる）、向き 1・2 は 1 -/
noncomputable def gK (r : Pt M → ℤˣ) : Link N M → ℤˣ := fun ℓ =>
  if ℓ.2 = 2 then kap3 M m k b r ℓ.1.2 else if ℓ.2 = 3 then kap4 M m k b r ℓ.1.2 else 1

theorem sgn_mul_self (u : ℤˣ) : sgn u * sgn u = 1 := by
  rcases Int.units_eq_one_or u with rfl | rfl <;> simp [sgn]

theorem sgn_sigX (σ : Fib M m k b → ℤˣ) (s : Pt M) : sgn (sigX M m k b σ s) = ext M m k b σ s := by
  unfold sigX ext
  split_ifs
  · rfl
  · exact sgn_one'

theorem sgn_canU (t : Bool) (s : Pt M) : sgn (canU M m k b t s) = etaSign M m k b t s := by
  unfold canU etaSign etaAt
  cases t
  · simp [sgn]
  · simp only [true_and, if_true]
    split_ifs <;> simp [sgn]

theorem etaSign_sq (t : Bool) (s : Pt M) : etaSign M m k b t s * etaSign M m k b t s = 1 := by
  unfold etaSign etaAt
  cases t
  · simp
  · simp only [if_true]; split_ifs <;> norm_num

theorem sgn_prod (σ : Fib M m k b → ℤˣ) : (∏ P, sgn (σ P)) = sgn (∏ P, σ P) := by
  unfold sgn; rw [Units.coe_prod, Int.cast_prod]

theorem prod_units_of_sgn (σ : Fib M m k b → ℤˣ) (t : Bool)
    (hσ : (∏ P, sgn (σ P)) = (if t then -1 else 1)) : ∏ P, σ P = (if t then -1 else 1 : ℤˣ) := by
  rw [sgn_prod] at hσ
  rcases Int.units_eq_one_or (∏ P, σ P) with h | h <;> rw [h] at hσ ⊢ <;> cases t
  all_goals first | rfl | (exfalso; norm_num [sgn] at hσ) | simp

theorem rho_tot [NeZero m] (hM : m * k ≤ M) (σ : Fib M m k b → ℤˣ) (t : Bool)
    (hσ : (∏ P, sgn (σ P)) = (if t then -1 else 1)) :
    ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), rho M m k b σ t s' = 1 := by
  unfold rho
  rw [Finset.prod_mul_distrib]
  have h1 : ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), sigX M m k b σ s'
      = ∏ P, σ P := by
    rw [Finset.prod_subtype (univ.filter (fun s' : Pt M => blk2 M m k s' = b))
      (p := fun s => blk2 M m k s = b) (by simp)]
    refine Finset.prod_congr rfl fun P _ => ?_
    unfold sigX; rw [dif_pos P.2]
  have h2 : ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), canU M m k b t s'
      = (if t then -1 else 1 : ℤˣ) := by
    unfold canU
    cases t
    · simp
    · simp only [true_and]
      have hc : corner M m k b ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b) :=
        Finset.mem_filter.mpr ⟨Finset.mem_univ _, blk2_corner M m k hM b⟩
      rw [Finset.prod_ite_eq', if_pos hc]
      try simp
  rw [h1, h2, prod_units_of_sgn M m k b σ t hσ]
  cases t <;> decide

theorem g_frame (r : Pt M → ℤˣ) (ℓ : Link N M) (h : fr N M m k ℓ) : gK N M m k b r ℓ = 1 := by
  unfold gK
  by_cases h2 : ℓ.2 = 2
  · rw [if_pos h2]; unfold fr at h; rw [if_pos h2] at h
    unfold kap3; rw [if_neg]; rintro ⟨_, h'⟩; exact h' h
  · rw [if_neg h2]
    by_cases h3 : ℓ.2 = 3
    · rw [if_pos h3]; unfold fr at h; rw [if_neg h2, if_pos h3] at h
      unfold kap4; rw [if_neg]; rintro ⟨_, _, h'⟩; exact h' h
    · rw [if_neg h3]

theorem smul_one_at (g : Link N M → ℤˣ) (ω : Link N M → SU2) (ℓ : Link N M) (h : g ℓ = 1) :
    (g • ω) ℓ = ω ℓ :=
  Subtype.ext (by rw [coe_smul_apply, h, sgn_one']; simp)

theorem ev0_snd (x : Site N M) : (x + ev N M 0).2 = x.2 := by ext <;> simp [ev]
theorem ev1_snd (x : Site N M) : (x + ev N M 1).2 = x.2 := by ext <;> simp [ev]
theorem ev0_snd' : (ev N M 0).2 = 0 := by ext <;> simp [ev]
theorem ev1_snd' : (ev N M 1).2 = 0 := by ext <;> simp [ev]
theorem ev2_snd (x : Site N M) : (x + ev N M 2).2 = (x.2.1 + 1, x.2.2) := by ext <;> simp [ev]
theorem ev3_snd (x : Site N M) : (x + ev N M 3).2 = (x.2.1, x.2.2 + 1) := by ext <;> simp [ev]

/-- 升ごと：`η'_B · χ_B(g) = η_B`（η' = 標準の場、η = ext σ） -/
theorem chi_key [NeZero m] (σ : Fib M m k b → ℤˣ) (t : Bool) (B : Plaq N M) (hB : blk2 M m k B.1.2 = b)
    (htot : ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), rho M m k b σ t s' = 1) :
    etaB N M (etaSign M m k b t) B * chiB N M B (gK N M m k b (rho M m k b σ t))
      = etaB N M (ext M m k b σ) B := by
  obtain ⟨x, P⟩ := B
  rcases plane_cases P with rfl | rfl | rfl | rfl | rfl | rfl
  · simp [etaB, chiB, gK, l1, l2, l3, l4, p01, p23, sgn_one']
  · simp [etaB, chiB, gK, l1, l2, l3, l4, q02, p23, sgn_one', ev0_snd', sgn_mul_self]
  · simp [etaB, chiB, gK, l1, l2, l3, l4, q03, p23, sgn_one', ev0_snd', sgn_mul_self]
  · simp [etaB, chiB, gK, l1, l2, l3, l4, q12, p23, sgn_one', ev1_snd', sgn_mul_self]
  · simp [etaB, chiB, gK, l1, l2, l3, l4, q13, p23, sgn_one', ev1_snd', sgn_mul_self]
  · have hd := delta_kap M m k b (rho M m k b σ t) x.2 hB htot
    have hc : chiB N M (x, p23) (gK N M m k b (rho M m k b σ t))
        = sgn (rho M m k b σ t x.2) := by
      rw [← hd]
      unfold chiB gK l1 l2 l3 l4
      simp only [p23, ev2_snd, ev3_snd, sgn_mul']
      simp
    unfold etaB
    simp only [if_true]
    rw [hc]
    unfold rho
    rw [sgn_mul', sgn_sigX, sgn_canU, mul_comm (ext M m k b σ x.2), ← mul_assoc, etaSign_sq, one_mul]

/-- **補題 2.3 の強い形（閉）** -/
theorem canon_holds (N : ℕ) [NeZero N] : Canon N := by
  intro M m k _ _ _ hM b F y σ t hσ
  have htot := rho_tot M m k b hM σ t hσ
  set g := gK N M m k b (rho M m k b σ t)
  refine ⟨fun j => (g • glueB N M m k b F y) j.1.1, ?_⟩
  have h1 : actB N M m k true b (etaSign M m k b t)
        (glueB N M m k b F (fun j => (g • glueB N M m k b F y) j.1.1))
      = actB N M m k true b (etaSign M m k b t) (g • glueB N M m k b F y) := by
    refine actB_local N M m k true b _ _ _ (fun ℓ hℓ => ?_) (fun ℓ hℓ hb => ?_)
    · have e1 : ∀ y0 : Inner N M m k b → SU2, glueB N M m k b F y0 ℓ = F ⟨ℓ, hℓ⟩ := by
        intro y0; unfold glueB BlockFubini.glue; rw [dif_pos hℓ]
      rw [e1, smul_one_at N M g _ ℓ (g_frame N M m k b _ ℓ hℓ), e1]
    · unfold glueB BlockFubini.glue
      rw [dif_neg hℓ, dif_pos hb]
  have h2 : actB N M m k true b (etaSign M m k b t) (g • glueB N M m k b F y)
      = actB N M m k true b (ext M m k b σ) (glueB N M m k b F y) := by
    unfold actB
    refine Finset.sum_congr rfl fun B hB => ?_
    have hb : blk2 M m k B.1.2 = b := (Finset.mem_filter.mp hB).2
    rw [hol_smul, ← chi_key N M m k b σ t B hb htot]
    ring
  rw [h1, h2]

/-- 鎖の仮定 `Canon` を払った形：太い渦の床は `LocalVortex` だけに条件つき -/
theorem thick_vortex_floor_of_local (N : ℕ) [NeZero N]
    (hL : ∀ m₀ : ℕ+, LocalVortex N m₀ (Svortex N m₀)) : ThickVortexFloor N :=
  thick_vortex_floor_of_canon_local N (canon_holds N) hL

end TwistBlocks

#print axioms TwistBlocks.canon_holds
#print axioms TwistBlocks.thick_vortex_floor_of_local
