import Blocks.ThickFloorApproxV1

/-!
# 命題 4.2 の部品（ラベルの段）：リンクの Z₂ のラベル c(λ) と、升の関係 η(P) = Π_{∂P} c

二次元の点 s・s′ の繊維 (A,B)・(A′,B′) が真空のゲージ変換 g・g′ に近く、二次元のリンク λ = (s, s′) の上の
横の N² 本 U と繊維の間の (μ,λ) の升（μ = 1,2）がほぼ平坦なら、h(a) = g(a)⁻¹ U(a) g′(a) は真空をほぼ変えない
（`stabDefect_le`）、よって定数 c(λ) ∈ {±1} に近い（`link_label`）。
升の側：四本の h が定数 c_i に近いとき、(3,4) の升の積の Re は c₁c₂c₃c₄ に近い（`plaq_label`）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem norm_unit (u : SU2) : ‖(u : ℍr)‖ = 1 := mem_sphere_zero_iff_norm.mp u.2

theorem norm_conj_sub (p q x y : SU2) :
    ‖((p * x * q : SU2) : ℍr) - ((p * y * q : SU2) : ℍr)‖ = ‖(x : ℍr) - (y : ℍr)‖ := by
  simp only [Metric.unitSphere.coe_mul]
  rw [show (p : ℍr) * x * q - p * y * q = p * (x - y) * q by noncomm_ring, norm_mul, norm_mul,
    norm_unit, norm_unit, one_mul, mul_one]

theorem norm_lmul_sub (u x y : SU2) :
    ‖((u * x : SU2) : ℍr) - ((u * y : SU2) : ℍr)‖ = ‖(x : ℍr) - (y : ℍr)‖ := by
  simp only [Metric.unitSphere.coe_mul]
  rw [show (u : ℍr) * x - u * y = u * (x - y) by noncomm_ring, norm_mul, norm_unit, one_mul]

theorem norm_rmul_sub (u x y : SU2) :
    ‖((x * u : SU2) : ℍr) - ((y * u : SU2) : ℍr)‖ = ‖(x : ℍr) - (y : ℍr)‖ := by
  simp only [Metric.unitSphere.coe_mul]
  rw [show (x : ℍr) * u - y * u = (x - y) * u by noncomm_ring, norm_mul, norm_unit, mul_one]

/-- 一本の項の評価（群の元で） -/
theorem link_term (ga gb ga' gb' u u' A A' V : SU2) :
    ‖(((ga⁻¹ * u * ga') * V * (gb⁻¹ * u' * gb')⁻¹ : SU2) : ℍr) - (V : ℍr)‖
      ≤ ‖((A * u' : SU2) : ℍr) - ((u * A' : SU2) : ℍr)‖
        + ‖(A : ℍr) - ((ga * V * gb⁻¹ : SU2) : ℍr)‖ + ‖(A' : ℍr) - ((ga' * V * gb'⁻¹ : SU2) : ℍr)‖ := by
  have e := norm_conj_sub ga (gb⁻¹ * u') ((ga⁻¹ * u * ga') * V * (gb⁻¹ * u' * gb')⁻¹) V
  have e1 : ga * ((ga⁻¹ * u * ga') * V * (gb⁻¹ * u' * gb')⁻¹) * (gb⁻¹ * u') = u * (ga' * V * gb'⁻¹) := by
    group
  have e2 : ga * V * (gb⁻¹ * u') = (ga * V * gb⁻¹) * u' := by group
  rw [e1, e2] at e
  rw [← e]
  set X := ga' * V * gb'⁻¹
  set Y := ga * V * gb⁻¹
  calc ‖((u * X : SU2) : ℍr) - ((Y * u' : SU2) : ℍr)‖
      ≤ ‖((u * X : SU2) : ℍr) - ((u * A' : SU2) : ℍr)‖ + ‖((u * A' : SU2) : ℍr) - ((A * u' : SU2) : ℍr)‖
        + ‖((A * u' : SU2) : ℍr) - ((Y * u' : SU2) : ℍr)‖ := by
        have t1 := norm_sub_le_norm_sub_add_norm_sub ((u * X : SU2) : ℍr) ((u * A' : SU2) : ℍr)
          ((Y * u' : SU2) : ℍr)
        have t2 := norm_sub_le_norm_sub_add_norm_sub ((u * A' : SU2) : ℍr) ((A * u' : SU2) : ℍr)
          ((Y * u' : SU2) : ℍr)
        linarith
    _ = ‖(X : ℍr) - (A' : ℍr)‖ + ‖((A * u' : SU2) : ℍr) - ((u * A' : SU2) : ℍr)‖ + ‖(A : ℍr) - (Y : ℍr)‖ := by
        rw [norm_lmul_sub, norm_rmul_sub, norm_sub_rev ((u * A' : SU2) : ℍr)]
    _ = _ := by rw [norm_sub_rev (X : ℍr)]; ring

variable (N : ℕ) [NeZero N]

/-- 繊維とリンクの間の (μ,λ) の升の平坦さからの欠け -/
noncomputable def linkDef (p p' : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2))
    (U : ZMod N × ZMod N → SU2) : ℝ :=
  ∑ a, (‖((p.1 a * U (a + ev12 N 0) : SU2) : ℍr) - ((U a * p'.1 a : SU2) : ℍr)‖
    + ‖((p.2 a * U (a + ev12 N 1) : SU2) : ℍr) - ((U a * p'.2 a : SU2) : ℍr)‖)

/-- **リンクの段**：`stabDefect (g⁻¹ U g′) ≤ linkDef + fibDist p g + fibDist p′ g′` -/
theorem stabDefect_le (p p' : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2))
    (U g g' : ZMod N × ZMod N → SU2) :
    stabDefect N (fun a => (g a)⁻¹ * U a * g' a) ≤ linkDef N p p' U + fibDist N p g + fibDist N p' g' := by
  unfold stabDefect linkDef fibDist
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  refine Finset.sum_le_sum fun a _ => ?_
  have h1 := link_term (g a) (g (a + ev12 N 0)) (g' a) (g' (a + ev12 N 0)) (U a) (U (a + ev12 N 0))
    (p.1 a) (p'.1 a) (AV N a)
  have h2 := link_term (g a) (g (a + ev12 N 1)) (g' a) (g' (a + ev12 N 1)) (U a) (U (a + ev12 N 1))
    (p.2 a) (p'.2 a) (BV N a)
  linarith

/-- **リンクのラベル**：全ての ε > 0 に δ > 0（N と ε だけに依る）があって、偏り・欠けが δ 未満なら
`g⁻¹ U g′` は定数 1 か定数 −1 に ε 近い -/
theorem link_label : ∀ ε > 0, ∃ δ > 0, ∀ (p p' : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2))
    (U g g' : ZMod N × ZMod N → SU2), fibDist N p g < δ → fibDist N p' g' < δ → linkDef N p p' U < δ →
    distPM N (fun a => (g a)⁻¹ * U a * g' a) < ε := by
  intro ε hε
  obtain ⟨δS, hδS, hS⟩ := stab_vacT_approx N ε hε
  refine ⟨δS / 3, by positivity, fun p p' U g g' h1 h2 h3 => hS _ ?_⟩
  have := stabDefect_le N p p' U g g'
  linarith

/-- **升のラベル**：四本の単位四元数 h_i が c_i ∈ {±1} に ε 近く、η c₁c₂c₃c₄ = −1 なら、
共役した積の作用 `1 − η Re(x h₁h₂h₃*h₄* x*)` は 2 − 4ε 以上 -/
theorem plaq_label (x h1 h2 h3 h4 : SU2) (c1 c2 c3 c4 η : ℝ)
    (hc : ∀ c ∈ ({c1, c2, c3, c4} : Set ℝ), c = 1 ∨ c = -1) (hη : η = 1 ∨ η = -1)
    (ε : ℝ) (e1 : ‖(h1 : ℍr) - c1‖ ≤ ε) (e2 : ‖(h2 : ℍr) - c2‖ ≤ ε) (e3 : ‖(h3 : ℍr) - c3‖ ≤ ε)
    (e4 : ‖(h4 : ℍr) - c4‖ ≤ ε) (hs : η * (c1 * c2 * c3 * c4) = -1) :
    2 - 4 * ε ≤ 1 - η * ((x : ℍr) * ((h1 : ℍr) * h2 * star (h3 : ℍr) * star (h4 : ℍr)) * star (x : ℍr)).re := by
  have hu : ∀ c : ℝ, c = 1 ∨ c = -1 → ‖((c : ℝ) : ℍr)‖ = 1 := by
    rintro c (rfl | rfl) <;> simp
  have n1 := hu c1 (hc c1 (by simp)); have n2 := hu c2 (hc c2 (by simp))
  have n3 := hu c3 (hc c3 (by simp)); have n4 := hu c4 (hc c4 (by simp))
  -- 共役で Re は変わらない
  have hre : ((x : ℍr) * ((h1 : ℍr) * h2 * star (h3 : ℍr) * star (h4 : ℍr)) * star (x : ℍr)).re
      = ((h1 : ℍr) * h2 * star (h3 : ℍr) * star (h4 : ℍr)).re := by
    rw [re_mul_comm', ← mul_assoc, Quaternion.star_mul_self, normSq_unit]; simp
  rw [hre]
  -- 積と c の積の差
  set q := (h1 : ℍr) * h2 * star (h3 : ℍr) * star (h4 : ℍr)
  set c : ℍr := ((c1 : ℝ) : ℍr) * (c2 : ℝ) * star ((c3 : ℝ) : ℍr) * star ((c4 : ℝ) : ℍr)
  have hcq : ‖q - c‖ ≤ 4 * ε := by
    have s3 : ‖star (h3 : ℍr) - star ((c3 : ℝ) : ℍr)‖ ≤ ε := by rw [← star_sub, norm_star]; exact e3
    have s4 : ‖star (h4 : ℍr) - star ((c4 : ℝ) : ℍr)‖ ≤ ε := by rw [← star_sub, norm_star]; exact e4
    have k1 := norm_unit h1; have k2 := norm_unit h2
    have k3 : ‖star (h3 : ℍr)‖ = 1 := by rw [norm_star]; exact norm_unit h3
    have k4 : ‖star (h4 : ℍr)‖ = 1 := by rw [norm_star]; exact norm_unit h4
    have m3 : ‖star ((c3 : ℝ) : ℍr)‖ = 1 := by rw [norm_star]; exact n3
    have m4 : ‖star ((c4 : ℝ) : ℍr)‖ = 1 := by rw [norm_star]; exact n4
    have key : ∀ (a b a' b' : ℍr), ‖a‖ ≤ 1 → ‖b'‖ ≤ 1 → ‖a * b - a' * b'‖ ≤ ‖a - a'‖ + ‖b - b'‖ := by
      intro a b a' b' ha hb'
      have : a * b - a' * b' = (a - a') * b' + a * (b - b') := by noncomm_ring
      rw [this]
      refine (norm_add_le _ _).trans (add_le_add ?_ ?_)
      · rw [norm_mul]
        exact mul_le_of_le_one_right (norm_nonneg (a - a')) hb'
      · rw [norm_mul]
        exact mul_le_of_le_one_left (norm_nonneg (b - b')) ha
    have p123 := key ((h1 : ℍr) * h2) (star (h3 : ℍr)) (((c1 : ℝ) : ℍr) * ((c2 : ℝ) : ℍr))
      (star ((c3 : ℝ) : ℍr)) (by rw [norm_mul, k1, k2, one_mul]) m3.le
    have p12 := key (h1 : ℍr) (h2 : ℍr) ((c1 : ℝ) : ℍr) ((c2 : ℝ) : ℍr) k1.le n2.le
    have p1234 := key ((h1 : ℍr) * h2 * star (h3 : ℍr)) (star (h4 : ℍr))
      (((c1 : ℝ) : ℍr) * ((c2 : ℝ) : ℍr) * star ((c3 : ℝ) : ℍr)) (star ((c4 : ℝ) : ℍr))
      (by rw [norm_mul, norm_mul, k1, k2, k3]; norm_num) m4.le
    simp only [q, c]
    linarith
  have hcre : c.re = c1 * c2 * c3 * c4 := by
    simp only [c, Quaternion.star_coe, ← Quaternion.coe_mul, Quaternion.re_coe]
  have absre : ∀ r : ℍr, |r.re| ≤ ‖r‖ := by
    intro r
    have h : r.re ^ 2 ≤ ‖r‖ ^ 2 := by
      rw [sq, sq, ← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
      nlinarith [sq_nonneg r.imI, sq_nonneg r.imJ, sq_nonneg r.imK]
    calc |r.re| = Real.sqrt (r.re ^ 2) := (Real.sqrt_sq_eq_abs _).symm
      _ ≤ Real.sqrt (‖r‖ ^ 2) := Real.sqrt_le_sqrt h
      _ = ‖r‖ := Real.sqrt_sq (norm_nonneg _)
  have hre_le : |q.re - c.re| ≤ 4 * ε := by
    rw [← Quaternion.re_sub]
    exact (absre _).trans hcq
  rw [hcre] at hre_le
  rcases hη with rfl | rfl
  · have := abs_le.mp hre_le; nlinarith
  · have := abs_le.mp hre_le; nlinarith

end TwistBlocks

#print axioms TwistBlocks.link_label
#print axioms TwistBlocks.plaq_label
