import Blocks.ThickFloorGridV1

/-!
# S_N > 0（太い渦の床の紙の命題 4.2）：S_渦(N, m) は m に一様に正

`Svortex N m`（格子 (ZMod N)² × (ZMod 2m)²、塊 [0,m)²、枠を捩れた真空 V に止め、角の (3,4) の升を
N² 枚反転した最小作用）の任意の内部の配位 ω について、二次元の点 (i,j)（i,j ≤ m）の繊維 `Fx`、
向き 3・4 のリンク `Hx`・`Vx`、角だけ −1 の `ηx` を取り出し、`grid_vortex_floor` に入れる。
繊維・升の部品は塊の作用の部分和（`fib_eq`・`plaq_eq`・`sum_le_actB`）、リンクの部品は
‖X − Y‖ = √(2(1 − Re XY*)) で塊の作用の平方根で抑える（`linkH_le`・`linkV_le`）。
枠の上の値は真空（`frame_val`）。結論：N だけに依る δ > 0 で δ ≤ S_渦(N, m)（全ての m ≥ 1、
**`Svortex_ge_unif`**）、よって **`SN_pos : 0 < SN N`**。δ はコンパクト性から来るので陽でない。
-/

open Finset BigOperators TwistedWilson TwistedPlane

namespace VortexPos

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (m : ℕ) [NeZero m] [NeZero (2 * m)]

/-- 格子点 (a, (i, j)) -/
def st (a : ZMod N × ZMod N) (i j : ℕ) : Site N (2 * m) := (a, ((i : ZMod (2 * m)), (j : ZMod (2 * m))))

theorem st_ev0 (a : ZMod N × ZMod N) (i j : ℕ) :
    st N m a i j + ev N (2 * m) 0 = st N m (a + TwistBlocks.ev12 N 0) i j := by
  simp [st, ev, TwistBlocks.ev12]

theorem st_ev1 (a : ZMod N × ZMod N) (i j : ℕ) :
    st N m a i j + ev N (2 * m) 1 = st N m (a + TwistBlocks.ev12 N 1) i j := by
  simp [st, ev, TwistBlocks.ev12]

theorem st_ev2 (a : ZMod N × ZMod N) (i j : ℕ) : st N m a i j + ev N (2 * m) 2 = st N m a (i + 1) j := by
  simp [st, ev]

theorem st_ev3 (a : ZMod N × ZMod N) (i j : ℕ) : st N m a i j + ev N (2 * m) 3 = st N m a i (j + 1) := by
  simp [st, ev]

theorem val_cast_le (i : ℕ) (hi : i ≤ m) : ((i : ZMod (2 * m))).val = i := by
  have := NeZero.ne m
  exact ZMod.val_cast_of_lt (by omega)

theorem onLine_end (i : ℕ) (hi : i = 0 ∨ i = m) : TwistBlocks.onLine (2 * m) m 2 (i : ZMod (2 * m)) := by
  have hm := NeZero.ne m
  unfold TwistBlocks.onLine
  rw [val_cast_le m i (by omega)]
  rcases hi with rfl | rfl
  · exact ⟨Nat.zero_mod _, by omega⟩
  · exact ⟨Nat.mod_self _, by omega⟩

open TwistBlocks in
/-- 枠の上の値 -/
theorem frame_val (ω : Link N (2 * m) → SU2) (hω : ∀ ℓ, fr N (2 * m) m 2 ℓ → ω ℓ = vac N (2 * m) ℓ)
    (a : ZMod N × ZMod N) (i j : ℕ) (hi : i ≤ m) (hj : j ≤ m) :
    ((i = 0 ∨ i = m ∨ j = 0 ∨ j = m) → ω (st N m a i j, 0) = AV N a ∧ ω (st N m a i j, 1) = BV N a) ∧
    ((j = 0 ∨ j = m) → ω (st N m a i j, 2) = 1) ∧ ((i = 0 ∨ i = m) → ω (st N m a i j, 3) = 1) := by
  refine ⟨fun h => ⟨?_, ?_⟩, fun h => ?_, fun h => ?_⟩
  · rw [hω _ ?_]
    · simp [vac, st, AV]
    · simp only [fr, st]
      rcases h with h | h | h | h
      · exact Or.inl (onLine_end m i (Or.inl h))
      · exact Or.inl (onLine_end m i (Or.inr h))
      · exact Or.inr (onLine_end m j (Or.inl h))
      · exact Or.inr (onLine_end m j (Or.inr h))
  · rw [hω _ ?_]
    · simp [vac, st, BV]
    · simp only [fr, st]
      rcases h with h | h | h | h
      · exact Or.inl (onLine_end m i (Or.inl h))
      · exact Or.inl (onLine_end m i (Or.inr h))
      · exact Or.inr (onLine_end m j (Or.inl h))
      · exact Or.inr (onLine_end m j (Or.inr h))
  · rw [hω _ ?_]
    · simp [vac, st]
    · simp only [fr, st, if_true]; exact onLine_end m j h
  · rw [hω _ ?_]
    · simp [vac, st]
    · simp only [fr, st]; exact onLine_end m i h

open TwistBlocks in
theorem blk_st (a : ZMod N × ZMod N) (i j : ℕ) (hi : i < m) (hj : j < m) :
    blk2 (2 * m) m 2 (st N m a i j).2 = (0, 0) := by
  simp only [st, blk2]
  refine Prod.ext (Fin.ext ?_) (Fin.ext ?_)
  · show min (((i : ZMod (2 * m))).val / m) (2 - 1) = 0
    rw [val_cast_le m i hi.le, Nat.div_eq_of_lt hi]; simp
  · show min (((j : ZMod (2 * m))).val / m) (2 - 1) = 0
    rw [val_cast_le m j hj.le, Nat.div_eq_of_lt hj]; simp

variable {N m}

open TwistBlocks in
/-- 塊の作用の項 -/
noncomputable def tB (ω : Link N (2 * m) → SU2) (B : Plaq N (2 * m)) : ℝ :=
  1 - zt N (2 * m) true false B * etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) B * (hol N (2 * m) ω B).re

open TwistBlocks in
theorem tB_nonneg (ω : Link N (2 * m) → SU2) (B : Plaq N (2 * m)) : 0 ≤ tB ω B :=
  (actB_term_bounds N (2 * m) true _ (abs_etaSign_le (2 * m) m 2 (0, 0) true) ω B).1

open TwistBlocks in
/-- 塊の中の升の族の和は塊の作用以下 -/
theorem sum_le_actB (ω : Link N (2 * m) → SU2) (i j : ℕ) (hi : i < m) (hj : j < m) (P : Plane) :
    ∑ a, tB ω (st N m a i j, P) ≤ actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true) ω := by
  have hinj : Function.Injective fun a : ZMod N × ZMod N => ((st N m a i j, P) : Plaq N (2 * m)) := by
    intro a b h
    have := congrArg (fun B : Plaq N (2 * m) => B.1.1) h
    simpa [st] using this
  rw [← Finset.sum_image (f := tB ω) (fun a _ b _ h => hinj h)]
  unfold actB
  refine Finset.sum_le_sum_of_subset_of_nonneg ?_ (fun B _ _ => tB_nonneg ω B)
  intro B hB
  obtain ⟨a, _, rfl⟩ := Finset.mem_image.mp hB
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  exact blk_st N m a i j hi hj

variable (N m)

open TwistBlocks in
noncomputable def Fx (ω : Link N (2 * m) → SU2) (i j : ℕ) :
    (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2) :=
  if i ≤ m ∧ j ≤ m then (fun a => ω (st N m a i j, 0), fun a => ω (st N m a i j, 1)) else vacF N

noncomputable def Hx (ω : Link N (2 * m) → SU2) (i j : ℕ) : ZMod N × ZMod N → SU2 :=
  fun a => if i ≤ m ∧ j ≤ m then ω (st N m a i j, 2) else 1

noncomputable def Vx (ω : Link N (2 * m) → SU2) (i j : ℕ) : ZMod N × ZMod N → SU2 :=
  fun a => if i ≤ m ∧ j ≤ m then ω (st N m a i j, 3) else 1

/-- 角の一枚だけ −1 -/
noncomputable def ηx (i j : ℕ) : ℝ := if i = 0 ∧ j = 0 then -1 else 1

def P02 : Plane := ⟨(0, 2), by decide⟩
def P12 : Plane := ⟨(1, 2), by decide⟩
def P03 : Plane := ⟨(0, 3), by decide⟩
def P13 : Plane := ⟨(1, 3), by decide⟩

open TwistBlocks in
theorem fib_eq (ω : Link N (2 * m) → SU2) (i j : ℕ) (hi : i < m) (hj : j < m) :
    fibAct N (Fx N m ω i j) = ∑ a, tB ω (st N m a i j, p01) := by
  unfold fibAct
  rw [Fx, if_pos ⟨hi.le, hj.le⟩]
  refine Finset.sum_congr rfl fun a _ => ?_
  have hz : zt N (2 * m) true false (st N m a i j, p01) = twT N a := by
    simp [zt, twT, tw, p01, p23, st]
  have he : etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) (st N m a i j, p01) = 1 := by
    simp [etaB, p01, p23]
  have hh : hol N (2 * m) ω (st N m a i j, p01)
      = holT N (fun a => ω (st N m a i j, 0)) (fun a => ω (st N m a i j, 1)) a := by
    simp only [hol, holT, l1, l2, l3, l4, p01]
    rw [st_ev0, st_ev1]
  unfold tB
  rw [hz, he, hh, mul_one]

open TwistBlocks in
theorem plaq_eq (ω : Link N (2 * m) → SU2) (i j : ℕ) (hi : i < m) (hj : j < m) :
    plaqAct N (Hx N m ω i j) (Vx N m ω (i + 1) j) (Hx N m ω i (j + 1)) (Vx N m ω i j) (ηx i j)
      = ∑ a, tB ω (st N m a i j, p23) := by
  unfold plaqAct
  refine Finset.sum_congr rfl fun a _ => ?_
  have hz : zt N (2 * m) true false (st N m a i j, p23) = 1 := by
    simp [zt, tw, p01, p23]
  have he : etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) (st N m a i j, p23) = ηx i j := by
    have hc : corner (2 * m) m 2 (0, 0) = (0, 0) := by simp [corner]
    have hcast : ((i : ZMod (2 * m)), (j : ZMod (2 * m))) = (0, 0) ↔ i = 0 ∧ j = 0 := by
      constructor
      · intro h
        have h1 := congrArg (fun p : ZMod (2 * m) × ZMod (2 * m) => p.1.val) h
        have h2 := congrArg (fun p : ZMod (2 * m) × ZMod (2 * m) => p.2.val) h
        simp only [ZMod.val_zero] at h1 h2
        rw [val_cast_le m i hi.le] at h1; rw [val_cast_le m j hj.le] at h2
        exact ⟨h1, h2⟩
      · rintro ⟨rfl, rfl⟩; simp
    simp only [etaB, p23, if_true, etaSign, etaAt, hc, st, ηx]
    by_cases h : i = 0 ∧ j = 0
    · rw [if_pos (hcast.mpr h), if_pos h]
    · rw [if_neg (fun e => h (hcast.mp e)), if_neg h]
  have hh : hol N (2 * m) ω (st N m a i j, p23)
      = (Hx N m ω i j a : ℍr) * (Vx N m ω (i + 1) j a : ℍr) * star (Hx N m ω i (j + 1) a : ℍr)
        * star (Vx N m ω i j a : ℍr) := by
    simp only [hol, l1, l2, l3, l4, p23, Hx, Vx]
    rw [st_ev2, st_ev3, if_pos ⟨hi.le, hj.le⟩, if_pos ⟨hi, hj.le⟩, if_pos ⟨hi.le, hj⟩, if_pos ⟨hi.le, hj.le⟩]
  unfold tB
  rw [hz, he, hh, one_mul]

theorem norm_eq_sqrt (X Y : ℍr) (hX : ‖X‖ = 1) (hY : ‖Y‖ = 1) :
    ‖X - Y‖ = Real.sqrt (2 * (1 - (X * star Y).re)) := by
  rw [← TwistBlocks.norm_sub_sq_unit X Y hX hY, Real.sqrt_sq (norm_nonneg _)]

open TwistBlocks in
theorem linkH_le (ω : Link N (2 * m) → SU2) (i j : ℕ) (hi : i < m) (hj : j < m) :
    linkDef N (Fx N m ω i j) (Fx N m ω (i + 1) j) (Hx N m ω i j)
      ≤ ∑ a, (Real.sqrt (2 * tB ω (st N m a i j, P02)) + Real.sqrt (2 * tB ω (st N m a i j, P12))) := by
  unfold linkDef
  refine le_of_eq (Finset.sum_congr rfl fun a _ => ?_)
  rw [Fx, Fx, if_pos ⟨hi.le, hj.le⟩, if_pos ⟨hi, hj.le⟩]
  simp only [Hx, if_pos (And.intro hi.le hj.le), Metric.unitSphere.coe_mul]
  have hz : ∀ P : Plane, P ≠ p01 → P ≠ p23 →
      tB ω (st N m a i j, P) = 1 - (hol N (2 * m) ω (st N m a i j, P)).re := by
    intro P h1 h2
    simp [tB, zt, etaB, h1, h2]
  rw [hz P02 (by decide) (by decide), hz P12 (by decide) (by decide)]
  congr 1
  · rw [norm_eq_sqrt _ _ (by simp [norm_unit]) (by simp [norm_unit])]
    congr 3
    simp only [hol, l1, l2, l3, l4, P02]
    rw [st_ev0, st_ev2, star_mul]; simp only [mul_assoc]
  · rw [norm_eq_sqrt _ _ (by simp [norm_unit]) (by simp [norm_unit])]
    congr 3
    simp only [hol, l1, l2, l3, l4, P12]
    rw [st_ev1, st_ev2, star_mul]; simp only [mul_assoc]

open TwistBlocks in
theorem linkV_le (ω : Link N (2 * m) → SU2) (i j : ℕ) (hi : i < m) (hj : j < m) :
    linkDef N (Fx N m ω i j) (Fx N m ω i (j + 1)) (Vx N m ω i j)
      ≤ ∑ a, (Real.sqrt (2 * tB ω (st N m a i j, P03)) + Real.sqrt (2 * tB ω (st N m a i j, P13))) := by
  unfold linkDef
  refine le_of_eq (Finset.sum_congr rfl fun a _ => ?_)
  rw [Fx, Fx, if_pos ⟨hi.le, hj.le⟩, if_pos ⟨hi.le, hj⟩]
  simp only [Vx, if_pos (And.intro hi.le hj.le), Metric.unitSphere.coe_mul]
  have hz : ∀ P : Plane, P ≠ p01 → P ≠ p23 →
      tB ω (st N m a i j, P) = 1 - (hol N (2 * m) ω (st N m a i j, P)).re := by
    intro P h1 h2
    simp [tB, zt, etaB, h1, h2]
  rw [hz P03 (by decide) (by decide), hz P13 (by decide) (by decide)]
  congr 1
  · rw [norm_eq_sqrt _ _ (by simp [norm_unit]) (by simp [norm_unit])]
    congr 3
    simp only [hol, l1, l2, l3, l4, P03]
    rw [st_ev0, st_ev3, star_mul]; simp only [mul_assoc]
  · rw [norm_eq_sqrt _ _ (by simp [norm_unit]) (by simp [norm_unit])]
    congr 3
    simp only [hol, l1, l2, l3, l4, P13]
    rw [st_ev1, st_ev3, star_mul]; simp only [mul_assoc]

open TwistBlocks in
theorem fibAct_vac : fibAct N (vacF N) = 0 := by
  unfold fibAct vacF
  refine Finset.sum_eq_zero fun a _ => ?_
  have h := flatV N a
  simp only [holT]
  rw [h]
  unfold twT; split_ifs <;> simp <;> (show (1 : ℝ) - 1 = 0; norm_num)

open TwistBlocks in
theorem linkDef_vac : linkDef N (vacF N) (vacF N) (fun _ => 1) = 0 := by
  unfold linkDef vacF; simp

open TwistBlocks in
/-- **S_渦 は m に一様に正**（命題 4.2）：N だけに依る δ > 0 で、全ての m ≥ 1 で δ ≤ S_渦(N, m) -/
theorem Svortex_ge_unif : ∃ δ > 0, ∀ (m : ℕ) [NeZero m], δ ≤ Svortex N m := by
  obtain ⟨δ₀, hδ₀, hG⟩ := grid_vortex_floor N
  set C : ℝ := (Fintype.card (ZMod N × ZMod N) : ℝ)
  have hC : 0 ≤ C := Nat.cast_nonneg _
  set δ := min δ₀ (δ₀ ^ 2 / (32 * C ^ 2 + 1)) with hδ
  have hδpos : 0 < δ := lt_min hδ₀ (by positivity)
  refine ⟨δ, hδpos, fun m _ => ?_⟩
  have : NeZero (2 * m) := ⟨by have := NeZero.ne m; omega⟩
  have hm : 0 < m := Nat.pos_of_ne_zero (NeZero.ne m)
  unfold Svortex Smin
  refine le_ciInf fun y => ?_
  set ω := glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) y
  have hω : ∀ ℓ, fr N (2 * m) m 2 ℓ → ω ℓ = vac N (2 * m) ℓ := by
    intro ℓ h
    simp only [ω, glueB, BlockFubini.glue, dif_pos h]
  set S := actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true) ω
  by_contra hS
  push_neg at hS
  have hSnn : 0 ≤ S := actB_nonneg N (2 * m) m 2 true (0, 0) _ (abs_etaSign_le (2 * m) m 2 (0, 0) true) ω
  -- 平方根の評価
  have hsq : ∀ t, 0 ≤ t → t ≤ S → Real.sqrt (2 * t) ≤ Real.sqrt (2 * S) :=
    fun t _ ht => Real.sqrt_le_sqrt (by linarith)
  have hlink : 2 * C * Real.sqrt (2 * S) < δ₀ := by
    have h1 : (2 * C * Real.sqrt (2 * S)) ^ 2 = 8 * C ^ 2 * S := by
      rw [mul_pow, Real.sq_sqrt (by linarith)]; ring
    have h2 : 8 * C ^ 2 * S < δ₀ ^ 2 := by
      have h3 : S < δ₀ ^ 2 / (32 * C ^ 2 + 1) := lt_of_lt_of_le hS (min_le_right _ _)
      rw [lt_div_iff₀ (by positivity)] at h3
      nlinarith [sq_nonneg C]
    have h4 : 0 ≤ 2 * C * Real.sqrt (2 * S) := by positivity
    nlinarith [sq_nonneg (2 * C * Real.sqrt (2 * S) - δ₀)]
  have hlink_le : ∀ (P Q : Plane) (i j : ℕ), i < m → j < m →
      ∑ a, (Real.sqrt (2 * tB ω (st N m a i j, P)) + Real.sqrt (2 * tB ω (st N m a i j, Q)))
        ≤ 2 * C * Real.sqrt (2 * S) := by
    intro P Q i j hi hj
    have hP := sum_le_actB ω i j hi hj P
    have hQ := sum_le_actB ω i j hi hj Q
    calc ∑ a, (Real.sqrt (2 * tB ω (st N m a i j, P)) + Real.sqrt (2 * tB ω (st N m a i j, Q)))
        ≤ ∑ _a : ZMod N × ZMod N, (Real.sqrt (2 * S) + Real.sqrt (2 * S)) := by
          refine Finset.sum_le_sum fun a _ => add_le_add ?_ ?_
          · exact hsq _ (tB_nonneg ω _) (le_trans (Finset.single_le_sum
              (f := fun a => tB ω (st N m a i j, P)) (fun a _ => tB_nonneg ω _) (Finset.mem_univ a)) hP)
          · exact hsq _ (tB_nonneg ω _) (le_trans (Finset.single_le_sum
              (f := fun a => tB ω (st N m a i j, Q)) (fun a _ => tB_nonneg ω _) (Finset.mem_univ a)) hQ)
      _ = 2 * C * Real.sqrt (2 * S) := by
          rw [Finset.sum_const, nsmul_eq_mul]; simp only [C, Finset.card_univ]; ring
  -- 格子の仮定
  have hbF : ∀ i j, bdG m i j → Fx N m ω i j = vacF N := by
    intro i j hb
    unfold Fx
    split_ifs with hr
    · have hb' : i = 0 ∨ i = m ∨ j = 0 ∨ j = m := by unfold bdG at hb; omega
      unfold vacF
      refine Prod.ext (funext fun a => ?_) (funext fun a => ?_)
      · exact ((frame_val N m ω hω a i j hr.1 hr.2).1 hb').1
      · exact ((frame_val N m ω hω a i j hr.1 hr.2).1 hb').2
    · rfl
  have hH0 : ∀ i a, Hx N m ω i 0 a = 1 := by
    intro i a; unfold Hx; split_ifs with hr
    · exact (frame_val N m ω hω a i 0 hr.1 hr.2).2.1 (Or.inl rfl)
    · rfl
  have hHm : ∀ i a, Hx N m ω i m a = 1 := by
    intro i a; unfold Hx; split_ifs with hr
    · exact (frame_val N m ω hω a i m hr.1 hr.2).2.1 (Or.inr rfl)
    · rfl
  have hV0 : ∀ j a, Vx N m ω 0 j a = 1 := by
    intro j a; unfold Vx; split_ifs with hr
    · exact (frame_val N m ω hω a 0 j hr.1 hr.2).2.2 (Or.inl rfl)
    · rfl
  have hVm : ∀ j a, Vx N m ω m j a = 1 := by
    intro j a; unfold Vx; split_ifs with hr
    · exact (frame_val N m ω hω a m j hr.1 hr.2).2.2 (Or.inr rfl)
    · rfl
  have hη : ∀ i j, ηx i j = 1 ∨ ηx i j = -1 := by
    intro i j; unfold ηx; split_ifs <;> simp
  have hprod : (∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m, ηx i j) = -1 := by
    have inner : ∀ i, ∏ j ∈ Finset.range m, ηx i j = if i = 0 then -1 else 1 := by
      intro i
      by_cases hi : i = 0
      · subst hi
        simp only [ηx, true_and, if_true]
        rw [Finset.prod_ite_eq' (Finset.range m) 0 (fun _ => (-1 : ℝ))]
        simp [hm]
      · simp [ηx, hi]
    rw [Finset.prod_congr rfl (fun i _ => inner i), Finset.prod_ite_eq' (Finset.range m) 0 (fun _ => (-1 : ℝ))]
    simp [hm]
  rcases hG m hm (Fx N m ω) (Hx N m ω) (Vx N m ω) ηx hbF hH0 hHm hV0 hVm hη hprod with
    ⟨i, j, hi, hj, h⟩ | ⟨i, j, hi, hj, h⟩ | ⟨i, j, hi, hj, h⟩ | ⟨i, j, hi, hj, h⟩
  · -- 繊維
    by_cases hb : bdG m i j
    · rw [hbF i j hb, fibAct_vac] at h; linarith
    · have hi' : i < m := by unfold bdG at hb; omega
      have hj' : j < m := by unfold bdG at hb; omega
      rw [fib_eq N m ω i j hi' hj'] at h
      have := sum_le_actB ω i j hi' hj' p01
      have : S < δ₀ := lt_of_lt_of_le hS (min_le_left _ _)
      linarith
  · -- 横のリンク
    by_cases hjm : j = m
    · rw [hbF i j (Or.inr (Or.inr (Or.inr hjm.symm.le))),
        hbF (i + 1) j (Or.inr (Or.inr (Or.inr hjm.symm.le)))] at h
      have e : Hx N m ω i j = fun _ => 1 := funext fun a => by rw [hjm]; exact hHm i a
      rw [e, linkDef_vac] at h; linarith
    · have hj' : j < m := lt_of_le_of_ne hj hjm
      have := (linkH_le N m ω i j hi hj').trans (hlink_le P02 P12 i j hi hj')
      linarith
  · -- 縦のリンク
    by_cases him : i = m
    · rw [hbF i j (Or.inr (Or.inr (Or.inl him.symm.le))),
        hbF i (j + 1) (Or.inr (Or.inr (Or.inl him.symm.le)))] at h
      have e : Vx N m ω i j = fun _ => 1 := funext fun a => by rw [him]; exact hVm j a
      rw [e, linkDef_vac] at h; linarith
    · have hi' : i < m := lt_of_le_of_ne hi him
      have := (linkV_le N m ω i j hi' hj).trans (hlink_le P03 P13 i j hi' hj)
      linarith
  · -- 升
    rw [plaq_eq N m ω i j hi hj] at h
    have := sum_le_actB ω i j hi hj p23
    have : S < δ₀ := lt_of_lt_of_le hS (min_le_left _ _)
    linarith

open TwistBlocks in
/-- **S_N > 0**（命題 4.2） -/
theorem SN_pos : 0 < SN N := by
  obtain ⟨δ, hδ, h⟩ := Svortex_ge_unif N
  exact lt_of_lt_of_le hδ (le_ciInf fun m => h (m : ℕ))

end VortexPos

#print axioms VortexPos.SN_pos
