import Blocks.ThickFloorTorusV1
import VortexCert.CertN4V1

/-!
# 太い渦の床の系（N = 4）：率 12.021

`thick_vortex_floor`（仮定の欄なし）と、有理数の配位の証明書 `VortexCert.SN_four_le : SN 4 ≤ 1202057/100000`
から、ε := 12021/1000 − SN 4 > 0 を取って、十分大きい β と（β ごとに）十分大きい M で
`|θ_{M+1}(β)| ≤ exp(−(M+1)² e^{−12.021 β})`。
率 12.021 は薄い渦の床の率 2N² = 32 より小さい（β → ∞ の率の比べ。β と M の閾は陽でない）。
-/

namespace TwistBlocks

theorem thick_vortex_floor_four : ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    |thetaM 4 (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (12021 / 1000))) := by
  have hS := VortexCert.SN_four_le
  have hε : (0 : ℝ) < 12021 / 1000 - SN 4 := by linarith
  have h := thick_vortex_floor 4 _ hε
  have e : SN 4 + (12021 / 1000 - SN 4) = 12021 / 1000 := by ring
  rw [e] at h
  exact h

/-- 率 12.021 は 2·4² = 32 より小さい（数の不等式） -/
theorem thick_vortex_floor_four_rate_lt : (12021 / 1000 : ℝ) < 2 * 4 ^ 2 := by norm_num

end TwistBlocks

#print axioms TwistBlocks.thick_vortex_floor_four
