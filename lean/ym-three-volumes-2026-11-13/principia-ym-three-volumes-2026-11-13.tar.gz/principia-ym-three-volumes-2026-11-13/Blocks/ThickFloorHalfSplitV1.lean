import Blocks.ThickFloorTorusV1
import Blocks.ThickFloorRPCoreV1

/-!
# 時間の向き（x₄）の鏡映による格子の半分への分け（M が偶数）

鏡映 x₄ ↦ −x₄ は x₄ = 0 と x₄ = M/2 の二枚の面を止める。
* リンクの鏡映 `thL`（向き 4 のリンク (x,4) は (r(x+e₄),4) へ、値は逆元 `sgL`）、
  面の上のリンク `fixL`（向き 1・2・3、x₄ ∈ {0, M/2}）、正の側 `posL`。
* 升の鏡映 `rhoP` と升の重み `cw`（上の半分 1、面の上 ½、下 0）：`cw B + cw (rhoP B) = 1`。
* `re_hol_refl`：Re U_B(Θω) = Re U_{ρB}(ω)。
* **`half_split`**：重み exp(β Σ_B z_B η_B Re U_B) は a_{η₁}(ω)·a_{η₂}(Θω) に割れる
  （η = `glueEta η₁ η₂`、a は閉じた上の半分のリンクだけに依る：`halfW_dep`）。
* **`half_pairing_nonneg`**：閉じた上の半分のリンクだけに依る有界可測な g について 0 ≤ ∫ g(Θω) g(ω)。
-/

open Finset MeasureTheory TwistedWilson TwistedPlane

namespace HalfSplit

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-! ## ZMod の値の算術 -/

theorem val_neg_eq (a : ZMod M) : (-a).val = if a.val = 0 then 0 else M - a.val := by
  rw [ZMod.neg_val]
  by_cases h : a = 0
  · simp [h]
  · have : a.val ≠ 0 := fun h' => h ((ZMod.val_eq_zero a).mp h')
    simp [h, this]

theorem val_add_one_eq (a : ZMod M) : (a + 1).val = if a.val + 1 = M then 0 else a.val + 1 := by
  have hlt := ZMod.val_lt a
  rw [ZMod.val_add, ZMod.val_one_eq_one_mod]
  rcases Nat.lt_or_ge 1 M with h | h
  · rw [Nat.mod_eq_of_lt h]
    by_cases h2 : a.val + 1 = M
    · rw [if_pos h2, h2, Nat.mod_self]
    · rw [if_neg h2]; exact Nat.mod_eq_of_lt (by omega)
  · have h1 : M = 1 := by have := NeZero.ne M; omega
    subst h1
    have ha : a.val = 0 := by omega
    simp [ha]

theorem val_neg_add_one (a : ZMod M) : (-(a + 1)).val = M - 1 - a.val := by
  have hlt := ZMod.val_lt a
  rw [val_neg_eq, val_add_one_eq]
  by_cases h : a.val + 1 = M
  · rw [if_pos h, if_pos rfl]; omega
  · rw [if_neg h, if_neg (by omega)]; omega

/-! ## 鏡映 -/

/-- 格子点の鏡映 x₄ ↦ −x₄ -/
def rS (x : Site N M) : Site N M := (x.1, (x.2.1, -x.2.2))

/-- リンクの鏡映 -/
def thL (ℓ : Link N M) : Link N M :=
  if ℓ.2 = 3 then (rS N M (ℓ.1 + ev N M 3), 3) else (rS N M ℓ.1, ℓ.2)

/-- 値の写像：向き 4 のリンクは逆元 -/
noncomputable def sgL (ℓ : Link N M) : SU2 → SU2 := if ℓ.2 = 3 then Inv.inv else id

/-- 二枚の面（x₄ = 0、x₄ = M/2）の上の、向き 1・2・3 のリンク -/
abbrev fixL (ℓ : Link N M) : Prop := ℓ.2 ≠ 3 ∧ (ℓ.1.2.2.val = 0 ∨ 2 * ℓ.1.2.2.val = M)

/-- 正の側：0 < x₄ < M/2 の向き 1・2・3 のリンクと、0 ≤ x₄ < M/2 から出る向き 4 のリンク -/
abbrev posL (ℓ : Link N M) : Prop :=
  (ℓ.2 ≠ 3 ∧ 0 < ℓ.1.2.2.val ∧ 2 * ℓ.1.2.2.val < M) ∨ (ℓ.2 = 3 ∧ 2 * ℓ.1.2.2.val < M)

instance : DecidablePred (fixL N M) := fun ℓ => by unfold fixL; infer_instance
instance : DecidablePred (posL N M) := fun ℓ => by unfold posL; infer_instance

theorem ev_v4 (z : Site N M) (d : Fin 4) :
    (z + ev N M d).2.2 = if d = 3 then z.2.2 + 1 else z.2.2 := by
  fin_cases d <;> simp [ev]

theorem rS_add_ev (z : Site N M) (d : Fin 4) (hd : d ≠ 3) :
    rS N M (z + ev N M d) = rS N M z + ev N M d := by
  obtain ⟨⟨a, b⟩, ⟨c, e⟩⟩ := z
  fin_cases d
  · simp [rS, ev]
  · simp [rS, ev]
  · simp [rS, ev]
  · exact absurd rfl hd

theorem rS_eq (z : Site N M) : rS N M z = rS N M (z + ev N M 3) + ev N M 3 := by
  obtain ⟨⟨a, b⟩, ⟨c, e⟩⟩ := z
  simp [rS, ev]

theorem rS_eq2 (z : Site N M) (d : Fin 4) (hd : d ≠ 3) :
    rS N M (z + ev N M d + ev N M 3) = rS N M (z + ev N M 3) + ev N M d := by
  rw [add_right_comm, rS_add_ev N M _ d hd]

theorem rS_rS (z : Site N M) : rS N M (rS N M z) = z := by
  obtain ⟨⟨a, b⟩, ⟨c, e⟩⟩ := z
  simp [rS]

theorem rS_rS3 (z : Site N M) : rS N M (rS N M (z + ev N M 3) + ev N M 3) = z := by
  rw [← rS_eq, rS_rS]

theorem thL_invol : Function.Involutive (thL N M) := by
  intro ℓ
  obtain ⟨x, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd; simp [thL, rS_rS3]
  · simp [thL, hd, rS_rS]

theorem thL_three (z : Site N M) : thL N M (z, 3) = (rS N M (z + ev N M 3), 3) := by
  simp [thL]

theorem thL_ne (z : Site N M) (d : Fin 4) (hd : d ≠ 3) : thL N M (z, d) = (rS N M z, d) := by
  simp [thL, hd]

theorem v4_rS (z : Site N M) : (rS N M z).2.2.val = if z.2.2.val = 0 then 0 else M - z.2.2.val := by
  simp only [rS]; exact val_neg_eq M _

theorem v4_rS3 (z : Site N M) : (rS N M (z + ev N M 3)).2.2.val = M - 1 - z.2.2.val := by
  simp only [rS, ev_v4, if_pos rfl]; exact val_neg_add_one M _

theorem fix_cond (ℓ : Link N M) (h : fixL N M ℓ) : thL N M ℓ = ℓ ∧ ∀ u, sgL N M ℓ u = u := by
  obtain ⟨x, d⟩ := ℓ
  obtain ⟨hd, hv⟩ := h
  simp only at hd hv
  refine ⟨?_, fun u => by simp [sgL, hd]⟩
  simp only [thL, hd, if_false]
  have hx : rS N M x = x := by
    obtain ⟨⟨a, b⟩, ⟨c, e⟩⟩ := x
    simp only [rS, Prod.mk.injEq, true_and]
    apply ZMod.val_injective
    have hlt := ZMod.val_lt e
    rw [val_neg_eq]
    simp only at hv
    split_ifs <;> omega
  rw [hx]

theorem pos_not_fix (ℓ : Link N M) (hp : posL N M ℓ) : ¬ fixL N M ℓ := by
  rintro ⟨h4, h5⟩
  rcases hp with ⟨h1, h2, h3⟩ | ⟨h1, h2⟩
  · omega
  · exact h4 h1

theorem pos_refl (hM : M % 2 = 0) (ℓ : Link N M) (hp : posL N M ℓ) : ¬ posL N M (thL N M ℓ) := by
  obtain ⟨x, d⟩ := ℓ
  have hlt := ZMod.val_lt x.2.2
  by_cases hd : d = 3
  · subst hd
    rw [thL_three]
    have hv := v4_rS3 N M x
    simp only [posL, ne_eq, not_true_eq_false, false_and, false_or, true_and] at hp ⊢
    omega
  · rw [thL_ne N M x d hd]
    have hv := v4_rS N M x
    simp only [posL, ne_eq, hd, not_false_eq_true, true_and, false_and, or_false] at hp ⊢
    split_ifs at hv <;> omega

theorem neg_refl (ℓ : Link N M) (hf : ¬ fixL N M ℓ) (hp : ¬ posL N M ℓ) : posL N M (thL N M ℓ) := by
  obtain ⟨x, d⟩ := ℓ
  have hlt := ZMod.val_lt x.2.2
  by_cases hd : d = 3
  · subst hd
    rw [thL_three]
    have hv := v4_rS3 N M x
    simp only [posL, ne_eq, not_true_eq_false, false_and, false_or, true_and] at hp ⊢
    omega
  · rw [thL_ne N M x d hd]
    have hv := v4_rS N M x
    simp only [posL, fixL, ne_eq, hd, not_false_eq_true, true_and, false_and, or_false] at hp hf ⊢
    split_ifs at hv <;> omega

instance : Measure.IsInvInvariant haarSU2 :=
  ⟨by show (haarProb SU2).inv = haarProb SU2; unfold haarProb
      exact ThickFloorRP.CompactHaar.haarTop_inv_eq⟩

theorem sgL_mp (ℓ : Link N M) : MeasurePreserving (sgL N M ℓ) haarSU2 haarSU2 := by
  unfold sgL
  split_ifs
  · exact Measure.measurePreserving_inv haarSU2
  · exact MeasurePreserving.id haarSU2

/-- 鏡映した配位 -/
noncomputable def Th (ω : Link N M → SU2) : Link N M → SU2 :=
  ThickFloorRP.LinkReflection.linkRefl (thL N M) (sgL N M) ω

/-! ## 升 -/

/-- 升の鏡映 -/
def rhoP (B : Plaq N M) : Plaq N M :=
  if B.2.1.2 = 3 then (rS N M (B.1 + ev N M 3), B.2) else (rS N M B.1, B.2)

theorem rhoP_invol : Function.Involutive (rhoP N M) := by
  intro B
  obtain ⟨x, P⟩ := B
  by_cases h : P.1.2 = 3
  · simp [rhoP, h, rS_rS3]
  · simp [rhoP, h, rS_rS]

/-- 升の重み：上の半分 1、面の上 ½、下 0 -/
noncomputable def cw (B : Plaq N M) : ℝ :=
  if B.2.1.2 = 3 then (if 2 * B.1.2.2.val < M then 1 else 0)
  else if B.1.2.2.val = 0 ∨ 2 * B.1.2.2.val = M then 1 / 2
  else if 2 * B.1.2.2.val < M then 1 else 0

theorem cw_add (hM : M % 2 = 0) (B : Plaq N M) : cw N M B + cw N M (rhoP N M B) = 1 := by
  obtain ⟨x, P⟩ := B
  have hlt := ZMod.val_lt x.2.2
  by_cases h : P.1.2 = 3
  · have hv := v4_rS3 N M x
    simp only [cw, rhoP, h, if_true] at hv ⊢
    rw [hv]
    split_ifs <;> (try norm_num) <;> omega
  · have hv := v4_rS N M x
    simp only [cw, rhoP, h, if_false] at hv ⊢
    rw [hv]
    split_ifs <;> (try norm_num) <;> omega

theorem re_rev (a b c d : ℍr) : (c * star b * star a * d).re = (a * b * star c * star d).re := by
  rw [← Quaternion.re_star]
  simp only [star_mul, star_star]
  rw [TwistBlocks.re_mul_comm']
  simp only [mul_assoc]

theorem Th_ne (ω : Link N M → SU2) (z : Site N M) (d : Fin 4) (hd : d ≠ 3) :
    Th N M ω (z, d) = ω (rS N M z, d) := by
  simp only [Th, ThickFloorRP.LinkReflection.linkRefl, thL_ne N M z d hd, sgL, hd, if_false, id_eq]

theorem Th_three (ω : Link N M → SU2) (z : Site N M) :
    ((Th N M ω (z, 3) : SU2) : ℍr) = star ((ω (rS N M (z + ev N M 3), 3) : SU2) : ℍr) := by
  simp only [Th, ThickFloorRP.LinkReflection.linkRefl, thL_three, sgL, if_true]
  rw [Metric.unitSphere.coe_inv, TwistBlocks.inv_unit]

theorem fin_ne_three (μ ν : Fin 4) (h : μ < ν) : μ ≠ 3 := by
  intro e; subst e
  have := ν.isLt
  rw [Fin.lt_iff_val_lt_val] at h
  have h3 : ((3 : Fin 4) : ℕ) = 3 := rfl
  omega

theorem re_hol_refl (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (Th N M ω) B).re = (hol N M ω (rhoP N M B)).re := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have hμ3 : μ ≠ 3 := fin_ne_three μ ν hμν
  by_cases hν : ν = 3
  · subst hν
    have e1 := rS_eq N M x
    have e2 := rS_eq2 N M x μ hμ3
    have hr : rhoP N M (x, ⟨(μ, 3), hμν⟩) = (rS N M (x + ev N M 3), ⟨(μ, 3), hμν⟩) := by
      simp [rhoP]
    rw [hr]
    simp only [hol, l1, l2, l3, l4]
    rw [Th_ne N M ω x μ hμ3, Th_three, Th_ne N M ω _ μ hμ3, Th_three, star_star, e2, e1]
    exact re_rev _ _ _ _
  · have hr : rhoP N M (x, ⟨(μ, ν), hμν⟩) = (rS N M x, ⟨(μ, ν), hμν⟩) := by
      simp [rhoP, hν]
    rw [hr]
    simp only [hol, l1, l2, l3, l4]
    rw [Th_ne N M ω x μ hμ3, Th_ne N M ω _ ν hν, Th_ne N M ω _ μ hμ3, Th_ne N M ω x ν hν,
      rS_add_ev N M x μ hμ3, rS_add_ev N M x ν hν]

theorem rhoP_snd (B : Plaq N M) : (rhoP N M B).2 = B.2 := by
  unfold rhoP; split_ifs <;> rfl

theorem rhoP_fst_fst (B : Plaq N M) : (rhoP N M B).1.1 = B.1.1 := by
  obtain ⟨⟨⟨a, b⟩, ⟨c, e⟩⟩, P⟩ := B
  unfold rhoP; split_ifs
  · simp [rS, ev]
  · rfl

theorem zt_rho (B : Plaq N M) : zt N M true false (rhoP N M B) = zt N M true false B := by
  unfold zt; rw [rhoP_snd, rhoP_fst_fst]; simp [tw]

/-! ## 重みの和と、半分への割れ -/

/-- `Σ_B c(B) Re U_B` -/
noncomputable def SB (c : Plaq N M → ℝ) (ω : Link N M → SU2) : ℝ := ∑ B, c B * (hol N M ω B).re

theorem continuous_SB (c : Plaq N M → ℝ) : Continuous (SB N M c) :=
  continuous_finsetSum _ fun B _ => continuous_const.mul (continuous_hol_re N M B)

theorem abs_SB_le (c : Plaq N M → ℝ) (ω : Link N M → SU2) : |SB N M c ω| ≤ ∑ B, |c B| := by
  unfold SB
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun B _ => ?_)
  rw [abs_mul]
  exact mul_le_of_le_one_right (abs_nonneg _) (abs_re_le_one _ (norm_hol N M ω B))

/-- 結合の係数（背景 n₁₂ = 1、(3,4) の升に η） -/
noncomputable def ce (η : Pt M → ℝ) (B : Plaq N M) : ℝ := zt N M true false B * etaB N M η B

/-- 上の半分の係数 -/
noncomputable def ca (η : Pt M → ℝ) (B : Plaq N M) : ℝ := cw N M B * ce N M η B

/-- 上の半分の η₁ と、鏡映した下の半分の η₂ の貼り合わせ -/
noncomputable def glueEta (η₁ η₂ : Pt M → ℝ) (y : Pt M) : ℝ :=
  if 2 * y.2.val < M then η₁ y else η₂ (y.1, -(y.2 + 1))

theorem coef_glue (hM : M % 2 = 0) (η₁ η₂ : Pt M → ℝ) (B : Plaq N M) :
    cw N M B * etaB N M η₁ B + cw N M (rhoP N M B) * etaB N M η₂ (rhoP N M B)
      = etaB N M (glueEta M η₁ η₂) B := by
  by_cases hp : B.2 = p23
  · obtain ⟨x, P⟩ := B
    simp only at hp
    subst hp
    have h3 : (p23 : Plane).1.2 = 3 := rfl
    have hr : rhoP N M (x, p23) = (rS N M (x + ev N M 3), p23) := by simp [rhoP, h3]
    have hy : (rS N M (x + ev N M 3)).2 = (x.2.1, -(x.2.2 + 1)) := by
      obtain ⟨⟨a, b⟩, ⟨c, e⟩⟩ := x; simp [rS, ev]
    have hlt := ZMod.val_lt x.2.2
    rw [hr]
    simp only [etaB, cw, glueEta, h3, if_true, hy, val_neg_add_one]
    split_ifs <;> (try simp) <;> omega
  · have hp' : (rhoP N M B).2 ≠ p23 := by rw [rhoP_snd]; exact hp
    simp only [etaB, if_neg hp, if_neg hp', mul_one]
    exact cw_add N M hM B

/-- **重みの半分への割れ**：`Σ_B ca_{η₁} Re U_B(ω) + Σ_B ca_{η₂} Re U_B(Θω) = Σ_B z_B η_B Re U_B(ω)`、
`η = glueEta η₁ η₂` -/
theorem half_split (hM : M % 2 = 0) (η₁ η₂ : Pt M → ℝ) (ω : Link N M → SU2) :
    SB N M (ca N M η₁) ω + SB N M (ca N M η₂) (Th N M ω)
      = SB N M (ce N M (glueEta M η₁ η₂)) ω := by
  have hre : SB N M (ca N M η₂) (Th N M ω)
      = ∑ B, ca N M η₂ (rhoP N M B) * (hol N M ω B).re := by
    unfold SB
    simp only [re_hol_refl]
    rw [← Equiv.sum_comp (rhoP_invol N M).toPerm
      (fun B => ca N M η₂ (rhoP N M B) * (hol N M ω B).re)]
    refine Finset.sum_congr rfl fun B _ => ?_
    simp only [Function.Involutive.coe_toPerm, rhoP_invol N M B]
  rw [hre]
  unfold SB
  rw [← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun B _ => ?_
  have h := coef_glue N M hM η₁ η₂ B
  unfold ca ce
  rw [zt_rho, ← h]
  ring

/-- 重みの正の升は、閉じた上の半分のリンクだけを含む -/
theorem hol_eq_of_closed (hM : M % 2 = 0) (ω ω' : Link N M → SU2)
    (h : ∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) (B : Plaq N M) (hB : cw N M B ≠ 0) :
    hol N M ω B = hol N M ω' B := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  have hμ3 := fin_ne_three μ ν hμν
  have hlt := ZMod.val_lt x.2.2
  simp only [hol, l1, l2, l3, l4]
  by_cases hν : ν = 3
  · subst hν
    have hc : 2 * x.2.2.val < M := by
      by_contra hc; apply hB; simp [cw, hc]
    have v1 : (x + ev N M μ).2.2 = x.2.2 := by rw [ev_v4]; simp [hμ3]
    have v2 : (x + ev N M 3).2.2.val = x.2.2.val + 1 := by
      have hM0 := NeZero.ne M
      rw [ev_v4, if_pos rfl, val_add_one_eq]
      rw [if_neg (show ¬ (x.2.2.val + 1 = M) by omega)]
    have f1 : fixL N M (x, μ) ∨ posL N M (x, μ) := by
      by_cases e : x.2.2.val = 0
      · exact Or.inl ⟨hμ3, Or.inl e⟩
      · refine Or.inr (Or.inl ⟨hμ3, ?_, hc⟩)
        show 0 < x.2.2.val
        omega
    have f2 : fixL N M (x + ev N M μ, 3) ∨ posL N M (x + ev N M μ, 3) := by
      refine Or.inr (Or.inr ⟨rfl, ?_⟩)
      show 2 * (x + ev N M μ).2.2.val < M
      rw [v1]; exact hc
    have f3 : fixL N M (x + ev N M 3, μ) ∨ posL N M (x + ev N M 3, μ) := by
      by_cases e : 2 * (x.2.2.val + 1) = M
      · refine Or.inl ⟨hμ3, Or.inr ?_⟩
        show 2 * (x + ev N M 3).2.2.val = M
        rw [v2]; exact e
      · refine Or.inr (Or.inl ⟨hμ3, ?_, ?_⟩)
        · show 0 < (x + ev N M 3).2.2.val
          rw [v2]; omega
        · show 2 * (x + ev N M 3).2.2.val < M
          rw [v2]; omega
    have f4 : fixL N M (x, 3) ∨ posL N M (x, 3) := Or.inr (Or.inr ⟨rfl, hc⟩)
    rw [h _ f1, h _ f2, h _ f3, h _ f4]
  · have hv1 : (x + ev N M μ).2.2 = x.2.2 := by rw [ev_v4]; simp [hμ3]
    have hv2 : (x + ev N M ν).2.2 = x.2.2 := by rw [ev_v4]; simp [hν]
    have hcw : (x.2.2.val = 0 ∨ 2 * x.2.2.val = M) ∨ (0 < x.2.2.val ∧ 2 * x.2.2.val < M) := by
      by_contra hc
      apply hB
      simp only [cw, hν, if_false]
      rw [if_neg (by omega), if_neg (by omega)]
    have key : ∀ d : Fin 4, d ≠ 3 → ∀ z : Site N M, z.2.2 = x.2.2 →
        fixL N M (z, d) ∨ posL N M (z, d) := by
      intro d hd z hz
      simp only [fixL, posL, ne_eq, hd, not_false_eq_true, true_and, false_and, or_false, hz]
      omega
    rw [h _ (key μ hμ3 x rfl), h _ (key ν hν (x + ev N M μ) hv1),
      h _ (key μ hμ3 (x + ev N M ν) hv2), h _ (key ν hν x rfl)]

theorem SB_ca_dep (hM : M % 2 = 0) (η : Pt M → ℝ) (ω ω' : Link N M → SU2)
    (h : ∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) :
    SB N M (ca N M η) ω = SB N M (ca N M η) ω' := by
  unfold SB
  refine Finset.sum_congr rfl fun B _ => ?_
  by_cases hB : cw N M B = 0
  · simp [ca, hB]
  · rw [hol_eq_of_closed N M hM ω ω' h B hB]

/-- **鏡映正値性**（M が偶数、全ての配位の関数で閉じた上の半分だけに依る有界可測な g） -/
theorem half_pairing_nonneg (hM : M % 2 = 0) (g : (Link N M → SU2) → ℝ) (hg : Measurable g)
    (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → g ω = g ω') :
    0 ≤ ∫ ω, g (Th N M ω) * g ω ∂(haarCfg N M) := by
  unfold haarCfg Th
  exact ThickFloorRP.LinkReflection.rp_core haarSU2 (thL N M) (sgL N M) (fixL N M) (posL N M)
    (thL_invol N M) (fix_cond N M) (pos_not_fix N M) (pos_refl N M hM) (neg_refl N M) (sgL_mp N M)
    g hg C hgC hdep

/-- 半分の重み `a_η(ω) = exp(β Σ_B ca_η(B) Re U_B)` -/
noncomputable def aW (β : ℝ) (η : Pt M → ℝ) (ω : Link N M → SU2) : ℝ :=
  Real.exp (β * SB N M (ca N M η) ω)

/-- η つきの全体の重み -/
noncomputable def wE (β : ℝ) (η : Pt M → ℝ) (ω : Link N M → SU2) : ℝ :=
  Real.exp (β * SB N M (ce N M η) ω)

/-- **`a_{η₁}(ω) · a_{η₂}(Θω) = w_{glueEta η₁ η₂}(ω)`** -/
theorem aW_mul_refl (hM : M % 2 = 0) (β : ℝ) (η₁ η₂ : Pt M → ℝ) (ω : Link N M → SU2) :
    aW N M β η₁ ω * aW N M β η₂ (Th N M ω) = wE N M β (glueEta M η₁ η₂) ω := by
  unfold aW wE
  rw [← Real.exp_add, ← mul_add, half_split N M hM]

theorem integral_wE (β : ℝ) (η : Pt M → ℝ) :
    ∫ ω, wE N M β η ω ∂(haarCfg N M) = ZEta N M β true η := rfl

theorem exp_SB_le (β : ℝ) (c : Plaq N M → ℝ) (ω : Link N M → SU2) :
    |Real.exp (β * SB N M c ω)| ≤ Real.exp (|β| * ∑ B, |c B|) := by
  rw [abs_of_pos (Real.exp_pos _)]
  apply Real.exp_le_exp.mpr
  calc β * SB N M c ω ≤ |β * SB N M c ω| := le_abs_self _
    _ = |β| * |SB N M c ω| := abs_mul _ _
    _ ≤ |β| * ∑ B, |c B| := mul_le_mul_of_nonneg_left (abs_SB_le N M c ω) (abs_nonneg _)

theorem continuous_exp_SB (β : ℝ) (c : Plaq N M → ℝ) :
    Continuous fun ω => Real.exp (β * SB N M c ω) :=
  Real.continuous_exp.comp (continuous_const.mul (continuous_SB N M c))

theorem integrable_wE (β : ℝ) (η : Pt M → ℝ) : Integrable (wE N M β η) (haarCfg N M) :=
  Integrable.of_bound (continuous_exp_SB N M β _).aestronglyMeasurable _
    (Filter.Eventually.of_forall fun ω => by
      rw [Real.norm_eq_abs]; exact exp_SB_le N M β _ ω)

end HalfSplit

#print axioms HalfSplit.half_pairing_nonneg
#print axioms HalfSplit.aW_mul_refl
