import Blocks.ThickFloorZeroTrivV1
import Blocks.ThickFloorQuatV1

/-!
# (c2) の入口（局所の模型）：局所の作用 0 ⇒ 局所の全ての升で U_B = z_B
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N : ℕ) [NeZero N]

theorem flat_local (V : ℕ) (n12 : Bool) (ωl : LLink N V → SU2) (h0 : SL N V n12 ωl ≤ 0) :
    ∀ B : LPlaq N V, holL N V ωl B = ((zL N V n12 B : ℝ) : Quaternion ℝ) := by
  have hnn : ∀ B ∈ (univ : Finset (LPlaq N V)), 0 ≤ 1 - zL N V n12 B * (holL N V ωl B).re := by
    intro B _
    have := (term_bounds_L N V n12 1 (by simp) ωl B).1
    rwa [mul_one] at this
  have hsum : SL N V n12 ωl = 0 := le_antisymm h0 (SL_nonneg N V n12 ωl)
  unfold SL at hsum
  have hz := (Finset.sum_eq_zero_iff_of_nonneg hnn).mp hsum
  intro B
  have h1 := hz B (Finset.mem_univ _)
  have hzpm : zL N V n12 B = 1 ∨ zL N V n12 B = -1 := by
    unfold zL tw; split_ifs <;> simp
  have hn : Quaternion.normSq (holL N V ωl B) = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self]
    have hn : ‖holL N V ωl B‖ = 1 := by
      unfold holL
      simp only [norm_mul, norm_star]
      have h : ∀ ℓ, ‖(ωl ℓ : Quaternion ℝ)‖ = 1 := fun ℓ => mem_sphere_zero_iff_norm.mp (ωl ℓ).2
      rw [h, h, h, h]; norm_num
    rw [hn]; norm_num
  exact ThickFloor.eq_of_re_eq_one _ hn _ hzpm (by linarith)

end TwistBlocks

#print axioms TwistBlocks.flat_local
