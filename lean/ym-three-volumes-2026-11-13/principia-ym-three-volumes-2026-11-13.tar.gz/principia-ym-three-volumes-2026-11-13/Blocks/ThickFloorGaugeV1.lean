import Blocks.ThickFloorSanityV1

/-!
# ゲージ変換と作用の不変性（剛性 (c2) と貼り合わせ (d) の部品）

格子点ごとの単位四元数 g によるゲージ変換 `ω^g(x, μ) = g(x) ω(x, μ) g(x + e_μ)⁻¹`。
升の積は `g(x) U_B g(x)⁻¹` に変わり（`hol_gauge`）、Re は変わらない（`re_hol_gauge`）、
よって塊の作用・窓の作用は変わらない（`actB_gauge`・`actW_gauge`）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- ゲージ変換 -/
noncomputable def gauge (g : Site N M → SU2) (ω : Link N M → SU2) : Link N M → SU2 :=
  fun ℓ => g ℓ.1 * ω ℓ * (g (ℓ.1 + ev N M ℓ.2))⁻¹

theorem normSq_unit (u : SU2) : Quaternion.normSq (u : ℍr) = 1 := by
  rw [Quaternion.normSq_eq_norm_mul_self, mem_sphere_zero_iff_norm.mp u.2]; norm_num

theorem inv_unit (u : SU2) : ((u : ℍr))⁻¹ = star (u : ℍr) := by
  rw [Quaternion.inv_def, normSq_unit, inv_one, one_smul]

theorem star_mul_cancel (u : SU2) (X : ℍr) : star (u : ℍr) * ((u : ℍr) * X) = X := by
  rw [← mul_assoc, Quaternion.star_mul_self, normSq_unit]; simp

theorem coe_gauge (g : Site N M → SU2) (ω : Link N M → SU2) (ℓ : Link N M) :
    ((gauge N M g ω ℓ : SU2) : ℍr)
      = (g ℓ.1 : ℍr) * (ω ℓ : ℍr) * star (g (ℓ.1 + ev N M ℓ.2) : ℍr) := by
  unfold gauge
  rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, inv_unit]

theorem hol_gauge (g : Site N M → SU2) (ω : Link N M → SU2) (B : Plaq N M) :
    hol N M (gauge N M g ω) B = (g B.1 : ℍr) * hol N M ω B * star (g B.1 : ℍr) := by
  unfold hol
  rw [coe_gauge, coe_gauge, coe_gauge, coe_gauge]
  simp only [l1, l2, l3, l4, star_mul, star_star]
  rw [add_right_comm B.1 (ev N M B.2.1.2) (ev N M B.2.1.1)]
  simp only [mul_assoc, star_mul_cancel]

theorem re_mul_comm' (a b : ℍr) : (a * b).re = (b * a).re := by
  simp only [Quaternion.re_mul]; ring

theorem re_hol_gauge (g : Site N M → SU2) (ω : Link N M → SU2) (B : Plaq N M) :
    (hol N M (gauge N M g ω) B).re = (hol N M ω B).re := by
  rw [hol_gauge, re_mul_comm', ← mul_assoc, Quaternion.star_mul_self, normSq_unit]
  simp

theorem actB_gauge (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (g : Site N M → SU2)
    (ω : Link N M → SU2) : actB N M m k n12 b e (gauge N M g ω) = actB N M m k n12 b e ω := by
  unfold actB
  exact Finset.sum_congr rfl fun B _ => by rw [re_hol_gauge]

theorem actW_gauge (n12 : Bool) (m₀ : ℕ) (b : Fin k × Fin k) (w : ℕ × ℕ) (e : Pt M → ℝ)
    (g : Site N M → SU2) (ω : Link N M → SU2) :
    actW N M m k n12 m₀ b w e (gauge N M g ω) = actW N M m k n12 m₀ b w e ω := by
  unfold actW
  exact Finset.sum_congr rfl fun B _ => by rw [re_hol_gauge]

end TwistBlocks

#print axioms TwistBlocks.hol_gauge
#print axioms TwistBlocks.actB_gauge
#print axioms TwistBlocks.actW_gauge
