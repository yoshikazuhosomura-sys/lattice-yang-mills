import Blocks.ThickFloorGaugeV1

/-!
# 類の下限と、η を標準の場に止めた下限は等しい（補題 2.3 の帰結）：`κ_c = κ`

紙： の `S^F_min(±)`（η を止めた値）と、Lean の段 3 の `SminC`（類 `Πη = ±1` と内部の下限）。
`Canon`（閉、`canon_holds`）から `SminC(±1) = Smin(η = 標準)`（`SminC_eq_Smin`）、よって
段 3 の `kappaC` は紙の `kappa`（`Blocks/TheoremEV2.lean` の定義）と等しい（`kappaC_eq_kappa`）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem ext_can [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (t : Bool) :
    ext M m k b (fun P => canU M m k b t P.1) = etaSign M m k b t := by
  funext P
  unfold ext
  split_ifs with h
  · exact sgn_canU M m k b t P
  · have hP : P ≠ corner M m k b := by
      intro hc; apply h; rw [hc]; exact blk2_corner M m k hM b
    unfold etaSign etaAt
    cases t
    · simp
    · simp [hP]

theorem prod_can [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (t : Bool) :
    (∏ P : Fib M m k b, sgn (canU M m k b t P.1)) = (if t then -1 else 1) := by
  rw [← Finset.prod_subtype (univ.filter (fun s : Pt M => blk2 M m k s = b))
    (p := fun s => blk2 M m k s = b) (by simp) (fun s => sgn (canU M m k b t s))]
  cases t
  · simp [canU, sgn]
  · have hc : corner M m k b ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b) :=
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, blk2_corner M m k hM b⟩
    have e : ∀ s, sgn (canU M m k b true s) = if s = corner M m k b then -1 else 1 := by
      intro s; unfold canU; simp only [true_and]; split_ifs <;> simp [sgn]
    simp only [e]
    rw [Finset.prod_ite_eq', if_pos hc]
    simp

theorem bdd_Smin (b : Fin k × Fin k) (F : Frame N M m k → SU2) (t : Bool) :
    BddBelow (Set.range fun y : Inner N M m k b → SU2 =>
      actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y)) :=
  ⟨0, by rintro _ ⟨y, rfl⟩; exact actB_nonneg N M m k true b _ (abs_etaSign_le M m k b t) _⟩

/-- **類の下限 = η を標準に止めた下限**（`Canon` から） -/
theorem SminC_eq_Smin [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (F : Frame N M m k → SU2)
    (t : Bool) :
    SminC N M m k true b F (if t then -1 else 1) = Smin N M m k true b F t := by
  have hs : (if t then (-1 : ℝ) else 1) = 1 ∨ (if t then (-1 : ℝ) else 1) = -1 := by
    cases t <;> simp
  haveI := cls_nonempty M m k hM b _ hs
  apply le_antisymm
  · unfold Smin
    refine le_ciInf fun y => ?_
    have hσ : (if t then (-1 : ℝ) else 1) * ∏ P : Fib M m k b, sgn (canU M m k b t P.1) = 1 := by
      rw [prod_can M m k hM b t]; cases t <;> norm_num
    have := SminC_le N M m k true b F _ y (fun P : Fib M m k b => canU M m k b t P.1) hσ
    rwa [ext_can M m k hM b t] at this
  · unfold SminC
    refine le_ciInf fun p => ?_
    have hPr : (∏ P, sgn (p.2.1 P)) = (if t then -1 else 1) := by
      have h := p.2.2
      cases t <;> simp at h ⊢ <;> linarith
    obtain ⟨y', hy'⟩ := canon_holds N M m k hM b F p.1 p.2.1 t hPr
    rw [← hy']
    exact ciInf_le (bdd_Smin N M m k b F t) y'

/-- **段 3 の κ_c は紙の κ に等しい** -/
theorem kappaC_eq_kappa [NeZero m] (hM : m * k ≤ M) :
    kappaC N M m k true = kappa N M m k true := by
  unfold kappaC kappa
  congr 1
  funext p
  have h1 := SminC_eq_Smin N M m k hM p.1 p.2 false
  have h2 := SminC_eq_Smin N M m k hM p.1 p.2 true
  simp only [Bool.false_eq_true, if_false, if_true] at h1 h2
  rw [h1, h2]

end TwistBlocks

#print axioms TwistBlocks.SminC_eq_Smin
#print axioms TwistBlocks.kappaC_eq_kappa
