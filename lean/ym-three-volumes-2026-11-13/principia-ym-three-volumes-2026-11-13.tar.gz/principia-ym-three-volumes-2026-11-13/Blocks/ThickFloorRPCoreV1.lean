import Mathlib

/-!
# 鏡映正値性の抽象の芯（リンクの添字の直積の測度）とコンパクト群の Haar 測度の逆元不変性

写し（言明と証明は元のまま、全体を名前空間 `ThickFloorRP` に入れた）：
元のファイルの `ReflectionProduct`（積の形の鏡映正値性）、`LinkReflection`（リンクの鏡映 θ、値の写像 σ、
面の上の `fix` と正の側の `pos` で、閉じた正の半分だけに依る有界可測な g について
`0 ≤ ∫ g(Θω) g(ω) dν^Λ`、`rp_core`）、`CompactHaar`（コンパクト群の正規化した Haar 測度の
右不変性と逆元不変性）。Osterwalder–Seiler の型の議論。格子に固有の所は無い。
-/

open MeasureTheory

namespace ThickFloorRP

namespace ReflectionProduct

open MeasureTheory

variable {A P : Type*} [MeasurableSpace A] [MeasurableSpace P]
  (μ : Measure A) [SFinite μ] (ν : Measure P) [SFinite ν]

theorem refl_pairing_eq (h g : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * g z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    ∫ z : P × (A × A), h z.2.1 z.1 * g z.2.2 z.1 ∂(ν.prod (μ.prod μ))
      = ∫ p, (∫ a, h a p ∂μ) * (∫ b, g b p ∂μ) ∂ν := by
  rw [integral_prod _ hint]
  refine integral_congr_ae (Filter.Eventually.of_forall (fun p => ?_))
  exact integral_prod_mul (fun a => h a p) (fun b => g b p)

/-- **Reflection positivity (integral form) for a product measure with a factorised weight.** -/
theorem refl_pos_integral (h : A → P → ℝ)
    (hint : Integrable (fun z : P × (A × A) => h z.2.1 z.1 * h z.2.2 z.1)
      (ν.prod (μ.prod μ))) :
    0 ≤ ∫ z : P × (A × A), h z.2.1 z.1 * h z.2.2 z.1 ∂(ν.prod (μ.prod μ)) := by
  rw [refl_pairing_eq μ ν h h hint]
  exact integral_nonneg (fun p => mul_self_nonneg _)

end ReflectionProduct

/-! ## Reflection positivity for a product measure on link variables (abstract index form)

Paper A, premise 10 / Appendix RP (site reflection positivity of the lattice measure);
Osterwalder–Seiler.  This is the bridge from a *link-indexed* configuration space `Λ → X`
with the product measure `ν^Λ` to the plane/positive/negative product form
`P × (A × A)` of `ReflectionProduct.refl_pos_integral` (the same form as the configuration
space of the fermion lane, plane configuration × positive configuration).

Data: a reflection of the links `θ : Λ → Λ` (an involution), a map on the values `σ ℓ : X → X`
(the identity on spatial links, `star` = inverse on temporal links), measure preserving for `ν`,
and two decidable predicates: `fix ℓ` (links in the reflection planes, fixed by `θ` and with
`σ ℓ = id`) and `pos ℓ` (links strictly on the positive side).  Every link that is neither is
sent by `θ` to a positive link, and positive links are sent to non-positive links.  The closed
positive half is `fix ∨ pos`.  The reflected configuration is `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`.

Statement (`rp_core`): for every bounded measurable `g` that depends only on the links of the
closed positive half, `0 ≤ ∫ g(Θω) g(ω) d ν^Λ`.  With a weight that factorises as
`W(ω) = a(ω) a(Θω)`, `a` bounded measurable on the closed positive half (`rp_weighted`).
Nothing here is specific to a lattice; the concrete torus is in the next section.
-/

namespace LinkReflection

open MeasureTheory

variable {Λ X : Type*} [Fintype Λ] [MeasurableSpace X]

/-- The reflected configuration `(Θ ω) ℓ = σ ℓ (ω (θ ℓ))`. -/
def linkRefl (θ : Λ → Λ) (σ : Λ → X → X) (ω : Λ → X) : Λ → X := fun ℓ => σ ℓ (ω (θ ℓ))

section Split

variable (θ : Λ → Λ) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]

/-- links off the planes -/
abbrev Off := {ℓ : Λ // ¬ fix ℓ}
/-- links strictly on the positive side (as a subtype of `Off`) -/
abbrev PosI := {q : Off fix // pos q.1}
/-- links strictly on the negative side -/
abbrev NegI := {q : Off fix // ¬ pos q.1}

/-- The reflection identifies the negative links with the positive links. -/
def negPosEquiv (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ)) : NegI fix pos ≃ PosI fix pos where
  toFun b := ⟨⟨θ b.1.1, hposfix _ (hB _ b.1.2 b.2)⟩, hB _ b.1.2 b.2⟩
  invFun a := ⟨⟨θ a.1.1, fun h => a.1.2 (by
      have h2 := hfix _ h
      rw [hθ] at h2
      rw [h2]; exact h)⟩, hA _ a.2⟩
  left_inv b := Subtype.ext (Subtype.ext (hθ _))
  right_inv a := Subtype.ext (Subtype.ext (hθ _))

/-- Gluing a plane configuration and a positive configuration into a configuration (the other
links get an arbitrary value; only the closed positive half matters). -/
noncomputable def glue [Nonempty X] (p : {ℓ // fix ℓ} → X) (a : PosI fix pos → X) : Λ → X :=
  fun ℓ => if h : fix ℓ then p ⟨ℓ, h⟩ else if h' : pos ℓ then a ⟨⟨ℓ, h⟩, h'⟩
    else Classical.arbitrary X

theorem measurable_glue [Nonempty X] :
    Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => glue fix pos z.1 z.2) := by
  refine measurable_pi_lambda _ (fun ℓ => ?_)
  unfold glue
  by_cases h : fix ℓ
  · simp only [dif_pos h]
    exact (measurable_pi_apply _).comp measurable_fst
  · by_cases h' : pos ℓ
    · simp only [dif_neg h, dif_pos h']
      exact (measurable_pi_apply _).comp measurable_snd
    · simp only [dif_neg h, dif_neg h']
      exact measurable_const

end Split

theorem piCongrLeft_const {α β Y : Type*} [MeasurableSpace Y] (e : α ≃ β) (c : α → Y) (b : β) :
    MeasurableEquiv.piCongrLeft (fun _ : β => Y) e c b = c (e.symm b) := by
  obtain ⟨a, rfl⟩ := e.surjective b
  rw [MeasurableEquiv.piCongrLeft_apply_apply, Equiv.symm_apply_apply]

/-- **Reflection positivity of the product measure on link variables** (premise 10, the
reference measure; Osterwalder–Seiler).  `g` bounded, measurable, depending only on the closed
positive half `fix ∨ pos`. -/
theorem rp_core [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (g : (Λ → X) → ℝ) (hg : Measurable g) (C : ℝ) (hgC : ∀ ω, |g ω| ≤ C)
    (hdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → g ω = g ω') :
    0 ≤ ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
  classical
  let e := negPosEquiv θ fix pos hθ (fun ℓ h => (hfix ℓ h).1) hposfix hA hB
  let Ψ : (Λ → X) → ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) :=
    fun ω => (fun i => ω i.1, (fun a => ω a.1.1, fun a => σ a.1.1 (ω (θ a.1.1))))
  have hs1 := measurePreserving_piEquivPiSubtypeProd (fun _ : Λ => ν) fix
  have hs2 := measurePreserving_piEquivPiSubtypeProd (fun _ : Off fix => ν)
    (fun q : Off fix => pos q.1)
  have hre := measurePreserving_piCongrLeft (fun _ : PosI fix pos => ν) e
  have hσp := measurePreserving_pi (fun _ : PosI fix pos => ν) (fun _ : PosI fix pos => ν)
    (f := fun a => σ a.1.1) (fun a => hσ a.1.1)
  have hτ := hσp.comp hre
  have hcomp := ((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod
    ((MeasurePreserving.id (Measure.pi fun _ : PosI fix pos => ν)).prod hτ)).comp
    (((MeasurePreserving.id (Measure.pi fun _ : {ℓ // fix ℓ} => ν)).prod hs2).comp hs1)
  have hΨ : MeasurePreserving Ψ (Measure.pi fun _ : Λ => ν)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    convert hcomp using 1
    funext ω
    refine Prod.ext rfl (Prod.ext rfl ?_)
    funext a
    show σ a.1.1 (ω (θ a.1.1)) = σ a.1.1 (MeasurableEquiv.piCongrLeft (fun _ : PosI fix pos => X) e
      (fun b => ω b.1.1) a)
    rw [piCongrLeft_const]
    rfl
  let G : ({ℓ // fix ℓ} → X) → (PosI fix pos → X) → ℝ := fun p a => g (glue fix pos p a)
  have hG : Measurable (fun z : ({ℓ // fix ℓ} → X) × (PosI fix pos → X) => G z.1 z.2) :=
    hg.comp (measurable_glue fix pos)
  have hH : Measurable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2) := by
    refine Measurable.mul ?_ ?_
    · exact hG.comp (measurable_fst.prodMk (measurable_fst.comp measurable_snd))
    · exact hG.comp (measurable_fst.prodMk (measurable_snd.comp measurable_snd))
  have h1 : ∀ ω, g ω = G (Ψ ω).1 (Ψ ω).2.1 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show ω ℓ = glue fix pos (fun i => ω i.1) (fun a => ω a.1.1) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have h2 : ∀ ω, g (linkRefl θ σ ω) = G (Ψ ω).1 (Ψ ω).2.2 := by
    intro ω
    refine hdep _ _ (fun ℓ hℓ => ?_)
    show σ ℓ (ω (θ ℓ)) =
      glue fix pos (fun i => ω i.1) (fun a => σ a.1.1 (ω (θ a.1.1))) ℓ
    unfold glue
    rcases hℓ with h | h
    · rw [dif_pos h, (hfix ℓ h).1, (hfix ℓ h).2]
    · rw [dif_neg (hposfix ℓ h), dif_pos h]
  have hC : 0 ≤ C := le_trans (abs_nonneg _) (hgC (fun _ => Classical.arbitrary X))
  have hint : Integrable (fun z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)) =>
      G z.1 z.2.1 * G z.1 z.2.2)
      ((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
        ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) := by
    refine Integrable.of_bound hH.aestronglyMeasurable (C * C) (ae_of_all _ fun z => ?_)
    rw [Real.norm_eq_abs, abs_mul]
    exact mul_le_mul (hgC _) (hgC _) (abs_nonneg _) hC
  calc (0 : ℝ) ≤ ∫ z : ({ℓ // fix ℓ} → X) × ((PosI fix pos → X) × (PosI fix pos → X)),
        G z.1 z.2.1 * G z.1 z.2.2
        ∂((Measure.pi fun _ : {ℓ // fix ℓ} => ν).prod
          ((Measure.pi fun _ : PosI fix pos => ν).prod (Measure.pi fun _ : PosI fix pos => ν))) :=
        ReflectionProduct.refl_pos_integral (Measure.pi fun _ : PosI fix pos => ν)
          (Measure.pi fun _ : {ℓ // fix ℓ} => ν) (fun a p => G p a) hint
    _ = ∫ ω, G (Ψ ω).1 (Ψ ω).2.1 * G (Ψ ω).1 (Ψ ω).2.2 ∂(Measure.pi fun _ : Λ => ν) := by
        rw [← hΨ.map_eq, integral_map hΨ.measurable.aemeasurable hH.aestronglyMeasurable]
    _ = ∫ ω, g (linkRefl θ σ ω) * g ω ∂(Measure.pi fun _ : Λ => ν) := by
        congr 1
        funext ω
        rw [h1 ω, h2 ω, mul_comm]

/-- **With a factorised weight** `W(ω) = a(ω) a(Θω)` (Wilson's action: plaquettes of the
positive side, half of the plaquettes in the planes).  `f`, `a` bounded measurable on the
closed positive half. -/
theorem rp_weighted [Nonempty X] (ν : Measure X) [IsProbabilityMeasure ν]
    (θ : Λ → Λ) (σ : Λ → X → X) (fix pos : Λ → Prop) [DecidablePred fix] [DecidablePred pos]
    (hθ : Function.Involutive θ) (hfix : ∀ ℓ, fix ℓ → θ ℓ = ℓ ∧ ∀ x, σ ℓ x = x)
    (hposfix : ∀ ℓ, pos ℓ → ¬ fix ℓ) (hA : ∀ ℓ, pos ℓ → ¬ pos (θ ℓ))
    (hB : ∀ ℓ, ¬ fix ℓ → ¬ pos ℓ → pos (θ ℓ))
    (hσ : ∀ ℓ, MeasurePreserving (σ ℓ) ν ν)
    (f a : (Λ → X) → ℝ) (hf : Measurable f) (ha : Measurable a) (Cf Ca : ℝ)
    (hfC : ∀ ω, |f ω| ≤ Cf) (haC : ∀ ω, |a ω| ≤ Ca)
    (hfdep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → f ω = f ω')
    (hadep : ∀ ω ω', (∀ ℓ, fix ℓ ∨ pos ℓ → ω ℓ = ω' ℓ) → a ω = a ω') :
    0 ≤ ∫ ω, f (linkRefl θ σ ω) * f ω * (a ω * a (linkRefl θ σ ω)) ∂(Measure.pi fun _ : Λ => ν) := by
  have hCa : 0 ≤ Ca := le_trans (abs_nonneg _) (haC (fun _ => Classical.arbitrary X))
  have h := rp_core ν θ σ fix pos hθ hfix hposfix hA hB hσ (fun ω => a ω * f ω) (ha.mul hf)
    (Ca * Cf) (fun ω => by rw [abs_mul]; exact mul_le_mul (haC ω) (hfC ω) (abs_nonneg _) hCa)
    (fun ω ω' h => by rw [hadep ω ω' h, hfdep ω ω' h])
  calc (0 : ℝ) ≤ _ := h
    _ = _ := by
      congr 1
      funext ω
      ring

end LinkReflection

namespace CompactHaar

open MeasureTheory Measure

section Group

variable {G : Type*} [Group G] [TopologicalSpace G] [IsTopologicalGroup G] [CompactSpace G]
  [MeasurableSpace G] [BorelSpace G]

/-- **Right invariance.** -/
theorem map_mul_right_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ]
    (g : G) : map (· * g) μ = μ := by
  have hreg : (map (· * g) μ).Regular := by
    have h := Regular.map (μ := μ) (Homeomorph.mulRight g)
    exact h
  have hc := isMulLeftInvariant_eq_smul_of_regular (map (· * g) μ) μ
  have h1 : (map (· * g) μ) Set.univ = 1 := by
    rw [map_apply (continuous_mul_right g).measurable MeasurableSet.univ, Set.preimage_univ,
      measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isMulRightInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ]
    [IsProbabilityMeasure μ] : IsMulRightInvariant μ :=
  ⟨fun g => map_mul_right_eq μ g⟩

/-- **Inversion invariance.** -/
theorem inv_eq (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    μ.inv = μ := by
  haveI : IsMulRightInvariant μ := isMulRightInvariant μ
  have hc := isMulLeftInvariant_eq_smul_of_regular μ.inv μ
  have h1 : μ.inv Set.univ = 1 := by
    rw [inv_apply, Set.inv_univ, measure_univ]
  rw [hc, coe_nnreal_smul_apply, measure_univ, mul_one, ENNReal.coe_eq_one] at h1
  rw [hc, h1, one_smul]

theorem isInvInvariant (μ : Measure G) [IsHaarMeasure μ] [Regular μ] [IsProbabilityMeasure μ] :
    IsInvInvariant μ :=
  ⟨inv_eq μ⟩

/-- the normalised Haar measure `haarMeasure ⊤` of a compact group is inversion invariant -/
theorem haarTop_inv_eq : (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)).inv
    = haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G) := by
  haveI : IsProbabilityMeasure (haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)) := by
    refine ⟨?_⟩
    have h : haarMeasure (⊤ : TopologicalSpace.PositiveCompacts G)
        ((⊤ : TopologicalSpace.PositiveCompacts G) : Set G) = 1 := haarMeasure_self
    rwa [TopologicalSpace.PositiveCompacts.coe_top] at h
  exact inv_eq _

end Group

end CompactHaar

end ThickFloorRP

#print axioms ThickFloorRP.LinkReflection.rp_core
#print axioms ThickFloorRP.CompactHaar.inv_eq
