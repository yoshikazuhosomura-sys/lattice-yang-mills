import Blocks.ThickFloorNearV1

/-!
# 中心化群の定量版（命題 4.2 の部品）

単位四元数 u が i・j とほぼ可換（‖ui − iu‖², ‖uj − ju‖² ≤ η²）なら、u は ±1 のどちらかに η 以内
（normSq (u ∓ 1) ≤ η²）。成分の計算：ui − iu = 2(d j − c k)、uj − ju = 2(b k − d i)。
-/

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem center_ij_approx (u : ℍr) (hu : Quaternion.normSq u = 1) (η : ℝ)
    (h1 : Quaternion.normSq (u * ThickFloor.qi - ThickFloor.qi * u) ≤ η ^ 2)
    (h2 : Quaternion.normSq (u * ThickFloor.qj - ThickFloor.qj * u) ≤ η ^ 2) :
    Quaternion.normSq (u - 1) ≤ η ^ 2 ∨ Quaternion.normSq (u + 1) ≤ η ^ 2 := by
  rw [Quaternion.normSq_def'] at hu h1 h2
  rw [Quaternion.normSq_def', Quaternion.normSq_def']
  simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] at h1 h2 ⊢
  have hb : u.imI ^ 2 + u.imJ ^ 2 + u.imK ^ 2 ≤ η ^ 2 / 2 := by nlinarith
  have ha1 : u.re ^ 2 ≤ 1 := by nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]
  rcases le_total 0 u.re with ha | ha
  · left
    have : u.re ≤ 1 := by nlinarith
    nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]
  · right
    have : -1 ≤ u.re := by nlinarith
    nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]

end TwistBlocks

#print axioms TwistBlocks.center_ij_approx
