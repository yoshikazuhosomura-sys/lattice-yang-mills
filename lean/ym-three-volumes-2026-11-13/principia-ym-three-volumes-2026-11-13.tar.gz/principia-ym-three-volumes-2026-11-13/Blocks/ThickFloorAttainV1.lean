import Blocks.ThickFloorLowerV1

/-!
# 下限は最小（貼り合わせ (d) の部品）：`S^F_min(±)` は内部の配位で達成される（コンパクト性）

紙： 命題 4.1 (d) の W（枠を V に止め、升を一枚反転した最小の配位、S_Q(W) = S_渦(N, m₀)）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem Smin_attained (b : Fin k × Fin k) (F : Frame N M m k → SU2) (t : Bool) :
    ∃ y : Inner N M m k b → SU2,
      actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y) = Smin N M m k true b F t := by
  have hcont : Continuous fun ω : Link N M → SU2 => actB N M m k true b (etaSign M m k b t) ω := by
    unfold actB
    exact continuous_finsetSum _ fun B _ =>
      continuous_const.sub (continuous_const.mul (continuous_hol_re N M B))
  have hglue : Continuous (glueB N M m k b F) :=
    LipschitzWith.continuous (K := 1) (LipschitzWith.of_dist_le_mul fun y y' => by
      simpa using dist_glueB_le N M m k b F y y')
  obtain ⟨y0, _, hmin⟩ := isCompact_univ.exists_isMinOn Set.univ_nonempty
    (hcont.comp hglue).continuousOn
  refine ⟨y0, le_antisymm ?_ (ciInf_le (bdd_Smin N M m k b F t) y0)⟩
  exact le_ciInf fun y => isMinOn_iff.mp hmin y (Set.mem_univ y)

/-- `S_渦(N, m)` は達成される：枠 V、角の一枚の反転で、作用がちょうど `S_渦` の内部の配位 W が在る -/
theorem Svortex_attained (N m : ℕ) [NeZero N] [NeZero m] :
    haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
    ∃ y : Inner N (2 * m) m 2 (0, 0) → SU2,
      actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true)
        (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) y) = Svortex N m := by
  haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
  exact Smin_attained N (2 * m) m 2 (0, 0) _ true

end TwistBlocks

#print axioms TwistBlocks.Smin_attained
#print axioms TwistBlocks.Svortex_attained
