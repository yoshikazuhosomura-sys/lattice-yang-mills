import Blocks.ThickFloorHalfFixCSV1
import Blocks.ThickFloorThetaPosV1

/-!
# Polyakov ループの対と θ（M が偶数、全ての実の β、時間の距離 T = M/2）

c：境の面 x₄ = 0 の、x₃ = 0 の向き 3 のリンク（全ての (x₁,x₂)）の符号の反転（`flipC`、中心の符号の場）。
c は Haar の直積を保ち、捩れのない重み w₀ を、(3,4) の升 (x₃,x₄) = (0,0) と (0,−1) を反転した重みに写す
（`chi_flip`・`wE_flip`）。
**`odd_fix_bound`**：面の上のリンクだけに依り |ψ| ≤ 1、ψ∘c = −ψ の ψ について
|∫ ψ w₀| ≤ √(Z₀² − Z₁²)。証明：∫ψw₀ = ½∫ψ(w₀ − w_{TT′})、w₀ − w_{TT′} を半分の重みの和と差 a_±
の対に書き（`aW_mul_refl`）、面の関数を挟んだ Cauchy–Schwarz（`pair_fix_cauchy_schwarz`）と
⟪a_±, a_±⟫ = 2(Z₀ ± Z₁)（`pair_aP`・`pair_aD`）。
**`polyakov_pair_theta`**：向き 3 を一周する Polyakov ループ P_b(t) = Re Π_k U_3((b),(k,t)) について
|⟨P_b(0) P_{b′}(M/2)⟩₀| ≤ 2√θ/(1+θ)。
-/

open Finset MeasureTheory TwistedWilson TwistedPlane CoveringInequality

namespace HalfSplit

local notation "ℍr" => Quaternion ℝ

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 境の面 x₄ = 0 の、x₃ = 0 の向き 3 のリンク（全ての (x₁,x₂)）の符号の反転 -/
noncomputable def flipC : Link N M → ℤˣ := fun ℓ => if ℓ.2 = 2 ∧ ℓ.1.2 = 0 then -1 else 1

/-- 二枚の反転（(0,0) と (0,−1)） -/
noncomputable def etaTT : Pt M → ℝ := fun y => etaAt M 0 y * etaAt M (0, -1) y

theorem sgn_flipC (ℓ : Link N M) : sgn (flipC N M ℓ) = if ℓ.2 = 2 ∧ ℓ.1.2 = 0 then -1 else 1 := by
  unfold flipC; split_ifs <;> simp [sgn]

theorem chi_flip (B : Plaq N M) : chiB N M B (flipC N M) = etaB N M (etaTT M) B := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [chiB, sgn_flipC, l1, l2, l3, l4, etaB, etaTT, etaAt, p23]
  have key : (x.2 + (0, 1) = (0 : Pt M)) ↔ x.2 = (0, -1) := by
    constructor
    · intro h
      have h1 := congrArg Prod.fst h; have h2 := congrArg Prod.snd h
      simp only [Prod.fst_add, Prod.snd_add, Prod.fst_zero, Prod.snd_zero, add_zero] at h1 h2
      exact Prod.ext h1 (by show x.2.2 = -1; linear_combination h2)
    · intro h; rw [h]; ext <;> simp
  fin_cases μ <;> fin_cases ν <;> simp at hμν <;> simp [ev, key, sgn_flipC, Prod.mk_zero_zero] <;> (try split_ifs) <;> simp_all [Prod.mk_zero_zero]

theorem wE_flip (β : ℝ) (ω : Link N M → SU2) :
    wE N M β (fun _ => 1) (flipC N M • ω) = wE N M β (etaTT M) ω := by
  unfold wE SB ce
  congr 2
  refine Finset.sum_congr rfl fun B _ => ?_
  rw [hol_smul, chi_flip]
  have : etaB N M (fun _ => 1) B = 1 := by unfold etaB; split_ifs <;> rfl
  rw [this]; ring

/-- 半分の重みの和と差 -/
noncomputable def aP (β : ℝ) (ω : Link N M → SU2) : ℝ := aW N M β (fun _ => 1) ω + aW N M β (etaAt M 0) ω
noncomputable def aD (β : ℝ) (ω : Link N M → SU2) : ℝ := aW N M β (fun _ => 1) ω - aW N M β (etaAt M 0) ω

theorem pair_aD (hM : M % 2 = 0) (β : ℝ) :
    ∫ ω, aD N M β (Th N M ω) * aD N M β ω ∂(haarCfg N M) = 2 * (ZW N M β true false - ZW N M β true true) := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  have hexp : ∀ ω, aD N M β (Th N M ω) * aD N M β ω
      = wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω - wE N M β (etaAt M (0, -1)) ω
        + wE N M β (fun y => etaAt M 0 y * etaAt M (0, -1) y) ω := by
    intro ω
    have h11 := aW_mul_refl N M hM β (fun _ => 1) (fun _ => 1) ω
    have hT1 := aW_mul_refl N M hM β (etaAt M 0) (fun _ => 1) ω
    have h1T := aW_mul_refl N M hM β (fun _ => 1) (etaAt M 0) ω
    have hTT := aW_mul_refl N M hM β (etaAt M 0) (etaAt M 0) ω
    rw [glue_one_one] at h11; rw [glue_T_one] at hT1
    rw [glue_one_T M hM2] at h1T; rw [glue_T_T M hM2] at hTT
    unfold aD; rw [← h11, ← hT1, ← h1T, ← hTT]; ring
  have i := fun η => integrable_wE N M β η
  have h2 : Integrable (fun ω => wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω) (haarCfg N M) :=
    (i _).sub (i _)
  have h1 : Integrable (fun ω => wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω
      - wE N M β (etaAt M (0, -1)) ω) (haarCfg N M) := h2.sub (i _)
  rw [integral_congr_ae (Filter.Eventually.of_forall hexp), integral_add h1 (i _), integral_sub h2 (i _),
    integral_sub (i _) (i _), integral_wE, integral_wE, integral_wE, integral_wE,
    ZEta_one, ZEta_flip, ZEta_flip_any]
  have hTT : ZEta N M β true (fun y => etaAt M 0 y * etaAt M (0, -1) y) = ZW N M β true false := by
    rw [ZEta_parity]
    · rw [if_pos]
      rw [Finset.prod_mul_distrib, prod_etaAt_any, prod_etaAt_any]; norm_num
    · intro y; simp only [etaAt]; split_ifs <;> norm_num
  rw [hTT]; ring

theorem pair_aP (hM : M % 2 = 0) (β : ℝ) :
    ∫ ω, aP N M β (Th N M ω) * aP N M β ω ∂(haarCfg N M) = 2 * (ZW N M β true false + ZW N M β true true) := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  have hexp : ∀ ω, aP N M β (Th N M ω) * aP N M β ω
      = wE N M β (fun _ => 1) ω + wE N M β (etaAt M 0) ω + wE N M β (etaAt M (0, -1)) ω
        + wE N M β (fun y => etaAt M 0 y * etaAt M (0, -1) y) ω := by
    intro ω
    have h11 := aW_mul_refl N M hM β (fun _ => 1) (fun _ => 1) ω
    have hT1 := aW_mul_refl N M hM β (etaAt M 0) (fun _ => 1) ω
    have h1T := aW_mul_refl N M hM β (fun _ => 1) (etaAt M 0) ω
    have hTT := aW_mul_refl N M hM β (etaAt M 0) (etaAt M 0) ω
    rw [glue_one_one] at h11; rw [glue_T_one] at hT1
    rw [glue_one_T M hM2] at h1T; rw [glue_T_T M hM2] at hTT
    unfold aP; rw [← h11, ← hT1, ← h1T, ← hTT]; ring
  have i := fun η => integrable_wE N M β η
  have h2 : Integrable (fun ω => wE N M β (fun _ => 1) ω + wE N M β (etaAt M 0) ω) (haarCfg N M) :=
    (i _).add (i _)
  have h1 : Integrable (fun ω => wE N M β (fun _ => 1) ω + wE N M β (etaAt M 0) ω
      + wE N M β (etaAt M (0, -1)) ω) (haarCfg N M) := h2.add (i _)
  rw [integral_congr_ae (Filter.Eventually.of_forall hexp), integral_add h1 (i _), integral_add h2 (i _),
    integral_add (i _) (i _), integral_wE, integral_wE, integral_wE, integral_wE,
    ZEta_one, ZEta_flip, ZEta_flip_any]
  have hTT : ZEta N M β true (fun y => etaAt M 0 y * etaAt M (0, -1) y) = ZW N M β true false := by
    rw [ZEta_parity]
    · rw [if_pos]
      rw [Finset.prod_mul_distrib, prod_etaAt_any, prod_etaAt_any]; norm_num
    · intro y; simp only [etaAt]; split_ifs <;> norm_num
  rw [hTT]; ring

/-- **c で符号の変わる面の上の関数の評価**：面の上のリンクだけに依り、|ψ| ≤ 1、ψ(c·ω) = −ψ(ω) なら
`|∫ ψ · w₀| ≤ √(Z₀² − Z₁²)`（M が偶数、全ての実の β）。Z₀ ⟨ψ⟩₀ の形。 -/
theorem odd_fix_bound (hM : M % 2 = 0) (β : ℝ) (ψ : (Link N M → SU2) → ℝ) (hψ : Measurable ψ)
    (hψ1 : ∀ ω, |ψ ω| ≤ 1) (hdψ : ∀ ω ω', (∀ ℓ, fixL N M ℓ → ω ℓ = ω' ℓ) → ψ ω = ψ ω')
    (hodd : ∀ ω, ψ (flipC N M • ω) = - ψ ω) :
    |∫ ω, ψ ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)|
      ≤ Real.sqrt (ZW N M β true false ^ 2 - ZW N M β true true ^ 2) := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  -- 可測・有界
  have mW : ∀ η, Measurable (aW N M β η) := fun η => (continuous_exp_SB N M β _).measurable
  set C1 := Real.exp (|β| * ∑ B, |ca N M (fun _ => 1) B|)
  set CT := Real.exp (|β| * ∑ B, |ca N M (etaAt M 0) B|)
  have b1 : ∀ ω, |aW N M β (fun _ => 1) ω| ≤ C1 := fun ω => exp_SB_le N M β _ ω
  have bT : ∀ ω, |aW N M β (etaAt M 0) ω| ≤ CT := fun ω => exp_SB_le N M β _ ω
  have mP : Measurable (aP N M β) := (mW _).add (mW _)
  have mD : Measurable (aD N M β) := (mW _).sub (mW _)
  have bP : ∀ ω, |aP N M β ω| ≤ C1 + CT := fun ω => (abs_add_le _ _).trans (add_le_add (b1 ω) (bT ω))
  have bD : ∀ ω, |aD N M β ω| ≤ C1 + CT := fun ω => (abs_sub _ _).trans (add_le_add (b1 ω) (bT ω))
  have dP : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → aP N M β ω = aP N M β ω' := by
    intro ω ω' h; unfold aP aW; rw [SB_ca_dep N M hM _ ω ω' h, SB_ca_dep N M hM _ ω ω' h]
  have dD : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → aD N M β ω = aD N M β ω' := by
    intro ω ω' h; unfold aD aW; rw [SB_ca_dep N M hM _ ω ω' h, SB_ca_dep N M hM _ ω ω' h]
  -- 反転で符号
  have iψw : ∀ η, Integrable (fun ω => ψ ω * wE N M β η ω) (haarCfg N M) := fun η =>
    Integrable.of_bound (hψ.mul (continuous_exp_SB N M β _).measurable).aestronglyMeasurable
      (1 * Real.exp (|β| * ∑ B, |ce N M η B|)) (Filter.Eventually.of_forall fun ω => by
        rw [Real.norm_eq_abs, abs_mul]
        exact mul_le_mul (hψ1 ω) (exp_SB_le N M β _ ω) (abs_nonneg _) zero_le_one)
  have hflip : ∫ ω, ψ ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)
      = - ∫ ω, ψ ω * wE N M β (etaTT M) ω ∂(haarCfg N M) := by
    rw [← haarCfg_inv N M (flipC N M) (fun ω => ψ ω * wE N M β (fun _ => 1) ω), ← integral_neg]
    congr 1; funext ω
    rw [hodd, wE_flip]; ring
  -- 点ごとの恒等式
  have hpt : ∀ ω, ψ ω * wE N M β (fun _ => 1) ω - ψ ω * wE N M β (etaTT M) ω
      = (1 / 2) * (aP N M β (Th N M ω) * (ψ ω * aD N M β ω))
        + (1 / 2) * (aD N M β (Th N M ω) * (ψ ω * aP N M β ω)) := by
    intro ω
    have h11 := aW_mul_refl N M hM β (fun _ => 1) (fun _ => 1) ω
    have hTT := aW_mul_refl N M hM β (etaAt M 0) (etaAt M 0) ω
    rw [glue_one_one] at h11; rw [glue_T_T M hM2] at hTT
    have e : etaTT M = fun y => etaAt M 0 y * etaAt M (0, -1) y := rfl
    rw [e, ← h11, ← hTT]; unfold aP aD; ring
  have iX := (integrable_pair N M (aP N M β) (fun ω => ψ ω * aD N M β ω) mP (hψ.mul mD) (C1 + CT) (C1 + CT)
    bP (fun ω => by rw [abs_mul]; exact (mul_le_of_le_one_left (abs_nonneg _) (hψ1 ω)).trans (bD ω)))
  have iY := (integrable_pair N M (aD N M β) (fun ω => ψ ω * aP N M β ω) mD (hψ.mul mP) (C1 + CT) (C1 + CT)
    bD (fun ω => by rw [abs_mul]; exact (mul_le_of_le_one_left (abs_nonneg _) (hψ1 ω)).trans (bP ω)))
  have h2I : 2 * ∫ ω, ψ ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)
      = (1 / 2) * (∫ ω, aP N M β (Th N M ω) * (ψ ω * aD N M β ω) ∂(haarCfg N M))
        + (1 / 2) * (∫ ω, aD N M β (Th N M ω) * (ψ ω * aP N M β ω) ∂(haarCfg N M)) := by
    have : 2 * ∫ ω, ψ ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)
        = ∫ ω, (ψ ω * wE N M β (fun _ => 1) ω - ψ ω * wE N M β (etaTT M) ω) ∂(haarCfg N M) := by
      rw [integral_sub (iψw _) (iψw _)]; linarith [hflip]
    rw [this, integral_congr_ae (Filter.Eventually.of_forall hpt),
      integral_add (iX.const_mul _) (iY.const_mul _), integral_const_mul, integral_const_mul]
  -- Cauchy–Schwarz
  have csX := pair_fix_cauchy_schwarz N M hM (aP N M β) (aD N M β) ψ mP mD hψ (C1 + CT) (C1 + CT) bP bD hψ1
    dP dD hdψ
  have csY := pair_fix_cauchy_schwarz N M hM (aD N M β) (aP N M β) ψ mD mP hψ (C1 + CT) (C1 + CT) bD bP hψ1
    dD dP hdψ
  rw [pair_aP N M hM β, pair_aD N M hM β] at csX csY
  set Z0 := ZW N M β true false
  set Z1 := ZW N M β true true
  have hK : 2 * (Z0 + Z1) * (2 * (Z0 - Z1)) = 4 * (Z0 ^ 2 - Z1 ^ 2) := by ring
  rw [hK] at csX
  rw [mul_comm, hK] at csY
  have aX := Real.abs_le_sqrt csX
  have aY := Real.abs_le_sqrt csY
  have hs4 : Real.sqrt (4 * (Z0 ^ 2 - Z1 ^ 2)) = 2 * Real.sqrt (Z0 ^ 2 - Z1 ^ 2) := by
    rw [Real.sqrt_mul (by norm_num), show Real.sqrt 4 = 2 by
      rw [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
  rw [hs4] at aX aY
  have habs : |2 * ∫ ω, ψ ω * wE N M β (fun _ => 1) ω ∂(haarCfg N M)| ≤ 2 * Real.sqrt (Z0 ^ 2 - Z1 ^ 2) := by
    rw [h2I]
    calc _ ≤ |(1 / 2) * (∫ ω, aP N M β (Th N M ω) * (ψ ω * aD N M β ω) ∂(haarCfg N M))|
          + |(1 / 2) * (∫ ω, aD N M β (Th N M ω) * (ψ ω * aP N M β ω) ∂(haarCfg N M))| := abs_add_le _ _
      _ ≤ (1 / 2) * (2 * Real.sqrt (Z0 ^ 2 - Z1 ^ 2)) + (1 / 2) * (2 * Real.sqrt (Z0 ^ 2 - Z1 ^ 2)) := by
          rw [abs_mul, abs_mul, abs_of_pos (by norm_num : (0:ℝ) < 1 / 2)]
          exact add_le_add (mul_le_mul_of_nonneg_left aX (by norm_num))
            (mul_le_mul_of_nonneg_left aY (by norm_num))
      _ = 2 * Real.sqrt (Z0 ^ 2 - Z1 ^ 2) := by ring
  rw [abs_mul, abs_of_pos (by norm_num : (0:ℝ) < 2)] at habs
  linarith

theorem norm_list_prod (l : List ℍr) (h : ∀ q ∈ l, ‖q‖ = 1) : ‖l.prod‖ = 1 := by
  induction l with
  | nil => simp
  | cons a t ih =>
    rw [List.prod_cons, norm_mul, h a (List.mem_cons_self), ih (fun q hq => h q (List.mem_cons_of_mem a hq)),
      one_mul]

/-- **Polyakov ループ**（向き 3 を一周、横の位置 b、x₄ = t）：Re Π_{k<M} U_3((b),(k,t)) -/
noncomputable def polyLoop (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) : ℝ :=
  (((List.range M).map fun k : ℕ => ((ω ((b, ((k : ZMod M), t)), 2) : SU2) : ℍr)).prod).re

theorem abs_polyLoop_le (b : ZMod N × ZMod N) (t : ZMod M) (ω : Link N M → SU2) :
    |polyLoop N M b t ω| ≤ 1 := by
  apply abs_re_le_one
  apply norm_list_prod
  intro q hq
  obtain ⟨k, _, rfl⟩ := List.mem_map.mp hq
  exact mem_sphere_zero_iff_norm.mp (ω _).2

theorem continuous_polyLoop (b : ZMod N × ZMod N) (t : ZMod M) : Continuous (polyLoop N M b t) := by
  unfold polyLoop
  refine Quaternion.continuous_re.comp ?_
  exact continuous_list_prod _ fun k _ => continuous_subtype_val.comp (continuous_apply _)

/-- 半分の点 M/2 -/
def halfPt : ZMod M := ((M / 2 : ℕ) : ZMod M)

theorem polyLoop_flip_zero (hM2 : 2 ≤ M) (b : ZMod N × ZMod N) (ω : Link N M → SU2) :
    polyLoop N M b 0 (flipC N M • ω) = - polyLoop N M b 0 ω := by
  obtain ⟨n, rfl⟩ : ∃ n, M = n + 1 := ⟨M - 1, by omega⟩
  unfold polyLoop
  rw [List.range_succ_eq_map, List.map_cons, List.map_cons, List.prod_cons, List.prod_cons, List.map_map,
    List.map_map]
  have h0 : ((flipC N (n + 1) • ω) ((b, (((0 : ℕ) : ZMod (n + 1)), (0 : ZMod (n + 1)))), 2) : ℍr)
      = - (ω ((b, (((0 : ℕ) : ZMod (n + 1)), 0)), 2) : ℍr) := by
    rw [TwistedWilson.coe_smul_apply]; simp [flipC, sgn]
  have hk : ((List.range n).map ((fun k : ℕ => ((flipC N (n + 1) • ω) ((b, ((k : ZMod (n + 1)), (0 : ZMod (n + 1)))), 2) : ℍr))
      ∘ Nat.succ)) = (List.range n).map ((fun k : ℕ => ((ω ((b, ((k : ZMod (n + 1)), (0 : ZMod (n + 1)))), 2)) : ℍr)) ∘ Nat.succ) := by
    refine List.map_congr_left fun k hk => ?_
    simp only [Function.comp]
    rw [TwistedWilson.coe_smul_apply]
    have hne : ((k.succ : ℕ) : ZMod (n + 1)) ≠ 0 := by
      intro h
      have := (ZMod.natCast_eq_zero_iff _ _).mp h
      have hk' := List.mem_range.mp hk
      exact absurd (Nat.le_of_dvd (Nat.succ_pos k) this) (by omega)
    have : flipC N (n + 1) ((b, ((k.succ : ℕ) : ZMod (n + 1)), 0), 2) = 1 := by
      unfold flipC; rw [if_neg]; rintro ⟨_, h⟩; exact hne (congrArg Prod.fst h)
    rw [this]; simp [sgn]
  rw [h0, hk, neg_mul, Quaternion.re_neg]

theorem polyLoop_flip_half (hM : M % 2 = 0) (b : ZMod N × ZMod N) (ω : Link N M → SU2) :
    polyLoop N M b (halfPt M) (flipC N M • ω) = polyLoop N M b (halfPt M) ω := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  have hne : halfPt M ≠ 0 := by
    intro h
    have := congrArg ZMod.val h
    rw [halfPt, ZMod.val_cast_of_lt (by omega), ZMod.val_zero] at this
    omega
  unfold polyLoop
  congr 2
  refine List.map_congr_left fun k _ => ?_
  rw [TwistedWilson.coe_smul_apply]
  have : flipC N M ((b, ((k : ZMod M), halfPt M)), 2) = 1 := by
    unfold flipC; rw [if_neg]; rintro ⟨_, h⟩; exact hne (congrArg Prod.snd h)
  rw [this]; simp [sgn]

/-- **Polyakov ループの対と θ**（M が偶数、全ての実の β、T = M/2）：
`|∫ P_b(0) P_{b'}(M/2) w₀| ≤ √(Z₀² − Z₁²)`、比の形で `|⟨P_b(0) P_{b'}(M/2)⟩₀| ≤ 2√θ/(1+θ)` -/
theorem polyakov_pair_bound (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) :
    |∫ ω, (polyLoop N M b 0 ω * polyLoop N M b' (halfPt M) ω) * wE N M β (fun _ => 1) ω ∂(haarCfg N M)|
      ≤ Real.sqrt (ZW N M β true false ^ 2 - ZW N M β true true ^ 2) := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  refine odd_fix_bound N M hM β _ ((continuous_polyLoop N M b 0).mul
    (continuous_polyLoop N M b' (halfPt M))).measurable (fun ω => ?_) (fun ω ω' h => ?_) (fun ω => ?_)
  · rw [abs_mul]
    exact mul_le_one₀ (abs_polyLoop_le N M b 0 ω) (abs_nonneg _) (abs_polyLoop_le N M b' _ ω)
  · have f1 : ∀ k : ℕ, ω ((b, ((k : ZMod M), (0 : ZMod M))), 2) = ω' ((b, ((k : ZMod M), (0 : ZMod M))), 2) :=
      fun k => h _ ⟨(show (2 : Fin 4) ≠ 3 by decide), Or.inl (by simp)⟩
    have f2 : ∀ k : ℕ, ω ((b', ((k : ZMod M), halfPt M)), 2) = ω' ((b', ((k : ZMod M), halfPt M)), 2) := by
      intro k
      refine h _ ⟨(show (2 : Fin 4) ≠ 3 by decide), Or.inr ?_⟩
      show 2 * (halfPt M).val = M
      rw [halfPt, ZMod.val_cast_of_lt (by omega)]; omega
    have e1 : polyLoop N M b 0 ω = polyLoop N M b 0 ω' := by
      unfold polyLoop; simp only [f1]
    have e2 : polyLoop N M b' (halfPt M) ω = polyLoop N M b' (halfPt M) ω' := by
      unfold polyLoop; simp only [f2]
    rw [e1, e2]
  · rw [polyLoop_flip_zero N M hM2, polyLoop_flip_half N M hM]; ring

theorem polyakov_pair_theta (hM : M % 2 = 0) (β : ℝ) (b b' : ZMod N × ZMod N) :
    |∫ ω, (polyLoop N M b 0 ω * polyLoop N M b' (halfPt M) ω) * wE N M β (fun _ => 1) ω ∂(haarCfg N M)|
        / ZW N M β true false
      ≤ 2 * Real.sqrt (TwistBlocks.thetaM N M β) / (1 + TwistBlocks.thetaM N M β) := by
  have h := polyakov_pair_bound N M hM β b b'
  set Z0 := ZW N M β true false
  set Z1 := ZW N M β true true
  have h0 : 0 < Z0 := ZW_pos N M β true false
  have h1 : 0 < Z1 := ZW_pos N M β true true
  have hθ : TwistBlocks.thetaM N M β = (Z0 - Z1) / (Z0 + Z1) := rfl
  have key : 2 * Real.sqrt ((Z0 - Z1) / (Z0 + Z1)) / (1 + (Z0 - Z1) / (Z0 + Z1))
      = Real.sqrt (Z0 ^ 2 - Z1 ^ 2) / Z0 := by
    have hs : Real.sqrt (Z0 ^ 2 - Z1 ^ 2) = (Z0 + Z1) * Real.sqrt ((Z0 - Z1) / (Z0 + Z1)) := by
      rw [show Z0 ^ 2 - Z1 ^ 2 = (Z0 + Z1) ^ 2 * ((Z0 - Z1) / (Z0 + Z1)) by field_simp; ring,
        Real.sqrt_mul (by positivity), Real.sqrt_sq (by linarith)]
    rw [hs]
    set r := Real.sqrt ((Z0 - Z1) / (Z0 + Z1))
    have hZ : Z0 + Z1 ≠ 0 := by linarith
    rw [show 1 + (Z0 - Z1) / (Z0 + Z1) = 2 * Z0 / (Z0 + Z1) by field_simp; ring]
    field_simp
  rw [hθ, key]
  exact div_le_div_of_nonneg_right h h0.le

end HalfSplit

#print axioms HalfSplit.polyakov_pair_theta
