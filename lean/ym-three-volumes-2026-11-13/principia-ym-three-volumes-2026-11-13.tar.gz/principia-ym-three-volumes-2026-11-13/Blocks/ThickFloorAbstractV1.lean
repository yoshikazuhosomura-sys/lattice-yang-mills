import Mathlib

/-!
# 段 4 の抽象の部品（Mathlib だけ）

紙： 命題 4.1。
* (c3) コンパクト性：コンパクト空間の上の連続関数 S（作用）と Φ（費用）で、S ≤ 0 の点で Φ ≤ c なら、
  全ての ε > 0 に δ > 0 が在って S < δ の点で Φ < c + ε（`small_action_cost`）。
  紙の (c) の「作用 ≤ δ なら真空に ε 近い」を、距離を使わずに費用 Φ の形で言う版。
* (c1) 四元数：単位四元数 A・B が AB = −BA なら Re A = Re B = 0、虚部は直交（`anticomm_unit`）。
-/

namespace ThickFloor

/-- **(c3) コンパクト性**（距離を使わない形） -/
theorem small_action_cost {X : Type*} [TopologicalSpace X] [CompactSpace X] (S Φ : X → ℝ)
    (hS : Continuous S) (hΦ : Continuous Φ) (c : ℝ) (h0 : ∀ x, S x ≤ 0 → Φ x ≤ c) :
    ∀ ε > 0, ∃ δ > 0, ∀ x, S x < δ → Φ x < c + ε := by
  intro ε hε
  set K : Set X := {x | c + ε ≤ Φ x}
  have hK : IsCompact K := (isClosed_le continuous_const hΦ).isCompact
  rcases K.eq_empty_or_nonempty with he | hne
  · refine ⟨1, one_pos, fun x _ => ?_⟩
    by_contra h
    have : x ∈ K := le_of_not_gt h
    rw [he] at this; exact this
  · obtain ⟨x0, hx0, hmin⟩ := hK.exists_isMinOn hne hS.continuousOn
    have hpos : 0 < S x0 := by
      by_contra h
      have := h0 x0 (le_of_not_gt h)
      have : c + ε ≤ Φ x0 := hx0
      linarith
    refine ⟨S x0, hpos, fun x hx => ?_⟩
    by_contra h
    have hxK : x ∈ K := le_of_not_gt h
    have := isMinOn_iff.mp hmin x hxK
    linarith

/-- **(c1) 反可換な単位四元数**：`AB = −BA`、`|A| = |B| = 1` なら `Re A = Re B = 0` で虚部は直交 -/
theorem anticomm_unit (A B : Quaternion ℝ) (hA : Quaternion.normSq A = 1)
    (hB : Quaternion.normSq B = 1) (h : A * B = -(B * A)) :
    A.re = 0 ∧ B.re = 0 ∧ A.imI * B.imI + A.imJ * B.imJ + A.imK * B.imK = 0 := by
  rw [Quaternion.normSq_def'] at hA hB
  have hR := congrArg (fun q : Quaternion ℝ => q.re) h
  have hI := congrArg (fun q : Quaternion ℝ => q.imI) h
  have hJ := congrArg (fun q : Quaternion ℝ => q.imJ) h
  have hK := congrArg (fun q : Quaternion ℝ => q.imK) h
  simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg] at hR hI hJ hK
  have ha : A.re = 0 := by
    linear_combination (-A.re) * hB + (B.re / 2) * hR + (B.imI / 2) * hI
      + (B.imJ / 2) * hJ + (B.imK / 2) * hK
  have hb : B.re = 0 := by
    linear_combination (-B.re) * hA + (A.re / 2) * hR + (A.imI / 2) * hI
      + (A.imJ / 2) * hJ + (A.imK / 2) * hK
  refine ⟨ha, hb, ?_⟩
  rw [ha, hb] at hR
  linear_combination (-1 / 2) * hR

end ThickFloor

#print axioms ThickFloor.small_action_cost
#print axioms ThickFloor.anticomm_unit
