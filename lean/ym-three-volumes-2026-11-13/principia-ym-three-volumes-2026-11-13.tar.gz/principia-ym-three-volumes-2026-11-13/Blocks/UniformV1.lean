import Blocks.KeffLaplaceV1

/-!
# 塊の大きさの M に一様な評価と、定理 E の「m を止めた形」（段 4 を仮定の欄に）

`m·k ≤ M < (k+1)·m`（k = ⌊M/m⌋ のとき）では塊の幅は m 以上 2m 未満。
* `card_Fib_le`・`nB_le`・`card_Inner_le`：#二次元の升 ≤ (2m)²、#升 ≤ 6N²(2m)²、#内部のリンク ≤ 4N²(2m)²。
* `Dmax_le`：`D(δ) ≤ D*(N,m,δ) = (2m)² log 2 − 4N²(2m)² log μ₁(δ / (24N²(2m)² + 1))`（M に依らない）。
* `kappaC_le`：`κ_c ≤ 12 N² (2m)²`（M に依らない。仮定の欄 `hK` が満たせることの証人）。
* `theta_fixed_m`：`κ_c ≤ K₀` なら `θ_M ≤ exp(−k² exp(−(β(K₀ + 2δ) + D*)))`。
  定理 E は、ここに「m → ∞ で sup_M κ_c → S_N」（紙の命題 4.1、段 4）を足すと出る。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem q_range [NeZero m] (hk : M < (k + 1) * m) (y : ZMod M) (c : Fin k) (hc : q M m k y = c) :
    c.val * m ≤ y.val ∧ y.val < c.val * m + 2 * m := by
  have hm : 0 < m := NeZero.pos m
  have hv := ZMod.val_lt y
  unfold q at hc
  have hcv : min (y.val / m) (k - 1) = c.val := by rw [← hc]
  have hck := c.isLt
  by_cases h : y.val / m ≤ k - 1
  · rw [min_eq_left h] at hcv
    have h1 := Nat.div_mul_le_self y.val m
    have h2 := Nat.lt_div_mul_add (a := y.val) hm
    rw [hcv] at h1 h2
    constructor <;> omega
  · have h : k - 1 < y.val / m := Nat.lt_of_not_le h
    rw [min_eq_right h.le] at hcv
    have h1 : k * m ≤ y.val := by
      have := (Nat.le_div_iff_mul_le hm).mp (by omega : k ≤ y.val / m); exact this
    have e1 : c.val * m + m = k * m := by
      rw [← hcv, ← Nat.succ_mul, Nat.succ_eq_add_one, Nat.sub_add_cancel (NeZero.pos k)]
    have e2 : (k + 1) * m = k * m + m := Nat.succ_mul k m
    constructor
    · generalize k * m = P at *; generalize c.val * m = Q at *; omega
    · generalize k * m = P at *; generalize c.val * m = Q at *; omega

theorem card_fiber1_le [NeZero m] (hk : M < (k + 1) * m) (c : Fin k) :
    Fintype.card {y : ZMod M // q M m k y = c} ≤ 2 * m := by
  let f : {y : ZMod M // q M m k y = c} → Fin (2 * m) := fun y =>
    ⟨y.1.val - c.val * m, by have := q_range M m k hk y.1 c y.2; omega⟩
  have hf : Function.Injective f := by
    intro y y' h
    have h1 := q_range M m k hk y.1 c y.2
    have h2 := q_range M m k hk y'.1 c y'.2
    have hv : y.1.val = y'.1.val := by
      have := congrArg Fin.val h; simp only [f] at this; omega
    exact Subtype.ext (ZMod.val_injective M hv)
  simpa using Fintype.card_le_of_injective f hf

theorem card_Fib_le [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k) :
    Fintype.card (Fib M m k b) ≤ (2 * m) * (2 * m) := by
  let f : Fib M m k b → {y : ZMod M // q M m k y = b.1} × {y : ZMod M // q M m k y = b.2} :=
    fun P => (⟨P.1.1, congrArg Prod.fst P.2⟩, ⟨P.1.2, congrArg Prod.snd P.2⟩)
  have hf : Function.Injective f := by
    intro P P' h
    simp only [f, Prod.mk.injEq, Subtype.mk.injEq] at h
    exact Subtype.ext (Prod.ext (congrArg Subtype.val h.1) (congrArg Subtype.val h.2))
  calc Fintype.card (Fib M m k b)
      ≤ Fintype.card ({y : ZMod M // q M m k y = b.1} × {y : ZMod M // q M m k y = b.2}) :=
        Fintype.card_le_of_injective f hf
    _ = _ := Fintype.card_prod _ _
    _ ≤ (2 * m) * (2 * m) := Nat.mul_le_mul (card_fiber1_le M m k hk b.1) (card_fiber1_le M m k hk b.2)

theorem nB_le [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k) :
    nB N M m k b ≤ N * N * ((2 * m) * (2 * m)) * 6 := by
  unfold nB
  rw [← Fintype.card_subtype]
  let f : {B : Plaq N M // blk2 M m k B.1.2 = b} → ((ZMod N × ZMod N) × Fib M m k b) × Plane :=
    fun B => ((B.1.1.1, ⟨B.1.1.2, B.2⟩), B.1.2)
  have hf : Function.Injective f := by
    intro B B' h
    simp only [f, Prod.mk.injEq, Subtype.mk.injEq] at h
    exact Subtype.ext (Prod.ext (Prod.ext h.1.1 h.1.2) h.2)
  refine (Fintype.card_le_of_injective f hf).trans ?_
  rw [Fintype.card_prod, Fintype.card_prod, Fintype.card_prod, ZMod.card]
  have h6 : Fintype.card Plane = 6 := by decide
  rw [h6]
  exact Nat.mul_le_mul (Nat.mul_le_mul le_rfl (card_Fib_le M m k hk b)) le_rfl

theorem card_Inner_le [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k) :
    Fintype.card (Inner N M m k b) ≤ N * N * ((2 * m) * (2 * m)) * 4 := by
  let f : Inner N M m k b → ((ZMod N × ZMod N) × Fib M m k b) × Fin 4 :=
    fun x => ((x.1.1.1.1, ⟨x.1.1.1.2, x.2⟩), x.1.1.2)
  have hf : Function.Injective f := by
    intro x x' h
    simp only [f, Prod.mk.injEq, Subtype.mk.injEq] at h
    exact Subtype.ext (Subtype.ext (Prod.ext (Prod.ext h.1.1 (congrArg Subtype.val h.1.2)) h.2))
  refine (Fintype.card_le_of_injective f hf).trans ?_
  rw [Fintype.card_prod, Fintype.card_prod, Fintype.card_prod, ZMod.card, Fintype.card_fin]
  exact Nat.mul_le_mul (Nat.mul_le_mul le_rfl (card_Fib_le M m k hk b)) le_rfl

/-! ## D(δ) と κ_c の M に一様な評価 -/

/-- `D*(N, m, δ) = (2m)² log 2 − 4N²(2m)² · log μ₁(δ / (24 N² (2m)² + 1))` -/
noncomputable def Dstar (N m : ℕ) (δ : ℝ) : ℝ :=
  ((2 * m) * (2 * m) : ℕ) * Real.log 2 - ((N * N * ((2 * m) * (2 * m)) * 4 : ℕ) : ℝ) *
    Real.log ((haarSU2 (Metric.ball 1
      (δ / (4 * ((N * N * ((2 * m) * (2 * m)) * 6 : ℕ) : ℝ) + 1)))).toReal)

theorem haar_ball_toReal_le_one (r : ℝ) : (haarSU2 (Metric.ball 1 r)).toReal ≤ 1 := by
  have h : haarSU2 (Metric.ball 1 r) ≤ 1 := prob_le_one
  have := ENNReal.toReal_mono ENNReal.one_ne_top h
  simpa using this

theorem haar_ball_toReal_mono {r₁ r₂ : ℝ} (h : r₁ ≤ r₂) :
    (haarSU2 (Metric.ball 1 r₁)).toReal ≤ (haarSU2 (Metric.ball 1 r₂)).toReal :=
  ENNReal.toReal_mono (measure_ne_top _ _) (measure_mono (Metric.ball_subset_ball h))

theorem Db_le [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k) {δ : ℝ} (hδ : 0 < δ) :
    Db N M m k b δ ≤ Dstar N m δ := by
  unfold Db Dstar
  set Ls : ℝ := 4 * ((N * N * ((2 * m) * (2 * m)) * 6 : ℕ) : ℝ) + 1
  have hnB : (nB N M m k b : ℝ) ≤ ((N * N * ((2 * m) * (2 * m)) * 6 : ℕ) : ℝ) := by
    exact_mod_cast nB_le N M m k hk b
  have hLb : 0 < 4 * (nB N M m k b : ℝ) + 1 := by positivity
  have hrad : δ / Ls ≤ δ / (4 * (nB N M m k b : ℝ) + 1) :=
    div_le_div_of_nonneg_left hδ.le hLb (by linarith)
  have hμs := CoarseLaplace.haar_ball_toReal_pos (div_pos hδ (by positivity : (0 : ℝ) < Ls))
  have hμmono := haar_ball_toReal_mono hrad
  have hμb1 := haar_ball_toReal_le_one (δ / (4 * (nB N M m k b : ℝ) + 1))
  have hlog1 : Real.log ((haarSU2 (Metric.ball 1 (δ / Ls))).toReal)
      ≤ Real.log ((haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal) :=
    Real.log_le_log hμs hμmono
  have hlog2 : Real.log ((haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal) ≤ 0 :=
    Real.log_nonpos (hμs.le.trans hμmono) hμb1
  have hn : (Fintype.card (Inner N M m k b) : ℝ) ≤ ((N * N * ((2 * m) * (2 * m)) * 4 : ℕ) : ℝ) := by
    exact_mod_cast card_Inner_le N M m k hk b
  have hc : Real.log (Fintype.card (Fib M m k b → ℤˣ) : ℝ) ≤ (((2 * m) * (2 * m) : ℕ) : ℝ) * Real.log 2 := by
    rw [Fintype.card_fun, Fintype.card_units_int, Nat.cast_pow, Real.log_pow]
    have := card_Fib_le M m k hk b
    have hl : 0 ≤ Real.log 2 := Real.log_nonneg (by norm_num)
    exact mul_le_mul_of_nonneg_right (by exact_mod_cast this) hl
  have hn0 : (0 : ℝ) ≤ (Fintype.card (Inner N M m k b) : ℝ) := Nat.cast_nonneg _
  have key : -((Fintype.card (Inner N M m k b) : ℝ)
      * Real.log ((haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal))
      ≤ -(((N * N * ((2 * m) * (2 * m)) * 4 : ℕ) : ℝ) * Real.log ((haarSU2 (Metric.ball 1 (δ / Ls))).toReal)) := by
    nlinarith [mul_le_mul_of_nonneg_left hlog1 hn0]
  linarith

theorem Dmax_le [NeZero m] (hk : M < (k + 1) * m) {δ : ℝ} (hδ : 0 < δ) :
    Dmax N M m k δ ≤ Dstar N m δ :=
  ciSup_le fun b => Db_le N M m k hk b hδ

theorem kappaC_le [NeZero m] (hM : m * k ≤ M) (hk : M < (k + 1) * m) (n12 : Bool) :
    kappaC N M m k n12 ≤ 2 * ((N * N * ((2 * m) * (2 * m)) * 6 : ℕ) : ℝ) := by
  refine ciSup_le fun p => ?_
  have hnB : (nB N M m k p.1 : ℝ) ≤ ((N * N * ((2 * m) * (2 * m)) * 6 : ℕ) : ℝ) := by
    exact_mod_cast nB_le N M m k hk p.1
  have hb : ∀ s : ℝ, (s = 1 ∨ s = -1) →
      0 ≤ SminC N M m k n12 p.1 p.2 s ∧ SminC N M m k n12 p.1 p.2 s ≤ 2 * (nB N M m k p.1 : ℝ) := by
    intro s hs
    haveI := cls_nonempty M m k hM p.1 s hs
    obtain ⟨σ0⟩ := cls_nonempty M m k hM p.1 s hs
    exact ⟨le_ciInf fun q => actB_nonneg N M m k n12 p.1 _ (abs_ext_le M m k p.1 q.2.1) _,
      (SminC_le N M m k n12 p.1 p.2 s (fun _ => 1) σ0.1 σ0.2).trans
        (actB_le N M m k n12 p.1 _ (abs_ext_le M m k p.1 σ0.1) _)⟩
  obtain ⟨a1, a2⟩ := hb 1 (Or.inl rfl)
  obtain ⟨b1, b2⟩ := hb (-1) (Or.inr rfl)
  rw [abs_le]; constructor <;> linarith

/-- **定理 E の m を止めた形**（段 4 を仮定の欄 `hK` に）：`m·k ≤ M < (k+1)m`、β ≥ 0、δ > 0、
`κ_c ≤ K₀` なら `θ_M ≤ exp(−k² · exp(−(β (K₀ + 2δ) + D*(N, m, δ))))`。D* は M・β に依らない。
`hK` は `kappaC_le` で `K₀ = 12 N² (2m)²` として常に満たせる。 -/
theorem theta_fixed_m [NeZero m] (hM : m * k ≤ M) (hk : M < (k + 1) * m) (β : ℝ) (hβ : 0 ≤ β)
    (n12 : Bool) {δ : ℝ} (hδ : 0 < δ) (K₀ : ℝ) (hK : kappaC N M m k n12 ≤ K₀) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.exp (-((k : ℝ) ^ 2) * Real.exp (-(β * (K₀ + 2 * δ) + Dstar N m δ))) := by
  refine (theta_laplace N M m k hM β hβ n12 hδ).trans (Real.exp_le_exp.mpr ?_)
  have hD := Dmax_le N M m k hk hδ
  have hA : β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ ≤ β * (K₀ + 2 * δ) + Dstar N m δ := by
    have := mul_le_mul_of_nonneg_left (by linarith : kappaC N M m k n12 + 2 * δ ≤ K₀ + 2 * δ) hβ
    linarith
  have he := Real.exp_le_exp.mpr (neg_le_neg hA)
  have hk2 : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
  nlinarith [mul_le_mul_of_nonneg_left he hk2]

end TwistBlocks

#print axioms TwistBlocks.theta_fixed_m
#print axioms TwistBlocks.kappaC_le
#print axioms TwistBlocks.Dmax_le
