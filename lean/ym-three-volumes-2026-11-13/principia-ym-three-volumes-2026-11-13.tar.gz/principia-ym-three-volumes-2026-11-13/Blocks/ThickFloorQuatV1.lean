import Blocks.ThickFloorAbstractV1

/-!
# (c1) の残り：反可換な単位四元数の組は一つの共役類（`(i, j)` に共役）

紙： 命題 4.1 (c)「SU(2) で ABA⁻¹B⁻¹ = −1 を満たす組は tr A = tr B = 0 かつ A ⊥ B で、
SO(3) の作用で一つの軌道」。ここでは軌道の代表を陽に作る：
`L(h) = h − i h a − j h b − k h (ab)` は `L(h) a = i L(h)`、`L(h) b = j L(h)` を満たし（`a² = b² = −1`、
`ab = −ba` だけを使う）、`Σ_{e ∈ {1,i,j,k}} Re(ē L(e)) = 4`（どの a, b でも）なので、どれかの e で L(e) ≠ 0。
g := L(e) で `g a g⁻¹ = i`、`g b g⁻¹ = j`。
-/

namespace ThickFloor

local notation "ℍr" => Quaternion ℝ

def qi : ℍr := ⟨0, 1, 0, 0⟩
def qj : ℍr := ⟨0, 0, 1, 0⟩
def qk : ℍr := ⟨0, 0, 0, 1⟩

@[simp] theorem qi_re : qi.re = 0 := rfl
@[simp] theorem qi_imI : qi.imI = 1 := rfl
@[simp] theorem qi_imJ : qi.imJ = 0 := rfl
@[simp] theorem qi_imK : qi.imK = 0 := rfl
@[simp] theorem qj_re : qj.re = 0 := rfl
@[simp] theorem qj_imI : qj.imI = 0 := rfl
@[simp] theorem qj_imJ : qj.imJ = 1 := rfl
@[simp] theorem qj_imK : qj.imK = 0 := rfl
@[simp] theorem qk_re : qk.re = 0 := rfl
@[simp] theorem qk_imI : qk.imI = 0 := rfl
@[simp] theorem qk_imJ : qk.imJ = 0 := rfl
@[simp] theorem qk_imK : qk.imK = 1 := rfl

theorem qi_qi : qi * qi = -1 := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num
theorem qi_qj : qi * qj = qk := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num
theorem qi_qk : qi * qk = -qj := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num
theorem qj_qi : qj * qi = -qk := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num
theorem qj_qj : qj * qj = -1 := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num
theorem qj_qk : qj * qk = qi := by
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one] <;> norm_num

/-- 絡みの写像 `L(h) = h − i h a − j h b − k h (ab)` -/
noncomputable def Lmap (a b h : ℍr) : ℍr := h - qi * h * a - qj * h * b - qk * h * (a * b)

theorem Lmap_a (a b h : ℍr) (ha : a * a = -1) (hab : a * b = -(b * a)) :
    Lmap a b h * a = qi * Lmap a b h := by
  have e1 : b * a = -(a * b) := by rw [hab, neg_neg]
  have e2 : a * b * a = b := by
    rw [mul_assoc, e1, mul_neg, ← mul_assoc, ha, neg_one_mul, neg_neg]
  have l : Lmap a b h * a = h * a - qi * h * (a * a) - qj * h * (b * a) - qk * h * (a * b * a) := by
    unfold Lmap; noncomm_ring
  have r : qi * Lmap a b h = qi * h - (qi * qi) * h * a - (qi * qj) * h * b - (qi * qk) * h * (a * b) := by
    unfold Lmap; noncomm_ring
  rw [l, r, ha, e1, e2, qi_qi, qi_qj, qi_qk]
  noncomm_ring

theorem Lmap_b (a b h : ℍr) (hb : b * b = -1) :
    Lmap a b h * b = qj * Lmap a b h := by
  have e2 : a * b * b = -a := by rw [mul_assoc, hb, mul_neg, mul_one]
  have l : Lmap a b h * b = h * b - qi * h * (a * b) - qj * h * (b * b) - qk * h * (a * b * b) := by
    unfold Lmap; noncomm_ring
  have r : qj * Lmap a b h = qj * h - (qj * qi) * h * a - (qj * qj) * h * b - (qj * qk) * h * (a * b) := by
    unfold Lmap; noncomm_ring
  rw [l, r, hb, e2, qj_qi, qj_qj, qj_qk]
  noncomm_ring

-- 跡の恒等式：`Σ_e Re(ē L(e)) = 4`（a, b は任意）
set_option maxRecDepth 20000 in
theorem Lmap_trace (a b : ℍr) :
    (star (1 : ℍr) * Lmap a b 1).re + (star qi * Lmap a b qi).re + (star qj * Lmap a b qj).re
      + (star qk * Lmap a b qk).re = 4 := by
  simp only [Lmap, qi_re, qi_imI, qi_imJ, qi_imK, qj_re, qj_imI, qj_imJ, qj_imK, qk_re, qk_imI, qk_imJ, qk_imK, Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul,
    Quaternion.imK_mul, Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub,
    Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star, Quaternion.imK_star,
    Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one, star_one]
  ring

theorem exists_Lmap_ne (a b : ℍr) : ∃ e : ℍr, Lmap a b e ≠ 0 := by
  by_contra h
  push_neg at h
  have := Lmap_trace a b
  rw [h 1, h qi, h qj, h qk] at this
  simp only [mul_zero, Quaternion.re_zero] at this
  norm_num at this

/-- **(c1) 一つの共役類**：単位四元数 A・B が `AB = −BA` なら、ある g ≠ 0 で `gAg⁻¹ = i`、`gBg⁻¹ = j`
（g は g/|g| に替えても同じ。単位四元数の共役） -/
theorem anticomm_conj (A B : ℍr) (hA : Quaternion.normSq A = 1) (hB : Quaternion.normSq B = 1)
    (h : A * B = -(B * A)) : ∃ g : ℍr, g ≠ 0 ∧ g * A * g⁻¹ = qi ∧ g * B * g⁻¹ = qj := by
  obtain ⟨ha0, hb0, _⟩ := anticomm_unit A B hA hB h
  have sq : ∀ X : ℍr, X.re = 0 → Quaternion.normSq X = 1 → X * X = -1 := by
    intro X h0 h1
    rw [Quaternion.normSq_def'] at h1
    apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul, Quaternion.re_neg, Quaternion.imI_neg, Quaternion.imJ_neg, Quaternion.imK_neg, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one, Quaternion.imK_one, h0] <;>
      nlinarith [h1]
  obtain ⟨e, he⟩ := exists_Lmap_ne A B
  refine ⟨Lmap A B e, he, ?_, ?_⟩
  · rw [Lmap_a A B e (sq A ha0 hA) h, mul_assoc, mul_inv_cancel₀ he, mul_one]
  · rw [Lmap_b A B e (sq B hb0 hB), mul_assoc, mul_inv_cancel₀ he, mul_one]

/-- 平坦な升：単位四元数 u と z = ±1 で `z · Re u = 1` なら `u = z`（作用 0 の升は捩れの符号そのもの） -/
theorem eq_of_re_eq_one (u : ℍr) (hu : Quaternion.normSq u = 1) (z : ℝ) (hz : z = 1 ∨ z = -1)
    (h : z * u.re = 1) : u = (z : ℍr) := by
  rw [Quaternion.normSq_def'] at hu
  have hre : u.re = z := by rcases hz with rfl | rfl <;> linarith
  have hz2 : z ^ 2 = 1 := by rcases hz with rfl | rfl <;> norm_num
  have h1 : u.imI = 0 := by nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]
  have h2 : u.imJ = 0 := by nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]
  have h3 : u.imK = 0 := by nlinarith [sq_nonneg u.imI, sq_nonneg u.imJ, sq_nonneg u.imK]
  apply Quaternion.ext <;> simp [hre, h1, h2, h3]

end ThickFloor

#print axioms ThickFloor.anticomm_conj
#print axioms ThickFloor.eq_of_re_eq_one
