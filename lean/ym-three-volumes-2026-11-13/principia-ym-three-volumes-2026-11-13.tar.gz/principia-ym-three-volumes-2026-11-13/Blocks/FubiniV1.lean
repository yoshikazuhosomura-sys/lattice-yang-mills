import Mathlib

/-!
# 枠を止めると塊ごとの積分の積に割れる（Fubini の塊の版）と、その上の符号の積の上界

紙： 補題 2.1b（芯）を、有限和でなく直積の確率測度の積分で。
配位 `ω : L → G`（直積の確率測度 `Measure.pi (fun _ => ν)`）。枠 `fr : L → Prop`、
枠でないリンクの塊 `blk`。塊 `b` の因子 `P b` は枠と塊 `b` の内部の値だけに依る（`hloc`）。
`glue d b F y`：枠に `F`、塊 `b` の内部に `y`、他は `d` を置いた配位。
-/

open MeasureTheory Finset

namespace BlockFubini

variable {L : Type*} [Fintype L] [DecidableEq L] {Bk : Type*} [Fintype Bk] [DecidableEq Bk]
  {G : Type*} [MeasurableSpace G]

/-- 枠の配位 `F` と塊 `b` の内部の配位 `y` を貼り合わせる（ほかは `d`） -/
def glue (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk) (d : G) (b : Bk)
    (F : {ℓ // fr ℓ} → G) (y : {x : {ℓ // ¬ fr ℓ} // blk x = b} → G) : L → G :=
  fun ℓ => if h : fr ℓ then F ⟨ℓ, h⟩ else if h' : blk ⟨ℓ, h⟩ = b then y ⟨⟨ℓ, h⟩, h'⟩ else d

theorem measurable_glue (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk) (d : G)
    (b : Bk) (F : {ℓ // fr ℓ} → G) : Measurable (glue fr blk d b F) := by
  rw [measurable_pi_iff]
  intro ℓ
  unfold glue
  by_cases h : fr ℓ
  · simp only [h, dite_true]; exact measurable_const
  · simp only [h, dite_false]
    by_cases h' : blk ⟨ℓ, h⟩ = b
    · simp only [h', dite_true]; exact measurable_pi_apply _
    · simp only [h', dite_false]; exact measurable_const

/-- 添字の分け：`L ≃ 枠 ⊕ Σ b, (塊 b の内部)` -/
def splitEquiv (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk) :
    {ℓ // fr ℓ} ⊕ (Σ b, {x : {ℓ // ¬ fr ℓ} // blk x = b}) ≃ L :=
  (Equiv.sumCongr (Equiv.refl _) (Equiv.sigmaFiberEquiv blk)).trans (Equiv.sumCompl fr)

/-- 配位の空間の分け（可測な同型）：`(枠 → G) × Π b, (塊 b の内部 → G) ≃ᵐ (L → G)` -/
def splitCfg (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk) :
    (({ℓ // fr ℓ} → G) × ((b : Bk) → {x : {ℓ // ¬ fr ℓ} // blk x = b} → G)) ≃ᵐ (L → G) :=
  ((MeasurableEquiv.prodCongr (MeasurableEquiv.refl _)
      (MeasurableEquiv.piCurry (fun b (_ : {x : {ℓ // ¬ fr ℓ} // blk x = b}) => G)).symm).trans
    (MeasurableEquiv.sumPiEquivProdPi
      (fun _ : {ℓ // fr ℓ} ⊕ (Σ b, {x : {ℓ // ¬ fr ℓ} // blk x = b}) => G)).symm).trans
    (MeasurableEquiv.piCongrLeft (fun _ : L => G) (splitEquiv fr blk))

theorem splitCfg_frame (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk)
    (F : {ℓ // fr ℓ} → G) (w : (b : Bk) → {x : {ℓ // ¬ fr ℓ} // blk x = b} → G)
    (x : {ℓ // fr ℓ}) : splitCfg fr blk (F, w) x.1 = F x := by
  have hx : x.1 = splitEquiv fr blk (Sum.inl x) := rfl
  unfold splitCfg
  rw [MeasurableEquiv.trans_apply, MeasurableEquiv.coe_piCongrLeft, hx,
    Equiv.piCongrLeft_apply_apply]
  rfl

theorem splitCfg_block (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk)
    (F : {ℓ // fr ℓ} → G) (w : (b : Bk) → {x : {ℓ // ¬ fr ℓ} // blk x = b} → G)
    (b : Bk) (y : {x : {ℓ // ¬ fr ℓ} // blk x = b}) : splitCfg fr blk (F, w) y.1.1 = w b y := by
  have hx : y.1.1 = splitEquiv fr blk (Sum.inr ⟨b, y⟩) := by
    obtain ⟨⟨ℓ, h⟩, rfl⟩ := y; rfl
  unfold splitCfg
  rw [MeasurableEquiv.trans_apply, MeasurableEquiv.coe_piCongrLeft, hx,
    Equiv.piCongrLeft_apply_apply]
  rfl

variable (ν : Measure G) [IsProbabilityMeasure ν]

theorem measurePreserving_splitCfg (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk) :
    MeasurePreserving (splitCfg fr blk)
      ((Measure.pi fun _ : {ℓ // fr ℓ} => ν).prod
        (Measure.pi fun b : Bk => Measure.pi fun _ : {x : {ℓ // ¬ fr ℓ} // blk x = b} => ν))
      (Measure.pi fun _ : L => ν) := by
  have h1 : MeasurePreserving
      (MeasurableEquiv.piCurry (fun b (_ : {x : {ℓ // ¬ fr ℓ} // blk x = b}) => G)).symm
      (Measure.pi fun b : Bk => Measure.pi fun _ : {x : {ℓ // ¬ fr ℓ} // blk x = b} => ν)
      (Measure.pi fun _ : (Σ b, {x : {ℓ // ¬ fr ℓ} // blk x = b}) => ν) := by
    refine ⟨(MeasurableEquiv.piCurry _).symm.measurable, ?_⟩
    have := Measure.infinitePi_map_piCurry_symm
      (X := fun b (_ : {x : {ℓ // ¬ fr ℓ} // blk x = b}) => G) (fun _ _ => ν)
    simp only [Measure.infinitePi_eq_pi] at this
    exact this
  have h2 := (MeasurePreserving.id (Measure.pi fun _ : {ℓ // fr ℓ} => ν)).prod h1
  have h3 := measurePreserving_sumPiEquivProdPi_symm
    (fun _ : {ℓ // fr ℓ} ⊕ (Σ b, {x : {ℓ // ¬ fr ℓ} // blk x = b}) => ν)
  have h4 := measurePreserving_piCongrLeft (fun _ : L => ν) (splitEquiv fr blk)
  exact h4.comp (h3.comp h2)

/-- **Fubini の塊の版**：塊ごとの因子が枠と自分の内部にしか依らなければ、
`∫ Π_b P_b = ∫_F Π_b ∫_y P_b(glue F y)`。 -/
theorem integral_prod_blocks (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk)
    (d : G) (P : Bk → (L → G) → ℝ) (hm : ∀ b, Measurable (P b)) (C : Bk → ℝ)
    (hbd : ∀ b ω, |P b ω| ≤ C b)
    (hloc : ∀ b ω ω', (∀ ℓ, fr ℓ → ω ℓ = ω' ℓ) →
      (∀ ℓ (h : ¬ fr ℓ), blk ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ) → P b ω = P b ω') :
    (∫ ω, ∏ b, P b ω ∂(Measure.pi fun _ : L => ν))
      = ∫ F, ∏ b, (∫ y, P b (glue fr blk d b F y) ∂(Measure.pi fun _ => ν))
          ∂(Measure.pi fun _ : {ℓ // fr ℓ} => ν) := by
  rw [← (measurePreserving_splitCfg ν fr blk).integral_comp']
  have hint : Integrable (fun p => ∏ b, P b (splitCfg fr blk p))
      ((Measure.pi fun _ : {ℓ // fr ℓ} => ν).prod
        (Measure.pi fun b : Bk => Measure.pi fun _ : {x : {ℓ // ¬ fr ℓ} // blk x = b} => ν)) := by
    refine Integrable.of_bound ?_ (∏ b, C b) (Filter.Eventually.of_forall fun p => ?_)
    · exact (Finset.measurable_prod _ fun b _ =>
        (hm b).comp (splitCfg fr blk).measurable).aestronglyMeasurable
    · rw [Real.norm_eq_abs, Finset.abs_prod]
      exact Finset.prod_le_prod (fun b _ => abs_nonneg _) (fun b _ => hbd b _)
  rw [integral_prod _ hint]
  refine integral_congr_ae (Filter.Eventually.of_forall fun F => ?_)
  have hpt : ∀ w : (b : Bk) → {x : {ℓ // ¬ fr ℓ} // blk x = b} → G,
      ∏ b, P b (splitCfg fr blk (F, w)) = ∏ b, P b (glue fr blk d b F (w b)) := by
    intro w
    refine Finset.prod_congr rfl fun b _ => hloc b _ _ ?_ ?_
    · intro ℓ h
      have := splitCfg_frame fr blk F w ⟨ℓ, h⟩
      simp only at this
      rw [this]; unfold glue; simp [h]
    · intro ℓ h hb
      have := splitCfg_block fr blk F w b ⟨⟨ℓ, h⟩, hb⟩
      simp only at this
      rw [this]; unfold glue; simp [h, hb]
  simp only
  rw [integral_congr_ae (Filter.Eventually.of_forall hpt)]
  exact integral_fintype_prod_eq_prod (fun b y => P b (glue fr blk d b F y))

/-- **段 2 の芯の積分の版**：塊ごとに、枠に一様に `|∫ Q_b| ≤ t_b ∫ P_b`（`P_b ≥ 0`）なら
`|∫ Π_b Q_b| ≤ (Π_b t_b) ∫ Π_b P_b`。 -/
theorem abs_integral_prod_blocks_le (fr : L → Prop) [DecidablePred fr] (blk : {ℓ // ¬ fr ℓ} → Bk)
    (d : G) (P Q : Bk → (L → G) → ℝ) (hmP : ∀ b, Measurable (P b)) (hmQ : ∀ b, Measurable (Q b))
    (C : Bk → ℝ) (hbdP : ∀ b ω, |P b ω| ≤ C b) (hbdQ : ∀ b ω, |Q b ω| ≤ C b)
    (hlocP : ∀ b ω ω', (∀ ℓ, fr ℓ → ω ℓ = ω' ℓ) →
      (∀ ℓ (h : ¬ fr ℓ), blk ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ) → P b ω = P b ω')
    (hlocQ : ∀ b ω ω', (∀ ℓ, fr ℓ → ω ℓ = ω' ℓ) →
      (∀ ℓ (h : ¬ fr ℓ), blk ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ) → Q b ω = Q b ω')
    (t : Bk → ℝ)
    (ht : ∀ b F, |∫ y, Q b (glue fr blk d b F y) ∂(Measure.pi fun _ => ν)|
      ≤ t b * ∫ y, P b (glue fr blk d b F y) ∂(Measure.pi fun _ => ν)) :
    |∫ ω, ∏ b, Q b ω ∂(Measure.pi fun _ : L => ν)|
      ≤ (∏ b, t b) * ∫ ω, ∏ b, P b ω ∂(Measure.pi fun _ : L => ν) := by
  rw [integral_prod_blocks ν fr blk d Q hmQ C hbdQ hlocQ,
    integral_prod_blocks ν fr blk d P hmP C hbdP hlocP]
  -- F ↦ Π_b ∫ P_b は可積分（直積の上の可積分な関数の内側の積分）
  have hintP : Integrable (fun F => ∏ b, (∫ y, P b (glue fr blk d b F y) ∂(Measure.pi fun _ => ν)))
      (Measure.pi fun _ : {ℓ // fr ℓ} => ν) := by
    refine Integrable.of_bound ?_ (∏ b, C b) (Filter.Eventually.of_forall fun F => ?_)
    · -- 可測性：直積の上の可測な関数の部分積分
      refine Finset.aestronglyMeasurable_fun_prod _ fun b _ => ?_
      have hj : Measurable (fun q : ({ℓ // fr ℓ} → G) × ({x : {ℓ // ¬ fr ℓ} // blk x = b} → G) =>
          P b (glue fr blk d b q.1 q.2)) := by
        refine (hmP b).comp ?_
        rw [measurable_pi_iff]
        intro ℓ
        unfold glue
        by_cases h : fr ℓ
        · simp only [h, dite_true]; exact (measurable_pi_apply _).comp measurable_fst
        · simp only [h, dite_false]
          by_cases h' : blk ⟨ℓ, h⟩ = b
          · simp only [h', dite_true]; exact (measurable_pi_apply _).comp measurable_snd
          · simp only [h', dite_false]; exact measurable_const
      exact (hj.stronglyMeasurable.integral_prod_right'
        (ν := Measure.pi fun _ => ν)).aestronglyMeasurable
    · rw [Real.norm_eq_abs, Finset.abs_prod]
      refine Finset.prod_le_prod (fun b _ => abs_nonneg _) (fun b _ => ?_)
      calc |∫ y, P b (glue fr blk d b F y) ∂(Measure.pi fun _ => ν)|
          ≤ ∫ y, |P b (glue fr blk d b F y)| ∂(Measure.pi fun _ => ν) :=
            abs_integral_le_integral_abs
        _ ≤ ∫ _y, C b ∂(Measure.pi fun _ => ν) :=
            integral_mono_of_nonneg (Filter.Eventually.of_forall fun _ => abs_nonneg _)
              (integrable_const _) (Filter.Eventually.of_forall fun y => hbdP b _)
        _ = C b := by simp
  rw [← integral_const_mul]
  refine (abs_integral_le_integral_abs).trans (integral_mono_of_nonneg
    (Filter.Eventually.of_forall fun _ => abs_nonneg _) (hintP.const_mul _)
    (Filter.Eventually.of_forall fun F => ?_))
  simp only
  rw [Finset.abs_prod, ← Finset.prod_mul_distrib]
  exact Finset.prod_le_prod (fun b _ => abs_nonneg _) (fun b _ => ht b F)

end BlockFubini

#print axioms BlockFubini.integral_prod_blocks
#print axioms BlockFubini.abs_integral_prod_blocks_le
