import Blocks.ThickFloorHalfSplitV1

/-!
# 鏡映の対の形（対称性と Cauchy–Schwarz）と、面の上の関数の挟み込み（M が偶数）

`HalfSplit` の鏡映 Θ（x₄ ↦ −x₄、面 x₄ = 0・M/2）について、閉じた上の半分だけに依る有界可測な
F・G の対 ⟪F, G⟫ := ∫ F(Θω) G(ω) dω は
* 対称（`pair_symm`：Θ は測度を保つ対合）、
* 半正定値（`half_pairing_nonneg`）、
* よって Cauchy–Schwarz ⟪F, G⟫² ≤ ⟪F, F⟫ ⟪G, G⟫（`pair_cauchy_schwarz`）。
* 面の上のリンクだけに依る ψ は Θ で変わらない（`fixFun_refl`）。よって
  ∫ ψ · w_{glueEta η₁ η₂} = ⟪ψ·a_{η₂}, a_{η₁}⟫（`insert_fix`）。
-/

open Finset MeasureTheory TwistedWilson TwistedPlane

namespace HalfSplit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem Th_mp : MeasurePreserving (Th N M) (haarCfg N M) (haarCfg N M) := by
  have h1 := measurePreserving_piCongrLeft (fun _ : Link N M => haarSU2) (thL_invol N M).toPerm
  have h2 := measurePreserving_pi (fun _ : Link N M => haarSU2) (fun _ : Link N M => haarSU2)
    (f := fun ℓ => sgL N M ℓ) (fun ℓ => sgL_mp N M ℓ)
  have h := h2.comp h1
  unfold haarCfg
  convert h using 1
  funext ω ℓ
  simp only [Th, ThickFloorRP.LinkReflection.linkRefl, Function.comp]
  rw [ThickFloorRP.LinkReflection.piCongrLeft_const, Function.Involutive.toPerm_symm,
    Function.Involutive.coe_toPerm]

theorem Th_Th (ω : Link N M → SU2) : Th N M (Th N M ω) = ω := by
  funext ℓ
  obtain ⟨x, d⟩ := ℓ
  by_cases hd : d = 3
  · subst hd
    apply Subtype.ext
    rw [Th_three, Th_three, star_star, rS_rS3]
  · rw [Th_ne N M _ x d hd, Th_ne N M _ _ d hd, rS_rS]

theorem integral_Th (H : (Link N M → SU2) → ℝ) (hH : Measurable H) :
    ∫ ω, H (Th N M ω) ∂(haarCfg N M) = ∫ ω, H ω ∂(haarCfg N M) := by
  conv_rhs => rw [← (Th_mp N M).map_eq]
  rw [integral_map (Th_mp N M).measurable.aemeasurable hH.aestronglyMeasurable]

theorem measurable_Th : Measurable (Th N M) := (Th_mp N M).measurable

/-- 対の対称性 -/
theorem pair_symm (F G : (Link N M → SU2) → ℝ) (hF : Measurable F) (hG : Measurable G) :
    ∫ ω, F (Th N M ω) * G ω ∂(haarCfg N M) = ∫ ω, G (Th N M ω) * F ω ∂(haarCfg N M) := by
  rw [← integral_Th N M (fun ω => G (Th N M ω) * F ω)
    ((hG.comp (measurable_Th N M)).mul hF)]
  simp only [Th_Th]
  congr 1; funext ω; ring

theorem integrable_pair (F G : (Link N M → SU2) → ℝ) (hF : Measurable F) (hG : Measurable G)
    (CF CG : ℝ) (hFC : ∀ ω, |F ω| ≤ CF) (hGC : ∀ ω, |G ω| ≤ CG) :
    Integrable (fun ω => F (Th N M ω) * G ω) (haarCfg N M) := by
  refine Integrable.of_bound ((hF.comp (measurable_Th N M)).mul hG).aestronglyMeasurable (CF * CG)
    (Filter.Eventually.of_forall fun ω => ?_)
  rw [Real.norm_eq_abs, abs_mul]
  exact mul_le_mul (hFC _) (hGC _) (abs_nonneg _) ((abs_nonneg _).trans (hFC ω))

/-- **Cauchy–Schwarz の対の形**（M が偶数、閉じた上の半分だけに依る有界可測な F・G）：
`(∫ F(Θω) G(ω))² ≤ (∫ F(Θω) F(ω)) · (∫ G(Θω) G(ω))` -/
theorem pair_cauchy_schwarz (hM : M % 2 = 0) (F G : (Link N M → SU2) → ℝ)
    (hF : Measurable F) (hG : Measurable G) (CF CG : ℝ) (hFC : ∀ ω, |F ω| ≤ CF)
    (hGC : ∀ ω, |G ω| ≤ CG)
    (hdF : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω')
    (hdG : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → G ω = G ω') :
    (∫ ω, F (Th N M ω) * G ω ∂(haarCfg N M)) ^ 2
      ≤ (∫ ω, F (Th N M ω) * F ω ∂(haarCfg N M)) * ∫ ω, G (Th N M ω) * G ω ∂(haarCfg N M) := by
  set A := ∫ ω, F (Th N M ω) * F ω ∂(haarCfg N M)
  set B := ∫ ω, F (Th N M ω) * G ω ∂(haarCfg N M)
  set C := ∫ ω, G (Th N M ω) * G ω ∂(haarCfg N M)
  have hB' : ∫ ω, G (Th N M ω) * F ω ∂(haarCfg N M) = B := (pair_symm N M F G hF hG).symm
  have iFF := integrable_pair N M F F hF hF CF CF hFC hFC
  have iFG := integrable_pair N M F G hF hG CF CG hFC hGC
  have iGF := integrable_pair N M G F hG hF CG CF hGC hFC
  have iGG := integrable_pair N M G G hG hG CG CG hGC hGC
  have hq : ∀ t : ℝ, 0 ≤ C * (t * t) + 2 * B * t + A := by
    intro t
    have h := half_pairing_nonneg N M hM (fun ω => F ω + t * G ω) (hF.add (measurable_const.mul hG))
      (CF + |t| * CG) (fun ω => (abs_add_le _ _).trans (add_le_add (hFC ω)
        (by rw [abs_mul]; exact mul_le_mul_of_nonneg_left (hGC ω) (abs_nonneg _))))
      (fun ω ω' h => by rw [hdF ω ω' h, hdG ω ω' h])
    have e : ∀ ω, (F (Th N M ω) + t * G (Th N M ω)) * (F ω + t * G ω)
        = F (Th N M ω) * F ω + t * (F (Th N M ω) * G ω) + t * (G (Th N M ω) * F ω)
          + (t * t) * (G (Th N M ω) * G ω) := fun ω => by ring
    rw [integral_congr_ae (Filter.Eventually.of_forall e)] at h
    have j1 : Integrable (fun ω => F (Th N M ω) * F ω + t * (F (Th N M ω) * G ω)) (haarCfg N M) :=
      iFF.add (iFG.const_mul t)
    have j2 : Integrable (fun ω => F (Th N M ω) * F ω + t * (F (Th N M ω) * G ω)
        + t * (G (Th N M ω) * F ω)) (haarCfg N M) := j1.add (iGF.const_mul t)
    rw [integral_add j2 (iGG.const_mul _), integral_add j1 (iGF.const_mul t),
      integral_add iFF (iFG.const_mul t), integral_const_mul, integral_const_mul,
      integral_const_mul, hB'] at h
    linarith
  have hd := discrim_le_zero hq
  unfold discrim at hd
  nlinarith [hd]

/-- 面の上のリンク（`fixL`）だけに依る関数は鏡映で変わらない -/
theorem fixFun_refl (ψ : (Link N M → SU2) → ℝ)
    (hψ : ∀ ω ω', (∀ ℓ, fixL N M ℓ → ω ℓ = ω' ℓ) → ψ ω = ψ ω') (ω : Link N M → SU2) :
    ψ (Th N M ω) = ψ ω := by
  refine hψ _ _ fun ℓ hℓ => ?_
  have h := fix_cond N M ℓ hℓ
  show sgL N M ℓ (ω (thL N M ℓ)) = ω ℓ
  rw [h.1, h.2]

/-- **面の上の関数の挟み込み**：`ψ(ω) w_{glueEta η₁ η₂}(ω) = (ψ a_{η₂})(Θω) · a_{η₁}(ω)` -/
theorem insert_fix (hM : M % 2 = 0) (β : ℝ) (η₁ η₂ : Pt M → ℝ) (ψ : (Link N M → SU2) → ℝ)
    (hψ : ∀ ω ω', (∀ ℓ, fixL N M ℓ → ω ℓ = ω' ℓ) → ψ ω = ψ ω') (ω : Link N M → SU2) :
    ψ ω * wE N M β (glueEta M η₁ η₂) ω
      = (ψ (Th N M ω) * aW N M β η₂ (Th N M ω)) * aW N M β η₁ ω := by
  rw [← aW_mul_refl N M hM, fixFun_refl N M ψ hψ]; ring

end HalfSplit

#print axioms HalfSplit.pair_cauchy_schwarz
#print axioms HalfSplit.insert_fix
#print axioms HalfSplit.pair_symm
