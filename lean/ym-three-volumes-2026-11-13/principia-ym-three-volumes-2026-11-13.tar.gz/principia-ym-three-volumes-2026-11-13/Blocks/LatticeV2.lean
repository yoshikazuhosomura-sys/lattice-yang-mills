import Wilson.ThetaV1

/-!
# (3,4) 平面を塊に分ける（全ての M ≥ m·k）：枠・塊の添字・升の型ごとの点検（紙の補題 2.1a）

紙：（枠・内部）、補題 2.1a、§2.1 の直し (i)（M が m の倍数でないとき）。
`m·k ≤ M`。境の線は `y.val ∈ {0, m, 2m, …, (k−1)m}`（`onLine`）。塊の番号 `q y = min(y.val / m, k − 1)`。
塊は一辺 m が k − 1 本と、最後の幅 `M − (k−1)m ∈ [m, 2m)`（M = m·k ならちょうど一辺 m の正方形）。

* 枠 `fr m ℓ`：向き 3（`Fin 4` の 2）のリンクは `x₄` が線の上、向き 4（3）は `x₃` が線の上、
  向き 1・2（0・1）は二次元の点が線の上（`x₃` か `x₄` が線の上）。
* リンク・升の塊：二次元の点 `(x₃,x₄)` の `(q x₃, q x₄)`。
* `blk_l1`〜`blk_l4`（補題 2.1a）：升 `B` の枠でないリンクの塊は `B` の塊。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane

namespace TwistBlocks

open TwistedWilson

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- 塊の番号（一つの座標） -/
def q (y : ZMod M) : Fin k := ⟨min (y.val / m) (k - 1), by have := NeZero.pos k; omega⟩

/-- 境の線の上 -/
def onLine (y : ZMod M) : Prop := y.val % m = 0 ∧ y.val < m * k

instance (y : ZMod M) : Decidable (onLine M m k y) := by unfold onLine; infer_instance

/-- 二次元の点の塊 -/
def blk2 (s : Pt M) : Fin k × Fin k := (q M m k s.1, q M m k s.2)

/-- 枠のリンク -/
def fr (ℓ : Link N M) : Prop :=
  if ℓ.2 = 2 then onLine M m k ℓ.1.2.2
  else if ℓ.2 = 3 then onLine M m k ℓ.1.2.1
  else (onLine M m k ℓ.1.2.1 ∨ onLine M m k ℓ.1.2.2)

instance (ℓ : Link N M) : Decidable (fr N M m k ℓ) := by unfold fr; infer_instance

/-- 枠でないリンクの塊 -/
def blkL (x : {ℓ : Link N M // ¬ fr N M m k ℓ}) : Fin k × Fin k := blk2 M m k x.1.1.2

theorem val_succ (y : ZMod M) : (y + 1).val = (y.val + 1) % M := by
  rw [ZMod.val_add, ZMod.val_one_eq_one_mod, Nat.add_mod_mod]

/-- 線を越えない一歩では塊は変わらない -/
theorem q_succ (y : ZMod M) (h : ¬ onLine M m k (y + 1)) :
    q M m k (y + 1) = q M m k y := by
  unfold onLine at h
  rw [val_succ] at h
  unfold q
  congr 1
  rw [val_succ]
  rcases Nat.eq_zero_or_pos m with h0 | hm
  · subst h0; simp
  by_cases hlt : y.val + 1 < M
  · rw [Nat.mod_eq_of_lt hlt] at h ⊢
    by_cases hc : y.val + 1 < m * k
    · have hnd : ¬ m ∣ y.val + 1 := fun hd => h ⟨Nat.mod_eq_zero_of_dvd hd, hc⟩
      rw [Nat.succ_div, if_neg hnd, add_zero]
    · have h1 : k ≤ (y.val + 1) / m := (Nat.le_div_iff_mul_le hm).mpr (by rw [mul_comm]; omega)
      have h2 : k - 1 ≤ y.val / m := by
        refine (Nat.le_div_iff_mul_le hm).mpr ?_
        rw [Nat.sub_one_mul]
        have : m * k = k * m := mul_comm m k
        generalize k * m = P at *
        omega
      omega
  · have he : y.val + 1 = M := by have := ZMod.val_lt y; omega
    rw [he, Nat.mod_self] at h
    exact absurd ⟨Nat.zero_mod m, by
      have := NeZero.pos k
      exact Nat.mul_pos hm this⟩ h

/-- 補題 2.1a（l1：升の根もとのリンク） -/
theorem blk_l1 (B : Plaq N M) : blk2 M m k (l1 N M B).1.2 = blk2 M m k B.1.2 := rfl

/-- 補題 2.1a（l4：升の根もとのリンク） -/
theorem blk_l4 (B : Plaq N M) : blk2 M m k (l4 N M B).1.2 = blk2 M m k B.1.2 := rfl

/-- 補題 2.1a（l2 = (x + e_μ, ν)）：枠でなければ塊は升の塊 -/
theorem blk_l2 (B : Plaq N M) (h : ¬ fr N M m k (l2 N M B)) :
    blk2 M m k (l2 N M B).1.2 = blk2 M m k B.1.2 := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [l2, blk2, fr] at h ⊢
  fin_cases μ <;> fin_cases ν <;> simp [ev] at hμν h ⊢
  all_goals first
    | exact q_succ M m k _ h
    | exact q_succ M m k _ h.1
    | exact q_succ M m k _ h.2

/-- 補題 2.1a（l3 = (x + e_ν, μ)）：枠でなければ塊は升の塊 -/
theorem blk_l3 (B : Plaq N M) (h : ¬ fr N M m k (l3 N M B)) :
    blk2 M m k (l3 N M B).1.2 = blk2 M m k B.1.2 := by
  obtain ⟨x, ⟨⟨μ, ν⟩, hμν⟩⟩ := B
  simp only [l3, blk2, fr] at h ⊢
  fin_cases μ <;> fin_cases ν <;> simp [ev] at hμν h ⊢
  all_goals first
    | exact q_succ M m k _ h
    | exact q_succ M m k _ h.1
    | exact q_succ M m k _ h.2

/-- 塊 `b` の角の二次元の点 `(b₃ m, b₄ m)` は塊 `b` に入る（`m·k ≤ M`）。塊は空でない。 -/
theorem q_corner [NeZero m] (hM : m * k ≤ M) (a : Fin k) :
    q M m k ((a.val * m : ℕ) : ZMod M) = a := by
  have hm : 0 < m := NeZero.pos m
  have hlt : a.val * m < M := by
    calc a.val * m < k * m := Nat.mul_lt_mul_of_pos_right a.isLt hm
      _ = m * k := mul_comm k m
      _ ≤ M := hM
  unfold q
  ext
  simp only
  rw [ZMod.val_natCast, Nat.mod_eq_of_lt hlt, Nat.mul_div_cancel _ hm]
  have := a.isLt
  omega

theorem blk2_corner [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) :
    blk2 M m k (((b.1.val * m : ℕ) : ZMod M), ((b.2.val * m : ℕ) : ZMod M)) = b := by
  unfold blk2; rw [q_corner M m k hM, q_corner M m k hM]

end TwistBlocks
