import Blocks.ThickFloorKappaTwoV1

/-!
# 局所の模型（窓の周りの格子を M に依らない一つの型に）：升の積の一致

`LSite N V = (ZMod N)² × (Fin (V+1))²`（窓の角からのずれ）、局所の升 `LPlaq N V = ((ZMod N)² × (Fin V)²) × Plane`。
埋め込み `emb c`：ずれ (u₃, u₄) を `(c₃ + u₃, c₄ + u₄) : (ZMod M)²` に。
`hol_emb`：大きい格子の升 `embP c B` の積は、局所の配位 `ω ∘ embL c` の局所の升の積に等しい。
（§6 の 1 の最初の一歩。窓の升との一対一と、窓の作用の書き換えはまだ。）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

abbrev LSite (N V : ℕ) := (ZMod N × ZMod N) × (Fin (V + 1) × Fin (V + 1))
abbrev LLink (N V : ℕ) := LSite N V × Fin 4
abbrev LPlaq (N V : ℕ) := ((ZMod N × ZMod N) × (Fin V × Fin V)) × Plane

variable (N M : ℕ) [NeZero N] [NeZero M] (V : ℕ)

/-- (x₁, x₂) の単位のずれ（M に依らない） -/
def ev12 (μ : Fin 4) : ZMod N × ZMod N := ![(1, 0), (0, 1), (0, 0), (0, 0)] μ

/-- 局所のずれ：向き μ に一つ進めた点（μ = 3, 4 の向きだけ二次元が動く） -/
def shL (μ : Fin 4) (u : Fin V × Fin V) : Fin (V + 1) × Fin (V + 1) :=
  if μ = 2 then (u.1.succ, u.2.castSucc) else if μ = 3 then (u.1.castSucc, u.2.succ)
  else (u.1.castSucc, u.2.castSucc)

/-- 局所の升の四本のリンク -/
def ll1 (B : LPlaq N V) : LLink N V := ((B.1.1, (B.1.2.1.castSucc, B.1.2.2.castSucc)), B.2.1.1)
def ll2 (B : LPlaq N V) : LLink N V :=
  ((B.1.1 + ev12 N B.2.1.1, shL V B.2.1.1 B.1.2), B.2.1.2)
def ll3 (B : LPlaq N V) : LLink N V :=
  ((B.1.1 + ev12 N B.2.1.2, shL V B.2.1.2 B.1.2), B.2.1.1)
def ll4 (B : LPlaq N V) : LLink N V := ((B.1.1, (B.1.2.1.castSucc, B.1.2.2.castSucc)), B.2.1.2)

/-- 局所の升の積 -/
noncomputable def holL (ω : LLink N V → SU2) (B : LPlaq N V) : ℍr :=
  (ω (ll1 N V B) : ℍr) * (ω (ll2 N V B) : ℍr) * star (ω (ll3 N V B) : ℍr) * star (ω (ll4 N V B) : ℍr)

/-- 埋め込み（点・リンク・升） -/
def emb (c : Pt M) (x : LSite N V) : Site N M :=
  (x.1, (c.1 + ((x.2.1 : ℕ) : ZMod M), c.2 + ((x.2.2 : ℕ) : ZMod M)))
def embL (c : Pt M) (ℓ : LLink N V) : Link N M := (emb N M V c ℓ.1, ℓ.2)
def embP (c : Pt M) (B : LPlaq N V) : Plaq N M :=
  (emb N M V c (B.1.1, (B.1.2.1.castSucc, B.1.2.2.castSucc)), B.2)

theorem emb_shift (c : Pt M) (a : ZMod N × ZMod N) (u : Fin V × Fin V) (μ : Fin 4) :
    emb N M V c (a, (u.1.castSucc, u.2.castSucc)) + ev N M μ = emb N M V c (a + ev12 N μ, shL V μ u) := by
  unfold emb ev12 shL
  fin_cases μ <;> simp [ev, ev12] <;> ring

theorem hol_emb (c : Pt M) (ω : Link N M → SU2) (B : LPlaq N V) :
    hol N M ω (embP N M V c B) = holL N V (ω ∘ embL N M V c) B := by
  unfold hol holL embP
  simp only [l1, l2, l3, l4, ll1, ll2, ll3, ll4, Function.comp, embL, emb_shift]

/-! ## 窓の作用を局所の模型の上の関数に -/

section Win

variable (m k : ℕ) [NeZero k]

/-- 窓 `(i, j)` の角（塊 b の角から各座標で `1 + i(m₀+2)` ずらした点） -/
def wc (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ) : Pt M :=
  (((b.1.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M), ((b.2.val * m + 1 + j * (m₀ + 2) : ℕ) : ZMod M))

theorem base_lt (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ) (hi : (i + 1) * (m₀ + 2) < m)
    (u : ℕ) (hu : u < m₀ + 2) : c.val * m + 1 + i * (m₀ + 2) + u < M := by
  have h1 : (c.val + 1) * m ≤ k * m := Nat.mul_le_mul_right m c.isLt
  rw [Nat.add_mul, one_mul] at h1
  rw [Nat.add_mul, one_mul] at hi
  rw [mul_comm m k] at hM
  generalize c.val * m = A at *
  generalize i * (m₀ + 2) = B at *
  generalize k * m = C at *
  omega

theorem val_cast_win (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ) (hi : (i + 1) * (m₀ + 2) < m)
    (u : ℕ) (hu : u < m₀ + 2) :
    (((c.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M) + ((u : ℕ) : ZMod M)).val
      = c.val * m + 1 + i * (m₀ + 2) + u := by
  rw [← Nat.cast_add, ZMod.val_natCast, Nat.mod_eq_of_lt (base_lt M m k hM m₀ c i hi u hu)]

theorem q_win [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ) (hi : (i + 1) * (m₀ + 2) < m)
    (u : ℕ) (hu : u < m₀ + 2) :
    q M m k (((c.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M) + ((u : ℕ) : ZMod M)) = c := by
  apply Fin.ext
  rw [q_val, val_cast_win M m k hM m₀ c i hi u hu]
  have hm : 0 < m := NeZero.pos m
  have hd : (c.val * m + 1 + i * (m₀ + 2) + u) / m = c.val := by
    refine Nat.div_eq_of_lt_le ?_ ?_
    · omega
    · rw [Nat.add_mul, one_mul] at hi ⊢
      generalize c.val * m = A at *
      generalize i * (m₀ + 2) = B at *
      omega
  rw [hd]
  have := c.isLt
  omega

end Win

/-! ## 局所の作用（M・m・b・窓に依らない） -/

/-- 局所の捩れの符号（背景 n₁₂、n₃₄ = 0） -/
noncomputable def zL (V : ℕ) (n12 : Bool) (B : LPlaq N V) : ℝ :=
  if B.2 = p01 ∧ B.1.1 = 0 then tw n12 else 1

/-- **局所の作用** `S_L(ω) = Σ_{局所の升} (1 − z Re U)`：`LLink N V → SU2` の上の関数で、M に依らない -/
noncomputable def SL (V : ℕ) (n12 : Bool) (ωl : LLink N V → SU2) : ℝ :=
  ∑ B : LPlaq N V, (1 - zL N V n12 B * (holL N V ωl B).re)

section Win2

variable (m k : ℕ) [NeZero k]

theorem embP_inj [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (hj : (j + 1) * (m₀ + 2) < m) (B B' : LPlaq N (m₀ + 2))
    (h : embP N M (m₀ + 2) (wc M m k m₀ b i j) B = embP N M (m₀ + 2) (wc M m k m₀ b i j) B') :
    B = B' := by
  obtain ⟨⟨a, u3, u4⟩, P⟩ := B
  obtain ⟨⟨a', u3', u4'⟩, P'⟩ := B'
  simp only [embP, emb, wc, Prod.mk.injEq] at h
  obtain ⟨⟨ha, h3, h4⟩, hP⟩ := h
  have e3 := congrArg ZMod.val h3
  have e4 := congrArg ZMod.val h4
  rw [val_cast_win M m k hM m₀ b.1 i hi _ (by simp), val_cast_win M m k hM m₀ b.1 i hi _ (by simp)] at e3
  rw [val_cast_win M m k hM m₀ b.2 j hj _ (by simp), val_cast_win M m k hM m₀ b.2 j hj _ (by simp)] at e4
  simp only [Fin.val_castSucc] at e3 e4
  have : u3 = u3' := Fin.ext (by omega)
  have : u4 = u4' := Fin.ext (by omega)
  subst ha; subst hP
  simp_all

theorem inWin_of_win [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (u : ℕ) (hu : u < m₀ + 2) :
    inWin M m k m₀ c i (((c.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M) + ((u : ℕ) : ZMod M)) := by
  refine ⟨q_win M m k hM m₀ c i hi u hu, ?_, ?_⟩ <;> rw [val_cast_win M m k hM m₀ c i hi u hu]
  · omega
  · rw [Nat.add_mul, one_mul]
    generalize c.val * m = A
    generalize i * (m₀ + 2) = B
    omega

theorem win_of_inWin [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (y : ZMod M) (h : inWin M m k m₀ c i y) :
    ∃ u : Fin (m₀ + 2), y = ((c.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M) + (((u : ℕ) : ℕ) : ZMod M) := by
  obtain ⟨_, h1, h2⟩ := h
  rw [Nat.add_mul, one_mul] at h2
  have hu : y.val - c.val * m - 1 - i * (m₀ + 2) < m₀ + 2 := by
    generalize c.val * m = A at *
    generalize i * (m₀ + 2) = B at *
    omega
  refine ⟨⟨_, hu⟩, ?_⟩
  apply ZMod.val_injective M
  rw [val_cast_win M m k hM m₀ c i hi _ hu]
  generalize c.val * m = A at *
  generalize i * (m₀ + 2) = B at *
  omega

/-- **窓の作用は局所の作用**：`S_W(ω) = S_L(ω ∘ emb)`（η は標準の場、窓は角を含まない） -/
theorem actW_local [NeZero m] (hM : m * k ≤ M) (n12 : Bool) (m₀ : ℕ) (b : Fin k × Fin k)
    (i j : ℕ) (hi : (i + 1) * (m₀ + 2) < m) (hj : (j + 1) * (m₀ + 2) < m) (t : Bool)
    (ω : Link N M → SU2) :
    actW N M m k n12 m₀ b (i, j) (etaSign M m k b t) ω
      = SL N (m₀ + 2) n12 (ω ∘ embL N M (m₀ + 2) (wc M m k m₀ b i j)) := by
  set c := wc M m k m₀ b i j
  have himg : winP N M m k m₀ b (i, j) = univ.image (embP N M (m₀ + 2) c) := by
    ext B
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_image]
    constructor
    · rintro ⟨h3, h4⟩
      obtain ⟨u3, hu3⟩ := win_of_inWin M m k hM m₀ b.1 i hi _ h3
      obtain ⟨u4, hu4⟩ := win_of_inWin M m k hM m₀ b.2 j hj _ h4
      refine ⟨((B.1.1, (u3, u4)), B.2), ?_⟩
      simp only [embP, emb, c, wc, Fin.val_castSucc]
      rw [← hu3, ← hu4]
    · rintro ⟨Bl, rfl⟩
      simp only [embP, emb, c, wc, Fin.val_castSucc]
      exact ⟨inWin_of_win M m k hM m₀ b.1 i hi _ Bl.1.2.1.isLt,
        inWin_of_win M m k hM m₀ b.2 j hj _ Bl.1.2.2.isLt⟩
  unfold actW SL
  rw [himg, Finset.sum_image (fun x _ y _ h => embP_inj N M m k hM m₀ b i j hi hj x y h)]
  refine Finset.sum_congr rfl fun Bl _ => ?_
  rw [hol_emb]
  have hz : zt N M n12 false (embP N M (m₀ + 2) c Bl) = zL N (m₀ + 2) n12 Bl := by
    unfold zt zL embP emb tw
    split_ifs <;> simp_all
  have he : etaB N M (etaSign M m k b t) (embP N M (m₀ + 2) c Bl) = 1 := by
    unfold etaB
    split_ifs
    · unfold etaSign etaAt
      cases t
      · simp
      · simp only [if_true]
        rw [if_neg]
        intro hc
        have e := congrArg (fun p : Pt M => p.1.val) hc
        simp only [embP, emb, c, wc, corner, Fin.val_castSucc] at e
        rw [val_cast_win M m k hM m₀ b.1 i hi _ Bl.1.2.1.isLt, ZMod.val_natCast,
          Nat.mod_eq_of_lt] at e
        · omega
        · have := base_lt M m k hM m₀ b.1 i hi 0 (by omega)
          omega
    · rfl
  rw [hz, he, mul_one]

end Win2

end TwistBlocks

#print axioms TwistBlocks.hol_emb
#print axioms TwistBlocks.actW_local
