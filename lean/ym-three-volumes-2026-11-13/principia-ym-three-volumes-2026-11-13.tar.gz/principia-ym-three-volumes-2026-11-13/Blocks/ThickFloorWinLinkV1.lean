import Blocks.ThickFloorInnerV1

/-!
# 局所の内部のリンク（ずれ u₃, u₄ ∈ [1, m₀+1]）を含む大きい格子の升は、窓の升

`(i)` の後半：持ち上げで替えるリンクは窓の升にしか現れない（窓の外の升の作用は変わらない）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M : ℕ) [NeZero N] [NeZero M] (m k : ℕ) [NeZero k]

theorem ev_snd_cases (μ : Fin 4) :
    ∃ d3 d4 : ℕ, d3 ≤ 1 ∧ d4 ≤ 1 ∧ (ev N M μ).2 = ((d3 : ZMod M), (d4 : ZMod M)) := by
  fin_cases μ
  · exact ⟨0, 0, by norm_num, by norm_num, by simp [ev]⟩
  · exact ⟨0, 0, by norm_num, by norm_num, by simp [ev]⟩
  · exact ⟨1, 0, by norm_num, by norm_num, by simp [ev]⟩
  · exact ⟨0, 1, by norm_num, by norm_num, by simp [ev]⟩

theorem sub_cast (y : ZMod M) (A d u : ℕ) (hd : d ≤ u) (h : y + (d : ZMod M) = (A : ZMod M) + (u : ZMod M)) :
    y = (A : ZMod M) + ((u - d : ℕ) : ZMod M) := by
  rw [Nat.cast_sub hd]
  linear_combination h

/-- 局所の内部のリンクを含む升は窓の升 -/
theorem mem_winP_of_link [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (hj : (j + 1) * (m₀ + 2) < m) (ℓ : LLink N (m₀ + 2))
    (h3l : 1 ≤ (ℓ.1.2.1 : ℕ)) (h3h : (ℓ.1.2.1 : ℕ) < m₀ + 2)
    (h4l : 1 ≤ (ℓ.1.2.2 : ℕ)) (h4h : (ℓ.1.2.2 : ℕ) < m₀ + 2) (B : Plaq N M)
    (hB : l1 N M B = embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ ∨
      l2 N M B = embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ ∨
      l3 N M B = embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ ∨
      l4 N M B = embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ) :
    B ∈ winP N M m k m₀ b (i, j) := by
  set A1 := b.1.val * m + 1 + i * (m₀ + 2)
  set A2 := b.2.val * m + 1 + j * (m₀ + 2)
  set u3 : ℕ := (ℓ.1.2.1 : ℕ)
  set u4 : ℕ := (ℓ.1.2.2 : ℕ)
  -- 根もとの点が (A1 + v3, A2 + v4)、v ≤ u
  have key : ∃ v3 v4 : ℕ, v3 ≤ u3 ∧ v4 ≤ u4 ∧
      B.1.2 = ((A1 : ZMod M) + (v3 : ZMod M), (A2 : ZMod M) + (v4 : ZMod M)) := by
    have direct : B.1 = emb N M (m₀ + 2) (wc M m k m₀ b i j) ℓ.1 →
        ∃ v3 v4 : ℕ, v3 ≤ u3 ∧ v4 ≤ u4 ∧
          B.1.2 = ((A1 : ZMod M) + (v3 : ZMod M), (A2 : ZMod M) + (v4 : ZMod M)) := by
      intro h
      exact ⟨u3, u4, le_rfl, le_rfl, by rw [h]; rfl⟩
    have shifted : ∀ μ : Fin 4, B.1 + ev N M μ = emb N M (m₀ + 2) (wc M m k m₀ b i j) ℓ.1 →
        ∃ v3 v4 : ℕ, v3 ≤ u3 ∧ v4 ≤ u4 ∧
          B.1.2 = ((A1 : ZMod M) + (v3 : ZMod M), (A2 : ZMod M) + (v4 : ZMod M)) := by
      intro μ h
      obtain ⟨d3, d4, hd3, hd4, he⟩ := ev_snd_cases N M μ
      have h2 := congrArg Prod.snd h
      rw [Prod.snd_add, he] at h2
      have e3 := congrArg Prod.fst h2
      have e4 := congrArg Prod.snd h2
      simp only [Prod.fst_add, Prod.snd_add, emb, wc] at e3 e4
      refine ⟨u3 - d3, u4 - d4, Nat.sub_le _ _, Nat.sub_le _ _, Prod.ext ?_ ?_⟩
      · exact sub_cast M B.1.2.1 A1 d3 u3 (by omega) e3
      · exact sub_cast M B.1.2.2 A2 d4 u4 (by omega) e4
    rcases hB with h | h | h | h
    · exact direct (congrArg Prod.fst h)
    · exact shifted _ (congrArg Prod.fst h)
    · exact shifted _ (congrArg Prod.fst h)
    · exact direct (congrArg Prod.fst h)
  obtain ⟨v3, v4, hv3, hv4, hp⟩ := key
  simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and]
  rw [hp]
  exact ⟨inWin_of_win M m k hM m₀ b.1 i hi v3 (by omega),
    inWin_of_win M m k hM m₀ b.2 j hj v4 (by omega)⟩

end TwistBlocks

#print axioms TwistBlocks.mem_winP_of_link
