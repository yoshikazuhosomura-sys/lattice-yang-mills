import Blocks.VacuumV1

/-!
# 段 4 (a) の一歩：(+) の最小作用は枠に触れる升だけで抑えられる

紙： 命題 4.1 (a)「S_B(U*) ≤ S_B(内部を V にした配位) ≤ 2·#{枠と内部にまたがる升}」。
ここでは数え（≤ c N² m）の手前まで：`S^F_min(+) ≤ 2 · #{塊 b の升で、四本のリンクのどれかが枠のもの}`、全ての枠 F で。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- 塊 b の升で、枠のリンクに触れるもの -/
noncomputable def touchB (b : Fin k × Fin k) : Finset (Plaq N M) :=
  univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b ∧
    (fr N M m k (l1 N M B) ∨ fr N M m k (l2 N M B) ∨ fr N M m k (l3 N M B) ∨ fr N M m k (l4 N M B)))

/-- **(+) の最小作用の上界**：内部を V に、η ≡ 1 にした配位で評価する -/
theorem SminC_plus_le (b : Fin k × Fin k) (F : Frame N M m k → SU2) :
    SminC N M m k true b F 1 ≤ 2 * ((touchB N M m k b).card : ℝ) := by
  let yV : Inner N M m k b → SU2 := fun j => vac N M j.1.1
  let σ1 : Fib M m k b → ℤˣ := fun _ => 1
  have hσ : (1 : ℝ) * ∏ P, sgn (σ1 P) = 1 := by simp [σ1, sgn]
  refine (SminC_le N M m k true b F 1 yV σ1 hσ).trans ?_
  have hext : ext M m k b σ1 = fun _ => 1 := by
    funext P; unfold ext; split_ifs <;> simp [σ1, sgn]
  rw [hext]
  unfold actB
  have hterm : ∀ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
      1 - zt N M true false B * etaB N M (fun _ => 1) B * (hol N M (glueB N M m k b F yV) B).re
        ≤ if B ∈ touchB N M m k b then 2 else 0 := by
    intro B hB
    have hb : blk2 M m k B.1.2 = b := (Finset.mem_filter.mp hB).2
    have he : etaB N M (fun _ => 1) B = 1 := by unfold etaB; split_ifs <;> rfl
    by_cases ht : B ∈ touchB N M m k b
    · rw [if_pos ht]
      exact (actB_term_bounds N M true (fun _ => 1) (fun _ => by simp) _ B).2
    · rw [if_neg ht]
      have hnf : ¬ (fr N M m k (l1 N M B) ∨ fr N M m k (l2 N M B) ∨ fr N M m k (l3 N M B)
          ∨ fr N M m k (l4 N M B)) := by
        intro h; exact ht (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb, h⟩)
      simp only [not_or] at hnf
      obtain ⟨n1, n2, n3, n4⟩ := hnf
      have hg : ∀ ℓ (h : ¬ fr N M m k ℓ), blk2 M m k ℓ.1.2 = b →
          glueB N M m k b F yV ℓ = vac N M ℓ := by
        intro ℓ h hℓ
        unfold glueB BlockFubini.glue
        rw [dif_neg h, dif_pos (show blkL N M m k ⟨ℓ, h⟩ = b from hℓ)]
      have hhol : hol N M (glueB N M m k b F yV) B = hol N M (vac N M) B := by
        unfold hol
        rw [hg _ n1 ((blk_l1 N M m k B).trans hb), hg _ n2 ((blk_l2 N M m k B n2).trans hb),
          hg _ n3 ((blk_l3 N M m k B n3).trans hb), hg _ n4 ((blk_l4 N M m k B).trans hb)]
      rw [hhol, he, mul_one, vac_term N M B, sub_self]
  refine (Finset.sum_le_sum hterm).trans ?_
  rw [← Finset.sum_filter]
  have hsub : (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
      (fun B => B ∈ touchB N M m k b) = touchB N M m k b := by
    ext B; simp only [Finset.mem_filter, Finset.mem_univ, true_and, touchB]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h; exact ⟨h.1, h⟩
  rw [hsub, Finset.sum_const, nsmul_eq_mul]
  ring_nf; exact le_refl _

end TwistBlocks

#print axioms TwistBlocks.SminC_plus_le
