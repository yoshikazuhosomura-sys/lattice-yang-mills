import Blocks.ThickFloorTorusV1
import VortexCert.CertN2V1

/-!
# 太い渦の床の系（N = 2）：指数が薄い渦の床の 2N² = 8 より真に小さい陽な数

`thick_vortex_floor`（仮定の欄なし）と、証明書 `VortexCert.SN_two_le : SN 2 ≤ 667401/100000` から、
ε := 6675/1000 − SN 2 > 0 を取って、十分大きい β・M で
`|θ_{M+1}(β)| ≤ exp(−(M+1)² e^{−6.675 β})`。指数 6.675 < 8。
-/

namespace TwistBlocks

theorem thick_vortex_floor_two : ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    |thetaM 2 (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (6675 / 1000))) := by
  have hS := VortexCert.SN_two_le
  have hε : (0 : ℝ) < 6675 / 1000 - SN 2 := by linarith
  have h := thick_vortex_floor 2 _ hε
  have e : SN 2 + (6675 / 1000 - SN 2) = 6675 / 1000 := by ring
  rw [e] at h
  exact h

/-- 指数は薄い渦の床の 8 より真に小さい -/
theorem thick_vortex_floor_two_rate_lt : (6675 / 1000 : ℝ) < 2 * 2 ^ 2 := by norm_num

end TwistBlocks

#print axioms TwistBlocks.thick_vortex_floor_two
