import Blocks.StageFourKappaV1

/-!
# 段 4 の鎖：鳩の巣（閉）と、二つの名指しの仮定から (H4)・太い渦の床（旧称 定理 E）へ

紙： 命題 4.1 (a)〜(d) と補題 2.3。
* (a) 総量：`SminC_plus_uniform`・`SminC_minus_le_touch`（import の先、閉）。
* (b) 鳩の巣：この塊の中に、角からのずれが `[1 + i(m₀+2), (i+1)(m₀+2)]`（二つの座標）の窓 `(i, j)` を
  互いに升を共有しないように並べる（`winP`）。窓ごとの作用の和は塊の作用以下（`sum_actW_le`）、
  よってどれかの窓の作用は `S_B / r²` 以下（`exists_win_le`）。閉。
* 補題 2.3 の強い形を名指しの仮定 `Canon` に（類の中の符号の場は、作用を変えずに標準の場
  ≡ 1 か角の一枚に移せる）。
* (c) 剛性と (d) 貼り合わせを一つの名指しの仮定 `LocalVortex N m₀ S` に（窓の作用が δ 未満なら、
  内部を取り替えて類を反転でき、費用は `S + ε` 以下）。紙の主張は `S = S_渦(N, m₀)`。
* 結論：`Canon N` と全ての m₀ で `LocalVortex N m₀ (Svortex N m₀)` を仮定すれば (H4)（S = S_N）、
  よって `ThickVortexFloor N`（= `TheoremEStatement N`）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-! ## 窓（一辺 m₀ + 2 の、塊の中の小さい正方形の升の集合） -/

/-- 一つの座標の窓：塊の番号が `c` で、塊の角からのずれが `[1 + i(m₀+2), (i+1)(m₀+2)]` -/
def inWin (m₀ : ℕ) (c : Fin k) (i : ℕ) (y : ZMod M) : Prop :=
  q M m k y = c ∧ 1 + i * (m₀ + 2) ≤ y.val - c.val * m ∧ y.val - c.val * m ≤ (i + 1) * (m₀ + 2)

instance (m₀ : ℕ) (c : Fin k) (i : ℕ) (y : ZMod M) : Decidable (inWin M m k m₀ c i y) := by
  unfold inWin; infer_instance

/-- 窓 `w = (i, j)` の升（根もとの二次元の点が窓に入る四次元の升） -/
noncomputable def winP (m₀ : ℕ) (b : Fin k × Fin k) (w : ℕ × ℕ) : Finset (Plaq N M) :=
  univ.filter (fun B : Plaq N M => inWin M m k m₀ b.1 w.1 B.1.2.1 ∧ inWin M m k m₀ b.2 w.2 B.1.2.2)

/-- 窓の作用 `S_W = Σ_{B ∈ 窓} (1 − z_B η_B Re U_B)` -/
noncomputable def actW (n12 : Bool) (m₀ : ℕ) (b : Fin k × Fin k) (w : ℕ × ℕ) (e : Pt M → ℝ)
    (ω : Link N M → SU2) : ℝ :=
  ∑ B ∈ winP N M m k m₀ b w, (1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re)

theorem inWin_unique (m₀ : ℕ) (c : Fin k) (i i' : ℕ) (y : ZMod M)
    (h : inWin M m k m₀ c i y) (h' : inWin M m k m₀ c i' y) : i = i' := by
  obtain ⟨_, h1, h2⟩ := h
  obtain ⟨_, h1', h2'⟩ := h'
  set d := y.val - c.val * m
  have e1 : (d - 1) / (m₀ + 2) = i := by
    refine Nat.div_eq_of_lt_le ?_ ?_
    · generalize i * (m₀ + 2) = P at *; omega
    · rw [Nat.add_mul, one_mul] at h2 ⊢
      generalize i * (m₀ + 2) = P at *; omega
  have e2 : (d - 1) / (m₀ + 2) = i' := by
    refine Nat.div_eq_of_lt_le ?_ ?_
    · generalize i' * (m₀ + 2) = P at *; omega
    · rw [Nat.add_mul, one_mul] at h2' ⊢
      generalize i' * (m₀ + 2) = P at *; omega
  rw [← e1, ← e2]

/-- **(b) の数え**：互いに交わらない窓の作用の和は塊の作用以下 -/
theorem sum_actW_le (n12 : Bool) (m₀ r : ℕ) (b : Fin k × Fin k) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (ω : Link N M → SU2) :
    ∑ w : Fin r × Fin r, actW N M m k n12 m₀ b ((w.1 : ℕ), (w.2 : ℕ)) e ω
      ≤ actB N M m k n12 b e ω := by
  classical
  unfold actW actB
  have hdis : ((univ : Finset (Fin r × Fin r)) : Set (Fin r × Fin r)).PairwiseDisjoint
      (fun w : Fin r × Fin r => winP N M m k m₀ b ((w.1 : ℕ), (w.2 : ℕ))) := by
    intro w _ w' _ hne
    simp only [Function.onFun]
    rw [Finset.disjoint_left]
    intro B hB hB'
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and] at hB hB'
    apply hne
    have h1 := inWin_unique M m k m₀ b.1 _ _ _ hB.1 hB'.1
    have h2 := inWin_unique M m k m₀ b.2 _ _ _ hB.2 hB'.2
    exact Prod.ext (Fin.ext h1) (Fin.ext h2)
  rw [← Finset.sum_biUnion hdis]
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro B hB
    simp only [Finset.mem_biUnion, Finset.mem_univ, true_and] at hB
    obtain ⟨w, hw⟩ := hB
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and] at hw
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact Prod.ext hw.1.1 hw.2.1
  · intro B _ _
    exact (actB_term_bounds N M n12 e he ω B).1

/-- **(b) 鳩の巣**：r ≥ 1 なら、ある窓の作用は `S_B / r²` 以下 -/
theorem exists_win_le (n12 : Bool) (m₀ r : ℕ) (hr : 0 < r) (b : Fin k × Fin k) (e : Pt M → ℝ)
    (he : ∀ y, |e y| ≤ 1) (ω : Link N M → SU2) :
    ∃ w : Fin r × Fin r, actW N M m k n12 m₀ b ((w.1 : ℕ), (w.2 : ℕ)) e ω
      ≤ actB N M m k n12 b e ω / (r : ℝ) ^ 2 := by
  have hne : (univ : Finset (Fin r × Fin r)).Nonempty := ⟨(⟨0, hr⟩, ⟨0, hr⟩), Finset.mem_univ _⟩
  have hs := sum_actW_le N M m k n12 m₀ r b e he ω
  have hr' : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne'
  have hsum : ∑ w : Fin r × Fin r, actW N M m k n12 m₀ b ((w.1 : ℕ), (w.2 : ℕ)) e ω
      ≤ ∑ _w : Fin r × Fin r, actB N M m k n12 b e ω / (r : ℝ) ^ 2 := by
    refine hs.trans (le_of_eq ?_)
    rw [Finset.sum_const, Finset.card_univ, Fintype.card_prod, Fintype.card_fin, nsmul_eq_mul]
    push_cast
    field_simp
  obtain ⟨w, _, hw⟩ := Finset.exists_le_of_sum_le hne hsum
  exact ⟨w, hw⟩

/-! ## 名指しの仮定 -/

/-- **補題 2.3 の強い形（紙、Lean に無い）**：塊の符号の場 σ（類 `Πσ = ±1`）と内部 y に、
内部 y' が在って、標準の場（`t = false`：≡ 1、`t = true`：角の一枚の反転）での塊の作用が等しい
（紙：塊の内部の切り口の反転 R_λ は升ごとの作用を保ち、η を λ の両側の二枚で反転する。双対グラフの連結性）。 -/
def Canon (N : ℕ) [NeZero N] : Prop :=
  ∀ (M m k : ℕ) [NeZero M] [NeZero m] [NeZero k], m * k ≤ M →
    ∀ (b : Fin k × Fin k) (F : Frame N M m k → SU2) (y : Inner N M m k b → SU2)
      (σ : Fib M m k b → ℤˣ) (t : Bool), (∏ P, sgn (σ P)) = (if t then -1 else 1) →
      ∃ y' : Inner N M m k b → SU2,
        actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y')
          = actB N M m k true b (ext M m k b σ) (glueB N M m k b F y)

/-- **剛性 (c) と貼り合わせ (d) の出力（紙、Lean に無い）**：全ての ε > 0 に δ > 0 が在って、
窓 `(i, j)`（`(i+1)(m₀+2) < m`、`(j+1)(m₀+2) < m`、塊の中で角と枠から離れている）の作用が δ 未満なら、
内部を取り替えて類を反転した配位が在り、塊の作用の増えは `S + ε` 以下。紙の主張は `S = S_渦(N, m₀)`。 -/
def LocalVortex (N : ℕ) [NeZero N] (m₀ : ℕ) (S : ℝ) : Prop :=
  ∀ ε > 0, ∃ δ > 0, ∀ (M m k : ℕ) [NeZero M] [NeZero m] [NeZero k], m * k ≤ M → M < (k + 1) * m →
    ∀ (b : Fin k × Fin k) (F : Frame N M m k → SU2) (y : Inner N M m k b → SU2) (t : Bool) (i j : ℕ),
      (i + 1) * (m₀ + 2) < m → (j + 1) * (m₀ + 2) < m →
      actW N M m k true m₀ b (i, j) (etaSign M m k b t) (glueB N M m k b F y) < δ →
      ∃ (y' : Inner N M m k b → SU2) (σ' : Fib M m k b → ℤˣ),
        (∏ P, sgn (σ' P)) = (if t then 1 else -1) ∧
        actB N M m k true b (ext M m k b σ') (glueB N M m k b F y')
          ≤ actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y) + S + ε

/-! ## (a) の両側の形 -/

theorem SminC_le_lin [NeZero m] (hM : m * k ≤ M) (hk : M < (k + 1) * m) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) (s : ℝ) (hs : s = 1 ∨ s = -1) :
    SminC N M m k true b F s ≤ 144 * (N : ℝ) ^ 2 * (m : ℝ) := by
  rcases hs with rfl | rfl
  · exact SminC_plus_uniform N M m k hk b F
  · refine (SminC_minus_le_touch N M m k hM b F).trans ?_
    have ht := card_touch_le N M m k hk b
    have htr : ((touchB N M m k b).card : ℝ) ≤ ((N * N * (12 * m) * 6 : ℕ) : ℝ) := by exact_mod_cast ht
    push_cast at htr
    nlinarith

/-! ## 一つの塊・一つの枠での一歩 -/

/-- 類 s の近い最小点から、標準の場へ（Canon）、鳩の巣で窓を選び（閉）、LocalVortex で類を反転。 -/
theorem step_flip (hC : Canon N) (m₀ : ℕ) (S : ℝ) (hL : LocalVortex N m₀ S) {ε δ : ℝ} (hε : 0 < ε)
    (hLδ : ∀ (M m k : ℕ) [NeZero M] [NeZero m] [NeZero k], m * k ≤ M → M < (k + 1) * m →
      ∀ (b : Fin k × Fin k) (F : Frame N M m k → SU2) (y : Inner N M m k b → SU2) (t : Bool) (i j : ℕ),
        (i + 1) * (m₀ + 2) < m → (j + 1) * (m₀ + 2) < m →
        actW N M m k true m₀ b (i, j) (etaSign M m k b t) (glueB N M m k b F y) < δ →
        ∃ (y' : Inner N M m k b → SU2) (σ' : Fib M m k b → ℤˣ),
          (∏ P, sgn (σ' P)) = (if t then 1 else -1) ∧
          actB N M m k true b (ext M m k b σ') (glueB N M m k b F y')
            ≤ actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y) + S + ε)
    [NeZero m] (T : ℕ) (hT : 0 < T) (hmT : T * (m₀ + 2) < m)
    (hTδ : 144 * (N : ℝ) ^ 2 * (m : ℝ) + ε < δ * (T : ℝ) ^ 2)
    (hM : m * k ≤ M) (hk : M < (k + 1) * m) (b : Fin k × Fin k) (F : Frame N M m k → SU2)
    (t : Bool) (s : ℝ) (hs : s = 1 ∨ s = -1)
    (hs1 : ∀ x : ℝ, s * x = 1 → x = (if t then -1 else 1))
    (hs2 : ∀ x : ℝ, x = (if t then 1 else -1) → -s * x = 1) :
    SminC N M m k true b F (-s) ≤ SminC N M m k true b F s + S + 2 * ε := by
  have := cls_nonempty M m k hM b s hs
  obtain ⟨p0, hp0⟩ := exists_lt_of_ciInf_lt (f := fun p : (Inner N M m k b → SU2) ×
      {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1} =>
        actB N M m k true b (ext M m k b p.2.1) (glueB N M m k b F p.1))
    (show SminC N M m k true b F s < SminC N M m k true b F s + ε by linarith)
  obtain ⟨y1, hy1⟩ := hC M m k hM b F p0.1 p0.2.1 t (hs1 _ p0.2.2)
  have hS := SminC_le_lin N M m k hM hk b F s hs
  set A := actB N M m k true b (etaSign M m k b t) (glueB N M m k b F y1)
  have hA : A < SminC N M m k true b F s + ε := by
    rw [hy1]; exact hp0
  obtain ⟨w, hw⟩ := exists_win_le N M m k true m₀ T hT b (etaSign M m k b t)
    (abs_etaSign_le M m k b t) (glueB N M m k b F y1)
  have hT2 : (0 : ℝ) < (T : ℝ) ^ 2 := by positivity
  have hwδ : actW N M m k true m₀ b ((w.1 : ℕ), (w.2 : ℕ)) (etaSign M m k b t) (glueB N M m k b F y1) < δ := by
    refine hw.trans_lt ?_
    rw [div_lt_iff₀ hT2]
    linarith
  have hi : ((w.1 : ℕ) + 1) * (m₀ + 2) < m :=
    lt_of_le_of_lt (Nat.mul_le_mul_right _ w.1.isLt) hmT
  have hj : ((w.2 : ℕ) + 1) * (m₀ + 2) < m :=
    lt_of_le_of_lt (Nat.mul_le_mul_right _ w.2.isLt) hmT
  obtain ⟨y2, σ2, hσ2, hact⟩ := hLδ M m k hM hk b F y1 t w.1 w.2 hi hj hwδ
  have hle := SminC_le N M m k true b F (-s) y2 σ2 (hs2 _ hσ2)
  linarith

/-! ## (H4) と太い渦の床（`Canon` と `LocalVortex` に条件つき） -/

theorem H4_of_local (N : ℕ) [NeZero N] (hC : Canon N)
    (hL : ∀ m₀ : ℕ+, LocalVortex N m₀ (Svortex N m₀)) :
    ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ SN N + ε := by
  intro ε hε
  obtain ⟨m₀, hm₀⟩ := exists_lt_of_ciInf_lt (f := fun m : ℕ+ => Svortex N (m : ℕ))
    (show SN N < SN N + ε / 4 by linarith)
  obtain ⟨δ, hδ, hloc⟩ := hL m₀ (ε / 4) (by positivity)
  set c : ℕ := (m₀ : ℕ) + 2
  set A : ℝ := 144 * (N : ℝ) ^ 2
  obtain ⟨T, hT⟩ := exists_nat_gt ((A * ((c : ℝ) + 1) + ε / 4) / δ)
  have hA0 : 0 ≤ A := by positivity
  have hTpos' : (0 : ℝ) < (T : ℝ) := lt_of_le_of_lt (by positivity) hT
  have hTpos : 0 < T := by exact_mod_cast hTpos'
  set m : ℕ := c * T + 1
  haveI hm0 : NeZero m := ⟨by omega⟩
  refine ⟨m, hm0, fun M _ _ hMm => ?_⟩
  set k := M / m
  have hMk : m * k ≤ M := Nat.mul_div_le M m
  have hkM : M < (k + 1) * m := by
    have := Nat.lt_div_mul_add (a := M) (NeZero.pos m)
    rw [Nat.add_mul, one_mul]; exact this
  have hmT : T * ((m₀ : ℕ) + 2) < m := by simp only [m, c]; rw [mul_comm]; omega
  have hTδ : A * (m : ℝ) + ε / 4 < δ * (T : ℝ) ^ 2 := by
    have h1 : (m : ℝ) ≤ ((c : ℝ) + 1) * (T : ℝ) := by
      have : (m : ℝ) = (c : ℝ) * (T : ℝ) + 1 := by simp only [m]; push_cast; ring
      have hT1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hTpos
      rw [this]; nlinarith
    have h2 : ε / 4 ≤ ε / 4 * (T : ℝ) := by
      have hT1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hTpos
      nlinarith
    have h3 : A * ((c : ℝ) + 1) + ε / 4 < δ * (T : ℝ) := by
      have := (div_lt_iff₀ hδ).mp hT; linarith
    have h4 : A * (m : ℝ) ≤ A * (((c : ℝ) + 1) * (T : ℝ)) := mul_le_mul_of_nonneg_left h1 hA0
    nlinarith
  have key := fun (t : Bool) (s : ℝ) (hs : s = 1 ∨ s = -1)
      (hs1 : ∀ x : ℝ, s * x = 1 → x = (if t then -1 else 1))
      (hs2 : ∀ x : ℝ, x = (if t then 1 else -1) → -s * x = 1) (p : (Fin k × Fin k) × (Frame N M m k → SU2)) =>
    step_flip N M m k hC m₀ (Svortex N m₀) (hL m₀) (ε := ε / 4) (δ := δ) (by positivity)
      (fun M' m' k' _ _ _ h1 h2 b F y t i j hi hj hw => hloc M' m' k' h1 h2 b F y t i j hi hj hw)
      T hTpos hmT hTδ hMk hkM p.1 p.2 t s hs hs1 hs2
  unfold kappaC
  refine ciSup_le fun p => ?_
  have k1 := key false 1 (Or.inl rfl) (fun x h => by simpa using h) (fun x h => by simp at h; rw [h]; norm_num) p
  have k2 := key true (-1) (Or.inr rfl) (fun x h => by simp at h ⊢; linarith) (fun x h => by simp at h; rw [h]; norm_num) p
  rw [neg_neg] at k2
  have hv : Svortex N (m₀ : ℕ) < SN N + ε / 4 := hm₀
  rw [abs_le]; constructor <;> linarith

/-- 太い渦の床（旧称 定理 E）の言明。`TheoremEStatement`（書き出し済み）と同じもの。 -/
def ThickVortexFloor (N : ℕ) [NeZero N] : Prop := TheoremEStatement N

/-- 旧名の定理への別名（証明は元の定理を呼ぶだけ） -/
theorem thick_vortex_floor_of_stage4 (N : ℕ) [NeZero N]
    (H4 : ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ SN N + ε) : ThickVortexFloor N :=
  theoremE_of_stage4_SN N H4

/-- **太い渦の床（`Canon` と、全ての m₀ での `LocalVortex N m₀ (S_渦(N, m₀))` に条件つき）** -/
theorem thick_vortex_floor_of_canon_local (N : ℕ) [NeZero N] (hC : Canon N)
    (hL : ∀ m₀ : ℕ+, LocalVortex N m₀ (Svortex N m₀)) : ThickVortexFloor N :=
  thick_vortex_floor_of_stage4 N (H4_of_local N hC hL)

end TwistBlocks

#print axioms TwistBlocks.exists_win_le
#print axioms TwistBlocks.H4_of_local
#print axioms TwistBlocks.thick_vortex_floor_of_canon_local
