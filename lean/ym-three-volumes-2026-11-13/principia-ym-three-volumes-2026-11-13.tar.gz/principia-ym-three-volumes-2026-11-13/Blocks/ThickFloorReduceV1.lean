import Blocks.ThickFloorLiftV1

/-!
# 局所の言明 `LocalVortexL` を、零作用での主張 `ZeroVortexL` に帰着（(c3) コンパクト性）

`ZeroVortexL N m₀ S`：局所の作用が 0（全ての窓の升が平坦）の局所の配位 ωl に、局所の内部の値 z と
反転の位置 P₀ が在って、内部を z に替え P₀ を反転した局所の作用が S 以下。
（紙の (c) 剛性と (d) 移植の、零作用の配位についての中身。δ・ε の議論はここで閉じる。）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N : ℕ) [NeZero N]

instance (V : ℕ) : DecidablePred (intL N V) := fun ℓ => by unfold intL; infer_instance

/-- 内部を z に、他を ωl に -/
def mixL (V : ℕ) (ωl z : LLink N V → SU2) : LLink N V → SU2 :=
  fun ℓ => if intL N V ℓ then z ℓ else ωl ℓ

theorem continuous_holL_re (V : ℕ) (B : LPlaq N V) :
    Continuous fun ωl : LLink N V → SU2 => (holL N V ωl B).re := by
  have hc : ∀ ℓ : LLink N V, Continuous fun ωl : LLink N V → SU2 => (ωl ℓ : Quaternion ℝ) :=
    fun ℓ => continuous_subtype_val.comp (continuous_apply ℓ)
  unfold holL
  exact Quaternion.continuous_re.comp
    ((((hc _).mul (hc _)).mul (continuous_star.comp (hc _))).mul (continuous_star.comp (hc _)))

/-- `SLe` は (η, ωl) について連続 -/
theorem continuous_SLe2 (V : ℕ) (n12 : Bool) :
    Continuous fun q : (Fin V × Fin V → ℝ) × (LLink N V → SU2) => SLe N V n12 q.1 q.2 := by
  unfold SLe
  refine continuous_finsetSum _ fun B _ => continuous_const.sub ?_
  refine (continuous_const.mul ?_).mul ((continuous_holL_re N V B).comp continuous_snd)
  split_ifs
  · exact (continuous_apply _).comp continuous_fst
  · exact continuous_const

theorem continuous_SL (V : ℕ) (n12 : Bool) : Continuous (SL N V n12) := by
  unfold SL
  exact continuous_finsetSum _ fun B _ =>
    continuous_const.sub (continuous_const.mul (continuous_holL_re N V B))

theorem continuous_mixL (V : ℕ) :
    Continuous fun p : (LLink N V → SU2) × (LLink N V → SU2) => mixL N V p.1 p.2 := by
  refine continuous_pi fun ℓ => ?_
  unfold mixL
  by_cases h : intL N V ℓ
  · simp only [h, if_true]; exact (continuous_apply ℓ).comp continuous_snd
  · simp only [h, if_false]; exact (continuous_apply ℓ).comp continuous_fst

/-- **零作用での主張**（剛性と移植の中身、Lean に無い） -/
def ZeroVortexL (N : ℕ) [NeZero N] (m₀ : ℕ) (S : ℝ) : Prop :=
  ∀ ωl : LLink N (m₀ + 2) → SU2, SL N (m₀ + 2) true ωl ≤ 0 →
    ∃ (z : LLink N (m₀ + 2) → SU2) (P0 : Fin (m₀ + 2) × Fin (m₀ + 2)),
      SLe N (m₀ + 2) true (flipAt (m₀ + 2) P0) (mixL N (m₀ + 2) ωl z) ≤ S

theorem SL_nonneg (V : ℕ) (n12 : Bool) (ωl : LLink N V → SU2) : 0 ≤ SL N V n12 ωl := by
  unfold SL
  refine Finset.sum_nonneg fun B _ => ?_
  have hz : |zL N V n12 B| ≤ 1 := by unfold zL tw; split_ifs <;> simp
  have hr : |(holL N V ωl B).re| ≤ 1 := by
    have hn : ‖holL N V ωl B‖ = 1 := by
      unfold holL
      simp only [norm_mul, norm_star]
      have h : ∀ ℓ, ‖(ωl ℓ : Quaternion ℝ)‖ = 1 := fun ℓ => mem_sphere_zero_iff_norm.mp (ωl ℓ).2
      rw [h, h, h, h]; norm_num
    exact (abs_re_le_norm _).trans hn.le
  have := abs_mul (zL N V n12 B) (holL N V ωl B).re
  have h2 : |zL N V n12 B * (holL N V ωl B).re| ≤ 1 := by
    rw [abs_mul]; nlinarith [abs_nonneg (zL N V n12 B), abs_nonneg (holL N V ωl B).re]
  linarith [le_abs_self (zL N V n12 B * (holL N V ωl B).re)]

/-- **(c3) の当てはめ**：`ZeroVortexL` から `LocalVortexL`（δ は N・m₀・ε だけで決まる） -/
theorem localVortexL_of_zero (m₀ : ℕ) (S : ℝ) (hZ : ZeroVortexL N m₀ S) : LocalVortexL N m₀ S := by
  intro ε hε
  set V := m₀ + 2
  set K : Set ((LLink N V → SU2) × (Fin V × Fin V → ℝ)) :=
    Set.univ ×ˢ Set.range (flipAt V)
  have hK : IsCompact K := isCompact_univ.prod (Set.finite_range _).isCompact
  have hKne : K.Nonempty := ⟨(fun _ => 1, flipAt V (0, 0)), Set.mem_univ _, ⟨(0, 0), rfl⟩⟩
  let g : (LLink N V → SU2) → (LLink N V → SU2) × (Fin V × Fin V → ℝ) → ℝ :=
    fun ωl p => SLe N V true p.2 (mixL N V ωl p.1)
  have hg : Continuous ↿g := by
    have h1 : Continuous fun q : (LLink N V → SU2) × ((LLink N V → SU2) × (Fin V × Fin V → ℝ)) =>
        ((q.2.2, mixL N V q.1 q.2.1) : (Fin V × Fin V → ℝ) × (LLink N V → SU2)) :=
      (continuous_snd.comp continuous_snd).prodMk
        ((continuous_mixL N V).comp (continuous_fst.prodMk (continuous_fst.comp continuous_snd)))
    exact (continuous_SLe2 N V true).comp h1
  set Φ := fun ωl => sInf (g ωl '' K)
  have hΦ : Continuous Φ := hK.continuous_sInf hg
  have h0 : ∀ ωl, SL N V true ωl ≤ 0 → Φ ωl ≤ S := by
    intro ωl h
    obtain ⟨z, P0, hz⟩ := hZ ωl h
    have hbdd : BddBelow (g ωl '' K) :=
      hK.bddBelow_image ((hg.comp (Continuous.prodMk_right ωl)).continuousOn)
    exact (csInf_le hbdd ⟨(z, flipAt V P0), ⟨Set.mem_univ _, ⟨P0, rfl⟩⟩, rfl⟩).trans hz
  obtain ⟨δ, hδ, hsm⟩ := ThickFloor.small_action_cost (SL N V true) Φ (continuous_SL N V true) hΦ S h0 ε hε
  refine ⟨δ, hδ, fun ωl hω => ?_⟩
  have hlt := hsm ωl hω
  obtain ⟨_, ⟨⟨z, η⟩, ⟨_, ⟨P0, hP0⟩⟩, rfl⟩, hv⟩ :=
    exists_lt_of_csInf_lt (hKne.image (g ωl)) hlt
  refine ⟨mixL N V ωl z, P0, fun ℓ hl => by simp [mixL, hl], ?_⟩
  have hv' : SLe N V true (flipAt V P0) (mixL N V ωl z) < S + ε := by
    simp only [g] at hv; rw [hP0]; exact hv
  have := SL_nonneg N V true ωl
  linarith

/-- **太い渦の床は `ZeroVortexL`（零作用の局所の配位についての主張）だけに条件つき** -/
theorem thick_vortex_floor_abs_of_zero (hZ : ∀ m₀ : ℕ+, ZeroVortexL N m₀ (Svortex N m₀)) :
    ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_localL N fun m₀ => localVortexL_of_zero N m₀ _ (hZ m₀)

end TwistBlocks

#print axioms TwistBlocks.localVortexL_of_zero
#print axioms TwistBlocks.thick_vortex_floor_abs_of_zero
