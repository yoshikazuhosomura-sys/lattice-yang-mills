import Blocks.ThickFloorCenterQV1

/-!
# 命題 4.2 の部品（コンパクト性の形）：T²_N の繊維の近似の剛性と、真空の固定群の近似

* `fibre_near_vac`：T²_N = (ZMod N)² の上の配位 (A, B) の捩れた作用
  `fibAct A B = Σ_a (1 − t_a Re(A(a) B(a+e₁) A(a+e₂)* B(a)*))`（t_0 = −1、他は 1）が小さければ、
  あるゲージ g で (A, B) は真空 (AV, BV) のゲージ変換に近い（偏りの和 < ε）。δ は N と ε だけに依る。
* `stab_vacT_approx`：R : T²_N → SU(2) が真空をほぼ変えない（`stabDefect R < δ`）なら、
  R は定数 1 か定数 −1 に近い（`distPM R < ε`）。δ は N と ε だけに依る。
零の場合（`rigidT_all`・`stab_vacT`）とコンパクト性（`small_action_cost`）から。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N]

/-- 捩れの符号（T²_N の升） -/
noncomputable def twT (a : ZMod N × ZMod N) : ℝ := if a = 0 then -1 else 1

/-- T²_N の升の積 -/
noncomputable def holT (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) : ℍr :=
  (A a : ℍr) * (B (a + ev12 N 0) : ℍr) * star (A (a + ev12 N 1) : ℍr) * star (B a : ℍr)

/-- 繊維の捩れた作用 -/
noncomputable def fibAct (p : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) : ℝ :=
  ∑ a, (1 - twT N a * (holT N p.1 p.2 a).re)

/-- 真空のゲージ変換からの偏り -/
noncomputable def fibDist (p : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2))
    (g : ZMod N × ZMod N → SU2) : ℝ :=
  ∑ a, (‖(p.1 a : ℍr) - ((g a * AV N a * (g (a + ev12 N 0))⁻¹ : SU2) : ℍr)‖
    + ‖(p.2 a : ℍr) - ((g a * BV N a * (g (a + ev12 N 1))⁻¹ : SU2) : ℍr)‖)

theorem norm_holT (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) : ‖holT N A B a‖ = 1 := by
  unfold holT
  simp only [norm_mul, norm_star]
  simp [mem_sphere_zero_iff_norm.mp (A a).2, mem_sphere_zero_iff_norm.mp (B a).2,
    mem_sphere_zero_iff_norm.mp (A (a + ev12 N 1)).2, mem_sphere_zero_iff_norm.mp (B (a + ev12 N 0)).2]

theorem abs_twT (a : ZMod N × ZMod N) : |twT N a| = 1 := by
  unfold twT; split_ifs <;> simp

theorem fib_term_nonneg (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) :
    0 ≤ 1 - twT N a * (holT N A B a).re := by
  have h1 := abs_re_le_one _ (norm_holT N A B a)
  have h2 : twT N a * (holT N A B a).re ≤ |twT N a * (holT N A B a).re| := le_abs_self _
  rw [abs_mul, abs_twT, one_mul] at h2
  linarith

theorem continuous_fibAct : Continuous (fibAct N) := by
  have hc : ∀ (i : Bool) (a : ZMod N × ZMod N), Continuous fun p :
      (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2) => ((if i then p.1 a else p.2 a : SU2) : ℍr) := by
    intro i a
    cases i
    · exact continuous_subtype_val.comp ((continuous_apply a).comp continuous_snd)
    · exact continuous_subtype_val.comp ((continuous_apply a).comp continuous_fst)
  unfold fibAct holT
  refine continuous_finsetSum _ fun a _ => continuous_const.sub (continuous_const.mul ?_)
  exact Quaternion.continuous_re.comp ((((hc true a).mul (hc false _)).mul
    (continuous_star.comp (hc true _))).mul (continuous_star.comp (hc false a)))

theorem continuous_fibDist :
    Continuous fun q : ((ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) × (ZMod N × ZMod N → SU2) =>
      fibDist N q.1 q.2 := by
  have hp1 : ∀ a, Continuous fun q : ((ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) ×
      (ZMod N × ZMod N → SU2) => (q.1.1 a : ℍr) :=
    fun a => continuous_subtype_val.comp ((continuous_apply a).comp (continuous_fst.comp continuous_fst))
  have hp2 : ∀ a, Continuous fun q : ((ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) ×
      (ZMod N × ZMod N → SU2) => (q.1.2 a : ℍr) :=
    fun a => continuous_subtype_val.comp ((continuous_apply a).comp (continuous_snd.comp continuous_fst))
  have hg : ∀ a, Continuous fun q : ((ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) ×
      (ZMod N × ZMod N → SU2) => q.2 a := fun a => (continuous_apply a).comp continuous_snd
  unfold fibDist
  refine continuous_finsetSum _ fun a _ => ?_
  refine (((hp1 a).sub ?_).norm).add (((hp2 a).sub ?_).norm)
  · exact continuous_subtype_val.comp (((hg a).mul continuous_const).mul (hg _).inv)
  · exact continuous_subtype_val.comp (((hg a).mul continuous_const).mul (hg _).inv)

/-- **繊維の近似の剛性** -/
theorem fibre_near_vac : ∀ ε > 0, ∃ δ > 0, ∀ p : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2),
    fibAct N p < δ → ∃ g : ZMod N × ZMod N → SU2, fibDist N p g < ε := by
  intro ε hε
  set K : Set (ZMod N × ZMod N → SU2) := Set.univ
  have hK : IsCompact K := isCompact_univ
  have hKne : K.Nonempty := ⟨fun _ => 1, trivial⟩
  let F : ((ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2)) → (ZMod N × ZMod N → SU2) → ℝ :=
    fun p g => fibDist N p g
  have hF : Continuous ↿F := continuous_fibDist N
  set Φ := fun p => sInf (F p '' K)
  have hΦ : Continuous Φ := hK.continuous_sInf hF
  have h0 : ∀ p, fibAct N p ≤ 0 → Φ p ≤ 0 := by
    intro p hp
    have hz : ∀ a, 1 - twT N a * (holT N p.1 p.2 a).re = 0 := by
      intro a
      have hall := (Finset.sum_eq_zero_iff_of_nonneg (fun a _ => fib_term_nonneg N p.1 p.2 a)).mp
        (le_antisymm hp (Finset.sum_nonneg fun a _ => fib_term_nonneg N p.1 p.2 a))
      exact hall a (Finset.mem_univ a)
    have hflat : FlatT N p.1 p.2 := by
      intro a
      have hn : Quaternion.normSq (holT N p.1 p.2 a) = 1 := by
        rw [Quaternion.normSq_eq_norm_mul_self, norm_holT]; norm_num
      have h := ThickFloor.eq_of_re_eq_one (holT N p.1 p.2 a) hn (twT N a)
        (by unfold twT; split_ifs <;> simp) (by linarith [hz a])
      unfold holT at h
      rw [h]; unfold twT; split_ifs <;> simp
    obtain ⟨R, hR⟩ := rigidT_all N p.1 p.2 hflat
    have hbdd : BddBelow (F p '' K) :=
      hK.bddBelow_image ((hF.comp (Continuous.prodMk_right p)).continuousOn)
    have hzero : F p (fun a => (R a)⁻¹) = 0 := by
      simp only [F, fibDist]
      refine Finset.sum_eq_zero fun a _ => ?_
      have e1 : (R a)⁻¹ * AV N a * ((R (a + ev12 N 0))⁻¹)⁻¹ = p.1 a := by
        rw [AV, ← (hR a).1]; group
      have e2 : (R a)⁻¹ * BV N a * ((R (a + ev12 N 1))⁻¹)⁻¹ = p.2 a := by
        rw [BV, ← (hR a).2]; group
      rw [e1, e2]; simp
    exact (csInf_le hbdd ⟨_, trivial, rfl⟩).trans hzero.le
  obtain ⟨δ, hδ, hsm⟩ := ThickFloor.small_action_cost (fibAct N) Φ (continuous_fibAct N) hΦ 0 h0 ε hε
  refine ⟨δ, hδ, fun p hp => ?_⟩
  have hlt := hsm p hp
  rw [zero_add] at hlt
  obtain ⟨_, ⟨g, _, rfl⟩, hv⟩ := exists_lt_of_csInf_lt (hKne.image (F p)) hlt
  exact ⟨g, hv⟩

/-- 真空を変えないことからの欠け -/
noncomputable def stabDefect (R : ZMod N × ZMod N → SU2) : ℝ :=
  ∑ a, (‖((R a * AV N a * (R (a + ev12 N 0))⁻¹ : SU2) : ℍr) - (AV N a : ℍr)‖
    + ‖((R a * BV N a * (R (a + ev12 N 1))⁻¹ : SU2) : ℍr) - (BV N a : ℍr)‖)

/-- 定数 1 か定数 −1 からの距離 -/
noncomputable def distPM (R : ZMod N × ZMod N → SU2) : ℝ :=
  min (∑ a, ‖(R a : ℍr) - 1‖) (∑ a, ‖(R a : ℍr) + 1‖)

/-- **真空の固定群の近似** -/
theorem stab_vacT_approx : ∀ ε > 0, ∃ δ > 0, ∀ R : ZMod N × ZMod N → SU2,
    stabDefect N R < δ → distPM N R < ε := by
  intro ε hε
  have hR : ∀ a, Continuous fun R : ZMod N × ZMod N → SU2 => R a := fun a => continuous_apply a
  have hS : Continuous (stabDefect N) := by
    unfold stabDefect
    refine continuous_finsetSum _ fun a _ => ?_
    refine ((continuous_subtype_val.comp (((hR a).mul continuous_const).mul (hR _).inv)).sub
      continuous_const).norm.add
      ((continuous_subtype_val.comp (((hR a).mul continuous_const).mul (hR _).inv)).sub
      continuous_const).norm
  have hD : Continuous (distPM N) := by
    unfold distPM
    refine Continuous.min (continuous_finsetSum _ fun a _ => ?_) (continuous_finsetSum _ fun a _ => ?_)
    · exact ((continuous_subtype_val.comp (hR a)).sub continuous_const).norm
    · exact ((continuous_subtype_val.comp (hR a)).add continuous_const).norm
  have h0 : ∀ R, stabDefect N R ≤ 0 → distPM N R ≤ 0 := by
    intro R hR0
    have hnn : ∀ a ∈ (Finset.univ : Finset (ZMod N × ZMod N)),
        0 ≤ ‖((R a * AV N a * (R (a + ev12 N 0))⁻¹ : SU2) : ℍr) - (AV N a : ℍr)‖
          + ‖((R a * BV N a * (R (a + ev12 N 1))⁻¹ : SU2) : ℍr) - (BV N a : ℍr)‖ :=
      fun a _ => add_nonneg (norm_nonneg _) (norm_nonneg _)
    have hall := (Finset.sum_eq_zero_iff_of_nonneg hnn).mp
      (le_antisymm hR0 (Finset.sum_nonneg hnn))
    have hA : ∀ a, R a * AV N a * (R (a + ev12 N 0))⁻¹ = AV N a := by
      intro a
      have h := hall a (Finset.mem_univ a)
      have h1 := le_antisymm ((le_add_of_nonneg_right (norm_nonneg _)).trans h.le) (norm_nonneg _)
      exact Subtype.ext (sub_eq_zero.mp (norm_eq_zero.mp h1))
    have hB : ∀ a, R a * BV N a * (R (a + ev12 N 1))⁻¹ = BV N a := by
      intro a
      have h := hall a (Finset.mem_univ a)
      have h1 := le_antisymm ((le_add_of_nonneg_left (norm_nonneg _)).trans h.le) (norm_nonneg _)
      exact Subtype.ext (sub_eq_zero.mp (norm_eq_zero.mp h1))
    obtain ⟨hc, h1 | h1⟩ := stab_vacT N R hA hB
    · refine (min_le_left _ _).trans (le_of_eq (Finset.sum_eq_zero fun a _ => ?_))
      rw [hc a, h1]; simp
    · refine (min_le_right _ _).trans (le_of_eq (Finset.sum_eq_zero fun a _ => ?_))
      rw [hc a, h1]; simp
  obtain ⟨δ, hδ, hsm⟩ := ThickFloor.small_action_cost (stabDefect N) (distPM N) hS hD 0 h0 ε hε
  exact ⟨δ, hδ, fun R hR' => by have := hsm R hR'; linarith⟩

end TwistBlocks

#print axioms TwistBlocks.fibre_near_vac
#print axioms TwistBlocks.stab_vacT_approx
