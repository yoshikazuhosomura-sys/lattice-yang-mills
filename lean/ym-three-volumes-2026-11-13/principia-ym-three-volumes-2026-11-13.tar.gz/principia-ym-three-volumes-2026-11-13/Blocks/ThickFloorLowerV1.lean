import Blocks.ThickFloorKappaEqV1

/-!
# この方法の率は S_N より良くならない（点検の 4）

`M = 2m`、塊 (0,0)、枠を捩れた真空 V に止めると、`S^V_min(+) = 0`、`S^V_min(−) = S_渦(N, m)`。
よって `κ_c(N, 2m, m, 2) ≥ S_渦(N, m) ≥ S_N`（`kappaC_ge_Svortex`）。
(H4) は `S < S_N` では偽（`H4_fails_below`）：段 4 の出力 (H4) の最良の S は S_N。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

theorem kappaC_ge_Svortex (N m : ℕ) [NeZero N] [NeZero m] (k : ℕ) [NeZero k] (hk : k = 2) :
    haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
    Svortex N m ≤ kappaC N (2 * m) m k true := by
  haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
  subst hk
  have hM : m * 2 ≤ 2 * m := by omega
  set F : Frame N (2 * m) m 2 → SU2 := fun x => vac N (2 * m) x.1
  set yV : Inner N (2 * m) m 2 (0, 0) → SU2 := fun j => vac N (2 * m) j.1.1
  have hact : actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) false)
      (glueB N (2 * m) m 2 (0, 0) F yV) = 0 := by
    have he : etaSign (2 * m) m 2 (0, 0) false = fun _ => 1 := by unfold etaSign; simp
    rw [he]
    rw [actB_local N (2 * m) m 2 true (0, 0) (fun _ => 1) (glueB N (2 * m) m 2 (0, 0) F yV)
      (vac N (2 * m)) (fun ℓ hℓ => ?_) (fun ℓ hℓ hb => ?_)]
    · exact actB_vac_one N (2 * m) m 2 (0, 0)
    · unfold glueB BlockFubini.glue; rw [dif_pos hℓ]
    · unfold glueB BlockFubini.glue; rw [dif_neg hℓ, dif_pos hb]
  have h0 : Smin N (2 * m) m 2 true (0, 0) F false = 0 := by
    apply le_antisymm
    · exact (ciInf_le (bdd_Smin N (2 * m) m 2 (0, 0) F false) yV).trans (le_of_eq hact)
    · exact le_ciInf fun y => actB_nonneg N (2 * m) m 2 true (0, 0) _
        (abs_etaSign_le (2 * m) m 2 (0, 0) false) _
  have hp := SminC_eq_Smin N (2 * m) m 2 hM (0, 0) F false
  have hm := SminC_eq_Smin N (2 * m) m 2 hM (0, 0) F true
  simp only [Bool.false_eq_true, if_false, if_true] at hp hm
  have hle := le_ciSup (bdd_kappaC N (2 * m) m 2 hM true) ((0, 0), F)
  have hv : Svortex N m = Smin N (2 * m) m 2 true (0, 0) F true := rfl
  have hv0 := Svortex_nonneg N m
  simp only at hle
  rw [hp, hm, h0, zero_sub, abs_neg] at hle
  unfold kappaC
  rw [hv] at hv0 ⊢
  rw [abs_of_nonneg hv0] at hle
  exact hle

/-- **(H4) は S < S_N で偽**（この方法の率の最良は S_N） -/
theorem H4_fails_below (N : ℕ) [NeZero N] (S : ℝ) (hS : S < SN N) :
    ¬ (∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ S + ε) := by
  intro H
  obtain ⟨m, hm, h⟩ := H ((SN N - S) / 2) (by linarith)
  haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
  have hk : 2 * m / m = 2 := Nat.mul_div_cancel 2 (NeZero.pos m)
  haveI : NeZero (2 * m / m) := ⟨by rw [hk]; norm_num⟩
  have h1 := h (2 * m) (by have := NeZero.pos m; omega)
  have h2 := kappaC_ge_Svortex N m (2 * m / m) hk
  have h3 : SN N ≤ Svortex N m := by
    have hbdd : BddBelow (Set.range fun j : ℕ+ => Svortex N (j : ℕ)) :=
      ⟨0, by rintro _ ⟨j, rfl⟩; exact Svortex_nonneg N j⟩
    exact ciInf_le hbdd (⟨m, NeZero.pos m⟩ : ℕ+)
  linarith

end TwistBlocks

#print axioms TwistBlocks.kappaC_ge_Svortex
#print axioms TwistBlocks.H4_fails_below
