import Blocks.LatticeV2
import Blocks.FubiniV1
import Factor.BlockFactorV5

/-!
# 段 2：(3,4) 平面を一辺 m の塊に分け、枠を止めて塊ごとの積に割る（具体の SU(2) の Wilson 測度）

紙：（枠・塊）、補題 2.1a（升の型ごとの点検：`Blocks.LatticeV1` の `blk_l1`〜`blk_l4`）、
補題 2.1b（芯：`Blocks.FubiniV1` の `abs_integral_prod_blocks_le`、Haar の直積の積分の Fubini）、
補題 2.2（`Factor.BlockFactorV5` の `ratio_tanh`）、命題 2.4（`block_bound_abs`）。
全ての `M ≥ m·k`（紙 §2.1 の直し (i) の代わりに、最後の塊を幅 `M − (k−1)m ∈ [m, 2m)` にする）。
η の和は升ごとに取る（`eta_sum`）：`Σ_η (Πη) e^{Σ η c} = Π_P (e^{c_P} − e^{−c_P})`。
このため補題 2.3（Z_B^F が η_B だけで決まること）は使わず、`Z_B^F(±)` は η|_B の類 `Πη_B = ±1` の和
（`C_b ± S_b` の積分）として定義する（`ZB`）。

既知の型（Mack–Petkova, Ann. Phys. 125 (1980) の線の、枠を止めた塊の条件つき独立と sup の積）の形式化で、
周りは知っている形かもしれない。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-! ## 升の結合と、塊ごとの重み（η を升ごとに和にした形） -/

/-- 升の結合 `a_B(ω) = β z_B Re U_B`（背景 `n₁₂`、`n₃₄ = 0`） -/
noncomputable def aB (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (B : Plaq N M) : ℝ :=
  β * zt N M n12 false B * (hol N M ω B).re

/-- 二次元の升 `P` の上の `N²` 枚の (3,4) の升の結合の和 `c_P` -/
noncomputable def cP (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (P : Pt M) : ℝ :=
  ∑ x : ZMod N × ZMod N, aB N M β n12 ω ((x, P), p23)

/-- 塊 `b` に属する (3,4) でない升の結合の和 -/
noncomputable def rB (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω : Link N M → SU2) : ℝ :=
  ∑ B ∈ (univ.filter (fun B : Plaq N M => B.2 ≠ p23)).filter (fun B => blk2 M m k B.1.2 = b),
    aB N M β n12 ω B

/-- 塊 `b` の重み（η|_B で和：`Σ_η e^{Σ η c}`＝`Π (e^c + e^{-c})`） -/
noncomputable def Cb (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω : Link N M → SU2) : ℝ :=
  Real.exp (rB N M m k β n12 b ω) *
    ∏ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
      (Real.exp (cP N M β n12 ω P) + Real.exp (-cP N M β n12 ω P))

/-- 塊 `b` の符号つきの重み（`Σ_η (Π_{P∈B} η_P) e^{Σ η c}`＝`Π (e^c − e^{-c})`） -/
noncomputable def Sb (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω : Link N M → SU2) : ℝ :=
  Real.exp (rB N M m k β n12 b ω) *
    ∏ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
      (Real.exp (cP N M β n12 ω P) - Real.exp (-cP N M β n12 ω P))

/-! ## η の和を升ごとに -/

theorem sum_units (f : ℤˣ → ℝ) : ∑ u : ℤˣ, f u = f 1 + f (-1) := by
  have huniv : (Finset.univ : Finset ℤˣ) = {1, -1} := by
    ext u; simp only [Finset.mem_univ, Finset.mem_insert, Finset.mem_singleton, true_iff]
    exact Int.units_eq_one_or u
  rw [huniv, Finset.sum_pair (by decide)]

theorem sum_p23 (g : Plaq N M → ℝ) :
    ∑ B ∈ univ.filter (fun B : Plaq N M => B.2 = p23), g B
      = ∑ P : Pt M, ∑ x : ZMod N × ZMod N, g ((x, P), p23) := by
  rw [Finset.sum_filter, Fintype.sum_prod_type]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true]
  rw [Fintype.sum_prod_type, Finset.sum_comm]

/-- 重みの分け：`exp(β Σ_B z η Re U) = exp(Σ_{(3,4) でない} a_B) · Π_P exp(η_P c_P)` -/
theorem weight_split (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (η : Pt M → ℤˣ) :
    Real.exp (β * ∑ B, zt N M n12 false B * etaB N M (fun y => sgn (η y)) B * (hol N M ω B).re)
      = Real.exp (∑ B ∈ univ.filter (fun B : Plaq N M => B.2 ≠ p23), aB N M β n12 ω B)
        * ∏ P : Pt M, Real.exp (sgn (η P) * cP N M β n12 ω P) := by
  rw [← Real.exp_sum, ← Real.exp_add]
  congr 1
  rw [Finset.mul_sum, ← Finset.sum_filter_not_add_sum_filter _ (fun B : Plaq N M => B.2 = p23)]
  congr 1
  · refine Finset.sum_congr rfl fun B hB => ?_
    have h : ¬ B.2 = p23 := (Finset.mem_filter.mp hB).2
    unfold aB etaB; rw [if_neg h]; ring
  · rw [sum_p23]
    refine Finset.sum_congr rfl fun P _ => ?_
    unfold cP aB etaB
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun x _ => ?_
    simp only [if_true]
    ring

/-- η の和：重み `w(η_P)` の積をつけて η について和を取ると、塊ごとの積に割れる -/
theorem eta_sum (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (w : ℤˣ → ℝ) :
    ∑ η : Pt M → ℤˣ, (∏ P, w (η P)) *
        Real.exp (β * ∑ B, zt N M n12 false B * etaB N M (fun y => sgn (η y)) B * (hol N M ω B).re)
      = ∏ b : Fin k × Fin k, (Real.exp (rB N M m k β n12 b ω) *
          ∏ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
            (w 1 * Real.exp (cP N M β n12 ω P) + w (-1) * Real.exp (-cP N M β n12 ω P))) := by
  simp_rw [weight_split]
  have h1 : ∀ η : Pt M → ℤˣ, (∏ P, w (η P)) *
      (Real.exp (∑ B ∈ univ.filter (fun B : Plaq N M => B.2 ≠ p23), aB N M β n12 ω B)
        * ∏ P : Pt M, Real.exp (sgn (η P) * cP N M β n12 ω P))
      = Real.exp (∑ B ∈ univ.filter (fun B : Plaq N M => B.2 ≠ p23), aB N M β n12 ω B)
        * ∏ P : Pt M, (w (η P) * Real.exp (sgn (η P) * cP N M β n12 ω P)) := by
    intro η; rw [Finset.prod_mul_distrib]; ring
  simp_rw [h1]
  rw [← Finset.mul_sum, ← Fintype.prod_sum (fun P (u : ℤˣ) => w u * Real.exp (sgn u * cP N M β n12 ω P))]
  simp_rw [sum_units]
  have hs1 : sgn (1 : ℤˣ) = 1 := by simp [sgn]
  have hs2 : sgn (-1 : ℤˣ) = -1 := by simp [sgn]
  simp only [hs1, hs2, one_mul, neg_one_mul]
  rw [Finset.prod_mul_distrib, ← Real.exp_sum]
  unfold rB
  rw [Finset.sum_fiberwise, Finset.prod_fiberwise]

/-! ## 連続・可積分 -/

theorem integrable_of_continuous (g : (Link N M → SU2) → ℝ) (hg : Continuous g) :
    Integrable g (haarCfg N M) := by
  obtain ⟨C, hC⟩ := (isCompact_univ (X := Link N M → SU2)).exists_bound_of_continuousOn
    hg.continuousOn
  exact Integrable.of_bound hg.aestronglyMeasurable C
    (Filter.Eventually.of_forall fun ω => hC ω (Set.mem_univ _))

theorem continuous_aB (β : ℝ) (n12 : Bool) (B : Plaq N M) :
    Continuous fun ω => aB N M β n12 ω B :=
  continuous_const.mul (continuous_hol_re N M B)

theorem continuous_cP (β : ℝ) (n12 : Bool) (P : Pt M) :
    Continuous fun ω => cP N M β n12 ω P :=
  continuous_finsetSum _ fun _ _ => continuous_aB N M β n12 _

theorem continuous_rB (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) :
    Continuous fun ω => rB N M m k β n12 b ω :=
  continuous_finsetSum _ fun B _ => continuous_aB N M β n12 B

theorem continuous_Cb (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) :
    Continuous fun ω => Cb N M m k β n12 b ω :=
  (Real.continuous_exp.comp (continuous_rB N M m k β n12 b)).mul
    (continuous_finsetProd _ fun P _ =>
      (Real.continuous_exp.comp (continuous_cP N M β n12 P)).add
        (Real.continuous_exp.comp (continuous_cP N M β n12 P).neg))

theorem continuous_Sb (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) :
    Continuous fun ω => Sb N M m k β n12 b ω :=
  (Real.continuous_exp.comp (continuous_rB N M m k β n12 b)).mul
    (continuous_finsetProd _ fun P _ =>
      (Real.continuous_exp.comp (continuous_cP N M β n12 P)).sub
        (Real.continuous_exp.comp (continuous_cP N M β n12 P).neg))

theorem continuous_weight (β : ℝ) (n12 : Bool) (e : Pt M → ℝ) :
    Continuous fun ω : Link N M → SU2 =>
      Real.exp (β * ∑ B, zt N M n12 false B * etaB N M e B * (hol N M ω B).re) :=
  Real.continuous_exp.comp (continuous_const.mul
    (continuous_finsetSum _ fun B _ => continuous_const.mul (continuous_hol_re N M B)))

/-! ## 't Hooft の比を塊の重みで -/

/-- `θ = ∫ Π_b S_b / ∫ Π_b C_b`（η の和を升ごとに取った形。`theta_eq_eta_average` から） -/
theorem theta_blocks (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      = (∫ ω, ∏ b, Sb N M m k β n12 b ω ∂(haarCfg N M))
        / (∫ ω, ∏ b, Cb N M m k β n12 b ω ∂(haarCfg N M)) := by
  rw [theta_eq_eta_average]
  have hs1 : sgn (1 : ℤˣ) = 1 := by simp [sgn]
  have hs2 : sgn (-1 : ℤˣ) = -1 := by simp [sgn]
  have hint : ∀ (c : ℝ) (η : Pt M → ℤˣ), Integrable (fun ω => c * Real.exp (β * ∑ B,
      zt N M n12 false B * etaB N M (fun y => sgn (η y)) B * (hol N M ω B).re)) (haarCfg N M) :=
    fun c η => integrable_of_continuous N M _
      (continuous_const.mul (continuous_weight N M β n12 _))
  have hnum : ∑ η : Pt M → ℤˣ, piSgn M η * ZEta N M β n12 (fun y => sgn (η y))
      = ∫ ω, ∏ b, Sb N M m k β n12 b ω ∂(haarCfg N M) := by
    have h1 : ∀ η : Pt M → ℤˣ, piSgn M η * ZEta N M β n12 (fun y => sgn (η y))
        = ∫ ω, (∏ P, sgn (η P)) * Real.exp (β * ∑ B,
          zt N M n12 false B * etaB N M (fun y => sgn (η y)) B * (hol N M ω B).re) ∂(haarCfg N M) := by
      intro η; unfold ZEta piSgn; rw [integral_const_mul]
    simp_rw [h1]
    rw [← integral_finsetSum _ (fun η _ => hint _ η)]
    congr 1; funext ω
    rw [eta_sum N M m k β n12 ω sgn]
    refine Finset.prod_congr rfl fun b _ => ?_
    unfold Sb
    congr 1
    refine Finset.prod_congr rfl fun P _ => ?_
    rw [hs1, hs2]; ring
  have hden : ∑ η : Pt M → ℤˣ, ZEta N M β n12 (fun y => sgn (η y))
      = ∫ ω, ∏ b, Cb N M m k β n12 b ω ∂(haarCfg N M) := by
    have h1 : ∀ η : Pt M → ℤˣ, ZEta N M β n12 (fun y => sgn (η y))
        = ∫ ω, (∏ P, (fun _ : ℤˣ => (1 : ℝ)) (η P)) * Real.exp (β * ∑ B,
          zt N M n12 false B * etaB N M (fun y => sgn (η y)) B * (hol N M ω B).re) ∂(haarCfg N M) := by
      intro η; unfold ZEta; simp
    simp_rw [h1]
    rw [← integral_finsetSum _ (fun η _ => hint _ η)]
    congr 1; funext ω
    rw [eta_sum N M m k β n12 ω (fun _ => 1)]
    refine Finset.prod_congr rfl fun b _ => ?_
    unfold Cb
    congr 1
    refine Finset.prod_congr rfl fun P _ => ?_
    ring
  rw [hnum, hden]

/-! ## 塊の重みの評価 -/

theorem abs_aB (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (B : Plaq N M) :
    |aB N M β n12 ω B| ≤ |β| :=
  abs_Jc N M β n12 false B ω

theorem abs_cP (β : ℝ) (n12 : Bool) (ω : Link N M → SU2) (P : Pt M) :
    |cP N M β n12 ω P| ≤ (N : ℝ) ^ 2 * |β| := by
  unfold cP
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  refine (Finset.sum_le_sum fun x _ => abs_aB N M β n12 ω _).trans ?_
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_sq N]

/-- `|c| ≤ A` なら `|e^c − e^{-c}| ≤ tanh A · (e^c + e^{-c})`（`|tanh c| ≤ tanh A`） -/
theorem abs_sub_exp_le {c A : ℝ} (hc : |c| ≤ A) :
    |Real.exp c - Real.exp (-c)| ≤ Real.tanh A * (Real.exp c + Real.exp (-c)) := by
  have hc1 : c ≤ A := (le_abs_self c).trans hc
  have hc2 : -c ≤ A := (neg_le_abs c).trans hc
  have f1 : Real.exp c * Real.exp (-A) ≤ Real.exp A * Real.exp (-c) := by
    rw [← Real.exp_add, ← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith)
  have f2 : Real.exp (-c) * Real.exp (-A) ≤ Real.exp A * Real.exp c := by
    rw [← Real.exp_add, ← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith)
  have hD : 0 < Real.exp A + Real.exp (-A) := by positivity
  rw [Real.tanh_eq, div_mul_eq_mul_div, le_div_iff₀ hD]
  rcases abs_cases (Real.exp c - Real.exp (-c)) with ⟨h, _⟩ | ⟨h, _⟩ <;> rw [h] <;> nlinarith [f1, f2]

/-- `|S| ≤ tanh A · C` なら `C ± S ≤ e^{2A} (C ∓ S)` -/
theorem ratio_of_tanh {C S A : ℝ} (h : |S| ≤ Real.tanh A * C) :
    C + S ≤ Real.exp (2 * A) * (C - S) ∧ C - S ≤ Real.exp (2 * A) * (C + S) := by
  have ha := Real.exp_pos A
  have hw := Real.exp_pos (-A)
  have haw : Real.exp A * Real.exp (-A) = 1 := by rw [← Real.exp_add]; simp
  have h2A : Real.exp (2 * A) = Real.exp A * Real.exp A := by rw [two_mul, Real.exp_add]
  have ht : Real.tanh A * (Real.exp A + Real.exp (-A)) = Real.exp A - Real.exp (-A) := by
    rw [Real.tanh_eq]; field_simp
  have key : Real.tanh A * (1 + Real.exp A * Real.exp A) = Real.exp A * Real.exp A - 1 := by
    have e : 1 + Real.exp A * Real.exp A = Real.exp A * (Real.exp A + Real.exp (-A)) := by
      rw [mul_add, haw]; ring
    rw [e, mul_left_comm, ht, mul_sub, haw]
  have key2 : Real.tanh A * C * (1 + Real.exp A * Real.exp A)
      = C * (Real.exp A * Real.exp A - 1) := by
    rw [mul_comm (Real.tanh A) C, mul_assoc, key]
  have hpos : 0 ≤ 1 + Real.exp A * Real.exp A := by positivity
  have h1 : S ≤ Real.tanh A * C := (le_abs_self S).trans h
  have h2 : -S ≤ Real.tanh A * C := (neg_le_abs S).trans h
  have m1 := mul_le_mul_of_nonneg_right h1 hpos
  have m2 := mul_le_mul_of_nonneg_right h2 hpos
  rw [h2A]
  constructor <;> nlinarith [m1, m2, key2]

/-- 積の評価：空でない `s` で `|y_i| ≤ τ x_i`、`|y_i| ≤ x_i`、`x_i ≥ 0` なら `|Π y| ≤ τ Π x` -/
theorem abs_prod_le_of_one {ι : Type*} (s : Finset ι) (hs : s.Nonempty) (x y : ι → ℝ) (τ : ℝ)
    (hx : ∀ i ∈ s, 0 ≤ x i) (h1 : ∀ i ∈ s, |y i| ≤ x i) (hτ : ∀ i ∈ s, |y i| ≤ τ * x i) :
    |∏ i ∈ s, y i| ≤ τ * ∏ i ∈ s, x i := by
  classical
  obtain ⟨i0, hi0⟩ := hs
  rw [← Finset.mul_prod_erase s y hi0, ← Finset.mul_prod_erase s x hi0, abs_mul, Finset.abs_prod]
  have hrest : ∏ i ∈ s.erase i0, |y i| ≤ ∏ i ∈ s.erase i0, x i :=
    Finset.prod_le_prod (fun i _ => abs_nonneg _)
      (fun i hi => h1 i (Finset.mem_of_mem_erase hi))
  have hxr : 0 ≤ ∏ i ∈ s.erase i0, x i :=
    Finset.prod_nonneg fun i hi => hx i (Finset.mem_of_mem_erase hi)
  calc |y i0| * ∏ i ∈ s.erase i0, |y i| ≤ (τ * x i0) * ∏ i ∈ s.erase i0, x i :=
        mul_le_mul (hτ i0 hi0) hrest (Finset.prod_nonneg fun i _ => abs_nonneg _)
          ((abs_nonneg _).trans (hτ i0 hi0))
    _ = τ * (x i0 * ∏ i ∈ s.erase i0, x i) := by ring

/-- 塊 `b` は空でない（`m·k ≤ M`） -/
theorem block_nonempty [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) :
    (univ.filter (fun P : Pt M => blk2 M m k P = b)).Nonempty :=
  ⟨_, Finset.mem_filter.mpr ⟨Finset.mem_univ _, blk2_corner M m k hM b⟩⟩

/-- 一様な比の定数 `τ = tanh(N²|β|) ∈ [0, 1)` -/
noncomputable def tau (β : ℝ) : ℝ := Real.tanh ((N : ℝ) ^ 2 * |β|)

theorem tau_lt_one (β : ℝ) : tau N β < 1 := Real.tanh_lt_one _

theorem tanh_nonneg_of_nonneg {x : ℝ} (hx : 0 ≤ x) : 0 ≤ Real.tanh x := by
  rw [Real.tanh_eq]
  exact div_nonneg (sub_nonneg.mpr (Real.exp_le_exp.mpr (by linarith))) (by positivity)

theorem tau_nonneg (β : ℝ) : 0 ≤ tau N β := tanh_nonneg_of_nonneg (by positivity)

theorem Cb_pos (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω : Link N M → SU2) :
    0 < Cb N M m k β n12 b ω := by
  unfold Cb
  exact mul_pos (Real.exp_pos _) (Finset.prod_pos fun P _ => by positivity)

/-- `|S_b| ≤ τ C_b`（全ての配位で、`m·k ≤ M`） -/
theorem abs_Sb_le [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) (b : Fin k × Fin k)
    (ω : Link N M → SU2) : |Sb N M m k β n12 b ω| ≤ tau N β * Cb N M m k β n12 b ω := by
  unfold Sb Cb
  rw [abs_mul, abs_of_pos (Real.exp_pos _)]
  have h := abs_prod_le_of_one _ (block_nonempty M m k hM b)
    (fun P => Real.exp (cP N M β n12 ω P) + Real.exp (-cP N M β n12 ω P))
    (fun P => Real.exp (cP N M β n12 ω P) - Real.exp (-cP N M β n12 ω P)) (tau N β)
    (fun P _ => by positivity)
    (fun P _ => by
      rw [abs_le]; constructor <;> nlinarith [Real.exp_pos (cP N M β n12 ω P),
        Real.exp_pos (-cP N M β n12 ω P)])
    (fun P _ => abs_sub_exp_le (abs_cP N M β n12 ω P))
  calc Real.exp (rB N M m k β n12 b ω) * |∏ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
        (Real.exp (cP N M β n12 ω P) - Real.exp (-cP N M β n12 ω P))|
      ≤ Real.exp (rB N M m k β n12 b ω) * (tau N β * ∏ P ∈ univ.filter
          (fun P : Pt M => blk2 M m k P = b),
          (Real.exp (cP N M β n12 ω P) + Real.exp (-cP N M β n12 ω P))) :=
        mul_le_mul_of_nonneg_left h (Real.exp_pos _).le
    _ = _ := by ring

/-! ## 局所性（補題 2.1a から）：塊 `b` の重みは枠と塊 `b` の内部だけに依る -/

theorem aB_local (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω ω' : Link N M → SU2)
    (h1 : ∀ ℓ, fr N M m k ℓ → ω ℓ = ω' ℓ)
    (h2 : ∀ ℓ (h : ¬ fr N M m k ℓ), blkL N M m k ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ)
    (B : Plaq N M) (hB : blk2 M m k B.1.2 = b) : aB N M β n12 ω B = aB N M β n12 ω' B := by
  have e : ∀ ℓ, blk2 M m k ℓ.1.2 = blk2 M m k B.1.2 → ω ℓ = ω' ℓ := by
    intro ℓ hℓ
    by_cases h : fr N M m k ℓ
    · exact h1 ℓ h
    · exact h2 ℓ h (by show blk2 M m k ℓ.1.2 = b; rw [hℓ, hB])
  have e1 := e (l1 N M B) (blk_l1 N M m k B)
  have e4 := e (l4 N M B) (blk_l4 N M m k B)
  have e2 : ω (l2 N M B) = ω' (l2 N M B) := by
    by_cases h : fr N M m k (l2 N M B)
    · exact h1 _ h
    · exact e _ (blk_l2 N M m k B h)
  have e3 : ω (l3 N M B) = ω' (l3 N M B) := by
    by_cases h : fr N M m k (l3 N M B)
    · exact h1 _ h
    · exact e _ (blk_l3 N M m k B h)
  unfold aB hol
  rw [e1, e2, e3, e4]

theorem Cb_Sb_local (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (ω ω' : Link N M → SU2)
    (h1 : ∀ ℓ, fr N M m k ℓ → ω ℓ = ω' ℓ)
    (h2 : ∀ ℓ (h : ¬ fr N M m k ℓ), blkL N M m k ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ) :
    Cb N M m k β n12 b ω = Cb N M m k β n12 b ω' ∧ Sb N M m k β n12 b ω = Sb N M m k β n12 b ω' := by
  have hr : rB N M m k β n12 b ω = rB N M m k β n12 b ω' := by
    unfold rB
    exact Finset.sum_congr rfl fun B hB =>
      aB_local N M m k β n12 b ω ω' h1 h2 B (Finset.mem_filter.mp hB).2
  have hc : ∀ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
      cP N M β n12 ω P = cP N M β n12 ω' P := by
    intro P hP
    unfold cP
    exact Finset.sum_congr rfl fun x _ =>
      aB_local N M m k β n12 b ω ω' h1 h2 _ (Finset.mem_filter.mp hP).2
  constructor
  · unfold Cb; rw [hr]; congr 1; exact Finset.prod_congr rfl fun P hP => by rw [hc P hP]
  · unfold Sb; rw [hr]; congr 1; exact Finset.prod_congr rfl fun P hP => by rw [hc P hP]

/-! ## 枠を止めた塊の分配関数と K_eff -/

/-- 枠 -/
abbrev Frame := {ℓ : Link N M // fr N M m k ℓ}

/-- 塊 `b` の内部のリンク -/
abbrev Inner (b : Fin k × Fin k) := {x : {ℓ : Link N M // ¬ fr N M m k ℓ} // blkL N M m k x = b}

/-- 枠 `F` と塊 `b` の内部 `y` を貼った配位（他のリンクは 1） -/
noncomputable def glueB (b : Fin k × Fin k) (F : Frame N M m k → SU2) (y : Inner N M m k b → SU2) :
    Link N M → SU2 :=
  BlockFubini.glue (fr N M m k) (blkL N M m k) (1 : SU2) b F y

/-- **枠 `F` を止めた塊 `b` の分配関数** `Z_B^F(±)`：
`Z_B^F(s) = ∫_{内部} (C_b + s S_b)`。`C_b ± S_b = e^{r_b} (Π_P(e^{c_P}+e^{-c_P}) ± Π_P(e^{c_P}−e^{-c_P}))`
は η|_B の類 `Π_{P∈B} η_P = ±1` の和 `Σ_{η_B : Πη = ±1} e^{r_b + Σ_P η_P c_P}` の 2 倍に等しい
（`eta_sum` と同じ升ごとの和）。 -/
noncomputable def ZB (β : ℝ) (n12 : Bool) (s : ℝ) (b : Fin k × Fin k) (F : Frame N M m k → SU2) : ℝ :=
  ∫ y, (Cb N M m k β n12 b (glueB N M m k b F y) + s * Sb N M m k β n12 b (glueB N M m k b F y))
    ∂(Measure.pi fun _ : Inner N M m k b => haarSU2)

/-- **K_eff** `= ½ · sup_{b, F} |log(Z_B^F(+)/Z_B^F(−))|`（塊 `b` と枠 `F` の全体の上限） -/
noncomputable def Keff (β : ℝ) (n12 : Bool) : ℝ :=
  (1 / 2) * ⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2),
    |Real.log (ZB N M m k β n12 1 p.1 p.2 / ZB N M m k β n12 (-1) p.1 p.2)|

theorem integrable_glue (b : Fin k × Fin k) (F : Frame N M m k → SU2)
    (g : (Link N M → SU2) → ℝ) (hg : Continuous g) :
    Integrable (fun y => g (glueB N M m k b F y)) (Measure.pi fun _ : Inner N M m k b => haarSU2) := by
  obtain ⟨C, hC⟩ := (isCompact_univ (X := Link N M → SU2)).exists_bound_of_continuousOn
    hg.continuousOn
  exact Integrable.of_bound
    (hg.measurable.comp (BlockFubini.measurable_glue _ _ _ _ _)).aestronglyMeasurable C
    (Filter.Eventually.of_forall fun y => hC _ (Set.mem_univ _))

theorem integral_pos_of_pos {α : Type*} [MeasurableSpace α] (μ : Measure α) [IsProbabilityMeasure μ]
    (f : α → ℝ) (hf : ∀ y, 0 < f y) (hi : Integrable f μ) : 0 < ∫ y, f y ∂μ := by
  rw [integral_pos_iff_support_of_nonneg (fun y => (hf y).le) hi]
  have : Function.support f = Set.univ := Set.eq_univ_of_forall fun y => (hf y).ne'
  rw [this, measure_univ]; exact one_pos

theorem ZB_eq (β : ℝ) (n12 : Bool) (s : ℝ) (b : Fin k × Fin k) (F : Frame N M m k → SU2) :
    ZB N M m k β n12 s b F
      = (∫ y, Cb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2))
        + s * ∫ y, Sb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2) := by
  unfold ZB
  rw [integral_add (integrable_glue N M m k b F _ (continuous_Cb N M m k β n12 b))
    ((integrable_glue N M m k b F _ (continuous_Sb N M m k β n12 b)).const_mul s),
    integral_const_mul]

theorem ZB_pos [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) (s : ℝ) (hs : |s| ≤ 1) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) : 0 < ZB N M m k β n12 s b F := by
  unfold ZB
  refine integral_pos_of_pos _ _ (fun y => ?_) ((integrable_glue N M m k b F _
    (continuous_Cb N M m k β n12 b)).add ((integrable_glue N M m k b F _
    (continuous_Sb N M m k β n12 b)).const_mul s))
  have hC := Cb_pos N M m k β n12 b (glueB N M m k b F y)
  have hS := abs_Sb_le N M m k hM β n12 b (glueB N M m k b F y)
  have ht := tau_lt_one N β
  have h0 := tau_nonneg N β
  have h1 : |s * Sb N M m k β n12 b (glueB N M m k b F y)| ≤ tau N β * Cb N M m k β n12 b (glueB N M m k b F y) := by
    rw [abs_mul]
    calc |s| * |Sb N M m k β n12 b (glueB N M m k b F y)| ≤ 1 * |Sb N M m k β n12 b (glueB N M m k b F y)| :=
          mul_le_mul_of_nonneg_right hs (abs_nonneg _)
      _ ≤ _ := by rw [one_mul]; exact hS
  have h2 := neg_abs_le (s * Sb N M m k β n12 b (glueB N M m k b F y))
  nlinarith

/-- 比の上界：`Z_B^F(±) ≤ e^{2N²|β|} Z_B^F(∓)` -/
theorem ZB_ratio [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (F : Frame N M m k → SU2) :
    ZB N M m k β n12 1 b F ≤ Real.exp (2 * ((N : ℝ) ^ 2 * |β|)) * ZB N M m k β n12 (-1) b F ∧
    ZB N M m k β n12 (-1) b F ≤ Real.exp (2 * ((N : ℝ) ^ 2 * |β|)) * ZB N M m k β n12 1 b F := by
  have hpt : ∀ y, Cb N M m k β n12 b (glueB N M m k b F y) + 1 * Sb N M m k β n12 b (glueB N M m k b F y)
        ≤ Real.exp (2 * ((N : ℝ) ^ 2 * |β|)) * (Cb N M m k β n12 b (glueB N M m k b F y)
          + (-1) * Sb N M m k β n12 b (glueB N M m k b F y)) ∧
      Cb N M m k β n12 b (glueB N M m k b F y) + (-1) * Sb N M m k β n12 b (glueB N M m k b F y)
        ≤ Real.exp (2 * ((N : ℝ) ^ 2 * |β|)) * (Cb N M m k β n12 b (glueB N M m k b F y)
          + 1 * Sb N M m k β n12 b (glueB N M m k b F y)) := by
    intro y
    have := ratio_of_tanh (abs_Sb_le N M m k hM β n12 b (glueB N M m k b F y))
    constructor <;> linarith [this.1, this.2]
  have iC := integrable_glue N M m k b F _ (continuous_Cb N M m k β n12 b)
  have iS := integrable_glue N M m k b F _ (continuous_Sb N M m k β n12 b)
  constructor
  · unfold ZB; rw [← integral_const_mul]
    exact integral_mono (iC.add (iS.const_mul 1)) ((iC.add (iS.const_mul (-1))).const_mul _)
      fun y => (hpt y).1
  · unfold ZB; rw [← integral_const_mul]
    exact integral_mono (iC.add (iS.const_mul (-1))) ((iC.add (iS.const_mul 1)).const_mul _)
      fun y => (hpt y).2

theorem abs_log_ZB_le [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) :
    |Real.log (ZB N M m k β n12 1 b F / ZB N M m k β n12 (-1) b F)| ≤ 2 * ((N : ℝ) ^ 2 * |β|) := by
  have hp := ZB_pos N M m k hM β n12 1 (by norm_num) b F
  have hm := ZB_pos N M m k hM β n12 (-1) (by norm_num) b F
  obtain ⟨r1, r2⟩ := ZB_ratio N M m k hM β n12 b F
  rw [Real.log_div hp.ne' hm.ne', abs_le]
  have l1 := Real.log_le_log hp r1
  have l2 := Real.log_le_log hm r2
  rw [Real.log_mul (Real.exp_pos _).ne' hm.ne', Real.log_exp] at l1
  rw [Real.log_mul (Real.exp_pos _).ne' hp.ne', Real.log_exp] at l2
  constructor <;> linarith

theorem bdd_Keff [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) :
    BddAbove (Set.range fun p : (Fin k × Fin k) × (Frame N M m k → SU2) =>
      |Real.log (ZB N M m k β n12 1 p.1 p.2 / ZB N M m k β n12 (-1) p.1 p.2)|) :=
  ⟨2 * ((N : ℝ) ^ 2 * |β|), by rintro _ ⟨p, rfl⟩; exact abs_log_ZB_le N M m k hM β n12 p.1 p.2⟩

/-- `K_eff ≤ N²|β|`（全ての m。m = 1 で床の形に戻る） -/
theorem Keff_le [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) : Keff N M m k β n12 ≤ (N : ℝ) ^ 2 * |β| := by
  unfold Keff
  have : (⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2),
      |Real.log (ZB N M m k β n12 1 p.1 p.2 / ZB N M m k β n12 (-1) p.1 p.2)|)
      ≤ 2 * ((N : ℝ) ^ 2 * |β|) :=
    ciSup_le fun p => abs_log_ZB_le N M m k hM β n12 p.1 p.2
  linarith

theorem Keff_nonneg (β : ℝ) (n12 : Bool) : 0 ≤ Keff N M m k β n12 := by
  unfold Keff
  have : 0 ≤ ⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2),
      |Real.log (ZB N M m k β n12 1 p.1 p.2 / ZB N M m k β n12 (-1) p.1 p.2)| :=
    Real.iSup_nonneg fun p => abs_nonneg _
  linarith

/-- 塊ごとの tanh の評価（命題 2.4 の一つの塊）：枠に一様に `|∫ S_b| ≤ tanh K_eff · ∫ C_b` -/
theorem block_tanh_bound [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) :
    |∫ y, Sb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2)|
      ≤ Real.tanh (Keff N M m k β n12)
        * ∫ y, Cb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2) := by
  have hle : |Real.log (ZB N M m k β n12 1 b F / ZB N M m k β n12 (-1) b F)|
      ≤ 2 * Keff N M m k β n12 := by
    have := le_ciSup (bdd_Keff N M m k hM β n12) (b, F)
    simp only at this
    unfold Keff
    linarith
  set K := Keff N M m k β n12
  have hp := ZB_pos N M m k hM β n12 1 (by norm_num) b F
  have hm := ZB_pos N M m k hM β n12 (-1) (by norm_num) b F
  rw [Real.log_div hp.ne' hm.ne', abs_le] at hle
  have h1 : ZB N M m k β n12 1 b F ≤ Real.exp (2 * K) * ZB N M m k β n12 (-1) b F := by
    have : Real.log (ZB N M m k β n12 1 b F) ≤ Real.log (Real.exp (2 * K) * ZB N M m k β n12 (-1) b F) := by
      rw [Real.log_mul (Real.exp_pos _).ne' hm.ne', Real.log_exp]; linarith
    exact (Real.log_le_log_iff hp (by positivity)).mp this
  have h2 : ZB N M m k β n12 (-1) b F ≤ Real.exp (2 * K) * ZB N M m k β n12 1 b F := by
    have : Real.log (ZB N M m k β n12 (-1) b F) ≤ Real.log (Real.exp (2 * K) * ZB N M m k β n12 1 b F) := by
      rw [Real.log_mul (Real.exp_pos _).ne' hp.ne', Real.log_exp]; linarith
    exact (Real.log_le_log_iff hm (by positivity)).mp this
  have hr := BlockFactor.ratio_tanh hp hm h1 h2
  rw [ZB_eq, ZB_eq] at hr
  set IC := ∫ y, Cb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2)
  set IS := ∫ y, Sb N M m k β n12 b (glueB N M m k b F y) ∂(Measure.pi fun _ => haarSU2)
  have e1 : IC + 1 * IS - (IC + -1 * IS) = 2 * IS := by ring
  have e2 : IC + 1 * IS + (IC + -1 * IS) = 2 * IC := by ring
  rw [e1, e2, abs_mul, abs_two] at hr
  linarith

/-! ## 主定理（段 2、命題 2.4） -/

/-- **段 2 の主定理**（紙： 命題 2.4。`m·k ≤ M`：塊は一辺 m の正方形と、最後の行・列だけ幅 `M − (k−1)m`）。
具体の SU(2) の Wilson 測度（`ZW`、Haar の直積）で、背景 `n₁₂`、全ての実数 `β` について
`|θ_M| ≤ (tanh K_eff)^{k²}`、`θ_M = (Z₀ − Z₁)/(Z₀ + Z₁)`、
`K_eff = ½ sup_{b,F} |log(Z_B^F(+)/Z_B^F(−))|`（`Keff`、`ZB`）。仮定は `NeZero` と `m·k ≤ M` だけ。
既知の型（Mack–Petkova の線の、枠を止めた塊の条件つき独立）の形式化で、周りは知っている形かもしれない。 -/
theorem block_bound_abs [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) :
    |(ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)|
      ≤ Real.tanh (Keff N M m k β n12) ^ (k ^ 2) := by
  rw [theta_blocks N M m k β n12]
  have hCpos : 0 < ∫ ω, ∏ b, Cb N M m k β n12 b ω ∂(haarCfg N M) := by
    exact integral_pos_of_pos _ _ (fun ω => Finset.prod_pos fun b _ => Cb_pos N M m k β n12 b ω)
      (integrable_of_continuous N M _ (continuous_finsetProd _ fun b _ => continuous_Cb N M m k β n12 b))
  rw [abs_div, abs_of_pos hCpos, div_le_iff₀ hCpos]
  have hbd : ∀ b : Fin k × Fin k, ∃ C, ∀ ω, |Cb N M m k β n12 b ω| ≤ C := by
    intro b
    obtain ⟨C, hC⟩ := (isCompact_univ (X := Link N M → SU2)).exists_bound_of_continuousOn
      (continuous_Cb N M m k β n12 b).continuousOn
    exact ⟨C, fun ω => hC ω (Set.mem_univ _)⟩
  choose C hC using hbd
  have hCS : ∀ b ω, |Sb N M m k β n12 b ω| ≤ C b := by
    intro b ω
    have h1 := abs_Sb_le N M m k hM β n12 b ω
    have h2 := Cb_pos N M m k β n12 b ω
    have h3 := tau_lt_one N β
    have h4 := tau_nonneg N β
    have h5 := hC b ω
    rw [abs_of_pos h2] at h5
    nlinarith
  have key := BlockFubini.abs_integral_prod_blocks_le haarSU2 (fr N M m k) (blkL N M m k) (1 : SU2)
    (Cb N M m k β n12) (Sb N M m k β n12)
    (fun b => (continuous_Cb N M m k β n12 b).measurable)
    (fun b => (continuous_Sb N M m k β n12 b).measurable) C hC hCS
    (fun b ω ω' h1 h2 => (Cb_Sb_local N M m k β n12 b ω ω' h1 h2).1)
    (fun b ω ω' h1 h2 => (Cb_Sb_local N M m k β n12 b ω ω' h1 h2).2)
    (fun _ => Real.tanh (Keff N M m k β n12))
    (fun b F => block_tanh_bound N M m k hM β n12 b F)
  rw [Finset.prod_const, Finset.card_univ, Fintype.card_prod, Fintype.card_fin, ← sq] at key
  exact key

/-- 片側の形：`θ_M ≤ (tanh K_eff)^{k²}` -/
theorem block_bound [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.tanh (Keff N M m k β n12) ^ (k ^ 2) :=
  (le_abs_self _).trans (block_bound_abs N M m k hM β n12)

end TwistBlocks

/-! ## 系：m = 1 で床の形 -/

namespace TwistBlocks

open TwistedWilson

theorem tanh_le_tanh {x y : ℝ} (h : x ≤ y) : Real.tanh x ≤ Real.tanh y := by
  rw [Real.tanh_eq, Real.tanh_eq, div_le_div_iff₀ (by positivity) (by positivity)]
  have f1 : Real.exp x * Real.exp (-y) ≤ Real.exp y * Real.exp (-x) := by
    rw [← Real.exp_add, ← Real.exp_add]; exact Real.exp_le_exp.mpr (by linarith)
  nlinarith [f1]

/-- **系（m = 1）**：`θ_M ≤ tanh(N²|β|)^{M²}`（ `twisted_vortex_bound` と同じ形を、段 2 の主定理から） -/
theorem block_bound_one (N M : ℕ) [NeZero N] [NeZero M] (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.tanh ((N : ℝ) ^ 2 * |β|) ^ (M ^ 2) := by
  have hM : 1 * M ≤ M := (one_mul M).le
  refine (block_bound N M 1 M hM β n12).trans ?_
  exact pow_le_pow_left₀ (tanh_nonneg_of_nonneg (Keff_nonneg N M 1 M β n12))
    (tanh_le_tanh (Keff_le N M 1 M hM β n12)) _

end TwistBlocks

#print axioms TwistBlocks.block_bound_abs
#print axioms TwistBlocks.block_bound
#print axioms TwistBlocks.block_bound_one
#print axioms TwistBlocks.Keff_le
