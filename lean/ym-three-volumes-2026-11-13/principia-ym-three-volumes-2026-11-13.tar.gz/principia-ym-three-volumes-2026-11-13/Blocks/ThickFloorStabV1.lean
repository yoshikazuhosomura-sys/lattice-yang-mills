import Blocks.ThickFloorTorusV1

/-!
# 真空の固定群は中心 {±1}（紙の命題 4.2 の部品）

`center_ij`：i と j の両方と可換な単位四元数は ±1。
`stab_vacT`：T²_N の真空 (AV, BV) をゲージ変換で変えない R は、定数 ±1。
（命題 4.2「背景の捩れが真空の固定群を離散にする」の Lean の部品。命題 4.2 そのものは未。）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem center_ij (u : ℍr) (hu : Quaternion.normSq u = 1) (h1 : u * ThickFloor.qi = ThickFloor.qi * u)
    (h2 : u * ThickFloor.qj = ThickFloor.qj * u) : u = 1 ∨ u = -1 := by
  have e1 := congrArg (fun q : ℍr => q.imJ) h1
  have e2 := congrArg (fun q : ℍr => q.imK) h1
  have e3 := congrArg (fun q : ℍr => q.imK) h2
  simp [Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul] at e1 e2 e3
  have hI : u.imI = 0 := by linarith
  have hJ : u.imJ = 0 := by linarith
  have hK : u.imK = 0 := by linarith
  rw [Quaternion.normSq_def'] at hu
  rw [hI, hJ, hK] at hu
  have hr : u.re = 1 ∨ u.re = -1 := by
    have : (u.re - 1) * (u.re + 1) = 0 := by nlinarith
    rcases mul_eq_zero.mp this with h | h
    · left; linarith
    · right; linarith
  rcases hr with hr | hr
  · left; apply Quaternion.ext <;> simp [hr, hI, hJ, hK, Quaternion.re_one, Quaternion.imI_one,
      Quaternion.imJ_one, Quaternion.imK_one]
  · right; apply Quaternion.ext <;> simp [hr, hI, hJ, hK, Quaternion.re_one, Quaternion.imI_one,
      Quaternion.imJ_one, Quaternion.imK_one, Quaternion.re_neg, Quaternion.imI_neg,
      Quaternion.imJ_neg, Quaternion.imK_neg]

variable (N : ℕ) [NeZero N]

theorem pt1_ne (k l : ℕ) (h1 : 1 ≤ k) (h2 : k < N) : (pt N k l).1 ≠ 0 := by
  intro h0
  have := congrArg ZMod.val h0
  rw [val_pt1 N k l h2, ZMod.val_zero] at this
  omega

theorem pt2_ne (k l : ℕ) (h1 : 1 ≤ l) (h2 : l < N) : (pt N k l).2 ≠ 0 := by
  intro h0
  have := congrArg ZMod.val h0
  rw [val_pt2 N k l h2, ZMod.val_zero] at this
  omega

theorem comm_of_conj (x q : SU2) (h : x * q * x⁻¹ = q) : (x : ℍr) * q = (q : ℍr) * x := by
  have e : ((x * q * x⁻¹ : SU2) : ℍr) = (q : ℍr) := by rw [h]
  rw [coe_conj] at e
  calc (x : ℍr) * q = (x : ℍr) * q * (star (x : ℍr) * x) := by rw [star_mul_unit, mul_one]
    _ = ((x : ℍr) * q * star (x : ℍr)) * x := by simp only [mul_assoc]
    _ = (q : ℍr) * x := by rw [e]

/-- **T²_N の真空の固定群は定数 ±1** -/
theorem stab_vacT (R : ZMod N × ZMod N → SU2)
    (hA : ∀ a, R a * AV N a * (R (a + ev12 N 0))⁻¹ = AV N a)
    (hB : ∀ a, R a * BV N a * (R (a + ev12 N 1))⁻¹ = BV N a) :
    (∀ a, R a = R 0) ∧ ((R 0 : ℍr) = 1 ∨ (R 0 : ℍr) = -1) := by
  have hN : 0 < N := NeZero.pos N
  -- 行
  have rowstep : ∀ k l, 1 ≤ k → k < N → R (pt N k l) = R (pt N (k + 1) l) := by
    intro k l h1 h2
    have h := hA (pt N k l)
    rw [pt_add0] at h
    unfold AV at h
    rw [if_neg (pt1_ne N k l h1 h2), mul_one, mul_inv_eq_one] at h
    exact h
  have row1 : ∀ l k, 1 ≤ k → k ≤ N → R (pt N k l) = R (pt N 1 l) := by
    intro l k hk
    induction k, hk using Nat.le_induction with
    | base => intro _; rfl
    | succ k hk ih => intro h; rw [← rowstep k l hk (by omega), ih (by omega)]
  have row10 : ∀ l, R (pt N 1 l) = R (pt N 0 l) := by
    intro l; rw [← row1 l N (by omega) le_rfl, pt_N]
  have row : ∀ l k, k < N → R (pt N k l) = R (pt N 0 l) := by
    intro l k hk
    rcases Nat.eq_zero_or_pos k with h0 | hpos
    · rw [h0]
    · rw [row1 l k hpos hk.le, row10]
  -- 列
  have colstep : ∀ k l, 1 ≤ l → l < N → R (pt N k l) = R (pt N k (l + 1)) := by
    intro k l h1 h2
    have h := hB (pt N k l)
    rw [pt_add1] at h
    unfold BV at h
    rw [if_neg (pt2_ne N k l h1 h2), mul_one, mul_inv_eq_one] at h
    exact h
  have col1 : ∀ k l, 1 ≤ l → l ≤ N → R (pt N k l) = R (pt N k 1) := by
    intro k l hl
    induction l, hl using Nat.le_induction with
    | base => intro _; rfl
    | succ l hl ih => intro h; rw [← colstep k l hl (by omega), ih (by omega)]
  have col10 : ∀ k, R (pt N k 1) = R (pt N k 0) := by
    intro k; rw [← col1 k N (by omega) le_rfl, pt_N']
  have col : ∀ k l, l < N → R (pt N k l) = R (pt N k 0) := by
    intro k l hl
    rcases Nat.eq_zero_or_pos l with h0 | hpos
    · rw [h0]
    · rw [col1 k l hpos hl.le, col10]
  have h00 : pt N 0 0 = 0 := by simp [pt]
  have hconst : ∀ a, R a = R 0 := by
    intro a
    rw [← pt_val N a, row _ _ (ZMod.val_lt _), col _ _ (ZMod.val_lt _), h00]
  refine ⟨hconst, ?_⟩
  -- i と j と可換
  have ci : (R 0 : ℍr) * ThickFloor.qi = ThickFloor.qi * R 0 := by
    have h := hA 0
    have hav : AV N 0 = qI := by simp [AV]
    rw [hav, hconst (0 + ev12 N 0)] at h
    have := comm_of_conj _ _ h
    rwa [coe_qI] at this
  have cj : (R 0 : ℍr) * ThickFloor.qj = ThickFloor.qj * R 0 := by
    have h := hB 0
    have hbv : BV N 0 = qJ := by simp [BV]
    rw [hbv, hconst (0 + ev12 N 1)] at h
    have := comm_of_conj _ _ h
    rwa [coe_qJ] at this
  exact center_ij _ (normSq_unit _) ci cj

end TwistBlocks

#print axioms TwistBlocks.center_ij
#print axioms TwistBlocks.stab_vacT
