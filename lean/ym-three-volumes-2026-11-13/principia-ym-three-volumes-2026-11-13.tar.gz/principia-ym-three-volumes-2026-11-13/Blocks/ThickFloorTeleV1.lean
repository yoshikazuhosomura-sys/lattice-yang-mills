import Blocks.ThickFloorLabelV1

/-!
# 命題 4.2 の部品：格子の正方形の上の Z₂ のラベルの積（境だけが残る）と、作用から欠けへ

* `prod_pairs_telescope`：x_j² = 1 なら Π_{j<m} x_j x_{j+1} = x_0 x_m。
* `grid_plaq_prod`：一辺 m の正方形の二次元の格子で、横のリンクのラベル h(i,j)（i < m、j ≤ m）、
  縦のリンクのラベル v(i,j)（i ≤ m、j < m）が ±1 なら、
  Π_{i,j<m} h(i,j) h(i,j+1) v(i,j) v(i+1,j) = Π_i h(i,0) h(i,m) · Π_j v(0,j) v(m,j)。
  境のラベルが全て 1 なら、全ての升の境の積の積は 1（一枚だけの反転とは両立しない）。
* `norm_sub_sq_unit`：単位四元数 X, Y で ‖X − Y‖² = 2(1 − Re(X Y*))（升の作用から `linkDef` の項へ）。
-/

open Finset BigOperators

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem prod_pairs_telescope (x : ℕ → ℝ) (hx : ∀ j, x j * x j = 1) (m : ℕ) :
    ∏ j ∈ Finset.range m, (x j * x (j + 1)) = if m = 0 then 1 else x 0 * x m := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.prod_range_succ, ih]
    by_cases hm : m = 0
    · subst hm; simp
    · rw [if_neg hm, if_neg (Nat.succ_ne_zero m)]
      calc x 0 * x m * (x m * x (m + 1)) = x 0 * (x m * x m) * x (m + 1) := by ring
        _ = x 0 * x (m + 1) := by rw [hx m, mul_one]

theorem grid_plaq_prod (m : ℕ) (hm : 0 < m) (h v : ℕ → ℕ → ℝ) (hh : ∀ i j, h i j * h i j = 1)
    (hv : ∀ i j, v i j * v i j = 1) :
    ∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m, (h i j * h i (j + 1) * (v i j * v (i + 1) j))
      = (∏ i ∈ Finset.range m, (h i 0 * h i m)) * ∏ j ∈ Finset.range m, (v 0 j * v m j) := by
  have hm0 : m ≠ 0 := Nat.pos_iff_ne_zero.mp hm
  have e1 : ∀ i, ∏ j ∈ Finset.range m, (h i j * h i (j + 1)) = h i 0 * h i m := by
    intro i
    have := prod_pairs_telescope (h i) (hh i) m
    rwa [if_neg hm0] at this
  have e2 : ∀ j, ∏ i ∈ Finset.range m, (v i j * v (i + 1) j) = v 0 j * v m j := by
    intro j
    have := prod_pairs_telescope (fun i => v i j) (fun i => hv i j) m
    rwa [if_neg hm0] at this
  rw [Finset.prod_congr rfl (fun i _ => Finset.prod_mul_distrib), Finset.prod_mul_distrib,
    Finset.prod_comm (s := Finset.range m) (t := Finset.range m)
      (f := fun i j => v i j * v (i + 1) j),
    Finset.prod_congr rfl (fun i _ => e1 i), Finset.prod_congr rfl (fun j _ => e2 j)]

/-- 境のラベルが全て 1 なら、全ての升の境の積の積は 1 -/
theorem grid_plaq_prod_one (m : ℕ) (hm : 0 < m) (h v : ℕ → ℕ → ℝ) (hh : ∀ i j, h i j * h i j = 1)
    (hv : ∀ i j, v i j * v i j = 1) (hb1 : ∀ i, h i 0 = 1) (hb2 : ∀ i, h i m = 1)
    (hb3 : ∀ j, v 0 j = 1) (hb4 : ∀ j, v m j = 1) :
    ∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m, (h i j * h i (j + 1) * (v i j * v (i + 1) j)) = 1 := by
  rw [grid_plaq_prod m hm h v hh hv]
  simp [hb1, hb2, hb3, hb4]

theorem norm_sub_sq_unit (X Y : ℍr) (hX : ‖X‖ = 1) (hY : ‖Y‖ = 1) :
    ‖X - Y‖ ^ 2 = 2 * (1 - (X * star Y).re) := by
  have nX : Quaternion.normSq X = 1 := by rw [Quaternion.normSq_eq_norm_mul_self, hX]; norm_num
  have nY : Quaternion.normSq Y = 1 := by rw [Quaternion.normSq_eq_norm_mul_self, hY]; norm_num
  rw [sq, ← Quaternion.normSq_eq_norm_mul_self]
  rw [Quaternion.normSq_def'] at nX nY ⊢
  simp only [Quaternion.re_mul, Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star,
    Quaternion.imK_star, Quaternion.re_sub, Quaternion.imI_sub, Quaternion.imJ_sub, Quaternion.imK_sub]
  nlinarith [nX, nY]

end TwistBlocks

#print axioms TwistBlocks.grid_plaq_prod_one
#print axioms TwistBlocks.norm_sub_sq_unit
