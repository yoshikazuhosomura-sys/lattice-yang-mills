import Blocks.BlockLaplaceV1

/-!
# 塊の重みを η|_B の類の和として：`C_b + s S_b = Σ_σ (1 + s Πσ) e^{β(n_b − S_B(η_σ))}`

段 3 を K_eff に繋ぐための恒等式（紙：命題 2.4 の `Z_B^F(±)` は η|_B の類 `Πη_B = ±1` の和、§3 の
`∫ e^{β Σ z ½tr} = e^{β #升} ∫ e^{−β S_B}`）。σ は塊 `b` の二次元の升の上の符号の場、`ext σ` はその外を 1 にした場。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- 塊 `b` の升の数 -/
def nB (b : Fin k × Fin k) : ℕ := (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card

/-- 塊 `b` の二次元の升 -/
abbrev Fib (b : Fin k × Fin k) := {P : Pt M // blk2 M m k P = b}

/-- 塊の符号の場を全体に（外は 1） -/
noncomputable def ext (b : Fin k × Fin k) (σ : Fib M m k b → ℤˣ) : Pt M → ℝ :=
  fun P => if h : blk2 M m k P = b then sgn (σ ⟨P, h⟩) else 1

/-- 指数の書き換え：`β (n_b − S_B(η)) = r_b + Σ_{P ∈ b} η_P c_P` -/
theorem exponent_eq (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (ω : Link N M → SU2) :
    β * ((nB N M m k b : ℝ) - actB N M m k n12 b e ω)
      = rB N M m k β n12 b ω + ∑ P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b),
          e P * cP N M β n12 ω P := by
  have h1 : β * ((nB N M m k b : ℝ) - actB N M m k n12 b e ω)
      = ∑ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
          etaB N M e B * aB N M β n12 ω B := by
    unfold nB actB aB
    rw [Finset.card_eq_sum_ones, Nat.cast_sum, ← Finset.sum_sub_distrib, Finset.mul_sum]
    refine Finset.sum_congr rfl fun B _ => ?_
    push_cast; ring
  rw [h1, ← Finset.sum_filter_not_add_sum_filter _ (fun B : Plaq N M => B.2 = p23)]
  congr 1
  · have hs : (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter (fun B => ¬ B.2 = p23)
        = (univ.filter (fun B : Plaq N M => B.2 ≠ p23)).filter (fun B => blk2 M m k B.1.2 = b) := by
      ext B; simp only [Finset.mem_filter, Finset.mem_univ, true_and, ne_eq]; tauto
    rw [hs]
    unfold rB
    refine Finset.sum_congr rfl fun B hB => ?_
    have h : ¬ B.2 = p23 := (Finset.mem_filter.mp (Finset.mem_filter.mp hB).1).2
    unfold etaB; rw [if_neg h, one_mul]
  · rw [Finset.filter_filter, Finset.sum_filter]
    have hg := sum_p23 N M (fun B => if blk2 M m k B.1.2 = b then etaB N M e B * aB N M β n12 ω B else 0)
    rw [Finset.sum_filter] at hg
    have hl : ∀ B : Plaq N M, (if blk2 M m k B.1.2 = b ∧ B.2 = p23 then etaB N M e B * aB N M β n12 ω B else 0)
        = if B.2 = p23 then (if blk2 M m k B.1.2 = b then etaB N M e B * aB N M β n12 ω B else 0) else 0 := by
      intro B; by_cases h1 : blk2 M m k B.1.2 = b <;> by_cases h2 : B.2 = p23 <;> simp [h1, h2]
    rw [Finset.sum_congr rfl fun B _ => hl B, hg, Finset.sum_filter]
    refine Finset.sum_congr rfl fun P _ => ?_
    by_cases hP : blk2 M m k P = b
    · simp only [hP, if_true]
      unfold cP etaB
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun x _ => ?_
      simp
    · simp [hP]

/-- **類の和の恒等式**：`C_b + s S_b = Σ_σ (1 + s Π σ) exp(β (n_b − S_B(ext σ)))` -/
theorem class_sum (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (s : ℝ) (ω : Link N M → SU2) :
    Cb N M m k β n12 b ω + s * Sb N M m k β n12 b ω
      = ∑ σ : Fib M m k b → ℤˣ, (1 + s * ∏ P, sgn (σ P))
          * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ) ω)) := by
  have hmem : ∀ P : Pt M, P ∈ univ.filter (fun P : Pt M => blk2 M m k P = b) ↔ blk2 M m k P = b := by
    intro P; simp
  have hexp : ∀ σ : Fib M m k b → ℤˣ,
      Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ) ω))
        = Real.exp (rB N M m k β n12 b ω) * ∏ P : Fib M m k b, Real.exp (sgn (σ P) * cP N M β n12 ω P.1) := by
    intro σ
    rw [exponent_eq, Real.exp_add, Real.exp_sum, Finset.prod_subtype _ hmem]
    congr 1
    refine Finset.prod_congr rfl fun P _ => ?_
    unfold ext; rw [dif_pos P.2]
  simp_rw [hexp]
  have hs1 : sgn (1 : ℤˣ) = 1 := by simp [sgn]
  have hs2 : sgn (-1 : ℤˣ) = -1 := by simp [sgn]
  have hC : ∏ P : Fib M m k b, (Real.exp (cP N M β n12 ω P.1) + Real.exp (-cP N M β n12 ω P.1))
      = ∑ σ : Fib M m k b → ℤˣ, ∏ P : Fib M m k b, Real.exp (sgn (σ P) * cP N M β n12 ω P.1) := by
    rw [← Fintype.prod_sum (fun (P : Fib M m k b) (u : ℤˣ) => Real.exp (sgn u * cP N M β n12 ω P.1))]
    refine Finset.prod_congr rfl fun P _ => ?_
    rw [sum_units, hs1, hs2, one_mul, neg_one_mul]
  have hS : ∏ P : Fib M m k b, (Real.exp (cP N M β n12 ω P.1) - Real.exp (-cP N M β n12 ω P.1))
      = ∑ σ : Fib M m k b → ℤˣ, (∏ P, sgn (σ P))
          * ∏ P : Fib M m k b, Real.exp (sgn (σ P) * cP N M β n12 ω P.1) := by
    simp_rw [← Finset.prod_mul_distrib]
    rw [← Fintype.prod_sum (fun (P : Fib M m k b) (u : ℤˣ) => sgn u * Real.exp (sgn u * cP N M β n12 ω P.1))]
    refine Finset.prod_congr rfl fun P _ => ?_
    rw [sum_units, hs1, hs2]; ring
  unfold Cb Sb
  rw [Finset.prod_subtype _ hmem, Finset.prod_subtype _ hmem, hC, hS]
  rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun σ _ => ?_
  ring

end TwistBlocks

#print axioms TwistBlocks.class_sum
#print axioms TwistBlocks.exponent_eq
