import Blocks.StageTwoV2

/-!
# 段 4 と定理 E の言明を Lean の型で（定義と言明まで）、と段 2 から段 3 への算術の一歩

紙：（捩れた真空 V、塊の作用、S^F_min(±)、κ、S_渦、S_N）、§5（定理 E）。
ここでは**定義と言明の型だけ**を置く（`TheoremEStatement` は命題で、証明はまだ無い）。
閉じた定理は `block_bound_exp`（段 2 の主定理と `BlockFactor.neg_log_tanh_ge` から
`θ_M ≤ exp(−k² e^{−2K_eff})`）だけ。

約束：塊の作用 `actB` は塊 `b` に属する升（升の根もとの二次元の点が塊 `b`）全部の和で、
枠だけの升も含む（紙は含めない）。差は枠だけの関数なので `S^F_min(+) − S^F_min(−)` は変わらない。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

/-- `normSq q = 1` の四元数を SU(2) の元に -/
noncomputable def unitOf (q : ℍr) (h : Quaternion.normSq q = 1) : SU2 :=
  ⟨q, by
    rw [mem_sphere_zero_iff_norm]
    have h2 : ‖q‖ * ‖q‖ = 1 := by rw [← Quaternion.normSq_eq_norm_mul_self, h]
    nlinarith [norm_nonneg q]⟩

/-- `i`（`basis 1`）と `j`（`basis 2`） -/
noncomputable def qI : SU2 := unitOf (TwistedQ8.basis 1) (TwistedQ8.normSq_basis 1)
noncomputable def qJ : SU2 := unitOf (TwistedQ8.basis 2) (TwistedQ8.normSq_basis 2)

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- **捩れた真空 V**：`U₁(x) = i`（`x₁ = 0`）、`U₂(x) = j`（`x₂ = 0`）、他は 1（紙 §1.3） -/
noncomputable def vac : Link N M → SU2 := fun ℓ =>
  if ℓ.2 = 0 ∧ ℓ.1.1.1 = 0 then qI else if ℓ.2 = 1 ∧ ℓ.1.1.2 = 0 then qJ else 1

/-- 塊 `b` の作用 `S_B(ω; η) = Σ_{B ∈ b} (1 − z_B η_B Re U_B)`（背景 `n₁₂`、β を掛ける前） -/
noncomputable def actB (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (ω : Link N M → SU2) : ℝ :=
  ∑ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
    (1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re)

/-- 塊 `b` の角の二次元の升 -/
def corner (b : Fin k × Fin k) : Pt M := (((b.1.val * m : ℕ) : ZMod M), ((b.2.val * m : ℕ) : ZMod M))

/-- (+)：η ≡ 1、(−)：塊 `b` の角の一枚だけ反転 -/
noncomputable def etaSign (b : Fin k × Fin k) (s : Bool) : Pt M → ℝ :=
  if s then etaAt M (corner M m k b) else fun _ => 1

/-- `S^F_min(±) = inf_{内部} S_B(glue F y; η±)` -/
noncomputable def Smin (n12 : Bool) (b : Fin k × Fin k) (F : Frame N M m k → SU2) (s : Bool) : ℝ :=
  ⨅ y : Inner N M m k b → SU2, actB N M m k n12 b (etaSign M m k b s) (glueB N M m k b F y)

/-- `κ = sup_{b,F} |S^F_min(+) − S^F_min(−)|` -/
noncomputable def kappa (n12 : Bool) : ℝ :=
  ⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2), |Smin N M m k n12 p.1 p.2 false - Smin N M m k n12 p.1 p.2 true|

/-- `S_渦(N, m) = S^V_min(−)`：一辺 m の塊（格子は `M = 2m`、塊 `(0,0)`、一周しない）の枠を V に止める -/
noncomputable def Svortex (N m : ℕ) [NeZero N] [NeZero m] : ℝ :=
  haveI : NeZero (2 * m) := ⟨by have := NeZero.ne m; omega⟩
  Smin N (2 * m) m 2 true (0, 0) (fun x => vac N (2 * m) x.1) true

/-- `S_N = inf_{m ≥ 1} S_渦(N, m)` -/
noncomputable def SN (N : ℕ) [NeZero N] : ℝ := ⨅ m : ℕ+, Svortex N (m : ℕ)

/-- 't Hooft の比 `θ_M(β)`（背景 `n₁₂ = 1`） -/
noncomputable def thetaM (β : ℝ) : ℝ :=
  (ZW N M β true false - ZW N M β true true) / (ZW N M β true false + ZW N M β true true)

/-- **定理 E の言明（型だけ、証明はまだ無い）**：全ての ε > 0 で、十分大きい β について、十分大きい M で
`θ_M(β) ≤ exp(−M² e^{−β(S_N + ε)})`。（σ_N(β) ≥ e^{−β(S_N+ε)} を liminf を使わずに書いた形。
θ_M = 0 の場合も含む。紙の定理 E はこれから limsup_{β→∞} (1/β) log(1/σ_N(β)) ≤ S_N。） -/
def TheoremEStatement (N : ℕ) [NeZero N] : Prop :=
  ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    thetaM N (M + 1) β ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (SN N + ε)))

/-! ## 段 2 から段 3 への算術の一歩（閉） -/

/-- `θ_M ≤ exp(−k² e^{−2K_eff})`（段 2 の主定理と `−log tanh K ≥ e^{−2K}`）。`m·k ≤ M`。 -/
theorem block_bound_exp [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.exp (-((k : ℝ) ^ 2) * Real.exp (-2 * Keff N M m k β n12)) := by
  have hb := block_bound N M m k hM β n12
  set K := Keff N M m k β n12
  have hK0 : 0 ≤ K := Keff_nonneg N M m k β n12
  rcases hK0.lt_or_eq with hK | hK
  · have ht : 0 < Real.tanh K := by
      rw [Real.tanh_eq]
      exact div_pos (sub_pos.mpr (Real.exp_lt_exp.mpr (by linarith))) (by positivity)
    have hlog := BlockFactor.neg_log_tanh_ge hK
    have hpow : Real.tanh K ^ (k ^ 2) = Real.exp (((k ^ 2 : ℕ) : ℝ) * Real.log (Real.tanh K)) := by
      rw [Real.exp_nat_mul, Real.exp_log ht]
    refine hb.trans (hpow.le.trans (Real.exp_le_exp.mpr ?_))
    push_cast
    have hk : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
    nlinarith [mul_le_mul_of_nonneg_left hlog hk]
  · rw [← hK, Real.tanh_zero] at hb
    have hk2 : k ^ 2 ≠ 0 := pow_ne_zero 2 (NeZero.ne k)
    rw [zero_pow hk2] at hb
    exact hb.trans (Real.exp_pos _).le

/-- 全ての `M ≥ m`：`k = ⌊M/m⌋` の塊で `θ_M ≤ exp(−⌊M/m⌋² e^{−2K_eff})` -/
theorem block_bound_floor [NeZero m] (hmM : m ≤ M) (β : ℝ) (n12 : Bool) :
    haveI : NeZero (M / m) := ⟨(Nat.div_pos hmM (NeZero.pos m)).ne'⟩
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.exp (-(((M / m : ℕ) : ℝ) ^ 2) * Real.exp (-2 * Keff N M m (M / m) β n12)) := by
  haveI : NeZero (M / m) := ⟨(Nat.div_pos hmM (NeZero.pos m)).ne'⟩
  exact block_bound_exp N M m (M / m) (by rw [mul_comm]; exact Nat.div_mul_le_self M m) β n12

end TwistBlocks

#print axioms TwistBlocks.block_bound_exp
#print axioms TwistBlocks.block_bound_floor
#check @TwistBlocks.TheoremEStatement
#check @TwistBlocks.kappa
#check @TwistBlocks.SN
