import Blocks.StageFourCountV1

/-!
# 段 4 (a)：(±) の両方で `S^F_min(±) ≤ 144 N² m`、よって `κ_c ≤ 144 N² m`（M に一様、m について一次）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- 一般の類の元 σ で、枠に触れない升の η が 1 なら `S^F_min(s) ≤ 2·#touch` -/
theorem SminC_le_touch (b : Fin k × Fin k) (F : Frame N M m k → SU2) (s : ℝ)
    (σ : Fib M m k b → ℤˣ) (hσ : s * ∏ P, sgn (σ P) = 1)
    (hη : ∀ B : Plaq N M, blk2 M m k B.1.2 = b → B ∉ touchB N M m k b → etaB N M (ext M m k b σ) B = 1) :
    SminC N M m k true b F s ≤ 2 * ((touchB N M m k b).card : ℝ) := by
  let yV : Inner N M m k b → SU2 := fun j => vac N M j.1.1
  refine (SminC_le N M m k true b F s yV σ hσ).trans ?_
  unfold actB
  have hterm : ∀ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
      1 - zt N M true false B * etaB N M (ext M m k b σ) B * (hol N M (glueB N M m k b F yV) B).re
        ≤ if B ∈ touchB N M m k b then 2 else 0 := by
    intro B hB
    have hb : blk2 M m k B.1.2 = b := (Finset.mem_filter.mp hB).2
    by_cases ht : B ∈ touchB N M m k b
    · rw [if_pos ht]
      exact (actB_term_bounds N M true _ (abs_ext_le M m k b σ) _ B).2
    · rw [if_neg ht]
      have hnf : ¬ (fr N M m k (l1 N M B) ∨ fr N M m k (l2 N M B) ∨ fr N M m k (l3 N M B)
          ∨ fr N M m k (l4 N M B)) := by
        intro h; exact ht (Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb, h⟩)
      simp only [not_or] at hnf
      obtain ⟨n1, n2, n3, n4⟩ := hnf
      have hg : ∀ ℓ (h : ¬ fr N M m k ℓ), blk2 M m k ℓ.1.2 = b →
          glueB N M m k b F yV ℓ = vac N M ℓ := by
        intro ℓ h hℓ
        unfold glueB BlockFubini.glue
        rw [dif_neg h, dif_pos (show blkL N M m k ⟨ℓ, h⟩ = b from hℓ)]
      have hhol : hol N M (glueB N M m k b F yV) B = hol N M (vac N M) B := by
        unfold hol
        rw [hg _ n1 ((blk_l1 N M m k B).trans hb), hg _ n2 ((blk_l2 N M m k B n2).trans hb),
          hg _ n3 ((blk_l3 N M m k B n3).trans hb), hg _ n4 ((blk_l4 N M m k B).trans hb)]
      rw [hhol, hη B hb ht, mul_one, vac_term N M B, sub_self]
  refine (Finset.sum_le_sum hterm).trans ?_
  rw [← Finset.sum_filter]
  have hsub : (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
      (fun B => B ∈ touchB N M m k b) = touchB N M m k b := by
    ext B; simp only [Finset.mem_filter, Finset.mem_univ, true_and, touchB]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h; exact ⟨h.1, h⟩
  rw [hsub, Finset.sum_const, nsmul_eq_mul]
  ring_nf; exact le_refl _

/-- (−)：角の升を反転した類の元で、角の (3,4) の升は枠に触れる -/
theorem SminC_minus_le_touch [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (F : Frame N M m k → SU2) :
    SminC N M m k true b F (-1) ≤ 2 * ((touchB N M m k b).card : ℝ) := by
  let P0 : Fib M m k b := ⟨corner M m k b, blk2_corner M m k hM b⟩
  let σ0 : Fib M m k b → ℤˣ := Pi.mulSingle P0 (-1)
  have h : ∀ P : Fib M m k b, sgn (σ0 P) = if P = P0 then -1 else 1 := by
    intro P; simp only [σ0]; rw [Pi.mulSingle_apply]; split_ifs <;> simp [sgn]
  have hσ : (-1 : ℝ) * ∏ P, sgn (σ0 P) = 1 := by
    simp only [h, Finset.prod_ite_eq', Finset.mem_univ, if_true]; norm_num
  refine SminC_le_touch N M m k b F (-1) σ0 hσ fun B hb ht => ?_
  unfold etaB
  split_ifs with h23
  · unfold ext
    rw [dif_pos hb]
    by_cases hP : (⟨B.1.2, hb⟩ : Fib M m k b) = P0
    · exfalso; apply ht
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb, Or.inl ?_⟩
      have hx : B.1.2 = corner M m k b := congrArg Subtype.val hP
      have hlt : b.2.val * m < M := by
        calc b.2.val * m < k * m := Nat.mul_lt_mul_of_pos_right b.2.isLt (NeZero.pos m)
          _ = m * k := mul_comm k m
          _ ≤ M := hM
      unfold l1 fr
      rw [h23]
      simp only [p23]
      simp only [if_true, ite_true]
      rw [hx]
      unfold corner onLine
      simp only
      rw [ZMod.val_natCast, Nat.mod_eq_of_lt hlt]
      refine ⟨Nat.mul_mod_left _ _, ?_⟩
      calc b.2.val * m < k * m := Nat.mul_lt_mul_of_pos_right b.2.isLt (NeZero.pos m)
        _ = m * k := mul_comm k m
    · rw [h, if_neg hP]
  · rfl

/-- **段 4 (a)**：`κ_c ≤ 288 N² m`（M に一様、m について一次。紙の命題 4.1 (a) の `c N² m`） -/
theorem kappaC_le_linear [NeZero m] (hM : m * k ≤ M) (hk : M < (k + 1) * m) :
    kappaC N M m k true ≤ 288 * (N : ℝ) ^ 2 * (m : ℝ) := by
  refine ciSup_le fun p => ?_
  have ht := card_touch_le N M m k hk p.1
  have htr : ((touchB N M m k p.1).card : ℝ) ≤ ((N * N * (12 * m) * 6 : ℕ) : ℝ) := by exact_mod_cast ht
  push_cast at htr
  have hp := SminC_le_touch N M m k p.1 p.2 1 (fun _ => 1) (by simp [sgn]) (fun B _ _ => by
    unfold etaB ext; split_ifs <;> simp [sgn])
  have hm := SminC_minus_le_touch N M m k hM p.1 p.2
  obtain ⟨a1, _⟩ := SminC_bounds N M m k hM true p.1 p.2 1 (Or.inl rfl)
  obtain ⟨b1, _⟩ := SminC_bounds N M m k hM true p.1 p.2 (-1) (Or.inr rfl)
  rw [abs_le]; constructor <;> nlinarith

end TwistBlocks

#print axioms TwistBlocks.kappaC_le_linear
