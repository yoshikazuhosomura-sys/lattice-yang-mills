import Blocks.ThickFloorTeleV1

/-!
# 命題 4.2 の芯（格子の正方形の上の抽象の形）：一様な δ(N) > 0 の床

二次元の点 (i, j)（0 ≤ i, j ≤ m）ごとの T²_N の繊維 F(i,j) = (A, B)、横のリンク H(i,j)（(i,j) → (i+1,j)）と
縦のリンク V(i,j)（(i,j) → (i,j+1)）の横の N² 本の値、二次元の升 (i,j)（i,j < m）の符号 η(i,j) ∈ {±1} について、
境（i = 0、j = 0、i ≥ m、j ≥ m）の繊維は真空 (AV, BV)、境の線の上のリンクは 1、Π η = −1（反転が奇数枚）とする。
このとき、N だけに依る δ > 0（m に依らない）があって、次のどれかの部品が δ 以上：
繊維の捩れた作用 `fibAct`、リンクの欠け `linkDef`、升の作用 `plaqAct`（**`grid_vortex_floor`**）。
証明：全ての部品が小さいとすると、繊維ごとにゲージ g（境では 1）、リンクごとに Z₂ のラベル c（境では 1）が決まり、
各升で η = Π_{∂P} c（`plaq_label`）、積を取ると Π η = 1（`grid_plaq_prod_one`）で矛盾。
-/

open Finset BigOperators

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

open TwistedWilson

variable (N : ℕ) [NeZero N]

/-- 真空の繊維 -/
noncomputable def vacF : (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2) :=
  (fun a => AV N a, fun a => BV N a)

/-- 二次元の升（(3,4) の升を横の N² 枚）の作用 -/
noncomputable def plaqAct (H1 V2 H3 V4 : ZMod N × ZMod N → SU2) (e : ℝ) : ℝ :=
  ∑ a, (1 - e * ((H1 a : ℍr) * (V2 a : ℍr) * star (H3 a : ℍr) * star (V4 a : ℍr)).re)

/-- 境 -/
def bdG (m i j : ℕ) : Prop := i = 0 ∨ j = 0 ∨ m ≤ i ∨ m ≤ j

theorem fibDist_vac : fibDist N (vacF N) (fun _ => 1) = 0 := by
  unfold fibDist vacF
  simp

theorem norm_prod4 (a b c d : SU2) : ‖(a : ℍr) * (b : ℍr) * star (c : ℍr) * star (d : ℍr)‖ = 1 := by
  simp only [norm_mul, norm_star, norm_unit]; norm_num

theorem plaq_term_nonneg (a b c d : SU2) (e : ℝ) (he : e = 1 ∨ e = -1) :
    0 ≤ 1 - e * ((a : ℍr) * (b : ℍr) * star (c : ℍr) * star (d : ℍr)).re := by
  have h := abs_re_le_one _ (norm_prod4 a b c d)
  rcases he with rfl | rfl
  · have := (abs_le.mp h).2; linarith
  · have := (abs_le.mp h).1; linarith

/-- **命題 4.2 の芯**（抽象の格子の形、δ は N だけに依る） -/
theorem grid_vortex_floor : ∃ δ > 0, ∀ m : ℕ, 0 < m →
    ∀ (F : ℕ → ℕ → (ZMod N × ZMod N → SU2) × (ZMod N × ZMod N → SU2))
      (H V : ℕ → ℕ → ZMod N × ZMod N → SU2) (η : ℕ → ℕ → ℝ),
    (∀ i j, bdG m i j → F i j = vacF N) →
    (∀ i a, H i 0 a = 1) → (∀ i a, H i m a = 1) → (∀ j a, V 0 j a = 1) → (∀ j a, V m j a = 1) →
    (∀ i j, η i j = 1 ∨ η i j = -1) →
    (∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m, η i j) = -1 →
    (∃ i j, i ≤ m ∧ j ≤ m ∧ δ ≤ fibAct N (F i j)) ∨
    (∃ i j, i < m ∧ j ≤ m ∧ δ ≤ linkDef N (F i j) (F (i + 1) j) (H i j)) ∨
    (∃ i j, i ≤ m ∧ j < m ∧ δ ≤ linkDef N (F i j) (F i (j + 1)) (V i j)) ∨
    (∃ i j, i < m ∧ j < m ∧ δ ≤ plaqAct N (H i j) (V (i + 1) j) (H i (j + 1)) (V i j) (η i j)) := by
  obtain ⟨δL, hδL, hL⟩ := link_label N (1 / 8) (by norm_num)
  obtain ⟨δF, hδF, hF⟩ := fibre_near_vac N δL hδL
  refine ⟨min (min δL δF) 1, by positivity, ?_⟩
  intro m hm F H V η hbF hH0 hHm hV0 hVm hη hprod
  set δ := min (min δL δF) 1 with hδdef
  have hδL' : δ ≤ δL := (min_le_left _ _).trans (min_le_left _ _)
  have hδF' : δ ≤ δF := (min_le_left _ _).trans (min_le_right _ _)
  have hδ1 : δ ≤ 1 := min_le_right _ _
  by_contra hcon
  simp only [not_or, not_exists, not_and, not_le] at hcon
  obtain ⟨hFs, hHs, hVs, hPs⟩ := hcon
  -- ゲージ（境では 1）
  have hg : ∀ i j, ∃ g : ZMod N × ZMod N → SU2,
      (i ≤ m → j ≤ m → fibDist N (F i j) g < δL) ∧ (bdG m i j → g = fun _ => 1) := by
    intro i j
    by_cases hb : bdG m i j
    · refine ⟨fun _ => 1, fun _ _ => ?_, fun _ => rfl⟩
      rw [hbF i j hb, fibDist_vac]; exact hδL
    · by_cases hr : i ≤ m ∧ j ≤ m
      · obtain ⟨g, hg⟩ := hF (F i j) (lt_of_lt_of_le (hFs i j hr.1 hr.2) hδF')
        exact ⟨g, fun _ _ => hg, fun h => absurd h hb⟩
      · exact ⟨fun _ => 1, fun h1 h2 => absurd ⟨h1, h2⟩ hr, fun h => absurd h hb⟩
  choose g hgd hgb using hg
  -- ラベル
  let lab : (ZMod N × ZMod N → SU2) → ℝ := fun h => if ∑ a, ‖(h a : ℍr) - 1‖ < 1 / 8 then 1 else -1
  have lab_pm : ∀ h, lab h = 1 ∨ lab h = -1 := by
    intro h; simp only [lab]; split_ifs <;> simp
  have lab_sq : ∀ h, lab h * lab h = 1 := by
    intro h; rcases lab_pm h with e | e <;> rw [e] <;> norm_num
  have lab_close : ∀ h : ZMod N × ZMod N → SU2, distPM N h < 1 / 8 →
      ∀ a, ‖(h a : ℍr) - ((lab h : ℝ) : ℍr)‖ ≤ 1 / 8 := by
    intro h hd a
    simp only [lab]
    by_cases hs : ∑ a, ‖(h a : ℍr) - 1‖ < 1 / 8
    · rw [if_pos hs]
      have := Finset.single_le_sum (f := fun a => ‖(h a : ℍr) - 1‖) (fun a _ => norm_nonneg _)
        (Finset.mem_univ a)
      rw [Quaternion.coe_one]; linarith
    · rw [if_neg hs]
      have h2 : ∑ a, ‖(h a : ℍr) + 1‖ < 1 / 8 := by
        unfold distPM at hd
        rcases min_lt_iff.mp hd with h1 | h1
        · exact absurd h1 hs
        · exact h1
      have := Finset.single_le_sum (f := fun a => ‖(h a : ℍr) + 1‖) (fun a _ => norm_nonneg _)
        (Finset.mem_univ a)
      rw [show (((-1 : ℝ)) : ℍr) = -1 by simp, sub_neg_eq_add]; linarith
  have lab_one : ∀ h : ZMod N × ZMod N → SU2, (∀ a, h a = 1) → lab h = 1 := by
    intro h hh
    simp only [lab]
    rw [if_pos]
    simp [hh]
  let hl : (ZMod N × ZMod N → SU2) → (ZMod N × ZMod N → SU2) → (ZMod N × ZMod N → SU2) →
      ZMod N × ZMod N → SU2 := fun g1 U g2 a => (g1 a)⁻¹ * U a * g2 a
  let cH : ℕ → ℕ → ℝ := fun i j => lab (hl (g i j) (H i j) (g (i + 1) j))
  let cV : ℕ → ℕ → ℝ := fun i j => lab (hl (g i j) (V i j) (g i (j + 1)))
  have bd_g : ∀ i j, bdG m i j → ∀ a, g i j a = 1 := fun i j hb a => by rw [hgb i j hb]
  have cH0 : ∀ i, cH i 0 = 1 := fun i => lab_one _ fun a => by
    simp only [hl]; rw [bd_g i 0 (Or.inr (Or.inl rfl)), bd_g (i + 1) 0 (Or.inr (Or.inl rfl)), hH0]; group
  have cHm : ∀ i, cH i m = 1 := fun i => lab_one _ fun a => by
    simp only [hl]
    rw [bd_g i m (Or.inr (Or.inr (Or.inr le_rfl))), bd_g (i + 1) m (Or.inr (Or.inr (Or.inr le_rfl))), hHm]
    group
  have cV0 : ∀ j, cV 0 j = 1 := fun j => lab_one _ fun a => by
    simp only [hl]; rw [bd_g 0 j (Or.inl rfl), bd_g 0 (j + 1) (Or.inl rfl), hV0]; group
  have cVm : ∀ j, cV m j = 1 := fun j => lab_one _ fun a => by
    simp only [hl]
    rw [bd_g m j (Or.inr (Or.inr (Or.inl le_rfl))), bd_g m (j + 1) (Or.inr (Or.inr (Or.inl le_rfl))), hVm]
    group
  -- リンクのラベルは近い
  have closeH : ∀ i j, i < m → j ≤ m → ∀ a,
      ‖((hl (g i j) (H i j) (g (i + 1) j) a : SU2) : ℍr) - ((cH i j : ℝ) : ℍr)‖ ≤ 1 / 8 := by
    intro i j hi hj
    exact lab_close _ (hL (F i j) (F (i + 1) j) (H i j) (g i j) (g (i + 1) j) (hgd i j hi.le hj)
      (hgd (i + 1) j hi hj) (lt_of_lt_of_le (hHs i j hi hj) hδL'))
  have closeV : ∀ i j, i ≤ m → j < m → ∀ a,
      ‖((hl (g i j) (V i j) (g i (j + 1)) a : SU2) : ℍr) - ((cV i j : ℝ) : ℍr)‖ ≤ 1 / 8 := by
    intro i j hi hj
    exact lab_close _ (hL (F i j) (F i (j + 1)) (V i j) (g i j) (g i (j + 1)) (hgd i j hi hj.le)
      (hgd i (j + 1) hi hj) (lt_of_lt_of_le (hVs i j hi hj) hδL'))
  -- 升の関係
  have hrel : ∀ i j, i < m → j < m → η i j = cH i j * cH i (j + 1) * (cV i j * cV (i + 1) j) := by
    intro i j hi hj
    set P := cH i j * cH i (j + 1) * (cV i j * cV (i + 1) j)
    have q1 : cH i j = 1 ∨ cH i j = -1 := lab_pm _
    have q2 : cH i (j + 1) = 1 ∨ cH i (j + 1) = -1 := lab_pm _
    have q3 : cV i j = 1 ∨ cV i j = -1 := lab_pm _
    have q4 : cV (i + 1) j = 1 ∨ cV (i + 1) j = -1 := lab_pm _
    have hPpm : P = 1 ∨ P = -1 := by
      simp only [P]
      rcases q1 with e1 | e1 <;> rcases q2 with e2 | e2 <;> rcases q3 with e3 | e3 <;>
        rcases q4 with e4 | e4 <;> rw [e1, e2, e3, e4] <;> norm_num
    by_contra hne
    have hηP : η i j * P = -1 := by
      rcases hη i j with e | e <;> rcases hPpm with f | f <;> rw [e, f] at hne ⊢ <;>
        first | exact absurd rfl hne | norm_num
    have hs : η i j * (cH i j * cV (i + 1) j * cH i (j + 1) * cV i j) = -1 := by
      rw [← hηP]; simp only [P]; ring
    let x := g i j 0
    let h1 := hl (g i j) (H i j) (g (i + 1) j) 0
    let h2 := hl (g (i + 1) j) (V (i + 1) j) (g (i + 1) (j + 1)) 0
    let h3 := hl (g i (j + 1)) (H i (j + 1)) (g (i + 1) (j + 1)) 0
    let h4 := hl (g i j) (V i j) (g i (j + 1)) 0
    have hid : (H i j 0 : ℍr) * (V (i + 1) j 0 : ℍr) * star (H i (j + 1) 0 : ℍr) * star (V i j 0 : ℍr)
        = (x : ℍr) * ((h1 : ℍr) * h2 * star (h3 : ℍr) * star (h4 : ℍr)) * star (x : ℍr) := by
      have eg : H i j 0 * V (i + 1) j 0 * (H i (j + 1) 0)⁻¹ * (V i j 0)⁻¹
          = x * (h1 * h2 * h3⁻¹ * h4⁻¹) * x⁻¹ := by
        simp only [x, h1, h2, h3, h4, hl]; group
      have := congrArg Subtype.val eg
      simp only [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, inv_unit] at this
      exact this
    have hlab := plaq_label x h1 h2 h3 h4 (cH i j) (cV (i + 1) j) (cH i (j + 1)) (cV i j) (η i j)
      (by
        intro c hc
        simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hc
        rcases hc with rfl | rfl | rfl | rfl
        · exact lab_pm _
        · exact lab_pm _
        · exact lab_pm _
        · exact lab_pm _)
      (hη i j) (1 / 8) (closeH i j hi hj.le 0) (closeV (i + 1) j hi hj 0)
      (closeH i (j + 1) hi hj 0) (closeV i j hi.le hj 0) hs
    rw [← hid] at hlab
    have hle := Finset.single_le_sum
      (f := fun a => 1 - η i j * ((H i j a : ℍr) * (V (i + 1) j a : ℍr) * star (H i (j + 1) a : ℍr)
        * star (V i j a : ℍr)).re)
      (fun a _ => plaq_term_nonneg _ _ _ _ _ (hη i j)) (Finset.mem_univ (0 : ZMod N × ZMod N))
    have hP := hPs i j hi hj
    unfold plaqAct at hP
    linarith
  -- 積
  have hone := grid_plaq_prod_one m hm cH cV (fun i j => lab_sq _) (fun i j => lab_sq _) cH0 cHm cV0 cVm
  have : (∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m, η i j)
      = ∏ i ∈ Finset.range m, ∏ j ∈ Finset.range m,
          (cH i j * cH i (j + 1) * (cV i j * cV (i + 1) j)) := by
    refine Finset.prod_congr rfl fun i hi => Finset.prod_congr rfl fun j hj => ?_
    exact hrel i j (Finset.mem_range.mp hi) (Finset.mem_range.mp hj)
  rw [this, hone] at hprod
  norm_num at hprod

end TwistBlocks

#print axioms TwistBlocks.grid_vortex_floor
