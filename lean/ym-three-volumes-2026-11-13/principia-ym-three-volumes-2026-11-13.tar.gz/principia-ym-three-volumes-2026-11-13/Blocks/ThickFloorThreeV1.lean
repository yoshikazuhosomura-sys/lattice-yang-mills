import Blocks.ThickFloorTorusV1
import VortexCert.CertN3V1

/-!
# 太い渦の床の系（N = 3）：率 9.094

`thick_vortex_floor`（仮定の欄なし）と、有理数の配位の証明書 `VortexCert.SN_three_le : SN 3 ≤ 909321/100000`
から、ε := 9094/1000 − SN 3 > 0 を取って、十分大きい β と（β ごとに）十分大きい M で
`|θ_{M+1}(β)| ≤ exp(−(M+1)² e^{−9.094 β})`。
率 9.094 は薄い渦の床の率 2N² = 18 より小さい（β → ∞ の率の比べ。β と M の閾は陽でない）。
-/

namespace TwistBlocks

theorem thick_vortex_floor_three : ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    |thetaM 3 (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (9094 / 1000))) := by
  have hS := VortexCert.SN_three_le
  have hε : (0 : ℝ) < 9094 / 1000 - SN 3 := by linarith
  have h := thick_vortex_floor 3 _ hε
  have e : SN 3 + (9094 / 1000 - SN 3) = 9094 / 1000 := by ring
  rw [e] at h
  exact h

/-- 率 9.094 は 2·3² = 18 より小さい（数の不等式） -/
theorem thick_vortex_floor_three_rate_lt : (9094 / 1000 : ℝ) < 2 * 3 ^ 2 := by norm_num

end TwistBlocks

#print axioms TwistBlocks.thick_vortex_floor_three
