import Blocks.ThickFloorCanonV1

/-!
# 太い渦の床を |θ| の形で（点検の指摘 1）

片側の形 `θ_M ≤ exp(…)`（`TheoremEStatement`）は θ_M ≤ 0 の M で自明に立つ（θ ≥ 0 は Lean に無い）。
ここでは `block_bound_abs`（|θ| ≤ tanh(K_eff)^{k²}）から同じ鎖を |θ| で通す。log は使わない。
* `abs_block_bound_exp`：`|θ| ≤ exp(−k² e^{−2K_eff})`
* `abs_theta_fixed_m`：`|θ| ≤ exp(−k² exp(−(β(K₀+2δ) + D*)))`（`κ_c ≤ K₀`）
* `ThickVortexFloorAbs N`：全ての ε > 0、十分大きい β、十分大きい M で `|θ_M| ≤ exp(−M² e^{−β(S_N+ε)})`
* `thick_vortex_floor_abs_of_H4`：(H4)（S 一般）から。`thick_vortex_floor_abs_of_local`：`LocalVortex` だけに条件つき。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem abs_block_bound_exp [NeZero m] (hM : m * k ≤ M) (β : ℝ) (n12 : Bool) :
    |(ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)|
      ≤ Real.exp (-((k : ℝ) ^ 2) * Real.exp (-2 * Keff N M m k β n12)) := by
  have hb := block_bound_abs N M m k hM β n12
  set K := Keff N M m k β n12
  have hK0 : 0 ≤ K := Keff_nonneg N M m k β n12
  rcases hK0.lt_or_eq with hK | hK
  · have ht : 0 < Real.tanh K := by
      rw [Real.tanh_eq]
      exact div_pos (sub_pos.mpr (Real.exp_lt_exp.mpr (by linarith))) (by positivity)
    have hlog := BlockFactor.neg_log_tanh_ge hK
    have hpow : Real.tanh K ^ (k ^ 2) = Real.exp (((k ^ 2 : ℕ) : ℝ) * Real.log (Real.tanh K)) := by
      rw [Real.exp_nat_mul, Real.exp_log ht]
    refine hb.trans (hpow.le.trans (Real.exp_le_exp.mpr ?_))
    push_cast
    have hk : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
    nlinarith [mul_le_mul_of_nonneg_left hlog hk]
  · rw [← hK, Real.tanh_zero] at hb
    have hk2 : k ^ 2 ≠ 0 := pow_ne_zero 2 (NeZero.ne k)
    rw [zero_pow hk2] at hb
    exact hb.trans (Real.exp_pos _).le

theorem abs_theta_fixed_m [NeZero m] (hM : m * k ≤ M) (hk : M < (k + 1) * m) (β : ℝ) (hβ : 0 ≤ β)
    (n12 : Bool) {δ : ℝ} (hδ : 0 < δ) (K₀ : ℝ) (hK : kappaC N M m k n12 ≤ K₀) :
    |(ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)|
      ≤ Real.exp (-((k : ℝ) ^ 2) * Real.exp (-(β * (K₀ + 2 * δ) + Dstar N m δ))) := by
  refine (abs_block_bound_exp N M m k hM β n12).trans (Real.exp_le_exp.mpr ?_)
  have hKe := Keff_le_laplace N M m k hM β hβ n12 hδ
  have hD := Dmax_le N M m k hk hδ
  have hA : β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ ≤ β * (K₀ + 2 * δ) + Dstar N m δ := by
    have := mul_le_mul_of_nonneg_left (by linarith : kappaC N M m k n12 + 2 * δ ≤ K₀ + 2 * δ) hβ
    linarith
  have he : Real.exp (-(β * (K₀ + 2 * δ) + Dstar N m δ)) ≤ Real.exp (-2 * Keff N M m k β n12) :=
    Real.exp_le_exp.mpr (by linarith)
  have hk2 : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
  nlinarith [mul_le_mul_of_nonneg_left he hk2]

/-- **太い渦の床（|θ| の形）の言明** -/
def ThickVortexFloorAbs (N : ℕ) [NeZero N] : Prop :=
  ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    |thetaM N (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (SN N + ε)))

theorem thick_vortex_floor_abs_of_H4 (N : ℕ) [NeZero N] (S : ℝ)
    (H4 : ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ S + ε) :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
      |thetaM N (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (S + ε))) := by
  intro ε hε
  obtain ⟨m, hm0, hκ⟩ := H4 (ε / 4) (by positivity)
  have hm : 0 < m := NeZero.pos m
  set δ : ℝ := ε / 8 with hδdef
  have hδ : 0 < δ := by positivity
  set C : ℝ := Dstar N m δ + Real.log (4 * (m : ℝ) ^ 2)
  filter_upwards [Filter.eventually_ge_atTop (0 : ℝ), Filter.eventually_ge_atTop (2 * |C| / ε)]
    with β hβ0 hβC
  filter_upwards [Filter.eventually_ge_atTop m] with M hMm
  have hM1 : m ≤ M + 1 := by omega
  haveI : NeZero ((M + 1) / m) := ⟨(Nat.div_pos hM1 hm).ne'⟩
  set k := (M + 1) / m
  have hk1 : 1 ≤ k := Nat.div_pos hM1 hm
  have hMk : m * k ≤ M + 1 := Nat.mul_div_le (M + 1) m
  have hkM : M + 1 < (k + 1) * m := by
    have := Nat.lt_div_mul_add (a := M + 1) hm
    rw [Nat.add_mul, one_mul]; exact this
  have hK := hκ (M + 1) hM1
  have hθ := abs_theta_fixed_m N (M + 1) m k hMk hkM β hβ0 true hδ (S + ε / 4) hK
  unfold thetaM
  refine hθ.trans (Real.exp_le_exp.mpr ?_)
  have hkr : ((M + 1 : ℕ) : ℝ) ≤ 2 * (m : ℝ) * (k : ℝ) := by
    have h1 : M + 1 < (k + 1) * m := hkM
    have h2 : (k + 1) * m ≤ 2 * m * k := by nlinarith
    exact_mod_cast (h1.trans_le h2).le
  have hmr : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have hsq : ((M + 1 : ℕ) : ℝ) ^ 2 ≤ 4 * (m : ℝ) ^ 2 * (k : ℝ) ^ 2 := by
    have h0 : (0 : ℝ) ≤ ((M + 1 : ℕ) : ℝ) := Nat.cast_nonneg _
    nlinarith
  have hexp : 4 * (m : ℝ) ^ 2 * Real.exp (-β * (S + ε))
      ≤ Real.exp (-(β * (S + ε / 4 + 2 * δ) + Dstar N m δ)) := by
    have h4 : (0 : ℝ) < 4 * (m : ℝ) ^ 2 := by positivity
    rw [← Real.exp_log h4, ← Real.exp_add]
    refine Real.exp_le_exp.mpr ?_
    have hC : C ≤ β * ε / 2 := by
      have := (div_le_iff₀ hε).mp hβC
      have hCa := le_abs_self C
      nlinarith
    simp only [C] at hC
    rw [hδdef]
    nlinarith
  have hE0 : 0 ≤ Real.exp (-β * (S + ε)) := (Real.exp_pos _).le
  have hk2 : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
  calc -((k : ℝ) ^ 2) * Real.exp (-(β * (S + ε / 4 + 2 * δ) + Dstar N m δ))
      ≤ -((k : ℝ) ^ 2) * (4 * (m : ℝ) ^ 2 * Real.exp (-β * (S + ε))) := by
        nlinarith [mul_le_mul_of_nonneg_left hexp hk2]
    _ = -(4 * (m : ℝ) ^ 2 * (k : ℝ) ^ 2) * Real.exp (-β * (S + ε)) := by ring
    _ ≤ -(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (S + ε)) := by
        nlinarith [mul_le_mul_of_nonneg_right hsq hE0]

/-- **太い渦の床（|θ| の形、`LocalVortex` だけに条件つき）** -/
theorem thick_vortex_floor_abs_of_local (N : ℕ) [NeZero N]
    (hL : ∀ m₀ : ℕ+, LocalVortex N m₀ (Svortex N m₀)) : ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_H4 N (SN N) (H4_of_local N (canon_holds N) hL)

end TwistBlocks

#print axioms TwistBlocks.thick_vortex_floor_abs_of_local
