import Blocks.ThickFloorStabV1

/-!
# 紙の (c) の距離の形：作用が小さい局所の配位は、真空のゲージ軌道に近い（命題 4.2 の部品）

局所の模型 `LLink N (V+1)` の上で、升に現れるリンクの偏り
`distV ω g = Σ_升 Σ_{四本} ‖ω(ℓ) − g(始点) V(ℓ) g(終点)⁻¹‖` について、
全ての ε > 0 に δ > 0 があって、SL ω < δ ⇒ ある g で distV ω g < ε（`near_vac_of_small`）。
零作用の剛性（`rigidL_of_rigidT`・`rigidT_all`）とコンパクト性（`small_action_cost`）から。δ は N・V・ε だけに依る。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (V : ℕ)

/-- 真空のゲージ変換の値（四元数） -/
noncomputable def Gv (g : LSite N (V + 1) → SU2) (ℓ : LLink N (V + 1)) : ℍr :=
  (g ℓ.1 : ℍr) * (vacL N (V + 1) ℓ : ℍr) * star (g (tgtL N (V + 1) ℓ) : ℍr)

noncomputable def dB (ω : LLink N (V + 1) → SU2) (g : LSite N (V + 1) → SU2) (B : LPlaq N (V + 1)) : ℝ :=
  ‖(ω (ll1 N (V + 1) B) : ℍr) - Gv N V g (ll1 N (V + 1) B)‖
    + ‖(ω (ll2 N (V + 1) B) : ℍr) - Gv N V g (ll2 N (V + 1) B)‖
    + ‖(ω (ll3 N (V + 1) B) : ℍr) - Gv N V g (ll3 N (V + 1) B)‖
    + ‖(ω (ll4 N (V + 1) B) : ℍr) - Gv N V g (ll4 N (V + 1) B)‖

/-- 升に現れるリンクの上の、真空のゲージ変換からの偏り -/
noncomputable def distV (ω : LLink N (V + 1) → SU2) (g : LSite N (V + 1) → SU2) : ℝ :=
  ∑ B, dB N V ω g B

theorem continuous_distV :
    Continuous fun p : (LLink N (V + 1) → SU2) × (LSite N (V + 1) → SU2) => distV N V p.1 p.2 := by
  have hω : ∀ ℓ, Continuous fun p : (LLink N (V + 1) → SU2) × (LSite N (V + 1) → SU2) =>
      (p.1 ℓ : ℍr) := fun ℓ => continuous_subtype_val.comp ((continuous_apply ℓ).comp continuous_fst)
  have hg : ∀ x, Continuous fun p : (LLink N (V + 1) → SU2) × (LSite N (V + 1) → SU2) =>
      (p.2 x : ℍr) := fun x => continuous_subtype_val.comp ((continuous_apply x).comp continuous_snd)
  have hG : ∀ ℓ, Continuous fun p : (LLink N (V + 1) → SU2) × (LSite N (V + 1) → SU2) =>
      Gv N V p.2 ℓ := fun ℓ => ((hg _).mul continuous_const).mul (continuous_star.comp (hg _))
  have ht : ∀ ℓ, Continuous fun p : (LLink N (V + 1) → SU2) × (LSite N (V + 1) → SU2) =>
      ‖(p.1 ℓ : ℍr) - Gv N V p.2 ℓ‖ := fun ℓ => ((hω ℓ).sub (hG ℓ)).norm
  unfold distV dB
  exact continuous_finsetSum _ fun B _ => (((ht _).add (ht _)).add (ht _)).add (ht _)

/-- **(c) の距離の形**：作用 < δ ⇒ ある局所のゲージ g で、升に現れる全てのリンクの偏りの和 < ε -/
theorem near_vac_of_small : ∀ ε > 0, ∃ δ > 0, ∀ ωl : LLink N (V + 1) → SU2,
    SL N (V + 1) true ωl < δ → ∃ g : LSite N (V + 1) → SU2, distV N V ωl g < ε := by
  intro ε hε
  set K : Set (LSite N (V + 1) → SU2) := Set.univ
  have hK : IsCompact K := isCompact_univ
  have hKne : K.Nonempty := ⟨fun _ => 1, trivial⟩
  let F : (LLink N (V + 1) → SU2) → (LSite N (V + 1) → SU2) → ℝ := fun ω g => distV N V ω g
  have hF : Continuous ↿F := continuous_distV N V
  set Φ := fun ω => sInf (F ω '' K)
  have hΦ : Continuous Φ := hK.continuous_sInf hF
  have h0 : ∀ ω, SL N (V + 1) true ω ≤ 0 → Φ ω ≤ 0 := by
    intro ω hω
    obtain ⟨g, hg⟩ := rigidL_of_rigidT N V (rigidT_all N) ω hω
    have hbdd : BddBelow (F ω '' K) :=
      hK.bddBelow_image ((hF.comp (Continuous.prodMk_right ω)).continuousOn)
    have hz : F ω g = 0 := by
      simp only [F, distV, dB]
      refine Finset.sum_eq_zero fun B _ => ?_
      obtain ⟨h1, h2, h3, h4⟩ := hg B
      simp only [Gv]
      rw [h1, h2, h3, h4, coe_gaugeL, coe_gaugeL, coe_gaugeL, coe_gaugeL]
      simp
    exact (csInf_le hbdd ⟨g, trivial, rfl⟩).trans hz.le
  obtain ⟨δ, hδ, hsm⟩ := ThickFloor.small_action_cost (SL N (V + 1) true) Φ
    (continuous_SL N (V + 1) true) hΦ 0 h0 ε hε
  refine ⟨δ, hδ, fun ω hω => ?_⟩
  have hlt := hsm ω hω
  rw [zero_add] at hlt
  obtain ⟨_, ⟨g, _, rfl⟩, hv⟩ := exists_lt_of_csInf_lt (hKne.image (F ω)) hlt
  exact ⟨g, hv⟩

end TwistBlocks

#print axioms TwistBlocks.near_vac_of_small
