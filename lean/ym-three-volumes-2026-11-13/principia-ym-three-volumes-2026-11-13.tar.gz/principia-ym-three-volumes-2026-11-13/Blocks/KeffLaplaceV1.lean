import Blocks.ClassSumV1

/-!
# 段 3：K_eff の上界 `K_eff ≤ ½ (β (κ_c + 2δ) + D(δ))`（粗い Laplace、具体の SU(2) の Wilson 測度）

紙： 補題 3.1・3.2 と §3 の `K_B ≤ ½(β κ_B + 3 n_B ln(β L_B / c₃) + 1)`。
ここでの形は前因子を陽にしない弱い形：δ > 0 を止めると `D(δ)` は β に依らない。
`κ_c = sup_{b,F} |S^F_min(+) − S^F_min(−)|` で、`S^F_min(±)` は η|_B の類 `Πη_B = ±1` と内部の両方についての
作用の下限（`SminC`。紙の S^F_min(±) は η を一つに止めた形で、補題 2.3 で同じ値。補題 2.3 はここでは使わない）。
`D(δ) = max_b (log #(類の場) − #内部 · log μ₁(δ / L_b))`、`L_b = 4·#{塊 b の升} + 1`。
D(δ) が M に一様であること（塊の大きさが m で決まる）は、ここでは示していない。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

theorem prod_sgn_or {ι : Type*} [Fintype ι] (σ : ι → ℤˣ) :
    (∏ i, sgn (σ i)) = 1 ∨ (∏ i, sgn (σ i)) = -1 := by
  classical
  refine Finset.prod_induction _ (fun x : ℝ => x = 1 ∨ x = -1) ?_ (Or.inl rfl) ?_
  · rintro a b (rfl | rfl) (rfl | rfl) <;> norm_num
  · intro i _; exact sgn_isSignChar.2 (σ i)

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem abs_ext_le (b : Fin k × Fin k) (σ : Fib M m k b → ℤˣ) (P : Pt M) : |ext M m k b σ P| ≤ 1 := by
  unfold ext
  split_ifs with h
  · rcases sgn_isSignChar.2 (σ ⟨P, h⟩) with h' | h' <;> rw [h'] <;> norm_num
  · simp

theorem actB_term_bounds (n12 : Bool) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1) (ω : Link N M → SU2)
    (B : Plaq N M) :
    0 ≤ 1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re ∧
      1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re ≤ 2 := by
  have hz : |zt N M n12 false B * etaB N M e B| ≤ 1 := by
    rw [abs_mul, abs_zt, one_mul]
    unfold etaB; split_ifs
    · exact he _
    · simp
  have hr : |(hol N M ω B).re| ≤ 1 := abs_re_le_one _ (norm_hol N M ω B)
  have hx : |zt N M n12 false B * etaB N M e B * (hol N M ω B).re| ≤ 1 := by
    rw [abs_mul]; nlinarith [abs_nonneg (zt N M n12 false B * etaB N M e B), abs_nonneg (hol N M ω B).re]
  constructor <;> linarith [le_abs_self (zt N M n12 false B * etaB N M e B * (hol N M ω B).re),
    neg_abs_le (zt N M n12 false B * etaB N M e B * (hol N M ω B).re)]

theorem actB_nonneg (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (ω : Link N M → SU2) : 0 ≤ actB N M m k n12 b e ω :=
  Finset.sum_nonneg fun B _ => (actB_term_bounds N M n12 e he ω B).1

theorem actB_le (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (ω : Link N M → SU2) : actB N M m k n12 b e ω ≤ 2 * (nB N M m k b : ℝ) := by
  unfold actB nB
  refine (Finset.sum_le_sum fun B _ => (actB_term_bounds N M n12 e he ω B).2).trans ?_
  rw [Finset.sum_const, nsmul_eq_mul]; linarith

/-! ## 点ごとの上下の評価（類の和から） -/

theorem class_lower (β : ℝ) (n12 : Bool) (b : Fin k × Fin k) (s : ℝ) (hs : s = 1 ∨ s = -1)
    (ω : Link N M → SU2) (σ0 : Fib M m k b → ℤˣ) (h0 : s * ∏ P, sgn (σ0 P) = 1) :
    2 * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ0) ω))
      ≤ Cb N M m k β n12 b ω + s * Sb N M m k β n12 b ω := by
  rw [class_sum]
  have hnn : ∀ σ : Fib M m k b → ℤˣ, 0 ≤ (1 + s * ∏ P, sgn (σ P))
      * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ) ω)) := by
    intro σ
    refine mul_nonneg ?_ (Real.exp_pos _).le
    rcases hs with rfl | rfl <;> rcases prod_sgn_or σ with h | h <;> rw [h] <;> norm_num
  have := Finset.single_le_sum (fun σ _ => hnn σ) (Finset.mem_univ σ0)
  calc 2 * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ0) ω))
      = (1 + s * ∏ P, sgn (σ0 P))
        * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ0) ω)) := by
        rw [h0]; ring
    _ ≤ _ := this

theorem class_upper (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool) (b : Fin k × Fin k) (s : ℝ)
    (hs : s = 1 ∨ s = -1) (ω : Link N M → SU2) (mlow : ℝ)
    (hlow : ∀ σ : Fib M m k b → ℤˣ, s * ∏ P, sgn (σ P) = 1 → mlow ≤ actB N M m k n12 b (ext M m k b σ) ω) :
    Cb N M m k β n12 b ω + s * Sb N M m k β n12 b ω
      ≤ 2 * (Fintype.card (Fib M m k b → ℤˣ) : ℝ) * Real.exp (β * ((nB N M m k b : ℝ) - mlow)) := by
  rw [class_sum]
  have hterm : ∀ σ : Fib M m k b → ℤˣ, (1 + s * ∏ P, sgn (σ P))
      * Real.exp (β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ) ω))
      ≤ 2 * Real.exp (β * ((nB N M m k b : ℝ) - mlow)) := by
    intro σ
    by_cases h : s * ∏ P, sgn (σ P) = 1
    · rw [h]
      have := hlow σ h
      have : β * ((nB N M m k b : ℝ) - actB N M m k n12 b (ext M m k b σ) ω)
          ≤ β * ((nB N M m k b : ℝ) - mlow) := mul_le_mul_of_nonneg_left (by linarith) hβ
      have := Real.exp_le_exp.mpr this
      linarith
    · have h' : s * ∏ P, sgn (σ P) = -1 := by
        rcases hs with rfl | rfl <;> rcases prod_sgn_or σ with h2 | h2 <;> rw [h2] at h ⊢ <;>
          (try norm_num at h) <;> (try norm_num)
      rw [h']
      have := Real.exp_pos (β * ((nB N M m k b : ℝ) - mlow))
      norm_num; positivity
  refine (Finset.sum_le_sum fun σ _ => hterm σ).trans ?_
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  ring_nf; exact le_refl _

/-! ## 類と内部についての作用の下限 -/

/-- `S^F_min(s)`：類 `s Πσ = 1` の符号の場と内部の配位の全体についての塊の作用の下限 -/
noncomputable def SminC (n12 : Bool) (b : Fin k × Fin k) (F : Frame N M m k → SU2) (s : ℝ) : ℝ :=
  ⨅ p : (Inner N M m k b → SU2) × {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1},
    actB N M m k n12 b (ext M m k b p.2.1) (glueB N M m k b F p.1)

theorem bdd_SminC (n12 : Bool) (b : Fin k × Fin k) (F : Frame N M m k → SU2) (s : ℝ) :
    BddBelow (Set.range fun p : (Inner N M m k b → SU2) × {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1} =>
      actB N M m k n12 b (ext M m k b p.2.1) (glueB N M m k b F p.1)) :=
  ⟨0, by rintro _ ⟨p, rfl⟩; exact actB_nonneg N M m k n12 b _ (abs_ext_le M m k b p.2.1) _⟩

theorem cls_nonempty [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (s : ℝ) (hs : s = 1 ∨ s = -1) :
    Nonempty {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1} := by
  rcases hs with rfl | rfl
  · exact ⟨⟨fun _ => 1, by simp [sgn]⟩⟩
  · let P0 : Fib M m k b := ⟨corner M m k b, blk2_corner M m k hM b⟩
    let σ0 : Fib M m k b → ℤˣ := Pi.mulSingle P0 (-1)
    refine ⟨⟨σ0, ?_⟩⟩
    have h : ∀ P : Fib M m k b, sgn (σ0 P) = if P = P0 then -1 else 1 := by
      intro P; simp only [σ0]; rw [Pi.mulSingle_apply]; split_ifs <;> simp [sgn]
    simp only [h, Finset.prod_ite_eq', Finset.mem_univ, if_true]
    norm_num

theorem SminC_le (n12 : Bool) (b : Fin k × Fin k) (F : Frame N M m k → SU2) (s : ℝ)
    (y : Inner N M m k b → SU2) (σ : Fib M m k b → ℤˣ) (hσ : s * ∏ P, sgn (σ P) = 1) :
    SminC N M m k n12 b F s ≤ actB N M m k n12 b (ext M m k b σ) (glueB N M m k b F y) :=
  ciInf_le (bdd_SminC N M m k n12 b F s) (y, ⟨σ, hσ⟩)

/-! ## Laplace（一般の符号の場） -/

theorem laplace_ext (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (F : Frame N M m k → SU2) (y0 : Inner N M m k b → SU2) {β δ : ℝ} (hβ : 0 ≤ β) (hδ : 0 < δ) :
    Real.exp (-β * (actB N M m k n12 b e (glueB N M m k b F y0) + δ))
        * (haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal
          ^ Fintype.card (Inner N M m k b)
      ≤ ∫ y, Real.exp (-β * actB N M m k n12 b e (glueB N M m k b F y))
          ∂(Measure.pi fun _ : Inner N M m k b => haarSU2) := by
  have hL : 0 < 4 * (nB N M m k b : ℝ) + 1 := by positivity
  have hcont : Continuous fun ω : Link N M → SU2 => actB N M m k n12 b e ω := by
    unfold actB
    exact continuous_finsetSum _ fun B _ =>
      continuous_const.sub (continuous_const.mul (continuous_hol_re N M B))
  have hglue : Continuous (glueB N M m k b F) :=
    LipschitzWith.continuous (K := 1) (LipschitzWith.of_dist_le_mul fun y y' => by
      simpa using dist_glueB_le N M m k b F y y')
  refine CoarseLaplace.laplace_lower _ (hcont.comp hglue) hL (fun y y' => ?_) hβ hδ y0
  refine (actB_lipschitz N M m k n12 b _ he _ _).trans ?_
  have hd := dist_glueB_le N M m k b F y y'
  have hc : (0 : ℝ) ≤ 4 * (nB N M m k b : ℝ) := by positivity
  have := dist_nonneg (x := y) (y := y')
  unfold nB at hc ⊢
  nlinarith [mul_le_mul_of_nonneg_left hd hc]

/-! ## 塊の分配関数の上下 -/

theorem ZB_upper [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) (s : ℝ) (hs : s = 1 ∨ s = -1) :
    ZB N M m k β n12 s b F
      ≤ 2 * (Fintype.card (Fib M m k b → ℤˣ) : ℝ)
          * Real.exp (β * ((nB N M m k b : ℝ) - SminC N M m k n12 b F s)) := by
  unfold ZB
  have hi := (integrable_glue N M m k b F _ (continuous_Cb N M m k β n12 b)).add
    ((integrable_glue N M m k b F _ (continuous_Sb N M m k β n12 b)).const_mul s)
  set c := 2 * (Fintype.card (Fib M m k b → ℤˣ) : ℝ)
    * Real.exp (β * ((nB N M m k b : ℝ) - SminC N M m k n12 b F s))
  calc (∫ y, (Cb N M m k β n12 b (glueB N M m k b F y) + s * Sb N M m k β n12 b (glueB N M m k b F y))
        ∂(Measure.pi fun _ : Inner N M m k b => haarSU2))
      ≤ ∫ _y, c ∂(Measure.pi fun _ : Inner N M m k b => haarSU2) :=
        integral_mono hi (integrable_const _) fun y =>
          class_upper N M m k β hβ n12 b s hs _ _ (fun σ hσ => SminC_le N M m k n12 b F s y σ hσ)
    _ = c := by rw [integral_const]; simp

theorem ZB_lower [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) (s : ℝ) (hs : s = 1 ∨ s = -1) {δ : ℝ} (hδ : 0 < δ) :
    2 * Real.exp (β * (nB N M m k b : ℝ)) * Real.exp (-β * (SminC N M m k n12 b F s + 2 * δ))
        * (haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal
          ^ Fintype.card (Inner N M m k b)
      ≤ ZB N M m k β n12 s b F := by
  haveI := cls_nonempty M m k hM b s hs
  obtain ⟨p0, hp0⟩ := exists_lt_of_ciInf_lt (f := fun p : (Inner N M m k b → SU2) ×
      {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1} =>
        actB N M m k n12 b (ext M m k b p.2.1) (glueB N M m k b F p.1))
    (show SminC N M m k n12 b F s < SminC N M m k n12 b F s + δ by linarith)
  set μr := (haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal
  have hμ : 0 ≤ μr ^ Fintype.card (Inner N M m k b) := by positivity
  have hlap := laplace_ext N M m k n12 b (ext M m k b p0.2.1) (abs_ext_le M m k b p0.2.1) F p0.1 hβ hδ
  have hcont : Continuous fun ω : Link N M → SU2 =>
      Real.exp (-β * actB N M m k n12 b (ext M m k b p0.2.1) ω) := by
    refine Real.continuous_exp.comp (continuous_const.mul ?_)
    unfold actB
    exact continuous_finsetSum _ fun B _ =>
      continuous_const.sub (continuous_const.mul (continuous_hol_re N M B))
  have hiE := integrable_glue N M m k b F _ hcont
  have hpt : ∀ y, 2 * Real.exp (β * (nB N M m k b : ℝ))
      * Real.exp (-β * actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F y))
      ≤ Cb N M m k β n12 b (glueB N M m k b F y) + s * Sb N M m k β n12 b (glueB N M m k b F y) := by
    intro y
    have := class_lower N M m k β n12 b s hs (glueB N M m k b F y) p0.2.1 p0.2.2
    have e : Real.exp (β * (nB N M m k b : ℝ))
        * Real.exp (-β * actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F y))
        = Real.exp (β * ((nB N M m k b : ℝ)
            - actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F y))) := by
      rw [← Real.exp_add]; ring_nf
    rw [mul_assoc, e]; exact this
  have hi := (integrable_glue N M m k b F _ (continuous_Cb N M m k β n12 b)).add
    ((integrable_glue N M m k b F _ (continuous_Sb N M m k β n12 b)).const_mul s)
  have hint := integral_mono (hiE.const_mul (2 * Real.exp (β * (nB N M m k b : ℝ)))) hi hpt
  rw [integral_const_mul] at hint
  unfold ZB
  have hexp : Real.exp (-β * (SminC N M m k n12 b F s + 2 * δ))
      ≤ Real.exp (-β * (actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F p0.1) + δ)) := by
    refine Real.exp_le_exp.mpr ?_
    have : actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F p0.1) + δ
        ≤ SminC N M m k n12 b F s + 2 * δ := by linarith
    nlinarith
  have h2 : (0 : ℝ) ≤ 2 * Real.exp (β * (nB N M m k b : ℝ)) := by positivity
  calc 2 * Real.exp (β * (nB N M m k b : ℝ)) * Real.exp (-β * (SminC N M m k n12 b F s + 2 * δ))
        * μr ^ Fintype.card (Inner N M m k b)
      ≤ 2 * Real.exp (β * (nB N M m k b : ℝ))
        * (Real.exp (-β * (actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F p0.1) + δ))
          * μr ^ Fintype.card (Inner N M m k b)) := by
        rw [mul_assoc]
        exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hexp hμ) h2
    _ ≤ 2 * Real.exp (β * (nB N M m k b : ℝ))
        * ∫ y, Real.exp (-β * actB N M m k n12 b (ext M m k b p0.2.1) (glueB N M m k b F y))
            ∂(Measure.pi fun _ : Inner N M m k b => haarSU2) :=
        mul_le_mul_of_nonneg_left hlap h2
    _ ≤ _ := hint

/-! ## K_eff の上界 -/

/-- 塊ごとの定数 `D_b(δ) = log #(塊の符号の場) − #内部 · log μ₁(δ / L_b)` -/
noncomputable def Db (b : Fin k × Fin k) (δ : ℝ) : ℝ :=
  Real.log (Fintype.card (Fib M m k b → ℤˣ) : ℝ) - (Fintype.card (Inner N M m k b) : ℝ) *
    Real.log ((haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal)

/-- `D(δ) = max_b D_b(δ)`（β に依らない。塊の形だけで決まる量の最大） -/
noncomputable def Dmax (δ : ℝ) : ℝ := ⨆ b : Fin k × Fin k, Db N M m k b δ

theorem log_ratio_le [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) (s : ℝ) (hs : s = 1 ∨ s = -1) {δ : ℝ} (hδ : 0 < δ) :
    Real.log (ZB N M m k β n12 s b F) - Real.log (ZB N M m k β n12 (-s) b F)
      ≤ β * (SminC N M m k n12 b F (-s) - SminC N M m k n12 b F s + 2 * δ) + Db N M m k b δ := by
  have hs' : -s = 1 ∨ -s = -1 := by rcases hs with rfl | rfl <;> norm_num
  have habs : ∀ t : ℝ, (t = 1 ∨ t = -1) → |t| ≤ 1 := by
    rintro t (rfl | rfl) <;> norm_num
  have hZs := ZB_pos N M m k hM β n12 s (habs s hs) b F
  have hZm := ZB_pos N M m k hM β n12 (-s) (habs (-s) hs') b F
  have hup := ZB_upper N M m k hM β hβ n12 b F s hs
  have hlo := ZB_lower N M m k hM β hβ n12 b F (-s) hs' hδ
  have hL : 0 < δ / (4 * (nB N M m k b : ℝ) + 1) := div_pos hδ (by positivity)
  have hμ := CoarseLaplace.haar_ball_toReal_pos hL
  set μr := (haarSU2 (Metric.ball 1 (δ / (4 * (nB N M m k b : ℝ) + 1)))).toReal
  set c := (Fintype.card (Fib M m k b → ℤˣ) : ℝ)
  set n := Fintype.card (Inner N M m k b)
  have hc : 0 < c := by
    simp only [c]; exact_mod_cast Fintype.card_pos
  have l1 : Real.log (ZB N M m k β n12 s b F)
      ≤ Real.log 2 + Real.log c + β * ((nB N M m k b : ℝ) - SminC N M m k n12 b F s) := by
    have := Real.log_le_log hZs hup
    rwa [Real.log_mul (by positivity) (Real.exp_pos _).ne', Real.log_mul (by norm_num) hc.ne',
      Real.log_exp] at this
  have l2 : Real.log 2 + β * (nB N M m k b : ℝ) + (-β * (SminC N M m k n12 b F (-s) + 2 * δ))
      + (n : ℝ) * Real.log μr ≤ Real.log (ZB N M m k β n12 (-s) b F) := by
    have hpos : 0 < 2 * Real.exp (β * (nB N M m k b : ℝ))
        * Real.exp (-β * (SminC N M m k n12 b F (-s) + 2 * δ)) * μr ^ n := by positivity
    have := Real.log_le_log hpos hlo
    rwa [Real.log_mul (by positivity) (pow_pos hμ n).ne', Real.log_mul (by positivity)
      (Real.exp_pos _).ne', Real.log_mul (by norm_num) (Real.exp_pos _).ne', Real.log_exp,
      Real.log_exp, Real.log_pow] at this
  unfold Db
  linarith

theorem abs_log_ZB_le_laplace [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool)
    (b : Fin k × Fin k) (F : Frame N M m k → SU2) {δ : ℝ} (hδ : 0 < δ) :
    |Real.log (ZB N M m k β n12 1 b F / ZB N M m k β n12 (-1) b F)|
      ≤ β * (|SminC N M m k n12 b F 1 - SminC N M m k n12 b F (-1)| + 2 * δ) + Db N M m k b δ := by
  have hZp := ZB_pos N M m k hM β n12 1 (by norm_num) b F
  have hZm := ZB_pos N M m k hM β n12 (-1) (by norm_num) b F
  have r1 := log_ratio_le N M m k hM β hβ n12 b F 1 (Or.inl rfl) hδ
  have r2 := log_ratio_le N M m k hM β hβ n12 b F (-1) (Or.inr rfl) hδ
  rw [neg_neg] at r2
  rw [Real.log_div hZp.ne' hZm.ne', abs_le]
  have a1 := le_abs_self (SminC N M m k n12 b F 1 - SminC N M m k n12 b F (-1))
  have a2 := neg_abs_le (SminC N M m k n12 b F 1 - SminC N M m k n12 b F (-1))
  constructor <;> nlinarith

theorem SminC_bounds [NeZero m] (hM : m * k ≤ M) (n12 : Bool) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) (s : ℝ) (hs : s = 1 ∨ s = -1) :
    0 ≤ SminC N M m k n12 b F s ∧ SminC N M m k n12 b F s ≤ 2 * (Fintype.card (Plaq N M) : ℝ) := by
  haveI := cls_nonempty M m k hM b s hs
  obtain ⟨σ0⟩ := cls_nonempty M m k hM b s hs
  constructor
  · exact le_ciInf fun p => actB_nonneg N M m k n12 b _ (abs_ext_le M m k b p.2.1) _
  · refine (SminC_le N M m k n12 b F s (fun _ => 1) σ0.1 σ0.2).trans ?_
    refine (actB_le N M m k n12 b _ (abs_ext_le M m k b σ0.1) _).trans ?_
    have : (nB N M m k b : ℝ) ≤ (Fintype.card (Plaq N M) : ℝ) := by
      unfold nB; exact_mod_cast (Finset.card_filter_le _ _).trans (Finset.card_univ.le)
    linarith

/-- `κ_c = sup_{b,F} |S^F_min(+) − S^F_min(−)|`（類と内部の下限で） -/
noncomputable def kappaC (n12 : Bool) : ℝ :=
  ⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2),
    |SminC N M m k n12 p.1 p.2 1 - SminC N M m k n12 p.1 p.2 (-1)|

theorem bdd_kappaC [NeZero m] (hM : m * k ≤ M) (n12 : Bool) :
    BddAbove (Set.range fun p : (Fin k × Fin k) × (Frame N M m k → SU2) =>
      |SminC N M m k n12 p.1 p.2 1 - SminC N M m k n12 p.1 p.2 (-1)|) := by
  refine ⟨2 * (Fintype.card (Plaq N M) : ℝ), ?_⟩
  rintro _ ⟨p, rfl⟩
  obtain ⟨a1, a2⟩ := SminC_bounds N M m k hM n12 p.1 p.2 1 (Or.inl rfl)
  obtain ⟨b1, b2⟩ := SminC_bounds N M m k hM n12 p.1 p.2 (-1) (Or.inr rfl)
  simp only
  rw [abs_le]; constructor <;> linarith

/-- **段 3 の結論（K_eff の上界、弱い一様な Laplace）**：β ≥ 0、δ > 0 で
`K_eff ≤ ½ (β (κ_c + 2δ) + D(δ))`。 -/
theorem Keff_le_laplace [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool)
    {δ : ℝ} (hδ : 0 < δ) :
    Keff N M m k β n12 ≤ (1 / 2) * (β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ) := by
  unfold Keff
  have : (⨆ p : (Fin k × Fin k) × (Frame N M m k → SU2),
      |Real.log (ZB N M m k β n12 1 p.1 p.2 / ZB N M m k β n12 (-1) p.1 p.2)|)
      ≤ β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ := by
    refine ciSup_le fun p => (abs_log_ZB_le_laplace N M m k hM β hβ n12 p.1 p.2 hδ).trans ?_
    have hk := le_ciSup (bdd_kappaC N M m k hM n12) p
    have hD : Db N M m k p.1 δ ≤ Dmax N M m k δ := by
      unfold Dmax
      exact le_ciSup (Set.finite_range fun b => Db N M m k b δ).bddAbove p.1
    have : β * (|SminC N M m k n12 p.1 p.2 1 - SminC N M m k n12 p.1 p.2 (-1)| + 2 * δ)
        ≤ β * (kappaC N M m k n12 + 2 * δ) := by
      refine mul_le_mul_of_nonneg_left ?_ hβ
      unfold kappaC; linarith
    linarith
  linarith

/-- **系**：`θ_M ≤ exp(−k² · exp(−(β (κ_c + 2δ) + D(δ))))`（β ≥ 0、δ > 0、`m·k ≤ M`） -/
theorem theta_laplace [NeZero m] (hM : m * k ≤ M) (β : ℝ) (hβ : 0 ≤ β) (n12 : Bool)
    {δ : ℝ} (hδ : 0 < δ) :
    (ZW N M β n12 false - ZW N M β n12 true) / (ZW N M β n12 false + ZW N M β n12 true)
      ≤ Real.exp (-((k : ℝ) ^ 2) * Real.exp (-(β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ))) := by
  refine (block_bound_exp N M m k hM β n12).trans (Real.exp_le_exp.mpr ?_)
  have hK := Keff_le_laplace N M m k hM β hβ n12 hδ
  have he : Real.exp (-(β * (kappaC N M m k n12 + 2 * δ) + Dmax N M m k δ))
      ≤ Real.exp (-2 * Keff N M m k β n12) := Real.exp_le_exp.mpr (by linarith)
  have hk : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
  nlinarith [mul_le_mul_of_nonneg_left he hk]

end TwistBlocks

#print axioms TwistBlocks.Keff_le_laplace
#print axioms TwistBlocks.theta_laplace
