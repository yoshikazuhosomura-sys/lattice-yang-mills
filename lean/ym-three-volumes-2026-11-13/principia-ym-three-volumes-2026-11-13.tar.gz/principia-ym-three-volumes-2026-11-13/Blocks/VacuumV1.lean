import Blocks.TheoremECondV1

/-!
# 段 4 の (a) の部品：捩れた真空 V の作用は 0、一枚反転で 2N²、`0 ≤ S_N ≤ 2N²`

紙：（V の升の積：(1,2) の升は (x₁,x₂) = (0,0) で −1、他は +1、全ての升で z·½tr U = 1）と、
自明な上界 `S_N ≤ S_渦(N, 1) ≤ 2N²`。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem coe_qI : ((qI : SU2) : ℍr) = ⟨0, 1, 0, 0⟩ := rfl
theorem coe_qJ : ((qJ : SU2) : ℍr) = ⟨0, 0, 1, 0⟩ := rfl

theorem re_ij (a b : ℍr) (a0 : a.re = 0) (a1 : a.imI = 1) (a2 : a.imJ = 0) (a3 : a.imK = 0)
    (b0 : b.re = 0) (b1 : b.imI = 0) (b2 : b.imJ = 1) (b3 : b.imK = 0) :
    (a * b * star a * star b).re = -1 := by
  simp only [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul, Quaternion.imK_mul,
    Quaternion.re_star, Quaternion.imI_star, Quaternion.imJ_star, Quaternion.imK_star,
    a0, a1, a2, a3, b0, b1, b2, b3]
  norm_num

theorem re_mul_star_unit (u : SU2) : ((u : ℍr) * star (u : ℍr)).re = 1 := by
  rw [Quaternion.self_mul_star, Quaternion.re_coe, Quaternion.normSq_eq_norm_mul_self,
    norm_eq_of_mem_sphere, one_mul]

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem vac_shift0 (x : Site N M) (ν : Fin 4) (hν : ν ≠ 0) : vac N M (x + ev N M ν, 0) = vac N M (x, 0) := by
  unfold vac
  fin_cases ν
  · exact absurd rfl hν
  all_goals simp [ev]

theorem vac_shift1 (x : Site N M) (ν : Fin 4) (hν : ν ≠ 1) : vac N M (x + ev N M ν, 1) = vac N M (x, 1) := by
  unfold vac
  fin_cases ν
  · simp [ev]
  · exact absurd rfl hν
  all_goals simp [ev]

theorem vac_23 (x : Site N M) (μ : Fin 4) (h : μ = 2 ∨ μ = 3) : vac N M (x, μ) = 1 := by
  unfold vac; rcases h with rfl | rfl <;> simp

def q02 : Plane := ⟨(0, 2), by decide⟩
def q03 : Plane := ⟨(0, 3), by decide⟩
def q12 : Plane := ⟨(1, 2), by decide⟩
def q13 : Plane := ⟨(1, 3), by decide⟩

theorem plane_cases (P : Plane) : P = p01 ∨ P = q02 ∨ P = q03 ∨ P = q12 ∨ P = q13 ∨ P = p23 := by
  revert P; decide

/-- 真空 V では全ての升で `z_B Re U_B = 1`（背景 n₁₂ = 1、n₃₄ = 0） -/
theorem vac_term (B : Plaq N M) : zt N M true false B * (hol N M (vac N M) B).re = 1 := by
  obtain ⟨x, P⟩ := B
  have s02 := vac_shift0 N M x 2 (by decide)
  have s03 := vac_shift0 N M x 3 (by decide)
  have s01 := vac_shift0 N M x 1 (by decide)
  have s12 := vac_shift1 N M x 2 (by decide)
  have s13 := vac_shift1 N M x 3 (by decide)
  have s10 := vac_shift1 N M x 0 (by decide)
  have v2 : ∀ y : Site N M, vac N M (y, 2) = 1 := fun y => vac_23 N M y 2 (Or.inl rfl)
  have v3 : ∀ y : Site N M, vac N M (y, 3) = 1 := fun y => vac_23 N M y 3 (Or.inr rfl)
  have hne : ∀ Q : Plane, Q ≠ p01 → Q ≠ p23 → zt N M true false (x, Q) = 1 := by
    intro Q h1 h2; unfold zt; simp [h1, h2]
  have h23 : zt N M true false (x, p23) = 1 := by unfold zt; simp [tw, p01, p23]
  rcases plane_cases P with rfl | rfl | rfl | rfl | rfl | rfl
  · unfold hol l1 l2 l3 l4
    simp only [p01, s10, s01]
    by_cases h1 : x.1.1 = 0 <;> by_cases h2 : x.1.2 = 0
    · have hx : x.1 = 0 := Prod.ext h1 h2
      have ha : vac N M (x, 0) = qI := by unfold vac; simp [h1]
      have hb : vac N M (x, 1) = qJ := by unfold vac; simp [h2]
      have hz : zt N M true false (x, p01) = -1 := by unfold zt; simp [hx, tw, p01, p23]
      simp only [p01] at hz
      rw [hz, ha, hb, re_ij _ _ (by rw [coe_qI]) (by rw [coe_qI]) (by rw [coe_qI]) (by rw [coe_qI])
        (by rw [coe_qJ]) (by rw [coe_qJ]) (by rw [coe_qJ]) (by rw [coe_qJ])]; norm_num
    · have hb : vac N M (x, 1) = 1 := by unfold vac; simp [h2]
      have hx : x.1 ≠ 0 := fun h => h2 (congrArg Prod.snd h)
      have hz : zt N M true false (x, p01) = 1 := by unfold zt; simp [hx, p01, p23]
      simp only [p01] at hz
      rw [hz, hb]; simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]
      rw [re_mul_star_unit]
    · have ha : vac N M (x, 0) = 1 := by unfold vac; simp [h1]
      have hx : x.1 ≠ 0 := fun h => h1 (congrArg Prod.fst h)
      have hz : zt N M true false (x, p01) = 1 := by unfold zt; simp [hx, p01, p23]
      simp only [p01] at hz
      rw [hz, ha]; simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]
      rw [re_mul_star_unit]
    · have ha : vac N M (x, 0) = 1 := by unfold vac; simp [h1]
      have hx : x.1 ≠ 0 := fun h => h1 (congrArg Prod.fst h)
      have hz : zt N M true false (x, p01) = 1 := by unfold zt; simp [hx, p01, p23]
      simp only [p01] at hz
      rw [hz, ha]; simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]
      rw [re_mul_star_unit]
  · rw [hne _ (by decide) (by decide), one_mul]
    unfold hol l1 l2 l3 l4; simp only [q02, s02, v2]
    simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]; rw [re_mul_star_unit]
  · rw [hne _ (by decide) (by decide), one_mul]
    unfold hol l1 l2 l3 l4; simp only [q03, s03, v3]
    simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]; rw [re_mul_star_unit]
  · rw [hne _ (by decide) (by decide), one_mul]
    unfold hol l1 l2 l3 l4; simp only [q12, s12, v2]
    simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]; rw [re_mul_star_unit]
  · rw [hne _ (by decide) (by decide), one_mul]
    unfold hol l1 l2 l3 l4; simp only [q13, s13, v3]
    simp only [Metric.unitSphere.coe_one, star_one, mul_one, one_mul]; rw [re_mul_star_unit]
  · rw [h23, one_mul]
    unfold hol l1 l2 l3 l4; simp only [p23, v2, v3]
    (try simp) <;> rfl

/-- 真空 V で η ≡ 1 の塊の作用は 0 -/
theorem actB_vac_one (b : Fin k × Fin k) : actB N M m k true b (fun _ => 1) (vac N M) = 0 := by
  unfold actB
  refine Finset.sum_eq_zero fun B _ => ?_
  have h := vac_term N M B
  have he : etaB N M (fun _ => 1) B = 1 := by unfold etaB; split_ifs <;> rfl
  rw [he, mul_one, h, sub_self]

/-- 真空 V で、塊 b の中の二次元の升 P₀ を一枚反転すると、塊の作用は `2N²` -/
theorem actB_vac_flip (b : Fin k × Fin k) (P0 : Pt M) (hP0 : blk2 M m k P0 = b) :
    actB N M m k true b (etaAt M P0) (vac N M) = 2 * (N : ℝ) ^ 2 := by
  unfold actB
  have hterm : ∀ B : Plaq N M, 1 - zt N M true false B * etaB N M (etaAt M P0) B * (hol N M (vac N M) B).re
      = if B.2 = p23 ∧ B.1.2 = P0 then 2 else 0 := by
    intro B
    have h := vac_term N M B
    unfold etaB etaAt
    by_cases h1 : B.2 = p23 <;> by_cases h2 : B.1.2 = P0
    · simp only [h1, h2, if_true, and_self]
      have : zt N M true false B * -1 * (hol N M (vac N M) B).re = -(zt N M true false B * (hol N M (vac N M) B).re) := by ring
      rw [this, h]; norm_num
    all_goals simp only [h1, h2, if_true, if_false, and_true, and_false, true_and, false_and, mul_one]
    all_goals linarith
  rw [Finset.sum_congr rfl fun B _ => hterm B, ← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
  have hcard : ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
      (fun B : Plaq N M => B.2 = p23 ∧ B.1.2 = P0)).card = N ^ 2 := by
    have : (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
        (fun B : Plaq N M => B.2 = p23 ∧ B.1.2 = P0)
        = (univ : Finset (ZMod N × ZMod N)).map
            ⟨fun x => ((x, P0), p23), fun x y h => by simpa using h⟩ := by
      ext B
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_map, Function.Embedding.coeFn_mk]
      constructor
      · rintro ⟨_, h1, h2⟩
        exact ⟨B.1.1, by rw [← h1, ← h2]; rfl⟩
      · rintro ⟨x, rfl⟩
        exact ⟨hP0, rfl, rfl⟩
    rw [this, Finset.card_map, Finset.card_univ, Fintype.card_prod, ZMod.card, sq]
  rw [hcard]; push_cast; ring

/-- 塊の作用の局所性（補題 2.1a から）：枠と塊 b の内部で一致すれば塊 b の作用は等しい -/
theorem actB_local (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (ω ω' : Link N M → SU2)
    (h1 : ∀ ℓ, fr N M m k ℓ → ω ℓ = ω' ℓ)
    (h2 : ∀ ℓ (h : ¬ fr N M m k ℓ), blkL N M m k ⟨ℓ, h⟩ = b → ω ℓ = ω' ℓ) :
    actB N M m k n12 b e ω = actB N M m k n12 b e ω' := by
  unfold actB
  refine Finset.sum_congr rfl fun B hB => ?_
  have h := aB_local N M m k 1 n12 b ω ω' h1 h2 B (Finset.mem_filter.mp hB).2
  unfold aB at h
  have hz : zt N M n12 false B ≠ 0 := by
    intro h0; have := abs_zt N M n12 false B; rw [h0, abs_zero] at this; norm_num at this
  have hre : (hol N M ω B).re = (hol N M ω' B).re := by
    have := mul_left_cancel₀ hz (by simpa [one_mul] using h)
    exact this
  rw [hre]

theorem Svortex_le (N m : ℕ) [NeZero N] [NeZero m] : Svortex N m ≤ 2 * (N : ℝ) ^ 2 := by
  unfold Svortex Smin
  haveI : NeZero (2 * m) := ⟨by have := NeZero.ne m; omega⟩
  have hM : m * 2 ≤ 2 * m := by rw [mul_comm]
  let F : Frame N (2 * m) m 2 → SU2 := fun x => vac N (2 * m) x.1
  let y0 : Inner N (2 * m) m 2 (0, 0) → SU2 := fun j => vac N (2 * m) j.1.1
  have hnn : ∀ y : Inner N (2 * m) m 2 (0, 0) → SU2,
      0 ≤ actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true) (glueB N (2 * m) m 2 (0, 0) F y) :=
    fun y => actB_nonneg N (2 * m) m 2 true (0, 0) _ (abs_etaSign_le (2 * m) m 2 (0, 0) true) _
  have hbdd : BddBelow (Set.range fun y : Inner N (2 * m) m 2 (0, 0) → SU2 =>
      actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true) (glueB N (2 * m) m 2 (0, 0) F y)) := by
    refine ⟨0, ?_⟩
    rintro _ ⟨y, rfl⟩
    exact hnn y
  refine (ciInf_le hbdd y0).trans (le_of_eq ?_)
  rw [actB_local N (2 * m) m 2 true (0, 0) _ (glueB N (2 * m) m 2 (0, 0) F y0) (vac N (2 * m))
    (fun ℓ h => by unfold glueB BlockFubini.glue; simp [h, F])
    (fun ℓ h hb => by unfold glueB BlockFubini.glue; simp [h, hb, y0])]
  unfold etaSign; simp only [if_true]
  exact actB_vac_flip N (2 * m) m 2 (0, 0) _ (blk2_corner (2 * m) m 2 hM (0, 0))

theorem Svortex_nonneg (N m : ℕ) [NeZero N] [NeZero m] : 0 ≤ Svortex N m := by
  unfold Svortex Smin
  haveI : NeZero (2 * m) := ⟨by have := NeZero.ne m; omega⟩
  exact le_ciInf fun y => actB_nonneg N (2 * m) m 2 true (0, 0) _
    (abs_etaSign_le (2 * m) m 2 (0, 0) true) _

/-- **`0 ≤ S_N ≤ 2N²`**（紙 §1.3 の自明な上界。S_N の定義が有限の実数であることの確認） -/
theorem SN_bounds (N : ℕ) [NeZero N] : 0 ≤ SN N ∧ SN N ≤ 2 * (N : ℝ) ^ 2 := by
  have hbdd : BddBelow (Set.range fun m : ℕ+ => Svortex N (m : ℕ)) :=
    ⟨0, by rintro _ ⟨m, rfl⟩; exact Svortex_nonneg N m⟩
  constructor
  · exact le_ciInf fun m => Svortex_nonneg N m
  · exact (ciInf_le hbdd 1).trans (Svortex_le N 1)

end TwistBlocks

#print axioms TwistBlocks.vac_term
#print axioms TwistBlocks.actB_vac_flip
#print axioms TwistBlocks.SN_bounds
