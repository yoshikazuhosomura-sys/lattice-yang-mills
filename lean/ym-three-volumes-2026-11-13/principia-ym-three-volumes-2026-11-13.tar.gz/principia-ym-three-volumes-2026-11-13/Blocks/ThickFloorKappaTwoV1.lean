import Blocks.ThickFloorAttainV1

/-!
# `κ_c ≤ 2N²`（全ての m、M に一様）：角の一枚の η の反転で類を移す

紙：「Z₂：上は (+) の最小点で升を一枚反転すれば差は ≤ 2N²（どの群でも）」。
段 4 (a) の `κ_c ≤ 288 N² m`（`kappaC_le_linear`）より強い、m によらない上界。
系：段 3 と合わせて、仮定の欄なしで率 2N²（`theoremE_of_stage4` の S = 2N²、|θ| の形）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem SminC_flip_le [NeZero m] (hM : m * k ≤ M) (b : Fin k × Fin k) (F : Frame N M m k → SU2)
    (s : ℝ) (hs : s = 1 ∨ s = -1) :
    SminC N M m k true b F (-s) ≤ SminC N M m k true b F s + 2 * (N : ℝ) ^ 2 := by
  have hs' : -s = 1 ∨ -s = -1 := by rcases hs with rfl | rfl <;> norm_num
  haveI := cls_nonempty M m k hM b s hs
  let P0 : Fib M m k b := ⟨corner M m k b, blk2_corner M m k hM b⟩
  have key : ∀ p : (Inner N M m k b → SU2) × {σ : Fib M m k b → ℤˣ // s * ∏ P, sgn (σ P) = 1},
      SminC N M m k true b F (-s) - 2 * (N : ℝ) ^ 2
        ≤ actB N M m k true b (ext M m k b p.2.1) (glueB N M m k b F p.1) := by
    rintro ⟨y, σ, hσ⟩
    let σ' : Fib M m k b → ℤˣ := fun P => σ P * (Pi.mulSingle P0 (-1 : ℤˣ) : Fib M m k b → ℤˣ) P
    have hsg : ∀ P, sgn (σ' P) = sgn (σ P) * (if P = P0 then -1 else 1) := by
      intro P; simp only [σ']; rw [sgn_mul', Pi.mulSingle_apply]; split_ifs <;> simp [sgn]
    have hσ' : -s * ∏ P, sgn (σ' P) = 1 := by
      simp only [hsg, Finset.prod_mul_distrib, Finset.prod_ite_eq', Finset.mem_univ, if_true]
      linarith
    have hext : ∀ x, x ≠ corner M m k b → ext M m k b σ' x = ext M m k b σ x := by
      intro x hx
      unfold ext
      split_ifs with h
      · simp only [σ']
        rw [Pi.mulSingle_eq_of_ne (fun e => hx (congrArg Subtype.val e)), mul_one]
      · rfl
    have hc := flip_cost N M m k true b (ext M m k b σ) (ext M m k b σ') (abs_ext_le M m k b σ)
      (abs_ext_le M m k b σ') (corner M m k b) hext (glueB N M m k b F y)
    have hle := SminC_le N M m k true b F (-s) y σ' hσ'
    simp only
    linarith
  have := le_ciInf key
  unfold SminC at this ⊢
  linarith

/-- **`κ_c ≤ 2N²`**（全ての m・M、`m·k ≤ M`） -/
theorem kappaC_le_two [NeZero m] (hM : m * k ≤ M) : kappaC N M m k true ≤ 2 * (N : ℝ) ^ 2 := by
  refine ciSup_le fun p => ?_
  have h1 := SminC_flip_le N M m k hM p.1 p.2 1 (Or.inl rfl)
  have h2 := SminC_flip_le N M m k hM p.1 p.2 (-1) (Or.inr rfl)
  rw [neg_neg] at h2
  rw [abs_le]; constructor <;> linarith

/-- 系（仮定の欄なし）：(H4) は S = 2N² で立つ（m = 1） -/
theorem H4_two (N : ℕ) [NeZero N] :
    ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ 2 * (N : ℝ) ^ 2 + ε := by
  intro ε hε
  refine ⟨1, inferInstance, fun M _ _ _ => ?_⟩
  have := kappaC_le_two N M 1 (M / 1) (Nat.mul_div_le M 1)
  linarith

end TwistBlocks

#print axioms TwistBlocks.kappaC_le_two
#print axioms TwistBlocks.H4_two
