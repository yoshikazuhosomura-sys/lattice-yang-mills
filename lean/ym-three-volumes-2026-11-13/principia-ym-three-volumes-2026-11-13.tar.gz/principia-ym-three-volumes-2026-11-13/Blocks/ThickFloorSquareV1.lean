import Blocks.ThickFloorTransportV1
import Blocks.ThickFloorAxialV1

/-!
# 剛性の第一段（紙の命題 4.1 (c)）：局所の模型の向き 3・4 をゲージで消し、T²_N の問題に帰着

局所の模型 `LLink N (V+1)`（二次元のずれ `Fin (V+2)`）の上で、作用 0 の配位 ωl に対し、
極大の木（x₃ の向きに u₄ = 0 の行、そこから x₄ の向きに列）に沿った前からの積 `h0` でゲージを取ると、
向き 3・4 のリンクは全て 1、向き 1・2 のリンクは二次元のずれに依らない（升の平坦さで帰納）。
残りは T²_N の上の問題 `RigidT N`（升の積が捩れの符号の配位は、真空のゲージ変換）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N] (V : ℕ)

/-- 自然数のずれ（`V+1` で止める） -/
def fv (n : ℕ) : Fin (V + 2) := ⟨min n (V + 1), by omega⟩
def fw (n : ℕ) : Fin (V + 1) := ⟨min n V, by omega⟩

/-- 自然数の座標のリンクと升 -/
def lk (a : ZMod N × ZMod N) (n3 n4 : ℕ) (μ : Fin 4) : LLink N (V + 1) := ((a, (fv V n3, fv V n4)), μ)
def pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (P : Plane) : LPlaq N (V + 1) := ((a, (fw V n3, fw V n4)), P)

def d3 (μ : Fin 4) : ℕ := if μ = 2 then 1 else 0
def d4 (μ : Fin 4) : ℕ := if μ = 3 then 1 else 0

theorem ev12_2 : ev12 N 2 = 0 := by unfold ev12; rfl
theorem ev12_3 : ev12 N 3 = 0 := by unfold ev12; rfl

theorem ll1_pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) :
    ll1 N (V + 1) (pl N V a n3 n4 P) = lk N V a n3 n4 P.1.1 := by
  ext <;> simp [ll1, pl, lk, fv, fw] <;> omega

theorem ll4_pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) :
    ll4 N (V + 1) (pl N V a n3 n4 P) = lk N V a n3 n4 P.1.2 := by
  ext <;> simp [ll4, pl, lk, fv, fw] <;> omega

theorem ll2_pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) :
    ll2 N (V + 1) (pl N V a n3 n4 P)
      = lk N V (a + ev12 N P.1.1) (n3 + d3 P.1.1) (n4 + d4 P.1.1) P.1.2 := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases μ <;> ext <;> simp [ll2, pl, lk, fv, fw, shL, d3, d4] <;> omega

theorem ll3_pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) :
    ll3 N (V + 1) (pl N V a n3 n4 P)
      = lk N V (a + ev12 N P.1.2) (n3 + d3 P.1.2) (n4 + d4 P.1.2) P.1.1 := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases ν <;> ext <;> simp [ll3, pl, lk, fv, fw, shL, d3, d4] <;> omega

theorem pl_eta (B : LPlaq N (V + 1)) :
    pl N V B.1.1 B.1.2.1.val B.1.2.2.val B.2 = B := by
  obtain ⟨⟨a, u3, u4⟩, P⟩ := B
  have := u3.isLt; have := u4.isLt
  ext <;> simp [pl, fw] <;> omega

/-! ## 単位四元数の小さい補題 -/

theorem coe_one_SU2 : ((1 : SU2) : ℍr) = 1 := Metric.unitSphere.coe_one

theorem mul_star_unit (u : SU2) : (u : ℍr) * star (u : ℍr) = 1 := by
  rw [Quaternion.self_mul_star, normSq_unit]; simp

theorem star_mul_unit (u : SU2) : star (u : ℍr) * (u : ℍr) = 1 := by
  rw [Quaternion.star_mul_self, normSq_unit]; simp

theorem eq_of_mul_star (x y : SU2) (h : (x : ℍr) * star (y : ℍr) = 1) : x = y := by
  apply Subtype.ext
  calc (x : ℍr) = (x : ℍr) * (star (y : ℍr) * (y : ℍr)) := by rw [star_mul_unit, mul_one]
    _ = ((x : ℍr) * star (y : ℍr)) * (y : ℍr) := by rw [mul_assoc]
    _ = y := by rw [h, one_mul]

/-- 平坦さはゲージで保たれる -/
theorem flat_gaugeL (g : LSite N (V + 1) → SU2) (ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) ω B = ((zL N (V + 1) true B : ℝ) : ℍr)) :
    ∀ B, holL N (V + 1) (gaugeL N (V + 1) g ω) B = ((zL N (V + 1) true B : ℝ) : ℍr) := by
  intro B
  rw [holL_gaugeL, hf B, ← Quaternion.coe_commutes, mul_assoc, mul_star_unit, mul_one]

/-- 升の平坦さを自然数の座標で -/
theorem flat_nat (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) :
    (Ω (lk N V a n3 n4 P.1.1) : ℍr)
        * (Ω (lk N V (a + ev12 N P.1.1) (n3 + d3 P.1.1) (n4 + d4 P.1.1) P.1.2) : ℍr)
        * star (Ω (lk N V (a + ev12 N P.1.2) (n3 + d3 P.1.2) (n4 + d4 P.1.2) P.1.1) : ℍr)
        * star (Ω (lk N V a n3 n4 P.1.2) : ℍr)
      = ((zL N (V + 1) true (pl N V a n3 n4 P) : ℝ) : ℍr) := by
  have := hf (pl N V a n3 n4 P)
  unfold holL at this
  rwa [ll1_pl N V a n3 n4 h3 h4, ll2_pl N V a n3 n4 h3 h4, ll3_pl N V a n3 n4 h3 h4,
    ll4_pl N V a n3 n4 h3 h4] at this

theorem zL_pl (a : ZMod N × ZMod N) (n3 n4 : ℕ) (P : Plane) (hP : P ≠ p01) :
    zL N (V + 1) true (pl N V a n3 n4 P) = 1 := by
  unfold zL pl; rw [if_neg]; rintro ⟨h, _⟩; exact hP h

theorem zL_pl01 (a : ZMod N × ZMod N) (n3 n4 : ℕ) :
    zL N (V + 1) true (pl N V a n3 n4 p01) = if a = 0 then -1 else 1 := by
  unfold zL pl tw; simp

/-! ## 木のゲージ `h0` -/

/-- 前からの積：u₄ = 0 の行を x₃ の向きに、そこから列を x₄ の向きに -/
noncomputable def h0 (ωl : LLink N (V + 1) → SU2) (x : LSite N (V + 1)) : SU2 :=
  ThickFloor.pre (fun n => ωl (lk N V x.1 n 0 2)) x.2.1.val
    * ThickFloor.pre (fun n => ωl (lk N V x.1 x.2.1.val n 3)) x.2.2.val

theorem fv_val (n : ℕ) (h : n ≤ V + 1) : (fv V n).val = n := by simp [fv]; omega

theorem fv_succ (n : ℕ) (h : n ≤ V) : fv V n + 1 = fv V (n + 1) := by
  apply Fin.ext
  rw [Fin.val_add]
  simp only [fv, Fin.val_one]
  rw [min_eq_left (by omega), min_eq_left (by omega)]
  exact Nat.mod_eq_of_lt (by omega)

theorem h0_lk (ωl : LLink N (V + 1) → SU2) (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V + 1)
    (h4 : n4 ≤ V + 1) :
    h0 N V ωl (a, (fv V n3, fv V n4)) = ThickFloor.pre (fun n => ωl (lk N V a n 0 2)) n3
      * ThickFloor.pre (fun n => ωl (lk N V a n3 n 3)) n4 := by
  unfold h0
  simp only [fv_val V n3 h3, fv_val V n4 h4]

theorem tree3 (ωl : LLink N (V + 1) → SU2) (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V + 1)
    (h4 : n4 ≤ V) : gaugeL N (V + 1) (h0 N V ωl) ωl (lk N V a n3 n4 3) = 1 := by
  have ht : tgtL N (V + 1) (lk N V a n3 n4 3) = (a, (fv V n3, fv V (n4 + 1))) := by
    simp [tgtL, lk, nxtL, ev12_3, fv_succ V n4 h4]
  unfold gaugeL
  rw [ht]
  show h0 N V ωl (a, (fv V n3, fv V n4)) * ωl (lk N V a n3 n4 3)
    * (h0 N V ωl (a, (fv V n3, fv V (n4 + 1))))⁻¹ = 1
  rw [h0_lk N V ωl a n3 n4 h3 (by omega), h0_lk N V ωl a n3 (n4 + 1) h3 (by omega)]
  simp only [ThickFloor.pre, mul_assoc, mul_inv_rev, mul_inv_cancel_left, mul_inv_cancel]

theorem tree2 (ωl : LLink N (V + 1) → SU2) (a : ZMod N × ZMod N) (n3 : ℕ) (h3 : n3 ≤ V) :
    gaugeL N (V + 1) (h0 N V ωl) ωl (lk N V a n3 0 2) = 1 := by
  have ht : tgtL N (V + 1) (lk N V a n3 0 2) = (a, (fv V (n3 + 1), fv V 0)) := by
    simp [tgtL, lk, nxtL, ev12_2, fv_succ V n3 h3]
  unfold gaugeL
  rw [ht]
  show h0 N V ωl (a, (fv V n3, fv V 0)) * ωl (lk N V a n3 0 2)
    * (h0 N V ωl (a, (fv V (n3 + 1), fv V 0)))⁻¹ = 1
  rw [h0_lk N V ωl a n3 0 (by omega) (by omega), h0_lk N V ωl a (n3 + 1) 0 (by omega) (by omega)]
  simp only [ThickFloor.pre, mul_one, mul_inv_rev, mul_assoc, mul_inv_cancel_left, mul_inv_cancel]

/-! ## 帰納：向き 3 のリンクは 1、向き 1・2 のリンクは二次元のずれに依らない -/

theorem one_of_star (x : SU2) (h : star (x : ℍr) = 1) : x = 1 := by
  apply Subtype.ext
  rw [coe_one_SU2]
  have := congrArg star h
  rwa [star_star, star_one] at this

theorem flat23 (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) :
    (Ω (lk N V a n3 n4 2) : ℍr) * (Ω (lk N V a (n3 + 1) n4 3) : ℍr)
      * star (Ω (lk N V a n3 (n4 + 1) 2) : ℍr) * star (Ω (lk N V a n3 n4 3) : ℍr) = 1 := by
  have e := flat_nat N V Ω hf a n3 n4 h3 h4 p23
  rw [zL_pl N V a n3 n4 p23 (by decide)] at e
  have d32 : d3 2 = 1 := rfl
  have d42 : d4 2 = 0 := rfl
  have d33 : d3 3 = 0 := rfl
  have d43 : d4 3 = 1 := rfl
  have p1 : p23.1.1 = 2 := rfl
  have p2 : p23.1.2 = 3 := rfl
  rw [p1, p2, d32, d42, d33, d43, ev12_2, ev12_3] at e
  simp only [add_zero, Quaternion.coe_one] at e
  exact e

theorem flat_x2 (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) (μ : Fin 4)
    (hP1 : P.1.1 = μ) (hP2 : P.1.2 = 2) (hμ : μ = 0 ∨ μ = 1) :
    (Ω (lk N V a n3 n4 μ) : ℍr) * (Ω (lk N V (a + ev12 N μ) n3 n4 2) : ℍr)
      * star (Ω (lk N V a (n3 + 1) n4 μ) : ℍr) * star (Ω (lk N V a n3 n4 2) : ℍr) = 1 := by
  have e := flat_nat N V Ω hf a n3 n4 h3 h4 P
  have hne : P ≠ p01 := by rintro rfl; exact absurd hP2 (by decide)
  rw [zL_pl N V a n3 n4 P hne, hP1, hP2] at e
  have hd3 : d3 μ = 0 := by rcases hμ with rfl | rfl <;> rfl
  have hd4 : d4 μ = 0 := by rcases hμ with rfl | rfl <;> rfl
  have d32 : d3 2 = 1 := rfl
  have d42 : d4 2 = 0 := rfl
  rw [hd3, hd4, d32, d42, ev12_2] at e
  simp only [add_zero, Quaternion.coe_one] at e
  exact e

theorem flat_x3 (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) (P : Plane) (μ : Fin 4)
    (hP1 : P.1.1 = μ) (hP2 : P.1.2 = 3) (hμ : μ = 0 ∨ μ = 1) :
    (Ω (lk N V a n3 n4 μ) : ℍr) * (Ω (lk N V (a + ev12 N μ) n3 n4 3) : ℍr)
      * star (Ω (lk N V a n3 (n4 + 1) μ) : ℍr) * star (Ω (lk N V a n3 n4 3) : ℍr) = 1 := by
  have e := flat_nat N V Ω hf a n3 n4 h3 h4 P
  have hne : P ≠ p01 := by rintro rfl; exact absurd hP2 (by decide)
  rw [zL_pl N V a n3 n4 P hne, hP1, hP2] at e
  have hd3 : d3 μ = 0 := by rcases hμ with rfl | rfl <;> rfl
  have hd4 : d4 μ = 0 := by rcases hμ with rfl | rfl <;> rfl
  have d33 : d3 3 = 0 := rfl
  have d43 : d4 3 = 1 := rfl
  rw [hd3, hd4, d33, d43, ev12_3] at e
  simp only [add_zero, Quaternion.coe_one] at e
  exact e

theorem ind2 (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (h3t : ∀ a n3 n4, n3 ≤ V + 1 → n4 ≤ V → Ω (lk N V a n3 n4 3) = 1)
    (h2t : ∀ a n3, n3 ≤ V → Ω (lk N V a n3 0 2) = 1)
    (a : ZMod N × ZMod N) (n3 : ℕ) (h3 : n3 ≤ V) :
    ∀ n4, n4 ≤ V + 1 → Ω (lk N V a n3 n4 2) = 1 := by
  intro n4
  induction n4 with
  | zero => intro _; exact h2t a n3 h3
  | succ n ih =>
    intro h4
    have e := flat23 N V Ω hf a n3 n h3 (by omega)
    rw [ih (by omega), h3t a (n3 + 1) n (by omega) (by omega), h3t a n3 n (by omega) (by omega)] at e
    simp only [coe_one_SU2, one_mul, star_one, mul_one] at e
    exact one_of_star _ e

theorem ind_up (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (h3t : ∀ a n3 n4, n3 ≤ V + 1 → n4 ≤ V → Ω (lk N V a n3 n4 3) = 1)
    (P : Plane) (μ : Fin 4) (hP1 : P.1.1 = μ) (hP2 : P.1.2 = 3) (hμ : μ = 0 ∨ μ = 1)
    (a : ZMod N × ZMod N) (n3 : ℕ) (h3 : n3 ≤ V) :
    ∀ n4, n4 ≤ V + 1 → Ω (lk N V a n3 n4 μ) = Ω (lk N V a n3 0 μ) := by
  intro n4
  induction n4 with
  | zero => intro _; rfl
  | succ n ih =>
    intro h4
    have e := flat_x3 N V Ω hf a n3 n h3 (by omega) P μ hP1 hP2 hμ
    rw [h3t (a + ev12 N μ) n3 n (by omega) (by omega), h3t a n3 n (by omega) (by omega)] at e
    simp only [coe_one_SU2, mul_one, star_one] at e
    rw [← ih (by omega)]
    exact (eq_of_mul_star _ _ e).symm

theorem ind_right (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (h2all : ∀ a n3, n3 ≤ V → ∀ n4, n4 ≤ V + 1 → Ω (lk N V a n3 n4 2) = 1)
    (P : Plane) (μ : Fin 4) (hP1 : P.1.1 = μ) (hP2 : P.1.2 = 2) (hμ : μ = 0 ∨ μ = 1)
    (a : ZMod N × ZMod N) (n4 : ℕ) (h4 : n4 ≤ V) :
    ∀ n3, n3 ≤ V + 1 → Ω (lk N V a n3 n4 μ) = Ω (lk N V a 0 n4 μ) := by
  intro n3
  induction n3 with
  | zero => intro _; rfl
  | succ n ih =>
    intro h3
    have e := flat_x2 N V Ω hf a n n4 (by omega) h4 P μ hP1 hP2 hμ
    rw [h2all (a + ev12 N μ) n (by omega) n4 (by omega), h2all a n (by omega) n4 (by omega)] at e
    simp only [coe_one_SU2, mul_one, star_one] at e
    rw [← ih (by omega)]
    exact (eq_of_mul_star _ _ e).symm

theorem torus_const (Ω : LLink N (V + 1) → SU2)
    (hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr))
    (h3t : ∀ a n3 n4, n3 ≤ V + 1 → n4 ≤ V → Ω (lk N V a n3 n4 3) = 1)
    (h2all : ∀ a n3, n3 ≤ V → ∀ n4, n4 ≤ V + 1 → Ω (lk N V a n3 n4 2) = 1)
    (P2 P3 : Plane) (μ : Fin 4) (hP21 : P2.1.1 = μ) (hP22 : P2.1.2 = 2) (hP31 : P3.1.1 = μ)
    (hP32 : P3.1.2 = 3) (hμ : μ = 0 ∨ μ = 1)
    (a : ZMod N × ZMod N) (n3 n4 : ℕ) (h3 : n3 ≤ V + 1) (h4 : n4 ≤ V + 1) (h : n3 ≤ V ∨ n4 ≤ V) :
    Ω (lk N V a n3 n4 μ) = Ω (lk N V a 0 0 μ) := by
  rcases h with h | h
  · rw [ind_up N V Ω hf h3t P3 μ hP31 hP32 hμ a n3 h n4 h4,
      ind_right N V Ω hf h2all P2 μ hP21 hP22 hμ a 0 (by omega) n3 h3]
  · rw [ind_right N V Ω hf h2all P2 μ hP21 hP22 hμ a n4 h n3 h3,
      ind_up N V Ω hf h3t P3 μ hP31 hP32 hμ a 0 (by omega) n4 h4]

/-! ## 升のリンクの座標の範囲 -/

def RC (κ : Fin 4) (m3 m4 : ℕ) : Prop :=
  (κ = 0 ∧ m3 ≤ V + 1 ∧ m4 ≤ V + 1 ∧ (m3 ≤ V ∨ m4 ≤ V)) ∨
  (κ = 1 ∧ m3 ≤ V + 1 ∧ m4 ≤ V + 1 ∧ (m3 ≤ V ∨ m4 ≤ V)) ∨
  (κ = 2 ∧ m3 ≤ V ∧ m4 ≤ V + 1) ∨ (κ = 3 ∧ m3 ≤ V + 1 ∧ m4 ≤ V)

theorem rc1 (P : Plane) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) : RC V P.1.1 n3 n4 := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases μ <;> fin_cases ν <;> simp [RC] at h ⊢ <;> omega

theorem rc4 (P : Plane) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) : RC V P.1.2 n3 n4 := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases μ <;> fin_cases ν <;> simp [RC] at h ⊢ <;> omega

theorem rc2 (P : Plane) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) :
    RC V P.1.2 (n3 + d3 P.1.1) (n4 + d4 P.1.1) := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases μ <;> fin_cases ν <;> simp [RC, d3, d4] at h ⊢ <;> omega

theorem rc3 (P : Plane) (n3 n4 : ℕ) (h3 : n3 ≤ V) (h4 : n4 ≤ V) :
    RC V P.1.1 (n3 + d3 P.1.2) (n4 + d4 P.1.2) := by
  obtain ⟨⟨μ, ν⟩, h⟩ := P
  fin_cases μ <;> fin_cases ν <;> simp [RC, d3, d4] at h ⊢ <;> omega

/-! ## T²_N の剛性と、局所の剛性への持ち上げ -/

/-- **T²_N の剛性**：升の積が捩れの符号（(0,0) で −1、他で 1）の配位 (A, B) は、
T²_N の真空（A = i（a₁ = 0）、B = j（a₂ = 0）、他は 1）のゲージ変換 -/
def RigidT : Prop :=
  ∀ A B : ZMod N × ZMod N → SU2,
    (∀ a, (A a : ℍr) * (B (a + ev12 N 0) : ℍr) * star (A (a + ev12 N 1) : ℍr) * star (B a : ℍr)
        = (((if a = 0 then -1 else 1 : ℝ)) : ℍr)) →
    ∃ R : ZMod N × ZMod N → SU2, ∀ a,
      R a * A a * (R (a + ev12 N 0))⁻¹ = (if a.1 = 0 then qI else 1) ∧
      R a * B a * (R (a + ev12 N 1))⁻¹ = (if a.2 = 0 then qJ else 1)

/-- **剛性の第一段**：T²_N の剛性から局所の模型の剛性 -/
theorem rigidL_of_rigidT (hT : RigidT N) : RigidL N (V + 1) := by
  intro ωl hω
  set Ω := gaugeL N (V + 1) (h0 N V ωl) ωl with hΩ
  have hf : ∀ B, holL N (V + 1) Ω B = ((zL N (V + 1) true B : ℝ) : ℍr) :=
    flat_gaugeL N V _ ωl (flat_local N (V + 1) true ωl hω)
  have h3t : ∀ a n3 n4, n3 ≤ V + 1 → n4 ≤ V → Ω (lk N V a n3 n4 3) = 1 :=
    fun a n3 n4 h3 h4 => tree3 N V ωl a n3 n4 h3 h4
  have h2t : ∀ a n3, n3 ≤ V → Ω (lk N V a n3 0 2) = 1 := fun a n3 h3 => tree2 N V ωl a n3 h3
  have h2all : ∀ a n3, n3 ≤ V → ∀ n4, n4 ≤ V + 1 → Ω (lk N V a n3 n4 2) = 1 :=
    fun a n3 h3 => ind2 N V Ω hf h3t h2t a n3 h3
  have hc0 := torus_const N V Ω hf h3t h2all q02 q03 0 rfl rfl rfl rfl (Or.inl rfl)
  have hc1 := torus_const N V Ω hf h3t h2all q12 q13 1 rfl rfl rfl rfl (Or.inr rfl)
  obtain ⟨R, hR⟩ := hT (fun a => Ω (lk N V a 0 0 0)) (fun a => Ω (lk N V a 0 0 1)) (fun a => by
    have e := flat_nat N V Ω hf a 0 0 (by omega) (by omega) p01
    rw [zL_pl01] at e
    have p1 : p01.1.1 = 0 := rfl
    have p2 : p01.1.2 = 1 := rfl
    have d30 : d3 0 = 0 := rfl
    have d40 : d4 0 = 0 := rfl
    have d31 : d3 1 = 0 := rfl
    have d41 : d4 1 = 0 := rfl
    rw [p1, p2, d30, d40, d31, d41] at e
    exact e)
  have comp : ∀ ℓ : LLink N (V + 1),
      gaugeL N (V + 1) (fun x => R x.1 * h0 N V ωl x) ωl ℓ
        = R ℓ.1.1 * Ω ℓ * (R (tgtL N (V + 1) ℓ).1)⁻¹ := by
    intro ℓ; simp only [gaugeL, hΩ]; group
  have good : ∀ a m3 m4 κ, RC V κ m3 m4 →
      gaugeL N (V + 1) (fun x => R x.1 * h0 N V ωl x) ωl (lk N V a m3 m4 κ)
        = vacL N (V + 1) (lk N V a m3 m4 κ) := by
    intro a m3 m4 κ hrc
    rw [comp]
    rcases hrc with ⟨rfl, h3, h4, h⟩ | ⟨rfl, h3, h4, h⟩ | ⟨rfl, h3, h4⟩ | ⟨rfl, h3, h4⟩
    · show R a * Ω (lk N V a m3 m4 0) * (R (a + ev12 N 0))⁻¹ = _
      rw [hc0 a m3 m4 h3 h4 h, (hR a).1]
      simp [vacL, lk]
    · show R a * Ω (lk N V a m3 m4 1) * (R (a + ev12 N 1))⁻¹ = _
      rw [hc1 a m3 m4 h3 h4 h, (hR a).2]
      simp [vacL, lk]
    · show R a * Ω (lk N V a m3 m4 2) * (R (a + ev12 N 2))⁻¹ = _
      rw [h2all a m3 h3 m4 h4, ev12_2, add_zero, mul_one, mul_inv_cancel]
      simp [vacL, lk]
    · show R a * Ω (lk N V a m3 m4 3) * (R (a + ev12 N 3))⁻¹ = _
      rw [h3t a m3 m4 h3 h4, ev12_3, add_zero, mul_one, mul_inv_cancel]
      simp [vacL, lk]
  have key : ∀ ℓ, gaugeL N (V + 1) (fun x => R x.1 * h0 N V ωl x) ωl ℓ = vacL N (V + 1) ℓ →
      ωl ℓ = gaugeL N (V + 1) (fun x => (R x.1 * h0 N V ωl x)⁻¹) (vacL N (V + 1)) ℓ := by
    intro ℓ h
    simp only [gaugeL] at h ⊢
    rw [← h]
    group
  refine ⟨fun x => (R x.1 * h0 N V ωl x)⁻¹, fun B => ?_⟩
  obtain ⟨⟨a, u3, u4⟩, P⟩ := B
  have h3 : u3.val ≤ V := by have := u3.isLt; omega
  have h4 : u4.val ≤ V := by have := u4.isLt; omega
  have hB : (((a, (u3, u4)), P) : LPlaq N (V + 1)) = pl N V a u3.val u4.val P :=
    (pl_eta N V ((a, (u3, u4)), P)).symm
  rw [hB, ll1_pl N V a _ _ h3 h4, ll2_pl N V a _ _ h3 h4, ll3_pl N V a _ _ h3 h4,
    ll4_pl N V a _ _ h3 h4]
  exact ⟨key _ (good _ _ _ _ (rc1 V P _ _ h3 h4)), key _ (good _ _ _ _ (rc2 V P _ _ h3 h4)),
    key _ (good _ _ _ _ (rc3 V P _ _ h3 h4)), key _ (good _ _ _ _ (rc4 V P _ _ h3 h4))⟩

/-- 太い渦の床は T²_N の剛性 `RigidT N` だけに条件つき -/
theorem thick_vortex_floor_abs_of_rigidT (hT : RigidT N) : ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_rigid N fun m₀ => rigidL_of_rigidT N ((m₀ : ℕ) + 1) hT

/-! ## N = 1：T²_1 は一点、反可換な組の共役（`anticomm_conj`）で閉じる -/

theorem rigidT_one : RigidT 1 := by
  intro A B hAB
  have hs : ∀ a : ZMod 1 × ZMod 1, a = 0 := fun a => Subsingleton.elim _ _
  have h := hAB 0
  rw [hs (0 + ev12 1 0), hs (0 + ev12 1 1), if_pos rfl] at h
  have sx : star (A 0 : ℍr) * (A 0 : ℍr) = 1 := star_mul_unit _
  have sy : star (B 0 : ℍr) * (B 0 : ℍr) = 1 := star_mul_unit _
  have hxy : (A 0 : ℍr) * (B 0 : ℍr) = -((B 0 : ℍr) * (A 0 : ℍr)) := by
    have e : (A 0 : ℍr) * (B 0 : ℍr) * star (A 0 : ℍr) * star (B 0 : ℍr) * ((B 0 : ℍr) * (A 0 : ℍr))
        = (((-1 : ℝ)) : ℍr) * ((B 0 : ℍr) * (A 0 : ℍr)) := by rw [h]
    have l : (A 0 : ℍr) * (B 0 : ℍr) * star (A 0 : ℍr) * star (B 0 : ℍr) * ((B 0 : ℍr) * (A 0 : ℍr))
        = (A 0 : ℍr) * (B 0 : ℍr) := by
      calc _ = (A 0 : ℍr) * (B 0 : ℍr) * star (A 0 : ℍr) * (star (B 0 : ℍr) * (B 0 : ℍr))
              * (A 0 : ℍr) := by simp only [mul_assoc]
        _ = (A 0 : ℍr) * (B 0 : ℍr) * (star (A 0 : ℍr) * (A 0 : ℍr)) := by
              rw [sy, mul_one, mul_assoc]
        _ = _ := by rw [sx, mul_one]
    rw [l] at e
    rw [e]; simp
  obtain ⟨g, hg0, hgA, hgB⟩ :=
    ThickFloor.anticomm_conj (A 0 : ℍr) (B 0 : ℍr) (normSq_unit _) (normSq_unit _) hxy
  have hn : ‖g‖ ≠ 0 := norm_ne_zero_iff.mpr hg0
  let u : SU2 := ⟨g * ((‖g‖⁻¹ : ℝ) : ℍr), by
    rw [mem_sphere_zero_iff_norm, norm_mul, Quaternion.norm_coe, Real.norm_eq_abs, abs_inv, abs_norm,
      mul_inv_cancel₀ hn]⟩
  have hu0 : (u : ℍr) ≠ 0 := by
    intro h0
    have := congrArg norm h0
    rw [norm_zero, mem_sphere_zero_iff_norm.mp u.2] at this
    exact one_ne_zero this
  have conj : ∀ (x q : ℍr), g * x * g⁻¹ = q → (u : ℍr) * x * (u : ℍr)⁻¹ = q := by
    intro x q hq
    have h1 : g * x = q * g := by
      rw [← hq, mul_assoc, inv_mul_cancel₀ hg0, mul_one]
    have h2 : (u : ℍr) * x = q * (u : ℍr) := by
      show g * ((‖g‖⁻¹ : ℝ) : ℍr) * x = q * (g * ((‖g‖⁻¹ : ℝ) : ℍr))
      rw [mul_assoc, Quaternion.coe_commutes, ← mul_assoc, h1, mul_assoc]
    rw [h2, mul_assoc, mul_inv_cancel₀ hu0, mul_one]
  refine ⟨fun _ => u, fun a => ?_⟩
  rw [hs a]
  simp only [Prod.fst_zero, Prod.snd_zero, if_true]
  constructor
  · apply Subtype.ext
    rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, coe_qI]
    exact conj _ _ hgA
  · apply Subtype.ext
    rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, coe_qJ]
    exact conj _ _ hgB

/-- **太い渦の床（N = 1）**：仮定の欄なし -/
theorem thick_vortex_floor_one : ThickVortexFloorAbs 1 :=
  thick_vortex_floor_abs_of_rigidT 1 rigidT_one

end TwistBlocks

#print axioms TwistBlocks.rigidT_one
#print axioms TwistBlocks.thick_vortex_floor_one
#print axioms TwistBlocks.rigidL_of_rigidT
#print axioms TwistBlocks.thick_vortex_floor_abs_of_rigidT
