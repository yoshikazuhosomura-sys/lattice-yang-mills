import Blocks.StageFourAV1

/-!
# 段 4 (a) の数え：枠に触れる升は ≤ 6N² · 12m（`m·k ≤ M < (k+1)m`）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem fr_imp (ℓ : Link N M) (h : fr N M m k ℓ) : onLine M m k ℓ.1.2.1 ∨ onLine M m k ℓ.1.2.2 := by
  unfold fr at h; split_ifs at h <;> tauto

theorem ev_fst (μ : Fin 4) : (ev N M μ).2.1 = 0 ∨ (ev N M μ).2.1 = 1 := by
  fin_cases μ <;> simp [ev]

theorem ev_snd (μ : Fin 4) : (ev N M μ).2.2 = 0 ∨ (ev N M μ).2.2 = 1 := by
  fin_cases μ <;> simp [ev]

theorem shift_cases (x : Site N M) (μ : Fin 4) :
    ((x + ev N M μ).2.1 = x.2.1 ∨ (x + ev N M μ).2.1 = x.2.1 + 1) ∧
    ((x + ev N M μ).2.2 = x.2.2 ∨ (x + ev N M μ).2.2 = x.2.2 + 1) := by
  simp only [Prod.snd_add, Prod.fst_add]
  constructor
  · rcases ev_fst N M μ with h | h <;> rw [h] <;> simp
  · rcases ev_snd N M μ with h | h <;> rw [h] <;> simp

/-- 枠に触れる升の根もとの二次元の点は、座標 y か y+1 が線の上 -/
theorem touch_near (B : Plaq N M) (h : B ∈ touchB N M m k (blk2 M m k B.1.2)) :
    onLine M m k B.1.2.1 ∨ onLine M m k (B.1.2.1 + 1) ∨ onLine M m k B.1.2.2 ∨
      onLine M m k (B.1.2.2 + 1) := by
  have h' := (Finset.mem_filter.mp h).2.2
  have c2 := shift_cases N M B.1 B.2.1.1
  have c3 := shift_cases N M B.1 B.2.1.2
  rcases h' with h1 | h1 | h1 | h1
  · rcases fr_imp N M m k _ h1 with h | h <;> simp only [l1] at h <;> tauto
  · rcases fr_imp N M m k _ h1 with h | h <;> simp only [l2] at h
    · rcases c2.1 with e | e <;> rw [e] at h <;> tauto
    · rcases c2.2 with e | e <;> rw [e] at h <;> tauto
  · rcases fr_imp N M m k _ h1 with h | h <;> simp only [l3] at h
    · rcases c3.1 with e | e <;> rw [e] at h <;> tauto
    · rcases c3.2 with e | e <;> rw [e] at h <;> tauto
  · rcases fr_imp N M m k _ h1 with h | h <;> simp only [l4] at h <;> tauto

/-- 一つの座標で「線の上か、次が線の上」で塊 c に入る y は高々三つ -/
theorem card_near_le [NeZero m] (c : Fin k) :
    (univ.filter (fun y : ZMod M => q M m k y = c ∧ (onLine M m k y ∨ onLine M m k (y + 1)))).card ≤ 3 := by
  have hm : 0 < m := NeZero.pos m
  have hsub : univ.filter (fun y : ZMod M => q M m k y = c ∧ (onLine M m k y ∨ onLine M m k (y + 1)))
      ⊆ (univ.filter (fun y : ZMod M => y.val = c.val * m)) ∪
        (univ.filter (fun y : ZMod M => y.val + 1 = (c.val + 1) * m)) ∪
        (univ.filter (fun y : ZMod M => y.val + 1 = M)) := by
    intro y hy
    obtain ⟨hq, hon⟩ := (Finset.mem_filter.mp hy).2
    simp only [Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and]
    unfold q at hq
    have hqv : min (y.val / m) (k - 1) = c.val := by rw [← hq]
    rcases hon with ⟨h0, h1⟩ | ⟨h0, h1⟩
    · left; left
      have hd : y.val / m < k := by
        rw [Nat.div_lt_iff_lt_mul hm]; rw [mul_comm]; exact h1
      rw [min_eq_left (by omega)] at hqv
      have := Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero h0)
      rw [hqv] at this; omega
    · rw [val_succ] at h0 h1
      by_cases hlt : y.val + 1 < M
      · rw [Nat.mod_eq_of_lt hlt] at h0 h1
        left; right
        obtain ⟨j, hj⟩ := Nat.dvd_of_mod_eq_zero h0
        have hj1 : 1 ≤ j := by
          rcases Nat.eq_zero_or_pos j with h | h
          · rw [h, mul_zero] at hj; omega
          · exact h
        have hjk : j < k := by
          have : m * j < m * k := by rw [← hj]; exact h1
          exact Nat.lt_of_mul_lt_mul_left this
        have hyv : y.val / m = j - 1 := by
          have e : y.val = m * (j - 1) + (m - 1) := by
            have : m * j = m * (j - 1) + m := by
              rw [← Nat.mul_succ, Nat.succ_eq_add_one, Nat.sub_add_cancel hj1]
            omega
          rw [e, Nat.mul_add_div hm, Nat.div_eq_of_lt (by omega), add_zero]
        rw [hyv, min_eq_left (by omega)] at hqv
        rw [hj, ← hqv, Nat.sub_add_cancel hj1, mul_comm]
      · right; have := ZMod.val_lt y; omega
  refine (Finset.card_le_card hsub).trans ?_
  refine (Finset.card_union_le _ _).trans ?_
  have one : ∀ (p : ℕ → Prop) [DecidablePred p], (∀ a b : ℕ, p a → p b → a = b) →
      (univ.filter (fun y : ZMod M => p y.val)).card ≤ 1 := by
    intro p _ hp
    refine Finset.card_le_one.mpr fun a ha b hb => ?_
    exact ZMod.val_injective M (hp _ _ (Finset.mem_filter.mp ha).2 (Finset.mem_filter.mp hb).2)
  have h1 := one (fun v => v = c.val * m) (fun a b ha hb => ha.trans hb.symm)
  have h2 := one (fun v => v + 1 = (c.val + 1) * m) (fun a b ha hb => by omega)
  have h3 := one (fun v => v + 1 = M) (fun a b ha hb => by omega)
  have := Finset.card_union_le (univ.filter (fun y : ZMod M => y.val = c.val * m))
    (univ.filter (fun y : ZMod M => y.val + 1 = (c.val + 1) * m))
  omega

theorem card_touch_le [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k) :
    (touchB N M m k b).card ≤ N * N * (12 * m) * 6 := by
  set A1 := univ.filter (fun y : ZMod M => q M m k y = b.1 ∧ (onLine M m k y ∨ onLine M m k (y + 1)))
  set A2 := univ.filter (fun y : ZMod M => q M m k y = b.2 ∧ (onLine M m k y ∨ onLine M m k (y + 1)))
  set Y1 := univ.filter (fun y : ZMod M => q M m k y = b.1)
  set Y2 := univ.filter (fun y : ZMod M => q M m k y = b.2)
  have hY1 : Y1.card ≤ 2 * m := by
    rw [← Fintype.card_subtype]; exact card_fiber1_le M m k hk b.1
  have hY2 : Y2.card ≤ 2 * m := by
    rw [← Fintype.card_subtype]; exact card_fiber1_le M m k hk b.2
  have hA1 := card_near_le M m k b.1
  have hA2 := card_near_le M m k b.2
  set T := (A1 ×ˢ Y2) ∪ (Y1 ×ˢ A2)
  have hT : T.card ≤ 12 * m := by
    refine (Finset.card_union_le _ _).trans ?_
    rw [Finset.card_product, Finset.card_product]
    nlinarith [Nat.mul_le_mul hA1 hY2, Nat.mul_le_mul hY1 hA2]
  have hsub : touchB N M m k b ⊆ ((univ : Finset (ZMod N × ZMod N)) ×ˢ T) ×ˢ (univ : Finset Plane) := by
    intro B hB
    have hb : blk2 M m k B.1.2 = b := (Finset.mem_filter.mp hB).2.1
    have hnear := touch_near N M m k B (by rw [hb]; exact hB)
    have hq1 : q M m k B.1.2.1 = b.1 := congrArg Prod.fst hb
    have hq2 : q M m k B.1.2.2 = b.2 := congrArg Prod.snd hb
    simp only [Finset.mem_product, Finset.mem_univ, true_and, and_true, T, Finset.mem_union,
      A1, A2, Y1, Y2, Finset.mem_filter]
    rcases hnear with h | h | h | h
    · left; exact ⟨⟨hq1, Or.inl h⟩, hq2⟩
    · left; exact ⟨⟨hq1, Or.inr h⟩, hq2⟩
    · right; exact ⟨hq1, hq2, Or.inl h⟩
    · right; exact ⟨hq1, hq2, Or.inr h⟩
  refine (Finset.card_le_card hsub).trans ?_
  rw [Finset.card_product, Finset.card_product, Finset.card_univ, Finset.card_univ,
    Fintype.card_prod, ZMod.card]
  have h6 : Fintype.card Plane = 6 := by decide
  rw [h6]
  exact Nat.mul_le_mul (Nat.mul_le_mul le_rfl hT) le_rfl

/-- **段 4 (a)**：全ての枠 F で `S^F_min(+) ≤ 144 N² m`（`m·k ≤ M < (k+1)m`、M に一様） -/
theorem SminC_plus_uniform [NeZero m] (hk : M < (k + 1) * m) (b : Fin k × Fin k)
    (F : Frame N M m k → SU2) :
    SminC N M m k true b F 1 ≤ 144 * (N : ℝ) ^ 2 * (m : ℝ) := by
  refine (SminC_plus_le N M m k b F).trans ?_
  have := card_touch_le N M m k hk b
  have h : ((touchB N M m k b).card : ℝ) ≤ ((N * N * (12 * m) * 6 : ℕ) : ℝ) := by exact_mod_cast this
  push_cast at h
  nlinarith

end TwistBlocks

#print axioms TwistBlocks.SminC_plus_uniform
