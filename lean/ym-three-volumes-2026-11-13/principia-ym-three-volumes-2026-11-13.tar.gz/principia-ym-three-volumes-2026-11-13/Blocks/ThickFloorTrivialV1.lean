import Blocks.ThickFloorChainV1

/-!
# `LocalVortex` の欄が空でないこと：自明な費用 `S = 2N²` では閉（升を一枚反転するだけ）

紙：「Z₂ では κ = 2N²」の上側（どの群でも、升を一枚反転すれば差は ≤ 2N²）。
`LocalVortex N m₀ (2N²)` は内部を替えずに η を角で一枚反転するだけで立つ。
これは仮定の型が空でないことの確かめで、太い渦の床の中身（`S = S_渦(N, m₀)`）ではない。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- 二つの符号の場が一点 `P0` を除いて一致すれば、塊の作用の差は `2N²` 以下 -/
theorem flip_cost (n12 : Bool) (b : Fin k × Fin k) (e e' : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (he' : ∀ y, |e' y| ≤ 1) (P0 : Pt M) (hee : ∀ y, y ≠ P0 → e' y = e y) (ω : Link N M → SU2) :
    actB N M m k n12 b e' ω ≤ actB N M m k n12 b e ω + 2 * (N : ℝ) ^ 2 := by
  unfold actB
  have hterm : ∀ B : Plaq N M,
      1 - zt N M n12 false B * etaB N M e' B * (hol N M ω B).re
        ≤ (1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re)
          + (if B.2 = p23 ∧ B.1.2 = P0 then 2 else 0) := by
    intro B
    have a1 := actB_term_bounds N M n12 e he ω B
    have a2 := actB_term_bounds N M n12 e' he' ω B
    by_cases hB : B.2 = p23 ∧ B.1.2 = P0
    · rw [if_pos hB]; linarith [a1.1, a2.2]
    · rw [if_neg hB, add_zero]
      have : etaB N M e' B = etaB N M e B := by
        unfold etaB
        split_ifs with h23
        · exact hee _ (fun h => hB ⟨h23, h⟩)
        · rfl
      rw [this]
  refine (Finset.sum_le_sum fun B _ => hterm B).trans ?_
  rw [Finset.sum_add_distrib]
  have hsub : ∑ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
      (if B.2 = p23 ∧ B.1.2 = P0 then (2 : ℝ) else 0)
      ≤ ∑ B : Plaq N M, (if B.2 = p23 ∧ B.1.2 = P0 then (2 : ℝ) else 0) :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      (fun B _ _ => by split_ifs <;> norm_num)
  have hcard : ∑ B : Plaq N M, (if B.2 = p23 ∧ B.1.2 = P0 then (2 : ℝ) else 0) = 2 * (N : ℝ) ^ 2 := by
    rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
    have : (univ.filter (fun B : Plaq N M => B.2 = p23 ∧ B.1.2 = P0))
        = (univ : Finset (ZMod N × ZMod N)).map
            ⟨fun x => ((x, P0), p23), fun x y h => by simpa using h⟩ := by
      ext B
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_map,
        Function.Embedding.coeFn_mk]
      constructor
      · rintro ⟨h1, h2⟩
        exact ⟨B.1.1, by rw [← h1, ← h2]; rfl⟩
      · rintro ⟨x, rfl⟩
        exact ⟨rfl, rfl⟩
    rw [this, Finset.card_map, Finset.card_univ, Fintype.card_prod, ZMod.card]
    push_cast; ring
  linarith

/-- **`LocalVortex` の欄は自明な費用 `2N²` で満たせる**（窓の条件を使わない） -/
theorem localVortex_trivial (N : ℕ) [NeZero N] (m₀ : ℕ) : LocalVortex N m₀ (2 * (N : ℝ) ^ 2) := by
  intro ε hε
  refine ⟨1, one_pos, fun M m k _ _ _ hM _ b F y t i j _ _ _ => ?_⟩
  let P0 : Fib M m k b := ⟨corner M m k b, blk2_corner M m k hM b⟩
  cases t with
  | false =>
    let σ0 : Fib M m k b → ℤˣ := Pi.mulSingle P0 (-1)
    have h : ∀ P : Fib M m k b, sgn (σ0 P) = if P = P0 then -1 else 1 := by
      intro P; simp only [σ0]; rw [Pi.mulSingle_apply]; split_ifs <;> simp [sgn]
    refine ⟨y, σ0, ?_, ?_⟩
    · simp only [h, Finset.prod_ite_eq', Finset.mem_univ, if_true]; simp
    · have hc := flip_cost N M m k true b (etaSign M m k b false) (ext M m k b σ0)
        (abs_etaSign_le M m k b false) (abs_ext_le M m k b σ0) (corner M m k b) ?_
        (glueB N M m k b F y)
      · linarith
      · intro P hP
        unfold ext etaSign
        simp only [Bool.false_eq_true, if_false]
        split_ifs with hb
        · rw [h, if_neg]
          intro hh; exact hP (congrArg Subtype.val hh)
        · rfl
  | true =>
    let σ1 : Fib M m k b → ℤˣ := fun _ => 1
    refine ⟨y, σ1, by simp [σ1, sgn], ?_⟩
    have hc := flip_cost N M m k true b (etaSign M m k b true) (ext M m k b σ1)
      (abs_etaSign_le M m k b true) (abs_ext_le M m k b σ1) (corner M m k b) ?_
      (glueB N M m k b F y)
    · linarith
    · intro P hP
      unfold ext etaSign etaAt
      simp only [if_true, if_neg hP]
      split_ifs <;> simp [σ1, sgn]

end TwistBlocks

#print axioms TwistBlocks.flip_cost
#print axioms TwistBlocks.localVortex_trivial
