import Wilson.SU2TwistV2

/-!
# 段 3（粗い Laplace の下界）の、定数を陽にしない一様な形

紙： 補題 3.1。ここで閉じるのは「弱い一様な形」：
SU(2)^ι（Haar の確率測度の直積、sup の距離）の上の L-Lipschitz な連続関数 f と、全ての x₀・β ≥ 0・δ > 0 で
  `e^{−β(f(x₀) + δ)} · μ₁(δ/L)^{|ι|} ≤ ∫ e^{−βf}`、`μ₁(r) := Haar(単位元のまわりの半径 r の球) > 0`。
前因子 `μ₁(δ/L)^{|ι|}` は x₀ にも f にも依らない（L だけ）。球の測度が中心に依らないのは左の積が等長で
Haar 測度が左不変だから。紙の強い形（`μ₁(r) ≥ c r³`）は使わない：β → ∞ の指数の率には、δ を止めて
β → ∞、その後 δ → 0 とすれば、この弱い形で足りる（前因子は β に依らない定数になる）。
-/

open MeasureTheory TwistedWilson

namespace CoarseLaplace

local notation "ℍr" => Quaternion ℝ

/-- 単位四元数の左の積は等長 -/
theorem dist_mul_left (g h h' : SU2) : dist (g * h) (g * h') = dist h h' := by
  rw [Subtype.dist_eq, Subtype.dist_eq, dist_eq_norm, dist_eq_norm, Metric.unitSphere.coe_mul,
    Metric.unitSphere.coe_mul, ← mul_sub, norm_mul, norm_eq_of_mem_sphere, one_mul]

theorem ball_eq_preimage (g : SU2) (r : ℝ) :
    Metric.ball g r = (fun h => g⁻¹ * h) ⁻¹' Metric.ball 1 r := by
  ext h
  simp only [Set.mem_preimage, Metric.mem_ball]
  rw [← dist_mul_left g⁻¹ h g, inv_mul_cancel]

/-- Haar の球の測度は中心に依らない -/
theorem haar_ball_eq (g : SU2) (r : ℝ) : haarSU2 (Metric.ball g r) = haarSU2 (Metric.ball 1 r) := by
  rw [ball_eq_preimage]; exact measure_preimage_mul haarSU2 g⁻¹ (Metric.ball 1 r)

instance : (haarSU2).IsOpenPosMeasure := by
  unfold haarSU2 haarProb; infer_instance

theorem haar_ball_pos {r : ℝ} (hr : 0 < r) : 0 < haarSU2 (Metric.ball 1 r) :=
  Metric.isOpen_ball.measure_pos haarSU2 ⟨1, Metric.mem_ball_self hr⟩

/-- 直積の球の測度：中心に依らず `μ₁(r)^{|ι|}` -/
theorem pi_ball_eq {ι : Type*} [Fintype ι] (ω : ι → SU2) {r : ℝ} (hr : 0 < r) :
    Measure.pi (fun _ : ι => haarSU2) (Metric.ball ω r) = haarSU2 (Metric.ball 1 r) ^ Fintype.card ι := by
  rw [Measure.pi_ball _ _ hr]
  simp only [haar_ball_eq]
  rw [Finset.prod_const, Finset.card_univ]

/-- **粗い Laplace の下界（弱い一様な形、紙の補題 3.1 の下側）**。 -/
theorem laplace_lower {ι : Type*} [Fintype ι] (f : (ι → SU2) → ℝ) (hf : Continuous f)
    {L : ℝ} (hL : 0 < L) (hLip : ∀ x y, |f x - f y| ≤ L * dist x y)
    {β δ : ℝ} (hβ : 0 ≤ β) (hδ : 0 < δ) (x0 : ι → SU2) :
    Real.exp (-β * (f x0 + δ)) * (haarSU2 (Metric.ball 1 (δ / L))).toReal ^ Fintype.card ι
      ≤ ∫ x, Real.exp (-β * f x) ∂(Measure.pi fun _ : ι => haarSU2) := by
  have hr : 0 < δ / L := div_pos hδ hL
  have hcont : Continuous fun x => Real.exp (-β * f x) :=
    Real.continuous_exp.comp (continuous_const.mul hf)
  obtain ⟨C, hC⟩ := (isCompact_univ (X := ι → SU2)).exists_bound_of_continuousOn hcont.continuousOn
  have hint : Integrable (fun x => Real.exp (-β * f x)) (Measure.pi fun _ : ι => haarSU2) :=
    Integrable.of_bound hcont.aestronglyMeasurable C
      (Filter.Eventually.of_forall fun x => hC x (Set.mem_univ _))
  have hball : ∀ x ∈ Metric.ball x0 (δ / L), Real.exp (-β * (f x0 + δ)) ≤ Real.exp (-β * f x) := by
    intro x hx
    rw [Metric.mem_ball] at hx
    have h1 : f x - f x0 ≤ L * dist x x0 := (le_abs_self _).trans (hLip x x0)
    have h2 : L * dist x x0 < δ := by rwa [lt_div_iff₀ hL, mul_comm] at hx
    exact Real.exp_le_exp.mpr (by nlinarith)
  have hset := setIntegral_ge_of_const_le_real (μ := Measure.pi fun _ : ι => haarSU2)
    Metric.isOpen_ball.measurableSet (measure_ne_top _ _) hball hint.integrableOn
  have hle := setIntegral_le_integral (s := Metric.ball x0 (δ / L)) hint
    (Filter.Eventually.of_forall fun x => (Real.exp_pos _).le)
  rw [Measure.real, pi_ball_eq x0 hr, ENNReal.toReal_pow] at hset
  linarith

/-- 正：`μ₁(r) > 0`（実数として） -/
theorem haar_ball_toReal_pos {r : ℝ} (hr : 0 < r) : 0 < (haarSU2 (Metric.ball 1 r)).toReal :=
  ENNReal.toReal_pos (haar_ball_pos hr).ne' (measure_ne_top _ _)

end CoarseLaplace

#print axioms CoarseLaplace.laplace_lower
#print axioms CoarseLaplace.haar_ball_toReal_pos
