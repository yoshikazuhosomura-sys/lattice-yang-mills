import Blocks.ThickFloorThetaPosV1

/-!
# 太い渦の床の、絶対値なしの形（M が偶数のとき）

`theta_nonneg`（M が偶数で θ ≥ 0）と `thick_vortex_floor_unfolded`（|θ| の床）から、
十分大きい β と（β ごとに）十分大きい M のうち M + 1 が偶数のもので 0 ≤ θ_{M+1} ≤ exp(−(M+1)² e^{−β(S_N+ε)})。
-/

open TwistedWilson

namespace TwistBlocks

theorem thick_vortex_floor_signed (N : ℕ) [NeZero N] :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop, (M + 1) % 2 = 0 →
      0 ≤ thetaM N (M + 1) β ∧
        thetaM N (M + 1) β ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (SN N + ε))) := by
  intro ε hε
  filter_upwards [thick_vortex_floor_unfolded N ε hε] with β hβ
  filter_upwards [hβ] with M hM hev
  have h0 := theta_nonneg N (M + 1) hev β
  exact ⟨h0, (le_abs_self _).trans hM⟩

end TwistBlocks

#print axioms TwistBlocks.thick_vortex_floor_signed
