import Blocks.ThickFloorHalfPairV1

/-!
# 面の上の有界な関数を挟んだ Cauchy–Schwarz（M が偶数）

面の上のリンク（`fixL`）だけに依る可測な ψ で |ψ| ≤ 1 のもの、閉じた上の半分だけに依る有界可測な F・G について
`(∫ F(Θω) ψ(ω) G(ω))² ≤ (∫ F(Θω) F(ω)) (∫ G(Θω) G(ω))`（`pair_fix_cauchy_schwarz`）。
証明：`pair_cauchy_schwarz` と、⟪ψG, ψG⟫ ≤ ⟪G, G⟫（差が ⟪√(1−ψ²) G, √(1−ψ²) G⟫ ≥ 0、ψ は鏡映で変わらない）。
-/

open Finset MeasureTheory TwistedWilson TwistedPlane

namespace HalfSplit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem pair_fix_cauchy_schwarz (hM : M % 2 = 0) (F G ψ : (Link N M → SU2) → ℝ)
    (hF : Measurable F) (hG : Measurable G) (hψ : Measurable ψ) (CF CG : ℝ)
    (hFC : ∀ ω, |F ω| ≤ CF) (hGC : ∀ ω, |G ω| ≤ CG) (hψ1 : ∀ ω, |ψ ω| ≤ 1)
    (hdF : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → F ω = F ω')
    (hdG : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → G ω = G ω')
    (hdψ : ∀ ω ω', (∀ ℓ, fixL N M ℓ → ω ℓ = ω' ℓ) → ψ ω = ψ ω') :
    (∫ ω, F (Th N M ω) * (ψ ω * G ω) ∂(haarCfg N M)) ^ 2
      ≤ (∫ ω, F (Th N M ω) * F ω ∂(haarCfg N M)) * ∫ ω, G (Th N M ω) * G ω ∂(haarCfg N M) := by
  have hCG : 0 ≤ CG := (abs_nonneg _).trans (hGC (fun _ => 1))
  have hdψ' : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → ψ ω = ψ ω' :=
    fun ω ω' h => hdψ ω ω' fun ℓ hℓ => h ℓ (Or.inl hℓ)
  have hψG : Measurable fun ω => ψ ω * G ω := hψ.mul hG
  have hψGC : ∀ ω, |ψ ω * G ω| ≤ CG := fun ω => by
    rw [abs_mul]; exact (mul_le_of_le_one_left (abs_nonneg _) (hψ1 ω)).trans (hGC ω)
  have hcs := pair_cauchy_schwarz N M hM F (fun ω => ψ ω * G ω) hF hψG CF CG hFC hψGC hdF
    (fun ω ω' h => by rw [hdψ' ω ω' h, hdG ω ω' h])
  -- ⟪ψG, ψG⟫ ≤ ⟪G, G⟫
  set s : (Link N M → SU2) → ℝ := fun ω => Real.sqrt (1 - ψ ω ^ 2)
  have hs_sq : ∀ ω, s ω * s ω = 1 - ψ ω ^ 2 := fun ω =>
    Real.mul_self_sqrt (by nlinarith [abs_le.mp (hψ1 ω), sq_abs (ψ ω)])
  have hs1 : ∀ ω, |s ω| ≤ 1 := fun ω => by
    rw [abs_of_nonneg (Real.sqrt_nonneg _)]
    exact Real.sqrt_le_one.mpr (by nlinarith [sq_nonneg (ψ ω)])
  have hsG : Measurable fun ω => s ω * G ω :=
    ((hψ.pow_const 2).const_sub 1).sqrt.mul hG
  have hsGC : ∀ ω, |s ω * G ω| ≤ CG := fun ω => by
    rw [abs_mul]; exact (mul_le_of_le_one_left (abs_nonneg _) (hs1 ω)).trans (hGC ω)
  have hpos := half_pairing_nonneg N M hM (fun ω => s ω * G ω) hsG CG hsGC
    (fun ω ω' h => by simp only [s]; rw [hdψ' ω ω' h, hdG ω ω' h])
  have hsΘ : ∀ ω, s (Th N M ω) = s ω := fun ω => by
    simp only [s]; rw [fixFun_refl N M ψ hdψ ω]
  have hψΘ : ∀ ω, ψ (Th N M ω) = ψ ω := fixFun_refl N M ψ hdψ
  have iGG := integrable_pair N M G G hG hG CG CG hGC hGC
  have iψψ := integrable_pair N M (fun ω => ψ ω * G ω) (fun ω => ψ ω * G ω) hψG hψG CG CG hψGC hψGC
  have e : ∀ ω, s (Th N M ω) * G (Th N M ω) * (s ω * G ω)
      = G (Th N M ω) * G ω - ψ (Th N M ω) * G (Th N M ω) * (ψ ω * G ω) := fun ω => by
    rw [hsΘ, hψΘ]
    have := hs_sq ω
    linear_combination G (Th N M ω) * G ω * this
  rw [integral_congr_ae (Filter.Eventually.of_forall e), integral_sub iGG iψψ] at hpos
  have hFF := half_pairing_nonneg N M hM F hF CF hFC hdF
  calc (∫ ω, F (Th N M ω) * (ψ ω * G ω) ∂(haarCfg N M)) ^ 2
      ≤ (∫ ω, F (Th N M ω) * F ω ∂(haarCfg N M))
          * ∫ ω, ψ (Th N M ω) * G (Th N M ω) * (ψ ω * G ω) ∂(haarCfg N M) := hcs
    _ ≤ (∫ ω, F (Th N M ω) * F ω ∂(haarCfg N M)) * ∫ ω, G (Th N M ω) * G ω ∂(haarCfg N M) :=
        mul_le_mul_of_nonneg_left (by linarith) hFF

end HalfSplit

#print axioms HalfSplit.pair_fix_cauchy_schwarz
