import Blocks.ThickFloorAbsV1
import Blocks.ThickFloorTrivialV1
import Blocks.ThickFloorQuatV1

/-!
# 機械の健全さの確かめ（点検の 3）と、剛性 (c2) の入口（窓の作用 0 ⇒ 窓の升は平坦）

* `H4_of_local_S`：一つの m₀ と一つの費用 S で `LocalVortex N m₀ S` なら (H4)（κ_c ≤ S + ε）。
* `thick_floor_abs_trivial`：自明な費用 2N²（`localVortex_trivial`、閉）を入れると、仮定の欄なしで
  `|θ_M| ≤ exp(−M² e^{−β(2N²+ε)})`（十分大きい β・M）。同じ鎖（Canon・鳩の巣・段 2・段 3）を通って
  薄い渦の床の指数 2N² に戻る（率として。前因子は粗い）。
* `flat_of_actW_zero`：窓の作用が 0 なら、窓の全ての升で `U_B = z_B η_B`（四元数として）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

theorem H4_of_local_S (N : ℕ) [NeZero N] (hC : Canon N) (m₀ : ℕ) (S : ℝ)
    (hL : LocalVortex N m₀ S) :
    ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ S + ε := by
  intro ε hε
  obtain ⟨δ, hδ, hloc⟩ := hL (ε / 4) (by positivity)
  set c : ℕ := m₀ + 2
  set A : ℝ := 144 * (N : ℝ) ^ 2
  obtain ⟨T, hT⟩ := exists_nat_gt ((A * ((c : ℝ) + 1) + ε / 4) / δ)
  have hA0 : 0 ≤ A := by positivity
  have hTpos' : (0 : ℝ) < (T : ℝ) := lt_of_le_of_lt (by positivity) hT
  have hTpos : 0 < T := by exact_mod_cast hTpos'
  set m : ℕ := c * T + 1
  haveI hm0 : NeZero m := ⟨by omega⟩
  refine ⟨m, hm0, fun M _ _ hMm => ?_⟩
  set k := M / m
  have hMk : m * k ≤ M := Nat.mul_div_le M m
  have hkM : M < (k + 1) * m := by
    have := Nat.lt_div_mul_add (a := M) (NeZero.pos m)
    rw [Nat.add_mul, one_mul]; exact this
  have hmT : T * (m₀ + 2) < m := by simp only [m, c]; rw [mul_comm]; omega
  have hTδ : A * (m : ℝ) + ε / 4 < δ * (T : ℝ) ^ 2 := by
    have h1 : (m : ℝ) ≤ ((c : ℝ) + 1) * (T : ℝ) := by
      have : (m : ℝ) = (c : ℝ) * (T : ℝ) + 1 := by simp only [m]; push_cast; ring
      have hT1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hTpos
      rw [this]; nlinarith
    have h2 : ε / 4 ≤ ε / 4 * (T : ℝ) := by
      have hT1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hTpos
      nlinarith
    have h3 : A * ((c : ℝ) + 1) + ε / 4 < δ * (T : ℝ) := by
      have := (div_lt_iff₀ hδ).mp hT; linarith
    have h4 : A * (m : ℝ) ≤ A * (((c : ℝ) + 1) * (T : ℝ)) := mul_le_mul_of_nonneg_left h1 hA0
    nlinarith
  have key := fun (t : Bool) (s : ℝ) (hs : s = 1 ∨ s = -1)
      (hs1 : ∀ x : ℝ, s * x = 1 → x = (if t then -1 else 1))
      (hs2 : ∀ x : ℝ, x = (if t then 1 else -1) → -s * x = 1) (p : (Fin k × Fin k) × (Frame N M m k → SU2)) =>
    step_flip N M m k hC m₀ S hL (ε := ε / 4) (δ := δ) (by positivity)
      (fun M' m' k' _ _ _ h1 h2 b F y t i j hi hj hw => hloc M' m' k' h1 h2 b F y t i j hi hj hw)
      T hTpos hmT hTδ hMk hkM p.1 p.2 t s hs hs1 hs2
  unfold kappaC
  refine ciSup_le fun p => ?_
  have k1 := key false 1 (Or.inl rfl) (fun x h => by simpa using h) (fun x h => by simp at h; rw [h]; norm_num) p
  have k2 := key true (-1) (Or.inr rfl) (fun x h => by simp at h ⊢; linarith) (fun x h => by simp at h; rw [h]; norm_num) p
  rw [neg_neg] at k2
  rw [abs_le]; constructor <;> linarith

/-- **機械の健全さ**（仮定の欄なし）：同じ鎖に自明な費用 2N² を入れると、率 2N²（薄い渦の床の指数）が出る -/
theorem thick_floor_abs_trivial (N : ℕ) [NeZero N] :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
      |thetaM N (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (2 * (N : ℝ) ^ 2 + ε))) :=
  thick_vortex_floor_abs_of_H4 N _ (H4_of_local_S N (canon_holds N) 0 _ (localVortex_trivial N 0))

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-- **(c2) の入口**：窓の作用が 0 なら窓の全ての升で `U_B = z_B η_B`（η = ±1 の場） -/
theorem flat_of_actW_zero (n12 : Bool) (m₀ : ℕ) (b : Fin k × Fin k) (w : ℕ × ℕ) (e : Pt M → ℝ)
    (he : ∀ y, e y = 1 ∨ e y = -1) (ω : Link N M → SU2)
    (h0 : actW N M m k n12 m₀ b w e ω = 0) :
    ∀ B ∈ winP N M m k m₀ b w,
      hol N M ω B = ((zt N M n12 false B * etaB N M e B : ℝ) : Quaternion ℝ) := by
  have he' : ∀ y, |e y| ≤ 1 := fun y => by rcases he y with h | h <;> rw [h] <;> norm_num
  have hnn : ∀ B ∈ winP N M m k m₀ b w,
      0 ≤ 1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re :=
    fun B _ => (actB_term_bounds N M n12 e he' ω B).1
  have hz := (Finset.sum_eq_zero_iff_of_nonneg hnn).mp h0
  intro B hB
  have h1 := hz B hB
  have hzt : zt N M n12 false B = 1 ∨ zt N M n12 false B = -1 := by
    have := abs_zt N M n12 false B
    rcases abs_eq (zero_le_one) |>.mp this with h | h <;> [left; right] <;> exact h
  have het : etaB N M e B = 1 ∨ etaB N M e B = -1 := by
    unfold etaB; split_ifs
    · exact he _
    · left; rfl
  have hzpm : zt N M n12 false B * etaB N M e B = 1 ∨ zt N M n12 false B * etaB N M e B = -1 := by
    rcases hzt with h | h <;> rcases het with h' | h' <;> rw [h, h'] <;> norm_num
  have hn : Quaternion.normSq (hol N M ω B) = 1 := by
    rw [Quaternion.normSq_eq_norm_mul_self, norm_hol]; norm_num
  exact ThickFloor.eq_of_re_eq_one _ hn _ hzpm (by linarith)

end TwistBlocks

#print axioms TwistBlocks.thick_floor_abs_trivial
#print axioms TwistBlocks.flat_of_actW_zero
