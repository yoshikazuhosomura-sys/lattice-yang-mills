import Blocks.ThickFloorChainV1

/-!
# 補題 2.3 の強い形（`Canon`）：塊の内部の切り口の反転で、符号の場を標準の場に移す

紙： 補題 2.3（R_λ は升ごとの作用を保ち、η を λ の両側の二枚で反転する。
塊の升の双対グラフは連結）。ここでは連結性の代わりに、櫛の形の木で反転の場 κ を陽に書く：
* 向き 3 の二次元のリンク（点 s、`s.2` が線の上でない）：κ₃(s) = Π_{同じ列、`s'.2.val ≥ s.2.val`} ρ(s')
* 向き 4 の二次元のリンク（点 s、`s.2` が線の上、`s.1` が線の上でない）：κ₄(s) = Π_{塊の中、`s'.1.val ≥ s.1.val`} ρ(s')
* ρ = σ · (標準の場)、塊の中の ρ の積は 1。
すると (3,4) の升ごとに δκ = ρ（`delta_kap`）、他の升では κ が二回ずつ現れて消える。
枠のリンクでは κ = 1（線の上の点の向き 3、線の上の点の向き 4 は κ の定義で 1）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

/-! ## 一つの座標の補題 -/

theorem q_val (y : ZMod M) : (q M m k y).val = min (y.val / m) (k - 1) := rfl

theorem q_lb (y : ZMod M) : (q M m k y).val * m ≤ y.val := by
  rw [q_val]
  exact (Nat.mul_le_mul_right m (min_le_left _ _)).trans (Nat.div_mul_le_self _ _)

theorem onLine_q (y : ZMod M) (h : onLine M m k y) : y.val = (q M m k y).val * m := by
  obtain ⟨h1, h2⟩ := h
  have hd : y.val / m < k := Nat.div_lt_of_lt_mul h2
  have hq : (q M m k y).val = y.val / m := by rw [q_val]; omega
  rw [hq]; exact (Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero h1)).symm

theorem succ_val [NeZero m] (y : ZMod M) (h : ¬ onLine M m k (y + 1)) : (y + 1).val = y.val + 1 := by
  rw [val_succ]
  by_cases hlt : y.val + 1 < M
  · exact Nat.mod_eq_of_lt hlt
  · exfalso
    have he : y.val + 1 = M := by have := ZMod.val_lt y; omega
    apply h
    unfold onLine
    rw [val_succ, he, Nat.mod_self]
    exact ⟨Nat.zero_mod m, Nat.mul_pos (NeZero.pos m) (NeZero.pos k)⟩

theorem q_mono (a c : ZMod M) (h : a.val ≤ c.val) : (q M m k a).val ≤ (q M m k c).val := by
  rw [q_val, q_val]; exact min_le_min_right _ (Nat.div_le_div_right h)

theorem last_of_onLine [NeZero m] (y y' : ZMod M) (h : onLine M m k (y + 1))
    (hq : q M m k y' = q M m k y) : y'.val ≤ y.val := by
  by_contra hc
  push_neg at hc
  have hv : (y + 1).val = y.val + 1 := by
    rw [val_succ]; exact Nat.mod_eq_of_lt (by have := ZMod.val_lt y'; omega)
  have e1 := q_mono M m k y (y + 1) (by omega)
  have e2 := q_mono M m k (y + 1) y' (by omega)
  rw [hq] at e2
  have he : (q M m k (y + 1)).val = (q M m k y).val := le_antisymm e2 e1
  have h1 := onLine_q M m k (y + 1) h
  have h2 := q_lb M m k y
  rw [he, hv] at h1
  omega

theorem first_of_onLine (y y' : ZMod M) (h : onLine M m k y) (hq : q M m k y' = q M m k y) :
    y.val ≤ y'.val := by
  have h1 := onLine_q M m k y h
  have h2 := q_lb M m k y'
  rw [hq] at h2
  omega

/-! ## 列・行の積 -/

variable (b : Fin k × Fin k)

noncomputable def col (r : Pt M → ℤˣ) (s : Pt M) : ℤˣ :=
  ∏ s' ∈ univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2 ∧ s.2.val ≤ s'.2.val), r s'

noncomputable def colAll (r : Pt M → ℤˣ) (a : ZMod M) : ℤˣ :=
  ∏ s' ∈ univ.filter (fun s' : Pt M => s'.1 = a ∧ q M m k s'.2 = b.2), r s'

noncomputable def rowR (r : Pt M → ℤˣ) (s : Pt M) : ℤˣ :=
  ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b ∧ s.1.val ≤ s'.1.val), r s'

theorem col_succ [NeZero m] (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.2 = b.2)
    (h : ¬ onLine M m k (s.2 + 1)) : col M m k b r s = r s * col M m k b r (s.1, s.2 + 1) := by
  have hv := succ_val M m k s.2 h
  have hset : univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2 ∧ s.2.val ≤ s'.2.val)
      = insert s (univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2 ∧
          (s.2 + 1).val ≤ s'.2.val)) := by
    ext s'
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, hv]
    constructor
    · rintro ⟨h1, h2, h3⟩
      by_cases he : s'.2.val = s.2.val
      · left; exact Prod.ext h1 (ZMod.val_injective M he)
      · right; exact ⟨h1, h2, by omega⟩
    · rintro (rfl | ⟨h1, h2, h3⟩)
      · exact ⟨rfl, hs, le_rfl⟩
      · exact ⟨h1, h2, by omega⟩
  have hnot : s ∉ univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2 ∧
      (s.2 + 1).val ≤ s'.2.val) := by
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, hv]; omega
  unfold col; rw [hset, Finset.prod_insert hnot]

theorem col_last [NeZero m] (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.2 = b.2)
    (h : onLine M m k (s.2 + 1)) : col M m k b r s = r s := by
  have hset : univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2 ∧ s.2.val ≤ s'.2.val)
      = {s} := by
    ext s'
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton]
    constructor
    · rintro ⟨h1, h2, h3⟩
      have := last_of_onLine M m k s.2 s'.2 h (h2.trans hs.symm)
      exact Prod.ext h1 (ZMod.val_injective M (by omega))
    · rintro rfl; exact ⟨rfl, hs, le_rfl⟩
  unfold col; rw [hset, Finset.prod_singleton]

theorem col_first (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.2 = b.2) (h : onLine M m k s.2) :
    col M m k b r s = colAll M m k b r s.1 := by
  unfold col colAll
  congr 1
  ext s'
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨h1, h2, _⟩; exact ⟨h1, h2⟩
  · rintro ⟨h1, h2⟩; exact ⟨h1, h2, first_of_onLine M m k s.2 s'.2 h (h2.trans hs.symm)⟩

theorem blk2_iff (s : Pt M) : blk2 M m k s = b ↔ q M m k s.1 = b.1 ∧ q M m k s.2 = b.2 := by
  unfold blk2; exact Prod.ext_iff

theorem row_succ [NeZero m] (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.1 = b.1)
    (h : ¬ onLine M m k (s.1 + 1)) :
    rowR M m k b r s = colAll M m k b r s.1 * rowR M m k b r (s.1 + 1, s.2) := by
  have hv := succ_val M m k s.1 h
  have hset : univ.filter (fun s' : Pt M => blk2 M m k s' = b ∧ s.1.val ≤ s'.1.val)
      = univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2)
        ∪ univ.filter (fun s' : Pt M => blk2 M m k s' = b ∧ (s.1 + 1).val ≤ s'.1.val) := by
    ext s'
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_union, blk2_iff, hv]
    constructor
    · rintro ⟨⟨h1, h2⟩, h3⟩
      by_cases he : s'.1.val = s.1.val
      · left; exact ⟨ZMod.val_injective M he, h2⟩
      · right; exact ⟨⟨h1, h2⟩, by omega⟩
    · rintro (⟨he, h2⟩ | ⟨⟨h1, h2⟩, h3⟩)
      · exact ⟨⟨by rw [he]; exact hs, h2⟩, by rw [he]⟩
      · exact ⟨⟨h1, h2⟩, by omega⟩
  have hdis : Disjoint (univ.filter (fun s' : Pt M => s'.1 = s.1 ∧ q M m k s'.2 = b.2))
      (univ.filter (fun s' : Pt M => blk2 M m k s' = b ∧ (s.1 + 1).val ≤ s'.1.val)) := by
    rw [Finset.disjoint_left]
    intro s' h1 h2
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, hv] at h1 h2
    rw [h1.1] at h2; omega
  unfold rowR colAll; rw [hset, Finset.prod_union hdis]

theorem row_last [NeZero m] (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.1 = b.1)
    (h : onLine M m k (s.1 + 1)) : rowR M m k b r s = colAll M m k b r s.1 := by
  unfold rowR colAll
  congr 1
  ext s'
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, blk2_iff]
  constructor
  · rintro ⟨⟨h1, h2⟩, h3⟩
    have := last_of_onLine M m k s.1 s'.1 h (h1.trans hs.symm)
    exact ⟨ZMod.val_injective M (by omega), h2⟩
  · rintro ⟨he, h2⟩; exact ⟨⟨by rw [he]; exact hs, h2⟩, by rw [he]⟩

theorem row_first (r : Pt M → ℤˣ) (s : Pt M) (hs : q M m k s.1 = b.1) (h : onLine M m k s.1) :
    rowR M m k b r s = ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), r s' := by
  unfold rowR
  congr 1
  ext s'
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, blk2_iff]
  constructor
  · rintro ⟨h1, _⟩; exact h1
  · rintro ⟨h1, h2⟩; exact ⟨⟨h1, h2⟩, first_of_onLine M m k s.1 s'.1 h (h1.trans hs.symm)⟩

/-! ## 反転の場 κ と δκ = ρ -/

noncomputable def kap3 (r : Pt M → ℤˣ) (s : Pt M) : ℤˣ :=
  if blk2 M m k s = b ∧ ¬ onLine M m k s.2 then col M m k b r s else 1

noncomputable def kap4 (r : Pt M → ℤˣ) (s : Pt M) : ℤˣ :=
  if blk2 M m k s = b ∧ onLine M m k s.2 ∧ ¬ onLine M m k s.1 then rowR M m k b r s else 1

theorem units_cases3 (a x z : ℤˣ) (P : ℤˣ → ℤˣ → ℤˣ → Prop)
    (h : ∀ a x z : ℤˣ, (a = 1 ∨ a = -1) → (x = 1 ∨ x = -1) → (z = 1 ∨ z = -1) → P a x z) :
    P a x z := h a x z (Int.units_eq_one_or a) (Int.units_eq_one_or x) (Int.units_eq_one_or z)

theorem delta_kap [NeZero m] (r : Pt M → ℤˣ) (s : Pt M) (hs : blk2 M m k s = b)
    (htot : ∏ s' ∈ univ.filter (fun s' : Pt M => blk2 M m k s' = b), r s' = 1) :
    kap3 M m k b r s * kap4 M m k b r (s.1 + 1, s.2) * kap3 M m k b r (s.1, s.2 + 1)
      * kap4 M m k b r s = r s := by
  have hs1 : q M m k s.1 = b.1 := ((blk2_iff M m k b s).mp hs).1
  have hs2 : q M m k s.2 = b.2 := ((blk2_iff M m k b s).mp hs).2
  set X := kap3 M m k b r (s.1, s.2 + 1) with hX
  set Y := kap4 M m k b r (s.1 + 1, s.2) with hY
  -- 列：col s = r s * X
  have hC : col M m k b r s = r s * X := by
    by_cases h : onLine M m k (s.2 + 1)
    · have hX1 : X = 1 := by
        rw [hX]; unfold kap3; rw [if_neg]; rintro ⟨_, h'⟩; exact h' h
      rw [hX1, mul_one]; exact col_last M m k b r s hs2 h
    · have hb : blk2 M m k (s.1, s.2 + 1) = b :=
        (blk2_iff M m k b _).mpr ⟨hs1, (q_succ M m k s.2 h).trans hs2⟩
      have hXc : X = col M m k b r (s.1, s.2 + 1) := by
        rw [hX]; unfold kap3; rw [if_pos ⟨hb, h⟩]
      rw [hXc]; exact col_succ M m k b r s hs2 h
  by_cases h2 : onLine M m k s.2
  · have hk3 : kap3 M m k b r s = 1 := by unfold kap3; rw [if_neg]; rintro ⟨_, h'⟩; exact h' h2
    have hcA : colAll M m k b r s.1 = r s * X := by rw [← col_first M m k b r s hs2 h2]; exact hC
    -- 行：rowR s = colAll s.1 * Y
    have hR : rowR M m k b r s = colAll M m k b r s.1 * Y := by
      by_cases h1' : onLine M m k (s.1 + 1)
      · have hY1 : Y = 1 := by
          rw [hY]; unfold kap4; rw [if_neg]; rintro ⟨_, _, h'⟩; exact h' h1'
        rw [hY1, mul_one]; exact row_last M m k b r s hs1 h1'
      · have hb : blk2 M m k (s.1 + 1, s.2) = b :=
          (blk2_iff M m k b _).mpr ⟨(q_succ M m k s.1 h1').trans hs1, hs2⟩
        have hYc : Y = rowR M m k b r (s.1 + 1, s.2) := by
          rw [hY]; unfold kap4; rw [if_pos ⟨hb, h2, h1'⟩]
        rw [hYc]; exact row_succ M m k b r s hs1 h1'
    rw [hcA] at hR
    by_cases h1 : onLine M m k s.1
    · have hk4 : kap4 M m k b r s = 1 := by
        unfold kap4; rw [if_neg]; rintro ⟨_, _, h'⟩; exact h' h1
      have hR1 : r s * X * Y = 1 := by rw [← hR, row_first M m k b r s hs1 h1, htot]
      rw [hk3, hk4]
      revert hR1
      refine units_cases3 (r s) X Y (fun a x z => a * x * z = 1 → 1 * z * x * 1 = a) ?_
      rintro a x z (rfl | rfl) (rfl | rfl) (rfl | rfl) <;> decide
    · have hk4 : kap4 M m k b r s = rowR M m k b r s := by
        unfold kap4; rw [if_pos ⟨hs, h2, h1⟩]
      rw [hk3, hk4, hR]
      refine units_cases3 (r s) X Y (fun a x z => 1 * z * x * (a * x * z) = a) ?_
      rintro a x z (rfl | rfl) (rfl | rfl) (rfl | rfl) <;> decide
  · have hk3 : kap3 M m k b r s = col M m k b r s := by unfold kap3; rw [if_pos ⟨hs, h2⟩]
    have hk4 : kap4 M m k b r s = 1 := by unfold kap4; rw [if_neg]; rintro ⟨_, h', _⟩; exact h2 h'
    have hY1 : Y = 1 := by rw [hY]; unfold kap4; rw [if_neg]; rintro ⟨_, h', _⟩; exact h2 h'
    rw [hk3, hk4, hY1, hC]
    refine units_cases3 (r s) X 1 (fun a x _ => a * x * 1 * x * 1 = a) ?_
    rintro a x z (rfl | rfl) (rfl | rfl) _ <;> decide

end TwistBlocks

#print axioms TwistBlocks.delta_kap
