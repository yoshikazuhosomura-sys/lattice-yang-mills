import Blocks.ThickFloorReduceV1

/-!
# `ZeroVortexL` の欄が空でないこと：自明な費用 2N² では閉（内部を替えず、η を一枚反転）
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N : ℕ) [NeZero N]

theorem mixL_self (V : ℕ) (ωl : LLink N V → SU2) : mixL N V ωl ωl = ωl := by
  funext ℓ; unfold mixL; split_ifs <;> rfl

theorem term_bounds_L (V : ℕ) (n12 : Bool) (e : ℝ) (he : |e| ≤ 1) (ωl : LLink N V → SU2)
    (B : LPlaq N V) :
    0 ≤ 1 - zL N V n12 B * e * (holL N V ωl B).re ∧ 1 - zL N V n12 B * e * (holL N V ωl B).re ≤ 2 := by
  have hz : |zL N V n12 B| ≤ 1 := by unfold zL tw; split_ifs <;> simp
  have hr : |(holL N V ωl B).re| ≤ 1 := by
    have hn : ‖holL N V ωl B‖ = 1 := by
      unfold holL
      simp only [norm_mul, norm_star]
      have h : ∀ ℓ, ‖(ωl ℓ : Quaternion ℝ)‖ = 1 := fun ℓ => mem_sphere_zero_iff_norm.mp (ωl ℓ).2
      rw [h, h, h, h]; norm_num
    exact (abs_re_le_norm _).trans hn.le
  have hze : |zL N V n12 B * e| ≤ 1 := by
    rw [abs_mul]; nlinarith [abs_nonneg (zL N V n12 B), abs_nonneg e]
  have h2 : |zL N V n12 B * e * (holL N V ωl B).re| ≤ 1 := by
    rw [abs_mul]; nlinarith [abs_nonneg (zL N V n12 B * e), abs_nonneg (holL N V ωl B).re]
  constructor <;> linarith [le_abs_self (zL N V n12 B * e * (holL N V ωl B).re),
    neg_abs_le (zL N V n12 B * e * (holL N V ωl B).re)]

/-- 局所の一枚の反転の費用は `2N²` 以下 -/
theorem SLe_flip_le (V : ℕ) (n12 : Bool) (P0 : Fin V × Fin V) (ωl : LLink N V → SU2) :
    SLe N V n12 (flipAt V P0) ωl ≤ SL N V n12 ωl + 2 * (N : ℝ) ^ 2 := by
  unfold SLe SL
  have hterm : ∀ B : LPlaq N V,
      1 - zL N V n12 B * (if B.2 = p23 then flipAt V P0 B.1.2 else 1) * (holL N V ωl B).re
        ≤ (1 - zL N V n12 B * (holL N V ωl B).re) + (if B.2 = p23 ∧ B.1.2 = P0 then 2 else 0) := by
    intro B
    have hf : |(if B.2 = p23 then flipAt V P0 B.1.2 else 1)| ≤ 1 := by
      unfold flipAt; split_ifs <;> simp
    have a1 := term_bounds_L N V n12 1 (by simp) ωl B
    have a2 := term_bounds_L N V n12 _ hf ωl B
    by_cases hB : B.2 = p23 ∧ B.1.2 = P0
    · rw [if_pos hB]; rw [mul_one] at a1; linarith [a1.1, a2.2]
    · rw [if_neg hB, add_zero]
      have : (if B.2 = p23 then flipAt V P0 B.1.2 else 1) = 1 := by
        unfold flipAt
        split_ifs with h1 h2
        · exact absurd ⟨h1, h2⟩ hB
        · rfl
        · rfl
      rw [this, mul_one]
  refine (Finset.sum_le_sum fun B _ => hterm B).trans ?_
  rw [Finset.sum_add_distrib]
  have hcard : ∑ B : LPlaq N V, (if B.2 = p23 ∧ B.1.2 = P0 then (2 : ℝ) else 0) = 2 * (N : ℝ) ^ 2 := by
    rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
    have : (univ.filter (fun B : LPlaq N V => B.2 = p23 ∧ B.1.2 = P0))
        = (univ : Finset (ZMod N × ZMod N)).map
            ⟨fun x => ((x, P0), p23), fun x y h => by simpa using h⟩ := by
      ext B
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_map,
        Function.Embedding.coeFn_mk]
      constructor
      · rintro ⟨h1, h2⟩
        exact ⟨B.1.1, by rw [← h1, ← h2]; rfl⟩
      · rintro ⟨x, rfl⟩
        exact ⟨rfl, rfl⟩
    rw [this, Finset.card_map, Finset.card_univ, Fintype.card_prod, ZMod.card]
    push_cast; ring
  linarith

/-- **`ZeroVortexL` の欄は自明な費用 2N² で満たせる** -/
theorem zeroVortexL_trivial (m₀ : ℕ) : ZeroVortexL N m₀ (2 * (N : ℝ) ^ 2) := by
  intro ωl h0
  refine ⟨ωl, (0, 0), ?_⟩
  rw [mixL_self]
  have := SLe_flip_le N (m₀ + 2) true (0, 0) ωl
  linarith

end TwistBlocks

#print axioms TwistBlocks.zeroVortexL_trivial
