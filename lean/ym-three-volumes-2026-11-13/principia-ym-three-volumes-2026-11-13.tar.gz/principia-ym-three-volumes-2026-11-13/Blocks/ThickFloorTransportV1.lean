import Blocks.ThickFloorFlatLV1

/-!
# 移植（紙の命題 4.1 (d)）：局所の剛性から零作用の主張 `ZeroVortexL N m₀ (S_渦(N, m₀))` へ

局所の模型の上のゲージ変換 `gaugeL`（升の積は共役で変わり、Re は不変）と局所の真空 `vacL`。
`RigidL N V`（局所の剛性：作用 0 の局所の配位は、升に現れる全てのリンクの上で `vacL` のゲージ変換）を
仮定すると、S_渦(N, m₀) の最小点 W（格子 M′ = 2m₀、塊 (0,0)）を、ずれ c = (−1, −1) の埋め込みで
局所の模型に引き戻し、ゲージで戻して、`ZeroVortexL N m₀ (S_渦(N, m₀))` が出る。
大きさの帳簿：塊 (0,0) の内部のリンクは二次元の座標が [0, m₀−1]、局所のずれは u = x + 1 ∈ [1, m₀]
で局所の内部（`intL`：u ∈ [1, m₀+1]）に入る。局所の升で像が塊 (0,0) に入るのは u ∈ [1, m₀]² だけで、
そこで埋め込みは単射。それ以外の局所の升の像は塊 (0,0) の外で、W′（塊 (0,0) の内部の外は V）は平坦。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N]

/-- 局所の真空（`vac` と同じ式、二次元の座標に依らない） -/
noncomputable def vacL (V : ℕ) : LLink N V → SU2 := fun ℓ =>
  if ℓ.2 = 0 ∧ ℓ.1.1.1 = 0 then qI else if ℓ.2 = 1 ∧ ℓ.1.1.2 = 0 then qJ else 1

theorem vac_embL (M V : ℕ) [NeZero M] (c : Pt M) (ℓ : LLink N V) :
    vac N M (embL N M V c ℓ) = vacL N V ℓ := rfl

/-- リンクの終点の二次元のずれ（`Fin (V+1)` の足し算。升に現れるリンクでは折り返さない） -/
def nxtL (V : ℕ) (μ : Fin 4) (u : Fin (V + 1) × Fin (V + 1)) : Fin (V + 1) × Fin (V + 1) :=
  if μ = 2 then (u.1 + 1, u.2) else if μ = 3 then (u.1, u.2 + 1) else u

/-- リンクの終点 -/
def tgtL (V : ℕ) (ℓ : LLink N V) : LSite N V := (ℓ.1.1 + ev12 N ℓ.2, nxtL V ℓ.2 ℓ.1.2)

/-- 局所の模型の上のゲージ変換 `ω^g(ℓ) = g(始点) ω(ℓ) g(終点)⁻¹` -/
noncomputable def gaugeL (V : ℕ) (g : LSite N V → SU2) (ω : LLink N V → SU2) : LLink N V → SU2 :=
  fun ℓ => g ℓ.1 * ω ℓ * (g (tgtL N V ℓ))⁻¹

theorem tgt_ll1 (V : ℕ) (B : LPlaq N V) : tgtL N V (ll1 N V B) = (ll2 N V B).1 := by
  obtain ⟨⟨a, u⟩, ⟨⟨μ, ν⟩, h⟩⟩ := B
  simp only [tgtL, ll1, ll2, nxtL, shL]
  fin_cases μ <;> simp [Fin.coeSucc_eq_succ]

theorem tgt_ll4 (V : ℕ) (B : LPlaq N V) : tgtL N V (ll4 N V B) = (ll3 N V B).1 := by
  obtain ⟨⟨a, u⟩, ⟨⟨μ, ν⟩, h⟩⟩ := B
  simp only [tgtL, ll4, ll3, nxtL, shL]
  fin_cases ν <;> simp [Fin.coeSucc_eq_succ]

theorem tgt_ll23 (V : ℕ) (B : LPlaq N V) : tgtL N V (ll2 N V B) = tgtL N V (ll3 N V B) := by
  obtain ⟨⟨a, u⟩, ⟨⟨μ, ν⟩, h⟩⟩ := B
  simp only [tgtL, ll2, ll3]
  refine Prod.ext (add_right_comm _ _ _) ?_
  simp only
  fin_cases μ <;> fin_cases ν <;> simp [nxtL, shL, Fin.coeSucc_eq_succ] at h ⊢

theorem coe_gaugeL (V : ℕ) (g : LSite N V → SU2) (ω : LLink N V → SU2) (ℓ : LLink N V) :
    ((gaugeL N V g ω ℓ : SU2) : ℍr) = (g ℓ.1 : ℍr) * (ω ℓ : ℍr) * star (g (tgtL N V ℓ) : ℍr) := by
  unfold gaugeL
  rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, inv_unit]

theorem holL_gaugeL (V : ℕ) (g : LSite N V → SU2) (ω : LLink N V → SU2) (B : LPlaq N V) :
    holL N V (gaugeL N V g ω) B
      = (g (ll1 N V B).1 : ℍr) * holL N V ω B * star (g (ll1 N V B).1 : ℍr) := by
  unfold holL
  rw [coe_gaugeL, coe_gaugeL, coe_gaugeL, coe_gaugeL, tgt_ll1, tgt_ll4, tgt_ll23]
  have h41 : (ll4 N V B).1 = (ll1 N V B).1 := rfl
  rw [h41]
  simp only [star_mul, star_star, mul_assoc, star_mul_cancel]

theorem re_holL_gaugeL (V : ℕ) (g : LSite N V → SU2) (ω : LLink N V → SU2) (B : LPlaq N V) :
    (holL N V (gaugeL N V g ω) B).re = (holL N V ω B).re := by
  rw [holL_gaugeL, re_mul_comm', ← mul_assoc, Quaternion.star_mul_self, normSq_unit]
  simp

/-- **局所の剛性**（紙の命題 4.1 (c)）：局所の作用 0 の配位は、升に現れる全てのリンクの上で
局所の真空のゲージ変換 -/
def RigidL (V : ℕ) : Prop :=
  ∀ ωl : LLink N V → SU2, SL N V true ωl ≤ 0 →
    ∃ g : LSite N V → SU2, ∀ B : LPlaq N V,
      ωl (ll1 N V B) = gaugeL N V g (vacL N V) (ll1 N V B) ∧
      ωl (ll2 N V B) = gaugeL N V g (vacL N V) (ll2 N V B) ∧
      ωl (ll3 N V B) = gaugeL N V g (vacL N V) (ll3 N V B) ∧
      ωl (ll4 N V B) = gaugeL N V g (vacL N V) (ll4 N V B)

/-! ## ずれ c = (−1, −1) の算術（格子 M） -/

theorem val_shift (M : ℕ) [NeZero M] (u : ℕ) (h1 : 1 ≤ u) (h : u - 1 < M) :
    (((M - 1 : ℕ) : ZMod M) + ((u : ℕ) : ZMod M)).val = u - 1 := by
  have hM : 0 < M := NeZero.pos M
  rw [← Nat.cast_add, ZMod.val_natCast]
  have e : M - 1 + u = (u - 1) + M := by omega
  rw [e, Nat.add_mod_right, Nat.mod_eq_of_lt h]

theorem val_shift0 (M : ℕ) [NeZero M] :
    (((M - 1 : ℕ) : ZMod M) + ((0 : ℕ) : ZMod M)).val = M - 1 := by
  have hM : 0 < M := NeZero.pos M
  rw [Nat.cast_zero, add_zero, ZMod.val_natCast, Nat.mod_eq_of_lt (by omega)]

/-- 像が塊の 0 番に入る ⇔ ずれ u ∈ [1, m] -/
theorem shift_lt_iff (m : ℕ) [NeZero m] (u : ℕ) (hu : u - 1 < 2 * m) :
    haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
    ((((2 * m - 1 : ℕ) : ZMod (2 * m)) + ((u : ℕ) : ZMod (2 * m))).val < m ↔ 1 ≤ u ∧ u ≤ m) := by
  haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
  have hm : 0 < m := NeZero.pos m
  rcases Nat.eq_zero_or_pos u with h0 | hpos
  · subst h0
    rw [val_shift0]; omega
  · rw [val_shift (2 * m) u hpos hu]; omega

theorem shift_eq_zero_iff (m : ℕ) [NeZero m] (u : ℕ) (hu : u - 1 < 2 * m) :
    haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
    (((2 * m - 1 : ℕ) : ZMod (2 * m)) + ((u : ℕ) : ZMod (2 * m)) = 0 ↔ u = 1) := by
  haveI : NeZero (2 * m) := ⟨by have := NeZero.pos m; omega⟩
  have hm : 0 < m := NeZero.pos m
  rw [← ZMod.val_eq_zero]
  rcases Nat.eq_zero_or_pos u with h0 | hpos
  · subst h0
    rw [val_shift0]; omega
  · rw [val_shift (2 * m) u hpos hu]; omega

theorem q2_eq_zero (M m : ℕ) [NeZero M] [NeZero m] (y : ZMod M) :
    q M m 2 y = 0 ↔ y.val < m := by
  have hm : 0 < m := NeZero.pos m
  rw [Fin.ext_iff]
  show min (y.val / m) (2 - 1) = 0 ↔ _
  by_cases hy : y.val < m
  · rw [Nat.div_eq_of_lt hy]; simp [hy]
  · have : 1 ≤ y.val / m := (Nat.le_div_iff_mul_le hm).mpr (by omega)
    constructor
    · intro h; omega
    · intro h; exact absurd h hy

/-- m = 1 では全てのリンクが枠（塊の内部は空） -/
theorem two_le_of_not_fr (m : ℕ) [NeZero m] [NeZero (2 * m)] (ℓ : Link N (2 * m))
    (h : ¬ fr N (2 * m) m 2 ℓ) : 2 ≤ m := by
  by_contra hlt
  have h1 : m = 1 := by have := NeZero.pos m; omega
  subst h1
  apply h
  have hl : ∀ y : ZMod (2 * 1), onLine (2 * 1) 1 2 y := fun y => by
    unfold onLine; rw [Nat.mod_one]; have := ZMod.val_lt y; omega
  unfold fr
  split_ifs
  · exact hl _
  · exact hl _
  · exact Or.inl (hl _)

/-! ## 引き戻しの配位と移植 -/

/-- ずれ (−1, −1) -/
def cm (m : ℕ) : Pt (2 * m) := (((2 * m - 1 : ℕ) : ZMod (2 * m)), ((2 * m - 1 : ℕ) : ZMod (2 * m)))

/-- 局所の反転の位置 (1, 1)（大域の (0, 0) に写る） -/
def P0m (m : ℕ) : Fin (m + 2) × Fin (m + 2) := (⟨1, by omega⟩, ⟨1, by omega⟩)

/-- 塊 (0,0) の内部の外を V に替えた配位 -/
noncomputable def Wout (m : ℕ) [NeZero (2 * m)] (W : Link N (2 * m) → SU2) : Link N (2 * m) → SU2 :=
  fun ℓ => if ¬ fr N (2 * m) m 2 ℓ ∧ blk2 (2 * m) m 2 ℓ.1.2 = (0, 0) then W ℓ else vac N (2 * m) ℓ

/-- 局所の模型への引き戻し -/
noncomputable def Xpull (m : ℕ) [NeZero (2 * m)] (W : Link N (2 * m) → SU2) : LLink N (m + 2) → SU2 :=
  Wout N m W ∘ embL N (2 * m) (m + 2) (cm m)

/-- 大域の升の項 -/
noncomputable def fW (m : ℕ) [NeZero (2 * m)] (W : Link N (2 * m) → SU2) (B : Plaq N (2 * m)) : ℝ :=
  1 - zt N (2 * m) true false B * etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) B
    * (hol N (2 * m) (Wout N m W) B).re

theorem Xpull_nonint (m : ℕ) [NeZero m] [NeZero (2 * m)] (W : Link N (2 * m) → SU2)
    (ℓ : LLink N (m + 2)) (h : ¬ intL N (m + 2) ℓ) : Xpull N m W ℓ = vacL N (m + 2) ℓ := by
  have hm : 0 < m := NeZero.pos m
  show Wout N m W (embL N (2 * m) (m + 2) (cm m) ℓ) = _
  unfold Wout
  rw [if_neg, vac_embL]
  rintro ⟨hf, hb⟩
  have h2 := two_le_of_not_fr N m _ hf
  have h3 := ℓ.1.2.1.isLt
  have h4 := ℓ.1.2.2.isLt
  simp only [blk2, embL, emb, cm, Prod.mk.injEq] at hb
  rw [q2_eq_zero, q2_eq_zero, shift_lt_iff m _ (by omega), shift_lt_iff m _ (by omega)] at hb
  apply h
  unfold intL
  omega

theorem blk_embP_iff (m : ℕ) [NeZero m] [NeZero (2 * m)] (B : LPlaq N (m + 2)) :
    blk2 (2 * m) m 2 (embP N (2 * m) (m + 2) (cm m) B).1.2 = (0, 0) ↔
      (1 ≤ (B.1.2.1 : ℕ) ∧ (B.1.2.1 : ℕ) ≤ m) ∧ (1 ≤ (B.1.2.2 : ℕ) ∧ (B.1.2.2 : ℕ) ≤ m) := by
  have hm : 0 < m := NeZero.pos m
  have h3 := B.1.2.1.isLt
  have h4 := B.1.2.2.isLt
  simp only [blk2, embP, emb, cm, Fin.val_castSucc, Prod.mk.injEq]
  rw [q2_eq_zero, q2_eq_zero, shift_lt_iff m _ (by omega), shift_lt_iff m _ (by omega)]

theorem eta_match (m : ℕ) [NeZero m] [NeZero (2 * m)] (B : LPlaq N (m + 2)) :
    (if B.2 = p23 then flipAt (m + 2) (P0m m) B.1.2 else 1)
      = etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) (embP N (2 * m) (m + 2) (cm m) B) := by
  have hm : 0 < m := NeZero.pos m
  unfold etaB
  have h2 : (embP N (2 * m) (m + 2) (cm m) B).2 = B.2 := rfl
  rw [h2]
  split_ifs with h23
  · unfold flipAt etaSign etaAt
    simp only [if_true]
    have hc : corner (2 * m) m 2 ((0, 0) : Fin 2 × Fin 2) = (0, 0) := by
      simp [corner]
    rw [hc]
    have hiff : (embP N (2 * m) (m + 2) (cm m) B).1.2 = (0, 0) ↔ B.1.2 = P0m m := by
      obtain ⟨⟨a, u3, u4⟩, P⟩ := B
      have h3 := u3.isLt
      have h4 := u4.isLt
      simp only [embP, emb, cm, Fin.val_castSucc, Prod.mk.injEq, P0m]
      rw [shift_eq_zero_iff m _ (by omega), shift_eq_zero_iff m _ (by omega)]
      simp [Fin.ext_iff]
    by_cases hq : B.1.2 = P0m m
    · rw [if_pos hq, if_pos (hiff.mpr hq)]
    · rw [if_neg hq, if_neg (fun e => hq (hiff.mp e))]
  · rfl

theorem hol_Wout_out (m : ℕ) [NeZero m] [NeZero (2 * m)] (W : Link N (2 * m) → SU2)
    (B : Plaq N (2 * m)) (hB : blk2 (2 * m) m 2 B.1.2 ≠ (0, 0)) :
    hol N (2 * m) (Wout N m W) B = hol N (2 * m) (vac N (2 * m)) B := by
  have key : ∀ ℓ, (¬ fr N (2 * m) m 2 ℓ → blk2 (2 * m) m 2 ℓ.1.2 = blk2 (2 * m) m 2 B.1.2) →
      Wout N m W ℓ = vac N (2 * m) ℓ := by
    intro ℓ hℓ
    unfold Wout
    rw [if_neg]
    rintro ⟨hf, hb⟩
    exact hB ((hℓ hf).symm.trans hb)
  unfold hol
  rw [key (l1 N (2 * m) B) (fun _ => blk_l1 N (2 * m) m 2 B),
    key (l2 N (2 * m) B) (blk_l2 N (2 * m) m 2 B),
    key (l3 N (2 * m) B) (blk_l3 N (2 * m) m 2 B),
    key (l4 N (2 * m) B) (fun _ => blk_l4 N (2 * m) m 2 B)]

theorem fW_out (m : ℕ) [NeZero m] [NeZero (2 * m)] (W : Link N (2 * m) → SU2)
    (B : Plaq N (2 * m)) (hB : blk2 (2 * m) m 2 B.1.2 ≠ (0, 0)) : fW N m W B = 0 := by
  unfold fW
  rw [hol_Wout_out N m W B hB]
  have he : etaB N (2 * m) (etaSign (2 * m) m 2 (0, 0) true) B = 1 := by
    unfold etaB
    split_ifs
    · unfold etaSign etaAt
      simp only [if_true]
      rw [if_neg]
      intro hc
      apply hB
      rw [hc]
      exact blk2_corner (2 * m) m 2 (by omega) (0, 0)
    · rfl
  rw [he, mul_one, vac_term]
  ring

theorem sum_pull_le (m : ℕ) [NeZero m] [NeZero (2 * m)] (W : Link N (2 * m) → SU2) :
    ∑ B : LPlaq N (m + 2), fW N m W (embP N (2 * m) (m + 2) (cm m) B)
      ≤ actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true) (Wout N m W) := by
  classical
  have hm : 0 < m := NeZero.pos m
  rw [← Finset.sum_filter_add_sum_filter_not univ
    (fun B : LPlaq N (m + 2) => blk2 (2 * m) m 2 (embP N (2 * m) (m + 2) (cm m) B).1.2 = (0, 0))]
  have hout : ∑ B ∈ univ.filter (fun B : LPlaq N (m + 2) =>
      ¬ blk2 (2 * m) m 2 (embP N (2 * m) (m + 2) (cm m) B).1.2 = (0, 0)),
        fW N m W (embP N (2 * m) (m + 2) (cm m) B) = 0 :=
    Finset.sum_eq_zero fun B hB => fW_out N m W _ (Finset.mem_filter.mp hB).2
  rw [hout, add_zero]
  rw [← Finset.sum_image (fun B1 hB1 B2 hB2 he => by
    obtain ⟨⟨a, u3, u4⟩, P⟩ := B1
    obtain ⟨⟨a', u3', u4'⟩, P'⟩ := B2
    have hb1 := (blk_embP_iff N m _).mp (Finset.mem_filter.mp hB1).2
    have hb2 := (blk_embP_iff N m _).mp (Finset.mem_filter.mp hB2).2
    simp only [Fin.val_castSucc] at hb1 hb2
    simp only [embP, emb, cm, Fin.val_castSucc, Prod.mk.injEq] at he
    obtain ⟨⟨ha, h3, h4⟩, hP⟩ := he
    have e3 := congrArg ZMod.val h3
    have e4 := congrArg ZMod.val h4
    rw [val_shift (2 * m) _ hb1.1.1 (by omega), val_shift (2 * m) _ hb2.1.1 (by omega)] at e3
    rw [val_shift (2 * m) _ hb1.2.1 (by omega), val_shift (2 * m) _ hb2.2.1 (by omega)] at e4
    have : u3 = u3' := Fin.ext (by omega)
    have : u4 = u4' := Fin.ext (by omega)
    subst ha; subst hP
    simp_all)]
  unfold actB
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro B' hB'
    obtain ⟨B, hB, rfl⟩ := Finset.mem_image.mp hB'
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hB).2⟩
  · intro B' _ _
    exact (actB_term_bounds N (2 * m) true _ (abs_etaSign_le (2 * m) m 2 (0, 0) true) _ B').1

theorem actB_Wout (m : ℕ) [NeZero m] [NeZero (2 * m)] (y : Inner N (2 * m) m 2 (0, 0) → SU2) :
    actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true)
        (Wout N m (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) y))
      = actB N (2 * m) m 2 true (0, 0) (etaSign (2 * m) m 2 (0, 0) true)
        (glueB N (2 * m) m 2 (0, 0) (fun x => vac N (2 * m) x.1) y) := by
  apply actB_local
  · intro ℓ h
    unfold Wout glueB BlockFubini.glue
    rw [if_neg (fun h' => h'.1 h), dif_pos h]
  · intro ℓ h hb
    unfold Wout
    rw [if_pos ⟨h, hb⟩]

/-- **移植（紙の命題 4.1 (d)）**：局所の剛性から零作用の主張（費用 S_渦(N, m₀)） -/
theorem thick_vortex_floor_zero_of_rigid (m₀ : ℕ) [NeZero m₀] (hR : RigidL N (m₀ + 2)) :
    ZeroVortexL N m₀ (Svortex N m₀) := by
  classical
  haveI : NeZero (2 * m₀) := ⟨by have := NeZero.pos m₀; omega⟩
  intro ωl hω
  obtain ⟨g, hg⟩ := hR ωl hω
  obtain ⟨y, hy⟩ := Svortex_attained N m₀
  refine ⟨gaugeL N (m₀ + 2) g
    (Xpull N m₀ (glueB N (2 * m₀) m₀ 2 (0, 0) (fun x => vac N (2 * m₀) x.1) y)), P0m m₀, ?_⟩
  set W := glueB N (2 * m₀) m₀ 2 (0, 0) (fun x => vac N (2 * m₀) x.1) y with hW
  have hmix : ∀ B, holL N (m₀ + 2) (mixL N (m₀ + 2) ωl (gaugeL N (m₀ + 2) g (Xpull N m₀ W))) B
      = holL N (m₀ + 2) (gaugeL N (m₀ + 2) g (Xpull N m₀ W)) B := by
    intro B
    have e : ∀ ℓ, ωl ℓ = gaugeL N (m₀ + 2) g (vacL N (m₀ + 2)) ℓ →
        mixL N (m₀ + 2) ωl (gaugeL N (m₀ + 2) g (Xpull N m₀ W)) ℓ
          = gaugeL N (m₀ + 2) g (Xpull N m₀ W) ℓ := by
      intro ℓ hℓ
      unfold mixL
      split_ifs with hi
      · rfl
      · rw [hℓ]; unfold gaugeL; rw [Xpull_nonint N m₀ W ℓ hi]
    obtain ⟨h1, h2, h3, h4⟩ := hg B
    unfold holL
    rw [e _ h1, e _ h2, e _ h3, e _ h4]
  have hterm : ∀ B : LPlaq N (m₀ + 2),
      1 - zL N (m₀ + 2) true B * (if B.2 = p23 then flipAt (m₀ + 2) (P0m m₀) B.1.2 else 1)
          * (holL N (m₀ + 2) (mixL N (m₀ + 2) ωl (gaugeL N (m₀ + 2) g (Xpull N m₀ W))) B).re
        = fW N m₀ W (embP N (2 * m₀) (m₀ + 2) (cm m₀) B) := by
    intro B
    rw [hmix, re_holL_gaugeL, Xpull, ← hol_emb, ← zt_embP N (2 * m₀) (m₀ + 2) (cm m₀) true B,
      eta_match]
    rfl
  unfold SLe
  rw [Finset.sum_congr rfl fun B _ => hterm B]
  calc _ ≤ _ := sum_pull_le N m₀ W
    _ = _ := actB_Wout N m₀ y
    _ = Svortex N m₀ := hy

/-- **太い渦の床は局所の剛性 `RigidL` だけに条件つき** -/
theorem thick_vortex_floor_abs_of_rigid (hR : ∀ m₀ : ℕ+, RigidL N ((m₀ : ℕ) + 2)) :
    ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_zero N fun m₀ => thick_vortex_floor_zero_of_rigid N m₀ (hR m₀)

end TwistBlocks

#print axioms TwistBlocks.holL_gaugeL
#print axioms TwistBlocks.thick_vortex_floor_zero_of_rigid
#print axioms TwistBlocks.thick_vortex_floor_abs_of_rigid
