import Blocks.ThickFloorPolyakovV1
import Blocks.ThickFloorSignedV1

open Finset MeasureTheory TwistedWilson TwistedPlane

namespace HalfSplit

/-- **Polyakov ループの対の減衰**（太い渦の床と合わせて）：十分大きい β と（β ごとに）十分大きい M で、
M + 1 が偶数なら `|⟨P_b(0) P_{b'}((M+1)/2)⟩₀| ≤ 2 exp(−(M+1)² e^{−β(S_N+ε)}/2)`。 -/
theorem polyakov_pair_floor (N : ℕ) [NeZero N] :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop, (M + 1) % 2 = 0 →
      ∀ b b' : ZMod N × ZMod N,
      |∫ ω, (polyLoop N (M + 1) b 0 ω * polyLoop N (M + 1) b' (halfPt (M + 1)) ω)
          * wE N (M + 1) β (fun _ => 1) ω ∂(haarCfg N (M + 1))| / ZW N (M + 1) β true false
        ≤ 2 * Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (TwistBlocks.SN N + ε)) / 2) := by
  intro ε hε
  filter_upwards [TwistBlocks.thick_vortex_floor_signed N ε hε] with β hβ
  filter_upwards [hβ] with M hM hev b b'
  obtain ⟨h0, h1⟩ := hM hev
  have hP := polyakov_pair_theta N (M + 1) hev β b b'
  set θ := TwistBlocks.thetaM N (M + 1) β
  set X := -(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (TwistBlocks.SN N + ε))
  have hs : Real.sqrt θ ≤ Real.exp (X / 2) := by
    have e : Real.exp (X / 2) = Real.sqrt (Real.exp X) := by
      rw [← Real.sqrt_sq (Real.exp_pos (X / 2)).le, ← Real.exp_nat_mul]; congr 2; push_cast; ring
    rw [e]; exact Real.sqrt_le_sqrt h1
  calc _ ≤ 2 * Real.sqrt θ / (1 + θ) := hP
    _ ≤ 2 * Real.sqrt θ := div_le_self (by positivity) (by linarith)
    _ ≤ 2 * Real.exp (X / 2) := by linarith

end HalfSplit

#print axioms HalfSplit.polyakov_pair_floor
