import Mathlib

/-!
# 軸のゲージ（一つの輪 ZMod N の上）：全てのリンクを 1 にし、輪のホロノミーを最後の一本に集める

(c2) 剛性の部品（T²_N の上の極大の木でのゲージの固定の一次元の版）。群 G は一般。
`pre U n = U 0 · U 1 ⋯ U (n−1)`（左から右の積）、`g a = pre U a.val`。
`g a · U a · g(a+1)⁻¹ = 1`（a.val + 1 < N）、`= pre U N`（輪のホロノミー、a.val + 1 = N）。
-/

namespace ThickFloor

variable {G : Type*} [Group G]

/-- 前からの積 -/
def pre (U : ℕ → G) : ℕ → G
  | 0 => 1
  | n + 1 => pre U n * U n

theorem axial_gauge (N : ℕ) [NeZero N] (U : ZMod N → G) (a : ZMod N) :
    pre (fun n => U (n : ZMod N)) a.val * U a * (pre (fun n => U (n : ZMod N)) (a + 1).val)⁻¹
      = if a.val + 1 = N then pre (fun n => U (n : ZMod N)) N else 1 := by
  have hv : (a + 1).val = (a.val + 1) % N := by
    rw [ZMod.val_add, ZMod.val_one_eq_one_mod, Nat.add_mod_mod]
  have hcast : ((a.val : ℕ) : ZMod N) = a := ZMod.natCast_zmod_val a
  by_cases h : a.val + 1 = N
  · rw [if_pos h, hv, h, Nat.mod_self]
    simp only [pre, inv_one, mul_one]
    have e := congrArg (pre (fun n => U (n : ZMod N))) h
    rw [← e]
    show _ = pre (fun n => U (n : ZMod N)) a.val * U ((a.val : ℕ) : ZMod N)
    rw [hcast]
  · rw [if_neg h, hv, Nat.mod_eq_of_lt (by have := ZMod.val_lt a; omega)]
    simp only [pre, hcast, mul_inv_rev, mul_assoc, mul_inv_cancel, mul_inv_cancel_left]

end ThickFloor

#print axioms ThickFloor.axial_gauge
