import Blocks.UniformV1

/-!
# 定理 E を段 4 の仮定のもとで（条件つきの定理 E）

仮定の欄（段 4、紙の命題 4.1 の出力の形）：
  (H4) 全ての ε > 0 に、m ≥ 1 が在って、全ての M ≥ m で `κ_c(N, M, m, ⌊M/m⌋) ≤ S + ε`。
結論：全ての ε > 0 で、十分大きい β について、十分大きい M で `θ_M(β) ≤ exp(−M² e^{−β(S + ε)})`
（`TheoremEStatement` の S_N を S にした形）。紙の定理 E は (H4) を S = S_N で（段 4）。
(H4) は S = 12N²(2m)² 型の自明な値でなら `kappaC_le` から満たせるが、S = S_N での (H4) は Lean に無い。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

/-- **条件つきの定理 E**（(H4) を仮定の欄に） -/
theorem theoremE_of_stage4 (N : ℕ) [NeZero N] (S : ℝ)
    (H4 : ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ S + ε) :
    ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
      thetaM N (M + 1) β ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (S + ε))) := by
  intro ε hε
  obtain ⟨m, hm0, hκ⟩ := H4 (ε / 4) (by positivity)
  have hm : 0 < m := NeZero.pos m
  set δ : ℝ := ε / 8 with hδdef
  have hδ : 0 < δ := by positivity
  set C : ℝ := Dstar N m δ + Real.log (4 * (m : ℝ) ^ 2)
  filter_upwards [Filter.eventually_ge_atTop (0 : ℝ), Filter.eventually_ge_atTop (2 * |C| / ε)]
    with β hβ0 hβC
  filter_upwards [Filter.eventually_ge_atTop m] with M hMm
  have hM1 : m ≤ M + 1 := by omega
  haveI : NeZero ((M + 1) / m) := ⟨(Nat.div_pos hM1 hm).ne'⟩
  set k := (M + 1) / m
  have hk1 : 1 ≤ k := Nat.div_pos hM1 hm
  have hMk : m * k ≤ M + 1 := Nat.mul_div_le (M + 1) m
  have hkM : M + 1 < (k + 1) * m := by
    have := Nat.lt_div_mul_add (a := M + 1) hm
    rw [Nat.add_mul, one_mul]; exact this
  have hK := hκ (M + 1) hM1
  have hθ := theta_fixed_m N (M + 1) m k hMk hkM β hβ0 true hδ (S + ε / 4) hK
  unfold thetaM
  refine hθ.trans (Real.exp_le_exp.mpr ?_)
  -- k ≥ (M+1)/(2m) as reals
  have hkr : ((M + 1 : ℕ) : ℝ) ≤ 2 * (m : ℝ) * (k : ℝ) := by
    have h1 : M + 1 < (k + 1) * m := hkM
    have h2 : (k + 1) * m ≤ 2 * m * k := by nlinarith
    exact_mod_cast (h1.trans_le h2).le
  have hmr : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm
  have hsq : ((M + 1 : ℕ) : ℝ) ^ 2 ≤ 4 * (m : ℝ) ^ 2 * (k : ℝ) ^ 2 := by
    have h0 : (0 : ℝ) ≤ ((M + 1 : ℕ) : ℝ) := Nat.cast_nonneg _
    nlinarith
  -- exponent comparison: exp(−(β(S+ε/4+2δ)+D*)) ≥ 4m² exp(−β(S+ε))
  have hexp : 4 * (m : ℝ) ^ 2 * Real.exp (-β * (S + ε))
      ≤ Real.exp (-(β * (S + ε / 4 + 2 * δ) + Dstar N m δ)) := by
    have h4 : (0 : ℝ) < 4 * (m : ℝ) ^ 2 := by positivity
    rw [← Real.exp_log h4, ← Real.exp_add]
    refine Real.exp_le_exp.mpr ?_
    have hC : C ≤ β * ε / 2 := by
      have := (div_le_iff₀ hε).mp hβC
      have hCa := le_abs_self C
      nlinarith
    simp only [C] at hC
    rw [hδdef]
    nlinarith
  have hE0 : 0 ≤ Real.exp (-β * (S + ε)) := (Real.exp_pos _).le
  have hk2 : (0 : ℝ) ≤ (k : ℝ) ^ 2 := by positivity
  calc -((k : ℝ) ^ 2) * Real.exp (-(β * (S + ε / 4 + 2 * δ) + Dstar N m δ))
      ≤ -((k : ℝ) ^ 2) * (4 * (m : ℝ) ^ 2 * Real.exp (-β * (S + ε))) := by
        nlinarith [mul_le_mul_of_nonneg_left hexp hk2]
    _ = -(4 * (m : ℝ) ^ 2 * (k : ℝ) ^ 2) * Real.exp (-β * (S + ε)) := by ring
    _ ≤ -(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (S + ε)) := by
        nlinarith [mul_le_mul_of_nonneg_right hsq hE0]

/-- (H4) を `S = S_N` で仮定すれば `TheoremEStatement N`（定理 E の言明）が出る。 -/
theorem theoremE_of_stage4_SN (N : ℕ) [NeZero N]
    (H4 : ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ SN N + ε) :
    TheoremEStatement N :=
  theoremE_of_stage4 N (SN N) H4

/-- (H4) の欄が満たせる例（自明な S で：m = 1、S = 12N²·2²、`kappaC_le` から） -/
example (N : ℕ) [NeZero N] :
    ∀ ε > 0, ∃ m : ℕ, ∃ _ : NeZero m, ∀ (M : ℕ) [NeZero M] [NeZero (M / m)], m ≤ M →
      kappaC N M m (M / m) true ≤ 2 * ((N * N * ((2 * 1) * (2 * 1)) * 6 : ℕ) : ℝ) + ε := by
  intro ε hε
  refine ⟨1, inferInstance, fun M _ _ hM => ?_⟩
  have hMk : 1 * (M / 1) ≤ M := Nat.mul_div_le M 1
  have hkM : M < (M / 1 + 1) * 1 := by simp
  have := kappaC_le N M 1 (M / 1) hMk hkM true
  linarith

end TwistBlocks

#print axioms TwistBlocks.theoremE_of_stage4
#print axioms TwistBlocks.theoremE_of_stage4_SN
