import Blocks.ThickFloorSquareV1

/-!
# T²_N の剛性（紙の命題 4.1 (c) の芯）と、仮定の欄なしの太い渦の床

T²_N = (ZMod N)² の上の配位 (A, B)（A は x₁ の向き、B は x₂ の向き）で、升の積が捩れの符号
（(0,0) で −1、他で 1）のもの（`FlatT`）は、真空（A = i（a₁ = 0）、B = j（a₂ = 0）、他は 1）の
ゲージ変換である（`rigidT_all`）。
証明：前からの積の木（x₂ の向きに a₁ = 0 の列、そこから x₁ の向きに行）でゲージを取ると
木のリンクは 1（`tree_gA`・`tree_gB`）。平坦さの帰納で、残りのリンクは二つの生成元
α = A(N−1, 0)、β = B(0, N−1) で決まり（`cfB`・`cfA`）、αβ = −βα（`cf_comm`）。
`anticomm_conj` で (α, β) を (i, j) に共役で写す定数 u を取り、真空の木のゲージの形と比べる（`uniqT`）。
N = 1 は `rigidT_one`。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

variable (N : ℕ) [NeZero N]

def pt (k l : ℕ) : ZMod N × ZMod N := ((k : ZMod N), (l : ZMod N))

theorem ev12_0 : ev12 N 0 = (1, 0) := by unfold ev12; rfl
theorem ev12_1 : ev12 N 1 = (0, 1) := by unfold ev12; rfl

theorem pt_add0 (k l : ℕ) : pt N k l + ev12 N 0 = pt N (k + 1) l := by
  rw [ev12_0]; simp [pt]
theorem pt_add1 (k l : ℕ) : pt N k l + ev12 N 1 = pt N k (l + 1) := by
  rw [ev12_1]; simp [pt]
theorem pt_N (l : ℕ) : pt N N l = pt N 0 l := by simp [pt]
theorem pt_N' (k : ℕ) : pt N k N = pt N k 0 := by simp [pt]
theorem pt_val (a : ZMod N × ZMod N) : pt N a.1.val a.2.val = a := by simp [pt]
theorem val_pt1 (k l : ℕ) (hk : k < N) : (pt N k l).1.val = k := ZMod.val_cast_of_lt hk
theorem val_pt2 (k l : ℕ) (hl : l < N) : (pt N k l).2.val = l := ZMod.val_cast_of_lt hl

theorem pt_eq_zero (k l : ℕ) (hk : k < N) (hl : l < N) : pt N k l = 0 ↔ k = 0 ∧ l = 0 := by
  constructor
  · intro h
    have h1 := congrArg (fun p : ZMod N × ZMod N => p.1.val) h
    have h2 := congrArg (fun p : ZMod N × ZMod N => p.2.val) h
    simp only [Prod.fst_zero, Prod.snd_zero, ZMod.val_zero] at h1 h2
    rw [val_pt1 N k l hk] at h1
    rw [val_pt2 N k l hl] at h2
    exact ⟨h1, h2⟩
  · rintro ⟨rfl, rfl⟩; simp [pt]

/-- 升の積が捩れの符号 -/
def FlatT (A B : ZMod N × ZMod N → SU2) : Prop :=
  ∀ a, (A a : ℍr) * (B (a + ev12 N 0) : ℍr) * star (A (a + ev12 N 1) : ℍr) * star (B a : ℍr)
    = (((if a = 0 then -1 else 1 : ℝ)) : ℍr)

/-- 前からの積の木の上で 1 -/
def TreeT (A B : ZMod N × ZMod N → SU2) : Prop :=
  (∀ a : ZMod N × ZMod N, a.1.val + 1 < N → A a = 1) ∧ (∀ l : ℕ, l + 1 < N → B (pt N 0 l) = 1)

theorem eq_mul_of_mul_star (x y : SU2) (q : ℍr) (h : (x : ℍr) * star (y : ℍr) = q) :
    (x : ℍr) = q * y := by
  rw [← h, mul_assoc, star_mul_unit, mul_one]

theorem eq_star_mul_of_mul_star (x y : SU2) (q : ℍr) (h : (x : ℍr) * star (y : ℍr) = q) :
    (y : ℍr) = star q * x := by
  rw [← h, star_mul, star_star, mul_assoc, star_mul_unit, mul_one]

theorem anticomm_of (x y : SU2) (h : (x : ℍr) * y * star (x : ℍr) * star (y : ℍr) = -1) :
    (x : ℍr) * y = -((y : ℍr) * x) := by
  have l : (x : ℍr) * y * star (x : ℍr) * star (y : ℍr) * ((y : ℍr) * x) = (x : ℍr) * y := by
    calc _ = (x : ℍr) * y * star (x : ℍr) * (star (y : ℍr) * (y : ℍr)) * (x : ℍr) := by
            simp only [mul_assoc]
      _ = (x : ℍr) * y * (star (x : ℍr) * (x : ℍr)) := by rw [star_mul_unit, mul_one, mul_assoc]
      _ = _ := by rw [star_mul_unit, mul_one]
  rw [← l, h, neg_one_mul]

/-! ## 生成元による表示（N ≥ 2） -/

section CF

variable (hN : 2 ≤ N) (A B : ZMod N × ZMod N → SU2) (hF : FlatT N A B) (hT : TreeT N A B)
include hN hF hT

theorem cfB : ∀ k, k < N → ∀ l, l < N →
    (B (pt N k l) : ℍr) = ((if l = 0 ∧ 1 ≤ k then -1 else 1 : ℝ) : ℍr) * B (pt N 0 l) := by
  intro k
  induction k with
  | zero => intro _ l _; simp
  | succ k ih =>
    intro hk l hl
    have e := hF (pt N k l)
    rw [pt_add0, pt_add1, hT.1 (pt N k l) (by rw [val_pt1 N k l (by omega)]; omega),
      hT.1 (pt N k (l + 1)) (by rw [val_pt1 N k (l + 1) (by omega)]; omega)] at e
    simp only [coe_one_SU2, one_mul, star_one, mul_one] at e
    rw [eq_mul_of_mul_star _ _ _ e, ih (by omega) l hl, ← mul_assoc, ← Quaternion.coe_mul]
    congr 2
    simp only [pt_eq_zero N k l (by omega) hl]
    split_ifs <;> first | (exfalso; omega) | norm_num

theorem cfA : ∀ l, 1 ≤ l → l < N → (A (pt N (N - 1) l) : ℍr) = -(A (pt N (N - 1) 0) : ℍr) := by
  intro l hl1
  induction l, hl1 using Nat.le_induction with
  | base =>
    intro _
    have e := hF (pt N (N - 1) 0)
    have hN1 : N - 1 + 1 = N := by omega
    rw [pt_add0, pt_add1, hN1, pt_N, hT.2 0 (by omega),
      if_neg (by rw [pt_eq_zero N (N - 1) 0 (by omega) (by omega)]; omega)] at e
    have hb := cfB N hN A B hF hT (N - 1) (by omega) 0 (by omega)
    rw [hT.2 0 (by omega), if_pos ⟨rfl, by omega⟩] at hb
    rw [hb] at e
    simp only [coe_one_SU2, mul_one, star_mul, star_one, one_mul, Quaternion.star_coe,
      Quaternion.coe_one, Quaternion.coe_neg, mul_neg, zero_add, star_neg] at e
    have e2 : (A (pt N (N - 1) 0) : ℍr) * star (A (pt N (N - 1) 1) : ℍr) = -1 := by
      rw [← neg_neg ((A (pt N (N - 1) 0) : ℍr) * star (A (pt N (N - 1) 1) : ℍr)), e]
    rw [eq_star_mul_of_mul_star _ _ _ e2]
    simp
  | succ l hl ih =>
    intro hl2
    have e := hF (pt N (N - 1) l)
    have hN1 : N - 1 + 1 = N := by omega
    rw [pt_add0, pt_add1, hN1, pt_N, hT.2 l (by omega),
      if_neg (by rw [pt_eq_zero N (N - 1) l (by omega) (by omega)]; omega)] at e
    have hb := cfB N hN A B hF hT (N - 1) (by omega) l (by omega)
    rw [hT.2 l (by omega), if_neg (by omega)] at hb
    rw [hb] at e
    simp only [coe_one_SU2, mul_one, star_mul, star_one, one_mul, Quaternion.star_coe,
      Quaternion.coe_one] at e
    rw [eq_star_mul_of_mul_star _ _ _ e, star_one, one_mul]
    exact ih (by omega)

theorem cf_comm : (A (pt N (N - 1) 0) : ℍr) * B (pt N 0 (N - 1))
    = -((B (pt N 0 (N - 1)) : ℍr) * A (pt N (N - 1) 0)) := by
  have e := hF (pt N (N - 1) (N - 1))
  have hN1 : N - 1 + 1 = N := by omega
  rw [pt_add0, pt_add1, hN1, pt_N, pt_N',
    if_neg (by rw [pt_eq_zero N (N - 1) (N - 1) (by omega) (by omega)]; omega)] at e
  have hb := cfB N hN A B hF hT (N - 1) (by omega) (N - 1) (by omega)
  rw [if_neg (by omega)] at hb
  have ha := cfA N hN A B hF hT (N - 1) (by omega) (by omega)
  rw [hb, ha] at e
  simp only [Quaternion.coe_one, one_mul, neg_mul] at e
  apply anticomm_of
  rw [← neg_neg ((A (pt N (N - 1) 0) : ℍr) * B (pt N 0 (N - 1)) * star (A (pt N (N - 1) 0) : ℍr)
    * star (B (pt N 0 (N - 1)) : ℍr)), e]

end CF

theorem uniqT (hN : 2 ≤ N) (A B A' B' : ZMod N × ZMod N → SU2) (hF : FlatT N A B) (hT : TreeT N A B)
    (hF' : FlatT N A' B') (hT' : TreeT N A' B')
    (hα : A (pt N (N - 1) 0) = A' (pt N (N - 1) 0)) (hβ : B (pt N 0 (N - 1)) = B' (pt N 0 (N - 1))) :
    ∀ a, A a = A' a ∧ B a = B' a := by
  intro a
  rw [← pt_val N a]
  have hk : a.1.val < N := ZMod.val_lt _
  have hl : a.2.val < N := ZMod.val_lt _
  generalize a.1.val = k at hk ⊢
  generalize a.2.val = l at hl ⊢
  constructor
  · by_cases hk1 : k + 1 < N
    · rw [hT.1 _ (by rw [val_pt1 N k l hk]; exact hk1), hT'.1 _ (by rw [val_pt1 N k l hk]; exact hk1)]
    · have hkN : k = N - 1 := by omega
      subst hkN
      by_cases hl0 : l = 0
      · subst hl0; exact hα
      · apply Subtype.ext
        rw [cfA N hN A B hF hT l (by omega) hl, cfA N hN A' B' hF' hT' l (by omega) hl, hα]
  · apply Subtype.ext
    rw [cfB N hN A B hF hT k hk l hl, cfB N hN A' B' hF' hT' k hk l hl]
    congr 1
    by_cases hl1 : l + 1 < N
    · rw [hT.2 l hl1, hT'.2 l hl1]
    · have : l = N - 1 := by omega
      subst this
      rw [hβ]

/-! ## 木のゲージ -/

noncomputable def Pc (B : ZMod N × ZMod N → SU2) (l : ℕ) : SU2 := ThickFloor.pre (fun n => B (pt N 0 n)) l
noncomputable def Pr (A : ZMod N × ZMod N → SU2) (l k : ℕ) : SU2 := ThickFloor.pre (fun n => A (pt N n l)) k
noncomputable def tauT (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) : SU2 :=
  Pc N B a.2.val * Pr N A a.2.val a.1.val
noncomputable def gA (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) : SU2 :=
  tauT N A B a * A a * (tauT N A B (a + ev12 N 0))⁻¹
noncomputable def gB (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) : SU2 :=
  tauT N A B a * B a * (tauT N A B (a + ev12 N 1))⁻¹

theorem tree_gA (A B : ZMod N × ZMod N → SU2) (a : ZMod N × ZMod N) (h : a.1.val + 1 < N) :
    gA N A B a = 1 := by
  have e1 : (a + ev12 N 0).1.val = a.1.val + 1 := by
    have : (a + ev12 N 0).1 = ((a.1.val + 1 : ℕ) : ZMod N) := by rw [ev12_0]; push_cast; simp
    rw [this, ZMod.val_cast_of_lt h]
  have e2 : (a + ev12 N 0).2 = a.2 := by rw [ev12_0]; simp
  unfold gA tauT
  rw [e1, e2]
  simp only [Pr, ThickFloor.pre, pt_val]
  group

theorem tree_gB (A B : ZMod N × ZMod N → SU2) (l : ℕ) (h : l + 1 < N) : gB N A B (pt N 0 l) = 1 := by
  unfold gB tauT
  rw [pt_add1, val_pt2 N 0 l (by omega), val_pt2 N 0 (l + 1) h, val_pt1 N 0 l (NeZero.pos N),
    val_pt1 N 0 (l + 1) (NeZero.pos N)]
  simp only [Pc, Pr, ThickFloor.pre]
  group

theorem coe_conj (x w : SU2) : ((x * w * x⁻¹ : SU2) : ℍr) = (x : ℍr) * w * star (x : ℍr) := by
  rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, inv_unit]

theorem coe_plaq (a b c d : SU2) :
    ((a * b * c⁻¹ * d⁻¹ : SU2) : ℍr) = (a : ℍr) * b * star (c : ℍr) * star (d : ℍr) := by
  simp only [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, inv_unit]

theorem real_conj (x : SU2) (r : ℝ) : (x : ℍr) * (r : ℍr) * star (x : ℍr) = r := by
  rw [← Quaternion.coe_commutes, mul_assoc, mul_star_unit, mul_one]

theorem flat_g (A B : ZMod N × ZMod N → SU2) (hF : FlatT N A B) : FlatT N (gA N A B) (gB N A B) := by
  intro a
  have hg : gA N A B a * gB N A B (a + ev12 N 0) * (gA N A B (a + ev12 N 1))⁻¹ * (gB N A B a)⁻¹
      = tauT N A B a * (A a * B (a + ev12 N 0) * (A (a + ev12 N 1))⁻¹ * (B a)⁻¹) * (tauT N A B a)⁻¹ := by
    unfold gA gB
    rw [add_right_comm a (ev12 N 1) (ev12 N 0)]
    group
  rw [← coe_plaq, hg, coe_conj, coe_plaq, hF a, real_conj]

theorem flat_conj (u : SU2) (A B : ZMod N × ZMod N → SU2) (hF : FlatT N A B) :
    FlatT N (fun a => u * A a * u⁻¹) (fun a => u * B a * u⁻¹) := by
  intro a
  have hg : (u * A a * u⁻¹) * (u * B (a + ev12 N 0) * u⁻¹) * (u * A (a + ev12 N 1) * u⁻¹)⁻¹
      * (u * B a * u⁻¹)⁻¹ = u * (A a * B (a + ev12 N 0) * (A (a + ev12 N 1))⁻¹ * (B a)⁻¹) * u⁻¹ := by
    group
  show ((u * A a * u⁻¹ : SU2) : ℍr) * ((u * B (a + ev12 N 0) * u⁻¹ : SU2) : ℍr)
      * star ((u * A (a + ev12 N 1) * u⁻¹ : SU2) : ℍr) * star ((u * B a * u⁻¹ : SU2) : ℍr) = _
  rw [← coe_plaq, hg, coe_conj, coe_plaq, hF a, real_conj]

theorem tree_conj (u : SU2) (A B : ZMod N × ZMod N → SU2) (hT : TreeT N A B) :
    TreeT N (fun a => u * A a * u⁻¹) (fun a => u * B a * u⁻¹) :=
  ⟨fun a h => by simp only [hT.1 a h, mul_one, mul_inv_cancel],
    fun l h => by simp only [hT.2 l h, mul_one, mul_inv_cancel]⟩

/-! ## 真空 -/

noncomputable def AV (a : ZMod N × ZMod N) : SU2 := if a.1 = 0 then qI else 1
noncomputable def BV (a : ZMod N × ZMod N) : SU2 := if a.2 = 0 then qJ else 1

theorem ijij : ((qI : SU2) : ℍr) * (qJ : ℍr) * star ((qI : SU2) : ℍr) * star ((qJ : SU2) : ℍr)
    = (((-1 : ℝ)) : ℍr) := by
  have hi : ((qI : SU2) : ℍr) = ThickFloor.qi := coe_qI
  have hj : ((qJ : SU2) : ℍr) = ThickFloor.qj := coe_qJ
  rw [hi, hj]
  apply Quaternion.ext <;> simp [Quaternion.re_mul, Quaternion.imI_mul, Quaternion.imJ_mul,
    Quaternion.imK_mul, Quaternion.re_one, Quaternion.imI_one, Quaternion.imJ_one,
    Quaternion.imK_one] <;> norm_num

theorem flatV : FlatT N (AV N) (BV N) := by
  intro a
  have e1 : (a + ev12 N 0).2 = a.2 := by rw [ev12_0]; simp
  have e2 : (a + ev12 N 1).1 = a.1 := by rw [ev12_1]; simp
  unfold AV BV
  rw [e1, e2]
  have hz : (a = 0) ↔ (a.1 = 0 ∧ a.2 = 0) := Prod.ext_iff
  by_cases h1 : a.1 = 0 <;> by_cases h2 : a.2 = 0 <;>
    simp only [h1, h2, if_true, if_false, hz, and_true, and_false, false_and] <;>
    first | exact ijij | simp [coe_one_SU2, mul_star_unit]

theorem pre_AV (l : ℕ) : ∀ k, 1 ≤ k → k ≤ N → ThickFloor.pre (fun n => AV N (pt N n l)) k = qI := by
  intro k hk
  induction k, hk using Nat.le_induction with
  | base => intro _; simp [ThickFloor.pre, AV, pt]
  | succ k hk ih =>
    intro hkN
    simp only [ThickFloor.pre]
    rw [ih (by omega)]
    have : ¬ ((k : ℕ) : ZMod N) = 0 := by
      intro h0
      have := congrArg ZMod.val h0
      rw [ZMod.val_cast_of_lt (by omega), ZMod.val_zero] at this
      omega
    simp [AV, pt, this]

theorem pre_BV : ∀ k, 1 ≤ k → k ≤ N → ThickFloor.pre (fun n => BV N (pt N 0 n)) k = qJ := by
  intro k hk
  induction k, hk using Nat.le_induction with
  | base => intro _; simp [ThickFloor.pre, BV, pt]
  | succ k hk ih =>
    intro hkN
    simp only [ThickFloor.pre]
    rw [ih (by omega)]
    have : ¬ ((k : ℕ) : ZMod N) = 0 := by
      intro h0
      have := congrArg ZMod.val h0
      rw [ZMod.val_cast_of_lt (by omega), ZMod.val_zero] at this
      omega
    simp [BV, pt, this]

theorem tau_zero (A B : ZMod N × ZMod N → SU2) : tauT N A B (pt N 0 0) = 1 := by
  unfold tauT
  rw [val_pt1 N 0 0 (NeZero.pos N), val_pt2 N 0 0 (NeZero.pos N)]
  simp [Pc, Pr, ThickFloor.pre]

theorem genA_V (hN : 2 ≤ N) : gA N (AV N) (BV N) (pt N (N - 1) 0) = qI := by
  unfold gA
  have hN1 : N - 1 + 1 = N := by omega
  rw [pt_add0, hN1, pt_N, tau_zero, inv_one, mul_one]
  unfold tauT
  rw [val_pt1 N (N - 1) 0 (by omega), val_pt2 N (N - 1) 0 (by omega)]
  simp only [Pc, Pr, ThickFloor.pre, one_mul]
  rw [pre_AV N 0 (N - 1) (by omega) (by omega)]
  have : ¬ (((N - 1 : ℕ) : ZMod N)) = 0 := by
    intro h0
    have := congrArg ZMod.val h0
    rw [ZMod.val_cast_of_lt (by omega), ZMod.val_zero] at this
    omega
  simp [AV, pt, this]

theorem genB_V (hN : 2 ≤ N) : gB N (AV N) (BV N) (pt N 0 (N - 1)) = qJ := by
  unfold gB
  have hN1 : N - 1 + 1 = N := by omega
  rw [pt_add1, hN1, pt_N', tau_zero, inv_one, mul_one]
  unfold tauT
  rw [val_pt1 N 0 (N - 1) (by omega), val_pt2 N 0 (N - 1) (by omega)]
  simp only [Pc, Pr, ThickFloor.pre, mul_one]
  rw [pre_BV N (N - 1) (by omega) (by omega)]
  have : ¬ (((N - 1 : ℕ) : ZMod N)) = 0 := by
    intro h0
    have := congrArg ZMod.val h0
    rw [ZMod.val_cast_of_lt (by omega), ZMod.val_zero] at this
    omega
  simp [BV, pt, this]

/-! ## 反可換な組を (i, j) に写す単位四元数 -/

theorem unit_conj (x y : SU2) (hxy : (x : ℍr) * y = -((y : ℍr) * x)) :
    ∃ u : SU2, u * x * u⁻¹ = qI ∧ u * y * u⁻¹ = qJ := by
  obtain ⟨g, hg0, hgA, hgB⟩ :=
    ThickFloor.anticomm_conj (x : ℍr) (y : ℍr) (normSq_unit _) (normSq_unit _) hxy
  have hn : ‖g‖ ≠ 0 := norm_ne_zero_iff.mpr hg0
  let u : SU2 := ⟨g * ((‖g‖⁻¹ : ℝ) : ℍr), by
    rw [mem_sphere_zero_iff_norm, norm_mul, Quaternion.norm_coe, Real.norm_eq_abs, abs_inv, abs_norm,
      mul_inv_cancel₀ hn]⟩
  have hu0 : (u : ℍr) ≠ 0 := by
    intro h0
    have := congrArg norm h0
    rw [norm_zero, mem_sphere_zero_iff_norm.mp u.2] at this
    exact one_ne_zero this
  have conj : ∀ (w q : ℍr), g * w * g⁻¹ = q → (u : ℍr) * w * (u : ℍr)⁻¹ = q := by
    intro w q hq
    have h1 : g * w = q * g := by
      rw [← hq, mul_assoc, inv_mul_cancel₀ hg0, mul_one]
    have h2 : (u : ℍr) * w = q * (u : ℍr) := by
      show g * ((‖g‖⁻¹ : ℝ) : ℍr) * w = q * (g * ((‖g‖⁻¹ : ℝ) : ℍr))
      rw [mul_assoc, Quaternion.coe_commutes, ← mul_assoc, h1, mul_assoc]
    rw [h2, mul_assoc, mul_inv_cancel₀ hu0, mul_one]
  refine ⟨u, ?_, ?_⟩
  · apply Subtype.ext
    rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, coe_qI]
    exact conj _ _ hgA
  · apply Subtype.ext
    rw [Metric.unitSphere.coe_mul, Metric.unitSphere.coe_mul, Metric.unitSphere.coe_inv, coe_qJ]
    exact conj _ _ hgB

/-! ## T²_N の剛性 -/

theorem rigidT_two (hN : 2 ≤ N) : RigidT N := by
  intro A B hF
  have hFg : FlatT N (gA N A B) (gB N A B) := flat_g N A B hF
  have hTg : TreeT N (gA N A B) (gB N A B) := ⟨tree_gA N A B, tree_gB N A B⟩
  obtain ⟨u, hu1, hu2⟩ := unit_conj _ _ (cf_comm N hN _ _ hFg hTg)
  have hU := uniqT N hN (fun a => u * gA N A B a * u⁻¹) (fun a => u * gB N A B a * u⁻¹)
    (gA N (AV N) (BV N)) (gB N (AV N) (BV N)) (flat_conj N u _ _ hFg) (tree_conj N u _ _ hTg)
    (flat_g N _ _ (flatV N)) ⟨tree_gA N _ _, tree_gB N _ _⟩
    (by show u * gA N A B (pt N (N - 1) 0) * u⁻¹ = _; rw [hu1, genA_V N hN])
    (by show u * gB N A B (pt N 0 (N - 1)) * u⁻¹ = _; rw [hu2, genB_V N hN])
  refine ⟨fun a => (tauT N (AV N) (BV N) a)⁻¹ * u * tauT N A B a, fun a => ⟨?_, ?_⟩⟩
  · have h1 := (hU a).1
    simp only [gA] at h1
    calc _ = (tauT N (AV N) (BV N) a)⁻¹
          * (u * (tauT N A B a * A a * (tauT N A B (a + ev12 N 0))⁻¹) * u⁻¹)
          * tauT N (AV N) (BV N) (a + ev12 N 0) := by group
      _ = (tauT N (AV N) (BV N) a)⁻¹
          * (tauT N (AV N) (BV N) a * AV N a * (tauT N (AV N) (BV N) (a + ev12 N 0))⁻¹)
          * tauT N (AV N) (BV N) (a + ev12 N 0) := by rw [h1]
      _ = AV N a := by group
  · have h1 := (hU a).2
    simp only [gB] at h1
    calc _ = (tauT N (AV N) (BV N) a)⁻¹
          * (u * (tauT N A B a * B a * (tauT N A B (a + ev12 N 1))⁻¹) * u⁻¹)
          * tauT N (AV N) (BV N) (a + ev12 N 1) := by group
      _ = (tauT N (AV N) (BV N) a)⁻¹
          * (tauT N (AV N) (BV N) a * BV N a * (tauT N (AV N) (BV N) (a + ev12 N 1))⁻¹)
          * tauT N (AV N) (BV N) (a + ev12 N 1) := by rw [h1]
      _ = BV N a := by group

theorem rigidT_all : RigidT N := by
  by_cases h : N = 1
  · subst h; exact rigidT_one
  · exact rigidT_two N (by have := NeZero.pos N; omega)

/-- **太い渦の床**（紙の定理 E、|θ| の形）：全ての N ≥ 1 で、仮定の欄なし。
全ての ε > 0 で、十分大きい β について、十分大きい M で
`|θ_{M+1}(β)| ≤ exp(−(M+1)² e^{−β(S_N + ε)})`、`S_N = inf_m S_渦(N, m)`。 -/
theorem thick_vortex_floor : ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_rigidT N (rigidT_all N)

/-- 定義を開いた形 -/
theorem thick_vortex_floor_unfolded : ∀ ε > 0, ∀ᶠ β in Filter.atTop, ∀ᶠ M in Filter.atTop,
    |thetaM N (M + 1) β| ≤ Real.exp (-(((M + 1 : ℕ) : ℝ) ^ 2) * Real.exp (-β * (SN N + ε))) :=
  thick_vortex_floor N

/-- 局所の真空の作用は 0（`RigidL`・`ZeroVortexL` の欄 `SL ≤ 0` を満たす配位が在る） -/
theorem SL_vacL (V : ℕ) : SL N V true (vacL N V) = 0 := by
  unfold SL
  refine Finset.sum_eq_zero fun B _ => ?_
  have h := vac_term N 1 (embP N 1 V 0 B)
  rw [hol_emb, zt_embP] at h
  have e : (vac N 1 ∘ embL N 1 V 0) = vacL N V := rfl
  rw [e] at h
  linarith

/-- T²_N の真空は `FlatT` を満たす（`RigidT` の欄が空でない） -/
theorem flatT_nonempty : ∃ A B : ZMod N × ZMod N → SU2, FlatT N A B := ⟨AV N, BV N, flatV N⟩

end TwistBlocks

#print axioms TwistBlocks.SL_vacL
#print axioms TwistBlocks.flatV
#print axioms TwistBlocks.cf_comm
#print axioms TwistBlocks.uniqT
#print axioms TwistBlocks.rigidT_two
#print axioms TwistBlocks.thick_vortex_floor_unfolded
#print axioms TwistBlocks.rigidT_all
#print axioms TwistBlocks.thick_vortex_floor
