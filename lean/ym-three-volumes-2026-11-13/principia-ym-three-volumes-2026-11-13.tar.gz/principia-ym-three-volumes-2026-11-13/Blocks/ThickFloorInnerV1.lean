import Blocks.ThickFloorLocalV1

/-!
# 局所の模型の点（ずれ < m₀+2）を埋め込むと、塊 b の内部（線の上に無い、塊の番号は b）

`(ii)` の持ち上げの準備：ずれ u₃, u₄ < m₀+2 の局所のリンクは、大きい格子で枠でなく、塊 b の内部のリンク。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M : ℕ) [NeZero N] [NeZero M] (m k : ℕ) [NeZero k]

theorem not_onLine_win [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (c : Fin k) (i : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (u : ℕ) (hu : u < m₀ + 2) :
    ¬ onLine M m k (((c.val * m + 1 + i * (m₀ + 2) : ℕ) : ZMod M) + ((u : ℕ) : ZMod M)) := by
  rintro ⟨h1, _⟩
  rw [val_cast_win M m k hM m₀ c i hi u hu] at h1
  have hr : 1 + i * (m₀ + 2) + u < m := by
    rw [Nat.add_mul, one_mul] at hi
    generalize i * (m₀ + 2) = B at *
    omega
  have e : c.val * m + 1 + i * (m₀ + 2) + u = (1 + i * (m₀ + 2) + u) + c.val * m := by ring
  rw [e, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hr] at h1
  omega

/-- 局所のリンク（ずれ < m₀+2）を埋め込むと、枠でなく、塊は b -/
theorem embL_inner [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (hj : (j + 1) * (m₀ + 2) < m) (ℓ : LLink N (m₀ + 2))
    (h3 : (ℓ.1.2.1 : ℕ) < m₀ + 2) (h4 : (ℓ.1.2.2 : ℕ) < m₀ + 2) :
    ¬ fr N M m k (embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ) ∧
      blk2 M m k (embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ).1.2 = b := by
  have n3 := not_onLine_win M m k hM m₀ b.1 i hi _ h3
  have n4 := not_onLine_win M m k hM m₀ b.2 j hj _ h4
  constructor
  · unfold fr
    have e2 : (embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ).2 = ℓ.2 := rfl
    by_cases h2 : ℓ.2 = 2
    · rw [if_pos (e2.trans h2)]; exact n4
    · rw [if_neg (fun h => h2 (e2.symm.trans h))]
      by_cases h3' : ℓ.2 = 3
      · rw [if_pos (e2.trans h3')]; exact n3
      · rw [if_neg (fun h => h3' (e2.symm.trans h))]
        rintro (h | h)
        · exact n3 h
        · exact n4 h
  · simp only [embL, emb, wc, blk2]
    rw [q_win M m k hM m₀ b.1 i hi _ h3, q_win M m k hM m₀ b.2 j hj _ h4]

end TwistBlocks

#print axioms TwistBlocks.embL_inner
