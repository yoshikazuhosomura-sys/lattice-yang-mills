import Blocks.TheoremEV2
import Blocks.LaplaceV1

/-!
# 段 3 を塊の作用に：Lipschitz（紙の補題 3.2）と、枠に一様な粗い Laplace の下界

紙： 補題 3.2（塊の作用は内部の変数について `L = 4·#升` で Lipschitz、L は枠に依らない）。
`block_laplace_lower`：全ての枠 F・内部の点 y₀・β ≥ 0・δ > 0 で
  `e^{−β(S_B(F,y₀) + δ)} · μ₁(δ/L)^{#内部} ≤ ∫_{内部} e^{−β S_B(F, y)}`（L・#内部 は F に依らない）。
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

local notation "ℍr" => Quaternion ℝ

theorem abs_re_le_norm (q : ℍr) : |q.re| ≤ ‖q‖ := by
  have h : q.re * q.re ≤ ‖q‖ * ‖q‖ := by
    rw [← Quaternion.normSq_eq_norm_mul_self, Quaternion.normSq_def']
    nlinarith [sq_nonneg q.imI, sq_nonneg q.imJ, sq_nonneg q.imK]
  have h2 : q.re ^ 2 ≤ ‖q‖ ^ 2 := by rw [sq, sq]; exact h
  have := sq_le_sq.mp h2
  rwa [abs_norm] at this

theorem norm_mul4_sub (p q r s p' q' r' s' : ℍr) (hq : ‖q‖ = 1) (hr : ‖r‖ = 1) (hs : ‖s‖ = 1)
    (hp' : ‖p'‖ = 1) (hq' : ‖q'‖ = 1) (hr' : ‖r'‖ = 1) :
    ‖p * q * r * s - p' * q' * r' * s'‖ ≤ ‖p - p'‖ + ‖q - q'‖ + ‖r - r'‖ + ‖s - s'‖ := by
  have e : p * q * r * s - p' * q' * r' * s'
      = (p - p') * q * r * s + p' * (q - q') * r * s + p' * q' * (r - r') * s
        + p' * q' * r' * (s - s') := by noncomm_ring
  rw [e]
  refine (norm_add_le _ _).trans (add_le_add ((norm_add_le _ _).trans (add_le_add
    ((norm_add_le _ _).trans (add_le_add ?_ ?_)) ?_)) ?_)
  · rw [norm_mul, norm_mul, norm_mul, hq, hr, hs]; ring_nf; exact le_refl _
  · rw [norm_mul, norm_mul, norm_mul, hp', hr, hs]; ring_nf; exact le_refl _
  · rw [norm_mul, norm_mul, norm_mul, hp', hq', hs]; ring_nf; exact le_refl _
  · rw [norm_mul, norm_mul, norm_mul, hp', hq', hr']; ring_nf; exact le_refl _

variable (N M m k : ℕ) [NeZero N] [NeZero M] [NeZero k]

theorem norm_link_sub (ω ω' : Link N M → SU2) (ℓ : Link N M) :
    ‖(ω ℓ : ℍr) - (ω' ℓ : ℍr)‖ ≤ dist ω ω' := by
  rw [← dist_eq_norm, ← Subtype.dist_eq]; exact dist_le_pi_dist ω ω' ℓ

/-- `Re U_B` は配位について 4-Lipschitz（sup の距離） -/
theorem re_hol_lipschitz (ω ω' : Link N M → SU2) (B : Plaq N M) :
    |(hol N M ω B).re - (hol N M ω' B).re| ≤ 4 * dist ω ω' := by
  have hn : ∀ (u : Link N M → SU2) ℓ, ‖(u ℓ : ℍr)‖ = 1 := fun u ℓ => norm_eq_of_mem_sphere (u ℓ)
  have hns : ∀ (u : Link N M → SU2) ℓ, ‖star (u ℓ : ℍr)‖ = 1 := fun u ℓ => by
    rw [norm_star]; exact hn u ℓ
  rw [← Quaternion.re_sub]
  refine (abs_re_le_norm _).trans ?_
  unfold hol
  refine (norm_mul4_sub _ _ _ _ _ _ _ _ (hn ω _) (hns ω _) (hns ω _) (hn ω' _) (hn ω' _)
    (hns ω' _)).trans ?_
  have h1 := norm_link_sub N M ω ω' (l1 N M B)
  have h2 := norm_link_sub N M ω ω' (l2 N M B)
  have h3 := norm_link_sub N M ω ω' (l3 N M B)
  have h4 := norm_link_sub N M ω ω' (l4 N M B)
  rw [← star_sub, norm_star, ← star_sub, norm_star]
  linarith

/-- 塊の作用は `L = 4·#{塊の升}` で Lipschitz（η の符号は |η| ≤ 1） -/
theorem actB_lipschitz (n12 : Bool) (b : Fin k × Fin k) (e : Pt M → ℝ) (he : ∀ y, |e y| ≤ 1)
    (ω ω' : Link N M → SU2) :
    |actB N M m k n12 b e ω - actB N M m k n12 b e ω'|
      ≤ (4 * ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card : ℝ)) * dist ω ω' := by
  unfold actB
  rw [← Finset.sum_sub_distrib]
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  have hterm : ∀ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b),
      |(1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re)
        - (1 - zt N M n12 false B * etaB N M e B * (hol N M ω' B).re)| ≤ 4 * dist ω ω' := by
    intro B _
    have hz : |zt N M n12 false B * etaB N M e B| ≤ 1 := by
      rw [abs_mul, abs_zt, one_mul]
      unfold etaB; split_ifs
      · exact he _
      · simp
    have e1 : (1 - zt N M n12 false B * etaB N M e B * (hol N M ω B).re)
        - (1 - zt N M n12 false B * etaB N M e B * (hol N M ω' B).re)
        = -(zt N M n12 false B * etaB N M e B) * ((hol N M ω B).re - (hol N M ω' B).re) := by ring
    rw [e1, abs_mul, abs_neg]
    calc |zt N M n12 false B * etaB N M e B| * |(hol N M ω B).re - (hol N M ω' B).re|
        ≤ 1 * (4 * dist ω ω') :=
          mul_le_mul hz (re_hol_lipschitz N M ω ω' B) (abs_nonneg _) zero_le_one
      _ = 4 * dist ω ω' := one_mul _
  refine (Finset.sum_le_sum hterm).trans ?_
  rw [Finset.sum_const, nsmul_eq_mul]
  ring_nf; exact le_refl _

/-- 貼り合わせは内部について 1-Lipschitz -/
theorem dist_glueB_le (b : Fin k × Fin k) (F : Frame N M m k → SU2) (y y' : Inner N M m k b → SU2) :
    dist (glueB N M m k b F y) (glueB N M m k b F y') ≤ dist y y' := by
  refine (dist_pi_le_iff dist_nonneg).mpr fun ℓ => ?_
  unfold glueB BlockFubini.glue
  by_cases h : fr N M m k ℓ
  · simp only [h, dite_true, dist_self]; exact dist_nonneg
  · simp only [h, dite_false]
    by_cases h' : blkL N M m k ⟨ℓ, h⟩ = b
    · simp only [h', dite_true]; exact dist_le_pi_dist y y' _
    · simp only [h', dite_false, dist_self]; exact dist_nonneg

/-- 符号の場 `etaSign` は |η| ≤ 1 -/
theorem abs_etaSign_le (b : Fin k × Fin k) (s : Bool) (y : Pt M) : |etaSign M m k b s y| ≤ 1 := by
  unfold etaSign etaAt
  split_ifs <;> simp
  all_goals (split_ifs <;> simp)

/-- **段 3（塊の作用、枠に一様な粗い Laplace の下界）** -/
theorem block_laplace_lower (n12 : Bool) (b : Fin k × Fin k) (s : Bool) (F : Frame N M m k → SU2)
    (y0 : Inner N M m k b → SU2) {β δ : ℝ} (hβ : 0 ≤ β) (hδ : 0 < δ) :
    let L := 4 * ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card : ℝ) + 1
    Real.exp (-β * (actB N M m k n12 b (etaSign M m k b s) (glueB N M m k b F y0) + δ))
        * (haarSU2 (Metric.ball 1 (δ / L))).toReal ^ Fintype.card (Inner N M m k b)
      ≤ ∫ y, Real.exp (-β * actB N M m k n12 b (etaSign M m k b s) (glueB N M m k b F y))
          ∂(Measure.pi fun _ : Inner N M m k b => haarSU2) := by
  intro L
  have hL : 0 < L := by positivity
  have hcont : Continuous fun ω : Link N M → SU2 => actB N M m k n12 b (etaSign M m k b s) ω := by
    unfold actB
    exact continuous_finsetSum _ fun B _ =>
      continuous_const.sub (continuous_const.mul (continuous_hol_re N M B))
  have hglue : Continuous (glueB N M m k b F) :=
    LipschitzWith.continuous (K := 1) (LipschitzWith.of_dist_le_mul fun y y' => by
      simpa using dist_glueB_le N M m k b F y y')
  refine CoarseLaplace.laplace_lower _ (hcont.comp hglue) hL (fun y y' => ?_) hβ hδ y0
  refine (actB_lipschitz N M m k n12 b _ (abs_etaSign_le M m k b s) _ _).trans ?_
  have hd := dist_glueB_le N M m k b F y y'
  have hc : (0 : ℝ) ≤ 4 * ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card : ℝ) := by
    positivity
  calc (4 * ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card : ℝ))
        * dist (glueB N M m k b F y) (glueB N M m k b F y')
      ≤ (4 * ((univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).card : ℝ)) * dist y y' :=
        mul_le_mul_of_nonneg_left hd hc
    _ ≤ L * dist y y' := by
        have := dist_nonneg (x := y) (y := y'); simp only [L]; nlinarith

end TwistBlocks

#print axioms TwistBlocks.block_laplace_lower
#print axioms TwistBlocks.actB_lipschitz
