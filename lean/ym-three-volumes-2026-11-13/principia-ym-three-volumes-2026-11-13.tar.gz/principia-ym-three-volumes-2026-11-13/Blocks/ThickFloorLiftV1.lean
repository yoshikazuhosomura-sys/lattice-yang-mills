import Blocks.ThickFloorWinLinkV1
import Blocks.ThickFloorKappaEqV1

/-!
# 持ち上げの準備：埋め込みは単射、窓の和は局所の升の和、η つきの局所の作用
-/

open Finset BigOperators MeasureTheory CoveringInequality TwistedPlane TwistedWilson

namespace TwistBlocks

variable (N M : ℕ) [NeZero N] [NeZero M]

/-- 局所の内部のリンク（ずれ u₃, u₄ ∈ [1, V−1]） -/
def intL (V : ℕ) (ℓ : LLink N V) : Prop :=
  1 ≤ (ℓ.1.2.1 : ℕ) ∧ (ℓ.1.2.1 : ℕ) < V ∧ 1 ≤ (ℓ.1.2.2 : ℕ) ∧ (ℓ.1.2.2 : ℕ) < V

/-- 局所の一枚の反転の場 -/
def flipAt (V : ℕ) (P0 : Fin V × Fin V) : Fin V × Fin V → ℝ := fun P => if P = P0 then -1 else 1

/-- η つきの局所の作用 -/
noncomputable def SLe (V : ℕ) (n12 : Bool) (ηl : Fin V × Fin V → ℝ) (ωl : LLink N V → SU2) : ℝ :=
  ∑ B : LPlaq N V, (1 - zL N V n12 B * (if B.2 = p23 then ηl B.1.2 else 1) * (holL N V ωl B).re)

variable (m k : ℕ) [NeZero k]

theorem cast_inj_small (u u' : ℕ) (hu : u < M) (hu' : u' < M) (h : (u : ZMod M) = (u' : ZMod M)) :
    u = u' := by
  have := congrArg ZMod.val h
  rwa [ZMod.val_natCast, ZMod.val_natCast, Nat.mod_eq_of_lt hu, Nat.mod_eq_of_lt hu'] at this

theorem embL_inj [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (ℓ ℓ' : LLink N (m₀ + 2))
    (h : embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ = embL N M (m₀ + 2) (wc M m k m₀ b i j) ℓ') :
    ℓ = ℓ' := by
  have hmM : m₀ + 2 < M := by
    have h1 : m ≤ M := by
      have := NeZero.pos k
      calc m = m * 1 := (mul_one m).symm
        _ ≤ m * k := Nat.mul_le_mul_left m this
        _ ≤ M := hM
    rw [Nat.add_mul, one_mul] at hi
    omega
  obtain ⟨⟨a, u3, u4⟩, μ⟩ := ℓ
  obtain ⟨⟨a', u3', u4'⟩, μ'⟩ := ℓ'
  simp only [embL, emb, Prod.mk.injEq] at h
  obtain ⟨⟨ha, h3, h4⟩, hμ⟩ := h
  have e3 := cast_inj_small M _ _ (by omega) (by omega) (add_left_cancel h3)
  have e4 := cast_inj_small M _ _ (by omega) (by omega) (add_left_cancel h4)
  have : u3 = u3' := Fin.ext e3
  have : u4 = u4' := Fin.ext e4
  subst ha; subst hμ
  simp_all

/-- 窓の升の和 = 局所の升の和（埋め込みを通して） -/
theorem sum_winP [NeZero m] (hM : m * k ≤ M) (m₀ : ℕ) (b : Fin k × Fin k) (i j : ℕ)
    (hi : (i + 1) * (m₀ + 2) < m) (hj : (j + 1) * (m₀ + 2) < m) (f : Plaq N M → ℝ) :
    ∑ B ∈ winP N M m k m₀ b (i, j), f B
      = ∑ Bl : LPlaq N (m₀ + 2), f (embP N M (m₀ + 2) (wc M m k m₀ b i j) Bl) := by
  set c := wc M m k m₀ b i j
  have himg : winP N M m k m₀ b (i, j) = univ.image (embP N M (m₀ + 2) c) := by
    ext B
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_image]
    constructor
    · rintro ⟨h3, h4⟩
      obtain ⟨u3, hu3⟩ := win_of_inWin M m k hM m₀ b.1 i hi _ h3
      obtain ⟨u4, hu4⟩ := win_of_inWin M m k hM m₀ b.2 j hj _ h4
      refine ⟨((B.1.1, (u3, u4)), B.2), ?_⟩
      simp only [embP, emb, c, wc, Fin.val_castSucc]
      rw [← hu3, ← hu4]
    · rintro ⟨Bl, rfl⟩
      simp only [embP, emb, c, wc, Fin.val_castSucc]
      exact ⟨inWin_of_win M m k hM m₀ b.1 i hi _ Bl.1.2.1.isLt,
        inWin_of_win M m k hM m₀ b.2 j hj _ Bl.1.2.2.isLt⟩
  rw [himg, Finset.sum_image (fun x _ y _ h => embP_inj N M m k hM m₀ b i j hi hj x y h)]

/-- **局所の言明**（M・m・b・窓に依らない）：局所の作用が δ 未満なら、局所の内部と η の一枚を替えて、
費用は `S + ε` 以下 -/
def LocalVortexL (N : ℕ) [NeZero N] (m₀ : ℕ) (S : ℝ) : Prop :=
  ∀ ε > 0, ∃ δ > 0, ∀ ωl : LLink N (m₀ + 2) → SU2, SL N (m₀ + 2) true ωl < δ →
    ∃ (ωl' : LLink N (m₀ + 2) → SU2) (P0 : Fin (m₀ + 2) × Fin (m₀ + 2)),
      (∀ ℓ, ¬ intL N (m₀ + 2) ℓ → ωl' ℓ = ωl ℓ) ∧
      SLe N (m₀ + 2) true (flipAt (m₀ + 2) P0) ωl' ≤ SL N (m₀ + 2) true ωl + S + ε

theorem zt_embP (V : ℕ) (c : Pt M) (n12 : Bool) (Bl : LPlaq N V) :
    zt N M n12 false (embP N M V c Bl) = zL N V n12 Bl := by
  unfold zt zL embP emb tw
  split_ifs <;> simp_all

set_option maxHeartbeats 1000000 in
/-- **持ち上げ**：局所の言明から `LocalVortex`（M に一様な δ） -/
theorem localVortex_of_local (N : ℕ) [NeZero N] (m₀ : ℕ) (S : ℝ) (hL : LocalVortexL N m₀ S) :
    LocalVortex N m₀ S := by
  classical
  intro ε hε
  obtain ⟨δ, hδ, hloc⟩ := hL ε hε
  refine ⟨δ, hδ, fun M m k _ _ _ hM hk b F y t i j hi hj hw => ?_⟩
  set c := wc M m k m₀ b i j with hc
  set ωl : LLink N (m₀ + 2) → SU2 := glueB N M m k b F y ∘ embL N M (m₀ + 2) c with hωl
  have hSL : SL N (m₀ + 2) true ωl < δ := by
    rw [hωl, ← actW_local N M m k hM true m₀ b i j hi hj t]; exact hw
  obtain ⟨ωl', P0, hag, hcost⟩ := hloc ωl hSL
  -- 内部の配位 y'
  let y' : Inner N M m k b → SU2 := fun jj =>
    if h : ∃ ℓ, intL N (m₀ + 2) ℓ ∧ embL N M (m₀ + 2) c ℓ = jj.1.1 then ωl' h.choose else y jj
  have G1 : ∀ x : Link N M, (∀ ℓ, intL N (m₀ + 2) ℓ → embL N M (m₀ + 2) c ℓ ≠ x) →
      glueB N M m k b F y' x = glueB N M m k b F y x := by
    intro x hx
    unfold glueB BlockFubini.glue
    by_cases hf : fr N M m k x
    · rw [dif_pos hf, dif_pos hf]
    · rw [dif_neg hf, dif_neg hf]
      by_cases hb : blkL N M m k ⟨x, hf⟩ = b
      · rw [dif_pos hb, dif_pos hb]
        simp only [y']
        rw [dif_neg]
        rintro ⟨ℓ, hl, he⟩; exact hx ℓ hl he
      · rw [dif_neg hb, dif_neg hb]
  have G2 : ∀ ℓ, intL N (m₀ + 2) ℓ → glueB N M m k b F y' (embL N M (m₀ + 2) c ℓ) = ωl' ℓ := by
    intro ℓ hl
    obtain ⟨hnf, hb⟩ := embL_inner N M m k hM m₀ b i j hi hj ℓ hl.2.1 hl.2.2.2
    unfold glueB BlockFubini.glue
    rw [dif_neg hnf, dif_pos (show blkL N M m k ⟨_, hnf⟩ = b from hb)]
    have hex : ∃ ℓ', intL N (m₀ + 2) ℓ' ∧ embL N M (m₀ + 2) c ℓ' = embL N M (m₀ + 2) c ℓ :=
      ⟨ℓ, hl, rfl⟩
    simp only [y']
    rw [dif_pos hex]
    congr 1
    exact embL_inj N M m k hM m₀ b i j hi _ _ hex.choose_spec.2
  have G3 : glueB N M m k b F y' ∘ embL N M (m₀ + 2) c = ωl' := by
    funext ℓ
    by_cases hl : intL N (m₀ + 2) ℓ
    · exact G2 ℓ hl
    · simp only [Function.comp]
      rw [G1 _ (fun ℓ' hl' he => hl ((embL_inj N M m k hM m₀ b i j hi ℓ' ℓ he) ▸ hl')), hag ℓ hl]
      rfl
  -- 反転の点
  set pt0 : Pt M := (c.1 + (((P0.1 : ℕ)) : ZMod M), c.2 + (((P0.2 : ℕ)) : ZMod M)) with hpt0
  have hpt0b : blk2 M m k pt0 = b := by
    simp only [blk2, pt0, c, wc]
    rw [q_win M m k hM m₀ b.1 i hi _ P0.1.isLt, q_win M m k hM m₀ b.2 j hj _ P0.2.isLt]
  have hpt0w : ∀ B : Plaq N M, B.1.2 = pt0 → B ∈ winP N M m k m₀ b (i, j) := by
    intro B hB
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and]
    rw [hB]
    exact ⟨inWin_of_win M m k hM m₀ b.1 i hi _ P0.1.isLt, inWin_of_win M m k hM m₀ b.2 j hj _ P0.2.isLt⟩
  let σ' : Fib M m k b → ℤˣ := fun P => canU M m k b t P.1 * (if P.1 = pt0 then -1 else 1)
  have hsgn : ∀ P : Fib M m k b, sgn (σ' P) = sgn (canU M m k b t P.1) * (if P.1 = pt0 then -1 else 1) := by
    intro P; simp only [σ']; rw [sgn_mul']; split_ifs <;> simp [sgn]
  have hclass : (∏ P, sgn (σ' P)) = (if t then 1 else -1) := by
    simp only [hsgn, Finset.prod_mul_distrib, prod_can M m k hM b t]
    have : (∏ P : Fib M m k b, (if P.1 = pt0 then (-1 : ℝ) else 1))
        = ∏ P : Fib M m k b, (if P = ⟨pt0, hpt0b⟩ then (-1 : ℝ) else 1) := by
      refine Finset.prod_congr rfl fun P _ => ?_
      by_cases h : P.1 = pt0
      · rw [if_pos h, if_pos (Subtype.ext h)]
      · rw [if_neg h, if_neg (fun e => h (congrArg Subtype.val e))]
    rw [this, Finset.prod_ite_eq', if_pos (Finset.mem_univ _)]
    cases t <;> norm_num
  have hext : ∀ x : Pt M, ext M m k b σ' x = etaSign M m k b t x * (if x = pt0 then -1 else 1) := by
    intro x
    have hc0 := congrFun (ext_can M m k hM b t) x
    unfold ext at hc0 ⊢
    by_cases h : blk2 M m k x = b
    · rw [dif_pos h] at hc0 ⊢
      rw [hsgn, hc0]
    · rw [dif_neg h] at hc0 ⊢
      have hx : x ≠ pt0 := fun e => h (e ▸ hpt0b)
      rw [if_neg hx, ← hc0]; ring
  refine ⟨y', σ', hclass, ?_⟩
  -- 作用の比べ
  have hsub : winP N M m k m₀ b (i, j) ⊆ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b) := by
    intro B hB
    simp only [winP, Finset.mem_filter, Finset.mem_univ, true_and] at hB ⊢
    exact Prod.ext hB.1.1 hB.2.1
  have split : ∀ f : Plaq N M → ℝ,
      ∑ B ∈ univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b), f B
        = ∑ B ∈ winP N M m k m₀ b (i, j), f B
          + ∑ B ∈ (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
              (fun B => B ∉ winP N M m k m₀ b (i, j)), f B := by
    intro f
    rw [← Finset.sum_filter_add_sum_filter_not _ (fun B => B ∈ winP N M m k m₀ b (i, j))]
    congr 1
    congr 1
    ext B
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨_, h⟩; exact h
    · intro h; exact ⟨Finset.mem_filter.mp (hsub h), h⟩
  have off : ∀ B ∈ (univ.filter (fun B : Plaq N M => blk2 M m k B.1.2 = b)).filter
      (fun B => B ∉ winP N M m k m₀ b (i, j)),
      (1 - zt N M true false B * etaB N M (ext M m k b σ') B * (hol N M (glueB N M m k b F y') B).re)
        = (1 - zt N M true false B * etaB N M (etaSign M m k b t) B
            * (hol N M (glueB N M m k b F y) B).re) := by
    intro B hB
    have hnw : B ∉ winP N M m k m₀ b (i, j) := (Finset.mem_filter.mp hB).2
    have nl : ∀ x, (x = l1 N M B ∨ x = l2 N M B ∨ x = l3 N M B ∨ x = l4 N M B) →
        glueB N M m k b F y' x = glueB N M m k b F y x := by
      intro x hx
      refine G1 x fun ℓ hl he => hnw ?_
      refine mem_winP_of_link N M m k hM m₀ b i j hi hj ℓ hl.1 hl.2.1 hl.2.2.1 hl.2.2.2 B ?_
      rcases hx with rfl | rfl | rfl | rfl
      · exact Or.inl he.symm
      · exact Or.inr (Or.inl he.symm)
      · exact Or.inr (Or.inr (Or.inl he.symm))
      · exact Or.inr (Or.inr (Or.inr he.symm))
    have hh : hol N M (glueB N M m k b F y') B = hol N M (glueB N M m k b F y) B := by
      unfold hol
      rw [nl _ (Or.inl rfl), nl _ (Or.inr (Or.inl rfl)), nl _ (Or.inr (Or.inr (Or.inl rfl))),
        nl _ (Or.inr (Or.inr (Or.inr rfl)))]
    have he : etaB N M (ext M m k b σ') B = etaB N M (etaSign M m k b t) B := by
      unfold etaB
      split_ifs
      · rw [hext, if_neg (fun e => hnw (hpt0w B e)), mul_one]
      · rfl
    rw [hh, he]
  have win_old : ∑ B ∈ winP N M m k m₀ b (i, j),
      (1 - zt N M true false B * etaB N M (etaSign M m k b t) B * (hol N M (glueB N M m k b F y) B).re)
        = SL N (m₀ + 2) true ωl := by
    rw [hωl, ← actW_local N M m k hM true m₀ b i j hi hj t]; rfl
  have win_new : ∑ B ∈ winP N M m k m₀ b (i, j),
      (1 - zt N M true false B * etaB N M (ext M m k b σ') B * (hol N M (glueB N M m k b F y') B).re)
        = SLe N (m₀ + 2) true (flipAt (m₀ + 2) P0) ωl' := by
    rw [sum_winP N M m k hM m₀ b i j hi hj]
    unfold SLe
    refine Finset.sum_congr rfl fun Bl _ => ?_
    rw [hol_emb, G3]
    have hz := zt_embP N M (m₀ + 2) c true Bl
    have heta : etaB N M (ext M m k b σ') (embP N M (m₀ + 2) c Bl)
        = (if Bl.2 = p23 then flipAt (m₀ + 2) P0 Bl.1.2 else 1) := by
      unfold etaB
      by_cases h23 : Bl.2 = p23
      · have h23' : (embP N M (m₀ + 2) c Bl).2 = p23 := h23
        rw [if_pos h23', if_pos h23, hext]
        have hnc : (embP N M (m₀ + 2) c Bl).1.2 ≠ corner M m k b := by
          intro hc'
          have e := congrArg (fun p : Pt M => p.1.val) hc'
          simp only [embP, emb, c, wc, corner, Fin.val_castSucc] at e
          rw [val_cast_win M m k hM m₀ b.1 i hi _ Bl.1.2.1.isLt, ZMod.val_natCast,
            Nat.mod_eq_of_lt] at e
          · omega
          · have := base_lt M m k hM m₀ b.1 i hi 0 (by omega)
            omega
        have hes : etaSign M m k b t (embP N M (m₀ + 2) c Bl).1.2 = 1 := by
          unfold etaSign etaAt
          cases t
          · simp
          · simp only [if_true]; rw [if_neg hnc]
        rw [hes, one_mul]
        unfold flipAt
        have hiff : (embP N M (m₀ + 2) c Bl).1.2 = pt0 ↔ Bl.1.2 = P0 := by
          have hmM : m₀ + 2 < M := by
            have h1 : m ≤ M := by
              have := NeZero.pos k
              calc m = m * 1 := (mul_one m).symm
                _ ≤ m * k := Nat.mul_le_mul_left m this
                _ ≤ M := hM
            have := hi
            rw [Nat.add_mul, one_mul] at this
            omega
          simp only [embP, emb, pt0, Fin.val_castSucc, Prod.mk.injEq]
          constructor
          · rintro ⟨e1, e2⟩
            have f1 := cast_inj_small M _ _ (by have := Bl.1.2.1.isLt; omega)
              (by have := P0.1.isLt; omega) (add_left_cancel e1)
            have f2 := cast_inj_small M _ _ (by have := Bl.1.2.2.isLt; omega)
              (by have := P0.2.isLt; omega) (add_left_cancel e2)
            exact Prod.ext (Fin.ext f1) (Fin.ext f2)
          · rintro e; rw [e]; exact ⟨rfl, rfl⟩
        by_cases hq : Bl.1.2 = P0
        · rw [if_pos (hiff.mpr hq), if_pos hq]
        · rw [if_neg (fun e => hq (hiff.mp e)), if_neg hq]
      · have h23' : ¬ (embP N M (m₀ + 2) c Bl).2 = p23 := h23
        rw [if_neg h23', if_neg h23]
    rw [hz, heta]
  unfold actB
  have e1 := split (fun B => 1 - zt N M true false B * etaB N M (ext M m k b σ') B
    * (hol N M (glueB N M m k b F y') B).re)
  have e2 := split (fun B => 1 - zt N M true false B * etaB N M (etaSign M m k b t) B
    * (hol N M (glueB N M m k b F y) B).re)
  have e3 := Finset.sum_congr rfl off
  rw [e1, e2, win_new, win_old, e3]
  linarith

/-- 太い渦の床は、局所の言明 `LocalVortexL`（M に依らない）だけに条件つき -/
theorem thick_vortex_floor_abs_of_localL (N : ℕ) [NeZero N]
    (hL : ∀ m₀ : ℕ+, LocalVortexL N m₀ (Svortex N m₀)) : ThickVortexFloorAbs N :=
  thick_vortex_floor_abs_of_local N fun m₀ => localVortex_of_local N m₀ _ (hL m₀)

end TwistBlocks

#print axioms TwistBlocks.embL_inj
#print axioms TwistBlocks.sum_winP
#print axioms TwistBlocks.localVortex_of_local
#print axioms TwistBlocks.thick_vortex_floor_abs_of_localL
