import Blocks.ThickFloorHalfSplitV1

/-!
# θ ≥ 0 を格子で（M が偶数、全ての実の β）

紙：太い渦の床の紙の段 1 の「θ ≥ 0」。時間の向き x₄ の鏡映（二枚の面 x₄ = 0、x₄ = M/2）で、
半分の重み a_η を取り、g = a_1 − a_{T}（T は (3,4) の升 (x₃,x₄) = (0,0) だけ −1）について
鏡映正値性 0 ≤ ∫ g(Θω) g(ω) を展開すると
0 ≤ Z[1] − Z[T] − Z[T′] + Z[T·T′]（T′ は鏡映した位置 (0, −1)）、
η の表示（`ZEta_flip_any`・`ZEta_parity`）で Z[T] = Z[T′] = Z₁、Z[T·T′] = Z₀。よって Z₁ ≤ Z₀。
-/

open Finset MeasureTheory TwistedWilson TwistedPlane

namespace HalfSplit

variable (N M : ℕ) [NeZero N] [NeZero M]

theorem val_neg_one (hM2 : 2 ≤ M) : ((-1 : ZMod M)).val = M - 1 := by
  have h := val_neg_add_one M 0
  rw [zero_add, ZMod.val_zero] at h
  omega

theorem glue_key (y : Pt M) : ((y.1, -(y.2 + 1)) : Pt M) = 0 ↔ y = (0, -1) := by
  constructor
  · intro h
    have h1 := congrArg Prod.fst h
    have h2 := congrArg Prod.snd h
    simp only [Prod.fst_zero, Prod.snd_zero] at h1 h2
    refine Prod.ext h1 ?_
    show y.2 = -1
    linear_combination -h2
  · rintro rfl
    simp

theorem not_upper_of (hM2 : 2 ≤ M) (y : Pt M) (hy : y = (0, -1)) : ¬ 2 * y.2.val < M := by
  subst hy
  show ¬ 2 * ((-1 : ZMod M)).val < M
  rw [val_neg_one M hM2]; omega

theorem glue_one_one : glueEta M (fun _ => (1 : ℝ)) (fun _ => 1) = fun _ => 1 := by
  funext y; simp [glueEta]

theorem glue_T_one : glueEta M (etaAt M 0) (fun _ => 1) = etaAt M 0 := by
  funext y
  unfold glueEta
  by_cases hy : y = 0
  · subst hy
    have : 2 * ((0 : Pt M).2).val < M := by
      simp only [Prod.snd_zero, ZMod.val_zero, mul_zero]; exact Nat.pos_of_ne_zero (NeZero.ne M)
    rw [if_pos this]
  · have : etaAt M 0 y = 1 := by simp [etaAt, hy]
    split_ifs <;> simp [this]

theorem glue_one_T (hM2 : 2 ≤ M) : glueEta M (fun _ => 1) (etaAt M 0) = etaAt M (0, -1) := by
  funext y
  unfold glueEta etaAt
  by_cases hy : y = (0, -1)
  · rw [if_neg (not_upper_of M hM2 y hy), if_pos ((glue_key M y).mpr hy), if_pos hy]
  · rw [if_neg hy, if_neg (fun h => hy ((glue_key M y).mp h))]
    split_ifs <;> rfl

theorem glue_T_T (hM2 : 2 ≤ M) :
    glueEta M (etaAt M 0) (etaAt M 0) = fun y => etaAt M 0 y * etaAt M (0, -1) y := by
  funext y
  unfold glueEta
  by_cases hc : 2 * y.2.val < M
  · rw [if_pos hc]
    have : y ≠ (0, -1) := fun h => not_upper_of M hM2 y h hc
    simp [etaAt, this]
  · rw [if_neg hc]
    have h0 : y ≠ 0 := by
      rintro rfl
      apply hc
      simp only [Prod.snd_zero, ZMod.val_zero, mul_zero]; exact Nat.pos_of_ne_zero (NeZero.ne M)
    simp only [etaAt, if_neg h0, one_mul]
    by_cases hy : y = (0, -1)
    · rw [if_pos ((glue_key M y).mpr hy), if_pos hy]
    · rw [if_neg (fun h => hy ((glue_key M y).mp h)), if_neg hy]

theorem prod_etaAt_any (P : Pt M) : ∏ y : Pt M, etaAt M P y = -1 := by
  simp [etaAt, Finset.prod_ite_eq']

theorem abs_aW_le (β : ℝ) (η : Pt M → ℝ) (ω : Link N M → SU2) :
    |aW N M β η ω| ≤ Real.exp (|β| * ∑ B, |ca N M η B|) := exp_SB_le N M β _ ω

/-- 鏡映正値性に入れる関数 `g = a_1 − a_T` -/
noncomputable def gTw (β : ℝ) (ω : Link N M → SU2) : ℝ :=
  aW N M β (fun _ => 1) ω - aW N M β (etaAt M 0) ω

/-- **Z₁ ≤ Z₀**（M が偶数、全ての実の β、背景 n₁₂ = 1） -/
theorem Z1_le_Z0 (hM : M % 2 = 0) (β : ℝ) : ZW N M β true true ≤ ZW N M β true false := by
  have hM2 : 2 ≤ M := by have := NeZero.ne M; omega
  have hg : Measurable (gTw N M β) :=
    ((continuous_exp_SB N M β _).sub (continuous_exp_SB N M β _)).measurable
  have hgC : ∀ ω, |gTw N M β ω| ≤ Real.exp (|β| * ∑ B, |ca N M (fun _ => 1) B|)
      + Real.exp (|β| * ∑ B, |ca N M (etaAt M 0) B|) := fun ω =>
    (abs_sub _ _).trans (add_le_add (abs_aW_le N M β _ ω) (abs_aW_le N M β _ ω))
  have hdep : ∀ ω ω', (∀ ℓ, fixL N M ℓ ∨ posL N M ℓ → ω ℓ = ω' ℓ) → gTw N M β ω = gTw N M β ω' := by
    intro ω ω' h
    unfold gTw aW
    rw [SB_ca_dep N M hM _ ω ω' h, SB_ca_dep N M hM _ ω ω' h]
  have hpos := half_pairing_nonneg N M hM (gTw N M β) hg _ hgC hdep
  have hexp : ∀ ω, gTw N M β (Th N M ω) * gTw N M β ω
      = wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω - wE N M β (etaAt M (0, -1)) ω
        + wE N M β (fun y => etaAt M 0 y * etaAt M (0, -1) y) ω := by
    intro ω
    have h11 := aW_mul_refl N M hM β (fun _ => 1) (fun _ => 1) ω
    have hT1 := aW_mul_refl N M hM β (etaAt M 0) (fun _ => 1) ω
    have h1T := aW_mul_refl N M hM β (fun _ => 1) (etaAt M 0) ω
    have hTT := aW_mul_refl N M hM β (etaAt M 0) (etaAt M 0) ω
    rw [glue_one_one] at h11
    rw [glue_T_one] at hT1
    rw [glue_one_T M hM2] at h1T
    rw [glue_T_T M hM2] at hTT
    unfold gTw
    rw [← h11, ← hT1, ← h1T, ← hTT]
    ring
  rw [integral_congr_ae (Filter.Eventually.of_forall hexp)] at hpos
  have i := fun η => integrable_wE N M β η
  have h2 : Integrable (fun ω => wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω) (haarCfg N M) :=
    (i _).sub (i _)
  have h1 : Integrable (fun ω => wE N M β (fun _ => 1) ω - wE N M β (etaAt M 0) ω
      - wE N M β (etaAt M (0, -1)) ω) (haarCfg N M) := h2.sub (i _)
  rw [integral_add h1 (i _), integral_sub h2 (i _), integral_sub (i _) (i _), integral_wE,
    integral_wE, integral_wE, integral_wE, ZEta_one, ZEta_flip, ZEta_flip_any] at hpos
  have hTT : ZEta N M β true (fun y => etaAt M 0 y * etaAt M (0, -1) y) = ZW N M β true false := by
    rw [ZEta_parity]
    · rw [if_pos]
      rw [Finset.prod_mul_distrib, prod_etaAt_any, prod_etaAt_any]; norm_num
    · intro y; simp only [etaAt]; split_ifs <;> norm_num
  rw [hTT] at hpos
  linarith

end HalfSplit

namespace TwistBlocks

/-- **θ ≥ 0**（M が偶数、全ての実の β）：`0 ≤ thetaM N M β` -/
theorem theta_nonneg (N M : ℕ) [NeZero N] [NeZero M] (hM : M % 2 = 0) (β : ℝ) :
    0 ≤ thetaM N M β := by
  unfold thetaM
  have h := HalfSplit.Z1_le_Z0 N M hM β
  exact div_nonneg (by linarith) (add_pos (ZW_pos N M β true false) (ZW_pos N M β true true)).le

/-- **θ < 1**（全ての M、β）：Z₁ > 0 から -/
theorem theta_lt_one (N M : ℕ) [NeZero N] [NeZero M] (β : ℝ) : thetaM N M β < 1 := by
  unfold thetaM
  have h0 := ZW_pos N M β true false
  have h1 := ZW_pos N M β true true
  rw [div_lt_one (by linarith)]
  linarith

end TwistBlocks

#print axioms TwistBlocks.theta_nonneg
#print axioms TwistBlocks.theta_lt_one
#print axioms HalfSplit.Z1_le_Z0
