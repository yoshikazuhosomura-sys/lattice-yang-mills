-- ===== CouplingGammaCombined: Coupling35Combined (verbatim, #print axioms removed) + QuadLipF.part + GammaDiff.lean body + CouplingGamma.part =====
-- ===== pruned verbatim pieces: All1135 lines 1-3726 and 5453-5798 (CouplingLimit); RowSplit part (RowSplitCombined 5900-6167); NmBracket..CouplingQuad (CouplingQuadCombined 5891-6897, #print axioms removed) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
-- ===== verbatim copy of an earlier file (without #print axioms) =====
import Mathlib

/-!
# A uniform bracket for an order-preserving linear iteration (skeleton of Theorem 1)

Setting.  `E` is a real inner product space, `Q` an index type (the momenta), and we work with
families of linear operators `A : Q → E →ₗ[ℝ] E`.  The Loewner order of families is pointwise in
`q` and in the quadratic form:

  `Lw A B  :↔  ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫`.

`M` is a linear map on families which preserves this order (`OrderPreserving M`).  The stages are
`G k = M^[k] G0`.

Part 1 (upper side, order and linearity only).  If `M P ≼ λ P` and `M B ≼ B + e P`
(in : `B = P/ω`, `λ = λ̄`, `e = e_T`), then from `G0 ≼ B + c0 P`
  `G k ≼ B + (λ^k c0 + e Σ_{j<k} λ^j) P`                       (`iterate_upper`, `cSeq_eq`),
and, for `0 ≤ λ < 1`, `P ≽ 0`, `c0 ≤ e/(1-λ)`: `G k ≼ B + (e/(1-λ)) P` for all `k`
(`uniform_upper`).  Two-sided geometric bounds for the differences and convergence of every
quadratic form `⟪x, G k q x⟫` with rate `λ^k/(1-λ)` (`iterate_two_sided`, `quad_tendsto`).
The sharp form: `M G0 ≼ G0` implies `G (k+1) ≼ G k` for all `k` (`iterate_antitone`).

Part 2 (inverse on the range of a projection).  `InvOnRange P G H`: `P` symmetric,
`G (H x) = P x`, `P (H x) = H x` (so `H` is the inverse of `G` on `ran P`, e.g. `H = G⁺` when
`G = P X P`).  No square roots and no C*-algebra are used: the variational inequality
`2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` (equality at `v = H x`) gives the antitonicity of the inverse
on `ran P` (`antitone_inv`), hence
  `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H`   (`inv_lower`),   `m P ≼ G ⇒ H ≼ m⁻¹ P`   (`inv_upper`).

Part 3 (the bracket).  `bracket`: with `B = P/ω`, `h k = ¼ H k`,
  `¼ (ω⁻¹ + e/(1-λ))⁻¹ P ≼ h k ≼ (ω/(4a)) P`   for all `k`, `q`;
`bracket_numeric`: with `ω ≤ 16`, `λ ≤ 0.838`, `e ≤ 15/8`, `a = (4/π²) σ²`, `σ ≥ 0.04452`:
  `(ω/745) P ≼ h k ≼ 312 ω P`.
(`311` needs `σ ≥ 0.04454`, see `const_upper_311`.)
-/

noncomputable section

open scoped RealInnerProductSpace
open Filter Topology
open scoped Real

namespace UniformBracket

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-! ## 0. The Loewner order of families -/

/-- The Loewner order of families of operators, pointwise in `q`. -/
def Lw (A B : Q → E →ₗ[ℝ] E) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

namespace Lw

theorem refl (A : Q → E →ₗ[ℝ] E) : Lw A A := fun _ _ => le_rfl

theorem trans {A B C : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw B C) : Lw A C :=
  fun q x => (h₁ q x).trans (h₂ q x)

theorem add {A B C D : Q → E →ₗ[ℝ] E} (h₁ : Lw A B) (h₂ : Lw C D) : Lw (A + C) (B + D) := by
  intro q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right]
  exact add_le_add (h₁ q x) (h₂ q x)

theorem smul {A B : Q → E →ₗ[ℝ] E} {t : ℝ} (ht : 0 ≤ t) (h : Lw A B) : Lw (t • A) (t • B) := by
  intro q x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_left (h q x) ht

theorem neg {A B : Q → E →ₗ[ℝ] E} (h : Lw A B) : Lw (-B) (-A) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right]
  linarith [h q x]

/-- Scaling a nonnegative family is monotone in the scalar. -/
theorem smul_left {A : Q → E →ₗ[ℝ] E} {s t : ℝ} (hst : s ≤ t) (hA : Lw 0 A) :
    Lw (s • A) (t • A) := by
  intro q x
  have h0 := hA q x
  simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right] at h0
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  exact mul_le_mul_of_nonneg_right hst h0

end Lw

/-- `M` preserves the Loewner order of families. -/
def OrderPreserving (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E)) : Prop :=
  ∀ A B, Lw A B → Lw (M A) (M B)

/-! ## 1. Part 1: the upper side from order and linearity -/

section Part1

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- The scalar recursion `c_{k+1} = e + λ c_k`, `c_0 = c0`. -/
def cSeq (lam e c0 : ℝ) : ℕ → ℝ
  | 0 => c0
  | k + 1 => e + lam * cSeq lam e c0 k

theorem cSeq_eq (lam e c0 : ℝ) (k : ℕ) :
    cSeq lam e c0 k = lam ^ k * c0 + e * ∑ j ∈ Finset.range k, lam ^ j := by
  induction k with
  | zero => simp [cSeq]
  | succ k ih =>
    have hs : ∑ j ∈ Finset.range k, lam ^ (j + 1) = lam * ∑ j ∈ Finset.range k, lam ^ j := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => pow_succ' lam j)
    rw [cSeq, ih, Finset.sum_range_succ', hs]
    ring

theorem cSeq_nonneg {lam e c0 : ℝ} (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0) (k : ℕ) :
    0 ≤ cSeq lam e c0 k := by
  induction k with
  | zero => exact hc0
  | succ k ih => exact add_nonneg he (mul_nonneg hlam ih)

theorem cSeq_le {lam e c0 : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1)
    (hc0 : c0 ≤ e / (1 - lam)) (k : ℕ) : cSeq lam e c0 k ≤ e / (1 - lam) := by
  have h1 : (1 - lam) ≠ 0 := by linarith
  have hd : e / (1 - lam) * (1 - lam) = e := div_mul_cancel₀ e h1
  induction k with
  | zero => exact hc0
  | succ k ih =>
    have h := mul_le_mul_of_nonneg_left ih hlam0
    show e + lam * cSeq lam e c0 k ≤ e / (1 - lam)
    nlinarith

/-- One step of the upper comparison. -/
theorem step_upper (hM : OrderPreserving M) {P B G : Q → E →ₗ[ℝ] E} {lam e c : ℝ}
    (hc : 0 ≤ c) (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P))
    (hG : Lw G (B + c • P)) : Lw (M G) (B + (e + lam * c) • P) := by
  have h1 : Lw (M G) (M B + c • M P) := by
    have := hM _ _ hG
    rwa [map_add, map_smul] at this
  have h2 : Lw (M B + c • M P) ((B + e • P) + c • (lam • P)) := Lw.add hB (Lw.smul hc hP)
  have h3 : (B + e • P) + c • (lam • P) = B + (e + lam * c) • P := by
    rw [smul_smul, add_assoc, ← add_smul, mul_comm c lam]
  rw [h3] at h2
  exact h1.trans h2

/-- **Upper side, all stages** (with the source term): `G k ≼ B + c_k P`,
`c_k = λ^k c0 + e Σ_{j<k} λ^j` (`cSeq_eq`). -/
theorem iterate_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam : 0 ≤ lam) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + cSeq lam e c0 k • P) := by
  intro k
  induction k with
  | zero => simpa [cSeq] using hG0
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact step_upper M hM (cSeq_nonneg hlam he hc0 k) hP hB ih

/-- **Uniform upper bound**: `G k ≼ B + (e/(1-λ)) P` for all `k`. -/
theorem uniform_upper (hM : OrderPreserving M) {P B G0 : Q → E →ₗ[ℝ] E} {lam e c0 : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (hc0 : 0 ≤ c0)
    (hc0' : c0 ≤ e / (1 - lam)) (hP0 : Lw 0 P)
    (hP : Lw (M P) (lam • P)) (hB : Lw (M B) (B + e • P)) (hG0 : Lw G0 (B + c0 • P)) :
    ∀ k, Lw ((⇑M)^[k] G0) (B + (e / (1 - lam)) • P) := by
  intro k
  exact (iterate_upper M hM hlam0 he hc0 hP hB hG0 k).trans
    (Lw.add (Lw.refl B) (Lw.smul_left (cSeq_le hlam0 hlam1 hc0' k) hP0))

/-- The pure contraction (no source): `G0 ≼ c P ⇒ G k ≼ λ^k c P`. -/
theorem iterate_P_le (hM : OrderPreserving M) {P : Q → E →ₗ[ℝ] E} {lam : ℝ}
    (hlam : 0 ≤ lam) (hP : Lw (M P) (lam • P)) : ∀ k, Lw ((⇑M)^[k] P) (lam ^ k • P) := by
  intro k
  induction k with
  | zero => simpa using Lw.refl P
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have h1 : Lw (M ((⇑M)^[k] P)) (lam ^ k • M P) := by
      have := hM _ _ ih
      rwa [map_smul] at this
    have h2 : Lw (lam ^ k • M P) (lam ^ k • lam • P) := Lw.smul (pow_nonneg hlam k) hP
    rw [smul_smul, ← pow_succ] at h2
    exact h1.trans h2

theorem upper_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw X (c • P)) : Lw (M X) ((c * lam) • P) := by
  have h1 : Lw (M X) (c • M P) := by
    have := hM _ _ hX
    rwa [map_smul] at this
  have h2 : Lw (c • M P) (c • lam • P) := Lw.smul hc hP
  rw [smul_smul] at h2
  exact h1.trans h2

theorem lower_step' (hM : OrderPreserving M) {P X : Q → E →ₗ[ℝ] E} {lam c : ℝ} (hc : 0 ≤ c)
    (hP : Lw (M P) (lam • P)) (hX : Lw (-(c • P)) X) : Lw (-((c * lam) • P)) (M X) := by
  have h1 : Lw (-(c • M P)) (M X) := by
    have := hM _ _ hX
    rwa [map_neg, map_smul] at this
  have h2 : Lw (-(c • lam • P)) (-(c • M P)) := Lw.neg (Lw.smul hc hP)
  rw [smul_smul] at h2
  exact h2.trans h1

/-- Two-sided geometric bounds propagate: `-bP ≼ D ≼ bP ⇒ -bλ^k P ≼ M^[k] D ≼ bλ^k P`. -/
theorem iterate_two_sided (hM : OrderPreserving M) {P D : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) D) (hhi : Lw D (b • P)) :
    ∀ k, Lw (-((b * lam ^ k) • P)) ((⇑M)^[k] D) ∧ Lw ((⇑M)^[k] D) ((b * lam ^ k) • P) := by
  intro k
  induction k with
  | zero => simpa using And.intro hlo hhi
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have hc : 0 ≤ b * lam ^ k := mul_nonneg hb (pow_nonneg hlam0 k)
    have e1 : b * lam ^ (k + 1) = b * lam ^ k * lam := by ring
    rw [e1]
    exact ⟨lower_step' M hM hc hP ih.1, upper_step' M hM hc hP ih.2⟩

theorem iter_sub (k : ℕ) (a b : Q → E →ₗ[ℝ] E) :
    (⇑M)^[k] (a - b) = (⇑M)^[k] a - (⇑M)^[k] b := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [Function.iterate_succ_apply', ih, map_sub]

/-- **Geometric convergence of every quadratic form** `⟪x, G k q x⟫`, from the two-sided bound
`-bP ≼ G 1 - G 0 ≼ bP`. -/
theorem quad_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P)) (q : Q) (x : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q x⟫) atTop (𝓝 L) ∧
      ∀ k, |⟪x, (⇑M)^[k] G0 q x⟫ - L| ≤ b * ⟪x, P q x⟫ * lam ^ k / (1 - lam) := by
  set s : ℕ → ℝ := fun k => ⟪x, (⇑M)^[k] G0 q x⟫ with hs
  have hdiff : ∀ k, s (k + 1) - s k = ⟪x, (⇑M)^[k] (M G0 - G0) q x⟫ := by
    intro k
    simp only [hs]
    rw [iter_sub, Function.iterate_succ_apply]
    simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hu : ∀ k, dist (s k) (s (k + 1)) ≤ b * ⟪x, P q x⟫ * lam ^ k := by
    intro k
    obtain ⟨h1, h2⟩ := iterate_two_sided M hM hlam0 hb hP hlo hhi k
    have l1 := h1 q x
    have l2 := h2 q x
    simp only [Pi.neg_apply, LinearMap.neg_apply, inner_neg_right, Pi.smul_apply,
      LinearMap.smul_apply, real_inner_smul_right] at l1 l2
    rw [Real.dist_eq, abs_sub_comm, abs_le, hdiff k]
    constructor <;> nlinarith
  obtain ⟨L, hL⟩ := cauchySeq_tendsto_of_complete
    (cauchySeq_of_le_geometric lam (b * ⟪x, P q x⟫) hlam1 hu)
  refine ⟨L, hL, fun k => ?_⟩
  have := dist_le_of_le_geometric_of_tendsto lam (b * ⟪x, P q x⟫) hlam1 hu hL k
  rwa [Real.dist_eq] at this

/-- **Sharp form (ii′)**: one step `M G0 ≼ G0` makes the whole sequence decrease. -/
theorem iterate_antitone (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0) :
    ∀ k, Lw ((⇑M)^[k + 1] G0) ((⇑M)^[k] G0) := by
  intro k
  induction k with
  | zero => simpa using h1
  | succ k ih =>
    simp only [Function.iterate_succ_apply'] at ih ⊢
    exact hM _ _ ih

/-- `M` maps the cone `0 ≼ ·` into itself. -/
theorem nonneg_iterate (hM : OrderPreserving M) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw 0 ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => simpa using hG
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    have := hM _ _ ih
    rwa [map_zero] at this

/-- **Dominated comparison** (the order part of dropping the alias terms):
if `M₀ ≼ M` on the cone and both preserve the order, then `M₀^[k] G ≼ M^[k] G` for `G ≽ 0`. -/
theorem iterate_dominated (M₀ : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))
    (hM : OrderPreserving M) (hM₀ : OrderPreserving M₀)
    (hdom : ∀ A, Lw 0 A → Lw (M₀ A) (M A)) {G : Q → E →ₗ[ℝ] E} (hG : Lw 0 G) :
    ∀ k, Lw ((⇑M₀)^[k] G) ((⇑M)^[k] G) := by
  intro k
  induction k with
  | zero => exact Lw.refl G
  | succ k ih =>
    rw [Function.iterate_succ_apply', Function.iterate_succ_apply']
    exact (hM₀ _ _ ih).trans (hdom _ (nonneg_iterate M hM hG k))

/-- Polarization: for symmetric `A`, `⟪x, A y⟫` is a combination of quadratic forms. -/
theorem polarization {A : E →ₗ[ℝ] E} (hA : A.IsSymmetric) (x y : E) :
    ⟪x, A y⟫ = (⟪x + y, A (x + y)⟫ - ⟪x - y, A (x - y)⟫) / 4 := by
  have h1 : ⟪y, A x⟫ = ⟪x, A y⟫ := by rw [← hA x y, real_inner_comm]
  simp only [map_add, map_sub, inner_add_left, inner_add_right, inner_sub_left, inner_sub_right]
  linarith [h1]

/-- **Convergence of every matrix entry** `⟪x, G k q y⟫` (symmetric stages, by polarization). -/
theorem bilin_tendsto (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam b : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hb : 0 ≤ b) (hP : Lw (M P) (lam • P))
    (hlo : Lw (-(b • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (b • P))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric) (q : Q) (x y : E) :
    ∃ L : ℝ, Tendsto (fun k => ⟪x, (⇑M)^[k] G0 q y⟫) atTop (𝓝 L) := by
  obtain ⟨L1, h1, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x + y)
  obtain ⟨L2, h2, -⟩ := quad_tendsto M hM hlam0 hlam1 hb hP hlo hhi q (x - y)
  refine ⟨(L1 - L2) / 4, ?_⟩
  exact Tendsto.congr (fun k => (polarization (hsym k q) x y).symm) ((h1.sub h2).div_const 4)

end Part1

/-! ## 2. Part 2: the inverse on the range of a projection -/

section Part2

variable {P G H : E →ₗ[ℝ] E}

/-- `H` inverts `G` on the range of the symmetric projection `P`. -/
structure InvOnRange (P G H : E →ₗ[ℝ] E) : Prop where
  symm_P : P.IsSymmetric
  comp : ∀ x, G (H x) = P x
  range : ∀ x, P (H x) = H x

theorem proj_nonneg (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) (v : E) :
    0 ≤ ⟪v, P v⟫ := by
  have : ⟪v, P v⟫ = ⟪P v, P v⟫ := by rw [hPs v (P v), hPP]
  rw [this]
  exact real_inner_self_nonneg

theorem quad_eq (h : InvOnRange P G H) (x : E) : ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  calc ⟪H x, G (H x)⟫ = ⟪H x, P x⟫ := by rw [h.comp]
    _ = ⟪P (H x), x⟫ := (h.symm_P (H x) x).symm
    _ = ⟪H x, x⟫ := by rw [h.range]
    _ = ⟪x, H x⟫ := real_inner_comm _ _

/-- The variational inequality: `2⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫` for all `v`. -/
theorem variational (h : InvOnRange P G H) (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (x v : E) : 2 * ⟪P x, v⟫ - ⟪v, G v⟫ ≤ ⟪x, H x⟫ := by
  have key := hGp (v - H x)
  have f1 : ⟪H x, G v⟫ = ⟪P x, v⟫ := by rw [← hGs (H x) v, h.comp]
  have f2 : ⟪H x, P x⟫ = ⟪x, H x⟫ := by
    rw [← h.symm_P (H x) x, h.range]
    exact real_inner_comm _ _
  have f3 : ⟪v, P x⟫ = ⟪P x, v⟫ := real_inner_comm _ _
  simp only [map_sub, h.comp, inner_sub_left, inner_sub_right] at key
  rw [f1, f2, f3] at key
  linarith

/-- Equality in the variational inequality at `v = H x`. -/
theorem variational_eq (h : InvOnRange P G H) (x : E) :
    2 * ⟪P x, H x⟫ - ⟪H x, G (H x)⟫ = ⟪x, H x⟫ := by
  rw [quad_eq h x, h.symm_P x (H x), h.range]
  ring

/-- **Antitonicity of the inverse on `ran P`**: `G ≼ G'` (`G` symmetric, `≽ 0`) gives
`H' ≼ H`. -/
theorem antitone_inv {G' H' : E →ₗ[ℝ] E} (h : InvOnRange P G H) (h' : InvOnRange P G' H')
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫) (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫)
    (x : E) : ⟪x, H' x⟫ ≤ ⟪x, H x⟫ := by
  have h1 := variational_eq h' x
  have h2 := variational h hGs hGp x (H' x)
  have h3 := hle (H' x)
  linarith

theorem invOnRange_smul (hPs : P.IsSymmetric) (hPP : ∀ x, P (P x) = P x) {m : ℝ} (hm : m ≠ 0) :
    InvOnRange P (m • P) (m⁻¹ • P) where
  symm_P := hPs
  comp x := by
    rw [LinearMap.smul_apply, LinearMap.smul_apply, map_smul, hPP, smul_smul,
      mul_inv_cancel₀ hm, one_smul]
  range x := by simp only [LinearMap.smul_apply, map_smul, hPP]

theorem isSymmetric_smul (hPs : P.IsSymmetric) (m : ℝ) : (m • P).IsSymmetric := by
  intro a b
  simp only [LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right, hPs a b]

/-- **Lower bound on the inverse**: `G ≼ Mx P ⇒ Mx⁻¹ P ≼ H` on all of `E`. -/
theorem inv_lower {Mx : ℝ} (hMx : 0 < Mx) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ Mx * ⟪v, P v⟫) (x : E) :
    Mx⁻¹ * ⟪x, P x⟫ ≤ ⟪x, H x⟫ := by
  have := antitone_inv h (invOnRange_smul h.symm_P hPP hMx.ne') hGs hGp
    (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hle v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

/-- **Upper bound on the inverse**: `m P ≼ G ⇒ H ≼ m⁻¹ P` on all of `E`. -/
theorem inv_upper {m : ℝ} (hm : 0 < m) (h : InvOnRange P G H) (hPP : ∀ x, P (P x) = P x)
    (hge : ∀ v, m * ⟪v, P v⟫ ≤ ⟪v, G v⟫) (x : E) :
    ⟪x, H x⟫ ≤ m⁻¹ * ⟪x, P x⟫ := by
  have hpos : ∀ v, 0 ≤ ⟪v, (m • P) v⟫ := by
    intro v
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg hm.le (proj_nonneg h.symm_P hPP v)
  have := antitone_inv (invOnRange_smul h.symm_P hPP hm.ne') h (isSymmetric_smul h.symm_P m)
    hpos (fun v => by simpa only [LinearMap.smul_apply, real_inner_smul_right] using hge v) x
  simpa only [LinearMap.smul_apply, real_inner_smul_right] using this

end Part2

/-! ## 3. Part 3: the bracket -/

section Part3

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The bracket (abstract form of Theorem 1).**  `B = P/ω`, the stages `G k = M^[k] G0`,
`H k q` the inverse of `G k q` on `ran P q`, and `h = ¼ H`.  Inputs: the one-step bounds
`M P ≼ λ P`, `M B ≼ B + e P` (upper side), and the lower bound `a B ≼ G k` for all `k`
(kept as a hypothesis). -/
theorem bracket (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q)
    {lam e a : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (he : 0 ≤ e) (ha : 0 < a)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    (1 / 4) * ((ω q)⁻¹ + e / (1 - lam))⁻¹ * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ ω q / (4 * a) * ⟪x, P q x⟫ := by
  set B : Q → E →ₗ[ℝ] E := fun q => (ω q)⁻¹ • P q with hBdef
  set c : ℝ := e / (1 - lam) with hcdef
  have h1lam : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he h1lam.le
  have hP0 : Lw 0 P := by
    intro q' v
    simp only [Pi.zero_apply, LinearMap.zero_apply, inner_zero_right]
    exact proj_nonneg (hPs q') (hPP q') v
  have hG0' : Lw G0 (B + (0 : ℝ) • P) := by simpa using hG0
  have hup := uniform_upper M hM hlam0 hlam1 he le_rfl (div_nonneg he h1lam.le) hP0 hPstep
    hBstep hG0' k
  set G := (⇑M)^[k] G0 with hGdef
  have hinv : InvOnRange (P q) (G q) (H k q) := ⟨hPs q, hH k q, hHP k q⟩
  have hupv : ∀ v, ⟪v, G q v⟫ ≤ ((ω q)⁻¹ + c) * ⟪v, P q v⟫ := by
    intro v
    have := hup q v
    simp only [hBdef, Pi.add_apply, LinearMap.add_apply, Pi.smul_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right] at this
    linarith
  have hlowv : ∀ v, (a * (ω q)⁻¹) * ⟪v, P q v⟫ ≤ ⟪v, G q v⟫ := by
    intro v
    have := hlow k q v
    simp only [hBdef, Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at this
    linarith
  have hωi : 0 < (ω q)⁻¹ := inv_pos.mpr (hω q)
  have hm : 0 < a * (ω q)⁻¹ := mul_pos ha hωi
  have hGp : ∀ v, 0 ≤ ⟪v, G q v⟫ := fun v =>
    le_trans (mul_nonneg hm.le (proj_nonneg (hPs q) (hPP q) v)) (hlowv v)
  have hMx : 0 < (ω q)⁻¹ + c := by linarith
  have lo := inv_lower hMx hinv (hPP q) (hsym k q) hGp hupv x
  have up := inv_upper hm hinv (hPP q) hlowv x
  have hinv' : (a * (ω q)⁻¹)⁻¹ = ω q / a := by rw [mul_inv, inv_inv]; ring
  rw [hinv'] at up
  have e2 : ω q / (4 * a) * ⟪x, P q x⟫ = (1 / 4) * (ω q / a * ⟪x, P q x⟫) := by ring
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  constructor
  · nlinarith
  · rw [e2]; nlinarith

/-- Arithmetic of the lower constant: `ω/745 ≤ ¼ (ω⁻¹ + e/(1-λ))⁻¹`. -/
theorem const_lower {ω lam e : ℝ} (hω : 0 < ω) (hω16 : ω ≤ 16) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8) :
    ω / 745 ≤ (1 / 4) * (ω⁻¹ + e / (1 - lam))⁻¹ := by
  set c := e / (1 - lam) with hcdef
  have h1 : 0 < 1 - lam := by linarith
  have hc0 : 0 ≤ c := div_nonneg he0 h1.le
  have hc : c * (1 - lam) = e := div_mul_cancel₀ e h1.ne'
  have hc1 : c * 0.162 ≤ 15 / 8 := by nlinarith
  have ht : 0 < ω⁻¹ + c := by positivity
  have e1 : 4 * (ω⁻¹ + c) * ω = 4 + 4 * (c * ω) := by
    rw [mul_assoc, add_mul, inv_mul_cancel₀ hω.ne']; ring
  have hkey : 4 * (ω⁻¹ + c) * ω ≤ 745 := by
    rw [e1]
    nlinarith [mul_le_mul_of_nonneg_left hω16 hc0]
  have e3 : (1 / 4 : ℝ) * (ω⁻¹ + c)⁻¹ = 1 / (4 * (ω⁻¹ + c)) := by
    rw [one_div, one_div, mul_inv]
  rw [e3, div_le_div_iff₀ (by norm_num) (by positivity)]
  nlinarith

/-- Arithmetic of the upper constant: `σ ≥ 0.04452`, `a = (4/π²) σ²` give `ω/(4a) ≤ 312 ω`. -/
theorem const_upper {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2) :
    ω / (4 * a) ≤ 312 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hσ2 : (0.0019820304 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1248 * a := by
    rw [ha, show 1248 * (4 / π ^ 2 * σ ^ 2) = 4992 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- The constant `311` needs `σ ≥ 0.04454` (from `σ ≥ 0.04452` one gets only `311.2`). -/
theorem const_upper_311 {ω σ a : ℝ} (hω : 0 < ω) (hσ : 0.04454 ≤ σ)
    (ha : a = 4 / π ^ 2 * σ ^ 2) : ω / (4 * a) ≤ 311 * ω := by
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.8697 := by nlinarith
  have hσ2 : (0.0019838116 : ℝ) ≤ σ ^ 2 := by nlinarith
  have ha' : 1 ≤ 1244 * a := by
    rw [ha, show 1244 * (4 / π ^ 2 * σ ^ 2) = 4976 * σ ^ 2 / π ^ 2 by ring,
      le_div_iff₀ (by positivity)]
    nlinarith
  have ha0 : 0 < a := by linarith
  rw [div_le_iff₀ (by positivity)]
  nlinarith

/-- **The bracket with numbers** (Theorem 1 of + §2.9, numbers as hypotheses):
`(ω/745) P ≼ h k ≼ 312 ω P` for all stages `k` and momenta `q`. -/
theorem bracket_numeric (hM : OrderPreserving M)
    {P : Q → E →ₗ[ℝ] E} (hPs : ∀ q, (P q).IsSymmetric) (hPP : ∀ q x, P q (P q x) = P q x)
    {ω : Q → ℝ} (hω : ∀ q, 0 < ω q) (hω16 : ∀ q, ω q ≤ 16)
    {lam e σ a : ℝ} (hlam0 : 0 ≤ lam) (hlam : lam ≤ 0.838) (he0 : 0 ≤ e) (he : e ≤ 15 / 8)
    (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hPstep : Lw (M P) (lam • P))
    (hBstep : Lw (M (fun q => (ω q)⁻¹ • P q)) ((fun q => (ω q)⁻¹ • P q) + e • P))
    {G0 : Q → E →ₗ[ℝ] E} (hG0 : Lw G0 (fun q => (ω q)⁻¹ • P q))
    (hlow : ∀ k, Lw (a • fun q => (ω q)⁻¹ • P q) ((⇑M)^[k] G0))
    (hsym : ∀ k q, ((⇑M)^[k] G0 q).IsSymmetric)
    {H : ℕ → Q → E →ₗ[ℝ] E} (hH : ∀ k q x, (⇑M)^[k] G0 q (H k q x) = P q x)
    (hHP : ∀ k q x, P q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : E) :
    ω q / 745 * ⟪x, P q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * ω q * ⟪x, P q x⟫ := by
  have hlam1 : lam < 1 := by linarith
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  obtain ⟨lo, up⟩ := bracket M hM hPs hPP hω hlam0 hlam1 he0 ha0 hPstep hBstep hG0 hlow hsym
    hH hHP k q x
  have hPx := proj_nonneg (hPs q) (hPP q) x
  have c1 := const_lower (hω q) (hω16 q) hlam he0 he
  have c2 := const_upper (hω q) hσ ha
  exact ⟨le_trans (mul_le_mul_of_nonneg_right c1 hPx) lo,
    le_trans up (mul_le_mul_of_nonneg_right c2 hPx)⟩

/-- **Sharp form on the inverse side**: if `G (k+1) ≼ G k` then `h k ≼ h (k+1)`. -/
theorem stage_action_increasing {P G G' H H' : E →ₗ[ℝ] E} (h : InvOnRange P G H)
    (h' : InvOnRange P G' H') (hGs : G.IsSymmetric) (hGp : ∀ v, 0 ≤ ⟪v, G v⟫)
    (hle : ∀ v, ⟪v, G v⟫ ≤ ⟪v, G' v⟫) (x : E) :
    ⟪x, ((1 / 4 : ℝ) • H') x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H) x⟫ := by
  have := antitone_inv h h' hGs hGp hle x
  simp only [LinearMap.smul_apply, real_inner_smul_right]
  linarith

end Part3

end UniformBracket


-- ===== verbatim copy of an earlier file (without its import line and #print axioms) =====

/-!
# The one-step norm `λ̄ ≤ 0.838` : the polynomial stages

Setting: `α = 1/8`, four directions.  For one direction `ν` the two aliases `ζ_ν ∈ {0,1}` of
`r_ζ = (q + 2πζ)/2` give `x_ν(r_ζ) = 4α sin²(r_{ζ,ν}/2)` equal to `σ_ν/2` (`ζ_ν = 0`) and
`(1-σ_ν)/2` (`ζ_ν = 1`), where `σ_ν = sin²(q_ν/4) ∈ [0,1]`.  The weight `cos²(r_{ζ,c}/2)` of the
distinguished direction `c` is `1-σ_c` and `σ_c` (`alias_x`, `alias_w`).

Stages, from the back:
* S6 `Dlin_le`: the linear inequality in `y = σ_c(1-σ_c) ≥ 0` with `t = 3/10`:
  `D(y) = 429/512 - (13/40) y ≤ 429/512 ≤ 0.838`.
* S5 one-direction alias sums (`sumT_*`, `sumS_*`) and the transverse bounds on `σ ∈ [0,1]`
  (`Tq_le`, `Tx2_le`, `Tq_antitone`).
* S4 the alias sum over `ζ ∈ {0,1}⁴` of a monomial is the product of one-direction sums
  (`alias_factor`); the closed forms `Msum_eq`, `Lsum_eq`.
* S4' `Msum_le`, `Lsum_le`, `Dsum_le`: `(1+t) M_c + (1+1/t) L̄_c ≤ 429/512` on the box `[0,1]⁴`.
* S2 (matrix level, any finite index type): Lemma 4 of `comp_identity`
  `(N u)_μ = (π_μ - x_μ) u_μ - s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν` for `u ⊥ s̃`, and the square bound
  `normSq_le` (`(a-b)² ≤ (1+t)a² + (1+1/t)b²` and weighted Cauchy–Schwarz).
-/

noncomputable section

open scoped Real
open Finset

namespace OneStepNorm

/-! ## S6. The linear inequality in one variable -/

/-- `D(y)` of after the transverse directions are set to `σ = 0`
(splitting parameter `t`):
`(1+t)·¼(125/64 − 19y/4) + (1+1/t)·(3/8)(3y/4 + 1/8)`. -/
def Dlin (t y : ℝ) : ℝ :=
  (1 + t) * ((1 / 4) * (125 / 64 - 19 / 4 * y)) + (1 + 1 / t) * ((3 / 8) * (3 / 4 * y + 1 / 8))

theorem Dlin_eq (y : ℝ) : Dlin (3 / 10) y = 429 / 512 - 13 / 40 * y := by
  unfold Dlin
  ring

theorem Dlin_le {y : ℝ} (hy : 0 ≤ y) : Dlin (3 / 10) y ≤ 429 / 512 := by
  rw [Dlin_eq]
  linarith

/-- The value at the end point `y = 1/4` (0.7566). -/
theorem Dlin_quarter : Dlin (3 / 10) (1 / 4) = 1937 / 2560 := by
  rw [Dlin_eq]
  norm_num

theorem const_429 : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-! ## S5. One direction: the two aliases -/

/-- `x = 4α sin²(r/2)` (`α = 1/8`) at the two aliases of one direction, `σ = sin²(q/4)`. -/
def xa (σ : ℝ) : Bool → ℝ
  | false => σ / 2
  | true => (1 - σ) / 2

/-- The weight `cos²(r_c/2)` at the two aliases of the distinguished direction. -/
def wa (σ : ℝ) : Bool → ℝ
  | false => 1 - σ
  | true => σ

/-- Trigonometric bridge for `x`: with `θ = q/4` the alias `ζ = 1` shifts `θ` by `π/2`. -/
theorem alias_x (θ : ℝ) (b : Bool) :
    (1 / 2) * Real.sin (θ + (if b then π / 2 else 0)) ^ 2 = xa (Real.sin θ ^ 2) b := by
  cases b <;> simp [xa, Real.sin_add_pi_div_two, Real.cos_sq'] <;> ring

/-- Trigonometric bridge for the weight `cos²(r_c/2)`. -/
theorem alias_w (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) ^ 2 = wa (Real.sin θ ^ 2) b := by
  cases b <;> simp [wa, Real.cos_add_pi_div_two, Real.cos_sq']

theorem sigma_mem (θ : ℝ) : 0 ≤ Real.sin θ ^ 2 ∧ Real.sin θ ^ 2 ≤ 1 :=
  ⟨sq_nonneg _, Real.sin_sq_le_one θ⟩

theorem xa_mem {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ xa σ b ∧ xa σ b ≤ 1 / 2 := by
  cases b <;> simp only [xa] <;> constructor <;> linarith

/-- `T[(1-x)²]`, the transverse factor of `M_c`. -/
def Tq (σ : ℝ) : ℝ := 5 / 4 - σ / 2 + σ ^ 2 / 2

/-- `T[x²]`. -/
def Tx2 (σ : ℝ) : ℝ := (σ ^ 2 + (1 - σ) ^ 2) / 4

/-- `y = σ(1-σ) = S_c[x]`. -/
def yv (σ : ℝ) : ℝ := σ * (1 - σ)

theorem sumT_one : ∑ _b : Bool, (1 : ℝ) = 2 := by
  rw [Fintype.sum_bool]
  norm_num

theorem sumT_x (σ : ℝ) : ∑ b, xa σ b = 1 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_x2 (σ : ℝ) : ∑ b, xa σ b ^ 2 = Tx2 σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tx2]
  ring

theorem sumT_1mx (σ : ℝ) : ∑ b, (1 - xa σ b) = 3 / 2 := by
  rw [Fintype.sum_bool]
  simp only [xa]
  ring

theorem sumT_1mx2 (σ : ℝ) : ∑ b, (1 - xa σ b) ^ 2 = Tq σ := by
  rw [Fintype.sum_bool]
  simp only [xa, Tq]
  ring

theorem sumS_one (σ : ℝ) : ∑ b, wa σ b = 1 := by
  rw [Fintype.sum_bool]
  simp only [wa]
  ring

theorem sumS_x (σ : ℝ) : ∑ b, wa σ b * xa σ b = yv σ := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

theorem sumS_x2 (σ : ℝ) : ∑ b, wa σ b * xa σ b ^ 2 = yv σ / 4 := by
  rw [Fintype.sum_bool]
  simp only [wa, xa, yv]
  ring

/-! Transverse bounds on `σ ∈ [0,1]` (the maximum is at `σ = 0`). -/

theorem Tq_pos (σ : ℝ) : 0 < Tq σ := by
  unfold Tq
  nlinarith [sq_nonneg (σ - 1 / 2)]

theorem Tq_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tq σ ≤ 5 / 4 := by
  unfold Tq
  nlinarith

/-- The factor `T[(1-x)²]` decreases on `[0, 1/2]` ("正かつ減る"). -/
theorem Tq_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) : Tq σ' ≤ Tq σ := by
  unfold Tq
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem Tx2_nonneg (σ : ℝ) : 0 ≤ Tx2 σ := by
  unfold Tx2
  positivity

theorem Tx2_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : Tx2 σ ≤ 1 / 4 := by
  unfold Tx2
  nlinarith

theorem Tx2_antitone {σ σ' : ℝ} (h : σ ≤ σ') (h' : σ' ≤ 1 / 2) :
    Tx2 σ' ≤ Tx2 σ := by
  unfold Tx2
  nlinarith [mul_nonneg (sub_nonneg.2 h) (by linarith : (0 : ℝ) ≤ 1 - σ - σ')]

theorem yv_nonneg {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ := by
  unfold yv
  exact mul_nonneg h0 (by linarith)

theorem yv_le (σ : ℝ) : yv σ ≤ 1 / 4 := by
  unfold yv
  nlinarith [sq_nonneg (σ - 1 / 2)]

/-! ## S4. Four directions: the alias sum factors monomial by monomial -/

/-- The alias sum over `ζ ∈ {0,1}⁴` of a product of one-direction factors is the product of the
one-direction sums. -/
theorem alias_factor (f0 f1 f2 f3 : Bool → ℝ) :
    ∑ b0, ∑ b1, ∑ b2, ∑ b3, f0 b0 * f1 b1 * f2 b2 * f3 b3 =
      (∑ b, f0 b) * (∑ b, f1 b) * (∑ b, f2 b) * (∑ b, f3 b) := by
  simp only [Fintype.sum_bool]
  ring

/-- `π_c − x_c` at the alias `(bc, b1, b2, b3)` (`c` the distinguished direction). -/
def pmx (σc σ1 σ2 σ3 : ℝ) (bc b1 b2 b3 : Bool) : ℝ :=
  (1 - xa σ1 b1) * (1 - xa σ2 b2) * (1 - xa σ3 b3) - xa σc bc

/-- `η̄_c = Σ_{μ≠c} x_μ (x_a + x_b)/2 · e₂(x_c, x_a, x_b)` (`{a,b}` the complement of `{μ,c}`). -/
def etaBar (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * ((x2 + x3) / 2) * (xc * x2 + xc * x3 + x2 * x3) +
  x2 * ((x1 + x3) / 2) * (xc * x1 + xc * x3 + x1 * x3) +
  x3 * ((x1 + x2) / 2) * (xc * x1 + xc * x2 + x1 * x2)

/-- `M_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) (π_c − x_c)²(r_ζ)`. -/
def Msum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2

/-- `L̄_c := ¼ Σ_ζ cos²(r_{ζ,c}/2) η̄_c(r_ζ)`. -/
def Lsum (σc σ1 σ2 σ3 : ℝ) : ℝ :=
  (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
    wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)

/-- Closed form of `M_c` (`¼[Π_{ν≠c}(5/4 − σ_ν/2 + σ_ν²/2) − (19/4) y_c]`). -/
theorem Msum_eq (σc σ1 σ2 σ3 : ℝ) :
    Msum σc σ1 σ2 σ3 = (1 / 4) * (Tq σ1 * Tq σ2 * Tq σ3 - 19 / 4 * yv σc) := by
  simp only [Msum, pmx, Fintype.sum_bool, xa, wa, Tq, yv]
  ring

/-- Closed form of `L̄_c` (`¼ Σ_{μ≠c} ½[y_c(T_a + T_b + ¼) + (T_a + T_b)/4]`). -/
theorem Lsum_eq (σc σ1 σ2 σ3 : ℝ) :
    Lsum σc σ1 σ2 σ3 = (1 / 4) *
      ((1 / 2) * (yv σc * (Tx2 σ2 + Tx2 σ3 + 1 / 4) + (Tx2 σ2 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ3 + 1 / 4) + (Tx2 σ1 + Tx2 σ3) / 4) +
       (1 / 2) * (yv σc * (Tx2 σ1 + Tx2 σ2 + 1 / 4) + (Tx2 σ1 + Tx2 σ2) / 4)) := by
  simp only [Lsum, etaBar, Fintype.sum_bool, xa, wa, Tx2, yv]
  ring

/-! ## S4'. The bound on the box -/

theorem Msum_le {σc σ1 σ2 σ3 : ℝ} (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1)
    (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Msum σc σ1 σ2 σ3 ≤ (1 / 4) * (125 / 64 - 19 / 4 * yv σc) := by
  rw [Msum_eq]
  have hprod : Tq σ1 * Tq σ2 * Tq σ3 ≤ (5 / 4) * (5 / 4) * (5 / 4) := by
    apply mul_le_mul _ (Tq_le h3.1 h3.2) (Tq_pos _).le (by norm_num)
    exact mul_le_mul (Tq_le h1.1 h1.2) (Tq_le h2.1 h2.2) (Tq_pos _).le (by norm_num)
  linarith

theorem Lsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    Lsum σc σ1 σ2 σ3 ≤ (3 / 8) * (3 / 4 * yv σc + 1 / 8) := by
  rw [Lsum_eq]
  have hy := yv_nonneg hc.1 hc.2
  have t1 := Tx2_le h1.1 h1.2
  have t2 := Tx2_le h2.1 h2.2
  have t3 := Tx2_le h3.1 h3.2
  have m1 := mul_le_mul_of_nonneg_left t1 hy
  have m2 := mul_le_mul_of_nonneg_left t2 hy
  have m3 := mul_le_mul_of_nonneg_left t3 hy
  nlinarith

/-- **The one-step bound on the box** (`t = 3/10`): for every direction `c` and every
`σ ∈ [0,1]⁴`, `D_c = (1+t) M_c + (1+1/t) L̄_c ≤ 429/512`. -/
theorem Dsum_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 429 / 512 := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have hD := Dlin_le (yv_nonneg hc.1 hc.2)
  unfold Dlin at hD
  have e1 : (1 + 1 / (3 / 10 : ℝ)) = 13 / 3 := by norm_num
  rw [e1]
  rw [e1] at hD
  nlinarith

/-- The same with the number of the request: `≤ 0.838`. -/
theorem Dsum_le_0838 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 3 / 10) * Msum σc σ1 σ2 σ3 + (1 + 1 / (3 / 10)) * Lsum σc σ1 σ2 σ3 ≤ 0.838 :=
  (Dsum_le hc h1 h2 h3).trans const_429

/-- The same in the trigonometric variables: `σ_ν = sin²(θ_ν)`, `θ_ν = q_ν/4`. -/
theorem Dsum_le_trig (θc θ1 θ2 θ3 : ℝ) :
    (1 + 3 / 10) * Msum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) +
      (1 + 1 / (3 / 10)) *
        Lsum (Real.sin θc ^ 2) (Real.sin θ1 ^ 2) (Real.sin θ2 ^ 2) (Real.sin θ3 ^ 2) ≤
      429 / 512 :=
  Dsum_le (sigma_mem θc) (sigma_mem θ1) (sigma_mem θ2) (sigma_mem θ3)

/-! ## S6'. A general splitting parameter `t`, and `t = 31/100` -/

/-- For any `t > 0` the box bound reduces to the one-variable `D(y)`. -/
theorem Dsum_le_Dlin {t σc σ1 σ2 σ3 : ℝ} (ht : 0 < t) (hc : 0 ≤ σc ∧ σc ≤ 1)
    (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1) (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + t) * Msum σc σ1 σ2 σ3 + (1 + 1 / t) * Lsum σc σ1 σ2 σ3 ≤ Dlin t (yv σc) := by
  have hM := Msum_le h1 h2 h3 (σc := σc)
  have hL := Lsum_le hc h1 h2 h3
  have a : 0 ≤ 1 + t := by linarith
  have b : 0 ≤ 1 + 1 / t := by positivity
  unfold Dlin
  have k1 := mul_le_mul_of_nonneg_left hM a
  have k2 := mul_le_mul_of_nonneg_left hL b
  linarith

theorem Dlin31_eq (y : ℝ) : Dlin (31 / 100) y = 26593 / 31744 - 18209 / 49600 * y := by
  unfold Dlin
  ring

/-- With `t = 31/100` (close to the optimal `√(12/125)` at `y = 0`):
`D_c ≤ 26593/31744 = 0.83773…`. -/
theorem Dsum_le_31 {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 + 31 / 100) * Msum σc σ1 σ2 σ3 + (1 + 1 / (31 / 100)) * Lsum σc σ1 σ2 σ3 ≤
      26593 / 31744 := by
  have h := Dsum_le_Dlin (t := 31 / 100) (by norm_num) hc h1 h2 h3
  rw [Dlin31_eq] at h
  have hy := yv_nonneg hc.1 hc.2
  linarith

theorem const_31_0838 : (26593 / 31744 : ℝ) ≤ 0.838 := by norm_num

/-- With `λ = 26593/31744` and `e = 15/8`: `1 + 16 e/(1-λ) ≤ 186`, i.e. `c₁ ≥ 1/186`
(found that `λ = 0.838` gives `186.19`). -/
theorem const_c1_186 : 1 + 16 * ((15 / 8 : ℝ) / (1 - 26593 / 31744)) ≤ 186 := by norm_num

/-! ## S1(b). The alias vector stays physical: `w_ζ ⊥ s(r_ζ)` -/

/-- One direction, with `θ = q/4` and `r/2 = θ + [ζ]π/2`:
`cos(r/2)·(−1)^ζ·sin(r/2) = ½ sin(q/2)`  (`C(r) s(r) = s(2r)/2` and `s(2r_ζ) = S_ζ s(q)`). -/
theorem alias_orth (θ : ℝ) (b : Bool) :
    Real.cos (θ + (if b then π / 2 else 0)) * (if b then -1 else 1) *
      Real.sin (θ + (if b then π / 2 else 0)) = (1 / 2) * Real.sin (2 * θ) := by
  cases b <;> simp [Real.cos_add_pi_div_two, Real.sin_add_pi_div_two, Real.sin_two_mul] <;> ring

/-- **`w_ζ ⊥ s(r_ζ)`**: with `w_ν = cos(r_ν/2)(−1)^{ζ_ν} u_ν` and `s_ν(r_ζ) = sin(r_ν/2)`,
`⟨w_ζ, s(r_ζ)⟩ = ½ ⟨u, s(q)⟩` (`s_ν(q) = sin(q_ν/2) = sin(2θ_ν)`); so `u ⊥ s(q)` gives
`w_ζ ⊥ s(r_ζ)`. -/
theorem alias_orth_sum {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) =
      (1 / 2) * ∑ ν, u ν * Real.sin (2 * θ ν) := by
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro ν _
  have h := alias_orth (θ ν) (ζ ν)
  calc (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))
      = u ν * (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0))) := by ring
    _ = u ν * ((1 / 2) * Real.sin (2 * θ ν)) := by rw [h]
    _ = 1 / 2 * (u ν * Real.sin (2 * θ ν)) := by ring

theorem alias_orth_zero {ι : Type*} [Fintype ι] (θ : ι → ℝ) (ζ : ι → Bool) (u : ι → ℝ)
    (hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0) :
    ∑ ν, (Real.cos (θ ν + (if ζ ν then π / 2 else 0)) * (if ζ ν then -1 else 1) * u ν) *
        Real.sin (θ ν + (if ζ ν then π / 2 else 0)) = 0 := by
  rw [alias_orth_sum, hu, mul_zero]

/-! ## e_T ≤ 15/8 : the scalar part -/

/-- `4 sin²(q/2) = 16 σ (1 − σ)` with `σ = sin²(q/4)` (`θ = q/4`). -/
theorem omega_dir (θ : ℝ) :
    4 * Real.sin (2 * θ) ^ 2 = 16 * (Real.sin θ ^ 2) * (1 - Real.sin θ ^ 2) := by
  rw [Real.sin_two_mul]
  have h := Real.sin_sq_add_cos_sq θ
  have hc : Real.cos θ ^ 2 = 1 - Real.sin θ ^ 2 := by linarith
  calc 4 * (2 * Real.sin θ * Real.cos θ) ^ 2 = 16 * Real.sin θ ^ 2 * Real.cos θ ^ 2 := by ring
    _ = _ := by rw [hc]

/-- `4 ω(q/2) − ω(q) = Σ 16 σ_ν² ≥ 0` in the `σ` variables
(`ω(q/2) = Σ 4σ_ν`, `ω(q) = Σ 16 σ_ν(1−σ_ν)`). -/
theorem omega_half (s0 s1 s2 s3 : ℝ) :
    16 * (s0 * (1 - s0) + s1 * (1 - s1) + s2 * (1 - s2) + s3 * (1 - s3)) ≤
      4 * (4 * s0 + 4 * s1 + 4 * s2 + 4 * s3) := by
  nlinarith [sq_nonneg s0, sq_nonneg s1, sq_nonneg s2, sq_nonneg s3]

/-- `ω` at the alias `ζ`: `Σ_ν 4 (σ_ν or 1 − σ_ν)`; for `ζ ≠ 0` and `σ ∈ [0, 1/2]⁴` it is `≥ 2`. -/
def omA (s0 s1 s2 s3 : ℝ) (b0 b1 b2 b3 : Bool) : ℝ :=
  4 * (if b0 then 1 - s0 else s0) + 4 * (if b1 then 1 - s1 else s1) +
    4 * (if b2 then 1 - s2 else s2) + 4 * (if b3 then 1 - s3 else s3)

theorem omA_ge_two {s0 s1 s2 s3 : ℝ} (h0 : 0 ≤ s0 ∧ s0 ≤ 1 / 2) (h1 : 0 ≤ s1 ∧ s1 ≤ 1 / 2)
    (h2 : 0 ≤ s2 ∧ s2 ≤ 1 / 2) (h3 : 0 ≤ s3 ∧ s3 ≤ 1 / 2) (b0 b1 b2 b3 : Bool)
    (hb : (b0 || b1 || b2 || b3) = true) : 2 ≤ omA s0 s1 s2 s3 b0 b1 b2 b3 := by
  unfold omA
  cases b0 <;> cases b1 <;> cases b2 <;> cases b3 <;> simp at hb ⊢ <;> linarith

/-- **The scalar step of `e_T ≤ 15/8`**: if the `ζ = 0` term satisfies `¼ F₀ ≤ 1/ω` and the
fifteen others `F_ζ ≤ 1/2` (from `ν² cos² ≤ 1` and `ω(r_ζ) ≥ 2`), then `¼ Σ_ζ F_ζ ≤ 1/ω + 15/8`. -/
theorem eT_sum (F : Bool → Bool → Bool → Bool → ℝ) {w : ℝ}
    (h0 : (1 / 4) * F false false false false ≤ w)
    (hF : ∀ b0 b1 b2 b3, (b0 || b1 || b2 || b3) = true → F b0 b1 b2 b3 ≤ 1 / 2) :
    (1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, F b0 b1 b2 b3 ≤ w + 15 / 8 := by
  simp only [Fintype.sum_bool]
  have := hF true true true true rfl
  have := hF true true true false rfl
  have := hF true true false true rfl
  have := hF true true false false rfl
  have := hF true false true true rfl
  have := hF true false true false rfl
  have := hF true false false true rfl
  have := hF true false false false rfl
  have := hF false true true true rfl
  have := hF false true true false rfl
  have := hF false true false true rfl
  have := hF false true false false rfl
  have := hF false false true true rfl
  have := hF false false true false rfl
  have := hF false false false true rfl
  linarith

/-! ## S2. Matrix level: Lemma 4 and the square bound -/

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- `(N u)_μ = π_μ u_μ + s̃_μ Σ_{ν≠μ} (1 − E_{μν}) s̃_ν u_ν`
(`N = diag π + diag s̃ 𝔅 diag s̃`, `𝔅_{μν} = 1 − E_{μν}` off the diagonal, `𝔅_{μμ} = 0`). -/
def Nap (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ) (μ : ι) : ℝ :=
  pi μ * u μ + st μ * ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)

/-- **Lemma 4 of **: for `u ⊥ s̃`,
`(N u)_μ = (π_μ − s̃_μ²) u_μ − s̃_μ Σ_{ν≠μ} E_{μν} s̃_ν u_ν`. -/
theorem comp_identity (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (μ : ι) :
    Nap pi st E u μ =
      (pi μ - st μ ^ 2) * u μ - st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
  unfold Nap
  have h1 : ∑ ν ∈ univ.erase μ, (1 - E μ ν) * (st ν * u ν)
      = ∑ ν ∈ univ.erase μ, st ν * u ν - ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν) := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro ν _
    ring
  have h2 : ∑ ν ∈ univ.erase μ, st ν * u ν = -(st μ * u μ) := by
    rw [Finset.sum_erase_eq_sub (Finset.mem_univ μ), hu]
    ring
  rw [h1, h2]
  ring

/-- `(a − b)² ≤ (1+t) a² + (1+1/t) b²` for `t > 0`. -/
theorem sq_split (a b : ℝ) {t : ℝ} (ht : 0 < t) :
    (a - b) ^ 2 ≤ (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 := by
  have key : (1 + t) * a ^ 2 + (1 + 1 / t) * b ^ 2 - (a - b) ^ 2 = (t * a + b) ^ 2 / t := by
    field_simp
    ring
  have : 0 ≤ (t * a + b) ^ 2 / t := by positivity
  linarith

omit [Fintype ι] [DecidableEq ι] in
/-- Weighted Cauchy–Schwarz: `(Σ w a b)² ≤ (Σ w a²)(Σ w b²)` for `w ≥ 0`. -/
theorem wcs (s : Finset ι) (w a b : ι → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s, w i * (a i * b i)) ^ 2 ≤ (∑ i ∈ s, w i * a i ^ 2) * ∑ i ∈ s, w i * b i ^ 2 := by
  apply Finset.sum_sq_le_sum_mul_sum_of_sq_le_mul s
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i hi
    exact mul_nonneg (hw i hi) (sq_nonneg _)
  · intro i _
    apply le_of_eq
    ring

/-- The componentwise square bound (the corollary of Lemma 4). -/
theorem comp_sq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) := by
  rw [comp_identity pi st E u hu μ]
  have h := sq_split ((pi μ - st μ ^ 2) * u μ)
    (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ht
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ 1 + 1 / t := by positivity
  have hb : (st μ * ∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) ^ 2 ≤
      st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
    rw [mul_pow]
    exact mul_le_mul_of_nonneg_left hcs (sq_nonneg _)
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hb hc
  linarith

/-- **The square bound** `|N u|² ≤ Σ_μ [(1+t)(π_μ − x_μ)² u_μ² + (1+1/t) x_μ ρ'_μ Σ_{ν≠μ} E_{μν} u_ν²]`
for `u ⊥ s̃`, `E ≥ 0`, `x = s̃²`, `ρ'_μ = Σ_{ν≠μ} E_{μν} x_ν`. -/
theorem normSq_le (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {t : ℝ} (ht : 0 < t) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + t) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (1 + 1 / t) * (st μ ^ 2 * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2))) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le pi st E u hu hE ht μ

end MatrixLevel

/-! ## S3. The specific `E` and `η ≤ η̄` (directions `c, 1, 2, 3`, all `x ∈ [0, 1/2]`) -/

/-- `E_{μν} = (x_ρ + x_σ)/2 − x_ρ x_σ/3` as a function of the complementary pair `{ρ, σ}`. -/
def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

theorem Ef_nonneg {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) : 0 ≤ Ef y z := by
  unfold Ef
  nlinarith [mul_le_mul_of_nonneg_left hz.2 hy.1]

theorem Ef_le {y z : ℝ} (hy : 0 ≤ y) (hz : 0 ≤ z) : Ef y z ≤ (y + z) / 2 := by
  unfold Ef
  nlinarith [mul_nonneg hy hz]

/-- `ρ'_μ = Σ_{λ≠μ} E_{μλ} x_λ`, the other three directions being `c, a, b`. -/
def rhoP (xc xa xb : ℝ) : ℝ := Ef xa xb * xc + Ef xc xb * xa + Ef xc xa * xb

theorem rhoP_nonneg {xc xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (ha : 0 ≤ xa ∧ xa ≤ 1 / 2)
    (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) : 0 ≤ rhoP xc xa xb := by
  unfold rhoP
  have e1 := mul_nonneg (Ef_nonneg ha hb) hc.1
  have e2 := mul_nonneg (Ef_nonneg hc hb) ha.1
  have e3 := mul_nonneg (Ef_nonneg hc ha) hb.1
  linarith

/-- `ρ'_μ ≤ e₂(x_{−μ})`. -/
theorem rhoP_le {xc xa xb : ℝ} (hc : 0 ≤ xc) (ha : 0 ≤ xa) (hb : 0 ≤ xb) :
    rhoP xc xa xb ≤ xc * xa + xc * xb + xa * xb := by
  unfold rhoP
  have e1 := mul_le_mul_of_nonneg_right (Ef_le ha hb) hc
  have e2 := mul_le_mul_of_nonneg_right (Ef_le hc hb) ha
  have e3 := mul_le_mul_of_nonneg_right (Ef_le hc ha) hb
  nlinarith

/-- `η_c = Σ_{μ≠c} x_μ E_{μc} ρ'_μ` (directions `c, 1, 2, 3`). -/
def eta (xc x1 x2 x3 : ℝ) : ℝ :=
  x1 * Ef x2 x3 * rhoP xc x2 x3 + x2 * Ef x1 x3 * rhoP xc x1 x3 + x3 * Ef x1 x2 * rhoP xc x1 x2

/-- One term of `η ≤ η̄`. -/
theorem eta_term_le {xc xm xa xb : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (hm : 0 ≤ xm)
    (ha : 0 ≤ xa ∧ xa ≤ 1 / 2) (hb : 0 ≤ xb ∧ xb ≤ 1 / 2) :
    xm * Ef xa xb * rhoP xc xa xb ≤ xm * ((xa + xb) / 2) * (xc * xa + xc * xb + xa * xb) := by
  apply mul_le_mul (mul_le_mul_of_nonneg_left (Ef_le ha.1 hb.1) hm)
    (rhoP_le hc.1 ha.1 hb.1) (rhoP_nonneg hc ha hb)
  exact mul_nonneg hm (by linarith [ha.1, hb.1])

/-- **`η_c ≤ η̄_c`** (`0 ≤ E_{μν} ≤ (x_ρ + x_σ)/2`, `0 ≤ ρ'_μ ≤ e₂(x_{−μ})`). -/
theorem eta_le_etaBar {xc x1 x2 x3 : ℝ} (hc : 0 ≤ xc ∧ xc ≤ 1 / 2) (h1 : 0 ≤ x1 ∧ x1 ≤ 1 / 2)
    (h2 : 0 ≤ x2 ∧ x2 ≤ 1 / 2) (h3 : 0 ≤ x3 ∧ x3 ≤ 1 / 2) :
    eta xc x1 x2 x3 ≤ etaBar xc x1 x2 x3 := by
  unfold eta etaBar
  have k1 := eta_term_le hc h1.1 h2 h3
  have k2 := eta_term_le hc h2.1 h1 h3
  have k3 := eta_term_le hc h3.1 h1 h2
  linarith

/-- The coefficient of `u_c²` in the alias sum with the true `η_c` is bounded by `D_c`
(`(1+t) M_c + (1+1/t) L̄_c` with `η̄_c`), alias by alias. -/
theorem alias_coeff_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤ 429 / 512 := by
  have hw : ∀ b, 0 ≤ wa σc b := by
    intro b
    cases b <;> simp only [wa] <;> linarith [hc.1, hc.2]
  have step : ∀ bc b1 b2 b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      (1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) := by
    intro bc b1 b2 b3
    have he := eta_le_etaBar (xa_mem hc.1 hc.2 bc) (xa_mem h1.1 h1.2 b1) (xa_mem h2.1 h2.2 b2)
      (xa_mem h3.1 h3.2 b3)
    have hm := mul_le_mul_of_nonneg_left he (hw bc)
    have hpos : (0 : ℝ) ≤ 1 + 1 / (3 / 10) := by norm_num
    nlinarith [mul_le_mul_of_nonneg_left hm hpos]
  have hD := Dsum_le hc h1 h2 h3
  unfold Msum Lsum at hD
  have hsum : ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc *
      ((1 + 3 / 10) * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
        (1 + 1 / (3 / 10)) * eta (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3)) ≤
      ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) := by
    apply Finset.sum_le_sum; intro bc _
    apply Finset.sum_le_sum; intro b1 _
    apply Finset.sum_le_sum; intro b2 _
    apply Finset.sum_le_sum; intro b3 _
    exact step bc b1 b2 b3
  have hsplit : ∑ bc, ∑ b1, ∑ b2, ∑ b3, ((1 + 3 / 10) * (wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2) +
        (1 + 1 / (3 / 10)) * (wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3))) =
      (1 + 3 / 10) * ∑ bc, ∑ b1, ∑ b2, ∑ b3, wa σc bc * pmx σc σ1 σ2 σ3 bc b1 b2 b3 ^ 2 +
      (1 + 1 / (3 / 10)) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * etaBar (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) := by
    simp only [Fintype.sum_bool]
    ring
  rw [hsplit] at hsum
  nlinarith

/-! ## S2'. Swapping the off-diagonal double sum (`Σ_μ a_μ Σ_{ν≠μ} E_{μν} v_ν = Σ_ν v_ν η_ν`) -/

section Swap

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

theorem swap_erase (a : ι → ℝ) (E : ι → ι → ℝ) (v : ι → ℝ) :
    ∑ μ, a μ * ∑ ν ∈ univ.erase μ, E μ ν * v ν =
      ∑ ν, v ν * ∑ μ ∈ univ.erase ν, a μ * E μ ν := by
  simp only [Finset.sum_erase_eq_sub (Finset.mem_univ _), mul_sub, Finset.sum_sub_distrib,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  congr 1
  · apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro y _
    ring
  · apply Finset.sum_congr rfl
    intro x _
    ring

end Swap

/-! ## Bridge to `UniformBracket` : a coordinate bound gives `M P ≼ λ P` -/

section Bridge

open scoped RealInnerProductSpace

variable {Q : Type*} {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The Loewner order of families, copied verbatim from `UniformBracket.Lw`. -/
def Lw (A B : Q → V →ₗ[ℝ] V) : Prop := ∀ q x, ⟪x, A q x⟫ ≤ ⟪x, B q x⟫

/-- If, in orthonormal coordinates `coord`, the quadratic form of `M P` is bounded by a diagonal
form `Σ_c D_c (P x)_c²` with every `D_c ≤ λ`, then `M P ≼ λ P` (the hypothesis `hPstep` of
`UniformBracket.bracket`). -/
theorem lw_of_coord_bound (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (D : Q → Fin 4 → ℝ) {lam : ℝ}
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, D q c * coord (P q x) c ^ 2)
    (hD : ∀ q c, D q c ≤ lam) : Lw MP (lam • P) := by
  intro q x
  have hPx : ⟪x, P q x⟫ = ∑ c, coord (P q x) c ^ 2 := by
    have h := hPs q x (P q x)
    rw [hPP q x] at h
    rw [← h, hcoord]
  have hsum : ∑ c, D q c * coord (P q x) c ^ 2 ≤ ∑ c, lam * coord (P q x) c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (hD q c) (sq_nonneg _)
  rw [← Finset.mul_sum] at hsum
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [hPx]
  exact (hrep q x).trans hsum

/-- The `D_c` of for the four directions (the other three in increasing order). -/
def Dc (σ : Fin 4 → ℝ) (c : Fin 4) : ℝ :=
  ![(1 + 3 / 10) * Msum (σ 0) (σ 1) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 0) (σ 1) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 1) (σ 0) (σ 2) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 1) (σ 0) (σ 2) (σ 3),
    (1 + 3 / 10) * Msum (σ 2) (σ 0) (σ 1) (σ 3) + (1 + 1 / (3 / 10)) * Lsum (σ 2) (σ 0) (σ 1) (σ 3),
    (1 + 3 / 10) * Msum (σ 3) (σ 0) (σ 1) (σ 2) + (1 + 1 / (3 / 10)) * Lsum (σ 3) (σ 0) (σ 1) (σ 2)]
    c

theorem Dc_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) : Dc σ c ≤ 429 / 512 := by
  fin_cases c
  · exact Dsum_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact Dsum_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact Dsum_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-- **The hand-over to `UniformBracket`**: if the quadratic form of `M P` at `q` is bounded by
`Σ_c D_c(σ(q)) (P x)_c²` (the alias representation, not formalized here), with
`σ_ν(q) = sin²(q_ν/4) ∈ [0,1]`, then `M P ≼ λ P` with `λ = 429/512 ≤ 0.838`. -/
theorem MP_le (MP P : Q → V →ₗ[ℝ] V) (hPs : ∀ q, (P q).IsSymmetric)
    (hPP : ∀ q x, P q (P q x) = P q x) (coord : V → Fin 4 → ℝ)
    (hcoord : ∀ v, ⟪v, v⟫ = ∑ c, coord v c ^ 2) (σ : Q → Fin 4 → ℝ)
    (hσ : ∀ q ν, 0 ≤ σ q ν ∧ σ q ν ≤ 1)
    (hrep : ∀ q x, ⟪x, MP q x⟫ ≤ ∑ c, Dc (σ q) c * coord (P q x) c ^ 2) :
    Lw MP ((429 / 512 : ℝ) • P) :=
  lw_of_coord_bound MP P hPs hPP coord hcoord (fun q c => Dc (σ q) c) hrep
    (fun q c => Dc_le (hσ q) c)

end Bridge

end OneStepNorm


-- ===== body of an earlier file (without its import line and #print axioms) =====

/-!
# Fourier analysis on a finite abelian group, decimation by a homomorphism, and the
symbols of the block-constraint operator

Momenta are the characters `ψ : AddChar F ℂ` of a finite additive group `F`
(for the torus `F = (ℤ/2L)^d` these are `y ↦ exp(i k·y)`).  Convention
`f̂(ψ) = Σ_y ψ(-y) f(y)`.

* §1 the transform: translation, convolution, inversion, Plancherel, injectivity;
* §2 decimation along `β : G →+ F` (coarse points `X ↦ β X`): the sampled function has the
  alias-sum transform `|F| (f∘β)^(φ) = |G| Σ_{ψ ∘ β = φ} f̂(ψ)`;
* §3 the constraint operator `(Ca)(X) = Σ_r c(r) a(βX + r)` and its adjoint: alias sums for
  `C`, `C†`, `C C†` and `C T C†` (`T` translation invariant on the fine group);
* §4 a lower bound on the symbol at one alias per coarse momentum gives a real-space lower bound
  `‖C† w‖² ≥ (|G|/|F|) c₀ ‖w‖²`, and `C` is onto (complex and real kernels);
* §5 intertwining of gradients from a symbol identity (`C ∇ = ∇ ∘ res`);
* §6 the torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X`, where `|F|/|G| = 2^d`;
* §7 the alias representation of the one-step map on the projection (linear algebra).
-/

open Finset
open scoped ComplexConjugate

noncomputable section

namespace TorusFourier

/-! ## §1 The transform -/

section Transform

variable {F : Type*} [AddCommGroup F] [Fintype F]

/-- Fourier transform, `f̂(ψ) = Σ_y ψ(-y) f(y)`. -/
def ft (f : F → ℂ) (ψ : AddChar F ℂ) : ℂ := ∑ y, ψ (-y) * f y

theorem ft_add (f g : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => f y + g y) ψ = ft f ψ + ft g ψ := by
  unfold ft; rw [← Finset.sum_add_distrib]; congr 1; ext y; ring

theorem ft_const_mul (k : ℂ) (f : F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => k * f y) ψ = k * ft f ψ := by
  unfold ft; rw [Finset.mul_sum]; congr 1; ext y; ring

theorem ft_sum {α : Type*} (s : Finset α) (f : α → F → ℂ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ i ∈ s, f i y) ψ = ∑ i ∈ s, ft (f i) ψ := by
  unfold ft
  simp_rw [Finset.mul_sum]
  exact Finset.sum_comm

/-- Translation becomes multiplication by the character. -/
theorem ft_translate (f : F → ℂ) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => f (y + r)) ψ = ψ r * ft f ψ := by
  unfold ft
  rw [Finset.mul_sum]
  refine Fintype.sum_equiv (Equiv.addRight r) _ _ (fun y => ?_)
  simp only [Equiv.coe_addRight]
  rw [show -y = -(y + r) + r by abel, AddChar.map_add_eq_mul]
  ring

/-- Convolution `(f ⋆ g)(x) = Σ_y f(y) g(x - y)`. -/
def conv (f g : F → ℂ) (x : F) : ℂ := ∑ y, f y * g (x - y)

/-- Convolution becomes multiplication. -/
theorem ft_conv (f g : F → ℂ) (ψ : AddChar F ℂ) : ft (conv f g) ψ = ft f ψ * ft g ψ := by
  unfold conv
  rw [ft_sum]
  have h : ∀ y, ft (fun x => f y * g (x - y)) ψ = ψ (-y) * f y * ft g ψ := by
    intro y
    rw [ft_const_mul]
    have := ft_translate g (-y) ψ
    simp only [← sub_eq_add_neg] at this
    rw [this]; ring
  simp_rw [h]
  unfold ft
  rw [Finset.sum_mul]

/-- Inversion: `Σ_ψ ψ(y) f̂(ψ) = |F| f(y)`. -/
theorem ft_inv (f : F → ℂ) (y : F) :
    ∑ ψ : AddChar F ℂ, ψ y * ft f ψ = (Fintype.card F : ℂ) * f y := by
  classical
  unfold ft
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  have h : ∀ x, ∑ ψ : AddChar F ℂ, ψ y * (ψ (-x) * f x) =
      (if y - x = 0 then (Fintype.card F : ℂ) else 0) * f x := by
    intro x
    rw [← AddChar.sum_apply_eq_ite, Finset.sum_mul]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    rw [sub_eq_add_neg, AddChar.map_add_eq_mul]; ring
  simp_rw [h, sub_eq_zero, ite_mul, zero_mul]
  rw [Finset.sum_ite_eq]
  simp

/-- The transform is injective. -/
theorem ft_injective {f g : F → ℂ} (h : ∀ ψ, ft f ψ = ft g ψ) : f = g := by
  funext y
  have h1 := ft_inv f y
  have h2 := ft_inv g y
  simp_rw [h] at h1
  have hc : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  exact mul_left_cancel₀ hc (h1.symm.trans h2)

theorem conj_ft (f : F → ℂ) (ψ : AddChar F ℂ) : conj (ft f ψ) = ∑ y, ψ y * conj (f y) := by
  unfold ft
  rw [map_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj, Complex.conj_conj]

/-- Plancherel (sesquilinear form). -/
theorem plancherel (f g : F → ℂ) :
    ∑ ψ : AddChar F ℂ, conj (ft f ψ) * ft g ψ =
      (Fintype.card F : ℂ) * ∑ y, conj (f y) * g y := by
  simp_rw [conj_ft, Finset.sum_mul]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun y _ => ?_
  calc ∑ ψ : AddChar F ℂ, ψ y * conj (f y) * ft g ψ
        = conj (f y) * ∑ ψ : AddChar F ℂ, ψ y * ft g ψ := by
          rw [Finset.mul_sum]; refine Finset.sum_congr rfl fun ψ _ => ?_; ring
    _ = _ := by rw [ft_inv]; ring

/-- Plancherel (norms). -/
theorem plancherel_norm (f : F → ℂ) :
    ∑ ψ : AddChar F ℂ, ‖ft f ψ‖ ^ 2 = (Fintype.card F : ℝ) * ∑ y, ‖f y‖ ^ 2 := by
  have h := plancherel f f
  simp_rw [Complex.conj_mul'] at h
  exact_mod_cast h

end Transform

/-! ## §2 Decimation along a homomorphism -/

section Decimation

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]

/-- Restriction of a fine momentum to the coarse group (for the torus: `k ↦ 2k`). -/
def res (β : G →+ F) (ψ : AddChar F ℂ) : AddChar G ℂ := ψ.compAddMonoidHom β

omit [Fintype F] [Fintype G] in
@[simp] theorem res_apply (β : G →+ F) (ψ : AddChar F ℂ) (X : G) : res β ψ X = ψ (β X) := rfl

omit [Fintype F] in
/-- Orthogonality on the coarse group: `Σ_X φ(-X) ψ(βX) = |G| [ψ ∘ β = φ]`. -/
theorem sum_res_mul (β : G →+ F) (ψ : AddChar F ℂ) (φ : AddChar G ℂ) :
    ∑ X, φ (-X) * ψ (β X) = if res β ψ = φ then (Fintype.card G : ℂ) else 0 := by
  classical
  have h := AddChar.sum_eq_ite (res β ψ - φ)
  have e : ∀ X, (res β ψ - φ) X = φ (-X) * ψ (β X) := by
    intro X
    rw [sub_eq_add_neg, AddChar.add_apply, AddChar.neg_apply, res_apply]
    ring
  simp_rw [e] at h
  rw [h]
  simp only [sub_eq_zero]

/-- **Decimation is an alias sum**: `|F| (f ∘ β)^(φ) = |G| Σ_{ψ : ψ∘β = φ} f̂(ψ)`. -/
theorem ft_sample (β : G →+ F) (f : F → ℂ) (φ : AddChar G ℂ) :
    (Fintype.card F : ℂ) * ft (fun X => f (β X)) φ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ, if res β ψ = φ then ft f ψ else 0 := by
  rw [ft, Finset.mul_sum]
  have h : ∀ X, (Fintype.card F : ℂ) * (φ (-X) * f (β X)) =
      ∑ ψ : AddChar F ℂ, φ (-X) * ψ (β X) * ft f ψ := by
    intro X
    rw [mul_left_comm, ← ft_inv f (β X), Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    ring
  simp_rw [h]
  rw [Finset.sum_comm, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ψ _ => ?_
  rw [← Finset.sum_mul, sum_res_mul]
  split_ifs <;> ring

/-- **The number of aliases**: for an injective `β`, every coarse momentum has exactly
`|F|/|G|` fine momenta above it (`f = δ₀` in `ft_sample`). -/
theorem card_alias (β : G →+ F) (hβ : Function.Injective β) (φ : AddChar G ℂ) :
    (Fintype.card G : ℂ) * ((Finset.univ.filter fun ψ : AddChar F ℂ => res β ψ = φ).card : ℂ) =
      Fintype.card F := by
  classical
  have h := ft_sample β (fun y => if y = 0 then (1 : ℂ) else 0) φ
  have h1 : ∀ ψ : AddChar F ℂ, ft (fun y => if y = 0 then (1 : ℂ) else 0) ψ = 1 := by
    intro ψ
    unfold ft
    simp
  have h2 : ft (fun X => if β X = 0 then (1 : ℂ) else 0) φ = 1 := by
    unfold ft
    have e : ∀ X, (φ (-X) * if β X = 0 then (1 : ℂ) else 0) = if X = 0 then 1 else 0 := by
      intro X
      by_cases hX : X = 0
      · subst hX; simp
      · have : β X ≠ 0 := fun h0 => hX (hβ (h0.trans (map_zero β).symm))
        simp [hX, this]
    simp_rw [e]
    simp
  simp only [h1, h2, mul_one] at h
  rw [h, Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, nsmul_eq_mul, mul_one]

end Decimation

/-! ## §3 The constraint operator, its adjoint, and their symbols -/

section Constraint

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- Componentwise transform of a vector-valued field. -/
def ftv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (a : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ft (fun y => a y ν) ψ

/-- The constraint operator `(Ca)_μ(X) = Σ_r Σ_ν c(r)_{μν} a_ν(βX + r)`. -/
def Cop (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) : G → κ → ℂ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- Its symbol `Q(ψ)_{μν} = Σ_r c(r)_{μν} ψ(r)`. -/
def sym (c : F → κ → ι → ℂ) (ψ : AddChar F ℂ) (μ : κ) (ν : ι) : ℂ := ∑ r, c r μ ν * ψ r

/-- The adjoint `(C†w)_ν(y) = Σ_X Σ_μ conj(c(y - βX)_{μν}) w_μ(X)`. -/
def Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ X, ∑ μ, conj (c (y - β X) μ ν) * w X μ

omit [Fintype ι] in
theorem ft_translate_v (a : F → ι → ℂ) (ν : ι) (r : F) (ψ : AddChar F ℂ) :
    ft (fun y => a (y + r) ν) ψ = ψ r * ftv a ψ ν :=
  ft_translate (fun y => a y ν) r ψ

omit [Fintype κ] in
theorem ft_shiftSum (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (μ : κ) (ψ : AddChar F ℂ) :
    ft (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) ψ = ∑ ν, sym c ψ μ ν * ftv a ψ ν := by
  rw [ft_sum]
  have h : ∀ r, ft (fun y => ∑ ν, c r μ ν * a (y + r) ν) ψ =
      ∑ ν, c r μ ν * (ψ r * ftv a ψ ν) := by
    intro r
    rw [ft_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ft_const_mul, ft_translate_v]
  simp_rw [h]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun ν _ => ?_
  unfold sym
  rw [Finset.sum_mul]
  refine Finset.sum_congr rfl fun r _ => ?_
  ring

omit [Fintype κ] in
/-- **Alias sum for `C`**: `|F| (Ca)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) â(ψ)`. -/
theorem alias_C (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c a) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then ∑ ν, sym c ψ μ ν * ftv a ψ ν else 0 := by
  have h := ft_sample β (fun y => ∑ r, ∑ ν, c r μ ν * a (y + r) ν) φ
  simp only [ft_shiftSum] at h
  exact h

omit [Fintype ι] [Fintype κ] in
theorem ft_conj_kernel (c : F → κ → ι → ℂ) (μ : κ) (ν : ι) (ψ : AddChar F ℂ) :
    ft (fun z => conj (c z μ ν)) ψ = conj (sym c ψ μ ν) := by
  unfold ft sym
  rw [map_sum]
  refine Finset.sum_congr rfl fun r _ => ?_
  rw [map_mul, AddChar.map_neg_eq_conj]
  ring

omit [Fintype ι] in
/-- **Symbol of the adjoint**: `(C†w)^(ψ) = Q(ψ)† ŵ(ψ ∘ β)`. -/
theorem ftv_Cadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Cadj β c w) ψ ν = ∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ := by
  unfold ftv Cadj
  rw [ft_sum]
  have h1 : ∀ X, ft (fun y => ∑ μ, conj (c (y - β X) μ ν) * w X μ) ψ =
      ∑ μ, w X μ * (ψ (-(β X)) * conj (sym c ψ μ ν)) := by
    intro X
    rw [ft_sum]
    refine Finset.sum_congr rfl fun μ _ => ?_
    have ht := ft_translate (fun z => conj (c z μ ν)) (-(β X)) ψ
    beta_reduce at ht
    have e : (fun y => conj (c (y - β X) μ ν) * w X μ) =
        fun y => w X μ * conj (c (y + -(β X)) μ ν) := by
      funext y
      rw [sub_eq_add_neg]
      ring
    rw [e, ft_const_mul, ht, ft_conj_kernel]
  simp_rw [h1]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun μ _ => ?_
  unfold ft
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun X _ => ?_
  rw [res_apply, map_neg β X]
  ring

/-- **Symbol of `C C†`** (命題 E): `|F| (CC†w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CCadj (β : G →+ F) (c : F → κ → ι → ℂ) (w : G → κ → ℂ) (φ : AddChar G ℂ)
    (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Cadj β c w)) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- A translation-invariant operator on the fine group, `(Ta)_ν(y) = Σ_z Σ_ν' t(z)_{νν'} a_ν'(y - z)`. -/
def Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) : F → ι → ℂ :=
  fun y ν => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν'

theorem ftv_Tconv (t : F → ι → ι → ℂ) (a : F → ι → ℂ) (ψ : AddChar F ℂ) (ν : ι) :
    ftv (Tconv t a) ψ ν = ∑ ν', ft (fun z => t z ν ν') ψ * ftv a ψ ν' := by
  unfold ftv Tconv
  have e : (fun y => ∑ z, ∑ ν', t z ν ν' * a (y - z) ν') =
      fun y => ∑ ν', conv (fun z => t z ν ν') (fun z => a z ν') y := by
    funext y
    unfold conv
    exact Finset.sum_comm
  rw [e, ft_sum]
  refine Finset.sum_congr rfl fun ν' _ => ?_
  rw [ft_conv]

/-- **Symbol of `C T C†`** (the push-forward of a covariance, the form of the map `𝓡`):
`|F| (C T C† w)^(φ) = |G| Σ_{ψ∘β = φ} Q(ψ) t̂(ψ) Q(ψ)† ŵ(φ)`. -/
theorem alias_CTCadj (β : G →+ F) (c : F → κ → ι → ℂ) (t : F → ι → ι → ℂ) (w : G → κ → ℂ)
    (φ : AddChar G ℂ) (μ : κ) :
    (Fintype.card F : ℂ) * ftv (Cop β c (Tconv t (Cadj β c w))) φ μ =
      (Fintype.card G : ℂ) * ∑ ψ : AddChar F ℂ,
        if res β ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ ν', ft (fun z => t z ν ν') ψ *
            ∑ l, conj (sym c ψ l ν') * ftv w φ l else 0 := by
  rw [alias_C]
  congr 1
  refine Finset.sum_congr rfl fun ψ _ => ?_
  split_ifs with h
  · refine Finset.sum_congr rfl fun ν _ => ?_
    rw [ftv_Tconv]
    congr 1
    refine Finset.sum_congr rfl fun ν' _ => ?_
    rw [ftv_Cadj, h]
  · rfl

/-- `C†` is the adjoint of `C` for the sesquilinear forms `Σ conj(u) v`. -/
theorem Cop_adjoint (β : G →+ F) (c : F → κ → ι → ℂ) (a : F → ι → ℂ) (w : G → κ → ℂ) :
    ∑ X, ∑ μ, conj (w X μ) * Cop β c a X μ = ∑ y, ∑ ν, conj (Cadj β c w y ν) * a y ν := by
  have hL : ∀ X μ, conj (w X μ) * Cop β c a X μ =
      ∑ ν, ∑ r, conj (w X μ) * (c r μ ν * a (β X + r) ν) := by
    intro X μ
    unfold Cop
    rw [Finset.mul_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl fun ν _ => ?_
    rw [Finset.mul_sum]
  have hR : ∀ y ν, conj (Cadj β c w y ν) * a y ν =
      ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    intro y ν
    unfold Cadj
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun X _ => ?_
    rw [map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [map_mul, Complex.conj_conj]
    ring
  simp_rw [hL, hR]
  -- right side: Σ_y Σ_ν Σ_X Σ_μ  →  Σ_X Σ_μ Σ_ν Σ_y
  have s1 : ∑ y, ∑ ν, ∑ X, ∑ μ, conj (w X μ) * (c (y - β X) μ ν * a y ν) =
      ∑ X, ∑ μ, ∑ ν, ∑ y, conj (w X μ) * (c (y - β X) μ ν * a y ν) := by
    rw [Finset.sum_comm]
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset G))]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun X _ => ?_
    simp_rw [Finset.sum_comm (s := (Finset.univ : Finset F)) (t := (Finset.univ : Finset κ))]
    rw [Finset.sum_comm]
  rw [s1]
  refine Finset.sum_congr rfl fun X _ => ?_
  refine Finset.sum_congr rfl fun μ _ => ?_
  refine Finset.sum_congr rfl fun ν _ => ?_
  refine Fintype.sum_equiv (Equiv.addLeft (β X)) _ _ (fun r => ?_)
  simp only [Equiv.coe_addLeft, add_sub_cancel_left]

end Constraint

/-! ## §4 Lower bound from one alias per coarse momentum; `C` is onto -/

section Onto

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **Real-space lower bound for `C†`**: if for every coarse momentum `φ` one alias `sec φ`
(`sec φ ∘ β = φ`) has `|Q(sec φ)† v|² ≥ c₀ |v|²`, then `|F| ‖C†w‖² ≥ |G| c₀ ‖w‖²`. -/
theorem Cadj_lower (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ}
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : G → κ → ℂ) :
    (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤
      (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 := by
  classical
  set g : AddChar F ℂ → ℝ := fun ψ =>
    ∑ ν, ‖∑ μ, conj (sym c ψ μ ν) * ftv w (res β ψ) μ‖ ^ 2 with hg
  have hR : (Fintype.card F : ℝ) * ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = ∑ ψ, g ψ := by
    rw [Finset.sum_comm, Finset.mul_sum]
    have h : ∀ ν, (Fintype.card F : ℝ) * ∑ y, ‖Cadj β c w y ν‖ ^ 2 =
        ∑ ψ : AddChar F ℂ, ‖ftv (Cadj β c w) ψ ν‖ ^ 2 := fun ν =>
      (plancherel_norm (fun y => Cadj β c w y ν)).symm
    simp_rw [h, ftv_Cadj]
    rw [Finset.sum_comm]
  have hinj : Function.Injective sec := fun a b h => by rw [← hsec a, ← hsec b, h]
  have hg0 : ∀ ψ, 0 ≤ g ψ := fun ψ => Finset.sum_nonneg fun ν _ => sq_nonneg _
  have hsub : ∑ φ, g (sec φ) ≤ ∑ ψ, g ψ := by
    rw [← Finset.sum_image (fun a _ b _ h => hinj h)]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
      (fun ψ _ _ => hg0 ψ)
  have hlow : ∀ φ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 ≤ g (sec φ) := by
    intro φ
    rw [hg]
    simp only [hsec]
    exact hc₀ φ (fun μ => ftv w φ μ)
  have hL : (Fintype.card G : ℝ) * c₀ * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 =
      ∑ φ : AddChar G ℂ, c₀ * ∑ μ, ‖ftv w φ μ‖ ^ 2 := by
    rw [← Finset.mul_sum, Finset.sum_comm (s := (Finset.univ : Finset (AddChar G ℂ))),
      Finset.sum_comm (s := (Finset.univ : Finset G))]
    have h : ∀ μ, ∑ φ : AddChar G ℂ, ‖ftv w φ μ‖ ^ 2 =
        (Fintype.card G : ℝ) * ∑ X, ‖w X μ‖ ^ 2 := fun μ => plancherel_norm (fun X => w X μ)
    simp_rw [h]
    rw [← Finset.mul_sum]
    ring
  rw [hL, hR]
  exact (Finset.sum_le_sum fun φ _ => hlow φ).trans hsub

/-- `C C†` as a complex-linear map on coarse fields. -/
def CCL (β : G →+ F) (c : F → κ → ι → ℂ) : (G → κ → ℂ) →ₗ[ℂ] (G → κ → ℂ) where
  toFun w := Cop β c (Cadj β c w)
  map_add' w v := by
    funext X μ
    simp only [Cop, Cadj, Pi.add_apply, mul_add, Finset.sum_add_distrib]
  map_smul' k w := by
    funext X μ
    simp only [Cop, Cadj, Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    refine Finset.sum_congr rfl fun r _ => Finset.sum_congr rfl fun ν _ => ?_
    refine Finset.sum_congr rfl fun X' _ => Finset.sum_congr rfl fun μ' _ => ?_
    ring

/-- **`C` is onto** under the one-alias symbol bound with `c₀ > 0`. -/
theorem Cop_surjective (β : G →+ F) (c : F → κ → ι → ℂ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ),
      c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤ ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (Cop β c) := by
  have hinj : Function.Injective (CCL β c) := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    have hw' : Cop β c (Cadj β c w) = 0 := hw
    have hadj := Cop_adjoint β c (Cadj β c w) w
    rw [hw'] at hadj
    simp only [Pi.zero_apply, mul_zero, Finset.sum_const_zero] at hadj
    simp_rw [Complex.conj_mul'] at hadj
    have hzero : ∑ y, ∑ ν, ‖Cadj β c w y ν‖ ^ 2 = 0 := by exact_mod_cast hadj.symm
    have hlow := Cadj_lower β c sec hsec hc₀ w
    rw [hzero, mul_zero] at hlow
    have hG : (0 : ℝ) < Fintype.card G := Nat.cast_pos.mpr Fintype.card_pos
    have hs0 : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ 0 := by
      by_contra hne
      have hne' : 0 < ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos (mul_pos hG hpos) hne'
      linarith
    have hs : ∑ X, ∑ μ, ‖w X μ‖ ^ 2 = 0 :=
      le_antisymm hs0 (Finset.sum_nonneg fun X _ => Finset.sum_nonneg fun μ _ => sq_nonneg _)
    funext X μ
    have h1 := (Finset.sum_eq_zero_iff_of_nonneg (fun X _ =>
      Finset.sum_nonneg fun μ _ => sq_nonneg ‖w X μ‖)).mp hs X (Finset.mem_univ _)
    have h2 := (Finset.sum_eq_zero_iff_of_nonneg (fun μ _ =>
      sq_nonneg ‖w X μ‖)).mp h1 μ (Finset.mem_univ _)
    simpa using h2
  have hsurj := LinearMap.injective_iff_surjective.mp hinj
  intro v
  obtain ⟨w, hw⟩ := hsurj v
  exact ⟨Cadj β c w, hw⟩

/-- The constraint operator with a real kernel on real fields. -/
def CopR (β : G →+ F) (c : F → κ → ι → ℝ) (a : F → ι → ℝ) : G → κ → ℝ :=
  fun X μ => ∑ r, ∑ ν, c r μ ν * a (β X + r) ν

/-- **The real constraint operator is onto** (take the real part of a complex preimage). -/
theorem CopR_surjective (β : G →+ F) (c : F → κ → ι → ℝ) (sec : AddChar G ℂ → AddChar F ℂ)
    (hsec : ∀ φ, res β (sec φ) = φ) {c₀ : ℝ} (hpos : 0 < c₀)
    (hc₀ : ∀ φ (v : κ → ℂ), c₀ * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR β c) := by
  intro w
  obtain ⟨a, ha⟩ := Cop_surjective β (fun r μ ν => (c r μ ν : ℂ)) sec hsec hpos hc₀
    (fun X μ => (w X μ : ℂ))
  refine ⟨fun y ν => (a y ν).re, ?_⟩
  funext X μ
  have h := congrFun (congrFun ha X) μ
  have h2 := congrArg Complex.re h
  simp only [Cop, Complex.re_sum, Complex.re_ofReal_mul, Complex.ofReal_re] at h2
  exact h2

end Onto

/-! ## §5 Gradients: `C ∇ = ∇ ∘ res` from a symbol identity -/

section Gradient

variable {F G : Type*} [AddCommGroup F] [Fintype F] [AddCommGroup G] [Fintype G]
variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- A translation-invariant "gradient" `(∇χ)_ν(y) = Σ_z d(z)_ν χ(y + z)`. -/
def grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ) (χ : H → ℂ) :
    H → τ → ℂ :=
  fun y ν => ∑ z, d z ν * χ (y + z)

/-- Its symbol `v(ψ)_ν = Σ_z d(z)_ν ψ(z)`. -/
def symv {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (ψ : AddChar H ℂ) (ν : τ) : ℂ :=
  ∑ z, d z ν * ψ z

theorem ftv_grad {H : Type*} [AddCommGroup H] [Fintype H] {τ : Type*} (d : H → τ → ℂ)
    (χ : H → ℂ) (ψ : AddChar H ℂ) (ν : τ) :
    ftv (grad d χ) ψ ν = symv d ψ ν * ft χ ψ := by
  unfold ftv grad symv
  rw [ft_sum, Finset.sum_mul]
  refine Finset.sum_congr rfl fun z _ => ?_
  rw [ft_const_mul, ft_translate]
  ring

omit [Fintype κ] in
/-- **Intertwining**: if `Q(ψ) v_F(ψ) = v_G(ψ ∘ β)` for every fine momentum, then
`C (∇_F χ) = ∇_G (χ ∘ β)` for every `χ` (命題 E の `C∇ = ∇res`). -/
theorem Cop_grad (β : G →+ F) (c : F → κ → ι → ℂ) (dF : F → ι → ℂ) (dG : G → κ → ℂ)
    (hsym : ∀ ψ μ, ∑ ν, sym c ψ μ ν * symv dF ψ ν = symv dG (res β ψ) μ) (χ : F → ℂ) :
    Cop β c (grad dF χ) = grad dG (fun X => χ (β X)) := by
  funext X μ
  have hcF : (Fintype.card F : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have key : ∀ φ, ftv (Cop β c (grad dF χ)) φ μ = ftv (grad dG (fun X => χ (β X))) φ μ := by
    intro φ
    apply mul_left_cancel₀ hcF
    rw [alias_C, ftv_grad, mul_left_comm (Fintype.card F : ℂ), ft_sample,
      mul_left_comm (symv dG φ μ)]
    congr 1
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ψ _ => ?_
    split_ifs with h
    · have e : ∑ ν, sym c ψ μ ν * ftv (grad dF χ) ψ ν = symv dG φ μ * ft χ ψ := by
        simp_rw [ftv_grad, ← mul_assoc]
        rw [← Finset.sum_mul, hsym, h]
      rw [e]
    · simp
  exact congrFun (ft_injective (f := fun X => Cop β c (grad dF χ) X μ)
    (g := fun X => grad dG (fun X => χ (β X)) X μ) key) X

end Gradient

/-! ## §6 The torus `(ℤ/L)^d → (ℤ/2L)^d`, `X ↦ 2X` -/

section Torus

instance neZero_two_mul (L : ℕ) [NeZero L] : NeZero (2 * L) :=
  ⟨by have := NeZero.ne L; omega⟩

/-- The doubling embedding `ℤ/L → ℤ/2L`, `x ↦ 2x`. -/
def dbl (L : ℕ) : ZMod L →+ ZMod (2 * L) :=
  ZMod.lift L ⟨zmultiplesHom (ZMod (2 * L)) 2, by
    rw [zmultiplesHom_apply, zsmul_eq_mul, Int.cast_natCast]
    have h := ZMod.natCast_self (2 * L)
    push_cast at h
    linear_combination h⟩

theorem dbl_intCast (L : ℕ) (x : ℤ) : dbl L (x : ZMod L) = 2 * (x : ZMod (2 * L)) := by
  unfold dbl
  rw [ZMod.lift_coe, zmultiplesHom_apply, zsmul_eq_mul]
  ring

/-- Coarse points of the torus: `X ↦ 2X` componentwise. -/
def betaT (d L : ℕ) : (Fin d → ZMod L) →+ (Fin d → ZMod (2 * L)) :=
  AddMonoidHom.compLeft (dbl L) (Fin d)

theorem card_fine (d L : ℕ) [NeZero L] :
    Fintype.card (Fin d → ZMod (2 * L)) = 2 ^ d * Fintype.card (Fin d → ZMod L) := by
  simp only [Fintype.card_fun, ZMod.card, Fintype.card_fin, mul_pow]

theorem dbl_injective (L : ℕ) [NeZero L] : Function.Injective (dbl L) := by
  rw [injective_iff_map_eq_zero]
  intro x hx
  have hx' : dbl L ((x.val : ℤ) : ZMod L) = 0 := by
    rwa [Int.cast_natCast, ZMod.natCast_zmod_val]
  rw [dbl_intCast] at hx'
  have h2 : ((2 * x.val : ℕ) : ZMod (2 * L)) = 0 := by push_cast; simpa using hx'
  rw [ZMod.natCast_eq_zero_iff] at h2
  have h3 : L ∣ x.val := Nat.dvd_of_mul_dvd_mul_left (by norm_num) h2
  have h4 : x.val = 0 := Nat.eq_zero_of_dvd_of_lt h3 (ZMod.val_lt x)
  exact (ZMod.val_eq_zero x).mp h4

theorem betaT_injective (d L : ℕ) [NeZero L] : Function.Injective (betaT d L) := by
  intro x y h
  funext μ
  exact dbl_injective L (congrFun h μ)

/-- **Exactly `2^d` aliases** on the torus: every coarse momentum has `2^d` fine momenta `ψ`
with `ψ ∘ β = φ` (the `k_η = p + πη`, `η ∈ {0,1}^d`). -/
theorem torus_card_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card = 2 ^ d := by
  have h := card_alias (betaT d L) (betaT_injective d L) φ
  rw [card_fine, Nat.cast_mul, mul_comm ((2 ^ d : ℕ) : ℂ) _] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have := mul_left_cancel₀ hG h
  exact_mod_cast this

/-- Every coarse momentum on the torus has a fine momentum above it (a section `sec` exists). -/
theorem torus_exists_alias (d L : ℕ) [NeZero L] (φ : AddChar (Fin d → ZMod L) ℂ) :
    ∃ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ, res (betaT d L) ψ = φ := by
  have h := torus_card_alias d L φ
  have hpos : 0 < (Finset.univ.filter fun ψ : AddChar (Fin d → ZMod (2 * L)) ℂ =>
      res (betaT d L) ψ = φ).card := by rw [h]; positivity
  obtain ⟨ψ, hψ⟩ := Finset.card_pos.mp hpos
  exact ⟨ψ, (Finset.mem_filter.mp hψ).2⟩

variable {ι κ : Type*} [Fintype ι] [Fintype κ]

/-- **(命題 E) the symbol of `C C†` on the torus**:
`(CC†w)^(φ) = 2^{-d} Σ_{ψ : ψ∘β = φ} Q(ψ) Q(ψ)† ŵ(φ)`, the `2^d` aliases of `φ`. -/
theorem torus_CCadj (d L : ℕ) [NeZero L] (c : (Fin d → ZMod (2 * L)) → κ → ι → ℂ)
    (w : (Fin d → ZMod L) → κ → ℂ) (φ : AddChar (Fin d → ZMod L) ℂ) (μ : κ) :
    (2 ^ d : ℂ) * ftv (Cop (betaT d L) c (Cadj (betaT d L) c w)) φ μ =
      ∑ ψ : AddChar (Fin d → ZMod (2 * L)) ℂ,
        if res (betaT d L) ψ = φ then
          ∑ ν, sym c ψ μ ν * ∑ l, conj (sym c ψ l ν) * ftv w φ l else 0 := by
  have h := alias_CCadj (betaT d L) c w φ μ
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (Fintype.card (Fin d → ZMod L) : ℂ) ≠ 0 :=
    Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  apply mul_left_cancel₀ hG
  rw [← h]
  ring

/-- **The constant of 命題 E on the four-dimensional torus**: the one-alias bound
`|Q(k_0)† v|² ≥ (121/1152)|v|²` (that is, `σ_min(Q(k_0)) ≥ 11√2/48`) gives
`‖C†w‖² ≥ (121/18432)‖w‖²` in real space. -/
theorem torus_Cadj_lower (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℂ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym c (sec φ) μ ν) * v μ‖ ^ 2)
    (w : (Fin 4 → ZMod L) → κ → ℂ) :
    121 / 18432 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 ≤ ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2 := by
  have h := Cadj_lower (betaT 4 L) c sec hsec hc₀ w
  rw [card_fine, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat] at h
  have hG : (0 : ℝ) < Fintype.card (Fin 4 → ZMod L) := Nat.cast_pos.mpr Fintype.card_pos
  have h' : (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (121 / 1152 * ∑ X, ∑ μ, ‖w X μ‖ ^ 2) ≤
      (Fintype.card (Fin 4 → ZMod L) : ℝ) *
      (2 ^ 4 * ∑ y, ∑ ν, ‖Cadj (betaT 4 L) c w y ν‖ ^ 2) := by
    calc _ = (Fintype.card (Fin 4 → ZMod L) : ℝ) * (121 / 1152) * ∑ X, ∑ μ, ‖w X μ‖ ^ 2 := by
            ring
      _ ≤ _ := h
      _ = _ := by ring
  have h'' := le_of_mul_le_mul_left h' hG
  linarith

/-- **The real constraint operator on the four-dimensional torus is onto** under the same
one-alias bound (the hypothesis `hsurj` of the tower theorems, for one stage). -/
theorem torus_CopR_surjective (L : ℕ) [NeZero L] (c : (Fin 4 → ZMod (2 * L)) → κ → ι → ℝ)
    (sec : AddChar (Fin 4 → ZMod L) ℂ → AddChar (Fin 4 → ZMod (2 * L)) ℂ)
    (hsec : ∀ φ, res (betaT 4 L) (sec φ) = φ)
    (hc₀ : ∀ φ (v : κ → ℂ), 121 / 1152 * ∑ μ, ‖v μ‖ ^ 2 ≤
      ∑ ν, ‖∑ μ, conj (sym (fun r μ ν => (c r μ ν : ℂ)) (sec φ) μ ν) * v μ‖ ^ 2) :
    Function.Surjective (CopR (betaT 4 L) c) :=
  CopR_surjective (betaT 4 L) c sec hsec (by norm_num) hc₀

end Torus

/-! ## §7 The alias representation of the one-step map on the projection (S1(a)) -/

section AliasRep

open scoped InnerProductSpace

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
variable {Z : Type*} [Fintype Z]

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def Aop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Pq (Sg ζ (Cr ζ (Pr ζ (Nr ζ y))))

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)` (all factors symmetric). -/
def Atr (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (ζ : Z) (y : V) : V :=
  (2 : ℝ) • Nr ζ (Pr ζ (Cr ζ (Sg ζ (Pq y))))

/-- The one-step map applied to the projection, `(𝓜P)(q) x = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ x`. -/
def MPop (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (x : V) : V :=
  (1 / 16 : ℝ) • ∑ ζ, Aop Pq Pr Cr Sg Nr ζ (Pr ζ (Atr Pq Pr Cr Sg Nr ζ x))

omit [Fintype Z] in
theorem Aop_adjoint (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric) (ζ : Z) (x y : V) :
    ⟪x, Aop Pq Pr Cr Sg Nr ζ y⟫_ℝ = ⟪Atr Pq Pr Cr Sg Nr ζ x, y⟫_ℝ := by
  unfold Aop Atr
  rw [inner_smul_right, inner_smul_left, ← hPq, ← hSg, ← hCr, ← hPr, ← hNr]
  simp

/-- **S1(a)**: if `P(r_ζ)` is an orthogonal projection commuting with `N(r_ζ)` and
`w_ζ := C(r_ζ) S_ζ P(q) x` lies in the range of `P(r_ζ)` (S1(b)), then
`⟨x, (𝓜P)(q) x⟩ = ¼ Σ_ζ |N(r_ζ) w_ζ|²`. -/
theorem alias_rep (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x))) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ = (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 := by
  unfold MPop
  rw [inner_smul_right, inner_sum, Finset.mul_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [Aop_adjoint Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr]
  have hA : Atr Pq Pr Cr Sg Nr ζ x = (2 : ℝ) • Nr ζ (Cr ζ (Sg ζ (Pq x))) := by
    unfold Atr
    rw [horth]
  rw [hA, map_smul, hNP, horth, inner_smul_left, inner_smul_right, real_inner_self_eq_norm_sq]
  simp only [RCLike.conj_to_real]
  ring

/-- With `w_ζ ⊥ s(r_ζ)` and a bound per alias `|N(r_ζ) w_ζ|² ≤ Σ_c b(ζ)_c u_c²` on coordinates
of `u = P(q)x`, the coordinate bound `hrep` of `OneStepNorm.MP_le` follows with
`D_c = ¼ Σ_ζ b(ζ)_c`. -/
theorem alias_rep_le (Pq : V →ₗ[ℝ] V) (Pr Cr Sg Nr : Z → V →ₗ[ℝ] V) (hPq : Pq.IsSymmetric)
    (hPr : ∀ ζ, (Pr ζ).IsSymmetric) (hCr : ∀ ζ, (Cr ζ).IsSymmetric)
    (hSg : ∀ ζ, (Sg ζ).IsSymmetric) (hNr : ∀ ζ, (Nr ζ).IsSymmetric)
    (hNP : ∀ ζ y, Pr ζ (Nr ζ y) = Nr ζ (Pr ζ y)) {ι : Type*} [Fintype ι]
    (coord : V → ι → ℝ) (b : Z → ι → ℝ) (x : V)
    (horth : ∀ ζ, Pr ζ (Cr ζ (Sg ζ (Pq x))) = Cr ζ (Sg ζ (Pq x)))
    (hb : ∀ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2 ≤ ∑ c, b ζ c * coord (Pq x) c ^ 2) :
    ⟪x, MPop Pq Pr Cr Sg Nr x⟫_ℝ ≤ ∑ c, ((1 / 4) * ∑ ζ, b ζ c) * coord (Pq x) c ^ 2 := by
  rw [alias_rep Pq Pr Cr Sg Nr hPq hPr hCr hSg hNr hNP x horth]
  calc (1 / 4) * ∑ ζ, ‖Nr ζ (Cr ζ (Sg ζ (Pq x)))‖ ^ 2
      ≤ (1 / 4) * ∑ ζ, ∑ c, b ζ c * coord (Pq x) c ^ 2 := by
        gcongr with ζ
        exact hb ζ
    _ = _ := by
        rw [Finset.sum_comm, Finset.mul_sum]
        refine Finset.sum_congr rfl fun c _ => ?_
        rw [mul_assoc, Finset.sum_mul]

end AliasRep

end TorusFourier

end


-- ===== new part : HrepConcrete.part.lean =====
/-!
# The coordinate bound `hrep` for the concrete one-step map 

Coordinates `Fin 4 → ℝ`, `θ = q/4`, aliases `ζ : Fin 4 → Bool`, `r_ζ/2 = θ + [ζ]π/2`.
* `s(r_ζ)_ν = sin(r_ν/2)`, `x_ν = 4α sin²(r_ν/2) = s_ν²/2` (`α = 1/8`), `C(r_ζ) = diag cos(r_ν/2)`,
  `S_ζ = diag (−1)^{ζ_ν}`, `s(q)_ν = sin(q_ν/2) = sin(2θ_ν)`;
* `N(r) u = diag(π) u + ½ diag(s) 𝔅 diag(s) u` with `𝔅 = 1 − E` off the diagonal;
* `P(p) y = y − (⟨s(p), y⟩/|s(p)|²) s(p)`;
* the quadratic form of the one-step map on the projection,
  `Qf(x) = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`, `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`
  (this is `⟨x, (𝓜P)(q) x⟩` for `𝓜P = (1/16) Σ_ζ A_ζ P(r_ζ) A_ζᵀ`).

Main results: `hrep_coord` `Qf(x) ≤ Σ_c D_c(σ) (P(q)x)_c²` with `σ_ν = sin²θ_ν` and the
alias coefficients `D_c`, `Dal_le` `D_c ≤ 429/512`, and `MP_coord_le`
`Qf(x) ≤ (429/512) ⟨x, P(q) x⟩` for every `θ` and `x` (no hypotheses).
-/

noncomputable section

namespace OneStepHrep

open Finset OneStepNorm
open scoped Real

/-! ## Coordinates -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

/-- The orthogonal projection onto `s^⊥` (the identity when `s = 0`). -/
def proj (s y : Fin 4 → ℝ) : Fin 4 → ℝ := fun i => y i - (dot s y / dot s s) * s i

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem dot_proj (s y : Fin 4 → ℝ) : dot s (proj s y) = 0 := by
  by_cases h : dot s s = 0
  · have hs : ∀ i, s i = 0 := by
      intro i
      have h' : ∑ j, s j * s j = 0 := h
      have := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => mul_self_nonneg (s j))).mp h' i
        (mem_univ _)
      exact mul_self_eq_zero.mp this
    unfold dot
    simp [hs]
  · have e : dot s (proj s y) = dot s y - (dot s y / dot s s) * dot s s := by
      unfold proj
      conv_lhs => unfold dot
      simp only [mul_sub, Finset.sum_sub_distrib]
      congr 1
      unfold dot
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      ring
    rw [e]
    field_simp
    ring

theorem proj_of_dot {s y : Fin 4 → ℝ} (h : dot s y = 0) : proj s y = y := by
  funext i; simp [proj, h]

theorem dot_proj_self (s y : Fin 4 → ℝ) : dot (proj s y) (proj s y) = dot y (proj s y) := by
  have h := dot_proj s y
  set p := proj s y with hp_def
  set a := dot s y / dot s s with ha_def
  have hp : ∀ i, p i = y i - a * s i := fun i => rfl
  have e : dot p p = dot y p - a * dot s p := by
    unfold dot
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun i _ => ?_
    rw [show p i * p i = (y i - a * s i) * p i by rw [← hp i]]
    ring
  rw [e, h, mul_zero, sub_zero]

/-! ## The concrete symbols -/

def phi (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := θ ν + (if ζ ν then π / 2 else 0)
def sR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.sin (phi θ ζ ν)
def cR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := Real.cos (phi θ ζ ν)
def sg (ζ : Fin 4 → Bool) (ν : Fin 4) : ℝ := if ζ ν then -1 else 1
def sQ (θ : Fin 4 → ℝ) (ν : Fin 4) : ℝ := Real.sin (2 * θ ν)

/-- `x = 4α s² = s²/2` (`α = 1/8`). -/
def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

/-- `π_μ = Π_{ν≠μ} (1 − x_ν)`. -/
def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

/-- `E_{μν} = Ef(x_ρ, x_σ)` with `{ρ, σ}` the complement of `{μ, ν}`; zero on the diagonal. -/
def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

/-- `A_ζᵀ x = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q) x`. -/
def Atr (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  fun μ => 2 * Nm (sR θ ζ)
    (proj (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) μ

/-- The quadratic form `⟨x, (𝓜P)(q) x⟩ = (1/16) Σ_ζ ⟨A_ζᵀ x, P(r_ζ) A_ζᵀ x⟩`. -/
def Qf (θ x : Fin 4 → ℝ) : ℝ :=
  (1 / 16) * ∑ ζ : Fin 4 → Bool, dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x))

/-! ## Properties of `N` -/

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

/-- `N` is symmetric. -/
theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

/-- `N s = s` (the leg identity `Σ_{ν≠μ} x_ν 𝔅_{μν} = 1 − π_μ`). -/
theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- `N` preserves `s^⊥`. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-! ## The square bound for one alias (S2 with the concrete `π`, `E`) -/

/-- The per-direction coefficient `(1+t)(π_c − x_c)² + (1+1/t) η_c`, with direction `c` first. -/
def coefT (t xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + t) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 + (1 + 1 / t) * eta xc x1 x2 x3

theorem EF_nonneg {x : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ EF x μ ν := by
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_nonneg (hx _) (hx _)

theorem Nm_eq_Nap (s u : Fin 4 → ℝ) (μ : Fin 4) :
    Nm s u μ = Nap (piF (xs s)) (fun ν => Real.sqrt (1 / 2) * s ν) (EF (xs s)) u μ := by
  have hc : Real.sqrt (1 / 2) * Real.sqrt (1 / 2) = 1 / 2 :=
    Real.mul_self_sqrt (by norm_num)
  unfold Nm Nap
  have e : ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (Real.sqrt (1 / 2) * s ν * u ν) =
      Real.sqrt (1 / 2) * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun ν _ => ?_
    ring
  rw [e]
  have : Real.sqrt (1 / 2) * s μ * (Real.sqrt (1 / 2) *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)) =
      (Real.sqrt (1 / 2) * Real.sqrt (1 / 2)) * s μ *
      ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν) := by ring
  rw [this, hc]

set_option maxRecDepth 8000 in
/-- **One alias**: for `w ⊥ s` and `x = s²/2 ∈ [0, 1/2]`,
`|N w|² ≤ Σ_c coef_c(x) w_c²` (directions `c` first, the others in increasing order). -/
theorem normSq_alias (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefT (3 / 10) (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefT (3 / 10) (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefT (3 / 10) (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefT (3 / 10) (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3 / 10)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefT, eta, rhoP, Ef, Matrix.cons_val]
  ring

/-! ## The alias values and the sum over aliases -/

theorem xs_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    xs (sR θ ζ) ν = xa (Real.sin (θ ν) ^ 2) (ζ ν) := by
  rw [← alias_x]
  unfold xs sR phi
  ring

theorem w_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (u : Fin 4 → ℝ) (ν : Fin 4) :
    (cR θ ζ ν * sg ζ ν * u ν) ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := by
  rw [← alias_w]
  unfold cR sg phi
  split_ifs <;> ring

theorem sum_bool4 (F : (Fin 4 → Bool) → ℝ) :
    ∑ ζ, F ζ = ∑ b0, ∑ b1, ∑ b2, ∑ b3, F ![b0, b1, b2, b3] := by
  let e : (Fin 4 → Bool) ≃ Bool × Bool × Bool × Bool :=
    { toFun := fun ζ => (ζ 0, ζ 1, ζ 2, ζ 3)
      invFun := fun b => ![b.1, b.2.1, b.2.2.1, b.2.2.2]
      left_inv := fun ζ => by funext i; fin_cases i <;> rfl
      right_inv := fun b => rfl }
  rw [← e.symm.sum_comp]
  simp only [Fintype.sum_prod_type]
  rfl

/-- The alias coefficients `D_c(σ) = ¼ Σ_ζ cos²(r_{ζ,c}/2) coef_c(x(r_ζ))`. -/
def Dal (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefT (3 / 10) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefT (3 / 10) (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefT (3 / 10) (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefT (3 / 10) (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

/-- **`D_c ≤ 429/512`** on the box `σ ∈ [0,1]⁴` (from `alias_coeff_le`, S3–S6). -/
theorem Dal_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    Dal σ c ≤ 429 / 512 := by
  fin_cases c
  · exact alias_coeff_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact alias_coeff_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact alias_coeff_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

/-! ## The coordinate bound -/

/-- One alias in full: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4|N(r_ζ) w_ζ|²` and the square bound. -/
theorem alias_term_le (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefT (3 / 10) (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefT (3 / 10) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  -- S1(b): `w ⊥ s(r_ζ)`
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

/-- **`hrep` in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ Σ_c D_c(σ) (P(q)x)_c²`, `σ_ν = sin²(q_ν/4)`. -/
theorem hrep_coord (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, Dal, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound in coordinates**: `⟨x, (𝓜P)(q) x⟩ ≤ (429/512) ⟨x, P(q) x⟩` for every
`q` and `x` (the coordinate form of `M P ≼ (429/512) P`, no hypotheses). -/
theorem MP_coord_le (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (429 / 512) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, Dal (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (429 / 512) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (Dal_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end OneStepHrep

end

-- ===== new part : Bridge.part.lean =====
/-!
# The concrete one-step map `𝓜` on families over `EuclideanSpace ℝ (Fin 4)` and the hypotheses
`hM`, `hPstep`, `hPs`, `hPP` of `UniformBracket.bracket_numeric`

`Q` is any index type of momenta with a coordinate map `th : Q → (Fin 4 → ℝ)` (`th q = q/4`) and
alias maps `rq : Q → (Fin 4 → Bool) → Q` with `th (rq q ζ) = th q / 2 + ζ π/4` (`r_ζ = (q+2πζ)/2`).
`(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`, `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`.
-/

noncomputable section

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

abbrev V := EuclideanSpace ℝ (Fin 4)

/-! ## Matrices for the coordinate maps -/

def projM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun i j => (if i = j then 1 else 0) - s i * s j / dot s s

def NM (s : Fin 4 → ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  Matrix.of fun μ ν =>
    if μ = ν then piF (xs s) μ else (1 / 2) * s μ * (1 - EF (xs s) μ ν) * s ν

theorem toE_apply (B : Matrix (Fin 4) (Fin 4) ℝ) (v : V) :
    Matrix.toEuclideanLin B v = WithLp.toLp 2 (B *ᵥ WithLp.ofLp v) := rfl

theorem diag_mulVec (d v : Fin 4 → ℝ) : Matrix.diagonal d *ᵥ v = fun i => d i * v i :=
  funext (Matrix.mulVec_diagonal d v)

theorem projM_mulVec (s y : Fin 4 → ℝ) : projM s *ᵥ y = proj s y := by
  funext i
  simp only [projM, Matrix.mulVec, dotProduct, Matrix.of_apply, sub_mul, Finset.sum_sub_distrib,
    ite_mul, one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, if_true, proj, dot]
  congr 1
  rw [div_mul_eq_mul_div, Finset.sum_mul, Finset.sum_div]
  refine Finset.sum_congr rfl fun j _ => ?_
  ring

theorem NM_mulVec (s u : Fin 4 → ℝ) : NM s *ᵥ u = Nm s u := by
  funext μ
  simp only [NM, Matrix.mulVec, dotProduct, Matrix.of_apply, Nm]
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ μ), if_pos rfl, Finset.mul_sum]
  congr 1
  refine Finset.sum_congr rfl fun ν hν => ?_
  rw [if_neg (Finset.ne_of_mem_erase hν).symm]
  ring

theorem projM_transpose (s : Fin 4 → ℝ) : (projM s)ᵀ = projM s := by
  ext i j
  simp only [projM, Matrix.transpose_apply, Matrix.of_apply]
  rw [mul_comm (s j) (s i)]
  by_cases h : i = j
  · subst h; rfl
  · rw [if_neg h, if_neg (Ne.symm h)]

theorem NM_transpose (s : Fin 4 → ℝ) : (NM s)ᵀ = NM s := by
  ext i j
  simp only [NM, Matrix.transpose_apply, Matrix.of_apply]
  fin_cases i <;> fin_cases j <;> simp [EF] <;> ring

/-! ## The alias data -/

/-- `θ(r_ζ) = θ/2 + ζ π/4`. -/
def thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Fin 4 → ℝ :=
  fun ν => θ ν / 2 + (if ζ ν then π / 4 else 0)

theorem sQ_thR (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : sQ (thR θ ζ) = sR θ ζ := by
  funext ν
  unfold sQ thR sR phi
  congr 1
  split_ifs <;> ring

/-- `A_ζᵀ = 2 N(r_ζ) P(r_ζ) C(r_ζ) S_ζ P(q)`. -/
def AtM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (NM (sR θ ζ) * projM (sR θ ζ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) *
    projM (sQ θ))

/-- `A_ζ = 2 P(q) S_ζ C(r_ζ) P(r_ζ) N(r_ζ)`. -/
def AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : Matrix (Fin 4) (Fin 4) ℝ :=
  (2 : ℝ) • (projM (sQ θ) * Matrix.diagonal (fun ν => cR θ ζ ν * sg ζ ν) * projM (sR θ ζ) *
    NM (sR θ ζ))

theorem AM_transpose (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : (AM θ ζ)ᵀ = AtM θ ζ := by
  unfold AM AtM
  rw [Matrix.transpose_smul]
  simp only [Matrix.transpose_mul, projM_transpose, NM_transpose, Matrix.diagonal_transpose,
    Matrix.mul_assoc]

theorem AtM_mulVec (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : AtM θ ζ *ᵥ x = Atr θ ζ x := by
  unfold AtM Atr
  rw [Matrix.smul_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec, ← Matrix.mulVec_mulVec]
  simp only [projM_mulVec, diag_mulVec, NM_mulVec]
  funext μ
  simp only [Pi.smul_apply, smul_eq_mul]

/-! ## Inner products in coordinates -/

theorem inner_coord (x y : V) : ⟪x, y⟫ = dot (WithLp.ofLp x) (WithLp.ofLp y) := by
  rw [EuclideanSpace.inner_eq_star_dotProduct]
  unfold dot dotProduct
  simp only [star_trivial]
  exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem inner_toE (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (x y : V) :
    ⟪x, Matrix.toEuclideanLin B y⟫ = ⟪Matrix.toEuclideanLin Bt x, y⟫ := by
  rw [inner_coord, inner_coord, toE_apply, toE_apply,
    WithLp.ofLp_toLp, WithLp.ofLp_toLp, ← hB]
  unfold dot
  have h := Matrix.dotProduct_mulVec (WithLp.ofLp x) B (WithLp.ofLp y)
  rw [← Matrix.mulVec_transpose] at h
  exact h

/-! ## The family map -/

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- The projection family `P(q)`. -/
def Pfam (q : Q) : V →ₗ[ℝ] V := Matrix.toEuclideanLin (projM (sQ (th q)))

/-- **The concrete one-step map** `(𝓜G)(q) = (1/16) Σ_ζ A_ζ(q) G(r_ζ) A_ζ(q)ᵀ`. -/
def Mfam : (Q → V →ₗ[ℝ] V) →ₗ[ℝ] (Q → V →ₗ[ℝ] V) where
  toFun G q := (1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool,
    Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)
  map_add' G H := by
    funext q
    simp only [Pi.add_apply, LinearMap.add_comp, LinearMap.comp_add, Finset.sum_add_distrib,
      smul_add]
  map_smul' c G := by
    funext q
    simp only [Pi.smul_apply, RingHom.id_apply, LinearMap.smul_comp, LinearMap.comp_smul,
      ← Finset.smul_sum, smul_comm c (1 / 16 : ℝ)]

theorem Mfam_inner (G : Q → V →ₗ[ℝ] V) (q : Q) (x : V) :
    ⟪x, Mfam th rq G q x⟫ = (1 / 16) * ∑ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
  show ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x⟫ = _
  rw [LinearMap.smul_apply, real_inner_smul_right, LinearMap.sum_apply, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  exact inner_toE _ _ (AM_transpose (th q) ζ) _ _

/-- **`hM`: the concrete `𝓜` preserves the Loewner order of families.** -/
theorem Mfam_orderPreserving : UniformBracket.OrderPreserving (Mfam th rq) := by
  intro A B hAB q x
  rw [Mfam_inner, Mfam_inner]
  gcongr with ζ
  exact hAB _ _

/-- **`hPs`**: `P(q)` is symmetric. -/
theorem Pfam_symm (q : Q) : (Pfam th q).IsSymmetric := by
  intro x y
  unfold Pfam
  rw [real_inner_comm, inner_toE _ _ (projM_transpose _) y x, real_inner_comm]

/-- **`hPP`**: `P(q)` is idempotent. -/
theorem Pfam_idem (q : Q) (x : V) : Pfam th q (Pfam th q x) = Pfam th q x := by
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp,
    projM_mulVec, projM_mulVec, proj_of_dot (dot_proj _ _)]

/-- `⟨x, (𝓜P)(q) x⟩ = Qf(x)` (the quadratic form bounded in `OneStepHrep`). -/
theorem Mfam_P_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (x : V) :
    ⟪x, Mfam th rq (Pfam th) q x⟫ = Qf (th q) (WithLp.ofLp x) := by
  rw [Mfam_inner]
  unfold Qf
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp,
    WithLp.ofLp_toLp, AtM_mulVec, projM_mulVec]

/-- **`hPstep` for the concrete `𝓜`**: `𝓜 P ≼ (429/512) P` (no hypotheses beyond the alias maps). -/
theorem Mfam_P_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((429 / 512 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact MP_coord_le (th q) (WithLp.ofLp x)

/-- `429/512 ≤ 0.838` (the `hlam` of `bracket_numeric`). -/
theorem lam_le : (429 / 512 : ℝ) ≤ 0.838 := by norm_num

/-- The model index set `Q = ℝ⁴` (`θ = q/4`) with `r_ζ` as alias maps. -/
theorem Mfam_P_le_R4 :
    UniformBracket.Lw (Mfam (fun θ : Fin 4 → ℝ => θ) thR (Pfam fun θ => θ))
      ((429 / 512 : ℝ) • Pfam fun θ : Fin 4 → ℝ => θ) :=
  Mfam_P_le (fun θ => θ) thR (fun _ _ => rfl)

end OneStepBridge

end

-- ===== new part : ETBridge.part.lean =====
/-!
# `‖N‖ ≤ 1`, the step `𝓜(P/ω) ≼ P/ω + (15/8) P` (`e_T ≤ 15/8`), and `bracket_numeric` for the
concrete `𝓜`

* `IminusN_form`, `IplusN_form`: `⟨u, (I ∓ N)u⟩` as sums of squares (Lemma 2(b) of and its
  `+` companion), so `−I ≼ N ≼ I`; `Nm_normSq_le`: `|N u|² ≤ |u|²` from these two without the
  spectral theorem (`2(|u|² − |Nu|²) = ⟨v,(I−N)v⟩ + ⟨w,(I+N)w⟩`, `v = u + Nu`, `w = u − Nu`).
* `eT_alias`: for `σ ∈ [0,1]⁴` with `ω(q) > 0`, `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`
  (the alias nearest to the origin `ζ*` plays the role of `ζ = 0`, so no box for `q` is needed).
* `Mfam_B_le`: `𝓜(P/ω) ≼ P/ω + (15/8) P` (the hypothesis `hBstep`).
* `bracket_concrete`: `UniformBracket.bracket_numeric` for the concrete `𝓜`, `P`, `ω`; the
  remaining hypotheses are the lower side `hlow`, symmetry `hsym` and the inverse `H`.
-/

noncomputable section

namespace OneStepET

open Finset OneStepNorm OneStepHrep OneStepBridge Matrix
open scoped Real RealInnerProductSpace

/-! ## Bilinearity of `dot` and linearity of `N` -/

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (b + c) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.add_apply]; ring

theorem dot_sub_right (a b c : Fin 4 → ℝ) : dot a (b - c) = dot a b - dot a c := by
  unfold dot; rw [← Finset.sum_sub_distrib]
  exact Finset.sum_congr rfl fun i _ => by simp only [Pi.sub_apply]; ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (a + b) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_sub_left (a b c : Fin 4 → ℝ) : dot (a - b) c = dot a c - dot b c := by
  rw [dot_comm, dot_sub_right, dot_comm c a, dot_comm c b]

theorem Nm_add (s u v : Fin 4 → ℝ) : Nm s (u + v) = Nm s u + Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_add]

theorem Nm_sub (s u v : Fin 4 → ℝ) : Nm s (u - v) = Nm s u - Nm s v := by
  rw [← NM_mulVec, ← NM_mulVec, ← NM_mulVec, Matrix.mulVec_sub]

/-! ## `−I ≼ N ≼ I` and `|N u| ≤ |u|` -/

/-- `𝔅_{μν} = 1 − E_{μν}`. -/
def BF (s : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := 1 - EF (xs s) μ ν

set_option maxRecDepth 8000 in
/-- **Lemma 2(b)**: `⟨u, (I − N)u⟩ = ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ − s_μ u_ν)²`. -/
theorem IminusN_form (s u : Fin 4 → ℝ) :
    dot u u - dot u (Nm s u) =
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

set_option maxRecDepth 8000 in
/-- `⟨u, (I + N)u⟩ = 2 Σ_μ π_μ u_μ² + ¼ Σ_{μ≠ν} 𝔅_{μν} (s_ν u_μ + s_μ u_ν)²`. -/
theorem IplusN_form (s u : Fin 4 → ℝ) :
    dot u u + dot u (Nm s u) = 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 +
      (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
  unfold dot Nm BF
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem Ef_le_one {y z : ℝ} (hy : 0 ≤ y ∧ y ≤ 1 / 2) (hz : 0 ≤ z ∧ z ≤ 1 / 2) :
    Ef y z ≤ 1 := by
  have := Ef_le hy.1 hz.1
  linarith [hy.2, hz.2]

theorem BF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ ν : Fin 4) :
    0 ≤ BF s μ ν := by
  unfold BF
  fin_cases μ <;> fin_cases ν <;> simp [EF] <;> exact Ef_le_one (hx _) (hx _)

theorem piF_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) (μ : Fin 4) :
    0 ≤ piF (xs s) μ := by
  have h0 : 0 ≤ 1 - xs s 0 := by linarith [(hx 0).2]
  have h1 : 0 ≤ 1 - xs s 1 := by linarith [(hx 1).2]
  have h2 : 0 ≤ 1 - xs s 2 := by linarith [(hx 2).2]
  have h3 : 0 ≤ 1 - xs s 3 := by linarith [(hx 3).2]
  fin_cases μ <;> simp [piF] <;> positivity

theorem IminusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot u (Nm s u) ≤ dot u u := by
  have h := IminusN_form s u
  have : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ - s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

theorem IplusN_nonneg {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : -dot u u ≤ dot u (Nm s u) := by
  have h := IplusN_form s u
  have h1 : 0 ≤ 2 * ∑ μ, piF (xs s) μ * u μ ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => mul_nonneg (piF_nonneg hx μ) (sq_nonneg _)
  have h2 : 0 ≤ (1 / 4) * ∑ μ, ∑ ν ∈ univ.erase μ, BF s μ ν * (s ν * u μ + s μ * u ν) ^ 2 := by
    apply mul_nonneg (by norm_num)
    exact Finset.sum_nonneg fun μ _ => Finset.sum_nonneg fun ν _ =>
      mul_nonneg (BF_nonneg hx μ ν) (sq_nonneg _)
  linarith

/-- **`‖N‖ ≤ 1`** (Lemma 2(c), `ν ≤ 1`): `|N u|² ≤ |u|²`. -/
theorem Nm_normSq_le {s : Fin 4 → ℝ} (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2)
    (u : Fin 4 → ℝ) : dot (Nm s u) (Nm s u) ≤ dot u u := by
  set A := Nm s u with hA
  set AA := Nm s A with hAA
  have h1 := IminusN_nonneg hx (u + A)
  have h2 := IplusN_nonneg hx (u - A)
  rw [Nm_add, Nm_sub] at *
  rw [← hA, ← hAA] at h1 h2
  simp only [dot_add_left, dot_add_right, dot_sub_left, dot_sub_right] at h1 h2
  have s1 : dot u AA = dot A A := by rw [hAA, Nm_symm]
  have s2 : dot A u = dot u A := dot_comm _ _
  have s3 : dot AA u = dot A A := by rw [dot_comm, s1]
  have s4 : dot AA A = dot A AA := dot_comm _ _
  linarith

/-! ## The scalar step `e_T ≤ 15/8` with the nearest alias -/

/-- `ω(r_ζ) = Σ_ν 8 x_ν(r_ζ)`. -/
def omR (σ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) : ℝ := ∑ ν, 8 * xa (σ ν) (ζ ν)

/-- `ω(q) = Σ_ν 16 σ_ν (1 − σ_ν)`. -/
def omQ (σ : Fin 4 → ℝ) : ℝ := ∑ ν, 16 * (σ ν * (1 - σ ν))

/-- The alias nearest to the origin. -/
def zstar (σ : Fin 4 → ℝ) : Fin 4 → Bool := fun ν => decide (1 / 2 < σ ν)

theorem xa_far {σ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} (ν : Fin 4)
    (h : ζ ν ≠ zstar σ ν) : 1 / 4 ≤ xa (σ ν) (ζ ν) := by
  unfold zstar at h
  by_cases hs : 1 / 2 < σ ν
  · have : ζ ν = false := by
      cases hz : ζ ν
      · rfl
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
    rw [this]; simp only [xa]; linarith
  · have : ζ ν = true := by
      cases hz : ζ ν
      · rw [hz] at h; exfalso; simp at h; linarith [show (2 : ℝ)⁻¹ = 1 / 2 by norm_num]
      · rfl
    have hs' : σ ν ≤ 1 / 2 := le_of_not_gt hs
    rw [this]; simp only [xa]; linarith

theorem omR_far {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) {ζ : Fin 4 → Bool}
    (h : ζ ≠ zstar σ) : 2 ≤ omR σ ζ := by
  obtain ⟨ν, hν⟩ : ∃ ν, ζ ν ≠ zstar σ ν := by
    by_contra hc
    exact h (funext fun ν => by by_contra h'; exact hc ⟨ν, h'⟩)
  have hf := xa_far ν hν
  unfold omR
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ ν)]
  have : 0 ≤ ∑ x ∈ univ.erase ν, 8 * xa (σ x) (ζ x) :=
    Finset.sum_nonneg fun x _ => by
      have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
  linarith

theorem omR_near {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) :
    omQ σ ≤ 4 * omR σ (zstar σ) := by
  unfold omQ omR
  rw [Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  unfold zstar
  have h0 := (hσ ν).1
  have h1 := (hσ ν).2
  by_cases hs : 1 / 2 < σ ν
  · simp only [hs, decide_true, xa]; nlinarith
  · simp only [hs, decide_false, xa]; nlinarith

theorem wa_le {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) (b : Bool) : 0 ≤ wa σ b ∧ wa σ b ≤ 1 := by
  cases b <;> simp only [wa] <;> constructor <;> linarith

/-- **The alias sum of `e_T`**: `¼ Σ_ζ cos²(r_{ζ,μ}/2)/ω(r_ζ) ≤ 1/ω(q) + 15/8`. -/
theorem eT_alias {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (hω : 0 < omQ σ) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omQ σ)⁻¹ + 15 / 8 := by
  have hnear := omR_near hσ
  have hpos : 0 < omR σ (zstar σ) := by linarith
  have hF : ∀ ζ, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ (omR σ ζ)⁻¹ := by
    intro ζ
    have hw := wa_le (hσ μ).1 (hσ μ).2 (ζ μ)
    have : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    nlinarith
  have hstar : (omR σ (zstar σ))⁻¹ ≤ 4 * (omQ σ)⁻¹ := by
    rw [inv_le_comm₀ hpos (by positivity), mul_inv, inv_inv]
    calc 4⁻¹ * omQ σ ≤ 4⁻¹ * (4 * omR σ (zstar σ)) := by gcongr
      _ = omR σ (zstar σ) := by ring
  have hfar : ∀ ζ ∈ (univ : Finset (Fin 4 → Bool)).erase (zstar σ),
      wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹ ≤ 1 / 2 := by
    intro ζ hζ
    have h2 := omR_far hσ (Finset.ne_of_mem_erase hζ)
    have : (omR σ ζ)⁻¹ ≤ 1 / 2 := by
      rw [inv_le_comm₀ (by linarith) (by norm_num)]; norm_num; linarith
    exact (hF ζ).trans this
  rw [← Finset.add_sum_erase _ _ (Finset.mem_univ (zstar σ))]
  have hsum := Finset.sum_le_sum hfar
  have hcard : ((univ : Finset (Fin 4 → Bool)).erase (zstar σ)).card = 15 := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, Fintype.card_fun,
      Fintype.card_bool, Fintype.card_fin]
    rfl
  rw [Finset.sum_const, hcard, nsmul_eq_mul] at hsum
  have h0 := (hF (zstar σ)).trans hstar
  push_cast at hsum
  linarith

/-! ## The step `𝓜(P/ω) ≼ P/ω + (15/8) P` -/

/-- `ω(q) = Σ_ν 4 sin²(q_ν/2)` from the coordinate `θ = q/4`. -/
def omF {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : ℝ := ∑ ν, 4 * sQ (th q) ν ^ 2

theorem omF_eq {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) :
    omF th q = omQ (fun ν => Real.sin (th q ν) ^ 2) := by
  unfold omF omQ sQ
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [omega_dir]; ring

theorem omF_alias {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool) :
    omF th (rq q ζ) = omR (fun ν => Real.sin (th q ν) ^ 2) ζ := by
  unfold omF omR
  rw [hrq, sQ_thR]
  refine Finset.sum_congr rfl fun ν _ => ?_
  rw [← xs_alias]; unfold xs; ring

theorem omF_le {Q : Type*} (th : Q → (Fin 4 → ℝ)) (q : Q) : omF th q ≤ 16 := by
  unfold omF sQ
  rw [Fin.sum_univ_four]
  have h0 := Real.sin_sq_le_one (2 * th q 0)
  have h1 := Real.sin_sq_le_one (2 * th q 1)
  have h2 := Real.sin_sq_le_one (2 * th q 2)
  have h3 := Real.sin_sq_le_one (2 * th q 3)
  linarith

/-- One alias, as an equality: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ = 4 |N(r_ζ) w_ζ|²`. -/
theorem alias_term_eq (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) =
      4 * dot (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν))
        (Nm (sR θ ζ) (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)) := by
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [proj_of_dot hw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun μ _ => by ring

/-- One alias, the `e_T` bound: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_one (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have h := Nm_normSq_le hx (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
  have e : dot (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν)
      (fun ν => cR θ ζ ν * sg ζ ν * proj (sQ θ) x ν) =
      ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  rw [e] at h
  linarith

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hBstep` for the concrete `𝓜`**: `𝓜(P/ω) ≼ P/ω + (15/8) P` (where `ω > 0`). -/
theorem Mfam_B_le (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_one (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * (omR σ ζ)⁻¹) * u μ ^ 2 ≤
      ∑ μ, ((omQ σ)⁻¹ + 15 / 8) * u μ ^ 2 :=
    Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right (eT_alias hσ hω' μ) (sq_nonneg _)
  have hRHS : ⟪x, ((fun q => (omF th q)⁻¹ • Pfam th q) + (15 / 8 : ℝ) • Pfam th) q x⟫ =
      ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by
    simp only [Pi.add_apply, Pi.smul_apply, LinearMap.add_apply, LinearMap.smul_apply,
      inner_add_right, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
    ring
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = ((omQ σ)⁻¹ + 15 / 8) * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-! ## `bracket_numeric` for the concrete `𝓜` -/

/-- **The bracket for the concrete one-step map**: with `ω(q) = Σ 4 sin²(q_ν/2) > 0` on `Q` and the
alias maps, every hypothesis of `UniformBracket.bracket_numeric` about `𝓜`, `P`, `ω`, `λ`, `e`
and `G₀ = P/ω` is discharged; what remains is the lower side `hlow`, the symmetry `hsym` of the
stages and the inverse `H` on the range of `P`. -/
theorem bracket_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
    (hsym : ∀ k q, ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric)
    {H : ℕ → Q → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q (H k q x) =
      Pfam th q x)
    (hHP : ∀ k q x, Pfam th q (H k q x) = H k q x) (k : ℕ) (q : Q) (x : V) :
    omF th q / 745 * ⟪x, Pfam th q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF th q * ⟪x, Pfam th q x⟫ :=
  UniformBracket.bracket_numeric (Mfam th rq) (Mfam_orderPreserving th rq) (Pfam_symm th)
    (Pfam_idem th) hω (omF_le th) (by norm_num : (0 : ℝ) ≤ 429 / 512) lam_le
    (by norm_num : (0 : ℝ) ≤ 15 / 8) le_rfl hσ ha (Mfam_P_le th rq hrq) (Mfam_B_le th rq hrq hω)
    (UniformBracket.Lw.refl _) hlow hsym hH hHP k q x

end OneStepET

end

-- ===== new part : Final.part.lean =====
/-!
# The symmetry of the stages and the index set `ω > 0`

* `Mfam_symm`, `iterate_symm`: `𝓜` maps symmetric families to symmetric families, so every stage
  `G_k = 𝓜^k(P/ω)` is symmetric (the hypothesis `hsym`).
* `Qpos`: the momenta with `ω(q) > 0` (`q ∉ 2πℤ⁴`), closed under the aliases `q ↦ r_ζ`
  (`s(q)_ν = ±2 sin(r_ν/2) cos(r_ν/2)`), and `bracket_Qpos`: the bracket with the remaining
  hypotheses `hlow`, `hH`, `hHP` only.
-/

noncomputable section

namespace OneStepFinal

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem term_symm (B Bt : Matrix (Fin 4) (Fin 4) ℝ) (hB : Bᵀ = Bt) (G : V →ₗ[ℝ] V)
    (hG : G.IsSymmetric) (x y : V) :
    ⟪(Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) x, y⟫ =
      ⟪x, (Matrix.toEuclideanLin B ∘ₗ G ∘ₗ Matrix.toEuclideanLin Bt) y⟫ := by
  simp only [LinearMap.comp_apply]
  rw [real_inner_comm, inner_toE B Bt hB, inner_toE B Bt hB x, ← hG]
  exact real_inner_comm _ _

/-- `𝓜` preserves symmetric families. -/
theorem Mfam_symm (G : Q → V →ₗ[ℝ] V) (hG : ∀ r, (G r).IsSymmetric) (q : Q) :
    (Mfam th rq G q).IsSymmetric := by
  intro x y
  show ⟪((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) x, y⟫ =
    ⟪x, ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y⟫
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    LinearMap.sum_apply, LinearMap.sum_apply, sum_inner, inner_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  exact term_symm _ _ (AM_transpose (th q) ζ) _ (hG _) x y

theorem smul_symm {T : V →ₗ[ℝ] V} (hT : T.IsSymmetric) (c : ℝ) : (c • T).IsSymmetric := by
  intro x y
  rw [LinearMap.smul_apply, LinearMap.smul_apply, real_inner_smul_left, real_inner_smul_right,
    hT]

/-- **`hsym`**: every stage `𝓜^k(P/ω)` is symmetric. -/
theorem iterate_symm (k : ℕ) (q : Q) :
    ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q).IsSymmetric := by
  induction k generalizing q with
  | zero => exact smul_symm (Pfam_symm th q) _
  | succ k ih =>
    rw [Function.iterate_succ_apply']
    exact Mfam_symm th rq _ ih q

/-! ## The momenta with `ω > 0` -/

/-- Momenta `q = 4θ` with `ω(q) > 0`. -/
abbrev Qpos : Type := {θ : Fin 4 → ℝ // 0 < ∑ ν, 4 * sQ θ ν ^ 2}

theorem sQ_eq_zero_of_sR {θ : Fin 4 → ℝ} {ζ : Fin 4 → Bool} {ν : Fin 4}
    (h : sR θ ζ ν = 0) : sQ θ ν = 0 := by
  unfold sR phi at h
  unfold sQ
  rw [Real.sin_two_mul]
  cases hz : ζ ν
  · rw [hz] at h; simp at h; rw [h]; ring
  · rw [hz] at h; simp [Real.sin_add_pi_div_two] at h; rw [h]; ring

theorem pos_alias {θ : Fin 4 → ℝ} (hθ : 0 < ∑ ν, 4 * sQ θ ν ^ 2) (ζ : Fin 4 → Bool) :
    0 < ∑ ν, 4 * sQ (thR θ ζ) ν ^ 2 := by
  rw [sQ_thR]
  by_contra hc
  have hle : ∑ ν, 4 * sR θ ζ ν ^ 2 ≤ 0 := le_of_not_gt hc
  have h0 : ∀ ν, sR θ ζ ν = 0 := by
    intro ν
    have hs := (Finset.sum_eq_zero_iff_of_nonneg (fun i _ => by positivity)).mp
      (le_antisymm hle (Finset.sum_nonneg fun i _ => by positivity)) ν (Finset.mem_univ _)
    have : sR θ ζ ν ^ 2 = 0 := by linarith
    exact pow_eq_zero_iff (n := 2) (by norm_num) |>.mp this
  have : ∑ ν, 4 * sQ θ ν ^ 2 = 0 := by
    refine Finset.sum_eq_zero fun ν _ => ?_
    rw [sQ_eq_zero_of_sR (h0 ν)]; ring
  linarith

/-- The aliases on `Qpos`. -/
def rqPos (q : Qpos) (ζ : Fin 4 → Bool) : Qpos := ⟨thR q.1 ζ, pos_alias q.2 ζ⟩

/-- **The bracket on `Qpos` for the concrete `𝓜`**: everything is discharged except the lower
side `hlow` and the inverse `H` on the range of `P`. -/
theorem bracket_Qpos {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)))
    {H : ℕ → Qpos → V →ₗ[ℝ] V}
    (hH : ∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) = Pfam Subtype.val q x)
    (hHP : ∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) (k : ℕ) (q : Qpos) (x : V) :
    omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤ ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
      ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_concrete Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2) hσ ha hlow
    (iterate_symm Subtype.val rqPos) hH hHP k q x

/-! ## The inverse on the range of `P` from the lower side -/

/-- In finite dimension, a lower bound `c ⟨x, Px⟩ ≤ ⟨x, Gx⟩` (`c > 0`) with `ran G ⊆ ran P`
gives `H` with `G H = P` and `P H = H` (the inverse of `G` on `ran P`). -/
theorem exists_inv_on_range {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
    [FiniteDimensional ℝ E] (P G : E →ₗ[ℝ] E) (hPP : ∀ x, P (P x) = P x)
    (hPG : ∀ x, P (G x) = G x) {c : ℝ} (hc : 0 < c) (hlow : ∀ x, c * ⟪x, P x⟫ ≤ ⟪x, G x⟫) :
    ∃ H : E →ₗ[ℝ] E, (∀ x, G (H x) = P x) ∧ (∀ x, P (H x) = H x) := by
  set W := LinearMap.range P
  have hGW : ∀ w ∈ W, G w ∈ W := fun w _ => ⟨G w, hPG w⟩
  let GW : W →ₗ[ℝ] W := G.restrict hGW
  have hinj : Function.Injective GW := by
    rw [← LinearMap.ker_eq_bot, LinearMap.ker_eq_bot']
    intro w hw
    obtain ⟨y, hy⟩ := w.2
    have h0 : G (w : E) = 0 := congrArg Subtype.val hw
    have hPw : P (w : E) = w := by rw [← hy, hPP]
    have h1 := hlow (w : E)
    rw [h0, inner_zero_right, hPw, real_inner_self_eq_norm_sq] at h1
    have h2 : ‖(w : E)‖ ^ 2 ≤ 0 := by
      by_contra hne
      have : 0 < ‖(w : E)‖ ^ 2 := lt_of_not_ge hne
      have := mul_pos hc this
      linarith
    have h3 : ‖(w : E)‖ = 0 := by nlinarith [norm_nonneg (w : E)]
    exact Subtype.ext (norm_eq_zero.mp h3)
  let e := LinearEquiv.ofInjectiveEndo GW hinj
  refine ⟨W.subtype ∘ₗ (e.symm : W →ₗ[ℝ] W) ∘ₗ P.rangeRestrict, ?_, ?_⟩
  · intro x
    exact congrArg Subtype.val (e.apply_symm_apply (P.rangeRestrict x))
  · intro x
    obtain ⟨y, hy⟩ := (e.symm (P.rangeRestrict x)).2
    show P ((e.symm (P.rangeRestrict x) : W) : E) = ((e.symm (P.rangeRestrict x) : W) : E)
    rw [← hy, hPP]

theorem projM_AM (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (w : Fin 4 → ℝ) :
    projM (sQ θ) *ᵥ (AM θ ζ *ᵥ w) = AM θ ζ *ᵥ w := by
  unfold AM
  simp only [Matrix.smul_mulVec, Matrix.mulVec_smul, ← Matrix.mulVec_mulVec, projM_mulVec]
  rw [proj_of_dot (dot_proj _ _)]

/-- `ran (𝓜G)(q) ⊆ ran P(q)`. -/
theorem Pfam_Mfam (G : Q → V →ₗ[ℝ] V) (q : Q) (y : V) :
    Pfam th q (Mfam th rq G q y) = Mfam th rq G q y := by
  show Pfam th q (((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y) =
    ((1 / 16 : ℝ) • ∑ ζ : Fin 4 → Bool, Matrix.toEuclideanLin (AM (th q) ζ) ∘ₗ
      G (rq q ζ) ∘ₗ Matrix.toEuclideanLin (AtM (th q) ζ)) y
  rw [LinearMap.smul_apply, map_smul, LinearMap.sum_apply, map_sum]
  congr 1
  refine Finset.sum_congr rfl fun ζ _ => ?_
  simp only [LinearMap.comp_apply]
  unfold Pfam
  rw [toE_apply, toE_apply, WithLp.ofLp_toLp, projM_AM]

/-- Every stage has range in `ran P`. -/
theorem iterate_P (k : ℕ) (q : Q) (y : V) :
    Pfam th q ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y) =
      (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q y := by
  cases k with
  | zero =>
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, map_smul, Pfam_idem]
  | succ k =>
    rw [Function.iterate_succ_apply']
    exact Pfam_Mfam th rq _ q y

/-- **The bracket on `Qpos` with the lower side as the only hypothesis**: the inverses `H_k` on
`ran P` exist, and `(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage. -/
theorem bracket_Qpos_low {σ a : ℝ} (hσ : 0.04452 ≤ σ) (ha : a = 4 / π ^ 2 * σ ^ 2)
    (hlow : ∀ k, UniformBracket.Lw (a • fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)
      ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ := by
  have ha0 : 0 < a := by
    rw [ha]
    have : 0 < σ := by linarith
    positivity
  have hex : ∀ k (q : Qpos), ∃ H : V →ₗ[ℝ] V,
      (∀ x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H x) = Pfam Subtype.val q x) ∧
      (∀ x, Pfam Subtype.val q (H x) = H x) := by
    intro k q
    have hω : 0 < omF Subtype.val q := q.2
    refine exists_inv_on_range (Pfam Subtype.val q) _ (Pfam_idem Subtype.val q)
      (iterate_P Subtype.val rqPos k q) (mul_pos ha0 (inv_pos.mpr hω)) fun x => ?_
    have h := hlow k q x
    simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right] at h
    linarith
  choose H hH hHP using hex
  exact ⟨H, hH, hHP, fun k q x => bracket_Qpos hσ ha hlow hH hHP k q x⟩

end OneStepFinal

end


-- ===== new part : LowerSide.part.lean =====
/-!
# The lower side `hlow` of Theorem 1 without the box 

For every stage `k` and every momentum `q` with `ω(q) > 0` (no box `q ∈ [−π, π]⁴`):
`G_k(q) = 𝓜^k(P/ω)(q) ≽ a P(q)/ω(q)` with `a = (4/π²)·0.04452²`.

The argument keeps one alias per stage, the alias `ζ*` nearest to the origin
(`ζ*_ν = 1` exactly when `sin²(q_ν/4) > 1/2`), and uses three facts:
* the scale: if `sin²(q_ν/2) ≤ sin²(β)` (`β = π/2^{m+1}`) for all `ν`, then at `r = r_{ζ*}`
  `sin²(r_ν/2) ≤ sin²(β/2)` (`alias_scale`);
* one alias from below: with `w = C(r) S_ζ P(q) x ⊥ s(r)`, `|N(r) w| ≥ n(ξ)|w|` (`Nm_lower`,
  `Nm_sq_lower`) and `|w|² ≥ (1 − b)|P(q)x|²`; the ratio `ω(q) ≥ 4(1 − b) ω(r)` (`omega_ratio`);
* the potentials `τ_m = (2Γ_m/π)⁴ ν_m` with `Γ_m = 2^m sin(π/2^{m+1})`, telescoping exactly in
  the cosine factors (`Gam_rec`, Viète), and `ν_m` absorbing the factors `n(ξ_{m+1})²`.
-/

noncomputable section

namespace OneStepLower

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET OneStepFinal Matrix
open scoped Real RealInnerProductSpace

/-! ## 1. `N` on `s^⊥` from below -/

/-- `n(ξ) = (1 − ξ)³ − ξ − ξ²/2 − ξ³` (Lemma 2(e)). -/
def nlow (ξ : ℝ) : ℝ := (1 - ξ) ^ 3 - ξ - ξ ^ 2 / 2 - ξ ^ 3

/-- The multiplier of `⟨s, u⟩` in the identity `Nm_form_perp`. -/
def Lmul (s u : Fin 4 → ℝ) : ℝ :=
  (s 0 ^ 3 * u 0 - s 0 ^ 2 * s 1 * u 1 - s 0 ^ 2 * s 2 * u 2 - s 0 ^ 2 * s 3 * u 3
    - s 0 * s 1 ^ 2 * u 0 - s 0 * s 2 ^ 2 * u 0 - s 0 * s 3 ^ 2 * u 0 + 4 * s 0 * u 0
    + s 1 ^ 3 * u 1 - s 1 ^ 2 * s 2 * u 2 - s 1 ^ 2 * s 3 * u 3 - s 1 * s 2 ^ 2 * u 1
    - s 1 * s 3 ^ 2 * u 1 + 4 * s 1 * u 1 + s 2 ^ 3 * u 2 - s 2 ^ 2 * s 3 * u 3
    - s 2 * s 3 ^ 2 * u 2 + 4 * s 2 * u 2 + s 3 ^ 3 * u 3 + 4 * s 3 * u 3) / 8

/-- The diagonal coefficient `d_μ = π_μ − x_μ(1 + x_μ − X/2)`. -/
def dco (x : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF x μ - x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2)

/-- The cubic remainder `Σ_{μ<ν} x_ρ x_σ s_μ s_ν u_μ u_ν`. -/
def Rem (s u : Fin 4 → ℝ) : ℝ :=
  xs s 2 * xs s 3 * (s 0 * s 1 * u 0 * u 1) + xs s 1 * xs s 3 * (s 0 * s 2 * u 0 * u 2)
  + xs s 1 * xs s 2 * (s 0 * s 3 * u 0 * u 3) + xs s 0 * xs s 3 * (s 1 * s 2 * u 1 * u 2)
  + xs s 0 * xs s 2 * (s 1 * s 3 * u 1 * u 3) + xs s 0 * xs s 1 * (s 2 * s 3 * u 2 * u 3)

set_option maxRecDepth 8000 in
/-- **The identity of Lemma 2(e)**: `⟨u, N u⟩ = Σ d_μ u_μ² + ⅓ Rem + ⟨s, u⟩ L`. -/
theorem Nm_form_perp (s u : Fin 4 → ℝ) :
    dot u (Nm s u) = ∑ μ, dco (xs s) μ * u μ ^ 2 + (1 / 3) * Rem s u + dot s u * Lmul s u := by
  unfold dot Nm dco Rem Lmul
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  ring

theorem prod3_lower {a b c ξ : ℝ} (ha : 0 ≤ a ∧ a ≤ ξ) (hb : 0 ≤ b ∧ b ≤ ξ)
    (hc : 0 ≤ c ∧ c ≤ ξ) (hξ : ξ ≤ 1) : (1 - ξ) ^ 3 ≤ (1 - a) * (1 - b) * (1 - c) := by
  have h1 : 0 ≤ 1 - ξ := by linarith
  have h2 : 1 - ξ ≤ 1 - a := by linarith
  have h3 : 1 - ξ ≤ 1 - b := by linarith
  have h4 : 1 - ξ ≤ 1 - c := by linarith
  have hab : (1 - ξ) * (1 - ξ) ≤ (1 - a) * (1 - b) := mul_le_mul h2 h3 h1 (by linarith)
  have hab0 : 0 ≤ (1 - a) * (1 - b) := mul_nonneg (by linarith) (by linarith)
  calc (1 - ξ) ^ 3 = (1 - ξ) * (1 - ξ) * (1 - ξ) := by ring
    _ ≤ (1 - a) * (1 - b) * (1 - c) := mul_le_mul hab h4 h1 hab0

theorem piF_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : (1 - ξ) ^ 3 ≤ piF x μ := by
  fin_cases μ
  · exact prod3_lower (hx 1) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 2) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 3) hξ
  · exact prod3_lower (hx 0) (hx 1) (hx 2) hξ

theorem dco_lower {x : Fin 4 → ℝ} {ξ : ℝ} (hx : ∀ ν, 0 ≤ x ν ∧ x ν ≤ ξ) (hξ : ξ ≤ 1)
    (μ : Fin 4) : nlow ξ + ξ ^ 3 ≤ dco x μ := by
  have hp := piF_lower hx hξ μ
  have hX : x μ ≤ x 0 + x 1 + x 2 + x 3 := by
    have h0 := hx 0; have h1 := hx 1; have h2 := hx 2; have h3 := hx 3
    fin_cases μ <;> simp <;> linarith
  have hm := hx μ
  have hprod : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ ξ + ξ ^ 2 / 2 := by
    have e1 : x μ * (1 + x μ - (x 0 + x 1 + x 2 + x 3) / 2) ≤ x μ * (1 + x μ / 2) :=
      mul_le_mul_of_nonneg_left (by linarith) hm.1
    have e2 : x μ * (1 + x μ / 2) ≤ ξ * (1 + ξ / 2) := by nlinarith
    nlinarith
  unfold dco nlow
  nlinarith

/-- One pair of the remainder: `0 ≤ ξ³(a² + b²) + p · s_a s_b a b` for `0 ≤ p ≤ ξ²`,
`s_a², s_b² ≤ 2ξ`. -/
theorem pair_nonneg {a b sa sb p ξ : ℝ} (hp0 : 0 ≤ p) (hp : p ≤ ξ ^ 2) (hξ : 0 ≤ ξ)
    (ha : sa ^ 2 ≤ 2 * ξ) (hb : sb ^ 2 ≤ 2 * ξ) :
    0 ≤ ξ ^ 3 * (a ^ 2 + b ^ 2) + p * (sa * sb * a * b) := by
  have h1 : 0 ≤ (sa * b + sb * a) ^ 2 := sq_nonneg _
  have h2 : sa ^ 2 * b ^ 2 ≤ 2 * ξ * b ^ 2 := mul_le_mul_of_nonneg_right ha (sq_nonneg b)
  have h3 : sb ^ 2 * a ^ 2 ≤ 2 * ξ * a ^ 2 := mul_le_mul_of_nonneg_right hb (sq_nonneg a)
  have hz : -(ξ * (a ^ 2 + b ^ 2)) ≤ sa * sb * a * b := by nlinarith
  have h4 : p * (-(ξ * (a ^ 2 + b ^ 2))) ≤ p * (sa * sb * a * b) :=
    mul_le_mul_of_nonneg_left hz hp0
  have h5 : p * (ξ * (a ^ 2 + b ^ 2)) ≤ ξ ^ 2 * (ξ * (a ^ 2 + b ^ 2)) :=
    mul_le_mul_of_nonneg_right hp (by positivity)
  nlinarith

/-- **`N ≽ n(ξ)` on `s^⊥`** when every `x_ν = s_ν²/2 ≤ ξ ≤ 1`. -/
theorem Nm_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) : nlow ξ * dot w w ≤ dot w (Nm s w) := by
  have hx' : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ ξ := fun ν => ⟨by unfold xs; positivity, hx ν⟩
  have hs : ∀ ν, s ν ^ 2 ≤ 2 * ξ := fun ν => by have := hx ν; unfold xs at this; linarith
  have hp : ∀ μ ν, 0 ≤ xs s μ * xs s ν ∧ xs s μ * xs s ν ≤ ξ ^ 2 := fun μ ν =>
    ⟨mul_nonneg (hx' μ).1 (hx' ν).1, by
      have := hx' μ; have := hx' ν
      calc xs s μ * xs s ν ≤ ξ * ξ := mul_le_mul (hx' μ).2 (hx' ν).2 (hx' ν).1 hξ0
        _ = ξ ^ 2 := by ring⟩
  rw [Nm_form_perp, hw, zero_mul, add_zero]
  have p01 := pair_nonneg (a := w 0) (b := w 1) (hp 2 3).1 (hp 2 3).2 hξ0 (hs 0) (hs 1)
  have p02 := pair_nonneg (a := w 0) (b := w 2) (hp 1 3).1 (hp 1 3).2 hξ0 (hs 0) (hs 2)
  have p03 := pair_nonneg (a := w 0) (b := w 3) (hp 1 2).1 (hp 1 2).2 hξ0 (hs 0) (hs 3)
  have p12 := pair_nonneg (a := w 1) (b := w 2) (hp 0 3).1 (hp 0 3).2 hξ0 (hs 1) (hs 2)
  have p13 := pair_nonneg (a := w 1) (b := w 3) (hp 0 2).1 (hp 0 2).2 hξ0 (hs 1) (hs 3)
  have p23 := pair_nonneg (a := w 2) (b := w 3) (hp 0 1).1 (hp 0 1).2 hξ0 (hs 2) (hs 3)
  have d0 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 0) (sq_nonneg (w 0))
  have d1 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 1) (sq_nonneg (w 1))
  have d2 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 2) (sq_nonneg (w 2))
  have d3 := mul_le_mul_of_nonneg_right (dco_lower hx' hξ 3) (sq_nonneg (w 3))
  unfold dot Rem
  simp only [Fin.sum_univ_four]
  linarith

theorem dot_self_nonneg (a : Fin 4 → ℝ) : 0 ≤ dot a a := by
  unfold dot; exact Finset.sum_nonneg fun i _ => mul_self_nonneg (a i)

theorem dot_cs (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa only [sq] using h

/-- `|N w|² ≥ n(ξ)² |w|²` on `s^⊥` (Cauchy–Schwarz with `Nm_lower`). -/
theorem Nm_sq_lower {s w : Fin 4 → ℝ} {ξ : ℝ} (hξ0 : 0 ≤ ξ) (hξ : ξ ≤ 1)
    (hx : ∀ ν, xs s ν ≤ ξ) (hw : dot s w = 0) (hn : 0 ≤ nlow ξ) :
    nlow ξ ^ 2 * dot w w ≤ dot (Nm s w) (Nm s w) := by
  have h1 := Nm_lower hξ0 hξ hx hw
  have hA := dot_self_nonneg w
  have hB := dot_self_nonneg (Nm s w)
  have hcs := dot_cs w (Nm s w)
  have hc0 : 0 ≤ nlow ξ * dot w w := mul_nonneg hn hA
  have hsq : (nlow ξ * dot w w) ^ 2 ≤ dot w (Nm s w) ^ 2 := pow_le_pow_left₀ hc0 h1 2
  rcases eq_or_lt_of_le hA with h0 | hpos
  · rw [← h0]; simpa using hB
  · have : dot w w * (nlow ξ ^ 2 * dot w w) ≤ dot w w * dot (Nm s w) (Nm s w) := by
      nlinarith
    exact le_of_mul_le_mul_left this hpos

/-! ## 2. The scale of the nearest alias -/

/-- `b_m = sin²(π/2^{m+1})`. -/
def bS (m : ℕ) : ℝ := Real.sin (π / 2 ^ (m + 1)) ^ 2

theorem ang_half (m : ℕ) : π / 2 ^ (m + 1 + 1) = (π / 2 ^ (m + 1)) / 2 := by
  rw [pow_succ 2 (m + 1), div_div]

theorem ang_pos (m : ℕ) : 0 < π / 2 ^ (m + 1) := by positivity

theorem ang_le (m : ℕ) : π / 2 ^ (m + 1) ≤ π / 2 := by
  have h2 : (2 : ℝ) ≤ 2 ^ (m + 1) := by
    calc (2 : ℝ) = 2 ^ 1 := by norm_num
      _ ≤ 2 ^ (m + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
  rw [div_le_div_iff₀ (by positivity) (by norm_num)]
  nlinarith [Real.pi_pos]

theorem cos_ang_nonneg (m : ℕ) : 0 ≤ Real.cos (π / 2 ^ (m + 1)) :=
  Real.cos_nonneg_of_mem_Icc ⟨by linarith [ang_pos m, Real.pi_pos], ang_le m⟩

theorem bS_eq (m : ℕ) : bS m = 1 - Real.cos (π / 2 ^ (m + 1)) ^ 2 := by
  unfold bS; rw [Real.sin_sq]

theorem bS_succ (m : ℕ) : bS (m + 1) = (1 - Real.cos (π / 2 ^ (m + 1))) / 2 := by
  unfold bS
  rw [ang_half, Real.sin_sq, Real.cos_sq (π / 2 ^ (m + 1) / 2)]
  have : 2 * (π / 2 ^ (m + 1) / 2) = π / 2 ^ (m + 1) := by ring
  rw [this]; ring

theorem bS_zero : bS 0 = 1 := by
  unfold bS; norm_num

theorem bS_le_one (m : ℕ) : bS m ≤ 1 := Real.sin_sq_le_one _

theorem bS_nonneg (m : ℕ) : 0 ≤ bS m := sq_nonneg _

/-- **The scale of the nearest alias**: if `sin²(q_ν/2) ≤ b_m` for all `ν`, then
`sin²(r_ν/2) ≤ b_{m+1}` at `r = r_{ζ*}` (no box on `q`). -/
theorem alias_scale (θ : Fin 4 → ℝ) (m : ℕ) (h : ∀ ν, sQ θ ν ^ 2 ≤ bS m) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ bS (m + 1) := by
  have hσ := sigma_mem (θ ν)
  have hx := xs_alias θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν
  unfold xs at hx
  have hq := omega_dir (θ ν)
  have hc0 := cos_ang_nonneg m
  have hb := h ν
  rw [bS_eq] at hb
  rw [bS_succ]
  unfold sQ at hb
  set c := Real.cos (π / 2 ^ (m + 1))
  set σ := Real.sin (θ ν) ^ 2
  set t := sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2
  by_cases hs : 1 / 2 < σ
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = true := by
      simp only [zstar, decide_eq_true_eq]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = 1 - σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 2 * σ - 1)]
  · have hz : zstar (fun ν => Real.sin (θ ν) ^ 2) ν = false := by
      simp only [zstar, decide_eq_false_iff_not]; exact hs
    rw [hz] at hx; simp only [xa] at hx
    have ht : t = σ := by linarith
    have hS : Real.sin (2 * θ ν) ^ 2 = 4 * σ * (1 - σ) := by linarith
    rw [hS] at hb
    rw [ht]
    have hs' : σ ≤ 1 / 2 := le_of_not_gt hs
    nlinarith [mul_nonneg hc0 (by linarith : (0 : ℝ) ≤ 1 - 2 * σ)]

/-! ## 3. The potentials -/

/-- `Γ_m = 2^m sin(π/2^{m+1})` (`Γ_0 = 1`, increasing to `π/2`). -/
def Gam (m : ℕ) : ℝ := 2 ^ m * Real.sin (π / 2 ^ (m + 1))

/-- `κ_{m+1} = cos(π/2^{m+2})`. -/
def kap (m : ℕ) : ℝ := Real.cos (π / 2 ^ (m + 1 + 1))

theorem Gam_rec (m : ℕ) : Gam (m + 1) * kap m = Gam m := by
  unfold Gam kap
  have h := Real.sin_two_mul (π / 2 ^ (m + 1 + 1))
  have e : 2 * (π / 2 ^ (m + 1 + 1)) = π / 2 ^ (m + 1) := by rw [ang_half]; ring
  rw [e] at h
  rw [h, pow_succ]
  ring

theorem one_sub_bS (m : ℕ) : 1 - bS (m + 1) = kap m ^ 2 := by
  unfold bS kap
  have := Real.sin_sq_add_cos_sq (π / 2 ^ (m + 1 + 1))
  linarith

theorem Gam_nonneg (m : ℕ) : 0 ≤ Gam m := by
  unfold Gam
  apply mul_nonneg (by positivity)
  apply Real.sin_nonneg_of_nonneg_of_le_pi (ang_pos m).le
  linarith [ang_le m, Real.pi_pos]

theorem Gam_le (m : ℕ) : Gam m ≤ π / 2 := by
  unfold Gam
  have h := Real.sin_le (ang_pos m).le
  calc 2 ^ m * Real.sin (π / 2 ^ (m + 1)) ≤ 2 ^ m * (π / 2 ^ (m + 1)) :=
        mul_le_mul_of_nonneg_left h (by positivity)
    _ = π / 2 := by rw [pow_succ]; field_simp

theorem Gam_zero : Gam 0 = 1 := by
  unfold Gam; norm_num

/-- `ξ_2 = 3.1416²/128 ≥ sin²(π/8)/2`. -/
def xi2 : ℝ := (3927 / 1250) ^ 2 / 128

/-- The bound `ξ` for `x = sin²(r/2)/2` at the scale `m + 1`. -/
def xiB : ℕ → ℝ
  | 0 => 1 / 4
  | 1 => xi2
  | m + 2 => (π / 2 ^ (m + 4)) ^ 2 / 2

/-- The `N`-part of the potential. -/
def nuT : ℕ → ℝ
  | 0 => nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160))
  | 1 => nlow xi2 ^ 2 * (1 - 33 / 160)
  | m + 2 => 1 - 33 / 10 / (2 ^ (m + 2)) ^ 2

/-- The potential `τ_m = (2Γ_m/π)⁴ ν_m`. -/
def tau (m : ℕ) : ℝ := (2 * Gam m / π) ^ 4 * nuT m

theorem nlow_ge {ξ : ℝ} (_h0 : 0 ≤ ξ) (h1 : ξ ≤ 1) : 1 - 4 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg (sq_nonneg ξ) (by linarith : (0 : ℝ) ≤ 5 / 2 - 2 * ξ)]

theorem sin_sq_le_sq {y : ℝ} (h0 : 0 ≤ y) (h1 : y ≤ π) : Real.sin y ^ 2 ≤ y ^ 2 :=
  pow_le_pow_left₀ (Real.sin_nonneg_of_nonneg_of_le_pi h0 h1) (Real.sin_le h0) 2

theorem bS_half_le (m : ℕ) : bS (m + 1) / 2 ≤ xiB m := by
  match m with
  | 0 =>
    show Real.sin (π / 2 ^ (0 + 1 + 1)) ^ 2 / 2 ≤ 1 / 4
    have e : π / 2 ^ (0 + 1 + 1) = π / 4 := by norm_num
    rw [e, Real.sin_pi_div_four, div_pow, Real.sq_sqrt (by norm_num)]
    norm_num
  | 1 =>
    show Real.sin (π / 2 ^ (1 + 1 + 1)) ^ 2 / 2 ≤ xi2
    have e : π / 2 ^ (1 + 1 + 1) = π / 8 := by norm_num
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 8) (by linarith [Real.pi_pos])
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have : (π / 8) ^ 2 ≤ (3927 / 1250 / 8) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (by norm_num at hp ⊢; linarith) 2
    unfold xi2
    nlinarith
  | k + 2 =>
    show Real.sin (π / 2 ^ (k + 2 + 1 + 1)) ^ 2 / 2 ≤ (π / 2 ^ (k + 4)) ^ 2 / 2
    have e : k + 2 + 1 + 1 = k + 4 := by omega
    rw [e]
    have h := sin_sq_le_sq (by positivity : 0 ≤ π / 2 ^ (k + 4))
      (by
        have : (1 : ℝ) ≤ 2 ^ (k + 4) := one_le_pow₀ (by norm_num)
        rw [div_le_iff₀ (by positivity)]
        nlinarith [Real.pi_pos])
    linarith

theorem xiB_nonneg (m : ℕ) : 0 ≤ xiB m := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 => simp only [xiB]; positivity

theorem xiB_le (m : ℕ) : xiB m ≤ 1 / 4 := by
  match m with
  | 0 => norm_num [xiB]
  | 1 => norm_num [xiB, xi2]
  | k + 2 =>
    simp only [xiB]
    have hp := Real.pi_lt_d4
    have hp0 := Real.pi_pos
    have h16 : (16 : ℝ) ≤ 2 ^ (k + 4) := by
      calc (16 : ℝ) = 2 ^ 4 := by norm_num
        _ ≤ 2 ^ (k + 4) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h1 : π / 2 ^ (k + 4) ≤ 1 / 4 := by
      rw [div_le_iff₀ (by positivity)]; nlinarith
    have h2 : 0 ≤ π / 2 ^ (k + 4) := by positivity
    nlinarith

theorem nlow_xiB_nonneg (m : ℕ) : 0 ≤ nlow (xiB m) := by
  have := nlow_ge (xiB_nonneg m) (by linarith [xiB_le m])
  linarith [xiB_le m]

theorem nuT_step (m : ℕ) : nuT m ≤ nuT (m + 1) * nlow (xiB m) ^ 2 := by
  match m with
  | 0 => show nuT 0 ≤ nuT 1 * nlow (1 / 4) ^ 2; simp only [nuT]; nlinarith
  | 1 =>
    show nuT 1 ≤ nuT 2 * nlow xi2 ^ 2
    simp only [nuT]
    norm_num
    linarith
  | k + 2 =>
    show 1 - 33 / 10 / (2 ^ (k + 2)) ^ 2 ≤
      (1 - 33 / 10 / (2 ^ (k + 3)) ^ 2) * nlow ((π / 2 ^ (k + 4)) ^ 2 / 2) ^ 2
    set p : ℝ := 2 ^ (k + 2) with hp_def
    have hp4 : (4 : ℝ) ≤ p := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have e3 : (2 : ℝ) ^ (k + 3) = 2 * p := by rw [hp_def, pow_succ]; ring
    have e4 : (2 : ℝ) ^ (k + 4) = 4 * p := by
      rw [hp_def, show k + 4 = k + 2 + 2 by omega, pow_add]; ring
    rw [e3, e4]
    have hπ := Real.pi_lt_d4
    have hπ0 := Real.pi_pos
    have hπ2 : π ^ 2 < 9.87 := by nlinarith
    set e : ℝ := 1 / p ^ 2 with he_def
    have hp0 : 0 < p := by linarith
    have he0 : 0 < e := by positivity
    have he1 : e ≤ 1 / 16 := by
      rw [he_def, div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith
    have hξ : (π / (4 * p)) ^ 2 / 2 = π ^ 2 * e / 32 := by
      rw [he_def]; field_simp; ring
    rw [hξ]
    have hξ0 : 0 ≤ π ^ 2 * e / 32 := by positivity
    have hξ1 : π ^ 2 * e / 32 ≤ 1 := by nlinarith
    have hn := nlow_ge hξ0 hξ1
    have hn0 : 0 ≤ 1 - 4 * (π ^ 2 * e / 32) := by nlinarith
    have hn2 : (1 - 4 * (π ^ 2 * e / 32)) ^ 2 ≤ nlow (π ^ 2 * e / 32) ^ 2 :=
      pow_le_pow_left₀ hn0 hn 2
    have l1 : 33 / 10 / p ^ 2 = 33 / 10 * e := by rw [he_def]; ring
    have l2 : 33 / 10 / (2 * p) ^ 2 = 33 / 10 * e / 4 := by rw [he_def]; field_simp; ring
    rw [l1, l2]
    have hA : 0 ≤ 1 - 33 / 10 * e / 4 := by nlinarith
    have hstep : 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
      have h1 : 1 - 2 * (4 * (π ^ 2 * e / 32)) ≤ (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := by
        nlinarith [sq_nonneg (4 * (π ^ 2 * e / 32))]
      have h2 := mul_le_mul_of_nonneg_left h1 hA
      have h3 : π ^ 2 * e < 9.87 * e := mul_lt_mul_of_pos_right hπ2 he0
      have h4 : 0 ≤ e * e * π ^ 2 := mul_nonneg (mul_nonneg he0.le he0.le) (sq_nonneg π)
      nlinarith
    calc 1 - 33 / 10 * e ≤ (1 - 33 / 10 * e / 4) * (1 - 4 * (π ^ 2 * e / 32)) ^ 2 := hstep
      _ ≤ (1 - 33 / 10 * e / 4) * nlow (π ^ 2 * e / 32) ^ 2 :=
        mul_le_mul_of_nonneg_left hn2 hA

theorem nuT_bounds (m : ℕ) : 0 ≤ nuT m ∧ nuT m ≤ 1 := by
  match m with
  | 0 => simp only [nuT]; norm_num [nlow, xi2]
  | 1 => simp only [nuT]; norm_num [nlow, xi2]
  | k + 2 =>
    simp only [nuT]
    have h4 : (4 : ℝ) ≤ 2 ^ (k + 2) := by
      calc (4 : ℝ) = 2 ^ 2 := by norm_num
        _ ≤ 2 ^ (k + 2) := pow_le_pow_right₀ (by norm_num) (by omega)
    have h16 : (16 : ℝ) ≤ (2 ^ (k + 2)) ^ 2 := by nlinarith
    have h0 : 0 ≤ 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 := by positivity
    have h1 : 33 / 10 / ((2 : ℝ) ^ (k + 2)) ^ 2 ≤ 1 := by
      rw [div_le_one (by positivity)]; linarith
    constructor <;> linarith

theorem pref_bounds (m : ℕ) : 0 ≤ (2 * Gam m / π) ^ 4 ∧ (2 * Gam m / π) ^ 4 ≤ 1 := by
  have h0 : 0 ≤ 2 * Gam m / π := div_nonneg (by linarith [Gam_nonneg m]) Real.pi_pos.le
  have h1 : 2 * Gam m / π ≤ 1 := by
    rw [div_le_one Real.pi_pos]; linarith [Gam_le m]
  exact ⟨by positivity, pow_le_one₀ h0 h1⟩

theorem tau_nonneg (m : ℕ) : 0 ≤ tau m :=
  mul_nonneg (pref_bounds m).1 (nuT_bounds m).1

theorem tau_le_one (m : ℕ) : tau m ≤ 1 := by
  unfold tau
  have := pref_bounds m
  have := nuT_bounds m
  nlinarith

/-- **One stage of the potentials**: `τ_m ≤ τ_{m+1} n(ξ_{m+1})² (1 − b_{m+1})²`. -/
theorem tau_step (m : ℕ) :
    tau m ≤ tau (m + 1) * nlow (xiB m) ^ 2 * (1 - bS (m + 1)) ^ 2 := by
  unfold tau
  rw [one_sub_bS, ← Gam_rec m]
  have hs := nuT_step m
  have h0 : 0 ≤ (2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4 := by positivity
  calc (2 * (Gam (m + 1) * kap m) / π) ^ 4 * nuT m
      = ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * nuT m := by ring
    _ ≤ ((2 * Gam (m + 1) / π) ^ 4 * kap m ^ 4) * (nuT (m + 1) * nlow (xiB m) ^ 2) :=
      mul_le_mul_of_nonneg_left hs h0
    _ = (2 * Gam (m + 1) / π) ^ 4 * nuT (m + 1) * nlow (xiB m) ^ 2 * (kap m ^ 2) ^ 2 := by ring

/-- `a = (4/π²)·0.04452² ≤ τ_0 = (2/π)⁴ ν_0`. -/
theorem a_le_tau : 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 ≤ tau 0 := by
  unfold tau
  rw [Gam_zero]
  have hν : nuT 0 = nlow (1 / 4) ^ 2 * (nlow xi2 ^ 2 * (1 - 33 / 160)) := rfl
  have hν' : (0.0049 : ℝ) ≤ nuT 0 := by rw [hν]; norm_num [nlow, xi2]
  have hπ := Real.pi_lt_d4
  have hπ0 := Real.pi_pos
  have hπ2 : π ^ 2 < 9.87 := by nlinarith
  have hp : 0 < π ^ 2 := by positivity
  have e : (2 * 1 / π) ^ 4 = 16 / (π ^ 2) ^ 2 := by field_simp; ring
  rw [e]
  rw [show 16 / (π ^ 2) ^ 2 * nuT 0 = (16 * nuT 0 / π ^ 2) / π ^ 2 by field_simp]
  rw [show 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 = (4 * 0.04452 ^ 2) / π ^ 2 by ring]
  apply div_le_div_of_nonneg_right _ hp.le
  rw [le_div_iff₀ hp]
  nlinarith

/-! ## 4. One alias from below and the ratio of `ω` -/

theorem cR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    cR θ ζ ν ^ 2 = 1 - sR θ ζ ν ^ 2 := by
  unfold cR sR; rw [Real.cos_sq']

theorem sg_sq (ζ : Fin 4 → Bool) (ν : Fin 4) : sg ζ ν ^ 2 = 1 := by
  unfold sg; split_ifs <;> norm_num

theorem sQ_sq_alias (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sQ θ ν ^ 2 = 4 * sR θ ζ ν ^ 2 * cR θ ζ ν ^ 2 := by
  unfold sQ sR cR phi
  cases ζ ν
  · simp only [Bool.false_eq_true, if_false, add_zero, Real.sin_two_mul]; ring
  · simp only [if_true, Real.sin_add_pi_div_two, Real.cos_add_pi_div_two, Real.sin_two_mul]; ring

/-- **One alias from below**: `4 n(ξ)² (1 − b) |P(q)x|² ≤ ⟨A_ζᵀx, P(r_ζ) A_ζᵀx⟩`
when `sin²(r_ν/2) ≤ b` for all `ν` and `b/2 ≤ ξ ≤ 1`, `n(ξ) ≥ 0`. -/
theorem one_alias_lower (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) {b ξ : ℝ}
    (hsR : ∀ ν, sR θ ζ ν ^ 2 ≤ b) (hξ : b / 2 ≤ ξ) (hξ1 : ξ ≤ 1) (hn : 0 ≤ nlow ξ) :
    4 * nlow ξ ^ 2 * (1 - b) * dot (proj (sQ θ) x) (proj (sQ θ) x) ≤
      dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) := by
  rw [alias_term_eq]
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb0 : 0 ≤ b := le_trans (sq_nonneg _) (hsR 0)
  have hξ0 : 0 ≤ ξ := by linarith
  have hx : ∀ ν, xs (sR θ ζ) ν ≤ ξ := fun ν => by unfold xs; linarith [hsR ν]
  have hN := Nm_sq_lower hξ0 hξ1 hx hw hn
  have hww : (1 - b) * dot u u ≤ dot w w := by
    unfold dot
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun ν _ => ?_
    have e : w ν * w ν = cR θ ζ ν ^ 2 * (u ν * u ν) := by
      rw [hw_def]
      have := sg_sq ζ ν
      calc cR θ ζ ν * sg ζ ν * u ν * (cR θ ζ ν * sg ζ ν * u ν)
          = cR θ ζ ν ^ 2 * sg ζ ν ^ 2 * (u ν * u ν) := by ring
        _ = _ := by rw [this, mul_one]
    rw [e, cR_sq]
    exact mul_le_mul_of_nonneg_right (by linarith [hsR ν]) (mul_self_nonneg _)
  have hn2 : 0 ≤ nlow ξ ^ 2 := sq_nonneg _
  calc 4 * nlow ξ ^ 2 * (1 - b) * dot u u = 4 * (nlow ξ ^ 2 * ((1 - b) * dot u u)) := by ring
    _ ≤ 4 * (nlow ξ ^ 2 * dot w w) := by gcongr
    _ ≤ 4 * dot (Nm (sR θ ζ) w) (Nm (sR θ ζ) w) := by gcongr

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **The ratio of `ω`**: `4(1 − b) ω(r_ζ) ≤ ω(q)` when `sin²(r_ν/2) ≤ b`. -/
theorem omega_ratio (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    {b : ℝ} (hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ b) :
    4 * (1 - b) * omF th (rq q ζ) ≤ omF th q := by
  unfold omF
  rw [hrq, sQ_thR, Finset.mul_sum]
  refine Finset.sum_le_sum fun ν _ => ?_
  rw [sQ_sq_alias (th q) ζ ν, cR_sq]
  have h := hsR ν
  have h0 := sq_nonneg (sR (th q) ζ ν)
  nlinarith

theorem inner_P (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) := by
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, dot_proj_self]

theorem inner_P_nonneg (q : Q) (x : V) : 0 ≤ ⟪x, Pfam th q x⟫ := by
  rw [inner_P]; exact dot_self_nonneg _

theorem alias_inner (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (q : Q) (ζ : Fin 4 → Bool)
    (x : V) :
    ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        Pfam th (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ =
      dot (Atr (th q) ζ (WithLp.ofLp x)) (proj (sR (th q) ζ) (Atr (th q) ζ (WithLp.ofLp x))) := by
  rw [inner_coord]
  unfold Pfam
  rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
    projM_mulVec]

theorem scale_zero (q : Q) (ν : Fin 4) : sQ (th q) ν ^ 2 ≤ bS 0 := by
  rw [bS_zero]; exact Real.sin_sq_le_one _

/-! ## 5. The induction over the stages -/

/-- **The lower side at every scale**: for every stage `k`, scale `m` and momentum `q` with
`sin²(q_ν/2) ≤ b_m`, `τ_m P(q)/ω(q) ≼ G_k(q)`. -/
theorem lower_inv (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) : ∀ (m : ℕ) (q : Q), (∀ ν, sQ (th q) ν ^ 2 ≤ bS m) → ∀ x : V,
      tau m * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ := by
  induction k with
  | zero =>
    intro m q _ x
    simp only [Function.iterate_zero, id_eq, LinearMap.smul_apply, real_inner_smul_right]
    have h1 := tau_le_one m
    have h0 := inner_P_nonneg th q x
    have hw := (inv_pos.mpr (hω q)).le
    have : 0 ≤ (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := mul_nonneg hw h0
    nlinarith
  | succ k ih =>
    intro m q hq x
    rw [Function.iterate_succ_apply', Mfam_inner]
    set G := (⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q) with hG
    set ζs := zstar fun ν => Real.sin (th q ν) ^ 2 with hζs
    set y := Matrix.toEuclideanLin (AtM (th q) ζs) x with hy
    have hnn : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
      intro ζ
      refine le_trans ?_ (ih 0 (rq q ζ) (scale_zero th (rq q ζ)) _)
      exact mul_nonneg (mul_nonneg (tau_nonneg 0) (inv_pos.mpr (hω _)).le)
        (inner_P_nonneg th _ _)
    have hsingle : ⟪y, G (rq q ζs) y⟫ ≤ ∑ ζ : Fin 4 → Bool,
        ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ :=
      Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
          G (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hnn ζ)
        (Finset.mem_univ ζs)
    have hscale : ∀ ν, sR (th q) ζs ν ^ 2 ≤ bS (m + 1) := alias_scale (th q) m hq
    have hq' : ∀ ν, sQ (th (rq q ζs)) ν ^ 2 ≤ bS (m + 1) := by
      rw [hrq, sQ_thR]; exact hscale
    have hIH := ih (m + 1) (rq q ζs) hq' y
    rw [hy, alias_inner th rq hrq q ζs x] at hIH
    rw [← hy] at hIH
    have hA := one_alias_lower (th q) (WithLp.ofLp x) ζs hscale (bS_half_le m)
      (by linarith [xiB_le m]) (nlow_xiB_nonneg m)
    have hωr := omega_ratio th rq hrq q ζs hscale
    have hτ := tau_step m
    rw [← inner_P th q x] at hA
    -- abbreviations
    set b := bS (m + 1)
    set n2 := nlow (xiB m) ^ 2
    set U := ⟪x, Pfam th q x⟫
    set Y := dot (Atr (th q) ζs (WithLp.ofLp x))
      (proj (sR (th q) ζs) (Atr (th q) ζs (WithLp.ofLp x)))
    set wq := (omF th q)⁻¹
    set wr := (omF th (rq q ζs))⁻¹
    have hU : 0 ≤ U := inner_P_nonneg th q x
    have hb1 : 0 ≤ 1 - b := by linarith [bS_le_one (m + 1)]
    have hτ' : 0 ≤ tau (m + 1) := tau_nonneg _
    have hn2 : 0 ≤ n2 := sq_nonneg _
    have hwq : 0 ≤ wq := (inv_pos.mpr (hω q)).le
    have hwr : 0 ≤ wr := (inv_pos.mpr (hω _)).le
    have e1 : omF th q * wq = 1 := mul_inv_cancel₀ (hω q).ne'
    have e2 : omF th (rq q ζs) * wr = 1 := mul_inv_cancel₀ (hω _).ne'
    have key : 4 * (1 - b) * wq ≤ wr := by
      calc 4 * (1 - b) * wq = 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) := by
            rw [show 4 * (1 - b) * omF th (rq q ζs) * (wq * wr) =
              4 * (1 - b) * wq * (omF th (rq q ζs) * wr) by ring, e2, mul_one]
        _ ≤ omF th q * (wq * wr) := mul_le_mul_of_nonneg_right hωr (mul_nonneg hwq hwr)
        _ = wr := by rw [← mul_assoc, e1, one_mul]
    have hc : 0 ≤ tau (m + 1) * n2 * (1 - b) := mul_nonneg (mul_nonneg hτ' hn2) hb1
    calc tau m * wq * U ≤ (tau (m + 1) * n2 * (1 - b) ^ 2) * wq * U :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hτ hwq) hU
      _ = (tau (m + 1) * n2 * (1 - b)) * ((1 - b) * wq) * U := by ring
      _ ≤ (tau (m + 1) * n2 * (1 - b)) * (wr / 4) * U := by
          apply mul_le_mul_of_nonneg_right _ hU
          apply mul_le_mul_of_nonneg_left _ hc
          linarith
      _ = (1 / 16) * (tau (m + 1) * wr * (4 * n2 * (1 - b) * U)) := by ring
      _ ≤ (1 / 16) * (tau (m + 1) * wr * Y) := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact mul_le_mul_of_nonneg_left hA (mul_nonneg hτ' hwr)
      _ ≤ (1 / 16) * ⟪y, G (rq q ζs) y⟫ := by
          apply mul_le_mul_of_nonneg_left _ (by norm_num)
          exact hIH
      _ ≤ _ := mul_le_mul_of_nonneg_left hsingle (by norm_num)

/-- **`hlow` without the box**: `(4/π²)·0.04452² · P/ω ≼ 𝓜^k(P/ω)` for every stage `k`. -/
theorem lower_side (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (k : ℕ) :
    UniformBracket.Lw ((4 / π ^ 2 * (0.04452 : ℝ) ^ 2) • fun q => (omF th q)⁻¹ • Pfam th q)
      ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) := by
  intro q x
  have h := lower_inv th rq hrq hω k 0 q (scale_zero th q) x
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  have ha := a_le_tau
  have hP := inner_P_nonneg th q x
  have hw := (inv_pos.mpr (hω q)).le
  calc 4 / π ^ 2 * (0.04452 : ℝ) ^ 2 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫)
      ≤ tau 0 * ((omF th q)⁻¹ * ⟪x, Pfam th q x⟫) :=
        mul_le_mul_of_nonneg_right ha (mul_nonneg hw hP)
    _ = tau 0 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
    _ ≤ _ := h

/-! ## 6. Theorem 1 on `Qpos` without hypotheses -/

/-- **Theorem 1 (the uniform bracket of the stage actions) on every momentum with `ω > 0`**:
the inverses `H_k` of `G_k = 𝓜^k(P/ω)` on `ran P` exist and
`(ω/745) P ≼ ¼ H_k ≼ 312 ω P` for every stage `k`, with no remaining hypothesis. -/
theorem bracket_Qpos_free :
    ∃ H : ℕ → Qpos → V →ₗ[ℝ] V,
      (∀ k q x, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) q (H k q x) =
          Pfam Subtype.val q x) ∧
      (∀ k q x, Pfam Subtype.val q (H k q x) = H k q x) ∧
      ∀ k q x, omF Subtype.val q / 745 * ⟪x, Pfam Subtype.val q x⟫ ≤
          ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ∧
        ⟪x, ((1 / 4 : ℝ) • H k q) x⟫ ≤ 312 * omF Subtype.val q * ⟪x, Pfam Subtype.val q x⟫ :=
  bracket_Qpos_low (σ := 0.04452) (a := 4 / π ^ 2 * (0.04452 : ℝ) ^ 2) le_rfl rfl
    (lower_side Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2))

end OneStepLower

end

-- ===== new part : CouplingLimit.part.lean =====
/-!
# (R3) The coupling coefficient `b_k → b_∞` from Theorem 1 

`b_k := Ξ(G_k)` with `G_k = 𝓜^k(P/ω)` (the physical stage covariance, `LatticeRec.rec_iterate`)
and `Ξ` Lipschitz relative to `P` on a set containing every `G_k`:
`−cP ≼ A − B ≼ cP  ⟹  |Ξ A − Ξ B| ≤ L c`  (`RelLip`).

* `coupling_limit` (abstract): if `M` preserves the order, `M P ≼ λ P` (`0 ≤ λ < 1`) and
  `−dP ≼ M G₀ − G₀ ≼ dP`, then `b_k = Ξ(M^k G₀)` converges to some `b_∞` with
  `|b_k − b_∞| ≤ L d λ^k/(1−λ)`, the bracket `b_∞ − Ld/(1−λ) ≤ b_k ≤ b_∞ + Ld/(1−λ)`,
  `Σ|b_k − b_∞|` summable with every partial sum `≤ L d/(1−λ)²`, hence the transient field
  `Σ_{k<n} max(−δ_k, 0) ≤ L d/(1−λ)²` of `CouplingStepsTransientE` (`δ_k = b_k − b_∞`).
* `D_lower` (the lower half of (R4)): `M(P/ω) − P/ω ≽ −2P` on `Qpos`; with `Mfam_B_le`
  (`≼ (15/8) P`) this gives `d = 2`.
* `coupling_converges`: the concrete statement for the family of Theorem 1 (`λ = 429/512`, `d = 2`).
* `quadLip`: every finite combination `Ξ(A) = Σ_i w_i ⟪v_i, A(q_i) v_i⟫` (on a finite torus,
  `(1/|Λ|) Σ_q tr(V(q) G(q))` is of this form) is `RelLip` with `L = Σ |w_i| ⟪v_i, P(q_i) v_i⟫`.
-/

noncomputable section

namespace CouplingLimit

open Finset Filter Topology UniformBracket
open scoped Real RealInnerProductSpace

section Abstract

variable {Q E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- `Ξ` is Lipschitz relative to `P` on `S` with constant `L`. -/
def RelLip (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (P : Q → E →ₗ[ℝ] E) (L : ℝ) (S : Set (Q → E →ₗ[ℝ] E)) :
    Prop :=
  ∀ A ∈ S, ∀ B ∈ S, ∀ c : ℝ, 0 ≤ c → Lw (-(c • P)) (A - B) → Lw (A - B) (c • P) →
    |Ξ A - Ξ B| ≤ L * c

theorem geom_partial_le {lam : ℝ} (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (n : ℕ) :
    ∑ k ∈ range n, lam ^ k ≤ 1 / (1 - lam) := by
  have h1 : 0 < 1 - lam := by linarith
  have e := geom_sum_mul lam n
  rw [le_div_iff₀ h1]
  have : (∑ k ∈ range n, lam ^ k) * (1 - lam) = 1 - lam ^ n := by linarith
  rw [this]
  have := pow_nonneg hlam0 n
  linarith

variable (M : (Q → E →ₗ[ℝ] E) →ₗ[ℝ] (Q → E →ₗ[ℝ] E))

/-- **The coupling coefficient converges geometrically** (abstract form). -/
theorem coupling_limit (hM : OrderPreserving M) {P G0 : Q → E →ₗ[ℝ] E} {lam d L : ℝ}
    (hlam0 : 0 ≤ lam) (hlam1 : lam < 1) (hd : 0 ≤ d) (hL : 0 ≤ L)
    (hP : Lw (M P) (lam • P)) (hlo : Lw (-(d • P)) (M G0 - G0)) (hhi : Lw (M G0 - G0) (d • P))
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (S : Set (Q → E →ₗ[ℝ] E)) (hS : ∀ k, (⇑M)^[k] G0 ∈ S)
    (hΞ : RelLip Ξ P L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d * lam ^ k / (1 - lam)) ∧
      (∀ k, binf - L * d / (1 - lam) ≤ Ξ ((⇑M)^[k] G0) ∧
        Ξ ((⇑M)^[k] G0) ≤ binf + L * d / (1 - lam)) ∧
      Summable (fun k => |Ξ ((⇑M)^[k] G0) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑M)^[k] G0) - binf| ≤ L * d / (1 - lam) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 ≤ L * d / (1 - lam) ^ 2) := by
  set b : ℕ → ℝ := fun k => Ξ ((⇑M)^[k] G0) with hb
  have h1 : 0 < 1 - lam := by linarith
  -- one step
  have hstep : ∀ k, dist (b k) (b (k + 1)) ≤ (L * d) * lam ^ k := by
    intro k
    obtain ⟨lo, hi⟩ := iterate_two_sided M hM hlam0 hd hP hlo hhi k
    have e : (⇑M)^[k] (M G0 - G0) = (⇑M)^[k + 1] G0 - (⇑M)^[k] G0 := by
      rw [iter_sub, Function.iterate_succ_apply]
    rw [e] at lo hi
    have hc : 0 ≤ d * lam ^ k := mul_nonneg hd (pow_nonneg hlam0 k)
    have := hΞ _ (hS (k + 1)) _ (hS k) _ hc lo hi
    rw [Real.dist_eq, abs_sub_comm]
    calc |b (k + 1) - b k| ≤ L * (d * lam ^ k) := this
      _ = L * d * lam ^ k := by ring
  have hcs : CauchySeq b := cauchySeq_of_le_geometric lam (L * d) hlam1 hstep
  obtain ⟨binf, hlim⟩ := cauchySeq_tendsto_of_complete hcs
  have hdist : ∀ k, |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := by
    intro k
    have := dist_le_of_le_geometric_of_tendsto lam (L * d) hlam1 hstep hlim k
    rwa [Real.dist_eq] at this
  have hLd : 0 ≤ L * d := mul_nonneg hL hd
  have hbr : ∀ k, |b k - binf| ≤ L * d / (1 - lam) := by
    intro k
    refine (hdist k).trans ?_
    rw [div_le_div_iff_of_pos_right h1]
    calc L * d * lam ^ k ≤ L * d * 1 := mul_le_mul_of_nonneg_left (pow_le_one₀ hlam0 hlam1.le) hLd
      _ = L * d := by ring
  have hsum : Summable (fun k => |b k - binf|) := by
    refine Summable.of_nonneg_of_le (fun k => abs_nonneg _) hdist ?_
    have := (summable_geometric_of_lt_one hlam0 hlam1).mul_left (L * d / (1 - lam))
    refine this.congr fun k => ?_
    ring
  have hpart : ∀ n, ∑ k ∈ range n, |b k - binf| ≤ L * d / (1 - lam) ^ 2 := by
    intro n
    calc ∑ k ∈ range n, |b k - binf| ≤ ∑ k ∈ range n, L * d / (1 - lam) * lam ^ k :=
          Finset.sum_le_sum fun k _ => by
            have := hdist k
            calc |b k - binf| ≤ L * d * lam ^ k / (1 - lam) := this
              _ = L * d / (1 - lam) * lam ^ k := by ring
      _ = L * d / (1 - lam) * ∑ k ∈ range n, lam ^ k := by rw [Finset.mul_sum]
      _ ≤ L * d / (1 - lam) * (1 / (1 - lam)) :=
          mul_le_mul_of_nonneg_left (geom_partial_le hlam0 hlam1 n) (div_nonneg hLd h1.le)
      _ = L * d / (1 - lam) ^ 2 := by field_simp
  refine ⟨binf, hlim, hdist, fun k => ?_, hsum, hpart, fun n => ?_⟩
  · have := abs_le.mp (hbr k)
    constructor <;> linarith [this.1, this.2]
  · refine le_trans (Finset.sum_le_sum fun k _ => ?_) (hpart n)
    exact max_le (neg_le_abs _) (abs_nonneg _)

/-- A finite combination of quadratic-form evaluations is Lipschitz relative to `P` on all
families, with `L = Σ_i |w_i| ⟪v_i, P(q_i) v_i⟫`. -/
theorem quadLip {ι : Type*} (s : Finset ι) (w : ι → ℝ) (qs : ι → Q) (vs : ι → E)
    (P : Q → E →ₗ[ℝ] E) :
    RelLip (fun A => ∑ i ∈ s, w i * ⟪vs i, A (qs i) (vs i)⟫) P
      (∑ i ∈ s, |w i| * ⟪vs i, P (qs i) (vs i)⟫) Set.univ := by
  intro A _ B _ c hc lo hi
  rw [← Finset.sum_sub_distrib, Finset.sum_mul]
  refine (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun i _ => ?_)
  have l := lo (qs i) (vs i)
  have h := hi (qs i) (vs i)
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.neg_apply,
    LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply, inner_neg_right,
    real_inner_smul_right] at l h
  rw [← mul_sub, abs_mul]
  have hab : |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫| ≤ c * ⟪vs i, P (qs i) (vs i)⟫ :=
    abs_le.mpr ⟨by linarith, by linarith⟩
  calc |w i| * |⟪vs i, A (qs i) (vs i)⟫ - ⟪vs i, B (qs i) (vs i)⟫|
      ≤ |w i| * (c * ⟪vs i, P (qs i) (vs i)⟫) := mul_le_mul_of_nonneg_left hab (abs_nonneg _)
    _ = |w i| * ⟪vs i, P (qs i) (vs i)⟫ * c := by ring


/-- **With the sharp form (OS↑) the transient vanishes**: if `M G₀ ≼ G₀` and `Ξ` is monotone for
the Loewner order, then `b_k` decreases to its limit, so `δ_k = b_k − b_∞ ≥ 0` and every term
`max(−δ_k, 0)` of the transient field is `0` (`D₀ = 0`). -/
theorem transient_zero (hM : OrderPreserving M) {G0 : Q → E →ₗ[ℝ] E} (h1 : Lw (M G0) G0)
    (Ξ : (Q → E →ₗ[ℝ] E) → ℝ) (hmono : ∀ A B, Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑M)^[k] G0)) atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑M)^[k] G0) ∧ max (-(Ξ ((⇑M)^[k] G0) - binf)) 0 = 0 := by
  have hanti : Antitone fun k => Ξ ((⇑M)^[k] G0) :=
    antitone_nat_of_succ_le fun n => hmono _ _ (iterate_antitone M hM h1 n)
  have hle : binf ≤ Ξ ((⇑M)^[k] G0) := hanti.le_of_tendsto hlim k
  exact ⟨hle, max_eq_right (by linarith)⟩

end Abstract

/-! ## The family of Theorem 1: `d = 2` -/

section Concrete

open OneStepHrep OneStepBridge OneStepET OneStepFinal OneStepLower

/-- The alias nearest to the origin is at most half as far: `sin²(r*/2) ≤ ½ sin²(q/2)`. -/
theorem sR_zstar_le (θ : Fin 4 → ℝ) (ν : Fin 4) :
    sR θ (zstar fun ν => Real.sin (θ ν) ^ 2) ν ^ 2 ≤ sQ θ ν ^ 2 / 2 := by
  have hs := Real.sin_sq_add_cos_sq (θ ν)
  have hQ : sQ θ ν ^ 2 = 4 * Real.sin (θ ν) ^ 2 * Real.cos (θ ν) ^ 2 := by
    unfold sQ; rw [Real.sin_two_mul]; ring
  rw [hQ]
  unfold sR phi zstar
  by_cases h : 1 / 2 < Real.sin (θ ν) ^ 2
  · simp only [h, decide_true, if_true, Real.sin_add_pi_div_two]
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]
  · simp only [h, decide_false, Bool.false_eq_true, if_false, add_zero]
    replace h := le_of_not_gt h
    nlinarith [sq_nonneg (Real.cos (θ ν)), sq_nonneg (Real.sin (θ ν))]

theorem nlow_ge {ξ : ℝ} (h0 : 0 ≤ ξ) (h1 : ξ ≤ 1 / 32) : 1 - 5 * ξ ≤ nlow ξ := by
  unfold nlow
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0]

/-- The scalar inequality behind `D_lower`: `1 − n(b/2)²(1−b)² ≤ 16 b` for `0 ≤ b ≤ 1/16`. -/
theorem deficit_le {b : ℝ} (h0 : 0 ≤ b) (h1 : b ≤ 1 / 16) :
    1 - nlow (b / 2) ^ 2 * (1 - b) ^ 2 ≤ 16 * b := by
  have hn := nlow_ge (ξ := b / 2) (by linarith) (by linarith)
  have hn0 : 0 ≤ 1 - 5 * (b / 2) := by linarith
  have hsq : (1 - 5 * (b / 2)) ^ 2 ≤ nlow (b / 2) ^ 2 := pow_le_pow_left₀ hn0 hn 2
  have hb1 : 0 ≤ (1 - b) ^ 2 := sq_nonneg _
  have : (1 - 5 * (b / 2)) ^ 2 * (1 - b) ^ 2 ≤ nlow (b / 2) ^ 2 * (1 - b) ^ 2 :=
    mul_le_mul_of_nonneg_right hsq hb1
  nlinarith [mul_nonneg h0 h0, mul_nonneg (mul_nonneg h0 h0) h0,
    mul_nonneg (mul_nonneg (mul_nonneg h0 h0) h0) h0]

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

theorem inner_P_dot (q : Q) (x : V) :
    ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x)) (proj (sQ (th q)) (WithLp.ofLp x)) :=
  inner_P th q x

/-- **(R4), lower half**: `𝓜(P/ω) − P/ω ≽ −2P`. -/
theorem D_lower (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (-((2 : ℝ) • Pfam th))
      (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  simp only [Pi.neg_apply, LinearMap.neg_apply, Pi.smul_apply, LinearMap.smul_apply,
    inner_neg_right, real_inner_smul_right, Pi.sub_apply, LinearMap.sub_apply, inner_sub_right]
  have hP := inner_P_nonneg th q x
  have hωq := hω q
  set G0 : Q → V →ₗ[ℝ] V := fun q => (omF th q)⁻¹ • Pfam th q with hG0
  -- the terms of `𝓜 G0` are nonnegative
  have hterm : ∀ ζ, 0 ≤ ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
      G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ := by
    intro ζ
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    exact mul_nonneg (inv_nonneg.mpr (hω _).le) (inner_P_nonneg th _ _)
  have hM := Mfam_inner th rq G0 q x
  have hG : ⟪x, G0 q x⟫ = (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by
    simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
  by_cases hbig : 1 / 2 ≤ omF th q
  · -- far from the origin: `𝓜 G0 ≽ 0` and `G0 ≼ 2P`
    have h0 : 0 ≤ ⟪x, Mfam th rq G0 q x⟫ := by
      rw [hM]; exact mul_nonneg (by norm_num) (Finset.sum_nonneg fun ζ _ => hterm ζ)
    have h2 : (omF th q)⁻¹ ≤ 2 := by
      rw [inv_le_comm₀ hωq (by norm_num)]; linarith
    nlinarith [mul_le_mul_of_nonneg_right h2 hP]
  · -- near the origin: keep the alias `ζ*` only
    replace hbig := lt_of_not_ge hbig
    set ζ := zstar fun ν => Real.sin (th q ν) ^ 2
    set bb := omF th q / 8 with hbb
    have hb0 : 0 ≤ bb := by rw [hbb]; linarith
    have hb1 : bb ≤ 1 / 16 := by rw [hbb]; linarith
    have hsR : ∀ ν, sR (th q) ζ ν ^ 2 ≤ bb := by
      intro ν
      refine (sR_zstar_le (th q) ν).trans ?_
      have hle : 4 * sQ (th q) ν ^ 2 ≤ omF th q := by
        unfold omF
        exact Finset.single_le_sum (f := fun ν => 4 * sQ (th q) ν ^ 2)
          (fun i _ => by positivity) (Finset.mem_univ ν)
      rw [hbb]; linarith
    have hn : 0 ≤ nlow (bb / 2) := by
      have := nlow_ge (ξ := bb / 2) (by linarith) (by linarith); linarith
    have h1 := one_alias_lower (th q) (WithLp.ofLp x) ζ hsR le_rfl (by linarith) hn
    rw [← alias_inner th rq hrq q ζ x] at h1
    have hrat := omega_ratio th rq hrq q ζ hsR
    have hωr := hω (rq q ζ)
    have hPx : ⟪x, Pfam th q x⟫ = dot (proj (sQ (th q)) (WithLp.ofLp x))
        (proj (sQ (th q)) (WithLp.ofLp x)) := inner_P th q x
    rw [← hPx] at h1
    -- one term of `𝓜 G0`
    set y := Matrix.toEuclideanLin (AtM (th q) ζ) x
    have hone : ⟪y, G0 (rq q ζ) y⟫ ≤ ⟪x, Mfam th rq G0 q x⟫ * 16 := by
      rw [hM]
      have := Finset.single_le_sum (f := fun ζ => ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        G0 (rq q ζ) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫) (fun ζ _ => hterm ζ)
        (Finset.mem_univ ζ)
      linarith
    have hyG : ⟪y, G0 (rq q ζ) y⟫ = (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
      simp only [hG0, LinearMap.smul_apply, real_inner_smul_right]
    -- `⟨y, P_r y⟩ / ω(r) ≥ 4 n² (1−b) |Px|² · 4(1−b)/ω(q)`
    have hb1' : 0 < 1 - bb := by linarith
    have hinv : 4 * (1 - bb) / omF th q ≤ (omF th (rq q ζ))⁻¹ := by
      rw [div_le_iff₀ hωq]
      calc 4 * (1 - bb) = (omF th (rq q ζ))⁻¹ * (4 * (1 - bb) * omF th (rq q ζ)) := by
            field_simp
        _ ≤ (omF th (rq q ζ))⁻¹ * omF th q :=
            mul_le_mul_of_nonneg_left hrat (inv_nonneg.mpr hωr.le)
    have hyP : 0 ≤ ⟪y, Pfam th (rq q ζ) y⟫ := inner_P_nonneg th _ _
    have hkey : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ ≤
        ⟪y, G0 (rq q ζ) y⟫ := by
      rw [hyG]
      calc nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫
          = (4 * (1 - bb) / omF th q) * (4 * nlow (bb / 2) ^ 2 * (1 - bb) * ⟪x, Pfam th q x⟫) := by
            ring
        _ ≤ (omF th (rq q ζ))⁻¹ * ⟪y, Pfam th (rq q ζ) y⟫ := by
            apply mul_le_mul hinv h1
            · exact mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _)) hb1'.le) hP
            · exact inv_nonneg.mpr hωr.le
    have hdef := deficit_le hb0 hb1
    -- assemble: `⟨x,𝓜G0 x⟩ − ω⁻¹⟨x,Px⟩ ≥ −2⟨x,Px⟩`
    have hA : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        ⟪x, Mfam th rq G0 q x⟫ := by
      have : nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (16 / omF th q) * ⟪x, Pfam th q x⟫ =
          16 * (nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫) := by
        field_simp
      linarith
    have hB : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
        nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ ≤
        2 * ⟪x, Pfam th q x⟫ := by
      have e : (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ -
          nlow (bb / 2) ^ 2 * (1 - bb) ^ 2 * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ =
          (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ * ⟪x, Pfam th q x⟫ := by ring
      rw [e]
      have h16 : (1 - nlow (bb / 2) ^ 2 * (1 - bb) ^ 2) * (omF th q)⁻¹ ≤ 2 := by
        rw [← div_eq_mul_inv, div_le_iff₀ hωq]
        have e16 : 16 * bb = 2 * omF th q := by rw [hbb]; ring
        linarith
      exact mul_le_mul_of_nonneg_right h16 hP
    linarith

/-- **(R4), upper half** from `Mfam_B_le`: `𝓜(P/ω) − P/ω ≼ 2P`. -/
theorem D_upper (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q) - fun q => (omF th q)⁻¹ • Pfam th q)
      ((2 : ℝ) • Pfam th) := by
  intro q x
  have h := Mfam_B_le th rq hrq hω q x
  have hP := inner_P_nonneg th q x
  simp only [Pi.add_apply, LinearMap.add_apply, inner_add_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right] at h
  simp only [Pi.sub_apply, LinearMap.sub_apply, inner_sub_right, Pi.smul_apply,
    LinearMap.smul_apply, real_inner_smul_right]
  nlinarith

/-- **b_k → b_∞ for the family of Theorem 1** (`λ = 429/512`, `d = 2`): for any `Ξ` Lipschitz
relative to `P` (constant `L`) on a set containing all `G_k = 𝓜^k(P/ω)`. -/
theorem coupling_converges (Ξ : (Qpos → V →ₗ[ℝ] V) → ℝ) (S : Set (Qpos → V →ₗ[ℝ] V)) {L : ℝ}
    (hL : 0 ≤ L)
    (hS : ∀ k, (⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) ∈ S)
    (hΞ : RelLip Ξ (Pfam Subtype.val) L S) :
    ∃ binf : ℝ, Tendsto (fun k => Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))) atTop (𝓝 binf) ∧
      (∀ k, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 * (429 / 512 : ℝ) ^ k / (1 - 429 / 512)) ∧
      (∀ k, binf - L * 2 / (1 - 429 / 512) ≤ Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ∧
        Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
          (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) ≤ binf + L * 2 / (1 - 429 / 512)) ∧
      Summable (fun k => |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf|) ∧
      (∀ n, ∑ k ∈ range n, |Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf| ≤
          L * 2 / (1 - 429 / 512) ^ 2) ∧
      (∀ n, ∑ k ∈ range n, max (-(Ξ ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q)) - binf)) 0 ≤
          L * 2 / (1 - 429 / 512) ^ 2) := by
  have hrq : ∀ (q : Qpos) ζ, Subtype.val (rqPos q ζ) = thR q.1 ζ := fun _ _ => rfl
  have hω : ∀ q : Qpos, 0 < omF Subtype.val q := fun q => q.2
  exact coupling_limit (Mfam (Subtype.val : Qpos → _) rqPos) (Mfam_orderPreserving _ _)
    (by norm_num) (by norm_num) (by norm_num) hL (Mfam_P_le _ _ hrq)
    (D_lower _ _ hrq hω) (D_upper _ _ hrq hω) Ξ S hS hΞ

/-- The numerical constants: `2/(1 − 429/512) = 1024/83 < 12.4` and
`2/(1 − 429/512)² = 524288/6889 < 76.2`. -/
theorem consts : (2 : ℝ) / (1 - 429 / 512) = 1024 / 83 ∧
    (2 : ℝ) / (1 - 429 / 512) ^ 2 = 524288 / 6889 := by
  constructor <;> norm_num

end Concrete

end CouplingLimit

end



-- ===== new part : RowSplit.part.lean =====
/-! # L3(ii) (round two): `𝓜 P ≼ (3/5) P` by the row-wise Cauchy split

work-08. All1135 `OneStepNorm.comp_sq_le` splits every row `μ`
of `N u` with one common `t = 3/10`, giving `λ̄ = 429/512` (`OneStepBridge.Mfam_P_le`). Here row
`μ` is split with `t_μ = 3 x_μ` (`row_split`, no division by `x_μ`), the cross terms keep the exact
`E`, `ρ′` (no `η̄`), and the coefficient of `u_c²` is `coefK`. The alias sum is the polynomial `Gk`
of `y_ν = σ_ν(1 − σ_ν)` and `Gk ≤ 3/5` on `[0, 1/4]⁴` (affine in each transverse `y`, a concave
quadratic in `y_c` at each vertex; largest `0.5902`).
Main: **`MP_coord_le_row`** `Qf θ x ≤ (3/5) ⟨x, P x⟩` and **`Mfam_P_le_row`** `𝓜 P ≼ (3/5) P`
(the `hPstep` of the bracket with `λ̄′ = 3/5` in place of `429/512`).
The hypothesis `hrq` of `Mfam_P_le_row` is the defining equation of the alias maps of the family
(the same convention as All1135 `rqPos`, `thR`), not an assumption on the measure.
-/

noncomputable section

namespace RowSplit

open Finset OneStepNorm OneStepHrep
open scoped Real

/-! ## 1. The row split -/

/-- `(a − sS)² ≤ (1 + k s²) a² + (s² + 1/k) S²` (`k > 0`): the split with `t = k s²`. -/
theorem row_split (a s S : ℝ) {k : ℝ} (hk : 0 < k) :
    (a - s * S) ^ 2 ≤ (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 := by
  have h : 0 ≤ (k * s * a + S) ^ 2 / k := div_nonneg (sq_nonneg _) hk.le
  have e : (1 + k * s ^ 2) * a ^ 2 + (s ^ 2 + 1 / k) * S ^ 2 - (a - s * S) ^ 2 =
      (k * s * a + S) ^ 2 / k := by
    field_simp; ring
  linarith

section MatrixLevel

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Row `μ` with `t_μ = k s̃_μ²`. -/
theorem comp_sq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) (μ : ι) :
    Nap pi st E u μ ^ 2 ≤ (1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2) := by
  rw [comp_identity pi st E u hu μ]
  have h := row_split ((pi μ - st μ ^ 2) * u μ) (st μ)
    (∑ ν ∈ univ.erase μ, E μ ν * (st ν * u ν)) hk
  have hcs := wcs (univ.erase μ) (E μ) st u (fun i _ => hE μ i)
  have hc : 0 ≤ st μ ^ 2 + 1 / k := by positivity
  have h2 : ((pi μ - st μ ^ 2) * u μ) ^ 2 = (pi μ - st μ ^ 2) ^ 2 * u μ ^ 2 := by ring
  rw [h2] at h
  have h3 := mul_le_mul_of_nonneg_left hcs hc
  linarith

theorem normSq_le_row (pi st : ι → ℝ) (E : ι → ι → ℝ) (u : ι → ℝ)
    (hu : ∑ ν, st ν * u ν = 0) (hE : ∀ μ ν, 0 ≤ E μ ν) {k : ℝ} (hk : 0 < k) :
    ∑ μ, Nap pi st E u μ ^ 2 ≤ ∑ μ, ((1 + k * st μ ^ 2) * ((pi μ - st μ ^ 2) ^ 2 * u μ ^ 2) +
      (st μ ^ 2 + 1 / k) * ((∑ ν ∈ univ.erase μ, E μ ν * st ν ^ 2) *
        ∑ ν ∈ univ.erase μ, E μ ν * u ν ^ 2)) :=
  Finset.sum_le_sum fun μ _ => comp_sq_le_row pi st E u hu hE hk μ

end MatrixLevel

/-! ## 2. The coefficient and the polynomial bound -/

/-- The row-split coefficient of `u_c²` with `t_μ = 3 x_μ` (direction `c` first). -/
def coefK (xc x1 x2 x3 : ℝ) : ℝ :=
  (1 + 3 * xc) * ((1 - x1) * (1 - x2) * (1 - x3) - xc) ^ 2 +
    ((x1 + 1 / 3) * Ef x2 x3 * rhoP xc x2 x3 + (x2 + 1 / 3) * Ef x1 x3 * rhoP xc x1 x3 +
      (x3 + 1 / 3) * Ef x1 x2 * rhoP xc x1 x2)

/-- The alias sum as a polynomial in `y_c, y_1, y_2, y_3`. -/
def Gk (y0 y1 y2 y3 : ℝ) : ℝ :=
  (-3/2) * y0^2 + (-3/32) * y0 * y1 * y2 * y3 + (149/576) * y0 * y1 * y2 +
    (149/576) * y0 * y1 * y3 + (-899/1152) * y0 * y1 + (149/576) * y0 * y2 * y3 +
    (-899/1152) * y0 * y2 + (-899/1152) * y0 * y3 + (65/256) * y0 + (-1/32) * y1 * y2 * y3 +
    (31/576) * y1 * y2 + (31/576) * y1 * y3 + (-281/1152) * y1 + (31/576) * y2 * y3 +
    (-281/1152) * y2 + (-281/1152) * y3 + (445/768)

theorem aliasK_eq (σc σ1 σ2 σ3 : ℝ) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) =
      Gk (yv σc) (yv σ1) (yv σ2) (yv σ3) := by
  simp only [Fintype.sum_bool, xa, wa, coefK, Ef, rhoP, yv, Gk]
  ring

theorem yv_mem' {σ : ℝ} (h0 : 0 ≤ σ) (h1 : σ ≤ 1) : 0 ≤ yv σ ∧ yv σ ≤ 1 / 4 := by
  unfold yv
  constructor
  · exact mul_nonneg h0 (by linarith)
  · nlinarith [sq_nonneg (σ - 1 / 2)]

theorem affine_le {f : ℝ → ℝ} {L y : ℝ} (hf : f y = (1 - 4 * y) * f 0 + 4 * y * f (1 / 4))
    (hy0 : 0 ≤ y) (hy1 : y ≤ 1 / 4) (h0 : f 0 ≤ L) (h1 : f (1 / 4) ≤ L) : f y ≤ L := by
  rw [hf]
  have ha : 0 ≤ 1 - 4 * y := by linarith
  have hb : 0 ≤ 4 * y := by linarith
  nlinarith [mul_le_mul_of_nonneg_left h0 ha, mul_le_mul_of_nonneg_left h1 hb]

theorem Gk_vertex {y0 : ℝ} (h0 : 0 ≤ y0) (h1 : y0 ≤ 1 / 4) (v1 v2 v3 : ℝ)
    (hv1 : v1 = 0 ∨ v1 = 1 / 4) (hv2 : v2 = 0 ∨ v2 = 1 / 4) (hv3 : v3 = 0 ∨ v3 = 1 / 4) :
    Gk y0 v1 v2 v3 ≤ 3 / 5 := by
  unfold Gk
  rcases hv1 with rfl | rfl <;> rcases hv2 with rfl | rfl <;> rcases hv3 with rfl | rfl <;>
    nlinarith [sq_nonneg (y0 - 65 / 768), sq_nonneg (y0 - 271 / 13824)]

theorem Gk_le {y0 y1 y2 y3 : ℝ} (h0 : 0 ≤ y0 ∧ y0 ≤ 1 / 4) (h1 : 0 ≤ y1 ∧ y1 ≤ 1 / 4)
    (h2 : 0 ≤ y2 ∧ y2 ≤ 1 / 4) (h3 : 0 ≤ y3 ∧ y3 ≤ 1 / 4) : Gk y0 y1 y2 y3 ≤ 3 / 5 := by
  have V := fun v1 v2 v3 hv1 hv2 hv3 => Gk_vertex h0.1 h0.2 v1 v2 v3 hv1 hv2 hv3
  have s3 : ∀ v1 v2, (v1 = 0 ∨ v1 = 1 / 4) → (v2 = 0 ∨ v2 = 1 / 4) → Gk y0 v1 v2 y3 ≤ 3 / 5 :=
    fun v1 v2 hv1 hv2 => affine_le (f := fun z => Gk y0 v1 v2 z) (by simp only [Gk]; ring)
      h3.1 h3.2 (V v1 v2 0 hv1 hv2 (Or.inl rfl)) (V v1 v2 (1 / 4) hv1 hv2 (Or.inr rfl))
  have s2 : ∀ v1, (v1 = 0 ∨ v1 = 1 / 4) → Gk y0 v1 y2 y3 ≤ 3 / 5 :=
    fun v1 hv1 => affine_le (f := fun z => Gk y0 v1 z y3) (by simp only [Gk]; ring)
      h2.1 h2.2 (s3 v1 0 hv1 (Or.inl rfl)) (s3 v1 (1 / 4) hv1 (Or.inr rfl))
  exact affine_le (f := fun z => Gk y0 z y2 y3) (by simp only [Gk]; ring)
    h1.1 h1.2 (s2 0 (Or.inl rfl)) (s2 (1 / 4) (Or.inr rfl))

theorem aliasK_le {σc σ1 σ2 σ3 : ℝ} (hc : 0 ≤ σc ∧ σc ≤ 1) (h1 : 0 ≤ σ1 ∧ σ1 ≤ 1)
    (h2 : 0 ≤ σ2 ∧ σ2 ≤ 1) (h3 : 0 ≤ σ3 ∧ σ3 ≤ 1) :
    (1 / 4) * ∑ bc, ∑ b1, ∑ b2, ∑ b3,
        wa σc bc * coefK (xa σc bc) (xa σ1 b1) (xa σ2 b2) (xa σ3 b3) ≤ 3 / 5 := by
  rw [aliasK_eq]
  exact Gk_le (yv_mem' hc.1 hc.2) (yv_mem' h1.1 h1.2) (yv_mem' h2.1 h2.2) (yv_mem' h3.1 h3.2)

/-! ## 3. One alias with the row split -/

set_option maxRecDepth 8000 in
theorem normSq_alias_row (s w : Fin 4 → ℝ) (hw : dot s w = 0)
    (hx : ∀ ν, 0 ≤ xs s ν ∧ xs s ν ≤ 1 / 2) :
    ∑ μ, Nm s w μ ^ 2 ≤
      coefK (xs s 0) (xs s 1) (xs s 2) (xs s 3) * w 0 ^ 2 +
      coefK (xs s 1) (xs s 0) (xs s 2) (xs s 3) * w 1 ^ 2 +
      coefK (xs s 2) (xs s 0) (xs s 1) (xs s 3) * w 2 ^ 2 +
      coefK (xs s 3) (xs s 0) (xs s 1) (xs s 2) * w 3 ^ 2 := by
  have hc2 : Real.sqrt (1 / 2) ^ 2 = 1 / 2 := Real.sq_sqrt (by norm_num)
  simp_rw [Nm_eq_Nap]
  have hu : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = 0 := by
    have : ∑ ν, Real.sqrt (1 / 2) * s ν * w ν = Real.sqrt (1 / 2) * dot s w := by
      unfold dot; rw [Finset.mul_sum]
      exact Finset.sum_congr rfl fun ν _ => by ring
    rw [this, hw, mul_zero]
  refine le_of_le_of_eq (normSq_le_row _ _ _ w hu (EF_nonneg hx) (by norm_num : (0 : ℝ) < 3)) ?_
  have hst : ∀ ν, (Real.sqrt (1 / 2) * s ν) ^ 2 = xs s ν := by
    intro ν; rw [mul_pow, hc2]; unfold xs; ring
  simp only [hst]
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, coefK, rhoP, Ef, Matrix.cons_val]
  ring

/-- The alias coefficients with the row split. -/
def DalK (σ : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 / 4) * ∑ b0, ∑ b1, ∑ b2, ∑ b3, wa (σ 0) b0 *
      coefK (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b1, ∑ b0, ∑ b2, ∑ b3, wa (σ 1) b1 *
      coefK (xa (σ 1) b1) (xa (σ 0) b0) (xa (σ 2) b2) (xa (σ 3) b3),
    (1 / 4) * ∑ b2, ∑ b0, ∑ b1, ∑ b3, wa (σ 2) b2 *
      coefK (xa (σ 2) b2) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 3) b3),
    (1 / 4) * ∑ b3, ∑ b0, ∑ b1, ∑ b2, wa (σ 3) b3 *
      coefK (xa (σ 3) b3) (xa (σ 0) b0) (xa (σ 1) b1) (xa (σ 2) b2)]

theorem DalK_le {σ : Fin 4 → ℝ} (hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1) (c : Fin 4) :
    DalK σ c ≤ 3 / 5 := by
  fin_cases c
  · exact aliasK_le (hσ 0) (hσ 1) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 1) (hσ 0) (hσ 2) (hσ 3)
  · exact aliasK_le (hσ 2) (hσ 0) (hσ 1) (hσ 3)
  · exact aliasK_le (hσ 3) (hσ 0) (hσ 1) (hσ 2)

theorem alias_term_le_row (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * (coefK (xa (Real.sin (θ 0) ^ 2) (ζ 0)) (xa (Real.sin (θ 1) ^ 2) (ζ 1))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 0) ^ 2) (ζ 0) * proj (sQ θ) x 0 ^ 2) +
        coefK (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 1) ^ 2) (ζ 1) * proj (sQ θ) x 1 ^ 2) +
        coefK (xa (Real.sin (θ 2) ^ 2) (ζ 2)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 3) ^ 2) (ζ 3)) *
          (wa (Real.sin (θ 2) ^ 2) (ζ 2) * proj (sQ θ) x 2 ^ 2) +
        coefK (xa (Real.sin (θ 3) ^ 2) (ζ 3)) (xa (Real.sin (θ 0) ^ 2) (ζ 0))
            (xa (Real.sin (θ 1) ^ 2) (ζ 1)) (xa (Real.sin (θ 2) ^ 2) (ζ 2)) *
          (wa (Real.sin (θ 3) ^ 2) (ζ 3) * proj (sQ θ) x 3 ^ 2)) := by
  set u := proj (sQ θ) x with hu_def
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hPw : proj (sR θ ζ) w = w := proj_of_dot hw
  have hA : Atr θ ζ x = fun μ => 2 * Nm (sR θ ζ) w μ := by
    unfold Atr
    rw [hPw]
  have hNw : dot (sR θ ζ) (Atr θ ζ x) = 0 := by
    rw [hA]
    have h := dot_Nm_of_dot hw
    unfold dot at h ⊢
    have : ∑ i, sR θ ζ i * (2 * Nm (sR θ ζ) w i) = 2 * ∑ i, sR θ ζ i * Nm (sR θ ζ) w i := by
      rw [Finset.mul_sum]; exact Finset.sum_congr rfl fun i _ => by ring
    rw [this, h, mul_zero]
  rw [proj_of_dot hNw, hA]
  have hx : ∀ ν, 0 ≤ xs (sR θ ζ) ν ∧ xs (sR θ ζ) ν ≤ 1 / 2 := by
    intro ν
    rw [xs_alias]
    exact xa_mem (sigma_mem (θ ν)).1 (sigma_mem (θ ν)).2 (ζ ν)
  have hb := normSq_alias_row (sR θ ζ) w hw hx
  simp only [xs_alias] at hb
  have hw2 : ∀ ν, w ν ^ 2 = wa (Real.sin (θ ν) ^ 2) (ζ ν) * u ν ^ 2 := fun ν =>
    w_sq_alias θ ζ u ν
  rw [hw2 0, hw2 1, hw2 2, hw2 3] at hb
  have e : dot (fun μ => 2 * Nm (sR θ ζ) w μ) (fun μ => 2 * Nm (sR θ ζ) w μ) =
      4 * ∑ μ, Nm (sR θ ζ) w μ ^ 2 := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun μ _ => by ring
  rw [e]
  linarith

theorem hrep_coord_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 := by
  unfold Qf
  have h := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) =>
    alias_term_le_row θ x ζ
  refine le_of_le_of_eq (mul_le_mul_of_nonneg_left h (by norm_num)) ?_
  rw [sum_bool4]
  simp only [Fin.sum_univ_four, DalK, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons,
    Fintype.sum_bool]
  ring

/-- **The one-step bound with the row split**: `⟨x, (𝓜P)(q) x⟩ ≤ (3/5) ⟨x, P(q) x⟩`. -/
theorem MP_coord_le_row (θ x : Fin 4 → ℝ) :
    Qf θ x ≤ (3 / 5) * dot x (proj (sQ θ) x) := by
  refine (hrep_coord_row θ x).trans ?_
  have hσ : ∀ ν, 0 ≤ Real.sin (θ ν) ^ 2 ∧ Real.sin (θ ν) ^ 2 ≤ 1 := fun ν => sigma_mem (θ ν)
  have h1 : ∑ c, DalK (fun ν => Real.sin (θ ν) ^ 2) c * proj (sQ θ) x c ^ 2 ≤
      ∑ c, (3 / 5) * proj (sQ θ) x c ^ 2 :=
    Finset.sum_le_sum fun c _ => mul_le_mul_of_nonneg_right (DalK_le hσ c) (sq_nonneg _)
  refine h1.trans (le_of_eq ?_)
  rw [← Finset.mul_sum, ← dot_proj_self]
  unfold dot
  congr 1
  exact Finset.sum_congr rfl fun c _ => by ring

end RowSplit

namespace OneStepBridge

open Finset OneStepHrep Matrix
open scoped Real RealInnerProductSpace

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **`hPstep` with `λ̄′ = 3/5`**: `𝓜 P ≼ (3/5) P` (row-wise split). -/
theorem Mfam_P_le_row (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) :
    UniformBracket.Lw (Mfam th rq (Pfam th)) ((3 / 5 : ℝ) • Pfam th) := by
  intro q x
  rw [Mfam_P_inner th rq hrq]
  simp only [Pi.smul_apply, LinearMap.smul_apply, real_inner_smul_right]
  rw [inner_coord]
  unfold Pfam
  rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec]
  exact RowSplit.MP_coord_le_row (th q) (WithLp.ofLp x)

end OneStepBridge

end

namespace NmBracket

noncomputable section

open Finset

/-! ## Copied definitions  -/

def dot (a b : Fin 4 → ℝ) : ℝ := ∑ i, a i * b i

def Ef (y z : ℝ) : ℝ := (y + z) / 2 - y * z / 3

def xs (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := s ν ^ 2 / 2

def piF (x : Fin 4 → ℝ) : Fin 4 → ℝ :=
  ![(1 - x 1) * (1 - x 2) * (1 - x 3), (1 - x 0) * (1 - x 2) * (1 - x 3),
    (1 - x 0) * (1 - x 1) * (1 - x 3), (1 - x 0) * (1 - x 1) * (1 - x 2)]

def EF (x : Fin 4 → ℝ) : Fin 4 → Fin 4 → ℝ :=
  ![![0, Ef (x 2) (x 3), Ef (x 1) (x 3), Ef (x 1) (x 2)],
    ![Ef (x 2) (x 3), 0, Ef (x 0) (x 3), Ef (x 0) (x 2)],
    ![Ef (x 1) (x 3), Ef (x 0) (x 3), 0, Ef (x 0) (x 1)],
    ![Ef (x 1) (x 2), Ef (x 0) (x 2), Ef (x 0) (x 1), 0]]

/-- `(N u)_μ = π_μ u_μ + ½ s_μ Σ_{ν≠μ} (1 − E_{μν}) s_ν u_ν`. -/
def Nm (s u : Fin 4 → ℝ) (μ : Fin 4) : ℝ :=
  piF (xs s) μ * u μ + (1 / 2) * s μ * ∑ ν ∈ univ.erase μ, (1 - EF (xs s) μ ν) * (s ν * u ν)

theorem sum_erase4 (f : Fin 4 → ℝ) (μ : Fin 4) :
    ∑ ν ∈ univ.erase μ, f ν = f 0 + f 1 + f 2 + f 3 - f μ := by
  rw [Finset.sum_erase_eq_sub (mem_univ μ), Fin.sum_univ_four]

theorem dot_comm (a b : Fin 4 → ℝ) : dot a b = dot b a := by
  unfold dot; exact Finset.sum_congr rfl fun i _ => mul_comm _ _

theorem Nm_symm (s u v : Fin 4 → ℝ) : dot v (Nm s u) = dot (Nm s v) u := by
  unfold dot Nm
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF]
  simp
  ring

theorem Nm_self (s : Fin 4 → ℝ) : Nm s s = s := by
  funext μ
  unfold Nm
  simp only [sum_erase4, EF, piF, xs, Ef]
  fin_cases μ <;> simp <;> ring

/-- Linearity of `N` in `u` (one combination). -/
theorem Nm_lin (s u v : Fin 4 → ℝ) (t : ℝ) :
    Nm s (fun i => u i + t * v i) = fun i => Nm s u i + t * Nm s v i := by
  funext μ
  unfold Nm
  simp only [sum_erase4]
  ring

/-! ## The `M`-form : `N u = u − ½ M u`, `M = Σ_{μ<ν} B_{μν} ρ ρᵀ` -/

/-- `B_{μν}` of the complementary pair `{ρ, ρ'}`, in `b = s²`. -/
def Bw (b b' : ℝ) : ℝ := 1 - (b + b') / 4 + b * b' / 12

theorem one_sub_Ef (b b' : ℝ) : 1 - Ef (b / 2) (b' / 2) = Bw b b' := by
  unfold Ef Bw; ring

/-- `D_{μν} = s_ν u_μ − s_μ u_ν`. -/
def Dp (s u : Fin 4 → ℝ) (μ ν : Fin 4) : ℝ := s ν * u μ - s μ * u ν

/-- The quadratic form `⟨u, M u⟩ = Σ_{μ<ν} B_{μν} D_{μν}²` written out over the six faces. -/
def Mq (s u : Fin 4 → ℝ) : ℝ :=
  Bw (s 2 ^ 2) (s 3 ^ 2) * Dp s u 0 1 ^ 2 + Bw (s 1 ^ 2) (s 3 ^ 2) * Dp s u 0 2 ^ 2 +
  Bw (s 1 ^ 2) (s 2 ^ 2) * Dp s u 0 3 ^ 2 + Bw (s 0 ^ 2) (s 3 ^ 2) * Dp s u 1 2 ^ 2 +
  Bw (s 0 ^ 2) (s 2 ^ 2) * Dp s u 1 3 ^ 2 + Bw (s 0 ^ 2) (s 1 ^ 2) * Dp s u 2 3 ^ 2

set_option maxRecDepth 8000 in
/-- `⟨u, N u⟩ = |u|² − ½ ⟨u, M u⟩` (unordered faces `μ < ν`). -/
theorem Nm_form (s u : Fin 4 → ℝ) : dot u (Nm s u) = dot u u - (1 / 2) * Mq s u := by
  unfold dot Nm Mq Dp Bw
  simp only [sum_erase4, Fin.sum_univ_four, EF, piF, xs, Ef, Matrix.cons_val]
  simp
  ring

/-! ## Per-face bounds on `B` (P3, P3′) -/

theorem Bw_le_refined {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') (hb1 : b ≤ 1) (hb1' : b' ≤ 1) :
    Bw b b' ≤ 1 - 5 * (b + b') / 24 := by
  unfold Bw; nlinarith [mul_nonneg hb hb', mul_nonneg (sub_nonneg.2 hb1) hb',
    mul_nonneg hb (sub_nonneg.2 hb1'), sq_nonneg (b - b')]

theorem Bw_ge_lin {b b' : ℝ} (hb : 0 ≤ b) (hb' : 0 ≤ b') : 1 - (b + b') / 4 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg hb hb']

theorem Bw_lower {b b' : ℝ} (hb1 : b ≤ 1) (hb1' : b' ≤ 1) : 7 / 12 ≤ Bw b b' := by
  unfold Bw; nlinarith [mul_nonneg (sub_nonneg.2 hb1) (sub_nonneg.2 hb1')]

/-! ## The bracket on `s^⊥` -/

def llo (X bm sb : ℝ) : ℝ := 1 - 1/2*((1 - 5/24*X)*X + 5/24*(X*bm + sb))
def lup (X sb : ℝ) : ℝ := min (1 - 7/24*X) (1 - (X - X^2/4 + sb/4)/2)

def Xs (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 2
def Sb (s : Fin 4 → ℝ) : ℝ := ∑ ν, s ν ^ 4

section Bracket

variable {s u : Fin 4 → ℝ}

/-- Upper side of `⟨u, M u⟩` (gives `λ_lo`): with `u ⊥ s`,
`⟨u,Mu⟩ ≤ (1 − 5X/24) X |u|² + 5/24 (X Σ s²u² + Σ s⁴ |u|²)`. -/
theorem Mq_le (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    Mq s u ≤ (1 - 5/24 * Xs s) * Xs s * dot u u +
      5/24 * (Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 + Sb s * dot u u) := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have f01 := mul_le_mul_of_nonneg_right (Bw_le_refined p2 p3 h2 h3) (sq_nonneg (Dp s u 0 1))
  have f02 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p3 h1 h3) (sq_nonneg (Dp s u 0 2))
  have f03 := mul_le_mul_of_nonneg_right (Bw_le_refined p1 p2 h1 h2) (sq_nonneg (Dp s u 0 3))
  have f12 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p3 h0 h3) (sq_nonneg (Dp s u 1 2))
  have f13 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p2 h0 h2) (sq_nonneg (Dp s u 1 3))
  have f23 := mul_le_mul_of_nonneg_right (Bw_le_refined p0 p1 h0 h1) (sq_nonneg (Dp s u 2 3))
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  unfold Mq
  simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at f01 f02 f03 f12 f13 f23 ⊢
  linarith

/-- Lower sides of `⟨u, M u⟩` (give `λ_up`). -/
theorem Mq_ge (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    7/12 * (Xs s * dot u u) ≤ Mq s u ∧
      (Xs s - Xs s ^ 2 / 4 + Sb s / 4) * dot u u ≤ Mq s u := by
  have h0 := hb 0; have h1 := hb 1; have h2 := hb 2; have h3 := hb 3
  have p0 := sq_nonneg (s 0); have p1 := sq_nonneg (s 1)
  have p2 := sq_nonneg (s 2); have p3 := sq_nonneg (s 3)
  have hu' : s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3 = 0 := by
    simpa [dot, Fin.sum_univ_four] using hu
  have e1 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) = 0 := by rw [hu']; ring
  have e2 : (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
      ((s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3)) = 0 := by rw [e1]; ring
  have e3 : (s 0 * u 0 + s 1 * u 1 + s 2 * u 2 + s 3 * u 3) *
      (s 0 ^ 3 * u 0 + s 1 ^ 3 * u 1 + s 2 ^ 3 * u 2 + s 3 ^ 3 * u 3) = 0 := by rw [hu']; ring
  constructor
  · have g01 := mul_le_mul_of_nonneg_right (Bw_lower h2 h3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_lower h1 h3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_lower h1 h2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_lower h0 h3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_lower h0 h2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_lower h0 h1) (sq_nonneg (Dp s u 2 3))
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith
  · have g01 := mul_le_mul_of_nonneg_right (Bw_ge_lin p2 p3) (sq_nonneg (Dp s u 0 1))
    have g02 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p3) (sq_nonneg (Dp s u 0 2))
    have g03 := mul_le_mul_of_nonneg_right (Bw_ge_lin p1 p2) (sq_nonneg (Dp s u 0 3))
    have g12 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p3) (sq_nonneg (Dp s u 1 2))
    have g13 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p2) (sq_nonneg (Dp s u 1 3))
    have g23 := mul_le_mul_of_nonneg_right (Bw_ge_lin p0 p1) (sq_nonneg (Dp s u 2 3))
    have hX : 0 ≤ (s 0 ^ 2 + s 1 ^ 2 + s 2 ^ 2 + s 3 ^ 2) *
        (s 0 ^ 2 * u 0 ^ 2 + s 1 ^ 2 * u 1 ^ 2 + s 2 ^ 2 * u 2 ^ 2 + s 3 ^ 2 * u 3 ^ 2) := by
      positivity
    unfold Mq
    simp only [Dp, Xs, Sb, dot, Fin.sum_univ_four] at g01 g02 g03 g12 g13 g23 ⊢
    linarith

theorem dot_self_nonneg (u : Fin 4 → ℝ) : 0 ≤ dot u u :=
  Finset.sum_nonneg fun i _ => mul_self_nonneg (u i)

theorem Xs_nonneg (s : Fin 4 → ℝ) : 0 ≤ Xs s := Finset.sum_nonneg fun i _ => sq_nonneg _

/-- **Lower end of the bracket**: `λ_lo |u|² ≤ ⟨u, N u⟩` on `s^⊥`. -/
theorem Nm_bracket_lo {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1) (hbm : ∀ ν, s ν ^ 2 ≤ bm)
    (hu : dot s u = 0) : llo (Xs s) bm (Sb s) * dot u u ≤ dot u (Nm s u) := by
  rw [Nm_form]
  have h := Mq_le hb hu
  have hw : ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ bm * dot u u := by
    unfold dot; rw [Finset.mul_sum]
    exact Finset.sum_le_sum fun ν _ => by
      have := mul_le_mul_of_nonneg_right (hbm ν) (sq_nonneg (u ν)); nlinarith
  have hX := Xs_nonneg s
  have : Xs s * ∑ ν, s ν ^ 2 * u ν ^ 2 ≤ Xs s * (bm * dot u u) :=
    mul_le_mul_of_nonneg_left hw hX
  unfold llo
  nlinarith

/-- **Upper end of the bracket**: `⟨u, N u⟩ ≤ λ_up |u|²` on `s^⊥`. -/
theorem Nm_bracket_up (hb : ∀ ν, s ν ^ 2 ≤ 1) (hu : dot s u = 0) :
    dot u (Nm s u) ≤ lup (Xs s) (Sb s) * dot u u := by
  rw [Nm_form]
  obtain ⟨h1, h2⟩ := Mq_ge hb hu
  unfold lup
  rw [min_mul_of_nonneg _ _ (dot_self_nonneg u)]
  refine le_min ?_ ?_ <;> nlinarith

end Bracket

/-! ## From the bracket to the norm bounds `κ⁻`, `κ⁺` -/

section Norm

theorem dot_add_right (a b c : Fin 4 → ℝ) : dot a (fun i => b i + c i) = dot a b + dot a c := by
  unfold dot; rw [← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_smul_right (a b : Fin 4 → ℝ) (t : ℝ) : dot a (fun i => t * b i) = t * dot a b := by
  unfold dot; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun i _ => by ring

theorem dot_add_left (a b c : Fin 4 → ℝ) : dot (fun i => a i + b i) c = dot a c + dot b c := by
  rw [dot_comm, dot_add_right, dot_comm c a, dot_comm c b]

theorem dot_smul_left (a b : Fin 4 → ℝ) (t : ℝ) : dot (fun i => t * a i) b = t * dot a b := by
  rw [dot_comm, dot_smul_right, dot_comm]

/-- `N` maps `s^⊥` into itself. -/
theorem dot_Nm_of_dot {s w : Fin 4 → ℝ} (h : dot s w = 0) : dot s (Nm s w) = 0 := by
  rw [Nm_symm, Nm_self, h]

/-- Cauchy–Schwarz for `dot`. -/
theorem dot_sq_le (a b : Fin 4 → ℝ) : dot a b ^ 2 ≤ dot a a * dot b b := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq (univ : Finset (Fin 4)) a b
  unfold dot
  simpa [sq] using h

variable {s u : Fin 4 → ℝ}

/-- The frame inequality on `s^⊥`: `|N u − lo u|² ≤ (up − lo)(⟨u,Nu⟩ − lo|u|²)`. -/
theorem frame_ineq {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) ≤
      (up - lo) * (dot u (Nm s u) - lo * dot u u) := by
  set y : Fin 4 → ℝ := fun i => Nm s u i + (-lo) * u i with hy
  -- the positive form p(v) = ⟨v, N v⟩ - lo |v|² on s^⊥
  have hys : dot s y = 0 := by
    rw [hy, dot_add_right, dot_smul_right, dot_Nm_of_dot hu, hu]; ring
  have hNy : Nm s y = fun i => Nm s (Nm s u) i + (-lo) * Nm s u i := by
    rw [hy, Nm_lin]
  -- c = ⟨u, P y⟩ = |y|²
  have hc : dot u (Nm s y) + (-lo) * dot u y = dot y y := by
    rw [hNy, dot_add_right, dot_smul_right, Nm_symm s (Nm s u) u]
    conv_rhs => rw [hy, dot_add_left, dot_smul_left]
    rw [hy, dot_add_right, dot_smul_right]
    rw [dot_comm (Nm s u) (Nm s u)]
    have : dot (Nm s u) u = dot u (Nm s u) := dot_comm _ _
    rw [dot_add_right, dot_smul_right, this]
  set p := dot u (Nm s u) - lo * dot u u
  set c := dot y y
  set d := dot y (Nm s y) - lo * dot y y
  have hp : 0 ≤ p := by have := hlo u hu; simp only [p]; linarith
  have hyy : 0 ≤ c := dot_self_nonneg y
  have hd : d ≤ (up - lo) * c := by
    have := hup y hys; simp only [d, c]; linarith
  -- positivity of the form along u + t y
  have hf : ∀ t : ℝ, 0 ≤ p + 2 * t * c + t ^ 2 * d := by
    intro t
    set v : Fin 4 → ℝ := fun i => u i + t * y i with hv
    have hvs : dot s v = 0 := by rw [hv, dot_add_right, dot_smul_right, hu, hys]; ring
    have h0 := hlo v hvs
    have hNv : Nm s v = fun i => Nm s u i + t * Nm s y i := by rw [hv, Nm_lin]
    have hyu : dot y (Nm s u) = dot u (Nm s y) := by rw [Nm_symm, dot_comm]
    have e1 : dot v (Nm s v) = dot u (Nm s u) + 2 * t * dot u (Nm s y) +
        t ^ 2 * dot y (Nm s y) := by
      rw [hNv, hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, hyu]
      ring
    have e2 : dot v v = dot u u + 2 * t * dot u y + t ^ 2 * dot y y := by
      rw [hv, dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
        dot_smul_right, dot_smul_right, dot_comm y u]
      ring
    have hc' : dot u (Nm s y) - lo * dot u y = c := by simp only [c]; linarith [hc]
    rw [e1, e2] at h0
    have h2c : 2 * t * (dot u (Nm s y) - lo * dot u y) = 2 * t * c := by rw [hc']
    simp only [p, d]
    nlinarith [h2c]
  by_cases hD : 0 < up - lo
  · have h1 := hf (-(1 / (up - lo)))
    have hdiv : d * (1 / (up - lo)) ^ 2 ≤ c * (1 / (up - lo)) := by
      have hpos : 0 < 1 / (up - lo) := by positivity
      have := mul_le_mul_of_nonneg_right hd (sq_nonneg (1 / (up - lo)))
      have e : (up - lo) * c * (1 / (up - lo)) ^ 2 = c * (1 / (up - lo)) := by
        field_simp
      linarith
    have h2 : 0 ≤ p - c * (1 / (up - lo)) := by nlinarith
    have h3 : c * (1 / (up - lo)) ≤ p := by linarith
    have := mul_le_mul_of_nonneg_left h3 hD.le
    have e : (up - lo) * (c * (1 / (up - lo))) = c := by field_simp
    linarith
  · -- `up ≤ lo`: then `p = 0`, `d ≤ 0`, and positivity along `u + t y` forces `c = 0`
    have hd0 : d ≤ 0 := by nlinarith
    have hpa : p ≤ 0 := by
      have h1 := hup u hu
      have ha := dot_self_nonneg u
      have : (up - lo) * dot u u ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (by linarith) ha
      simp only [p]; nlinarith
    have hp0 : p = 0 := le_antisymm hpa hp
    rw [hp0, mul_zero]
    by_contra hcon
    have hcpos : 0 < c := lt_of_not_ge hcon
    have h1 := hf (-1 / (2 * c))
    rw [hp0] at h1
    have e : 2 * (-1 / (2 * c)) * c = -1 := by field_simp
    have hn : (-1 / (2 * c)) ^ 2 * d ≤ 0 := mul_nonpos_of_nonneg_of_nonpos (sq_nonneg _) hd0
    linarith

/-- **`κ⁺`**: on `s^⊥`, `|N u|² ≤ max (lo²) (up²) |u|²`. -/
theorem Nm_sq_le_of_bracket {lo up : ℝ}
    (hlo : ∀ v, dot s v = 0 → lo * dot v v ≤ dot v (Nm s v))
    (hup : ∀ v, dot s v = 0 → dot v (Nm s v) ≤ up * dot v v) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤ max (lo ^ 2) (up ^ 2) * dot u u := by
  have hF := frame_ineq hlo hup hu
  have e : dot (fun i => Nm s u i + (-lo) * u i) (fun i => Nm s u i + (-lo) * u i) =
      dot (Nm s u) (Nm s u) - 2 * lo * dot u (Nm s u) + lo ^ 2 * dot u u := by
    rw [dot_add_left, dot_add_right, dot_add_right, dot_smul_left, dot_smul_left,
      dot_smul_right, dot_smul_right, dot_comm (Nm s u) u]
    ring
  rw [e] at hF
  set t := dot u (Nm s u)
  set a := dot u u
  have ha : 0 ≤ a := dot_self_nonneg u
  have h1 := hlo u hu
  have h2 := hup u hu
  have hm1 := le_max_left (lo ^ 2) (up ^ 2)
  have hm2 := le_max_right (lo ^ 2) (up ^ 2)
  -- `N² ≤ (up + lo) t − up lo a`, linear in `t ∈ [lo a, up a]`
  rcases le_total 0 (up + lo) with hs | hs
  · have : (up + lo) * t ≤ (up + lo) * (up * a) := mul_le_mul_of_nonneg_left h2 hs
    nlinarith [mul_le_mul_of_nonneg_right hm2 ha]
  · have : (up + lo) * (lo * a) ≥ (up + lo) * t := mul_le_mul_of_nonpos_left h1 hs
    nlinarith [mul_le_mul_of_nonneg_right hm1 ha]

/-- **`κ⁻`**: on `s^⊥`, `(max lo 0)² |u|² ≤ |N u|²`. -/
theorem le_Nm_sq_of_bracket {lo : ℝ}
    (hlo : lo * dot u u ≤ dot u (Nm s u)) :
    (max lo 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) := by
  have ha := dot_self_nonneg u
  have hcs := dot_sq_le u (Nm s u)
  rcases le_total lo 0 with h | h
  · rw [max_eq_right h]; simp; exact dot_self_nonneg _
  · rw [max_eq_left h]
    have ht : lo * dot u u ≤ dot u (Nm s u) := hlo
    have h0 : 0 ≤ lo * dot u u := mul_nonneg h ha
    have hsq : (lo * dot u u) ^ 2 ≤ dot u (Nm s u) ^ 2 := pow_le_pow_left₀ h0 ht 2
    rcases lt_or_eq_of_le ha with hpos | hzero
    · have : lo ^ 2 * dot u u * dot u u ≤ dot (Nm s u) (Nm s u) * dot u u := by nlinarith
      exact le_of_mul_le_mul_right this hpos
    · rw [← hzero]; simp; exact dot_self_nonneg _

end Norm

/-! ## The concrete `κ⁻`, `κ⁺` of TauStageZero -/

theorem Nm_sq_le_kplus {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    dot (Nm s u) (Nm s u) ≤
      max (llo (Xs s) bm (Sb s) ^ 2) (lup (Xs s) (Sb s) ^ 2) * dot u u :=
  Nm_sq_le_of_bracket (fun _ hv => Nm_bracket_lo hb hbm hv) (fun _ hv => Nm_bracket_up hb hv) hu

theorem kminus_le_Nm_sq {s u : Fin 4 → ℝ} {bm : ℝ} (hb : ∀ ν, s ν ^ 2 ≤ 1)
    (hbm : ∀ ν, s ν ^ 2 ≤ bm) (hu : dot s u = 0) :
    (max (llo (Xs s) bm (Sb s)) 0) ^ 2 * dot u u ≤ dot (Nm s u) (Nm s u) :=
  le_Nm_sq_of_bracket (Nm_bracket_lo hb hbm hu)


end

end NmBracket

/-! # L2-3: (OS↑) `𝓜(P/ω) ≼ P/ω` from `E_ν ≤ 4`, and the transient `D₀ = 0`

Paper: theorem 3 (`E_ν < 4 ⇒ (OS↑)`), §8.57 ("紙のまま: E_ν < 4 ⇒ (OS↑)、Lean の EE と紙の
E_ν の同一"). Lean: `os_up` is `UniformBracket.Lw (Mfam th rq G₀) G₀`, `G₀ = P/ω`, i.e. the field
`h1` of `CouplingLimit.transient_zero`, under the hypothesis `hEE : EE σ(q) ν ≤ 4` where `EE` is
the definition of (`EE s ν = Σ_e HH s / XX s e * kplus s e * (1 − bb s e ν)`) copied
verbatim, and `σ(q)_ν = sin²(th q ν)`. The hypothesis is the conclusion of 
`FreeStageOS.E_lt_four_s` (`Adm σ`, i.e. `σ ≤ 1/2`, and `σ ≠ 0`).

Dictionary (proved here): `xa = bb/2`, `wa = 1 − bb`, `omR = 4·XX`, `omQ = 4·HH`,
`sR² = bb`, `Σ sR² = XX`, `Σ sR⁴ = SS`; the per-alias bound `alias_term_le_kplus` replaces
`alias_term_le_one` (κ⁺ in place of 1) via `NmBracket.Nm_sq_le_kplus`. -/

namespace OSUpBridge

open Finset OneStepNorm OneStepHrep OneStepBridge OneStepET Matrix
open scoped Real RealInnerProductSpace

/-! ## Copies of the definitions (ℝ) -/

def bb (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (μ : Fin 4) : ℝ := if e μ then 1 - s μ else s μ
def XX (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, bb s e μ
def SS (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, (bb s e μ)^2
def BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max (max (bb s e 0) (bb s e 1)) (max (bb s e 2) (bb s e 3))
def HH (s : Fin 4 → ℝ) : ℝ := 4 * ∑ μ, s μ * (1 - s μ)
noncomputable def lamLo (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.llo (XX s e) (BM s e) (SS s e)
noncomputable def lamUp (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  NmBracket.lup (XX s e) (SS s e)
noncomputable def kplus (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max ((lamLo s e)^2) ((lamUp s e)^2)
noncomputable def EE (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  ∑ e, HH s / XX s e * kplus s e * (1 - bb s e ν)

/-! ## The dictionary -/

theorem xa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    xa (s ν) (e ν) = bb s e ν / 2 := by
  unfold bb; cases e ν <;> simp [xa]

theorem wa_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) :
    wa (s ν) (e ν) = 1 - bb s e ν := by
  unfold bb; cases e ν <;> simp [wa]

theorem omR_eq (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : omR s e = 4 * XX s e := by
  unfold omR XX; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by rw [xa_eq]; ring

theorem omQ_eq (s : Fin 4 → ℝ) : omQ s = 4 * HH s := by
  unfold omQ HH; rw [Finset.mul_sum, Finset.mul_sum]
  exact Finset.sum_congr rfl fun ν _ => by ring

theorem sR_sq (θ : Fin 4 → ℝ) (ζ : Fin 4 → Bool) (ν : Fin 4) :
    sR θ ζ ν ^ 2 = bb (fun ν => Real.sin (θ ν) ^ 2) ζ ν := by
  have h := xs_alias θ ζ ν
  unfold xs at h
  rw [xa_eq (fun ν => Real.sin (θ ν) ^ 2) ζ ν] at h
  linarith

theorem bb_le_BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (ν : Fin 4) : bb s e ν ≤ BM s e := by
  unfold BM
  fin_cases ν
  · exact le_trans (le_max_left _ _) (le_max_left _ _)
  · exact le_trans (le_max_right _ _) (le_max_left _ _)
  · exact le_trans (le_max_left _ _) (le_max_right _ _)
  · exact le_trans (le_max_right _ _) (le_max_right _ _)

/-- `N` of All1135 is the `N` of `NmBracket` (same definition). -/
theorem Nm_eq (s u : Fin 4 → ℝ) : Nm s u = NmBracket.Nm s u := rfl

theorem dot_eq (a b : Fin 4 → ℝ) : dot a b = NmBracket.dot a b := rfl

/-! ## One alias with `κ⁺` -/

/-- **`alias_term_le_kplus`**: `⟨A_ζᵀx, P(r_ζ)A_ζᵀx⟩ ≤ 4 κ⁺_ζ Σ_μ cos²(r_{ζ,μ}/2) (P(q)x)_μ²`. -/
theorem alias_term_le_kplus (θ x : Fin 4 → ℝ) (ζ : Fin 4 → Bool) :
    dot (Atr θ ζ x) (proj (sR θ ζ) (Atr θ ζ x)) ≤
      4 * kplus (fun ν => Real.sin (θ ν) ^ 2) ζ *
        ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * proj (sQ θ) x μ ^ 2 := by
  rw [alias_term_eq]
  set σ : Fin 4 → ℝ := fun ν => Real.sin (θ ν) ^ 2 with hσ
  set u := proj (sQ θ) x
  set w : Fin 4 → ℝ := fun ν => cR θ ζ ν * sg ζ ν * u ν with hw_def
  have hu : ∑ ν, u ν * Real.sin (2 * θ ν) = 0 := by
    have h := dot_proj (sQ θ) x
    rw [dot_comm] at h
    exact h
  have hw : dot (sR θ ζ) w = 0 := by
    have h := alias_orth_zero θ ζ u hu
    rw [dot_comm]
    exact h
  have hb : ∀ ν, sR θ ζ ν ^ 2 ≤ 1 := fun ν => by
    unfold sR; exact Real.sin_sq_le_one _
  have hbm : ∀ ν, sR θ ζ ν ^ 2 ≤ BM σ ζ := fun ν => by
    rw [sR_sq]; exact bb_le_BM σ ζ ν
  have hK := NmBracket.Nm_sq_le_kplus hb hbm (by rw [← dot_eq]; exact hw)
  have hX : NmBracket.Xs (sR θ ζ) = XX σ ζ := by
    unfold NmBracket.Xs XX; exact Finset.sum_congr rfl fun ν _ => sR_sq θ ζ ν
  have hS : NmBracket.Sb (sR θ ζ) = SS σ ζ := by
    unfold NmBracket.Sb SS
    exact Finset.sum_congr rfl fun ν _ => by
      rw [← sR_sq]; ring
  rw [hX, hS] at hK
  have e : dot w w = ∑ μ, wa (Real.sin (θ μ) ^ 2) (ζ μ) * u μ ^ 2 := by
    unfold dot
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [← w_sq_alias]; ring
  have hk : kplus σ ζ = max (NmBracket.llo (XX σ ζ) (BM σ ζ) (SS σ ζ) ^ 2)
      (NmBracket.lup (XX σ ζ) (SS σ ζ) ^ 2) := rfl
  rw [← dot_eq, ← dot_eq, ← Nm_eq, ← hk, e] at hK
  linarith

/-! ## The coefficient identity and (OS↑) -/

theorem coef_eq (σ : Fin 4 → ℝ) (hH : HH σ ≠ 0) (μ : Fin 4) :
    (1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹ =
      EE σ μ / (4 * omQ σ) := by
  unfold EE
  rw [omQ_eq, Finset.mul_sum, Finset.sum_div]
  refine Finset.sum_congr rfl fun ζ _ => ?_
  rw [wa_eq, omR_eq]
  field_simp

variable {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)

/-- **(OS↑)**: `𝓜(P/ω) ≼ P/ω` when every `E_ν ≤ 4`. -/
theorem os_up (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  intro q x
  set σ : Fin 4 → ℝ := fun ν => Real.sin (th q ν) ^ 2 with hσ_def
  have hσ : ∀ ν, 0 ≤ σ ν ∧ σ ν ≤ 1 := fun ν => sigma_mem (th q ν)
  set u := proj (sQ (th q)) (WithLp.ofLp x) with hu_def
  rw [Mfam_inner]
  have hterm : ∀ ζ : Fin 4 → Bool,
      ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫ ≤
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by
    intro ζ
    rw [LinearMap.smul_apply, real_inner_smul_right, omF_alias th rq hrq, inner_coord]
    unfold Pfam
    rw [hrq, sQ_thR, toE_apply, toE_apply, WithLp.ofLp_toLp, WithLp.ofLp_toLp, AtM_mulVec,
      projM_mulVec]
    have hinv : 0 ≤ (omR σ ζ)⁻¹ := by
      apply inv_nonneg.mpr
      unfold omR
      exact Finset.sum_nonneg fun x _ => by
        have := (xa_mem (hσ x).1 (hσ x).2 (ζ x)).1; linarith
    exact mul_le_mul_of_nonneg_left (alias_term_le_kplus (th q) (WithLp.ofLp x) ζ) hinv
  have hsum := Finset.sum_le_sum fun ζ (_ : ζ ∈ (univ : Finset (Fin 4 → Bool))) => hterm ζ
  have hω' : 0 < omQ σ := by rw [← omF_eq]; exact hω q
  have hH : HH σ ≠ 0 := by rw [omQ_eq] at hω'; intro h; rw [h] at hω'; simp at hω'
  have hreorg : (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
      (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) =
      ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) *
        u μ ^ 2 := by
    rw [Finset.mul_sum]
    have e1 : ∀ ζ : Fin 4 → Bool, (1 / 16 : ℝ) * ((omR σ ζ)⁻¹ *
        (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2)) =
        ∑ μ, (1 / 4) * (wa (σ μ) (ζ μ) * kplus σ ζ * (omR σ ζ)⁻¹) * u μ ^ 2 := by
      intro ζ
      rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl fun μ _ => ?_
      ring
    simp_rw [e1]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun μ _ => ?_
    rw [Finset.mul_sum, Finset.sum_mul]
  have hbound : ∑ μ, ((1 / 4) * ∑ ζ : Fin 4 → Bool, wa (σ μ) (ζ μ) * kplus σ ζ *
      (omR σ ζ)⁻¹) * u μ ^ 2 ≤ ∑ μ, (omQ σ)⁻¹ * u μ ^ 2 := by
    refine Finset.sum_le_sum fun μ _ => mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)
    rw [coef_eq σ hH μ]
    have h4 : 0 < 4 * omQ σ := by linarith
    rw [div_le_iff₀ h4]
    have := hEE q μ
    have e : (omQ σ)⁻¹ * (4 * omQ σ) = 4 := by field_simp
    linarith
  have hRHS : ⟪x, (fun q => (omF th q)⁻¹ • Pfam th q) q x⟫ =
      (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by
    simp only [LinearMap.smul_apply, real_inner_smul_right]
    rw [omF_eq, inner_coord]
    unfold Pfam
    rw [toE_apply, WithLp.ofLp_toLp, projM_mulVec, ← hu_def, ← dot_proj_self]
    unfold dot
    have : ∑ i, u i * u i = ∑ μ, u μ ^ 2 := Finset.sum_congr rfl fun i _ => by ring
    rw [this]
  rw [hRHS]
  calc (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool, ⟪Matrix.toEuclideanLin (AtM (th q) ζ) x,
        ((omF th (rq q ζ))⁻¹ • Pfam th (rq q ζ)) (Matrix.toEuclideanLin (AtM (th q) ζ) x)⟫
      ≤ (1 / 16 : ℝ) * ∑ ζ : Fin 4 → Bool,
          (omR σ ζ)⁻¹ * (4 * kplus σ ζ * ∑ μ, wa (σ μ) (ζ μ) * u μ ^ 2) := by gcongr
    _ = _ := hreorg
    _ ≤ _ := hbound
    _ = (omQ σ)⁻¹ * ∑ μ, u μ ^ 2 := by rw [Finset.mul_sum]

/-- `Adm` of (same text). -/
def Adm (s : Fin 4 → ℝ) : Prop := ∀ μ, 0 ≤ s μ ∧ s μ ≤ 1/2

theorem sin_sq_le_half {x : ℝ} (hx : |x| ≤ π / 4) : Real.sin x ^ 2 ≤ 1 / 2 := by
  have h := abs_le.mp hx
  have hc : 0 ≤ Real.cos (2 * x) :=
    Real.cos_nonneg_of_mem_Icc ⟨by linarith [Real.pi_pos], by linarith [Real.pi_pos]⟩
  have e : Real.sin x ^ 2 = 1 / 2 - Real.cos (2 * x) / 2 := by
    rw [Real.sin_sq, Real.cos_sq x]; ring
  rw [e]; linarith

/-- **(OS↑) with the free-stage input as a hypothesis in the exact form of 
`FreeStageOS.E_lt_four_s`** (`hE`), for momenta with `|θ_ν| ≤ π/4` (i.e. `|q_ν| ≤ π`). -/
theorem os_up_of_free (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q)
    (hth : ∀ q ν, |th q ν| ≤ π / 4)
    (hE : ∀ {s : Fin 4 → ℝ}, Adm s → (∃ μ, 0 < s μ) → ∀ ν, EE s ν < 4) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  refine os_up th rq hrq hω fun q ν => le_of_lt (hE ?_ ?_ ν)
  · intro μ; exact ⟨sq_nonneg _, sin_sq_le_half (hth q μ)⟩
  · by_contra hne
    push_neg at hne
    have hz : ∀ μ, Real.sin (th q μ) = 0 := fun μ => by
      have := hne μ
      have h0 : Real.sin (th q μ) ^ 2 = 0 := le_antisymm this (sq_nonneg _)
      exact pow_eq_zero_iff (two_ne_zero) |>.mp h0
    have h0 : omF th q = 0 := by
      unfold omF sQ
      refine Finset.sum_eq_zero fun μ _ => ?_
      rw [Real.sin_two_mul, hz μ]; ring
    linarith [hω q]

open Filter Topology in
/-- **`transient_zero_concrete`**: with (OS↑) from `E_ν ≤ 4`, a Loewner-monotone `Ξ` along the
concrete stages decreases to its limit: `δ_k ≥ 0`, every transient term vanishes (`D₀ = 0`). -/
theorem transient_zero_concrete (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ)
    (hω : ∀ q, 0 < omF th q)
    (hEE : ∀ q ν, EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4)
    (Ξ : (Q → V →ₗ[ℝ] V) → ℝ) (hmono : ∀ A B, UniformBracket.Lw A B → Ξ A ≤ Ξ B) {binf : ℝ}
    (hlim : Tendsto (fun k => Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)))
      atTop (𝓝 binf)) (k : ℕ) :
    binf ≤ Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) ∧
      max (-(Ξ ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q)) - binf)) 0 = 0 :=
  CouplingLimit.transient_zero (Mfam th rq) (Mfam_orderPreserving th rq)
    (os_up th rq hrq hω hEE) Ξ hmono hlim k

end OSUpBridge

-- ===== verbatim copy of an earlier file (without import and #print axioms) =====

/-!
# (OS↑) for the stage-0 free field: stages 2 and 3 

`G3(X) = U3(X)²/X = 1/X - 1 + 7X/16 - 3X²/32 + 9X³/1024` (for `X ≠ 0`).
With `c = (c_ν, c_1, c_2, c_3)`, `y_μ = c_μ/2`:
`E3_ν / H = Σ_{e=±} ((1 - e c_ν)/2) Σ_{ε ∈ {±}³} G3(2 + e c_ν/2 + ε·y)`.

* stage 3: at the smoothed point `c = (c_ν, t, t, t)`, `H·F < 4` unless `c = (1,1,1,1)`;
  the numerator `N(u,v)`, `u = 1 - c_ν`, `v = 1 - t`, has nonnegative Bernstein coefficients.
* stage 2: for fixed `c_ν` and `|c_o|`, the smoothed point is the maximum of `F`.
-/

noncomputable section
namespace FreeStageOS

/-- `G3(X) = U3(X)²/X` written out (equal for `X ≠ 0`) -/
def G3 (X : ℝ) : ℝ := X⁻¹ - 1 + 7/16*X - 3/32*X^2 + 9/1024*X^3

/-- `F` at the smoothed point `c = (c0, t, t, t)` -/
def Feq (c0 t : ℝ) : ℝ :=
  (1 - c0)/2 * (G3 (2 + c0/2 - 3*t/2) + 3*G3 (2 + c0/2 - t/2) + 3*G3 (2 + c0/2 + t/2)
      + G3 (2 + c0/2 + 3*t/2))
  + (1 + c0)/2 * (G3 (2 - c0/2 - 3*t/2) + 3*G3 (2 - c0/2 - t/2) + 3*G3 (2 - c0/2 + t/2)
      + G3 (2 - c0/2 + 3*t/2))

/-- the product of the eight denominators -/
def DD (c0 t : ℝ) : ℝ :=
  (2 + c0/2 - 3*t/2) * (2 + c0/2 - t/2) * (2 + c0/2 + t/2) * (2 + c0/2 + 3*t/2)
  * (2 - c0/2 - 3*t/2) * (2 - c0/2 - t/2) * (2 - c0/2 + t/2) * (2 - c0/2 + 3*t/2)
/-! ## (OS↑) stage 3: Bernstein form of the numerator at the smoothed point 

`N(u,v) = Σ_k C(14,k) u^k (1-u)^(14-k) p_k(v)`, and every `p_k` has nonnegative
Bernstein coefficients of degree 12 on `[0,1]`.
-/

/-- the coefficient of `u^0` in `N(u,v)` -/
def nr0 (v : ℝ) : ℝ :=
    (1053/32)*v^2 + (161325/256)*v^3 + (-28215/64)*v^4 + (-3235653/4096)*v^5 + (9880731/8192)*v^6
    + (-5767011/8192)*v^7 + (1681425/8192)*v^8 + (-781245/65536)*v^9 + (-1623969/131072)*v^10
    + (242757/65536)*v^11 + (-80919/262144)*v^12
/-- the coefficient of `u^1` in `N(u,v)` -/
def nr1 (v : ℝ) : ℝ :=
    (2655/16)*v + (325317/256)*v^2 + (-267453/256)*v^3 + (-5591859/4096)*v^4 + (1464309/512)*v^5
    + (-18506667/8192)*v^6 + (7873605/8192)*v^7 + (-14838471/65536)*v^8 + (727785/32768)*v^9
    + (287469/65536)*v^10 + (-59049/32768)*v^11 + (19683/131072)*v^12
/-- the coefficient of `u^2` in `N(u,v)` -/
def nr2 (v : ℝ) : ℝ :=
    (7797/32) + (253391/256)*v + (-597071/256)*v^2 + (3288575/2048)*v^3 + (6300967/8192)*v^4
    + (-16604091/8192)*v^5 + (12888969/8192)*v^6 + (-10711251/16384)*v^7 + (19775637/131072)*v^8
    + (-1077705/65536)*v^9 + (-217485/131072)*v^10 + (59049/65536)*v^11 + (-19683/262144)*v^12
/-- the coefficient of `u^3` in `N(u,v)` -/
def nr3 (v : ℝ) : ℝ :=
    (7871/256) + (-388059/256)*v + (4292405/2048)*v^2 + (-1309819/1024)*v^3 + (-80971/8192)*v^4
    + (4697469/8192)*v^5 + (-7114233/16384)*v^6 + (1398897/8192)*v^7 + (-2448657/65536)*v^8
    + (10935/2048)*v^9 + (-2187/4096)*v^10
/-- the coefficient of `u^4` in `N(u,v)` -/
def nr4 (v : ℝ) : ℝ :=
    (-91549/256) + (3870295/4096)*v + (-8553431/8192)*v^2 + (4775071/8192)*v^3 + (-834013/8192)*v^4
    + (-3661551/32768)*v^5 + (6303987/65536)*v^6 + (-1299267/32768)*v^7 + (2349027/262144)*v^8
    + (-10935/8192)*v^9 + (2187/16384)*v^10
/-- the coefficient of `u^5` in `N(u,v)` -/
def nr5 (v : ℝ) : ℝ :=
    (883129/4096) + (-360371/1024)*v + (2780247/8192)*v^2 + (-1501321/8192)*v^3
    + (2433667/32768)*v^4 + (-363393/16384)*v^5 + (260613/32768)*v^6 + (-29889/16384)*v^7
    + (29889/131072)*v^8
/-- the coefficient of `u^6` in `N(u,v)` -/
def nr6 (v : ℝ) : ℝ :=
    (-283595/8192) + (508671/8192)*v + (-616485/8192)*v^2 + (836949/16384)*v^3
    + (-1440051/65536)*v^4 + (208827/32768)*v^5 + (-116103/65536)*v^6 + (9963/32768)*v^7
    + (-9963/262144)*v^8
/-- the coefficient of `u^7` in `N(u,v)` -/
def nr7 (v : ℝ) : ℝ :=
    (-53473/8192) + (44615/8192)*v + (64287/16384)*v^2 + (-66979/8192)*v^3 + (129619/32768)*v^4
    + (-2349/2048)*v^5 + (783/4096)*v^6
/-- the coefficient of `u^8` in `N(u,v)` -/
def nr8 (v : ℝ) : ℝ :=
    (4573/1024) + (-332141/65536)*v + (274539/131072)*v^2 + (41329/65536)*v^3
    + (-103969/262144)*v^4 + (2349/16384)*v^5 + (-783/32768)*v^6
/-- the coefficient of `u^9` in `N(u,v)` -/
def nr9 (v : ℝ) : ℝ :=
    (-75223/65536) + (49505/32768)*v + (-58055/65536)*v^2 + (4275/32768)*v^3 + (-4275/131072)*v^4
/-- the coefficient of `u^10` in `N(u,v)` -/
def nr10 (v : ℝ) : ℝ :=
    (9505/131072) + (-11485/65536)*v + (13195/131072)*v^2 + (-855/65536)*v^3 + (855/262144)*v^4
/-- the coefficient of `u^11` in `N(u,v)` -/
def nr11 (v : ℝ) : ℝ :=
    (1083/65536) + (27/4096)*v + (-27/8192)*v^2
/-- the coefficient of `u^12` in `N(u,v)` -/
def nr12 (v : ℝ) : ℝ :=
    (-907/262144) + (-9/16384)*v + (9/32768)*v^2
/-- the coefficient of `u^13` in `N(u,v)` -/
def nr13 (v : ℝ) : ℝ :=
    (63/131072)
/-- the coefficient of `u^14` in `N(u,v)` -/
def nr14 (v : ℝ) : ℝ :=
    (-9/262144)
/-- the numerator `N(u,v)` in the power basis of `u` -/
def NN (u v : ℝ) : ℝ :=
    u^0*nr0 v + u^1*nr1 v + u^2*nr2 v + u^3*nr3 v + u^4*nr4 v + u^5*nr5 v + u^6*nr6 v + u^7*nr7 v + u^8*nr8 v + u^9*nr9 v + u^10*nr10 v + u^11*nr11 v + u^12*nr12 v + u^13*nr13 v + u^14*nr14 v
def pp0 (v : ℝ) : ℝ :=
    1*nr0 v
def pp1 (v : ℝ) : ℝ :=
    1*nr0 v + (1/14)*nr1 v
def pp2 (v : ℝ) : ℝ :=
    1*nr0 v + (1/7)*nr1 v + (1/91)*nr2 v
def pp3 (v : ℝ) : ℝ :=
    1*nr0 v + (3/14)*nr1 v + (3/91)*nr2 v + (1/364)*nr3 v
def pp4 (v : ℝ) : ℝ :=
    1*nr0 v + (2/7)*nr1 v + (6/91)*nr2 v + (1/91)*nr3 v + (1/1001)*nr4 v
def pp5 (v : ℝ) : ℝ :=
    1*nr0 v + (5/14)*nr1 v + (10/91)*nr2 v + (5/182)*nr3 v + (5/1001)*nr4 v + (1/2002)*nr5 v
def pp6 (v : ℝ) : ℝ :=
    1*nr0 v + (3/7)*nr1 v + (15/91)*nr2 v + (5/91)*nr3 v + (15/1001)*nr4 v + (3/1001)*nr5 v + (1/3003)*nr6 v
def pp7 (v : ℝ) : ℝ :=
    1*nr0 v + (1/2)*nr1 v + (3/13)*nr2 v + (5/52)*nr3 v + (5/143)*nr4 v + (3/286)*nr5 v + (1/429)*nr6 v + (1/3432)*nr7 v
def pp8 (v : ℝ) : ℝ :=
    1*nr0 v + (4/7)*nr1 v + (4/13)*nr2 v + (2/13)*nr3 v + (10/143)*nr4 v + (4/143)*nr5 v + (4/429)*nr6 v + (1/429)*nr7 v + (1/3003)*nr8 v
def pp9 (v : ℝ) : ℝ :=
    1*nr0 v + (9/14)*nr1 v + (36/91)*nr2 v + (3/13)*nr3 v + (18/143)*nr4 v + (9/143)*nr5 v + (4/143)*nr6 v + (3/286)*nr7 v + (3/1001)*nr8 v + (1/2002)*nr9 v
def pp10 (v : ℝ) : ℝ :=
    1*nr0 v + (5/7)*nr1 v + (45/91)*nr2 v + (30/91)*nr3 v + (30/143)*nr4 v + (18/143)*nr5 v + (10/143)*nr6 v + (5/143)*nr7 v + (15/1001)*nr8 v + (5/1001)*nr9 v + (1/1001)*nr10 v
def pp11 (v : ℝ) : ℝ :=
    1*nr0 v + (11/14)*nr1 v + (55/91)*nr2 v + (165/364)*nr3 v + (30/91)*nr4 v + (3/13)*nr5 v + (2/13)*nr6 v + (5/52)*nr7 v + (5/91)*nr8 v + (5/182)*nr9 v + (1/91)*nr10 v + (1/364)*nr11 v
def pp12 (v : ℝ) : ℝ :=
    1*nr0 v + (6/7)*nr1 v + (66/91)*nr2 v + (55/91)*nr3 v + (45/91)*nr4 v + (36/91)*nr5 v + (4/13)*nr6 v + (3/13)*nr7 v + (15/91)*nr8 v + (10/91)*nr9 v + (6/91)*nr10 v + (3/91)*nr11 v + (1/91)*nr12 v
def pp13 (v : ℝ) : ℝ :=
    1*nr0 v + (13/14)*nr1 v + (6/7)*nr2 v + (11/14)*nr3 v + (5/7)*nr4 v + (9/14)*nr5 v + (4/7)*nr6 v + (1/2)*nr7 v + (3/7)*nr8 v + (5/14)*nr9 v + (2/7)*nr10 v + (3/14)*nr11 v + (1/7)*nr12 v + (1/14)*nr13 v
def pp14 (v : ℝ) : ℝ :=
    1*nr0 v + 1*nr1 v + 1*nr2 v + 1*nr3 v + 1*nr4 v + 1*nr5 v + 1*nr6 v + 1*nr7 v + 1*nr8 v + 1*nr9 v + 1*nr10 v + 1*nr11 v + 1*nr12 v + 1*nr13 v + 1*nr14 v

theorem NN_bern (u v w : ℝ) (hw : w = 1 - u) :
    NN u v = 1*u^0*w^14*pp0 v
    + 14*u^1*w^13*pp1 v
    + 91*u^2*w^12*pp2 v
    + 364*u^3*w^11*pp3 v
    + 1001*u^4*w^10*pp4 v
    + 2002*u^5*w^9*pp5 v
    + 3003*u^6*w^8*pp6 v
    + 3432*u^7*w^7*pp7 v
    + 3003*u^8*w^6*pp8 v
    + 2002*u^9*w^5*pp9 v
    + 1001*u^10*w^4*pp10 v
    + 364*u^11*w^3*pp11 v
    + 91*u^12*w^2*pp12 v
    + 14*u^13*w^1*pp13 v
    + 1*u^14*w^0*pp14 v := by
  subst hw; unfold NN pp0 pp1 pp2 pp3 pp4 pp5 pp6 pp7 pp8 pp9 pp10 pp11 pp12 pp13 pp14; ring

theorem pp0_bern (v w : ℝ) (hw : w = 1 - v) :
    pp0 v = (1053/32)*v^2*w^10 + (245565/256)*v^3*w^9 + (1718145/256)*v^4*w^8 + (91415547/4096)*v^5*w^7
    + (353709909/8192)*v^6*w^6 + (433768365/8192)*v^7*w^5 + (348826905/8192)*v^8*w^4
    + (1470571875/65536)*v^9*w^3 + (979070625/131072)*v^10*w^2 + (93403125/65536)*v^11*w
    + (31134375/262144)*v^12 := by
  subst hw; unfold pp0 nr0; ring
theorem pp0_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp0 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp0_bern v w hwd]; positivity

theorem pp1_bern (v w : ℝ) (hw : w = 1 - v) :
    pp1 v = (2655/224)*v*w^11 + (910533/3584)*v^2*w^10 + (8760027/3584)*v^3*w^9 + (687134829/57344)*v^4*w^8
    + (970823685/28672)*v^5*w^7 + (6879531459/114688)*v^6*w^6 + (8008320441/114688)*v^7*w^5
    + (49895929641/917504)*v^8*w^4 + (1611594525/57344)*v^9*w^3 + (1061254905/114688)*v^10*w^2
    + (3148875/1792)*v^11*w + (1049625/7168)*v^12 := by
  subst hw; unfold pp1 nr0 nr1; ring
theorem pp1_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp1 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp1_bern v w hwd]; positivity

theorem pp2_bern (v w : ℝ) (hw : w = 1 - v) :
    pp2 v = (7797/2912)*w^12 + (1554143/23296)*v*w^11 + (17377391/23296)*v^2*w^10
    + (909068183/186368)*v^3*w^9 + (2064730723/106496)*v^4*w^8 + (36316474175/745472)*v^5*w^7
    + (288473581/3584)*v^6*w^6 + (1469913013/16384)*v^7*w^5 + (810789178903/11927552)*v^8*w^4
    + (919417355/26624)*v^9*w^3 + (4196922997/372736)*v^10*w^2 + (198391275/93184)*v^11*w
    + (66130425/372736)*v^12 := by
  subst hw; unfold pp2 nr0 nr1 nr2; ring
theorem pp2_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp2 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp2_bern v w hwd]; positivity

theorem pp3_bern (v w : ℝ) (hw : w = 1 - v) :
    pp3 v = (756383/93184)*w^12 + (15042669/93184)*v*w^11 + (156983819/106496)*v^2*w^10
    + (755132255/93184)*v^3*w^9 + (12144467207/425984)*v^4*w^8 + (197239974409/2981888)*v^5*w^7
    + (618850313065/5963776)*v^6*w^6 + (333358229287/2981888)*v^7*w^5
    + (1976029879567/23855104)*v^8*w^4 + (123714665135/2981888)*v^9*w^3
    + (80012946067/5963776)*v^10*w^2 + (942102495/372736)*v^11*w + (314034165/1490944)*v^12 := by
  subst hw; unfold pp3 nr0 nr1 nr2 nr3; ring
theorem pp3_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp3 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp3_bern v w hwd]; positivity

theorem pp4_bern (v w : ℝ) (hw : w = 1 - v) :
    pp4 v = (39537/2464)*w^12 + (13044133/45056)*v*w^11 + (19596568479/8200192)*v^2*w^10
    + (8892622793/745472)*v^3*w^9 + (1751143851/45056)*v^4*w^8 + (254448317703/2981888)*v^5*w^7
    + (1207358771859/9371648)*v^6*w^6 + (4434439444959/32800768)*v^7*w^5
    + (3689001238785/37486592)*v^8*w^4 + (1598184978855/32800768)*v^9*w^3
    + (146661655741/9371648)*v^10*w^2 + (12051044223/4100096)*v^11*w + (4017014741/16400384)*v^12 := by
  subst hw; unfold pp4 nr0 nr1 nr2 nr3 nr4; ring
theorem pp4_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp4 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp4_bern v w hwd]; positivity

theorem pp5_bern (v w : ℝ) (hw : w = 1 - v) :
    pp5 v = (30389327/1171456)*w^12 + (259027181/585728)*v*w^11 + (56341756893/16400384)*v^2*w^10
    + (264694512539/16400384)*v^3*w^9 + (3276505995951/65601536)*v^4*w^8
    + (1728958338543/16400384)*v^5*w^7 + (5073185233401/32800768)*v^6*w^6
    + (1302841881/8192)*v^7*w^5 + (7488373951257/65601536)*v^8*w^4 + (459173245625/8200192)*v^9*w^3
    + (293331676901/16400384)*v^10*w^2 + (858652107/256256)*v^11*w + (286217369/1025024)*v^12 := by
  subst hw; unfold pp5 nr0 nr1 nr2 nr3 nr4 nr5; ring
theorem pp5_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp5 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp5_bern v w hwd]; positivity

theorem pp6_bern (v w : ℝ) (hw : w = 1 - v) :
    pp6 v = (913376887/24600576)*w^12 + (714174733/1171456)*v*w^11 + (2331536267/512512)*v^2*w^10
    + (1009361223467/49201152)*v^3*w^9 + (4016894943053/65601536)*v^4*w^8
    + (2059485533551/16400384)*v^5*w^7 + (5913510576601/32800768)*v^6*w^6
    + (1496384654777/8200192)*v^7*w^5 + (653637280853/5046272)*v^8*w^4
    + (1551535199635/24600576)*v^9*w^3 + (328909913341/16400384)*v^10*w^2 + (73909823/19712)*v^11*w
    + (73909823/236544)*v^12 := by
  subst hw; unfold pp6 nr0 nr1 nr2 nr3 nr4 nr5 nr6; ring
theorem pp6_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp6 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp6_bern v w hwd]; positivity

theorem pp7_bern (v w : ℝ) (hw : w = 1 - v) :
    pp7 v = (124880909/2555904)*w^12 + (21970178147/28114944)*v*w^11 + (318799937549/56229888)*v^2*w^10
    + (698365192325/28114944)*v^3*w^9 + (738432379391/10223616)*v^4*w^8
    + (1019110914401/7028736)*v^5*w^7 + (2878356040811/14057472)*v^6*w^6
    + (89936865449/439296)*v^7*w^5 + (506261036393/3514368)*v^8*w^4 + (116027185/1664)*v^9*w^3
    + (5655761/256)*v^10*w^2 + (428859/104)*v^11*w + (142953/416)*v^12 := by
  subst hw; unfold pp7 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7; ring
theorem pp7_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp7 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp7_bern v w hwd]; positivity

theorem pp8_bern (v w : ℝ) (hw : w = 1 - v) :
    pp8 v = (1485576437/24600576)*w^12 + (26643026285/28114944)*v*w^11 + (378886566611/56229888)*v^2*w^10
    + (5690220823061/196804608)*v^3*w^9 + (64928477033989/787218432)*v^4*w^8
    + (728811943627/4472832)*v^5*w^7 + (1720024454975/7569408)*v^6*w^6
    + (692094053513/3075072)*v^7*w^5 + (3869296420169/24600576)*v^8*w^4
    + (9709192875/128128)*v^9*w^3 + (6135055119/256256)*v^10*w^2 + (35737641/8008)*v^11*w
    + (11912547/32032)*v^12 := by
  subst hw; unfold pp8 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8; ring
theorem pp8_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp8 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp8_bern v w hwd]; positivity

theorem pp9_bern (v w : ℝ) (hw : w = 1 - v) :
    pp9 v = (1331114775/18743296)*w^12 + (1638876289/1490944)*v*w^11 + (252661948503/32800768)*v^2*w^10
    + (20537032631/630784)*v^3*w^9 + (429136997349/4685824)*v^4*w^8
    + (733049588025/4100096)*v^5*w^7 + (2025317112723/8200192)*v^6*w^6
    + (15559297269/64064)*v^7*w^5 + (86531141205/512512)*v^8*w^4 + (185441535/2288)*v^9*w^3
    + (116916979/4576)*v^10*w^2 + (680358/143)*v^11*w + (113393/286)*v^12 := by
  subst hw; unfold pp9 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9; ring
theorem pp9_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp9 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp9_bern v w hwd]; positivity

theorem pp10_bern (v w : ℝ) (hw : w = 1 - v) :
    pp10 v = (10516351403/131203072)*w^12 + (1831616811/1490944)*v*w^11 + (279466446485/32800768)*v^2*w^10
    + (22472629763/630784)*v^3*w^9 + (3254054254271/32800768)*v^4*w^8
    + (787239665957/4100096)*v^5*w^7 + (2159955088439/8200192)*v^6*w^6
    + (16505166449/64064)*v^7*w^5 + (91431544913/512512)*v^8*w^4 + (195412275/2288)*v^9*w^3
    + (122997143/4576)*v^10*w^2 + (55014/11)*v^11*w + (9169/22)*v^12 := by
  subst hw; unfold pp10 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10; ring
theorem pp10_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp10 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp10_bern v w hwd]; positivity

theorem pp11_bern (v w : ℝ) (hw : w = 1 - v) :
    pp11 v = (160240443/1835008)*w^12 + (566346147/425984)*v*w^11 + (54603803941/5963776)*v^2*w^10
    + (1089674823/28672)*v^3*w^9 + (156694083355/1490944)*v^4*w^8 + (2355100381/11648)*v^5*w^7
    + (6430352095/23296)*v^6*w^6 + (97905233/364)*v^7*w^5 + (540847313/2912)*v^8*w^4
    + (1153700/13)*v^9*w^3 + (362650/13)*v^10*w^2 + (67440/13)*v^11*w + (5620/13)*v^12 := by
  subst hw; unfold pp11 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11; ring
theorem pp11_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp11 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp11_bern v w hwd]; positivity

theorem pp12_bern (v w : ℝ) (hw : w = 1 - v) :
    pp12 v = (169208321/1835008)*w^12 + (595606025/425984)*v*w^11 + (57177140431/5963776)*v^2*w^10
    + (1135871053/28672)*v^3*w^9 + (162634617961/1490944)*v^4*w^8 + (2435237167/11648)*v^5*w^7
    + (6628844581/23296)*v^6*w^6 + (100687547/364)*v^7*w^5 + (555236411/2912)*v^8*w^4
    + (1182940/13)*v^9*w^3 + (371558/13)*v^10*w^2 + (69072/13)*v^11*w + (5756/13)*v^12 := by
  subst hw; unfold pp12 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12; ring
theorem pp12_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp12 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp12_bern v w hwd]; positivity

theorem pp13_bern (v w : ℝ) (hw : w = 1 - v) :
    pp13 v = (6203295/65536)*w^12 + (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10
    + (10347939/256)*v^3*w^9 + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7
    + (9241883/32)*v^6*w^6 + 280436*v^7*w^5 + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2
    + 5376*v^11*w + 448*v^12 := by
  subst hw; unfold pp13 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13; ring
theorem pp13_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp13 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp13_bern v w hwd]; positivity

theorem pp14_bern (v w : ℝ) (hw : w = 1 - v) :
    pp14 v = (6203295/65536)*w^12 + (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10
    + (10347939/256)*v^3*w^9 + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7
    + (9241883/32)*v^6*w^6 + 280436*v^7*w^5 + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2
    + 5376*v^11*w + 448*v^12 := by
  subst hw; unfold pp14 nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13 nr14; ring
theorem pp14_nonneg {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 ≤ pp14 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp14_bern v w hwd]; positivity

theorem pp0_pos {v : ℝ} (hv0 : 0 < v) (hv1 : v ≤ 1) : 0 < pp0 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp0_bern v w hwd]
  have h1 : 0 < (31134375/262144)*v^12 := by positivity
  have h2 : 0 ≤ (1053/32)*v^2*w^10 + (245565/256)*v^3*w^9 + (1718145/256)*v^4*w^8 + (91415547/4096)*v^5*w^7
    + (353709909/8192)*v^6*w^6 + (433768365/8192)*v^7*w^5 + (348826905/8192)*v^8*w^4
    + (1470571875/65536)*v^9*w^3 + (979070625/131072)*v^10*w^2 + (93403125/65536)*v^11*w := by positivity
  linarith
theorem pp14_pos {v : ℝ} (hv0 : 0 ≤ v) (hv1 : v ≤ 1) : 0 < pp14 v := by
  set w := 1 - v with hwd
  have hw : 0 ≤ w := by linarith
  rw [pp14_bern v w hwd]
  have h2 : 0 ≤ (11735307/8192)*v*w^11 + (160614859/16384)*v^2*w^10 + (10347939/256)*v^3*w^9
    + (113739619/1024)*v^4*w^8 + (3400145/16)*v^5*w^7 + (9241883/32)*v^6*w^6 + 280436*v^7*w^5
    + (386285/2)*v^8*w^4 + 92120*v^9*w^3 + 28924*v^10*w^2 + 5376*v^11*w := by positivity
  have h3 : 0 < (6203295/65536)*w^12 + 448*v^12 := by
    rcases eq_or_lt_of_le hv0 with h | h
    · have : w = 1 := by rw [hwd, ← h]; ring
      rw [this, ← h]; norm_num
    · have : 0 < v^12 := by positivity
      have : 0 ≤ w^12 := by positivity
      linarith
  linarith
/-- `(4 - H·F)·D = N(1 - c0, 1 - t)` at the smoothed point -/
theorem NN_eq (c0 t : ℝ) (h0 : (2 + c0/2 - 3*t/2) ≠ 0) (h1 : (2 + c0/2 - t/2) ≠ 0) (h2 : (2 + c0/2 + t/2) ≠ 0) (h3 : (2 + c0/2 + 3*t/2) ≠ 0) (h4 : (2 - c0/2 - 3*t/2) ≠ 0) (h5 : (2 - c0/2 - t/2) ≠ 0) (h6 : (2 - c0/2 + t/2) ≠ 0) (h7 : (2 - c0/2 + 3*t/2) ≠ 0) :
    (4 - (4 - c0^2 - 3*t^2) * Feq c0 t) * DD c0 t = NN (1 - c0) (1 - t) := by
  have e0 : (2 + c0/2 - 3*t/2) * (2 + c0/2 - 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h0
  have e1 : (2 + c0/2 - t/2) * (2 + c0/2 - t/2)⁻¹ = 1 := mul_inv_cancel₀ h1
  have e2 : (2 + c0/2 + t/2) * (2 + c0/2 + t/2)⁻¹ = 1 := mul_inv_cancel₀ h2
  have e3 : (2 + c0/2 + 3*t/2) * (2 + c0/2 + 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h3
  have e4 : (2 - c0/2 - 3*t/2) * (2 - c0/2 - 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h4
  have e5 : (2 - c0/2 - t/2) * (2 - c0/2 - t/2)⁻¹ = 1 := mul_inv_cancel₀ h5
  have e6 : (2 - c0/2 + t/2) * (2 - c0/2 + t/2)⁻¹ = 1 := mul_inv_cancel₀ h6
  have e7 : (2 - c0/2 + 3*t/2) * (2 - c0/2 + 3*t/2)⁻¹ = 1 := mul_inv_cancel₀ h7
  unfold Feq G3 DD NN nr0 nr1 nr2 nr3 nr4 nr5 nr6 nr7 nr8 nr9 nr10 nr11 nr12 nr13 nr14
  linear_combination (-(4 - c0^2 - 3*t^2)) * ((1 - c0)/2*((2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e0 + (1 - c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e1 + (1 - c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e2 + (1 - c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e3 + (1 + c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e4 + (1 + c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 + t/2)*(2 - c0/2 + 3*t/2))*e5 + (1 + c0)/2*3*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + 3*t/2))*e6 + (1 + c0)/2*((2 + c0/2 - 3*t/2)*(2 + c0/2 - t/2)*(2 + c0/2 + t/2)*(2 + c0/2 + 3*t/2)*(2 - c0/2 - 3*t/2)*(2 - c0/2 - t/2)*(2 - c0/2 + t/2))*e7)

theorem NN_pos {u v : ℝ} (hu0 : 0 ≤ u) (hu1 : u ≤ 1) (hv0 : 0 ≤ v) (hv1 : v ≤ 1)
    (hne : 0 < u + v) : 0 < NN u v := by
  have hw : 0 ≤ 1 - u := by linarith
  rw [NN_bern u v (1 - u) rfl]
  have t0 : 0 ≤ 1*u^0*(1-u)^14*pp0 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp0_nonneg hv0 hv1)
  have t1 : 0 ≤ 14*u^1*(1-u)^13*pp1 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp1_nonneg hv0 hv1)
  have t2 : 0 ≤ 91*u^2*(1-u)^12*pp2 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp2_nonneg hv0 hv1)
  have t3 : 0 ≤ 364*u^3*(1-u)^11*pp3 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp3_nonneg hv0 hv1)
  have t4 : 0 ≤ 1001*u^4*(1-u)^10*pp4 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp4_nonneg hv0 hv1)
  have t5 : 0 ≤ 2002*u^5*(1-u)^9*pp5 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp5_nonneg hv0 hv1)
  have t6 : 0 ≤ 3003*u^6*(1-u)^8*pp6 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp6_nonneg hv0 hv1)
  have t7 : 0 ≤ 3432*u^7*(1-u)^7*pp7 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp7_nonneg hv0 hv1)
  have t8 : 0 ≤ 3003*u^8*(1-u)^6*pp8 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp8_nonneg hv0 hv1)
  have t9 : 0 ≤ 2002*u^9*(1-u)^5*pp9 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp9_nonneg hv0 hv1)
  have t10 : 0 ≤ 1001*u^10*(1-u)^4*pp10 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp10_nonneg hv0 hv1)
  have t11 : 0 ≤ 364*u^11*(1-u)^3*pp11 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp11_nonneg hv0 hv1)
  have t12 : 0 ≤ 91*u^12*(1-u)^2*pp12 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp12_nonneg hv0 hv1)
  have t13 : 0 ≤ 14*u^13*(1-u)^1*pp13 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp13_nonneg hv0 hv1)
  have t14 : 0 ≤ 1*u^14*(1-u)^0*pp14 v :=
    mul_nonneg (mul_nonneg (mul_nonneg (by norm_num) (pow_nonneg hu0 _)) (pow_nonneg hw _)) (pp14_nonneg hv0 hv1)
  rcases eq_or_lt_of_le hu0 with h | h
  · have hv : 0 < v := by linarith
    have hw1 : 0 < 1 - u := by linarith
    have s0 : 0 < 1*u^0*(1-u)^14*pp0 v :=
      mul_pos (mul_pos (by norm_num) (pow_pos hw1 _)) (pp0_pos hv hv1)
    linarith
  · have s14 : 0 < 1*u^14*(1-u)^0*pp14 v :=
      mul_pos (mul_pos (mul_pos (by norm_num) (pow_pos h _)) (by norm_num)) (pp14_pos hv0 hv1)
    linarith

theorem DD_pos {c0 t : ℝ} (hX0 : 0 < (2 + c0/2 - 3*t/2)) (hX1 : 0 < (2 + c0/2 - t/2)) (hX2 : 0 < (2 + c0/2 + t/2)) (hX3 : 0 < (2 + c0/2 + 3*t/2)) (hX4 : 0 < (2 - c0/2 - 3*t/2)) (hX5 : 0 < (2 - c0/2 - t/2)) (hX6 : 0 < (2 - c0/2 + t/2)) (hX7 : 0 < (2 - c0/2 + 3*t/2)) : 0 < DD c0 t := by
  unfold DD
  exact mul_pos (mul_pos (mul_pos (mul_pos (mul_pos (mul_pos (mul_pos hX0 hX1) hX2) hX3) hX4) hX5) hX6) hX7

/-- **stage 3**: at the smoothed point, `H·F < 4` unless `c0 = t = 1` -/
theorem eq_lt_four {c0 t : ℝ} (hc0 : 0 ≤ c0) (hc1 : c0 ≤ 1) (ht0 : 0 ≤ t) (ht1 : t ≤ 1)
    (hne : c0 + 3*t < 4) : (4 - c0^2 - 3*t^2) * Feq c0 t < 4 := by

  have hX0 : 0 < (2 + c0/2 - 3*t/2) := by linarith
  have hX1 : 0 < (2 + c0/2 - t/2) := by linarith
  have hX2 : 0 < (2 + c0/2 + t/2) := by linarith
  have hX3 : 0 < (2 + c0/2 + 3*t/2) := by linarith
  have hX4 : 0 < (2 - c0/2 - 3*t/2) := by linarith
  have hX5 : 0 < (2 - c0/2 - t/2) := by linarith
  have hX6 : 0 < (2 - c0/2 + t/2) := by linarith
  have hX7 : 0 < (2 - c0/2 + 3*t/2) := by linarith
  have hD := DD_pos hX0 hX1 hX2 hX3 hX4 hX5 hX6 hX7
  have hN := NN_pos (u := 1 - c0) (v := 1 - t) (by linarith) (by linarith) (by linarith) (by linarith)
    (by linarith)
  have hE := NN_eq c0 t (ne_of_gt hX0) (ne_of_gt hX1) (ne_of_gt hX2) (ne_of_gt hX3)
    (ne_of_gt hX4) (ne_of_gt hX5) (ne_of_gt hX6) (ne_of_gt hX7)
  rw [← hE] at hN
  by_contra hc
  rw [not_lt] at hc
  nlinarith [hc, hD, hN]

/-! ## (OS↑) stage 2: smoothing `c_o` at fixed `c_ν` and `|c_o|` 

`Fo b y = Σ_{ε ∈ {±}³} G3(b + ε·y)` splits as `Inv b y + PP b |y|²`: the cubic part of `G3`
only sees `|y|²`.  The pair sum `PS B y1 y2 = Σ_{±,±} 1/(B ± y1 ± y2)` equals
`2B/(A - 2p) + 2B/(A + 2p)` with `A = B² - (y1² + y2²)`, `p = y1 y2`, so at fixed `y1² + y2²`
it increases with `p`.  Two such steps carry `(y1, y2, y3)` to `(m, m, m)`, `3m² = |y|²`.
-/

/-- the eight aliases with `e_ν` fixed -/
def Fo (b y1 y2 y3 : ℝ) : ℝ :=
  G3 (b + y1 + y2 + y3) + G3 (b + y1 + y2 - y3) + G3 (b + y1 - y2 + y3) + G3 (b + y1 - y2 - y3)
  + G3 (b - y1 + y2 + y3) + G3 (b - y1 + y2 - y3) + G3 (b - y1 - y2 + y3) + G3 (b - y1 - y2 - y3)

/-- the `1/X` part of `Fo` -/
def Inv (b y1 y2 y3 : ℝ) : ℝ :=
  (b + y1 + y2 + y3)⁻¹ + (b + y1 + y2 - y3)⁻¹ + (b + y1 - y2 + y3)⁻¹ + (b + y1 - y2 - y3)⁻¹
  + (b - y1 + y2 + y3)⁻¹ + (b - y1 + y2 - y3)⁻¹ + (b - y1 - y2 + y3)⁻¹ + (b - y1 - y2 - y3)⁻¹

/-- the cubic part of `Fo`, a function of `b` and `S = |y|²` only -/
def PP (b S : ℝ) : ℝ := 8*(-1 + 7/16*b - 3/32*b^2 + 9/1024*b^3) + 4*(-3/16 + 27/512*b)*S

/-- `F(c) = E3_ν/H` in the momentum form, `c = (c_ν, c_1, c_2, c_3)` -/
def FF (c0 c1 c2 c3 : ℝ) : ℝ :=
  (1 - c0)/2 * Fo (2 + c0/2) (c1/2) (c2/2) (c3/2) + (1 + c0)/2 * Fo (2 - c0/2) (c1/2) (c2/2) (c3/2)

/-- the pair sum -/
def PS (B y1 y2 : ℝ) : ℝ := (B + y1 + y2)⁻¹ + (B + y1 - y2)⁻¹ + (B - y1 + y2)⁻¹ + (B - y1 - y2)⁻¹

theorem Fo_split (b y1 y2 y3 : ℝ) : Fo b y1 y2 y3 = Inv b y1 y2 y3 + PP b (y1^2 + y2^2 + y3^2) := by
  unfold Fo Inv PP G3; ring

theorem FF_eq (c0 t : ℝ) : FF c0 t t t = Feq c0 t := by
  unfold FF Fo Feq G3; ring

theorem Inv_pair12 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = PS (b + y3) y1 y2 + PS (b - y3) y1 y2 := by
  unfold Inv PS; ring

theorem Inv_pair23 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = PS (b + y1) y2 y3 + PS (b - y1) y2 y3 := by
  unfold Inv PS; ring

theorem Inv_swap23 (b y1 y2 y3 : ℝ) : Inv b y1 y2 y3 = Inv b y1 y3 y2 := by
  unfold Inv; ring

theorem PS_closed {B y1 y2 : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hB : y1 + y2 < B) :
    PS B y1 y2 = 2*B/(B^2 - (y1^2 + y2^2) - 2*(y1*y2)) + 2*B/(B^2 - (y1^2 + y2^2) + 2*(y1*y2)) := by
  have h1 : 0 < B + y1 + y2 := by linarith
  have h2 : 0 < B + y1 - y2 := by linarith
  have h3 : 0 < B - y1 + y2 := by linarith
  have h4 : 0 < B - y1 - y2 := by linarith
  have d1 : B^2 - (y1^2 + y2^2) - 2*(y1*y2) = (B + y1 + y2) * (B - y1 - y2) := by ring
  have d2 : B^2 - (y1^2 + y2^2) + 2*(y1*y2) = (B + y1 - y2) * (B - y1 + y2) := by ring
  rw [d1, d2]
  unfold PS
  field_simp
  ring

theorem pair_mono {B A p p' : ℝ} (hB : 0 < B) (hp : 0 ≤ p) (hpp : p ≤ p') (hA : 2*p' < A) :
    2*B/(A - 2*p) + 2*B/(A + 2*p) ≤ 2*B/(A - 2*p') + 2*B/(A + 2*p') := by
  have a1 : 0 < A - 2*p := by linarith
  have a2 : 0 < A + 2*p := by linarith
  have a3 : 0 < A - 2*p' := by linarith
  have a4 : 0 < A + 2*p' := by linarith
  rw [div_add_div _ _ (ne_of_gt a1) (ne_of_gt a2), div_add_div _ _ (ne_of_gt a3) (ne_of_gt a4),
    div_le_div_iff₀ (mul_pos a1 a2) (mul_pos a3 a4)]
  have hBA : 0 ≤ B * A := by nlinarith
  have hq : 0 ≤ p'^2 - p^2 := by nlinarith
  nlinarith [mul_nonneg hBA hq]

theorem PS_le {B y1 y2 z1 z2 : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hz1 : 0 ≤ z1) (hz2 : 0 ≤ z2)
    (hS : y1^2 + y2^2 = z1^2 + z2^2) (hp : y1*y2 ≤ z1*z2) (hB : z1 + z2 < B) :
    PS B y1 y2 ≤ PS B z1 z2 := by
  have hsq : (y1 + y2)^2 ≤ (z1 + z2)^2 := by nlinarith
  have hyz : y1 + y2 ≤ z1 + z2 := (sq_le_sq₀ (by linarith) (by linarith)).mp hsq
  rw [PS_closed hy1 hy2 (by linarith), PS_closed hz1 hz2 hB, hS]
  exact pair_mono (by linarith) (mul_nonneg hy1 hy2) hp (by nlinarith)

/-- one smoothing: if `(y1² - m²)(y2² - m²) ≤ 0`, two pair steps reach `(m, m, m)` -/
theorem Inv_smooth_core {b y1 y2 y3 m : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hy3 : 0 ≤ y3)
    (hm0 : 0 ≤ m) (hm : 3*m^2 = y1^2 + y2^2 + y3^2) (hd : (y1^2 - m^2)*(y2^2 - m^2) ≤ 0)
    (hb : 3*m < b) : Inv b y1 y2 y3 ≤ Inv b m m m := by
  have hW : 0 ≤ y1^2 + y2^2 - m^2 := by
    by_contra hc
    rw [not_le] at hc
    have e1 : 0 < m^2 - y1^2 := by nlinarith
    have e2 : 0 < m^2 - y2^2 := by nlinarith
    nlinarith [mul_pos e1 e2]
  set w := Real.sqrt (y1^2 + y2^2 - m^2) with hwdef
  have hw0 : 0 ≤ w := Real.sqrt_nonneg _
  have hw2 : w^2 = y1^2 + y2^2 - m^2 := Real.sq_sqrt hW
  have hmw : y1*y2 ≤ m*w := by
    have : (y1*y2)^2 ≤ (m*w)^2 := by rw [mul_pow, mul_pow, hw2]; nlinarith
    exact (sq_le_sq₀ (mul_nonneg hy1 hy2) (mul_nonneg hm0 hw0)).mp this
  have hcs : y3 + m + w ≤ 3*m := by
    have : (y3 + m + w)^2 ≤ (3*m)^2 := by
      nlinarith [sq_nonneg (y3 - m), sq_nonneg (y3 - w), sq_nonneg (m - w)]
    exact (sq_le_sq₀ (by linarith) (by linarith)).mp this
  have step1 : Inv b y1 y2 y3 ≤ Inv b m w y3 := by
    rw [Inv_pair12, Inv_pair12 b m w y3]
    have hS : y1^2 + y2^2 = m^2 + w^2 := by rw [hw2]; ring
    exact add_le_add (PS_le hy1 hy2 hm0 hw0 hS hmw (by linarith))
      (PS_le hy1 hy2 hm0 hw0 hS hmw (by linarith))
  have step2 : Inv b m w y3 ≤ Inv b m m m := by
    rw [Inv_pair23, Inv_pair23 b m m m]
    have hS : w^2 + y3^2 = m^2 + m^2 := by rw [hw2]; linarith
    have hp : w*y3 ≤ m*m := by nlinarith [sq_nonneg (w - y3)]
    exact add_le_add (PS_le hw0 hy3 hm0 hm0 hS hp (by linarith))
      (PS_le hw0 hy3 hm0 hm0 hS hp (by linarith))
  exact le_trans step1 step2

theorem Inv_smooth {b y1 y2 y3 m : ℝ} (hy1 : 0 ≤ y1) (hy2 : 0 ≤ y2) (hy3 : 0 ≤ y3)
    (hm0 : 0 ≤ m) (hm : 3*m^2 = y1^2 + y2^2 + y3^2) (hb : 3*m < b) :
    Inv b y1 y2 y3 ≤ Inv b m m m := by
  by_cases hd : (y1^2 - m^2)*(y2^2 - m^2) ≤ 0
  · exact Inv_smooth_core hy1 hy2 hy3 hm0 hm hd hb
  · rw [not_le] at hd
    have hd' : (y1^2 - m^2)*(y3^2 - m^2) ≤ 0 := by
      have : y3^2 - m^2 = -((y1^2 - m^2) + (y2^2 - m^2)) := by linarith
      rw [this]; nlinarith [sq_nonneg (y1^2 - m^2)]
    rw [Inv_swap23]
    exact Inv_smooth_core hy1 hy3 hy2 hm0 (by linarith) hd' hb

/-- **stage 2**: at fixed `c0` and `c1² + c2² + c3² = 3t²`, the smoothed point is the maximum -/
theorem FF_smooth {c0 c1 c2 c3 t : ℝ} (hc0 : 0 ≤ c0) (hc0' : c0 ≤ 1) (hc1 : 0 ≤ c1) (hc2 : 0 ≤ c2)
    (hc3 : 0 ≤ c3) (ht0 : 0 ≤ t) (ht : 3*t^2 = c1^2 + c2^2 + c3^2) (hne : c0 + 3*t < 4) :
    FF c0 c1 c2 c3 ≤ FF c0 t t t := by
  unfold FF
  simp only [Fo_split]
  have hS : (c1/2)^2 + (c2/2)^2 + (c3/2)^2 = (t/2)^2 + (t/2)^2 + (t/2)^2 := by nlinarith
  rw [hS]
  have hm : 3*(t/2)^2 = (c1/2)^2 + (c2/2)^2 + (c3/2)^2 := by nlinarith
  have i1 := Inv_smooth (b := 2 + c0/2) (by linarith) (by linarith) (by linarith) (by linarith) hm
    (by linarith)
  have i2 := Inv_smooth (b := 2 - c0/2) (by linarith) (by linarith) (by linarith) (by linarith) hm
    (by linarith)
  have w1 : 0 ≤ (1 - c0)/2 := by linarith
  have w2 : 0 ≤ (1 + c0)/2 := by linarith
  nlinarith [mul_le_mul_of_nonneg_left i1 w1, mul_le_mul_of_nonneg_left i2 w2]

end FreeStageOS

/-! ## Stage 1 (copied from an earlier file `TauStageZero`, only the parts used by `EE_le_E3`) -/

namespace TauStageZero

open Finset

def llo (X bm sb : ℝ) : ℝ := 1 - 1/2*((1 - 5/24*X)*X + 5/24*(X*bm + sb))
def lup (X sb : ℝ) : ℝ := min (1 - 7/24*X) (1 - (X - X^2/4 + sb/4)/2)

theorem sum_cons_bool {n : ℕ} (F : (Fin (n+1) → Bool) → ℝ) :
    ∑ e, F e = ∑ y, F (Fin.cons true y) + ∑ y, F (Fin.cons false y) := by
  rw [← (Fin.consEquiv (fun _ => Bool)).sum_comp]
  simp [Fintype.sum_prod_type]
  rfl

theorem sum0_bool (F : (Fin 0 → Bool) → ℝ) : ∑ e, F e = F ![] := by
  rw [Fintype.sum_unique]; congr 1

theorem sum16 (F : (Fin 4 → Bool) → ℝ) : ∑ e, F e =
    F ![true,true,true,true] + F ![true,true,true,false] + F ![true,true,false,true]
    + F ![true,true,false,false] + F ![true,false,true,true] + F ![true,false,true,false]
    + F ![true,false,false,true] + F ![true,false,false,false] + F ![false,true,true,true]
    + F ![false,true,true,false] + F ![false,true,false,true] + F ![false,true,false,false]
    + F ![false,false,true,true] + F ![false,false,true,false] + F ![false,false,false,true]
    + F ![false,false,false,false] := by
  simp only [sum_cons_bool, sum0_bool, add_assoc]
  rfl

def Adm (s : Fin 4 → ℝ) : Prop := ∀ μ, 0 ≤ s μ ∧ s μ ≤ 1/2
def bb (s : Fin 4 → ℝ) (e : Fin 4 → Bool) (μ : Fin 4) : ℝ := if e μ then 1 - s μ else s μ
def XX (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, bb s e μ
def SS (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := ∑ μ, (bb s e μ)^2
def BM (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ :=
  max (max (bb s e 0) (bb s e 1)) (max (bb s e 2) (bb s e 3))
def HH (s : Fin 4 → ℝ) : ℝ := 4 * ∑ μ, s μ * (1 - s μ)
def lamLo (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := llo (XX s e) (BM s e) (SS s e)
def lamUp (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := lup (XX s e) (SS s e)
def kplus (s : Fin 4 → ℝ) (e : Fin 4 → Bool) : ℝ := max ((lamLo s e)^2) ((lamUp s e)^2)

theorem llo_le_lup {X bm S2 : ℝ} (hX0 : 0 ≤ X) (hX4 : X ≤ 4)
    (hS1 : X^2/4 ≤ S2) (hS2 : S2 ≤ X*bm) : llo X bm S2 ≤ lup X S2 := by
  unfold llo lup
  apply le_min
  · nlinarith
  · nlinarith

theorem llo_ge {X bm S2 : ℝ} (hX : 0 ≤ X) (hbm : bm ≤ 1) (hS : S2 ≤ X) : -(49/240) ≤ llo X bm S2 := by
  unfold llo
  have : X*bm ≤ X := by nlinarith
  nlinarith [sq_nonneg (X - 17/5)]

section
variable {s : Fin 4 → ℝ} (hs : Adm s) (e : Fin 4 → Bool)
include hs

theorem bb_nonneg (μ : Fin 4) : 0 ≤ bb s e μ := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_le_one (μ : Fin 4) : bb s e μ ≤ 1 := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_ge_s (μ : Fin 4) : s μ ≤ bb s e μ := by
  have := hs μ; unfold bb; split_ifs <;> linarith
theorem bb_le_BM (μ : Fin 4) : bb s e μ ≤ BM s e := by
  unfold BM; fin_cases μ <;> simp
theorem BM_le_one : BM s e ≤ 1 := by
  unfold BM
  exact max_le (max_le (bb_le_one hs e 0) (bb_le_one hs e 1))
    (max_le (bb_le_one hs e 2) (bb_le_one hs e 3))
theorem XX_nonneg : 0 ≤ XX s e := by
  unfold XX; exact Finset.sum_nonneg (fun μ _ => bb_nonneg hs e μ)
theorem XX_le_four : XX s e ≤ 4 := by
  unfold XX; simp only [Fin.sum_univ_four]
  linarith [bb_le_one hs e 0, bb_le_one hs e 1, bb_le_one hs e 2, bb_le_one hs e 3]
theorem SS_le_XX : SS s e ≤ XX s e := by
  unfold XX SS
  apply Finset.sum_le_sum; intro μ _
  nlinarith [bb_nonneg hs e μ, bb_le_one hs e μ]
theorem SS_cs : (XX s e)^2/4 ≤ SS s e := by
  unfold XX SS; simp only [Fin.sum_univ_four]
  nlinarith [sq_nonneg (bb s e 0 - bb s e 1), sq_nonneg (bb s e 0 - bb s e 2),
    sq_nonneg (bb s e 0 - bb s e 3), sq_nonneg (bb s e 1 - bb s e 2),
    sq_nonneg (bb s e 1 - bb s e 3), sq_nonneg (bb s e 2 - bb s e 3)]
theorem SS_le_XBM : SS s e ≤ XX s e * BM s e := by
  unfold XX SS; rw [Finset.sum_mul]
  apply Finset.sum_le_sum; intro μ _
  nlinarith [bb_nonneg hs e μ, bb_le_BM hs e μ]
end

/-- `U3(X) = 1 - X/2 + 3X²/32`: the upper end `λ_up` with `Σ b² ≥ X²/4` inserted -/
def U3 (X : ℝ) : ℝ := 1 - X/2 + 3*X^2/32

/-- `E_ν = Σ_e (H/X_e) κ⁺_e (1 - b_{e,ν})` (Theorem 3, refined brackets) -/
def EE (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ := ∑ e, HH s / XX s e * kplus s e * (1 - bb s e ν)

/-- the majorant `E3_ν = Σ_e (H/X_e) U3(X_e)² (1 - b_{e,ν})` -/
def E3 (s : Fin 4 → ℝ) (ν : Fin 4) : ℝ :=
  ∑ e, HH s / XX s e * (U3 (XX s e))^2 * (1 - bb s e ν)

theorem U3_ge (X : ℝ) : 1/3 ≤ U3 X := by
  unfold U3; nlinarith [sq_nonneg (X - 8/3)]

theorem kplus_le_U3 {s : Fin 4 → ℝ} (hs : Adm s) (e : Fin 4 → Bool) :
    kplus s e ≤ (U3 (XX s e))^2 := by
  have l1 : lamLo s e ≤ lamUp s e :=
    llo_le_lup (XX_nonneg hs e) (XX_le_four hs e) (SS_cs hs e) (SS_le_XBM hs e)
  have l4 : -(49/240) ≤ lamLo s e := llo_ge (XX_nonneg hs e) (BM_le_one hs e) (SS_le_XX hs e)
  have hup : lamUp s e ≤ U3 (XX s e) := by
    unfold lamUp lup U3
    apply le_trans (min_le_right _ _)
    nlinarith [SS_cs hs e]
  have hU := U3_ge (XX s e)
  unfold kplus
  apply max_le
  · nlinarith
  · nlinarith

theorem HH_nonneg {s : Fin 4 → ℝ} (hs : Adm s) : 0 ≤ HH s := by
  unfold HH
  apply mul_nonneg (by norm_num)
  exact Finset.sum_nonneg (fun μ _ => mul_nonneg (hs μ).1 (by linarith [(hs μ).2]))

/-- **step 1** : `E_ν ≤ E3_ν` for every admissible `s` -/
theorem EE_le_E3 {s : Fin 4 → ℝ} (hs : Adm s) (ν : Fin 4) : EE s ν ≤ E3 s ν := by
  unfold EE E3
  apply Finset.sum_le_sum; intro e _
  have h1 : 0 ≤ HH s / XX s e := div_nonneg (HH_nonneg hs) (XX_nonneg hs e)
  have h2 : 0 ≤ 1 - bb s e ν := by linarith [bb_le_one hs e ν]
  exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (kplus_le_U3 hs e) h1) h2

end TauStageZero

/-! ## Joining the three stages: `E_ν < 4` for every `q ≠ 0`  -/

namespace FreeStageOS

open TauStageZero

theorem XX_pos {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (e : Fin 4 → Bool) :
    0 < XX s e := by
  obtain ⟨μ, hμ⟩ := hne
  have h : s μ ≤ XX s e :=
    le_trans (bb_ge_s hs e μ)
      (Finset.single_le_sum (f := fun μ => bb s e μ) (fun μ _ => bb_nonneg hs e μ)
        (Finset.mem_univ μ))
  linarith

theorem E3_term (H X w : ℝ) (hX : X ≠ 0) : H / X * (U3 X)^2 * w = H * (G3 X * w) := by
  unfold U3 G3; field_simp; ring

theorem E3_G3 {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (ν : Fin 4) :
    E3 s ν = HH s * ∑ e, G3 (XX s e) * (1 - bb s e ν) := by
  unfold E3; rw [Finset.mul_sum]
  exact Finset.sum_congr rfl (fun e _ => E3_term _ _ _ (ne_of_gt (XX_pos hs hne e)))

theorem sumG3_FF0 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 0)) = FF (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 2) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF1 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 1)) = FF (1 - 2*s 1) (1 - 2*s 0) (1 - 2*s 2) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF2 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 2)) = FF (1 - 2*s 2) (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 3) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sumG3_FF3 (s : Fin 4 → ℝ) :
    (∑ e, G3 (XX s e) * (1 - bb s e 3)) = FF (1 - 2*s 3) (1 - 2*s 0) (1 - 2*s 1) (1 - 2*s 2) := by
  rw [sum16]
  simp only [XX, bb, Fin.sum_univ_four, Matrix.cons_val_zero, Matrix.cons_val_one,
    Matrix.cons_val_two, Matrix.cons_val_three, Matrix.head_cons, Matrix.tail_cons]
  simp only [if_true, if_false, Bool.false_eq_true]
  unfold FF Fo G3; ring

theorem sq0 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 2)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq1 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 1)^2 + (1 - 2*s 0)^2 + (1 - 2*s 2)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq2 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 2)^2 + (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 3)^2 := by
  simp only [Fin.sum_univ_four] <;> ring
theorem sq3 (s : Fin 4 → ℝ) :
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s 3)^2 + (1 - 2*s 0)^2 + (1 - 2*s 1)^2 + (1 - 2*s 2)^2 := by
  simp only [Fin.sum_univ_four] <;> ring

/-- the sixteen aliases regrouped by `e_ν`: `Σ_e G3(X_e)(1 - b_{e,ν}) = F(c)`, `c = 1 - 2s` -/
theorem sumG3_FF (s : Fin 4 → ℝ) (ν : Fin 4) : ∃ a b d : Fin 4,
    (∑ e, G3 (XX s e) * (1 - bb s e ν)) = FF (1 - 2*s ν) (1 - 2*s a) (1 - 2*s b) (1 - 2*s d) ∧
    ∑ μ, (1 - 2*s μ)^2 = (1 - 2*s ν)^2 + (1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2 := by
  fin_cases ν
  · exact ⟨1, 2, 3, sumG3_FF0 s, sq0 s⟩
  · exact ⟨0, 2, 3, sumG3_FF1 s, sq1 s⟩
  · exact ⟨0, 1, 3, sumG3_FF2 s, sq2 s⟩
  · exact ⟨0, 1, 2, sumG3_FF3 s, sq3 s⟩

theorem HH_c (s : Fin 4 → ℝ) : HH s = 4 - ∑ μ, (1 - 2*s μ)^2 := by
  simp only [HH, Fin.sum_univ_four]; ring

theorem csq_lt {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) : ∑ μ, (1 - 2*s μ)^2 < 4 := by
  obtain ⟨μ, hμ⟩ := hne
  have h : ∑ μ, (1 - 2*s μ)^2 < ∑ _μ : Fin 4, (1:ℝ) := by
    apply Finset.sum_lt_sum
    · intro i _
      have := hs i
      nlinarith
    · refine ⟨μ, Finset.mem_univ μ, ?_⟩
      have := hs μ
      nlinarith
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin] at h
  norm_num at h
  exact h

/-- **(OS↑) at stage 0, scalar form**: `E_ν < 4` for every admissible `s ≠ 0` and every `ν` -/
theorem E_lt_four_s {s : Fin 4 → ℝ} (hs : Adm s) (hne : ∃ μ, 0 < s μ) (ν : Fin 4) :
    EE s ν < 4 := by
  obtain ⟨a, b, d, hF, hsq⟩ := sumG3_FF s ν
  have hc : ∀ μ, 0 ≤ 1 - 2*s μ ∧ 1 - 2*s μ ≤ 1 := fun μ =>
    ⟨by linarith [(hs μ).2], by linarith [(hs μ).1]⟩
  have hlt := csq_lt hs hne
  rw [hsq] at hlt
  have hT : 0 ≤ ((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3 := by positivity
  obtain ⟨t, htd⟩ : ∃ t, t = Real.sqrt (((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3) :=
    ⟨_, rfl⟩
  have ht0 : 0 ≤ t := by rw [htd]; exact Real.sqrt_nonneg _
  have ht2 : t^2 = ((1 - 2*s a)^2 + (1 - 2*s b)^2 + (1 - 2*s d)^2)/3 := by
    rw [htd]; exact Real.sq_sqrt hT
  have ha := hc a
  have hb := hc b
  have hd := hc d
  have hn := hc ν
  have ht1 : t ≤ 1 := by nlinarith
  have hne' : (1 - 2*s ν) + 3*t < 4 := by nlinarith
  have hsm := FF_smooth hn.1 hn.2 ha.1 hb.1 hd.1 ht0 (by rw [ht2]; ring) hne'
  have hs3 := eq_lt_four hn.1 hn.2 ht0 ht1 hne'
  calc EE s ν ≤ E3 s ν := EE_le_E3 hs ν
    _ = HH s * FF (1 - 2*s ν) (1 - 2*s a) (1 - 2*s b) (1 - 2*s d) := by rw [E3_G3 hs hne, hF]
    _ ≤ HH s * FF (1 - 2*s ν) t t t := mul_le_mul_of_nonneg_left hsm (HH_nonneg hs)
    _ = (4 - (1 - 2*s ν)^2 - 3*t^2) * Feq (1 - 2*s ν) t := by rw [FF_eq, HH_c, hsq, ht2]; ring
    _ < 4 := hs3

/-- **(OS↑) at stage 0**: with `s_μ = (1 - cos(q_μ/2))/2`, `E_ν < 4` for every
`q ∈ [-π, π]⁴ ∖ {0}` and every `ν` -/
theorem E_lt_four (q : Fin 4 → ℝ) (hq : ∀ μ, |q μ| ≤ Real.pi) (hq0 : q ≠ 0) (ν : Fin 4) :
    EE (fun μ => (1 - Real.cos (q μ / 2))/2) ν < 4 := by
  apply E_lt_four_s
  · intro μ
    have h := abs_le.mp (hq μ)
    have hc0 : 0 ≤ Real.cos (q μ / 2) :=
      Real.cos_nonneg_of_mem_Icc ⟨by linarith, by linarith⟩
    have hc1 := Real.cos_le_one (q μ / 2)
    constructor <;> simp only <;> linarith
  · obtain ⟨μ, hμ⟩ := Function.ne_iff.mp hq0
    refine ⟨μ, ?_⟩
    have h := abs_le.mp (hq μ)
    have hpi := Real.pi_pos
    have hne1 : Real.cos (q μ / 2) ≠ 1 := by
      intro h1
      have := (Real.cos_eq_one_iff_of_lt_of_lt (x := q μ / 2) (by linarith) (by linarith)).mp h1
      apply hμ; simp only [Pi.zero_apply]; linarith
    have hc1 := Real.cos_le_one (q μ / 2)
    have : Real.cos (q μ / 2) < 1 := lt_of_le_of_ne hc1 hne1
    show 0 < (1 - Real.cos (q μ / 2))/2
    linarith

end FreeStageOS


-- ===== new part : OSUpFree.part.lean =====
/-! # L2 seam (b): (OS↑) from the free-stage bound, in one file (plan-20 §4c)

Paper (for checking): The definitions `EE`, `Adm` (and below them `bb`,
`XX`, `SS`, `BM`, `HH`, `lamLo`, `lamUp`, `kplus`, `llo`, `lup`) of `OSUpBridge` (All1135) and of
 `TauStageZero` are the same text; here they are identified by `rfl` (`EE_eq`), and
**`os_up_free`** is `OSUpBridge.os_up_of_free` with its input `hE` supplied by 
`FreeStageOS.E_lt_four_s`. **`hEE_free`**: the `hEE` of `coupling_converges_*` for momenta with
`|θ_ν| ≤ π/4`. -/

namespace OSUpFree

theorem EE_eq (s : Fin 4 → ℝ) (ν : Fin 4) : OSUpBridge.EE s ν = TauStageZero.EE s ν := rfl

theorem Adm_iff (s : Fin 4 → ℝ) : OSUpBridge.Adm s ↔ TauStageZero.Adm s := Iff.rfl

theorem os_up_free {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = OneStepBridge.thR (th q) ζ) (hω : ∀ q, 0 < OneStepET.omF th q)
    (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4) :
    UniformBracket.Lw (OneStepBridge.Mfam th rq
        (fun q => (OneStepET.omF th q)⁻¹ • OneStepBridge.Pfam th q))
      (fun q => (OneStepET.omF th q)⁻¹ • OneStepBridge.Pfam th q) :=
  OSUpBridge.os_up_of_free th rq hrq hω hth
    (fun hs hne ν => by rw [EE_eq]; exact FreeStageOS.E_lt_four_s hs hne ν)

theorem hEE_free {Q : Type*} (th : Q → (Fin 4 → ℝ)) (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4)
    (q : Q) (ν : Fin 4) : OSUpBridge.EE (fun ν => Real.sin (th q ν) ^ 2) ν ≤ 4 := by
  have hadm : TauStageZero.Adm (fun ν => Real.sin (th q ν) ^ 2) :=
    fun μ => ⟨sq_nonneg _, OSUpBridge.sin_sq_le_half (hth q μ)⟩
  by_cases hne : ∃ μ, 0 < Real.sin (th q μ) ^ 2
  · rw [EE_eq]; exact (FreeStageOS.E_lt_four_s hadm hne ν).le
  · push_neg at hne
    have h0 : ∀ μ, Real.sin (th q μ) ^ 2 = 0 := fun μ => le_antisymm (hne μ) (sq_nonneg _)
    simp only [OSUpBridge.EE, OSUpBridge.HH, h0, zero_mul, mul_zero, Finset.sum_const_zero,
      zero_div, sub_zero]
    norm_num

end OSUpFree

#print axioms OSUpFree.EE_eq
#print axioms OSUpFree.os_up_free
#print axioms OSUpFree.hEE_free

-- ===== new part : OSUpQpos.part.lean =====
/-! # T0: (OS↑) on the whole of `Qpos`, with no hypotheses

The statements `OSUpFree.os_up_free` and
`OSUpBridge.os_up_of_free` above take both `hrq` (the family is closed under the aliases
`thR θ ζ = θ/2 + ζπ/4`) and `hth : ∀ q ν, |th q ν| ≤ π/4`; for a nonempty `Q` these are
incompatible (two alias steps with `ζ ≡ true` leave the box), so those two statements are vacuous
on any nonempty family (`box_alias_closed_empty` below). `OSUpFree.hEE_free` takes no `hrq` and is a
true statement about points in the box only.

Here the input `hEE` of `OSUpBridge.os_up` is discharged at **every** point:
* `EE_bbflip`: `EE` is invariant under `s ↦ (bb s f ·)` (flip the coordinates in `f`, `s_μ ↦ 1 − s_μ`),
  because `bb (bb s f) e = bb s (e xor f)` and `e ↦ e xor f` is a bijection of `{0,1}⁴`;
* `EE_flip`: the one-coordinate form;
* `hEE_all`: `EE (sin² θ) ν ≤ 4` for every `θ` (fold to `min(s, 1 − s)`, which is `Adm`, and use
  `FreeStageOS.E_lt_four_s`; the case `s′ = 0` gives `EE = 0`);
* `os_up_Qpos`: `𝓜(P/ω) ≼ P/ω` on `Qpos` with the aliases `rqPos` (no hypotheses);
* `Gs_le_G0`: `𝓜^k(P/ω) ≼ P/ω` for every `k` (`C₊ = 1` at every stage). -/

namespace OSUpQpos

open Finset OneStepBridge OneStepET OneStepFinal

/-- `e xor f`, coordinatewise. -/
def bxor (e f : Fin 4 → Bool) : Fin 4 → Bool := fun j => xor (e j) (f j)

theorem bxor_invol (f : Fin 4 → Bool) : Function.Involutive (fun e => bxor e f) := by
  intro e; funext j; simp [bxor]

theorem bb_bb (s : Fin 4 → ℝ) (f e : Fin 4 → Bool) (j : Fin 4) :
    OSUpBridge.bb (fun i => OSUpBridge.bb s f i) e j = OSUpBridge.bb s (bxor e f) j := by
  unfold OSUpBridge.bb bxor
  cases h1 : e j <;> cases h2 : f j <;> simp [h1, h2]

theorem HH_bb (s : Fin 4 → ℝ) (f : Fin 4 → Bool) :
    OSUpBridge.HH (fun i => OSUpBridge.bb s f i) = OSUpBridge.HH s := by
  unfold OSUpBridge.HH
  congr 1
  refine Finset.sum_congr rfl fun j _ => ?_
  unfold OSUpBridge.bb
  cases h : f j <;> simp [h] <;> ring

/-- **`EE` is invariant under flipping any set of coordinates `s_μ ↦ 1 − s_μ`.** -/
theorem EE_bbflip (s : Fin 4 → ℝ) (f : Fin 4 → Bool) (ν : Fin 4) :
    OSUpBridge.EE (fun i => OSUpBridge.bb s f i) ν = OSUpBridge.EE s ν := by
  have hX : ∀ e, OSUpBridge.XX (fun i => OSUpBridge.bb s f i) e = OSUpBridge.XX s (bxor e f) :=
    fun e => by unfold OSUpBridge.XX; simp only [bb_bb]
  have hS : ∀ e, OSUpBridge.SS (fun i => OSUpBridge.bb s f i) e = OSUpBridge.SS s (bxor e f) :=
    fun e => by unfold OSUpBridge.SS; simp only [bb_bb]
  have hB : ∀ e, OSUpBridge.BM (fun i => OSUpBridge.bb s f i) e = OSUpBridge.BM s (bxor e f) :=
    fun e => by unfold OSUpBridge.BM; simp only [bb_bb]
  have hK : ∀ e, OSUpBridge.kplus (fun i => OSUpBridge.bb s f i) e =
      OSUpBridge.kplus s (bxor e f) := fun e => by
    unfold OSUpBridge.kplus OSUpBridge.lamLo OSUpBridge.lamUp
    rw [hX, hS, hB]
  unfold OSUpBridge.EE
  rw [HH_bb]
  simp only [hX, hK, bb_bb]
  exact Fintype.sum_equiv (bxor_invol f).toPerm _ _ (fun e => rfl)

/-- **`EE_flip`** : one coordinate. -/
theorem EE_flip (s : Fin 4 → ℝ) (μ ν : Fin 4) :
    OSUpBridge.EE (Function.update s μ (1 - s μ)) ν = OSUpBridge.EE s ν := by
  have h : Function.update s μ (1 - s μ) =
      fun i => OSUpBridge.bb s (fun j => decide (j = μ)) i := by
    funext i
    by_cases hi : i = μ
    · subst hi; simp [OSUpBridge.bb]
    · simp [OSUpBridge.bb, Function.update, hi]
  rw [h, EE_bbflip]

/-- `hEE` at every `θ`, from the free-stage bound on the admissible set (as a hypothesis `hE`,
in the exact form of `FreeStageOS.E_lt_four_s`). -/
theorem hEE_all_of
    (hE : ∀ {s : Fin 4 → ℝ}, OSUpBridge.Adm s → (∃ μ, 0 < s μ) → ∀ ν, OSUpBridge.EE s ν < 4)
    (θ : Fin 4 → ℝ) (ν : Fin 4) :
    OSUpBridge.EE (fun ν => Real.sin (θ ν) ^ 2) ν ≤ 4 := by
  set s : Fin 4 → ℝ := fun ν => Real.sin (θ ν) ^ 2 with hs_def
  have hs : ∀ j, 0 ≤ s j ∧ s j ≤ 1 := fun j =>
    ⟨sq_nonneg _, Real.sin_sq_le_one _⟩
  set f : Fin 4 → Bool := fun j => decide (1 / 2 < s j) with hf_def
  have hadm : OSUpBridge.Adm (fun i => OSUpBridge.bb s f i) := by
    intro j
    show 0 ≤ OSUpBridge.bb s f j ∧ OSUpBridge.bb s f j ≤ 1 / 2
    have hv : OSUpBridge.bb s f j = if 1 / 2 < s j then 1 - s j else s j := by
      simp [OSUpBridge.bb, hf_def]
    rw [hv]
    by_cases hj : 1 / 2 < s j
    · rw [if_pos hj]; constructor <;> linarith [(hs j).2]
    · rw [if_neg hj]; push_neg at hj; constructor <;> linarith [(hs j).1]
  rw [← EE_bbflip s f ν]
  by_cases hne : ∃ μ, 0 < OSUpBridge.bb s f μ
  · exact (hE hadm hne ν).le
  · push_neg at hne
    have h0 : ∀ μ, OSUpBridge.bb s f μ = 0 := fun μ => le_antisymm (hne μ) (hadm μ).1
    have hH : OSUpBridge.HH (fun i => OSUpBridge.bb s f i) = 0 := by
      unfold OSUpBridge.HH; simp [h0]
    unfold OSUpBridge.EE
    rw [hH]
    simp

/-- **`hEE_all`** : `E_ν ≤ 4` at every momentum (no box, no `ω > 0` needed). -/
theorem hEE_all (θ : Fin 4 → ℝ) (ν : Fin 4) :
    OSUpBridge.EE (fun ν => Real.sin (θ ν) ^ 2) ν ≤ 4 :=
  hEE_all_of (fun hs hne ν => by
    rw [OSUpFree.EE_eq]; exact FreeStageOS.E_lt_four_s hs hne ν) θ ν

/-- **(OS↑) for any alias-closed family with `ω > 0`**: no box hypothesis. -/
theorem os_up_family {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) :
    UniformBracket.Lw (Mfam th rq (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) :=
  OSUpBridge.os_up th rq hrq hω fun q ν => hEE_all (th q) ν

/-- **`os_up_Qpos`** : (OS↑) on `Qpos`, no hypotheses. -/
theorem os_up_Qpos :
    UniformBracket.Lw (Mfam (Subtype.val : Qpos → _) rqPos
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) :=
  os_up_family Subtype.val rqPos (fun _ _ => rfl) (fun q => q.2)

/-- **`Gs_le_G0`** : every stage `G_k = 𝓜^k(P/ω) ≼ P/ω` on `Qpos` (`C₊ = 1`). -/
theorem Gs_le_G0 (k : ℕ) :
    UniformBracket.Lw ((⇑(Mfam (Subtype.val : Qpos → _) rqPos))^[k]
        (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q))
      (fun q => (omF Subtype.val q)⁻¹ • Pfam Subtype.val q) := by
  induction k with
  | zero => exact UniformBracket.Lw.refl _
  | succ k ih =>
    exact UniformBracket.Lw.trans
      (UniformBracket.iterate_antitone (Mfam Subtype.val rqPos)
        (Mfam_orderPreserving Subtype.val rqPos) os_up_Qpos k) ih

/-- The family version of `Gs_le_G0`. -/
theorem Gs_le_G0_family {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hω : ∀ q, 0 < omF th q) (k : ℕ) :
    UniformBracket.Lw ((⇑(Mfam th rq))^[k] (fun q => (omF th q)⁻¹ • Pfam th q))
      (fun q => (omF th q)⁻¹ • Pfam th q) := by
  induction k with
  | zero => exact UniformBracket.Lw.refl _
  | succ k ih =>
    exact UniformBracket.Lw.trans
      (UniformBracket.iterate_antitone (Mfam th rq) (Mfam_orderPreserving th rq)
        (os_up_family th rq hrq hω) k) ih

/-- **Why `os_up_free` / `os_up_of_free` are vacuous**: an alias-closed family whose every member
lies in the box `|θ_ν| ≤ π/4` is empty. -/
theorem box_alias_closed_empty {Q : Type*} (th : Q → (Fin 4 → ℝ)) (rq : Q → (Fin 4 → Bool) → Q)
    (hrq : ∀ q ζ, th (rq q ζ) = thR (th q) ζ) (hth : ∀ q ν, |th q ν| ≤ Real.pi / 4) :
    IsEmpty Q := by
  refine ⟨fun q => ?_⟩
  have h2 := hth (rq (rq q fun _ => true) fun _ => true) 0
  have h0 := hth q 0
  rw [hrq, hrq] at h2
  simp only [thR, if_true] at h2
  have := (abs_le.mp h0).1
  have := (abs_le.mp h2).2
  linarith [Real.pi_pos]

end OSUpQpos

#print axioms OSUpQpos.EE_flip
#print axioms OSUpQpos.hEE_all
#print axioms OSUpQpos.os_up_Qpos
#print axioms OSUpQpos.Gs_le_G0
#print axioms OSUpQpos.Gs_le_G0_family
#print axioms OSUpQpos.box_alias_closed_empty

